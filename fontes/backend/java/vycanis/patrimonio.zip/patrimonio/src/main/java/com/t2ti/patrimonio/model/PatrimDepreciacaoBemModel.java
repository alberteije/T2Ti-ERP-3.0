package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="patrim_depreciacao_bem")
@NamedQuery(name="PatrimDepreciacaoBemModel.findAll", query="SELECT t FROM PatrimDepreciacaoBemModel t")
public class PatrimDepreciacaoBemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimDepreciacaoBemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_depreciacao")
	private Date dataDepreciacao;

	@Column(name="dias")
	private Integer dias;

	@Column(name="taxa")
	private BigDecimal taxa;

	@Column(name="indice")
	private BigDecimal indice;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="depreciacao_acumulada")
	private BigDecimal depreciacaoAcumulada;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_patrim_bem")
	private PatrimBemModel patrimBemModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataDepreciacao() { 
		return this.dataDepreciacao; 
	} 

	public void setDataDepreciacao(Date dataDepreciacao) { 
		this.dataDepreciacao = dataDepreciacao; 
	} 

	public Integer getDias() { 
		return this.dias; 
	} 

	public void setDias(Integer dias) { 
		this.dias = dias; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

	public BigDecimal getIndice() { 
		return this.indice; 
	} 

	public void setIndice(BigDecimal indice) { 
		this.indice = indice; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public BigDecimal getDepreciacaoAcumulada() { 
		return this.depreciacaoAcumulada; 
	} 

	public void setDepreciacaoAcumulada(BigDecimal depreciacaoAcumulada) { 
		this.depreciacaoAcumulada = depreciacaoAcumulada; 
	} 

	public PatrimBemModel getPatrimBemModel() { 
	return this.patrimBemModel; 
	} 

	public void setPatrimBemModel(PatrimBemModel patrimBemModel) { 
	this.patrimBemModel = patrimBemModel; 
	} 

		
}