package com.t2ti.patrimonio.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.exception.ResourseNotFoundException;
import com.t2ti.patrimonio.exception.BadRequestException;
import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.model.PatrimGrupoBemModel;
import com.t2ti.patrimonio.service.PatrimGrupoBemService;

@RestController
@RequestMapping(value = "/patrim-grupo-bem", produces = "application/json;charset=UTF-8")
public class PatrimGrupoBemController {

	@Autowired
	private PatrimGrupoBemService service;
	
	@GetMapping({ "", "/" })
	public List<PatrimGrupoBemModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [PatrimGrupoBem] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public PatrimGrupoBemModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found PatrimGrupoBem].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found PatrimGrupoBem] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public PatrimGrupoBemModel insert(@RequestBody PatrimGrupoBemModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert PatrimGrupoBem] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public PatrimGrupoBemModel update(@RequestBody PatrimGrupoBemModel objJson) {	
		try {			
			PatrimGrupoBemModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update PatrimGrupoBem].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update PatrimGrupoBem] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PatrimGrupoBem] - Exception: " + e.getMessage());
		}
	}
	
}