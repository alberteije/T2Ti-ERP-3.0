package com.t2ti.patrimonio.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.model.PatrimTipoAquisicaoBemModel;
import com.t2ti.patrimonio.repository.PatrimTipoAquisicaoBemRepository;

@Service
public class PatrimTipoAquisicaoBemService {

	@Autowired
	private PatrimTipoAquisicaoBemRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PatrimTipoAquisicaoBemModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PatrimTipoAquisicaoBemModel> getList(Filter filter) {
		String sql = "select * from patrim_tipo_aquisicao_bem where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PatrimTipoAquisicaoBemModel.class);
		return query.getResultList();
	}

	public PatrimTipoAquisicaoBemModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PatrimTipoAquisicaoBemModel save(PatrimTipoAquisicaoBemModel obj) {
		PatrimTipoAquisicaoBemModel patrimTipoAquisicaoBemModel = repository.save(obj);
		return patrimTipoAquisicaoBemModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PatrimTipoAquisicaoBemModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PatrimTipoAquisicaoBem] - Exception: " + e.getMessage());
		}
	}

}