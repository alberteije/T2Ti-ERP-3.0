package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="patrim_bem")
@NamedQuery(name="PatrimBemModel.findAll", query="SELECT t FROM PatrimBemModel t")
public class PatrimBemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimBemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_nb")
	private String numeroNb;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Temporal(TemporalType.DATE)
@Column(name="data_aquisicao")
	private Date dataAquisicao;

	@Temporal(TemporalType.DATE)
@Column(name="data_aceite")
	private Date dataAceite;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
@Column(name="data_contabilizado")
	private Date dataContabilizado;

	@Temporal(TemporalType.DATE)
@Column(name="data_vistoria")
	private Date dataVistoria;

	@Temporal(TemporalType.DATE)
@Column(name="data_marcacao")
	private Date dataMarcacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_baixa")
	private Date dataBaixa;

	@Temporal(TemporalType.DATE)
@Column(name="vencimento_garantia")
	private Date vencimentoGarantia;

	@Column(name="numero_nota_fiscal")
	private String numeroNotaFiscal;

	@Column(name="numero_serie")
	private String numeroSerie;

	@Column(name="chave_nfe")
	private String chaveNfe;

	@Column(name="valor_original")
	private BigDecimal valorOriginal;

	@Column(name="valor_compra")
	private BigDecimal valorCompra;

	@Column(name="valor_atualizado")
	private BigDecimal valorAtualizado;

	@Column(name="valor_baixa")
	private BigDecimal valorBaixa;

	@Column(name="deprecia")
	private String deprecia;

	@Column(name="metodo_depreciacao")
	private String metodoDepreciacao;

	@Temporal(TemporalType.DATE)
@Column(name="inicio_depreciacao")
	private Date inicioDepreciacao;

	@Temporal(TemporalType.DATE)
@Column(name="ultima_depreciacao")
	private Date ultimaDepreciacao;

	@Column(name="tipo_depreciacao")
	private String tipoDepreciacao;

	@Column(name="taxa_anual_depreciacao")
	private BigDecimal taxaAnualDepreciacao;

	@Column(name="taxa_mensal_depreciacao")
	private BigDecimal taxaMensalDepreciacao;

	@Column(name="taxa_depreciacao_acelerada")
	private BigDecimal taxaDepreciacaoAcelerada;

	@Column(name="taxa_depreciacao_incentivada")
	private BigDecimal taxaDepreciacaoIncentivada;

	@Column(name="funcao")
	private String funcao;

	@OneToMany(mappedBy = "patrimBemModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PatrimDocumentoBemModel> patrimDocumentoBemModelList; 

	@OneToMany(mappedBy = "patrimBemModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PatrimDepreciacaoBemModel> patrimDepreciacaoBemModelList; 

	@OneToMany(mappedBy = "patrimBemModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PatrimMovimentacaoBemModel> patrimMovimentacaoBemModelList; 

	@OneToMany(mappedBy = "patrimBemModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PatrimApoliceSeguroModel> patrimApoliceSeguroModelList; 

	@ManyToOne 
	@JoinColumn(name="id_centro_resultado")
	private CentroResultadoModel centroResultadoModel; 

	@ManyToOne 
	@JoinColumn(name="id_patrim_estado_conservacao")
	private PatrimEstadoConservacaoModel patrimEstadoConservacaoModel; 

	@ManyToOne 
	@JoinColumn(name="id_setor")
	private SetorModel setorModel; 

	@ManyToOne 
	@JoinColumn(name="id_fornecedor")
	private ViewPessoaFornecedorModel viewPessoaFornecedorModel; 

	@ManyToOne 
	@JoinColumn(name="id_patrim_tipo_aquisicao_bem")
	private PatrimTipoAquisicaoBemModel patrimTipoAquisicaoBemModel; 

	@ManyToOne 
	@JoinColumn(name="id_patrim_grupo_bem")
	private PatrimGrupoBemModel patrimGrupoBemModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumeroNb() { 
		return this.numeroNb; 
	} 

	public void setNumeroNb(String numeroNb) { 
		this.numeroNb = numeroNb; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Date getDataAquisicao() { 
		return this.dataAquisicao; 
	} 

	public void setDataAquisicao(Date dataAquisicao) { 
		this.dataAquisicao = dataAquisicao; 
	} 

	public Date getDataAceite() { 
		return this.dataAceite; 
	} 

	public void setDataAceite(Date dataAceite) { 
		this.dataAceite = dataAceite; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public Date getDataContabilizado() { 
		return this.dataContabilizado; 
	} 

	public void setDataContabilizado(Date dataContabilizado) { 
		this.dataContabilizado = dataContabilizado; 
	} 

	public Date getDataVistoria() { 
		return this.dataVistoria; 
	} 

	public void setDataVistoria(Date dataVistoria) { 
		this.dataVistoria = dataVistoria; 
	} 

	public Date getDataMarcacao() { 
		return this.dataMarcacao; 
	} 

	public void setDataMarcacao(Date dataMarcacao) { 
		this.dataMarcacao = dataMarcacao; 
	} 

	public Date getDataBaixa() { 
		return this.dataBaixa; 
	} 

	public void setDataBaixa(Date dataBaixa) { 
		this.dataBaixa = dataBaixa; 
	} 

	public Date getVencimentoGarantia() { 
		return this.vencimentoGarantia; 
	} 

	public void setVencimentoGarantia(Date vencimentoGarantia) { 
		this.vencimentoGarantia = vencimentoGarantia; 
	} 

	public String getNumeroNotaFiscal() { 
		return this.numeroNotaFiscal; 
	} 

	public void setNumeroNotaFiscal(String numeroNotaFiscal) { 
		this.numeroNotaFiscal = numeroNotaFiscal; 
	} 

	public String getNumeroSerie() { 
		return this.numeroSerie; 
	} 

	public void setNumeroSerie(String numeroSerie) { 
		this.numeroSerie = numeroSerie; 
	} 

	public String getChaveNfe() { 
		return this.chaveNfe; 
	} 

	public void setChaveNfe(String chaveNfe) { 
		this.chaveNfe = chaveNfe; 
	} 

	public BigDecimal getValorOriginal() { 
		return this.valorOriginal; 
	} 

	public void setValorOriginal(BigDecimal valorOriginal) { 
		this.valorOriginal = valorOriginal; 
	} 

	public BigDecimal getValorCompra() { 
		return this.valorCompra; 
	} 

	public void setValorCompra(BigDecimal valorCompra) { 
		this.valorCompra = valorCompra; 
	} 

	public BigDecimal getValorAtualizado() { 
		return this.valorAtualizado; 
	} 

	public void setValorAtualizado(BigDecimal valorAtualizado) { 
		this.valorAtualizado = valorAtualizado; 
	} 

	public BigDecimal getValorBaixa() { 
		return this.valorBaixa; 
	} 

	public void setValorBaixa(BigDecimal valorBaixa) { 
		this.valorBaixa = valorBaixa; 
	} 

	public String getDeprecia() { 
		return this.deprecia; 
	} 

	public void setDeprecia(String deprecia) { 
		this.deprecia = deprecia; 
	} 

	public String getMetodoDepreciacao() { 
		return this.metodoDepreciacao; 
	} 

	public void setMetodoDepreciacao(String metodoDepreciacao) { 
		this.metodoDepreciacao = metodoDepreciacao; 
	} 

	public Date getInicioDepreciacao() { 
		return this.inicioDepreciacao; 
	} 

	public void setInicioDepreciacao(Date inicioDepreciacao) { 
		this.inicioDepreciacao = inicioDepreciacao; 
	} 

	public Date getUltimaDepreciacao() { 
		return this.ultimaDepreciacao; 
	} 

	public void setUltimaDepreciacao(Date ultimaDepreciacao) { 
		this.ultimaDepreciacao = ultimaDepreciacao; 
	} 

	public String getTipoDepreciacao() { 
		return this.tipoDepreciacao; 
	} 

	public void setTipoDepreciacao(String tipoDepreciacao) { 
		this.tipoDepreciacao = tipoDepreciacao; 
	} 

	public BigDecimal getTaxaAnualDepreciacao() { 
		return this.taxaAnualDepreciacao; 
	} 

	public void setTaxaAnualDepreciacao(BigDecimal taxaAnualDepreciacao) { 
		this.taxaAnualDepreciacao = taxaAnualDepreciacao; 
	} 

	public BigDecimal getTaxaMensalDepreciacao() { 
		return this.taxaMensalDepreciacao; 
	} 

	public void setTaxaMensalDepreciacao(BigDecimal taxaMensalDepreciacao) { 
		this.taxaMensalDepreciacao = taxaMensalDepreciacao; 
	} 

	public BigDecimal getTaxaDepreciacaoAcelerada() { 
		return this.taxaDepreciacaoAcelerada; 
	} 

	public void setTaxaDepreciacaoAcelerada(BigDecimal taxaDepreciacaoAcelerada) { 
		this.taxaDepreciacaoAcelerada = taxaDepreciacaoAcelerada; 
	} 

	public BigDecimal getTaxaDepreciacaoIncentivada() { 
		return this.taxaDepreciacaoIncentivada; 
	} 

	public void setTaxaDepreciacaoIncentivada(BigDecimal taxaDepreciacaoIncentivada) { 
		this.taxaDepreciacaoIncentivada = taxaDepreciacaoIncentivada; 
	} 

	public String getFuncao() { 
		return this.funcao; 
	} 

	public void setFuncao(String funcao) { 
		this.funcao = funcao; 
	} 

	public Set<PatrimDocumentoBemModel> getPatrimDocumentoBemModelList() { 
	return this.patrimDocumentoBemModelList; 
	} 

	public void setPatrimDocumentoBemModelList(Set<PatrimDocumentoBemModel> patrimDocumentoBemModelList) { 
	this.patrimDocumentoBemModelList = patrimDocumentoBemModelList; 
		for (PatrimDocumentoBemModel patrimDocumentoBemModel : patrimDocumentoBemModelList) { 
			patrimDocumentoBemModel.setPatrimBemModel(this); 
		}
	} 

	public Set<PatrimDepreciacaoBemModel> getPatrimDepreciacaoBemModelList() { 
	return this.patrimDepreciacaoBemModelList; 
	} 

	public void setPatrimDepreciacaoBemModelList(Set<PatrimDepreciacaoBemModel> patrimDepreciacaoBemModelList) { 
	this.patrimDepreciacaoBemModelList = patrimDepreciacaoBemModelList; 
		for (PatrimDepreciacaoBemModel patrimDepreciacaoBemModel : patrimDepreciacaoBemModelList) { 
			patrimDepreciacaoBemModel.setPatrimBemModel(this); 
		}
	} 

	public Set<PatrimMovimentacaoBemModel> getPatrimMovimentacaoBemModelList() { 
	return this.patrimMovimentacaoBemModelList; 
	} 

	public void setPatrimMovimentacaoBemModelList(Set<PatrimMovimentacaoBemModel> patrimMovimentacaoBemModelList) { 
	this.patrimMovimentacaoBemModelList = patrimMovimentacaoBemModelList; 
		for (PatrimMovimentacaoBemModel patrimMovimentacaoBemModel : patrimMovimentacaoBemModelList) { 
			patrimMovimentacaoBemModel.setPatrimBemModel(this); 
		}
	} 

	public Set<PatrimApoliceSeguroModel> getPatrimApoliceSeguroModelList() { 
	return this.patrimApoliceSeguroModelList; 
	} 

	public void setPatrimApoliceSeguroModelList(Set<PatrimApoliceSeguroModel> patrimApoliceSeguroModelList) { 
	this.patrimApoliceSeguroModelList = patrimApoliceSeguroModelList; 
		for (PatrimApoliceSeguroModel patrimApoliceSeguroModel : patrimApoliceSeguroModelList) { 
			patrimApoliceSeguroModel.setPatrimBemModel(this); 
		}
	} 

	public CentroResultadoModel getCentroResultadoModel() { 
	return this.centroResultadoModel; 
	} 

	public void setCentroResultadoModel(CentroResultadoModel centroResultadoModel) { 
	this.centroResultadoModel = centroResultadoModel; 
	} 

	public PatrimEstadoConservacaoModel getPatrimEstadoConservacaoModel() { 
	return this.patrimEstadoConservacaoModel; 
	} 

	public void setPatrimEstadoConservacaoModel(PatrimEstadoConservacaoModel patrimEstadoConservacaoModel) { 
	this.patrimEstadoConservacaoModel = patrimEstadoConservacaoModel; 
	} 

	public SetorModel getSetorModel() { 
	return this.setorModel; 
	} 

	public void setSetorModel(SetorModel setorModel) { 
	this.setorModel = setorModel; 
	} 

	public ViewPessoaFornecedorModel getViewPessoaFornecedorModel() { 
	return this.viewPessoaFornecedorModel; 
	} 

	public void setViewPessoaFornecedorModel(ViewPessoaFornecedorModel viewPessoaFornecedorModel) { 
	this.viewPessoaFornecedorModel = viewPessoaFornecedorModel; 
	} 

	public PatrimTipoAquisicaoBemModel getPatrimTipoAquisicaoBemModel() { 
	return this.patrimTipoAquisicaoBemModel; 
	} 

	public void setPatrimTipoAquisicaoBemModel(PatrimTipoAquisicaoBemModel patrimTipoAquisicaoBemModel) { 
	this.patrimTipoAquisicaoBemModel = patrimTipoAquisicaoBemModel; 
	} 

	public PatrimGrupoBemModel getPatrimGrupoBemModel() { 
	return this.patrimGrupoBemModel; 
	} 

	public void setPatrimGrupoBemModel(PatrimGrupoBemModel patrimGrupoBemModel) { 
	this.patrimGrupoBemModel = patrimGrupoBemModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}