package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="patrim_grupo_bem")
@NamedQuery(name="PatrimGrupoBemModel.findAll", query="SELECT t FROM PatrimGrupoBemModel t")
public class PatrimGrupoBemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimGrupoBemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="conta_ativo_imobilizado")
	private String contaAtivoImobilizado;

	@Column(name="conta_depreciacao_acumulada")
	private String contaDepreciacaoAcumulada;

	@Column(name="conta_despesa_depreciacao")
	private String contaDespesaDepreciacao;

	@Column(name="codigo_historico")
	private Integer codigoHistorico;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getContaAtivoImobilizado() { 
		return this.contaAtivoImobilizado; 
	} 

	public void setContaAtivoImobilizado(String contaAtivoImobilizado) { 
		this.contaAtivoImobilizado = contaAtivoImobilizado; 
	} 

	public String getContaDepreciacaoAcumulada() { 
		return this.contaDepreciacaoAcumulada; 
	} 

	public void setContaDepreciacaoAcumulada(String contaDepreciacaoAcumulada) { 
		this.contaDepreciacaoAcumulada = contaDepreciacaoAcumulada; 
	} 

	public String getContaDespesaDepreciacao() { 
		return this.contaDespesaDepreciacao; 
	} 

	public void setContaDespesaDepreciacao(String contaDespesaDepreciacao) { 
		this.contaDespesaDepreciacao = contaDespesaDepreciacao; 
	} 

	public Integer getCodigoHistorico() { 
		return this.codigoHistorico; 
	} 

	public void setCodigoHistorico(Integer codigoHistorico) { 
		this.codigoHistorico = codigoHistorico; 
	} 

		
}