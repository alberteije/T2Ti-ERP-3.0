package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="patrim_taxa_depreciacao")
@NamedQuery(name="PatrimTaxaDepreciacaoModel.findAll", query="SELECT t FROM PatrimTaxaDepreciacaoModel t")
public class PatrimTaxaDepreciacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimTaxaDepreciacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="ncm")
	private String ncm;

	@Column(name="bem")
	private String bem;

	@Column(name="vida")
	private BigDecimal vida;

	@Column(name="taxa")
	private BigDecimal taxa;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNcm() { 
		return this.ncm; 
	} 

	public void setNcm(String ncm) { 
		this.ncm = ncm; 
	} 

	public String getBem() { 
		return this.bem; 
	} 

	public void setBem(String bem) { 
		this.bem = bem; 
	} 

	public BigDecimal getVida() { 
		return this.vida; 
	} 

	public void setVida(BigDecimal vida) { 
		this.vida = vida; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

		
}