package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="patrim_apolice_seguro")
@NamedQuery(name="PatrimApoliceSeguroModel.findAll", query="SELECT t FROM PatrimApoliceSeguroModel t")
public class PatrimApoliceSeguroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimApoliceSeguroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_contratacao")
	private Date dataContratacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_vencimento")
	private Date dataVencimento;

	@Column(name="valor_premio")
	private BigDecimal valorPremio;

	@Column(name="valor_segurado")
	private BigDecimal valorSegurado;

	@Column(name="observacao")
	private String observacao;

	@Column(name="imagem")
	private String imagem;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_patrim_bem")
	private PatrimBemModel patrimBemModel; 

	@ManyToOne 
	@JoinColumn(name="id_seguradora")
	private SeguradoraModel seguradoraModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public Date getDataContratacao() { 
		return this.dataContratacao; 
	} 

	public void setDataContratacao(Date dataContratacao) { 
		this.dataContratacao = dataContratacao; 
	} 

	public Date getDataVencimento() { 
		return this.dataVencimento; 
	} 

	public void setDataVencimento(Date dataVencimento) { 
		this.dataVencimento = dataVencimento; 
	} 

	public BigDecimal getValorPremio() { 
		return this.valorPremio; 
	} 

	public void setValorPremio(BigDecimal valorPremio) { 
		this.valorPremio = valorPremio; 
	} 

	public BigDecimal getValorSegurado() { 
		return this.valorSegurado; 
	} 

	public void setValorSegurado(BigDecimal valorSegurado) { 
		this.valorSegurado = valorSegurado; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public String getImagem() { 
		return this.imagem; 
	} 

	public void setImagem(String imagem) { 
		this.imagem = imagem; 
	} 

	public PatrimBemModel getPatrimBemModel() { 
	return this.patrimBemModel; 
	} 

	public void setPatrimBemModel(PatrimBemModel patrimBemModel) { 
	this.patrimBemModel = patrimBemModel; 
	} 

	public SeguradoraModel getSeguradoraModel() { 
	return this.seguradoraModel; 
	} 

	public void setSeguradoraModel(SeguradoraModel seguradoraModel) { 
	this.seguradoraModel = seguradoraModel; 
	} 

		
}