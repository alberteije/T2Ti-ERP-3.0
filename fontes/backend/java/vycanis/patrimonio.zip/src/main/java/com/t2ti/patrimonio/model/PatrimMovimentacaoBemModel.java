package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="patrim_movimentacao_bem")
@NamedQuery(name="PatrimMovimentacaoBemModel.findAll", query="SELECT t FROM PatrimMovimentacaoBemModel t")
public class PatrimMovimentacaoBemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimMovimentacaoBemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_movimentacao")
	private Date dataMovimentacao;

	@Column(name="responsavel")
	private String responsavel;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_patrim_bem")
	private PatrimBemModel patrimBemModel; 

	@ManyToOne 
	@JoinColumn(name="id_patrim_tipo_movimentacao")
	private PatrimTipoMovimentacaoModel patrimTipoMovimentacaoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataMovimentacao() { 
		return this.dataMovimentacao; 
	} 

	public void setDataMovimentacao(Date dataMovimentacao) { 
		this.dataMovimentacao = dataMovimentacao; 
	} 

	public String getResponsavel() { 
		return this.responsavel; 
	} 

	public void setResponsavel(String responsavel) { 
		this.responsavel = responsavel; 
	} 

	public PatrimBemModel getPatrimBemModel() { 
	return this.patrimBemModel; 
	} 

	public void setPatrimBemModel(PatrimBemModel patrimBemModel) { 
	this.patrimBemModel = patrimBemModel; 
	} 

	public PatrimTipoMovimentacaoModel getPatrimTipoMovimentacaoModel() { 
	return this.patrimTipoMovimentacaoModel; 
	} 

	public void setPatrimTipoMovimentacaoModel(PatrimTipoMovimentacaoModel patrimTipoMovimentacaoModel) { 
	this.patrimTipoMovimentacaoModel = patrimTipoMovimentacaoModel; 
	} 

		
}