package com.t2ti.patrimonio.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.patrimonio.model.SeguradoraModel;

public interface SeguradoraRepository extends JpaRepository<SeguradoraModel, Integer> {}