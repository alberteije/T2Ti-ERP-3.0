package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="patrim_indice_atualizacao")
@NamedQuery(name="PatrimIndiceAtualizacaoModel.findAll", query="SELECT t FROM PatrimIndiceAtualizacaoModel t")
public class PatrimIndiceAtualizacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimIndiceAtualizacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_indice")
	private Date dataIndice;

	@Column(name="nome")
	private String nome;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="valor_alternativo")
	private BigDecimal valorAlternativo;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataIndice() { 
		return this.dataIndice; 
	} 

	public void setDataIndice(Date dataIndice) { 
		this.dataIndice = dataIndice; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public BigDecimal getValorAlternativo() { 
		return this.valorAlternativo; 
	} 

	public void setValorAlternativo(BigDecimal valorAlternativo) { 
		this.valorAlternativo = valorAlternativo; 
	} 

		
}