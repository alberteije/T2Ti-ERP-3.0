package com.t2ti.patrimonio.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.model.PatrimIndiceAtualizacaoModel;
import com.t2ti.patrimonio.repository.PatrimIndiceAtualizacaoRepository;

@Service
public class PatrimIndiceAtualizacaoService {

	@Autowired
	private PatrimIndiceAtualizacaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PatrimIndiceAtualizacaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PatrimIndiceAtualizacaoModel> getList(Filter filter) {
		String sql = "select * from patrim_indice_atualizacao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PatrimIndiceAtualizacaoModel.class);
		return query.getResultList();
	}

	public PatrimIndiceAtualizacaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PatrimIndiceAtualizacaoModel save(PatrimIndiceAtualizacaoModel obj) {
		PatrimIndiceAtualizacaoModel patrimIndiceAtualizacaoModel = repository.save(obj);
		return patrimIndiceAtualizacaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PatrimIndiceAtualizacaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PatrimIndiceAtualizacao] - Exception: " + e.getMessage());
		}
	}

}