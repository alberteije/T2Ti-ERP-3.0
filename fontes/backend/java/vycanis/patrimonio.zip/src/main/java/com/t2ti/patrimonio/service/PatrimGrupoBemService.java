package com.t2ti.patrimonio.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.model.PatrimGrupoBemModel;
import com.t2ti.patrimonio.repository.PatrimGrupoBemRepository;

@Service
public class PatrimGrupoBemService {

	@Autowired
	private PatrimGrupoBemRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PatrimGrupoBemModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PatrimGrupoBemModel> getList(Filter filter) {
		String sql = "select * from patrim_grupo_bem where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PatrimGrupoBemModel.class);
		return query.getResultList();
	}

	public PatrimGrupoBemModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PatrimGrupoBemModel save(PatrimGrupoBemModel obj) {
		PatrimGrupoBemModel patrimGrupoBemModel = repository.save(obj);
		return patrimGrupoBemModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PatrimGrupoBemModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PatrimGrupoBem] - Exception: " + e.getMessage());
		}
	}

}