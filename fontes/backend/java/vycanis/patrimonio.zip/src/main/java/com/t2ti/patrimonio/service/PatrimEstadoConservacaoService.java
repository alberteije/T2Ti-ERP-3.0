package com.t2ti.patrimonio.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.model.PatrimEstadoConservacaoModel;
import com.t2ti.patrimonio.repository.PatrimEstadoConservacaoRepository;

@Service
public class PatrimEstadoConservacaoService {

	@Autowired
	private PatrimEstadoConservacaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PatrimEstadoConservacaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PatrimEstadoConservacaoModel> getList(Filter filter) {
		String sql = "select * from patrim_estado_conservacao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PatrimEstadoConservacaoModel.class);
		return query.getResultList();
	}

	public PatrimEstadoConservacaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PatrimEstadoConservacaoModel save(PatrimEstadoConservacaoModel obj) {
		PatrimEstadoConservacaoModel patrimEstadoConservacaoModel = repository.save(obj);
		return patrimEstadoConservacaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PatrimEstadoConservacaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PatrimEstadoConservacao] - Exception: " + e.getMessage());
		}
	}

}