package com.t2ti.patrimonio.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.model.PatrimTaxaDepreciacaoModel;
import com.t2ti.patrimonio.repository.PatrimTaxaDepreciacaoRepository;

@Service
public class PatrimTaxaDepreciacaoService {

	@Autowired
	private PatrimTaxaDepreciacaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PatrimTaxaDepreciacaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PatrimTaxaDepreciacaoModel> getList(Filter filter) {
		String sql = "select * from patrim_taxa_depreciacao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PatrimTaxaDepreciacaoModel.class);
		return query.getResultList();
	}

	public PatrimTaxaDepreciacaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PatrimTaxaDepreciacaoModel save(PatrimTaxaDepreciacaoModel obj) {
		PatrimTaxaDepreciacaoModel patrimTaxaDepreciacaoModel = repository.save(obj);
		return patrimTaxaDepreciacaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PatrimTaxaDepreciacaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PatrimTaxaDepreciacao] - Exception: " + e.getMessage());
		}
	}

}