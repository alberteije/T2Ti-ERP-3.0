package com.t2ti.patrimonio.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="centro_resultado")
@NamedQuery(name="CentroResultadoModel.findAll", query="SELECT t FROM CentroResultadoModel t")
public class CentroResultadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CentroResultadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_plano_centro_resultado")
	private Integer idPlanoCentroResultado;

	@Column(name="classificacao")
	private String classificacao;

	@Column(name="descricao")
	private String descricao;

	@Column(name="sofre_rateiro")
	private String sofreRateiro;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdPlanoCentroResultado() { 
		return this.idPlanoCentroResultado; 
	} 

	public void setIdPlanoCentroResultado(Integer idPlanoCentroResultado) { 
		this.idPlanoCentroResultado = idPlanoCentroResultado; 
	} 

	public String getClassificacao() { 
		return this.classificacao; 
	} 

	public void setClassificacao(String classificacao) { 
		this.classificacao = classificacao; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getSofreRateiro() { 
		return this.sofreRateiro; 
	} 

	public void setSofreRateiro(String sofreRateiro) { 
		this.sofreRateiro = sofreRateiro; 
	} 

		
}