package com.t2ti.patrimonio.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.model.PatrimTipoMovimentacaoModel;
import com.t2ti.patrimonio.repository.PatrimTipoMovimentacaoRepository;

@Service
public class PatrimTipoMovimentacaoService {

	@Autowired
	private PatrimTipoMovimentacaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PatrimTipoMovimentacaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PatrimTipoMovimentacaoModel> getList(Filter filter) {
		String sql = "select * from patrim_tipo_movimentacao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PatrimTipoMovimentacaoModel.class);
		return query.getResultList();
	}

	public PatrimTipoMovimentacaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PatrimTipoMovimentacaoModel save(PatrimTipoMovimentacaoModel obj) {
		PatrimTipoMovimentacaoModel patrimTipoMovimentacaoModel = repository.save(obj);
		return patrimTipoMovimentacaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PatrimTipoMovimentacaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PatrimTipoMovimentacao] - Exception: " + e.getMessage());
		}
	}

}