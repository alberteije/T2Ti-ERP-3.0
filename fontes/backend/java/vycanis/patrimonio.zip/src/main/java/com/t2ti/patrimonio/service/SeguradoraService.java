package com.t2ti.patrimonio.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.patrimonio.util.Filter;
import com.t2ti.patrimonio.exception.GenericException;
import com.t2ti.patrimonio.model.SeguradoraModel;
import com.t2ti.patrimonio.repository.SeguradoraRepository;

@Service
public class SeguradoraService {

	@Autowired
	private SeguradoraRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SeguradoraModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SeguradoraModel> getList(Filter filter) {
		String sql = "select * from seguradora where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SeguradoraModel.class);
		return query.getResultList();
	}

	public SeguradoraModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SeguradoraModel save(SeguradoraModel obj) {
		SeguradoraModel seguradoraModel = repository.save(obj);
		return seguradoraModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SeguradoraModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Seguradora] - Exception: " + e.getMessage());
		}
	}

}