package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="fiscal_livro")
@NamedQuery(name="FiscalLivroModel.findAll", query="SELECT t FROM FiscalLivroModel t")
public class FiscalLivroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FiscalLivroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "fiscalLivroModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FiscalTermoModel> fiscalTermoModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<FiscalTermoModel> getFiscalTermoModelList() { 
	return this.fiscalTermoModelList; 
	} 

	public void setFiscalTermoModelList(Set<FiscalTermoModel> fiscalTermoModelList) { 
	this.fiscalTermoModelList = fiscalTermoModelList; 
		for (FiscalTermoModel fiscalTermoModel : fiscalTermoModelList) { 
			fiscalTermoModel.setFiscalLivroModel(this); 
		}
	} 

		
}