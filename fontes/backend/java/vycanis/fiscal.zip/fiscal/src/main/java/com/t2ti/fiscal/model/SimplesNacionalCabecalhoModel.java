package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="simples_nacional_cabecalho")
@NamedQuery(name="SimplesNacionalCabecalhoModel.findAll", query="SELECT t FROM SimplesNacionalCabecalhoModel t")
public class SimplesNacionalCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public SimplesNacionalCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="vigencia_inicial")
	private Date vigenciaInicial;

	@Temporal(TemporalType.DATE)
@Column(name="vigencia_final")
	private Date vigenciaFinal;

	@Column(name="anexo")
	private String anexo;

	@Column(name="tabela")
	private String tabela;

	@OneToMany(mappedBy = "simplesNacionalCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<SimplesNacionalDetalheModel> simplesNacionalDetalheModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getVigenciaInicial() { 
		return this.vigenciaInicial; 
	} 

	public void setVigenciaInicial(Date vigenciaInicial) { 
		this.vigenciaInicial = vigenciaInicial; 
	} 

	public Date getVigenciaFinal() { 
		return this.vigenciaFinal; 
	} 

	public void setVigenciaFinal(Date vigenciaFinal) { 
		this.vigenciaFinal = vigenciaFinal; 
	} 

	public String getAnexo() { 
		return this.anexo; 
	} 

	public void setAnexo(String anexo) { 
		this.anexo = anexo; 
	} 

	public String getTabela() { 
		return this.tabela; 
	} 

	public void setTabela(String tabela) { 
		this.tabela = tabela; 
	} 

	public Set<SimplesNacionalDetalheModel> getSimplesNacionalDetalheModelList() { 
	return this.simplesNacionalDetalheModelList; 
	} 

	public void setSimplesNacionalDetalheModelList(Set<SimplesNacionalDetalheModel> simplesNacionalDetalheModelList) { 
	this.simplesNacionalDetalheModelList = simplesNacionalDetalheModelList; 
		for (SimplesNacionalDetalheModel simplesNacionalDetalheModel : simplesNacionalDetalheModelList) { 
			simplesNacionalDetalheModel.setSimplesNacionalCabecalhoModel(this); 
		}
	} 

		
}