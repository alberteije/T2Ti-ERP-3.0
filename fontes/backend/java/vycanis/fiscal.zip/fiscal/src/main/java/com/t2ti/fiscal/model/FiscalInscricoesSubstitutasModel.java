package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fiscal_inscricoes_substitutas")
@NamedQuery(name="FiscalInscricoesSubstitutasModel.findAll", query="SELECT t FROM FiscalInscricoesSubstitutasModel t")
public class FiscalInscricoesSubstitutasModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FiscalInscricoesSubstitutasModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="uf")
	private String uf;

	@Column(name="inscricao_estadual")
	private String inscricaoEstadual;

	@Column(name="pmpf")
	private String pmpf;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_fiscal_parametros")
	private FiscalParametroModel fiscalParametroModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getInscricaoEstadual() { 
		return this.inscricaoEstadual; 
	} 

	public void setInscricaoEstadual(String inscricaoEstadual) { 
		this.inscricaoEstadual = inscricaoEstadual; 
	} 

	public String getPmpf() { 
		return this.pmpf; 
	} 

	public void setPmpf(String pmpf) { 
		this.pmpf = pmpf; 
	} 

	public FiscalParametroModel getFiscalParametroModel() { 
	return this.fiscalParametroModel; 
	} 

	public void setFiscalParametroModel(FiscalParametroModel fiscalParametroModel) { 
	this.fiscalParametroModel = fiscalParametroModel; 
	} 

		
}