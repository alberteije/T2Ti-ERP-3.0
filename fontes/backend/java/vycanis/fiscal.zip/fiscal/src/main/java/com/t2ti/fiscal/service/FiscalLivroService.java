package com.t2ti.fiscal.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.fiscal.util.Filter;
import com.t2ti.fiscal.exception.GenericException;
import com.t2ti.fiscal.model.FiscalLivroModel;
import com.t2ti.fiscal.repository.FiscalLivroRepository;

@Service
public class FiscalLivroService {

	@Autowired
	private FiscalLivroRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FiscalLivroModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FiscalLivroModel> getList(Filter filter) {
		String sql = "select * from fiscal_livro where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FiscalLivroModel.class);
		return query.getResultList();
	}

	public FiscalLivroModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FiscalLivroModel save(FiscalLivroModel obj) {
		FiscalLivroModel fiscalLivroModel = repository.save(obj);
		return fiscalLivroModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FiscalLivroModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FiscalLivro] - Exception: " + e.getMessage());
		}
	}

}