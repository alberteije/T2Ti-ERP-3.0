package com.t2ti.fiscal.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.fiscal.util.Filter;
import com.t2ti.fiscal.exception.GenericException;
import com.t2ti.fiscal.model.SimplesNacionalCabecalhoModel;
import com.t2ti.fiscal.repository.SimplesNacionalCabecalhoRepository;

@Service
public class SimplesNacionalCabecalhoService {

	@Autowired
	private SimplesNacionalCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SimplesNacionalCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SimplesNacionalCabecalhoModel> getList(Filter filter) {
		String sql = "select * from simples_nacional_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SimplesNacionalCabecalhoModel.class);
		return query.getResultList();
	}

	public SimplesNacionalCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SimplesNacionalCabecalhoModel save(SimplesNacionalCabecalhoModel obj) {
		SimplesNacionalCabecalhoModel simplesNacionalCabecalhoModel = repository.save(obj);
		return simplesNacionalCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SimplesNacionalCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SimplesNacionalCabecalho] - Exception: " + e.getMessage());
		}
	}

}