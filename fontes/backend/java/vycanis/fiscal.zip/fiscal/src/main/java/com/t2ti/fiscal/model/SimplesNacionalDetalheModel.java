package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="simples_nacional_detalhe")
@NamedQuery(name="SimplesNacionalDetalheModel.findAll", query="SELECT t FROM SimplesNacionalDetalheModel t")
public class SimplesNacionalDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public SimplesNacionalDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="faixa")
	private Integer faixa;

	@Column(name="valor_inicial")
	private BigDecimal valorInicial;

	@Column(name="valor_final")
	private BigDecimal valorFinal;

	@Column(name="aliquota")
	private BigDecimal aliquota;

	@Column(name="irpj")
	private BigDecimal irpj;

	@Column(name="csll")
	private BigDecimal csll;

	@Column(name="cofins")
	private BigDecimal cofins;

	@Column(name="pis_pasep")
	private BigDecimal pisPasep;

	@Column(name="cpp")
	private BigDecimal cpp;

	@Column(name="icms")
	private BigDecimal icms;

	@Column(name="ipi")
	private BigDecimal ipi;

	@Column(name="iss")
	private BigDecimal iss;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_simples_nacional_cabecalho")
	private SimplesNacionalCabecalhoModel simplesNacionalCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getFaixa() { 
		return this.faixa; 
	} 

	public void setFaixa(Integer faixa) { 
		this.faixa = faixa; 
	} 

	public BigDecimal getValorInicial() { 
		return this.valorInicial; 
	} 

	public void setValorInicial(BigDecimal valorInicial) { 
		this.valorInicial = valorInicial; 
	} 

	public BigDecimal getValorFinal() { 
		return this.valorFinal; 
	} 

	public void setValorFinal(BigDecimal valorFinal) { 
		this.valorFinal = valorFinal; 
	} 

	public BigDecimal getAliquota() { 
		return this.aliquota; 
	} 

	public void setAliquota(BigDecimal aliquota) { 
		this.aliquota = aliquota; 
	} 

	public BigDecimal getIrpj() { 
		return this.irpj; 
	} 

	public void setIrpj(BigDecimal irpj) { 
		this.irpj = irpj; 
	} 

	public BigDecimal getCsll() { 
		return this.csll; 
	} 

	public void setCsll(BigDecimal csll) { 
		this.csll = csll; 
	} 

	public BigDecimal getCofins() { 
		return this.cofins; 
	} 

	public void setCofins(BigDecimal cofins) { 
		this.cofins = cofins; 
	} 

	public BigDecimal getPisPasep() { 
		return this.pisPasep; 
	} 

	public void setPisPasep(BigDecimal pisPasep) { 
		this.pisPasep = pisPasep; 
	} 

	public BigDecimal getCpp() { 
		return this.cpp; 
	} 

	public void setCpp(BigDecimal cpp) { 
		this.cpp = cpp; 
	} 

	public BigDecimal getIcms() { 
		return this.icms; 
	} 

	public void setIcms(BigDecimal icms) { 
		this.icms = icms; 
	} 

	public BigDecimal getIpi() { 
		return this.ipi; 
	} 

	public void setIpi(BigDecimal ipi) { 
		this.ipi = ipi; 
	} 

	public BigDecimal getIss() { 
		return this.iss; 
	} 

	public void setIss(BigDecimal iss) { 
		this.iss = iss; 
	} 

	public SimplesNacionalCabecalhoModel getSimplesNacionalCabecalhoModel() { 
	return this.simplesNacionalCabecalhoModel; 
	} 

	public void setSimplesNacionalCabecalhoModel(SimplesNacionalCabecalhoModel simplesNacionalCabecalhoModel) { 
	this.simplesNacionalCabecalhoModel = simplesNacionalCabecalhoModel; 
	} 

		
}