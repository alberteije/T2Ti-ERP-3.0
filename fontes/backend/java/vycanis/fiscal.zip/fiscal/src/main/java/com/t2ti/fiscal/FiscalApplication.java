package com.t2ti.fiscal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiscalApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiscalApplication.class, args);
	}

}
