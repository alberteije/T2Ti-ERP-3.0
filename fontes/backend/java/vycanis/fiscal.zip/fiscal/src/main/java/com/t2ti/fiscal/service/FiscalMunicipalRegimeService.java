package com.t2ti.fiscal.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.fiscal.util.Filter;
import com.t2ti.fiscal.exception.GenericException;
import com.t2ti.fiscal.model.FiscalMunicipalRegimeModel;
import com.t2ti.fiscal.repository.FiscalMunicipalRegimeRepository;

@Service
public class FiscalMunicipalRegimeService {

	@Autowired
	private FiscalMunicipalRegimeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FiscalMunicipalRegimeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FiscalMunicipalRegimeModel> getList(Filter filter) {
		String sql = "select * from fiscal_municipal_regime where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FiscalMunicipalRegimeModel.class);
		return query.getResultList();
	}

	public FiscalMunicipalRegimeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FiscalMunicipalRegimeModel save(FiscalMunicipalRegimeModel obj) {
		FiscalMunicipalRegimeModel fiscalMunicipalRegimeModel = repository.save(obj);
		return fiscalMunicipalRegimeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FiscalMunicipalRegimeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FiscalMunicipalRegime] - Exception: " + e.getMessage());
		}
	}

}