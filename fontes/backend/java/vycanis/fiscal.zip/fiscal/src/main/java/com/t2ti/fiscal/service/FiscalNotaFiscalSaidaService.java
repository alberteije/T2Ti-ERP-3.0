package com.t2ti.fiscal.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.fiscal.util.Filter;
import com.t2ti.fiscal.exception.GenericException;
import com.t2ti.fiscal.model.FiscalNotaFiscalSaidaModel;
import com.t2ti.fiscal.repository.FiscalNotaFiscalSaidaRepository;

@Service
public class FiscalNotaFiscalSaidaService {

	@Autowired
	private FiscalNotaFiscalSaidaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FiscalNotaFiscalSaidaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FiscalNotaFiscalSaidaModel> getList(Filter filter) {
		String sql = "select * from fiscal_nota_fiscal_saida where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FiscalNotaFiscalSaidaModel.class);
		return query.getResultList();
	}

	public FiscalNotaFiscalSaidaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FiscalNotaFiscalSaidaModel save(FiscalNotaFiscalSaidaModel obj) {
		FiscalNotaFiscalSaidaModel fiscalNotaFiscalSaidaModel = repository.save(obj);
		return fiscalNotaFiscalSaidaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FiscalNotaFiscalSaidaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FiscalNotaFiscalSaida] - Exception: " + e.getMessage());
		}
	}

}