package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fiscal_termo")
@NamedQuery(name="FiscalTermoModel.findAll", query="SELECT t FROM FiscalTermoModel t")
public class FiscalTermoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FiscalTermoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="abertura_encerramento")
	private String aberturaEncerramento;

	@Column(name="numero")
	private Integer numero;

	@Column(name="pagina_inicial")
	private Integer paginaInicial;

	@Column(name="pagina_final")
	private Integer paginaFinal;

	@Column(name="numero_registro")
	private String numeroRegistro;

	@Column(name="registrado")
	private String registrado;

	@Temporal(TemporalType.DATE)
@Column(name="data_despacho")
	private Date dataDespacho;

	@Temporal(TemporalType.DATE)
@Column(name="data_abertura")
	private Date dataAbertura;

	@Temporal(TemporalType.DATE)
@Column(name="data_encerramento")
	private Date dataEncerramento;

	@Temporal(TemporalType.DATE)
@Column(name="escrituracao_inicio")
	private Date escrituracaoInicio;

	@Temporal(TemporalType.DATE)
@Column(name="escrituracao_fim")
	private Date escrituracaoFim;

	@Column(name="texto")
	private String texto;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_fiscal_livro")
	private FiscalLivroModel fiscalLivroModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getAberturaEncerramento() { 
		return this.aberturaEncerramento; 
	} 

	public void setAberturaEncerramento(String aberturaEncerramento) { 
		this.aberturaEncerramento = aberturaEncerramento; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public Integer getPaginaInicial() { 
		return this.paginaInicial; 
	} 

	public void setPaginaInicial(Integer paginaInicial) { 
		this.paginaInicial = paginaInicial; 
	} 

	public Integer getPaginaFinal() { 
		return this.paginaFinal; 
	} 

	public void setPaginaFinal(Integer paginaFinal) { 
		this.paginaFinal = paginaFinal; 
	} 

	public String getNumeroRegistro() { 
		return this.numeroRegistro; 
	} 

	public void setNumeroRegistro(String numeroRegistro) { 
		this.numeroRegistro = numeroRegistro; 
	} 

	public String getRegistrado() { 
		return this.registrado; 
	} 

	public void setRegistrado(String registrado) { 
		this.registrado = registrado; 
	} 

	public Date getDataDespacho() { 
		return this.dataDespacho; 
	} 

	public void setDataDespacho(Date dataDespacho) { 
		this.dataDespacho = dataDespacho; 
	} 

	public Date getDataAbertura() { 
		return this.dataAbertura; 
	} 

	public void setDataAbertura(Date dataAbertura) { 
		this.dataAbertura = dataAbertura; 
	} 

	public Date getDataEncerramento() { 
		return this.dataEncerramento; 
	} 

	public void setDataEncerramento(Date dataEncerramento) { 
		this.dataEncerramento = dataEncerramento; 
	} 

	public Date getEscrituracaoInicio() { 
		return this.escrituracaoInicio; 
	} 

	public void setEscrituracaoInicio(Date escrituracaoInicio) { 
		this.escrituracaoInicio = escrituracaoInicio; 
	} 

	public Date getEscrituracaoFim() { 
		return this.escrituracaoFim; 
	} 

	public void setEscrituracaoFim(Date escrituracaoFim) { 
		this.escrituracaoFim = escrituracaoFim; 
	} 

	public String getTexto() { 
		return this.texto; 
	} 

	public void setTexto(String texto) { 
		this.texto = texto; 
	} 

	public FiscalLivroModel getFiscalLivroModel() { 
	return this.fiscalLivroModel; 
	} 

	public void setFiscalLivroModel(FiscalLivroModel fiscalLivroModel) { 
	this.fiscalLivroModel = fiscalLivroModel; 
	} 

		
}