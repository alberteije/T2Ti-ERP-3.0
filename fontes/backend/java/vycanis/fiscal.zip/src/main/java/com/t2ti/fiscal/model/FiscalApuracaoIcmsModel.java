package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="fiscal_apuracao_icms")
@NamedQuery(name="FiscalApuracaoIcmsModel.findAll", query="SELECT t FROM FiscalApuracaoIcmsModel t")
public class FiscalApuracaoIcmsModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FiscalApuracaoIcmsModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="valor_total_debito")
	private BigDecimal valorTotalDebito;

	@Column(name="valor_ajuste_debito")
	private BigDecimal valorAjusteDebito;

	@Column(name="valor_total_ajuste_debito")
	private BigDecimal valorTotalAjusteDebito;

	@Column(name="valor_estorno_credito")
	private BigDecimal valorEstornoCredito;

	@Column(name="valor_total_credito")
	private BigDecimal valorTotalCredito;

	@Column(name="valor_ajuste_credito")
	private BigDecimal valorAjusteCredito;

	@Column(name="valor_total_ajuste_credito")
	private BigDecimal valorTotalAjusteCredito;

	@Column(name="valor_estorno_debito")
	private BigDecimal valorEstornoDebito;

	@Column(name="valor_saldo_credor_anterior")
	private BigDecimal valorSaldoCredorAnterior;

	@Column(name="valor_saldo_apurado")
	private BigDecimal valorSaldoApurado;

	@Column(name="valor_total_deducao")
	private BigDecimal valorTotalDeducao;

	@Column(name="valor_icms_recolher")
	private BigDecimal valorIcmsRecolher;

	@Column(name="valor_saldo_credor_transp")
	private BigDecimal valorSaldoCredorTransp;

	@Column(name="valor_debito_especial")
	private BigDecimal valorDebitoEspecial;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public BigDecimal getValorTotalDebito() { 
		return this.valorTotalDebito; 
	} 

	public void setValorTotalDebito(BigDecimal valorTotalDebito) { 
		this.valorTotalDebito = valorTotalDebito; 
	} 

	public BigDecimal getValorAjusteDebito() { 
		return this.valorAjusteDebito; 
	} 

	public void setValorAjusteDebito(BigDecimal valorAjusteDebito) { 
		this.valorAjusteDebito = valorAjusteDebito; 
	} 

	public BigDecimal getValorTotalAjusteDebito() { 
		return this.valorTotalAjusteDebito; 
	} 

	public void setValorTotalAjusteDebito(BigDecimal valorTotalAjusteDebito) { 
		this.valorTotalAjusteDebito = valorTotalAjusteDebito; 
	} 

	public BigDecimal getValorEstornoCredito() { 
		return this.valorEstornoCredito; 
	} 

	public void setValorEstornoCredito(BigDecimal valorEstornoCredito) { 
		this.valorEstornoCredito = valorEstornoCredito; 
	} 

	public BigDecimal getValorTotalCredito() { 
		return this.valorTotalCredito; 
	} 

	public void setValorTotalCredito(BigDecimal valorTotalCredito) { 
		this.valorTotalCredito = valorTotalCredito; 
	} 

	public BigDecimal getValorAjusteCredito() { 
		return this.valorAjusteCredito; 
	} 

	public void setValorAjusteCredito(BigDecimal valorAjusteCredito) { 
		this.valorAjusteCredito = valorAjusteCredito; 
	} 

	public BigDecimal getValorTotalAjusteCredito() { 
		return this.valorTotalAjusteCredito; 
	} 

	public void setValorTotalAjusteCredito(BigDecimal valorTotalAjusteCredito) { 
		this.valorTotalAjusteCredito = valorTotalAjusteCredito; 
	} 

	public BigDecimal getValorEstornoDebito() { 
		return this.valorEstornoDebito; 
	} 

	public void setValorEstornoDebito(BigDecimal valorEstornoDebito) { 
		this.valorEstornoDebito = valorEstornoDebito; 
	} 

	public BigDecimal getValorSaldoCredorAnterior() { 
		return this.valorSaldoCredorAnterior; 
	} 

	public void setValorSaldoCredorAnterior(BigDecimal valorSaldoCredorAnterior) { 
		this.valorSaldoCredorAnterior = valorSaldoCredorAnterior; 
	} 

	public BigDecimal getValorSaldoApurado() { 
		return this.valorSaldoApurado; 
	} 

	public void setValorSaldoApurado(BigDecimal valorSaldoApurado) { 
		this.valorSaldoApurado = valorSaldoApurado; 
	} 

	public BigDecimal getValorTotalDeducao() { 
		return this.valorTotalDeducao; 
	} 

	public void setValorTotalDeducao(BigDecimal valorTotalDeducao) { 
		this.valorTotalDeducao = valorTotalDeducao; 
	} 

	public BigDecimal getValorIcmsRecolher() { 
		return this.valorIcmsRecolher; 
	} 

	public void setValorIcmsRecolher(BigDecimal valorIcmsRecolher) { 
		this.valorIcmsRecolher = valorIcmsRecolher; 
	} 

	public BigDecimal getValorSaldoCredorTransp() { 
		return this.valorSaldoCredorTransp; 
	} 

	public void setValorSaldoCredorTransp(BigDecimal valorSaldoCredorTransp) { 
		this.valorSaldoCredorTransp = valorSaldoCredorTransp; 
	} 

	public BigDecimal getValorDebitoEspecial() { 
		return this.valorDebitoEspecial; 
	} 

	public void setValorDebitoEspecial(BigDecimal valorDebitoEspecial) { 
		this.valorDebitoEspecial = valorDebitoEspecial; 
	} 

		
}