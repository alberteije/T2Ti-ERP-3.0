package com.t2ti.fiscal.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.fiscal.util.Filter;
import com.t2ti.fiscal.exception.GenericException;
import com.t2ti.fiscal.model.FiscalParametroModel;
import com.t2ti.fiscal.repository.FiscalParametroRepository;

@Service
public class FiscalParametroService {

	@Autowired
	private FiscalParametroRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FiscalParametroModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FiscalParametroModel> getList(Filter filter) {
		String sql = "select * from fiscal_parametro where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FiscalParametroModel.class);
		return query.getResultList();
	}

	public FiscalParametroModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FiscalParametroModel save(FiscalParametroModel obj) {
		FiscalParametroModel fiscalParametroModel = repository.save(obj);
		return fiscalParametroModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FiscalParametroModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FiscalParametro] - Exception: " + e.getMessage());
		}
	}

}