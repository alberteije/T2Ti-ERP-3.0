package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fiscal_parametro")
@NamedQuery(name="FiscalParametroModel.findAll", query="SELECT t FROM FiscalParametroModel t")
public class FiscalParametroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FiscalParametroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="vigencia")
	private String vigencia;

	@Column(name="descricao_vigencia")
	private String descricaoVigencia;

	@Column(name="criterio_lancamento")
	private String criterioLancamento;

	@Column(name="apuracao")
	private String apuracao;

	@Column(name="microempree_individual")
	private String microempreeIndividual;

	@Column(name="calc_pis_cofins_efd")
	private String calcPisCofinsEfd;

	@Column(name="simples_codigo_acesso")
	private String simplesCodigoAcesso;

	@Column(name="simples_tabela")
	private String simplesTabela;

	@Column(name="simples_atividade")
	private String simplesAtividade;

	@Column(name="perfil_sped")
	private String perfilSped;

	@Column(name="apuracao_consolidada")
	private String apuracaoConsolidada;

	@Column(name="substituicao_tributaria")
	private String substituicaoTributaria;

	@Column(name="forma_calculo_iss")
	private String formaCalculoIss;

	@OneToMany(mappedBy = "fiscalParametroModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FiscalInscricoesSubstitutasModel> fiscalInscricoesSubstitutasModelList; 

	@ManyToOne 
	@JoinColumn(name="id_fiscal_estadual_regime")
	private FiscalEstadualRegimeModel fiscalEstadualRegimeModel; 

	@ManyToOne 
	@JoinColumn(name="id_fiscal_estadual_porte")
	private FiscalEstadualPorteModel fiscalEstadualPorteModel; 

	@ManyToOne 
	@JoinColumn(name="id_fiscal_municipal_regime")
	private FiscalMunicipalRegimeModel fiscalMunicipalRegimeModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getVigencia() { 
		return this.vigencia; 
	} 

	public void setVigencia(String vigencia) { 
		this.vigencia = vigencia; 
	} 

	public String getDescricaoVigencia() { 
		return this.descricaoVigencia; 
	} 

	public void setDescricaoVigencia(String descricaoVigencia) { 
		this.descricaoVigencia = descricaoVigencia; 
	} 

	public String getCriterioLancamento() { 
		return this.criterioLancamento; 
	} 

	public void setCriterioLancamento(String criterioLancamento) { 
		this.criterioLancamento = criterioLancamento; 
	} 

	public String getApuracao() { 
		return this.apuracao; 
	} 

	public void setApuracao(String apuracao) { 
		this.apuracao = apuracao; 
	} 

	public String getMicroempreeIndividual() { 
		return this.microempreeIndividual; 
	} 

	public void setMicroempreeIndividual(String microempreeIndividual) { 
		this.microempreeIndividual = microempreeIndividual; 
	} 

	public String getCalcPisCofinsEfd() { 
		return this.calcPisCofinsEfd; 
	} 

	public void setCalcPisCofinsEfd(String calcPisCofinsEfd) { 
		this.calcPisCofinsEfd = calcPisCofinsEfd; 
	} 

	public String getSimplesCodigoAcesso() { 
		return this.simplesCodigoAcesso; 
	} 

	public void setSimplesCodigoAcesso(String simplesCodigoAcesso) { 
		this.simplesCodigoAcesso = simplesCodigoAcesso; 
	} 

	public String getSimplesTabela() { 
		return this.simplesTabela; 
	} 

	public void setSimplesTabela(String simplesTabela) { 
		this.simplesTabela = simplesTabela; 
	} 

	public String getSimplesAtividade() { 
		return this.simplesAtividade; 
	} 

	public void setSimplesAtividade(String simplesAtividade) { 
		this.simplesAtividade = simplesAtividade; 
	} 

	public String getPerfilSped() { 
		return this.perfilSped; 
	} 

	public void setPerfilSped(String perfilSped) { 
		this.perfilSped = perfilSped; 
	} 

	public String getApuracaoConsolidada() { 
		return this.apuracaoConsolidada; 
	} 

	public void setApuracaoConsolidada(String apuracaoConsolidada) { 
		this.apuracaoConsolidada = apuracaoConsolidada; 
	} 

	public String getSubstituicaoTributaria() { 
		return this.substituicaoTributaria; 
	} 

	public void setSubstituicaoTributaria(String substituicaoTributaria) { 
		this.substituicaoTributaria = substituicaoTributaria; 
	} 

	public String getFormaCalculoIss() { 
		return this.formaCalculoIss; 
	} 

	public void setFormaCalculoIss(String formaCalculoIss) { 
		this.formaCalculoIss = formaCalculoIss; 
	} 

	public Set<FiscalInscricoesSubstitutasModel> getFiscalInscricoesSubstitutasModelList() { 
	return this.fiscalInscricoesSubstitutasModelList; 
	} 

	public void setFiscalInscricoesSubstitutasModelList(Set<FiscalInscricoesSubstitutasModel> fiscalInscricoesSubstitutasModelList) { 
	this.fiscalInscricoesSubstitutasModelList = fiscalInscricoesSubstitutasModelList; 
		for (FiscalInscricoesSubstitutasModel fiscalInscricoesSubstitutasModel : fiscalInscricoesSubstitutasModelList) { 
			fiscalInscricoesSubstitutasModel.setFiscalParametroModel(this); 
		}
	} 

	public FiscalEstadualRegimeModel getFiscalEstadualRegimeModel() { 
	return this.fiscalEstadualRegimeModel; 
	} 

	public void setFiscalEstadualRegimeModel(FiscalEstadualRegimeModel fiscalEstadualRegimeModel) { 
	this.fiscalEstadualRegimeModel = fiscalEstadualRegimeModel; 
	} 

	public FiscalEstadualPorteModel getFiscalEstadualPorteModel() { 
	return this.fiscalEstadualPorteModel; 
	} 

	public void setFiscalEstadualPorteModel(FiscalEstadualPorteModel fiscalEstadualPorteModel) { 
	this.fiscalEstadualPorteModel = fiscalEstadualPorteModel; 
	} 

	public FiscalMunicipalRegimeModel getFiscalMunicipalRegimeModel() { 
	return this.fiscalMunicipalRegimeModel; 
	} 

	public void setFiscalMunicipalRegimeModel(FiscalMunicipalRegimeModel fiscalMunicipalRegimeModel) { 
	this.fiscalMunicipalRegimeModel = fiscalMunicipalRegimeModel; 
	} 

		
}