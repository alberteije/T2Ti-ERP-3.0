package com.t2ti.fiscal.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.fiscal.util.Filter;
import com.t2ti.fiscal.exception.GenericException;
import com.t2ti.fiscal.model.FiscalApuracaoIcmsModel;
import com.t2ti.fiscal.repository.FiscalApuracaoIcmsRepository;

@Service
public class FiscalApuracaoIcmsService {

	@Autowired
	private FiscalApuracaoIcmsRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FiscalApuracaoIcmsModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FiscalApuracaoIcmsModel> getList(Filter filter) {
		String sql = "select * from fiscal_apuracao_icms where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FiscalApuracaoIcmsModel.class);
		return query.getResultList();
	}

	public FiscalApuracaoIcmsModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FiscalApuracaoIcmsModel save(FiscalApuracaoIcmsModel obj) {
		FiscalApuracaoIcmsModel fiscalApuracaoIcmsModel = repository.save(obj);
		return fiscalApuracaoIcmsModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FiscalApuracaoIcmsModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FiscalApuracaoIcms] - Exception: " + e.getMessage());
		}
	}

}