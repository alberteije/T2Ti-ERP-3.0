package com.t2ti.fiscal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.fiscal.model.FiscalEstadualPorteModel;

public interface FiscalEstadualPorteRepository extends JpaRepository<FiscalEstadualPorteModel, Integer> {}