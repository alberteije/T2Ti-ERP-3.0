package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="fiscal_estadual_porte")
@NamedQuery(name="FiscalEstadualPorteModel.findAll", query="SELECT t FROM FiscalEstadualPorteModel t")
public class FiscalEstadualPorteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FiscalEstadualPorteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="uf")
	private String uf;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

		
}