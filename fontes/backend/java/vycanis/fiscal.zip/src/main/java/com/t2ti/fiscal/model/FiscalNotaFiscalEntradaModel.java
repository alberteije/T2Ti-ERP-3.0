package com.t2ti.fiscal.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fiscal_nota_fiscal_entrada")
@NamedQuery(name="FiscalNotaFiscalEntradaModel.findAll", query="SELECT t FROM FiscalNotaFiscalEntradaModel t")
public class FiscalNotaFiscalEntradaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FiscalNotaFiscalEntradaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="cfop_entrada")
	private Integer cfopEntrada;

	@Column(name="valor_rateio_frete")
	private BigDecimal valorRateioFrete;

	@Column(name="valor_custo_medio")
	private BigDecimal valorCustoMedio;

	@Column(name="valor_icms_antecipado")
	private BigDecimal valorIcmsAntecipado;

	@Column(name="valor_bc_icms_antecipado")
	private BigDecimal valorBcIcmsAntecipado;

	@Column(name="valor_bc_icms_creditado")
	private BigDecimal valorBcIcmsCreditado;

	@Column(name="valor_bc_pis_creditado")
	private BigDecimal valorBcPisCreditado;

	@Column(name="valor_bc_cofins_creditado")
	private BigDecimal valorBcCofinsCreditado;

	@Column(name="valor_bc_ipi_creditado")
	private BigDecimal valorBcIpiCreditado;

	@Column(name="cst_credito_icms")
	private String cstCreditoIcms;

	@Column(name="cst_credito_pis")
	private String cstCreditoPis;

	@Column(name="cst_credito_cofins")
	private String cstCreditoCofins;

	@Column(name="cst_credito_ipi")
	private String cstCreditoIpi;

	@Column(name="valor_icms_creditado")
	private BigDecimal valorIcmsCreditado;

	@Column(name="valor_pis_creditado")
	private BigDecimal valorPisCreditado;

	@Column(name="valor_cofins_creditado")
	private BigDecimal valorCofinsCreditado;

	@Column(name="valor_ipi_creditado")
	private BigDecimal valorIpiCreditado;

	@Column(name="qtde_parcela_credito_pis")
	private Integer qtdeParcelaCreditoPis;

	@Column(name="qtde_parcela_credito_cofins")
	private Integer qtdeParcelaCreditoCofins;

	@Column(name="qtde_parcela_credito_icms")
	private Integer qtdeParcelaCreditoIcms;

	@Column(name="qtde_parcela_credito_ipi")
	private Integer qtdeParcelaCreditoIpi;

	@Column(name="aliquota_credito_icms")
	private BigDecimal aliquotaCreditoIcms;

	@Column(name="aliquota_credito_pis")
	private BigDecimal aliquotaCreditoPis;

	@Column(name="aliquota_credito_cofins")
	private BigDecimal aliquotaCreditoCofins;

	@Column(name="aliquota_credito_ipi")
	private BigDecimal aliquotaCreditoIpi;

	@ManyToOne 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public Integer getCfopEntrada() { 
		return this.cfopEntrada; 
	} 

	public void setCfopEntrada(Integer cfopEntrada) { 
		this.cfopEntrada = cfopEntrada; 
	} 

	public BigDecimal getValorRateioFrete() { 
		return this.valorRateioFrete; 
	} 

	public void setValorRateioFrete(BigDecimal valorRateioFrete) { 
		this.valorRateioFrete = valorRateioFrete; 
	} 

	public BigDecimal getValorCustoMedio() { 
		return this.valorCustoMedio; 
	} 

	public void setValorCustoMedio(BigDecimal valorCustoMedio) { 
		this.valorCustoMedio = valorCustoMedio; 
	} 

	public BigDecimal getValorIcmsAntecipado() { 
		return this.valorIcmsAntecipado; 
	} 

	public void setValorIcmsAntecipado(BigDecimal valorIcmsAntecipado) { 
		this.valorIcmsAntecipado = valorIcmsAntecipado; 
	} 

	public BigDecimal getValorBcIcmsAntecipado() { 
		return this.valorBcIcmsAntecipado; 
	} 

	public void setValorBcIcmsAntecipado(BigDecimal valorBcIcmsAntecipado) { 
		this.valorBcIcmsAntecipado = valorBcIcmsAntecipado; 
	} 

	public BigDecimal getValorBcIcmsCreditado() { 
		return this.valorBcIcmsCreditado; 
	} 

	public void setValorBcIcmsCreditado(BigDecimal valorBcIcmsCreditado) { 
		this.valorBcIcmsCreditado = valorBcIcmsCreditado; 
	} 

	public BigDecimal getValorBcPisCreditado() { 
		return this.valorBcPisCreditado; 
	} 

	public void setValorBcPisCreditado(BigDecimal valorBcPisCreditado) { 
		this.valorBcPisCreditado = valorBcPisCreditado; 
	} 

	public BigDecimal getValorBcCofinsCreditado() { 
		return this.valorBcCofinsCreditado; 
	} 

	public void setValorBcCofinsCreditado(BigDecimal valorBcCofinsCreditado) { 
		this.valorBcCofinsCreditado = valorBcCofinsCreditado; 
	} 

	public BigDecimal getValorBcIpiCreditado() { 
		return this.valorBcIpiCreditado; 
	} 

	public void setValorBcIpiCreditado(BigDecimal valorBcIpiCreditado) { 
		this.valorBcIpiCreditado = valorBcIpiCreditado; 
	} 

	public String getCstCreditoIcms() { 
		return this.cstCreditoIcms; 
	} 

	public void setCstCreditoIcms(String cstCreditoIcms) { 
		this.cstCreditoIcms = cstCreditoIcms; 
	} 

	public String getCstCreditoPis() { 
		return this.cstCreditoPis; 
	} 

	public void setCstCreditoPis(String cstCreditoPis) { 
		this.cstCreditoPis = cstCreditoPis; 
	} 

	public String getCstCreditoCofins() { 
		return this.cstCreditoCofins; 
	} 

	public void setCstCreditoCofins(String cstCreditoCofins) { 
		this.cstCreditoCofins = cstCreditoCofins; 
	} 

	public String getCstCreditoIpi() { 
		return this.cstCreditoIpi; 
	} 

	public void setCstCreditoIpi(String cstCreditoIpi) { 
		this.cstCreditoIpi = cstCreditoIpi; 
	} 

	public BigDecimal getValorIcmsCreditado() { 
		return this.valorIcmsCreditado; 
	} 

	public void setValorIcmsCreditado(BigDecimal valorIcmsCreditado) { 
		this.valorIcmsCreditado = valorIcmsCreditado; 
	} 

	public BigDecimal getValorPisCreditado() { 
		return this.valorPisCreditado; 
	} 

	public void setValorPisCreditado(BigDecimal valorPisCreditado) { 
		this.valorPisCreditado = valorPisCreditado; 
	} 

	public BigDecimal getValorCofinsCreditado() { 
		return this.valorCofinsCreditado; 
	} 

	public void setValorCofinsCreditado(BigDecimal valorCofinsCreditado) { 
		this.valorCofinsCreditado = valorCofinsCreditado; 
	} 

	public BigDecimal getValorIpiCreditado() { 
		return this.valorIpiCreditado; 
	} 

	public void setValorIpiCreditado(BigDecimal valorIpiCreditado) { 
		this.valorIpiCreditado = valorIpiCreditado; 
	} 

	public Integer getQtdeParcelaCreditoPis() { 
		return this.qtdeParcelaCreditoPis; 
	} 

	public void setQtdeParcelaCreditoPis(Integer qtdeParcelaCreditoPis) { 
		this.qtdeParcelaCreditoPis = qtdeParcelaCreditoPis; 
	} 

	public Integer getQtdeParcelaCreditoCofins() { 
		return this.qtdeParcelaCreditoCofins; 
	} 

	public void setQtdeParcelaCreditoCofins(Integer qtdeParcelaCreditoCofins) { 
		this.qtdeParcelaCreditoCofins = qtdeParcelaCreditoCofins; 
	} 

	public Integer getQtdeParcelaCreditoIcms() { 
		return this.qtdeParcelaCreditoIcms; 
	} 

	public void setQtdeParcelaCreditoIcms(Integer qtdeParcelaCreditoIcms) { 
		this.qtdeParcelaCreditoIcms = qtdeParcelaCreditoIcms; 
	} 

	public Integer getQtdeParcelaCreditoIpi() { 
		return this.qtdeParcelaCreditoIpi; 
	} 

	public void setQtdeParcelaCreditoIpi(Integer qtdeParcelaCreditoIpi) { 
		this.qtdeParcelaCreditoIpi = qtdeParcelaCreditoIpi; 
	} 

	public BigDecimal getAliquotaCreditoIcms() { 
		return this.aliquotaCreditoIcms; 
	} 

	public void setAliquotaCreditoIcms(BigDecimal aliquotaCreditoIcms) { 
		this.aliquotaCreditoIcms = aliquotaCreditoIcms; 
	} 

	public BigDecimal getAliquotaCreditoPis() { 
		return this.aliquotaCreditoPis; 
	} 

	public void setAliquotaCreditoPis(BigDecimal aliquotaCreditoPis) { 
		this.aliquotaCreditoPis = aliquotaCreditoPis; 
	} 

	public BigDecimal getAliquotaCreditoCofins() { 
		return this.aliquotaCreditoCofins; 
	} 

	public void setAliquotaCreditoCofins(BigDecimal aliquotaCreditoCofins) { 
		this.aliquotaCreditoCofins = aliquotaCreditoCofins; 
	} 

	public BigDecimal getAliquotaCreditoIpi() { 
		return this.aliquotaCreditoIpi; 
	} 

	public void setAliquotaCreditoIpi(BigDecimal aliquotaCreditoIpi) { 
		this.aliquotaCreditoIpi = aliquotaCreditoIpi; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}