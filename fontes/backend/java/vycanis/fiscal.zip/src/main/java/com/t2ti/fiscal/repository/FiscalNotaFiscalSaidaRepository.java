package com.t2ti.fiscal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.fiscal.model.FiscalNotaFiscalSaidaModel;

public interface FiscalNotaFiscalSaidaRepository extends JpaRepository<FiscalNotaFiscalSaidaModel, Integer> {}