package com.t2ti.fiscal.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.fiscal.util.Filter;
import com.t2ti.fiscal.exception.GenericException;
import com.t2ti.fiscal.model.FiscalEstadualPorteModel;
import com.t2ti.fiscal.repository.FiscalEstadualPorteRepository;

@Service
public class FiscalEstadualPorteService {

	@Autowired
	private FiscalEstadualPorteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FiscalEstadualPorteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FiscalEstadualPorteModel> getList(Filter filter) {
		String sql = "select * from fiscal_estadual_porte where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FiscalEstadualPorteModel.class);
		return query.getResultList();
	}

	public FiscalEstadualPorteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FiscalEstadualPorteModel save(FiscalEstadualPorteModel obj) {
		FiscalEstadualPorteModel fiscalEstadualPorteModel = repository.save(obj);
		return fiscalEstadualPorteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FiscalEstadualPorteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FiscalEstadualPorte] - Exception: " + e.getMessage());
		}
	}

}