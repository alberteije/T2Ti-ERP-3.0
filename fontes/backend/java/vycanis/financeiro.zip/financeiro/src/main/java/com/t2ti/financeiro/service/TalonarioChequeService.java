package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.TalonarioChequeModel;
import com.t2ti.financeiro.repository.TalonarioChequeRepository;

@Service
public class TalonarioChequeService {

	@Autowired
	private TalonarioChequeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TalonarioChequeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TalonarioChequeModel> getList(Filter filter) {
		String sql = "select * from talonario_cheque where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TalonarioChequeModel.class);
		return query.getResultList();
	}

	public TalonarioChequeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TalonarioChequeModel save(TalonarioChequeModel obj) {
		TalonarioChequeModel talonarioChequeModel = repository.save(obj);
		return talonarioChequeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TalonarioChequeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TalonarioCheque] - Exception: " + e.getMessage());
		}
	}

}