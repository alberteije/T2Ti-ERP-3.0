package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_parcela_receber")
@NamedQuery(name="FinParcelaReceberModel.findAll", query="SELECT t FROM FinParcelaReceberModel t")
public class FinParcelaReceberModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinParcelaReceberModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_parcela")
	private Integer numeroParcela;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="data_vencimento")
	private Date dataVencimento;

	@Temporal(TemporalType.DATE)
@Column(name="data_recebimento")
	private Date dataRecebimento;

	@Temporal(TemporalType.DATE)
@Column(name="desconto_ate")
	private Date descontoAte;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="taxa_juro")
	private BigDecimal taxaJuro;

	@Column(name="taxa_multa")
	private BigDecimal taxaMulta;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_juro")
	private BigDecimal valorJuro;

	@Column(name="valor_multa")
	private BigDecimal valorMulta;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="emitiu_boleto")
	private String emitiuBoleto;

	@Column(name="boleto_nosso_numero")
	private String boletoNossoNumero;

	@Column(name="valor_recebido")
	private BigDecimal valorRecebido;

	@Column(name="historico")
	private String historico;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_fin_lancamento_receber")
	private FinLancamentoReceberModel finLancamentoReceberModel; 

	@ManyToOne 
	@JoinColumn(name="id_fin_status_parcela")
	private FinStatusParcelaModel finStatusParcelaModel; 

	@ManyToOne 
	@JoinColumn(name="id_fin_tipo_recebimento")
	private FinTipoRecebimentoModel finTipoRecebimentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumeroParcela() { 
		return this.numeroParcela; 
	} 

	public void setNumeroParcela(Integer numeroParcela) { 
		this.numeroParcela = numeroParcela; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public Date getDataVencimento() { 
		return this.dataVencimento; 
	} 

	public void setDataVencimento(Date dataVencimento) { 
		this.dataVencimento = dataVencimento; 
	} 

	public Date getDataRecebimento() { 
		return this.dataRecebimento; 
	} 

	public void setDataRecebimento(Date dataRecebimento) { 
		this.dataRecebimento = dataRecebimento; 
	} 

	public Date getDescontoAte() { 
		return this.descontoAte; 
	} 

	public void setDescontoAte(Date descontoAte) { 
		this.descontoAte = descontoAte; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public BigDecimal getTaxaJuro() { 
		return this.taxaJuro; 
	} 

	public void setTaxaJuro(BigDecimal taxaJuro) { 
		this.taxaJuro = taxaJuro; 
	} 

	public BigDecimal getTaxaMulta() { 
		return this.taxaMulta; 
	} 

	public void setTaxaMulta(BigDecimal taxaMulta) { 
		this.taxaMulta = taxaMulta; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorJuro() { 
		return this.valorJuro; 
	} 

	public void setValorJuro(BigDecimal valorJuro) { 
		this.valorJuro = valorJuro; 
	} 

	public BigDecimal getValorMulta() { 
		return this.valorMulta; 
	} 

	public void setValorMulta(BigDecimal valorMulta) { 
		this.valorMulta = valorMulta; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public String getEmitiuBoleto() { 
		return this.emitiuBoleto; 
	} 

	public void setEmitiuBoleto(String emitiuBoleto) { 
		this.emitiuBoleto = emitiuBoleto; 
	} 

	public String getBoletoNossoNumero() { 
		return this.boletoNossoNumero; 
	} 

	public void setBoletoNossoNumero(String boletoNossoNumero) { 
		this.boletoNossoNumero = boletoNossoNumero; 
	} 

	public BigDecimal getValorRecebido() { 
		return this.valorRecebido; 
	} 

	public void setValorRecebido(BigDecimal valorRecebido) { 
		this.valorRecebido = valorRecebido; 
	} 

	public String getHistorico() { 
		return this.historico; 
	} 

	public void setHistorico(String historico) { 
		this.historico = historico; 
	} 

	public FinLancamentoReceberModel getFinLancamentoReceberModel() { 
	return this.finLancamentoReceberModel; 
	} 

	public void setFinLancamentoReceberModel(FinLancamentoReceberModel finLancamentoReceberModel) { 
	this.finLancamentoReceberModel = finLancamentoReceberModel; 
	} 

	public FinStatusParcelaModel getFinStatusParcelaModel() { 
	return this.finStatusParcelaModel; 
	} 

	public void setFinStatusParcelaModel(FinStatusParcelaModel finStatusParcelaModel) { 
	this.finStatusParcelaModel = finStatusParcelaModel; 
	} 

	public FinTipoRecebimentoModel getFinTipoRecebimentoModel() { 
	return this.finTipoRecebimentoModel; 
	} 

	public void setFinTipoRecebimentoModel(FinTipoRecebimentoModel finTipoRecebimentoModel) { 
	this.finTipoRecebimentoModel = finTipoRecebimentoModel; 
	} 

		
}