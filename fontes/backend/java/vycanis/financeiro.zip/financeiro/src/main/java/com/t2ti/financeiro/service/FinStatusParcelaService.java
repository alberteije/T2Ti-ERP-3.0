package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinStatusParcelaModel;
import com.t2ti.financeiro.repository.FinStatusParcelaRepository;

@Service
public class FinStatusParcelaService {

	@Autowired
	private FinStatusParcelaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinStatusParcelaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinStatusParcelaModel> getList(Filter filter) {
		String sql = "select * from fin_status_parcela where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinStatusParcelaModel.class);
		return query.getResultList();
	}

	public FinStatusParcelaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinStatusParcelaModel save(FinStatusParcelaModel obj) {
		FinStatusParcelaModel finStatusParcelaModel = repository.save(obj);
		return finStatusParcelaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinStatusParcelaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinStatusParcela] - Exception: " + e.getMessage());
		}
	}

}