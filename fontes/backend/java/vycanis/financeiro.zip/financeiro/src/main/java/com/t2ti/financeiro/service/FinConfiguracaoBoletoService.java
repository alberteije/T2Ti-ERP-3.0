package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinConfiguracaoBoletoModel;
import com.t2ti.financeiro.repository.FinConfiguracaoBoletoRepository;

@Service
public class FinConfiguracaoBoletoService {

	@Autowired
	private FinConfiguracaoBoletoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinConfiguracaoBoletoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinConfiguracaoBoletoModel> getList(Filter filter) {
		String sql = "select * from fin_configuracao_boleto where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinConfiguracaoBoletoModel.class);
		return query.getResultList();
	}

	public FinConfiguracaoBoletoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinConfiguracaoBoletoModel save(FinConfiguracaoBoletoModel obj) {
		FinConfiguracaoBoletoModel finConfiguracaoBoletoModel = repository.save(obj);
		return finConfiguracaoBoletoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinConfiguracaoBoletoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinConfiguracaoBoleto] - Exception: " + e.getMessage());
		}
	}

}