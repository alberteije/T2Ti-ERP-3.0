package com.t2ti.financeiro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.financeiro.model.BancoContaCaixaModel;

public interface BancoContaCaixaRepository extends JpaRepository<BancoContaCaixaModel, Integer> {}