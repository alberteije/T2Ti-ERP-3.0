package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinLancamentoPagarModel;
import com.t2ti.financeiro.repository.FinLancamentoPagarRepository;

@Service
public class FinLancamentoPagarService {

	@Autowired
	private FinLancamentoPagarRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinLancamentoPagarModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinLancamentoPagarModel> getList(Filter filter) {
		String sql = "select * from fin_lancamento_pagar where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinLancamentoPagarModel.class);
		return query.getResultList();
	}

	public FinLancamentoPagarModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinLancamentoPagarModel save(FinLancamentoPagarModel obj) {
		FinLancamentoPagarModel finLancamentoPagarModel = repository.save(obj);
		return finLancamentoPagarModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinLancamentoPagarModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinLancamentoPagar] - Exception: " + e.getMessage());
		}
	}

}