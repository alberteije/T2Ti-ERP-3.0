package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinNaturezaFinanceiraModel;
import com.t2ti.financeiro.repository.FinNaturezaFinanceiraRepository;

@Service
public class FinNaturezaFinanceiraService {

	@Autowired
	private FinNaturezaFinanceiraRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinNaturezaFinanceiraModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinNaturezaFinanceiraModel> getList(Filter filter) {
		String sql = "select * from fin_natureza_financeira where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinNaturezaFinanceiraModel.class);
		return query.getResultList();
	}

	public FinNaturezaFinanceiraModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinNaturezaFinanceiraModel save(FinNaturezaFinanceiraModel obj) {
		FinNaturezaFinanceiraModel finNaturezaFinanceiraModel = repository.save(obj);
		return finNaturezaFinanceiraModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinNaturezaFinanceiraModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinNaturezaFinanceira] - Exception: " + e.getMessage());
		}
	}

}