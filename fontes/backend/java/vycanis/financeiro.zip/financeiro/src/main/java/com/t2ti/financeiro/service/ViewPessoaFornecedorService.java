package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.ViewPessoaFornecedorModel;
import com.t2ti.financeiro.repository.ViewPessoaFornecedorRepository;

@Service
public class ViewPessoaFornecedorService {

	@Autowired
	private ViewPessoaFornecedorRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ViewPessoaFornecedorModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ViewPessoaFornecedorModel> getList(Filter filter) {
		String sql = "select * from view_pessoa_fornecedor where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewPessoaFornecedorModel.class);
		return query.getResultList();
	}

	public ViewPessoaFornecedorModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ViewPessoaFornecedorModel save(ViewPessoaFornecedorModel obj) {
		ViewPessoaFornecedorModel viewPessoaFornecedorModel = repository.save(obj);
		return viewPessoaFornecedorModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ViewPessoaFornecedorModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ViewPessoaFornecedor] - Exception: " + e.getMessage());
		}
	}

}