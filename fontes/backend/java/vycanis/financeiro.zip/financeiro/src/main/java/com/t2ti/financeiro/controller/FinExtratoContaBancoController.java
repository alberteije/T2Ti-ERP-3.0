package com.t2ti.financeiro.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.exception.ResourseNotFoundException;
import com.t2ti.financeiro.exception.BadRequestException;
import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.model.FinExtratoContaBancoModel;
import com.t2ti.financeiro.service.FinExtratoContaBancoService;

@RestController
@RequestMapping(value = "/fin-extrato-conta-banco", produces = "application/json;charset=UTF-8")
public class FinExtratoContaBancoController {

	@Autowired
	private FinExtratoContaBancoService service;
	
	@GetMapping({ "", "/" })
	public List<FinExtratoContaBancoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [FinExtratoContaBanco] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public FinExtratoContaBancoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found FinExtratoContaBanco].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found FinExtratoContaBanco] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public FinExtratoContaBancoModel insert(@RequestBody FinExtratoContaBancoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert FinExtratoContaBanco] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public FinExtratoContaBancoModel update(@RequestBody FinExtratoContaBancoModel objJson) {	
		try {			
			FinExtratoContaBancoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update FinExtratoContaBanco].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update FinExtratoContaBanco] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinExtratoContaBanco] - Exception: " + e.getMessage());
		}
	}
	
}