package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cheque")
@NamedQuery(name="ChequeModel.findAll", query="SELECT t FROM ChequeModel t")
public class ChequeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ChequeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private Integer numero;

	@Column(name="status_cheque")
	private String statusCheque;

	@Temporal(TemporalType.DATE)
@Column(name="data_status")
	private Date dataStatus;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_talonario_cheque")
	private TalonarioChequeModel talonarioChequeModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public String getStatusCheque() { 
		return this.statusCheque; 
	} 

	public void setStatusCheque(String statusCheque) { 
		this.statusCheque = statusCheque; 
	} 

	public Date getDataStatus() { 
		return this.dataStatus; 
	} 

	public void setDataStatus(Date dataStatus) { 
		this.dataStatus = dataStatus; 
	} 

	public TalonarioChequeModel getTalonarioChequeModel() { 
	return this.talonarioChequeModel; 
	} 

	public void setTalonarioChequeModel(TalonarioChequeModel talonarioChequeModel) { 
	this.talonarioChequeModel = talonarioChequeModel; 
	} 

		
}