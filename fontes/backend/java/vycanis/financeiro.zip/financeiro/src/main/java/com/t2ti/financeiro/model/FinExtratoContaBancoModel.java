package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_extrato_conta_banco")
@NamedQuery(name="FinExtratoContaBancoModel.findAll", query="SELECT t FROM FinExtratoContaBancoModel t")
public class FinExtratoContaBancoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinExtratoContaBancoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="mes_ano")
	private String mesAno;

	@Column(name="mes")
	private String mes;

	@Column(name="ano")
	private String ano;

	@Temporal(TemporalType.DATE)
@Column(name="data_movimento")
	private Date dataMovimento;

	@Temporal(TemporalType.DATE)
@Column(name="data_balancete")
	private Date dataBalancete;

	@Column(name="historico")
	private String historico;

	@Column(name="documento")
	private String documento;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="conciliado")
	private String conciliado;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JoinColumn(name="id_banco_conta_caixa")
	private BancoContaCaixaModel bancoContaCaixaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getMesAno() { 
		return this.mesAno; 
	} 

	public void setMesAno(String mesAno) { 
		this.mesAno = mesAno; 
	} 

	public String getMes() { 
		return this.mes; 
	} 

	public void setMes(String mes) { 
		this.mes = mes; 
	} 

	public String getAno() { 
		return this.ano; 
	} 

	public void setAno(String ano) { 
		this.ano = ano; 
	} 

	public Date getDataMovimento() { 
		return this.dataMovimento; 
	} 

	public void setDataMovimento(Date dataMovimento) { 
		this.dataMovimento = dataMovimento; 
	} 

	public Date getDataBalancete() { 
		return this.dataBalancete; 
	} 

	public void setDataBalancete(Date dataBalancete) { 
		this.dataBalancete = dataBalancete; 
	} 

	public String getHistorico() { 
		return this.historico; 
	} 

	public void setHistorico(String historico) { 
		this.historico = historico; 
	} 

	public String getDocumento() { 
		return this.documento; 
	} 

	public void setDocumento(String documento) { 
		this.documento = documento; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public String getConciliado() { 
		return this.conciliado; 
	} 

	public void setConciliado(String conciliado) { 
		this.conciliado = conciliado; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public BancoContaCaixaModel getBancoContaCaixaModel() { 
	return this.bancoContaCaixaModel; 
	} 

	public void setBancoContaCaixaModel(BancoContaCaixaModel bancoContaCaixaModel) { 
	this.bancoContaCaixaModel = bancoContaCaixaModel; 
	} 

		
}