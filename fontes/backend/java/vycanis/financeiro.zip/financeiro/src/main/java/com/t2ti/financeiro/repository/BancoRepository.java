package com.t2ti.financeiro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.financeiro.model.BancoModel;

public interface BancoRepository extends JpaRepository<BancoModel, Integer> {}