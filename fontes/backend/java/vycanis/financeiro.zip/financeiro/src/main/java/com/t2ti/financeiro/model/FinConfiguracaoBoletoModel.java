package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_configuracao_boleto")
@NamedQuery(name="FinConfiguracaoBoletoModel.findAll", query="SELECT t FROM FinConfiguracaoBoletoModel t")
public class FinConfiguracaoBoletoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinConfiguracaoBoletoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="instrucao01")
	private String instrucao01;

	@Column(name="instrucao02")
	private String instrucao02;

	@Column(name="caminho_arquivo_remessa")
	private String caminhoArquivoRemessa;

	@Column(name="caminho_arquivo_retorno")
	private String caminhoArquivoRetorno;

	@Column(name="caminho_arquivo_logotipo")
	private String caminhoArquivoLogotipo;

	@Column(name="caminho_arquivo_pdf")
	private String caminhoArquivoPdf;

	@Column(name="mensagem")
	private String mensagem;

	@Column(name="local_pagamento")
	private String localPagamento;

	@Column(name="layout_remessa")
	private String layoutRemessa;

	@Column(name="aceite")
	private String aceite;

	@Column(name="especie")
	private String especie;

	@Column(name="carteira")
	private String carteira;

	@Column(name="codigo_convenio")
	private String codigoConvenio;

	@Column(name="codigo_cedente")
	private String codigoCedente;

	@Column(name="taxa_multa")
	private BigDecimal taxaMulta;

	@Column(name="taxa_juro")
	private BigDecimal taxaJuro;

	@Column(name="dias_protesto")
	private Integer diasProtesto;

	@Column(name="nosso_numero_anterior")
	private String nossoNumeroAnterior;

	@ManyToOne 
	@JoinColumn(name="id_banco_conta_caixa")
	private BancoContaCaixaModel bancoContaCaixaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getInstrucao01() { 
		return this.instrucao01; 
	} 

	public void setInstrucao01(String instrucao01) { 
		this.instrucao01 = instrucao01; 
	} 

	public String getInstrucao02() { 
		return this.instrucao02; 
	} 

	public void setInstrucao02(String instrucao02) { 
		this.instrucao02 = instrucao02; 
	} 

	public String getCaminhoArquivoRemessa() { 
		return this.caminhoArquivoRemessa; 
	} 

	public void setCaminhoArquivoRemessa(String caminhoArquivoRemessa) { 
		this.caminhoArquivoRemessa = caminhoArquivoRemessa; 
	} 

	public String getCaminhoArquivoRetorno() { 
		return this.caminhoArquivoRetorno; 
	} 

	public void setCaminhoArquivoRetorno(String caminhoArquivoRetorno) { 
		this.caminhoArquivoRetorno = caminhoArquivoRetorno; 
	} 

	public String getCaminhoArquivoLogotipo() { 
		return this.caminhoArquivoLogotipo; 
	} 

	public void setCaminhoArquivoLogotipo(String caminhoArquivoLogotipo) { 
		this.caminhoArquivoLogotipo = caminhoArquivoLogotipo; 
	} 

	public String getCaminhoArquivoPdf() { 
		return this.caminhoArquivoPdf; 
	} 

	public void setCaminhoArquivoPdf(String caminhoArquivoPdf) { 
		this.caminhoArquivoPdf = caminhoArquivoPdf; 
	} 

	public String getMensagem() { 
		return this.mensagem; 
	} 

	public void setMensagem(String mensagem) { 
		this.mensagem = mensagem; 
	} 

	public String getLocalPagamento() { 
		return this.localPagamento; 
	} 

	public void setLocalPagamento(String localPagamento) { 
		this.localPagamento = localPagamento; 
	} 

	public String getLayoutRemessa() { 
		return this.layoutRemessa; 
	} 

	public void setLayoutRemessa(String layoutRemessa) { 
		this.layoutRemessa = layoutRemessa; 
	} 

	public String getAceite() { 
		return this.aceite; 
	} 

	public void setAceite(String aceite) { 
		this.aceite = aceite; 
	} 

	public String getEspecie() { 
		return this.especie; 
	} 

	public void setEspecie(String especie) { 
		this.especie = especie; 
	} 

	public String getCarteira() { 
		return this.carteira; 
	} 

	public void setCarteira(String carteira) { 
		this.carteira = carteira; 
	} 

	public String getCodigoConvenio() { 
		return this.codigoConvenio; 
	} 

	public void setCodigoConvenio(String codigoConvenio) { 
		this.codigoConvenio = codigoConvenio; 
	} 

	public String getCodigoCedente() { 
		return this.codigoCedente; 
	} 

	public void setCodigoCedente(String codigoCedente) { 
		this.codigoCedente = codigoCedente; 
	} 

	public BigDecimal getTaxaMulta() { 
		return this.taxaMulta; 
	} 

	public void setTaxaMulta(BigDecimal taxaMulta) { 
		this.taxaMulta = taxaMulta; 
	} 

	public BigDecimal getTaxaJuro() { 
		return this.taxaJuro; 
	} 

	public void setTaxaJuro(BigDecimal taxaJuro) { 
		this.taxaJuro = taxaJuro; 
	} 

	public Integer getDiasProtesto() { 
		return this.diasProtesto; 
	} 

	public void setDiasProtesto(Integer diasProtesto) { 
		this.diasProtesto = diasProtesto; 
	} 

	public String getNossoNumeroAnterior() { 
		return this.nossoNumeroAnterior; 
	} 

	public void setNossoNumeroAnterior(String nossoNumeroAnterior) { 
		this.nossoNumeroAnterior = nossoNumeroAnterior; 
	} 

	public BancoContaCaixaModel getBancoContaCaixaModel() { 
	return this.bancoContaCaixaModel; 
	} 

	public void setBancoContaCaixaModel(BancoContaCaixaModel bancoContaCaixaModel) { 
	this.bancoContaCaixaModel = bancoContaCaixaModel; 
	} 

		
}