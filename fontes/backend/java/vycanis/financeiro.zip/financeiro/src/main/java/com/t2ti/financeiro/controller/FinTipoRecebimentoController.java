package com.t2ti.financeiro.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.exception.ResourseNotFoundException;
import com.t2ti.financeiro.exception.BadRequestException;
import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.model.FinTipoRecebimentoModel;
import com.t2ti.financeiro.service.FinTipoRecebimentoService;

@RestController
@RequestMapping(value = "/fin-tipo-recebimento", produces = "application/json;charset=UTF-8")
public class FinTipoRecebimentoController {

	@Autowired
	private FinTipoRecebimentoService service;
	
	@GetMapping({ "", "/" })
	public List<FinTipoRecebimentoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [FinTipoRecebimento] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public FinTipoRecebimentoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found FinTipoRecebimento].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found FinTipoRecebimento] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public FinTipoRecebimentoModel insert(@RequestBody FinTipoRecebimentoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert FinTipoRecebimento] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public FinTipoRecebimentoModel update(@RequestBody FinTipoRecebimentoModel objJson) {	
		try {			
			FinTipoRecebimentoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update FinTipoRecebimento].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update FinTipoRecebimento] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinTipoRecebimento] - Exception: " + e.getMessage());
		}
	}
	
}