package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_lancamento_pagar")
@NamedQuery(name="FinLancamentoPagarModel.findAll", query="SELECT t FROM FinLancamentoPagarModel t")
public class FinLancamentoPagarModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinLancamentoPagarModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade_parcela")
	private Integer quantidadeParcela;

	@Column(name="valor_a_pagar")
	private BigDecimal valorAPagar;

	@Temporal(TemporalType.DATE)
@Column(name="data_lancamento")
	private Date dataLancamento;

	@Column(name="numero_documento")
	private String numeroDocumento;

	@Temporal(TemporalType.DATE)
@Column(name="primeiro_vencimento")
	private Date primeiroVencimento;

	@Column(name="intervalo_entre_parcelas")
	private Integer intervaloEntreParcelas;

	@Column(name="dia_fixo")
	private String diaFixo;

	@Column(name="imagem_documento")
	private String imagemDocumento;

	@OneToMany(mappedBy = "finLancamentoPagarModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FinParcelaPagarModel> finParcelaPagarModelList; 

	@ManyToOne 
	@JoinColumn(name="id_fin_documento_origem")
	private FinDocumentoOrigemModel finDocumentoOrigemModel; 

	@ManyToOne 
	@JoinColumn(name="id_banco_conta_caixa")
	private BancoContaCaixaModel bancoContaCaixaModel; 

	@ManyToOne 
	@JoinColumn(name="id_fin_natureza_financeira")
	private FinNaturezaFinanceiraModel finNaturezaFinanceiraModel; 

	@ManyToOne 
	@JoinColumn(name="id_fornecedor")
	private ViewPessoaFornecedorModel viewPessoaFornecedorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidadeParcela() { 
		return this.quantidadeParcela; 
	} 

	public void setQuantidadeParcela(Integer quantidadeParcela) { 
		this.quantidadeParcela = quantidadeParcela; 
	} 

	public BigDecimal getValorAPagar() { 
		return this.valorAPagar; 
	} 

	public void setValorAPagar(BigDecimal valorAPagar) { 
		this.valorAPagar = valorAPagar; 
	} 

	public Date getDataLancamento() { 
		return this.dataLancamento; 
	} 

	public void setDataLancamento(Date dataLancamento) { 
		this.dataLancamento = dataLancamento; 
	} 

	public String getNumeroDocumento() { 
		return this.numeroDocumento; 
	} 

	public void setNumeroDocumento(String numeroDocumento) { 
		this.numeroDocumento = numeroDocumento; 
	} 

	public Date getPrimeiroVencimento() { 
		return this.primeiroVencimento; 
	} 

	public void setPrimeiroVencimento(Date primeiroVencimento) { 
		this.primeiroVencimento = primeiroVencimento; 
	} 

	public Integer getIntervaloEntreParcelas() { 
		return this.intervaloEntreParcelas; 
	} 

	public void setIntervaloEntreParcelas(Integer intervaloEntreParcelas) { 
		this.intervaloEntreParcelas = intervaloEntreParcelas; 
	} 

	public String getDiaFixo() { 
		return this.diaFixo; 
	} 

	public void setDiaFixo(String diaFixo) { 
		this.diaFixo = diaFixo; 
	} 

	public String getImagemDocumento() { 
		return this.imagemDocumento; 
	} 

	public void setImagemDocumento(String imagemDocumento) { 
		this.imagemDocumento = imagemDocumento; 
	} 

	public Set<FinParcelaPagarModel> getFinParcelaPagarModelList() { 
	return this.finParcelaPagarModelList; 
	} 

	public void setFinParcelaPagarModelList(Set<FinParcelaPagarModel> finParcelaPagarModelList) { 
	this.finParcelaPagarModelList = finParcelaPagarModelList; 
		for (FinParcelaPagarModel finParcelaPagarModel : finParcelaPagarModelList) { 
			finParcelaPagarModel.setFinLancamentoPagarModel(this); 
		}
	} 

	public FinDocumentoOrigemModel getFinDocumentoOrigemModel() { 
	return this.finDocumentoOrigemModel; 
	} 

	public void setFinDocumentoOrigemModel(FinDocumentoOrigemModel finDocumentoOrigemModel) { 
	this.finDocumentoOrigemModel = finDocumentoOrigemModel; 
	} 

	public BancoContaCaixaModel getBancoContaCaixaModel() { 
	return this.bancoContaCaixaModel; 
	} 

	public void setBancoContaCaixaModel(BancoContaCaixaModel bancoContaCaixaModel) { 
	this.bancoContaCaixaModel = bancoContaCaixaModel; 
	} 

	public FinNaturezaFinanceiraModel getFinNaturezaFinanceiraModel() { 
	return this.finNaturezaFinanceiraModel; 
	} 

	public void setFinNaturezaFinanceiraModel(FinNaturezaFinanceiraModel finNaturezaFinanceiraModel) { 
	this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel; 
	} 

	public ViewPessoaFornecedorModel getViewPessoaFornecedorModel() { 
	return this.viewPessoaFornecedorModel; 
	} 

	public void setViewPessoaFornecedorModel(ViewPessoaFornecedorModel viewPessoaFornecedorModel) { 
	this.viewPessoaFornecedorModel = viewPessoaFornecedorModel; 
	} 

		
}