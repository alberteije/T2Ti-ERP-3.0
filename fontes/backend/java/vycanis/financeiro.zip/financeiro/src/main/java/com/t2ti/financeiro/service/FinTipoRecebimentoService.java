package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinTipoRecebimentoModel;
import com.t2ti.financeiro.repository.FinTipoRecebimentoRepository;

@Service
public class FinTipoRecebimentoService {

	@Autowired
	private FinTipoRecebimentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinTipoRecebimentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinTipoRecebimentoModel> getList(Filter filter) {
		String sql = "select * from fin_tipo_recebimento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinTipoRecebimentoModel.class);
		return query.getResultList();
	}

	public FinTipoRecebimentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinTipoRecebimentoModel save(FinTipoRecebimentoModel obj) {
		FinTipoRecebimentoModel finTipoRecebimentoModel = repository.save(obj);
		return finTipoRecebimentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinTipoRecebimentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinTipoRecebimento] - Exception: " + e.getMessage());
		}
	}

}