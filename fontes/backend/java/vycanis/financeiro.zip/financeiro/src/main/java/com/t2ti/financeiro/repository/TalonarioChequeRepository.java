package com.t2ti.financeiro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.financeiro.model.TalonarioChequeModel;

public interface TalonarioChequeRepository extends JpaRepository<TalonarioChequeModel, Integer> {}