package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="fin_status_parcela")
@NamedQuery(name="FinStatusParcelaModel.findAll", query="SELECT t FROM FinStatusParcelaModel t")
public class FinStatusParcelaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinStatusParcelaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="situacao")
	private String situacao;

	@Column(name="descricao")
	private String descricao;

	@Column(name="procedimento")
	private String procedimento;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getProcedimento() { 
		return this.procedimento; 
	} 

	public void setProcedimento(String procedimento) { 
		this.procedimento = procedimento; 
	} 

		
}