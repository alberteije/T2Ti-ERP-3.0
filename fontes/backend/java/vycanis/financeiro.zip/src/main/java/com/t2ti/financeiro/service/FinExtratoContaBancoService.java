package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinExtratoContaBancoModel;
import com.t2ti.financeiro.repository.FinExtratoContaBancoRepository;

@Service
public class FinExtratoContaBancoService {

	@Autowired
	private FinExtratoContaBancoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinExtratoContaBancoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinExtratoContaBancoModel> getList(Filter filter) {
		String sql = "select * from fin_extrato_conta_banco where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinExtratoContaBancoModel.class);
		return query.getResultList();
	}

	public FinExtratoContaBancoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinExtratoContaBancoModel save(FinExtratoContaBancoModel obj) {
		FinExtratoContaBancoModel finExtratoContaBancoModel = repository.save(obj);
		return finExtratoContaBancoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinExtratoContaBancoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinExtratoContaBanco] - Exception: " + e.getMessage());
		}
	}

}