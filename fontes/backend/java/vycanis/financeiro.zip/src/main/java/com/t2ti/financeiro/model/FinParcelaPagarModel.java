package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_parcela_pagar")
@NamedQuery(name="FinParcelaPagarModel.findAll", query="SELECT t FROM FinParcelaPagarModel t")
public class FinParcelaPagarModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinParcelaPagarModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_parcela")
	private Integer numeroParcela;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="data_vencimento")
	private Date dataVencimento;

	@Temporal(TemporalType.DATE)
@Column(name="data_pagamento")
	private Date dataPagamento;

	@Temporal(TemporalType.DATE)
@Column(name="desconto_ate")
	private Date descontoAte;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="taxa_juro")
	private BigDecimal taxaJuro;

	@Column(name="taxa_multa")
	private BigDecimal taxaMulta;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_juro")
	private BigDecimal valorJuro;

	@Column(name="valor_multa")
	private BigDecimal valorMulta;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_pago")
	private BigDecimal valorPago;

	@Column(name="historico")
	private String historico;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_fin_lancamento_pagar")
	private FinLancamentoPagarModel finLancamentoPagarModel; 

	@ManyToOne 
	@JoinColumn(name="id_fin_status_parcela")
	private FinStatusParcelaModel finStatusParcelaModel; 

	@ManyToOne 
	@JoinColumn(name="id_fin_tipo_pagamento")
	private FinTipoPagamentoModel finTipoPagamentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumeroParcela() { 
		return this.numeroParcela; 
	} 

	public void setNumeroParcela(Integer numeroParcela) { 
		this.numeroParcela = numeroParcela; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public Date getDataVencimento() { 
		return this.dataVencimento; 
	} 

	public void setDataVencimento(Date dataVencimento) { 
		this.dataVencimento = dataVencimento; 
	} 

	public Date getDataPagamento() { 
		return this.dataPagamento; 
	} 

	public void setDataPagamento(Date dataPagamento) { 
		this.dataPagamento = dataPagamento; 
	} 

	public Date getDescontoAte() { 
		return this.descontoAte; 
	} 

	public void setDescontoAte(Date descontoAte) { 
		this.descontoAte = descontoAte; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public BigDecimal getTaxaJuro() { 
		return this.taxaJuro; 
	} 

	public void setTaxaJuro(BigDecimal taxaJuro) { 
		this.taxaJuro = taxaJuro; 
	} 

	public BigDecimal getTaxaMulta() { 
		return this.taxaMulta; 
	} 

	public void setTaxaMulta(BigDecimal taxaMulta) { 
		this.taxaMulta = taxaMulta; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorJuro() { 
		return this.valorJuro; 
	} 

	public void setValorJuro(BigDecimal valorJuro) { 
		this.valorJuro = valorJuro; 
	} 

	public BigDecimal getValorMulta() { 
		return this.valorMulta; 
	} 

	public void setValorMulta(BigDecimal valorMulta) { 
		this.valorMulta = valorMulta; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorPago() { 
		return this.valorPago; 
	} 

	public void setValorPago(BigDecimal valorPago) { 
		this.valorPago = valorPago; 
	} 

	public String getHistorico() { 
		return this.historico; 
	} 

	public void setHistorico(String historico) { 
		this.historico = historico; 
	} 

	public FinLancamentoPagarModel getFinLancamentoPagarModel() { 
	return this.finLancamentoPagarModel; 
	} 

	public void setFinLancamentoPagarModel(FinLancamentoPagarModel finLancamentoPagarModel) { 
	this.finLancamentoPagarModel = finLancamentoPagarModel; 
	} 

	public FinStatusParcelaModel getFinStatusParcelaModel() { 
	return this.finStatusParcelaModel; 
	} 

	public void setFinStatusParcelaModel(FinStatusParcelaModel finStatusParcelaModel) { 
	this.finStatusParcelaModel = finStatusParcelaModel; 
	} 

	public FinTipoPagamentoModel getFinTipoPagamentoModel() { 
	return this.finTipoPagamentoModel; 
	} 

	public void setFinTipoPagamentoModel(FinTipoPagamentoModel finTipoPagamentoModel) { 
	this.finTipoPagamentoModel = finTipoPagamentoModel; 
	} 

		
}