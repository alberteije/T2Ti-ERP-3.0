package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinChequeEmitidoModel;
import com.t2ti.financeiro.repository.FinChequeEmitidoRepository;

@Service
public class FinChequeEmitidoService {

	@Autowired
	private FinChequeEmitidoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinChequeEmitidoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinChequeEmitidoModel> getList(Filter filter) {
		String sql = "select * from fin_cheque_emitido where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinChequeEmitidoModel.class);
		return query.getResultList();
	}

	public FinChequeEmitidoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinChequeEmitidoModel save(FinChequeEmitidoModel obj) {
		FinChequeEmitidoModel finChequeEmitidoModel = repository.save(obj);
		return finChequeEmitidoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinChequeEmitidoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinChequeEmitido] - Exception: " + e.getMessage());
		}
	}

}