package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.FinTipoPagamentoModel;
import com.t2ti.financeiro.repository.FinTipoPagamentoRepository;

@Service
public class FinTipoPagamentoService {

	@Autowired
	private FinTipoPagamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FinTipoPagamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FinTipoPagamentoModel> getList(Filter filter) {
		String sql = "select * from fin_tipo_pagamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FinTipoPagamentoModel.class);
		return query.getResultList();
	}

	public FinTipoPagamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FinTipoPagamentoModel save(FinTipoPagamentoModel obj) {
		FinTipoPagamentoModel finTipoPagamentoModel = repository.save(obj);
		return finTipoPagamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FinTipoPagamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinTipoPagamento] - Exception: " + e.getMessage());
		}
	}

}