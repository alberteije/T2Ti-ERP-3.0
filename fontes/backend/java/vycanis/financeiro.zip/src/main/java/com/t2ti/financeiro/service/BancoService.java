package com.t2ti.financeiro.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.financeiro.util.Filter;
import com.t2ti.financeiro.exception.GenericException;
import com.t2ti.financeiro.model.BancoModel;
import com.t2ti.financeiro.repository.BancoRepository;

@Service
public class BancoService {

	@Autowired
	private BancoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<BancoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<BancoModel> getList(Filter filter) {
		String sql = "select * from banco where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, BancoModel.class);
		return query.getResultList();
	}

	public BancoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public BancoModel save(BancoModel obj) {
		BancoModel bancoModel = repository.save(obj);
		return bancoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		BancoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Banco] - Exception: " + e.getMessage());
		}
	}

}