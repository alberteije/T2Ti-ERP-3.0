package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_cheque_emitido")
@NamedQuery(name="FinChequeEmitidoModel.findAll", query="SELECT t FROM FinChequeEmitidoModel t")
public class FinChequeEmitidoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinChequeEmitidoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="bom_para")
	private Date bomPara;

	@Temporal(TemporalType.DATE)
@Column(name="data_compensacao")
	private Date dataCompensacao;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="nominal_a")
	private String nominalA;

	@ManyToOne 
	@JoinColumn(name="id_cheque")
	private ChequeModel chequeModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public Date getBomPara() { 
		return this.bomPara; 
	} 

	public void setBomPara(Date bomPara) { 
		this.bomPara = bomPara; 
	} 

	public Date getDataCompensacao() { 
		return this.dataCompensacao; 
	} 

	public void setDataCompensacao(Date dataCompensacao) { 
		this.dataCompensacao = dataCompensacao; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public String getNominalA() { 
		return this.nominalA; 
	} 

	public void setNominalA(String nominalA) { 
		this.nominalA = nominalA; 
	} 

	public ChequeModel getChequeModel() { 
	return this.chequeModel; 
	} 

	public void setChequeModel(ChequeModel chequeModel) { 
	this.chequeModel = chequeModel; 
	} 

		
}