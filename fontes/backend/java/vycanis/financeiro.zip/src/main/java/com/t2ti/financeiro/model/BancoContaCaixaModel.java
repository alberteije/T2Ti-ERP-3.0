package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="banco_conta_caixa")
@NamedQuery(name="BancoContaCaixaModel.findAll", query="SELECT t FROM BancoContaCaixaModel t")
public class BancoContaCaixaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public BancoContaCaixaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Column(name="digito")
	private String digito;

	@Column(name="nome")
	private String nome;

	@Column(name="tipo")
	private String tipo;

	@Column(name="descricao")
	private String descricao;

	@ManyToOne 
	@JoinColumn(name="id_banco_agencia")
	private BancoAgenciaModel bancoAgenciaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getDigito() { 
		return this.digito; 
	} 

	public void setDigito(String digito) { 
		this.digito = digito; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public BancoAgenciaModel getBancoAgenciaModel() { 
	return this.bancoAgenciaModel; 
	} 

	public void setBancoAgenciaModel(BancoAgenciaModel bancoAgenciaModel) { 
	this.bancoAgenciaModel = bancoAgenciaModel; 
	} 

		
}