package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_cheque_recebido")
@NamedQuery(name="FinChequeRecebidoModel.findAll", query="SELECT t FROM FinChequeRecebidoModel t")
public class FinChequeRecebidoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinChequeRecebidoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cpf")
	private String cpf;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="nome")
	private String nome;

	@Column(name="codigo_banco")
	private String codigoBanco;

	@Column(name="codigo_agencia")
	private String codigoAgencia;

	@Column(name="conta")
	private String conta;

	@Column(name="numero")
	private Integer numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="bom_para")
	private Date bomPara;

	@Temporal(TemporalType.DATE)
@Column(name="data_compensacao")
	private Date dataCompensacao;

	@Column(name="valor")
	private BigDecimal valor;

	@Temporal(TemporalType.DATE)
@Column(name="custodia_data")
	private Date custodiaData;

	@Column(name="custodia_tarifa")
	private BigDecimal custodiaTarifa;

	@Column(name="custodia_comissao")
	private BigDecimal custodiaComissao;

	@Temporal(TemporalType.DATE)
@Column(name="desconto_data")
	private Date descontoData;

	@Column(name="desconto_tarifa")
	private BigDecimal descontoTarifa;

	@Column(name="desconto_comissao")
	private BigDecimal descontoComissao;

	@Column(name="valor_recebido")
	private BigDecimal valorRecebido;

	@ManyToOne 
	@JoinColumn(name="id_cliente")
	private ViewPessoaClienteModel viewPessoaClienteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getCodigoBanco() { 
		return this.codigoBanco; 
	} 

	public void setCodigoBanco(String codigoBanco) { 
		this.codigoBanco = codigoBanco; 
	} 

	public String getCodigoAgencia() { 
		return this.codigoAgencia; 
	} 

	public void setCodigoAgencia(String codigoAgencia) { 
		this.codigoAgencia = codigoAgencia; 
	} 

	public String getConta() { 
		return this.conta; 
	} 

	public void setConta(String conta) { 
		this.conta = conta; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public Date getBomPara() { 
		return this.bomPara; 
	} 

	public void setBomPara(Date bomPara) { 
		this.bomPara = bomPara; 
	} 

	public Date getDataCompensacao() { 
		return this.dataCompensacao; 
	} 

	public void setDataCompensacao(Date dataCompensacao) { 
		this.dataCompensacao = dataCompensacao; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public Date getCustodiaData() { 
		return this.custodiaData; 
	} 

	public void setCustodiaData(Date custodiaData) { 
		this.custodiaData = custodiaData; 
	} 

	public BigDecimal getCustodiaTarifa() { 
		return this.custodiaTarifa; 
	} 

	public void setCustodiaTarifa(BigDecimal custodiaTarifa) { 
		this.custodiaTarifa = custodiaTarifa; 
	} 

	public BigDecimal getCustodiaComissao() { 
		return this.custodiaComissao; 
	} 

	public void setCustodiaComissao(BigDecimal custodiaComissao) { 
		this.custodiaComissao = custodiaComissao; 
	} 

	public Date getDescontoData() { 
		return this.descontoData; 
	} 

	public void setDescontoData(Date descontoData) { 
		this.descontoData = descontoData; 
	} 

	public BigDecimal getDescontoTarifa() { 
		return this.descontoTarifa; 
	} 

	public void setDescontoTarifa(BigDecimal descontoTarifa) { 
		this.descontoTarifa = descontoTarifa; 
	} 

	public BigDecimal getDescontoComissao() { 
		return this.descontoComissao; 
	} 

	public void setDescontoComissao(BigDecimal descontoComissao) { 
		this.descontoComissao = descontoComissao; 
	} 

	public BigDecimal getValorRecebido() { 
		return this.valorRecebido; 
	} 

	public void setValorRecebido(BigDecimal valorRecebido) { 
		this.valorRecebido = valorRecebido; 
	} 

	public ViewPessoaClienteModel getViewPessoaClienteModel() { 
	return this.viewPessoaClienteModel; 
	} 

	public void setViewPessoaClienteModel(ViewPessoaClienteModel viewPessoaClienteModel) { 
	this.viewPessoaClienteModel = viewPessoaClienteModel; 
	} 

		
}