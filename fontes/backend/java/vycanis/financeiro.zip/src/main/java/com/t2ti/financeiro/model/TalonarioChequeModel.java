package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="talonario_cheque")
@NamedQuery(name="TalonarioChequeModel.findAll", query="SELECT t FROM TalonarioChequeModel t")
public class TalonarioChequeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TalonarioChequeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="talao")
	private String talao;

	@Column(name="numero")
	private Integer numero;

	@Column(name="status_talao")
	private String statusTalao;

	@OneToMany(mappedBy = "talonarioChequeModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ChequeModel> chequeModelList; 

	@ManyToOne 
	@JoinColumn(name="id_banco_conta_caixa")
	private BancoContaCaixaModel bancoContaCaixaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTalao() { 
		return this.talao; 
	} 

	public void setTalao(String talao) { 
		this.talao = talao; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public String getStatusTalao() { 
		return this.statusTalao; 
	} 

	public void setStatusTalao(String statusTalao) { 
		this.statusTalao = statusTalao; 
	} 

	public Set<ChequeModel> getChequeModelList() { 
	return this.chequeModelList; 
	} 

	public void setChequeModelList(Set<ChequeModel> chequeModelList) { 
	this.chequeModelList = chequeModelList; 
		for (ChequeModel chequeModel : chequeModelList) { 
			chequeModel.setTalonarioChequeModel(this); 
		}
	} 

	public BancoContaCaixaModel getBancoContaCaixaModel() { 
	return this.bancoContaCaixaModel; 
	} 

	public void setBancoContaCaixaModel(BancoContaCaixaModel bancoContaCaixaModel) { 
	this.bancoContaCaixaModel = bancoContaCaixaModel; 
	} 

		
}