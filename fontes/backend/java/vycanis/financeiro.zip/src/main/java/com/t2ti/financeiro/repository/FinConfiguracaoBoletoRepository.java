package com.t2ti.financeiro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.financeiro.model.FinConfiguracaoBoletoModel;

public interface FinConfiguracaoBoletoRepository extends JpaRepository<FinConfiguracaoBoletoModel, Integer> {}