package com.t2ti.financeiro.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fin_fechamento_caixa_banco")
@NamedQuery(name="FinFechamentoCaixaBancoModel.findAll", query="SELECT t FROM FinFechamentoCaixaBancoModel t")
public class FinFechamentoCaixaBancoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinFechamentoCaixaBancoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_fechamento")
	private Date dataFechamento;

	@Column(name="mes_ano")
	private String mesAno;

	@Column(name="mes")
	private String mes;

	@Column(name="ano")
	private String ano;

	@Column(name="saldo_anterior")
	private BigDecimal saldoAnterior;

	@Column(name="recebimentos")
	private BigDecimal recebimentos;

	@Column(name="pagamentos")
	private BigDecimal pagamentos;

	@Column(name="saldo_conta")
	private BigDecimal saldoConta;

	@Column(name="cheque_nao_compensado")
	private BigDecimal chequeNaoCompensado;

	@Column(name="saldo_disponivel")
	private BigDecimal saldoDisponivel;

	@ManyToOne 
	@JoinColumn(name="id_banco_conta_caixa")
	private BancoContaCaixaModel bancoContaCaixaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataFechamento() { 
		return this.dataFechamento; 
	} 

	public void setDataFechamento(Date dataFechamento) { 
		this.dataFechamento = dataFechamento; 
	} 

	public String getMesAno() { 
		return this.mesAno; 
	} 

	public void setMesAno(String mesAno) { 
		this.mesAno = mesAno; 
	} 

	public String getMes() { 
		return this.mes; 
	} 

	public void setMes(String mes) { 
		this.mes = mes; 
	} 

	public String getAno() { 
		return this.ano; 
	} 

	public void setAno(String ano) { 
		this.ano = ano; 
	} 

	public BigDecimal getSaldoAnterior() { 
		return this.saldoAnterior; 
	} 

	public void setSaldoAnterior(BigDecimal saldoAnterior) { 
		this.saldoAnterior = saldoAnterior; 
	} 

	public BigDecimal getRecebimentos() { 
		return this.recebimentos; 
	} 

	public void setRecebimentos(BigDecimal recebimentos) { 
		this.recebimentos = recebimentos; 
	} 

	public BigDecimal getPagamentos() { 
		return this.pagamentos; 
	} 

	public void setPagamentos(BigDecimal pagamentos) { 
		this.pagamentos = pagamentos; 
	} 

	public BigDecimal getSaldoConta() { 
		return this.saldoConta; 
	} 

	public void setSaldoConta(BigDecimal saldoConta) { 
		this.saldoConta = saldoConta; 
	} 

	public BigDecimal getChequeNaoCompensado() { 
		return this.chequeNaoCompensado; 
	} 

	public void setChequeNaoCompensado(BigDecimal chequeNaoCompensado) { 
		this.chequeNaoCompensado = chequeNaoCompensado; 
	} 

	public BigDecimal getSaldoDisponivel() { 
		return this.saldoDisponivel; 
	} 

	public void setSaldoDisponivel(BigDecimal saldoDisponivel) { 
		this.saldoDisponivel = saldoDisponivel; 
	} 

	public BancoContaCaixaModel getBancoContaCaixaModel() { 
	return this.bancoContaCaixaModel; 
	} 

	public void setBancoContaCaixaModel(BancoContaCaixaModel bancoContaCaixaModel) { 
	this.bancoContaCaixaModel = bancoContaCaixaModel; 
	} 

		
}