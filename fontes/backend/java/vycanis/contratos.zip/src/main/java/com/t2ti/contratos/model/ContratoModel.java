package com.t2ti.contratos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contrato")
@NamedQuery(name="ContratoModel.findAll", query="SELECT t FROM ContratoModel t")
public class ContratoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContratoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio_vigencia")
	private Date dataInicioVigencia;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim_vigencia")
	private Date dataFimVigencia;

	@Column(name="dia_faturamento")
	private String diaFaturamento;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="quantidade_parcelas")
	private Integer quantidadeParcelas;

	@Column(name="intervalo_entre_parcelas")
	private Integer intervaloEntreParcelas;

	@Column(name="classificacao_contabil_conta")
	private String classificacaoContabilConta;

	@Column(name="observacao")
	private String observacao;

	@OneToMany(mappedBy = "contratoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContratoHistoricoReajusteModel> contratoHistoricoReajusteModelList; 

	@OneToMany(mappedBy = "contratoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContratoPrevFaturamentoModel> contratoPrevFaturamentoModelList; 

	@OneToMany(mappedBy = "contratoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContratoHistFaturamentoModel> contratoHistFaturamentoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_tipo_contrato")
	private TipoContratoModel tipoContratoModel; 

	@ManyToOne 
	@JoinColumn(name="id_solicitacao_servico")
	private ContratoSolicitacaoServicoModel contratoSolicitacaoServicoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public Date getDataInicioVigencia() { 
		return this.dataInicioVigencia; 
	} 

	public void setDataInicioVigencia(Date dataInicioVigencia) { 
		this.dataInicioVigencia = dataInicioVigencia; 
	} 

	public Date getDataFimVigencia() { 
		return this.dataFimVigencia; 
	} 

	public void setDataFimVigencia(Date dataFimVigencia) { 
		this.dataFimVigencia = dataFimVigencia; 
	} 

	public String getDiaFaturamento() { 
		return this.diaFaturamento; 
	} 

	public void setDiaFaturamento(String diaFaturamento) { 
		this.diaFaturamento = diaFaturamento; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public Integer getQuantidadeParcelas() { 
		return this.quantidadeParcelas; 
	} 

	public void setQuantidadeParcelas(Integer quantidadeParcelas) { 
		this.quantidadeParcelas = quantidadeParcelas; 
	} 

	public Integer getIntervaloEntreParcelas() { 
		return this.intervaloEntreParcelas; 
	} 

	public void setIntervaloEntreParcelas(Integer intervaloEntreParcelas) { 
		this.intervaloEntreParcelas = intervaloEntreParcelas; 
	} 

	public String getClassificacaoContabilConta() { 
		return this.classificacaoContabilConta; 
	} 

	public void setClassificacaoContabilConta(String classificacaoContabilConta) { 
		this.classificacaoContabilConta = classificacaoContabilConta; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Set<ContratoHistoricoReajusteModel> getContratoHistoricoReajusteModelList() { 
	return this.contratoHistoricoReajusteModelList; 
	} 

	public void setContratoHistoricoReajusteModelList(Set<ContratoHistoricoReajusteModel> contratoHistoricoReajusteModelList) { 
	this.contratoHistoricoReajusteModelList = contratoHistoricoReajusteModelList; 
		for (ContratoHistoricoReajusteModel contratoHistoricoReajusteModel : contratoHistoricoReajusteModelList) { 
			contratoHistoricoReajusteModel.setContratoModel(this); 
		}
	} 

	public Set<ContratoPrevFaturamentoModel> getContratoPrevFaturamentoModelList() { 
	return this.contratoPrevFaturamentoModelList; 
	} 

	public void setContratoPrevFaturamentoModelList(Set<ContratoPrevFaturamentoModel> contratoPrevFaturamentoModelList) { 
	this.contratoPrevFaturamentoModelList = contratoPrevFaturamentoModelList; 
		for (ContratoPrevFaturamentoModel contratoPrevFaturamentoModel : contratoPrevFaturamentoModelList) { 
			contratoPrevFaturamentoModel.setContratoModel(this); 
		}
	} 

	public Set<ContratoHistFaturamentoModel> getContratoHistFaturamentoModelList() { 
	return this.contratoHistFaturamentoModelList; 
	} 

	public void setContratoHistFaturamentoModelList(Set<ContratoHistFaturamentoModel> contratoHistFaturamentoModelList) { 
	this.contratoHistFaturamentoModelList = contratoHistFaturamentoModelList; 
		for (ContratoHistFaturamentoModel contratoHistFaturamentoModel : contratoHistFaturamentoModelList) { 
			contratoHistFaturamentoModel.setContratoModel(this); 
		}
	} 

	public TipoContratoModel getTipoContratoModel() { 
	return this.tipoContratoModel; 
	} 

	public void setTipoContratoModel(TipoContratoModel tipoContratoModel) { 
	this.tipoContratoModel = tipoContratoModel; 
	} 

	public ContratoSolicitacaoServicoModel getContratoSolicitacaoServicoModel() { 
	return this.contratoSolicitacaoServicoModel; 
	} 

	public void setContratoSolicitacaoServicoModel(ContratoSolicitacaoServicoModel contratoSolicitacaoServicoModel) { 
	this.contratoSolicitacaoServicoModel = contratoSolicitacaoServicoModel; 
	} 

		
}