package com.t2ti.contratos.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contratos.util.Filter;
import com.t2ti.contratos.exception.GenericException;
import com.t2ti.contratos.model.ContratoTipoServicoModel;
import com.t2ti.contratos.repository.ContratoTipoServicoRepository;

@Service
public class ContratoTipoServicoService {

	@Autowired
	private ContratoTipoServicoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContratoTipoServicoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContratoTipoServicoModel> getList(Filter filter) {
		String sql = "select * from contrato_tipo_servico where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContratoTipoServicoModel.class);
		return query.getResultList();
	}

	public ContratoTipoServicoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContratoTipoServicoModel save(ContratoTipoServicoModel obj) {
		ContratoTipoServicoModel contratoTipoServicoModel = repository.save(obj);
		return contratoTipoServicoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContratoTipoServicoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContratoTipoServico] - Exception: " + e.getMessage());
		}
	}

}