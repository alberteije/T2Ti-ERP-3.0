package com.t2ti.contratos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contrato_solicitacao_servico")
@NamedQuery(name="ContratoSolicitacaoServicoModel.findAll", query="SELECT t FROM ContratoSolicitacaoServicoModel t")
public class ContratoSolicitacaoServicoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContratoSolicitacaoServicoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_solicitacao")
	private Date dataSolicitacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_desejada_inicio")
	private Date dataDesejadaInicio;

	@Column(name="urgente")
	private String urgente;

	@Column(name="status_solicitacao")
	private String statusSolicitacao;

	@Column(name="descricao")
	private String descricao;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_cliente")
	private ViewPessoaClienteModel viewPessoaClienteModel; 

	@ManyToOne 
	@JoinColumn(name="id_fornecedor")
	private ViewPessoaFornecedorModel viewPessoaFornecedorModel; 

	@ManyToOne 
	@JoinColumn(name="id_setor")
	private SetorModel setorModel; 

	@ManyToOne 
	@JoinColumn(name="id_contrato_tipo_servico")
	private ContratoTipoServicoModel contratoTipoServicoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataSolicitacao() { 
		return this.dataSolicitacao; 
	} 

	public void setDataSolicitacao(Date dataSolicitacao) { 
		this.dataSolicitacao = dataSolicitacao; 
	} 

	public Date getDataDesejadaInicio() { 
		return this.dataDesejadaInicio; 
	} 

	public void setDataDesejadaInicio(Date dataDesejadaInicio) { 
		this.dataDesejadaInicio = dataDesejadaInicio; 
	} 

	public String getUrgente() { 
		return this.urgente; 
	} 

	public void setUrgente(String urgente) { 
		this.urgente = urgente; 
	} 

	public String getStatusSolicitacao() { 
		return this.statusSolicitacao; 
	} 

	public void setStatusSolicitacao(String statusSolicitacao) { 
		this.statusSolicitacao = statusSolicitacao; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public ViewPessoaClienteModel getViewPessoaClienteModel() { 
	return this.viewPessoaClienteModel; 
	} 

	public void setViewPessoaClienteModel(ViewPessoaClienteModel viewPessoaClienteModel) { 
	this.viewPessoaClienteModel = viewPessoaClienteModel; 
	} 

	public ViewPessoaFornecedorModel getViewPessoaFornecedorModel() { 
	return this.viewPessoaFornecedorModel; 
	} 

	public void setViewPessoaFornecedorModel(ViewPessoaFornecedorModel viewPessoaFornecedorModel) { 
	this.viewPessoaFornecedorModel = viewPessoaFornecedorModel; 
	} 

	public SetorModel getSetorModel() { 
	return this.setorModel; 
	} 

	public void setSetorModel(SetorModel setorModel) { 
	this.setorModel = setorModel; 
	} 

	public ContratoTipoServicoModel getContratoTipoServicoModel() { 
	return this.contratoTipoServicoModel; 
	} 

	public void setContratoTipoServicoModel(ContratoTipoServicoModel contratoTipoServicoModel) { 
	this.contratoTipoServicoModel = contratoTipoServicoModel; 
	} 

		
}