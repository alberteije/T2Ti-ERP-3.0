package com.t2ti.contratos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contrato_prev_faturamento")
@NamedQuery(name="ContratoPrevFaturamentoModel.findAll", query="SELECT t FROM ContratoPrevFaturamentoModel t")
public class ContratoPrevFaturamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContratoPrevFaturamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_prevista")
	private Date dataPrevista;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_contrato")
	private ContratoModel contratoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataPrevista() { 
		return this.dataPrevista; 
	} 

	public void setDataPrevista(Date dataPrevista) { 
		this.dataPrevista = dataPrevista; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public ContratoModel getContratoModel() { 
	return this.contratoModel; 
	} 

	public void setContratoModel(ContratoModel contratoModel) { 
	this.contratoModel = contratoModel; 
	} 

		
}