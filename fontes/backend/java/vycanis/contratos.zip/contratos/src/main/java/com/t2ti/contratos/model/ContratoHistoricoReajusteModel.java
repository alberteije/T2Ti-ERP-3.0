package com.t2ti.contratos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contrato_historico_reajuste")
@NamedQuery(name="ContratoHistoricoReajusteModel.findAll", query="SELECT t FROM ContratoHistoricoReajusteModel t")
public class ContratoHistoricoReajusteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContratoHistoricoReajusteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="indice")
	private BigDecimal indice;

	@Column(name="valor_anterior")
	private BigDecimal valorAnterior;

	@Column(name="valor_atual")
	private BigDecimal valorAtual;

	@Temporal(TemporalType.DATE)
@Column(name="data_reajuste")
	private Date dataReajuste;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_contrato")
	private ContratoModel contratoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getIndice() { 
		return this.indice; 
	} 

	public void setIndice(BigDecimal indice) { 
		this.indice = indice; 
	} 

	public BigDecimal getValorAnterior() { 
		return this.valorAnterior; 
	} 

	public void setValorAnterior(BigDecimal valorAnterior) { 
		this.valorAnterior = valorAnterior; 
	} 

	public BigDecimal getValorAtual() { 
		return this.valorAtual; 
	} 

	public void setValorAtual(BigDecimal valorAtual) { 
		this.valorAtual = valorAtual; 
	} 

	public Date getDataReajuste() { 
		return this.dataReajuste; 
	} 

	public void setDataReajuste(Date dataReajuste) { 
		this.dataReajuste = dataReajuste; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public ContratoModel getContratoModel() { 
	return this.contratoModel; 
	} 

	public void setContratoModel(ContratoModel contratoModel) { 
	this.contratoModel = contratoModel; 
	} 

		
}