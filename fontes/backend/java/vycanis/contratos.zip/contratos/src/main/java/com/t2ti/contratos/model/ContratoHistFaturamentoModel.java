package com.t2ti.contratos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contrato_hist_faturamento")
@NamedQuery(name="ContratoHistFaturamentoModel.findAll", query="SELECT t FROM ContratoHistFaturamentoModel t")
public class ContratoHistFaturamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContratoHistFaturamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_fatura")
	private Date dataFatura;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_contrato")
	private ContratoModel contratoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataFatura() { 
		return this.dataFatura; 
	} 

	public void setDataFatura(Date dataFatura) { 
		this.dataFatura = dataFatura; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public ContratoModel getContratoModel() { 
	return this.contratoModel; 
	} 

	public void setContratoModel(ContratoModel contratoModel) { 
	this.contratoModel = contratoModel; 
	} 

		
}