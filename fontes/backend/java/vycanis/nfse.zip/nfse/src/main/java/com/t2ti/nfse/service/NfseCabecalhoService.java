package com.t2ti.nfse.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfse.util.Filter;
import com.t2ti.nfse.exception.GenericException;
import com.t2ti.nfse.model.NfseCabecalhoModel;
import com.t2ti.nfse.repository.NfseCabecalhoRepository;

@Service
public class NfseCabecalhoService {

	@Autowired
	private NfseCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfseCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfseCabecalhoModel> getList(Filter filter) {
		String sql = "select * from nfse_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfseCabecalhoModel.class);
		return query.getResultList();
	}

	public NfseCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfseCabecalhoModel save(NfseCabecalhoModel obj) {
		NfseCabecalhoModel nfseCabecalhoModel = repository.save(obj);
		return nfseCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfseCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfseCabecalho] - Exception: " + e.getMessage());
		}
	}

}