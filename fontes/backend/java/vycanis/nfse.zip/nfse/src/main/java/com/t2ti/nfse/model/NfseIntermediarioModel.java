package com.t2ti.nfse.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfse_intermediario")
@NamedQuery(name="NfseIntermediarioModel.findAll", query="SELECT t FROM NfseIntermediarioModel t")
public class NfseIntermediarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfseIntermediarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="inscricao_municipal")
	private String inscricaoMunicipal;

	@Column(name="razao")
	private String razao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfse_cabecalho")
	private NfseCabecalhoModel nfseCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getInscricaoMunicipal() { 
		return this.inscricaoMunicipal; 
	} 

	public void setInscricaoMunicipal(String inscricaoMunicipal) { 
		this.inscricaoMunicipal = inscricaoMunicipal; 
	} 

	public String getRazao() { 
		return this.razao; 
	} 

	public void setRazao(String razao) { 
		this.razao = razao; 
	} 

	public NfseCabecalhoModel getNfseCabecalhoModel() { 
	return this.nfseCabecalhoModel; 
	} 

	public void setNfseCabecalhoModel(NfseCabecalhoModel nfseCabecalhoModel) { 
	this.nfseCabecalhoModel = nfseCabecalhoModel; 
	} 

		
}