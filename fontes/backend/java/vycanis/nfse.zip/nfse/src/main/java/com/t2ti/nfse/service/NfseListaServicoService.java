package com.t2ti.nfse.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfse.util.Filter;
import com.t2ti.nfse.exception.GenericException;
import com.t2ti.nfse.model.NfseListaServicoModel;
import com.t2ti.nfse.repository.NfseListaServicoRepository;

@Service
public class NfseListaServicoService {

	@Autowired
	private NfseListaServicoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfseListaServicoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfseListaServicoModel> getList(Filter filter) {
		String sql = "select * from nfse_lista_servico where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfseListaServicoModel.class);
		return query.getResultList();
	}

	public NfseListaServicoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfseListaServicoModel save(NfseListaServicoModel obj) {
		NfseListaServicoModel nfseListaServicoModel = repository.save(obj);
		return nfseListaServicoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfseListaServicoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfseListaServico] - Exception: " + e.getMessage());
		}
	}

}