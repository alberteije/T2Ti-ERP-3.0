/*******************************************************************************
Title: T2Ti ERP 3.0
Description: Configuração do DataSource no Spring para usar o TenantRoutingDataSource.
                                                                                
The MIT License                                                                 
                                                                                
Copyright: Copyright (C) 2024 T2Ti.COM                                          
                                                                                
Permission is hereby granted, free of charge, to any person                     
obtaining a copy of this software and associated documentation                  
files (the "Software"), to deal in the Software without                         
restriction, including without limitation the rights to use,                    
copy, modify, merge, publish, distribute, sublicense, and/or sell               
copies of the Software, and to permit persons to whom the                       
Software is furnished to do so, subject to the following                        
conditions:                                                                     
                                                                                
The above copyright notice and this permission notice shall be                  
included in all copies or substantial portions of the Software.                 
                                                                                
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,                 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES                 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND                        
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT                     
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,                    
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING                    
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR                   
OTHER DEALINGS IN THE SOFTWARE.                                                 
                                                                                
       The author may be contacted at:                                          
           t2ti.com@gmail.com                                                   
                                                                                
@author Albert Eije (alberteije@gmail.com)                    
@version 1.0.0
*******************************************************************************/
package com.t2ti.nfse.config;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class DataSourceConfig {

    @SuppressWarnings("unchecked")
	@Bean
    public DataSource dataSource() throws IOException {
        TenantRoutingDataSource dataSource = new TenantRoutingDataSource();
        Map<Object, Object> dataSourceMap = new HashMap<>();

        // Carregar dados do arquivo JSON
        File jsonFile = new File("C:\\T2Ti\\json\\datasources_java.json");
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Map<String, String>> jsonData = objectMapper.readValue(jsonFile, Map.class);

        for (Map.Entry<String, Map<String, String>> entry : jsonData.entrySet()) {
            String tenantId = entry.getKey();
            Map<String, String> dataSourceProps = entry.getValue();

            DataSourceBuilder<?> dataSourceBuilder = DataSourceBuilder.create()
                    .url(dataSourceProps.get("url"))
                    .username(dataSourceProps.get("username"))
                    .password(dataSourceProps.get("password"));

            dataSourceMap.put(tenantId, dataSourceBuilder.build());
        }
        // Configura o DataSource padrão ou de fallback
        dataSource.setDefaultTargetDataSource(dataSourceMap.get("fenix")); // Ajuste conforme necessário
        dataSource.setTargetDataSources(dataSourceMap);
        return dataSource;
    }
}