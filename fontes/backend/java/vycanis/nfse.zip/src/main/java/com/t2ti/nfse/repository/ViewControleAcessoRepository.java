package com.t2ti.nfse.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.nfse.model.ViewControleAcessoModel;

public interface ViewControleAcessoRepository extends JpaRepository<ViewControleAcessoModel, Integer> {}