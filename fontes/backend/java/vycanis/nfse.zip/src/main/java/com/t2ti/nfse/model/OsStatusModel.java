package com.t2ti.nfse.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="os_status")
@NamedQuery(name="OsStatusModel.findAll", query="SELECT t FROM OsStatusModel t")
public class OsStatusModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OsStatusModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@OneToMany(mappedBy = "osStatusModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<OsAberturaModel> osAberturaModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Set<OsAberturaModel> getOsAberturaModelList() { 
	return this.osAberturaModelList; 
	} 

	public void setOsAberturaModelList(Set<OsAberturaModel> osAberturaModelList) { 
	this.osAberturaModelList = osAberturaModelList; 
		for (OsAberturaModel osAberturaModel : osAberturaModelList) { 
			osAberturaModel.setOsStatusModel(this); 
		}
	} 

		
}