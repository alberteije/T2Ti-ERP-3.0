package com.t2ti.nfse.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfse_cabecalho")
@NamedQuery(name="NfseCabecalhoModel.findAll", query="SELECT t FROM NfseCabecalhoModel t")
public class NfseCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfseCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Column(name="codigo_verificacao")
	private String codigoVerificacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_emissao")
	private Date dataHoraEmissao;

	@Column(name="competencia")
	private String competencia;

	@Column(name="numero_substituida")
	private String numeroSubstituida;

	@Column(name="natureza_operacao")
	private String naturezaOperacao;

	@Column(name="regime_especial_tributacao")
	private String regimeEspecialTributacao;

	@Column(name="optante_simples_nacional")
	private String optanteSimplesNacional;

	@Column(name="incentivador_cultural")
	private String incentivadorCultural;

	@Column(name="numero_rps")
	private String numeroRps;

	@Column(name="serie_rps")
	private String serieRps;

	@Column(name="tipo_rps")
	private String tipoRps;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao_rps")
	private Date dataEmissaoRps;

	@Column(name="outras_informacoes")
	private String outrasInformacoes;

	@OneToMany(mappedBy = "nfseCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfseDetalheModel> nfseDetalheModelList; 

	@OneToMany(mappedBy = "nfseCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfseIntermediarioModel> nfseIntermediarioModelList; 

	@ManyToOne 
	@JoinColumn(name="id_cliente")
	private ViewPessoaClienteModel viewPessoaClienteModel; 

	@ManyToOne 
	@JoinColumn(name="id_os_abertura")
	private OsAberturaModel osAberturaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getCodigoVerificacao() { 
		return this.codigoVerificacao; 
	} 

	public void setCodigoVerificacao(String codigoVerificacao) { 
		this.codigoVerificacao = codigoVerificacao; 
	} 

	public Date getDataHoraEmissao() { 
		return this.dataHoraEmissao; 
	} 

	public void setDataHoraEmissao(Date dataHoraEmissao) { 
		this.dataHoraEmissao = dataHoraEmissao; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public String getNumeroSubstituida() { 
		return this.numeroSubstituida; 
	} 

	public void setNumeroSubstituida(String numeroSubstituida) { 
		this.numeroSubstituida = numeroSubstituida; 
	} 

	public String getNaturezaOperacao() { 
		return this.naturezaOperacao; 
	} 

	public void setNaturezaOperacao(String naturezaOperacao) { 
		this.naturezaOperacao = naturezaOperacao; 
	} 

	public String getRegimeEspecialTributacao() { 
		return this.regimeEspecialTributacao; 
	} 

	public void setRegimeEspecialTributacao(String regimeEspecialTributacao) { 
		this.regimeEspecialTributacao = regimeEspecialTributacao; 
	} 

	public String getOptanteSimplesNacional() { 
		return this.optanteSimplesNacional; 
	} 

	public void setOptanteSimplesNacional(String optanteSimplesNacional) { 
		this.optanteSimplesNacional = optanteSimplesNacional; 
	} 

	public String getIncentivadorCultural() { 
		return this.incentivadorCultural; 
	} 

	public void setIncentivadorCultural(String incentivadorCultural) { 
		this.incentivadorCultural = incentivadorCultural; 
	} 

	public String getNumeroRps() { 
		return this.numeroRps; 
	} 

	public void setNumeroRps(String numeroRps) { 
		this.numeroRps = numeroRps; 
	} 

	public String getSerieRps() { 
		return this.serieRps; 
	} 

	public void setSerieRps(String serieRps) { 
		this.serieRps = serieRps; 
	} 

	public String getTipoRps() { 
		return this.tipoRps; 
	} 

	public void setTipoRps(String tipoRps) { 
		this.tipoRps = tipoRps; 
	} 

	public Date getDataEmissaoRps() { 
		return this.dataEmissaoRps; 
	} 

	public void setDataEmissaoRps(Date dataEmissaoRps) { 
		this.dataEmissaoRps = dataEmissaoRps; 
	} 

	public String getOutrasInformacoes() { 
		return this.outrasInformacoes; 
	} 

	public void setOutrasInformacoes(String outrasInformacoes) { 
		this.outrasInformacoes = outrasInformacoes; 
	} 

	public Set<NfseDetalheModel> getNfseDetalheModelList() { 
	return this.nfseDetalheModelList; 
	} 

	public void setNfseDetalheModelList(Set<NfseDetalheModel> nfseDetalheModelList) { 
	this.nfseDetalheModelList = nfseDetalheModelList; 
		for (NfseDetalheModel nfseDetalheModel : nfseDetalheModelList) { 
			nfseDetalheModel.setNfseCabecalhoModel(this); 
		}
	} 

	public Set<NfseIntermediarioModel> getNfseIntermediarioModelList() { 
	return this.nfseIntermediarioModelList; 
	} 

	public void setNfseIntermediarioModelList(Set<NfseIntermediarioModel> nfseIntermediarioModelList) { 
	this.nfseIntermediarioModelList = nfseIntermediarioModelList; 
		for (NfseIntermediarioModel nfseIntermediarioModel : nfseIntermediarioModelList) { 
			nfseIntermediarioModel.setNfseCabecalhoModel(this); 
		}
	} 

	public ViewPessoaClienteModel getViewPessoaClienteModel() { 
	return this.viewPessoaClienteModel; 
	} 

	public void setViewPessoaClienteModel(ViewPessoaClienteModel viewPessoaClienteModel) { 
	this.viewPessoaClienteModel = viewPessoaClienteModel; 
	} 

	public OsAberturaModel getOsAberturaModel() { 
	return this.osAberturaModel; 
	} 

	public void setOsAberturaModel(OsAberturaModel osAberturaModel) { 
	this.osAberturaModel = osAberturaModel; 
	} 

		
}