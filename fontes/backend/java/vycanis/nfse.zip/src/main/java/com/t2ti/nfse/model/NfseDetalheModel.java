package com.t2ti.nfse.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfse_detalhe")
@NamedQuery(name="NfseDetalheModel.findAll", query="SELECT t FROM NfseDetalheModel t")
public class NfseDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfseDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_cnae")
	private String codigoCnae;

	@Column(name="codigo_tributacao_municipio")
	private String codigoTributacaoMunicipio;

	@Column(name="valor_servicos")
	private BigDecimal valorServicos;

	@Column(name="valor_deducoes")
	private BigDecimal valorDeducoes;

	@Column(name="valor_pis")
	private BigDecimal valorPis;

	@Column(name="valor_cofins")
	private BigDecimal valorCofins;

	@Column(name="valor_inss")
	private BigDecimal valorInss;

	@Column(name="valor_ir")
	private BigDecimal valorIr;

	@Column(name="valor_csll")
	private BigDecimal valorCsll;

	@Column(name="valor_base_calculo")
	private BigDecimal valorBaseCalculo;

	@Column(name="aliquota")
	private BigDecimal aliquota;

	@Column(name="valor_iss")
	private BigDecimal valorIss;

	@Column(name="valor_liquido")
	private BigDecimal valorLiquido;

	@Column(name="outras_retencoes")
	private BigDecimal outrasRetencoes;

	@Column(name="valor_credito")
	private BigDecimal valorCredito;

	@Column(name="iss_retido")
	private String issRetido;

	@Column(name="valor_iss_retido")
	private BigDecimal valorIssRetido;

	@Column(name="valor_desconto_condicionado")
	private BigDecimal valorDescontoCondicionado;

	@Column(name="valor_desconto_incondicionado")
	private BigDecimal valorDescontoIncondicionado;

	@Column(name="municipio_prestacao")
	private Integer municipioPrestacao;

	@Column(name="discriminacao")
	private String discriminacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfse_cabecalho")
	private NfseCabecalhoModel nfseCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_nfse_lista_servico")
	private NfseListaServicoModel nfseListaServicoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoCnae() { 
		return this.codigoCnae; 
	} 

	public void setCodigoCnae(String codigoCnae) { 
		this.codigoCnae = codigoCnae; 
	} 

	public String getCodigoTributacaoMunicipio() { 
		return this.codigoTributacaoMunicipio; 
	} 

	public void setCodigoTributacaoMunicipio(String codigoTributacaoMunicipio) { 
		this.codigoTributacaoMunicipio = codigoTributacaoMunicipio; 
	} 

	public BigDecimal getValorServicos() { 
		return this.valorServicos; 
	} 

	public void setValorServicos(BigDecimal valorServicos) { 
		this.valorServicos = valorServicos; 
	} 

	public BigDecimal getValorDeducoes() { 
		return this.valorDeducoes; 
	} 

	public void setValorDeducoes(BigDecimal valorDeducoes) { 
		this.valorDeducoes = valorDeducoes; 
	} 

	public BigDecimal getValorPis() { 
		return this.valorPis; 
	} 

	public void setValorPis(BigDecimal valorPis) { 
		this.valorPis = valorPis; 
	} 

	public BigDecimal getValorCofins() { 
		return this.valorCofins; 
	} 

	public void setValorCofins(BigDecimal valorCofins) { 
		this.valorCofins = valorCofins; 
	} 

	public BigDecimal getValorInss() { 
		return this.valorInss; 
	} 

	public void setValorInss(BigDecimal valorInss) { 
		this.valorInss = valorInss; 
	} 

	public BigDecimal getValorIr() { 
		return this.valorIr; 
	} 

	public void setValorIr(BigDecimal valorIr) { 
		this.valorIr = valorIr; 
	} 

	public BigDecimal getValorCsll() { 
		return this.valorCsll; 
	} 

	public void setValorCsll(BigDecimal valorCsll) { 
		this.valorCsll = valorCsll; 
	} 

	public BigDecimal getValorBaseCalculo() { 
		return this.valorBaseCalculo; 
	} 

	public void setValorBaseCalculo(BigDecimal valorBaseCalculo) { 
		this.valorBaseCalculo = valorBaseCalculo; 
	} 

	public BigDecimal getAliquota() { 
		return this.aliquota; 
	} 

	public void setAliquota(BigDecimal aliquota) { 
		this.aliquota = aliquota; 
	} 

	public BigDecimal getValorIss() { 
		return this.valorIss; 
	} 

	public void setValorIss(BigDecimal valorIss) { 
		this.valorIss = valorIss; 
	} 

	public BigDecimal getValorLiquido() { 
		return this.valorLiquido; 
	} 

	public void setValorLiquido(BigDecimal valorLiquido) { 
		this.valorLiquido = valorLiquido; 
	} 

	public BigDecimal getOutrasRetencoes() { 
		return this.outrasRetencoes; 
	} 

	public void setOutrasRetencoes(BigDecimal outrasRetencoes) { 
		this.outrasRetencoes = outrasRetencoes; 
	} 

	public BigDecimal getValorCredito() { 
		return this.valorCredito; 
	} 

	public void setValorCredito(BigDecimal valorCredito) { 
		this.valorCredito = valorCredito; 
	} 

	public String getIssRetido() { 
		return this.issRetido; 
	} 

	public void setIssRetido(String issRetido) { 
		this.issRetido = issRetido; 
	} 

	public BigDecimal getValorIssRetido() { 
		return this.valorIssRetido; 
	} 

	public void setValorIssRetido(BigDecimal valorIssRetido) { 
		this.valorIssRetido = valorIssRetido; 
	} 

	public BigDecimal getValorDescontoCondicionado() { 
		return this.valorDescontoCondicionado; 
	} 

	public void setValorDescontoCondicionado(BigDecimal valorDescontoCondicionado) { 
		this.valorDescontoCondicionado = valorDescontoCondicionado; 
	} 

	public BigDecimal getValorDescontoIncondicionado() { 
		return this.valorDescontoIncondicionado; 
	} 

	public void setValorDescontoIncondicionado(BigDecimal valorDescontoIncondicionado) { 
		this.valorDescontoIncondicionado = valorDescontoIncondicionado; 
	} 

	public Integer getMunicipioPrestacao() { 
		return this.municipioPrestacao; 
	} 

	public void setMunicipioPrestacao(Integer municipioPrestacao) { 
		this.municipioPrestacao = municipioPrestacao; 
	} 

	public String getDiscriminacao() { 
		return this.discriminacao; 
	} 

	public void setDiscriminacao(String discriminacao) { 
		this.discriminacao = discriminacao; 
	} 

	public NfseCabecalhoModel getNfseCabecalhoModel() { 
	return this.nfseCabecalhoModel; 
	} 

	public void setNfseCabecalhoModel(NfseCabecalhoModel nfseCabecalhoModel) { 
	this.nfseCabecalhoModel = nfseCabecalhoModel; 
	} 

	public NfseListaServicoModel getNfseListaServicoModel() { 
	return this.nfseListaServicoModel; 
	} 

	public void setNfseListaServicoModel(NfseListaServicoModel nfseListaServicoModel) { 
	this.nfseListaServicoModel = nfseListaServicoModel; 
	} 

		
}