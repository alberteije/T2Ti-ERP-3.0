package com.t2ti.nfse.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfse.util.Filter;
import com.t2ti.nfse.exception.GenericException;
import com.t2ti.nfse.model.OsStatusModel;
import com.t2ti.nfse.repository.OsStatusRepository;

@Service
public class OsStatusService {

	@Autowired
	private OsStatusRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<OsStatusModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<OsStatusModel> getList(Filter filter) {
		String sql = "select * from os_status where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, OsStatusModel.class);
		return query.getResultList();
	}

	public OsStatusModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public OsStatusModel save(OsStatusModel obj) {
		OsStatusModel osStatusModel = repository.save(obj);
		return osStatusModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		OsStatusModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete OsStatus] - Exception: " + e.getMessage());
		}
	}

}