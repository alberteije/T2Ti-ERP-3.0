package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_horario_autorizado")
@NamedQuery(name="PontoHorarioAutorizadoModel.findAll", query="SELECT t FROM PontoHorarioAutorizadoModel t")
public class PontoHorarioAutorizadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoHorarioAutorizadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_horario")
	private Date dataHorario;

	@Column(name="tipo")
	private String tipo;

	@Column(name="carga_horaria")
	private String cargaHoraria;

	@Column(name="entrada01")
	private String entrada01;

	@Column(name="saida01")
	private String saida01;

	@Column(name="entrada02")
	private String entrada02;

	@Column(name="saida02")
	private String saida02;

	@Column(name="entrada03")
	private String entrada03;

	@Column(name="saida03")
	private String saida03;

	@Column(name="entrada04")
	private String entrada04;

	@Column(name="saida04")
	private String saida04;

	@Column(name="entrada05")
	private String entrada05;

	@Column(name="saida05")
	private String saida05;

	@Column(name="hora_fechamento_dia")
	private String horaFechamentoDia;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataHorario() { 
		return this.dataHorario; 
	} 

	public void setDataHorario(Date dataHorario) { 
		this.dataHorario = dataHorario; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getCargaHoraria() { 
		return this.cargaHoraria; 
	} 

	public void setCargaHoraria(String cargaHoraria) { 
		this.cargaHoraria = cargaHoraria; 
	} 

	public String getEntrada01() { 
		return this.entrada01; 
	} 

	public void setEntrada01(String entrada01) { 
		this.entrada01 = entrada01; 
	} 

	public String getSaida01() { 
		return this.saida01; 
	} 

	public void setSaida01(String saida01) { 
		this.saida01 = saida01; 
	} 

	public String getEntrada02() { 
		return this.entrada02; 
	} 

	public void setEntrada02(String entrada02) { 
		this.entrada02 = entrada02; 
	} 

	public String getSaida02() { 
		return this.saida02; 
	} 

	public void setSaida02(String saida02) { 
		this.saida02 = saida02; 
	} 

	public String getEntrada03() { 
		return this.entrada03; 
	} 

	public void setEntrada03(String entrada03) { 
		this.entrada03 = entrada03; 
	} 

	public String getSaida03() { 
		return this.saida03; 
	} 

	public void setSaida03(String saida03) { 
		this.saida03 = saida03; 
	} 

	public String getEntrada04() { 
		return this.entrada04; 
	} 

	public void setEntrada04(String entrada04) { 
		this.entrada04 = entrada04; 
	} 

	public String getSaida04() { 
		return this.saida04; 
	} 

	public void setSaida04(String saida04) { 
		this.saida04 = saida04; 
	} 

	public String getEntrada05() { 
		return this.entrada05; 
	} 

	public void setEntrada05(String entrada05) { 
		this.entrada05 = entrada05; 
	} 

	public String getSaida05() { 
		return this.saida05; 
	} 

	public void setSaida05(String saida05) { 
		this.saida05 = saida05; 
	} 

	public String getHoraFechamentoDia() { 
		return this.horaFechamentoDia; 
	} 

	public void setHoraFechamentoDia(String horaFechamentoDia) { 
		this.horaFechamentoDia = horaFechamentoDia; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}