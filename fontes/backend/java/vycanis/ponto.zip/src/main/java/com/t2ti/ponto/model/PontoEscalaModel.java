package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="ponto_escala")
@NamedQuery(name="PontoEscalaModel.findAll", query="SELECT t FROM PontoEscalaModel t")
public class PontoEscalaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoEscalaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="desconto_hora_dia")
	private String descontoHoraDia;

	@Column(name="desconto_dsr")
	private String descontoDsr;

	@Column(name="codigo_horario_domingo")
	private String codigoHorarioDomingo;

	@Column(name="codigo_horario_segunda")
	private String codigoHorarioSegunda;

	@Column(name="codigo_horario_terca")
	private String codigoHorarioTerca;

	@Column(name="codigo_horario_quarta")
	private String codigoHorarioQuarta;

	@Column(name="codigo_horario_quinta")
	private String codigoHorarioQuinta;

	@Column(name="codigo_horario_sexta")
	private String codigoHorarioSexta;

	@Column(name="codigo_horario_sabado")
	private String codigoHorarioSabado;

	@OneToMany(mappedBy = "pontoEscalaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PontoTurmaModel> pontoTurmaModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescontoHoraDia() { 
		return this.descontoHoraDia; 
	} 

	public void setDescontoHoraDia(String descontoHoraDia) { 
		this.descontoHoraDia = descontoHoraDia; 
	} 

	public String getDescontoDsr() { 
		return this.descontoDsr; 
	} 

	public void setDescontoDsr(String descontoDsr) { 
		this.descontoDsr = descontoDsr; 
	} 

	public String getCodigoHorarioDomingo() { 
		return this.codigoHorarioDomingo; 
	} 

	public void setCodigoHorarioDomingo(String codigoHorarioDomingo) { 
		this.codigoHorarioDomingo = codigoHorarioDomingo; 
	} 

	public String getCodigoHorarioSegunda() { 
		return this.codigoHorarioSegunda; 
	} 

	public void setCodigoHorarioSegunda(String codigoHorarioSegunda) { 
		this.codigoHorarioSegunda = codigoHorarioSegunda; 
	} 

	public String getCodigoHorarioTerca() { 
		return this.codigoHorarioTerca; 
	} 

	public void setCodigoHorarioTerca(String codigoHorarioTerca) { 
		this.codigoHorarioTerca = codigoHorarioTerca; 
	} 

	public String getCodigoHorarioQuarta() { 
		return this.codigoHorarioQuarta; 
	} 

	public void setCodigoHorarioQuarta(String codigoHorarioQuarta) { 
		this.codigoHorarioQuarta = codigoHorarioQuarta; 
	} 

	public String getCodigoHorarioQuinta() { 
		return this.codigoHorarioQuinta; 
	} 

	public void setCodigoHorarioQuinta(String codigoHorarioQuinta) { 
		this.codigoHorarioQuinta = codigoHorarioQuinta; 
	} 

	public String getCodigoHorarioSexta() { 
		return this.codigoHorarioSexta; 
	} 

	public void setCodigoHorarioSexta(String codigoHorarioSexta) { 
		this.codigoHorarioSexta = codigoHorarioSexta; 
	} 

	public String getCodigoHorarioSabado() { 
		return this.codigoHorarioSabado; 
	} 

	public void setCodigoHorarioSabado(String codigoHorarioSabado) { 
		this.codigoHorarioSabado = codigoHorarioSabado; 
	} 

	public Set<PontoTurmaModel> getPontoTurmaModelList() { 
	return this.pontoTurmaModelList; 
	} 

	public void setPontoTurmaModelList(Set<PontoTurmaModel> pontoTurmaModelList) { 
	this.pontoTurmaModelList = pontoTurmaModelList; 
		for (PontoTurmaModel pontoTurmaModel : pontoTurmaModelList) { 
			pontoTurmaModel.setPontoEscalaModel(this); 
		}
	} 

		
}