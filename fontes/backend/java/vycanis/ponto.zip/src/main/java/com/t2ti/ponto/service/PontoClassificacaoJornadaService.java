package com.t2ti.ponto.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.model.PontoClassificacaoJornadaModel;
import com.t2ti.ponto.repository.PontoClassificacaoJornadaRepository;

@Service
public class PontoClassificacaoJornadaService {

	@Autowired
	private PontoClassificacaoJornadaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PontoClassificacaoJornadaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PontoClassificacaoJornadaModel> getList(Filter filter) {
		String sql = "select * from ponto_classificacao_jornada where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PontoClassificacaoJornadaModel.class);
		return query.getResultList();
	}

	public PontoClassificacaoJornadaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PontoClassificacaoJornadaModel save(PontoClassificacaoJornadaModel obj) {
		PontoClassificacaoJornadaModel pontoClassificacaoJornadaModel = repository.save(obj);
		return pontoClassificacaoJornadaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PontoClassificacaoJornadaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoClassificacaoJornada] - Exception: " + e.getMessage());
		}
	}

}