package com.t2ti.ponto.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.model.PontoFechamentoJornadaModel;
import com.t2ti.ponto.repository.PontoFechamentoJornadaRepository;

@Service
public class PontoFechamentoJornadaService {

	@Autowired
	private PontoFechamentoJornadaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PontoFechamentoJornadaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PontoFechamentoJornadaModel> getList(Filter filter) {
		String sql = "select * from ponto_fechamento_jornada where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PontoFechamentoJornadaModel.class);
		return query.getResultList();
	}

	public PontoFechamentoJornadaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PontoFechamentoJornadaModel save(PontoFechamentoJornadaModel obj) {
		PontoFechamentoJornadaModel pontoFechamentoJornadaModel = repository.save(obj);
		return pontoFechamentoJornadaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PontoFechamentoJornadaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoFechamentoJornada] - Exception: " + e.getMessage());
		}
	}

}