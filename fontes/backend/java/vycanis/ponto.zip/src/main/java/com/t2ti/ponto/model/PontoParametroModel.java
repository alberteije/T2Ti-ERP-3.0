package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="ponto_parametro")
@NamedQuery(name="PontoParametroModel.findAll", query="SELECT t FROM PontoParametroModel t")
public class PontoParametroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoParametroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="mes_ano")
	private String mesAno;

	@Column(name="dia_inicial_apuracao")
	private Integer diaInicialApuracao;

	@Column(name="hora_noturna_inicio")
	private String horaNoturnaInicio;

	@Column(name="hora_noturna_fim")
	private String horaNoturnaFim;

	@Column(name="periodo_minimo_interjornada")
	private String periodoMinimoInterjornada;

	@Column(name="percentual_he_diurna")
	private BigDecimal percentualHeDiurna;

	@Column(name="percentual_he_noturna")
	private BigDecimal percentualHeNoturna;

	@Column(name="duracao_hora_noturna")
	private String duracaoHoraNoturna;

	@Column(name="tratamento_hora_mais")
	private String tratamentoHoraMais;

	@Column(name="tratamento_hora_menos")
	private String tratamentoHoraMenos;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getMesAno() { 
		return this.mesAno; 
	} 

	public void setMesAno(String mesAno) { 
		this.mesAno = mesAno; 
	} 

	public Integer getDiaInicialApuracao() { 
		return this.diaInicialApuracao; 
	} 

	public void setDiaInicialApuracao(Integer diaInicialApuracao) { 
		this.diaInicialApuracao = diaInicialApuracao; 
	} 

	public String getHoraNoturnaInicio() { 
		return this.horaNoturnaInicio; 
	} 

	public void setHoraNoturnaInicio(String horaNoturnaInicio) { 
		this.horaNoturnaInicio = horaNoturnaInicio; 
	} 

	public String getHoraNoturnaFim() { 
		return this.horaNoturnaFim; 
	} 

	public void setHoraNoturnaFim(String horaNoturnaFim) { 
		this.horaNoturnaFim = horaNoturnaFim; 
	} 

	public String getPeriodoMinimoInterjornada() { 
		return this.periodoMinimoInterjornada; 
	} 

	public void setPeriodoMinimoInterjornada(String periodoMinimoInterjornada) { 
		this.periodoMinimoInterjornada = periodoMinimoInterjornada; 
	} 

	public BigDecimal getPercentualHeDiurna() { 
		return this.percentualHeDiurna; 
	} 

	public void setPercentualHeDiurna(BigDecimal percentualHeDiurna) { 
		this.percentualHeDiurna = percentualHeDiurna; 
	} 

	public BigDecimal getPercentualHeNoturna() { 
		return this.percentualHeNoturna; 
	} 

	public void setPercentualHeNoturna(BigDecimal percentualHeNoturna) { 
		this.percentualHeNoturna = percentualHeNoturna; 
	} 

	public String getDuracaoHoraNoturna() { 
		return this.duracaoHoraNoturna; 
	} 

	public void setDuracaoHoraNoturna(String duracaoHoraNoturna) { 
		this.duracaoHoraNoturna = duracaoHoraNoturna; 
	} 

	public String getTratamentoHoraMais() { 
		return this.tratamentoHoraMais; 
	} 

	public void setTratamentoHoraMais(String tratamentoHoraMais) { 
		this.tratamentoHoraMais = tratamentoHoraMais; 
	} 

	public String getTratamentoHoraMenos() { 
		return this.tratamentoHoraMenos; 
	} 

	public void setTratamentoHoraMenos(String tratamentoHoraMenos) { 
		this.tratamentoHoraMenos = tratamentoHoraMenos; 
	} 

		
}