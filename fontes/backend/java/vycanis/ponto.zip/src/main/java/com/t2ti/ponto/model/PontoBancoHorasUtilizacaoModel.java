package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_banco_horas_utilizacao")
@NamedQuery(name="PontoBancoHorasUtilizacaoModel.findAll", query="SELECT t FROM PontoBancoHorasUtilizacaoModel t")
public class PontoBancoHorasUtilizacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoBancoHorasUtilizacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_utilizacao")
	private Date dataUtilizacao;

	@Column(name="quantidade_utilizada")
	private String quantidadeUtilizada;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_ponto_banco_horas")
	private PontoBancoHorasModel pontoBancoHorasModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataUtilizacao() { 
		return this.dataUtilizacao; 
	} 

	public void setDataUtilizacao(Date dataUtilizacao) { 
		this.dataUtilizacao = dataUtilizacao; 
	} 

	public String getQuantidadeUtilizada() { 
		return this.quantidadeUtilizada; 
	} 

	public void setQuantidadeUtilizada(String quantidadeUtilizada) { 
		this.quantidadeUtilizada = quantidadeUtilizada; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public PontoBancoHorasModel getPontoBancoHorasModel() { 
	return this.pontoBancoHorasModel; 
	} 

	public void setPontoBancoHorasModel(PontoBancoHorasModel pontoBancoHorasModel) { 
	this.pontoBancoHorasModel = pontoBancoHorasModel; 
	} 

		
}