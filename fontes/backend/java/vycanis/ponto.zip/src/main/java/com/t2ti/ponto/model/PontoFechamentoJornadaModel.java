package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_fechamento_jornada")
@NamedQuery(name="PontoFechamentoJornadaModel.findAll", query="SELECT t FROM PontoFechamentoJornadaModel t")
public class PontoFechamentoJornadaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoFechamentoJornadaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_fechamento")
	private Date dataFechamento;

	@Column(name="dia_semana")
	private String diaSemana;

	@Column(name="codigo_horario")
	private String codigoHorario;

	@Column(name="carga_horaria_esperada")
	private String cargaHorariaEsperada;

	@Column(name="carga_horaria_diurna")
	private String cargaHorariaDiurna;

	@Column(name="carga_horaria_noturna")
	private String cargaHorariaNoturna;

	@Column(name="carga_horaria_total")
	private String cargaHorariaTotal;

	@Column(name="entrada01")
	private String entrada01;

	@Column(name="saida01")
	private String saida01;

	@Column(name="entrada02")
	private String entrada02;

	@Column(name="saida02")
	private String saida02;

	@Column(name="entrada03")
	private String entrada03;

	@Column(name="saida03")
	private String saida03;

	@Column(name="entrada04")
	private String entrada04;

	@Column(name="saida04")
	private String saida04;

	@Column(name="entrada05")
	private String entrada05;

	@Column(name="saida05")
	private String saida05;

	@Column(name="hora_inicio_jornada")
	private String horaInicioJornada;

	@Column(name="hora_fim_jornada")
	private String horaFimJornada;

	@Column(name="hora_extra01")
	private String horaExtra01;

	@Column(name="percentual_hora_extra01")
	private BigDecimal percentualHoraExtra01;

	@Column(name="modalidade_hora_extra01")
	private String modalidadeHoraExtra01;

	@Column(name="hora_extra02")
	private String horaExtra02;

	@Column(name="percentual_hora_extra02")
	private BigDecimal percentualHoraExtra02;

	@Column(name="modalidade_hora_extra02")
	private String modalidadeHoraExtra02;

	@Column(name="hora_extra03")
	private String horaExtra03;

	@Column(name="percentual_hora_extra03")
	private BigDecimal percentualHoraExtra03;

	@Column(name="modalidade_hora_extra03")
	private String modalidadeHoraExtra03;

	@Column(name="hora_extra04")
	private String horaExtra04;

	@Column(name="percentual_hora_extra04")
	private BigDecimal percentualHoraExtra04;

	@Column(name="modalidade_hora_extra04")
	private String modalidadeHoraExtra04;

	@Column(name="falta_atraso")
	private String faltaAtraso;

	@Column(name="compensar")
	private String compensar;

	@Column(name="banco_horas")
	private String bancoHoras;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_ponto_classificacao_jornada")
	private PontoClassificacaoJornadaModel pontoClassificacaoJornadaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataFechamento() { 
		return this.dataFechamento; 
	} 

	public void setDataFechamento(Date dataFechamento) { 
		this.dataFechamento = dataFechamento; 
	} 

	public String getDiaSemana() { 
		return this.diaSemana; 
	} 

	public void setDiaSemana(String diaSemana) { 
		this.diaSemana = diaSemana; 
	} 

	public String getCodigoHorario() { 
		return this.codigoHorario; 
	} 

	public void setCodigoHorario(String codigoHorario) { 
		this.codigoHorario = codigoHorario; 
	} 

	public String getCargaHorariaEsperada() { 
		return this.cargaHorariaEsperada; 
	} 

	public void setCargaHorariaEsperada(String cargaHorariaEsperada) { 
		this.cargaHorariaEsperada = cargaHorariaEsperada; 
	} 

	public String getCargaHorariaDiurna() { 
		return this.cargaHorariaDiurna; 
	} 

	public void setCargaHorariaDiurna(String cargaHorariaDiurna) { 
		this.cargaHorariaDiurna = cargaHorariaDiurna; 
	} 

	public String getCargaHorariaNoturna() { 
		return this.cargaHorariaNoturna; 
	} 

	public void setCargaHorariaNoturna(String cargaHorariaNoturna) { 
		this.cargaHorariaNoturna = cargaHorariaNoturna; 
	} 

	public String getCargaHorariaTotal() { 
		return this.cargaHorariaTotal; 
	} 

	public void setCargaHorariaTotal(String cargaHorariaTotal) { 
		this.cargaHorariaTotal = cargaHorariaTotal; 
	} 

	public String getEntrada01() { 
		return this.entrada01; 
	} 

	public void setEntrada01(String entrada01) { 
		this.entrada01 = entrada01; 
	} 

	public String getSaida01() { 
		return this.saida01; 
	} 

	public void setSaida01(String saida01) { 
		this.saida01 = saida01; 
	} 

	public String getEntrada02() { 
		return this.entrada02; 
	} 

	public void setEntrada02(String entrada02) { 
		this.entrada02 = entrada02; 
	} 

	public String getSaida02() { 
		return this.saida02; 
	} 

	public void setSaida02(String saida02) { 
		this.saida02 = saida02; 
	} 

	public String getEntrada03() { 
		return this.entrada03; 
	} 

	public void setEntrada03(String entrada03) { 
		this.entrada03 = entrada03; 
	} 

	public String getSaida03() { 
		return this.saida03; 
	} 

	public void setSaida03(String saida03) { 
		this.saida03 = saida03; 
	} 

	public String getEntrada04() { 
		return this.entrada04; 
	} 

	public void setEntrada04(String entrada04) { 
		this.entrada04 = entrada04; 
	} 

	public String getSaida04() { 
		return this.saida04; 
	} 

	public void setSaida04(String saida04) { 
		this.saida04 = saida04; 
	} 

	public String getEntrada05() { 
		return this.entrada05; 
	} 

	public void setEntrada05(String entrada05) { 
		this.entrada05 = entrada05; 
	} 

	public String getSaida05() { 
		return this.saida05; 
	} 

	public void setSaida05(String saida05) { 
		this.saida05 = saida05; 
	} 

	public String getHoraInicioJornada() { 
		return this.horaInicioJornada; 
	} 

	public void setHoraInicioJornada(String horaInicioJornada) { 
		this.horaInicioJornada = horaInicioJornada; 
	} 

	public String getHoraFimJornada() { 
		return this.horaFimJornada; 
	} 

	public void setHoraFimJornada(String horaFimJornada) { 
		this.horaFimJornada = horaFimJornada; 
	} 

	public String getHoraExtra01() { 
		return this.horaExtra01; 
	} 

	public void setHoraExtra01(String horaExtra01) { 
		this.horaExtra01 = horaExtra01; 
	} 

	public BigDecimal getPercentualHoraExtra01() { 
		return this.percentualHoraExtra01; 
	} 

	public void setPercentualHoraExtra01(BigDecimal percentualHoraExtra01) { 
		this.percentualHoraExtra01 = percentualHoraExtra01; 
	} 

	public String getModalidadeHoraExtra01() { 
		return this.modalidadeHoraExtra01; 
	} 

	public void setModalidadeHoraExtra01(String modalidadeHoraExtra01) { 
		this.modalidadeHoraExtra01 = modalidadeHoraExtra01; 
	} 

	public String getHoraExtra02() { 
		return this.horaExtra02; 
	} 

	public void setHoraExtra02(String horaExtra02) { 
		this.horaExtra02 = horaExtra02; 
	} 

	public BigDecimal getPercentualHoraExtra02() { 
		return this.percentualHoraExtra02; 
	} 

	public void setPercentualHoraExtra02(BigDecimal percentualHoraExtra02) { 
		this.percentualHoraExtra02 = percentualHoraExtra02; 
	} 

	public String getModalidadeHoraExtra02() { 
		return this.modalidadeHoraExtra02; 
	} 

	public void setModalidadeHoraExtra02(String modalidadeHoraExtra02) { 
		this.modalidadeHoraExtra02 = modalidadeHoraExtra02; 
	} 

	public String getHoraExtra03() { 
		return this.horaExtra03; 
	} 

	public void setHoraExtra03(String horaExtra03) { 
		this.horaExtra03 = horaExtra03; 
	} 

	public BigDecimal getPercentualHoraExtra03() { 
		return this.percentualHoraExtra03; 
	} 

	public void setPercentualHoraExtra03(BigDecimal percentualHoraExtra03) { 
		this.percentualHoraExtra03 = percentualHoraExtra03; 
	} 

	public String getModalidadeHoraExtra03() { 
		return this.modalidadeHoraExtra03; 
	} 

	public void setModalidadeHoraExtra03(String modalidadeHoraExtra03) { 
		this.modalidadeHoraExtra03 = modalidadeHoraExtra03; 
	} 

	public String getHoraExtra04() { 
		return this.horaExtra04; 
	} 

	public void setHoraExtra04(String horaExtra04) { 
		this.horaExtra04 = horaExtra04; 
	} 

	public BigDecimal getPercentualHoraExtra04() { 
		return this.percentualHoraExtra04; 
	} 

	public void setPercentualHoraExtra04(BigDecimal percentualHoraExtra04) { 
		this.percentualHoraExtra04 = percentualHoraExtra04; 
	} 

	public String getModalidadeHoraExtra04() { 
		return this.modalidadeHoraExtra04; 
	} 

	public void setModalidadeHoraExtra04(String modalidadeHoraExtra04) { 
		this.modalidadeHoraExtra04 = modalidadeHoraExtra04; 
	} 

	public String getFaltaAtraso() { 
		return this.faltaAtraso; 
	} 

	public void setFaltaAtraso(String faltaAtraso) { 
		this.faltaAtraso = faltaAtraso; 
	} 

	public String getCompensar() { 
		return this.compensar; 
	} 

	public void setCompensar(String compensar) { 
		this.compensar = compensar; 
	} 

	public String getBancoHoras() { 
		return this.bancoHoras; 
	} 

	public void setBancoHoras(String bancoHoras) { 
		this.bancoHoras = bancoHoras; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public PontoClassificacaoJornadaModel getPontoClassificacaoJornadaModel() { 
	return this.pontoClassificacaoJornadaModel; 
	} 

	public void setPontoClassificacaoJornadaModel(PontoClassificacaoJornadaModel pontoClassificacaoJornadaModel) { 
	this.pontoClassificacaoJornadaModel = pontoClassificacaoJornadaModel; 
	} 

		
}