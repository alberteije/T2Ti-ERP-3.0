package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_turma")
@NamedQuery(name="PontoTurmaModel.findAll", query="SELECT t FROM PontoTurmaModel t")
public class PontoTurmaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoTurmaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_ponto_escala")
	private PontoEscalaModel pontoEscalaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public PontoEscalaModel getPontoEscalaModel() { 
	return this.pontoEscalaModel; 
	} 

	public void setPontoEscalaModel(PontoEscalaModel pontoEscalaModel) { 
	this.pontoEscalaModel = pontoEscalaModel; 
	} 

		
}