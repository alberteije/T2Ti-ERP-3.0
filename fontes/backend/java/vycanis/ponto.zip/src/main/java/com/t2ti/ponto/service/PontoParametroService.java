package com.t2ti.ponto.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.model.PontoParametroModel;
import com.t2ti.ponto.repository.PontoParametroRepository;

@Service
public class PontoParametroService {

	@Autowired
	private PontoParametroRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PontoParametroModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PontoParametroModel> getList(Filter filter) {
		String sql = "select * from ponto_parametro where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PontoParametroModel.class);
		return query.getResultList();
	}

	public PontoParametroModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PontoParametroModel save(PontoParametroModel obj) {
		PontoParametroModel pontoParametroModel = repository.save(obj);
		return pontoParametroModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PontoParametroModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoParametro] - Exception: " + e.getMessage());
		}
	}

}