package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="ponto_horario")
@NamedQuery(name="PontoHorarioModel.findAll", query="SELECT t FROM PontoHorarioModel t")
public class PontoHorarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoHorarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo")
	private String tipo;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@Column(name="tipo_trabalho")
	private String tipoTrabalho;

	@Column(name="carga_horaria")
	private String cargaHoraria;

	@Column(name="entrada01")
	private String entrada01;

	@Column(name="saida01")
	private String saida01;

	@Column(name="entrada02")
	private String entrada02;

	@Column(name="saida02")
	private String saida02;

	@Column(name="entrada03")
	private String entrada03;

	@Column(name="saida03")
	private String saida03;

	@Column(name="entrada04")
	private String entrada04;

	@Column(name="saida04")
	private String saida04;

	@Column(name="entrada05")
	private String entrada05;

	@Column(name="saida05")
	private String saida05;

	@Column(name="hora_inicio_jornada")
	private String horaInicioJornada;

	@Column(name="hora_fim_jornada")
	private String horaFimJornada;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getTipoTrabalho() { 
		return this.tipoTrabalho; 
	} 

	public void setTipoTrabalho(String tipoTrabalho) { 
		this.tipoTrabalho = tipoTrabalho; 
	} 

	public String getCargaHoraria() { 
		return this.cargaHoraria; 
	} 

	public void setCargaHoraria(String cargaHoraria) { 
		this.cargaHoraria = cargaHoraria; 
	} 

	public String getEntrada01() { 
		return this.entrada01; 
	} 

	public void setEntrada01(String entrada01) { 
		this.entrada01 = entrada01; 
	} 

	public String getSaida01() { 
		return this.saida01; 
	} 

	public void setSaida01(String saida01) { 
		this.saida01 = saida01; 
	} 

	public String getEntrada02() { 
		return this.entrada02; 
	} 

	public void setEntrada02(String entrada02) { 
		this.entrada02 = entrada02; 
	} 

	public String getSaida02() { 
		return this.saida02; 
	} 

	public void setSaida02(String saida02) { 
		this.saida02 = saida02; 
	} 

	public String getEntrada03() { 
		return this.entrada03; 
	} 

	public void setEntrada03(String entrada03) { 
		this.entrada03 = entrada03; 
	} 

	public String getSaida03() { 
		return this.saida03; 
	} 

	public void setSaida03(String saida03) { 
		this.saida03 = saida03; 
	} 

	public String getEntrada04() { 
		return this.entrada04; 
	} 

	public void setEntrada04(String entrada04) { 
		this.entrada04 = entrada04; 
	} 

	public String getSaida04() { 
		return this.saida04; 
	} 

	public void setSaida04(String saida04) { 
		this.saida04 = saida04; 
	} 

	public String getEntrada05() { 
		return this.entrada05; 
	} 

	public void setEntrada05(String entrada05) { 
		this.entrada05 = entrada05; 
	} 

	public String getSaida05() { 
		return this.saida05; 
	} 

	public void setSaida05(String saida05) { 
		this.saida05 = saida05; 
	} 

	public String getHoraInicioJornada() { 
		return this.horaInicioJornada; 
	} 

	public void setHoraInicioJornada(String horaInicioJornada) { 
		this.horaInicioJornada = horaInicioJornada; 
	} 

	public String getHoraFimJornada() { 
		return this.horaFimJornada; 
	} 

	public void setHoraFimJornada(String horaFimJornada) { 
		this.horaFimJornada = horaFimJornada; 
	} 

		
}