package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="ponto_relogio")
@NamedQuery(name="PontoRelogioModel.findAll", query="SELECT t FROM PontoRelogioModel t")
public class PontoRelogioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoRelogioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="localizacao")
	private String localizacao;

	@Column(name="marca")
	private String marca;

	@Column(name="fabricante")
	private String fabricante;

	@Column(name="numero_serie")
	private String numeroSerie;

	@Column(name="utilizacao")
	private String utilizacao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getLocalizacao() { 
		return this.localizacao; 
	} 

	public void setLocalizacao(String localizacao) { 
		this.localizacao = localizacao; 
	} 

	public String getMarca() { 
		return this.marca; 
	} 

	public void setMarca(String marca) { 
		this.marca = marca; 
	} 

	public String getFabricante() { 
		return this.fabricante; 
	} 

	public void setFabricante(String fabricante) { 
		this.fabricante = fabricante; 
	} 

	public String getNumeroSerie() { 
		return this.numeroSerie; 
	} 

	public void setNumeroSerie(String numeroSerie) { 
		this.numeroSerie = numeroSerie; 
	} 

	public String getUtilizacao() { 
		return this.utilizacao; 
	} 

	public void setUtilizacao(String utilizacao) { 
		this.utilizacao = utilizacao; 
	} 

		
}