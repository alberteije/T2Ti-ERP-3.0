package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_abono_utilizacao")
@NamedQuery(name="PontoAbonoUtilizacaoModel.findAll", query="SELECT t FROM PontoAbonoUtilizacaoModel t")
public class PontoAbonoUtilizacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoAbonoUtilizacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_utilizacao")
	private Date dataUtilizacao;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_ponto_abono")
	private PontoAbonoModel pontoAbonoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataUtilizacao() { 
		return this.dataUtilizacao; 
	} 

	public void setDataUtilizacao(Date dataUtilizacao) { 
		this.dataUtilizacao = dataUtilizacao; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public PontoAbonoModel getPontoAbonoModel() { 
	return this.pontoAbonoModel; 
	} 

	public void setPontoAbonoModel(PontoAbonoModel pontoAbonoModel) { 
	this.pontoAbonoModel = pontoAbonoModel; 
	} 

		
}