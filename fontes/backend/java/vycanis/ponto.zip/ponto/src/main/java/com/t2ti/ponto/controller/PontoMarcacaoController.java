package com.t2ti.ponto.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.exception.ResourseNotFoundException;
import com.t2ti.ponto.exception.BadRequestException;
import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.model.PontoMarcacaoModel;
import com.t2ti.ponto.service.PontoMarcacaoService;

@RestController
@RequestMapping(value = "/ponto-marcacao", produces = "application/json;charset=UTF-8")
public class PontoMarcacaoController {

	@Autowired
	private PontoMarcacaoService service;
	
	@GetMapping({ "", "/" })
	public List<PontoMarcacaoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [PontoMarcacao] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public PontoMarcacaoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found PontoMarcacao].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found PontoMarcacao] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public PontoMarcacaoModel insert(@RequestBody PontoMarcacaoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert PontoMarcacao] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public PontoMarcacaoModel update(@RequestBody PontoMarcacaoModel objJson) {	
		try {			
			PontoMarcacaoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update PontoMarcacao].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update PontoMarcacao] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoMarcacao] - Exception: " + e.getMessage());
		}
	}
	
}