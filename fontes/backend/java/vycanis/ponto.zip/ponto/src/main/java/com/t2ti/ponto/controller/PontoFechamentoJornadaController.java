package com.t2ti.ponto.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.exception.ResourseNotFoundException;
import com.t2ti.ponto.exception.BadRequestException;
import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.model.PontoFechamentoJornadaModel;
import com.t2ti.ponto.service.PontoFechamentoJornadaService;

@RestController
@RequestMapping(value = "/ponto-fechamento-jornada", produces = "application/json;charset=UTF-8")
public class PontoFechamentoJornadaController {

	@Autowired
	private PontoFechamentoJornadaService service;
	
	@GetMapping({ "", "/" })
	public List<PontoFechamentoJornadaModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [PontoFechamentoJornada] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public PontoFechamentoJornadaModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found PontoFechamentoJornada].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found PontoFechamentoJornada] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public PontoFechamentoJornadaModel insert(@RequestBody PontoFechamentoJornadaModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert PontoFechamentoJornada] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public PontoFechamentoJornadaModel update(@RequestBody PontoFechamentoJornadaModel objJson) {	
		try {			
			PontoFechamentoJornadaModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update PontoFechamentoJornada].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update PontoFechamentoJornada] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoFechamentoJornada] - Exception: " + e.getMessage());
		}
	}
	
}