package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_banco_horas")
@NamedQuery(name="PontoBancoHorasModel.findAll", query="SELECT t FROM PontoBancoHorasModel t")
public class PontoBancoHorasModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoBancoHorasModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_trabalho")
	private Date dataTrabalho;

	@Column(name="quantidade")
	private String quantidade;

	@Column(name="situacao")
	private String situacao;

	@OneToMany(mappedBy = "pontoBancoHorasModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PontoBancoHorasUtilizacaoModel> pontoBancoHorasUtilizacaoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataTrabalho() { 
		return this.dataTrabalho; 
	} 

	public void setDataTrabalho(Date dataTrabalho) { 
		this.dataTrabalho = dataTrabalho; 
	} 

	public String getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(String quantidade) { 
		this.quantidade = quantidade; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public Set<PontoBancoHorasUtilizacaoModel> getPontoBancoHorasUtilizacaoModelList() { 
	return this.pontoBancoHorasUtilizacaoModelList; 
	} 

	public void setPontoBancoHorasUtilizacaoModelList(Set<PontoBancoHorasUtilizacaoModel> pontoBancoHorasUtilizacaoModelList) { 
	this.pontoBancoHorasUtilizacaoModelList = pontoBancoHorasUtilizacaoModelList; 
		for (PontoBancoHorasUtilizacaoModel pontoBancoHorasUtilizacaoModel : pontoBancoHorasUtilizacaoModelList) { 
			pontoBancoHorasUtilizacaoModel.setPontoBancoHorasModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}