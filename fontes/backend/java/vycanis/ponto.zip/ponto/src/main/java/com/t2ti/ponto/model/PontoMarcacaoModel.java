package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_marcacao")
@NamedQuery(name="PontoMarcacaoModel.findAll", query="SELECT t FROM PontoMarcacaoModel t")
public class PontoMarcacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoMarcacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nsr")
	private Integer nsr;

	@Temporal(TemporalType.DATE)
@Column(name="data_marcacao")
	private Date dataMarcacao;

	@Column(name="hora_marcacao")
	private String horaMarcacao;

	@Column(name="tipo_marcacao")
	private String tipoMarcacao;

	@Column(name="tipo_registro")
	private String tipoRegistro;

	@Column(name="par_entrada_saida")
	private String parEntradaSaida;

	@Column(name="justificativa")
	private String justificativa;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_ponto_relogio")
	private PontoRelogioModel pontoRelogioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNsr() { 
		return this.nsr; 
	} 

	public void setNsr(Integer nsr) { 
		this.nsr = nsr; 
	} 

	public Date getDataMarcacao() { 
		return this.dataMarcacao; 
	} 

	public void setDataMarcacao(Date dataMarcacao) { 
		this.dataMarcacao = dataMarcacao; 
	} 

	public String getHoraMarcacao() { 
		return this.horaMarcacao; 
	} 

	public void setHoraMarcacao(String horaMarcacao) { 
		this.horaMarcacao = horaMarcacao; 
	} 

	public String getTipoMarcacao() { 
		return this.tipoMarcacao; 
	} 

	public void setTipoMarcacao(String tipoMarcacao) { 
		this.tipoMarcacao = tipoMarcacao; 
	} 

	public String getTipoRegistro() { 
		return this.tipoRegistro; 
	} 

	public void setTipoRegistro(String tipoRegistro) { 
		this.tipoRegistro = tipoRegistro; 
	} 

	public String getParEntradaSaida() { 
		return this.parEntradaSaida; 
	} 

	public void setParEntradaSaida(String parEntradaSaida) { 
		this.parEntradaSaida = parEntradaSaida; 
	} 

	public String getJustificativa() { 
		return this.justificativa; 
	} 

	public void setJustificativa(String justificativa) { 
		this.justificativa = justificativa; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public PontoRelogioModel getPontoRelogioModel() { 
	return this.pontoRelogioModel; 
	} 

	public void setPontoRelogioModel(PontoRelogioModel pontoRelogioModel) { 
	this.pontoRelogioModel = pontoRelogioModel; 
	} 

		
}