package com.t2ti.ponto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.ponto.model.PontoHorarioAutorizadoModel;

public interface PontoHorarioAutorizadoRepository extends JpaRepository<PontoHorarioAutorizadoModel, Integer> {}