package com.t2ti.ponto.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.model.PontoHorarioAutorizadoModel;
import com.t2ti.ponto.repository.PontoHorarioAutorizadoRepository;

@Service
public class PontoHorarioAutorizadoService {

	@Autowired
	private PontoHorarioAutorizadoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PontoHorarioAutorizadoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PontoHorarioAutorizadoModel> getList(Filter filter) {
		String sql = "select * from ponto_horario_autorizado where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PontoHorarioAutorizadoModel.class);
		return query.getResultList();
	}

	public PontoHorarioAutorizadoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PontoHorarioAutorizadoModel save(PontoHorarioAutorizadoModel obj) {
		PontoHorarioAutorizadoModel pontoHorarioAutorizadoModel = repository.save(obj);
		return pontoHorarioAutorizadoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PontoHorarioAutorizadoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoHorarioAutorizado] - Exception: " + e.getMessage());
		}
	}

}