package com.t2ti.ponto.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.model.PontoEscalaModel;
import com.t2ti.ponto.repository.PontoEscalaRepository;

@Service
public class PontoEscalaService {

	@Autowired
	private PontoEscalaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PontoEscalaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PontoEscalaModel> getList(Filter filter) {
		String sql = "select * from ponto_escala where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PontoEscalaModel.class);
		return query.getResultList();
	}

	public PontoEscalaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PontoEscalaModel save(PontoEscalaModel obj) {
		PontoEscalaModel pontoEscalaModel = repository.save(obj);
		return pontoEscalaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PontoEscalaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoEscala] - Exception: " + e.getMessage());
		}
	}

}