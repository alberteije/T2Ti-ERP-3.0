package com.t2ti.ponto.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ponto_abono")
@NamedQuery(name="PontoAbonoModel.findAll", query="SELECT t FROM PontoAbonoModel t")
public class PontoAbonoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PontoAbonoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private Integer quantidade;

	@Column(name="utilizado")
	private Integer utilizado;

	@Column(name="saldo")
	private Integer saldo;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
@Column(name="inicio_utilizacao")
	private Date inicioUtilizacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_validade")
	private Date dataValidade;

	@Column(name="observacao")
	private String observacao;

	@OneToMany(mappedBy = "pontoAbonoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PontoAbonoUtilizacaoModel> pontoAbonoUtilizacaoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public Integer getUtilizado() { 
		return this.utilizado; 
	} 

	public void setUtilizado(Integer utilizado) { 
		this.utilizado = utilizado; 
	} 

	public Integer getSaldo() { 
		return this.saldo; 
	} 

	public void setSaldo(Integer saldo) { 
		this.saldo = saldo; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public Date getInicioUtilizacao() { 
		return this.inicioUtilizacao; 
	} 

	public void setInicioUtilizacao(Date inicioUtilizacao) { 
		this.inicioUtilizacao = inicioUtilizacao; 
	} 

	public Date getDataValidade() { 
		return this.dataValidade; 
	} 

	public void setDataValidade(Date dataValidade) { 
		this.dataValidade = dataValidade; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Set<PontoAbonoUtilizacaoModel> getPontoAbonoUtilizacaoModelList() { 
	return this.pontoAbonoUtilizacaoModelList; 
	} 

	public void setPontoAbonoUtilizacaoModelList(Set<PontoAbonoUtilizacaoModel> pontoAbonoUtilizacaoModelList) { 
	this.pontoAbonoUtilizacaoModelList = pontoAbonoUtilizacaoModelList; 
		for (PontoAbonoUtilizacaoModel pontoAbonoUtilizacaoModel : pontoAbonoUtilizacaoModelList) { 
			pontoAbonoUtilizacaoModel.setPontoAbonoModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}