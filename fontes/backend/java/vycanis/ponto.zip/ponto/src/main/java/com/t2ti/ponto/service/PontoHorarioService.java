package com.t2ti.ponto.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.model.PontoHorarioModel;
import com.t2ti.ponto.repository.PontoHorarioRepository;

@Service
public class PontoHorarioService {

	@Autowired
	private PontoHorarioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PontoHorarioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PontoHorarioModel> getList(Filter filter) {
		String sql = "select * from ponto_horario where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PontoHorarioModel.class);
		return query.getResultList();
	}

	public PontoHorarioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PontoHorarioModel save(PontoHorarioModel obj) {
		PontoHorarioModel pontoHorarioModel = repository.save(obj);
		return pontoHorarioModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PontoHorarioModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoHorario] - Exception: " + e.getMessage());
		}
	}

}