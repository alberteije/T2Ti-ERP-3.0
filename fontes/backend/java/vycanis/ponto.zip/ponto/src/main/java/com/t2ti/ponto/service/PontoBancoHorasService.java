package com.t2ti.ponto.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ponto.util.Filter;
import com.t2ti.ponto.exception.GenericException;
import com.t2ti.ponto.model.PontoBancoHorasModel;
import com.t2ti.ponto.repository.PontoBancoHorasRepository;

@Service
public class PontoBancoHorasService {

	@Autowired
	private PontoBancoHorasRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PontoBancoHorasModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PontoBancoHorasModel> getList(Filter filter) {
		String sql = "select * from ponto_banco_horas where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PontoBancoHorasModel.class);
		return query.getResultList();
	}

	public PontoBancoHorasModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PontoBancoHorasModel save(PontoBancoHorasModel obj) {
		PontoBancoHorasModel pontoBancoHorasModel = repository.save(obj);
		return pontoBancoHorasModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PontoBancoHorasModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PontoBancoHoras] - Exception: " + e.getMessage());
		}
	}

}