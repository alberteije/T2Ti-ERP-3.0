package com.t2ti.ponto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.ponto.model.ViewPessoaUsuarioModel;

public interface ViewPessoaUsuarioRepository extends JpaRepository<ViewPessoaUsuarioModel, Integer> {}