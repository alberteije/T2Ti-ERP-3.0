package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_transporte")
@NamedQuery(name="NfeTransporteModel.findAll", query="SELECT t FROM NfeTransporteModel t")
public class NfeTransporteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeTransporteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_transportadora")
	private Integer idTransportadora;

	@Column(name="modalidade_frete")
	private String modalidadeFrete;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="cpf")
	private String cpf;

	@Column(name="nome")
	private String nome;

	@Column(name="inscricao_estadual")
	private String inscricaoEstadual;

	@Column(name="endereco")
	private String endereco;

	@Column(name="nome_municipio")
	private String nomeMunicipio;

	@Column(name="uf")
	private String uf;

	@Column(name="valor_servico")
	private BigDecimal valorServico;

	@Column(name="valor_bc_retencao_icms")
	private BigDecimal valorBcRetencaoIcms;

	@Column(name="aliquota_retencao_icms")
	private BigDecimal aliquotaRetencaoIcms;

	@Column(name="valor_icms_retido")
	private BigDecimal valorIcmsRetido;

	@Column(name="cfop")
	private Integer cfop;

	@Column(name="municipio")
	private Integer municipio;

	@Column(name="placa_veiculo")
	private String placaVeiculo;

	@Column(name="uf_veiculo")
	private String ufVeiculo;

	@Column(name="rntc_veiculo")
	private String rntcVeiculo;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdTransportadora() { 
		return this.idTransportadora; 
	} 

	public void setIdTransportadora(Integer idTransportadora) { 
		this.idTransportadora = idTransportadora; 
	} 

	public String getModalidadeFrete() { 
		return this.modalidadeFrete; 
	} 

	public void setModalidadeFrete(String modalidadeFrete) { 
		this.modalidadeFrete = modalidadeFrete; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getInscricaoEstadual() { 
		return this.inscricaoEstadual; 
	} 

	public void setInscricaoEstadual(String inscricaoEstadual) { 
		this.inscricaoEstadual = inscricaoEstadual; 
	} 

	public String getEndereco() { 
		return this.endereco; 
	} 

	public void setEndereco(String endereco) { 
		this.endereco = endereco; 
	} 

	public String getNomeMunicipio() { 
		return this.nomeMunicipio; 
	} 

	public void setNomeMunicipio(String nomeMunicipio) { 
		this.nomeMunicipio = nomeMunicipio; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public BigDecimal getValorServico() { 
		return this.valorServico; 
	} 

	public void setValorServico(BigDecimal valorServico) { 
		this.valorServico = valorServico; 
	} 

	public BigDecimal getValorBcRetencaoIcms() { 
		return this.valorBcRetencaoIcms; 
	} 

	public void setValorBcRetencaoIcms(BigDecimal valorBcRetencaoIcms) { 
		this.valorBcRetencaoIcms = valorBcRetencaoIcms; 
	} 

	public BigDecimal getAliquotaRetencaoIcms() { 
		return this.aliquotaRetencaoIcms; 
	} 

	public void setAliquotaRetencaoIcms(BigDecimal aliquotaRetencaoIcms) { 
		this.aliquotaRetencaoIcms = aliquotaRetencaoIcms; 
	} 

	public BigDecimal getValorIcmsRetido() { 
		return this.valorIcmsRetido; 
	} 

	public void setValorIcmsRetido(BigDecimal valorIcmsRetido) { 
		this.valorIcmsRetido = valorIcmsRetido; 
	} 

	public Integer getCfop() { 
		return this.cfop; 
	} 

	public void setCfop(Integer cfop) { 
		this.cfop = cfop; 
	} 

	public Integer getMunicipio() { 
		return this.municipio; 
	} 

	public void setMunicipio(Integer municipio) { 
		this.municipio = municipio; 
	} 

	public String getPlacaVeiculo() { 
		return this.placaVeiculo; 
	} 

	public void setPlacaVeiculo(String placaVeiculo) { 
		this.placaVeiculo = placaVeiculo; 
	} 

	public String getUfVeiculo() { 
		return this.ufVeiculo; 
	} 

	public void setUfVeiculo(String ufVeiculo) { 
		this.ufVeiculo = ufVeiculo; 
	} 

	public String getRntcVeiculo() { 
		return this.rntcVeiculo; 
	} 

	public void setRntcVeiculo(String rntcVeiculo) { 
		this.rntcVeiculo = rntcVeiculo; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}