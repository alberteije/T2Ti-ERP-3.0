package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_cana")
@NamedQuery(name="NfeCanaModel.findAll", query="SELECT t FROM NfeCanaModel t")
public class NfeCanaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeCanaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="safra")
	private String safra;

	@Column(name="mes_ano_referencia")
	private String mesAnoReferencia;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getSafra() { 
		return this.safra; 
	} 

	public void setSafra(String safra) { 
		this.safra = safra; 
	} 

	public String getMesAnoReferencia() { 
		return this.mesAnoReferencia; 
	} 

	public void setMesAnoReferencia(String mesAnoReferencia) { 
		this.mesAnoReferencia = mesAnoReferencia; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}