package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_acesso_xml")
@NamedQuery(name="NfeAcessoXmlModel.findAll", query="SELECT t FROM NfeAcessoXmlModel t")
public class NfeAcessoXmlModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeAcessoXmlModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="cpf")
	private String cpf;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}