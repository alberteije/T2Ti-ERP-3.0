package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_responsavel_tecnico")
@NamedQuery(name="NfeResponsavelTecnicoModel.findAll", query="SELECT t FROM NfeResponsavelTecnicoModel t")
public class NfeResponsavelTecnicoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeResponsavelTecnicoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="contato")
	private String contato;

	@Column(name="email")
	private String email;

	@Column(name="telefone")
	private String telefone;

	@Column(name="identificador_csrt")
	private String identificadorCsrt;

	@Column(name="hash_csrt")
	private String hashCsrt;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getContato() { 
		return this.contato; 
	} 

	public void setContato(String contato) { 
		this.contato = contato; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public String getTelefone() { 
		return this.telefone; 
	} 

	public void setTelefone(String telefone) { 
		this.telefone = telefone; 
	} 

	public String getIdentificadorCsrt() { 
		return this.identificadorCsrt; 
	} 

	public void setIdentificadorCsrt(String identificadorCsrt) { 
		this.identificadorCsrt = identificadorCsrt; 
	} 

	public String getHashCsrt() { 
		return this.hashCsrt; 
	} 

	public void setHashCsrt(String hashCsrt) { 
		this.hashCsrt = hashCsrt; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}