package com.t2ti.nfe.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.exception.ResourseNotFoundException;
import com.t2ti.nfe.exception.BadRequestException;
import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.model.NfeConfiguracaoModel;
import com.t2ti.nfe.service.NfeConfiguracaoService;

@RestController
@RequestMapping(value = "/nfe-configuracao", produces = "application/json;charset=UTF-8")
public class NfeConfiguracaoController {

	@Autowired
	private NfeConfiguracaoService service;
	
	@GetMapping({ "", "/" })
	public List<NfeConfiguracaoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [NfeConfiguracao] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public NfeConfiguracaoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found NfeConfiguracao].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found NfeConfiguracao] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public NfeConfiguracaoModel insert(@RequestBody NfeConfiguracaoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert NfeConfiguracao] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public NfeConfiguracaoModel update(@RequestBody NfeConfiguracaoModel objJson) {	
		try {			
			NfeConfiguracaoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update NfeConfiguracao].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update NfeConfiguracao] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeConfiguracao] - Exception: " + e.getMessage());
		}
	}
	
}