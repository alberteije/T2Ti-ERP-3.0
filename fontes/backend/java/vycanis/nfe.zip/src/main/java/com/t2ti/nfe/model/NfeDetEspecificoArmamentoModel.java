package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_det_especifico_armamento")
@NamedQuery(name="NfeDetEspecificoArmamentoModel.findAll", query="SELECT t FROM NfeDetEspecificoArmamentoModel t")
public class NfeDetEspecificoArmamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetEspecificoArmamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo_arma")
	private String tipoArma;

	@Column(name="numero_serie_arma")
	private String numeroSerieArma;

	@Column(name="numero_serie_cano")
	private String numeroSerieCano;

	@Column(name="descricao")
	private String descricao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipoArma() { 
		return this.tipoArma; 
	} 

	public void setTipoArma(String tipoArma) { 
		this.tipoArma = tipoArma; 
	} 

	public String getNumeroSerieArma() { 
		return this.numeroSerieArma; 
	} 

	public void setNumeroSerieArma(String numeroSerieArma) { 
		this.numeroSerieArma = numeroSerieArma; 
	} 

	public String getNumeroSerieCano() { 
		return this.numeroSerieCano; 
	} 

	public void setNumeroSerieCano(String numeroSerieCano) { 
		this.numeroSerieCano = numeroSerieCano; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}