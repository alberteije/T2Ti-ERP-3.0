package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="venda_cabecalho")
@NamedQuery(name="VendaCabecalhoModel.findAll", query="SELECT t FROM VendaCabecalhoModel t")
public class VendaCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_venda_orcamento_cabecalho")
	private Integer idVendaOrcamentoCabecalho;

	@Column(name="id_venda_condicoes_pagamento")
	private Integer idVendaCondicoesPagamento;

	@Column(name="id_nota_fiscal_tipo")
	private Integer idNotaFiscalTipo;

	@Column(name="id_transportadora")
	private Integer idTransportadora;

	@Temporal(TemporalType.DATE)
@Column(name="data_venda")
	private Date dataVenda;

	@Temporal(TemporalType.DATE)
@Column(name="data_saida")
	private Date dataSaida;

	@Column(name="hora_saida")
	private String horaSaida;

	@Column(name="numero_fatura")
	private Integer numeroFatura;

	@Column(name="local_entrega")
	private String localEntrega;

	@Column(name="local_cobranca")
	private String localCobranca;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="taxa_comissao")
	private BigDecimal taxaComissao;

	@Column(name="valor_comissao")
	private BigDecimal valorComissao;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="tipo_frete")
	private String tipoFrete;

	@Column(name="forma_pagamento")
	private String formaPagamento;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@Column(name="valor_seguro")
	private BigDecimal valorSeguro;

	@Column(name="observacao")
	private String observacao;

	@Column(name="situacao")
	private String situacao;

	@Column(name="dia_fixo_parcela")
	private String diaFixoParcela;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdVendaOrcamentoCabecalho() { 
		return this.idVendaOrcamentoCabecalho; 
	} 

	public void setIdVendaOrcamentoCabecalho(Integer idVendaOrcamentoCabecalho) { 
		this.idVendaOrcamentoCabecalho = idVendaOrcamentoCabecalho; 
	} 

	public Integer getIdVendaCondicoesPagamento() { 
		return this.idVendaCondicoesPagamento; 
	} 

	public void setIdVendaCondicoesPagamento(Integer idVendaCondicoesPagamento) { 
		this.idVendaCondicoesPagamento = idVendaCondicoesPagamento; 
	} 

	public Integer getIdNotaFiscalTipo() { 
		return this.idNotaFiscalTipo; 
	} 

	public void setIdNotaFiscalTipo(Integer idNotaFiscalTipo) { 
		this.idNotaFiscalTipo = idNotaFiscalTipo; 
	} 

	public Integer getIdTransportadora() { 
		return this.idTransportadora; 
	} 

	public void setIdTransportadora(Integer idTransportadora) { 
		this.idTransportadora = idTransportadora; 
	} 

	public Date getDataVenda() { 
		return this.dataVenda; 
	} 

	public void setDataVenda(Date dataVenda) { 
		this.dataVenda = dataVenda; 
	} 

	public Date getDataSaida() { 
		return this.dataSaida; 
	} 

	public void setDataSaida(Date dataSaida) { 
		this.dataSaida = dataSaida; 
	} 

	public String getHoraSaida() { 
		return this.horaSaida; 
	} 

	public void setHoraSaida(String horaSaida) { 
		this.horaSaida = horaSaida; 
	} 

	public Integer getNumeroFatura() { 
		return this.numeroFatura; 
	} 

	public void setNumeroFatura(Integer numeroFatura) { 
		this.numeroFatura = numeroFatura; 
	} 

	public String getLocalEntrega() { 
		return this.localEntrega; 
	} 

	public void setLocalEntrega(String localEntrega) { 
		this.localEntrega = localEntrega; 
	} 

	public String getLocalCobranca() { 
		return this.localCobranca; 
	} 

	public void setLocalCobranca(String localCobranca) { 
		this.localCobranca = localCobranca; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getTaxaComissao() { 
		return this.taxaComissao; 
	} 

	public void setTaxaComissao(BigDecimal taxaComissao) { 
		this.taxaComissao = taxaComissao; 
	} 

	public BigDecimal getValorComissao() { 
		return this.valorComissao; 
	} 

	public void setValorComissao(BigDecimal valorComissao) { 
		this.valorComissao = valorComissao; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public String getTipoFrete() { 
		return this.tipoFrete; 
	} 

	public void setTipoFrete(String tipoFrete) { 
		this.tipoFrete = tipoFrete; 
	} 

	public String getFormaPagamento() { 
		return this.formaPagamento; 
	} 

	public void setFormaPagamento(String formaPagamento) { 
		this.formaPagamento = formaPagamento; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public BigDecimal getValorSeguro() { 
		return this.valorSeguro; 
	} 

	public void setValorSeguro(BigDecimal valorSeguro) { 
		this.valorSeguro = valorSeguro; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public String getDiaFixoParcela() { 
		return this.diaFixoParcela; 
	} 

	public void setDiaFixoParcela(String diaFixoParcela) { 
		this.diaFixoParcela = diaFixoParcela; 
	} 

		
}