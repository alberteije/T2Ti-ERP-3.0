package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_transporte_volume")
@NamedQuery(name="NfeTransporteVolumeModel.findAll", query="SELECT t FROM NfeTransporteVolumeModel t")
public class NfeTransporteVolumeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeTransporteVolumeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private Integer quantidade;

	@Column(name="especie")
	private String especie;

	@Column(name="marca")
	private String marca;

	@Column(name="numeracao")
	private String numeracao;

	@Column(name="peso_liquido")
	private BigDecimal pesoLiquido;

	@Column(name="peso_bruto")
	private BigDecimal pesoBruto;

	@ManyToOne 
	@JoinColumn(name="id_nfe_transporte")
	private NfeTransporteModel nfeTransporteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public String getEspecie() { 
		return this.especie; 
	} 

	public void setEspecie(String especie) { 
		this.especie = especie; 
	} 

	public String getMarca() { 
		return this.marca; 
	} 

	public void setMarca(String marca) { 
		this.marca = marca; 
	} 

	public String getNumeracao() { 
		return this.numeracao; 
	} 

	public void setNumeracao(String numeracao) { 
		this.numeracao = numeracao; 
	} 

	public BigDecimal getPesoLiquido() { 
		return this.pesoLiquido; 
	} 

	public void setPesoLiquido(BigDecimal pesoLiquido) { 
		this.pesoLiquido = pesoLiquido; 
	} 

	public BigDecimal getPesoBruto() { 
		return this.pesoBruto; 
	} 

	public void setPesoBruto(BigDecimal pesoBruto) { 
		this.pesoBruto = pesoBruto; 
	} 

	public NfeTransporteModel getNfeTransporteModel() { 
	return this.nfeTransporteModel; 
	} 

	public void setNfeTransporteModel(NfeTransporteModel nfeTransporteModel) { 
	this.nfeTransporteModel = nfeTransporteModel; 
	} 

		
}