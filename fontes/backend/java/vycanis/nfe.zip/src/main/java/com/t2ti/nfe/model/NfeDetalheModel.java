package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe")
@NamedQuery(name="NfeDetalheModel.findAll", query="SELECT t FROM NfeDetalheModel t")
public class NfeDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_item")
	private Integer numeroItem;

	@Column(name="codigo_produto")
	private String codigoProduto;

	@Column(name="gtin")
	private String gtin;

	@Column(name="nome_produto")
	private String nomeProduto;

	@Column(name="ncm")
	private String ncm;

	@Column(name="nve")
	private String nve;

	@Column(name="cest")
	private String cest;

	@Column(name="indicador_escala_relevante")
	private String indicadorEscalaRelevante;

	@Column(name="cnpj_fabricante")
	private String cnpjFabricante;

	@Column(name="codigo_beneficio_fiscal")
	private String codigoBeneficioFiscal;

	@Column(name="ex_tipi")
	private Integer exTipi;

	@Column(name="cfop")
	private Integer cfop;

	@Column(name="unidade_comercial")
	private String unidadeComercial;

	@Column(name="quantidade_comercial")
	private BigDecimal quantidadeComercial;

	@Column(name="numero_pedido_compra")
	private String numeroPedidoCompra;

	@Column(name="item_pedido_compra")
	private Integer itemPedidoCompra;

	@Column(name="numero_fci")
	private String numeroFci;

	@Column(name="numero_recopi")
	private String numeroRecopi;

	@Column(name="valor_unitario_comercial")
	private BigDecimal valorUnitarioComercial;

	@Column(name="valor_bruto_produto")
	private BigDecimal valorBrutoProduto;

	@Column(name="gtin_unidade_tributavel")
	private String gtinUnidadeTributavel;

	@Column(name="unidade_tributavel")
	private String unidadeTributavel;

	@Column(name="quantidade_tributavel")
	private BigDecimal quantidadeTributavel;

	@Column(name="valor_unitario_tributavel")
	private BigDecimal valorUnitarioTributavel;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@Column(name="valor_seguro")
	private BigDecimal valorSeguro;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_outras_despesas")
	private BigDecimal valorOutrasDespesas;

	@Column(name="entra_total")
	private String entraTotal;

	@Column(name="valor_total_tributos")
	private BigDecimal valorTotalTributos;

	@Column(name="percentual_devolvido")
	private BigDecimal percentualDevolvido;

	@Column(name="valor_ipi_devolvido")
	private BigDecimal valorIpiDevolvido;

	@Column(name="informacoes_adicionais")
	private String informacoesAdicionais;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetEspecificoVeiculoModel> nfeDetEspecificoVeiculoModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetEspecificoMedicamentoModel> nfeDetEspecificoMedicamentoModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetEspecificoArmamentoModel> nfeDetEspecificoArmamentoModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetEspecificoCombustivelModel> nfeDetEspecificoCombustivelModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDeclaracaoImportacaoModel> nfeDeclaracaoImportacaoModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoIcmsModel> nfeDetalheImpostoIcmsModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoIpiModel> nfeDetalheImpostoIpiModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoIiModel> nfeDetalheImpostoIiModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoPisModel> nfeDetalheImpostoPisModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoCofinsModel> nfeDetalheImpostoCofinsModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoIssqnModel> nfeDetalheImpostoIssqnModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeExportacaoModel> nfeExportacaoModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeItemRastreadoModel> nfeItemRastreadoModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoPisStModel> nfeDetalheImpostoPisStModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoIcmsUfdestModel> nfeDetalheImpostoIcmsUfdestModelList; 

	@OneToMany(mappedBy = "nfeDetalheModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDetalheImpostoCofinsStModel> nfeDetalheImpostoCofinsStModelList; 

	@ManyToOne 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumeroItem() { 
		return this.numeroItem; 
	} 

	public void setNumeroItem(Integer numeroItem) { 
		this.numeroItem = numeroItem; 
	} 

	public String getCodigoProduto() { 
		return this.codigoProduto; 
	} 

	public void setCodigoProduto(String codigoProduto) { 
		this.codigoProduto = codigoProduto; 
	} 

	public String getGtin() { 
		return this.gtin; 
	} 

	public void setGtin(String gtin) { 
		this.gtin = gtin; 
	} 

	public String getNomeProduto() { 
		return this.nomeProduto; 
	} 

	public void setNomeProduto(String nomeProduto) { 
		this.nomeProduto = nomeProduto; 
	} 

	public String getNcm() { 
		return this.ncm; 
	} 

	public void setNcm(String ncm) { 
		this.ncm = ncm; 
	} 

	public String getNve() { 
		return this.nve; 
	} 

	public void setNve(String nve) { 
		this.nve = nve; 
	} 

	public String getCest() { 
		return this.cest; 
	} 

	public void setCest(String cest) { 
		this.cest = cest; 
	} 

	public String getIndicadorEscalaRelevante() { 
		return this.indicadorEscalaRelevante; 
	} 

	public void setIndicadorEscalaRelevante(String indicadorEscalaRelevante) { 
		this.indicadorEscalaRelevante = indicadorEscalaRelevante; 
	} 

	public String getCnpjFabricante() { 
		return this.cnpjFabricante; 
	} 

	public void setCnpjFabricante(String cnpjFabricante) { 
		this.cnpjFabricante = cnpjFabricante; 
	} 

	public String getCodigoBeneficioFiscal() { 
		return this.codigoBeneficioFiscal; 
	} 

	public void setCodigoBeneficioFiscal(String codigoBeneficioFiscal) { 
		this.codigoBeneficioFiscal = codigoBeneficioFiscal; 
	} 

	public Integer getExTipi() { 
		return this.exTipi; 
	} 

	public void setExTipi(Integer exTipi) { 
		this.exTipi = exTipi; 
	} 

	public Integer getCfop() { 
		return this.cfop; 
	} 

	public void setCfop(Integer cfop) { 
		this.cfop = cfop; 
	} 

	public String getUnidadeComercial() { 
		return this.unidadeComercial; 
	} 

	public void setUnidadeComercial(String unidadeComercial) { 
		this.unidadeComercial = unidadeComercial; 
	} 

	public BigDecimal getQuantidadeComercial() { 
		return this.quantidadeComercial; 
	} 

	public void setQuantidadeComercial(BigDecimal quantidadeComercial) { 
		this.quantidadeComercial = quantidadeComercial; 
	} 

	public String getNumeroPedidoCompra() { 
		return this.numeroPedidoCompra; 
	} 

	public void setNumeroPedidoCompra(String numeroPedidoCompra) { 
		this.numeroPedidoCompra = numeroPedidoCompra; 
	} 

	public Integer getItemPedidoCompra() { 
		return this.itemPedidoCompra; 
	} 

	public void setItemPedidoCompra(Integer itemPedidoCompra) { 
		this.itemPedidoCompra = itemPedidoCompra; 
	} 

	public String getNumeroFci() { 
		return this.numeroFci; 
	} 

	public void setNumeroFci(String numeroFci) { 
		this.numeroFci = numeroFci; 
	} 

	public String getNumeroRecopi() { 
		return this.numeroRecopi; 
	} 

	public void setNumeroRecopi(String numeroRecopi) { 
		this.numeroRecopi = numeroRecopi; 
	} 

	public BigDecimal getValorUnitarioComercial() { 
		return this.valorUnitarioComercial; 
	} 

	public void setValorUnitarioComercial(BigDecimal valorUnitarioComercial) { 
		this.valorUnitarioComercial = valorUnitarioComercial; 
	} 

	public BigDecimal getValorBrutoProduto() { 
		return this.valorBrutoProduto; 
	} 

	public void setValorBrutoProduto(BigDecimal valorBrutoProduto) { 
		this.valorBrutoProduto = valorBrutoProduto; 
	} 

	public String getGtinUnidadeTributavel() { 
		return this.gtinUnidadeTributavel; 
	} 

	public void setGtinUnidadeTributavel(String gtinUnidadeTributavel) { 
		this.gtinUnidadeTributavel = gtinUnidadeTributavel; 
	} 

	public String getUnidadeTributavel() { 
		return this.unidadeTributavel; 
	} 

	public void setUnidadeTributavel(String unidadeTributavel) { 
		this.unidadeTributavel = unidadeTributavel; 
	} 

	public BigDecimal getQuantidadeTributavel() { 
		return this.quantidadeTributavel; 
	} 

	public void setQuantidadeTributavel(BigDecimal quantidadeTributavel) { 
		this.quantidadeTributavel = quantidadeTributavel; 
	} 

	public BigDecimal getValorUnitarioTributavel() { 
		return this.valorUnitarioTributavel; 
	} 

	public void setValorUnitarioTributavel(BigDecimal valorUnitarioTributavel) { 
		this.valorUnitarioTributavel = valorUnitarioTributavel; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public BigDecimal getValorSeguro() { 
		return this.valorSeguro; 
	} 

	public void setValorSeguro(BigDecimal valorSeguro) { 
		this.valorSeguro = valorSeguro; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorOutrasDespesas() { 
		return this.valorOutrasDespesas; 
	} 

	public void setValorOutrasDespesas(BigDecimal valorOutrasDespesas) { 
		this.valorOutrasDespesas = valorOutrasDespesas; 
	} 

	public String getEntraTotal() { 
		return this.entraTotal; 
	} 

	public void setEntraTotal(String entraTotal) { 
		this.entraTotal = entraTotal; 
	} 

	public BigDecimal getValorTotalTributos() { 
		return this.valorTotalTributos; 
	} 

	public void setValorTotalTributos(BigDecimal valorTotalTributos) { 
		this.valorTotalTributos = valorTotalTributos; 
	} 

	public BigDecimal getPercentualDevolvido() { 
		return this.percentualDevolvido; 
	} 

	public void setPercentualDevolvido(BigDecimal percentualDevolvido) { 
		this.percentualDevolvido = percentualDevolvido; 
	} 

	public BigDecimal getValorIpiDevolvido() { 
		return this.valorIpiDevolvido; 
	} 

	public void setValorIpiDevolvido(BigDecimal valorIpiDevolvido) { 
		this.valorIpiDevolvido = valorIpiDevolvido; 
	} 

	public String getInformacoesAdicionais() { 
		return this.informacoesAdicionais; 
	} 

	public void setInformacoesAdicionais(String informacoesAdicionais) { 
		this.informacoesAdicionais = informacoesAdicionais; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public Set<NfeDetEspecificoVeiculoModel> getNfeDetEspecificoVeiculoModelList() { 
	return this.nfeDetEspecificoVeiculoModelList; 
	} 

	public void setNfeDetEspecificoVeiculoModelList(Set<NfeDetEspecificoVeiculoModel> nfeDetEspecificoVeiculoModelList) { 
	this.nfeDetEspecificoVeiculoModelList = nfeDetEspecificoVeiculoModelList; 
		for (NfeDetEspecificoVeiculoModel nfeDetEspecificoVeiculoModel : nfeDetEspecificoVeiculoModelList) { 
			nfeDetEspecificoVeiculoModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetEspecificoMedicamentoModel> getNfeDetEspecificoMedicamentoModelList() { 
	return this.nfeDetEspecificoMedicamentoModelList; 
	} 

	public void setNfeDetEspecificoMedicamentoModelList(Set<NfeDetEspecificoMedicamentoModel> nfeDetEspecificoMedicamentoModelList) { 
	this.nfeDetEspecificoMedicamentoModelList = nfeDetEspecificoMedicamentoModelList; 
		for (NfeDetEspecificoMedicamentoModel nfeDetEspecificoMedicamentoModel : nfeDetEspecificoMedicamentoModelList) { 
			nfeDetEspecificoMedicamentoModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetEspecificoArmamentoModel> getNfeDetEspecificoArmamentoModelList() { 
	return this.nfeDetEspecificoArmamentoModelList; 
	} 

	public void setNfeDetEspecificoArmamentoModelList(Set<NfeDetEspecificoArmamentoModel> nfeDetEspecificoArmamentoModelList) { 
	this.nfeDetEspecificoArmamentoModelList = nfeDetEspecificoArmamentoModelList; 
		for (NfeDetEspecificoArmamentoModel nfeDetEspecificoArmamentoModel : nfeDetEspecificoArmamentoModelList) { 
			nfeDetEspecificoArmamentoModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetEspecificoCombustivelModel> getNfeDetEspecificoCombustivelModelList() { 
	return this.nfeDetEspecificoCombustivelModelList; 
	} 

	public void setNfeDetEspecificoCombustivelModelList(Set<NfeDetEspecificoCombustivelModel> nfeDetEspecificoCombustivelModelList) { 
	this.nfeDetEspecificoCombustivelModelList = nfeDetEspecificoCombustivelModelList; 
		for (NfeDetEspecificoCombustivelModel nfeDetEspecificoCombustivelModel : nfeDetEspecificoCombustivelModelList) { 
			nfeDetEspecificoCombustivelModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDeclaracaoImportacaoModel> getNfeDeclaracaoImportacaoModelList() { 
	return this.nfeDeclaracaoImportacaoModelList; 
	} 

	public void setNfeDeclaracaoImportacaoModelList(Set<NfeDeclaracaoImportacaoModel> nfeDeclaracaoImportacaoModelList) { 
	this.nfeDeclaracaoImportacaoModelList = nfeDeclaracaoImportacaoModelList; 
		for (NfeDeclaracaoImportacaoModel nfeDeclaracaoImportacaoModel : nfeDeclaracaoImportacaoModelList) { 
			nfeDeclaracaoImportacaoModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoIcmsModel> getNfeDetalheImpostoIcmsModelList() { 
	return this.nfeDetalheImpostoIcmsModelList; 
	} 

	public void setNfeDetalheImpostoIcmsModelList(Set<NfeDetalheImpostoIcmsModel> nfeDetalheImpostoIcmsModelList) { 
	this.nfeDetalheImpostoIcmsModelList = nfeDetalheImpostoIcmsModelList; 
		for (NfeDetalheImpostoIcmsModel nfeDetalheImpostoIcmsModel : nfeDetalheImpostoIcmsModelList) { 
			nfeDetalheImpostoIcmsModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoIpiModel> getNfeDetalheImpostoIpiModelList() { 
	return this.nfeDetalheImpostoIpiModelList; 
	} 

	public void setNfeDetalheImpostoIpiModelList(Set<NfeDetalheImpostoIpiModel> nfeDetalheImpostoIpiModelList) { 
	this.nfeDetalheImpostoIpiModelList = nfeDetalheImpostoIpiModelList; 
		for (NfeDetalheImpostoIpiModel nfeDetalheImpostoIpiModel : nfeDetalheImpostoIpiModelList) { 
			nfeDetalheImpostoIpiModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoIiModel> getNfeDetalheImpostoIiModelList() { 
	return this.nfeDetalheImpostoIiModelList; 
	} 

	public void setNfeDetalheImpostoIiModelList(Set<NfeDetalheImpostoIiModel> nfeDetalheImpostoIiModelList) { 
	this.nfeDetalheImpostoIiModelList = nfeDetalheImpostoIiModelList; 
		for (NfeDetalheImpostoIiModel nfeDetalheImpostoIiModel : nfeDetalheImpostoIiModelList) { 
			nfeDetalheImpostoIiModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoPisModel> getNfeDetalheImpostoPisModelList() { 
	return this.nfeDetalheImpostoPisModelList; 
	} 

	public void setNfeDetalheImpostoPisModelList(Set<NfeDetalheImpostoPisModel> nfeDetalheImpostoPisModelList) { 
	this.nfeDetalheImpostoPisModelList = nfeDetalheImpostoPisModelList; 
		for (NfeDetalheImpostoPisModel nfeDetalheImpostoPisModel : nfeDetalheImpostoPisModelList) { 
			nfeDetalheImpostoPisModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoCofinsModel> getNfeDetalheImpostoCofinsModelList() { 
	return this.nfeDetalheImpostoCofinsModelList; 
	} 

	public void setNfeDetalheImpostoCofinsModelList(Set<NfeDetalheImpostoCofinsModel> nfeDetalheImpostoCofinsModelList) { 
	this.nfeDetalheImpostoCofinsModelList = nfeDetalheImpostoCofinsModelList; 
		for (NfeDetalheImpostoCofinsModel nfeDetalheImpostoCofinsModel : nfeDetalheImpostoCofinsModelList) { 
			nfeDetalheImpostoCofinsModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoIssqnModel> getNfeDetalheImpostoIssqnModelList() { 
	return this.nfeDetalheImpostoIssqnModelList; 
	} 

	public void setNfeDetalheImpostoIssqnModelList(Set<NfeDetalheImpostoIssqnModel> nfeDetalheImpostoIssqnModelList) { 
	this.nfeDetalheImpostoIssqnModelList = nfeDetalheImpostoIssqnModelList; 
		for (NfeDetalheImpostoIssqnModel nfeDetalheImpostoIssqnModel : nfeDetalheImpostoIssqnModelList) { 
			nfeDetalheImpostoIssqnModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeExportacaoModel> getNfeExportacaoModelList() { 
	return this.nfeExportacaoModelList; 
	} 

	public void setNfeExportacaoModelList(Set<NfeExportacaoModel> nfeExportacaoModelList) { 
	this.nfeExportacaoModelList = nfeExportacaoModelList; 
		for (NfeExportacaoModel nfeExportacaoModel : nfeExportacaoModelList) { 
			nfeExportacaoModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeItemRastreadoModel> getNfeItemRastreadoModelList() { 
	return this.nfeItemRastreadoModelList; 
	} 

	public void setNfeItemRastreadoModelList(Set<NfeItemRastreadoModel> nfeItemRastreadoModelList) { 
	this.nfeItemRastreadoModelList = nfeItemRastreadoModelList; 
		for (NfeItemRastreadoModel nfeItemRastreadoModel : nfeItemRastreadoModelList) { 
			nfeItemRastreadoModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoPisStModel> getNfeDetalheImpostoPisStModelList() { 
	return this.nfeDetalheImpostoPisStModelList; 
	} 

	public void setNfeDetalheImpostoPisStModelList(Set<NfeDetalheImpostoPisStModel> nfeDetalheImpostoPisStModelList) { 
	this.nfeDetalheImpostoPisStModelList = nfeDetalheImpostoPisStModelList; 
		for (NfeDetalheImpostoPisStModel nfeDetalheImpostoPisStModel : nfeDetalheImpostoPisStModelList) { 
			nfeDetalheImpostoPisStModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoIcmsUfdestModel> getNfeDetalheImpostoIcmsUfdestModelList() { 
	return this.nfeDetalheImpostoIcmsUfdestModelList; 
	} 

	public void setNfeDetalheImpostoIcmsUfdestModelList(Set<NfeDetalheImpostoIcmsUfdestModel> nfeDetalheImpostoIcmsUfdestModelList) { 
	this.nfeDetalheImpostoIcmsUfdestModelList = nfeDetalheImpostoIcmsUfdestModelList; 
		for (NfeDetalheImpostoIcmsUfdestModel nfeDetalheImpostoIcmsUfdestModel : nfeDetalheImpostoIcmsUfdestModelList) { 
			nfeDetalheImpostoIcmsUfdestModel.setNfeDetalheModel(this); 
		}
	} 

	public Set<NfeDetalheImpostoCofinsStModel> getNfeDetalheImpostoCofinsStModelList() { 
	return this.nfeDetalheImpostoCofinsStModelList; 
	} 

	public void setNfeDetalheImpostoCofinsStModelList(Set<NfeDetalheImpostoCofinsStModel> nfeDetalheImpostoCofinsStModelList) { 
	this.nfeDetalheImpostoCofinsStModelList = nfeDetalheImpostoCofinsStModelList; 
		for (NfeDetalheImpostoCofinsStModel nfeDetalheImpostoCofinsStModel : nfeDetalheImpostoCofinsStModelList) { 
			nfeDetalheImpostoCofinsStModel.setNfeDetalheModel(this); 
		}
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}