package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_exportacao")
@NamedQuery(name="NfeExportacaoModel.findAll", query="SELECT t FROM NfeExportacaoModel t")
public class NfeExportacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeExportacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="drawback")
	private Integer drawback;

	@Column(name="numero_registro")
	private Integer numeroRegistro;

	@Column(name="chave_acesso")
	private String chaveAcesso;

	@Column(name="quantidade")
	private BigDecimal quantidade;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getDrawback() { 
		return this.drawback; 
	} 

	public void setDrawback(Integer drawback) { 
		this.drawback = drawback; 
	} 

	public Integer getNumeroRegistro() { 
		return this.numeroRegistro; 
	} 

	public void setNumeroRegistro(Integer numeroRegistro) { 
		this.numeroRegistro = numeroRegistro; 
	} 

	public String getChaveAcesso() { 
		return this.chaveAcesso; 
	} 

	public void setChaveAcesso(String chaveAcesso) { 
		this.chaveAcesso = chaveAcesso; 
	} 

	public BigDecimal getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(BigDecimal quantidade) { 
		this.quantidade = quantidade; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}