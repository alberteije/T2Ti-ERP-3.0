package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_det_especifico_combustivel")
@NamedQuery(name="NfeDetEspecificoCombustivelModel.findAll", query="SELECT t FROM NfeDetEspecificoCombustivelModel t")
public class NfeDetEspecificoCombustivelModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetEspecificoCombustivelModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_anp")
	private Integer codigoAnp;

	@Column(name="descricao_anp")
	private String descricaoAnp;

	@Column(name="percentual_glp")
	private BigDecimal percentualGlp;

	@Column(name="percentual_gas_nacional")
	private BigDecimal percentualGasNacional;

	@Column(name="percentual_gas_importado")
	private BigDecimal percentualGasImportado;

	@Column(name="valor_partida")
	private BigDecimal valorPartida;

	@Column(name="codif")
	private String codif;

	@Column(name="quantidade_temp_ambiente")
	private BigDecimal quantidadeTempAmbiente;

	@Column(name="uf_consumo")
	private String ufConsumo;

	@Column(name="cide_base_calculo")
	private BigDecimal cideBaseCalculo;

	@Column(name="cide_aliquota")
	private BigDecimal cideAliquota;

	@Column(name="cide_valor")
	private BigDecimal cideValor;

	@Column(name="encerrante_bico")
	private Integer encerranteBico;

	@Column(name="encerrante_bomba")
	private Integer encerranteBomba;

	@Column(name="encerrante_tanque")
	private Integer encerranteTanque;

	@Column(name="encerrante_valor_inicio")
	private BigDecimal encerranteValorInicio;

	@Column(name="encerrante_valor_fim")
	private BigDecimal encerranteValorFim;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getCodigoAnp() { 
		return this.codigoAnp; 
	} 

	public void setCodigoAnp(Integer codigoAnp) { 
		this.codigoAnp = codigoAnp; 
	} 

	public String getDescricaoAnp() { 
		return this.descricaoAnp; 
	} 

	public void setDescricaoAnp(String descricaoAnp) { 
		this.descricaoAnp = descricaoAnp; 
	} 

	public BigDecimal getPercentualGlp() { 
		return this.percentualGlp; 
	} 

	public void setPercentualGlp(BigDecimal percentualGlp) { 
		this.percentualGlp = percentualGlp; 
	} 

	public BigDecimal getPercentualGasNacional() { 
		return this.percentualGasNacional; 
	} 

	public void setPercentualGasNacional(BigDecimal percentualGasNacional) { 
		this.percentualGasNacional = percentualGasNacional; 
	} 

	public BigDecimal getPercentualGasImportado() { 
		return this.percentualGasImportado; 
	} 

	public void setPercentualGasImportado(BigDecimal percentualGasImportado) { 
		this.percentualGasImportado = percentualGasImportado; 
	} 

	public BigDecimal getValorPartida() { 
		return this.valorPartida; 
	} 

	public void setValorPartida(BigDecimal valorPartida) { 
		this.valorPartida = valorPartida; 
	} 

	public String getCodif() { 
		return this.codif; 
	} 

	public void setCodif(String codif) { 
		this.codif = codif; 
	} 

	public BigDecimal getQuantidadeTempAmbiente() { 
		return this.quantidadeTempAmbiente; 
	} 

	public void setQuantidadeTempAmbiente(BigDecimal quantidadeTempAmbiente) { 
		this.quantidadeTempAmbiente = quantidadeTempAmbiente; 
	} 

	public String getUfConsumo() { 
		return this.ufConsumo; 
	} 

	public void setUfConsumo(String ufConsumo) { 
		this.ufConsumo = ufConsumo; 
	} 

	public BigDecimal getCideBaseCalculo() { 
		return this.cideBaseCalculo; 
	} 

	public void setCideBaseCalculo(BigDecimal cideBaseCalculo) { 
		this.cideBaseCalculo = cideBaseCalculo; 
	} 

	public BigDecimal getCideAliquota() { 
		return this.cideAliquota; 
	} 

	public void setCideAliquota(BigDecimal cideAliquota) { 
		this.cideAliquota = cideAliquota; 
	} 

	public BigDecimal getCideValor() { 
		return this.cideValor; 
	} 

	public void setCideValor(BigDecimal cideValor) { 
		this.cideValor = cideValor; 
	} 

	public Integer getEncerranteBico() { 
		return this.encerranteBico; 
	} 

	public void setEncerranteBico(Integer encerranteBico) { 
		this.encerranteBico = encerranteBico; 
	} 

	public Integer getEncerranteBomba() { 
		return this.encerranteBomba; 
	} 

	public void setEncerranteBomba(Integer encerranteBomba) { 
		this.encerranteBomba = encerranteBomba; 
	} 

	public Integer getEncerranteTanque() { 
		return this.encerranteTanque; 
	} 

	public void setEncerranteTanque(Integer encerranteTanque) { 
		this.encerranteTanque = encerranteTanque; 
	} 

	public BigDecimal getEncerranteValorInicio() { 
		return this.encerranteValorInicio; 
	} 

	public void setEncerranteValorInicio(BigDecimal encerranteValorInicio) { 
		this.encerranteValorInicio = encerranteValorInicio; 
	} 

	public BigDecimal getEncerranteValorFim() { 
		return this.encerranteValorFim; 
	} 

	public void setEncerranteValorFim(BigDecimal encerranteValorFim) { 
		this.encerranteValorFim = encerranteValorFim; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}