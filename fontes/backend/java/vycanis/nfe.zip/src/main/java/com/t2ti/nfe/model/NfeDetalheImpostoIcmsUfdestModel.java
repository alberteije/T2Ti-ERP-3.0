package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_icms_ufdest")
@NamedQuery(name="NfeDetalheImpostoIcmsUfdestModel.findAll", query="SELECT t FROM NfeDetalheImpostoIcmsUfdestModel t")
public class NfeDetalheImpostoIcmsUfdestModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoIcmsUfdestModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor_bc_icms_uf_destino")
	private BigDecimal valorBcIcmsUfDestino;

	@Column(name="valor_bc_fcp_uf_destino")
	private BigDecimal valorBcFcpUfDestino;

	@Column(name="percentual_fcp_uf_destino")
	private BigDecimal percentualFcpUfDestino;

	@Column(name="aliquota_interna_uf_destino")
	private BigDecimal aliquotaInternaUfDestino;

	@Column(name="aliquota_interesdatual_uf_envolvidas")
	private BigDecimal aliquotaInteresdatualUfEnvolvidas;

	@Column(name="percentual_provisorio_partilha_icms")
	private BigDecimal percentualProvisorioPartilhaIcms;

	@Column(name="valor_icms_fcp_uf_destino")
	private BigDecimal valorIcmsFcpUfDestino;

	@Column(name="valor_interestadual_uf_destino")
	private BigDecimal valorInterestadualUfDestino;

	@Column(name="valor_interestadual_uf_remetente")
	private BigDecimal valorInterestadualUfRemetente;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValorBcIcmsUfDestino() { 
		return this.valorBcIcmsUfDestino; 
	} 

	public void setValorBcIcmsUfDestino(BigDecimal valorBcIcmsUfDestino) { 
		this.valorBcIcmsUfDestino = valorBcIcmsUfDestino; 
	} 

	public BigDecimal getValorBcFcpUfDestino() { 
		return this.valorBcFcpUfDestino; 
	} 

	public void setValorBcFcpUfDestino(BigDecimal valorBcFcpUfDestino) { 
		this.valorBcFcpUfDestino = valorBcFcpUfDestino; 
	} 

	public BigDecimal getPercentualFcpUfDestino() { 
		return this.percentualFcpUfDestino; 
	} 

	public void setPercentualFcpUfDestino(BigDecimal percentualFcpUfDestino) { 
		this.percentualFcpUfDestino = percentualFcpUfDestino; 
	} 

	public BigDecimal getAliquotaInternaUfDestino() { 
		return this.aliquotaInternaUfDestino; 
	} 

	public void setAliquotaInternaUfDestino(BigDecimal aliquotaInternaUfDestino) { 
		this.aliquotaInternaUfDestino = aliquotaInternaUfDestino; 
	} 

	public BigDecimal getAliquotaInteresdatualUfEnvolvidas() { 
		return this.aliquotaInteresdatualUfEnvolvidas; 
	} 

	public void setAliquotaInteresdatualUfEnvolvidas(BigDecimal aliquotaInteresdatualUfEnvolvidas) { 
		this.aliquotaInteresdatualUfEnvolvidas = aliquotaInteresdatualUfEnvolvidas; 
	} 

	public BigDecimal getPercentualProvisorioPartilhaIcms() { 
		return this.percentualProvisorioPartilhaIcms; 
	} 

	public void setPercentualProvisorioPartilhaIcms(BigDecimal percentualProvisorioPartilhaIcms) { 
		this.percentualProvisorioPartilhaIcms = percentualProvisorioPartilhaIcms; 
	} 

	public BigDecimal getValorIcmsFcpUfDestino() { 
		return this.valorIcmsFcpUfDestino; 
	} 

	public void setValorIcmsFcpUfDestino(BigDecimal valorIcmsFcpUfDestino) { 
		this.valorIcmsFcpUfDestino = valorIcmsFcpUfDestino; 
	} 

	public BigDecimal getValorInterestadualUfDestino() { 
		return this.valorInterestadualUfDestino; 
	} 

	public void setValorInterestadualUfDestino(BigDecimal valorInterestadualUfDestino) { 
		this.valorInterestadualUfDestino = valorInterestadualUfDestino; 
	} 

	public BigDecimal getValorInterestadualUfRemetente() { 
		return this.valorInterestadualUfRemetente; 
	} 

	public void setValorInterestadualUfRemetente(BigDecimal valorInterestadualUfRemetente) { 
		this.valorInterestadualUfRemetente = valorInterestadualUfRemetente; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}