package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.NfeCabecalhoModel;
import com.t2ti.nfe.repository.NfeCabecalhoRepository;

@Service
public class NfeCabecalhoService {

	@Autowired
	private NfeCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfeCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfeCabecalhoModel> getList(Filter filter) {
		String sql = "select * from nfe_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfeCabecalhoModel.class);
		return query.getResultList();
	}

	public NfeCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfeCabecalhoModel save(NfeCabecalhoModel obj) {
		NfeCabecalhoModel nfeCabecalhoModel = repository.save(obj);
		return nfeCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfeCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeCabecalho] - Exception: " + e.getMessage());
		}
	}

}