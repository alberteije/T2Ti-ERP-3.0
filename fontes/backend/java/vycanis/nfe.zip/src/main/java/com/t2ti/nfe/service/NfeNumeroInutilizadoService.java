package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.NfeNumeroInutilizadoModel;
import com.t2ti.nfe.repository.NfeNumeroInutilizadoRepository;

@Service
public class NfeNumeroInutilizadoService {

	@Autowired
	private NfeNumeroInutilizadoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfeNumeroInutilizadoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfeNumeroInutilizadoModel> getList(Filter filter) {
		String sql = "select * from nfe_numero_inutilizado where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfeNumeroInutilizadoModel.class);
		return query.getResultList();
	}

	public NfeNumeroInutilizadoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfeNumeroInutilizadoModel save(NfeNumeroInutilizadoModel obj) {
		NfeNumeroInutilizadoModel nfeNumeroInutilizadoModel = repository.save(obj);
		return nfeNumeroInutilizadoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfeNumeroInutilizadoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeNumeroInutilizado] - Exception: " + e.getMessage());
		}
	}

}