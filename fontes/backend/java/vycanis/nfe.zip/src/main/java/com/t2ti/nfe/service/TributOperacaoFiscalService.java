package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.TributOperacaoFiscalModel;
import com.t2ti.nfe.repository.TributOperacaoFiscalRepository;

@Service
public class TributOperacaoFiscalService {

	@Autowired
	private TributOperacaoFiscalRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TributOperacaoFiscalModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TributOperacaoFiscalModel> getList(Filter filter) {
		String sql = "select * from tribut_operacao_fiscal where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TributOperacaoFiscalModel.class);
		return query.getResultList();
	}

	public TributOperacaoFiscalModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TributOperacaoFiscalModel save(TributOperacaoFiscalModel obj) {
		TributOperacaoFiscalModel tributOperacaoFiscalModel = repository.save(obj);
		return tributOperacaoFiscalModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TributOperacaoFiscalModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TributOperacaoFiscal] - Exception: " + e.getMessage());
		}
	}

}