package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_informacao_pagamento")
@NamedQuery(name="NfeInformacaoPagamentoModel.findAll", query="SELECT t FROM NfeInformacaoPagamentoModel t")
public class NfeInformacaoPagamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeInformacaoPagamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="indicador_pagamento")
	private String indicadorPagamento;

	@Column(name="meio_pagamento")
	private String meioPagamento;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="tipo_integracao")
	private String tipoIntegracao;

	@Column(name="cnpj_operadora_cartao")
	private String cnpjOperadoraCartao;

	@Column(name="bandeira")
	private String bandeira;

	@Column(name="numero_autorizacao")
	private String numeroAutorizacao;

	@Column(name="troco")
	private BigDecimal troco;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getIndicadorPagamento() { 
		return this.indicadorPagamento; 
	} 

	public void setIndicadorPagamento(String indicadorPagamento) { 
		this.indicadorPagamento = indicadorPagamento; 
	} 

	public String getMeioPagamento() { 
		return this.meioPagamento; 
	} 

	public void setMeioPagamento(String meioPagamento) { 
		this.meioPagamento = meioPagamento; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public String getTipoIntegracao() { 
		return this.tipoIntegracao; 
	} 

	public void setTipoIntegracao(String tipoIntegracao) { 
		this.tipoIntegracao = tipoIntegracao; 
	} 

	public String getCnpjOperadoraCartao() { 
		return this.cnpjOperadoraCartao; 
	} 

	public void setCnpjOperadoraCartao(String cnpjOperadoraCartao) { 
		this.cnpjOperadoraCartao = cnpjOperadoraCartao; 
	} 

	public String getBandeira() { 
		return this.bandeira; 
	} 

	public void setBandeira(String bandeira) { 
		this.bandeira = bandeira; 
	} 

	public String getNumeroAutorizacao() { 
		return this.numeroAutorizacao; 
	} 

	public void setNumeroAutorizacao(String numeroAutorizacao) { 
		this.numeroAutorizacao = numeroAutorizacao; 
	} 

	public BigDecimal getTroco() { 
		return this.troco; 
	} 

	public void setTroco(BigDecimal troco) { 
		this.troco = troco; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}