package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.ProdutoSubgrupoModel;
import com.t2ti.nfe.repository.ProdutoSubgrupoRepository;

@Service
public class ProdutoSubgrupoService {

	@Autowired
	private ProdutoSubgrupoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ProdutoSubgrupoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ProdutoSubgrupoModel> getList(Filter filter) {
		String sql = "select * from produto_subgrupo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ProdutoSubgrupoModel.class);
		return query.getResultList();
	}

	public ProdutoSubgrupoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ProdutoSubgrupoModel save(ProdutoSubgrupoModel obj) {
		ProdutoSubgrupoModel produtoSubgrupoModel = repository.save(obj);
		return produtoSubgrupoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ProdutoSubgrupoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ProdutoSubgrupo] - Exception: " + e.getMessage());
		}
	}

}