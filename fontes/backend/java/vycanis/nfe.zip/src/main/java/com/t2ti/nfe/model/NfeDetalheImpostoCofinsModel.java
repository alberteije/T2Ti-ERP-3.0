package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_cofins")
@NamedQuery(name="NfeDetalheImpostoCofinsModel.findAll", query="SELECT t FROM NfeDetalheImpostoCofinsModel t")
public class NfeDetalheImpostoCofinsModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoCofinsModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cst_cofins")
	private String cstCofins;

	@Column(name="base_calculo_cofins")
	private BigDecimal baseCalculoCofins;

	@Column(name="aliquota_cofins_percentual")
	private BigDecimal aliquotaCofinsPercentual;

	@Column(name="quantidade_vendida")
	private BigDecimal quantidadeVendida;

	@Column(name="aliquota_cofins_reais")
	private BigDecimal aliquotaCofinsReais;

	@Column(name="valor_cofins")
	private BigDecimal valorCofins;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCstCofins() { 
		return this.cstCofins; 
	} 

	public void setCstCofins(String cstCofins) { 
		this.cstCofins = cstCofins; 
	} 

	public BigDecimal getBaseCalculoCofins() { 
		return this.baseCalculoCofins; 
	} 

	public void setBaseCalculoCofins(BigDecimal baseCalculoCofins) { 
		this.baseCalculoCofins = baseCalculoCofins; 
	} 

	public BigDecimal getAliquotaCofinsPercentual() { 
		return this.aliquotaCofinsPercentual; 
	} 

	public void setAliquotaCofinsPercentual(BigDecimal aliquotaCofinsPercentual) { 
		this.aliquotaCofinsPercentual = aliquotaCofinsPercentual; 
	} 

	public BigDecimal getQuantidadeVendida() { 
		return this.quantidadeVendida; 
	} 

	public void setQuantidadeVendida(BigDecimal quantidadeVendida) { 
		this.quantidadeVendida = quantidadeVendida; 
	} 

	public BigDecimal getAliquotaCofinsReais() { 
		return this.aliquotaCofinsReais; 
	} 

	public void setAliquotaCofinsReais(BigDecimal aliquotaCofinsReais) { 
		this.aliquotaCofinsReais = aliquotaCofinsReais; 
	} 

	public BigDecimal getValorCofins() { 
		return this.valorCofins; 
	} 

	public void setValorCofins(BigDecimal valorCofins) { 
		this.valorCofins = valorCofins; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}