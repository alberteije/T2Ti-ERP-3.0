package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_cana_fornecimento_diario")
@NamedQuery(name="NfeCanaFornecimentoDiarioModel.findAll", query="SELECT t FROM NfeCanaFornecimentoDiarioModel t")
public class NfeCanaFornecimentoDiarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeCanaFornecimentoDiarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="dia")
	private String dia;

	@Column(name="quantidade")
	private BigDecimal quantidade;

	@Column(name="quantidade_total_mes")
	private BigDecimal quantidadeTotalMes;

	@Column(name="quantidade_total_anterior")
	private BigDecimal quantidadeTotalAnterior;

	@Column(name="quantidade_total_geral")
	private BigDecimal quantidadeTotalGeral;

	@ManyToOne 
	@JoinColumn(name="id_nfe_cana")
	private NfeCanaModel nfeCanaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDia() { 
		return this.dia; 
	} 

	public void setDia(String dia) { 
		this.dia = dia; 
	} 

	public BigDecimal getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(BigDecimal quantidade) { 
		this.quantidade = quantidade; 
	} 

	public BigDecimal getQuantidadeTotalMes() { 
		return this.quantidadeTotalMes; 
	} 

	public void setQuantidadeTotalMes(BigDecimal quantidadeTotalMes) { 
		this.quantidadeTotalMes = quantidadeTotalMes; 
	} 

	public BigDecimal getQuantidadeTotalAnterior() { 
		return this.quantidadeTotalAnterior; 
	} 

	public void setQuantidadeTotalAnterior(BigDecimal quantidadeTotalAnterior) { 
		this.quantidadeTotalAnterior = quantidadeTotalAnterior; 
	} 

	public BigDecimal getQuantidadeTotalGeral() { 
		return this.quantidadeTotalGeral; 
	} 

	public void setQuantidadeTotalGeral(BigDecimal quantidadeTotalGeral) { 
		this.quantidadeTotalGeral = quantidadeTotalGeral; 
	} 

	public NfeCanaModel getNfeCanaModel() { 
	return this.nfeCanaModel; 
	} 

	public void setNfeCanaModel(NfeCanaModel nfeCanaModel) { 
	this.nfeCanaModel = nfeCanaModel; 
	} 

		
}