package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_importacao_detalhe")
@NamedQuery(name="NfeImportacaoDetalheModel.findAll", query="SELECT t FROM NfeImportacaoDetalheModel t")
public class NfeImportacaoDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeImportacaoDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_adicao")
	private Integer numeroAdicao;

	@Column(name="numero_sequencial")
	private Integer numeroSequencial;

	@Column(name="codigo_fabricante_estrangeiro")
	private String codigoFabricanteEstrangeiro;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="drawback")
	private Integer drawback;

	@ManyToOne 
	@JoinColumn(name="id_nfe_declaracao_importacao")
	private NfeDeclaracaoImportacaoModel nfeDeclaracaoImportacaoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumeroAdicao() { 
		return this.numeroAdicao; 
	} 

	public void setNumeroAdicao(Integer numeroAdicao) { 
		this.numeroAdicao = numeroAdicao; 
	} 

	public Integer getNumeroSequencial() { 
		return this.numeroSequencial; 
	} 

	public void setNumeroSequencial(Integer numeroSequencial) { 
		this.numeroSequencial = numeroSequencial; 
	} 

	public String getCodigoFabricanteEstrangeiro() { 
		return this.codigoFabricanteEstrangeiro; 
	} 

	public void setCodigoFabricanteEstrangeiro(String codigoFabricanteEstrangeiro) { 
		this.codigoFabricanteEstrangeiro = codigoFabricanteEstrangeiro; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public Integer getDrawback() { 
		return this.drawback; 
	} 

	public void setDrawback(Integer drawback) { 
		this.drawback = drawback; 
	} 

	public NfeDeclaracaoImportacaoModel getNfeDeclaracaoImportacaoModel() { 
	return this.nfeDeclaracaoImportacaoModel; 
	} 

	public void setNfeDeclaracaoImportacaoModel(NfeDeclaracaoImportacaoModel nfeDeclaracaoImportacaoModel) { 
	this.nfeDeclaracaoImportacaoModel = nfeDeclaracaoImportacaoModel; 
	} 

		
}