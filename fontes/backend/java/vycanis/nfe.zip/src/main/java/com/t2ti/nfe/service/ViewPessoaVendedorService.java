package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.ViewPessoaVendedorModel;
import com.t2ti.nfe.repository.ViewPessoaVendedorRepository;

@Service
public class ViewPessoaVendedorService {

	@Autowired
	private ViewPessoaVendedorRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ViewPessoaVendedorModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ViewPessoaVendedorModel> getList(Filter filter) {
		String sql = "select * from view_pessoa_vendedor where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewPessoaVendedorModel.class);
		return query.getResultList();
	}

	public ViewPessoaVendedorModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ViewPessoaVendedorModel save(ViewPessoaVendedorModel obj) {
		ViewPessoaVendedorModel viewPessoaVendedorModel = repository.save(obj);
		return viewPessoaVendedorModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ViewPessoaVendedorModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ViewPessoaVendedor] - Exception: " + e.getMessage());
		}
	}

}