package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_processo_referenciado")
@NamedQuery(name="NfeProcessoReferenciadoModel.findAll", query="SELECT t FROM NfeProcessoReferenciadoModel t")
public class NfeProcessoReferenciadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeProcessoReferenciadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="identificador")
	private String identificador;

	@Column(name="origem")
	private String origem;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getIdentificador() { 
		return this.identificador; 
	} 

	public void setIdentificador(String identificador) { 
		this.identificador = identificador; 
	} 

	public String getOrigem() { 
		return this.origem; 
	} 

	public void setOrigem(String origem) { 
		this.origem = origem; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}