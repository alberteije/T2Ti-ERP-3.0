package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_cana_deducoes_safra")
@NamedQuery(name="NfeCanaDeducoesSafraModel.findAll", query="SELECT t FROM NfeCanaDeducoesSafraModel t")
public class NfeCanaDeducoesSafraModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeCanaDeducoesSafraModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="decricao")
	private String decricao;

	@Column(name="valor_deducao")
	private BigDecimal valorDeducao;

	@Column(name="valor_fornecimento")
	private BigDecimal valorFornecimento;

	@Column(name="valor_total_deducao")
	private BigDecimal valorTotalDeducao;

	@Column(name="valor_liquido_fornecimento")
	private BigDecimal valorLiquidoFornecimento;

	@ManyToOne 
	@JoinColumn(name="id_nfe_cana")
	private NfeCanaModel nfeCanaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDecricao() { 
		return this.decricao; 
	} 

	public void setDecricao(String decricao) { 
		this.decricao = decricao; 
	} 

	public BigDecimal getValorDeducao() { 
		return this.valorDeducao; 
	} 

	public void setValorDeducao(BigDecimal valorDeducao) { 
		this.valorDeducao = valorDeducao; 
	} 

	public BigDecimal getValorFornecimento() { 
		return this.valorFornecimento; 
	} 

	public void setValorFornecimento(BigDecimal valorFornecimento) { 
		this.valorFornecimento = valorFornecimento; 
	} 

	public BigDecimal getValorTotalDeducao() { 
		return this.valorTotalDeducao; 
	} 

	public void setValorTotalDeducao(BigDecimal valorTotalDeducao) { 
		this.valorTotalDeducao = valorTotalDeducao; 
	} 

	public BigDecimal getValorLiquidoFornecimento() { 
		return this.valorLiquidoFornecimento; 
	} 

	public void setValorLiquidoFornecimento(BigDecimal valorLiquidoFornecimento) { 
		this.valorLiquidoFornecimento = valorLiquidoFornecimento; 
	} 

	public NfeCanaModel getNfeCanaModel() { 
	return this.nfeCanaModel; 
	} 

	public void setNfeCanaModel(NfeCanaModel nfeCanaModel) { 
	this.nfeCanaModel = nfeCanaModel; 
	} 

		
}