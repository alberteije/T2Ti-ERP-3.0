package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_cupom_fiscal_referenciado")
@NamedQuery(name="NfeCupomFiscalReferenciadoModel.findAll", query="SELECT t FROM NfeCupomFiscalReferenciadoModel t")
public class NfeCupomFiscalReferenciadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeCupomFiscalReferenciadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="modelo_documento_fiscal")
	private String modeloDocumentoFiscal;

	@Column(name="numero_ordem_ecf")
	private Integer numeroOrdemEcf;

	@Column(name="coo")
	private Integer coo;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao_cupom")
	private Date dataEmissaoCupom;

	@Column(name="numero_caixa")
	private Integer numeroCaixa;

	@Column(name="numero_serie_ecf")
	private String numeroSerieEcf;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getModeloDocumentoFiscal() { 
		return this.modeloDocumentoFiscal; 
	} 

	public void setModeloDocumentoFiscal(String modeloDocumentoFiscal) { 
		this.modeloDocumentoFiscal = modeloDocumentoFiscal; 
	} 

	public Integer getNumeroOrdemEcf() { 
		return this.numeroOrdemEcf; 
	} 

	public void setNumeroOrdemEcf(Integer numeroOrdemEcf) { 
		this.numeroOrdemEcf = numeroOrdemEcf; 
	} 

	public Integer getCoo() { 
		return this.coo; 
	} 

	public void setCoo(Integer coo) { 
		this.coo = coo; 
	} 

	public Date getDataEmissaoCupom() { 
		return this.dataEmissaoCupom; 
	} 

	public void setDataEmissaoCupom(Date dataEmissaoCupom) { 
		this.dataEmissaoCupom = dataEmissaoCupom; 
	} 

	public Integer getNumeroCaixa() { 
		return this.numeroCaixa; 
	} 

	public void setNumeroCaixa(Integer numeroCaixa) { 
		this.numeroCaixa = numeroCaixa; 
	} 

	public String getNumeroSerieEcf() { 
		return this.numeroSerieEcf; 
	} 

	public void setNumeroSerieEcf(String numeroSerieEcf) { 
		this.numeroSerieEcf = numeroSerieEcf; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}