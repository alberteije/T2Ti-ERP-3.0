package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_item_rastreado")
@NamedQuery(name="NfeItemRastreadoModel.findAll", query="SELECT t FROM NfeItemRastreadoModel t")
public class NfeItemRastreadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeItemRastreadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_lote")
	private String numeroLote;

	@Column(name="quantidade_itens")
	private BigDecimal quantidadeItens;

	@Temporal(TemporalType.DATE)
@Column(name="data_fabricacao")
	private Date dataFabricacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_validade")
	private Date dataValidade;

	@Column(name="codigo_agregacao")
	private String codigoAgregacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumeroLote() { 
		return this.numeroLote; 
	} 

	public void setNumeroLote(String numeroLote) { 
		this.numeroLote = numeroLote; 
	} 

	public BigDecimal getQuantidadeItens() { 
		return this.quantidadeItens; 
	} 

	public void setQuantidadeItens(BigDecimal quantidadeItens) { 
		this.quantidadeItens = quantidadeItens; 
	} 

	public Date getDataFabricacao() { 
		return this.dataFabricacao; 
	} 

	public void setDataFabricacao(Date dataFabricacao) { 
		this.dataFabricacao = dataFabricacao; 
	} 

	public Date getDataValidade() { 
		return this.dataValidade; 
	} 

	public void setDataValidade(Date dataValidade) { 
		this.dataValidade = dataValidade; 
	} 

	public String getCodigoAgregacao() { 
		return this.codigoAgregacao; 
	} 

	public void setCodigoAgregacao(String codigoAgregacao) { 
		this.codigoAgregacao = codigoAgregacao; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}