package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_cabecalho")
@NamedQuery(name="NfeCabecalhoModel.findAll", query="SELECT t FROM NfeCabecalhoModel t")
public class NfeCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="uf_emitente")
	private String ufEmitente;

	@Column(name="codigo_numerico")
	private String codigoNumerico;

	@Column(name="natureza_operacao")
	private String naturezaOperacao;

	@Column(name="codigo_modelo")
	private String codigoModelo;

	@Column(name="serie")
	private String serie;

	@Column(name="numero")
	private String numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_emissao")
	private Date dataHoraEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_entrada_saida")
	private Date dataHoraEntradaSaida;

	@Column(name="tipo_operacao")
	private String tipoOperacao;

	@Column(name="local_destino")
	private String localDestino;

	@Column(name="codigo_municipio")
	private Integer codigoMunicipio;

	@Column(name="formato_impressao_danfe")
	private String formatoImpressaoDanfe;

	@Column(name="tipo_emissao")
	private String tipoEmissao;

	@Column(name="chave_acesso")
	private String chaveAcesso;

	@Column(name="digito_chave_acesso")
	private String digitoChaveAcesso;

	@Column(name="ambiente")
	private String ambiente;

	@Column(name="finalidade_emissao")
	private String finalidadeEmissao;

	@Column(name="consumidor_operacao")
	private String consumidorOperacao;

	@Column(name="consumidor_presenca")
	private String consumidorPresenca;

	@Column(name="processo_emissao")
	private String processoEmissao;

	@Column(name="versao_processo_emissao")
	private String versaoProcessoEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="data_entrada_contingencia")
	private Date dataEntradaContingencia;

	@Column(name="justificativa_contingencia")
	private String justificativaContingencia;

	@Column(name="base_calculo_icms")
	private BigDecimal baseCalculoIcms;

	@Column(name="valor_icms")
	private BigDecimal valorIcms;

	@Column(name="valor_icms_desonerado")
	private BigDecimal valorIcmsDesonerado;

	@Column(name="total_icms_fcp_uf_destino")
	private BigDecimal totalIcmsFcpUfDestino;

	@Column(name="total_icms_interestadual_uf_destino")
	private BigDecimal totalIcmsInterestadualUfDestino;

	@Column(name="total_icms_interestadual_uf_remetente")
	private BigDecimal totalIcmsInterestadualUfRemetente;

	@Column(name="valor_total_fcp")
	private BigDecimal valorTotalFcp;

	@Column(name="base_calculo_icms_st")
	private BigDecimal baseCalculoIcmsSt;

	@Column(name="valor_icms_st")
	private BigDecimal valorIcmsSt;

	@Column(name="valor_total_fcp_st")
	private BigDecimal valorTotalFcpSt;

	@Column(name="valor_total_fcp_st_retido")
	private BigDecimal valorTotalFcpStRetido;

	@Column(name="valor_total_produtos")
	private BigDecimal valorTotalProdutos;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@Column(name="valor_seguro")
	private BigDecimal valorSeguro;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_imposto_importacao")
	private BigDecimal valorImpostoImportacao;

	@Column(name="valor_ipi")
	private BigDecimal valorIpi;

	@Column(name="valor_ipi_devolvido")
	private BigDecimal valorIpiDevolvido;

	@Column(name="valor_pis")
	private BigDecimal valorPis;

	@Column(name="valor_cofins")
	private BigDecimal valorCofins;

	@Column(name="valor_despesas_acessorias")
	private BigDecimal valorDespesasAcessorias;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="valor_total_tributos")
	private BigDecimal valorTotalTributos;

	@Column(name="valor_servicos")
	private BigDecimal valorServicos;

	@Column(name="base_calculo_issqn")
	private BigDecimal baseCalculoIssqn;

	@Column(name="valor_issqn")
	private BigDecimal valorIssqn;

	@Column(name="valor_pis_issqn")
	private BigDecimal valorPisIssqn;

	@Column(name="valor_cofins_issqn")
	private BigDecimal valorCofinsIssqn;

	@Temporal(TemporalType.DATE)
@Column(name="data_prestacao_servico")
	private Date dataPrestacaoServico;

	@Column(name="valor_deducao_issqn")
	private BigDecimal valorDeducaoIssqn;

	@Column(name="outras_retencoes_issqn")
	private BigDecimal outrasRetencoesIssqn;

	@Column(name="desconto_incondicionado_issqn")
	private BigDecimal descontoIncondicionadoIssqn;

	@Column(name="desconto_condicionado_issqn")
	private BigDecimal descontoCondicionadoIssqn;

	@Column(name="total_retencao_issqn")
	private BigDecimal totalRetencaoIssqn;

	@Column(name="regime_especial_tributacao")
	private String regimeEspecialTributacao;

	@Column(name="valor_retido_pis")
	private BigDecimal valorRetidoPis;

	@Column(name="valor_retido_cofins")
	private BigDecimal valorRetidoCofins;

	@Column(name="valor_retido_csll")
	private BigDecimal valorRetidoCsll;

	@Column(name="base_calculo_irrf")
	private BigDecimal baseCalculoIrrf;

	@Column(name="valor_retido_irrf")
	private BigDecimal valorRetidoIrrf;

	@Column(name="base_calculo_previdencia")
	private BigDecimal baseCalculoPrevidencia;

	@Column(name="valor_retido_previdencia")
	private BigDecimal valorRetidoPrevidencia;

	@Column(name="informacoes_add_fisco")
	private String informacoesAddFisco;

	@Column(name="informacoes_add_contribuinte")
	private String informacoesAddContribuinte;

	@Column(name="comex_uf_embarque")
	private String comexUfEmbarque;

	@Column(name="comex_local_embarque")
	private String comexLocalEmbarque;

	@Column(name="comex_local_despacho")
	private String comexLocalDespacho;

	@Column(name="compra_nota_empenho")
	private String compraNotaEmpenho;

	@Column(name="compra_pedido")
	private String compraPedido;

	@Column(name="compra_contrato")
	private String compraContrato;

	@Column(name="qrcode")
	private String qrcode;

	@Column(name="url_chave")
	private String urlChave;

	@Column(name="status_nota")
	private String statusNota;

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeReferenciadaModel> nfeReferenciadaModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeEmitenteModel> nfeEmitenteModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeDestinatarioModel> nfeDestinatarioModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeLocalRetiradaModel> nfeLocalRetiradaModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeLocalEntregaModel> nfeLocalEntregaModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeTransporteModel> nfeTransporteModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeFaturaModel> nfeFaturaModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeCanaModel> nfeCanaModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeProdRuralReferenciadaModel> nfeProdRuralReferenciadaModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeNfReferenciadaModel> nfeNfReferenciadaModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeProcessoReferenciadoModel> nfeProcessoReferenciadoModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeAcessoXmlModel> nfeAcessoXmlModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeInformacaoPagamentoModel> nfeInformacaoPagamentoModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeResponsavelTecnicoModel> nfeResponsavelTecnicoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_tribut_operacao_fiscal")
	private TributOperacaoFiscalModel tributOperacaoFiscalModel; 

	@ManyToOne 
	@JoinColumn(name="id_venda_cabecalho")
	private VendaCabecalhoModel vendaCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_cliente")
	private ViewPessoaClienteModel viewPessoaClienteModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_fornecedor")
	private ViewPessoaFornecedorModel viewPessoaFornecedorModel; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeCteReferenciadoModel> nfeCteReferenciadoModelList; 

	@OneToMany(mappedBy = "nfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<NfeCupomFiscalReferenciadoModel> nfeCupomFiscalReferenciadoModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getUfEmitente() { 
		return this.ufEmitente; 
	} 

	public void setUfEmitente(String ufEmitente) { 
		this.ufEmitente = ufEmitente; 
	} 

	public String getCodigoNumerico() { 
		return this.codigoNumerico; 
	} 

	public void setCodigoNumerico(String codigoNumerico) { 
		this.codigoNumerico = codigoNumerico; 
	} 

	public String getNaturezaOperacao() { 
		return this.naturezaOperacao; 
	} 

	public void setNaturezaOperacao(String naturezaOperacao) { 
		this.naturezaOperacao = naturezaOperacao; 
	} 

	public String getCodigoModelo() { 
		return this.codigoModelo; 
	} 

	public void setCodigoModelo(String codigoModelo) { 
		this.codigoModelo = codigoModelo; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public Date getDataHoraEmissao() { 
		return this.dataHoraEmissao; 
	} 

	public void setDataHoraEmissao(Date dataHoraEmissao) { 
		this.dataHoraEmissao = dataHoraEmissao; 
	} 

	public Date getDataHoraEntradaSaida() { 
		return this.dataHoraEntradaSaida; 
	} 

	public void setDataHoraEntradaSaida(Date dataHoraEntradaSaida) { 
		this.dataHoraEntradaSaida = dataHoraEntradaSaida; 
	} 

	public String getTipoOperacao() { 
		return this.tipoOperacao; 
	} 

	public void setTipoOperacao(String tipoOperacao) { 
		this.tipoOperacao = tipoOperacao; 
	} 

	public String getLocalDestino() { 
		return this.localDestino; 
	} 

	public void setLocalDestino(String localDestino) { 
		this.localDestino = localDestino; 
	} 

	public Integer getCodigoMunicipio() { 
		return this.codigoMunicipio; 
	} 

	public void setCodigoMunicipio(Integer codigoMunicipio) { 
		this.codigoMunicipio = codigoMunicipio; 
	} 

	public String getFormatoImpressaoDanfe() { 
		return this.formatoImpressaoDanfe; 
	} 

	public void setFormatoImpressaoDanfe(String formatoImpressaoDanfe) { 
		this.formatoImpressaoDanfe = formatoImpressaoDanfe; 
	} 

	public String getTipoEmissao() { 
		return this.tipoEmissao; 
	} 

	public void setTipoEmissao(String tipoEmissao) { 
		this.tipoEmissao = tipoEmissao; 
	} 

	public String getChaveAcesso() { 
		return this.chaveAcesso; 
	} 

	public void setChaveAcesso(String chaveAcesso) { 
		this.chaveAcesso = chaveAcesso; 
	} 

	public String getDigitoChaveAcesso() { 
		return this.digitoChaveAcesso; 
	} 

	public void setDigitoChaveAcesso(String digitoChaveAcesso) { 
		this.digitoChaveAcesso = digitoChaveAcesso; 
	} 

	public String getAmbiente() { 
		return this.ambiente; 
	} 

	public void setAmbiente(String ambiente) { 
		this.ambiente = ambiente; 
	} 

	public String getFinalidadeEmissao() { 
		return this.finalidadeEmissao; 
	} 

	public void setFinalidadeEmissao(String finalidadeEmissao) { 
		this.finalidadeEmissao = finalidadeEmissao; 
	} 

	public String getConsumidorOperacao() { 
		return this.consumidorOperacao; 
	} 

	public void setConsumidorOperacao(String consumidorOperacao) { 
		this.consumidorOperacao = consumidorOperacao; 
	} 

	public String getConsumidorPresenca() { 
		return this.consumidorPresenca; 
	} 

	public void setConsumidorPresenca(String consumidorPresenca) { 
		this.consumidorPresenca = consumidorPresenca; 
	} 

	public String getProcessoEmissao() { 
		return this.processoEmissao; 
	} 

	public void setProcessoEmissao(String processoEmissao) { 
		this.processoEmissao = processoEmissao; 
	} 

	public String getVersaoProcessoEmissao() { 
		return this.versaoProcessoEmissao; 
	} 

	public void setVersaoProcessoEmissao(String versaoProcessoEmissao) { 
		this.versaoProcessoEmissao = versaoProcessoEmissao; 
	} 

	public Date getDataEntradaContingencia() { 
		return this.dataEntradaContingencia; 
	} 

	public void setDataEntradaContingencia(Date dataEntradaContingencia) { 
		this.dataEntradaContingencia = dataEntradaContingencia; 
	} 

	public String getJustificativaContingencia() { 
		return this.justificativaContingencia; 
	} 

	public void setJustificativaContingencia(String justificativaContingencia) { 
		this.justificativaContingencia = justificativaContingencia; 
	} 

	public BigDecimal getBaseCalculoIcms() { 
		return this.baseCalculoIcms; 
	} 

	public void setBaseCalculoIcms(BigDecimal baseCalculoIcms) { 
		this.baseCalculoIcms = baseCalculoIcms; 
	} 

	public BigDecimal getValorIcms() { 
		return this.valorIcms; 
	} 

	public void setValorIcms(BigDecimal valorIcms) { 
		this.valorIcms = valorIcms; 
	} 

	public BigDecimal getValorIcmsDesonerado() { 
		return this.valorIcmsDesonerado; 
	} 

	public void setValorIcmsDesonerado(BigDecimal valorIcmsDesonerado) { 
		this.valorIcmsDesonerado = valorIcmsDesonerado; 
	} 

	public BigDecimal getTotalIcmsFcpUfDestino() { 
		return this.totalIcmsFcpUfDestino; 
	} 

	public void setTotalIcmsFcpUfDestino(BigDecimal totalIcmsFcpUfDestino) { 
		this.totalIcmsFcpUfDestino = totalIcmsFcpUfDestino; 
	} 

	public BigDecimal getTotalIcmsInterestadualUfDestino() { 
		return this.totalIcmsInterestadualUfDestino; 
	} 

	public void setTotalIcmsInterestadualUfDestino(BigDecimal totalIcmsInterestadualUfDestino) { 
		this.totalIcmsInterestadualUfDestino = totalIcmsInterestadualUfDestino; 
	} 

	public BigDecimal getTotalIcmsInterestadualUfRemetente() { 
		return this.totalIcmsInterestadualUfRemetente; 
	} 

	public void setTotalIcmsInterestadualUfRemetente(BigDecimal totalIcmsInterestadualUfRemetente) { 
		this.totalIcmsInterestadualUfRemetente = totalIcmsInterestadualUfRemetente; 
	} 

	public BigDecimal getValorTotalFcp() { 
		return this.valorTotalFcp; 
	} 

	public void setValorTotalFcp(BigDecimal valorTotalFcp) { 
		this.valorTotalFcp = valorTotalFcp; 
	} 

	public BigDecimal getBaseCalculoIcmsSt() { 
		return this.baseCalculoIcmsSt; 
	} 

	public void setBaseCalculoIcmsSt(BigDecimal baseCalculoIcmsSt) { 
		this.baseCalculoIcmsSt = baseCalculoIcmsSt; 
	} 

	public BigDecimal getValorIcmsSt() { 
		return this.valorIcmsSt; 
	} 

	public void setValorIcmsSt(BigDecimal valorIcmsSt) { 
		this.valorIcmsSt = valorIcmsSt; 
	} 

	public BigDecimal getValorTotalFcpSt() { 
		return this.valorTotalFcpSt; 
	} 

	public void setValorTotalFcpSt(BigDecimal valorTotalFcpSt) { 
		this.valorTotalFcpSt = valorTotalFcpSt; 
	} 

	public BigDecimal getValorTotalFcpStRetido() { 
		return this.valorTotalFcpStRetido; 
	} 

	public void setValorTotalFcpStRetido(BigDecimal valorTotalFcpStRetido) { 
		this.valorTotalFcpStRetido = valorTotalFcpStRetido; 
	} 

	public BigDecimal getValorTotalProdutos() { 
		return this.valorTotalProdutos; 
	} 

	public void setValorTotalProdutos(BigDecimal valorTotalProdutos) { 
		this.valorTotalProdutos = valorTotalProdutos; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public BigDecimal getValorSeguro() { 
		return this.valorSeguro; 
	} 

	public void setValorSeguro(BigDecimal valorSeguro) { 
		this.valorSeguro = valorSeguro; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorImpostoImportacao() { 
		return this.valorImpostoImportacao; 
	} 

	public void setValorImpostoImportacao(BigDecimal valorImpostoImportacao) { 
		this.valorImpostoImportacao = valorImpostoImportacao; 
	} 

	public BigDecimal getValorIpi() { 
		return this.valorIpi; 
	} 

	public void setValorIpi(BigDecimal valorIpi) { 
		this.valorIpi = valorIpi; 
	} 

	public BigDecimal getValorIpiDevolvido() { 
		return this.valorIpiDevolvido; 
	} 

	public void setValorIpiDevolvido(BigDecimal valorIpiDevolvido) { 
		this.valorIpiDevolvido = valorIpiDevolvido; 
	} 

	public BigDecimal getValorPis() { 
		return this.valorPis; 
	} 

	public void setValorPis(BigDecimal valorPis) { 
		this.valorPis = valorPis; 
	} 

	public BigDecimal getValorCofins() { 
		return this.valorCofins; 
	} 

	public void setValorCofins(BigDecimal valorCofins) { 
		this.valorCofins = valorCofins; 
	} 

	public BigDecimal getValorDespesasAcessorias() { 
		return this.valorDespesasAcessorias; 
	} 

	public void setValorDespesasAcessorias(BigDecimal valorDespesasAcessorias) { 
		this.valorDespesasAcessorias = valorDespesasAcessorias; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public BigDecimal getValorTotalTributos() { 
		return this.valorTotalTributos; 
	} 

	public void setValorTotalTributos(BigDecimal valorTotalTributos) { 
		this.valorTotalTributos = valorTotalTributos; 
	} 

	public BigDecimal getValorServicos() { 
		return this.valorServicos; 
	} 

	public void setValorServicos(BigDecimal valorServicos) { 
		this.valorServicos = valorServicos; 
	} 

	public BigDecimal getBaseCalculoIssqn() { 
		return this.baseCalculoIssqn; 
	} 

	public void setBaseCalculoIssqn(BigDecimal baseCalculoIssqn) { 
		this.baseCalculoIssqn = baseCalculoIssqn; 
	} 

	public BigDecimal getValorIssqn() { 
		return this.valorIssqn; 
	} 

	public void setValorIssqn(BigDecimal valorIssqn) { 
		this.valorIssqn = valorIssqn; 
	} 

	public BigDecimal getValorPisIssqn() { 
		return this.valorPisIssqn; 
	} 

	public void setValorPisIssqn(BigDecimal valorPisIssqn) { 
		this.valorPisIssqn = valorPisIssqn; 
	} 

	public BigDecimal getValorCofinsIssqn() { 
		return this.valorCofinsIssqn; 
	} 

	public void setValorCofinsIssqn(BigDecimal valorCofinsIssqn) { 
		this.valorCofinsIssqn = valorCofinsIssqn; 
	} 

	public Date getDataPrestacaoServico() { 
		return this.dataPrestacaoServico; 
	} 

	public void setDataPrestacaoServico(Date dataPrestacaoServico) { 
		this.dataPrestacaoServico = dataPrestacaoServico; 
	} 

	public BigDecimal getValorDeducaoIssqn() { 
		return this.valorDeducaoIssqn; 
	} 

	public void setValorDeducaoIssqn(BigDecimal valorDeducaoIssqn) { 
		this.valorDeducaoIssqn = valorDeducaoIssqn; 
	} 

	public BigDecimal getOutrasRetencoesIssqn() { 
		return this.outrasRetencoesIssqn; 
	} 

	public void setOutrasRetencoesIssqn(BigDecimal outrasRetencoesIssqn) { 
		this.outrasRetencoesIssqn = outrasRetencoesIssqn; 
	} 

	public BigDecimal getDescontoIncondicionadoIssqn() { 
		return this.descontoIncondicionadoIssqn; 
	} 

	public void setDescontoIncondicionadoIssqn(BigDecimal descontoIncondicionadoIssqn) { 
		this.descontoIncondicionadoIssqn = descontoIncondicionadoIssqn; 
	} 

	public BigDecimal getDescontoCondicionadoIssqn() { 
		return this.descontoCondicionadoIssqn; 
	} 

	public void setDescontoCondicionadoIssqn(BigDecimal descontoCondicionadoIssqn) { 
		this.descontoCondicionadoIssqn = descontoCondicionadoIssqn; 
	} 

	public BigDecimal getTotalRetencaoIssqn() { 
		return this.totalRetencaoIssqn; 
	} 

	public void setTotalRetencaoIssqn(BigDecimal totalRetencaoIssqn) { 
		this.totalRetencaoIssqn = totalRetencaoIssqn; 
	} 

	public String getRegimeEspecialTributacao() { 
		return this.regimeEspecialTributacao; 
	} 

	public void setRegimeEspecialTributacao(String regimeEspecialTributacao) { 
		this.regimeEspecialTributacao = regimeEspecialTributacao; 
	} 

	public BigDecimal getValorRetidoPis() { 
		return this.valorRetidoPis; 
	} 

	public void setValorRetidoPis(BigDecimal valorRetidoPis) { 
		this.valorRetidoPis = valorRetidoPis; 
	} 

	public BigDecimal getValorRetidoCofins() { 
		return this.valorRetidoCofins; 
	} 

	public void setValorRetidoCofins(BigDecimal valorRetidoCofins) { 
		this.valorRetidoCofins = valorRetidoCofins; 
	} 

	public BigDecimal getValorRetidoCsll() { 
		return this.valorRetidoCsll; 
	} 

	public void setValorRetidoCsll(BigDecimal valorRetidoCsll) { 
		this.valorRetidoCsll = valorRetidoCsll; 
	} 

	public BigDecimal getBaseCalculoIrrf() { 
		return this.baseCalculoIrrf; 
	} 

	public void setBaseCalculoIrrf(BigDecimal baseCalculoIrrf) { 
		this.baseCalculoIrrf = baseCalculoIrrf; 
	} 

	public BigDecimal getValorRetidoIrrf() { 
		return this.valorRetidoIrrf; 
	} 

	public void setValorRetidoIrrf(BigDecimal valorRetidoIrrf) { 
		this.valorRetidoIrrf = valorRetidoIrrf; 
	} 

	public BigDecimal getBaseCalculoPrevidencia() { 
		return this.baseCalculoPrevidencia; 
	} 

	public void setBaseCalculoPrevidencia(BigDecimal baseCalculoPrevidencia) { 
		this.baseCalculoPrevidencia = baseCalculoPrevidencia; 
	} 

	public BigDecimal getValorRetidoPrevidencia() { 
		return this.valorRetidoPrevidencia; 
	} 

	public void setValorRetidoPrevidencia(BigDecimal valorRetidoPrevidencia) { 
		this.valorRetidoPrevidencia = valorRetidoPrevidencia; 
	} 

	public String getInformacoesAddFisco() { 
		return this.informacoesAddFisco; 
	} 

	public void setInformacoesAddFisco(String informacoesAddFisco) { 
		this.informacoesAddFisco = informacoesAddFisco; 
	} 

	public String getInformacoesAddContribuinte() { 
		return this.informacoesAddContribuinte; 
	} 

	public void setInformacoesAddContribuinte(String informacoesAddContribuinte) { 
		this.informacoesAddContribuinte = informacoesAddContribuinte; 
	} 

	public String getComexUfEmbarque() { 
		return this.comexUfEmbarque; 
	} 

	public void setComexUfEmbarque(String comexUfEmbarque) { 
		this.comexUfEmbarque = comexUfEmbarque; 
	} 

	public String getComexLocalEmbarque() { 
		return this.comexLocalEmbarque; 
	} 

	public void setComexLocalEmbarque(String comexLocalEmbarque) { 
		this.comexLocalEmbarque = comexLocalEmbarque; 
	} 

	public String getComexLocalDespacho() { 
		return this.comexLocalDespacho; 
	} 

	public void setComexLocalDespacho(String comexLocalDespacho) { 
		this.comexLocalDespacho = comexLocalDespacho; 
	} 

	public String getCompraNotaEmpenho() { 
		return this.compraNotaEmpenho; 
	} 

	public void setCompraNotaEmpenho(String compraNotaEmpenho) { 
		this.compraNotaEmpenho = compraNotaEmpenho; 
	} 

	public String getCompraPedido() { 
		return this.compraPedido; 
	} 

	public void setCompraPedido(String compraPedido) { 
		this.compraPedido = compraPedido; 
	} 

	public String getCompraContrato() { 
		return this.compraContrato; 
	} 

	public void setCompraContrato(String compraContrato) { 
		this.compraContrato = compraContrato; 
	} 

	public String getQrcode() { 
		return this.qrcode; 
	} 

	public void setQrcode(String qrcode) { 
		this.qrcode = qrcode; 
	} 

	public String getUrlChave() { 
		return this.urlChave; 
	} 

	public void setUrlChave(String urlChave) { 
		this.urlChave = urlChave; 
	} 

	public String getStatusNota() { 
		return this.statusNota; 
	} 

	public void setStatusNota(String statusNota) { 
		this.statusNota = statusNota; 
	} 

	public Set<NfeReferenciadaModel> getNfeReferenciadaModelList() { 
	return this.nfeReferenciadaModelList; 
	} 

	public void setNfeReferenciadaModelList(Set<NfeReferenciadaModel> nfeReferenciadaModelList) { 
	this.nfeReferenciadaModelList = nfeReferenciadaModelList; 
		for (NfeReferenciadaModel nfeReferenciadaModel : nfeReferenciadaModelList) { 
			nfeReferenciadaModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeEmitenteModel> getNfeEmitenteModelList() { 
	return this.nfeEmitenteModelList; 
	} 

	public void setNfeEmitenteModelList(Set<NfeEmitenteModel> nfeEmitenteModelList) { 
	this.nfeEmitenteModelList = nfeEmitenteModelList; 
		for (NfeEmitenteModel nfeEmitenteModel : nfeEmitenteModelList) { 
			nfeEmitenteModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeDestinatarioModel> getNfeDestinatarioModelList() { 
	return this.nfeDestinatarioModelList; 
	} 

	public void setNfeDestinatarioModelList(Set<NfeDestinatarioModel> nfeDestinatarioModelList) { 
	this.nfeDestinatarioModelList = nfeDestinatarioModelList; 
		for (NfeDestinatarioModel nfeDestinatarioModel : nfeDestinatarioModelList) { 
			nfeDestinatarioModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeLocalRetiradaModel> getNfeLocalRetiradaModelList() { 
	return this.nfeLocalRetiradaModelList; 
	} 

	public void setNfeLocalRetiradaModelList(Set<NfeLocalRetiradaModel> nfeLocalRetiradaModelList) { 
	this.nfeLocalRetiradaModelList = nfeLocalRetiradaModelList; 
		for (NfeLocalRetiradaModel nfeLocalRetiradaModel : nfeLocalRetiradaModelList) { 
			nfeLocalRetiradaModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeLocalEntregaModel> getNfeLocalEntregaModelList() { 
	return this.nfeLocalEntregaModelList; 
	} 

	public void setNfeLocalEntregaModelList(Set<NfeLocalEntregaModel> nfeLocalEntregaModelList) { 
	this.nfeLocalEntregaModelList = nfeLocalEntregaModelList; 
		for (NfeLocalEntregaModel nfeLocalEntregaModel : nfeLocalEntregaModelList) { 
			nfeLocalEntregaModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeTransporteModel> getNfeTransporteModelList() { 
	return this.nfeTransporteModelList; 
	} 

	public void setNfeTransporteModelList(Set<NfeTransporteModel> nfeTransporteModelList) { 
	this.nfeTransporteModelList = nfeTransporteModelList; 
		for (NfeTransporteModel nfeTransporteModel : nfeTransporteModelList) { 
			nfeTransporteModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeFaturaModel> getNfeFaturaModelList() { 
	return this.nfeFaturaModelList; 
	} 

	public void setNfeFaturaModelList(Set<NfeFaturaModel> nfeFaturaModelList) { 
	this.nfeFaturaModelList = nfeFaturaModelList; 
		for (NfeFaturaModel nfeFaturaModel : nfeFaturaModelList) { 
			nfeFaturaModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeCanaModel> getNfeCanaModelList() { 
	return this.nfeCanaModelList; 
	} 

	public void setNfeCanaModelList(Set<NfeCanaModel> nfeCanaModelList) { 
	this.nfeCanaModelList = nfeCanaModelList; 
		for (NfeCanaModel nfeCanaModel : nfeCanaModelList) { 
			nfeCanaModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeProdRuralReferenciadaModel> getNfeProdRuralReferenciadaModelList() { 
	return this.nfeProdRuralReferenciadaModelList; 
	} 

	public void setNfeProdRuralReferenciadaModelList(Set<NfeProdRuralReferenciadaModel> nfeProdRuralReferenciadaModelList) { 
	this.nfeProdRuralReferenciadaModelList = nfeProdRuralReferenciadaModelList; 
		for (NfeProdRuralReferenciadaModel nfeProdRuralReferenciadaModel : nfeProdRuralReferenciadaModelList) { 
			nfeProdRuralReferenciadaModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeNfReferenciadaModel> getNfeNfReferenciadaModelList() { 
	return this.nfeNfReferenciadaModelList; 
	} 

	public void setNfeNfReferenciadaModelList(Set<NfeNfReferenciadaModel> nfeNfReferenciadaModelList) { 
	this.nfeNfReferenciadaModelList = nfeNfReferenciadaModelList; 
		for (NfeNfReferenciadaModel nfeNfReferenciadaModel : nfeNfReferenciadaModelList) { 
			nfeNfReferenciadaModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeProcessoReferenciadoModel> getNfeProcessoReferenciadoModelList() { 
	return this.nfeProcessoReferenciadoModelList; 
	} 

	public void setNfeProcessoReferenciadoModelList(Set<NfeProcessoReferenciadoModel> nfeProcessoReferenciadoModelList) { 
	this.nfeProcessoReferenciadoModelList = nfeProcessoReferenciadoModelList; 
		for (NfeProcessoReferenciadoModel nfeProcessoReferenciadoModel : nfeProcessoReferenciadoModelList) { 
			nfeProcessoReferenciadoModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeAcessoXmlModel> getNfeAcessoXmlModelList() { 
	return this.nfeAcessoXmlModelList; 
	} 

	public void setNfeAcessoXmlModelList(Set<NfeAcessoXmlModel> nfeAcessoXmlModelList) { 
	this.nfeAcessoXmlModelList = nfeAcessoXmlModelList; 
		for (NfeAcessoXmlModel nfeAcessoXmlModel : nfeAcessoXmlModelList) { 
			nfeAcessoXmlModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeInformacaoPagamentoModel> getNfeInformacaoPagamentoModelList() { 
	return this.nfeInformacaoPagamentoModelList; 
	} 

	public void setNfeInformacaoPagamentoModelList(Set<NfeInformacaoPagamentoModel> nfeInformacaoPagamentoModelList) { 
	this.nfeInformacaoPagamentoModelList = nfeInformacaoPagamentoModelList; 
		for (NfeInformacaoPagamentoModel nfeInformacaoPagamentoModel : nfeInformacaoPagamentoModelList) { 
			nfeInformacaoPagamentoModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeResponsavelTecnicoModel> getNfeResponsavelTecnicoModelList() { 
	return this.nfeResponsavelTecnicoModelList; 
	} 

	public void setNfeResponsavelTecnicoModelList(Set<NfeResponsavelTecnicoModel> nfeResponsavelTecnicoModelList) { 
	this.nfeResponsavelTecnicoModelList = nfeResponsavelTecnicoModelList; 
		for (NfeResponsavelTecnicoModel nfeResponsavelTecnicoModel : nfeResponsavelTecnicoModelList) { 
			nfeResponsavelTecnicoModel.setNfeCabecalhoModel(this); 
		}
	} 

	public TributOperacaoFiscalModel getTributOperacaoFiscalModel() { 
	return this.tributOperacaoFiscalModel; 
	} 

	public void setTributOperacaoFiscalModel(TributOperacaoFiscalModel tributOperacaoFiscalModel) { 
	this.tributOperacaoFiscalModel = tributOperacaoFiscalModel; 
	} 

	public VendaCabecalhoModel getVendaCabecalhoModel() { 
	return this.vendaCabecalhoModel; 
	} 

	public void setVendaCabecalhoModel(VendaCabecalhoModel vendaCabecalhoModel) { 
	this.vendaCabecalhoModel = vendaCabecalhoModel; 
	} 

	public ViewPessoaClienteModel getViewPessoaClienteModel() { 
	return this.viewPessoaClienteModel; 
	} 

	public void setViewPessoaClienteModel(ViewPessoaClienteModel viewPessoaClienteModel) { 
	this.viewPessoaClienteModel = viewPessoaClienteModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public ViewPessoaFornecedorModel getViewPessoaFornecedorModel() { 
	return this.viewPessoaFornecedorModel; 
	} 

	public void setViewPessoaFornecedorModel(ViewPessoaFornecedorModel viewPessoaFornecedorModel) { 
	this.viewPessoaFornecedorModel = viewPessoaFornecedorModel; 
	} 

	public Set<NfeCteReferenciadoModel> getNfeCteReferenciadoModelList() { 
	return this.nfeCteReferenciadoModelList; 
	} 

	public void setNfeCteReferenciadoModelList(Set<NfeCteReferenciadoModel> nfeCteReferenciadoModelList) { 
	this.nfeCteReferenciadoModelList = nfeCteReferenciadoModelList; 
		for (NfeCteReferenciadoModel nfeCteReferenciadoModel : nfeCteReferenciadoModelList) { 
			nfeCteReferenciadoModel.setNfeCabecalhoModel(this); 
		}
	} 

	public Set<NfeCupomFiscalReferenciadoModel> getNfeCupomFiscalReferenciadoModelList() { 
	return this.nfeCupomFiscalReferenciadoModelList; 
	} 

	public void setNfeCupomFiscalReferenciadoModelList(Set<NfeCupomFiscalReferenciadoModel> nfeCupomFiscalReferenciadoModelList) { 
	this.nfeCupomFiscalReferenciadoModelList = nfeCupomFiscalReferenciadoModelList; 
		for (NfeCupomFiscalReferenciadoModel nfeCupomFiscalReferenciadoModel : nfeCupomFiscalReferenciadoModelList) { 
			nfeCupomFiscalReferenciadoModel.setNfeCabecalhoModel(this); 
		}
	} 

		
}