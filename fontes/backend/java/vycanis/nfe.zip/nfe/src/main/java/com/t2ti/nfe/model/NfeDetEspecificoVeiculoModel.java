package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_det_especifico_veiculo")
@NamedQuery(name="NfeDetEspecificoVeiculoModel.findAll", query="SELECT t FROM NfeDetEspecificoVeiculoModel t")
public class NfeDetEspecificoVeiculoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetEspecificoVeiculoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo_operacao")
	private String tipoOperacao;

	@Column(name="chassi")
	private String chassi;

	@Column(name="cor")
	private String cor;

	@Column(name="descricao_cor")
	private String descricaoCor;

	@Column(name="potencia_motor")
	private String potenciaMotor;

	@Column(name="cilindradas")
	private String cilindradas;

	@Column(name="peso_liquido")
	private String pesoLiquido;

	@Column(name="peso_bruto")
	private String pesoBruto;

	@Column(name="numero_serie")
	private String numeroSerie;

	@Column(name="tipo_combustivel")
	private String tipoCombustivel;

	@Column(name="numero_motor")
	private String numeroMotor;

	@Column(name="capacidade_maxima_tracao")
	private String capacidadeMaximaTracao;

	@Column(name="distancia_eixos")
	private String distanciaEixos;

	@Column(name="ano_modelo")
	private String anoModelo;

	@Column(name="ano_fabricacao")
	private String anoFabricacao;

	@Column(name="tipo_pintura")
	private String tipoPintura;

	@Column(name="tipo_veiculo")
	private String tipoVeiculo;

	@Column(name="especie_veiculo")
	private String especieVeiculo;

	@Column(name="condicao_vin")
	private String condicaoVin;

	@Column(name="condicao_veiculo")
	private String condicaoVeiculo;

	@Column(name="codigo_marca_modelo")
	private String codigoMarcaModelo;

	@Column(name="codigo_cor_denatran")
	private String codigoCorDenatran;

	@Column(name="lotacao_maxima")
	private Integer lotacaoMaxima;

	@Column(name="restricao")
	private String restricao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipoOperacao() { 
		return this.tipoOperacao; 
	} 

	public void setTipoOperacao(String tipoOperacao) { 
		this.tipoOperacao = tipoOperacao; 
	} 

	public String getChassi() { 
		return this.chassi; 
	} 

	public void setChassi(String chassi) { 
		this.chassi = chassi; 
	} 

	public String getCor() { 
		return this.cor; 
	} 

	public void setCor(String cor) { 
		this.cor = cor; 
	} 

	public String getDescricaoCor() { 
		return this.descricaoCor; 
	} 

	public void setDescricaoCor(String descricaoCor) { 
		this.descricaoCor = descricaoCor; 
	} 

	public String getPotenciaMotor() { 
		return this.potenciaMotor; 
	} 

	public void setPotenciaMotor(String potenciaMotor) { 
		this.potenciaMotor = potenciaMotor; 
	} 

	public String getCilindradas() { 
		return this.cilindradas; 
	} 

	public void setCilindradas(String cilindradas) { 
		this.cilindradas = cilindradas; 
	} 

	public String getPesoLiquido() { 
		return this.pesoLiquido; 
	} 

	public void setPesoLiquido(String pesoLiquido) { 
		this.pesoLiquido = pesoLiquido; 
	} 

	public String getPesoBruto() { 
		return this.pesoBruto; 
	} 

	public void setPesoBruto(String pesoBruto) { 
		this.pesoBruto = pesoBruto; 
	} 

	public String getNumeroSerie() { 
		return this.numeroSerie; 
	} 

	public void setNumeroSerie(String numeroSerie) { 
		this.numeroSerie = numeroSerie; 
	} 

	public String getTipoCombustivel() { 
		return this.tipoCombustivel; 
	} 

	public void setTipoCombustivel(String tipoCombustivel) { 
		this.tipoCombustivel = tipoCombustivel; 
	} 

	public String getNumeroMotor() { 
		return this.numeroMotor; 
	} 

	public void setNumeroMotor(String numeroMotor) { 
		this.numeroMotor = numeroMotor; 
	} 

	public String getCapacidadeMaximaTracao() { 
		return this.capacidadeMaximaTracao; 
	} 

	public void setCapacidadeMaximaTracao(String capacidadeMaximaTracao) { 
		this.capacidadeMaximaTracao = capacidadeMaximaTracao; 
	} 

	public String getDistanciaEixos() { 
		return this.distanciaEixos; 
	} 

	public void setDistanciaEixos(String distanciaEixos) { 
		this.distanciaEixos = distanciaEixos; 
	} 

	public String getAnoModelo() { 
		return this.anoModelo; 
	} 

	public void setAnoModelo(String anoModelo) { 
		this.anoModelo = anoModelo; 
	} 

	public String getAnoFabricacao() { 
		return this.anoFabricacao; 
	} 

	public void setAnoFabricacao(String anoFabricacao) { 
		this.anoFabricacao = anoFabricacao; 
	} 

	public String getTipoPintura() { 
		return this.tipoPintura; 
	} 

	public void setTipoPintura(String tipoPintura) { 
		this.tipoPintura = tipoPintura; 
	} 

	public String getTipoVeiculo() { 
		return this.tipoVeiculo; 
	} 

	public void setTipoVeiculo(String tipoVeiculo) { 
		this.tipoVeiculo = tipoVeiculo; 
	} 

	public String getEspecieVeiculo() { 
		return this.especieVeiculo; 
	} 

	public void setEspecieVeiculo(String especieVeiculo) { 
		this.especieVeiculo = especieVeiculo; 
	} 

	public String getCondicaoVin() { 
		return this.condicaoVin; 
	} 

	public void setCondicaoVin(String condicaoVin) { 
		this.condicaoVin = condicaoVin; 
	} 

	public String getCondicaoVeiculo() { 
		return this.condicaoVeiculo; 
	} 

	public void setCondicaoVeiculo(String condicaoVeiculo) { 
		this.condicaoVeiculo = condicaoVeiculo; 
	} 

	public String getCodigoMarcaModelo() { 
		return this.codigoMarcaModelo; 
	} 

	public void setCodigoMarcaModelo(String codigoMarcaModelo) { 
		this.codigoMarcaModelo = codigoMarcaModelo; 
	} 

	public String getCodigoCorDenatran() { 
		return this.codigoCorDenatran; 
	} 

	public void setCodigoCorDenatran(String codigoCorDenatran) { 
		this.codigoCorDenatran = codigoCorDenatran; 
	} 

	public Integer getLotacaoMaxima() { 
		return this.lotacaoMaxima; 
	} 

	public void setLotacaoMaxima(Integer lotacaoMaxima) { 
		this.lotacaoMaxima = lotacaoMaxima; 
	} 

	public String getRestricao() { 
		return this.restricao; 
	} 

	public void setRestricao(String restricao) { 
		this.restricao = restricao; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}