package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.NfeImportacaoDetalheModel;
import com.t2ti.nfe.repository.NfeImportacaoDetalheRepository;

@Service
public class NfeImportacaoDetalheService {

	@Autowired
	private NfeImportacaoDetalheRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfeImportacaoDetalheModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfeImportacaoDetalheModel> getList(Filter filter) {
		String sql = "select * from nfe_importacao_detalhe where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfeImportacaoDetalheModel.class);
		return query.getResultList();
	}

	public NfeImportacaoDetalheModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfeImportacaoDetalheModel save(NfeImportacaoDetalheModel obj) {
		NfeImportacaoDetalheModel nfeImportacaoDetalheModel = repository.save(obj);
		return nfeImportacaoDetalheModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfeImportacaoDetalheModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeImportacaoDetalhe] - Exception: " + e.getMessage());
		}
	}

}