package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="nfe_numero_inutilizado")
@NamedQuery(name="NfeNumeroInutilizadoModel.findAll", query="SELECT t FROM NfeNumeroInutilizadoModel t")
public class NfeNumeroInutilizadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeNumeroInutilizadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="serie")
	private String serie;

	@Column(name="numero")
	private Integer numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_inutilizacao")
	private Date dataInutilizacao;

	@Column(name="observacao")
	private String observacao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public Date getDataInutilizacao() { 
		return this.dataInutilizacao; 
	} 

	public void setDataInutilizacao(Date dataInutilizacao) { 
		this.dataInutilizacao = dataInutilizacao; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

		
}