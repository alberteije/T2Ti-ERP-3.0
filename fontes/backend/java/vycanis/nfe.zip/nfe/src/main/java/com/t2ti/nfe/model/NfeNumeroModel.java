package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="nfe_numero")
@NamedQuery(name="NfeNumeroModel.findAll", query="SELECT t FROM NfeNumeroModel t")
public class NfeNumeroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeNumeroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="serie")
	private String serie;

	@Column(name="numero")
	private Integer numero;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

		
}