package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_nf_referenciada")
@NamedQuery(name="NfeNfReferenciadaModel.findAll", query="SELECT t FROM NfeNfReferenciadaModel t")
public class NfeNfReferenciadaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeNfReferenciadaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_uf")
	private Integer codigoUf;

	@Column(name="ano_mes")
	private String anoMes;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="modelo")
	private String modelo;

	@Column(name="serie")
	private String serie;

	@Column(name="numero_nf")
	private Integer numeroNf;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_cabecalho")
	private NfeCabecalhoModel nfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getCodigoUf() { 
		return this.codigoUf; 
	} 

	public void setCodigoUf(Integer codigoUf) { 
		this.codigoUf = codigoUf; 
	} 

	public String getAnoMes() { 
		return this.anoMes; 
	} 

	public void setAnoMes(String anoMes) { 
		this.anoMes = anoMes; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getModelo() { 
		return this.modelo; 
	} 

	public void setModelo(String modelo) { 
		this.modelo = modelo; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public Integer getNumeroNf() { 
		return this.numeroNf; 
	} 

	public void setNumeroNf(Integer numeroNf) { 
		this.numeroNf = numeroNf; 
	} 

	public NfeCabecalhoModel getNfeCabecalhoModel() { 
	return this.nfeCabecalhoModel; 
	} 

	public void setNfeCabecalhoModel(NfeCabecalhoModel nfeCabecalhoModel) { 
	this.nfeCabecalhoModel = nfeCabecalhoModel; 
	} 

		
}