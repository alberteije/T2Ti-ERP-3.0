package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_declaracao_importacao")
@NamedQuery(name="NfeDeclaracaoImportacaoModel.findAll", query="SELECT t FROM NfeDeclaracaoImportacaoModel t")
public class NfeDeclaracaoImportacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDeclaracaoImportacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_documento")
	private String numeroDocumento;

	@Temporal(TemporalType.DATE)
@Column(name="data_registro")
	private Date dataRegistro;

	@Column(name="local_desembaraco")
	private String localDesembaraco;

	@Column(name="uf_desembaraco")
	private String ufDesembaraco;

	@Temporal(TemporalType.DATE)
@Column(name="data_desembaraco")
	private Date dataDesembaraco;

	@Column(name="via_transporte")
	private String viaTransporte;

	@Column(name="valor_afrmm")
	private BigDecimal valorAfrmm;

	@Column(name="forma_intermediacao")
	private String formaIntermediacao;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="uf_terceiro")
	private String ufTerceiro;

	@Column(name="codigo_exportador")
	private String codigoExportador;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumeroDocumento() { 
		return this.numeroDocumento; 
	} 

	public void setNumeroDocumento(String numeroDocumento) { 
		this.numeroDocumento = numeroDocumento; 
	} 

	public Date getDataRegistro() { 
		return this.dataRegistro; 
	} 

	public void setDataRegistro(Date dataRegistro) { 
		this.dataRegistro = dataRegistro; 
	} 

	public String getLocalDesembaraco() { 
		return this.localDesembaraco; 
	} 

	public void setLocalDesembaraco(String localDesembaraco) { 
		this.localDesembaraco = localDesembaraco; 
	} 

	public String getUfDesembaraco() { 
		return this.ufDesembaraco; 
	} 

	public void setUfDesembaraco(String ufDesembaraco) { 
		this.ufDesembaraco = ufDesembaraco; 
	} 

	public Date getDataDesembaraco() { 
		return this.dataDesembaraco; 
	} 

	public void setDataDesembaraco(Date dataDesembaraco) { 
		this.dataDesembaraco = dataDesembaraco; 
	} 

	public String getViaTransporte() { 
		return this.viaTransporte; 
	} 

	public void setViaTransporte(String viaTransporte) { 
		this.viaTransporte = viaTransporte; 
	} 

	public BigDecimal getValorAfrmm() { 
		return this.valorAfrmm; 
	} 

	public void setValorAfrmm(BigDecimal valorAfrmm) { 
		this.valorAfrmm = valorAfrmm; 
	} 

	public String getFormaIntermediacao() { 
		return this.formaIntermediacao; 
	} 

	public void setFormaIntermediacao(String formaIntermediacao) { 
		this.formaIntermediacao = formaIntermediacao; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getUfTerceiro() { 
		return this.ufTerceiro; 
	} 

	public void setUfTerceiro(String ufTerceiro) { 
		this.ufTerceiro = ufTerceiro; 
	} 

	public String getCodigoExportador() { 
		return this.codigoExportador; 
	} 

	public void setCodigoExportador(String codigoExportador) { 
		this.codigoExportador = codigoExportador; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}