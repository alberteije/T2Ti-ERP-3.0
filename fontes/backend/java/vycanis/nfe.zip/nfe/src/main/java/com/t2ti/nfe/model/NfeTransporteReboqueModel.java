package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_transporte_reboque")
@NamedQuery(name="NfeTransporteReboqueModel.findAll", query="SELECT t FROM NfeTransporteReboqueModel t")
public class NfeTransporteReboqueModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeTransporteReboqueModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="placa")
	private String placa;

	@Column(name="uf")
	private String uf;

	@Column(name="rntc")
	private String rntc;

	@Column(name="vagao")
	private String vagao;

	@Column(name="balsa")
	private String balsa;

	@ManyToOne 
	@JoinColumn(name="id_nfe_transporte")
	private NfeTransporteModel nfeTransporteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getPlaca() { 
		return this.placa; 
	} 

	public void setPlaca(String placa) { 
		this.placa = placa; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getRntc() { 
		return this.rntc; 
	} 

	public void setRntc(String rntc) { 
		this.rntc = rntc; 
	} 

	public String getVagao() { 
		return this.vagao; 
	} 

	public void setVagao(String vagao) { 
		this.vagao = vagao; 
	} 

	public String getBalsa() { 
		return this.balsa; 
	} 

	public void setBalsa(String balsa) { 
		this.balsa = balsa; 
	} 

	public NfeTransporteModel getNfeTransporteModel() { 
	return this.nfeTransporteModel; 
	} 

	public void setNfeTransporteModel(NfeTransporteModel nfeTransporteModel) { 
	this.nfeTransporteModel = nfeTransporteModel; 
	} 

		
}