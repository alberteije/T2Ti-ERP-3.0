package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_cofins_st")
@NamedQuery(name="NfeDetalheImpostoCofinsStModel.findAll", query="SELECT t FROM NfeDetalheImpostoCofinsStModel t")
public class NfeDetalheImpostoCofinsStModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoCofinsStModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="base_calculo_cofins_st")
	private BigDecimal baseCalculoCofinsSt;

	@Column(name="aliquota_cofins_st_percentual")
	private BigDecimal aliquotaCofinsStPercentual;

	@Column(name="quantidade_vendida_cofins_st")
	private BigDecimal quantidadeVendidaCofinsSt;

	@Column(name="aliquota_cofins_st_reais")
	private BigDecimal aliquotaCofinsStReais;

	@Column(name="valor_cofins_st")
	private BigDecimal valorCofinsSt;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getBaseCalculoCofinsSt() { 
		return this.baseCalculoCofinsSt; 
	} 

	public void setBaseCalculoCofinsSt(BigDecimal baseCalculoCofinsSt) { 
		this.baseCalculoCofinsSt = baseCalculoCofinsSt; 
	} 

	public BigDecimal getAliquotaCofinsStPercentual() { 
		return this.aliquotaCofinsStPercentual; 
	} 

	public void setAliquotaCofinsStPercentual(BigDecimal aliquotaCofinsStPercentual) { 
		this.aliquotaCofinsStPercentual = aliquotaCofinsStPercentual; 
	} 

	public BigDecimal getQuantidadeVendidaCofinsSt() { 
		return this.quantidadeVendidaCofinsSt; 
	} 

	public void setQuantidadeVendidaCofinsSt(BigDecimal quantidadeVendidaCofinsSt) { 
		this.quantidadeVendidaCofinsSt = quantidadeVendidaCofinsSt; 
	} 

	public BigDecimal getAliquotaCofinsStReais() { 
		return this.aliquotaCofinsStReais; 
	} 

	public void setAliquotaCofinsStReais(BigDecimal aliquotaCofinsStReais) { 
		this.aliquotaCofinsStReais = aliquotaCofinsStReais; 
	} 

	public BigDecimal getValorCofinsSt() { 
		return this.valorCofinsSt; 
	} 

	public void setValorCofinsSt(BigDecimal valorCofinsSt) { 
		this.valorCofinsSt = valorCofinsSt; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}