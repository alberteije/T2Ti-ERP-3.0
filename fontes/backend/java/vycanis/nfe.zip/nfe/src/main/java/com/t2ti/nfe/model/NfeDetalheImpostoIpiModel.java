package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_ipi")
@NamedQuery(name="NfeDetalheImpostoIpiModel.findAll", query="SELECT t FROM NfeDetalheImpostoIpiModel t")
public class NfeDetalheImpostoIpiModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoIpiModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj_produtor")
	private String cnpjProdutor;

	@Column(name="codigo_selo_ipi")
	private String codigoSeloIpi;

	@Column(name="quantidade_selo_ipi")
	private Integer quantidadeSeloIpi;

	@Column(name="enquadramento_legal_ipi")
	private String enquadramentoLegalIpi;

	@Column(name="cst_ipi")
	private String cstIpi;

	@Column(name="valor_base_calculo_ipi")
	private BigDecimal valorBaseCalculoIpi;

	@Column(name="quantidade_unidade_tributavel")
	private BigDecimal quantidadeUnidadeTributavel;

	@Column(name="valor_unidade_tributavel")
	private BigDecimal valorUnidadeTributavel;

	@Column(name="aliquota_ipi")
	private BigDecimal aliquotaIpi;

	@Column(name="valor_ipi")
	private BigDecimal valorIpi;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpjProdutor() { 
		return this.cnpjProdutor; 
	} 

	public void setCnpjProdutor(String cnpjProdutor) { 
		this.cnpjProdutor = cnpjProdutor; 
	} 

	public String getCodigoSeloIpi() { 
		return this.codigoSeloIpi; 
	} 

	public void setCodigoSeloIpi(String codigoSeloIpi) { 
		this.codigoSeloIpi = codigoSeloIpi; 
	} 

	public Integer getQuantidadeSeloIpi() { 
		return this.quantidadeSeloIpi; 
	} 

	public void setQuantidadeSeloIpi(Integer quantidadeSeloIpi) { 
		this.quantidadeSeloIpi = quantidadeSeloIpi; 
	} 

	public String getEnquadramentoLegalIpi() { 
		return this.enquadramentoLegalIpi; 
	} 

	public void setEnquadramentoLegalIpi(String enquadramentoLegalIpi) { 
		this.enquadramentoLegalIpi = enquadramentoLegalIpi; 
	} 

	public String getCstIpi() { 
		return this.cstIpi; 
	} 

	public void setCstIpi(String cstIpi) { 
		this.cstIpi = cstIpi; 
	} 

	public BigDecimal getValorBaseCalculoIpi() { 
		return this.valorBaseCalculoIpi; 
	} 

	public void setValorBaseCalculoIpi(BigDecimal valorBaseCalculoIpi) { 
		this.valorBaseCalculoIpi = valorBaseCalculoIpi; 
	} 

	public BigDecimal getQuantidadeUnidadeTributavel() { 
		return this.quantidadeUnidadeTributavel; 
	} 

	public void setQuantidadeUnidadeTributavel(BigDecimal quantidadeUnidadeTributavel) { 
		this.quantidadeUnidadeTributavel = quantidadeUnidadeTributavel; 
	} 

	public BigDecimal getValorUnidadeTributavel() { 
		return this.valorUnidadeTributavel; 
	} 

	public void setValorUnidadeTributavel(BigDecimal valorUnidadeTributavel) { 
		this.valorUnidadeTributavel = valorUnidadeTributavel; 
	} 

	public BigDecimal getAliquotaIpi() { 
		return this.aliquotaIpi; 
	} 

	public void setAliquotaIpi(BigDecimal aliquotaIpi) { 
		this.aliquotaIpi = aliquotaIpi; 
	} 

	public BigDecimal getValorIpi() { 
		return this.valorIpi; 
	} 

	public void setValorIpi(BigDecimal valorIpi) { 
		this.valorIpi = valorIpi; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}