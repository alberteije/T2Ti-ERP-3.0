package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.NfeDuplicataModel;
import com.t2ti.nfe.repository.NfeDuplicataRepository;

@Service
public class NfeDuplicataService {

	@Autowired
	private NfeDuplicataRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfeDuplicataModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfeDuplicataModel> getList(Filter filter) {
		String sql = "select * from nfe_duplicata where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfeDuplicataModel.class);
		return query.getResultList();
	}

	public NfeDuplicataModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfeDuplicataModel save(NfeDuplicataModel obj) {
		NfeDuplicataModel nfeDuplicataModel = repository.save(obj);
		return nfeDuplicataModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfeDuplicataModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeDuplicata] - Exception: " + e.getMessage());
		}
	}

}