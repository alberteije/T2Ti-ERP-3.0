package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_issqn")
@NamedQuery(name="NfeDetalheImpostoIssqnModel.findAll", query="SELECT t FROM NfeDetalheImpostoIssqnModel t")
public class NfeDetalheImpostoIssqnModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoIssqnModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="base_calculo_issqn")
	private BigDecimal baseCalculoIssqn;

	@Column(name="aliquota_issqn")
	private BigDecimal aliquotaIssqn;

	@Column(name="valor_issqn")
	private BigDecimal valorIssqn;

	@Column(name="municipio_issqn")
	private Integer municipioIssqn;

	@Column(name="item_lista_servicos")
	private Integer itemListaServicos;

	@Column(name="valor_deducao")
	private BigDecimal valorDeducao;

	@Column(name="valor_outras_retencoes")
	private BigDecimal valorOutrasRetencoes;

	@Column(name="valor_desconto_incondicionado")
	private BigDecimal valorDescontoIncondicionado;

	@Column(name="valor_desconto_condicionado")
	private BigDecimal valorDescontoCondicionado;

	@Column(name="valor_retencao_iss")
	private BigDecimal valorRetencaoIss;

	@Column(name="indicador_exigibilidade_iss")
	private String indicadorExigibilidadeIss;

	@Column(name="codigo_servico")
	private String codigoServico;

	@Column(name="municipio_incidencia")
	private Integer municipioIncidencia;

	@Column(name="pais_sevico_prestado")
	private Integer paisSevicoPrestado;

	@Column(name="numero_processo")
	private String numeroProcesso;

	@Column(name="indicador_incentivo_fiscal")
	private String indicadorIncentivoFiscal;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getBaseCalculoIssqn() { 
		return this.baseCalculoIssqn; 
	} 

	public void setBaseCalculoIssqn(BigDecimal baseCalculoIssqn) { 
		this.baseCalculoIssqn = baseCalculoIssqn; 
	} 

	public BigDecimal getAliquotaIssqn() { 
		return this.aliquotaIssqn; 
	} 

	public void setAliquotaIssqn(BigDecimal aliquotaIssqn) { 
		this.aliquotaIssqn = aliquotaIssqn; 
	} 

	public BigDecimal getValorIssqn() { 
		return this.valorIssqn; 
	} 

	public void setValorIssqn(BigDecimal valorIssqn) { 
		this.valorIssqn = valorIssqn; 
	} 

	public Integer getMunicipioIssqn() { 
		return this.municipioIssqn; 
	} 

	public void setMunicipioIssqn(Integer municipioIssqn) { 
		this.municipioIssqn = municipioIssqn; 
	} 

	public Integer getItemListaServicos() { 
		return this.itemListaServicos; 
	} 

	public void setItemListaServicos(Integer itemListaServicos) { 
		this.itemListaServicos = itemListaServicos; 
	} 

	public BigDecimal getValorDeducao() { 
		return this.valorDeducao; 
	} 

	public void setValorDeducao(BigDecimal valorDeducao) { 
		this.valorDeducao = valorDeducao; 
	} 

	public BigDecimal getValorOutrasRetencoes() { 
		return this.valorOutrasRetencoes; 
	} 

	public void setValorOutrasRetencoes(BigDecimal valorOutrasRetencoes) { 
		this.valorOutrasRetencoes = valorOutrasRetencoes; 
	} 

	public BigDecimal getValorDescontoIncondicionado() { 
		return this.valorDescontoIncondicionado; 
	} 

	public void setValorDescontoIncondicionado(BigDecimal valorDescontoIncondicionado) { 
		this.valorDescontoIncondicionado = valorDescontoIncondicionado; 
	} 

	public BigDecimal getValorDescontoCondicionado() { 
		return this.valorDescontoCondicionado; 
	} 

	public void setValorDescontoCondicionado(BigDecimal valorDescontoCondicionado) { 
		this.valorDescontoCondicionado = valorDescontoCondicionado; 
	} 

	public BigDecimal getValorRetencaoIss() { 
		return this.valorRetencaoIss; 
	} 

	public void setValorRetencaoIss(BigDecimal valorRetencaoIss) { 
		this.valorRetencaoIss = valorRetencaoIss; 
	} 

	public String getIndicadorExigibilidadeIss() { 
		return this.indicadorExigibilidadeIss; 
	} 

	public void setIndicadorExigibilidadeIss(String indicadorExigibilidadeIss) { 
		this.indicadorExigibilidadeIss = indicadorExigibilidadeIss; 
	} 

	public String getCodigoServico() { 
		return this.codigoServico; 
	} 

	public void setCodigoServico(String codigoServico) { 
		this.codigoServico = codigoServico; 
	} 

	public Integer getMunicipioIncidencia() { 
		return this.municipioIncidencia; 
	} 

	public void setMunicipioIncidencia(Integer municipioIncidencia) { 
		this.municipioIncidencia = municipioIncidencia; 
	} 

	public Integer getPaisSevicoPrestado() { 
		return this.paisSevicoPrestado; 
	} 

	public void setPaisSevicoPrestado(Integer paisSevicoPrestado) { 
		this.paisSevicoPrestado = paisSevicoPrestado; 
	} 

	public String getNumeroProcesso() { 
		return this.numeroProcesso; 
	} 

	public void setNumeroProcesso(String numeroProcesso) { 
		this.numeroProcesso = numeroProcesso; 
	} 

	public String getIndicadorIncentivoFiscal() { 
		return this.indicadorIncentivoFiscal; 
	} 

	public void setIndicadorIncentivoFiscal(String indicadorIncentivoFiscal) { 
		this.indicadorIncentivoFiscal = indicadorIncentivoFiscal; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}