package com.t2ti.nfe.util;

import java.io.Serializable;

/**
 * Transient class that controls the filter
 * Take as a basis the following scheme to create filter conditions
 * https://github.com/nestjsx/crud/wiki/Requests
 */
public class Filter implements Serializable {
	private static final long serialVersionUID = 1L;

	private String field;
	private String value;
	private String startDate;
	private String endDate;
	private String where;
	private String condition;

	public Filter() {}
	
	public Filter(String filter) {
		String filterString = filter.replace("||", ":");
		String[] filterParts = filterString.split("\\?");
		
		for (int i = 0; i < filterParts.length; i++) {
			String[] conditions = filterParts[i].split(":");

	        setCondition(conditions[1]);

	        if (i > 0) {
	            setWhere(getWhere() + " AND ");
	        }
	        
	        // $cont (LIKE %val%, contains)
	        if (condition.equals("$cont")) {
	            this.field = conditions[0];
	            this.value = conditions[2];
	            setWhere(getWhere() + field + " like '%" + value + "%'");
	        }

	        // $eq (=, equal)
	        if (condition.equals("$eq")) {
	            this.field = conditions[0];
	            this.value = conditions[2];
	            setWhere(getWhere() + field + " = '" + value + "'");
	        }
	        
	        // $between (BETWEEN, between, accepts two values)
	        if (condition.equals("$between")) {
							String[] datas = conditions[2].split(",");
	            this.field = conditions[0];
	            this.startDate = datas[0];
	            this.endDate = datas[1];
	            setWhere(getWhere() + field + " between '" + startDate + "' and '" + endDate + "'");
	        }			
		}
		
        
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getWhere() {
		if (where == null)
			return "";
	    return where;
	}

	public void setWhere(String where) {
		this.where = where;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

}