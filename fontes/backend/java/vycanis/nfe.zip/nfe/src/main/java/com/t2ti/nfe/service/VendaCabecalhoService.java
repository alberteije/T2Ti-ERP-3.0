package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.VendaCabecalhoModel;
import com.t2ti.nfe.repository.VendaCabecalhoRepository;

@Service
public class VendaCabecalhoService {

	@Autowired
	private VendaCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<VendaCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<VendaCabecalhoModel> getList(Filter filter) {
		String sql = "select * from venda_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, VendaCabecalhoModel.class);
		return query.getResultList();
	}

	public VendaCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public VendaCabecalhoModel save(VendaCabecalhoModel obj) {
		VendaCabecalhoModel vendaCabecalhoModel = repository.save(obj);
		return vendaCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		VendaCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete VendaCabecalho] - Exception: " + e.getMessage());
		}
	}

}