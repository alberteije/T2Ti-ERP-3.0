package com.t2ti.nfe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.nfe.model.NfeDetalheModel;

public interface NfeDetalheRepository extends JpaRepository<NfeDetalheModel, Integer> {}