package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.NfeConfiguracaoModel;
import com.t2ti.nfe.repository.NfeConfiguracaoRepository;

@Service
public class NfeConfiguracaoService {

	@Autowired
	private NfeConfiguracaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfeConfiguracaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfeConfiguracaoModel> getList(Filter filter) {
		String sql = "select * from nfe_configuracao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfeConfiguracaoModel.class);
		return query.getResultList();
	}

	public NfeConfiguracaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfeConfiguracaoModel save(NfeConfiguracaoModel obj) {
		NfeConfiguracaoModel nfeConfiguracaoModel = repository.save(obj);
		return nfeConfiguracaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfeConfiguracaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeConfiguracao] - Exception: " + e.getMessage());
		}
	}

}