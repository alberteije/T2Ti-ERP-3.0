package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_ii")
@NamedQuery(name="NfeDetalheImpostoIiModel.findAll", query="SELECT t FROM NfeDetalheImpostoIiModel t")
public class NfeDetalheImpostoIiModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoIiModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor_bc_ii")
	private BigDecimal valorBcIi;

	@Column(name="valor_despesas_aduaneiras")
	private BigDecimal valorDespesasAduaneiras;

	@Column(name="valor_imposto_importacao")
	private BigDecimal valorImpostoImportacao;

	@Column(name="valor_iof")
	private BigDecimal valorIof;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValorBcIi() { 
		return this.valorBcIi; 
	} 

	public void setValorBcIi(BigDecimal valorBcIi) { 
		this.valorBcIi = valorBcIi; 
	} 

	public BigDecimal getValorDespesasAduaneiras() { 
		return this.valorDespesasAduaneiras; 
	} 

	public void setValorDespesasAduaneiras(BigDecimal valorDespesasAduaneiras) { 
		this.valorDespesasAduaneiras = valorDespesasAduaneiras; 
	} 

	public BigDecimal getValorImpostoImportacao() { 
		return this.valorImpostoImportacao; 
	} 

	public void setValorImpostoImportacao(BigDecimal valorImpostoImportacao) { 
		this.valorImpostoImportacao = valorImpostoImportacao; 
	} 

	public BigDecimal getValorIof() { 
		return this.valorIof; 
	} 

	public void setValorIof(BigDecimal valorIof) { 
		this.valorIof = valorIof; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}