package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_pis_st")
@NamedQuery(name="NfeDetalheImpostoPisStModel.findAll", query="SELECT t FROM NfeDetalheImpostoPisStModel t")
public class NfeDetalheImpostoPisStModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoPisStModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor_base_calculo_pis_st")
	private BigDecimal valorBaseCalculoPisSt;

	@Column(name="aliquota_pis_st_percentual")
	private BigDecimal aliquotaPisStPercentual;

	@Column(name="quantidade_vendida_pis_st")
	private BigDecimal quantidadeVendidaPisSt;

	@Column(name="aliquota_pis_st_reais")
	private BigDecimal aliquotaPisStReais;

	@Column(name="valor_pis_st")
	private BigDecimal valorPisSt;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValorBaseCalculoPisSt() { 
		return this.valorBaseCalculoPisSt; 
	} 

	public void setValorBaseCalculoPisSt(BigDecimal valorBaseCalculoPisSt) { 
		this.valorBaseCalculoPisSt = valorBaseCalculoPisSt; 
	} 

	public BigDecimal getAliquotaPisStPercentual() { 
		return this.aliquotaPisStPercentual; 
	} 

	public void setAliquotaPisStPercentual(BigDecimal aliquotaPisStPercentual) { 
		this.aliquotaPisStPercentual = aliquotaPisStPercentual; 
	} 

	public BigDecimal getQuantidadeVendidaPisSt() { 
		return this.quantidadeVendidaPisSt; 
	} 

	public void setQuantidadeVendidaPisSt(BigDecimal quantidadeVendidaPisSt) { 
		this.quantidadeVendidaPisSt = quantidadeVendidaPisSt; 
	} 

	public BigDecimal getAliquotaPisStReais() { 
		return this.aliquotaPisStReais; 
	} 

	public void setAliquotaPisStReais(BigDecimal aliquotaPisStReais) { 
		this.aliquotaPisStReais = aliquotaPisStReais; 
	} 

	public BigDecimal getValorPisSt() { 
		return this.valorPisSt; 
	} 

	public void setValorPisSt(BigDecimal valorPisSt) { 
		this.valorPisSt = valorPisSt; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}