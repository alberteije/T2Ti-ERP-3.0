package com.t2ti.nfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NfeApplication {

	public static void main(String[] args) {
		SpringApplication.run(NfeApplication.class, args);
	}

}
