package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_det_especifico_medicamento")
@NamedQuery(name="NfeDetEspecificoMedicamentoModel.findAll", query="SELECT t FROM NfeDetEspecificoMedicamentoModel t")
public class NfeDetEspecificoMedicamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetEspecificoMedicamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_anvisa")
	private String codigoAnvisa;

	@Column(name="motivo_isencao")
	private String motivoIsencao;

	@Column(name="preco_maximo_consumidor")
	private BigDecimal precoMaximoConsumidor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoAnvisa() { 
		return this.codigoAnvisa; 
	} 

	public void setCodigoAnvisa(String codigoAnvisa) { 
		this.codigoAnvisa = codigoAnvisa; 
	} 

	public String getMotivoIsencao() { 
		return this.motivoIsencao; 
	} 

	public void setMotivoIsencao(String motivoIsencao) { 
		this.motivoIsencao = motivoIsencao; 
	} 

	public BigDecimal getPrecoMaximoConsumidor() { 
		return this.precoMaximoConsumidor; 
	} 

	public void setPrecoMaximoConsumidor(BigDecimal precoMaximoConsumidor) { 
		this.precoMaximoConsumidor = precoMaximoConsumidor; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}