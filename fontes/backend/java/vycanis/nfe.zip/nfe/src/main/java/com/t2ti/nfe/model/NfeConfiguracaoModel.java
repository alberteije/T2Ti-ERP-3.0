package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="nfe_configuracao")
@NamedQuery(name="NfeConfiguracaoModel.findAll", query="SELECT t FROM NfeConfiguracaoModel t")
public class NfeConfiguracaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeConfiguracaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="certificado_digital_serie")
	private String certificadoDigitalSerie;

	@Column(name="certificado_digital_caminho")
	private String certificadoDigitalCaminho;

	@Column(name="certificado_digital_senha")
	private String certificadoDigitalSenha;

	@Column(name="tipo_emissao")
	private Integer tipoEmissao;

	@Column(name="formato_impressao_danfe")
	private Integer formatoImpressaoDanfe;

	@Column(name="processo_emissao")
	private Integer processoEmissao;

	@Column(name="versao_processo_emissao")
	private String versaoProcessoEmissao;

	@Column(name="caminho_logomarca")
	private String caminhoLogomarca;

	@Column(name="salvar_xml")
	private String salvarXml;

	@Column(name="caminho_salvar_xml")
	private String caminhoSalvarXml;

	@Column(name="caminho_schemas")
	private String caminhoSchemas;

	@Column(name="caminho_arquivo_danfe")
	private String caminhoArquivoDanfe;

	@Column(name="caminho_salvar_pdf")
	private String caminhoSalvarPdf;

	@Column(name="webservice_uf")
	private String webserviceUf;

	@Column(name="webservice_ambiente")
	private Integer webserviceAmbiente;

	@Column(name="webservice_proxy_host")
	private String webserviceProxyHost;

	@Column(name="webservice_proxy_porta")
	private Integer webserviceProxyPorta;

	@Column(name="webservice_proxy_usuario")
	private String webserviceProxyUsuario;

	@Column(name="webservice_proxy_senha")
	private String webserviceProxySenha;

	@Column(name="webservice_visualizar")
	private String webserviceVisualizar;

	@Column(name="email_servidor_smtp")
	private String emailServidorSmtp;

	@Column(name="email_porta")
	private Integer emailPorta;

	@Column(name="email_usuario")
	private String emailUsuario;

	@Column(name="email_senha")
	private String emailSenha;

	@Column(name="email_assunto")
	private String emailAssunto;

	@Column(name="email_autentica_ssl")
	private String emailAutenticaSsl;

	@Column(name="email_texto")
	private String emailTexto;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCertificadoDigitalSerie() { 
		return this.certificadoDigitalSerie; 
	} 

	public void setCertificadoDigitalSerie(String certificadoDigitalSerie) { 
		this.certificadoDigitalSerie = certificadoDigitalSerie; 
	} 

	public String getCertificadoDigitalCaminho() { 
		return this.certificadoDigitalCaminho; 
	} 

	public void setCertificadoDigitalCaminho(String certificadoDigitalCaminho) { 
		this.certificadoDigitalCaminho = certificadoDigitalCaminho; 
	} 

	public String getCertificadoDigitalSenha() { 
		return this.certificadoDigitalSenha; 
	} 

	public void setCertificadoDigitalSenha(String certificadoDigitalSenha) { 
		this.certificadoDigitalSenha = certificadoDigitalSenha; 
	} 

	public Integer getTipoEmissao() { 
		return this.tipoEmissao; 
	} 

	public void setTipoEmissao(Integer tipoEmissao) { 
		this.tipoEmissao = tipoEmissao; 
	} 

	public Integer getFormatoImpressaoDanfe() { 
		return this.formatoImpressaoDanfe; 
	} 

	public void setFormatoImpressaoDanfe(Integer formatoImpressaoDanfe) { 
		this.formatoImpressaoDanfe = formatoImpressaoDanfe; 
	} 

	public Integer getProcessoEmissao() { 
		return this.processoEmissao; 
	} 

	public void setProcessoEmissao(Integer processoEmissao) { 
		this.processoEmissao = processoEmissao; 
	} 

	public String getVersaoProcessoEmissao() { 
		return this.versaoProcessoEmissao; 
	} 

	public void setVersaoProcessoEmissao(String versaoProcessoEmissao) { 
		this.versaoProcessoEmissao = versaoProcessoEmissao; 
	} 

	public String getCaminhoLogomarca() { 
		return this.caminhoLogomarca; 
	} 

	public void setCaminhoLogomarca(String caminhoLogomarca) { 
		this.caminhoLogomarca = caminhoLogomarca; 
	} 

	public String getSalvarXml() { 
		return this.salvarXml; 
	} 

	public void setSalvarXml(String salvarXml) { 
		this.salvarXml = salvarXml; 
	} 

	public String getCaminhoSalvarXml() { 
		return this.caminhoSalvarXml; 
	} 

	public void setCaminhoSalvarXml(String caminhoSalvarXml) { 
		this.caminhoSalvarXml = caminhoSalvarXml; 
	} 

	public String getCaminhoSchemas() { 
		return this.caminhoSchemas; 
	} 

	public void setCaminhoSchemas(String caminhoSchemas) { 
		this.caminhoSchemas = caminhoSchemas; 
	} 

	public String getCaminhoArquivoDanfe() { 
		return this.caminhoArquivoDanfe; 
	} 

	public void setCaminhoArquivoDanfe(String caminhoArquivoDanfe) { 
		this.caminhoArquivoDanfe = caminhoArquivoDanfe; 
	} 

	public String getCaminhoSalvarPdf() { 
		return this.caminhoSalvarPdf; 
	} 

	public void setCaminhoSalvarPdf(String caminhoSalvarPdf) { 
		this.caminhoSalvarPdf = caminhoSalvarPdf; 
	} 

	public String getWebserviceUf() { 
		return this.webserviceUf; 
	} 

	public void setWebserviceUf(String webserviceUf) { 
		this.webserviceUf = webserviceUf; 
	} 

	public Integer getWebserviceAmbiente() { 
		return this.webserviceAmbiente; 
	} 

	public void setWebserviceAmbiente(Integer webserviceAmbiente) { 
		this.webserviceAmbiente = webserviceAmbiente; 
	} 

	public String getWebserviceProxyHost() { 
		return this.webserviceProxyHost; 
	} 

	public void setWebserviceProxyHost(String webserviceProxyHost) { 
		this.webserviceProxyHost = webserviceProxyHost; 
	} 

	public Integer getWebserviceProxyPorta() { 
		return this.webserviceProxyPorta; 
	} 

	public void setWebserviceProxyPorta(Integer webserviceProxyPorta) { 
		this.webserviceProxyPorta = webserviceProxyPorta; 
	} 

	public String getWebserviceProxyUsuario() { 
		return this.webserviceProxyUsuario; 
	} 

	public void setWebserviceProxyUsuario(String webserviceProxyUsuario) { 
		this.webserviceProxyUsuario = webserviceProxyUsuario; 
	} 

	public String getWebserviceProxySenha() { 
		return this.webserviceProxySenha; 
	} 

	public void setWebserviceProxySenha(String webserviceProxySenha) { 
		this.webserviceProxySenha = webserviceProxySenha; 
	} 

	public String getWebserviceVisualizar() { 
		return this.webserviceVisualizar; 
	} 

	public void setWebserviceVisualizar(String webserviceVisualizar) { 
		this.webserviceVisualizar = webserviceVisualizar; 
	} 

	public String getEmailServidorSmtp() { 
		return this.emailServidorSmtp; 
	} 

	public void setEmailServidorSmtp(String emailServidorSmtp) { 
		this.emailServidorSmtp = emailServidorSmtp; 
	} 

	public Integer getEmailPorta() { 
		return this.emailPorta; 
	} 

	public void setEmailPorta(Integer emailPorta) { 
		this.emailPorta = emailPorta; 
	} 

	public String getEmailUsuario() { 
		return this.emailUsuario; 
	} 

	public void setEmailUsuario(String emailUsuario) { 
		this.emailUsuario = emailUsuario; 
	} 

	public String getEmailSenha() { 
		return this.emailSenha; 
	} 

	public void setEmailSenha(String emailSenha) { 
		this.emailSenha = emailSenha; 
	} 

	public String getEmailAssunto() { 
		return this.emailAssunto; 
	} 

	public void setEmailAssunto(String emailAssunto) { 
		this.emailAssunto = emailAssunto; 
	} 

	public String getEmailAutenticaSsl() { 
		return this.emailAutenticaSsl; 
	} 

	public void setEmailAutenticaSsl(String emailAutenticaSsl) { 
		this.emailAutenticaSsl = emailAutenticaSsl; 
	} 

	public String getEmailTexto() { 
		return this.emailTexto; 
	} 

	public void setEmailTexto(String emailTexto) { 
		this.emailTexto = emailTexto; 
	} 

		
}