package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="tribut_operacao_fiscal")
@NamedQuery(name="TributOperacaoFiscalModel.findAll", query="SELECT t FROM TributOperacaoFiscalModel t")
public class TributOperacaoFiscalModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TributOperacaoFiscalModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Column(name="descricao_na_nf")
	private String descricaoNaNf;

	@Column(name="cfop")
	private Integer cfop;

	@Column(name="observacao")
	private String observacao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getDescricaoNaNf() { 
		return this.descricaoNaNf; 
	} 

	public void setDescricaoNaNf(String descricaoNaNf) { 
		this.descricaoNaNf = descricaoNaNf; 
	} 

	public Integer getCfop() { 
		return this.cfop; 
	} 

	public void setCfop(Integer cfop) { 
		this.cfop = cfop; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

		
}