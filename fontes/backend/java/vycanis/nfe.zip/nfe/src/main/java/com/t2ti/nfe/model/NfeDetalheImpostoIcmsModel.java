package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_icms")
@NamedQuery(name="NfeDetalheImpostoIcmsModel.findAll", query="SELECT t FROM NfeDetalheImpostoIcmsModel t")
public class NfeDetalheImpostoIcmsModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoIcmsModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="origem_mercadoria")
	private String origemMercadoria;

	@Column(name="cst_icms")
	private String cstIcms;

	@Column(name="csosn")
	private String csosn;

	@Column(name="modalidade_bc_icms")
	private String modalidadeBcIcms;

	@Column(name="percentual_reducao_bc_icms")
	private BigDecimal percentualReducaoBcIcms;

	@Column(name="valor_bc_icms")
	private BigDecimal valorBcIcms;

	@Column(name="aliquota_icms")
	private BigDecimal aliquotaIcms;

	@Column(name="valor_icms_operacao")
	private BigDecimal valorIcmsOperacao;

	@Column(name="percentual_diferimento")
	private BigDecimal percentualDiferimento;

	@Column(name="valor_icms_diferido")
	private BigDecimal valorIcmsDiferido;

	@Column(name="valor_icms")
	private BigDecimal valorIcms;

	@Column(name="base_calculo_fcp")
	private BigDecimal baseCalculoFcp;

	@Column(name="percentual_fcp")
	private BigDecimal percentualFcp;

	@Column(name="valor_fcp")
	private BigDecimal valorFcp;

	@Column(name="modalidade_bc_icms_st")
	private String modalidadeBcIcmsSt;

	@Column(name="percentual_mva_icms_st")
	private BigDecimal percentualMvaIcmsSt;

	@Column(name="percentual_reducao_bc_icms_st")
	private BigDecimal percentualReducaoBcIcmsSt;

	@Column(name="valor_base_calculo_icms_st")
	private BigDecimal valorBaseCalculoIcmsSt;

	@Column(name="aliquota_icms_st")
	private BigDecimal aliquotaIcmsSt;

	@Column(name="valor_icms_st")
	private BigDecimal valorIcmsSt;

	@Column(name="base_calculo_fcp_st")
	private BigDecimal baseCalculoFcpSt;

	@Column(name="percentual_fcp_st")
	private BigDecimal percentualFcpSt;

	@Column(name="valor_fcp_st")
	private BigDecimal valorFcpSt;

	@Column(name="uf_st")
	private String ufSt;

	@Column(name="percentual_bc_operacao_propria")
	private BigDecimal percentualBcOperacaoPropria;

	@Column(name="valor_bc_icms_st_retido")
	private BigDecimal valorBcIcmsStRetido;

	@Column(name="aliquota_suportada_consumidor")
	private BigDecimal aliquotaSuportadaConsumidor;

	@Column(name="valor_icms_substituto")
	private BigDecimal valorIcmsSubstituto;

	@Column(name="valor_icms_st_retido")
	private BigDecimal valorIcmsStRetido;

	@Column(name="base_calculo_fcp_st_retido")
	private BigDecimal baseCalculoFcpStRetido;

	@Column(name="percentual_fcp_st_retido")
	private BigDecimal percentualFcpStRetido;

	@Column(name="valor_fcp_st_retido")
	private BigDecimal valorFcpStRetido;

	@Column(name="motivo_desoneracao_icms")
	private String motivoDesoneracaoIcms;

	@Column(name="valor_icms_desonerado")
	private BigDecimal valorIcmsDesonerado;

	@Column(name="aliquota_credito_icms_sn")
	private BigDecimal aliquotaCreditoIcmsSn;

	@Column(name="valor_credito_icms_sn")
	private BigDecimal valorCreditoIcmsSn;

	@Column(name="valor_bc_icms_st_destino")
	private BigDecimal valorBcIcmsStDestino;

	@Column(name="valor_icms_st_destino")
	private BigDecimal valorIcmsStDestino;

	@Column(name="percentual_reducao_bc_efetivo")
	private BigDecimal percentualReducaoBcEfetivo;

	@Column(name="valor_bc_efetivo")
	private BigDecimal valorBcEfetivo;

	@Column(name="aliquota_icms_efetivo")
	private BigDecimal aliquotaIcmsEfetivo;

	@Column(name="valor_icms_efetivo")
	private BigDecimal valorIcmsEfetivo;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getOrigemMercadoria() { 
		return this.origemMercadoria; 
	} 

	public void setOrigemMercadoria(String origemMercadoria) { 
		this.origemMercadoria = origemMercadoria; 
	} 

	public String getCstIcms() { 
		return this.cstIcms; 
	} 

	public void setCstIcms(String cstIcms) { 
		this.cstIcms = cstIcms; 
	} 

	public String getCsosn() { 
		return this.csosn; 
	} 

	public void setCsosn(String csosn) { 
		this.csosn = csosn; 
	} 

	public String getModalidadeBcIcms() { 
		return this.modalidadeBcIcms; 
	} 

	public void setModalidadeBcIcms(String modalidadeBcIcms) { 
		this.modalidadeBcIcms = modalidadeBcIcms; 
	} 

	public BigDecimal getPercentualReducaoBcIcms() { 
		return this.percentualReducaoBcIcms; 
	} 

	public void setPercentualReducaoBcIcms(BigDecimal percentualReducaoBcIcms) { 
		this.percentualReducaoBcIcms = percentualReducaoBcIcms; 
	} 

	public BigDecimal getValorBcIcms() { 
		return this.valorBcIcms; 
	} 

	public void setValorBcIcms(BigDecimal valorBcIcms) { 
		this.valorBcIcms = valorBcIcms; 
	} 

	public BigDecimal getAliquotaIcms() { 
		return this.aliquotaIcms; 
	} 

	public void setAliquotaIcms(BigDecimal aliquotaIcms) { 
		this.aliquotaIcms = aliquotaIcms; 
	} 

	public BigDecimal getValorIcmsOperacao() { 
		return this.valorIcmsOperacao; 
	} 

	public void setValorIcmsOperacao(BigDecimal valorIcmsOperacao) { 
		this.valorIcmsOperacao = valorIcmsOperacao; 
	} 

	public BigDecimal getPercentualDiferimento() { 
		return this.percentualDiferimento; 
	} 

	public void setPercentualDiferimento(BigDecimal percentualDiferimento) { 
		this.percentualDiferimento = percentualDiferimento; 
	} 

	public BigDecimal getValorIcmsDiferido() { 
		return this.valorIcmsDiferido; 
	} 

	public void setValorIcmsDiferido(BigDecimal valorIcmsDiferido) { 
		this.valorIcmsDiferido = valorIcmsDiferido; 
	} 

	public BigDecimal getValorIcms() { 
		return this.valorIcms; 
	} 

	public void setValorIcms(BigDecimal valorIcms) { 
		this.valorIcms = valorIcms; 
	} 

	public BigDecimal getBaseCalculoFcp() { 
		return this.baseCalculoFcp; 
	} 

	public void setBaseCalculoFcp(BigDecimal baseCalculoFcp) { 
		this.baseCalculoFcp = baseCalculoFcp; 
	} 

	public BigDecimal getPercentualFcp() { 
		return this.percentualFcp; 
	} 

	public void setPercentualFcp(BigDecimal percentualFcp) { 
		this.percentualFcp = percentualFcp; 
	} 

	public BigDecimal getValorFcp() { 
		return this.valorFcp; 
	} 

	public void setValorFcp(BigDecimal valorFcp) { 
		this.valorFcp = valorFcp; 
	} 

	public String getModalidadeBcIcmsSt() { 
		return this.modalidadeBcIcmsSt; 
	} 

	public void setModalidadeBcIcmsSt(String modalidadeBcIcmsSt) { 
		this.modalidadeBcIcmsSt = modalidadeBcIcmsSt; 
	} 

	public BigDecimal getPercentualMvaIcmsSt() { 
		return this.percentualMvaIcmsSt; 
	} 

	public void setPercentualMvaIcmsSt(BigDecimal percentualMvaIcmsSt) { 
		this.percentualMvaIcmsSt = percentualMvaIcmsSt; 
	} 

	public BigDecimal getPercentualReducaoBcIcmsSt() { 
		return this.percentualReducaoBcIcmsSt; 
	} 

	public void setPercentualReducaoBcIcmsSt(BigDecimal percentualReducaoBcIcmsSt) { 
		this.percentualReducaoBcIcmsSt = percentualReducaoBcIcmsSt; 
	} 

	public BigDecimal getValorBaseCalculoIcmsSt() { 
		return this.valorBaseCalculoIcmsSt; 
	} 

	public void setValorBaseCalculoIcmsSt(BigDecimal valorBaseCalculoIcmsSt) { 
		this.valorBaseCalculoIcmsSt = valorBaseCalculoIcmsSt; 
	} 

	public BigDecimal getAliquotaIcmsSt() { 
		return this.aliquotaIcmsSt; 
	} 

	public void setAliquotaIcmsSt(BigDecimal aliquotaIcmsSt) { 
		this.aliquotaIcmsSt = aliquotaIcmsSt; 
	} 

	public BigDecimal getValorIcmsSt() { 
		return this.valorIcmsSt; 
	} 

	public void setValorIcmsSt(BigDecimal valorIcmsSt) { 
		this.valorIcmsSt = valorIcmsSt; 
	} 

	public BigDecimal getBaseCalculoFcpSt() { 
		return this.baseCalculoFcpSt; 
	} 

	public void setBaseCalculoFcpSt(BigDecimal baseCalculoFcpSt) { 
		this.baseCalculoFcpSt = baseCalculoFcpSt; 
	} 

	public BigDecimal getPercentualFcpSt() { 
		return this.percentualFcpSt; 
	} 

	public void setPercentualFcpSt(BigDecimal percentualFcpSt) { 
		this.percentualFcpSt = percentualFcpSt; 
	} 

	public BigDecimal getValorFcpSt() { 
		return this.valorFcpSt; 
	} 

	public void setValorFcpSt(BigDecimal valorFcpSt) { 
		this.valorFcpSt = valorFcpSt; 
	} 

	public String getUfSt() { 
		return this.ufSt; 
	} 

	public void setUfSt(String ufSt) { 
		this.ufSt = ufSt; 
	} 

	public BigDecimal getPercentualBcOperacaoPropria() { 
		return this.percentualBcOperacaoPropria; 
	} 

	public void setPercentualBcOperacaoPropria(BigDecimal percentualBcOperacaoPropria) { 
		this.percentualBcOperacaoPropria = percentualBcOperacaoPropria; 
	} 

	public BigDecimal getValorBcIcmsStRetido() { 
		return this.valorBcIcmsStRetido; 
	} 

	public void setValorBcIcmsStRetido(BigDecimal valorBcIcmsStRetido) { 
		this.valorBcIcmsStRetido = valorBcIcmsStRetido; 
	} 

	public BigDecimal getAliquotaSuportadaConsumidor() { 
		return this.aliquotaSuportadaConsumidor; 
	} 

	public void setAliquotaSuportadaConsumidor(BigDecimal aliquotaSuportadaConsumidor) { 
		this.aliquotaSuportadaConsumidor = aliquotaSuportadaConsumidor; 
	} 

	public BigDecimal getValorIcmsSubstituto() { 
		return this.valorIcmsSubstituto; 
	} 

	public void setValorIcmsSubstituto(BigDecimal valorIcmsSubstituto) { 
		this.valorIcmsSubstituto = valorIcmsSubstituto; 
	} 

	public BigDecimal getValorIcmsStRetido() { 
		return this.valorIcmsStRetido; 
	} 

	public void setValorIcmsStRetido(BigDecimal valorIcmsStRetido) { 
		this.valorIcmsStRetido = valorIcmsStRetido; 
	} 

	public BigDecimal getBaseCalculoFcpStRetido() { 
		return this.baseCalculoFcpStRetido; 
	} 

	public void setBaseCalculoFcpStRetido(BigDecimal baseCalculoFcpStRetido) { 
		this.baseCalculoFcpStRetido = baseCalculoFcpStRetido; 
	} 

	public BigDecimal getPercentualFcpStRetido() { 
		return this.percentualFcpStRetido; 
	} 

	public void setPercentualFcpStRetido(BigDecimal percentualFcpStRetido) { 
		this.percentualFcpStRetido = percentualFcpStRetido; 
	} 

	public BigDecimal getValorFcpStRetido() { 
		return this.valorFcpStRetido; 
	} 

	public void setValorFcpStRetido(BigDecimal valorFcpStRetido) { 
		this.valorFcpStRetido = valorFcpStRetido; 
	} 

	public String getMotivoDesoneracaoIcms() { 
		return this.motivoDesoneracaoIcms; 
	} 

	public void setMotivoDesoneracaoIcms(String motivoDesoneracaoIcms) { 
		this.motivoDesoneracaoIcms = motivoDesoneracaoIcms; 
	} 

	public BigDecimal getValorIcmsDesonerado() { 
		return this.valorIcmsDesonerado; 
	} 

	public void setValorIcmsDesonerado(BigDecimal valorIcmsDesonerado) { 
		this.valorIcmsDesonerado = valorIcmsDesonerado; 
	} 

	public BigDecimal getAliquotaCreditoIcmsSn() { 
		return this.aliquotaCreditoIcmsSn; 
	} 

	public void setAliquotaCreditoIcmsSn(BigDecimal aliquotaCreditoIcmsSn) { 
		this.aliquotaCreditoIcmsSn = aliquotaCreditoIcmsSn; 
	} 

	public BigDecimal getValorCreditoIcmsSn() { 
		return this.valorCreditoIcmsSn; 
	} 

	public void setValorCreditoIcmsSn(BigDecimal valorCreditoIcmsSn) { 
		this.valorCreditoIcmsSn = valorCreditoIcmsSn; 
	} 

	public BigDecimal getValorBcIcmsStDestino() { 
		return this.valorBcIcmsStDestino; 
	} 

	public void setValorBcIcmsStDestino(BigDecimal valorBcIcmsStDestino) { 
		this.valorBcIcmsStDestino = valorBcIcmsStDestino; 
	} 

	public BigDecimal getValorIcmsStDestino() { 
		return this.valorIcmsStDestino; 
	} 

	public void setValorIcmsStDestino(BigDecimal valorIcmsStDestino) { 
		this.valorIcmsStDestino = valorIcmsStDestino; 
	} 

	public BigDecimal getPercentualReducaoBcEfetivo() { 
		return this.percentualReducaoBcEfetivo; 
	} 

	public void setPercentualReducaoBcEfetivo(BigDecimal percentualReducaoBcEfetivo) { 
		this.percentualReducaoBcEfetivo = percentualReducaoBcEfetivo; 
	} 

	public BigDecimal getValorBcEfetivo() { 
		return this.valorBcEfetivo; 
	} 

	public void setValorBcEfetivo(BigDecimal valorBcEfetivo) { 
		this.valorBcEfetivo = valorBcEfetivo; 
	} 

	public BigDecimal getAliquotaIcmsEfetivo() { 
		return this.aliquotaIcmsEfetivo; 
	} 

	public void setAliquotaIcmsEfetivo(BigDecimal aliquotaIcmsEfetivo) { 
		this.aliquotaIcmsEfetivo = aliquotaIcmsEfetivo; 
	} 

	public BigDecimal getValorIcmsEfetivo() { 
		return this.valorIcmsEfetivo; 
	} 

	public void setValorIcmsEfetivo(BigDecimal valorIcmsEfetivo) { 
		this.valorIcmsEfetivo = valorIcmsEfetivo; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}