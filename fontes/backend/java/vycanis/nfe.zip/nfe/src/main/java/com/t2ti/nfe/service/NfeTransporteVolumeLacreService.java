package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.NfeTransporteVolumeLacreModel;
import com.t2ti.nfe.repository.NfeTransporteVolumeLacreRepository;

@Service
public class NfeTransporteVolumeLacreService {

	@Autowired
	private NfeTransporteVolumeLacreRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfeTransporteVolumeLacreModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfeTransporteVolumeLacreModel> getList(Filter filter) {
		String sql = "select * from nfe_transporte_volume_lacre where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfeTransporteVolumeLacreModel.class);
		return query.getResultList();
	}

	public NfeTransporteVolumeLacreModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfeTransporteVolumeLacreModel save(NfeTransporteVolumeLacreModel obj) {
		NfeTransporteVolumeLacreModel nfeTransporteVolumeLacreModel = repository.save(obj);
		return nfeTransporteVolumeLacreModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfeTransporteVolumeLacreModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeTransporteVolumeLacre] - Exception: " + e.getMessage());
		}
	}

}