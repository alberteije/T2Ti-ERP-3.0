package com.t2ti.nfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nfe_detalhe_imposto_pis")
@NamedQuery(name="NfeDetalheImpostoPisModel.findAll", query="SELECT t FROM NfeDetalheImpostoPisModel t")
public class NfeDetalheImpostoPisModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NfeDetalheImpostoPisModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cst_pis")
	private String cstPis;

	@Column(name="valor_base_calculo_pis")
	private BigDecimal valorBaseCalculoPis;

	@Column(name="aliquota_pis_percentual")
	private BigDecimal aliquotaPisPercentual;

	@Column(name="valor_pis")
	private BigDecimal valorPis;

	@Column(name="quantidade_vendida")
	private BigDecimal quantidadeVendida;

	@Column(name="aliquota_pis_reais")
	private BigDecimal aliquotaPisReais;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_nfe_detalhe")
	private NfeDetalheModel nfeDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCstPis() { 
		return this.cstPis; 
	} 

	public void setCstPis(String cstPis) { 
		this.cstPis = cstPis; 
	} 

	public BigDecimal getValorBaseCalculoPis() { 
		return this.valorBaseCalculoPis; 
	} 

	public void setValorBaseCalculoPis(BigDecimal valorBaseCalculoPis) { 
		this.valorBaseCalculoPis = valorBaseCalculoPis; 
	} 

	public BigDecimal getAliquotaPisPercentual() { 
		return this.aliquotaPisPercentual; 
	} 

	public void setAliquotaPisPercentual(BigDecimal aliquotaPisPercentual) { 
		this.aliquotaPisPercentual = aliquotaPisPercentual; 
	} 

	public BigDecimal getValorPis() { 
		return this.valorPis; 
	} 

	public void setValorPis(BigDecimal valorPis) { 
		this.valorPis = valorPis; 
	} 

	public BigDecimal getQuantidadeVendida() { 
		return this.quantidadeVendida; 
	} 

	public void setQuantidadeVendida(BigDecimal quantidadeVendida) { 
		this.quantidadeVendida = quantidadeVendida; 
	} 

	public BigDecimal getAliquotaPisReais() { 
		return this.aliquotaPisReais; 
	} 

	public void setAliquotaPisReais(BigDecimal aliquotaPisReais) { 
		this.aliquotaPisReais = aliquotaPisReais; 
	} 

	public NfeDetalheModel getNfeDetalheModel() { 
	return this.nfeDetalheModel; 
	} 

	public void setNfeDetalheModel(NfeDetalheModel nfeDetalheModel) { 
	this.nfeDetalheModel = nfeDetalheModel; 
	} 

		
}