package com.t2ti.nfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.nfe.util.Filter;
import com.t2ti.nfe.exception.GenericException;
import com.t2ti.nfe.model.NfeTransporteVolumeModel;
import com.t2ti.nfe.repository.NfeTransporteVolumeRepository;

@Service
public class NfeTransporteVolumeService {

	@Autowired
	private NfeTransporteVolumeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NfeTransporteVolumeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NfeTransporteVolumeModel> getList(Filter filter) {
		String sql = "select * from nfe_transporte_volume where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NfeTransporteVolumeModel.class);
		return query.getResultList();
	}

	public NfeTransporteVolumeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NfeTransporteVolumeModel save(NfeTransporteVolumeModel obj) {
		NfeTransporteVolumeModel nfeTransporteVolumeModel = repository.save(obj);
		return nfeTransporteVolumeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NfeTransporteVolumeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NfeTransporteVolume] - Exception: " + e.getMessage());
		}
	}

}