package com.t2ti.nfe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.nfe.model.ProdutoMarcaModel;

public interface ProdutoMarcaRepository extends JpaRepository<ProdutoMarcaModel, Integer> {}