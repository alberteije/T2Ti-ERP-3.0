package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_aereo")
@NamedQuery(name="CteAereoModel.findAll", query="SELECT t FROM CteAereoModel t")
public class CteAereoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteAereoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_minuta")
	private Integer numeroMinuta;

	@Column(name="numero_conhecimento")
	private Integer numeroConhecimento;

	@Temporal(TemporalType.DATE)
@Column(name="data_prevista_entrega")
	private Date dataPrevistaEntrega;

	@Column(name="id_emissor")
	private String idEmissor;

	@Column(name="id_interna_tomador")
	private String idInternaTomador;

	@Column(name="tarifa_classe")
	private String tarifaClasse;

	@Column(name="tarifa_codigo")
	private String tarifaCodigo;

	@Column(name="tarifa_valor")
	private BigDecimal tarifaValor;

	@Column(name="carga_dimensao")
	private String cargaDimensao;

	@Column(name="carga_informacao_manuseio")
	private String cargaInformacaoManuseio;

	@Column(name="carga_especial")
	private String cargaEspecial;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumeroMinuta() { 
		return this.numeroMinuta; 
	} 

	public void setNumeroMinuta(Integer numeroMinuta) { 
		this.numeroMinuta = numeroMinuta; 
	} 

	public Integer getNumeroConhecimento() { 
		return this.numeroConhecimento; 
	} 

	public void setNumeroConhecimento(Integer numeroConhecimento) { 
		this.numeroConhecimento = numeroConhecimento; 
	} 

	public Date getDataPrevistaEntrega() { 
		return this.dataPrevistaEntrega; 
	} 

	public void setDataPrevistaEntrega(Date dataPrevistaEntrega) { 
		this.dataPrevistaEntrega = dataPrevistaEntrega; 
	} 

	public String getIdEmissor() { 
		return this.idEmissor; 
	} 

	public void setIdEmissor(String idEmissor) { 
		this.idEmissor = idEmissor; 
	} 

	public String getIdInternaTomador() { 
		return this.idInternaTomador; 
	} 

	public void setIdInternaTomador(String idInternaTomador) { 
		this.idInternaTomador = idInternaTomador; 
	} 

	public String getTarifaClasse() { 
		return this.tarifaClasse; 
	} 

	public void setTarifaClasse(String tarifaClasse) { 
		this.tarifaClasse = tarifaClasse; 
	} 

	public String getTarifaCodigo() { 
		return this.tarifaCodigo; 
	} 

	public void setTarifaCodigo(String tarifaCodigo) { 
		this.tarifaCodigo = tarifaCodigo; 
	} 

	public BigDecimal getTarifaValor() { 
		return this.tarifaValor; 
	} 

	public void setTarifaValor(BigDecimal tarifaValor) { 
		this.tarifaValor = tarifaValor; 
	} 

	public String getCargaDimensao() { 
		return this.cargaDimensao; 
	} 

	public void setCargaDimensao(String cargaDimensao) { 
		this.cargaDimensao = cargaDimensao; 
	} 

	public String getCargaInformacaoManuseio() { 
		return this.cargaInformacaoManuseio; 
	} 

	public void setCargaInformacaoManuseio(String cargaInformacaoManuseio) { 
		this.cargaInformacaoManuseio = cargaInformacaoManuseio; 
	} 

	public String getCargaEspecial() { 
		return this.cargaEspecial; 
	} 

	public void setCargaEspecial(String cargaEspecial) { 
		this.cargaEspecial = cargaEspecial; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}