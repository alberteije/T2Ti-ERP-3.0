package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_perigoso")
@NamedQuery(name="CtePerigosoModel.findAll", query="SELECT t FROM CtePerigosoModel t")
public class CtePerigosoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CtePerigosoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_onu")
	private String numeroOnu;

	@Column(name="nome_apropriado")
	private String nomeApropriado;

	@Column(name="classe_risco")
	private String classeRisco;

	@Column(name="grupo_embalagem")
	private String grupoEmbalagem;

	@Column(name="quantidade_total_produto")
	private String quantidadeTotalProduto;

	@Column(name="quantidade_tipo_volume")
	private String quantidadeTipoVolume;

	@Column(name="ponto_fulgor")
	private String pontoFulgor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumeroOnu() { 
		return this.numeroOnu; 
	} 

	public void setNumeroOnu(String numeroOnu) { 
		this.numeroOnu = numeroOnu; 
	} 

	public String getNomeApropriado() { 
		return this.nomeApropriado; 
	} 

	public void setNomeApropriado(String nomeApropriado) { 
		this.nomeApropriado = nomeApropriado; 
	} 

	public String getClasseRisco() { 
		return this.classeRisco; 
	} 

	public void setClasseRisco(String classeRisco) { 
		this.classeRisco = classeRisco; 
	} 

	public String getGrupoEmbalagem() { 
		return this.grupoEmbalagem; 
	} 

	public void setGrupoEmbalagem(String grupoEmbalagem) { 
		this.grupoEmbalagem = grupoEmbalagem; 
	} 

	public String getQuantidadeTotalProduto() { 
		return this.quantidadeTotalProduto; 
	} 

	public void setQuantidadeTotalProduto(String quantidadeTotalProduto) { 
		this.quantidadeTotalProduto = quantidadeTotalProduto; 
	} 

	public String getQuantidadeTipoVolume() { 
		return this.quantidadeTipoVolume; 
	} 

	public void setQuantidadeTipoVolume(String quantidadeTipoVolume) { 
		this.quantidadeTipoVolume = quantidadeTipoVolume; 
	} 

	public String getPontoFulgor() { 
		return this.pontoFulgor; 
	} 

	public void setPontoFulgor(String pontoFulgor) { 
		this.pontoFulgor = pontoFulgor; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}