package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_seguro")
@NamedQuery(name="CteSeguroModel.findAll", query="SELECT t FROM CteSeguroModel t")
public class CteSeguroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteSeguroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="responsavel")
	private String responsavel;

	@Column(name="seguradora")
	private String seguradora;

	@Column(name="apolice")
	private String apolice;

	@Column(name="averbacao")
	private String averbacao;

	@Column(name="valor_carga")
	private BigDecimal valorCarga;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getResponsavel() { 
		return this.responsavel; 
	} 

	public void setResponsavel(String responsavel) { 
		this.responsavel = responsavel; 
	} 

	public String getSeguradora() { 
		return this.seguradora; 
	} 

	public void setSeguradora(String seguradora) { 
		this.seguradora = seguradora; 
	} 

	public String getApolice() { 
		return this.apolice; 
	} 

	public void setApolice(String apolice) { 
		this.apolice = apolice; 
	} 

	public String getAverbacao() { 
		return this.averbacao; 
	} 

	public void setAverbacao(String averbacao) { 
		this.averbacao = averbacao; 
	} 

	public BigDecimal getValorCarga() { 
		return this.valorCarga; 
	} 

	public void setValorCarga(BigDecimal valorCarga) { 
		this.valorCarga = valorCarga; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}