package com.t2ti.cte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CteApplication {

	public static void main(String[] args) {
		SpringApplication.run(CteApplication.class, args);
	}

}
