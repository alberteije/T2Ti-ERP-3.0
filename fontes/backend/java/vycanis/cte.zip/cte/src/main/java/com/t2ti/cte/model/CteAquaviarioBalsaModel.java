package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_aquaviario_balsa")
@NamedQuery(name="CteAquaviarioBalsaModel.findAll", query="SELECT t FROM CteAquaviarioBalsaModel t")
public class CteAquaviarioBalsaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteAquaviarioBalsaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_balsa")
	private String idBalsa;

	@Column(name="numero_viagem")
	private Integer numeroViagem;

	@Column(name="direcao")
	private String direcao;

	@Column(name="porto_embarque")
	private String portoEmbarque;

	@Column(name="porto_transbordo")
	private String portoTransbordo;

	@Column(name="porto_destino")
	private String portoDestino;

	@Column(name="tipo_navegacao")
	private String tipoNavegacao;

	@Column(name="irin")
	private String irin;

	@ManyToOne 
	@JoinColumn(name="id_cte_aquaviario")
	private CteAquaviarioModel cteAquaviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getIdBalsa() { 
		return this.idBalsa; 
	} 

	public void setIdBalsa(String idBalsa) { 
		this.idBalsa = idBalsa; 
	} 

	public Integer getNumeroViagem() { 
		return this.numeroViagem; 
	} 

	public void setNumeroViagem(Integer numeroViagem) { 
		this.numeroViagem = numeroViagem; 
	} 

	public String getDirecao() { 
		return this.direcao; 
	} 

	public void setDirecao(String direcao) { 
		this.direcao = direcao; 
	} 

	public String getPortoEmbarque() { 
		return this.portoEmbarque; 
	} 

	public void setPortoEmbarque(String portoEmbarque) { 
		this.portoEmbarque = portoEmbarque; 
	} 

	public String getPortoTransbordo() { 
		return this.portoTransbordo; 
	} 

	public void setPortoTransbordo(String portoTransbordo) { 
		this.portoTransbordo = portoTransbordo; 
	} 

	public String getPortoDestino() { 
		return this.portoDestino; 
	} 

	public void setPortoDestino(String portoDestino) { 
		this.portoDestino = portoDestino; 
	} 

	public String getTipoNavegacao() { 
		return this.tipoNavegacao; 
	} 

	public void setTipoNavegacao(String tipoNavegacao) { 
		this.tipoNavegacao = tipoNavegacao; 
	} 

	public String getIrin() { 
		return this.irin; 
	} 

	public void setIrin(String irin) { 
		this.irin = irin; 
	} 

	public CteAquaviarioModel getCteAquaviarioModel() { 
	return this.cteAquaviarioModel; 
	} 

	public void setCteAquaviarioModel(CteAquaviarioModel cteAquaviarioModel) { 
	this.cteAquaviarioModel = cteAquaviarioModel; 
	} 

		
}