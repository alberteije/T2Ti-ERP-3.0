package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_passagem")
@NamedQuery(name="CtePassagemModel.findAll", query="SELECT t FROM CtePassagemModel t")
public class CtePassagemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CtePassagemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="sigla_passagem")
	private String siglaPassagem;

	@Column(name="sigla_destino")
	private String siglaDestino;

	@Column(name="rota")
	private String rota;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getSiglaPassagem() { 
		return this.siglaPassagem; 
	} 

	public void setSiglaPassagem(String siglaPassagem) { 
		this.siglaPassagem = siglaPassagem; 
	} 

	public String getSiglaDestino() { 
		return this.siglaDestino; 
	} 

	public void setSiglaDestino(String siglaDestino) { 
		this.siglaDestino = siglaDestino; 
	} 

	public String getRota() { 
		return this.rota; 
	} 

	public void setRota(String rota) { 
		this.rota = rota; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}