package com.t2ti.cte.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cte.util.Filter;
import com.t2ti.cte.exception.GenericException;
import com.t2ti.cte.model.CteInformacaoNfTransporteModel;
import com.t2ti.cte.repository.CteInformacaoNfTransporteRepository;

@Service
public class CteInformacaoNfTransporteService {

	@Autowired
	private CteInformacaoNfTransporteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CteInformacaoNfTransporteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CteInformacaoNfTransporteModel> getList(Filter filter) {
		String sql = "select * from cte_informacao_nf_transporte where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CteInformacaoNfTransporteModel.class);
		return query.getResultList();
	}

	public CteInformacaoNfTransporteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CteInformacaoNfTransporteModel save(CteInformacaoNfTransporteModel obj) {
		CteInformacaoNfTransporteModel cteInformacaoNfTransporteModel = repository.save(obj);
		return cteInformacaoNfTransporteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CteInformacaoNfTransporteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CteInformacaoNfTransporte] - Exception: " + e.getMessage());
		}
	}

}