package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_informacao_nf_transporte")
@NamedQuery(name="CteInformacaoNfTransporteModel.findAll", query="SELECT t FROM CteInformacaoNfTransporteModel t")
public class CteInformacaoNfTransporteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteInformacaoNfTransporteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo_unidade_transporte")
	private String tipoUnidadeTransporte;

	@Column(name="id_unidade_transporte")
	private String idUnidadeTransporte;

	@ManyToOne 
	@JoinColumn(name="id_cte_informacao_nf")
	private CteInformacaoNfOutrosModel cteInformacaoNfOutrosModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipoUnidadeTransporte() { 
		return this.tipoUnidadeTransporte; 
	} 

	public void setTipoUnidadeTransporte(String tipoUnidadeTransporte) { 
		this.tipoUnidadeTransporte = tipoUnidadeTransporte; 
	} 

	public String getIdUnidadeTransporte() { 
		return this.idUnidadeTransporte; 
	} 

	public void setIdUnidadeTransporte(String idUnidadeTransporte) { 
		this.idUnidadeTransporte = idUnidadeTransporte; 
	} 

	public CteInformacaoNfOutrosModel getCteInformacaoNfOutrosModel() { 
	return this.cteInformacaoNfOutrosModel; 
	} 

	public void setCteInformacaoNfOutrosModel(CteInformacaoNfOutrosModel cteInformacaoNfOutrosModel) { 
	this.cteInformacaoNfOutrosModel = cteInformacaoNfOutrosModel; 
	} 

		
}