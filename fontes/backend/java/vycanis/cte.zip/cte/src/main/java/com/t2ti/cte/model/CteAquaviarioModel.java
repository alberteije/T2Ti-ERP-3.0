package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_aquaviario")
@NamedQuery(name="CteAquaviarioModel.findAll", query="SELECT t FROM CteAquaviarioModel t")
public class CteAquaviarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteAquaviarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor_prestacao")
	private BigDecimal valorPrestacao;

	@Column(name="afrmm")
	private BigDecimal afrmm;

	@Column(name="numero_booking")
	private String numeroBooking;

	@Column(name="numero_controle")
	private String numeroControle;

	@Column(name="id_navio")
	private String idNavio;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValorPrestacao() { 
		return this.valorPrestacao; 
	} 

	public void setValorPrestacao(BigDecimal valorPrestacao) { 
		this.valorPrestacao = valorPrestacao; 
	} 

	public BigDecimal getAfrmm() { 
		return this.afrmm; 
	} 

	public void setAfrmm(BigDecimal afrmm) { 
		this.afrmm = afrmm; 
	} 

	public String getNumeroBooking() { 
		return this.numeroBooking; 
	} 

	public void setNumeroBooking(String numeroBooking) { 
		this.numeroBooking = numeroBooking; 
	} 

	public String getNumeroControle() { 
		return this.numeroControle; 
	} 

	public void setNumeroControle(String numeroControle) { 
		this.numeroControle = numeroControle; 
	} 

	public String getIdNavio() { 
		return this.idNavio; 
	} 

	public void setIdNavio(String idNavio) { 
		this.idNavio = idNavio; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}