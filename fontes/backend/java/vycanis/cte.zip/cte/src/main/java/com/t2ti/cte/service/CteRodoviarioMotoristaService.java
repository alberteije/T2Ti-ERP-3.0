package com.t2ti.cte.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cte.util.Filter;
import com.t2ti.cte.exception.GenericException;
import com.t2ti.cte.model.CteRodoviarioMotoristaModel;
import com.t2ti.cte.repository.CteRodoviarioMotoristaRepository;

@Service
public class CteRodoviarioMotoristaService {

	@Autowired
	private CteRodoviarioMotoristaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CteRodoviarioMotoristaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CteRodoviarioMotoristaModel> getList(Filter filter) {
		String sql = "select * from cte_rodoviario_motorista where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CteRodoviarioMotoristaModel.class);
		return query.getResultList();
	}

	public CteRodoviarioMotoristaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CteRodoviarioMotoristaModel save(CteRodoviarioMotoristaModel obj) {
		CteRodoviarioMotoristaModel cteRodoviarioMotoristaModel = repository.save(obj);
		return cteRodoviarioMotoristaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CteRodoviarioMotoristaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CteRodoviarioMotorista] - Exception: " + e.getMessage());
		}
	}

}