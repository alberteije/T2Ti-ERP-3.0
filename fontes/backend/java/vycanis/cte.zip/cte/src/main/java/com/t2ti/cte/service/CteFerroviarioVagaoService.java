package com.t2ti.cte.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cte.util.Filter;
import com.t2ti.cte.exception.GenericException;
import com.t2ti.cte.model.CteFerroviarioVagaoModel;
import com.t2ti.cte.repository.CteFerroviarioVagaoRepository;

@Service
public class CteFerroviarioVagaoService {

	@Autowired
	private CteFerroviarioVagaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CteFerroviarioVagaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CteFerroviarioVagaoModel> getList(Filter filter) {
		String sql = "select * from cte_ferroviario_vagao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CteFerroviarioVagaoModel.class);
		return query.getResultList();
	}

	public CteFerroviarioVagaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CteFerroviarioVagaoModel save(CteFerroviarioVagaoModel obj) {
		CteFerroviarioVagaoModel cteFerroviarioVagaoModel = repository.save(obj);
		return cteFerroviarioVagaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CteFerroviarioVagaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CteFerroviarioVagao] - Exception: " + e.getMessage());
		}
	}

}