package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_fatura")
@NamedQuery(name="CteFaturaModel.findAll", query="SELECT t FROM CteFaturaModel t")
public class CteFaturaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteFaturaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Column(name="valor_original")
	private BigDecimal valorOriginal;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_liquido")
	private BigDecimal valorLiquido;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public BigDecimal getValorOriginal() { 
		return this.valorOriginal; 
	} 

	public void setValorOriginal(BigDecimal valorOriginal) { 
		this.valorOriginal = valorOriginal; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorLiquido() { 
		return this.valorLiquido; 
	} 

	public void setValorLiquido(BigDecimal valorLiquido) { 
		this.valorLiquido = valorLiquido; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}