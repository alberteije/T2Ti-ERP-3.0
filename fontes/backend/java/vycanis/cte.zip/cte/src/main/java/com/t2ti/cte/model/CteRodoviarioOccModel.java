package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_rodoviario_occ")
@NamedQuery(name="CteRodoviarioOccModel.findAll", query="SELECT t FROM CteRodoviarioOccModel t")
public class CteRodoviarioOccModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteRodoviarioOccModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="serie")
	private String serie;

	@Column(name="numero")
	private Integer numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="codigo_interno")
	private String codigoInterno;

	@Column(name="ie")
	private String ie;

	@Column(name="uf")
	private String uf;

	@Column(name="telefone")
	private String telefone;

	@ManyToOne 
	@JoinColumn(name="id_cte_rodoviario")
	private CteRodoviarioModel cteRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getCodigoInterno() { 
		return this.codigoInterno; 
	} 

	public void setCodigoInterno(String codigoInterno) { 
		this.codigoInterno = codigoInterno; 
	} 

	public String getIe() { 
		return this.ie; 
	} 

	public void setIe(String ie) { 
		this.ie = ie; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getTelefone() { 
		return this.telefone; 
	} 

	public void setTelefone(String telefone) { 
		this.telefone = telefone; 
	} 

	public CteRodoviarioModel getCteRodoviarioModel() { 
	return this.cteRodoviarioModel; 
	} 

	public void setCteRodoviarioModel(CteRodoviarioModel cteRodoviarioModel) { 
	this.cteRodoviarioModel = cteRodoviarioModel; 
	} 

		
}