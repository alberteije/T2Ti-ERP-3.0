package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_veiculo_novo")
@NamedQuery(name="CteVeiculoNovoModel.findAll", query="SELECT t FROM CteVeiculoNovoModel t")
public class CteVeiculoNovoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteVeiculoNovoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="chassi")
	private String chassi;

	@Column(name="cor")
	private String cor;

	@Column(name="descricao_cor")
	private String descricaoCor;

	@Column(name="codigo_marca_modelo")
	private String codigoMarcaModelo;

	@Column(name="valor_unitario")
	private BigDecimal valorUnitario;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getChassi() { 
		return this.chassi; 
	} 

	public void setChassi(String chassi) { 
		this.chassi = chassi; 
	} 

	public String getCor() { 
		return this.cor; 
	} 

	public void setCor(String cor) { 
		this.cor = cor; 
	} 

	public String getDescricaoCor() { 
		return this.descricaoCor; 
	} 

	public void setDescricaoCor(String descricaoCor) { 
		this.descricaoCor = descricaoCor; 
	} 

	public String getCodigoMarcaModelo() { 
		return this.codigoMarcaModelo; 
	} 

	public void setCodigoMarcaModelo(String codigoMarcaModelo) { 
		this.codigoMarcaModelo = codigoMarcaModelo; 
	} 

	public BigDecimal getValorUnitario() { 
		return this.valorUnitario; 
	} 

	public void setValorUnitario(BigDecimal valorUnitario) { 
		this.valorUnitario = valorUnitario; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}