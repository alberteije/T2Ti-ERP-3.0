package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_componente")
@NamedQuery(name="CteComponenteModel.findAll", query="SELECT t FROM CteComponenteModel t")
public class CteComponenteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteComponenteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}