package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_informacao_nf_carga")
@NamedQuery(name="CteInformacaoNfCargaModel.findAll", query="SELECT t FROM CteInformacaoNfCargaModel t")
public class CteInformacaoNfCargaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteInformacaoNfCargaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo_unidade_carga")
	private String tipoUnidadeCarga;

	@Column(name="id_unidade_carga")
	private String idUnidadeCarga;

	@ManyToOne 
	@JoinColumn(name="id_cte_informacao_nf")
	private CteInformacaoNfOutrosModel cteInformacaoNfOutrosModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipoUnidadeCarga() { 
		return this.tipoUnidadeCarga; 
	} 

	public void setTipoUnidadeCarga(String tipoUnidadeCarga) { 
		this.tipoUnidadeCarga = tipoUnidadeCarga; 
	} 

	public String getIdUnidadeCarga() { 
		return this.idUnidadeCarga; 
	} 

	public void setIdUnidadeCarga(String idUnidadeCarga) { 
		this.idUnidadeCarga = idUnidadeCarga; 
	} 

	public CteInformacaoNfOutrosModel getCteInformacaoNfOutrosModel() { 
	return this.cteInformacaoNfOutrosModel; 
	} 

	public void setCteInformacaoNfOutrosModel(CteInformacaoNfOutrosModel cteInformacaoNfOutrosModel) { 
	this.cteInformacaoNfOutrosModel = cteInformacaoNfOutrosModel; 
	} 

		
}