package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="cte_documento_anterior_id")
@NamedQuery(name="CteDocumentoAnteriorIdModel.findAll", query="SELECT t FROM CteDocumentoAnteriorIdModel t")
public class CteDocumentoAnteriorIdModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteDocumentoAnteriorIdModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo")
	private String tipo;

	@Column(name="serie")
	private String serie;

	@Column(name="subserie")
	private String subserie;

	@Column(name="numero")
	private String numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Column(name="chave_cte")
	private String chaveCte;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public String getSubserie() { 
		return this.subserie; 
	} 

	public void setSubserie(String subserie) { 
		this.subserie = subserie; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public String getChaveCte() { 
		return this.chaveCte; 
	} 

	public void setChaveCte(String chaveCte) { 
		this.chaveCte = chaveCte; 
	} 

		
}