package com.t2ti.cte.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.cte.exception.GenericException;
import com.t2ti.cte.exception.ResourseNotFoundException;
import com.t2ti.cte.exception.BadRequestException;
import com.t2ti.cte.util.Filter;
import com.t2ti.cte.model.CteRodoviarioLacreModel;
import com.t2ti.cte.service.CteRodoviarioLacreService;

@RestController
@RequestMapping(value = "/cte-rodoviario-lacre", produces = "application/json;charset=UTF-8")
public class CteRodoviarioLacreController {

	@Autowired
	private CteRodoviarioLacreService service;
	
	@GetMapping({ "", "/" })
	public List<CteRodoviarioLacreModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [CteRodoviarioLacre] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public CteRodoviarioLacreModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found CteRodoviarioLacre].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found CteRodoviarioLacre] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public CteRodoviarioLacreModel insert(@RequestBody CteRodoviarioLacreModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert CteRodoviarioLacre] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public CteRodoviarioLacreModel update(@RequestBody CteRodoviarioLacreModel objJson) {	
		try {			
			CteRodoviarioLacreModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update CteRodoviarioLacre].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update CteRodoviarioLacre] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CteRodoviarioLacre] - Exception: " + e.getMessage());
		}
	}
	
}