package com.t2ti.cte.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cte.util.Filter;
import com.t2ti.cte.exception.GenericException;
import com.t2ti.cte.model.CteInfNfCargaLacreModel;
import com.t2ti.cte.repository.CteInfNfCargaLacreRepository;

@Service
public class CteInfNfCargaLacreService {

	@Autowired
	private CteInfNfCargaLacreRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CteInfNfCargaLacreModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CteInfNfCargaLacreModel> getList(Filter filter) {
		String sql = "select * from cte_inf_nf_carga_lacre where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CteInfNfCargaLacreModel.class);
		return query.getResultList();
	}

	public CteInfNfCargaLacreModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CteInfNfCargaLacreModel save(CteInfNfCargaLacreModel obj) {
		CteInfNfCargaLacreModel cteInfNfCargaLacreModel = repository.save(obj);
		return cteInfNfCargaLacreModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CteInfNfCargaLacreModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CteInfNfCargaLacre] - Exception: " + e.getMessage());
		}
	}

}