package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_carga")
@NamedQuery(name="CteCargaModel.findAll", query="SELECT t FROM CteCargaModel t")
public class CteCargaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteCargaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_unidade_medida")
	private String codigoUnidadeMedida;

	@Column(name="tipo_medida")
	private String tipoMedida;

	@Column(name="quantidade")
	private BigDecimal quantidade;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoUnidadeMedida() { 
		return this.codigoUnidadeMedida; 
	} 

	public void setCodigoUnidadeMedida(String codigoUnidadeMedida) { 
		this.codigoUnidadeMedida = codigoUnidadeMedida; 
	} 

	public String getTipoMedida() { 
		return this.tipoMedida; 
	} 

	public void setTipoMedida(String tipoMedida) { 
		this.tipoMedida = tipoMedida; 
	} 

	public BigDecimal getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(BigDecimal quantidade) { 
		this.quantidade = quantidade; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}