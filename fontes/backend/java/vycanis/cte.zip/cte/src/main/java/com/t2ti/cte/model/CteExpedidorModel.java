package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_expedidor")
@NamedQuery(name="CteExpedidorModel.findAll", query="SELECT t FROM CteExpedidorModel t")
public class CteExpedidorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteExpedidorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="cpf")
	private String cpf;

	@Column(name="ie")
	private String ie;

	@Column(name="nome")
	private String nome;

	@Column(name="fantasia")
	private String fantasia;

	@Column(name="telefone")
	private String telefone;

	@Column(name="logradouro")
	private String logradouro;

	@Column(name="numero")
	private String numero;

	@Column(name="complemento")
	private String complemento;

	@Column(name="bairro")
	private String bairro;

	@Column(name="codigo_municipio")
	private Integer codigoMunicipio;

	@Column(name="nome_municipio")
	private String nomeMunicipio;

	@Column(name="uf")
	private String uf;

	@Column(name="cep")
	private String cep;

	@Column(name="codigo_pais")
	private Integer codigoPais;

	@Column(name="nome_pais")
	private String nomePais;

	@Column(name="email")
	private String email;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public String getIe() { 
		return this.ie; 
	} 

	public void setIe(String ie) { 
		this.ie = ie; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getFantasia() { 
		return this.fantasia; 
	} 

	public void setFantasia(String fantasia) { 
		this.fantasia = fantasia; 
	} 

	public String getTelefone() { 
		return this.telefone; 
	} 

	public void setTelefone(String telefone) { 
		this.telefone = telefone; 
	} 

	public String getLogradouro() { 
		return this.logradouro; 
	} 

	public void setLogradouro(String logradouro) { 
		this.logradouro = logradouro; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getComplemento() { 
		return this.complemento; 
	} 

	public void setComplemento(String complemento) { 
		this.complemento = complemento; 
	} 

	public String getBairro() { 
		return this.bairro; 
	} 

	public void setBairro(String bairro) { 
		this.bairro = bairro; 
	} 

	public Integer getCodigoMunicipio() { 
		return this.codigoMunicipio; 
	} 

	public void setCodigoMunicipio(Integer codigoMunicipio) { 
		this.codigoMunicipio = codigoMunicipio; 
	} 

	public String getNomeMunicipio() { 
		return this.nomeMunicipio; 
	} 

	public void setNomeMunicipio(String nomeMunicipio) { 
		this.nomeMunicipio = nomeMunicipio; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getCep() { 
		return this.cep; 
	} 

	public void setCep(String cep) { 
		this.cep = cep; 
	} 

	public Integer getCodigoPais() { 
		return this.codigoPais; 
	} 

	public void setCodigoPais(Integer codigoPais) { 
		this.codigoPais = codigoPais; 
	} 

	public String getNomePais() { 
		return this.nomePais; 
	} 

	public void setNomePais(String nomePais) { 
		this.nomePais = nomePais; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}