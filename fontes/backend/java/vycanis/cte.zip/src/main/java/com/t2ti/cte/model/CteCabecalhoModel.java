package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="cte_cabecalho")
@NamedQuery(name="CteCabecalhoModel.findAll", query="SELECT t FROM CteCabecalhoModel t")
public class CteCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="natureza_operacao")
	private String naturezaOperacao;

	@Column(name="chave_acesso")
	private String chaveAcesso;

	@Column(name="digito_chave_acesso")
	private String digitoChaveAcesso;

	@Column(name="codigo_numerico")
	private String codigoNumerico;

	@Column(name="serie")
	private String serie;

	@Column(name="numero")
	private String numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_emissao")
	private Date dataHoraEmissao;

	@Column(name="uf_emitente")
	private String ufEmitente;

	@Column(name="cfop")
	private Integer cfop;

	@Column(name="forma_pagamento")
	private String formaPagamento;

	@Column(name="modelo")
	private String modelo;

	@Column(name="formato_impressao_dacte")
	private String formatoImpressaoDacte;

	@Column(name="tipo_emissao")
	private String tipoEmissao;

	@Column(name="ambiente")
	private String ambiente;

	@Column(name="tipo_cte")
	private String tipoCte;

	@Column(name="processo_emissao")
	private String processoEmissao;

	@Column(name="versao_processo_emissao")
	private String versaoProcessoEmissao;

	@Column(name="chave_referenciado")
	private String chaveReferenciado;

	@Column(name="codigo_municipio_envio")
	private Integer codigoMunicipioEnvio;

	@Column(name="nome_municipio_envio")
	private String nomeMunicipioEnvio;

	@Column(name="uf_envio")
	private String ufEnvio;

	@Column(name="modal")
	private String modal;

	@Column(name="tipo_servico")
	private String tipoServico;

	@Column(name="codigo_municipio_ini_prestacao")
	private Integer codigoMunicipioIniPrestacao;

	@Column(name="nome_municipio_ini_prestacao")
	private String nomeMunicipioIniPrestacao;

	@Column(name="uf_ini_prestacao")
	private String ufIniPrestacao;

	@Column(name="codigo_municipio_fim_prestacao")
	private Integer codigoMunicipioFimPrestacao;

	@Column(name="nome_municipio_fim_prestacao")
	private String nomeMunicipioFimPrestacao;

	@Column(name="uf_fim_prestacao")
	private String ufFimPrestacao;

	@Column(name="retira")
	private String retira;

	@Column(name="retira_detalhe")
	private String retiraDetalhe;

	@Column(name="tomador")
	private String tomador;

	@Temporal(TemporalType.DATE)
@Column(name="data_entrada_contingencia")
	private Date dataEntradaContingencia;

	@Column(name="justificativa_contingencia")
	private String justificativaContingencia;

	@Column(name="carac_adicional_transporte")
	private String caracAdicionalTransporte;

	@Column(name="carac_adicional_servico")
	private String caracAdicionalServico;

	@Column(name="funcionario_emissor")
	private String funcionarioEmissor;

	@Column(name="fluxo_origem")
	private String fluxoOrigem;

	@Column(name="entrega_tipo_periodo")
	private String entregaTipoPeriodo;

	@Temporal(TemporalType.DATE)
@Column(name="entrega_data_programada")
	private Date entregaDataProgramada;

	@Temporal(TemporalType.DATE)
@Column(name="entrega_data_inicial")
	private Date entregaDataInicial;

	@Temporal(TemporalType.DATE)
@Column(name="entrega_data_final")
	private Date entregaDataFinal;

	@Column(name="entrega_tipo_hora")
	private String entregaTipoHora;

	@Column(name="entrega_hora_programada")
	private String entregaHoraProgramada;

	@Column(name="entrega_hora_inicial")
	private String entregaHoraInicial;

	@Column(name="entrega_hora_final")
	private String entregaHoraFinal;

	@Column(name="municipio_origem_calculo")
	private String municipioOrigemCalculo;

	@Column(name="municipio_destino_calculo")
	private String municipioDestinoCalculo;

	@Column(name="observacoes_gerais")
	private String observacoesGerais;

	@Column(name="valor_total_servico")
	private BigDecimal valorTotalServico;

	@Column(name="valor_receber")
	private BigDecimal valorReceber;

	@Column(name="cst")
	private String cst;

	@Column(name="base_calculo_icms")
	private BigDecimal baseCalculoIcms;

	@Column(name="aliquota_icms")
	private BigDecimal aliquotaIcms;

	@Column(name="valor_icms")
	private BigDecimal valorIcms;

	@Column(name="percentual_reducao_bc_icms")
	private BigDecimal percentualReducaoBcIcms;

	@Column(name="valor_bc_icms_st_retido")
	private BigDecimal valorBcIcmsStRetido;

	@Column(name="valor_icms_st_retido")
	private BigDecimal valorIcmsStRetido;

	@Column(name="aliquota_icms_st_retido")
	private BigDecimal aliquotaIcmsStRetido;

	@Column(name="valor_credito_presumido_icms")
	private BigDecimal valorCreditoPresumidoIcms;

	@Column(name="percentual_bc_icms_outra_uf")
	private BigDecimal percentualBcIcmsOutraUf;

	@Column(name="valor_bc_icms_outra_uf")
	private BigDecimal valorBcIcmsOutraUf;

	@Column(name="aliquota_icms_outra_uf")
	private BigDecimal aliquotaIcmsOutraUf;

	@Column(name="valor_icms_outra_uf")
	private BigDecimal valorIcmsOutraUf;

	@Column(name="simples_nacional_indicador")
	private String simplesNacionalIndicador;

	@Column(name="simples_nacional_total")
	private BigDecimal simplesNacionalTotal;

	@Column(name="informacoes_add_fisco")
	private String informacoesAddFisco;

	@Column(name="valor_total_carga")
	private BigDecimal valorTotalCarga;

	@Column(name="produto_predominante")
	private String produtoPredominante;

	@Column(name="carga_outras_caracteristicas")
	private String cargaOutrasCaracteristicas;

	@Column(name="modal_versao_layout")
	private Integer modalVersaoLayout;

	@Column(name="chave_cte_substituido")
	private String chaveCteSubstituido;

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteEmitenteModel> cteEmitenteModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteLocalColetaModel> cteLocalColetaModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteTomadorModel> cteTomadorModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CtePassagemModel> ctePassagemModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteRemetenteModel> cteRemetenteModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteExpedidorModel> cteExpedidorModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteRecebedorModel> cteRecebedorModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteDestinatarioModel> cteDestinatarioModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteLocalEntregaModel> cteLocalEntregaModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteComponenteModel> cteComponenteModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteCargaModel> cteCargaModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteInformacaoNfOutrosModel> cteInformacaoNfOutrosModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteSeguroModel> cteSeguroModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CtePerigosoModel> ctePerigosoModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteVeiculoNovoModel> cteVeiculoNovoModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteFaturaModel> cteFaturaModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteDuplicataModel> cteDuplicataModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteRodoviarioModel> cteRodoviarioModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteAereoModel> cteAereoModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteAquaviarioModel> cteAquaviarioModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteFerroviarioModel> cteFerroviarioModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteDutoviarioModel> cteDutoviarioModelList; 

	@OneToMany(mappedBy = "cteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CteMultimodalModel> cteMultimodalModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNaturezaOperacao() { 
		return this.naturezaOperacao; 
	} 

	public void setNaturezaOperacao(String naturezaOperacao) { 
		this.naturezaOperacao = naturezaOperacao; 
	} 

	public String getChaveAcesso() { 
		return this.chaveAcesso; 
	} 

	public void setChaveAcesso(String chaveAcesso) { 
		this.chaveAcesso = chaveAcesso; 
	} 

	public String getDigitoChaveAcesso() { 
		return this.digitoChaveAcesso; 
	} 

	public void setDigitoChaveAcesso(String digitoChaveAcesso) { 
		this.digitoChaveAcesso = digitoChaveAcesso; 
	} 

	public String getCodigoNumerico() { 
		return this.codigoNumerico; 
	} 

	public void setCodigoNumerico(String codigoNumerico) { 
		this.codigoNumerico = codigoNumerico; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public Date getDataHoraEmissao() { 
		return this.dataHoraEmissao; 
	} 

	public void setDataHoraEmissao(Date dataHoraEmissao) { 
		this.dataHoraEmissao = dataHoraEmissao; 
	} 

	public String getUfEmitente() { 
		return this.ufEmitente; 
	} 

	public void setUfEmitente(String ufEmitente) { 
		this.ufEmitente = ufEmitente; 
	} 

	public Integer getCfop() { 
		return this.cfop; 
	} 

	public void setCfop(Integer cfop) { 
		this.cfop = cfop; 
	} 

	public String getFormaPagamento() { 
		return this.formaPagamento; 
	} 

	public void setFormaPagamento(String formaPagamento) { 
		this.formaPagamento = formaPagamento; 
	} 

	public String getModelo() { 
		return this.modelo; 
	} 

	public void setModelo(String modelo) { 
		this.modelo = modelo; 
	} 

	public String getFormatoImpressaoDacte() { 
		return this.formatoImpressaoDacte; 
	} 

	public void setFormatoImpressaoDacte(String formatoImpressaoDacte) { 
		this.formatoImpressaoDacte = formatoImpressaoDacte; 
	} 

	public String getTipoEmissao() { 
		return this.tipoEmissao; 
	} 

	public void setTipoEmissao(String tipoEmissao) { 
		this.tipoEmissao = tipoEmissao; 
	} 

	public String getAmbiente() { 
		return this.ambiente; 
	} 

	public void setAmbiente(String ambiente) { 
		this.ambiente = ambiente; 
	} 

	public String getTipoCte() { 
		return this.tipoCte; 
	} 

	public void setTipoCte(String tipoCte) { 
		this.tipoCte = tipoCte; 
	} 

	public String getProcessoEmissao() { 
		return this.processoEmissao; 
	} 

	public void setProcessoEmissao(String processoEmissao) { 
		this.processoEmissao = processoEmissao; 
	} 

	public String getVersaoProcessoEmissao() { 
		return this.versaoProcessoEmissao; 
	} 

	public void setVersaoProcessoEmissao(String versaoProcessoEmissao) { 
		this.versaoProcessoEmissao = versaoProcessoEmissao; 
	} 

	public String getChaveReferenciado() { 
		return this.chaveReferenciado; 
	} 

	public void setChaveReferenciado(String chaveReferenciado) { 
		this.chaveReferenciado = chaveReferenciado; 
	} 

	public Integer getCodigoMunicipioEnvio() { 
		return this.codigoMunicipioEnvio; 
	} 

	public void setCodigoMunicipioEnvio(Integer codigoMunicipioEnvio) { 
		this.codigoMunicipioEnvio = codigoMunicipioEnvio; 
	} 

	public String getNomeMunicipioEnvio() { 
		return this.nomeMunicipioEnvio; 
	} 

	public void setNomeMunicipioEnvio(String nomeMunicipioEnvio) { 
		this.nomeMunicipioEnvio = nomeMunicipioEnvio; 
	} 

	public String getUfEnvio() { 
		return this.ufEnvio; 
	} 

	public void setUfEnvio(String ufEnvio) { 
		this.ufEnvio = ufEnvio; 
	} 

	public String getModal() { 
		return this.modal; 
	} 

	public void setModal(String modal) { 
		this.modal = modal; 
	} 

	public String getTipoServico() { 
		return this.tipoServico; 
	} 

	public void setTipoServico(String tipoServico) { 
		this.tipoServico = tipoServico; 
	} 

	public Integer getCodigoMunicipioIniPrestacao() { 
		return this.codigoMunicipioIniPrestacao; 
	} 

	public void setCodigoMunicipioIniPrestacao(Integer codigoMunicipioIniPrestacao) { 
		this.codigoMunicipioIniPrestacao = codigoMunicipioIniPrestacao; 
	} 

	public String getNomeMunicipioIniPrestacao() { 
		return this.nomeMunicipioIniPrestacao; 
	} 

	public void setNomeMunicipioIniPrestacao(String nomeMunicipioIniPrestacao) { 
		this.nomeMunicipioIniPrestacao = nomeMunicipioIniPrestacao; 
	} 

	public String getUfIniPrestacao() { 
		return this.ufIniPrestacao; 
	} 

	public void setUfIniPrestacao(String ufIniPrestacao) { 
		this.ufIniPrestacao = ufIniPrestacao; 
	} 

	public Integer getCodigoMunicipioFimPrestacao() { 
		return this.codigoMunicipioFimPrestacao; 
	} 

	public void setCodigoMunicipioFimPrestacao(Integer codigoMunicipioFimPrestacao) { 
		this.codigoMunicipioFimPrestacao = codigoMunicipioFimPrestacao; 
	} 

	public String getNomeMunicipioFimPrestacao() { 
		return this.nomeMunicipioFimPrestacao; 
	} 

	public void setNomeMunicipioFimPrestacao(String nomeMunicipioFimPrestacao) { 
		this.nomeMunicipioFimPrestacao = nomeMunicipioFimPrestacao; 
	} 

	public String getUfFimPrestacao() { 
		return this.ufFimPrestacao; 
	} 

	public void setUfFimPrestacao(String ufFimPrestacao) { 
		this.ufFimPrestacao = ufFimPrestacao; 
	} 

	public String getRetira() { 
		return this.retira; 
	} 

	public void setRetira(String retira) { 
		this.retira = retira; 
	} 

	public String getRetiraDetalhe() { 
		return this.retiraDetalhe; 
	} 

	public void setRetiraDetalhe(String retiraDetalhe) { 
		this.retiraDetalhe = retiraDetalhe; 
	} 

	public String getTomador() { 
		return this.tomador; 
	} 

	public void setTomador(String tomador) { 
		this.tomador = tomador; 
	} 

	public Date getDataEntradaContingencia() { 
		return this.dataEntradaContingencia; 
	} 

	public void setDataEntradaContingencia(Date dataEntradaContingencia) { 
		this.dataEntradaContingencia = dataEntradaContingencia; 
	} 

	public String getJustificativaContingencia() { 
		return this.justificativaContingencia; 
	} 

	public void setJustificativaContingencia(String justificativaContingencia) { 
		this.justificativaContingencia = justificativaContingencia; 
	} 

	public String getCaracAdicionalTransporte() { 
		return this.caracAdicionalTransporte; 
	} 

	public void setCaracAdicionalTransporte(String caracAdicionalTransporte) { 
		this.caracAdicionalTransporte = caracAdicionalTransporte; 
	} 

	public String getCaracAdicionalServico() { 
		return this.caracAdicionalServico; 
	} 

	public void setCaracAdicionalServico(String caracAdicionalServico) { 
		this.caracAdicionalServico = caracAdicionalServico; 
	} 

	public String getFuncionarioEmissor() { 
		return this.funcionarioEmissor; 
	} 

	public void setFuncionarioEmissor(String funcionarioEmissor) { 
		this.funcionarioEmissor = funcionarioEmissor; 
	} 

	public String getFluxoOrigem() { 
		return this.fluxoOrigem; 
	} 

	public void setFluxoOrigem(String fluxoOrigem) { 
		this.fluxoOrigem = fluxoOrigem; 
	} 

	public String getEntregaTipoPeriodo() { 
		return this.entregaTipoPeriodo; 
	} 

	public void setEntregaTipoPeriodo(String entregaTipoPeriodo) { 
		this.entregaTipoPeriodo = entregaTipoPeriodo; 
	} 

	public Date getEntregaDataProgramada() { 
		return this.entregaDataProgramada; 
	} 

	public void setEntregaDataProgramada(Date entregaDataProgramada) { 
		this.entregaDataProgramada = entregaDataProgramada; 
	} 

	public Date getEntregaDataInicial() { 
		return this.entregaDataInicial; 
	} 

	public void setEntregaDataInicial(Date entregaDataInicial) { 
		this.entregaDataInicial = entregaDataInicial; 
	} 

	public Date getEntregaDataFinal() { 
		return this.entregaDataFinal; 
	} 

	public void setEntregaDataFinal(Date entregaDataFinal) { 
		this.entregaDataFinal = entregaDataFinal; 
	} 

	public String getEntregaTipoHora() { 
		return this.entregaTipoHora; 
	} 

	public void setEntregaTipoHora(String entregaTipoHora) { 
		this.entregaTipoHora = entregaTipoHora; 
	} 

	public String getEntregaHoraProgramada() { 
		return this.entregaHoraProgramada; 
	} 

	public void setEntregaHoraProgramada(String entregaHoraProgramada) { 
		this.entregaHoraProgramada = entregaHoraProgramada; 
	} 

	public String getEntregaHoraInicial() { 
		return this.entregaHoraInicial; 
	} 

	public void setEntregaHoraInicial(String entregaHoraInicial) { 
		this.entregaHoraInicial = entregaHoraInicial; 
	} 

	public String getEntregaHoraFinal() { 
		return this.entregaHoraFinal; 
	} 

	public void setEntregaHoraFinal(String entregaHoraFinal) { 
		this.entregaHoraFinal = entregaHoraFinal; 
	} 

	public String getMunicipioOrigemCalculo() { 
		return this.municipioOrigemCalculo; 
	} 

	public void setMunicipioOrigemCalculo(String municipioOrigemCalculo) { 
		this.municipioOrigemCalculo = municipioOrigemCalculo; 
	} 

	public String getMunicipioDestinoCalculo() { 
		return this.municipioDestinoCalculo; 
	} 

	public void setMunicipioDestinoCalculo(String municipioDestinoCalculo) { 
		this.municipioDestinoCalculo = municipioDestinoCalculo; 
	} 

	public String getObservacoesGerais() { 
		return this.observacoesGerais; 
	} 

	public void setObservacoesGerais(String observacoesGerais) { 
		this.observacoesGerais = observacoesGerais; 
	} 

	public BigDecimal getValorTotalServico() { 
		return this.valorTotalServico; 
	} 

	public void setValorTotalServico(BigDecimal valorTotalServico) { 
		this.valorTotalServico = valorTotalServico; 
	} 

	public BigDecimal getValorReceber() { 
		return this.valorReceber; 
	} 

	public void setValorReceber(BigDecimal valorReceber) { 
		this.valorReceber = valorReceber; 
	} 

	public String getCst() { 
		return this.cst; 
	} 

	public void setCst(String cst) { 
		this.cst = cst; 
	} 

	public BigDecimal getBaseCalculoIcms() { 
		return this.baseCalculoIcms; 
	} 

	public void setBaseCalculoIcms(BigDecimal baseCalculoIcms) { 
		this.baseCalculoIcms = baseCalculoIcms; 
	} 

	public BigDecimal getAliquotaIcms() { 
		return this.aliquotaIcms; 
	} 

	public void setAliquotaIcms(BigDecimal aliquotaIcms) { 
		this.aliquotaIcms = aliquotaIcms; 
	} 

	public BigDecimal getValorIcms() { 
		return this.valorIcms; 
	} 

	public void setValorIcms(BigDecimal valorIcms) { 
		this.valorIcms = valorIcms; 
	} 

	public BigDecimal getPercentualReducaoBcIcms() { 
		return this.percentualReducaoBcIcms; 
	} 

	public void setPercentualReducaoBcIcms(BigDecimal percentualReducaoBcIcms) { 
		this.percentualReducaoBcIcms = percentualReducaoBcIcms; 
	} 

	public BigDecimal getValorBcIcmsStRetido() { 
		return this.valorBcIcmsStRetido; 
	} 

	public void setValorBcIcmsStRetido(BigDecimal valorBcIcmsStRetido) { 
		this.valorBcIcmsStRetido = valorBcIcmsStRetido; 
	} 

	public BigDecimal getValorIcmsStRetido() { 
		return this.valorIcmsStRetido; 
	} 

	public void setValorIcmsStRetido(BigDecimal valorIcmsStRetido) { 
		this.valorIcmsStRetido = valorIcmsStRetido; 
	} 

	public BigDecimal getAliquotaIcmsStRetido() { 
		return this.aliquotaIcmsStRetido; 
	} 

	public void setAliquotaIcmsStRetido(BigDecimal aliquotaIcmsStRetido) { 
		this.aliquotaIcmsStRetido = aliquotaIcmsStRetido; 
	} 

	public BigDecimal getValorCreditoPresumidoIcms() { 
		return this.valorCreditoPresumidoIcms; 
	} 

	public void setValorCreditoPresumidoIcms(BigDecimal valorCreditoPresumidoIcms) { 
		this.valorCreditoPresumidoIcms = valorCreditoPresumidoIcms; 
	} 

	public BigDecimal getPercentualBcIcmsOutraUf() { 
		return this.percentualBcIcmsOutraUf; 
	} 

	public void setPercentualBcIcmsOutraUf(BigDecimal percentualBcIcmsOutraUf) { 
		this.percentualBcIcmsOutraUf = percentualBcIcmsOutraUf; 
	} 

	public BigDecimal getValorBcIcmsOutraUf() { 
		return this.valorBcIcmsOutraUf; 
	} 

	public void setValorBcIcmsOutraUf(BigDecimal valorBcIcmsOutraUf) { 
		this.valorBcIcmsOutraUf = valorBcIcmsOutraUf; 
	} 

	public BigDecimal getAliquotaIcmsOutraUf() { 
		return this.aliquotaIcmsOutraUf; 
	} 

	public void setAliquotaIcmsOutraUf(BigDecimal aliquotaIcmsOutraUf) { 
		this.aliquotaIcmsOutraUf = aliquotaIcmsOutraUf; 
	} 

	public BigDecimal getValorIcmsOutraUf() { 
		return this.valorIcmsOutraUf; 
	} 

	public void setValorIcmsOutraUf(BigDecimal valorIcmsOutraUf) { 
		this.valorIcmsOutraUf = valorIcmsOutraUf; 
	} 

	public String getSimplesNacionalIndicador() { 
		return this.simplesNacionalIndicador; 
	} 

	public void setSimplesNacionalIndicador(String simplesNacionalIndicador) { 
		this.simplesNacionalIndicador = simplesNacionalIndicador; 
	} 

	public BigDecimal getSimplesNacionalTotal() { 
		return this.simplesNacionalTotal; 
	} 

	public void setSimplesNacionalTotal(BigDecimal simplesNacionalTotal) { 
		this.simplesNacionalTotal = simplesNacionalTotal; 
	} 

	public String getInformacoesAddFisco() { 
		return this.informacoesAddFisco; 
	} 

	public void setInformacoesAddFisco(String informacoesAddFisco) { 
		this.informacoesAddFisco = informacoesAddFisco; 
	} 

	public BigDecimal getValorTotalCarga() { 
		return this.valorTotalCarga; 
	} 

	public void setValorTotalCarga(BigDecimal valorTotalCarga) { 
		this.valorTotalCarga = valorTotalCarga; 
	} 

	public String getProdutoPredominante() { 
		return this.produtoPredominante; 
	} 

	public void setProdutoPredominante(String produtoPredominante) { 
		this.produtoPredominante = produtoPredominante; 
	} 

	public String getCargaOutrasCaracteristicas() { 
		return this.cargaOutrasCaracteristicas; 
	} 

	public void setCargaOutrasCaracteristicas(String cargaOutrasCaracteristicas) { 
		this.cargaOutrasCaracteristicas = cargaOutrasCaracteristicas; 
	} 

	public Integer getModalVersaoLayout() { 
		return this.modalVersaoLayout; 
	} 

	public void setModalVersaoLayout(Integer modalVersaoLayout) { 
		this.modalVersaoLayout = modalVersaoLayout; 
	} 

	public String getChaveCteSubstituido() { 
		return this.chaveCteSubstituido; 
	} 

	public void setChaveCteSubstituido(String chaveCteSubstituido) { 
		this.chaveCteSubstituido = chaveCteSubstituido; 
	} 

	public Set<CteEmitenteModel> getCteEmitenteModelList() { 
	return this.cteEmitenteModelList; 
	} 

	public void setCteEmitenteModelList(Set<CteEmitenteModel> cteEmitenteModelList) { 
	this.cteEmitenteModelList = cteEmitenteModelList; 
		for (CteEmitenteModel cteEmitenteModel : cteEmitenteModelList) { 
			cteEmitenteModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteLocalColetaModel> getCteLocalColetaModelList() { 
	return this.cteLocalColetaModelList; 
	} 

	public void setCteLocalColetaModelList(Set<CteLocalColetaModel> cteLocalColetaModelList) { 
	this.cteLocalColetaModelList = cteLocalColetaModelList; 
		for (CteLocalColetaModel cteLocalColetaModel : cteLocalColetaModelList) { 
			cteLocalColetaModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteTomadorModel> getCteTomadorModelList() { 
	return this.cteTomadorModelList; 
	} 

	public void setCteTomadorModelList(Set<CteTomadorModel> cteTomadorModelList) { 
	this.cteTomadorModelList = cteTomadorModelList; 
		for (CteTomadorModel cteTomadorModel : cteTomadorModelList) { 
			cteTomadorModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CtePassagemModel> getCtePassagemModelList() { 
	return this.ctePassagemModelList; 
	} 

	public void setCtePassagemModelList(Set<CtePassagemModel> ctePassagemModelList) { 
	this.ctePassagemModelList = ctePassagemModelList; 
		for (CtePassagemModel ctePassagemModel : ctePassagemModelList) { 
			ctePassagemModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteRemetenteModel> getCteRemetenteModelList() { 
	return this.cteRemetenteModelList; 
	} 

	public void setCteRemetenteModelList(Set<CteRemetenteModel> cteRemetenteModelList) { 
	this.cteRemetenteModelList = cteRemetenteModelList; 
		for (CteRemetenteModel cteRemetenteModel : cteRemetenteModelList) { 
			cteRemetenteModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteExpedidorModel> getCteExpedidorModelList() { 
	return this.cteExpedidorModelList; 
	} 

	public void setCteExpedidorModelList(Set<CteExpedidorModel> cteExpedidorModelList) { 
	this.cteExpedidorModelList = cteExpedidorModelList; 
		for (CteExpedidorModel cteExpedidorModel : cteExpedidorModelList) { 
			cteExpedidorModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteRecebedorModel> getCteRecebedorModelList() { 
	return this.cteRecebedorModelList; 
	} 

	public void setCteRecebedorModelList(Set<CteRecebedorModel> cteRecebedorModelList) { 
	this.cteRecebedorModelList = cteRecebedorModelList; 
		for (CteRecebedorModel cteRecebedorModel : cteRecebedorModelList) { 
			cteRecebedorModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteDestinatarioModel> getCteDestinatarioModelList() { 
	return this.cteDestinatarioModelList; 
	} 

	public void setCteDestinatarioModelList(Set<CteDestinatarioModel> cteDestinatarioModelList) { 
	this.cteDestinatarioModelList = cteDestinatarioModelList; 
		for (CteDestinatarioModel cteDestinatarioModel : cteDestinatarioModelList) { 
			cteDestinatarioModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteLocalEntregaModel> getCteLocalEntregaModelList() { 
	return this.cteLocalEntregaModelList; 
	} 

	public void setCteLocalEntregaModelList(Set<CteLocalEntregaModel> cteLocalEntregaModelList) { 
	this.cteLocalEntregaModelList = cteLocalEntregaModelList; 
		for (CteLocalEntregaModel cteLocalEntregaModel : cteLocalEntregaModelList) { 
			cteLocalEntregaModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteComponenteModel> getCteComponenteModelList() { 
	return this.cteComponenteModelList; 
	} 

	public void setCteComponenteModelList(Set<CteComponenteModel> cteComponenteModelList) { 
	this.cteComponenteModelList = cteComponenteModelList; 
		for (CteComponenteModel cteComponenteModel : cteComponenteModelList) { 
			cteComponenteModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteCargaModel> getCteCargaModelList() { 
	return this.cteCargaModelList; 
	} 

	public void setCteCargaModelList(Set<CteCargaModel> cteCargaModelList) { 
	this.cteCargaModelList = cteCargaModelList; 
		for (CteCargaModel cteCargaModel : cteCargaModelList) { 
			cteCargaModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteInformacaoNfOutrosModel> getCteInformacaoNfOutrosModelList() { 
	return this.cteInformacaoNfOutrosModelList; 
	} 

	public void setCteInformacaoNfOutrosModelList(Set<CteInformacaoNfOutrosModel> cteInformacaoNfOutrosModelList) { 
	this.cteInformacaoNfOutrosModelList = cteInformacaoNfOutrosModelList; 
		for (CteInformacaoNfOutrosModel cteInformacaoNfOutrosModel : cteInformacaoNfOutrosModelList) { 
			cteInformacaoNfOutrosModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteSeguroModel> getCteSeguroModelList() { 
	return this.cteSeguroModelList; 
	} 

	public void setCteSeguroModelList(Set<CteSeguroModel> cteSeguroModelList) { 
	this.cteSeguroModelList = cteSeguroModelList; 
		for (CteSeguroModel cteSeguroModel : cteSeguroModelList) { 
			cteSeguroModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CtePerigosoModel> getCtePerigosoModelList() { 
	return this.ctePerigosoModelList; 
	} 

	public void setCtePerigosoModelList(Set<CtePerigosoModel> ctePerigosoModelList) { 
	this.ctePerigosoModelList = ctePerigosoModelList; 
		for (CtePerigosoModel ctePerigosoModel : ctePerigosoModelList) { 
			ctePerigosoModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteVeiculoNovoModel> getCteVeiculoNovoModelList() { 
	return this.cteVeiculoNovoModelList; 
	} 

	public void setCteVeiculoNovoModelList(Set<CteVeiculoNovoModel> cteVeiculoNovoModelList) { 
	this.cteVeiculoNovoModelList = cteVeiculoNovoModelList; 
		for (CteVeiculoNovoModel cteVeiculoNovoModel : cteVeiculoNovoModelList) { 
			cteVeiculoNovoModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteFaturaModel> getCteFaturaModelList() { 
	return this.cteFaturaModelList; 
	} 

	public void setCteFaturaModelList(Set<CteFaturaModel> cteFaturaModelList) { 
	this.cteFaturaModelList = cteFaturaModelList; 
		for (CteFaturaModel cteFaturaModel : cteFaturaModelList) { 
			cteFaturaModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteDuplicataModel> getCteDuplicataModelList() { 
	return this.cteDuplicataModelList; 
	} 

	public void setCteDuplicataModelList(Set<CteDuplicataModel> cteDuplicataModelList) { 
	this.cteDuplicataModelList = cteDuplicataModelList; 
		for (CteDuplicataModel cteDuplicataModel : cteDuplicataModelList) { 
			cteDuplicataModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteRodoviarioModel> getCteRodoviarioModelList() { 
	return this.cteRodoviarioModelList; 
	} 

	public void setCteRodoviarioModelList(Set<CteRodoviarioModel> cteRodoviarioModelList) { 
	this.cteRodoviarioModelList = cteRodoviarioModelList; 
		for (CteRodoviarioModel cteRodoviarioModel : cteRodoviarioModelList) { 
			cteRodoviarioModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteAereoModel> getCteAereoModelList() { 
	return this.cteAereoModelList; 
	} 

	public void setCteAereoModelList(Set<CteAereoModel> cteAereoModelList) { 
	this.cteAereoModelList = cteAereoModelList; 
		for (CteAereoModel cteAereoModel : cteAereoModelList) { 
			cteAereoModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteAquaviarioModel> getCteAquaviarioModelList() { 
	return this.cteAquaviarioModelList; 
	} 

	public void setCteAquaviarioModelList(Set<CteAquaviarioModel> cteAquaviarioModelList) { 
	this.cteAquaviarioModelList = cteAquaviarioModelList; 
		for (CteAquaviarioModel cteAquaviarioModel : cteAquaviarioModelList) { 
			cteAquaviarioModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteFerroviarioModel> getCteFerroviarioModelList() { 
	return this.cteFerroviarioModelList; 
	} 

	public void setCteFerroviarioModelList(Set<CteFerroviarioModel> cteFerroviarioModelList) { 
	this.cteFerroviarioModelList = cteFerroviarioModelList; 
		for (CteFerroviarioModel cteFerroviarioModel : cteFerroviarioModelList) { 
			cteFerroviarioModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteDutoviarioModel> getCteDutoviarioModelList() { 
	return this.cteDutoviarioModelList; 
	} 

	public void setCteDutoviarioModelList(Set<CteDutoviarioModel> cteDutoviarioModelList) { 
	this.cteDutoviarioModelList = cteDutoviarioModelList; 
		for (CteDutoviarioModel cteDutoviarioModel : cteDutoviarioModelList) { 
			cteDutoviarioModel.setCteCabecalhoModel(this); 
		}
	} 

	public Set<CteMultimodalModel> getCteMultimodalModelList() { 
	return this.cteMultimodalModelList; 
	} 

	public void setCteMultimodalModelList(Set<CteMultimodalModel> cteMultimodalModelList) { 
	this.cteMultimodalModelList = cteMultimodalModelList; 
		for (CteMultimodalModel cteMultimodalModel : cteMultimodalModelList) { 
			cteMultimodalModel.setCteCabecalhoModel(this); 
		}
	} 

		
}