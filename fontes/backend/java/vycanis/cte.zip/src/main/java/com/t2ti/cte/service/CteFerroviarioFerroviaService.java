package com.t2ti.cte.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cte.util.Filter;
import com.t2ti.cte.exception.GenericException;
import com.t2ti.cte.model.CteFerroviarioFerroviaModel;
import com.t2ti.cte.repository.CteFerroviarioFerroviaRepository;

@Service
public class CteFerroviarioFerroviaService {

	@Autowired
	private CteFerroviarioFerroviaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CteFerroviarioFerroviaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CteFerroviarioFerroviaModel> getList(Filter filter) {
		String sql = "select * from cte_ferroviario_ferrovia where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CteFerroviarioFerroviaModel.class);
		return query.getResultList();
	}

	public CteFerroviarioFerroviaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CteFerroviarioFerroviaModel save(CteFerroviarioFerroviaModel obj) {
		CteFerroviarioFerroviaModel cteFerroviarioFerroviaModel = repository.save(obj);
		return cteFerroviarioFerroviaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CteFerroviarioFerroviaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CteFerroviarioFerrovia] - Exception: " + e.getMessage());
		}
	}

}