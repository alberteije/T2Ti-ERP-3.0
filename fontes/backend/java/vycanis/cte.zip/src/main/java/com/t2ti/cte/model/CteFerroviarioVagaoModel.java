package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_ferroviario_vagao")
@NamedQuery(name="CteFerroviarioVagaoModel.findAll", query="SELECT t FROM CteFerroviarioVagaoModel t")
public class CteFerroviarioVagaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteFerroviarioVagaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_vagao")
	private Integer numeroVagao;

	@Column(name="capacidade")
	private BigDecimal capacidade;

	@Column(name="tipo_vagao")
	private String tipoVagao;

	@Column(name="peso_real")
	private BigDecimal pesoReal;

	@Column(name="peso_bc")
	private BigDecimal pesoBc;

	@ManyToOne 
	@JoinColumn(name="id_cte_ferroviario")
	private CteFerroviarioModel cteFerroviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumeroVagao() { 
		return this.numeroVagao; 
	} 

	public void setNumeroVagao(Integer numeroVagao) { 
		this.numeroVagao = numeroVagao; 
	} 

	public BigDecimal getCapacidade() { 
		return this.capacidade; 
	} 

	public void setCapacidade(BigDecimal capacidade) { 
		this.capacidade = capacidade; 
	} 

	public String getTipoVagao() { 
		return this.tipoVagao; 
	} 

	public void setTipoVagao(String tipoVagao) { 
		this.tipoVagao = tipoVagao; 
	} 

	public BigDecimal getPesoReal() { 
		return this.pesoReal; 
	} 

	public void setPesoReal(BigDecimal pesoReal) { 
		this.pesoReal = pesoReal; 
	} 

	public BigDecimal getPesoBc() { 
		return this.pesoBc; 
	} 

	public void setPesoBc(BigDecimal pesoBc) { 
		this.pesoBc = pesoBc; 
	} 

	public CteFerroviarioModel getCteFerroviarioModel() { 
	return this.cteFerroviarioModel; 
	} 

	public void setCteFerroviarioModel(CteFerroviarioModel cteFerroviarioModel) { 
	this.cteFerroviarioModel = cteFerroviarioModel; 
	} 

		
}