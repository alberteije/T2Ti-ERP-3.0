package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_multimodal")
@NamedQuery(name="CteMultimodalModel.findAll", query="SELECT t FROM CteMultimodalModel t")
public class CteMultimodalModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteMultimodalModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cotm")
	private String cotm;

	@Column(name="indicador_negociavel")
	private String indicadorNegociavel;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCotm() { 
		return this.cotm; 
	} 

	public void setCotm(String cotm) { 
		this.cotm = cotm; 
	} 

	public String getIndicadorNegociavel() { 
		return this.indicadorNegociavel; 
	} 

	public void setIndicadorNegociavel(String indicadorNegociavel) { 
		this.indicadorNegociavel = indicadorNegociavel; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}