package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_inf_nf_carga_lacre")
@NamedQuery(name="CteInfNfCargaLacreModel.findAll", query="SELECT t FROM CteInfNfCargaLacreModel t")
public class CteInfNfCargaLacreModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteInfNfCargaLacreModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Column(name="quantidade_rateada")
	private BigDecimal quantidadeRateada;

	@ManyToOne 
	@JoinColumn(name="id_cte_informacao_nf_carga")
	private CteInformacaoNfCargaModel cteInformacaoNfCargaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public BigDecimal getQuantidadeRateada() { 
		return this.quantidadeRateada; 
	} 

	public void setQuantidadeRateada(BigDecimal quantidadeRateada) { 
		this.quantidadeRateada = quantidadeRateada; 
	} 

	public CteInformacaoNfCargaModel getCteInformacaoNfCargaModel() { 
	return this.cteInformacaoNfCargaModel; 
	} 

	public void setCteInformacaoNfCargaModel(CteInformacaoNfCargaModel cteInformacaoNfCargaModel) { 
	this.cteInformacaoNfCargaModel = cteInformacaoNfCargaModel; 
	} 

		
}