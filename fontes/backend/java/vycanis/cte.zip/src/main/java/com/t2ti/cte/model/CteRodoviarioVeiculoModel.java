package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_rodoviario_veiculo")
@NamedQuery(name="CteRodoviarioVeiculoModel.findAll", query="SELECT t FROM CteRodoviarioVeiculoModel t")
public class CteRodoviarioVeiculoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteRodoviarioVeiculoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_interno")
	private String codigoInterno;

	@Column(name="renavam")
	private String renavam;

	@Column(name="placa")
	private String placa;

	@Column(name="tara")
	private Integer tara;

	@Column(name="capacidade_kg")
	private Integer capacidadeKg;

	@Column(name="capacidade_m3")
	private Integer capacidadeM3;

	@Column(name="tipo_propriedade")
	private String tipoPropriedade;

	@Column(name="tipo_veiculo")
	private String tipoVeiculo;

	@Column(name="tipo_rodado")
	private String tipoRodado;

	@Column(name="tipo_carroceria")
	private String tipoCarroceria;

	@Column(name="uf")
	private String uf;

	@Column(name="proprietario_cpf")
	private String proprietarioCpf;

	@Column(name="proprietario_cnpj")
	private String proprietarioCnpj;

	@Column(name="proprietario_rntrc")
	private String proprietarioRntrc;

	@Column(name="proprietario_nome")
	private String proprietarioNome;

	@Column(name="proprietario_ie")
	private String proprietarioIe;

	@Column(name="proprietario_uf")
	private String proprietarioUf;

	@Column(name="proprietario_tipo")
	private String proprietarioTipo;

	@ManyToOne 
	@JoinColumn(name="id_cte_rodoviario")
	private CteRodoviarioModel cteRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoInterno() { 
		return this.codigoInterno; 
	} 

	public void setCodigoInterno(String codigoInterno) { 
		this.codigoInterno = codigoInterno; 
	} 

	public String getRenavam() { 
		return this.renavam; 
	} 

	public void setRenavam(String renavam) { 
		this.renavam = renavam; 
	} 

	public String getPlaca() { 
		return this.placa; 
	} 

	public void setPlaca(String placa) { 
		this.placa = placa; 
	} 

	public Integer getTara() { 
		return this.tara; 
	} 

	public void setTara(Integer tara) { 
		this.tara = tara; 
	} 

	public Integer getCapacidadeKg() { 
		return this.capacidadeKg; 
	} 

	public void setCapacidadeKg(Integer capacidadeKg) { 
		this.capacidadeKg = capacidadeKg; 
	} 

	public Integer getCapacidadeM3() { 
		return this.capacidadeM3; 
	} 

	public void setCapacidadeM3(Integer capacidadeM3) { 
		this.capacidadeM3 = capacidadeM3; 
	} 

	public String getTipoPropriedade() { 
		return this.tipoPropriedade; 
	} 

	public void setTipoPropriedade(String tipoPropriedade) { 
		this.tipoPropriedade = tipoPropriedade; 
	} 

	public String getTipoVeiculo() { 
		return this.tipoVeiculo; 
	} 

	public void setTipoVeiculo(String tipoVeiculo) { 
		this.tipoVeiculo = tipoVeiculo; 
	} 

	public String getTipoRodado() { 
		return this.tipoRodado; 
	} 

	public void setTipoRodado(String tipoRodado) { 
		this.tipoRodado = tipoRodado; 
	} 

	public String getTipoCarroceria() { 
		return this.tipoCarroceria; 
	} 

	public void setTipoCarroceria(String tipoCarroceria) { 
		this.tipoCarroceria = tipoCarroceria; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getProprietarioCpf() { 
		return this.proprietarioCpf; 
	} 

	public void setProprietarioCpf(String proprietarioCpf) { 
		this.proprietarioCpf = proprietarioCpf; 
	} 

	public String getProprietarioCnpj() { 
		return this.proprietarioCnpj; 
	} 

	public void setProprietarioCnpj(String proprietarioCnpj) { 
		this.proprietarioCnpj = proprietarioCnpj; 
	} 

	public String getProprietarioRntrc() { 
		return this.proprietarioRntrc; 
	} 

	public void setProprietarioRntrc(String proprietarioRntrc) { 
		this.proprietarioRntrc = proprietarioRntrc; 
	} 

	public String getProprietarioNome() { 
		return this.proprietarioNome; 
	} 

	public void setProprietarioNome(String proprietarioNome) { 
		this.proprietarioNome = proprietarioNome; 
	} 

	public String getProprietarioIe() { 
		return this.proprietarioIe; 
	} 

	public void setProprietarioIe(String proprietarioIe) { 
		this.proprietarioIe = proprietarioIe; 
	} 

	public String getProprietarioUf() { 
		return this.proprietarioUf; 
	} 

	public void setProprietarioUf(String proprietarioUf) { 
		this.proprietarioUf = proprietarioUf; 
	} 

	public String getProprietarioTipo() { 
		return this.proprietarioTipo; 
	} 

	public void setProprietarioTipo(String proprietarioTipo) { 
		this.proprietarioTipo = proprietarioTipo; 
	} 

	public CteRodoviarioModel getCteRodoviarioModel() { 
	return this.cteRodoviarioModel; 
	} 

	public void setCteRodoviarioModel(CteRodoviarioModel cteRodoviarioModel) { 
	this.cteRodoviarioModel = cteRodoviarioModel; 
	} 

		
}