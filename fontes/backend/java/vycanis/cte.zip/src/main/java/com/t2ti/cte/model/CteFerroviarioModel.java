package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_ferroviario")
@NamedQuery(name="CteFerroviarioModel.findAll", query="SELECT t FROM CteFerroviarioModel t")
public class CteFerroviarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteFerroviarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo_trafego")
	private String tipoTrafego;

	@Column(name="responsavel_faturamento")
	private String responsavelFaturamento;

	@Column(name="ferrovia_emitente_cte")
	private String ferroviaEmitenteCte;

	@Column(name="fluxo")
	private String fluxo;

	@Column(name="id_trem")
	private String idTrem;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipoTrafego() { 
		return this.tipoTrafego; 
	} 

	public void setTipoTrafego(String tipoTrafego) { 
		this.tipoTrafego = tipoTrafego; 
	} 

	public String getResponsavelFaturamento() { 
		return this.responsavelFaturamento; 
	} 

	public void setResponsavelFaturamento(String responsavelFaturamento) { 
		this.responsavelFaturamento = responsavelFaturamento; 
	} 

	public String getFerroviaEmitenteCte() { 
		return this.ferroviaEmitenteCte; 
	} 

	public void setFerroviaEmitenteCte(String ferroviaEmitenteCte) { 
		this.ferroviaEmitenteCte = ferroviaEmitenteCte; 
	} 

	public String getFluxo() { 
		return this.fluxo; 
	} 

	public void setFluxo(String fluxo) { 
		this.fluxo = fluxo; 
	} 

	public String getIdTrem() { 
		return this.idTrem; 
	} 

	public void setIdTrem(String idTrem) { 
		this.idTrem = idTrem; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}