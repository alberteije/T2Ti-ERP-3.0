package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_informacao_nf_outros")
@NamedQuery(name="CteInformacaoNfOutrosModel.findAll", query="SELECT t FROM CteInformacaoNfOutrosModel t")
public class CteInformacaoNfOutrosModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteInformacaoNfOutrosModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_romaneio")
	private String numeroRomaneio;

	@Column(name="numero_pedido")
	private String numeroPedido;

	@Column(name="chave_acesso_nfe")
	private String chaveAcessoNfe;

	@Column(name="codigo_modelo")
	private String codigoModelo;

	@Column(name="serie")
	private String serie;

	@Column(name="numero")
	private String numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Column(name="uf_emitente")
	private Integer ufEmitente;

	@Column(name="base_calculo_icms")
	private BigDecimal baseCalculoIcms;

	@Column(name="valor_icms")
	private BigDecimal valorIcms;

	@Column(name="base_calculo_icms_st")
	private BigDecimal baseCalculoIcmsSt;

	@Column(name="valor_icms_st")
	private BigDecimal valorIcmsSt;

	@Column(name="valor_total_produtos")
	private BigDecimal valorTotalProdutos;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="cfop_predominante")
	private Integer cfopPredominante;

	@Column(name="peso_total_kg")
	private BigDecimal pesoTotalKg;

	@Column(name="pin_suframa")
	private Integer pinSuframa;

	@Temporal(TemporalType.DATE)
@Column(name="data_prevista_entrega")
	private Date dataPrevistaEntrega;

	@Column(name="outro_tipo_doc_orig")
	private String outroTipoDocOrig;

	@Column(name="outro_descricao")
	private String outroDescricao;

	@Column(name="outro_valor_documento")
	private BigDecimal outroValorDocumento;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumeroRomaneio() { 
		return this.numeroRomaneio; 
	} 

	public void setNumeroRomaneio(String numeroRomaneio) { 
		this.numeroRomaneio = numeroRomaneio; 
	} 

	public String getNumeroPedido() { 
		return this.numeroPedido; 
	} 

	public void setNumeroPedido(String numeroPedido) { 
		this.numeroPedido = numeroPedido; 
	} 

	public String getChaveAcessoNfe() { 
		return this.chaveAcessoNfe; 
	} 

	public void setChaveAcessoNfe(String chaveAcessoNfe) { 
		this.chaveAcessoNfe = chaveAcessoNfe; 
	} 

	public String getCodigoModelo() { 
		return this.codigoModelo; 
	} 

	public void setCodigoModelo(String codigoModelo) { 
		this.codigoModelo = codigoModelo; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public Integer getUfEmitente() { 
		return this.ufEmitente; 
	} 

	public void setUfEmitente(Integer ufEmitente) { 
		this.ufEmitente = ufEmitente; 
	} 

	public BigDecimal getBaseCalculoIcms() { 
		return this.baseCalculoIcms; 
	} 

	public void setBaseCalculoIcms(BigDecimal baseCalculoIcms) { 
		this.baseCalculoIcms = baseCalculoIcms; 
	} 

	public BigDecimal getValorIcms() { 
		return this.valorIcms; 
	} 

	public void setValorIcms(BigDecimal valorIcms) { 
		this.valorIcms = valorIcms; 
	} 

	public BigDecimal getBaseCalculoIcmsSt() { 
		return this.baseCalculoIcmsSt; 
	} 

	public void setBaseCalculoIcmsSt(BigDecimal baseCalculoIcmsSt) { 
		this.baseCalculoIcmsSt = baseCalculoIcmsSt; 
	} 

	public BigDecimal getValorIcmsSt() { 
		return this.valorIcmsSt; 
	} 

	public void setValorIcmsSt(BigDecimal valorIcmsSt) { 
		this.valorIcmsSt = valorIcmsSt; 
	} 

	public BigDecimal getValorTotalProdutos() { 
		return this.valorTotalProdutos; 
	} 

	public void setValorTotalProdutos(BigDecimal valorTotalProdutos) { 
		this.valorTotalProdutos = valorTotalProdutos; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public Integer getCfopPredominante() { 
		return this.cfopPredominante; 
	} 

	public void setCfopPredominante(Integer cfopPredominante) { 
		this.cfopPredominante = cfopPredominante; 
	} 

	public BigDecimal getPesoTotalKg() { 
		return this.pesoTotalKg; 
	} 

	public void setPesoTotalKg(BigDecimal pesoTotalKg) { 
		this.pesoTotalKg = pesoTotalKg; 
	} 

	public Integer getPinSuframa() { 
		return this.pinSuframa; 
	} 

	public void setPinSuframa(Integer pinSuframa) { 
		this.pinSuframa = pinSuframa; 
	} 

	public Date getDataPrevistaEntrega() { 
		return this.dataPrevistaEntrega; 
	} 

	public void setDataPrevistaEntrega(Date dataPrevistaEntrega) { 
		this.dataPrevistaEntrega = dataPrevistaEntrega; 
	} 

	public String getOutroTipoDocOrig() { 
		return this.outroTipoDocOrig; 
	} 

	public void setOutroTipoDocOrig(String outroTipoDocOrig) { 
		this.outroTipoDocOrig = outroTipoDocOrig; 
	} 

	public String getOutroDescricao() { 
		return this.outroDescricao; 
	} 

	public void setOutroDescricao(String outroDescricao) { 
		this.outroDescricao = outroDescricao; 
	} 

	public BigDecimal getOutroValorDocumento() { 
		return this.outroValorDocumento; 
	} 

	public void setOutroValorDocumento(BigDecimal outroValorDocumento) { 
		this.outroValorDocumento = outroValorDocumento; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}