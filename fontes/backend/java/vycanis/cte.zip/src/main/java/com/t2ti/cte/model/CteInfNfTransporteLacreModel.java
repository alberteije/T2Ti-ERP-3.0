package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_inf_nf_transporte_lacre")
@NamedQuery(name="CteInfNfTransporteLacreModel.findAll", query="SELECT t FROM CteInfNfTransporteLacreModel t")
public class CteInfNfTransporteLacreModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteInfNfTransporteLacreModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@ManyToOne 
	@JoinColumn(name="id_cte_informacao_nf_transporte")
	private CteInformacaoNfTransporteModel cteInformacaoNfTransporteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public CteInformacaoNfTransporteModel getCteInformacaoNfTransporteModel() { 
	return this.cteInformacaoNfTransporteModel; 
	} 

	public void setCteInformacaoNfTransporteModel(CteInformacaoNfTransporteModel cteInformacaoNfTransporteModel) { 
	this.cteInformacaoNfTransporteModel = cteInformacaoNfTransporteModel; 
	} 

		
}