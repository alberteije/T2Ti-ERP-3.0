package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_rodoviario_lacre")
@NamedQuery(name="CteRodoviarioLacreModel.findAll", query="SELECT t FROM CteRodoviarioLacreModel t")
public class CteRodoviarioLacreModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteRodoviarioLacreModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@ManyToOne 
	@JoinColumn(name="id_cte_rodoviario")
	private CteRodoviarioModel cteRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public CteRodoviarioModel getCteRodoviarioModel() { 
	return this.cteRodoviarioModel; 
	} 

	public void setCteRodoviarioModel(CteRodoviarioModel cteRodoviarioModel) { 
	this.cteRodoviarioModel = cteRodoviarioModel; 
	} 

		
}