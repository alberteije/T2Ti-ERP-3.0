package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_rodoviario_pedagio")
@NamedQuery(name="CteRodoviarioPedagioModel.findAll", query="SELECT t FROM CteRodoviarioPedagioModel t")
public class CteRodoviarioPedagioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteRodoviarioPedagioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj_fornecedor")
	private String cnpjFornecedor;

	@Column(name="comprovante_compra")
	private String comprovanteCompra;

	@Column(name="cnpj_responsavel")
	private String cnpjResponsavel;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JoinColumn(name="id_cte_rodoviario")
	private CteRodoviarioModel cteRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpjFornecedor() { 
		return this.cnpjFornecedor; 
	} 

	public void setCnpjFornecedor(String cnpjFornecedor) { 
		this.cnpjFornecedor = cnpjFornecedor; 
	} 

	public String getComprovanteCompra() { 
		return this.comprovanteCompra; 
	} 

	public void setComprovanteCompra(String comprovanteCompra) { 
		this.comprovanteCompra = comprovanteCompra; 
	} 

	public String getCnpjResponsavel() { 
		return this.cnpjResponsavel; 
	} 

	public void setCnpjResponsavel(String cnpjResponsavel) { 
		this.cnpjResponsavel = cnpjResponsavel; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public CteRodoviarioModel getCteRodoviarioModel() { 
	return this.cteRodoviarioModel; 
	} 

	public void setCteRodoviarioModel(CteRodoviarioModel cteRodoviarioModel) { 
	this.cteRodoviarioModel = cteRodoviarioModel; 
	} 

		
}