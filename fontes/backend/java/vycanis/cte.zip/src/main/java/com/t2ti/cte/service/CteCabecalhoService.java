package com.t2ti.cte.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cte.util.Filter;
import com.t2ti.cte.exception.GenericException;
import com.t2ti.cte.model.CteCabecalhoModel;
import com.t2ti.cte.repository.CteCabecalhoRepository;

@Service
public class CteCabecalhoService {

	@Autowired
	private CteCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CteCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CteCabecalhoModel> getList(Filter filter) {
		String sql = "select * from cte_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CteCabecalhoModel.class);
		return query.getResultList();
	}

	public CteCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CteCabecalhoModel save(CteCabecalhoModel obj) {
		CteCabecalhoModel cteCabecalhoModel = repository.save(obj);
		return cteCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CteCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CteCabecalho] - Exception: " + e.getMessage());
		}
	}

}