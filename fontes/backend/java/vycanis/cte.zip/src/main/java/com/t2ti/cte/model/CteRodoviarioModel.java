package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_rodoviario")
@NamedQuery(name="CteRodoviarioModel.findAll", query="SELECT t FROM CteRodoviarioModel t")
public class CteRodoviarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteRodoviarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="rntrc")
	private String rntrc;

	@Temporal(TemporalType.DATE)
@Column(name="data_prevista_entrega")
	private Date dataPrevistaEntrega;

	@Column(name="indicador_lotacao")
	private String indicadorLotacao;

	@Column(name="ciot")
	private Integer ciot;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_cte_cabecalho")
	private CteCabecalhoModel cteCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getRntrc() { 
		return this.rntrc; 
	} 

	public void setRntrc(String rntrc) { 
		this.rntrc = rntrc; 
	} 

	public Date getDataPrevistaEntrega() { 
		return this.dataPrevistaEntrega; 
	} 

	public void setDataPrevistaEntrega(Date dataPrevistaEntrega) { 
		this.dataPrevistaEntrega = dataPrevistaEntrega; 
	} 

	public String getIndicadorLotacao() { 
		return this.indicadorLotacao; 
	} 

	public void setIndicadorLotacao(String indicadorLotacao) { 
		this.indicadorLotacao = indicadorLotacao; 
	} 

	public Integer getCiot() { 
		return this.ciot; 
	} 

	public void setCiot(Integer ciot) { 
		this.ciot = ciot; 
	} 

	public CteCabecalhoModel getCteCabecalhoModel() { 
	return this.cteCabecalhoModel; 
	} 

	public void setCteCabecalhoModel(CteCabecalhoModel cteCabecalhoModel) { 
	this.cteCabecalhoModel = cteCabecalhoModel; 
	} 

		
}