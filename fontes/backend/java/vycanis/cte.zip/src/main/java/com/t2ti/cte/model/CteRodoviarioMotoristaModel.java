package com.t2ti.cte.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cte_rodoviario_motorista")
@NamedQuery(name="CteRodoviarioMotoristaModel.findAll", query="SELECT t FROM CteRodoviarioMotoristaModel t")
public class CteRodoviarioMotoristaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CteRodoviarioMotoristaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="cpf")
	private String cpf;

	@ManyToOne 
	@JoinColumn(name="id_cte_rodoviario")
	private CteRodoviarioModel cteRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public CteRodoviarioModel getCteRodoviarioModel() { 
	return this.cteRodoviarioModel; 
	} 

	public void setCteRodoviarioModel(CteRodoviarioModel cteRodoviarioModel) { 
	this.cteRodoviarioModel = cteRodoviarioModel; 
	} 

		
}