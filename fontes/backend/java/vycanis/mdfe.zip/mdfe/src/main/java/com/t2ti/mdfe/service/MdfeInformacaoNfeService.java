package com.t2ti.mdfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.mdfe.util.Filter;
import com.t2ti.mdfe.exception.GenericException;
import com.t2ti.mdfe.model.MdfeInformacaoNfeModel;
import com.t2ti.mdfe.repository.MdfeInformacaoNfeRepository;

@Service
public class MdfeInformacaoNfeService {

	@Autowired
	private MdfeInformacaoNfeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<MdfeInformacaoNfeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<MdfeInformacaoNfeModel> getList(Filter filter) {
		String sql = "select * from mdfe_informacao_nfe where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, MdfeInformacaoNfeModel.class);
		return query.getResultList();
	}

	public MdfeInformacaoNfeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public MdfeInformacaoNfeModel save(MdfeInformacaoNfeModel obj) {
		MdfeInformacaoNfeModel mdfeInformacaoNfeModel = repository.save(obj);
		return mdfeInformacaoNfeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		MdfeInformacaoNfeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete MdfeInformacaoNfe] - Exception: " + e.getMessage());
		}
	}

}