package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_informacao_cte")
@NamedQuery(name="MdfeInformacaoCteModel.findAll", query="SELECT t FROM MdfeInformacaoCteModel t")
public class MdfeInformacaoCteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeInformacaoCteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="chave_cte")
	private String chaveCte;

	@Column(name="segundo_codigo_barra")
	private String segundoCodigoBarra;

	@Column(name="indicador_reentrega")
	private Integer indicadorReentrega;

	@ManyToOne 
	@JoinColumn(name="id_mdfe_municipio_descarrega")
	private MdfeMunicipioDescarregaModel mdfeMunicipioDescarregaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getChaveCte() { 
		return this.chaveCte; 
	} 

	public void setChaveCte(String chaveCte) { 
		this.chaveCte = chaveCte; 
	} 

	public String getSegundoCodigoBarra() { 
		return this.segundoCodigoBarra; 
	} 

	public void setSegundoCodigoBarra(String segundoCodigoBarra) { 
		this.segundoCodigoBarra = segundoCodigoBarra; 
	} 

	public Integer getIndicadorReentrega() { 
		return this.indicadorReentrega; 
	} 

	public void setIndicadorReentrega(Integer indicadorReentrega) { 
		this.indicadorReentrega = indicadorReentrega; 
	} 

	public MdfeMunicipioDescarregaModel getMdfeMunicipioDescarregaModel() { 
	return this.mdfeMunicipioDescarregaModel; 
	} 

	public void setMdfeMunicipioDescarregaModel(MdfeMunicipioDescarregaModel mdfeMunicipioDescarregaModel) { 
	this.mdfeMunicipioDescarregaModel = mdfeMunicipioDescarregaModel; 
	} 

		
}