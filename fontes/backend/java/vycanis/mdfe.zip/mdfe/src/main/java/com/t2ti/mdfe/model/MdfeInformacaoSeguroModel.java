package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_informacao_seguro")
@NamedQuery(name="MdfeInformacaoSeguroModel.findAll", query="SELECT t FROM MdfeInformacaoSeguroModel t")
public class MdfeInformacaoSeguroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeInformacaoSeguroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="responsavel")
	private Integer responsavel;

	@Column(name="cnpj_cpf")
	private String cnpjCpf;

	@Column(name="seguradora")
	private String seguradora;

	@Column(name="cnpj_seguradora")
	private String cnpjSeguradora;

	@Column(name="apolice")
	private String apolice;

	@Column(name="averbacao")
	private String averbacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_mdfe_cabecalho")
	private MdfeCabecalhoModel mdfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getResponsavel() { 
		return this.responsavel; 
	} 

	public void setResponsavel(Integer responsavel) { 
		this.responsavel = responsavel; 
	} 

	public String getCnpjCpf() { 
		return this.cnpjCpf; 
	} 

	public void setCnpjCpf(String cnpjCpf) { 
		this.cnpjCpf = cnpjCpf; 
	} 

	public String getSeguradora() { 
		return this.seguradora; 
	} 

	public void setSeguradora(String seguradora) { 
		this.seguradora = seguradora; 
	} 

	public String getCnpjSeguradora() { 
		return this.cnpjSeguradora; 
	} 

	public void setCnpjSeguradora(String cnpjSeguradora) { 
		this.cnpjSeguradora = cnpjSeguradora; 
	} 

	public String getApolice() { 
		return this.apolice; 
	} 

	public void setApolice(String apolice) { 
		this.apolice = apolice; 
	} 

	public String getAverbacao() { 
		return this.averbacao; 
	} 

	public void setAverbacao(String averbacao) { 
		this.averbacao = averbacao; 
	} 

	public MdfeCabecalhoModel getMdfeCabecalhoModel() { 
	return this.mdfeCabecalhoModel; 
	} 

	public void setMdfeCabecalhoModel(MdfeCabecalhoModel mdfeCabecalhoModel) { 
	this.mdfeCabecalhoModel = mdfeCabecalhoModel; 
	} 

		
}