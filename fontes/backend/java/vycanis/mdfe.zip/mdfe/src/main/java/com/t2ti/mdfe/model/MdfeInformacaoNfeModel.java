package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_informacao_nfe")
@NamedQuery(name="MdfeInformacaoNfeModel.findAll", query="SELECT t FROM MdfeInformacaoNfeModel t")
public class MdfeInformacaoNfeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeInformacaoNfeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="chave_nfe")
	private String chaveNfe;

	@Column(name="segundo_codigo_barra")
	private String segundoCodigoBarra;

	@Column(name="indicador_reentrega")
	private Integer indicadorReentrega;

	@ManyToOne 
	@JoinColumn(name="id_mdfe_municipio_descarrega")
	private MdfeMunicipioDescarregaModel mdfeMunicipioDescarregaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getChaveNfe() { 
		return this.chaveNfe; 
	} 

	public void setChaveNfe(String chaveNfe) { 
		this.chaveNfe = chaveNfe; 
	} 

	public String getSegundoCodigoBarra() { 
		return this.segundoCodigoBarra; 
	} 

	public void setSegundoCodigoBarra(String segundoCodigoBarra) { 
		this.segundoCodigoBarra = segundoCodigoBarra; 
	} 

	public Integer getIndicadorReentrega() { 
		return this.indicadorReentrega; 
	} 

	public void setIndicadorReentrega(Integer indicadorReentrega) { 
		this.indicadorReentrega = indicadorReentrega; 
	} 

	public MdfeMunicipioDescarregaModel getMdfeMunicipioDescarregaModel() { 
	return this.mdfeMunicipioDescarregaModel; 
	} 

	public void setMdfeMunicipioDescarregaModel(MdfeMunicipioDescarregaModel mdfeMunicipioDescarregaModel) { 
	this.mdfeMunicipioDescarregaModel = mdfeMunicipioDescarregaModel; 
	} 

		
}