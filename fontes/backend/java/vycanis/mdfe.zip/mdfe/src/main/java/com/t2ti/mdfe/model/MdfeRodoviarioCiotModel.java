package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_rodoviario_ciot")
@NamedQuery(name="MdfeRodoviarioCiotModel.findAll", query="SELECT t FROM MdfeRodoviarioCiotModel t")
public class MdfeRodoviarioCiotModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeRodoviarioCiotModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="ciot")
	private String ciot;

	@Column(name="cpf")
	private String cpf;

	@Column(name="cnpj")
	private String cnpj;

	@ManyToOne 
	@JoinColumn(name="id_mdfe_rodoviario")
	private MdfeRodoviarioModel mdfeRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCiot() { 
		return this.ciot; 
	} 

	public void setCiot(String ciot) { 
		this.ciot = ciot; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public MdfeRodoviarioModel getMdfeRodoviarioModel() { 
	return this.mdfeRodoviarioModel; 
	} 

	public void setMdfeRodoviarioModel(MdfeRodoviarioModel mdfeRodoviarioModel) { 
	this.mdfeRodoviarioModel = mdfeRodoviarioModel; 
	} 

		
}