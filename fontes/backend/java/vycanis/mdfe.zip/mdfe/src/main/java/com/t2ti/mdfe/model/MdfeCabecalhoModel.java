package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="mdfe_cabecalho")
@NamedQuery(name="MdfeCabecalhoModel.findAll", query="SELECT t FROM MdfeCabecalhoModel t")
public class MdfeCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="uf")
	private String uf;

	@Column(name="tipo_ambiente")
	private String tipoAmbiente;

	@Column(name="tipo_emitente")
	private String tipoEmitente;

	@Column(name="tipo_transportadora")
	private String tipoTransportadora;

	@Column(name="modelo")
	private String modelo;

	@Column(name="serie")
	private String serie;

	@Column(name="numero_mdfe")
	private String numeroMdfe;

	@Column(name="codigo_numerico")
	private String codigoNumerico;

	@Column(name="chave_acesso")
	private String chaveAcesso;

	@Column(name="digito_verificador")
	private Integer digitoVerificador;

	@Column(name="modal")
	private String modal;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_emissao")
	private Date dataHoraEmissao;

	@Column(name="tipo_emissao")
	private String tipoEmissao;

	@Column(name="processo_emissao")
	private String processoEmissao;

	@Column(name="versao_processo_emissao")
	private String versaoProcessoEmissao;

	@Column(name="uf_inicio")
	private String ufInicio;

	@Column(name="uf_fim")
	private String ufFim;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_previsao_viagem")
	private Date dataHoraPrevisaoViagem;

	@Column(name="quantidade_total_cte")
	private Integer quantidadeTotalCte;

	@Column(name="quantidade_total_nfe")
	private Integer quantidadeTotalNfe;

	@Column(name="quantidade_total_mdfe")
	private Integer quantidadeTotalMdfe;

	@Column(name="codigo_unidade_medida")
	private String codigoUnidadeMedida;

	@Column(name="peso_bruto_carga")
	private BigDecimal pesoBrutoCarga;

	@Column(name="valor_carga")
	private BigDecimal valorCarga;

	@Column(name="numero_protocolo")
	private String numeroProtocolo;

	@OneToMany(mappedBy = "mdfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<MdfeLacreModel> mdfeLacreModelList; 

	@OneToMany(mappedBy = "mdfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<MdfeMunicipioDescarregaModel> mdfeMunicipioDescarregaModelList; 

	@OneToMany(mappedBy = "mdfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<MdfeEmitenteModel> mdfeEmitenteModelList; 

	@OneToMany(mappedBy = "mdfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<MdfePercursoModel> mdfePercursoModelList; 

	@OneToMany(mappedBy = "mdfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<MdfeMunicipioCarregamentoModel> mdfeMunicipioCarregamentoModelList; 

	@OneToMany(mappedBy = "mdfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<MdfeRodoviarioModel> mdfeRodoviarioModelList; 

	@OneToMany(mappedBy = "mdfeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<MdfeInformacaoSeguroModel> mdfeInformacaoSeguroModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getTipoAmbiente() { 
		return this.tipoAmbiente; 
	} 

	public void setTipoAmbiente(String tipoAmbiente) { 
		this.tipoAmbiente = tipoAmbiente; 
	} 

	public String getTipoEmitente() { 
		return this.tipoEmitente; 
	} 

	public void setTipoEmitente(String tipoEmitente) { 
		this.tipoEmitente = tipoEmitente; 
	} 

	public String getTipoTransportadora() { 
		return this.tipoTransportadora; 
	} 

	public void setTipoTransportadora(String tipoTransportadora) { 
		this.tipoTransportadora = tipoTransportadora; 
	} 

	public String getModelo() { 
		return this.modelo; 
	} 

	public void setModelo(String modelo) { 
		this.modelo = modelo; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public String getNumeroMdfe() { 
		return this.numeroMdfe; 
	} 

	public void setNumeroMdfe(String numeroMdfe) { 
		this.numeroMdfe = numeroMdfe; 
	} 

	public String getCodigoNumerico() { 
		return this.codigoNumerico; 
	} 

	public void setCodigoNumerico(String codigoNumerico) { 
		this.codigoNumerico = codigoNumerico; 
	} 

	public String getChaveAcesso() { 
		return this.chaveAcesso; 
	} 

	public void setChaveAcesso(String chaveAcesso) { 
		this.chaveAcesso = chaveAcesso; 
	} 

	public Integer getDigitoVerificador() { 
		return this.digitoVerificador; 
	} 

	public void setDigitoVerificador(Integer digitoVerificador) { 
		this.digitoVerificador = digitoVerificador; 
	} 

	public String getModal() { 
		return this.modal; 
	} 

	public void setModal(String modal) { 
		this.modal = modal; 
	} 

	public Date getDataHoraEmissao() { 
		return this.dataHoraEmissao; 
	} 

	public void setDataHoraEmissao(Date dataHoraEmissao) { 
		this.dataHoraEmissao = dataHoraEmissao; 
	} 

	public String getTipoEmissao() { 
		return this.tipoEmissao; 
	} 

	public void setTipoEmissao(String tipoEmissao) { 
		this.tipoEmissao = tipoEmissao; 
	} 

	public String getProcessoEmissao() { 
		return this.processoEmissao; 
	} 

	public void setProcessoEmissao(String processoEmissao) { 
		this.processoEmissao = processoEmissao; 
	} 

	public String getVersaoProcessoEmissao() { 
		return this.versaoProcessoEmissao; 
	} 

	public void setVersaoProcessoEmissao(String versaoProcessoEmissao) { 
		this.versaoProcessoEmissao = versaoProcessoEmissao; 
	} 

	public String getUfInicio() { 
		return this.ufInicio; 
	} 

	public void setUfInicio(String ufInicio) { 
		this.ufInicio = ufInicio; 
	} 

	public String getUfFim() { 
		return this.ufFim; 
	} 

	public void setUfFim(String ufFim) { 
		this.ufFim = ufFim; 
	} 

	public Date getDataHoraPrevisaoViagem() { 
		return this.dataHoraPrevisaoViagem; 
	} 

	public void setDataHoraPrevisaoViagem(Date dataHoraPrevisaoViagem) { 
		this.dataHoraPrevisaoViagem = dataHoraPrevisaoViagem; 
	} 

	public Integer getQuantidadeTotalCte() { 
		return this.quantidadeTotalCte; 
	} 

	public void setQuantidadeTotalCte(Integer quantidadeTotalCte) { 
		this.quantidadeTotalCte = quantidadeTotalCte; 
	} 

	public Integer getQuantidadeTotalNfe() { 
		return this.quantidadeTotalNfe; 
	} 

	public void setQuantidadeTotalNfe(Integer quantidadeTotalNfe) { 
		this.quantidadeTotalNfe = quantidadeTotalNfe; 
	} 

	public Integer getQuantidadeTotalMdfe() { 
		return this.quantidadeTotalMdfe; 
	} 

	public void setQuantidadeTotalMdfe(Integer quantidadeTotalMdfe) { 
		this.quantidadeTotalMdfe = quantidadeTotalMdfe; 
	} 

	public String getCodigoUnidadeMedida() { 
		return this.codigoUnidadeMedida; 
	} 

	public void setCodigoUnidadeMedida(String codigoUnidadeMedida) { 
		this.codigoUnidadeMedida = codigoUnidadeMedida; 
	} 

	public BigDecimal getPesoBrutoCarga() { 
		return this.pesoBrutoCarga; 
	} 

	public void setPesoBrutoCarga(BigDecimal pesoBrutoCarga) { 
		this.pesoBrutoCarga = pesoBrutoCarga; 
	} 

	public BigDecimal getValorCarga() { 
		return this.valorCarga; 
	} 

	public void setValorCarga(BigDecimal valorCarga) { 
		this.valorCarga = valorCarga; 
	} 

	public String getNumeroProtocolo() { 
		return this.numeroProtocolo; 
	} 

	public void setNumeroProtocolo(String numeroProtocolo) { 
		this.numeroProtocolo = numeroProtocolo; 
	} 

	public Set<MdfeLacreModel> getMdfeLacreModelList() { 
	return this.mdfeLacreModelList; 
	} 

	public void setMdfeLacreModelList(Set<MdfeLacreModel> mdfeLacreModelList) { 
	this.mdfeLacreModelList = mdfeLacreModelList; 
		for (MdfeLacreModel mdfeLacreModel : mdfeLacreModelList) { 
			mdfeLacreModel.setMdfeCabecalhoModel(this); 
		}
	} 

	public Set<MdfeMunicipioDescarregaModel> getMdfeMunicipioDescarregaModelList() { 
	return this.mdfeMunicipioDescarregaModelList; 
	} 

	public void setMdfeMunicipioDescarregaModelList(Set<MdfeMunicipioDescarregaModel> mdfeMunicipioDescarregaModelList) { 
	this.mdfeMunicipioDescarregaModelList = mdfeMunicipioDescarregaModelList; 
		for (MdfeMunicipioDescarregaModel mdfeMunicipioDescarregaModel : mdfeMunicipioDescarregaModelList) { 
			mdfeMunicipioDescarregaModel.setMdfeCabecalhoModel(this); 
		}
	} 

	public Set<MdfeEmitenteModel> getMdfeEmitenteModelList() { 
	return this.mdfeEmitenteModelList; 
	} 

	public void setMdfeEmitenteModelList(Set<MdfeEmitenteModel> mdfeEmitenteModelList) { 
	this.mdfeEmitenteModelList = mdfeEmitenteModelList; 
		for (MdfeEmitenteModel mdfeEmitenteModel : mdfeEmitenteModelList) { 
			mdfeEmitenteModel.setMdfeCabecalhoModel(this); 
		}
	} 

	public Set<MdfePercursoModel> getMdfePercursoModelList() { 
	return this.mdfePercursoModelList; 
	} 

	public void setMdfePercursoModelList(Set<MdfePercursoModel> mdfePercursoModelList) { 
	this.mdfePercursoModelList = mdfePercursoModelList; 
		for (MdfePercursoModel mdfePercursoModel : mdfePercursoModelList) { 
			mdfePercursoModel.setMdfeCabecalhoModel(this); 
		}
	} 

	public Set<MdfeMunicipioCarregamentoModel> getMdfeMunicipioCarregamentoModelList() { 
	return this.mdfeMunicipioCarregamentoModelList; 
	} 

	public void setMdfeMunicipioCarregamentoModelList(Set<MdfeMunicipioCarregamentoModel> mdfeMunicipioCarregamentoModelList) { 
	this.mdfeMunicipioCarregamentoModelList = mdfeMunicipioCarregamentoModelList; 
		for (MdfeMunicipioCarregamentoModel mdfeMunicipioCarregamentoModel : mdfeMunicipioCarregamentoModelList) { 
			mdfeMunicipioCarregamentoModel.setMdfeCabecalhoModel(this); 
		}
	} 

	public Set<MdfeRodoviarioModel> getMdfeRodoviarioModelList() { 
	return this.mdfeRodoviarioModelList; 
	} 

	public void setMdfeRodoviarioModelList(Set<MdfeRodoviarioModel> mdfeRodoviarioModelList) { 
	this.mdfeRodoviarioModelList = mdfeRodoviarioModelList; 
		for (MdfeRodoviarioModel mdfeRodoviarioModel : mdfeRodoviarioModelList) { 
			mdfeRodoviarioModel.setMdfeCabecalhoModel(this); 
		}
	} 

	public Set<MdfeInformacaoSeguroModel> getMdfeInformacaoSeguroModelList() { 
	return this.mdfeInformacaoSeguroModelList; 
	} 

	public void setMdfeInformacaoSeguroModelList(Set<MdfeInformacaoSeguroModel> mdfeInformacaoSeguroModelList) { 
	this.mdfeInformacaoSeguroModelList = mdfeInformacaoSeguroModelList; 
		for (MdfeInformacaoSeguroModel mdfeInformacaoSeguroModel : mdfeInformacaoSeguroModelList) { 
			mdfeInformacaoSeguroModel.setMdfeCabecalhoModel(this); 
		}
	} 

		
}