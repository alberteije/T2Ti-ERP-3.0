package com.t2ti.mdfe.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.mdfe.exception.GenericException;
import com.t2ti.mdfe.exception.ResourseNotFoundException;
import com.t2ti.mdfe.exception.BadRequestException;
import com.t2ti.mdfe.util.Filter;
import com.t2ti.mdfe.model.MdfeRodoviarioVeiculoModel;
import com.t2ti.mdfe.service.MdfeRodoviarioVeiculoService;

@RestController
@RequestMapping(value = "/mdfe-rodoviario-veiculo", produces = "application/json;charset=UTF-8")
public class MdfeRodoviarioVeiculoController {

	@Autowired
	private MdfeRodoviarioVeiculoService service;
	
	@GetMapping({ "", "/" })
	public List<MdfeRodoviarioVeiculoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [MdfeRodoviarioVeiculo] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public MdfeRodoviarioVeiculoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found MdfeRodoviarioVeiculo].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found MdfeRodoviarioVeiculo] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public MdfeRodoviarioVeiculoModel insert(@RequestBody MdfeRodoviarioVeiculoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert MdfeRodoviarioVeiculo] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public MdfeRodoviarioVeiculoModel update(@RequestBody MdfeRodoviarioVeiculoModel objJson) {	
		try {			
			MdfeRodoviarioVeiculoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update MdfeRodoviarioVeiculo].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update MdfeRodoviarioVeiculo] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete MdfeRodoviarioVeiculo] - Exception: " + e.getMessage());
		}
	}
	
}