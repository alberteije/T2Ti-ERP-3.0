package com.t2ti.mdfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.mdfe.util.Filter;
import com.t2ti.mdfe.exception.GenericException;
import com.t2ti.mdfe.model.MdfeRodoviarioVeiculoModel;
import com.t2ti.mdfe.repository.MdfeRodoviarioVeiculoRepository;

@Service
public class MdfeRodoviarioVeiculoService {

	@Autowired
	private MdfeRodoviarioVeiculoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<MdfeRodoviarioVeiculoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<MdfeRodoviarioVeiculoModel> getList(Filter filter) {
		String sql = "select * from mdfe_rodoviario_veiculo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, MdfeRodoviarioVeiculoModel.class);
		return query.getResultList();
	}

	public MdfeRodoviarioVeiculoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public MdfeRodoviarioVeiculoModel save(MdfeRodoviarioVeiculoModel obj) {
		MdfeRodoviarioVeiculoModel mdfeRodoviarioVeiculoModel = repository.save(obj);
		return mdfeRodoviarioVeiculoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		MdfeRodoviarioVeiculoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete MdfeRodoviarioVeiculo] - Exception: " + e.getMessage());
		}
	}

}