package com.t2ti.mdfe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.mdfe.model.UsuarioTokenModel;

public interface UsuarioTokenRepository extends JpaRepository<UsuarioTokenModel, Integer> {}