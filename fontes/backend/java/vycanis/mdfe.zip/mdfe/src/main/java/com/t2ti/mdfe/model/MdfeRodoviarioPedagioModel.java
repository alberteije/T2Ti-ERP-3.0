package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_rodoviario_pedagio")
@NamedQuery(name="MdfeRodoviarioPedagioModel.findAll", query="SELECT t FROM MdfeRodoviarioPedagioModel t")
public class MdfeRodoviarioPedagioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeRodoviarioPedagioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj_fornecedor")
	private String cnpjFornecedor;

	@Column(name="cnpj_responsavel")
	private String cnpjResponsavel;

	@Column(name="cpf_responsavel")
	private String cpfResponsavel;

	@Column(name="numero_comprovante")
	private String numeroComprovante;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JoinColumn(name="id_mdfe_rodoviario")
	private MdfeRodoviarioModel mdfeRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpjFornecedor() { 
		return this.cnpjFornecedor; 
	} 

	public void setCnpjFornecedor(String cnpjFornecedor) { 
		this.cnpjFornecedor = cnpjFornecedor; 
	} 

	public String getCnpjResponsavel() { 
		return this.cnpjResponsavel; 
	} 

	public void setCnpjResponsavel(String cnpjResponsavel) { 
		this.cnpjResponsavel = cnpjResponsavel; 
	} 

	public String getCpfResponsavel() { 
		return this.cpfResponsavel; 
	} 

	public void setCpfResponsavel(String cpfResponsavel) { 
		this.cpfResponsavel = cpfResponsavel; 
	} 

	public String getNumeroComprovante() { 
		return this.numeroComprovante; 
	} 

	public void setNumeroComprovante(String numeroComprovante) { 
		this.numeroComprovante = numeroComprovante; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public MdfeRodoviarioModel getMdfeRodoviarioModel() { 
	return this.mdfeRodoviarioModel; 
	} 

	public void setMdfeRodoviarioModel(MdfeRodoviarioModel mdfeRodoviarioModel) { 
	this.mdfeRodoviarioModel = mdfeRodoviarioModel; 
	} 

		
}