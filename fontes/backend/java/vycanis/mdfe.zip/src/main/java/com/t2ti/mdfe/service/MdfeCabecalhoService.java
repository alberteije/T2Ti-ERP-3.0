package com.t2ti.mdfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.mdfe.util.Filter;
import com.t2ti.mdfe.exception.GenericException;
import com.t2ti.mdfe.model.MdfeCabecalhoModel;
import com.t2ti.mdfe.repository.MdfeCabecalhoRepository;

@Service
public class MdfeCabecalhoService {

	@Autowired
	private MdfeCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<MdfeCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<MdfeCabecalhoModel> getList(Filter filter) {
		String sql = "select * from mdfe_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, MdfeCabecalhoModel.class);
		return query.getResultList();
	}

	public MdfeCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public MdfeCabecalhoModel save(MdfeCabecalhoModel obj) {
		MdfeCabecalhoModel mdfeCabecalhoModel = repository.save(obj);
		return mdfeCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		MdfeCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete MdfeCabecalho] - Exception: " + e.getMessage());
		}
	}

}