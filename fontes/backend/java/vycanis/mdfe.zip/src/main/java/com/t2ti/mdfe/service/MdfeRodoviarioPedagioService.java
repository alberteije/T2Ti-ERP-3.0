package com.t2ti.mdfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.mdfe.util.Filter;
import com.t2ti.mdfe.exception.GenericException;
import com.t2ti.mdfe.model.MdfeRodoviarioPedagioModel;
import com.t2ti.mdfe.repository.MdfeRodoviarioPedagioRepository;

@Service
public class MdfeRodoviarioPedagioService {

	@Autowired
	private MdfeRodoviarioPedagioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<MdfeRodoviarioPedagioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<MdfeRodoviarioPedagioModel> getList(Filter filter) {
		String sql = "select * from mdfe_rodoviario_pedagio where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, MdfeRodoviarioPedagioModel.class);
		return query.getResultList();
	}

	public MdfeRodoviarioPedagioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public MdfeRodoviarioPedagioModel save(MdfeRodoviarioPedagioModel obj) {
		MdfeRodoviarioPedagioModel mdfeRodoviarioPedagioModel = repository.save(obj);
		return mdfeRodoviarioPedagioModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		MdfeRodoviarioPedagioModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete MdfeRodoviarioPedagio] - Exception: " + e.getMessage());
		}
	}

}