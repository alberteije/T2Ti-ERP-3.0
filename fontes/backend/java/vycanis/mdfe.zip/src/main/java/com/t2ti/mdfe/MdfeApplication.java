package com.t2ti.mdfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdfeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdfeApplication.class, args);
	}

}
