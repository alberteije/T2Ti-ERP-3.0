package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_municipio_carregamento")
@NamedQuery(name="MdfeMunicipioCarregamentoModel.findAll", query="SELECT t FROM MdfeMunicipioCarregamentoModel t")
public class MdfeMunicipioCarregamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeMunicipioCarregamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_municipio")
	private String codigoMunicipio;

	@Column(name="nome_municipio")
	private String nomeMunicipio;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_mdfe_cabecalho")
	private MdfeCabecalhoModel mdfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoMunicipio() { 
		return this.codigoMunicipio; 
	} 

	public void setCodigoMunicipio(String codigoMunicipio) { 
		this.codigoMunicipio = codigoMunicipio; 
	} 

	public String getNomeMunicipio() { 
		return this.nomeMunicipio; 
	} 

	public void setNomeMunicipio(String nomeMunicipio) { 
		this.nomeMunicipio = nomeMunicipio; 
	} 

	public MdfeCabecalhoModel getMdfeCabecalhoModel() { 
	return this.mdfeCabecalhoModel; 
	} 

	public void setMdfeCabecalhoModel(MdfeCabecalhoModel mdfeCabecalhoModel) { 
	this.mdfeCabecalhoModel = mdfeCabecalhoModel; 
	} 

		
}