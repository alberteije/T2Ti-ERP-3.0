package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_lacre")
@NamedQuery(name="MdfeLacreModel.findAll", query="SELECT t FROM MdfeLacreModel t")
public class MdfeLacreModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeLacreModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_lacre")
	private String numeroLacre;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_mdfe_cabecalho")
	private MdfeCabecalhoModel mdfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumeroLacre() { 
		return this.numeroLacre; 
	} 

	public void setNumeroLacre(String numeroLacre) { 
		this.numeroLacre = numeroLacre; 
	} 

	public MdfeCabecalhoModel getMdfeCabecalhoModel() { 
	return this.mdfeCabecalhoModel; 
	} 

	public void setMdfeCabecalhoModel(MdfeCabecalhoModel mdfeCabecalhoModel) { 
	this.mdfeCabecalhoModel = mdfeCabecalhoModel; 
	} 

		
}