package com.t2ti.mdfe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.mdfe.util.Filter;
import com.t2ti.mdfe.exception.GenericException;
import com.t2ti.mdfe.model.MdfeInformacaoCteModel;
import com.t2ti.mdfe.repository.MdfeInformacaoCteRepository;

@Service
public class MdfeInformacaoCteService {

	@Autowired
	private MdfeInformacaoCteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<MdfeInformacaoCteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<MdfeInformacaoCteModel> getList(Filter filter) {
		String sql = "select * from mdfe_informacao_cte where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, MdfeInformacaoCteModel.class);
		return query.getResultList();
	}

	public MdfeInformacaoCteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public MdfeInformacaoCteModel save(MdfeInformacaoCteModel obj) {
		MdfeInformacaoCteModel mdfeInformacaoCteModel = repository.save(obj);
		return mdfeInformacaoCteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		MdfeInformacaoCteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete MdfeInformacaoCte] - Exception: " + e.getMessage());
		}
	}

}