package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_rodoviario_veiculo")
@NamedQuery(name="MdfeRodoviarioVeiculoModel.findAll", query="SELECT t FROM MdfeRodoviarioVeiculoModel t")
public class MdfeRodoviarioVeiculoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfeRodoviarioVeiculoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_interno")
	private String codigoInterno;

	@Column(name="placa")
	private String placa;

	@Column(name="renavam")
	private String renavam;

	@Column(name="tara")
	private Integer tara;

	@Column(name="capacidade_kg")
	private Integer capacidadeKg;

	@Column(name="capacidade_m3")
	private Integer capacidadeM3;

	@Column(name="tipo_rodado")
	private String tipoRodado;

	@Column(name="tipo_carroceria")
	private String tipoCarroceria;

	@Column(name="uf_licenciamento")
	private String ufLicenciamento;

	@Column(name="proprietario_cpf")
	private String proprietarioCpf;

	@Column(name="proprietario_cnpj")
	private String proprietarioCnpj;

	@Column(name="proprietario_rntrc")
	private String proprietarioRntrc;

	@Column(name="proprietario_nome")
	private String proprietarioNome;

	@Column(name="proprietario_ie")
	private String proprietarioIe;

	@Column(name="proprietario_tipo")
	private Integer proprietarioTipo;

	@ManyToOne 
	@JoinColumn(name="id_mdfe_rodoviario")
	private MdfeRodoviarioModel mdfeRodoviarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoInterno() { 
		return this.codigoInterno; 
	} 

	public void setCodigoInterno(String codigoInterno) { 
		this.codigoInterno = codigoInterno; 
	} 

	public String getPlaca() { 
		return this.placa; 
	} 

	public void setPlaca(String placa) { 
		this.placa = placa; 
	} 

	public String getRenavam() { 
		return this.renavam; 
	} 

	public void setRenavam(String renavam) { 
		this.renavam = renavam; 
	} 

	public Integer getTara() { 
		return this.tara; 
	} 

	public void setTara(Integer tara) { 
		this.tara = tara; 
	} 

	public Integer getCapacidadeKg() { 
		return this.capacidadeKg; 
	} 

	public void setCapacidadeKg(Integer capacidadeKg) { 
		this.capacidadeKg = capacidadeKg; 
	} 

	public Integer getCapacidadeM3() { 
		return this.capacidadeM3; 
	} 

	public void setCapacidadeM3(Integer capacidadeM3) { 
		this.capacidadeM3 = capacidadeM3; 
	} 

	public String getTipoRodado() { 
		return this.tipoRodado; 
	} 

	public void setTipoRodado(String tipoRodado) { 
		this.tipoRodado = tipoRodado; 
	} 

	public String getTipoCarroceria() { 
		return this.tipoCarroceria; 
	} 

	public void setTipoCarroceria(String tipoCarroceria) { 
		this.tipoCarroceria = tipoCarroceria; 
	} 

	public String getUfLicenciamento() { 
		return this.ufLicenciamento; 
	} 

	public void setUfLicenciamento(String ufLicenciamento) { 
		this.ufLicenciamento = ufLicenciamento; 
	} 

	public String getProprietarioCpf() { 
		return this.proprietarioCpf; 
	} 

	public void setProprietarioCpf(String proprietarioCpf) { 
		this.proprietarioCpf = proprietarioCpf; 
	} 

	public String getProprietarioCnpj() { 
		return this.proprietarioCnpj; 
	} 

	public void setProprietarioCnpj(String proprietarioCnpj) { 
		this.proprietarioCnpj = proprietarioCnpj; 
	} 

	public String getProprietarioRntrc() { 
		return this.proprietarioRntrc; 
	} 

	public void setProprietarioRntrc(String proprietarioRntrc) { 
		this.proprietarioRntrc = proprietarioRntrc; 
	} 

	public String getProprietarioNome() { 
		return this.proprietarioNome; 
	} 

	public void setProprietarioNome(String proprietarioNome) { 
		this.proprietarioNome = proprietarioNome; 
	} 

	public String getProprietarioIe() { 
		return this.proprietarioIe; 
	} 

	public void setProprietarioIe(String proprietarioIe) { 
		this.proprietarioIe = proprietarioIe; 
	} 

	public Integer getProprietarioTipo() { 
		return this.proprietarioTipo; 
	} 

	public void setProprietarioTipo(Integer proprietarioTipo) { 
		this.proprietarioTipo = proprietarioTipo; 
	} 

	public MdfeRodoviarioModel getMdfeRodoviarioModel() { 
	return this.mdfeRodoviarioModel; 
	} 

	public void setMdfeRodoviarioModel(MdfeRodoviarioModel mdfeRodoviarioModel) { 
	this.mdfeRodoviarioModel = mdfeRodoviarioModel; 
	} 

		
}