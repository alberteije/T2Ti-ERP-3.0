package com.t2ti.mdfe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="mdfe_percurso")
@NamedQuery(name="MdfePercursoModel.findAll", query="SELECT t FROM MdfePercursoModel t")
public class MdfePercursoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MdfePercursoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="uf_percurso")
	private String ufPercurso;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio_viagem")
	private Date dataInicioViagem;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_mdfe_cabecalho")
	private MdfeCabecalhoModel mdfeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getUfPercurso() { 
		return this.ufPercurso; 
	} 

	public void setUfPercurso(String ufPercurso) { 
		this.ufPercurso = ufPercurso; 
	} 

	public Date getDataInicioViagem() { 
		return this.dataInicioViagem; 
	} 

	public void setDataInicioViagem(Date dataInicioViagem) { 
		this.dataInicioViagem = dataInicioViagem; 
	} 

	public MdfeCabecalhoModel getMdfeCabecalhoModel() { 
	return this.mdfeCabecalhoModel; 
	} 

	public void setMdfeCabecalhoModel(MdfeCabecalhoModel mdfeCabecalhoModel) { 
	this.mdfeCabecalhoModel = mdfeCabecalhoModel; 
	} 

		
}