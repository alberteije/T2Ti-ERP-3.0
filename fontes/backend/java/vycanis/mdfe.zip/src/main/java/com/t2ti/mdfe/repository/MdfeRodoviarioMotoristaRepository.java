package com.t2ti.mdfe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.mdfe.model.MdfeRodoviarioMotoristaModel;

public interface MdfeRodoviarioMotoristaRepository extends JpaRepository<MdfeRodoviarioMotoristaModel, Integer> {}