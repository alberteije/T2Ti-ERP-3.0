package com.t2ti.ordem_servico.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="os_evolucao")
@NamedQuery(name="OsEvolucaoModel.findAll", query="SELECT t FROM OsEvolucaoModel t")
public class OsEvolucaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OsEvolucaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_registro")
	private Date dataRegistro;

	@Column(name="hora_registro")
	private String horaRegistro;

	@Column(name="enviar_email")
	private String enviarEmail;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_os_abertura")
	private OsAberturaModel osAberturaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataRegistro() { 
		return this.dataRegistro; 
	} 

	public void setDataRegistro(Date dataRegistro) { 
		this.dataRegistro = dataRegistro; 
	} 

	public String getHoraRegistro() { 
		return this.horaRegistro; 
	} 

	public void setHoraRegistro(String horaRegistro) { 
		this.horaRegistro = horaRegistro; 
	} 

	public String getEnviarEmail() { 
		return this.enviarEmail; 
	} 

	public void setEnviarEmail(String enviarEmail) { 
		this.enviarEmail = enviarEmail; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public OsAberturaModel getOsAberturaModel() { 
	return this.osAberturaModel; 
	} 

	public void setOsAberturaModel(OsAberturaModel osAberturaModel) { 
	this.osAberturaModel = osAberturaModel; 
	} 

		
}