package com.t2ti.ordem_servico.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="os_abertura")
@NamedQuery(name="OsAberturaModel.findAll", query="SELECT t FROM OsAberturaModel t")
public class OsAberturaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OsAberturaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Column(name="hora_inicio")
	private String horaInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_previsao")
	private Date dataPrevisao;

	@Column(name="hora_previsao")
	private String horaPrevisao;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Column(name="hora_fim")
	private String horaFim;

	@Column(name="nome_contato")
	private String nomeContato;

	@Column(name="fone_contato")
	private String foneContato;

	@Column(name="observacao_cliente")
	private String observacaoCliente;

	@Column(name="observacao_abertura")
	private String observacaoAbertura;

	@OneToMany(mappedBy = "osAberturaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<OsAberturaEquipamentoModel> osAberturaEquipamentoModelList; 

	@OneToMany(mappedBy = "osAberturaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<OsProdutoServicoModel> osProdutoServicoModelList; 

	@OneToMany(mappedBy = "osAberturaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<OsEvolucaoModel> osEvolucaoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_cliente")
	private ViewPessoaClienteModel viewPessoaClienteModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_os_status")
	private OsStatusModel osStatusModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public String getHoraInicio() { 
		return this.horaInicio; 
	} 

	public void setHoraInicio(String horaInicio) { 
		this.horaInicio = horaInicio; 
	} 

	public Date getDataPrevisao() { 
		return this.dataPrevisao; 
	} 

	public void setDataPrevisao(Date dataPrevisao) { 
		this.dataPrevisao = dataPrevisao; 
	} 

	public String getHoraPrevisao() { 
		return this.horaPrevisao; 
	} 

	public void setHoraPrevisao(String horaPrevisao) { 
		this.horaPrevisao = horaPrevisao; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public String getHoraFim() { 
		return this.horaFim; 
	} 

	public void setHoraFim(String horaFim) { 
		this.horaFim = horaFim; 
	} 

	public String getNomeContato() { 
		return this.nomeContato; 
	} 

	public void setNomeContato(String nomeContato) { 
		this.nomeContato = nomeContato; 
	} 

	public String getFoneContato() { 
		return this.foneContato; 
	} 

	public void setFoneContato(String foneContato) { 
		this.foneContato = foneContato; 
	} 

	public String getObservacaoCliente() { 
		return this.observacaoCliente; 
	} 

	public void setObservacaoCliente(String observacaoCliente) { 
		this.observacaoCliente = observacaoCliente; 
	} 

	public String getObservacaoAbertura() { 
		return this.observacaoAbertura; 
	} 

	public void setObservacaoAbertura(String observacaoAbertura) { 
		this.observacaoAbertura = observacaoAbertura; 
	} 

	public Set<OsAberturaEquipamentoModel> getOsAberturaEquipamentoModelList() { 
	return this.osAberturaEquipamentoModelList; 
	} 

	public void setOsAberturaEquipamentoModelList(Set<OsAberturaEquipamentoModel> osAberturaEquipamentoModelList) { 
	this.osAberturaEquipamentoModelList = osAberturaEquipamentoModelList; 
		for (OsAberturaEquipamentoModel osAberturaEquipamentoModel : osAberturaEquipamentoModelList) { 
			osAberturaEquipamentoModel.setOsAberturaModel(this); 
		}
	} 

	public Set<OsProdutoServicoModel> getOsProdutoServicoModelList() { 
	return this.osProdutoServicoModelList; 
	} 

	public void setOsProdutoServicoModelList(Set<OsProdutoServicoModel> osProdutoServicoModelList) { 
	this.osProdutoServicoModelList = osProdutoServicoModelList; 
		for (OsProdutoServicoModel osProdutoServicoModel : osProdutoServicoModelList) { 
			osProdutoServicoModel.setOsAberturaModel(this); 
		}
	} 

	public Set<OsEvolucaoModel> getOsEvolucaoModelList() { 
	return this.osEvolucaoModelList; 
	} 

	public void setOsEvolucaoModelList(Set<OsEvolucaoModel> osEvolucaoModelList) { 
	this.osEvolucaoModelList = osEvolucaoModelList; 
		for (OsEvolucaoModel osEvolucaoModel : osEvolucaoModelList) { 
			osEvolucaoModel.setOsAberturaModel(this); 
		}
	} 

	public ViewPessoaClienteModel getViewPessoaClienteModel() { 
	return this.viewPessoaClienteModel; 
	} 

	public void setViewPessoaClienteModel(ViewPessoaClienteModel viewPessoaClienteModel) { 
	this.viewPessoaClienteModel = viewPessoaClienteModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public OsStatusModel getOsStatusModel() { 
	return this.osStatusModel; 
	} 

	public void setOsStatusModel(OsStatusModel osStatusModel) { 
	this.osStatusModel = osStatusModel; 
	} 

		
}