package com.t2ti.ordem_servico.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ordem_servico.util.Filter;
import com.t2ti.ordem_servico.exception.GenericException;
import com.t2ti.ordem_servico.model.ViewPessoaClienteModel;
import com.t2ti.ordem_servico.repository.ViewPessoaClienteRepository;

@Service
public class ViewPessoaClienteService {

	@Autowired
	private ViewPessoaClienteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ViewPessoaClienteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ViewPessoaClienteModel> getList(Filter filter) {
		String sql = "select * from view_pessoa_cliente where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewPessoaClienteModel.class);
		return query.getResultList();
	}

	public ViewPessoaClienteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ViewPessoaClienteModel save(ViewPessoaClienteModel obj) {
		ViewPessoaClienteModel viewPessoaClienteModel = repository.save(obj);
		return viewPessoaClienteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ViewPessoaClienteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ViewPessoaCliente] - Exception: " + e.getMessage());
		}
	}

}