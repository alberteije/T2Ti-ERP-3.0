package com.t2ti.ordem_servico.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="os_abertura_equipamento")
@NamedQuery(name="OsAberturaEquipamentoModel.findAll", query="SELECT t FROM OsAberturaEquipamentoModel t")
public class OsAberturaEquipamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OsAberturaEquipamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo_cobertura")
	private String tipoCobertura;

	@Column(name="numero_serie")
	private String numeroSerie;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_os_abertura")
	private OsAberturaModel osAberturaModel; 

	@ManyToOne 
	@JoinColumn(name="id_os_equipamento")
	private OsEquipamentoModel osEquipamentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipoCobertura() { 
		return this.tipoCobertura; 
	} 

	public void setTipoCobertura(String tipoCobertura) { 
		this.tipoCobertura = tipoCobertura; 
	} 

	public String getNumeroSerie() { 
		return this.numeroSerie; 
	} 

	public void setNumeroSerie(String numeroSerie) { 
		this.numeroSerie = numeroSerie; 
	} 

	public OsAberturaModel getOsAberturaModel() { 
	return this.osAberturaModel; 
	} 

	public void setOsAberturaModel(OsAberturaModel osAberturaModel) { 
	this.osAberturaModel = osAberturaModel; 
	} 

	public OsEquipamentoModel getOsEquipamentoModel() { 
	return this.osEquipamentoModel; 
	} 

	public void setOsEquipamentoModel(OsEquipamentoModel osEquipamentoModel) { 
	this.osEquipamentoModel = osEquipamentoModel; 
	} 

		
}