package com.t2ti.ordem_servico.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.ordem_servico.model.ProdutoUnidadeModel;

public interface ProdutoUnidadeRepository extends JpaRepository<ProdutoUnidadeModel, Integer> {}