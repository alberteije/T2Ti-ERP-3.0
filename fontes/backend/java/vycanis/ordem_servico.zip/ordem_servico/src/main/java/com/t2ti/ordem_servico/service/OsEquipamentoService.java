package com.t2ti.ordem_servico.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ordem_servico.util.Filter;
import com.t2ti.ordem_servico.exception.GenericException;
import com.t2ti.ordem_servico.model.OsEquipamentoModel;
import com.t2ti.ordem_servico.repository.OsEquipamentoRepository;

@Service
public class OsEquipamentoService {

	@Autowired
	private OsEquipamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<OsEquipamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<OsEquipamentoModel> getList(Filter filter) {
		String sql = "select * from os_equipamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, OsEquipamentoModel.class);
		return query.getResultList();
	}

	public OsEquipamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public OsEquipamentoModel save(OsEquipamentoModel obj) {
		OsEquipamentoModel osEquipamentoModel = repository.save(obj);
		return osEquipamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		OsEquipamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete OsEquipamento] - Exception: " + e.getMessage());
		}
	}

}