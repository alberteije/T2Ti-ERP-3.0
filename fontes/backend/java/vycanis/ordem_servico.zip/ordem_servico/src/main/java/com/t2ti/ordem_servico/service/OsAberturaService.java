package com.t2ti.ordem_servico.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ordem_servico.util.Filter;
import com.t2ti.ordem_servico.exception.GenericException;
import com.t2ti.ordem_servico.model.OsAberturaModel;
import com.t2ti.ordem_servico.repository.OsAberturaRepository;

@Service
public class OsAberturaService {

	@Autowired
	private OsAberturaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<OsAberturaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<OsAberturaModel> getList(Filter filter) {
		String sql = "select * from os_abertura where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, OsAberturaModel.class);
		return query.getResultList();
	}

	public OsAberturaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public OsAberturaModel save(OsAberturaModel obj) {
		OsAberturaModel osAberturaModel = repository.save(obj);
		return osAberturaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		OsAberturaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete OsAbertura] - Exception: " + e.getMessage());
		}
	}

}