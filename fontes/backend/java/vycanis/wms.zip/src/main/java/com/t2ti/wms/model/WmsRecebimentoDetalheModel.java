package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="wms_recebimento_detalhe")
@NamedQuery(name="WmsRecebimentoDetalheModel.findAll", query="SELECT t FROM WmsRecebimentoDetalheModel t")
public class WmsRecebimentoDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsRecebimentoDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade_volume")
	private Integer quantidadeVolume;

	@Column(name="quantidade_item_por_volume")
	private Integer quantidadeItemPorVolume;

	@Column(name="quantidade_recebida")
	private Integer quantidadeRecebida;

	@Column(name="destino")
	private String destino;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_wms_recebimento_cabecalho")
	private WmsRecebimentoCabecalhoModel wmsRecebimentoCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidadeVolume() { 
		return this.quantidadeVolume; 
	} 

	public void setQuantidadeVolume(Integer quantidadeVolume) { 
		this.quantidadeVolume = quantidadeVolume; 
	} 

	public Integer getQuantidadeItemPorVolume() { 
		return this.quantidadeItemPorVolume; 
	} 

	public void setQuantidadeItemPorVolume(Integer quantidadeItemPorVolume) { 
		this.quantidadeItemPorVolume = quantidadeItemPorVolume; 
	} 

	public Integer getQuantidadeRecebida() { 
		return this.quantidadeRecebida; 
	} 

	public void setQuantidadeRecebida(Integer quantidadeRecebida) { 
		this.quantidadeRecebida = quantidadeRecebida; 
	} 

	public String getDestino() { 
		return this.destino; 
	} 

	public void setDestino(String destino) { 
		this.destino = destino; 
	} 

	public WmsRecebimentoCabecalhoModel getWmsRecebimentoCabecalhoModel() { 
	return this.wmsRecebimentoCabecalhoModel; 
	} 

	public void setWmsRecebimentoCabecalhoModel(WmsRecebimentoCabecalhoModel wmsRecebimentoCabecalhoModel) { 
	this.wmsRecebimentoCabecalhoModel = wmsRecebimentoCabecalhoModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}