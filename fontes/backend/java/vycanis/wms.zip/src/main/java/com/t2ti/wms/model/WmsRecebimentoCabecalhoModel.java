package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="wms_recebimento_cabecalho")
@NamedQuery(name="WmsRecebimentoCabecalhoModel.findAll", query="SELECT t FROM WmsRecebimentoCabecalhoModel t")
public class WmsRecebimentoCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsRecebimentoCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_recebimento")
	private Date dataRecebimento;

	@Column(name="hora_inicio")
	private String horaInicio;

	@Column(name="hora_fim")
	private String horaFim;

	@Column(name="volume_recebido")
	private Integer volumeRecebido;

	@Column(name="peso_recebido")
	private BigDecimal pesoRecebido;

	@Column(name="inconsistencia")
	private String inconsistencia;

	@Column(name="observacao")
	private String observacao;

	@OneToMany(mappedBy = "wmsRecebimentoCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<WmsRecebimentoDetalheModel> wmsRecebimentoDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_wms_agendamento")
	private WmsAgendamentoModel wmsAgendamentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataRecebimento() { 
		return this.dataRecebimento; 
	} 

	public void setDataRecebimento(Date dataRecebimento) { 
		this.dataRecebimento = dataRecebimento; 
	} 

	public String getHoraInicio() { 
		return this.horaInicio; 
	} 

	public void setHoraInicio(String horaInicio) { 
		this.horaInicio = horaInicio; 
	} 

	public String getHoraFim() { 
		return this.horaFim; 
	} 

	public void setHoraFim(String horaFim) { 
		this.horaFim = horaFim; 
	} 

	public Integer getVolumeRecebido() { 
		return this.volumeRecebido; 
	} 

	public void setVolumeRecebido(Integer volumeRecebido) { 
		this.volumeRecebido = volumeRecebido; 
	} 

	public BigDecimal getPesoRecebido() { 
		return this.pesoRecebido; 
	} 

	public void setPesoRecebido(BigDecimal pesoRecebido) { 
		this.pesoRecebido = pesoRecebido; 
	} 

	public String getInconsistencia() { 
		return this.inconsistencia; 
	} 

	public void setInconsistencia(String inconsistencia) { 
		this.inconsistencia = inconsistencia; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Set<WmsRecebimentoDetalheModel> getWmsRecebimentoDetalheModelList() { 
	return this.wmsRecebimentoDetalheModelList; 
	} 

	public void setWmsRecebimentoDetalheModelList(Set<WmsRecebimentoDetalheModel> wmsRecebimentoDetalheModelList) { 
	this.wmsRecebimentoDetalheModelList = wmsRecebimentoDetalheModelList; 
		for (WmsRecebimentoDetalheModel wmsRecebimentoDetalheModel : wmsRecebimentoDetalheModelList) { 
			wmsRecebimentoDetalheModel.setWmsRecebimentoCabecalhoModel(this); 
		}
	} 

	public WmsAgendamentoModel getWmsAgendamentoModel() { 
	return this.wmsAgendamentoModel; 
	} 

	public void setWmsAgendamentoModel(WmsAgendamentoModel wmsAgendamentoModel) { 
	this.wmsAgendamentoModel = wmsAgendamentoModel; 
	} 

		
}