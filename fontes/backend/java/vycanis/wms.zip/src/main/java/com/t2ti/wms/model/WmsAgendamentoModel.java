package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="wms_agendamento")
@NamedQuery(name="WmsAgendamentoModel.findAll", query="SELECT t FROM WmsAgendamentoModel t")
public class WmsAgendamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsAgendamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_operacao")
	private Date dataOperacao;

	@Column(name="hora_operacao")
	private String horaOperacao;

	@Column(name="local_operacao")
	private String localOperacao;

	@Column(name="quantidade_volume")
	private Integer quantidadeVolume;

	@Column(name="peso_total_volume")
	private BigDecimal pesoTotalVolume;

	@Column(name="quantidade_pessoa")
	private Integer quantidadePessoa;

	@Column(name="quantidade_hora")
	private Integer quantidadeHora;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataOperacao() { 
		return this.dataOperacao; 
	} 

	public void setDataOperacao(Date dataOperacao) { 
		this.dataOperacao = dataOperacao; 
	} 

	public String getHoraOperacao() { 
		return this.horaOperacao; 
	} 

	public void setHoraOperacao(String horaOperacao) { 
		this.horaOperacao = horaOperacao; 
	} 

	public String getLocalOperacao() { 
		return this.localOperacao; 
	} 

	public void setLocalOperacao(String localOperacao) { 
		this.localOperacao = localOperacao; 
	} 

	public Integer getQuantidadeVolume() { 
		return this.quantidadeVolume; 
	} 

	public void setQuantidadeVolume(Integer quantidadeVolume) { 
		this.quantidadeVolume = quantidadeVolume; 
	} 

	public BigDecimal getPesoTotalVolume() { 
		return this.pesoTotalVolume; 
	} 

	public void setPesoTotalVolume(BigDecimal pesoTotalVolume) { 
		this.pesoTotalVolume = pesoTotalVolume; 
	} 

	public Integer getQuantidadePessoa() { 
		return this.quantidadePessoa; 
	} 

	public void setQuantidadePessoa(Integer quantidadePessoa) { 
		this.quantidadePessoa = quantidadePessoa; 
	} 

	public Integer getQuantidadeHora() { 
		return this.quantidadeHora; 
	} 

	public void setQuantidadeHora(Integer quantidadeHora) { 
		this.quantidadeHora = quantidadeHora; 
	} 

		
}