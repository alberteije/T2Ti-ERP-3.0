package com.t2ti.wms.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.wms.util.Filter;
import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.model.WmsAgendamentoModel;
import com.t2ti.wms.repository.WmsAgendamentoRepository;

@Service
public class WmsAgendamentoService {

	@Autowired
	private WmsAgendamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<WmsAgendamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<WmsAgendamentoModel> getList(Filter filter) {
		String sql = "select * from wms_agendamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, WmsAgendamentoModel.class);
		return query.getResultList();
	}

	public WmsAgendamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public WmsAgendamentoModel save(WmsAgendamentoModel obj) {
		WmsAgendamentoModel wmsAgendamentoModel = repository.save(obj);
		return wmsAgendamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		WmsAgendamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsAgendamento] - Exception: " + e.getMessage());
		}
	}

}