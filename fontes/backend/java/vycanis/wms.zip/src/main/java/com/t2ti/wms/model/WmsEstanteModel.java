package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="wms_estante")
@NamedQuery(name="WmsEstanteModel.findAll", query="SELECT t FROM WmsEstanteModel t")
public class WmsEstanteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsEstanteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="quantidade_caixa")
	private Integer quantidadeCaixa;

	@ManyToOne 
	@JoinColumn(name="id_wms_rua")
	private WmsRuaModel wmsRuaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public Integer getQuantidadeCaixa() { 
		return this.quantidadeCaixa; 
	} 

	public void setQuantidadeCaixa(Integer quantidadeCaixa) { 
		this.quantidadeCaixa = quantidadeCaixa; 
	} 

	public WmsRuaModel getWmsRuaModel() { 
	return this.wmsRuaModel; 
	} 

	public void setWmsRuaModel(WmsRuaModel wmsRuaModel) { 
	this.wmsRuaModel = wmsRuaModel; 
	} 

		
}