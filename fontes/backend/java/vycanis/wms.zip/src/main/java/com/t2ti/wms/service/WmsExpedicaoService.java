package com.t2ti.wms.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.wms.util.Filter;
import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.model.WmsExpedicaoModel;
import com.t2ti.wms.repository.WmsExpedicaoRepository;

@Service
public class WmsExpedicaoService {

	@Autowired
	private WmsExpedicaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<WmsExpedicaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<WmsExpedicaoModel> getList(Filter filter) {
		String sql = "select * from wms_expedicao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, WmsExpedicaoModel.class);
		return query.getResultList();
	}

	public WmsExpedicaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public WmsExpedicaoModel save(WmsExpedicaoModel obj) {
		WmsExpedicaoModel wmsExpedicaoModel = repository.save(obj);
		return wmsExpedicaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		WmsExpedicaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsExpedicao] - Exception: " + e.getMessage());
		}
	}

}