package com.t2ti.wms.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.wms.util.Filter;
import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.model.WmsRuaModel;
import com.t2ti.wms.repository.WmsRuaRepository;

@Service
public class WmsRuaService {

	@Autowired
	private WmsRuaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<WmsRuaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<WmsRuaModel> getList(Filter filter) {
		String sql = "select * from wms_rua where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, WmsRuaModel.class);
		return query.getResultList();
	}

	public WmsRuaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public WmsRuaModel save(WmsRuaModel obj) {
		WmsRuaModel wmsRuaModel = repository.save(obj);
		return wmsRuaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		WmsRuaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsRua] - Exception: " + e.getMessage());
		}
	}

}