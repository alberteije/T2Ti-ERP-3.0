package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="wms_ordem_separacao_cab")
@NamedQuery(name="WmsOrdemSeparacaoCabModel.findAll", query="SELECT t FROM WmsOrdemSeparacaoCabModel t")
public class WmsOrdemSeparacaoCabModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsOrdemSeparacaoCabModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="origem")
	private String origem;

	@Temporal(TemporalType.DATE)
@Column(name="data_solicitacao")
	private Date dataSolicitacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_limite")
	private Date dataLimite;

	@OneToMany(mappedBy = "wmsOrdemSeparacaoCabModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<WmsOrdemSeparacaoDetModel> wmsOrdemSeparacaoDetModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getOrigem() { 
		return this.origem; 
	} 

	public void setOrigem(String origem) { 
		this.origem = origem; 
	} 

	public Date getDataSolicitacao() { 
		return this.dataSolicitacao; 
	} 

	public void setDataSolicitacao(Date dataSolicitacao) { 
		this.dataSolicitacao = dataSolicitacao; 
	} 

	public Date getDataLimite() { 
		return this.dataLimite; 
	} 

	public void setDataLimite(Date dataLimite) { 
		this.dataLimite = dataLimite; 
	} 

	public Set<WmsOrdemSeparacaoDetModel> getWmsOrdemSeparacaoDetModelList() { 
	return this.wmsOrdemSeparacaoDetModelList; 
	} 

	public void setWmsOrdemSeparacaoDetModelList(Set<WmsOrdemSeparacaoDetModel> wmsOrdemSeparacaoDetModelList) { 
	this.wmsOrdemSeparacaoDetModelList = wmsOrdemSeparacaoDetModelList; 
		for (WmsOrdemSeparacaoDetModel wmsOrdemSeparacaoDetModel : wmsOrdemSeparacaoDetModelList) { 
			wmsOrdemSeparacaoDetModel.setWmsOrdemSeparacaoCabModel(this); 
		}
	} 

		
}