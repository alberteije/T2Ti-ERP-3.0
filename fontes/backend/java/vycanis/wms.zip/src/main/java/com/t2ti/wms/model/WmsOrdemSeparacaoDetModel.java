package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="wms_ordem_separacao_det")
@NamedQuery(name="WmsOrdemSeparacaoDetModel.findAll", query="SELECT t FROM WmsOrdemSeparacaoDetModel t")
public class WmsOrdemSeparacaoDetModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsOrdemSeparacaoDetModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private Integer quantidade;

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_wms_ordem_separacao_cab")
	private WmsOrdemSeparacaoCabModel wmsOrdemSeparacaoCabModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

	public WmsOrdemSeparacaoCabModel getWmsOrdemSeparacaoCabModel() { 
	return this.wmsOrdemSeparacaoCabModel; 
	} 

	public void setWmsOrdemSeparacaoCabModel(WmsOrdemSeparacaoCabModel wmsOrdemSeparacaoCabModel) { 
	this.wmsOrdemSeparacaoCabModel = wmsOrdemSeparacaoCabModel; 
	} 

		
}