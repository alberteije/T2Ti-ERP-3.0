package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="wms_caixa")
@NamedQuery(name="WmsCaixaModel.findAll", query="SELECT t FROM WmsCaixaModel t")
public class WmsCaixaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsCaixaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="altura")
	private Integer altura;

	@Column(name="largura")
	private Integer largura;

	@Column(name="profundidade")
	private Integer profundidade;

	@OneToMany(mappedBy = "wmsCaixaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<WmsArmazenamentoModel> wmsArmazenamentoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_wms_estante")
	private WmsEstanteModel wmsEstanteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public Integer getAltura() { 
		return this.altura; 
	} 

	public void setAltura(Integer altura) { 
		this.altura = altura; 
	} 

	public Integer getLargura() { 
		return this.largura; 
	} 

	public void setLargura(Integer largura) { 
		this.largura = largura; 
	} 

	public Integer getProfundidade() { 
		return this.profundidade; 
	} 

	public void setProfundidade(Integer profundidade) { 
		this.profundidade = profundidade; 
	} 

	public Set<WmsArmazenamentoModel> getWmsArmazenamentoModelList() { 
	return this.wmsArmazenamentoModelList; 
	} 

	public void setWmsArmazenamentoModelList(Set<WmsArmazenamentoModel> wmsArmazenamentoModelList) { 
	this.wmsArmazenamentoModelList = wmsArmazenamentoModelList; 
		for (WmsArmazenamentoModel wmsArmazenamentoModel : wmsArmazenamentoModelList) { 
			wmsArmazenamentoModel.setWmsCaixaModel(this); 
		}
	} 

	public WmsEstanteModel getWmsEstanteModel() { 
	return this.wmsEstanteModel; 
	} 

	public void setWmsEstanteModel(WmsEstanteModel wmsEstanteModel) { 
	this.wmsEstanteModel = wmsEstanteModel; 
	} 

		
}