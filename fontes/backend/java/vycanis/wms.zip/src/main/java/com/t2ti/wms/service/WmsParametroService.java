package com.t2ti.wms.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.wms.util.Filter;
import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.model.WmsParametroModel;
import com.t2ti.wms.repository.WmsParametroRepository;

@Service
public class WmsParametroService {

	@Autowired
	private WmsParametroRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<WmsParametroModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<WmsParametroModel> getList(Filter filter) {
		String sql = "select * from wms_parametro where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, WmsParametroModel.class);
		return query.getResultList();
	}

	public WmsParametroModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public WmsParametroModel save(WmsParametroModel obj) {
		WmsParametroModel wmsParametroModel = repository.save(obj);
		return wmsParametroModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		WmsParametroModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsParametro] - Exception: " + e.getMessage());
		}
	}

}