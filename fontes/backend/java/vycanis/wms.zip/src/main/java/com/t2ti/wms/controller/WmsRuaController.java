package com.t2ti.wms.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.exception.ResourseNotFoundException;
import com.t2ti.wms.exception.BadRequestException;
import com.t2ti.wms.util.Filter;
import com.t2ti.wms.model.WmsRuaModel;
import com.t2ti.wms.service.WmsRuaService;

@RestController
@RequestMapping(value = "/wms-rua", produces = "application/json;charset=UTF-8")
public class WmsRuaController {

	@Autowired
	private WmsRuaService service;
	
	@GetMapping({ "", "/" })
	public List<WmsRuaModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [WmsRua] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public WmsRuaModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found WmsRua].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found WmsRua] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public WmsRuaModel insert(@RequestBody WmsRuaModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert WmsRua] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public WmsRuaModel update(@RequestBody WmsRuaModel objJson) {	
		try {			
			WmsRuaModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update WmsRua].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update WmsRua] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsRua] - Exception: " + e.getMessage());
		}
	}
	
}