package com.t2ti.wms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.wms.model.WmsOrdemSeparacaoCabModel;

public interface WmsOrdemSeparacaoCabRepository extends JpaRepository<WmsOrdemSeparacaoCabModel, Integer> {}