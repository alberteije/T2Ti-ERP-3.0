package com.t2ti.wms.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.wms.util.Filter;
import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.model.WmsRecebimentoCabecalhoModel;
import com.t2ti.wms.repository.WmsRecebimentoCabecalhoRepository;

@Service
public class WmsRecebimentoCabecalhoService {

	@Autowired
	private WmsRecebimentoCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<WmsRecebimentoCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<WmsRecebimentoCabecalhoModel> getList(Filter filter) {
		String sql = "select * from wms_recebimento_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, WmsRecebimentoCabecalhoModel.class);
		return query.getResultList();
	}

	public WmsRecebimentoCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public WmsRecebimentoCabecalhoModel save(WmsRecebimentoCabecalhoModel obj) {
		WmsRecebimentoCabecalhoModel wmsRecebimentoCabecalhoModel = repository.save(obj);
		return wmsRecebimentoCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		WmsRecebimentoCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsRecebimentoCabecalho] - Exception: " + e.getMessage());
		}
	}

}