package com.t2ti.wms.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.exception.ResourseNotFoundException;
import com.t2ti.wms.exception.BadRequestException;
import com.t2ti.wms.util.Filter;
import com.t2ti.wms.model.WmsRecebimentoCabecalhoModel;
import com.t2ti.wms.service.WmsRecebimentoCabecalhoService;

@RestController
@RequestMapping(value = "/wms-recebimento-cabecalho", produces = "application/json;charset=UTF-8")
public class WmsRecebimentoCabecalhoController {

	@Autowired
	private WmsRecebimentoCabecalhoService service;
	
	@GetMapping({ "", "/" })
	public List<WmsRecebimentoCabecalhoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [WmsRecebimentoCabecalho] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public WmsRecebimentoCabecalhoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found WmsRecebimentoCabecalho].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found WmsRecebimentoCabecalho] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public WmsRecebimentoCabecalhoModel insert(@RequestBody WmsRecebimentoCabecalhoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert WmsRecebimentoCabecalho] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public WmsRecebimentoCabecalhoModel update(@RequestBody WmsRecebimentoCabecalhoModel objJson) {	
		try {			
			WmsRecebimentoCabecalhoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update WmsRecebimentoCabecalho].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update WmsRecebimentoCabecalho] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsRecebimentoCabecalho] - Exception: " + e.getMessage());
		}
	}
	
}