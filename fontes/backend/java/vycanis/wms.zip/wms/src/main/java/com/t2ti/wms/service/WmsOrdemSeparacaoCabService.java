package com.t2ti.wms.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.wms.util.Filter;
import com.t2ti.wms.exception.GenericException;
import com.t2ti.wms.model.WmsOrdemSeparacaoCabModel;
import com.t2ti.wms.repository.WmsOrdemSeparacaoCabRepository;

@Service
public class WmsOrdemSeparacaoCabService {

	@Autowired
	private WmsOrdemSeparacaoCabRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<WmsOrdemSeparacaoCabModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<WmsOrdemSeparacaoCabModel> getList(Filter filter) {
		String sql = "select * from wms_ordem_separacao_cab where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, WmsOrdemSeparacaoCabModel.class);
		return query.getResultList();
	}

	public WmsOrdemSeparacaoCabModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public WmsOrdemSeparacaoCabModel save(WmsOrdemSeparacaoCabModel obj) {
		WmsOrdemSeparacaoCabModel wmsOrdemSeparacaoCabModel = repository.save(obj);
		return wmsOrdemSeparacaoCabModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		WmsOrdemSeparacaoCabModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete WmsOrdemSeparacaoCab] - Exception: " + e.getMessage());
		}
	}

}