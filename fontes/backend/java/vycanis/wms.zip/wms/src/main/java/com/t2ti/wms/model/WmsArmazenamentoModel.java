package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="wms_armazenamento")
@NamedQuery(name="WmsArmazenamentoModel.findAll", query="SELECT t FROM WmsArmazenamentoModel t")
public class WmsArmazenamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsArmazenamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private Integer quantidade;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_wms_caixa")
	private WmsCaixaModel wmsCaixaModel; 

	@ManyToOne 
	@JoinColumn(name="id_wms_recebimento_detalhe")
	private WmsRecebimentoDetalheModel wmsRecebimentoDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public WmsCaixaModel getWmsCaixaModel() { 
	return this.wmsCaixaModel; 
	} 

	public void setWmsCaixaModel(WmsCaixaModel wmsCaixaModel) { 
	this.wmsCaixaModel = wmsCaixaModel; 
	} 

	public WmsRecebimentoDetalheModel getWmsRecebimentoDetalheModel() { 
	return this.wmsRecebimentoDetalheModel; 
	} 

	public void setWmsRecebimentoDetalheModel(WmsRecebimentoDetalheModel wmsRecebimentoDetalheModel) { 
	this.wmsRecebimentoDetalheModel = wmsRecebimentoDetalheModel; 
	} 

		
}