package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="wms_parametro")
@NamedQuery(name="WmsParametroModel.findAll", query="SELECT t FROM WmsParametroModel t")
public class WmsParametroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsParametroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="hora_por_volume")
	private Integer horaPorVolume;

	@Column(name="pessoa_por_volume")
	private Integer pessoaPorVolume;

	@Column(name="hora_por_peso")
	private Integer horaPorPeso;

	@Column(name="pessoa_por_peso")
	private Integer pessoaPorPeso;

	@Column(name="item_diferente_caixa")
	private String itemDiferenteCaixa;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getHoraPorVolume() { 
		return this.horaPorVolume; 
	} 

	public void setHoraPorVolume(Integer horaPorVolume) { 
		this.horaPorVolume = horaPorVolume; 
	} 

	public Integer getPessoaPorVolume() { 
		return this.pessoaPorVolume; 
	} 

	public void setPessoaPorVolume(Integer pessoaPorVolume) { 
		this.pessoaPorVolume = pessoaPorVolume; 
	} 

	public Integer getHoraPorPeso() { 
		return this.horaPorPeso; 
	} 

	public void setHoraPorPeso(Integer horaPorPeso) { 
		this.horaPorPeso = horaPorPeso; 
	} 

	public Integer getPessoaPorPeso() { 
		return this.pessoaPorPeso; 
	} 

	public void setPessoaPorPeso(Integer pessoaPorPeso) { 
		this.pessoaPorPeso = pessoaPorPeso; 
	} 

	public String getItemDiferenteCaixa() { 
		return this.itemDiferenteCaixa; 
	} 

	public void setItemDiferenteCaixa(String itemDiferenteCaixa) { 
		this.itemDiferenteCaixa = itemDiferenteCaixa; 
	} 

		
}