package com.t2ti.wms.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="wms_expedicao")
@NamedQuery(name="WmsExpedicaoModel.findAll", query="SELECT t FROM WmsExpedicaoModel t")
public class WmsExpedicaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public WmsExpedicaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private Integer quantidade;

	@Temporal(TemporalType.DATE)
@Column(name="data_saida")
	private Date dataSaida;

	@ManyToOne 
	@JoinColumn(name="id_wms_ordem_separacao_det")
	private WmsOrdemSeparacaoDetModel wmsOrdemSeparacaoDetModel; 

	@ManyToOne 
	@JoinColumn(name="id_wms_armazenamento")
	private WmsArmazenamentoModel wmsArmazenamentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public Date getDataSaida() { 
		return this.dataSaida; 
	} 

	public void setDataSaida(Date dataSaida) { 
		this.dataSaida = dataSaida; 
	} 

	public WmsOrdemSeparacaoDetModel getWmsOrdemSeparacaoDetModel() { 
	return this.wmsOrdemSeparacaoDetModel; 
	} 

	public void setWmsOrdemSeparacaoDetModel(WmsOrdemSeparacaoDetModel wmsOrdemSeparacaoDetModel) { 
	this.wmsOrdemSeparacaoDetModel = wmsOrdemSeparacaoDetModel; 
	} 

	public WmsArmazenamentoModel getWmsArmazenamentoModel() { 
	return this.wmsArmazenamentoModel; 
	} 

	public void setWmsArmazenamentoModel(WmsArmazenamentoModel wmsArmazenamentoModel) { 
	this.wmsArmazenamentoModel = wmsArmazenamentoModel; 
	} 

		
}