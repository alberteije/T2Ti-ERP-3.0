package com.t2ti.wms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.wms.model.WmsAgendamentoModel;

public interface WmsAgendamentoRepository extends JpaRepository<WmsAgendamentoModel, Integer> {}