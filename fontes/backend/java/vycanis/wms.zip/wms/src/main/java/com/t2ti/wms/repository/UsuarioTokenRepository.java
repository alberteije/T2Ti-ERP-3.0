package com.t2ti.wms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.wms.model.UsuarioTokenModel;

public interface UsuarioTokenRepository extends JpaRepository<UsuarioTokenModel, Integer> {}