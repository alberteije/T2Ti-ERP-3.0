package com.t2ti.tributacao.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="tribut_iss")
@NamedQuery(name="TributIssModel.findAll", query="SELECT t FROM TributIssModel t")
public class TributIssModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TributIssModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="modalidade_base_calculo")
	private String modalidadeBaseCalculo;

	@Column(name="codigo_tributacao")
	private String codigoTributacao;

	@Column(name="item_lista_servico")
	private Integer itemListaServico;

	@Column(name="porcento_base_calculo")
	private BigDecimal porcentoBaseCalculo;

	@Column(name="aliquota_porcento")
	private BigDecimal aliquotaPorcento;

	@Column(name="aliquota_unidade")
	private BigDecimal aliquotaUnidade;

	@Column(name="valor_preco_maximo")
	private BigDecimal valorPrecoMaximo;

	@Column(name="valor_pauta_fiscal")
	private BigDecimal valorPautaFiscal;

	@ManyToOne 
	@JoinColumn(name="id_tribut_operacao_fiscal")
	private TributOperacaoFiscalModel tributOperacaoFiscalModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getModalidadeBaseCalculo() { 
		return this.modalidadeBaseCalculo; 
	} 

	public void setModalidadeBaseCalculo(String modalidadeBaseCalculo) { 
		this.modalidadeBaseCalculo = modalidadeBaseCalculo; 
	} 

	public String getCodigoTributacao() { 
		return this.codigoTributacao; 
	} 

	public void setCodigoTributacao(String codigoTributacao) { 
		this.codigoTributacao = codigoTributacao; 
	} 

	public Integer getItemListaServico() { 
		return this.itemListaServico; 
	} 

	public void setItemListaServico(Integer itemListaServico) { 
		this.itemListaServico = itemListaServico; 
	} 

	public BigDecimal getPorcentoBaseCalculo() { 
		return this.porcentoBaseCalculo; 
	} 

	public void setPorcentoBaseCalculo(BigDecimal porcentoBaseCalculo) { 
		this.porcentoBaseCalculo = porcentoBaseCalculo; 
	} 

	public BigDecimal getAliquotaPorcento() { 
		return this.aliquotaPorcento; 
	} 

	public void setAliquotaPorcento(BigDecimal aliquotaPorcento) { 
		this.aliquotaPorcento = aliquotaPorcento; 
	} 

	public BigDecimal getAliquotaUnidade() { 
		return this.aliquotaUnidade; 
	} 

	public void setAliquotaUnidade(BigDecimal aliquotaUnidade) { 
		this.aliquotaUnidade = aliquotaUnidade; 
	} 

	public BigDecimal getValorPrecoMaximo() { 
		return this.valorPrecoMaximo; 
	} 

	public void setValorPrecoMaximo(BigDecimal valorPrecoMaximo) { 
		this.valorPrecoMaximo = valorPrecoMaximo; 
	} 

	public BigDecimal getValorPautaFiscal() { 
		return this.valorPautaFiscal; 
	} 

	public void setValorPautaFiscal(BigDecimal valorPautaFiscal) { 
		this.valorPautaFiscal = valorPautaFiscal; 
	} 

	public TributOperacaoFiscalModel getTributOperacaoFiscalModel() { 
	return this.tributOperacaoFiscalModel; 
	} 

	public void setTributOperacaoFiscalModel(TributOperacaoFiscalModel tributOperacaoFiscalModel) { 
	this.tributOperacaoFiscalModel = tributOperacaoFiscalModel; 
	} 

		
}