package com.t2ti.tributacao.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.tributacao.util.Filter;
import com.t2ti.tributacao.exception.GenericException;
import com.t2ti.tributacao.model.TributIssModel;
import com.t2ti.tributacao.repository.TributIssRepository;

@Service
public class TributIssService {

	@Autowired
	private TributIssRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TributIssModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TributIssModel> getList(Filter filter) {
		String sql = "select * from tribut_iss where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TributIssModel.class);
		return query.getResultList();
	}

	public TributIssModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TributIssModel save(TributIssModel obj) {
		TributIssModel tributIssModel = repository.save(obj);
		return tributIssModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TributIssModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TributIss] - Exception: " + e.getMessage());
		}
	}

}