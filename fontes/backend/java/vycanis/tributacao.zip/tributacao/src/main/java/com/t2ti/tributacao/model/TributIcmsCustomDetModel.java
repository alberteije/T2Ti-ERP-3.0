package com.t2ti.tributacao.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="tribut_icms_custom_det")
@NamedQuery(name="TributIcmsCustomDetModel.findAll", query="SELECT t FROM TributIcmsCustomDetModel t")
public class TributIcmsCustomDetModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TributIcmsCustomDetModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="uf_destino")
	private String ufDestino;

	@Column(name="cst")
	private String cst;

	@Column(name="csosn")
	private String csosn;

	@Column(name="modalidade_bc")
	private String modalidadeBc;

	@Column(name="cfop")
	private Integer cfop;

	@Column(name="aliquota")
	private BigDecimal aliquota;

	@Column(name="valor_pauta")
	private BigDecimal valorPauta;

	@Column(name="valor_preco_maximo")
	private BigDecimal valorPrecoMaximo;

	@Column(name="mva")
	private BigDecimal mva;

	@Column(name="porcento_bc")
	private BigDecimal porcentoBc;

	@Column(name="modalidade_bc_st")
	private String modalidadeBcSt;

	@Column(name="aliquota_interna_st")
	private BigDecimal aliquotaInternaSt;

	@Column(name="aliquota_interestadual_st")
	private BigDecimal aliquotaInterestadualSt;

	@Column(name="porcento_bc_st")
	private BigDecimal porcentoBcSt;

	@Column(name="aliquota_icms_st")
	private BigDecimal aliquotaIcmsSt;

	@Column(name="valor_pauta_st")
	private BigDecimal valorPautaSt;

	@Column(name="valor_preco_maximo_st")
	private BigDecimal valorPrecoMaximoSt;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_tribut_icms_custom_cab")
	private TributIcmsCustomCabModel tributIcmsCustomCabModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getUfDestino() { 
		return this.ufDestino; 
	} 

	public void setUfDestino(String ufDestino) { 
		this.ufDestino = ufDestino; 
	} 

	public String getCst() { 
		return this.cst; 
	} 

	public void setCst(String cst) { 
		this.cst = cst; 
	} 

	public String getCsosn() { 
		return this.csosn; 
	} 

	public void setCsosn(String csosn) { 
		this.csosn = csosn; 
	} 

	public String getModalidadeBc() { 
		return this.modalidadeBc; 
	} 

	public void setModalidadeBc(String modalidadeBc) { 
		this.modalidadeBc = modalidadeBc; 
	} 

	public Integer getCfop() { 
		return this.cfop; 
	} 

	public void setCfop(Integer cfop) { 
		this.cfop = cfop; 
	} 

	public BigDecimal getAliquota() { 
		return this.aliquota; 
	} 

	public void setAliquota(BigDecimal aliquota) { 
		this.aliquota = aliquota; 
	} 

	public BigDecimal getValorPauta() { 
		return this.valorPauta; 
	} 

	public void setValorPauta(BigDecimal valorPauta) { 
		this.valorPauta = valorPauta; 
	} 

	public BigDecimal getValorPrecoMaximo() { 
		return this.valorPrecoMaximo; 
	} 

	public void setValorPrecoMaximo(BigDecimal valorPrecoMaximo) { 
		this.valorPrecoMaximo = valorPrecoMaximo; 
	} 

	public BigDecimal getMva() { 
		return this.mva; 
	} 

	public void setMva(BigDecimal mva) { 
		this.mva = mva; 
	} 

	public BigDecimal getPorcentoBc() { 
		return this.porcentoBc; 
	} 

	public void setPorcentoBc(BigDecimal porcentoBc) { 
		this.porcentoBc = porcentoBc; 
	} 

	public String getModalidadeBcSt() { 
		return this.modalidadeBcSt; 
	} 

	public void setModalidadeBcSt(String modalidadeBcSt) { 
		this.modalidadeBcSt = modalidadeBcSt; 
	} 

	public BigDecimal getAliquotaInternaSt() { 
		return this.aliquotaInternaSt; 
	} 

	public void setAliquotaInternaSt(BigDecimal aliquotaInternaSt) { 
		this.aliquotaInternaSt = aliquotaInternaSt; 
	} 

	public BigDecimal getAliquotaInterestadualSt() { 
		return this.aliquotaInterestadualSt; 
	} 

	public void setAliquotaInterestadualSt(BigDecimal aliquotaInterestadualSt) { 
		this.aliquotaInterestadualSt = aliquotaInterestadualSt; 
	} 

	public BigDecimal getPorcentoBcSt() { 
		return this.porcentoBcSt; 
	} 

	public void setPorcentoBcSt(BigDecimal porcentoBcSt) { 
		this.porcentoBcSt = porcentoBcSt; 
	} 

	public BigDecimal getAliquotaIcmsSt() { 
		return this.aliquotaIcmsSt; 
	} 

	public void setAliquotaIcmsSt(BigDecimal aliquotaIcmsSt) { 
		this.aliquotaIcmsSt = aliquotaIcmsSt; 
	} 

	public BigDecimal getValorPautaSt() { 
		return this.valorPautaSt; 
	} 

	public void setValorPautaSt(BigDecimal valorPautaSt) { 
		this.valorPautaSt = valorPautaSt; 
	} 

	public BigDecimal getValorPrecoMaximoSt() { 
		return this.valorPrecoMaximoSt; 
	} 

	public void setValorPrecoMaximoSt(BigDecimal valorPrecoMaximoSt) { 
		this.valorPrecoMaximoSt = valorPrecoMaximoSt; 
	} 

	public TributIcmsCustomCabModel getTributIcmsCustomCabModel() { 
	return this.tributIcmsCustomCabModel; 
	} 

	public void setTributIcmsCustomCabModel(TributIcmsCustomCabModel tributIcmsCustomCabModel) { 
	this.tributIcmsCustomCabModel = tributIcmsCustomCabModel; 
	} 

		
}