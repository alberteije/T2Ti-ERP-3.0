package com.t2ti.tributacao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.tributacao.model.TributGrupoTributarioModel;

public interface TributGrupoTributarioRepository extends JpaRepository<TributGrupoTributarioModel, Integer> {}