package com.t2ti.tributacao.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.tributacao.util.Filter;
import com.t2ti.tributacao.exception.GenericException;
import com.t2ti.tributacao.model.TributConfiguraOfGtModel;
import com.t2ti.tributacao.repository.TributConfiguraOfGtRepository;

@Service
public class TributConfiguraOfGtService {

	@Autowired
	private TributConfiguraOfGtRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TributConfiguraOfGtModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TributConfiguraOfGtModel> getList(Filter filter) {
		String sql = "select * from tribut_configura_of_gt where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TributConfiguraOfGtModel.class);
		return query.getResultList();
	}

	public TributConfiguraOfGtModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TributConfiguraOfGtModel save(TributConfiguraOfGtModel obj) {
		TributConfiguraOfGtModel tributConfiguraOfGtModel = repository.save(obj);
		return tributConfiguraOfGtModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TributConfiguraOfGtModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TributConfiguraOfGt] - Exception: " + e.getMessage());
		}
	}

}