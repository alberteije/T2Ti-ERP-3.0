package com.t2ti.tributacao.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.tributacao.util.Filter;
import com.t2ti.tributacao.exception.GenericException;
import com.t2ti.tributacao.model.TributIcmsCustomCabModel;
import com.t2ti.tributacao.repository.TributIcmsCustomCabRepository;

@Service
public class TributIcmsCustomCabService {

	@Autowired
	private TributIcmsCustomCabRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TributIcmsCustomCabModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TributIcmsCustomCabModel> getList(Filter filter) {
		String sql = "select * from tribut_icms_custom_cab where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TributIcmsCustomCabModel.class);
		return query.getResultList();
	}

	public TributIcmsCustomCabModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TributIcmsCustomCabModel save(TributIcmsCustomCabModel obj) {
		TributIcmsCustomCabModel tributIcmsCustomCabModel = repository.save(obj);
		return tributIcmsCustomCabModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TributIcmsCustomCabModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TributIcmsCustomCab] - Exception: " + e.getMessage());
		}
	}

}