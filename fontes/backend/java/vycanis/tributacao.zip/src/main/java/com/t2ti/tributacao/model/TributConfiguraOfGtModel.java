package com.t2ti.tributacao.model;

import java.io.Serializable;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="tribut_configura_of_gt")
@NamedQuery(name="TributConfiguraOfGtModel.findAll", query="SELECT t FROM TributConfiguraOfGtModel t")
public class TributConfiguraOfGtModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TributConfiguraOfGtModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@OneToOne(mappedBy = "tributConfiguraOfGtModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private TributIpiModel tributIpiModel; 

	@OneToOne(mappedBy = "tributConfiguraOfGtModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private TributCofinsModel tributCofinsModel; 

	@OneToOne(mappedBy = "tributConfiguraOfGtModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private TributPisModel tributPisModel; 

	@ManyToOne 
	@JoinColumn(name="id_tribut_grupo_tributario")
	private TributGrupoTributarioModel tributGrupoTributarioModel; 

	@ManyToOne 
	@JoinColumn(name="id_tribut_operacao_fiscal")
	private TributOperacaoFiscalModel tributOperacaoFiscalModel; 

	@OneToMany(mappedBy = "tributConfiguraOfGtModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<TributIcmsUfModel> tributIcmsUfModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public TributIpiModel getTributIpiModel() { 
	return this.tributIpiModel; 
	} 

	public void setTributIpiModel(TributIpiModel tributIpiModel) { 
	this.tributIpiModel = tributIpiModel; 
		if (tributIpiModel != null) { 
			tributIpiModel.setTributConfiguraOfGtModel(this); 
		}
	} 

	public TributCofinsModel getTributCofinsModel() { 
	return this.tributCofinsModel; 
	} 

	public void setTributCofinsModel(TributCofinsModel tributCofinsModel) { 
	this.tributCofinsModel = tributCofinsModel; 
		if (tributCofinsModel != null) { 
			tributCofinsModel.setTributConfiguraOfGtModel(this); 
		}
	} 

	public TributPisModel getTributPisModel() { 
	return this.tributPisModel; 
	} 

	public void setTributPisModel(TributPisModel tributPisModel) { 
	this.tributPisModel = tributPisModel; 
		if (tributPisModel != null) { 
			tributPisModel.setTributConfiguraOfGtModel(this); 
		}
	} 

	public TributGrupoTributarioModel getTributGrupoTributarioModel() { 
	return this.tributGrupoTributarioModel; 
	} 

	public void setTributGrupoTributarioModel(TributGrupoTributarioModel tributGrupoTributarioModel) { 
	this.tributGrupoTributarioModel = tributGrupoTributarioModel; 
	} 

	public TributOperacaoFiscalModel getTributOperacaoFiscalModel() { 
	return this.tributOperacaoFiscalModel; 
	} 

	public void setTributOperacaoFiscalModel(TributOperacaoFiscalModel tributOperacaoFiscalModel) { 
	this.tributOperacaoFiscalModel = tributOperacaoFiscalModel; 
	} 

	public Set<TributIcmsUfModel> getTributIcmsUfModelList() { 
	return this.tributIcmsUfModelList; 
	} 

	public void setTributIcmsUfModelList(Set<TributIcmsUfModel> tributIcmsUfModelList) { 
	this.tributIcmsUfModelList = tributIcmsUfModelList; 
		for (TributIcmsUfModel tributIcmsUfModel : tributIcmsUfModelList) { 
			tributIcmsUfModel.setTributConfiguraOfGtModel(this); 
		}
	} 

		
}