package com.t2ti.tributacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TributacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TributacaoApplication.class, args);
	}

}
