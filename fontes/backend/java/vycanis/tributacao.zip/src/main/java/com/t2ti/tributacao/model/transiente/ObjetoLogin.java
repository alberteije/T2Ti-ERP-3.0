package com.t2ti.tributacao.model.transiente;

import java.io.Serializable;

public class ObjetoLogin implements Serializable {
	private static final long serialVersionUID = 1L;

	private String token;
	private String user;

	public ObjetoLogin() {}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


}