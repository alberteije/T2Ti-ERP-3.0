package com.t2ti.tributacao.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="tribut_cofins")
@NamedQuery(name="TributCofinsModel.findAll", query="SELECT t FROM TributCofinsModel t")
public class TributCofinsModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TributCofinsModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cst_cofins")
	private String cstCofins;

	@Column(name="modalidade_base_calculo")
	private String modalidadeBaseCalculo;

	@Column(name="efd_tabela_435")
	private String efdTabela435;

	@Column(name="porcento_base_calculo")
	private BigDecimal porcentoBaseCalculo;

	@Column(name="aliquota_porcento")
	private BigDecimal aliquotaPorcento;

	@Column(name="aliquota_unidade")
	private BigDecimal aliquotaUnidade;

	@Column(name="valor_preco_maximo")
	private BigDecimal valorPrecoMaximo;

	@Column(name="valor_pauta_fiscal")
	private BigDecimal valorPautaFiscal;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_tribut_configura_of_gt")
	private TributConfiguraOfGtModel tributConfiguraOfGtModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCstCofins() { 
		return this.cstCofins; 
	} 

	public void setCstCofins(String cstCofins) { 
		this.cstCofins = cstCofins; 
	} 

	public String getModalidadeBaseCalculo() { 
		return this.modalidadeBaseCalculo; 
	} 

	public void setModalidadeBaseCalculo(String modalidadeBaseCalculo) { 
		this.modalidadeBaseCalculo = modalidadeBaseCalculo; 
	} 

	public String getEfdTabela435() { 
		return this.efdTabela435; 
	} 

	public void setEfdTabela435(String efdTabela435) { 
		this.efdTabela435 = efdTabela435; 
	} 

	public BigDecimal getPorcentoBaseCalculo() { 
		return this.porcentoBaseCalculo; 
	} 

	public void setPorcentoBaseCalculo(BigDecimal porcentoBaseCalculo) { 
		this.porcentoBaseCalculo = porcentoBaseCalculo; 
	} 

	public BigDecimal getAliquotaPorcento() { 
		return this.aliquotaPorcento; 
	} 

	public void setAliquotaPorcento(BigDecimal aliquotaPorcento) { 
		this.aliquotaPorcento = aliquotaPorcento; 
	} 

	public BigDecimal getAliquotaUnidade() { 
		return this.aliquotaUnidade; 
	} 

	public void setAliquotaUnidade(BigDecimal aliquotaUnidade) { 
		this.aliquotaUnidade = aliquotaUnidade; 
	} 

	public BigDecimal getValorPrecoMaximo() { 
		return this.valorPrecoMaximo; 
	} 

	public void setValorPrecoMaximo(BigDecimal valorPrecoMaximo) { 
		this.valorPrecoMaximo = valorPrecoMaximo; 
	} 

	public BigDecimal getValorPautaFiscal() { 
		return this.valorPautaFiscal; 
	} 

	public void setValorPautaFiscal(BigDecimal valorPautaFiscal) { 
		this.valorPautaFiscal = valorPautaFiscal; 
	} 

	public TributConfiguraOfGtModel getTributConfiguraOfGtModel() { 
	return this.tributConfiguraOfGtModel; 
	} 

	public void setTributConfiguraOfGtModel(TributConfiguraOfGtModel tributConfiguraOfGtModel) { 
	this.tributConfiguraOfGtModel = tributConfiguraOfGtModel; 
	} 

		
}