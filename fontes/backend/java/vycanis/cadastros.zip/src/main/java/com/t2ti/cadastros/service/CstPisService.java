package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.CstPisModel;
import com.t2ti.cadastros.repository.CstPisRepository;

@Service
public class CstPisService {

	@Autowired
	private CstPisRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CstPisModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CstPisModel> getList(Filter filter) {
		String sql = "select * from cst_pis where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CstPisModel.class);
		return query.getResultList();
	}

	public CstPisModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CstPisModel save(CstPisModel obj) {
		CstPisModel cstPisModel = repository.save(obj);
		return cstPisModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CstPisModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CstPis] - Exception: " + e.getMessage());
		}
	}

}