package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.SindicatoModel;
import com.t2ti.cadastros.repository.SindicatoRepository;

@Service
public class SindicatoService {

	@Autowired
	private SindicatoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SindicatoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SindicatoModel> getList(Filter filter) {
		String sql = "select * from sindicato where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SindicatoModel.class);
		return query.getResultList();
	}

	public SindicatoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SindicatoModel save(SindicatoModel obj) {
		SindicatoModel sindicatoModel = repository.save(obj);
		return sindicatoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SindicatoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Sindicato] - Exception: " + e.getMessage());
		}
	}

}