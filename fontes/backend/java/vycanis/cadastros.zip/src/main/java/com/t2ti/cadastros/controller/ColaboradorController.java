package com.t2ti.cadastros.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.exception.ResourseNotFoundException;
import com.t2ti.cadastros.exception.BadRequestException;
import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.model.ColaboradorModel;
import com.t2ti.cadastros.service.ColaboradorService;

@RestController
@RequestMapping(value = "/colaborador", produces = "application/json;charset=UTF-8")
public class ColaboradorController {

	@Autowired
	private ColaboradorService service;
	
	@GetMapping({ "", "/" })
	public List<ColaboradorModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Colaborador] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public ColaboradorModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found Colaborador].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found Colaborador] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public ColaboradorModel insert(@RequestBody ColaboradorModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert Colaborador] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public ColaboradorModel update(@RequestBody ColaboradorModel objJson) {	
		try {			
			ColaboradorModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update Colaborador].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update Colaborador] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Colaborador] - Exception: " + e.getMessage());
		}
	}
	
}