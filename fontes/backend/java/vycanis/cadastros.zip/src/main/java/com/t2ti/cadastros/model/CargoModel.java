package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="cargo")
@NamedQuery(name="CargoModel.findAll", query="SELECT t FROM CargoModel t")
public class CargoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CargoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="salario")
	private BigDecimal salario;

	@Column(name="cbo_1994")
	private String cbo1994;

	@Column(name="cbo_2002")
	private String cbo2002;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public BigDecimal getSalario() { 
		return this.salario; 
	} 

	public void setSalario(BigDecimal salario) { 
		this.salario = salario; 
	} 

	public String getCbo1994() { 
		return this.cbo1994; 
	} 

	public void setCbo1994(String cbo1994) { 
		this.cbo1994 = cbo1994; 
	} 

	public String getCbo2002() { 
		return this.cbo2002; 
	} 

	public void setCbo2002(String cbo2002) { 
		this.cbo2002 = cbo2002; 
	} 

		
}