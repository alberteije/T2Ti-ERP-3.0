package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.OneToOne;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="cliente")
@NamedQuery(name="ClienteModel.findAll", query="SELECT t FROM ClienteModel t")
public class ClienteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ClienteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="desde")
	private Date desde;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="limite_credito")
	private BigDecimal limiteCredito;

	@Column(name="observacao")
	private String observacao;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pessoa")
	private PessoaModel pessoaModel; 

	@ManyToOne 
	@JoinColumn(name="id_tabela_preco")
	private TabelaPrecoModel tabelaPrecoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDesde() { 
		return this.desde; 
	} 

	public void setDesde(Date desde) { 
		this.desde = desde; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getLimiteCredito() { 
		return this.limiteCredito; 
	} 

	public void setLimiteCredito(BigDecimal limiteCredito) { 
		this.limiteCredito = limiteCredito; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public PessoaModel getPessoaModel() { 
	return this.pessoaModel; 
	} 

	public void setPessoaModel(PessoaModel pessoaModel) { 
	this.pessoaModel = pessoaModel; 
	} 

	public TabelaPrecoModel getTabelaPrecoModel() { 
	return this.tabelaPrecoModel; 
	} 

	public void setTabelaPrecoModel(TabelaPrecoModel tabelaPrecoModel) { 
	this.tabelaPrecoModel = tabelaPrecoModel; 
	} 

		
}