package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.ColaboradorModel;
import com.t2ti.cadastros.repository.ColaboradorRepository;

@Service
public class ColaboradorService {

	@Autowired
	private ColaboradorRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ColaboradorModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ColaboradorModel> getList(Filter filter) {
		String sql = "select * from colaborador where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ColaboradorModel.class);
		return query.getResultList();
	}

	public ColaboradorModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ColaboradorModel save(ColaboradorModel obj) {
		ColaboradorModel colaboradorModel = repository.save(obj);
		return colaboradorModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ColaboradorModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Colaborador] - Exception: " + e.getMessage());
		}
	}

}