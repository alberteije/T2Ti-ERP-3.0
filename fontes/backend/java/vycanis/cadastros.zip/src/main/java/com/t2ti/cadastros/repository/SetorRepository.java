package com.t2ti.cadastros.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.cadastros.model.SetorModel;

public interface SetorRepository extends JpaRepository<SetorModel, Integer> {}