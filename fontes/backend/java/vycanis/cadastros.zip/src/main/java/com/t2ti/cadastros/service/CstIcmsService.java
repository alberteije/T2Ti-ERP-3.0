package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.CstIcmsModel;
import com.t2ti.cadastros.repository.CstIcmsRepository;

@Service
public class CstIcmsService {

	@Autowired
	private CstIcmsRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CstIcmsModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CstIcmsModel> getList(Filter filter) {
		String sql = "select * from cst_icms where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CstIcmsModel.class);
		return query.getResultList();
	}

	public CstIcmsModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CstIcmsModel save(CstIcmsModel obj) {
		CstIcmsModel cstIcmsModel = repository.save(obj);
		return cstIcmsModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CstIcmsModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CstIcms] - Exception: " + e.getMessage());
		}
	}

}