package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.ProdutoGrupoModel;
import com.t2ti.cadastros.repository.ProdutoGrupoRepository;

@Service
public class ProdutoGrupoService {

	@Autowired
	private ProdutoGrupoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ProdutoGrupoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ProdutoGrupoModel> getList(Filter filter) {
		String sql = "select * from produto_grupo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ProdutoGrupoModel.class);
		return query.getResultList();
	}

	public ProdutoGrupoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ProdutoGrupoModel save(ProdutoGrupoModel obj) {
		ProdutoGrupoModel produtoGrupoModel = repository.save(obj);
		return produtoGrupoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ProdutoGrupoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ProdutoGrupo] - Exception: " + e.getMessage());
		}
	}

}