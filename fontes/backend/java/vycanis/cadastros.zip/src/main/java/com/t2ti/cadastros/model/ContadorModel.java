package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contador")
@NamedQuery(name="ContadorModel.findAll", query="SELECT t FROM ContadorModel t")
public class ContadorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContadorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="crc_inscricao")
	private String crcInscricao;

	@Column(name="crc_uf")
	private String crcUf;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pessoa")
	private PessoaModel pessoaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCrcInscricao() { 
		return this.crcInscricao; 
	} 

	public void setCrcInscricao(String crcInscricao) { 
		this.crcInscricao = crcInscricao; 
	} 

	public String getCrcUf() { 
		return this.crcUf; 
	} 

	public void setCrcUf(String crcUf) { 
		this.crcUf = crcUf; 
	} 

	public PessoaModel getPessoaModel() { 
	return this.pessoaModel; 
	} 

	public void setPessoaModel(PessoaModel pessoaModel) { 
	this.pessoaModel = pessoaModel; 
	} 

		
}