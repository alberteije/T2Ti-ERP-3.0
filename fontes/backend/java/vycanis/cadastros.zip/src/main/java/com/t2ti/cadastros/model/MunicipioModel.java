package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="municipio")
@NamedQuery(name="MunicipioModel.findAll", query="SELECT t FROM MunicipioModel t")
public class MunicipioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public MunicipioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="codigo_ibge")
	private Integer codigoIbge;

	@Column(name="codigo_receita_federal")
	private Integer codigoReceitaFederal;

	@Column(name="codigo_estadual")
	private Integer codigoEstadual;

	@ManyToOne 
	@JoinColumn(name="id_uf")
	private UfModel ufModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Integer getCodigoIbge() { 
		return this.codigoIbge; 
	} 

	public void setCodigoIbge(Integer codigoIbge) { 
		this.codigoIbge = codigoIbge; 
	} 

	public Integer getCodigoReceitaFederal() { 
		return this.codigoReceitaFederal; 
	} 

	public void setCodigoReceitaFederal(Integer codigoReceitaFederal) { 
		this.codigoReceitaFederal = codigoReceitaFederal; 
	} 

	public Integer getCodigoEstadual() { 
		return this.codigoEstadual; 
	} 

	public void setCodigoEstadual(Integer codigoEstadual) { 
		this.codigoEstadual = codigoEstadual; 
	} 

	public UfModel getUfModel() { 
	return this.ufModel; 
	} 

	public void setUfModel(UfModel ufModel) { 
	this.ufModel = ufModel; 
	} 

		
}