package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.ColaboradorTipoModel;
import com.t2ti.cadastros.repository.ColaboradorTipoRepository;

@Service
public class ColaboradorTipoService {

	@Autowired
	private ColaboradorTipoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ColaboradorTipoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ColaboradorTipoModel> getList(Filter filter) {
		String sql = "select * from colaborador_tipo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ColaboradorTipoModel.class);
		return query.getResultList();
	}

	public ColaboradorTipoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ColaboradorTipoModel save(ColaboradorTipoModel obj) {
		ColaboradorTipoModel colaboradorTipoModel = repository.save(obj);
		return colaboradorTipoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ColaboradorTipoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ColaboradorTipo] - Exception: " + e.getMessage());
		}
	}

}