package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="cnae")
@NamedQuery(name="CnaeModel.findAll", query="SELECT t FROM CnaeModel t")
public class CnaeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CnaeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="denominacao")
	private String denominacao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getDenominacao() { 
		return this.denominacao; 
	} 

	public void setDenominacao(String denominacao) { 
		this.denominacao = denominacao; 
	} 

		
}