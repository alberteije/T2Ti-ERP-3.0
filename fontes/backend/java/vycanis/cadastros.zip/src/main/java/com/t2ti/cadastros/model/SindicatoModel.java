package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="sindicato")
@NamedQuery(name="SindicatoModel.findAll", query="SELECT t FROM SindicatoModel t")
public class SindicatoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public SindicatoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="codigo_banco")
	private Integer codigoBanco;

	@Column(name="codigo_agencia")
	private Integer codigoAgencia;

	@Column(name="conta_banco")
	private String contaBanco;

	@Column(name="codigo_cedente")
	private String codigoCedente;

	@Column(name="logradouro")
	private String logradouro;

	@Column(name="numero")
	private String numero;

	@Column(name="bairro")
	private String bairro;

	@Column(name="municipio_ibge")
	private Integer municipioIbge;

	@Column(name="uf")
	private String uf;

	@Column(name="fone1")
	private String fone1;

	@Column(name="fone2")
	private String fone2;

	@Column(name="email")
	private String email;

	@Column(name="tipo_sindicato")
	private String tipoSindicato;

	@Temporal(TemporalType.DATE)
@Column(name="data_base")
	private Date dataBase;

	@Column(name="piso_salarial")
	private BigDecimal pisoSalarial;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="classificacao_contabil_conta")
	private String classificacaoContabilConta;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Integer getCodigoBanco() { 
		return this.codigoBanco; 
	} 

	public void setCodigoBanco(Integer codigoBanco) { 
		this.codigoBanco = codigoBanco; 
	} 

	public Integer getCodigoAgencia() { 
		return this.codigoAgencia; 
	} 

	public void setCodigoAgencia(Integer codigoAgencia) { 
		this.codigoAgencia = codigoAgencia; 
	} 

	public String getContaBanco() { 
		return this.contaBanco; 
	} 

	public void setContaBanco(String contaBanco) { 
		this.contaBanco = contaBanco; 
	} 

	public String getCodigoCedente() { 
		return this.codigoCedente; 
	} 

	public void setCodigoCedente(String codigoCedente) { 
		this.codigoCedente = codigoCedente; 
	} 

	public String getLogradouro() { 
		return this.logradouro; 
	} 

	public void setLogradouro(String logradouro) { 
		this.logradouro = logradouro; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getBairro() { 
		return this.bairro; 
	} 

	public void setBairro(String bairro) { 
		this.bairro = bairro; 
	} 

	public Integer getMunicipioIbge() { 
		return this.municipioIbge; 
	} 

	public void setMunicipioIbge(Integer municipioIbge) { 
		this.municipioIbge = municipioIbge; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getFone1() { 
		return this.fone1; 
	} 

	public void setFone1(String fone1) { 
		this.fone1 = fone1; 
	} 

	public String getFone2() { 
		return this.fone2; 
	} 

	public void setFone2(String fone2) { 
		this.fone2 = fone2; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public String getTipoSindicato() { 
		return this.tipoSindicato; 
	} 

	public void setTipoSindicato(String tipoSindicato) { 
		this.tipoSindicato = tipoSindicato; 
	} 

	public Date getDataBase() { 
		return this.dataBase; 
	} 

	public void setDataBase(Date dataBase) { 
		this.dataBase = dataBase; 
	} 

	public BigDecimal getPisoSalarial() { 
		return this.pisoSalarial; 
	} 

	public void setPisoSalarial(BigDecimal pisoSalarial) { 
		this.pisoSalarial = pisoSalarial; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getClassificacaoContabilConta() { 
		return this.classificacaoContabilConta; 
	} 

	public void setClassificacaoContabilConta(String classificacaoContabilConta) { 
		this.classificacaoContabilConta = classificacaoContabilConta; 
	} 

		
}