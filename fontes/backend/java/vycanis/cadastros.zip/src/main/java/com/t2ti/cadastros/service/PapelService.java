package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.PapelModel;
import com.t2ti.cadastros.repository.PapelRepository;

@Service
public class PapelService {

	@Autowired
	private PapelRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PapelModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PapelModel> getList(Filter filter) {
		String sql = "select * from papel where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PapelModel.class);
		return query.getResultList();
	}

	public PapelModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PapelModel save(PapelModel obj) {
		PapelModel papelModel = repository.save(obj);
		return papelModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PapelModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Papel] - Exception: " + e.getMessage());
		}
	}

}