package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.OneToOne;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="vendedor")
@NamedQuery(name="VendedorModel.findAll", query="SELECT t FROM VendedorModel t")
public class VendedorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendedorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="comissao")
	private BigDecimal comissao;

	@Column(name="meta_venda")
	private BigDecimal metaVenda;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_colaborador")
	private ColaboradorModel colaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_comissao_perfil")
	private ComissaoPerfilModel comissaoPerfilModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getComissao() { 
		return this.comissao; 
	} 

	public void setComissao(BigDecimal comissao) { 
		this.comissao = comissao; 
	} 

	public BigDecimal getMetaVenda() { 
		return this.metaVenda; 
	} 

	public void setMetaVenda(BigDecimal metaVenda) { 
		this.metaVenda = metaVenda; 
	} 

	public ColaboradorModel getColaboradorModel() { 
	return this.colaboradorModel; 
	} 

	public void setColaboradorModel(ColaboradorModel colaboradorModel) { 
	this.colaboradorModel = colaboradorModel; 
	} 

	public ComissaoPerfilModel getComissaoPerfilModel() { 
	return this.comissaoPerfilModel; 
	} 

	public void setComissaoPerfilModel(ComissaoPerfilModel comissaoPerfilModel) { 
	this.comissaoPerfilModel = comissaoPerfilModel; 
	} 

		
}