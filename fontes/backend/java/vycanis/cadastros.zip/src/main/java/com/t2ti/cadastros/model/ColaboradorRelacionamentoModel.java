package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="colaborador_relacionamento")
@NamedQuery(name="ColaboradorRelacionamentoModel.findAll", query="SELECT t FROM ColaboradorRelacionamentoModel t")
public class ColaboradorRelacionamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ColaboradorRelacionamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Temporal(TemporalType.DATE)
@Column(name="data_nascimento")
	private Date dataNascimento;

	@Column(name="cpf")
	private String cpf;

	@Column(name="registro_matricula")
	private String registroMatricula;

	@Column(name="registro_cartorio")
	private String registroCartorio;

	@Column(name="registro_cartorio_numero")
	private String registroCartorioNumero;

	@Column(name="registro_numero_livro")
	private String registroNumeroLivro;

	@Column(name="registro_numero_folha")
	private String registroNumeroFolha;

	@Temporal(TemporalType.DATE)
@Column(name="data_entrega_documento")
	private Date dataEntregaDocumento;

	@Column(name="salario_familia")
	private String salarioFamilia;

	@Column(name="salario_familia_idade_limite")
	private Integer salarioFamiliaIdadeLimite;

	@Temporal(TemporalType.DATE)
@Column(name="salario_familia_data_fim")
	private Date salarioFamiliaDataFim;

	@Column(name="imposto_renda_idade_limite")
	private Integer impostoRendaIdadeLimite;

	@Column(name="imposto_renda_data_fim")
	private Integer impostoRendaDataFim;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_colaborador")
	private ColaboradorModel colaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_tipo_relacionamento")
	private TipoRelacionamentoModel tipoRelacionamentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Date getDataNascimento() { 
		return this.dataNascimento; 
	} 

	public void setDataNascimento(Date dataNascimento) { 
		this.dataNascimento = dataNascimento; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public String getRegistroMatricula() { 
		return this.registroMatricula; 
	} 

	public void setRegistroMatricula(String registroMatricula) { 
		this.registroMatricula = registroMatricula; 
	} 

	public String getRegistroCartorio() { 
		return this.registroCartorio; 
	} 

	public void setRegistroCartorio(String registroCartorio) { 
		this.registroCartorio = registroCartorio; 
	} 

	public String getRegistroCartorioNumero() { 
		return this.registroCartorioNumero; 
	} 

	public void setRegistroCartorioNumero(String registroCartorioNumero) { 
		this.registroCartorioNumero = registroCartorioNumero; 
	} 

	public String getRegistroNumeroLivro() { 
		return this.registroNumeroLivro; 
	} 

	public void setRegistroNumeroLivro(String registroNumeroLivro) { 
		this.registroNumeroLivro = registroNumeroLivro; 
	} 

	public String getRegistroNumeroFolha() { 
		return this.registroNumeroFolha; 
	} 

	public void setRegistroNumeroFolha(String registroNumeroFolha) { 
		this.registroNumeroFolha = registroNumeroFolha; 
	} 

	public Date getDataEntregaDocumento() { 
		return this.dataEntregaDocumento; 
	} 

	public void setDataEntregaDocumento(Date dataEntregaDocumento) { 
		this.dataEntregaDocumento = dataEntregaDocumento; 
	} 

	public String getSalarioFamilia() { 
		return this.salarioFamilia; 
	} 

	public void setSalarioFamilia(String salarioFamilia) { 
		this.salarioFamilia = salarioFamilia; 
	} 

	public Integer getSalarioFamiliaIdadeLimite() { 
		return this.salarioFamiliaIdadeLimite; 
	} 

	public void setSalarioFamiliaIdadeLimite(Integer salarioFamiliaIdadeLimite) { 
		this.salarioFamiliaIdadeLimite = salarioFamiliaIdadeLimite; 
	} 

	public Date getSalarioFamiliaDataFim() { 
		return this.salarioFamiliaDataFim; 
	} 

	public void setSalarioFamiliaDataFim(Date salarioFamiliaDataFim) { 
		this.salarioFamiliaDataFim = salarioFamiliaDataFim; 
	} 

	public Integer getImpostoRendaIdadeLimite() { 
		return this.impostoRendaIdadeLimite; 
	} 

	public void setImpostoRendaIdadeLimite(Integer impostoRendaIdadeLimite) { 
		this.impostoRendaIdadeLimite = impostoRendaIdadeLimite; 
	} 

	public Integer getImpostoRendaDataFim() { 
		return this.impostoRendaDataFim; 
	} 

	public void setImpostoRendaDataFim(Integer impostoRendaDataFim) { 
		this.impostoRendaDataFim = impostoRendaDataFim; 
	} 

	public ColaboradorModel getColaboradorModel() { 
	return this.colaboradorModel; 
	} 

	public void setColaboradorModel(ColaboradorModel colaboradorModel) { 
	this.colaboradorModel = colaboradorModel; 
	} 

	public TipoRelacionamentoModel getTipoRelacionamentoModel() { 
	return this.tipoRelacionamentoModel; 
	} 

	public void setTipoRelacionamentoModel(TipoRelacionamentoModel tipoRelacionamentoModel) { 
	this.tipoRelacionamentoModel = tipoRelacionamentoModel; 
	} 

		
}