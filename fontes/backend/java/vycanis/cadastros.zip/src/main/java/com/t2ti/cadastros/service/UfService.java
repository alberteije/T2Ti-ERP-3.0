package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.UfModel;
import com.t2ti.cadastros.repository.UfRepository;

@Service
public class UfService {

	@Autowired
	private UfRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<UfModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<UfModel> getList(Filter filter) {
		String sql = "select * from uf where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, UfModel.class);
		return query.getResultList();
	}

	public UfModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public UfModel save(UfModel obj) {
		UfModel ufModel = repository.save(obj);
		return ufModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		UfModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Uf] - Exception: " + e.getMessage());
		}
	}

}