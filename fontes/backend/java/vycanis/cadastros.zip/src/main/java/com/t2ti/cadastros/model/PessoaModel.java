package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.OneToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="pessoa")
@NamedQuery(name="PessoaModel.findAll", query="SELECT t FROM PessoaModel t")
public class PessoaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PessoaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="tipo")
	private String tipo;

	@Column(name="site")
	private String site;

	@Column(name="email")
	private String email;

	@Column(name="eh_cliente")
	private String ehCliente;

	@Column(name="eh_fornecedor")
	private String ehFornecedor;

	@Column(name="eh_transportadora")
	private String ehTransportadora;

	@Column(name="eh_colaborador")
	private String ehColaborador;

	@Column(name="eh_contador")
	private String ehContador;

	@OneToOne(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private PessoaJuridicaModel pessoaJuridicaModel; 

	@OneToOne(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private FornecedorModel fornecedorModel; 

	@OneToOne(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private ClienteModel clienteModel; 

	@OneToOne(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private PessoaFisicaModel pessoaFisicaModel; 

	@OneToOne(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private TransportadoraModel transportadoraModel; 

	@OneToOne(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private ContadorModel contadorModel; 

	@OneToMany(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PessoaContatoModel> pessoaContatoModelList; 

	@OneToMany(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PessoaTelefoneModel> pessoaTelefoneModelList; 

	@OneToMany(mappedBy = "pessoaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PessoaEnderecoModel> pessoaEnderecoModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getSite() { 
		return this.site; 
	} 

	public void setSite(String site) { 
		this.site = site; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public String getEhCliente() { 
		return this.ehCliente; 
	} 

	public void setEhCliente(String ehCliente) { 
		this.ehCliente = ehCliente; 
	} 

	public String getEhFornecedor() { 
		return this.ehFornecedor; 
	} 

	public void setEhFornecedor(String ehFornecedor) { 
		this.ehFornecedor = ehFornecedor; 
	} 

	public String getEhTransportadora() { 
		return this.ehTransportadora; 
	} 

	public void setEhTransportadora(String ehTransportadora) { 
		this.ehTransportadora = ehTransportadora; 
	} 

	public String getEhColaborador() { 
		return this.ehColaborador; 
	} 

	public void setEhColaborador(String ehColaborador) { 
		this.ehColaborador = ehColaborador; 
	} 

	public String getEhContador() { 
		return this.ehContador; 
	} 

	public void setEhContador(String ehContador) { 
		this.ehContador = ehContador; 
	} 

	public PessoaJuridicaModel getPessoaJuridicaModel() { 
	return this.pessoaJuridicaModel; 
	} 

	public void setPessoaJuridicaModel(PessoaJuridicaModel pessoaJuridicaModel) { 
	this.pessoaJuridicaModel = pessoaJuridicaModel; 
		if (pessoaJuridicaModel != null) { 
			pessoaJuridicaModel.setPessoaModel(this); 
		}
	} 

	public FornecedorModel getFornecedorModel() { 
	return this.fornecedorModel; 
	} 

	public void setFornecedorModel(FornecedorModel fornecedorModel) { 
	this.fornecedorModel = fornecedorModel; 
		if (fornecedorModel != null) { 
			fornecedorModel.setPessoaModel(this); 
		}
	} 

	public ClienteModel getClienteModel() { 
	return this.clienteModel; 
	} 

	public void setClienteModel(ClienteModel clienteModel) { 
	this.clienteModel = clienteModel; 
		if (clienteModel != null) { 
			clienteModel.setPessoaModel(this); 
		}
	} 

	public PessoaFisicaModel getPessoaFisicaModel() { 
	return this.pessoaFisicaModel; 
	} 

	public void setPessoaFisicaModel(PessoaFisicaModel pessoaFisicaModel) { 
	this.pessoaFisicaModel = pessoaFisicaModel; 
		if (pessoaFisicaModel != null) { 
			pessoaFisicaModel.setPessoaModel(this); 
		}
	} 

	public TransportadoraModel getTransportadoraModel() { 
	return this.transportadoraModel; 
	} 

	public void setTransportadoraModel(TransportadoraModel transportadoraModel) { 
	this.transportadoraModel = transportadoraModel; 
		if (transportadoraModel != null) { 
			transportadoraModel.setPessoaModel(this); 
		}
	} 

	public ContadorModel getContadorModel() { 
	return this.contadorModel; 
	} 

	public void setContadorModel(ContadorModel contadorModel) { 
	this.contadorModel = contadorModel; 
		if (contadorModel != null) { 
			contadorModel.setPessoaModel(this); 
		}
	} 

	public Set<PessoaContatoModel> getPessoaContatoModelList() { 
	return this.pessoaContatoModelList; 
	} 

	public void setPessoaContatoModelList(Set<PessoaContatoModel> pessoaContatoModelList) { 
	this.pessoaContatoModelList = pessoaContatoModelList; 
		for (PessoaContatoModel pessoaContatoModel : pessoaContatoModelList) { 
			pessoaContatoModel.setPessoaModel(this); 
		}
	} 

	public Set<PessoaTelefoneModel> getPessoaTelefoneModelList() { 
	return this.pessoaTelefoneModelList; 
	} 

	public void setPessoaTelefoneModelList(Set<PessoaTelefoneModel> pessoaTelefoneModelList) { 
	this.pessoaTelefoneModelList = pessoaTelefoneModelList; 
		for (PessoaTelefoneModel pessoaTelefoneModel : pessoaTelefoneModelList) { 
			pessoaTelefoneModel.setPessoaModel(this); 
		}
	} 

	public Set<PessoaEnderecoModel> getPessoaEnderecoModelList() { 
	return this.pessoaEnderecoModelList; 
	} 

	public void setPessoaEnderecoModelList(Set<PessoaEnderecoModel> pessoaEnderecoModelList) { 
	this.pessoaEnderecoModelList = pessoaEnderecoModelList; 
		for (PessoaEnderecoModel pessoaEnderecoModel : pessoaEnderecoModelList) { 
			pessoaEnderecoModel.setPessoaModel(this); 
		}
	} 

		
}