package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="uf")
@NamedQuery(name="UfModel.findAll", query="SELECT t FROM UfModel t")
public class UfModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public UfModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="sigla")
	private String sigla;

	@Column(name="codigo_ibge")
	private Integer codigoIbge;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getSigla() { 
		return this.sigla; 
	} 

	public void setSigla(String sigla) { 
		this.sigla = sigla; 
	} 

	public Integer getCodigoIbge() { 
		return this.codigoIbge; 
	} 

	public void setCodigoIbge(Integer codigoIbge) { 
		this.codigoIbge = codigoIbge; 
	} 

		
}