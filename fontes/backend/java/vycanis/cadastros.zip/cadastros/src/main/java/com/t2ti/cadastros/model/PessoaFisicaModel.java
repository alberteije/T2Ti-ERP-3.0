package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.OneToOne;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pessoa_fisica")
@NamedQuery(name="PessoaFisicaModel.findAll", query="SELECT t FROM PessoaFisicaModel t")
public class PessoaFisicaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PessoaFisicaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cpf")
	private String cpf;

	@Column(name="rg")
	private String rg;

	@Column(name="orgao_rg")
	private String orgaoRg;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao_rg")
	private Date dataEmissaoRg;

	@Temporal(TemporalType.DATE)
@Column(name="data_nascimento")
	private Date dataNascimento;

	@Column(name="sexo")
	private String sexo;

	@Column(name="raca")
	private String raca;

	@Column(name="nacionalidade")
	private String nacionalidade;

	@Column(name="naturalidade")
	private String naturalidade;

	@Column(name="nome_pai")
	private String nomePai;

	@Column(name="nome_mae")
	private String nomeMae;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pessoa")
	private PessoaModel pessoaModel; 

	@ManyToOne 
	@JoinColumn(name="id_estado_civil")
	private EstadoCivilModel estadoCivilModel; 

	@ManyToOne 
	@JoinColumn(name="id_nivel_formacao")
	private NivelFormacaoModel nivelFormacaoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public String getRg() { 
		return this.rg; 
	} 

	public void setRg(String rg) { 
		this.rg = rg; 
	} 

	public String getOrgaoRg() { 
		return this.orgaoRg; 
	} 

	public void setOrgaoRg(String orgaoRg) { 
		this.orgaoRg = orgaoRg; 
	} 

	public Date getDataEmissaoRg() { 
		return this.dataEmissaoRg; 
	} 

	public void setDataEmissaoRg(Date dataEmissaoRg) { 
		this.dataEmissaoRg = dataEmissaoRg; 
	} 

	public Date getDataNascimento() { 
		return this.dataNascimento; 
	} 

	public void setDataNascimento(Date dataNascimento) { 
		this.dataNascimento = dataNascimento; 
	} 

	public String getSexo() { 
		return this.sexo; 
	} 

	public void setSexo(String sexo) { 
		this.sexo = sexo; 
	} 

	public String getRaca() { 
		return this.raca; 
	} 

	public void setRaca(String raca) { 
		this.raca = raca; 
	} 

	public String getNacionalidade() { 
		return this.nacionalidade; 
	} 

	public void setNacionalidade(String nacionalidade) { 
		this.nacionalidade = nacionalidade; 
	} 

	public String getNaturalidade() { 
		return this.naturalidade; 
	} 

	public void setNaturalidade(String naturalidade) { 
		this.naturalidade = naturalidade; 
	} 

	public String getNomePai() { 
		return this.nomePai; 
	} 

	public void setNomePai(String nomePai) { 
		this.nomePai = nomePai; 
	} 

	public String getNomeMae() { 
		return this.nomeMae; 
	} 

	public void setNomeMae(String nomeMae) { 
		this.nomeMae = nomeMae; 
	} 

	public PessoaModel getPessoaModel() { 
	return this.pessoaModel; 
	} 

	public void setPessoaModel(PessoaModel pessoaModel) { 
	this.pessoaModel = pessoaModel; 
	} 

	public EstadoCivilModel getEstadoCivilModel() { 
	return this.estadoCivilModel; 
	} 

	public void setEstadoCivilModel(EstadoCivilModel estadoCivilModel) { 
	this.estadoCivilModel = estadoCivilModel; 
	} 

	public NivelFormacaoModel getNivelFormacaoModel() { 
	return this.nivelFormacaoModel; 
	} 

	public void setNivelFormacaoModel(NivelFormacaoModel nivelFormacaoModel) { 
	this.nivelFormacaoModel = nivelFormacaoModel; 
	} 

		
}