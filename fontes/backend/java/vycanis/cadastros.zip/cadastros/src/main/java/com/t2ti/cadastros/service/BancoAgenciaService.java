package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.BancoAgenciaModel;
import com.t2ti.cadastros.repository.BancoAgenciaRepository;

@Service
public class BancoAgenciaService {

	@Autowired
	private BancoAgenciaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<BancoAgenciaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<BancoAgenciaModel> getList(Filter filter) {
		String sql = "select * from banco_agencia where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, BancoAgenciaModel.class);
		return query.getResultList();
	}

	public BancoAgenciaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public BancoAgenciaModel save(BancoAgenciaModel obj) {
		BancoAgenciaModel bancoAgenciaModel = repository.save(obj);
		return bancoAgenciaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		BancoAgenciaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete BancoAgencia] - Exception: " + e.getMessage());
		}
	}

}