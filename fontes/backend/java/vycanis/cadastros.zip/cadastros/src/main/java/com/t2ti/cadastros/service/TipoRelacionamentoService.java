package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.TipoRelacionamentoModel;
import com.t2ti.cadastros.repository.TipoRelacionamentoRepository;

@Service
public class TipoRelacionamentoService {

	@Autowired
	private TipoRelacionamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TipoRelacionamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TipoRelacionamentoModel> getList(Filter filter) {
		String sql = "select * from tipo_relacionamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TipoRelacionamentoModel.class);
		return query.getResultList();
	}

	public TipoRelacionamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TipoRelacionamentoModel save(TipoRelacionamentoModel obj) {
		TipoRelacionamentoModel tipoRelacionamentoModel = repository.save(obj);
		return tipoRelacionamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TipoRelacionamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TipoRelacionamento] - Exception: " + e.getMessage());
		}
	}

}