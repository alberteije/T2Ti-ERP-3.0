package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.CstCofinsModel;
import com.t2ti.cadastros.repository.CstCofinsRepository;

@Service
public class CstCofinsService {

	@Autowired
	private CstCofinsRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CstCofinsModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CstCofinsModel> getList(Filter filter) {
		String sql = "select * from cst_cofins where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CstCofinsModel.class);
		return query.getResultList();
	}

	public CstCofinsModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CstCofinsModel save(CstCofinsModel obj) {
		CstCofinsModel cstCofinsModel = repository.save(obj);
		return cstCofinsModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CstCofinsModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CstCofins] - Exception: " + e.getMessage());
		}
	}

}