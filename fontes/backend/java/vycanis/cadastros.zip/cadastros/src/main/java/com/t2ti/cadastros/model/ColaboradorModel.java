package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.OneToOne;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="colaborador")
@NamedQuery(name="ColaboradorModel.findAll", query="SELECT t FROM ColaboradorModel t")
public class ColaboradorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ColaboradorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="matricula")
	private String matricula;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
@Column(name="data_admissao")
	private Date dataAdmissao;

	@Temporal(TemporalType.DATE)
@Column(name="data_demissao")
	private Date dataDemissao;

	@Column(name="ctps_numero")
	private String ctpsNumero;

	@Column(name="ctps_serie")
	private String ctpsSerie;

	@Temporal(TemporalType.DATE)
@Column(name="ctps_data_expedicao")
	private Date ctpsDataExpedicao;

	@Column(name="ctps_uf")
	private String ctpsUf;

	@Column(name="observacao")
	private String observacao;

	@OneToOne(mappedBy = "colaboradorModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private VendedorModel vendedorModel; 

	@ManyToOne 
	@JoinColumn(name="id_pessoa")
	private PessoaModel pessoaModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador_situacao")
	private ColaboradorSituacaoModel colaboradorSituacaoModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador_tipo")
	private ColaboradorTipoModel colaboradorTipoModel; 

	@ManyToOne 
	@JoinColumn(name="id_setor")
	private SetorModel setorModel; 

	@ManyToOne 
	@JoinColumn(name="id_cargo")
	private CargoModel cargoModel; 

	@ManyToOne 
	@JoinColumn(name="id_tipo_admissao")
	private TipoAdmissaoModel tipoAdmissaoModel; 

	@OneToMany(mappedBy = "colaboradorModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ColaboradorRelacionamentoModel> colaboradorRelacionamentoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_sindicato")
	private SindicatoModel sindicatoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getMatricula() { 
		return this.matricula; 
	} 

	public void setMatricula(String matricula) { 
		this.matricula = matricula; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public Date getDataAdmissao() { 
		return this.dataAdmissao; 
	} 

	public void setDataAdmissao(Date dataAdmissao) { 
		this.dataAdmissao = dataAdmissao; 
	} 

	public Date getDataDemissao() { 
		return this.dataDemissao; 
	} 

	public void setDataDemissao(Date dataDemissao) { 
		this.dataDemissao = dataDemissao; 
	} 

	public String getCtpsNumero() { 
		return this.ctpsNumero; 
	} 

	public void setCtpsNumero(String ctpsNumero) { 
		this.ctpsNumero = ctpsNumero; 
	} 

	public String getCtpsSerie() { 
		return this.ctpsSerie; 
	} 

	public void setCtpsSerie(String ctpsSerie) { 
		this.ctpsSerie = ctpsSerie; 
	} 

	public Date getCtpsDataExpedicao() { 
		return this.ctpsDataExpedicao; 
	} 

	public void setCtpsDataExpedicao(Date ctpsDataExpedicao) { 
		this.ctpsDataExpedicao = ctpsDataExpedicao; 
	} 

	public String getCtpsUf() { 
		return this.ctpsUf; 
	} 

	public void setCtpsUf(String ctpsUf) { 
		this.ctpsUf = ctpsUf; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public VendedorModel getVendedorModel() { 
	return this.vendedorModel; 
	} 

	public void setVendedorModel(VendedorModel vendedorModel) { 
	this.vendedorModel = vendedorModel; 
		if (vendedorModel != null) { 
			vendedorModel.setColaboradorModel(this); 
		}
	} 

	public PessoaModel getPessoaModel() { 
	return this.pessoaModel; 
	} 

	public void setPessoaModel(PessoaModel pessoaModel) { 
	this.pessoaModel = pessoaModel; 
	} 

	public ColaboradorSituacaoModel getColaboradorSituacaoModel() { 
	return this.colaboradorSituacaoModel; 
	} 

	public void setColaboradorSituacaoModel(ColaboradorSituacaoModel colaboradorSituacaoModel) { 
	this.colaboradorSituacaoModel = colaboradorSituacaoModel; 
	} 

	public ColaboradorTipoModel getColaboradorTipoModel() { 
	return this.colaboradorTipoModel; 
	} 

	public void setColaboradorTipoModel(ColaboradorTipoModel colaboradorTipoModel) { 
	this.colaboradorTipoModel = colaboradorTipoModel; 
	} 

	public SetorModel getSetorModel() { 
	return this.setorModel; 
	} 

	public void setSetorModel(SetorModel setorModel) { 
	this.setorModel = setorModel; 
	} 

	public CargoModel getCargoModel() { 
	return this.cargoModel; 
	} 

	public void setCargoModel(CargoModel cargoModel) { 
	this.cargoModel = cargoModel; 
	} 

	public TipoAdmissaoModel getTipoAdmissaoModel() { 
	return this.tipoAdmissaoModel; 
	} 

	public void setTipoAdmissaoModel(TipoAdmissaoModel tipoAdmissaoModel) { 
	this.tipoAdmissaoModel = tipoAdmissaoModel; 
	} 

	public Set<ColaboradorRelacionamentoModel> getColaboradorRelacionamentoModelList() { 
	return this.colaboradorRelacionamentoModelList; 
	} 

	public void setColaboradorRelacionamentoModelList(Set<ColaboradorRelacionamentoModel> colaboradorRelacionamentoModelList) { 
	this.colaboradorRelacionamentoModelList = colaboradorRelacionamentoModelList; 
		for (ColaboradorRelacionamentoModel colaboradorRelacionamentoModel : colaboradorRelacionamentoModelList) { 
			colaboradorRelacionamentoModel.setColaboradorModel(this); 
		}
	} 

	public SindicatoModel getSindicatoModel() { 
	return this.sindicatoModel; 
	} 

	public void setSindicatoModel(SindicatoModel sindicatoModel) { 
	this.sindicatoModel = sindicatoModel; 
	} 

		
}