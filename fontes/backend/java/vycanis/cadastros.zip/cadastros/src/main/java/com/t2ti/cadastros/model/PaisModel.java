package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="pais")
@NamedQuery(name="PaisModel.findAll", query="SELECT t FROM PaisModel t")
public class PaisModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PaisModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome_ptbr")
	private String nomePtbr;

	@Column(name="nome_en")
	private String nomeEn;

	@Column(name="codigo")
	private Integer codigo;

	@Column(name="sigla2")
	private String sigla2;

	@Column(name="sigla3")
	private String sigla3;

	@Column(name="codigo_bacen")
	private Integer codigoBacen;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNomePtbr() { 
		return this.nomePtbr; 
	} 

	public void setNomePtbr(String nomePtbr) { 
		this.nomePtbr = nomePtbr; 
	} 

	public String getNomeEn() { 
		return this.nomeEn; 
	} 

	public void setNomeEn(String nomeEn) { 
		this.nomeEn = nomeEn; 
	} 

	public Integer getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(Integer codigo) { 
		this.codigo = codigo; 
	} 

	public String getSigla2() { 
		return this.sigla2; 
	} 

	public void setSigla2(String sigla2) { 
		this.sigla2 = sigla2; 
	} 

	public String getSigla3() { 
		return this.sigla3; 
	} 

	public void setSigla3(String sigla3) { 
		this.sigla3 = sigla3; 
	} 

	public Integer getCodigoBacen() { 
		return this.codigoBacen; 
	} 

	public void setCodigoBacen(Integer codigoBacen) { 
		this.codigoBacen = codigoBacen; 
	} 

		
}