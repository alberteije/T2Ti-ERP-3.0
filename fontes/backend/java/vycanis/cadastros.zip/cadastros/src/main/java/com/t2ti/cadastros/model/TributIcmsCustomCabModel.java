package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="tribut_icms_custom_cab")
@NamedQuery(name="TributIcmsCustomCabModel.findAll", query="SELECT t FROM TributIcmsCustomCabModel t")
public class TributIcmsCustomCabModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TributIcmsCustomCabModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Column(name="origem_mercadoria")
	private String origemMercadoria;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getOrigemMercadoria() { 
		return this.origemMercadoria; 
	} 

	public void setOrigemMercadoria(String origemMercadoria) { 
		this.origemMercadoria = origemMercadoria; 
	} 

		
}