package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="cfop")
@NamedQuery(name="CfopModel.findAll", query="SELECT t FROM CfopModel t")
public class CfopModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CfopModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private Integer codigo;

	@Column(name="descricao")
	private String descricao;

	@Column(name="aplicacao")
	private String aplicacao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(Integer codigo) { 
		this.codigo = codigo; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getAplicacao() { 
		return this.aplicacao; 
	} 

	public void setAplicacao(String aplicacao) { 
		this.aplicacao = aplicacao; 
	} 

		
}