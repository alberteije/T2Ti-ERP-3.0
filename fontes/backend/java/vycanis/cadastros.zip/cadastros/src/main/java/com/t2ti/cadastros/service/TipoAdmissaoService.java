package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.TipoAdmissaoModel;
import com.t2ti.cadastros.repository.TipoAdmissaoRepository;

@Service
public class TipoAdmissaoService {

	@Autowired
	private TipoAdmissaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TipoAdmissaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TipoAdmissaoModel> getList(Filter filter) {
		String sql = "select * from tipo_admissao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TipoAdmissaoModel.class);
		return query.getResultList();
	}

	public TipoAdmissaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TipoAdmissaoModel save(TipoAdmissaoModel obj) {
		TipoAdmissaoModel tipoAdmissaoModel = repository.save(obj);
		return tipoAdmissaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TipoAdmissaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TipoAdmissao] - Exception: " + e.getMessage());
		}
	}

}