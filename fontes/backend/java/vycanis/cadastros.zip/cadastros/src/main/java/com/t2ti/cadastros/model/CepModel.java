package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="cep")
@NamedQuery(name="CepModel.findAll", query="SELECT t FROM CepModel t")
public class CepModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CepModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private String numero;

	@Column(name="logradouro")
	private String logradouro;

	@Column(name="complemento")
	private String complemento;

	@Column(name="bairro")
	private String bairro;

	@Column(name="municipio")
	private String municipio;

	@Column(name="uf")
	private String uf;

	@Column(name="codigo_ibge_municipio")
	private Integer codigoIbgeMunicipio;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getLogradouro() { 
		return this.logradouro; 
	} 

	public void setLogradouro(String logradouro) { 
		this.logradouro = logradouro; 
	} 

	public String getComplemento() { 
		return this.complemento; 
	} 

	public void setComplemento(String complemento) { 
		this.complemento = complemento; 
	} 

	public String getBairro() { 
		return this.bairro; 
	} 

	public void setBairro(String bairro) { 
		this.bairro = bairro; 
	} 

	public String getMunicipio() { 
		return this.municipio; 
	} 

	public void setMunicipio(String municipio) { 
		this.municipio = municipio; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public Integer getCodigoIbgeMunicipio() { 
		return this.codigoIbgeMunicipio; 
	} 

	public void setCodigoIbgeMunicipio(Integer codigoIbgeMunicipio) { 
		this.codigoIbgeMunicipio = codigoIbgeMunicipio; 
	} 

		
}