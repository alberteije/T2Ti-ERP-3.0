package com.t2ti.cadastros.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.cadastros.model.TributGrupoTributarioModel;

public interface TributGrupoTributarioRepository extends JpaRepository<TributGrupoTributarioModel, Integer> {}