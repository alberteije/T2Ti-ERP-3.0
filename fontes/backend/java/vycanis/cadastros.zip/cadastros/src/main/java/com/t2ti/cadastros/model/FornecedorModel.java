package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="fornecedor")
@NamedQuery(name="FornecedorModel.findAll", query="SELECT t FROM FornecedorModel t")
public class FornecedorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FornecedorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="desde")
	private Date desde;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Column(name="observacao")
	private String observacao;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pessoa")
	private PessoaModel pessoaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDesde() { 
		return this.desde; 
	} 

	public void setDesde(Date desde) { 
		this.desde = desde; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public PessoaModel getPessoaModel() { 
	return this.pessoaModel; 
	} 

	public void setPessoaModel(PessoaModel pessoaModel) { 
	this.pessoaModel = pessoaModel; 
	} 

		
}