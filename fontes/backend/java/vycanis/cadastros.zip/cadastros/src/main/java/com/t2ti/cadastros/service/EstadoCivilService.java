package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.EstadoCivilModel;
import com.t2ti.cadastros.repository.EstadoCivilRepository;

@Service
public class EstadoCivilService {

	@Autowired
	private EstadoCivilRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EstadoCivilModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EstadoCivilModel> getList(Filter filter) {
		String sql = "select * from estado_civil where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EstadoCivilModel.class);
		return query.getResultList();
	}

	public EstadoCivilModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EstadoCivilModel save(EstadoCivilModel obj) {
		EstadoCivilModel estadoCivilModel = repository.save(obj);
		return estadoCivilModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EstadoCivilModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EstadoCivil] - Exception: " + e.getMessage());
		}
	}

}