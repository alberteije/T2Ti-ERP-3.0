package com.t2ti.cadastros.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.cadastros.model.UfModel;

public interface UfRepository extends JpaRepository<UfModel, Integer> {}