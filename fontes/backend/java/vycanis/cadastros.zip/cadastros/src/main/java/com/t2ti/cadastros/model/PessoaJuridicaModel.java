package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pessoa_juridica")
@NamedQuery(name="PessoaJuridicaModel.findAll", query="SELECT t FROM PessoaJuridicaModel t")
public class PessoaJuridicaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PessoaJuridicaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="nome_fantasia")
	private String nomeFantasia;

	@Column(name="inscricao_estadual")
	private String inscricaoEstadual;

	@Column(name="inscricao_municipal")
	private String inscricaoMunicipal;

	@Temporal(TemporalType.DATE)
@Column(name="data_constituicao")
	private Date dataConstituicao;

	@Column(name="tipo_regime")
	private String tipoRegime;

	@Column(name="crt")
	private String crt;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pessoa")
	private PessoaModel pessoaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getNomeFantasia() { 
		return this.nomeFantasia; 
	} 

	public void setNomeFantasia(String nomeFantasia) { 
		this.nomeFantasia = nomeFantasia; 
	} 

	public String getInscricaoEstadual() { 
		return this.inscricaoEstadual; 
	} 

	public void setInscricaoEstadual(String inscricaoEstadual) { 
		this.inscricaoEstadual = inscricaoEstadual; 
	} 

	public String getInscricaoMunicipal() { 
		return this.inscricaoMunicipal; 
	} 

	public void setInscricaoMunicipal(String inscricaoMunicipal) { 
		this.inscricaoMunicipal = inscricaoMunicipal; 
	} 

	public Date getDataConstituicao() { 
		return this.dataConstituicao; 
	} 

	public void setDataConstituicao(Date dataConstituicao) { 
		this.dataConstituicao = dataConstituicao; 
	} 

	public String getTipoRegime() { 
		return this.tipoRegime; 
	} 

	public void setTipoRegime(String tipoRegime) { 
		this.tipoRegime = tipoRegime; 
	} 

	public String getCrt() { 
		return this.crt; 
	} 

	public void setCrt(String crt) { 
		this.crt = crt; 
	} 

	public PessoaModel getPessoaModel() { 
	return this.pessoaModel; 
	} 

	public void setPessoaModel(PessoaModel pessoaModel) { 
	this.pessoaModel = pessoaModel; 
	} 

		
}