package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="tabela_preco")
@NamedQuery(name="TabelaPrecoModel.findAll", query="SELECT t FROM TabelaPrecoModel t")
public class TabelaPrecoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public TabelaPrecoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="principal")
	private String principal;

	@Column(name="coeficiente")
	private BigDecimal coeficiente;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getPrincipal() { 
		return this.principal; 
	} 

	public void setPrincipal(String principal) { 
		this.principal = principal; 
	} 

	public BigDecimal getCoeficiente() { 
		return this.coeficiente; 
	} 

	public void setCoeficiente(BigDecimal coeficiente) { 
		this.coeficiente = coeficiente; 
	} 

		
}