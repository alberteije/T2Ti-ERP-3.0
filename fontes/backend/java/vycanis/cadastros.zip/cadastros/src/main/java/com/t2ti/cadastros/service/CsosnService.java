package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.CsosnModel;
import com.t2ti.cadastros.repository.CsosnRepository;

@Service
public class CsosnService {

	@Autowired
	private CsosnRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CsosnModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CsosnModel> getList(Filter filter) {
		String sql = "select * from csosn where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CsosnModel.class);
		return query.getResultList();
	}

	public CsosnModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CsosnModel save(CsosnModel obj) {
		CsosnModel csosnModel = repository.save(obj);
		return csosnModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CsosnModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Csosn] - Exception: " + e.getMessage());
		}
	}

}