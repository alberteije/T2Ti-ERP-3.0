package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.ComissaoPerfilModel;
import com.t2ti.cadastros.repository.ComissaoPerfilRepository;

@Service
public class ComissaoPerfilService {

	@Autowired
	private ComissaoPerfilRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ComissaoPerfilModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ComissaoPerfilModel> getList(Filter filter) {
		String sql = "select * from comissao_perfil where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ComissaoPerfilModel.class);
		return query.getResultList();
	}

	public ComissaoPerfilModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ComissaoPerfilModel save(ComissaoPerfilModel obj) {
		ComissaoPerfilModel comissaoPerfilModel = repository.save(obj);
		return comissaoPerfilModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ComissaoPerfilModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ComissaoPerfil] - Exception: " + e.getMessage());
		}
	}

}