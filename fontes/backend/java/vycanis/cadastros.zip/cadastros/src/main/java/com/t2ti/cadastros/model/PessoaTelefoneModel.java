package com.t2ti.cadastros.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pessoa_telefone")
@NamedQuery(name="PessoaTelefoneModel.findAll", query="SELECT t FROM PessoaTelefoneModel t")
public class PessoaTelefoneModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PessoaTelefoneModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo")
	private String tipo;

	@Column(name="numero")
	private String numero;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pessoa")
	private PessoaModel pessoaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public PessoaModel getPessoaModel() { 
	return this.pessoaModel; 
	} 

	public void setPessoaModel(PessoaModel pessoaModel) { 
	this.pessoaModel = pessoaModel; 
	} 

		
}