package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.TabelaPrecoModel;
import com.t2ti.cadastros.repository.TabelaPrecoRepository;

@Service
public class TabelaPrecoService {

	@Autowired
	private TabelaPrecoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<TabelaPrecoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<TabelaPrecoModel> getList(Filter filter) {
		String sql = "select * from tabela_preco where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, TabelaPrecoModel.class);
		return query.getResultList();
	}

	public TabelaPrecoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public TabelaPrecoModel save(TabelaPrecoModel obj) {
		TabelaPrecoModel tabelaPrecoModel = repository.save(obj);
		return tabelaPrecoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		TabelaPrecoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete TabelaPreco] - Exception: " + e.getMessage());
		}
	}

}