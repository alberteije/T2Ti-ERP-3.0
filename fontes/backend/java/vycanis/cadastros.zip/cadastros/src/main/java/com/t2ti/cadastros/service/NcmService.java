package com.t2ti.cadastros.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.cadastros.util.Filter;
import com.t2ti.cadastros.exception.GenericException;
import com.t2ti.cadastros.model.NcmModel;
import com.t2ti.cadastros.repository.NcmRepository;

@Service
public class NcmService {

	@Autowired
	private NcmRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NcmModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NcmModel> getList(Filter filter) {
		String sql = "select * from ncm where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NcmModel.class);
		return query.getResultList();
	}

	public NcmModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NcmModel save(NcmModel obj) {
		NcmModel ncmModel = repository.save(obj);
		return ncmModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NcmModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Ncm] - Exception: " + e.getMessage());
		}
	}

}