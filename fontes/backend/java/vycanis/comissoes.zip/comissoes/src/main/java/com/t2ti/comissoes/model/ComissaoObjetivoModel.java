package com.t2ti.comissoes.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="comissao_objetivo")
@NamedQuery(name="ComissaoObjetivoModel.findAll", query="SELECT t FROM ComissaoObjetivoModel t")
public class ComissaoObjetivoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ComissaoObjetivoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="taxa_pagamento")
	private BigDecimal taxaPagamento;

	@Column(name="valor_pagamento")
	private BigDecimal valorPagamento;

	@Column(name="valor_meta")
	private BigDecimal valorMeta;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@ManyToOne 
	@JoinColumn(name="id_comissao_perfil")
	private ComissaoPerfilModel comissaoPerfilModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public BigDecimal getTaxaPagamento() { 
		return this.taxaPagamento; 
	} 

	public void setTaxaPagamento(BigDecimal taxaPagamento) { 
		this.taxaPagamento = taxaPagamento; 
	} 

	public BigDecimal getValorPagamento() { 
		return this.valorPagamento; 
	} 

	public void setValorPagamento(BigDecimal valorPagamento) { 
		this.valorPagamento = valorPagamento; 
	} 

	public BigDecimal getValorMeta() { 
		return this.valorMeta; 
	} 

	public void setValorMeta(BigDecimal valorMeta) { 
		this.valorMeta = valorMeta; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public ComissaoPerfilModel getComissaoPerfilModel() { 
	return this.comissaoPerfilModel; 
	} 

	public void setComissaoPerfilModel(ComissaoPerfilModel comissaoPerfilModel) { 
	this.comissaoPerfilModel = comissaoPerfilModel; 
	} 

		
}