package com.t2ti.comissoes.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="auditoria")
@NamedQuery(name="AuditoriaModel.findAll", query="SELECT t FROM AuditoriaModel t")
public class AuditoriaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public AuditoriaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_registro")
	private Date dataRegistro;

	@Column(name="hora_registro")
	private String horaRegistro;

	@Column(name="janela_controller")
	private String janelaController;

	@Column(name="acao")
	private String acao;

	@Column(name="conteudo")
	private String conteudo;

	@Column(name="token_jwt")
	private String tokenJwt;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataRegistro() { 
		return this.dataRegistro; 
	} 

	public void setDataRegistro(Date dataRegistro) { 
		this.dataRegistro = dataRegistro; 
	} 

	public String getHoraRegistro() { 
		return this.horaRegistro; 
	} 

	public void setHoraRegistro(String horaRegistro) { 
		this.horaRegistro = horaRegistro; 
	} 

	public String getJanelaController() { 
		return this.janelaController; 
	} 

	public void setJanelaController(String janelaController) { 
		this.janelaController = janelaController; 
	} 

	public String getAcao() { 
		return this.acao; 
	} 

	public void setAcao(String acao) { 
		this.acao = acao; 
	} 

	public String getConteudo() { 
		return this.conteudo; 
	} 

	public void setConteudo(String conteudo) { 
		this.conteudo = conteudo; 
	} 

	public String getTokenJwt() { 
		return this.tokenJwt; 
	} 

	public void setTokenJwt(String tokenJwt) { 
		this.tokenJwt = tokenJwt; 
	} 

		
}