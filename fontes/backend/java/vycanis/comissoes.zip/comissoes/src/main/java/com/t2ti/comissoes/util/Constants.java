package com.t2ti.comissoes.util;

public class Constants {

	private Constants() {
		throw new IllegalStateException("Constants");
	}
	

    public static final int QUANTIDADE_POR_PAGINA = 50;
    public static int DECIMAIS_QUANTIDADE = 3;
    public static int DECIMAIS_VALOR = 2;
    public static int MAXIMO_REGISTROS_RETORNADOS = 50;
    public static String ENDERECO_SERVIDOR = "127.0.0.1";
    public static String CHAVE = "#Sua-Chave-de-32-caracteres-aqui";
    public static String VETOR = "#Seu-Vetor-aqui#";    
}