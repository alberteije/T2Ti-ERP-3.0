package com.t2ti.comissoes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.comissoes.model.ViewPessoaUsuarioModel;

public interface ViewPessoaUsuarioRepository extends JpaRepository<ViewPessoaUsuarioModel, Integer> {}