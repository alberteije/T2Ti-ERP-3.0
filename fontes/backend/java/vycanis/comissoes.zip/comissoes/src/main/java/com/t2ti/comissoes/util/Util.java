package com.t2ti.comissoes.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Util {

	private Util() {
		throw new IllegalStateException("Util");
	}

	public static String quotedStr(String pValor) {
		return "'" + pValor + "'";
	}

	public static String repeat(String string, int quantidade) {
		StringBuffer retorno = new StringBuffer();
		for (int j = 0; j < quantidade; j++) {
			retorno.append(string);
		}
		return retorno.toString();
	}

	public static String md5String(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MessageDigest md;
		md = MessageDigest.getInstance("MD5");
		byte[] md5hash = new byte[32];
		md.update(text.getBytes("iso-8859-1"), 0, text.length());
		md5hash = md.digest();
		return convertToHex(md5hash);
	}

	private static String convertToHex(byte[] data) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < data.length; i++) {
			int halfbyte = (data[i] >>> 4) & 0x0F;
			int two_halfs = 0;
			do {
				if ((0 <= halfbyte) && (halfbyte <= 9)) {
					buf.append((char) ('0' + halfbyte));
				} else {
					buf.append((char) ('a' + (halfbyte - 10)));
				}
				halfbyte = data[i] & 0x0F;
			} while (two_halfs++ < 1);
		}
		return buf.toString();
	}
	
    public static String cifrar(String valor) throws java.lang.Exception {
	    //Get Cipher Instance
		Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");		
        //Create SecretKeySpec
        SecretKeySpec keySpec = new SecretKeySpec(Constants.CHAVE.getBytes("UTF-8"), "AES");
        //Create IvParameterSpec
        IvParameterSpec ivSpec = new IvParameterSpec(Constants.VETOR.getBytes("UTF-8"));   
        //Initialize Cipher for ENCRYPT_MODE
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
        byte[] valorParaBytes = valor.getBytes("UTF-8"); // 'valor' convertido para bytes
        byte[] resultado = cipher.doFinal(valorParaBytes); 
		String base64output = Base64.getEncoder().encodeToString(resultado);
		return base64output;
    }
	
    public static String decifrar(String valor) throws java.lang.Exception {
	    byte[] decodedBytes = Base64.getDecoder().decode(valor);
	    //Get Cipher Instance
		Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");		
        //Create SecretKeySpec
        SecretKeySpec keySpec = new SecretKeySpec(Constants.CHAVE.getBytes("UTF-8"), "AES");        
        //Create IvParameterSpec
        IvParameterSpec ivSpec = new IvParameterSpec(Constants.VETOR.getBytes("UTF-8"));         
        //Initialize Cipher for ENCRYPT_MODE
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);        
        //Perform Decryption
        byte[] decryptedText = cipher.doFinal(decodedBytes);        
        String textoDecifrado = new String(decryptedText);
        return textoDecifrado;
    }
	

}
