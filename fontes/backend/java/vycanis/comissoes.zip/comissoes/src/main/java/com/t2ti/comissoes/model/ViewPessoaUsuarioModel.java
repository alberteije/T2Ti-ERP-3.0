package com.t2ti.comissoes.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="view_pessoa_usuario")
@NamedQuery(name="ViewPessoaUsuarioModel.findAll", query="SELECT t FROM ViewPessoaUsuarioModel t")
public class ViewPessoaUsuarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ViewPessoaUsuarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_pessoa")
	private Integer idPessoa;

	@Column(name="pessoa_nome")
	private String pessoaNome;

	@Column(name="tipo")
	private String tipo;

	@Column(name="email")
	private String email;

	@Column(name="id_colaborador")
	private Integer idColaborador;

	@Column(name="id_usuario")
	private Integer idUsuario;

	@Column(name="login")
	private String login;

	@Column(name="senha")
	private String senha;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Column(name="administrador")
	private String administrador;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdPessoa() { 
		return this.idPessoa; 
	} 

	public void setIdPessoa(Integer idPessoa) { 
		this.idPessoa = idPessoa; 
	} 

	public String getPessoaNome() { 
		return this.pessoaNome; 
	} 

	public void setPessoaNome(String pessoaNome) { 
		this.pessoaNome = pessoaNome; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public Integer getIdColaborador() { 
		return this.idColaborador; 
	} 

	public void setIdColaborador(Integer idColaborador) { 
		this.idColaborador = idColaborador; 
	} 

	public Integer getIdUsuario() { 
		return this.idUsuario; 
	} 

	public void setIdUsuario(Integer idUsuario) { 
		this.idUsuario = idUsuario; 
	} 

	public String getLogin() { 
		return this.login; 
	} 

	public void setLogin(String login) { 
		this.login = login; 
	} 

	public String getSenha() { 
		return this.senha; 
	} 

	public void setSenha(String senha) { 
		this.senha = senha; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public String getAdministrador() { 
		return this.administrador; 
	} 

	public void setAdministrador(String administrador) { 
		this.administrador = administrador; 
	} 

		
}