package com.t2ti.comissoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComissoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComissoesApplication.class, args);
	}

}
