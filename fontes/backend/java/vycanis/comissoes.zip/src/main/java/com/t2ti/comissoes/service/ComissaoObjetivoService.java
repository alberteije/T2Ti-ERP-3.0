package com.t2ti.comissoes.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.comissoes.util.Filter;
import com.t2ti.comissoes.exception.GenericException;
import com.t2ti.comissoes.model.ComissaoObjetivoModel;
import com.t2ti.comissoes.repository.ComissaoObjetivoRepository;

@Service
public class ComissaoObjetivoService {

	@Autowired
	private ComissaoObjetivoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ComissaoObjetivoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ComissaoObjetivoModel> getList(Filter filter) {
		String sql = "select * from comissao_objetivo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ComissaoObjetivoModel.class);
		return query.getResultList();
	}

	public ComissaoObjetivoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ComissaoObjetivoModel save(ComissaoObjetivoModel obj) {
		ComissaoObjetivoModel comissaoObjetivoModel = repository.save(obj);
		return comissaoObjetivoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ComissaoObjetivoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ComissaoObjetivo] - Exception: " + e.getMessage());
		}
	}

}