package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ferias_periodo_aquisitivo")
@NamedQuery(name="FeriasPeriodoAquisitivoModel.findAll", query="SELECT t FROM FeriasPeriodoAquisitivoModel t")
public class FeriasPeriodoAquisitivoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FeriasPeriodoAquisitivoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Column(name="situacao")
	private String situacao;

	@Temporal(TemporalType.DATE)
@Column(name="limite_para_gozo")
	private Date limiteParaGozo;

	@Column(name="descontar_faltas")
	private String descontarFaltas;

	@Column(name="desconsiderar_afastamento")
	private String desconsiderarAfastamento;

	@Column(name="afastamento_previdencia")
	private Integer afastamentoPrevidencia;

	@Column(name="afastamento_sem_remun")
	private Integer afastamentoSemRemun;

	@Column(name="afastamento_com_remun")
	private Integer afastamentoComRemun;

	@Column(name="dias_direito")
	private Integer diasDireito;

	@Column(name="dias_gozados")
	private Integer diasGozados;

	@Column(name="dias_faltas")
	private Integer diasFaltas;

	@Column(name="dias_restantes")
	private Integer diasRestantes;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public Date getLimiteParaGozo() { 
		return this.limiteParaGozo; 
	} 

	public void setLimiteParaGozo(Date limiteParaGozo) { 
		this.limiteParaGozo = limiteParaGozo; 
	} 

	public String getDescontarFaltas() { 
		return this.descontarFaltas; 
	} 

	public void setDescontarFaltas(String descontarFaltas) { 
		this.descontarFaltas = descontarFaltas; 
	} 

	public String getDesconsiderarAfastamento() { 
		return this.desconsiderarAfastamento; 
	} 

	public void setDesconsiderarAfastamento(String desconsiderarAfastamento) { 
		this.desconsiderarAfastamento = desconsiderarAfastamento; 
	} 

	public Integer getAfastamentoPrevidencia() { 
		return this.afastamentoPrevidencia; 
	} 

	public void setAfastamentoPrevidencia(Integer afastamentoPrevidencia) { 
		this.afastamentoPrevidencia = afastamentoPrevidencia; 
	} 

	public Integer getAfastamentoSemRemun() { 
		return this.afastamentoSemRemun; 
	} 

	public void setAfastamentoSemRemun(Integer afastamentoSemRemun) { 
		this.afastamentoSemRemun = afastamentoSemRemun; 
	} 

	public Integer getAfastamentoComRemun() { 
		return this.afastamentoComRemun; 
	} 

	public void setAfastamentoComRemun(Integer afastamentoComRemun) { 
		this.afastamentoComRemun = afastamentoComRemun; 
	} 

	public Integer getDiasDireito() { 
		return this.diasDireito; 
	} 

	public void setDiasDireito(Integer diasDireito) { 
		this.diasDireito = diasDireito; 
	} 

	public Integer getDiasGozados() { 
		return this.diasGozados; 
	} 

	public void setDiasGozados(Integer diasGozados) { 
		this.diasGozados = diasGozados; 
	} 

	public Integer getDiasFaltas() { 
		return this.diasFaltas; 
	} 

	public void setDiasFaltas(Integer diasFaltas) { 
		this.diasFaltas = diasFaltas; 
	} 

	public Integer getDiasRestantes() { 
		return this.diasRestantes; 
	} 

	public void setDiasRestantes(Integer diasRestantes) { 
		this.diasRestantes = diasRestantes; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}