package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="empresa_transporte_itinerario")
@NamedQuery(name="EmpresaTransporteItinerarioModel.findAll", query="SELECT t FROM EmpresaTransporteItinerarioModel t")
public class EmpresaTransporteItinerarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EmpresaTransporteItinerarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="tarifa")
	private BigDecimal tarifa;

	@Column(name="trajeto")
	private String trajeto;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_empresa_transporte")
	private EmpresaTransporteModel empresaTransporteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public BigDecimal getTarifa() { 
		return this.tarifa; 
	} 

	public void setTarifa(BigDecimal tarifa) { 
		this.tarifa = tarifa; 
	} 

	public String getTrajeto() { 
		return this.trajeto; 
	} 

	public void setTrajeto(String trajeto) { 
		this.trajeto = trajeto; 
	} 

	public EmpresaTransporteModel getEmpresaTransporteModel() { 
	return this.empresaTransporteModel; 
	} 

	public void setEmpresaTransporteModel(EmpresaTransporteModel empresaTransporteModel) { 
	this.empresaTransporteModel = empresaTransporteModel; 
	} 

		
}