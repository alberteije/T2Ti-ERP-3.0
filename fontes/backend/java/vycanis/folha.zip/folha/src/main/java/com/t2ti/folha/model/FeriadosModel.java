package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="feriados")
@NamedQuery(name="FeriadosModel.findAll", query="SELECT t FROM FeriadosModel t")
public class FeriadosModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FeriadosModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="ano")
	private String ano;

	@Column(name="nome")
	private String nome;

	@Column(name="abrangencia")
	private String abrangencia;

	@Column(name="uf")
	private String uf;

	@Column(name="municipio_ibge")
	private Integer municipioIbge;

	@Column(name="tipo")
	private String tipo;

	@Temporal(TemporalType.DATE)
@Column(name="data_feriado")
	private Date dataFeriado;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getAno() { 
		return this.ano; 
	} 

	public void setAno(String ano) { 
		this.ano = ano; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getAbrangencia() { 
		return this.abrangencia; 
	} 

	public void setAbrangencia(String abrangencia) { 
		this.abrangencia = abrangencia; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public Integer getMunicipioIbge() { 
		return this.municipioIbge; 
	} 

	public void setMunicipioIbge(Integer municipioIbge) { 
		this.municipioIbge = municipioIbge; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public Date getDataFeriado() { 
		return this.dataFeriado; 
	} 

	public void setDataFeriado(Date dataFeriado) { 
		this.dataFeriado = dataFeriado; 
	} 

		
}