package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaParametroModel;
import com.t2ti.folha.repository.FolhaParametroRepository;

@Service
public class FolhaParametroService {

	@Autowired
	private FolhaParametroRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaParametroModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaParametroModel> getList(Filter filter) {
		String sql = "select * from folha_parametro where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaParametroModel.class);
		return query.getResultList();
	}

	public FolhaParametroModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaParametroModel save(FolhaParametroModel obj) {
		FolhaParametroModel folhaParametroModel = repository.save(obj);
		return folhaParametroModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaParametroModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaParametro] - Exception: " + e.getMessage());
		}
	}

}