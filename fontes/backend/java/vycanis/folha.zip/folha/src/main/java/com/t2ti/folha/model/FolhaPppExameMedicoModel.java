package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_ppp_exame_medico")
@NamedQuery(name="FolhaPppExameMedicoModel.findAll", query="SELECT t FROM FolhaPppExameMedicoModel t")
public class FolhaPppExameMedicoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaPppExameMedicoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_ultimo")
	private Date dataUltimo;

	@Column(name="tipo")
	private String tipo;

	@Column(name="exame")
	private String exame;

	@Column(name="natureza")
	private String natureza;

	@Column(name="indicacao_resultados")
	private String indicacaoResultados;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_folha_ppp")
	private FolhaPppModel folhaPppModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataUltimo() { 
		return this.dataUltimo; 
	} 

	public void setDataUltimo(Date dataUltimo) { 
		this.dataUltimo = dataUltimo; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getExame() { 
		return this.exame; 
	} 

	public void setExame(String exame) { 
		this.exame = exame; 
	} 

	public String getNatureza() { 
		return this.natureza; 
	} 

	public void setNatureza(String natureza) { 
		this.natureza = natureza; 
	} 

	public String getIndicacaoResultados() { 
		return this.indicacaoResultados; 
	} 

	public void setIndicacaoResultados(String indicacaoResultados) { 
		this.indicacaoResultados = indicacaoResultados; 
	} 

	public FolhaPppModel getFolhaPppModel() { 
	return this.folhaPppModel; 
	} 

	public void setFolhaPppModel(FolhaPppModel folhaPppModel) { 
	this.folhaPppModel = folhaPppModel; 
	} 

		
}