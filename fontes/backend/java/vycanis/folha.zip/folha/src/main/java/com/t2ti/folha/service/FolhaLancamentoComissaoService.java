package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaLancamentoComissaoModel;
import com.t2ti.folha.repository.FolhaLancamentoComissaoRepository;

@Service
public class FolhaLancamentoComissaoService {

	@Autowired
	private FolhaLancamentoComissaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaLancamentoComissaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaLancamentoComissaoModel> getList(Filter filter) {
		String sql = "select * from folha_lancamento_comissao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaLancamentoComissaoModel.class);
		return query.getResultList();
	}

	public FolhaLancamentoComissaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaLancamentoComissaoModel save(FolhaLancamentoComissaoModel obj) {
		FolhaLancamentoComissaoModel folhaLancamentoComissaoModel = repository.save(obj);
		return folhaLancamentoComissaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaLancamentoComissaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaLancamentoComissao] - Exception: " + e.getMessage());
		}
	}

}