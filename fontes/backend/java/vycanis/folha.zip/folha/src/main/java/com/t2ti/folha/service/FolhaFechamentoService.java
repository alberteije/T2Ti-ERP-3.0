package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaFechamentoModel;
import com.t2ti.folha.repository.FolhaFechamentoRepository;

@Service
public class FolhaFechamentoService {

	@Autowired
	private FolhaFechamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaFechamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaFechamentoModel> getList(Filter filter) {
		String sql = "select * from folha_fechamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaFechamentoModel.class);
		return query.getResultList();
	}

	public FolhaFechamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaFechamentoModel save(FolhaFechamentoModel obj) {
		FolhaFechamentoModel folhaFechamentoModel = repository.save(obj);
		return folhaFechamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaFechamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaFechamento] - Exception: " + e.getMessage());
		}
	}

}