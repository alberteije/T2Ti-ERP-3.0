package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaInssModel;
import com.t2ti.folha.repository.FolhaInssRepository;

@Service
public class FolhaInssService {

	@Autowired
	private FolhaInssRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaInssModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaInssModel> getList(Filter filter) {
		String sql = "select * from folha_inss where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaInssModel.class);
		return query.getResultList();
	}

	public FolhaInssModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaInssModel save(FolhaInssModel obj) {
		FolhaInssModel folhaInssModel = repository.save(obj);
		return folhaInssModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaInssModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaInss] - Exception: " + e.getMessage());
		}
	}

}