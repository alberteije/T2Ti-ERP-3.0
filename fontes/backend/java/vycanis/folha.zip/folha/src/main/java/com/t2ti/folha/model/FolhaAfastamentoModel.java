package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_afastamento")
@NamedQuery(name="FolhaAfastamentoModel.findAll", query="SELECT t FROM FolhaAfastamentoModel t")
public class FolhaAfastamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaAfastamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Column(name="dias_afastado")
	private Integer diasAfastado;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_folha_tipo_afastamento")
	private FolhaTipoAfastamentoModel folhaTipoAfastamentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public Integer getDiasAfastado() { 
		return this.diasAfastado; 
	} 

	public void setDiasAfastado(Integer diasAfastado) { 
		this.diasAfastado = diasAfastado; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public FolhaTipoAfastamentoModel getFolhaTipoAfastamentoModel() { 
	return this.folhaTipoAfastamentoModel; 
	} 

	public void setFolhaTipoAfastamentoModel(FolhaTipoAfastamentoModel folhaTipoAfastamentoModel) { 
	this.folhaTipoAfastamentoModel = folhaTipoAfastamentoModel; 
	} 

		
}