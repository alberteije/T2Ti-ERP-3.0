package com.t2ti.folha.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.exception.ResourseNotFoundException;
import com.t2ti.folha.exception.BadRequestException;
import com.t2ti.folha.util.Filter;
import com.t2ti.folha.model.FolhaAfastamentoModel;
import com.t2ti.folha.service.FolhaAfastamentoService;

@RestController
@RequestMapping(value = "/folha-afastamento", produces = "application/json;charset=UTF-8")
public class FolhaAfastamentoController {

	@Autowired
	private FolhaAfastamentoService service;
	
	@GetMapping({ "", "/" })
	public List<FolhaAfastamentoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [FolhaAfastamento] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public FolhaAfastamentoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found FolhaAfastamento].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found FolhaAfastamento] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public FolhaAfastamentoModel insert(@RequestBody FolhaAfastamentoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert FolhaAfastamento] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public FolhaAfastamentoModel update(@RequestBody FolhaAfastamentoModel objJson) {	
		try {			
			FolhaAfastamentoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update FolhaAfastamento].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update FolhaAfastamento] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaAfastamento] - Exception: " + e.getMessage());
		}
	}
	
}