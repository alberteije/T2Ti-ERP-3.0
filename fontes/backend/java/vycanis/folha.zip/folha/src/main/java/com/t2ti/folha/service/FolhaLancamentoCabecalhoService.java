package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaLancamentoCabecalhoModel;
import com.t2ti.folha.repository.FolhaLancamentoCabecalhoRepository;

@Service
public class FolhaLancamentoCabecalhoService {

	@Autowired
	private FolhaLancamentoCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaLancamentoCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaLancamentoCabecalhoModel> getList(Filter filter) {
		String sql = "select * from folha_lancamento_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaLancamentoCabecalhoModel.class);
		return query.getResultList();
	}

	public FolhaLancamentoCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaLancamentoCabecalhoModel save(FolhaLancamentoCabecalhoModel obj) {
		FolhaLancamentoCabecalhoModel folhaLancamentoCabecalhoModel = repository.save(obj);
		return folhaLancamentoCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaLancamentoCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaLancamentoCabecalho] - Exception: " + e.getMessage());
		}
	}

}