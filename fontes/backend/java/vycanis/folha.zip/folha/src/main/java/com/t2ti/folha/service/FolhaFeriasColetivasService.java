package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaFeriasColetivasModel;
import com.t2ti.folha.repository.FolhaFeriasColetivasRepository;

@Service
public class FolhaFeriasColetivasService {

	@Autowired
	private FolhaFeriasColetivasRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaFeriasColetivasModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaFeriasColetivasModel> getList(Filter filter) {
		String sql = "select * from folha_ferias_coletivas where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaFeriasColetivasModel.class);
		return query.getResultList();
	}

	public FolhaFeriasColetivasModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaFeriasColetivasModel save(FolhaFeriasColetivasModel obj) {
		FolhaFeriasColetivasModel folhaFeriasColetivasModel = repository.save(obj);
		return folhaFeriasColetivasModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaFeriasColetivasModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaFeriasColetivas] - Exception: " + e.getMessage());
		}
	}

}