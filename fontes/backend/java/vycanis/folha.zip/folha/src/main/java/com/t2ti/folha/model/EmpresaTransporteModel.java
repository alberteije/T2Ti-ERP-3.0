package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="empresa_transporte")
@NamedQuery(name="EmpresaTransporteModel.findAll", query="SELECT t FROM EmpresaTransporteModel t")
public class EmpresaTransporteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EmpresaTransporteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="uf")
	private String uf;

	@Column(name="classificacao_contabil_conta")
	private String classificacaoContabilConta;

	@OneToMany(mappedBy = "empresaTransporteModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<EmpresaTransporteItinerarioModel> empresaTransporteItinerarioModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getClassificacaoContabilConta() { 
		return this.classificacaoContabilConta; 
	} 

	public void setClassificacaoContabilConta(String classificacaoContabilConta) { 
		this.classificacaoContabilConta = classificacaoContabilConta; 
	} 

	public Set<EmpresaTransporteItinerarioModel> getEmpresaTransporteItinerarioModelList() { 
	return this.empresaTransporteItinerarioModelList; 
	} 

	public void setEmpresaTransporteItinerarioModelList(Set<EmpresaTransporteItinerarioModel> empresaTransporteItinerarioModelList) { 
	this.empresaTransporteItinerarioModelList = empresaTransporteItinerarioModelList; 
		for (EmpresaTransporteItinerarioModel empresaTransporteItinerarioModel : empresaTransporteItinerarioModelList) { 
			empresaTransporteItinerarioModel.setEmpresaTransporteModel(this); 
		}
	} 

		
}