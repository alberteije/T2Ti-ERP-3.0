package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.ViewPessoaColaboradorModel;

public interface ViewPessoaColaboradorRepository extends JpaRepository<ViewPessoaColaboradorModel, Integer> {}