package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_rescisao")
@NamedQuery(name="FolhaRescisaoModel.findAll", query="SELECT t FROM FolhaRescisaoModel t")
public class FolhaRescisaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaRescisaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_demissao")
	private Date dataDemissao;

	@Temporal(TemporalType.DATE)
@Column(name="data_pagamento")
	private Date dataPagamento;

	@Column(name="motivo")
	private String motivo;

	@Column(name="motivo_esocial")
	private String motivoEsocial;

	@Temporal(TemporalType.DATE)
@Column(name="data_aviso_previo")
	private Date dataAvisoPrevio;

	@Column(name="dias_aviso_previo")
	private Integer diasAvisoPrevio;

	@Column(name="comprovou_novo_emprego")
	private String comprovouNovoEmprego;

	@Column(name="dispensou_empregado")
	private String dispensouEmpregado;

	@Column(name="pensao_alimenticia")
	private BigDecimal pensaoAlimenticia;

	@Column(name="pensao_alimenticia_fgts")
	private BigDecimal pensaoAlimenticiaFgts;

	@Column(name="fgts_valor_rescisao")
	private BigDecimal fgtsValorRescisao;

	@Column(name="fgts_saldo_banco")
	private BigDecimal fgtsSaldoBanco;

	@Column(name="fgts_complemento_saldo")
	private BigDecimal fgtsComplementoSaldo;

	@Column(name="fgts_codigo_afastamento")
	private String fgtsCodigoAfastamento;

	@Column(name="fgts_codigo_saque")
	private String fgtsCodigoSaque;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataDemissao() { 
		return this.dataDemissao; 
	} 

	public void setDataDemissao(Date dataDemissao) { 
		this.dataDemissao = dataDemissao; 
	} 

	public Date getDataPagamento() { 
		return this.dataPagamento; 
	} 

	public void setDataPagamento(Date dataPagamento) { 
		this.dataPagamento = dataPagamento; 
	} 

	public String getMotivo() { 
		return this.motivo; 
	} 

	public void setMotivo(String motivo) { 
		this.motivo = motivo; 
	} 

	public String getMotivoEsocial() { 
		return this.motivoEsocial; 
	} 

	public void setMotivoEsocial(String motivoEsocial) { 
		this.motivoEsocial = motivoEsocial; 
	} 

	public Date getDataAvisoPrevio() { 
		return this.dataAvisoPrevio; 
	} 

	public void setDataAvisoPrevio(Date dataAvisoPrevio) { 
		this.dataAvisoPrevio = dataAvisoPrevio; 
	} 

	public Integer getDiasAvisoPrevio() { 
		return this.diasAvisoPrevio; 
	} 

	public void setDiasAvisoPrevio(Integer diasAvisoPrevio) { 
		this.diasAvisoPrevio = diasAvisoPrevio; 
	} 

	public String getComprovouNovoEmprego() { 
		return this.comprovouNovoEmprego; 
	} 

	public void setComprovouNovoEmprego(String comprovouNovoEmprego) { 
		this.comprovouNovoEmprego = comprovouNovoEmprego; 
	} 

	public String getDispensouEmpregado() { 
		return this.dispensouEmpregado; 
	} 

	public void setDispensouEmpregado(String dispensouEmpregado) { 
		this.dispensouEmpregado = dispensouEmpregado; 
	} 

	public BigDecimal getPensaoAlimenticia() { 
		return this.pensaoAlimenticia; 
	} 

	public void setPensaoAlimenticia(BigDecimal pensaoAlimenticia) { 
		this.pensaoAlimenticia = pensaoAlimenticia; 
	} 

	public BigDecimal getPensaoAlimenticiaFgts() { 
		return this.pensaoAlimenticiaFgts; 
	} 

	public void setPensaoAlimenticiaFgts(BigDecimal pensaoAlimenticiaFgts) { 
		this.pensaoAlimenticiaFgts = pensaoAlimenticiaFgts; 
	} 

	public BigDecimal getFgtsValorRescisao() { 
		return this.fgtsValorRescisao; 
	} 

	public void setFgtsValorRescisao(BigDecimal fgtsValorRescisao) { 
		this.fgtsValorRescisao = fgtsValorRescisao; 
	} 

	public BigDecimal getFgtsSaldoBanco() { 
		return this.fgtsSaldoBanco; 
	} 

	public void setFgtsSaldoBanco(BigDecimal fgtsSaldoBanco) { 
		this.fgtsSaldoBanco = fgtsSaldoBanco; 
	} 

	public BigDecimal getFgtsComplementoSaldo() { 
		return this.fgtsComplementoSaldo; 
	} 

	public void setFgtsComplementoSaldo(BigDecimal fgtsComplementoSaldo) { 
		this.fgtsComplementoSaldo = fgtsComplementoSaldo; 
	} 

	public String getFgtsCodigoAfastamento() { 
		return this.fgtsCodigoAfastamento; 
	} 

	public void setFgtsCodigoAfastamento(String fgtsCodigoAfastamento) { 
		this.fgtsCodigoAfastamento = fgtsCodigoAfastamento; 
	} 

	public String getFgtsCodigoSaque() { 
		return this.fgtsCodigoSaque; 
	} 

	public void setFgtsCodigoSaque(String fgtsCodigoSaque) { 
		this.fgtsCodigoSaque = fgtsCodigoSaque; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}