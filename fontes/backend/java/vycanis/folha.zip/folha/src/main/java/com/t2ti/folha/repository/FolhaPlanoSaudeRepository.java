package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaPlanoSaudeModel;

public interface FolhaPlanoSaudeRepository extends JpaRepository<FolhaPlanoSaudeModel, Integer> {}