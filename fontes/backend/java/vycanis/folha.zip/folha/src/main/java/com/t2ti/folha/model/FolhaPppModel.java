package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_ppp")
@NamedQuery(name="FolhaPppModel.findAll", query="SELECT t FROM FolhaPppModel t")
public class FolhaPppModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaPppModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="observacao")
	private String observacao;

	@OneToMany(mappedBy = "folhaPppModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FolhaPppCatModel> folhaPppCatModelList; 

	@OneToMany(mappedBy = "folhaPppModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FolhaPppAtividadeModel> folhaPppAtividadeModelList; 

	@OneToMany(mappedBy = "folhaPppModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FolhaPppFatorRiscoModel> folhaPppFatorRiscoModelList; 

	@OneToMany(mappedBy = "folhaPppModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FolhaPppExameMedicoModel> folhaPppExameMedicoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Set<FolhaPppCatModel> getFolhaPppCatModelList() { 
	return this.folhaPppCatModelList; 
	} 

	public void setFolhaPppCatModelList(Set<FolhaPppCatModel> folhaPppCatModelList) { 
	this.folhaPppCatModelList = folhaPppCatModelList; 
		for (FolhaPppCatModel folhaPppCatModel : folhaPppCatModelList) { 
			folhaPppCatModel.setFolhaPppModel(this); 
		}
	} 

	public Set<FolhaPppAtividadeModel> getFolhaPppAtividadeModelList() { 
	return this.folhaPppAtividadeModelList; 
	} 

	public void setFolhaPppAtividadeModelList(Set<FolhaPppAtividadeModel> folhaPppAtividadeModelList) { 
	this.folhaPppAtividadeModelList = folhaPppAtividadeModelList; 
		for (FolhaPppAtividadeModel folhaPppAtividadeModel : folhaPppAtividadeModelList) { 
			folhaPppAtividadeModel.setFolhaPppModel(this); 
		}
	} 

	public Set<FolhaPppFatorRiscoModel> getFolhaPppFatorRiscoModelList() { 
	return this.folhaPppFatorRiscoModelList; 
	} 

	public void setFolhaPppFatorRiscoModelList(Set<FolhaPppFatorRiscoModel> folhaPppFatorRiscoModelList) { 
	this.folhaPppFatorRiscoModelList = folhaPppFatorRiscoModelList; 
		for (FolhaPppFatorRiscoModel folhaPppFatorRiscoModel : folhaPppFatorRiscoModelList) { 
			folhaPppFatorRiscoModel.setFolhaPppModel(this); 
		}
	} 

	public Set<FolhaPppExameMedicoModel> getFolhaPppExameMedicoModelList() { 
	return this.folhaPppExameMedicoModelList; 
	} 

	public void setFolhaPppExameMedicoModelList(Set<FolhaPppExameMedicoModel> folhaPppExameMedicoModelList) { 
	this.folhaPppExameMedicoModelList = folhaPppExameMedicoModelList; 
		for (FolhaPppExameMedicoModel folhaPppExameMedicoModel : folhaPppExameMedicoModelList) { 
			folhaPppExameMedicoModel.setFolhaPppModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}