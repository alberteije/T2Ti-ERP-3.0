package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaValeTransporteModel;
import com.t2ti.folha.repository.FolhaValeTransporteRepository;

@Service
public class FolhaValeTransporteService {

	@Autowired
	private FolhaValeTransporteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaValeTransporteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaValeTransporteModel> getList(Filter filter) {
		String sql = "select * from folha_vale_transporte where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaValeTransporteModel.class);
		return query.getResultList();
	}

	public FolhaValeTransporteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaValeTransporteModel save(FolhaValeTransporteModel obj) {
		FolhaValeTransporteModel folhaValeTransporteModel = repository.save(obj);
		return folhaValeTransporteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaValeTransporteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaValeTransporte] - Exception: " + e.getMessage());
		}
	}

}