package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_inss_retencao")
@NamedQuery(name="FolhaInssRetencaoModel.findAll", query="SELECT t FROM FolhaInssRetencaoModel t")
public class FolhaInssRetencaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaInssRetencaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor_mensal")
	private BigDecimal valorMensal;

	@Column(name="valor_13")
	private BigDecimal valor13;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_folha_inss")
	private FolhaInssModel folhaInssModel; 

	@ManyToOne 
	@JoinColumn(name="id_folha_inss_servico")
	private FolhaInssServicoModel folhaInssServicoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValorMensal() { 
		return this.valorMensal; 
	} 

	public void setValorMensal(BigDecimal valorMensal) { 
		this.valorMensal = valorMensal; 
	} 

	public BigDecimal getValor13() { 
		return this.valor13; 
	} 

	public void setValor13(BigDecimal valor13) { 
		this.valor13 = valor13; 
	} 

	public FolhaInssModel getFolhaInssModel() { 
	return this.folhaInssModel; 
	} 

	public void setFolhaInssModel(FolhaInssModel folhaInssModel) { 
	this.folhaInssModel = folhaInssModel; 
	} 

	public FolhaInssServicoModel getFolhaInssServicoModel() { 
	return this.folhaInssServicoModel; 
	} 

	public void setFolhaInssServicoModel(FolhaInssServicoModel folhaInssServicoModel) { 
	this.folhaInssServicoModel = folhaInssServicoModel; 
	} 

		
}