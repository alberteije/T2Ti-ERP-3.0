package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.EmpresaTransporteModel;

public interface EmpresaTransporteRepository extends JpaRepository<EmpresaTransporteModel, Integer> {}