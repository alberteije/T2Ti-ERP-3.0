package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_lancamento_detalhe")
@NamedQuery(name="FolhaLancamentoDetalheModel.findAll", query="SELECT t FROM FolhaLancamentoDetalheModel t")
public class FolhaLancamentoDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaLancamentoDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="origem")
	private BigDecimal origem;

	@Column(name="provento")
	private BigDecimal provento;

	@Column(name="desconto")
	private BigDecimal desconto;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_folha_lancamento_cabecalho")
	private FolhaLancamentoCabecalhoModel folhaLancamentoCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_folha_evento")
	private FolhaEventoModel folhaEventoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getOrigem() { 
		return this.origem; 
	} 

	public void setOrigem(BigDecimal origem) { 
		this.origem = origem; 
	} 

	public BigDecimal getProvento() { 
		return this.provento; 
	} 

	public void setProvento(BigDecimal provento) { 
		this.provento = provento; 
	} 

	public BigDecimal getDesconto() { 
		return this.desconto; 
	} 

	public void setDesconto(BigDecimal desconto) { 
		this.desconto = desconto; 
	} 

	public FolhaLancamentoCabecalhoModel getFolhaLancamentoCabecalhoModel() { 
	return this.folhaLancamentoCabecalhoModel; 
	} 

	public void setFolhaLancamentoCabecalhoModel(FolhaLancamentoCabecalhoModel folhaLancamentoCabecalhoModel) { 
	this.folhaLancamentoCabecalhoModel = folhaLancamentoCabecalhoModel; 
	} 

	public FolhaEventoModel getFolhaEventoModel() { 
	return this.folhaEventoModel; 
	} 

	public void setFolhaEventoModel(FolhaEventoModel folhaEventoModel) { 
	this.folhaEventoModel = folhaEventoModel; 
	} 

		
}