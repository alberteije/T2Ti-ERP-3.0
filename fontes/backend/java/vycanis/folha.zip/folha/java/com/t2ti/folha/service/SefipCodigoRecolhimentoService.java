package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.SefipCodigoRecolhimentoModel;
import com.t2ti.folha.repository.SefipCodigoRecolhimentoRepository;

@Service
public class SefipCodigoRecolhimentoService {

	@Autowired
	private SefipCodigoRecolhimentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SefipCodigoRecolhimentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SefipCodigoRecolhimentoModel> getList(Filter filter) {
		String sql = "select * from sefip_codigo_recolhimento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SefipCodigoRecolhimentoModel.class);
		return query.getResultList();
	}

	public SefipCodigoRecolhimentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SefipCodigoRecolhimentoModel save(SefipCodigoRecolhimentoModel obj) {
		SefipCodigoRecolhimentoModel sefipCodigoRecolhimentoModel = repository.save(obj);
		return sefipCodigoRecolhimentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SefipCodigoRecolhimentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SefipCodigoRecolhimento] - Exception: " + e.getMessage());
		}
	}

}