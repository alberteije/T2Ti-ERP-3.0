package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaRescisaoModel;

public interface FolhaRescisaoRepository extends JpaRepository<FolhaRescisaoModel, Integer> {}