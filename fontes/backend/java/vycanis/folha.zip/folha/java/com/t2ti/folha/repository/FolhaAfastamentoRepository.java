package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaAfastamentoModel;

public interface FolhaAfastamentoRepository extends JpaRepository<FolhaAfastamentoModel, Integer> {}