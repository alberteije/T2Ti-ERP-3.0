package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.SefipCodigoRecolhimentoModel;

public interface SefipCodigoRecolhimentoRepository extends JpaRepository<SefipCodigoRecolhimentoModel, Integer> {}