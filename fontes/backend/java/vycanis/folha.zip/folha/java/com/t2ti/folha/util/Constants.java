package com.t2ti.folha.util;

public class Constants {

	private Constants() {
		throw new IllegalStateException("Constants");
	}
	

    public static int MAX_ROWS = 50;
}