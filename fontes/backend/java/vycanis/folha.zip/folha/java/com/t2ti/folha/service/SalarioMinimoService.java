package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.SalarioMinimoModel;
import com.t2ti.folha.repository.SalarioMinimoRepository;

@Service
public class SalarioMinimoService {

	@Autowired
	private SalarioMinimoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SalarioMinimoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SalarioMinimoModel> getList(Filter filter) {
		String sql = "select * from salario_minimo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SalarioMinimoModel.class);
		return query.getResultList();
	}

	public SalarioMinimoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SalarioMinimoModel save(SalarioMinimoModel obj) {
		SalarioMinimoModel salarioMinimoModel = repository.save(obj);
		return salarioMinimoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SalarioMinimoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SalarioMinimo] - Exception: " + e.getMessage());
		}
	}

}