package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaTipoAfastamentoModel;
import com.t2ti.folha.repository.FolhaTipoAfastamentoRepository;

@Service
public class FolhaTipoAfastamentoService {

	@Autowired
	private FolhaTipoAfastamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaTipoAfastamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaTipoAfastamentoModel> getList(Filter filter) {
		String sql = "select * from folha_tipo_afastamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaTipoAfastamentoModel.class);
		return query.getResultList();
	}

	public FolhaTipoAfastamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaTipoAfastamentoModel save(FolhaTipoAfastamentoModel obj) {
		FolhaTipoAfastamentoModel folhaTipoAfastamentoModel = repository.save(obj);
		return folhaTipoAfastamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaTipoAfastamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaTipoAfastamento] - Exception: " + e.getMessage());
		}
	}

}