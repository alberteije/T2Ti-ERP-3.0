package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.EmpresaTransporteItinerarioModel;
import com.t2ti.folha.repository.EmpresaTransporteItinerarioRepository;

@Service
public class EmpresaTransporteItinerarioService {

	@Autowired
	private EmpresaTransporteItinerarioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EmpresaTransporteItinerarioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EmpresaTransporteItinerarioModel> getList(Filter filter) {
		String sql = "select * from empresa_transporte_itinerario where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EmpresaTransporteItinerarioModel.class);
		return query.getResultList();
	}

	public EmpresaTransporteItinerarioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EmpresaTransporteItinerarioModel save(EmpresaTransporteItinerarioModel obj) {
		EmpresaTransporteItinerarioModel empresaTransporteItinerarioModel = repository.save(obj);
		return empresaTransporteItinerarioModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EmpresaTransporteItinerarioModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EmpresaTransporteItinerario] - Exception: " + e.getMessage());
		}
	}

}