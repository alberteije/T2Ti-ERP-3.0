package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.CboModel;
import com.t2ti.folha.repository.CboRepository;

@Service
public class CboService {

	@Autowired
	private CboRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CboModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CboModel> getList(Filter filter) {
		String sql = "select * from cbo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CboModel.class);
		return query.getResultList();
	}

	public CboModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CboModel save(CboModel obj) {
		CboModel cboModel = repository.save(obj);
		return cboModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CboModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Cbo] - Exception: " + e.getMessage());
		}
	}

}