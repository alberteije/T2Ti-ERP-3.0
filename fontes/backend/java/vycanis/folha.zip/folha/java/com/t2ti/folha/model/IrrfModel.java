package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="irrf")
@NamedQuery(name="IrrfModel.findAll", query="SELECT t FROM IrrfModel t")
public class IrrfModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public IrrfModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="desconto_por_dependente")
	private BigDecimal descontoPorDependente;

	@Column(name="minimo_para_retencao")
	private BigDecimal minimoParaRetencao;

	@OneToMany(mappedBy = "irrfModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<IrrfDetalheModel> irrfDetalheModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public BigDecimal getDescontoPorDependente() { 
		return this.descontoPorDependente; 
	} 

	public void setDescontoPorDependente(BigDecimal descontoPorDependente) { 
		this.descontoPorDependente = descontoPorDependente; 
	} 

	public BigDecimal getMinimoParaRetencao() { 
		return this.minimoParaRetencao; 
	} 

	public void setMinimoParaRetencao(BigDecimal minimoParaRetencao) { 
		this.minimoParaRetencao = minimoParaRetencao; 
	} 

	public Set<IrrfDetalheModel> getIrrfDetalheModelList() { 
	return this.irrfDetalheModelList; 
	} 

	public void setIrrfDetalheModelList(Set<IrrfDetalheModel> irrfDetalheModelList) { 
	this.irrfDetalheModelList = irrfDetalheModelList; 
		for (IrrfDetalheModel irrfDetalheModel : irrfDetalheModelList) { 
			irrfDetalheModel.setIrrfModel(this); 
		}
	} 

		
}