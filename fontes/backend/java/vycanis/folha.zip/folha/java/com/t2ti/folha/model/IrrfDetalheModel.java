package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="irrf_detalhe")
@NamedQuery(name="IrrfDetalheModel.findAll", query="SELECT t FROM IrrfDetalheModel t")
public class IrrfDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public IrrfDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="faixa")
	private Integer faixa;

	@Column(name="de")
	private BigDecimal de;

	@Column(name="ate")
	private BigDecimal ate;

	@Column(name="taxa")
	private BigDecimal taxa;

	@Column(name="desconto")
	private BigDecimal desconto;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_irrf")
	private IrrfModel irrfModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getFaixa() { 
		return this.faixa; 
	} 

	public void setFaixa(Integer faixa) { 
		this.faixa = faixa; 
	} 

	public BigDecimal getDe() { 
		return this.de; 
	} 

	public void setDe(BigDecimal de) { 
		this.de = de; 
	} 

	public BigDecimal getAte() { 
		return this.ate; 
	} 

	public void setAte(BigDecimal ate) { 
		this.ate = ate; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

	public BigDecimal getDesconto() { 
		return this.desconto; 
	} 

	public void setDesconto(BigDecimal desconto) { 
		this.desconto = desconto; 
	} 

	public IrrfModel getIrrfModel() { 
	return this.irrfModel; 
	} 

	public void setIrrfModel(IrrfModel irrfModel) { 
	this.irrfModel = irrfModel; 
	} 

		
}