package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaInssServicoModel;
import com.t2ti.folha.repository.FolhaInssServicoRepository;

@Service
public class FolhaInssServicoService {

	@Autowired
	private FolhaInssServicoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaInssServicoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaInssServicoModel> getList(Filter filter) {
		String sql = "select * from folha_inss_servico where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaInssServicoModel.class);
		return query.getResultList();
	}

	public FolhaInssServicoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaInssServicoModel save(FolhaInssServicoModel obj) {
		FolhaInssServicoModel folhaInssServicoModel = repository.save(obj);
		return folhaInssServicoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaInssServicoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaInssServico] - Exception: " + e.getMessage());
		}
	}

}