package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="fpas")
@NamedQuery(name="FpasModel.findAll", query="SELECT t FROM FpasModel t")
public class FpasModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FpasModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private Integer codigo;

	@Column(name="cnae")
	private String cnae;

	@Column(name="aliquota_sat")
	private BigDecimal aliquotaSat;

	@Column(name="descricao")
	private String descricao;

	@Column(name="percentual_inss_patronal")
	private BigDecimal percentualInssPatronal;

	@Column(name="codigo_terceiro")
	private String codigoTerceiro;

	@Column(name="percentual_terceiros")
	private BigDecimal percentualTerceiros;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(Integer codigo) { 
		this.codigo = codigo; 
	} 

	public String getCnae() { 
		return this.cnae; 
	} 

	public void setCnae(String cnae) { 
		this.cnae = cnae; 
	} 

	public BigDecimal getAliquotaSat() { 
		return this.aliquotaSat; 
	} 

	public void setAliquotaSat(BigDecimal aliquotaSat) { 
		this.aliquotaSat = aliquotaSat; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public BigDecimal getPercentualInssPatronal() { 
		return this.percentualInssPatronal; 
	} 

	public void setPercentualInssPatronal(BigDecimal percentualInssPatronal) { 
		this.percentualInssPatronal = percentualInssPatronal; 
	} 

	public String getCodigoTerceiro() { 
		return this.codigoTerceiro; 
	} 

	public void setCodigoTerceiro(String codigoTerceiro) { 
		this.codigoTerceiro = codigoTerceiro; 
	} 

	public BigDecimal getPercentualTerceiros() { 
		return this.percentualTerceiros; 
	} 

	public void setPercentualTerceiros(BigDecimal percentualTerceiros) { 
		this.percentualTerceiros = percentualTerceiros; 
	} 

		
}