package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.CodigoGpsModel;
import com.t2ti.folha.repository.CodigoGpsRepository;

@Service
public class CodigoGpsService {

	@Autowired
	private CodigoGpsRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CodigoGpsModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CodigoGpsModel> getList(Filter filter) {
		String sql = "select * from codigo_gps where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CodigoGpsModel.class);
		return query.getResultList();
	}

	public CodigoGpsModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CodigoGpsModel save(CodigoGpsModel obj) {
		CodigoGpsModel codigoGpsModel = repository.save(obj);
		return codigoGpsModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CodigoGpsModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CodigoGps] - Exception: " + e.getMessage());
		}
	}

}