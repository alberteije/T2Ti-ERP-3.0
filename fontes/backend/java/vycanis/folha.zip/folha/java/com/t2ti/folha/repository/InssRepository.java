package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.InssModel;

public interface InssRepository extends JpaRepository<InssModel, Integer> {}