package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaValeTransporteModel;

public interface FolhaValeTransporteRepository extends JpaRepository<FolhaValeTransporteModel, Integer> {}