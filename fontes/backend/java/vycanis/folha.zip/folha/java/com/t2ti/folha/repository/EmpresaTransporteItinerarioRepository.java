package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.EmpresaTransporteItinerarioModel;

public interface EmpresaTransporteItinerarioRepository extends JpaRepository<EmpresaTransporteItinerarioModel, Integer> {}