package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="operadora_plano_saude")
@NamedQuery(name="OperadoraPlanoSaudeModel.findAll", query="SELECT t FROM OperadoraPlanoSaudeModel t")
public class OperadoraPlanoSaudeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OperadoraPlanoSaudeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="registro_ans")
	private String registroAns;

	@Column(name="classificacao_contabil_conta")
	private String classificacaoContabilConta;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getRegistroAns() { 
		return this.registroAns; 
	} 

	public void setRegistroAns(String registroAns) { 
		this.registroAns = registroAns; 
	} 

	public String getClassificacaoContabilConta() { 
		return this.classificacaoContabilConta; 
	} 

	public void setClassificacaoContabilConta(String classificacaoContabilConta) { 
		this.classificacaoContabilConta = classificacaoContabilConta; 
	} 

		
}