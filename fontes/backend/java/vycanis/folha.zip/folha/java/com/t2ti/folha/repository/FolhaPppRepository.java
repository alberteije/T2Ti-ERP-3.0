package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaPppModel;

public interface FolhaPppRepository extends JpaRepository<FolhaPppModel, Integer> {}