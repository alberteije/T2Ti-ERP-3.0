package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaLancamentoComissaoModel;

public interface FolhaLancamentoComissaoRepository extends JpaRepository<FolhaLancamentoComissaoModel, Integer> {}