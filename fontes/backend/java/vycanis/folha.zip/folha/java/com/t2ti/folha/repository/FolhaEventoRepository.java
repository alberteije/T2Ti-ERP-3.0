package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaEventoModel;

public interface FolhaEventoRepository extends JpaRepository<FolhaEventoModel, Integer> {}