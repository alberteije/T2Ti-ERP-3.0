package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaLancamentoCabecalhoModel;

public interface FolhaLancamentoCabecalhoRepository extends JpaRepository<FolhaLancamentoCabecalhoModel, Integer> {}