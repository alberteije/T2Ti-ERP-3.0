package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.IrrfModel;
import com.t2ti.folha.repository.IrrfRepository;

@Service
public class IrrfService {

	@Autowired
	private IrrfRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<IrrfModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<IrrfModel> getList(Filter filter) {
		String sql = "select * from irrf where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, IrrfModel.class);
		return query.getResultList();
	}

	public IrrfModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public IrrfModel save(IrrfModel obj) {
		IrrfModel irrfModel = repository.save(obj);
		return irrfModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		IrrfModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Irrf] - Exception: " + e.getMessage());
		}
	}

}