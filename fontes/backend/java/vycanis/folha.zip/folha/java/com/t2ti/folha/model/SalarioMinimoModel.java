package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="salario_minimo")
@NamedQuery(name="SalarioMinimoModel.findAll", query="SELECT t FROM SalarioMinimoModel t")
public class SalarioMinimoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public SalarioMinimoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="vigencia")
	private Date vigencia;

	@Column(name="valor_mensal")
	private BigDecimal valorMensal;

	@Column(name="valor_diario")
	private BigDecimal valorDiario;

	@Column(name="valor_hora")
	private BigDecimal valorHora;

	@Column(name="norma_legal")
	private String normaLegal;

	@Temporal(TemporalType.DATE)
@Column(name="dou")
	private Date dou;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getVigencia() { 
		return this.vigencia; 
	} 

	public void setVigencia(Date vigencia) { 
		this.vigencia = vigencia; 
	} 

	public BigDecimal getValorMensal() { 
		return this.valorMensal; 
	} 

	public void setValorMensal(BigDecimal valorMensal) { 
		this.valorMensal = valorMensal; 
	} 

	public BigDecimal getValorDiario() { 
		return this.valorDiario; 
	} 

	public void setValorDiario(BigDecimal valorDiario) { 
		this.valorDiario = valorDiario; 
	} 

	public BigDecimal getValorHora() { 
		return this.valorHora; 
	} 

	public void setValorHora(BigDecimal valorHora) { 
		this.valorHora = valorHora; 
	} 

	public String getNormaLegal() { 
		return this.normaLegal; 
	} 

	public void setNormaLegal(String normaLegal) { 
		this.normaLegal = normaLegal; 
	} 

	public Date getDou() { 
		return this.dou; 
	} 

	public void setDou(Date dou) { 
		this.dou = dou; 
	} 

		
}