package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.ViewPessoaUsuarioModel;
import com.t2ti.folha.repository.ViewPessoaUsuarioRepository;

@Service
public class ViewPessoaUsuarioService {

	@Autowired
	private ViewPessoaUsuarioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ViewPessoaUsuarioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ViewPessoaUsuarioModel> getList(Filter filter) {
		String sql = "select * from view_pessoa_usuario where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewPessoaUsuarioModel.class);
		return query.getResultList();
	}

	public ViewPessoaUsuarioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ViewPessoaUsuarioModel save(ViewPessoaUsuarioModel obj) {
		ViewPessoaUsuarioModel viewPessoaUsuarioModel = repository.save(obj);
		return viewPessoaUsuarioModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ViewPessoaUsuarioModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ViewPessoaUsuario] - Exception: " + e.getMessage());
		}
	}

}