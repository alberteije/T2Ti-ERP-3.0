package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_plano_saude")
@NamedQuery(name="FolhaPlanoSaudeModel.findAll", query="SELECT t FROM FolhaPlanoSaudeModel t")
public class FolhaPlanoSaudeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaPlanoSaudeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Column(name="beneficiario")
	private String beneficiario;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_operadora_plano_saude")
	private OperadoraPlanoSaudeModel operadoraPlanoSaudeModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public String getBeneficiario() { 
		return this.beneficiario; 
	} 

	public void setBeneficiario(String beneficiario) { 
		this.beneficiario = beneficiario; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public OperadoraPlanoSaudeModel getOperadoraPlanoSaudeModel() { 
	return this.operadoraPlanoSaudeModel; 
	} 

	public void setOperadoraPlanoSaudeModel(OperadoraPlanoSaudeModel operadoraPlanoSaudeModel) { 
	this.operadoraPlanoSaudeModel = operadoraPlanoSaudeModel; 
	} 

		
}