package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="sefip_categoria_trabalho")
@NamedQuery(name="SefipCategoriaTrabalhoModel.findAll", query="SELECT t FROM SefipCategoriaTrabalhoModel t")
public class SefipCategoriaTrabalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public SefipCategoriaTrabalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private Integer codigo;

	@Column(name="nome")
	private String nome;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(Integer codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

		
}