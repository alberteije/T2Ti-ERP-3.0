package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.SefipCategoriaTrabalhoModel;
import com.t2ti.folha.repository.SefipCategoriaTrabalhoRepository;

@Service
public class SefipCategoriaTrabalhoService {

	@Autowired
	private SefipCategoriaTrabalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SefipCategoriaTrabalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SefipCategoriaTrabalhoModel> getList(Filter filter) {
		String sql = "select * from sefip_categoria_trabalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SefipCategoriaTrabalhoModel.class);
		return query.getResultList();
	}

	public SefipCategoriaTrabalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SefipCategoriaTrabalhoModel save(SefipCategoriaTrabalhoModel obj) {
		SefipCategoriaTrabalhoModel sefipCategoriaTrabalhoModel = repository.save(obj);
		return sefipCategoriaTrabalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SefipCategoriaTrabalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SefipCategoriaTrabalho] - Exception: " + e.getMessage());
		}
	}

}