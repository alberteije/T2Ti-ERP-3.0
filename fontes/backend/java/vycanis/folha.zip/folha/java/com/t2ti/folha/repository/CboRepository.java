package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.CboModel;

public interface CboRepository extends JpaRepository<CboModel, Integer> {}