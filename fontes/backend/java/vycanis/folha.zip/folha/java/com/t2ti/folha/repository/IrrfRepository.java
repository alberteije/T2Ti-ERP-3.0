package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.IrrfModel;

public interface IrrfRepository extends JpaRepository<IrrfModel, Integer> {}