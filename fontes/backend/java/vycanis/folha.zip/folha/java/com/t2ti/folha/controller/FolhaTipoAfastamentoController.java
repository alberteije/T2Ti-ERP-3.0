package com.t2ti.folha.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.exception.ResourseNotFoundException;
import com.t2ti.folha.exception.BadRequestException;
import com.t2ti.folha.util.Filter;
import com.t2ti.folha.model.FolhaTipoAfastamentoModel;
import com.t2ti.folha.service.FolhaTipoAfastamentoService;

@RestController
@RequestMapping(value = "/folha-tipo-afastamento", produces = "application/json;charset=UTF-8")
public class FolhaTipoAfastamentoController {

	@Autowired
	private FolhaTipoAfastamentoService service;
	
	@GetMapping({ "", "/" })
	public List<FolhaTipoAfastamentoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [FolhaTipoAfastamento] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public FolhaTipoAfastamentoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found FolhaTipoAfastamento].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found FolhaTipoAfastamento] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public FolhaTipoAfastamentoModel insert(@RequestBody FolhaTipoAfastamentoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert FolhaTipoAfastamento] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public FolhaTipoAfastamentoModel update(@RequestBody FolhaTipoAfastamentoModel objJson) {	
		try {			
			FolhaTipoAfastamentoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update FolhaTipoAfastamento].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update FolhaTipoAfastamento] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaTipoAfastamento] - Exception: " + e.getMessage());
		}
	}
	
}