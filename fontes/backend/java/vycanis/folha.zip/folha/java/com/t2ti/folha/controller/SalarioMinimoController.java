package com.t2ti.folha.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.exception.ResourseNotFoundException;
import com.t2ti.folha.exception.BadRequestException;
import com.t2ti.folha.util.Filter;
import com.t2ti.folha.model.SalarioMinimoModel;
import com.t2ti.folha.service.SalarioMinimoService;

@RestController
@RequestMapping(value = "/salario-minimo", produces = "application/json;charset=UTF-8")
public class SalarioMinimoController {

	@Autowired
	private SalarioMinimoService service;
	
	@GetMapping({ "", "/" })
	public List<SalarioMinimoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [SalarioMinimo] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public SalarioMinimoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found SalarioMinimo].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found SalarioMinimo] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public SalarioMinimoModel insert(@RequestBody SalarioMinimoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert SalarioMinimo] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public SalarioMinimoModel update(@RequestBody SalarioMinimoModel objJson) {	
		try {			
			SalarioMinimoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update SalarioMinimo].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update SalarioMinimo] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SalarioMinimo] - Exception: " + e.getMessage());
		}
	}
	
}