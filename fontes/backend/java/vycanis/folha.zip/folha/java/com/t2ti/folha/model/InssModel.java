package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="inss")
@NamedQuery(name="InssModel.findAll", query="SELECT t FROM InssModel t")
public class InssModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public InssModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@OneToMany(mappedBy = "inssModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<SalarioFamiliaModel> salarioFamiliaModelList; 

	@OneToMany(mappedBy = "inssModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<InssDetalheModel> inssDetalheModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public Set<SalarioFamiliaModel> getSalarioFamiliaModelList() { 
	return this.salarioFamiliaModelList; 
	} 

	public void setSalarioFamiliaModelList(Set<SalarioFamiliaModel> salarioFamiliaModelList) { 
	this.salarioFamiliaModelList = salarioFamiliaModelList; 
		for (SalarioFamiliaModel salarioFamiliaModel : salarioFamiliaModelList) { 
			salarioFamiliaModel.setInssModel(this); 
		}
	} 

	public Set<InssDetalheModel> getInssDetalheModelList() { 
	return this.inssDetalheModelList; 
	} 

	public void setInssDetalheModelList(Set<InssDetalheModel> inssDetalheModelList) { 
	this.inssDetalheModelList = inssDetalheModelList; 
		for (InssDetalheModel inssDetalheModel : inssDetalheModelList) { 
			inssDetalheModel.setInssModel(this); 
		}
	} 

		
}