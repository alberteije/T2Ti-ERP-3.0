package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.InssModel;
import com.t2ti.folha.repository.InssRepository;

@Service
public class InssService {

	@Autowired
	private InssRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<InssModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<InssModel> getList(Filter filter) {
		String sql = "select * from inss where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, InssModel.class);
		return query.getResultList();
	}

	public InssModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public InssModel save(InssModel obj) {
		InssModel inssModel = repository.save(obj);
		return inssModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		InssModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Inss] - Exception: " + e.getMessage());
		}
	}

}