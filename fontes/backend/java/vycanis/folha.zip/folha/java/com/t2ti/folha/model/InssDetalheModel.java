package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="inss_detalhe")
@NamedQuery(name="InssDetalheModel.findAll", query="SELECT t FROM InssDetalheModel t")
public class InssDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public InssDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="faixa")
	private Integer faixa;

	@Column(name="de")
	private BigDecimal de;

	@Column(name="ate")
	private BigDecimal ate;

	@Column(name="taxa")
	private BigDecimal taxa;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_inss")
	private InssModel inssModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getFaixa() { 
		return this.faixa; 
	} 

	public void setFaixa(Integer faixa) { 
		this.faixa = faixa; 
	} 

	public BigDecimal getDe() { 
		return this.de; 
	} 

	public void setDe(BigDecimal de) { 
		this.de = de; 
	} 

	public BigDecimal getAte() { 
		return this.ate; 
	} 

	public void setAte(BigDecimal ate) { 
		this.ate = ate; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

	public InssModel getInssModel() { 
	return this.inssModel; 
	} 

	public void setInssModel(InssModel inssModel) { 
	this.inssModel = inssModel; 
	} 

		
}