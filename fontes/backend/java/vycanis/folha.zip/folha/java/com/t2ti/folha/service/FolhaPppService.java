package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaPppModel;
import com.t2ti.folha.repository.FolhaPppRepository;

@Service
public class FolhaPppService {

	@Autowired
	private FolhaPppRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaPppModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaPppModel> getList(Filter filter) {
		String sql = "select * from folha_ppp where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaPppModel.class);
		return query.getResultList();
	}

	public FolhaPppModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaPppModel save(FolhaPppModel obj) {
		FolhaPppModel folhaPppModel = repository.save(obj);
		return folhaPppModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaPppModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaPpp] - Exception: " + e.getMessage());
		}
	}

}