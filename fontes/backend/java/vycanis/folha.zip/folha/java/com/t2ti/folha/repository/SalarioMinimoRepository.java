package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.SalarioMinimoModel;

public interface SalarioMinimoRepository extends JpaRepository<SalarioMinimoModel, Integer> {}