package com.t2ti.folha.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.exception.ResourseNotFoundException;
import com.t2ti.folha.exception.BadRequestException;
import com.t2ti.folha.util.Filter;
import com.t2ti.folha.model.FolhaEventoModel;
import com.t2ti.folha.service.FolhaEventoService;

@RestController
@RequestMapping(value = "/folha-evento", produces = "application/json;charset=UTF-8")
public class FolhaEventoController {

	@Autowired
	private FolhaEventoService service;
	
	@GetMapping({ "", "/" })
	public List<FolhaEventoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [FolhaEvento] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public FolhaEventoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found FolhaEvento].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found FolhaEvento] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public FolhaEventoModel insert(@RequestBody FolhaEventoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert FolhaEvento] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public FolhaEventoModel update(@RequestBody FolhaEventoModel objJson) {	
		try {			
			FolhaEventoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update FolhaEvento].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update FolhaEvento] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaEvento] - Exception: " + e.getMessage());
		}
	}
	
}