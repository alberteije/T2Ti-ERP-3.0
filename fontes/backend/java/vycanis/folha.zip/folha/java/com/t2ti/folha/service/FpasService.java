package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FpasModel;
import com.t2ti.folha.repository.FpasRepository;

@Service
public class FpasService {

	@Autowired
	private FpasRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FpasModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FpasModel> getList(Filter filter) {
		String sql = "select * from fpas where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FpasModel.class);
		return query.getResultList();
	}

	public FpasModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FpasModel save(FpasModel obj) {
		FpasModel fpasModel = repository.save(obj);
		return fpasModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FpasModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Fpas] - Exception: " + e.getMessage());
		}
	}

}