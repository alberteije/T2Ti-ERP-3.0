package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaFechamentoModel;

public interface FolhaFechamentoRepository extends JpaRepository<FolhaFechamentoModel, Integer> {}