package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FeriasPeriodoAquisitivoModel;
import com.t2ti.folha.repository.FeriasPeriodoAquisitivoRepository;

@Service
public class FeriasPeriodoAquisitivoService {

	@Autowired
	private FeriasPeriodoAquisitivoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FeriasPeriodoAquisitivoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FeriasPeriodoAquisitivoModel> getList(Filter filter) {
		String sql = "select * from ferias_periodo_aquisitivo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FeriasPeriodoAquisitivoModel.class);
		return query.getResultList();
	}

	public FeriasPeriodoAquisitivoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FeriasPeriodoAquisitivoModel save(FeriasPeriodoAquisitivoModel obj) {
		FeriasPeriodoAquisitivoModel feriasPeriodoAquisitivoModel = repository.save(obj);
		return feriasPeriodoAquisitivoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FeriasPeriodoAquisitivoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FeriasPeriodoAquisitivo] - Exception: " + e.getMessage());
		}
	}

}