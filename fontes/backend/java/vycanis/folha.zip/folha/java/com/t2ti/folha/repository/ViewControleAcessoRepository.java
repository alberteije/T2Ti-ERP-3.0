package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.ViewControleAcessoModel;

public interface ViewControleAcessoRepository extends JpaRepository<ViewControleAcessoModel, Integer> {}