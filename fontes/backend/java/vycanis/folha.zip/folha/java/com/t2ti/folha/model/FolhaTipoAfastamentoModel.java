package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="folha_tipo_afastamento")
@NamedQuery(name="FolhaTipoAfastamentoModel.findAll", query="SELECT t FROM FolhaTipoAfastamentoModel t")
public class FolhaTipoAfastamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaTipoAfastamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@Column(name="codigo_esocial")
	private String codigoEsocial;

	@Column(name="descricao")
	private String descricao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getCodigoEsocial() { 
		return this.codigoEsocial; 
	} 

	public void setCodigoEsocial(String codigoEsocial) { 
		this.codigoEsocial = codigoEsocial; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

		
}