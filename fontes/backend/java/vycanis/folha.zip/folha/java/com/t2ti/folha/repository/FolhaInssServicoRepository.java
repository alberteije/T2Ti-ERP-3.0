package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FolhaInssServicoModel;

public interface FolhaInssServicoRepository extends JpaRepository<FolhaInssServicoModel, Integer> {}