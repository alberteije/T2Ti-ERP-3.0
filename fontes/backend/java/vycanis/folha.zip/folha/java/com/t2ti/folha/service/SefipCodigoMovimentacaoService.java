package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.SefipCodigoMovimentacaoModel;
import com.t2ti.folha.repository.SefipCodigoMovimentacaoRepository;

@Service
public class SefipCodigoMovimentacaoService {

	@Autowired
	private SefipCodigoMovimentacaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SefipCodigoMovimentacaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SefipCodigoMovimentacaoModel> getList(Filter filter) {
		String sql = "select * from sefip_codigo_movimentacao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SefipCodigoMovimentacaoModel.class);
		return query.getResultList();
	}

	public SefipCodigoMovimentacaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SefipCodigoMovimentacaoModel save(SefipCodigoMovimentacaoModel obj) {
		SefipCodigoMovimentacaoModel sefipCodigoMovimentacaoModel = repository.save(obj);
		return sefipCodigoMovimentacaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SefipCodigoMovimentacaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SefipCodigoMovimentacao] - Exception: " + e.getMessage());
		}
	}

}