package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FeriadosModel;

public interface FeriadosRepository extends JpaRepository<FeriadosModel, Integer> {}