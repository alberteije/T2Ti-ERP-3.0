package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.FpasModel;

public interface FpasRepository extends JpaRepository<FpasModel, Integer> {}