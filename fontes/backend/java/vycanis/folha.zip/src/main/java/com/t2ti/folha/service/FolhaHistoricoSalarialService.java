package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaHistoricoSalarialModel;
import com.t2ti.folha.repository.FolhaHistoricoSalarialRepository;

@Service
public class FolhaHistoricoSalarialService {

	@Autowired
	private FolhaHistoricoSalarialRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaHistoricoSalarialModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaHistoricoSalarialModel> getList(Filter filter) {
		String sql = "select * from folha_historico_salarial where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaHistoricoSalarialModel.class);
		return query.getResultList();
	}

	public FolhaHistoricoSalarialModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaHistoricoSalarialModel save(FolhaHistoricoSalarialModel obj) {
		FolhaHistoricoSalarialModel folhaHistoricoSalarialModel = repository.save(obj);
		return folhaHistoricoSalarialModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaHistoricoSalarialModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaHistoricoSalarial] - Exception: " + e.getMessage());
		}
	}

}