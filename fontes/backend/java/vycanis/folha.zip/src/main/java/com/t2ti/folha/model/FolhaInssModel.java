package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="folha_inss")
@NamedQuery(name="FolhaInssModel.findAll", query="SELECT t FROM FolhaInssModel t")
public class FolhaInssModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaInssModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@OneToMany(mappedBy = "folhaInssModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FolhaInssRetencaoModel> folhaInssRetencaoModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public Set<FolhaInssRetencaoModel> getFolhaInssRetencaoModelList() { 
	return this.folhaInssRetencaoModelList; 
	} 

	public void setFolhaInssRetencaoModelList(Set<FolhaInssRetencaoModel> folhaInssRetencaoModelList) { 
	this.folhaInssRetencaoModelList = folhaInssRetencaoModelList; 
		for (FolhaInssRetencaoModel folhaInssRetencaoModel : folhaInssRetencaoModelList) { 
			folhaInssRetencaoModel.setFolhaInssModel(this); 
		}
	} 

		
}