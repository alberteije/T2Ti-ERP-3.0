package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_ppp_atividade")
@NamedQuery(name="FolhaPppAtividadeModel.findAll", query="SELECT t FROM FolhaPppAtividadeModel t")
public class FolhaPppAtividadeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaPppAtividadeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Column(name="descricao")
	private String descricao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_folha_ppp")
	private FolhaPppModel folhaPppModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public FolhaPppModel getFolhaPppModel() { 
	return this.folhaPppModel; 
	} 

	public void setFolhaPppModel(FolhaPppModel folhaPppModel) { 
	this.folhaPppModel = folhaPppModel; 
	} 

		
}