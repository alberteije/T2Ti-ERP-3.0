package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.OperadoraPlanoSaudeModel;
import com.t2ti.folha.repository.OperadoraPlanoSaudeRepository;

@Service
public class OperadoraPlanoSaudeService {

	@Autowired
	private OperadoraPlanoSaudeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<OperadoraPlanoSaudeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<OperadoraPlanoSaudeModel> getList(Filter filter) {
		String sql = "select * from operadora_plano_saude where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, OperadoraPlanoSaudeModel.class);
		return query.getResultList();
	}

	public OperadoraPlanoSaudeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public OperadoraPlanoSaudeModel save(OperadoraPlanoSaudeModel obj) {
		OperadoraPlanoSaudeModel operadoraPlanoSaudeModel = repository.save(obj);
		return operadoraPlanoSaudeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		OperadoraPlanoSaudeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete OperadoraPlanoSaude] - Exception: " + e.getMessage());
		}
	}

}