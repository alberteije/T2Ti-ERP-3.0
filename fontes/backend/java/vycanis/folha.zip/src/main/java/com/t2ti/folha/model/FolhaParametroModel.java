package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="folha_parametro")
@NamedQuery(name="FolhaParametroModel.findAll", query="SELECT t FROM FolhaParametroModel t")
public class FolhaParametroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaParametroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="contribui_pis")
	private String contribuiPis;

	@Column(name="aliquota_pis")
	private BigDecimal aliquotaPis;

	@Column(name="discriminar_dsr")
	private String discriminarDsr;

	@Column(name="dia_pagamento")
	private String diaPagamento;

	@Column(name="calculo_proporcionalidade")
	private String calculoProporcionalidade;

	@Column(name="descontar_faltas_13")
	private String descontarFaltas13;

	@Column(name="pagar_adicionais_13")
	private String pagarAdicionais13;

	@Column(name="pagar_estagiarios_13")
	private String pagarEstagiarios13;

	@Column(name="mes_adiantamento_13")
	private String mesAdiantamento13;

	@Column(name="percentual_adiantam_13")
	private BigDecimal percentualAdiantam13;

	@Column(name="ferias_descontar_faltas")
	private String feriasDescontarFaltas;

	@Column(name="ferias_pagar_adicionais")
	private String feriasPagarAdicionais;

	@Column(name="ferias_adiantar_13")
	private String feriasAdiantar13;

	@Column(name="ferias_pagar_estagiarios")
	private String feriasPagarEstagiarios;

	@Column(name="ferias_calc_justa_causa")
	private String feriasCalcJustaCausa;

	@Column(name="ferias_movimento_mensal")
	private String feriasMovimentoMensal;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public String getContribuiPis() { 
		return this.contribuiPis; 
	} 

	public void setContribuiPis(String contribuiPis) { 
		this.contribuiPis = contribuiPis; 
	} 

	public BigDecimal getAliquotaPis() { 
		return this.aliquotaPis; 
	} 

	public void setAliquotaPis(BigDecimal aliquotaPis) { 
		this.aliquotaPis = aliquotaPis; 
	} 

	public String getDiscriminarDsr() { 
		return this.discriminarDsr; 
	} 

	public void setDiscriminarDsr(String discriminarDsr) { 
		this.discriminarDsr = discriminarDsr; 
	} 

	public String getDiaPagamento() { 
		return this.diaPagamento; 
	} 

	public void setDiaPagamento(String diaPagamento) { 
		this.diaPagamento = diaPagamento; 
	} 

	public String getCalculoProporcionalidade() { 
		return this.calculoProporcionalidade; 
	} 

	public void setCalculoProporcionalidade(String calculoProporcionalidade) { 
		this.calculoProporcionalidade = calculoProporcionalidade; 
	} 

	public String getDescontarFaltas13() { 
		return this.descontarFaltas13; 
	} 

	public void setDescontarFaltas13(String descontarFaltas13) { 
		this.descontarFaltas13 = descontarFaltas13; 
	} 

	public String getPagarAdicionais13() { 
		return this.pagarAdicionais13; 
	} 

	public void setPagarAdicionais13(String pagarAdicionais13) { 
		this.pagarAdicionais13 = pagarAdicionais13; 
	} 

	public String getPagarEstagiarios13() { 
		return this.pagarEstagiarios13; 
	} 

	public void setPagarEstagiarios13(String pagarEstagiarios13) { 
		this.pagarEstagiarios13 = pagarEstagiarios13; 
	} 

	public String getMesAdiantamento13() { 
		return this.mesAdiantamento13; 
	} 

	public void setMesAdiantamento13(String mesAdiantamento13) { 
		this.mesAdiantamento13 = mesAdiantamento13; 
	} 

	public BigDecimal getPercentualAdiantam13() { 
		return this.percentualAdiantam13; 
	} 

	public void setPercentualAdiantam13(BigDecimal percentualAdiantam13) { 
		this.percentualAdiantam13 = percentualAdiantam13; 
	} 

	public String getFeriasDescontarFaltas() { 
		return this.feriasDescontarFaltas; 
	} 

	public void setFeriasDescontarFaltas(String feriasDescontarFaltas) { 
		this.feriasDescontarFaltas = feriasDescontarFaltas; 
	} 

	public String getFeriasPagarAdicionais() { 
		return this.feriasPagarAdicionais; 
	} 

	public void setFeriasPagarAdicionais(String feriasPagarAdicionais) { 
		this.feriasPagarAdicionais = feriasPagarAdicionais; 
	} 

	public String getFeriasAdiantar13() { 
		return this.feriasAdiantar13; 
	} 

	public void setFeriasAdiantar13(String feriasAdiantar13) { 
		this.feriasAdiantar13 = feriasAdiantar13; 
	} 

	public String getFeriasPagarEstagiarios() { 
		return this.feriasPagarEstagiarios; 
	} 

	public void setFeriasPagarEstagiarios(String feriasPagarEstagiarios) { 
		this.feriasPagarEstagiarios = feriasPagarEstagiarios; 
	} 

	public String getFeriasCalcJustaCausa() { 
		return this.feriasCalcJustaCausa; 
	} 

	public void setFeriasCalcJustaCausa(String feriasCalcJustaCausa) { 
		this.feriasCalcJustaCausa = feriasCalcJustaCausa; 
	} 

	public String getFeriasMovimentoMensal() { 
		return this.feriasMovimentoMensal; 
	} 

	public void setFeriasMovimentoMensal(String feriasMovimentoMensal) { 
		this.feriasMovimentoMensal = feriasMovimentoMensal; 
	} 

		
}