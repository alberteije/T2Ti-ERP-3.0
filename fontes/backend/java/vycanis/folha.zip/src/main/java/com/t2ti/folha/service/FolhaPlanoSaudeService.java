package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaPlanoSaudeModel;
import com.t2ti.folha.repository.FolhaPlanoSaudeRepository;

@Service
public class FolhaPlanoSaudeService {

	@Autowired
	private FolhaPlanoSaudeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaPlanoSaudeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaPlanoSaudeModel> getList(Filter filter) {
		String sql = "select * from folha_plano_saude where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaPlanoSaudeModel.class);
		return query.getResultList();
	}

	public FolhaPlanoSaudeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaPlanoSaudeModel save(FolhaPlanoSaudeModel obj) {
		FolhaPlanoSaudeModel folhaPlanoSaudeModel = repository.save(obj);
		return folhaPlanoSaudeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaPlanoSaudeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaPlanoSaude] - Exception: " + e.getMessage());
		}
	}

}