package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_lancamento_comissao")
@NamedQuery(name="FolhaLancamentoComissaoModel.findAll", query="SELECT t FROM FolhaLancamentoComissaoModel t")
public class FolhaLancamentoComissaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaLancamentoComissaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Temporal(TemporalType.DATE)
@Column(name="vencimento")
	private Date vencimento;

	@Column(name="base_calculo")
	private BigDecimal baseCalculo;

	@Column(name="valor_comissao")
	private BigDecimal valorComissao;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public Date getVencimento() { 
		return this.vencimento; 
	} 

	public void setVencimento(Date vencimento) { 
		this.vencimento = vencimento; 
	} 

	public BigDecimal getBaseCalculo() { 
		return this.baseCalculo; 
	} 

	public void setBaseCalculo(BigDecimal baseCalculo) { 
		this.baseCalculo = baseCalculo; 
	} 

	public BigDecimal getValorComissao() { 
		return this.valorComissao; 
	} 

	public void setValorComissao(BigDecimal valorComissao) { 
		this.valorComissao = valorComissao; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}