package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaAfastamentoModel;
import com.t2ti.folha.repository.FolhaAfastamentoRepository;

@Service
public class FolhaAfastamentoService {

	@Autowired
	private FolhaAfastamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaAfastamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaAfastamentoModel> getList(Filter filter) {
		String sql = "select * from folha_afastamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaAfastamentoModel.class);
		return query.getResultList();
	}

	public FolhaAfastamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaAfastamentoModel save(FolhaAfastamentoModel obj) {
		FolhaAfastamentoModel folhaAfastamentoModel = repository.save(obj);
		return folhaAfastamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaAfastamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaAfastamento] - Exception: " + e.getMessage());
		}
	}

}