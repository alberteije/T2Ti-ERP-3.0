package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaEventoModel;
import com.t2ti.folha.repository.FolhaEventoRepository;

@Service
public class FolhaEventoService {

	@Autowired
	private FolhaEventoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaEventoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaEventoModel> getList(Filter filter) {
		String sql = "select * from folha_evento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaEventoModel.class);
		return query.getResultList();
	}

	public FolhaEventoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaEventoModel save(FolhaEventoModel obj) {
		FolhaEventoModel folhaEventoModel = repository.save(obj);
		return folhaEventoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaEventoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaEvento] - Exception: " + e.getMessage());
		}
	}

}