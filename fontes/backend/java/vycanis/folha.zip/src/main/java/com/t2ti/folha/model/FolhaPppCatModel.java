package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_ppp_cat")
@NamedQuery(name="FolhaPppCatModel.findAll", query="SELECT t FROM FolhaPppCatModel t")
public class FolhaPppCatModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaPppCatModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero_cat")
	private Integer numeroCat;

	@Temporal(TemporalType.DATE)
@Column(name="data_afastamento")
	private Date dataAfastamento;

	@Temporal(TemporalType.DATE)
@Column(name="data_registro")
	private Date dataRegistro;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_folha_ppp")
	private FolhaPppModel folhaPppModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumeroCat() { 
		return this.numeroCat; 
	} 

	public void setNumeroCat(Integer numeroCat) { 
		this.numeroCat = numeroCat; 
	} 

	public Date getDataAfastamento() { 
		return this.dataAfastamento; 
	} 

	public void setDataAfastamento(Date dataAfastamento) { 
		this.dataAfastamento = dataAfastamento; 
	} 

	public Date getDataRegistro() { 
		return this.dataRegistro; 
	} 

	public void setDataRegistro(Date dataRegistro) { 
		this.dataRegistro = dataRegistro; 
	} 

	public FolhaPppModel getFolhaPppModel() { 
	return this.folhaPppModel; 
	} 

	public void setFolhaPppModel(FolhaPppModel folhaPppModel) { 
	this.folhaPppModel = folhaPppModel; 
	} 

		
}