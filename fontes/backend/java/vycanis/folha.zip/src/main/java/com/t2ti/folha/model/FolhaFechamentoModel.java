package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="folha_fechamento")
@NamedQuery(name="FolhaFechamentoModel.findAll", query="SELECT t FROM FolhaFechamentoModel t")
public class FolhaFechamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaFechamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="fechamento_atual")
	private String fechamentoAtual;

	@Column(name="proximo_fechamento")
	private String proximoFechamento;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getFechamentoAtual() { 
		return this.fechamentoAtual; 
	} 

	public void setFechamentoAtual(String fechamentoAtual) { 
		this.fechamentoAtual = fechamentoAtual; 
	} 

	public String getProximoFechamento() { 
		return this.proximoFechamento; 
	} 

	public void setProximoFechamento(String proximoFechamento) { 
		this.proximoFechamento = proximoFechamento; 
	} 

		
}