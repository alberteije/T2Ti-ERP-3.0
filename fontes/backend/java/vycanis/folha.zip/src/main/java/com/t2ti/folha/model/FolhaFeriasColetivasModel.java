package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="folha_ferias_coletivas")
@NamedQuery(name="FolhaFeriasColetivasModel.findAll", query="SELECT t FROM FolhaFeriasColetivasModel t")
public class FolhaFeriasColetivasModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaFeriasColetivasModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Column(name="dias_gozo")
	private Integer diasGozo;

	@Temporal(TemporalType.DATE)
@Column(name="abono_pecuniario_inicio")
	private Date abonoPecuniarioInicio;

	@Temporal(TemporalType.DATE)
@Column(name="abono_pecuniario_fim")
	private Date abonoPecuniarioFim;

	@Column(name="dias_abono")
	private Integer diasAbono;

	@Temporal(TemporalType.DATE)
@Column(name="data_pagamento")
	private Date dataPagamento;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public Integer getDiasGozo() { 
		return this.diasGozo; 
	} 

	public void setDiasGozo(Integer diasGozo) { 
		this.diasGozo = diasGozo; 
	} 

	public Date getAbonoPecuniarioInicio() { 
		return this.abonoPecuniarioInicio; 
	} 

	public void setAbonoPecuniarioInicio(Date abonoPecuniarioInicio) { 
		this.abonoPecuniarioInicio = abonoPecuniarioInicio; 
	} 

	public Date getAbonoPecuniarioFim() { 
		return this.abonoPecuniarioFim; 
	} 

	public void setAbonoPecuniarioFim(Date abonoPecuniarioFim) { 
		this.abonoPecuniarioFim = abonoPecuniarioFim; 
	} 

	public Integer getDiasAbono() { 
		return this.diasAbono; 
	} 

	public void setDiasAbono(Integer diasAbono) { 
		this.diasAbono = diasAbono; 
	} 

	public Date getDataPagamento() { 
		return this.dataPagamento; 
	} 

	public void setDataPagamento(Date dataPagamento) { 
		this.dataPagamento = dataPagamento; 
	} 

		
}