package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_ppp_fator_risco")
@NamedQuery(name="FolhaPppFatorRiscoModel.findAll", query="SELECT t FROM FolhaPppFatorRiscoModel t")
public class FolhaPppFatorRiscoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaPppFatorRiscoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Column(name="tipo")
	private String tipo;

	@Column(name="fator_risco")
	private String fatorRisco;

	@Column(name="intensidade")
	private String intensidade;

	@Column(name="tecnica_utilizada")
	private String tecnicaUtilizada;

	@Column(name="epc_eficaz")
	private String epcEficaz;

	@Column(name="epi_eficaz")
	private String epiEficaz;

	@Column(name="ca_epi")
	private Integer caEpi;

	@Column(name="atendimento_nr06_1")
	private String atendimentoNr061;

	@Column(name="atendimento_nr06_2")
	private String atendimentoNr062;

	@Column(name="atendimento_nr06_3")
	private String atendimentoNr063;

	@Column(name="atendimento_nr06_4")
	private String atendimentoNr064;

	@Column(name="atendimento_nr06_5")
	private String atendimentoNr065;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_folha_ppp")
	private FolhaPppModel folhaPppModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getFatorRisco() { 
		return this.fatorRisco; 
	} 

	public void setFatorRisco(String fatorRisco) { 
		this.fatorRisco = fatorRisco; 
	} 

	public String getIntensidade() { 
		return this.intensidade; 
	} 

	public void setIntensidade(String intensidade) { 
		this.intensidade = intensidade; 
	} 

	public String getTecnicaUtilizada() { 
		return this.tecnicaUtilizada; 
	} 

	public void setTecnicaUtilizada(String tecnicaUtilizada) { 
		this.tecnicaUtilizada = tecnicaUtilizada; 
	} 

	public String getEpcEficaz() { 
		return this.epcEficaz; 
	} 

	public void setEpcEficaz(String epcEficaz) { 
		this.epcEficaz = epcEficaz; 
	} 

	public String getEpiEficaz() { 
		return this.epiEficaz; 
	} 

	public void setEpiEficaz(String epiEficaz) { 
		this.epiEficaz = epiEficaz; 
	} 

	public Integer getCaEpi() { 
		return this.caEpi; 
	} 

	public void setCaEpi(Integer caEpi) { 
		this.caEpi = caEpi; 
	} 

	public String getAtendimentoNr061() { 
		return this.atendimentoNr061; 
	} 

	public void setAtendimentoNr061(String atendimentoNr061) { 
		this.atendimentoNr061 = atendimentoNr061; 
	} 

	public String getAtendimentoNr062() { 
		return this.atendimentoNr062; 
	} 

	public void setAtendimentoNr062(String atendimentoNr062) { 
		this.atendimentoNr062 = atendimentoNr062; 
	} 

	public String getAtendimentoNr063() { 
		return this.atendimentoNr063; 
	} 

	public void setAtendimentoNr063(String atendimentoNr063) { 
		this.atendimentoNr063 = atendimentoNr063; 
	} 

	public String getAtendimentoNr064() { 
		return this.atendimentoNr064; 
	} 

	public void setAtendimentoNr064(String atendimentoNr064) { 
		this.atendimentoNr064 = atendimentoNr064; 
	} 

	public String getAtendimentoNr065() { 
		return this.atendimentoNr065; 
	} 

	public void setAtendimentoNr065(String atendimentoNr065) { 
		this.atendimentoNr065 = atendimentoNr065; 
	} 

	public FolhaPppModel getFolhaPppModel() { 
	return this.folhaPppModel; 
	} 

	public void setFolhaPppModel(FolhaPppModel folhaPppModel) { 
	this.folhaPppModel = folhaPppModel; 
	} 

		
}