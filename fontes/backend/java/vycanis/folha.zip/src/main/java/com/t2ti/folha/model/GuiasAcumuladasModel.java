package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="guias_acumuladas")
@NamedQuery(name="GuiasAcumuladasModel.findAll", query="SELECT t FROM GuiasAcumuladasModel t")
public class GuiasAcumuladasModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GuiasAcumuladasModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="gps_tipo")
	private String gpsTipo;

	@Column(name="gps_competencia")
	private String gpsCompetencia;

	@Column(name="gps_valor_inss")
	private BigDecimal gpsValorInss;

	@Column(name="gps_valor_outras_ent")
	private BigDecimal gpsValorOutrasEnt;

	@Temporal(TemporalType.DATE)
@Column(name="gps_data_pagamento")
	private Date gpsDataPagamento;

	@Column(name="irrf_competencia")
	private String irrfCompetencia;

	@Column(name="irrf_codigo_recolhimento")
	private Integer irrfCodigoRecolhimento;

	@Column(name="irrf_valor_acumulado")
	private BigDecimal irrfValorAcumulado;

	@Temporal(TemporalType.DATE)
@Column(name="irrf_data_pagamento")
	private Date irrfDataPagamento;

	@Column(name="pis_competencia")
	private String pisCompetencia;

	@Column(name="pis_valor_acumulado")
	private BigDecimal pisValorAcumulado;

	@Temporal(TemporalType.DATE)
@Column(name="pis_data_pagamento")
	private Date pisDataPagamento;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getGpsTipo() { 
		return this.gpsTipo; 
	} 

	public void setGpsTipo(String gpsTipo) { 
		this.gpsTipo = gpsTipo; 
	} 

	public String getGpsCompetencia() { 
		return this.gpsCompetencia; 
	} 

	public void setGpsCompetencia(String gpsCompetencia) { 
		this.gpsCompetencia = gpsCompetencia; 
	} 

	public BigDecimal getGpsValorInss() { 
		return this.gpsValorInss; 
	} 

	public void setGpsValorInss(BigDecimal gpsValorInss) { 
		this.gpsValorInss = gpsValorInss; 
	} 

	public BigDecimal getGpsValorOutrasEnt() { 
		return this.gpsValorOutrasEnt; 
	} 

	public void setGpsValorOutrasEnt(BigDecimal gpsValorOutrasEnt) { 
		this.gpsValorOutrasEnt = gpsValorOutrasEnt; 
	} 

	public Date getGpsDataPagamento() { 
		return this.gpsDataPagamento; 
	} 

	public void setGpsDataPagamento(Date gpsDataPagamento) { 
		this.gpsDataPagamento = gpsDataPagamento; 
	} 

	public String getIrrfCompetencia() { 
		return this.irrfCompetencia; 
	} 

	public void setIrrfCompetencia(String irrfCompetencia) { 
		this.irrfCompetencia = irrfCompetencia; 
	} 

	public Integer getIrrfCodigoRecolhimento() { 
		return this.irrfCodigoRecolhimento; 
	} 

	public void setIrrfCodigoRecolhimento(Integer irrfCodigoRecolhimento) { 
		this.irrfCodigoRecolhimento = irrfCodigoRecolhimento; 
	} 

	public BigDecimal getIrrfValorAcumulado() { 
		return this.irrfValorAcumulado; 
	} 

	public void setIrrfValorAcumulado(BigDecimal irrfValorAcumulado) { 
		this.irrfValorAcumulado = irrfValorAcumulado; 
	} 

	public Date getIrrfDataPagamento() { 
		return this.irrfDataPagamento; 
	} 

	public void setIrrfDataPagamento(Date irrfDataPagamento) { 
		this.irrfDataPagamento = irrfDataPagamento; 
	} 

	public String getPisCompetencia() { 
		return this.pisCompetencia; 
	} 

	public void setPisCompetencia(String pisCompetencia) { 
		this.pisCompetencia = pisCompetencia; 
	} 

	public BigDecimal getPisValorAcumulado() { 
		return this.pisValorAcumulado; 
	} 

	public void setPisValorAcumulado(BigDecimal pisValorAcumulado) { 
		this.pisValorAcumulado = pisValorAcumulado; 
	} 

	public Date getPisDataPagamento() { 
		return this.pisDataPagamento; 
	} 

	public void setPisDataPagamento(Date pisDataPagamento) { 
		this.pisDataPagamento = pisDataPagamento; 
	} 

		
}