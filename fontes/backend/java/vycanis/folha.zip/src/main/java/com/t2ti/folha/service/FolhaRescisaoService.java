package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.FolhaRescisaoModel;
import com.t2ti.folha.repository.FolhaRescisaoRepository;

@Service
public class FolhaRescisaoService {

	@Autowired
	private FolhaRescisaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FolhaRescisaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FolhaRescisaoModel> getList(Filter filter) {
		String sql = "select * from folha_rescisao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FolhaRescisaoModel.class);
		return query.getResultList();
	}

	public FolhaRescisaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FolhaRescisaoModel save(FolhaRescisaoModel obj) {
		FolhaRescisaoModel folhaRescisaoModel = repository.save(obj);
		return folhaRescisaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FolhaRescisaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FolhaRescisao] - Exception: " + e.getMessage());
		}
	}

}