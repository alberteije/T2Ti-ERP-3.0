package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="folha_evento")
@NamedQuery(name="FolhaEventoModel.findAll", query="SELECT t FROM FolhaEventoModel t")
public class FolhaEventoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaEventoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="base_calculo")
	private String baseCalculo;

	@Column(name="tipo")
	private String tipo;

	@Column(name="unidade")
	private String unidade;

	@Column(name="taxa")
	private BigDecimal taxa;

	@Column(name="rubrica_esocial")
	private String rubricaEsocial;

	@Column(name="cod_incidencia_previdencia")
	private String codIncidenciaPrevidencia;

	@Column(name="cod_incidencia_irrf")
	private String codIncidenciaIrrf;

	@Column(name="cod_incidencia_fgts")
	private String codIncidenciaFgts;

	@Column(name="cod_incidencia_sindicato")
	private String codIncidenciaSindicato;

	@Column(name="repercute_dsr")
	private String repercuteDsr;

	@Column(name="repercute_13")
	private String repercute13;

	@Column(name="repercute_ferias")
	private String repercuteFerias;

	@Column(name="repercute_aviso")
	private String repercuteAviso;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getBaseCalculo() { 
		return this.baseCalculo; 
	} 

	public void setBaseCalculo(String baseCalculo) { 
		this.baseCalculo = baseCalculo; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getUnidade() { 
		return this.unidade; 
	} 

	public void setUnidade(String unidade) { 
		this.unidade = unidade; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

	public String getRubricaEsocial() { 
		return this.rubricaEsocial; 
	} 

	public void setRubricaEsocial(String rubricaEsocial) { 
		this.rubricaEsocial = rubricaEsocial; 
	} 

	public String getCodIncidenciaPrevidencia() { 
		return this.codIncidenciaPrevidencia; 
	} 

	public void setCodIncidenciaPrevidencia(String codIncidenciaPrevidencia) { 
		this.codIncidenciaPrevidencia = codIncidenciaPrevidencia; 
	} 

	public String getCodIncidenciaIrrf() { 
		return this.codIncidenciaIrrf; 
	} 

	public void setCodIncidenciaIrrf(String codIncidenciaIrrf) { 
		this.codIncidenciaIrrf = codIncidenciaIrrf; 
	} 

	public String getCodIncidenciaFgts() { 
		return this.codIncidenciaFgts; 
	} 

	public void setCodIncidenciaFgts(String codIncidenciaFgts) { 
		this.codIncidenciaFgts = codIncidenciaFgts; 
	} 

	public String getCodIncidenciaSindicato() { 
		return this.codIncidenciaSindicato; 
	} 

	public void setCodIncidenciaSindicato(String codIncidenciaSindicato) { 
		this.codIncidenciaSindicato = codIncidenciaSindicato; 
	} 

	public String getRepercuteDsr() { 
		return this.repercuteDsr; 
	} 

	public void setRepercuteDsr(String repercuteDsr) { 
		this.repercuteDsr = repercuteDsr; 
	} 

	public String getRepercute13() { 
		return this.repercute13; 
	} 

	public void setRepercute13(String repercute13) { 
		this.repercute13 = repercute13; 
	} 

	public String getRepercuteFerias() { 
		return this.repercuteFerias; 
	} 

	public void setRepercuteFerias(String repercuteFerias) { 
		this.repercuteFerias = repercuteFerias; 
	} 

	public String getRepercuteAviso() { 
		return this.repercuteAviso; 
	} 

	public void setRepercuteAviso(String repercuteAviso) { 
		this.repercuteAviso = repercuteAviso; 
	} 

		
}