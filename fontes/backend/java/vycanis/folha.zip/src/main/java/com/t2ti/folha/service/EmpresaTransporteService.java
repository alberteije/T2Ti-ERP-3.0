package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.EmpresaTransporteModel;
import com.t2ti.folha.repository.EmpresaTransporteRepository;

@Service
public class EmpresaTransporteService {

	@Autowired
	private EmpresaTransporteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EmpresaTransporteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EmpresaTransporteModel> getList(Filter filter) {
		String sql = "select * from empresa_transporte where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EmpresaTransporteModel.class);
		return query.getResultList();
	}

	public EmpresaTransporteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EmpresaTransporteModel save(EmpresaTransporteModel obj) {
		EmpresaTransporteModel empresaTransporteModel = repository.save(obj);
		return empresaTransporteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EmpresaTransporteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EmpresaTransporte] - Exception: " + e.getMessage());
		}
	}

}