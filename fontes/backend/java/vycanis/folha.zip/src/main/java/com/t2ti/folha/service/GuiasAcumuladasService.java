package com.t2ti.folha.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.folha.util.Filter;
import com.t2ti.folha.exception.GenericException;
import com.t2ti.folha.model.GuiasAcumuladasModel;
import com.t2ti.folha.repository.GuiasAcumuladasRepository;

@Service
public class GuiasAcumuladasService {

	@Autowired
	private GuiasAcumuladasRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<GuiasAcumuladasModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<GuiasAcumuladasModel> getList(Filter filter) {
		String sql = "select * from guias_acumuladas where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, GuiasAcumuladasModel.class);
		return query.getResultList();
	}

	public GuiasAcumuladasModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public GuiasAcumuladasModel save(GuiasAcumuladasModel obj) {
		GuiasAcumuladasModel guiasAcumuladasModel = repository.save(obj);
		return guiasAcumuladasModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		GuiasAcumuladasModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete GuiasAcumuladas] - Exception: " + e.getMessage());
		}
	}

}