package com.t2ti.folha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.folha.model.GuiasAcumuladasModel;

public interface GuiasAcumuladasRepository extends JpaRepository<GuiasAcumuladasModel, Integer> {}