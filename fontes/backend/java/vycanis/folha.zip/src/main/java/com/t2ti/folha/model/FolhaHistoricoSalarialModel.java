package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_historico_salarial")
@NamedQuery(name="FolhaHistoricoSalarialModel.findAll", query="SELECT t FROM FolhaHistoricoSalarialModel t")
public class FolhaHistoricoSalarialModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaHistoricoSalarialModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="salario_atual")
	private BigDecimal salarioAtual;

	@Column(name="percentual_aumento")
	private BigDecimal percentualAumento;

	@Column(name="salario_novo")
	private BigDecimal salarioNovo;

	@Column(name="valido_a_partir")
	private String validoAPartir;

	@Column(name="motivo")
	private String motivo;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public BigDecimal getSalarioAtual() { 
		return this.salarioAtual; 
	} 

	public void setSalarioAtual(BigDecimal salarioAtual) { 
		this.salarioAtual = salarioAtual; 
	} 

	public BigDecimal getPercentualAumento() { 
		return this.percentualAumento; 
	} 

	public void setPercentualAumento(BigDecimal percentualAumento) { 
		this.percentualAumento = percentualAumento; 
	} 

	public BigDecimal getSalarioNovo() { 
		return this.salarioNovo; 
	} 

	public void setSalarioNovo(BigDecimal salarioNovo) { 
		this.salarioNovo = salarioNovo; 
	} 

	public String getValidoAPartir() { 
		return this.validoAPartir; 
	} 

	public void setValidoAPartir(String validoAPartir) { 
		this.validoAPartir = validoAPartir; 
	} 

	public String getMotivo() { 
		return this.motivo; 
	} 

	public void setMotivo(String motivo) { 
		this.motivo = motivo; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}