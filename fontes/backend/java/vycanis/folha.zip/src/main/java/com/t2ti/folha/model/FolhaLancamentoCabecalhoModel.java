package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_lancamento_cabecalho")
@NamedQuery(name="FolhaLancamentoCabecalhoModel.findAll", query="SELECT t FROM FolhaLancamentoCabecalhoModel t")
public class FolhaLancamentoCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaLancamentoCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="tipo")
	private String tipo;

	@OneToMany(mappedBy = "folhaLancamentoCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FolhaLancamentoDetalheModel> folhaLancamentoDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public Set<FolhaLancamentoDetalheModel> getFolhaLancamentoDetalheModelList() { 
	return this.folhaLancamentoDetalheModelList; 
	} 

	public void setFolhaLancamentoDetalheModelList(Set<FolhaLancamentoDetalheModel> folhaLancamentoDetalheModelList) { 
	this.folhaLancamentoDetalheModelList = folhaLancamentoDetalheModelList; 
		for (FolhaLancamentoDetalheModel folhaLancamentoDetalheModel : folhaLancamentoDetalheModelList) { 
			folhaLancamentoDetalheModel.setFolhaLancamentoCabecalhoModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}