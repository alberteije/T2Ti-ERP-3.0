package com.t2ti.folha.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="folha_vale_transporte")
@NamedQuery(name="FolhaValeTransporteModel.findAll", query="SELECT t FROM FolhaValeTransporteModel t")
public class FolhaValeTransporteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FolhaValeTransporteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private Integer quantidade;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_empresa_transp_itin")
	private EmpresaTransporteItinerarioModel empresaTransporteItinerarioModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public EmpresaTransporteItinerarioModel getEmpresaTransporteItinerarioModel() { 
	return this.empresaTransporteItinerarioModel; 
	} 

	public void setEmpresaTransporteItinerarioModel(EmpresaTransporteItinerarioModel empresaTransporteItinerarioModel) { 
	this.empresaTransporteItinerarioModel = empresaTransporteItinerarioModel; 
	} 

		
}