package com.t2ti.vendas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.vendas.util.Filter;
import com.t2ti.vendas.exception.GenericException;
import com.t2ti.vendas.model.VendaCondicoesPagamentoModel;
import com.t2ti.vendas.repository.VendaCondicoesPagamentoRepository;

@Service
public class VendaCondicoesPagamentoService {

	@Autowired
	private VendaCondicoesPagamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<VendaCondicoesPagamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<VendaCondicoesPagamentoModel> getList(Filter filter) {
		String sql = "select * from venda_condicoes_pagamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, VendaCondicoesPagamentoModel.class);
		return query.getResultList();
	}

	public VendaCondicoesPagamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public VendaCondicoesPagamentoModel save(VendaCondicoesPagamentoModel obj) {
		VendaCondicoesPagamentoModel vendaCondicoesPagamentoModel = repository.save(obj);
		return vendaCondicoesPagamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		VendaCondicoesPagamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete VendaCondicoesPagamento] - Exception: " + e.getMessage());
		}
	}

}