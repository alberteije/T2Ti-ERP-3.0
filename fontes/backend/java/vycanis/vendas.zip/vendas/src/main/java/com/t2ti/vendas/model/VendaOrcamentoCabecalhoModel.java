package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="venda_orcamento_cabecalho")
@NamedQuery(name="VendaOrcamentoCabecalhoModel.findAll", query="SELECT t FROM VendaOrcamentoCabecalhoModel t")
public class VendaOrcamentoCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaOrcamentoCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo_frete")
	private String tipoFrete;

	@Column(name="codigo")
	private String codigo;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
@Column(name="data_entrega")
	private Date dataEntrega;

	@Temporal(TemporalType.DATE)
@Column(name="data_validade")
	private Date dataValidade;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@Column(name="taxa_comissao")
	private BigDecimal taxaComissao;

	@Column(name="valor_comissao")
	private BigDecimal valorComissao;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="observacao")
	private String observacao;

	@OneToMany(mappedBy = "vendaOrcamentoCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<VendaOrcamentoDetalheModel> vendaOrcamentoDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_venda_condicoes_pagamento")
	private VendaCondicoesPagamentoModel vendaCondicoesPagamentoModel; 

	@ManyToOne 
	@JoinColumn(name="id_vendedor")
	private ViewPessoaVendedorModel viewPessoaVendedorModel; 

	@ManyToOne 
	@JoinColumn(name="id_transportadora")
	private ViewPessoaTransportadoraModel viewPessoaTransportadoraModel; 

	@ManyToOne 
	@JoinColumn(name="id_cliente")
	private ViewPessoaClienteModel viewPessoaClienteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipoFrete() { 
		return this.tipoFrete; 
	} 

	public void setTipoFrete(String tipoFrete) { 
		this.tipoFrete = tipoFrete; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public Date getDataEntrega() { 
		return this.dataEntrega; 
	} 

	public void setDataEntrega(Date dataEntrega) { 
		this.dataEntrega = dataEntrega; 
	} 

	public Date getDataValidade() { 
		return this.dataValidade; 
	} 

	public void setDataValidade(Date dataValidade) { 
		this.dataValidade = dataValidade; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public BigDecimal getTaxaComissao() { 
		return this.taxaComissao; 
	} 

	public void setTaxaComissao(BigDecimal taxaComissao) { 
		this.taxaComissao = taxaComissao; 
	} 

	public BigDecimal getValorComissao() { 
		return this.valorComissao; 
	} 

	public void setValorComissao(BigDecimal valorComissao) { 
		this.valorComissao = valorComissao; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Set<VendaOrcamentoDetalheModel> getVendaOrcamentoDetalheModelList() { 
	return this.vendaOrcamentoDetalheModelList; 
	} 

	public void setVendaOrcamentoDetalheModelList(Set<VendaOrcamentoDetalheModel> vendaOrcamentoDetalheModelList) { 
	this.vendaOrcamentoDetalheModelList = vendaOrcamentoDetalheModelList; 
		for (VendaOrcamentoDetalheModel vendaOrcamentoDetalheModel : vendaOrcamentoDetalheModelList) { 
			vendaOrcamentoDetalheModel.setVendaOrcamentoCabecalhoModel(this); 
		}
	} 

	public VendaCondicoesPagamentoModel getVendaCondicoesPagamentoModel() { 
	return this.vendaCondicoesPagamentoModel; 
	} 

	public void setVendaCondicoesPagamentoModel(VendaCondicoesPagamentoModel vendaCondicoesPagamentoModel) { 
	this.vendaCondicoesPagamentoModel = vendaCondicoesPagamentoModel; 
	} 

	public ViewPessoaVendedorModel getViewPessoaVendedorModel() { 
	return this.viewPessoaVendedorModel; 
	} 

	public void setViewPessoaVendedorModel(ViewPessoaVendedorModel viewPessoaVendedorModel) { 
	this.viewPessoaVendedorModel = viewPessoaVendedorModel; 
	} 

	public ViewPessoaTransportadoraModel getViewPessoaTransportadoraModel() { 
	return this.viewPessoaTransportadoraModel; 
	} 

	public void setViewPessoaTransportadoraModel(ViewPessoaTransportadoraModel viewPessoaTransportadoraModel) { 
	this.viewPessoaTransportadoraModel = viewPessoaTransportadoraModel; 
	} 

	public ViewPessoaClienteModel getViewPessoaClienteModel() { 
	return this.viewPessoaClienteModel; 
	} 

	public void setViewPessoaClienteModel(ViewPessoaClienteModel viewPessoaClienteModel) { 
	this.viewPessoaClienteModel = viewPessoaClienteModel; 
	} 

		
}