package com.t2ti.vendas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.vendas.model.VendaOrcamentoCabecalhoModel;

public interface VendaOrcamentoCabecalhoRepository extends JpaRepository<VendaOrcamentoCabecalhoModel, Integer> {}