package com.t2ti.vendas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.vendas.util.Filter;
import com.t2ti.vendas.exception.GenericException;
import com.t2ti.vendas.model.ProdutoMarcaModel;
import com.t2ti.vendas.repository.ProdutoMarcaRepository;

@Service
public class ProdutoMarcaService {

	@Autowired
	private ProdutoMarcaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ProdutoMarcaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ProdutoMarcaModel> getList(Filter filter) {
		String sql = "select * from produto_marca where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ProdutoMarcaModel.class);
		return query.getResultList();
	}

	public ProdutoMarcaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ProdutoMarcaModel save(ProdutoMarcaModel obj) {
		ProdutoMarcaModel produtoMarcaModel = repository.save(obj);
		return produtoMarcaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ProdutoMarcaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ProdutoMarca] - Exception: " + e.getMessage());
		}
	}

}