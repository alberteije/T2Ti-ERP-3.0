package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.OneToOne;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="venda_comissao")
@NamedQuery(name="VendaComissaoModel.findAll", query="SELECT t FROM VendaComissaoModel t")
public class VendaComissaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaComissaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor_venda")
	private BigDecimal valorVenda;

	@Column(name="tipo_contabil")
	private String tipoContabil;

	@Column(name="valor_comissao")
	private BigDecimal valorComissao;

	@Column(name="situacao")
	private String situacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_lancamento")
	private Date dataLancamento;

	@OneToOne 
	@JsonIgnore 
	@JoinColumn(name="id_venda_cabecalho")
	private VendaCabecalhoModel vendaCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_vendedor")
	private ViewPessoaVendedorModel viewPessoaVendedorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValorVenda() { 
		return this.valorVenda; 
	} 

	public void setValorVenda(BigDecimal valorVenda) { 
		this.valorVenda = valorVenda; 
	} 

	public String getTipoContabil() { 
		return this.tipoContabil; 
	} 

	public void setTipoContabil(String tipoContabil) { 
		this.tipoContabil = tipoContabil; 
	} 

	public BigDecimal getValorComissao() { 
		return this.valorComissao; 
	} 

	public void setValorComissao(BigDecimal valorComissao) { 
		this.valorComissao = valorComissao; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public Date getDataLancamento() { 
		return this.dataLancamento; 
	} 

	public void setDataLancamento(Date dataLancamento) { 
		this.dataLancamento = dataLancamento; 
	} 

	public VendaCabecalhoModel getVendaCabecalhoModel() { 
	return this.vendaCabecalhoModel; 
	} 

	public void setVendaCabecalhoModel(VendaCabecalhoModel vendaCabecalhoModel) { 
	this.vendaCabecalhoModel = vendaCabecalhoModel; 
	} 

	public ViewPessoaVendedorModel getViewPessoaVendedorModel() { 
	return this.viewPessoaVendedorModel; 
	} 

	public void setViewPessoaVendedorModel(ViewPessoaVendedorModel viewPessoaVendedorModel) { 
	this.viewPessoaVendedorModel = viewPessoaVendedorModel; 
	} 

		
}