package com.t2ti.vendas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.vendas.util.Filter;
import com.t2ti.vendas.exception.GenericException;
import com.t2ti.vendas.model.NotaFiscalTipoModel;
import com.t2ti.vendas.repository.NotaFiscalTipoRepository;

@Service
public class NotaFiscalTipoService {

	@Autowired
	private NotaFiscalTipoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<NotaFiscalTipoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<NotaFiscalTipoModel> getList(Filter filter) {
		String sql = "select * from nota_fiscal_tipo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, NotaFiscalTipoModel.class);
		return query.getResultList();
	}

	public NotaFiscalTipoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public NotaFiscalTipoModel save(NotaFiscalTipoModel obj) {
		NotaFiscalTipoModel notaFiscalTipoModel = repository.save(obj);
		return notaFiscalTipoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		NotaFiscalTipoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NotaFiscalTipo] - Exception: " + e.getMessage());
		}
	}

}