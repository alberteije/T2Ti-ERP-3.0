package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="nota_fiscal_modelo")
@NamedQuery(name="NotaFiscalModeloModel.findAll", query="SELECT t FROM NotaFiscalModeloModel t")
public class NotaFiscalModeloModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NotaFiscalModeloModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="descricao")
	private String descricao;

	@Column(name="modelo")
	private String modelo;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getModelo() { 
		return this.modelo; 
	} 

	public void setModelo(String modelo) { 
		this.modelo = modelo; 
	} 

		
}