package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="nota_fiscal_tipo")
@NamedQuery(name="NotaFiscalTipoModel.findAll", query="SELECT t FROM NotaFiscalTipoModel t")
public class NotaFiscalTipoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public NotaFiscalTipoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="serie")
	private String serie;

	@Column(name="serie_scan")
	private String serieScan;

	@Column(name="ultimo_numero")
	private Integer ultimoNumero;

	@ManyToOne 
	@JoinColumn(name="id_nota_fiscal_modelo")
	private NotaFiscalModeloModel notaFiscalModeloModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public String getSerieScan() { 
		return this.serieScan; 
	} 

	public void setSerieScan(String serieScan) { 
		this.serieScan = serieScan; 
	} 

	public Integer getUltimoNumero() { 
		return this.ultimoNumero; 
	} 

	public void setUltimoNumero(Integer ultimoNumero) { 
		this.ultimoNumero = ultimoNumero; 
	} 

	public NotaFiscalModeloModel getNotaFiscalModeloModel() { 
	return this.notaFiscalModeloModel; 
	} 

	public void setNotaFiscalModeloModel(NotaFiscalModeloModel notaFiscalModeloModel) { 
	this.notaFiscalModeloModel = notaFiscalModeloModel; 
	} 

		
}