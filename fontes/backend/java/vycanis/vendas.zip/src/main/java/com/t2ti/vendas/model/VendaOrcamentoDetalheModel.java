package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="venda_orcamento_detalhe")
@NamedQuery(name="VendaOrcamentoDetalheModel.findAll", query="SELECT t FROM VendaOrcamentoDetalheModel t")
public class VendaOrcamentoDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaOrcamentoDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private BigDecimal quantidade;

	@Column(name="valor_unitario")
	private BigDecimal valorUnitario;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_venda_orcamento_cabecalho")
	private VendaOrcamentoCabecalhoModel vendaOrcamentoCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(BigDecimal quantidade) { 
		this.quantidade = quantidade; 
	} 

	public BigDecimal getValorUnitario() { 
		return this.valorUnitario; 
	} 

	public void setValorUnitario(BigDecimal valorUnitario) { 
		this.valorUnitario = valorUnitario; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public VendaOrcamentoCabecalhoModel getVendaOrcamentoCabecalhoModel() { 
	return this.vendaOrcamentoCabecalhoModel; 
	} 

	public void setVendaOrcamentoCabecalhoModel(VendaOrcamentoCabecalhoModel vendaOrcamentoCabecalhoModel) { 
	this.vendaOrcamentoCabecalhoModel = vendaOrcamentoCabecalhoModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}