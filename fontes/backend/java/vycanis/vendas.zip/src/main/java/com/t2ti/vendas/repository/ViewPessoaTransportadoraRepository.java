package com.t2ti.vendas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.vendas.model.ViewPessoaTransportadoraModel;

public interface ViewPessoaTransportadoraRepository extends JpaRepository<ViewPessoaTransportadoraModel, Integer> {}