package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="venda_condicoes_pagamento")
@NamedQuery(name="VendaCondicoesPagamentoModel.findAll", query="SELECT t FROM VendaCondicoesPagamentoModel t")
public class VendaCondicoesPagamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaCondicoesPagamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="faturamento_minimo")
	private BigDecimal faturamentoMinimo;

	@Column(name="faturamento_maximo")
	private BigDecimal faturamentoMaximo;

	@Column(name="indice_correcao")
	private BigDecimal indiceCorrecao;

	@Column(name="dias_tolerancia")
	private Integer diasTolerancia;

	@Column(name="valor_tolerancia")
	private BigDecimal valorTolerancia;

	@Column(name="prazo_medio")
	private Integer prazoMedio;

	@Column(name="vista_prazo")
	private String vistaPrazo;

	@OneToMany(mappedBy = "vendaCondicoesPagamentoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<VendaCondicoesParcelasModel> vendaCondicoesParcelasModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public BigDecimal getFaturamentoMinimo() { 
		return this.faturamentoMinimo; 
	} 

	public void setFaturamentoMinimo(BigDecimal faturamentoMinimo) { 
		this.faturamentoMinimo = faturamentoMinimo; 
	} 

	public BigDecimal getFaturamentoMaximo() { 
		return this.faturamentoMaximo; 
	} 

	public void setFaturamentoMaximo(BigDecimal faturamentoMaximo) { 
		this.faturamentoMaximo = faturamentoMaximo; 
	} 

	public BigDecimal getIndiceCorrecao() { 
		return this.indiceCorrecao; 
	} 

	public void setIndiceCorrecao(BigDecimal indiceCorrecao) { 
		this.indiceCorrecao = indiceCorrecao; 
	} 

	public Integer getDiasTolerancia() { 
		return this.diasTolerancia; 
	} 

	public void setDiasTolerancia(Integer diasTolerancia) { 
		this.diasTolerancia = diasTolerancia; 
	} 

	public BigDecimal getValorTolerancia() { 
		return this.valorTolerancia; 
	} 

	public void setValorTolerancia(BigDecimal valorTolerancia) { 
		this.valorTolerancia = valorTolerancia; 
	} 

	public Integer getPrazoMedio() { 
		return this.prazoMedio; 
	} 

	public void setPrazoMedio(Integer prazoMedio) { 
		this.prazoMedio = prazoMedio; 
	} 

	public String getVistaPrazo() { 
		return this.vistaPrazo; 
	} 

	public void setVistaPrazo(String vistaPrazo) { 
		this.vistaPrazo = vistaPrazo; 
	} 

	public Set<VendaCondicoesParcelasModel> getVendaCondicoesParcelasModelList() { 
	return this.vendaCondicoesParcelasModelList; 
	} 

	public void setVendaCondicoesParcelasModelList(Set<VendaCondicoesParcelasModel> vendaCondicoesParcelasModelList) { 
	this.vendaCondicoesParcelasModelList = vendaCondicoesParcelasModelList; 
		for (VendaCondicoesParcelasModel vendaCondicoesParcelasModel : vendaCondicoesParcelasModelList) { 
			vendaCondicoesParcelasModel.setVendaCondicoesPagamentoModel(this); 
		}
	} 

		
}