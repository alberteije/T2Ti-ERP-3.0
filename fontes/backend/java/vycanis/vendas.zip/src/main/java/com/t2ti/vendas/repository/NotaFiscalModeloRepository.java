package com.t2ti.vendas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.vendas.model.NotaFiscalModeloModel;

public interface NotaFiscalModeloRepository extends JpaRepository<NotaFiscalModeloModel, Integer> {}