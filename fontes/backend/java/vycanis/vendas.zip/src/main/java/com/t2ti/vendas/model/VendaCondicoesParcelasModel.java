package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="venda_condicoes_parcelas")
@NamedQuery(name="VendaCondicoesParcelasModel.findAll", query="SELECT t FROM VendaCondicoesParcelasModel t")
public class VendaCondicoesParcelasModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaCondicoesParcelasModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="parcela")
	private Integer parcela;

	@Column(name="dias")
	private Integer dias;

	@Column(name="taxa")
	private BigDecimal taxa;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_venda_condicoes_pagamento")
	private VendaCondicoesPagamentoModel vendaCondicoesPagamentoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getParcela() { 
		return this.parcela; 
	} 

	public void setParcela(Integer parcela) { 
		this.parcela = parcela; 
	} 

	public Integer getDias() { 
		return this.dias; 
	} 

	public void setDias(Integer dias) { 
		this.dias = dias; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

	public VendaCondicoesPagamentoModel getVendaCondicoesPagamentoModel() { 
	return this.vendaCondicoesPagamentoModel; 
	} 

	public void setVendaCondicoesPagamentoModel(VendaCondicoesPagamentoModel vendaCondicoesPagamentoModel) { 
	this.vendaCondicoesPagamentoModel = vendaCondicoesPagamentoModel; 
	} 

		
}