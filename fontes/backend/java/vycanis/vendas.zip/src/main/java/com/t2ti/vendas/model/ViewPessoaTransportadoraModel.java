package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="view_pessoa_transportadora")
@NamedQuery(name="ViewPessoaTransportadoraModel.findAll", query="SELECT t FROM ViewPessoaTransportadoraModel t")
public class ViewPessoaTransportadoraModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ViewPessoaTransportadoraModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="tipo")
	private String tipo;

	@Column(name="email")
	private String email;

	@Column(name="site")
	private String site;

	@Column(name="cpf_cnpj")
	private String cpfCnpj;

	@Column(name="rg_ie")
	private String rgIe;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Column(name="observacao")
	private String observacao;

	@Column(name="id_pessoa")
	private Integer idPessoa;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public String getSite() { 
		return this.site; 
	} 

	public void setSite(String site) { 
		this.site = site; 
	} 

	public String getCpfCnpj() { 
		return this.cpfCnpj; 
	} 

	public void setCpfCnpj(String cpfCnpj) { 
		this.cpfCnpj = cpfCnpj; 
	} 

	public String getRgIe() { 
		return this.rgIe; 
	} 

	public void setRgIe(String rgIe) { 
		this.rgIe = rgIe; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Integer getIdPessoa() { 
		return this.idPessoa; 
	} 

	public void setIdPessoa(Integer idPessoa) { 
		this.idPessoa = idPessoa; 
	} 

		
}