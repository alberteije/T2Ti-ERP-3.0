package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="produto_marca")
@NamedQuery(name="ProdutoMarcaModel.findAll", query="SELECT t FROM ProdutoMarcaModel t")
public class ProdutoMarcaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProdutoMarcaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "produtoMarcaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ProdutoModel> produtoModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<ProdutoModel> getProdutoModelList() { 
	return this.produtoModelList; 
	} 

	public void setProdutoModelList(Set<ProdutoModel> produtoModelList) { 
	this.produtoModelList = produtoModelList; 
		for (ProdutoModel produtoModel : produtoModelList) { 
			produtoModel.setProdutoMarcaModel(this); 
		}
	} 

		
}