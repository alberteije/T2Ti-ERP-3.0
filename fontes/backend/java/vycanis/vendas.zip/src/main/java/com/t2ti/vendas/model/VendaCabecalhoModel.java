package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.OneToOne;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="venda_cabecalho")
@NamedQuery(name="VendaCabecalhoModel.findAll", query="SELECT t FROM VendaCabecalhoModel t")
public class VendaCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="local_entrega")
	private String localEntrega;

	@Column(name="local_cobranca")
	private String localCobranca;

	@Column(name="tipo_frete")
	private String tipoFrete;

	@Column(name="forma_pagamento")
	private String formaPagamento;

	@Temporal(TemporalType.DATE)
@Column(name="data_venda")
	private Date dataVenda;

	@Temporal(TemporalType.DATE)
@Column(name="data_saida")
	private Date dataSaida;

	@Column(name="hora_saida")
	private String horaSaida;

	@Column(name="numero_fatura")
	private Integer numeroFatura;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@Column(name="valor_seguro")
	private BigDecimal valorSeguro;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="taxa_comissao")
	private BigDecimal taxaComissao;

	@Column(name="valor_comissao")
	private BigDecimal valorComissao;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="situacao")
	private String situacao;

	@Column(name="dia_fixo_parcela")
	private String diaFixoParcela;

	@Column(name="observacao")
	private String observacao;

	@OneToOne(mappedBy = "vendaCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private VendaComissaoModel vendaComissaoModel; 

	@OneToMany(mappedBy = "vendaCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<VendaDetalheModel> vendaDetalheModelList; 

	@OneToMany(mappedBy = "vendaCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<VendaFreteModel> vendaFreteModelList; 

	@ManyToOne 
	@JoinColumn(name="id_venda_condicoes_pagamento")
	private VendaCondicoesPagamentoModel vendaCondicoesPagamentoModel; 

	@ManyToOne 
	@JoinColumn(name="id_vendedor")
	private ViewPessoaVendedorModel viewPessoaVendedorModel; 

	@ManyToOne 
	@JoinColumn(name="id_transportadora")
	private ViewPessoaTransportadoraModel viewPessoaTransportadoraModel; 

	@ManyToOne 
	@JoinColumn(name="id_cliente")
	private ViewPessoaClienteModel viewPessoaClienteModel; 

	@ManyToOne 
	@JoinColumn(name="id_venda_orcamento_cabecalho")
	private VendaOrcamentoCabecalhoModel vendaOrcamentoCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_nota_fiscal_tipo")
	private NotaFiscalTipoModel notaFiscalTipoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getLocalEntrega() { 
		return this.localEntrega; 
	} 

	public void setLocalEntrega(String localEntrega) { 
		this.localEntrega = localEntrega; 
	} 

	public String getLocalCobranca() { 
		return this.localCobranca; 
	} 

	public void setLocalCobranca(String localCobranca) { 
		this.localCobranca = localCobranca; 
	} 

	public String getTipoFrete() { 
		return this.tipoFrete; 
	} 

	public void setTipoFrete(String tipoFrete) { 
		this.tipoFrete = tipoFrete; 
	} 

	public String getFormaPagamento() { 
		return this.formaPagamento; 
	} 

	public void setFormaPagamento(String formaPagamento) { 
		this.formaPagamento = formaPagamento; 
	} 

	public Date getDataVenda() { 
		return this.dataVenda; 
	} 

	public void setDataVenda(Date dataVenda) { 
		this.dataVenda = dataVenda; 
	} 

	public Date getDataSaida() { 
		return this.dataSaida; 
	} 

	public void setDataSaida(Date dataSaida) { 
		this.dataSaida = dataSaida; 
	} 

	public String getHoraSaida() { 
		return this.horaSaida; 
	} 

	public void setHoraSaida(String horaSaida) { 
		this.horaSaida = horaSaida; 
	} 

	public Integer getNumeroFatura() { 
		return this.numeroFatura; 
	} 

	public void setNumeroFatura(Integer numeroFatura) { 
		this.numeroFatura = numeroFatura; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public BigDecimal getValorSeguro() { 
		return this.valorSeguro; 
	} 

	public void setValorSeguro(BigDecimal valorSeguro) { 
		this.valorSeguro = valorSeguro; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getTaxaComissao() { 
		return this.taxaComissao; 
	} 

	public void setTaxaComissao(BigDecimal taxaComissao) { 
		this.taxaComissao = taxaComissao; 
	} 

	public BigDecimal getValorComissao() { 
		return this.valorComissao; 
	} 

	public void setValorComissao(BigDecimal valorComissao) { 
		this.valorComissao = valorComissao; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public String getDiaFixoParcela() { 
		return this.diaFixoParcela; 
	} 

	public void setDiaFixoParcela(String diaFixoParcela) { 
		this.diaFixoParcela = diaFixoParcela; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public VendaComissaoModel getVendaComissaoModel() { 
	return this.vendaComissaoModel; 
	} 

	public void setVendaComissaoModel(VendaComissaoModel vendaComissaoModel) { 
	this.vendaComissaoModel = vendaComissaoModel; 
		if (vendaComissaoModel != null) { 
			vendaComissaoModel.setVendaCabecalhoModel(this); 
		}
	} 

	public Set<VendaDetalheModel> getVendaDetalheModelList() { 
	return this.vendaDetalheModelList; 
	} 

	public void setVendaDetalheModelList(Set<VendaDetalheModel> vendaDetalheModelList) { 
	this.vendaDetalheModelList = vendaDetalheModelList; 
		for (VendaDetalheModel vendaDetalheModel : vendaDetalheModelList) { 
			vendaDetalheModel.setVendaCabecalhoModel(this); 
		}
	} 

	public Set<VendaFreteModel> getVendaFreteModelList() { 
	return this.vendaFreteModelList; 
	} 

	public void setVendaFreteModelList(Set<VendaFreteModel> vendaFreteModelList) { 
	this.vendaFreteModelList = vendaFreteModelList; 
		for (VendaFreteModel vendaFreteModel : vendaFreteModelList) { 
			vendaFreteModel.setVendaCabecalhoModel(this); 
		}
	} 

	public VendaCondicoesPagamentoModel getVendaCondicoesPagamentoModel() { 
	return this.vendaCondicoesPagamentoModel; 
	} 

	public void setVendaCondicoesPagamentoModel(VendaCondicoesPagamentoModel vendaCondicoesPagamentoModel) { 
	this.vendaCondicoesPagamentoModel = vendaCondicoesPagamentoModel; 
	} 

	public ViewPessoaVendedorModel getViewPessoaVendedorModel() { 
	return this.viewPessoaVendedorModel; 
	} 

	public void setViewPessoaVendedorModel(ViewPessoaVendedorModel viewPessoaVendedorModel) { 
	this.viewPessoaVendedorModel = viewPessoaVendedorModel; 
	} 

	public ViewPessoaTransportadoraModel getViewPessoaTransportadoraModel() { 
	return this.viewPessoaTransportadoraModel; 
	} 

	public void setViewPessoaTransportadoraModel(ViewPessoaTransportadoraModel viewPessoaTransportadoraModel) { 
	this.viewPessoaTransportadoraModel = viewPessoaTransportadoraModel; 
	} 

	public ViewPessoaClienteModel getViewPessoaClienteModel() { 
	return this.viewPessoaClienteModel; 
	} 

	public void setViewPessoaClienteModel(ViewPessoaClienteModel viewPessoaClienteModel) { 
	this.viewPessoaClienteModel = viewPessoaClienteModel; 
	} 

	public VendaOrcamentoCabecalhoModel getVendaOrcamentoCabecalhoModel() { 
	return this.vendaOrcamentoCabecalhoModel; 
	} 

	public void setVendaOrcamentoCabecalhoModel(VendaOrcamentoCabecalhoModel vendaOrcamentoCabecalhoModel) { 
	this.vendaOrcamentoCabecalhoModel = vendaOrcamentoCabecalhoModel; 
	} 

	public NotaFiscalTipoModel getNotaFiscalTipoModel() { 
	return this.notaFiscalTipoModel; 
	} 

	public void setNotaFiscalTipoModel(NotaFiscalTipoModel notaFiscalTipoModel) { 
	this.notaFiscalTipoModel = notaFiscalTipoModel; 
	} 

		
}