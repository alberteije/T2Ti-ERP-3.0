package com.t2ti.vendas.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.vendas.exception.GenericException;
import com.t2ti.vendas.exception.ResourseNotFoundException;
import com.t2ti.vendas.exception.BadRequestException;
import com.t2ti.vendas.util.Filter;
import com.t2ti.vendas.model.NotaFiscalModeloModel;
import com.t2ti.vendas.service.NotaFiscalModeloService;

@RestController
@RequestMapping(value = "/nota-fiscal-modelo", produces = "application/json;charset=UTF-8")
public class NotaFiscalModeloController {

	@Autowired
	private NotaFiscalModeloService service;
	
	@GetMapping({ "", "/" })
	public List<NotaFiscalModeloModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [NotaFiscalModelo] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public NotaFiscalModeloModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found NotaFiscalModelo].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found NotaFiscalModelo] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public NotaFiscalModeloModel insert(@RequestBody NotaFiscalModeloModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert NotaFiscalModelo] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public NotaFiscalModeloModel update(@RequestBody NotaFiscalModeloModel objJson) {	
		try {			
			NotaFiscalModeloModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update NotaFiscalModelo].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update NotaFiscalModelo] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete NotaFiscalModelo] - Exception: " + e.getMessage());
		}
	}
	
}