package com.t2ti.vendas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="venda_frete")
@NamedQuery(name="VendaFreteModel.findAll", query="SELECT t FROM VendaFreteModel t")
public class VendaFreteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public VendaFreteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="responsavel")
	private String responsavel;

	@Column(name="conhecimento")
	private Integer conhecimento;

	@Column(name="placa")
	private String placa;

	@Column(name="uf_placa")
	private String ufPlaca;

	@Column(name="selo_fiscal")
	private Integer seloFiscal;

	@Column(name="quantidade_volume")
	private BigDecimal quantidadeVolume;

	@Column(name="marca_volume")
	private String marcaVolume;

	@Column(name="especie_volume")
	private String especieVolume;

	@Column(name="peso_bruto")
	private BigDecimal pesoBruto;

	@Column(name="peso_liquido")
	private BigDecimal pesoLiquido;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_venda_cabecalho")
	private VendaCabecalhoModel vendaCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_transportadora")
	private ViewPessoaTransportadoraModel viewPessoaTransportadoraModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getResponsavel() { 
		return this.responsavel; 
	} 

	public void setResponsavel(String responsavel) { 
		this.responsavel = responsavel; 
	} 

	public Integer getConhecimento() { 
		return this.conhecimento; 
	} 

	public void setConhecimento(Integer conhecimento) { 
		this.conhecimento = conhecimento; 
	} 

	public String getPlaca() { 
		return this.placa; 
	} 

	public void setPlaca(String placa) { 
		this.placa = placa; 
	} 

	public String getUfPlaca() { 
		return this.ufPlaca; 
	} 

	public void setUfPlaca(String ufPlaca) { 
		this.ufPlaca = ufPlaca; 
	} 

	public Integer getSeloFiscal() { 
		return this.seloFiscal; 
	} 

	public void setSeloFiscal(Integer seloFiscal) { 
		this.seloFiscal = seloFiscal; 
	} 

	public BigDecimal getQuantidadeVolume() { 
		return this.quantidadeVolume; 
	} 

	public void setQuantidadeVolume(BigDecimal quantidadeVolume) { 
		this.quantidadeVolume = quantidadeVolume; 
	} 

	public String getMarcaVolume() { 
		return this.marcaVolume; 
	} 

	public void setMarcaVolume(String marcaVolume) { 
		this.marcaVolume = marcaVolume; 
	} 

	public String getEspecieVolume() { 
		return this.especieVolume; 
	} 

	public void setEspecieVolume(String especieVolume) { 
		this.especieVolume = especieVolume; 
	} 

	public BigDecimal getPesoBruto() { 
		return this.pesoBruto; 
	} 

	public void setPesoBruto(BigDecimal pesoBruto) { 
		this.pesoBruto = pesoBruto; 
	} 

	public BigDecimal getPesoLiquido() { 
		return this.pesoLiquido; 
	} 

	public void setPesoLiquido(BigDecimal pesoLiquido) { 
		this.pesoLiquido = pesoLiquido; 
	} 

	public VendaCabecalhoModel getVendaCabecalhoModel() { 
	return this.vendaCabecalhoModel; 
	} 

	public void setVendaCabecalhoModel(VendaCabecalhoModel vendaCabecalhoModel) { 
	this.vendaCabecalhoModel = vendaCabecalhoModel; 
	} 

	public ViewPessoaTransportadoraModel getViewPessoaTransportadoraModel() { 
	return this.viewPessoaTransportadoraModel; 
	} 

	public void setViewPessoaTransportadoraModel(ViewPessoaTransportadoraModel viewPessoaTransportadoraModel) { 
	this.viewPessoaTransportadoraModel = viewPessoaTransportadoraModel; 
	} 

		
}