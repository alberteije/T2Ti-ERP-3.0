/*******************************************************************************
Title: T2Ti ERP 3.0
Description: Controller responsável pelo Login.
                                                                                
The MIT License                                                                 
                                                                                
Copyright: Copyright (C) 2024 T2Ti.COM                                          
                                                                                
Permission is hereby granted, free of charge, to any person                     
obtaining a copy of this software and associated documentation                  
files (the "Software"), to deal in the Software without                         
restriction, including without limitation the rights to use,                    
copy, modify, merge, publish, distribute, sublicense, and/or sell               
copies of the Software, and to permit persons to whom the                       
Software is furnished to do so, subject to the following                        
conditions:                                                                     
                                                                                
The above copyright notice and this permission notice shall be                  
included in all copies or substantial portions of the Software.                 
                                                                                
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,                 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES                 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND                        
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT                     
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,                    
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING                    
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR                   
OTHER DEALINGS IN THE SOFTWARE.                                                 
                                                                                
       The author may be contacted at:                                          
           t2ti.com@gmail.com                                                   
                                                                                
@author Albert Eije (alberteije@gmail.com)                    
@version 1.0.0
*******************************************************************************/
package com.t2ti.ged.jwt;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.t2ti.ged.exception.GenericException;
import com.t2ti.ged.model.UsuarioTokenModel;
import com.t2ti.ged.model.ViewPessoaUsuarioModel;
import com.t2ti.ged.model.transiente.ObjetoLogin;
import com.t2ti.ged.service.UsuarioTokenService;
import com.t2ti.ged.service.ViewPessoaUsuarioService;
import com.t2ti.ged.util.Filter;
import com.t2ti.ged.util.Util;


@RestController
@RequestMapping(value = "/login", produces = "application/json;charset=UTF-8")
public class JWTController {

	@Autowired
	private ViewPessoaUsuarioService service;
    
	@Autowired
    private UsuarioTokenService usuarioTokenService; 
    
	@PostMapping
	public ObjetoLogin login(@RequestBody String corpoRequisicao) {
		ObjectMapper objectMapper = new ObjectMapper();		
		try {
			String corpo = Util.decifrar(corpoRequisicao);
			ViewPessoaUsuarioModel usuario = objectMapper.readValue(corpo, ViewPessoaUsuarioModel.class);

			String login = usuario.getLogin();
			String senha = usuario.getSenha();
			String md5Senha = Util.md5String(login+senha);
			
			Filter filtro = new Filter();
			filtro.setWhere(" login = '" + login + "' AND senha = '" + md5Senha + "'");
			
			usuario = service.getObjectFilter(filtro);
			
			if (usuario == null) {
				throw new Exception();				
			} else {
				String usuarioString = objectMapper.writeValueAsString(usuario);
				ObjetoLogin objetoLogin = new ObjetoLogin();
				String token = JWTManager.geraToken(usuario.getLogin());
				objetoLogin.setToken(Util.cifrar(token));
				objetoLogin.setUser(Util.cifrar(usuarioString));
				
				// persistir token para o usuário
	            UsuarioTokenModel usuarioToken = new UsuarioTokenModel();
	            usuarioToken.setLogin(login);
	            usuarioToken.setToken(token);
	            usuarioToken.setDataCriacao(new Date());
	            usuarioToken.setDataExpiracao(new Date(System.currentTimeMillis() + (24 * 60 * 60 * 1000)));
	            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
	            usuarioToken.setHoraCriacao(timeFormat.format(new Date()));
	            usuarioToken.setHoraExpiracao(timeFormat.format(new Date(System.currentTimeMillis() + (24 * 60 * 60 * 1000))));
	            
	            usuarioTokenService.save(usuarioToken);
	            
				return objetoLogin;
			}
		} catch (Exception e) {
			throw new GenericException("Error [Login] - Exception: " + e.getMessage());
		}
	}
	
}