package com.t2ti.ged.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="usuario_token")
@NamedQuery(name="UsuarioTokenModel.findAll", query="SELECT t FROM UsuarioTokenModel t")
public class UsuarioTokenModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public UsuarioTokenModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="login")
	private String login;

	@Column(name="token")
	private String token;

	@Temporal(TemporalType.DATE)
@Column(name="data_criacao")
	private Date dataCriacao;

	@Column(name="hora_criacao")
	private String horaCriacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_expiracao")
	private Date dataExpiracao;

	@Column(name="hora_expiracao")
	private String horaExpiracao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getLogin() { 
		return this.login; 
	} 

	public void setLogin(String login) { 
		this.login = login; 
	} 

	public String getToken() { 
		return this.token; 
	} 

	public void setToken(String token) { 
		this.token = token; 
	} 

	public Date getDataCriacao() { 
		return this.dataCriacao; 
	} 

	public void setDataCriacao(Date dataCriacao) { 
		this.dataCriacao = dataCriacao; 
	} 

	public String getHoraCriacao() { 
		return this.horaCriacao; 
	} 

	public void setHoraCriacao(String horaCriacao) { 
		this.horaCriacao = horaCriacao; 
	} 

	public Date getDataExpiracao() { 
		return this.dataExpiracao; 
	} 

	public void setDataExpiracao(Date dataExpiracao) { 
		this.dataExpiracao = dataExpiracao; 
	} 

	public String getHoraExpiracao() { 
		return this.horaExpiracao; 
	} 

	public void setHoraExpiracao(String horaExpiracao) { 
		this.horaExpiracao = horaExpiracao; 
	} 

		
}