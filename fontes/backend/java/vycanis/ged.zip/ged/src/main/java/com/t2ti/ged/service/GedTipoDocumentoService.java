package com.t2ti.ged.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ged.util.Filter;
import com.t2ti.ged.exception.GenericException;
import com.t2ti.ged.model.GedTipoDocumentoModel;
import com.t2ti.ged.repository.GedTipoDocumentoRepository;

@Service
public class GedTipoDocumentoService {

	@Autowired
	private GedTipoDocumentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<GedTipoDocumentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<GedTipoDocumentoModel> getList(Filter filter) {
		String sql = "select * from ged_tipo_documento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, GedTipoDocumentoModel.class);
		return query.getResultList();
	}

	public GedTipoDocumentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public GedTipoDocumentoModel save(GedTipoDocumentoModel obj) {
		GedTipoDocumentoModel gedTipoDocumentoModel = repository.save(obj);
		return gedTipoDocumentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		GedTipoDocumentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete GedTipoDocumento] - Exception: " + e.getMessage());
		}
	}

}