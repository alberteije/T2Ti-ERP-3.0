package com.t2ti.ged.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ged.util.Filter;
import com.t2ti.ged.exception.GenericException;
import com.t2ti.ged.model.ViewPessoaColaboradorModel;
import com.t2ti.ged.repository.ViewPessoaColaboradorRepository;

@Service
public class ViewPessoaColaboradorService {

	@Autowired
	private ViewPessoaColaboradorRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ViewPessoaColaboradorModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ViewPessoaColaboradorModel> getList(Filter filter) {
		String sql = "select * from view_pessoa_colaborador where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewPessoaColaboradorModel.class);
		return query.getResultList();
	}

	public ViewPessoaColaboradorModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ViewPessoaColaboradorModel save(ViewPessoaColaboradorModel obj) {
		ViewPessoaColaboradorModel viewPessoaColaboradorModel = repository.save(obj);
		return viewPessoaColaboradorModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ViewPessoaColaboradorModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ViewPessoaColaborador] - Exception: " + e.getMessage());
		}
	}

}