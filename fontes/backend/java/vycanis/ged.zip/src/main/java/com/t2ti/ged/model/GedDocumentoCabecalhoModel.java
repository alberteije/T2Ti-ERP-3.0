package com.t2ti.ged.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="ged_documento_cabecalho")
@NamedQuery(name="GedDocumentoCabecalhoModel.findAll", query="SELECT t FROM GedDocumentoCabecalhoModel t")
public class GedDocumentoCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GedDocumentoCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Temporal(TemporalType.DATE)
@Column(name="data_inclusao")
	private Date dataInclusao;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "gedDocumentoCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<GedDocumentoDetalheModel> gedDocumentoDetalheModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Date getDataInclusao() { 
		return this.dataInclusao; 
	} 

	public void setDataInclusao(Date dataInclusao) { 
		this.dataInclusao = dataInclusao; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<GedDocumentoDetalheModel> getGedDocumentoDetalheModelList() { 
	return this.gedDocumentoDetalheModelList; 
	} 

	public void setGedDocumentoDetalheModelList(Set<GedDocumentoDetalheModel> gedDocumentoDetalheModelList) { 
	this.gedDocumentoDetalheModelList = gedDocumentoDetalheModelList; 
		for (GedDocumentoDetalheModel gedDocumentoDetalheModel : gedDocumentoDetalheModelList) { 
			gedDocumentoDetalheModel.setGedDocumentoCabecalhoModel(this); 
		}
	} 

		
}