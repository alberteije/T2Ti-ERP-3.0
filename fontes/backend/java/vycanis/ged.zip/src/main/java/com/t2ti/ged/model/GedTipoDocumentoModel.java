package com.t2ti.ged.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="ged_tipo_documento")
@NamedQuery(name="GedTipoDocumentoModel.findAll", query="SELECT t FROM GedTipoDocumentoModel t")
public class GedTipoDocumentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GedTipoDocumentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="tamanho_maximo")
	private BigDecimal tamanhoMaximo;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public BigDecimal getTamanhoMaximo() { 
		return this.tamanhoMaximo; 
	} 

	public void setTamanhoMaximo(BigDecimal tamanhoMaximo) { 
		this.tamanhoMaximo = tamanhoMaximo; 
	} 

		
}