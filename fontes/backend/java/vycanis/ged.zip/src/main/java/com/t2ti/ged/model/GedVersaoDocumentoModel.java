package com.t2ti.ged.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ged_versao_documento")
@NamedQuery(name="GedVersaoDocumentoModel.findAll", query="SELECT t FROM GedVersaoDocumentoModel t")
public class GedVersaoDocumentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GedVersaoDocumentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="acao")
	private String acao;

	@Column(name="versao")
	private Integer versao;

	@Temporal(TemporalType.DATE)
@Column(name="data_versao")
	private Date dataVersao;

	@Column(name="hora_versao")
	private String horaVersao;

	@Column(name="hash_arquivo")
	private String hashArquivo;

	@Column(name="caminho")
	private String caminho;

	@ManyToOne 
	@JoinColumn(name="id_ged_documento_detalhe")
	private GedDocumentoDetalheModel gedDocumentoDetalheModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getAcao() { 
		return this.acao; 
	} 

	public void setAcao(String acao) { 
		this.acao = acao; 
	} 

	public Integer getVersao() { 
		return this.versao; 
	} 

	public void setVersao(Integer versao) { 
		this.versao = versao; 
	} 

	public Date getDataVersao() { 
		return this.dataVersao; 
	} 

	public void setDataVersao(Date dataVersao) { 
		this.dataVersao = dataVersao; 
	} 

	public String getHoraVersao() { 
		return this.horaVersao; 
	} 

	public void setHoraVersao(String horaVersao) { 
		this.horaVersao = horaVersao; 
	} 

	public String getHashArquivo() { 
		return this.hashArquivo; 
	} 

	public void setHashArquivo(String hashArquivo) { 
		this.hashArquivo = hashArquivo; 
	} 

	public String getCaminho() { 
		return this.caminho; 
	} 

	public void setCaminho(String caminho) { 
		this.caminho = caminho; 
	} 

	public GedDocumentoDetalheModel getGedDocumentoDetalheModel() { 
	return this.gedDocumentoDetalheModel; 
	} 

	public void setGedDocumentoDetalheModel(GedDocumentoDetalheModel gedDocumentoDetalheModel) { 
	this.gedDocumentoDetalheModel = gedDocumentoDetalheModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}