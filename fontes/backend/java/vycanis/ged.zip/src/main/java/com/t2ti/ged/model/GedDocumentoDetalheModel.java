package com.t2ti.ged.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ged_documento_detalhe")
@NamedQuery(name="GedDocumentoDetalheModel.findAll", query="SELECT t FROM GedDocumentoDetalheModel t")
public class GedDocumentoDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GedDocumentoDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="palavras_chave")
	private String palavrasChave;

	@Column(name="pode_excluir")
	private String podeExcluir;

	@Column(name="pode_alterar")
	private String podeAlterar;

	@Column(name="assinado")
	private String assinado;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim_vigencia")
	private Date dataFimVigencia;

	@Temporal(TemporalType.DATE)
@Column(name="data_exclusao")
	private Date dataExclusao;

	@ManyToOne 
	@JoinColumn(name="id_ged_tipo_documento")
	private GedTipoDocumentoModel gedTipoDocumentoModel; 

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_ged_documento_cabecalho")
	private GedDocumentoCabecalhoModel gedDocumentoCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getPalavrasChave() { 
		return this.palavrasChave; 
	} 

	public void setPalavrasChave(String palavrasChave) { 
		this.palavrasChave = palavrasChave; 
	} 

	public String getPodeExcluir() { 
		return this.podeExcluir; 
	} 

	public void setPodeExcluir(String podeExcluir) { 
		this.podeExcluir = podeExcluir; 
	} 

	public String getPodeAlterar() { 
		return this.podeAlterar; 
	} 

	public void setPodeAlterar(String podeAlterar) { 
		this.podeAlterar = podeAlterar; 
	} 

	public String getAssinado() { 
		return this.assinado; 
	} 

	public void setAssinado(String assinado) { 
		this.assinado = assinado; 
	} 

	public Date getDataFimVigencia() { 
		return this.dataFimVigencia; 
	} 

	public void setDataFimVigencia(Date dataFimVigencia) { 
		this.dataFimVigencia = dataFimVigencia; 
	} 

	public Date getDataExclusao() { 
		return this.dataExclusao; 
	} 

	public void setDataExclusao(Date dataExclusao) { 
		this.dataExclusao = dataExclusao; 
	} 

	public GedTipoDocumentoModel getGedTipoDocumentoModel() { 
	return this.gedTipoDocumentoModel; 
	} 

	public void setGedTipoDocumentoModel(GedTipoDocumentoModel gedTipoDocumentoModel) { 
	this.gedTipoDocumentoModel = gedTipoDocumentoModel; 
	} 

	public GedDocumentoCabecalhoModel getGedDocumentoCabecalhoModel() { 
	return this.gedDocumentoCabecalhoModel; 
	} 

	public void setGedDocumentoCabecalhoModel(GedDocumentoCabecalhoModel gedDocumentoCabecalhoModel) { 
	this.gedDocumentoCabecalhoModel = gedDocumentoCabecalhoModel; 
	} 

		
}