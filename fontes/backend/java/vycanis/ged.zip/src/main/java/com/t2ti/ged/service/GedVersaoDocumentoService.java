package com.t2ti.ged.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ged.util.Filter;
import com.t2ti.ged.exception.GenericException;
import com.t2ti.ged.model.GedVersaoDocumentoModel;
import com.t2ti.ged.repository.GedVersaoDocumentoRepository;

@Service
public class GedVersaoDocumentoService {

	@Autowired
	private GedVersaoDocumentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<GedVersaoDocumentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<GedVersaoDocumentoModel> getList(Filter filter) {
		String sql = "select * from ged_versao_documento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, GedVersaoDocumentoModel.class);
		return query.getResultList();
	}

	public GedVersaoDocumentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public GedVersaoDocumentoModel save(GedVersaoDocumentoModel obj) {
		GedVersaoDocumentoModel gedVersaoDocumentoModel = repository.save(obj);
		return gedVersaoDocumentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		GedVersaoDocumentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete GedVersaoDocumento] - Exception: " + e.getMessage());
		}
	}

}