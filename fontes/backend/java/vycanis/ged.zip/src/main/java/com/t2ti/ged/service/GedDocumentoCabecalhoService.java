package com.t2ti.ged.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.ged.util.Filter;
import com.t2ti.ged.exception.GenericException;
import com.t2ti.ged.model.GedDocumentoCabecalhoModel;
import com.t2ti.ged.repository.GedDocumentoCabecalhoRepository;

@Service
public class GedDocumentoCabecalhoService {

	@Autowired
	private GedDocumentoCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<GedDocumentoCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<GedDocumentoCabecalhoModel> getList(Filter filter) {
		String sql = "select * from ged_documento_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, GedDocumentoCabecalhoModel.class);
		return query.getResultList();
	}

	public GedDocumentoCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public GedDocumentoCabecalhoModel save(GedDocumentoCabecalhoModel obj) {
		GedDocumentoCabecalhoModel gedDocumentoCabecalhoModel = repository.save(obj);
		return gedDocumentoCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		GedDocumentoCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete GedDocumentoCabecalho] - Exception: " + e.getMessage());
		}
	}

}