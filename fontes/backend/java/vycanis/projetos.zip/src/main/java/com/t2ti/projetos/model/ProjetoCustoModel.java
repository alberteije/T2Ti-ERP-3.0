package com.t2ti.projetos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="projeto_custo")
@NamedQuery(name="ProjetoCustoModel.findAll", query="SELECT t FROM ProjetoCustoModel t")
public class ProjetoCustoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProjetoCustoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="valor_mensal")
	private BigDecimal valorMensal;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="justificativa")
	private String justificativa;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_projeto_principal")
	private ProjetoPrincipalModel projetoPrincipalModel; 

	@ManyToOne 
	@JoinColumn(name="id_fin_natureza_financeira")
	private FinNaturezaFinanceiraModel finNaturezaFinanceiraModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public BigDecimal getValorMensal() { 
		return this.valorMensal; 
	} 

	public void setValorMensal(BigDecimal valorMensal) { 
		this.valorMensal = valorMensal; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public String getJustificativa() { 
		return this.justificativa; 
	} 

	public void setJustificativa(String justificativa) { 
		this.justificativa = justificativa; 
	} 

	public ProjetoPrincipalModel getProjetoPrincipalModel() { 
	return this.projetoPrincipalModel; 
	} 

	public void setProjetoPrincipalModel(ProjetoPrincipalModel projetoPrincipalModel) { 
	this.projetoPrincipalModel = projetoPrincipalModel; 
	} 

	public FinNaturezaFinanceiraModel getFinNaturezaFinanceiraModel() { 
	return this.finNaturezaFinanceiraModel; 
	} 

	public void setFinNaturezaFinanceiraModel(FinNaturezaFinanceiraModel finNaturezaFinanceiraModel) { 
	this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel; 
	} 

		
}