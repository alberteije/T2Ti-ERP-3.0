package com.t2ti.projetos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetosApplication.class, args);
	}

}
