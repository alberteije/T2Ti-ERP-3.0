package com.t2ti.projetos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="projeto_stakeholders")
@NamedQuery(name="ProjetoStakeholdersModel.findAll", query="SELECT t FROM ProjetoStakeholdersModel t")
public class ProjetoStakeholdersModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProjetoStakeholdersModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_projeto_principal")
	private ProjetoPrincipalModel projetoPrincipalModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public ProjetoPrincipalModel getProjetoPrincipalModel() { 
	return this.projetoPrincipalModel; 
	} 

	public void setProjetoPrincipalModel(ProjetoPrincipalModel projetoPrincipalModel) { 
	this.projetoPrincipalModel = projetoPrincipalModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}