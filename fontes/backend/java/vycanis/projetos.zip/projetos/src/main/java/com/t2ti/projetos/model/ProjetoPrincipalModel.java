package com.t2ti.projetos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="projeto_principal")
@NamedQuery(name="ProjetoPrincipalModel.findAll", query="SELECT t FROM ProjetoPrincipalModel t")
public class ProjetoPrincipalModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProjetoPrincipalModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_previsao_fim")
	private Date dataPrevisaoFim;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Column(name="valor_orcamento")
	private BigDecimal valorOrcamento;

	@Column(name="link_quadro_kanban")
	private String linkQuadroKanban;

	@Column(name="observacao")
	private String observacao;

	@OneToMany(mappedBy = "projetoPrincipalModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ProjetoCronogramaModel> projetoCronogramaModelList; 

	@OneToMany(mappedBy = "projetoPrincipalModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ProjetoRiscoModel> projetoRiscoModelList; 

	@OneToMany(mappedBy = "projetoPrincipalModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ProjetoCustoModel> projetoCustoModelList; 

	@OneToMany(mappedBy = "projetoPrincipalModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ProjetoStakeholdersModel> projetoStakeholdersModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataPrevisaoFim() { 
		return this.dataPrevisaoFim; 
	} 

	public void setDataPrevisaoFim(Date dataPrevisaoFim) { 
		this.dataPrevisaoFim = dataPrevisaoFim; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public BigDecimal getValorOrcamento() { 
		return this.valorOrcamento; 
	} 

	public void setValorOrcamento(BigDecimal valorOrcamento) { 
		this.valorOrcamento = valorOrcamento; 
	} 

	public String getLinkQuadroKanban() { 
		return this.linkQuadroKanban; 
	} 

	public void setLinkQuadroKanban(String linkQuadroKanban) { 
		this.linkQuadroKanban = linkQuadroKanban; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Set<ProjetoCronogramaModel> getProjetoCronogramaModelList() { 
	return this.projetoCronogramaModelList; 
	} 

	public void setProjetoCronogramaModelList(Set<ProjetoCronogramaModel> projetoCronogramaModelList) { 
	this.projetoCronogramaModelList = projetoCronogramaModelList; 
		for (ProjetoCronogramaModel projetoCronogramaModel : projetoCronogramaModelList) { 
			projetoCronogramaModel.setProjetoPrincipalModel(this); 
		}
	} 

	public Set<ProjetoRiscoModel> getProjetoRiscoModelList() { 
	return this.projetoRiscoModelList; 
	} 

	public void setProjetoRiscoModelList(Set<ProjetoRiscoModel> projetoRiscoModelList) { 
	this.projetoRiscoModelList = projetoRiscoModelList; 
		for (ProjetoRiscoModel projetoRiscoModel : projetoRiscoModelList) { 
			projetoRiscoModel.setProjetoPrincipalModel(this); 
		}
	} 

	public Set<ProjetoCustoModel> getProjetoCustoModelList() { 
	return this.projetoCustoModelList; 
	} 

	public void setProjetoCustoModelList(Set<ProjetoCustoModel> projetoCustoModelList) { 
	this.projetoCustoModelList = projetoCustoModelList; 
		for (ProjetoCustoModel projetoCustoModel : projetoCustoModelList) { 
			projetoCustoModel.setProjetoPrincipalModel(this); 
		}
	} 

	public Set<ProjetoStakeholdersModel> getProjetoStakeholdersModelList() { 
	return this.projetoStakeholdersModelList; 
	} 

	public void setProjetoStakeholdersModelList(Set<ProjetoStakeholdersModel> projetoStakeholdersModelList) { 
	this.projetoStakeholdersModelList = projetoStakeholdersModelList; 
		for (ProjetoStakeholdersModel projetoStakeholdersModel : projetoStakeholdersModelList) { 
			projetoStakeholdersModel.setProjetoPrincipalModel(this); 
		}
	} 

		
}