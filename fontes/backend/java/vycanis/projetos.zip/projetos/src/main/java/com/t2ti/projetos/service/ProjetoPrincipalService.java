package com.t2ti.projetos.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.projetos.util.Filter;
import com.t2ti.projetos.exception.GenericException;
import com.t2ti.projetos.model.ProjetoPrincipalModel;
import com.t2ti.projetos.repository.ProjetoPrincipalRepository;

@Service
public class ProjetoPrincipalService {

	@Autowired
	private ProjetoPrincipalRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ProjetoPrincipalModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ProjetoPrincipalModel> getList(Filter filter) {
		String sql = "select * from projeto_principal where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ProjetoPrincipalModel.class);
		return query.getResultList();
	}

	public ProjetoPrincipalModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ProjetoPrincipalModel save(ProjetoPrincipalModel obj) {
		ProjetoPrincipalModel projetoPrincipalModel = repository.save(obj);
		return projetoPrincipalModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ProjetoPrincipalModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ProjetoPrincipal] - Exception: " + e.getMessage());
		}
	}

}