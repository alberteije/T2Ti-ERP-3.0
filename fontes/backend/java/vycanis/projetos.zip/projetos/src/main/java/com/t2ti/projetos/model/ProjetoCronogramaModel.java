package com.t2ti.projetos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="projeto_cronograma")
@NamedQuery(name="ProjetoCronogramaModel.findAll", query="SELECT t FROM ProjetoCronogramaModel t")
public class ProjetoCronogramaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProjetoCronogramaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tarefa")
	private String tarefa;

	@Temporal(TemporalType.DATE)
@Column(name="data_tarefa")
	private Date dataTarefa;

	@Column(name="descricao")
	private String descricao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_projeto_principal")
	private ProjetoPrincipalModel projetoPrincipalModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTarefa() { 
		return this.tarefa; 
	} 

	public void setTarefa(String tarefa) { 
		this.tarefa = tarefa; 
	} 

	public Date getDataTarefa() { 
		return this.dataTarefa; 
	} 

	public void setDataTarefa(Date dataTarefa) { 
		this.dataTarefa = dataTarefa; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public ProjetoPrincipalModel getProjetoPrincipalModel() { 
	return this.projetoPrincipalModel; 
	} 

	public void setProjetoPrincipalModel(ProjetoPrincipalModel projetoPrincipalModel) { 
	this.projetoPrincipalModel = projetoPrincipalModel; 
	} 

		
}