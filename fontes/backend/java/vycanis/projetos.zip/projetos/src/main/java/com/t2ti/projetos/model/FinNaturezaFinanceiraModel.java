package com.t2ti.projetos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="fin_natureza_financeira")
@NamedQuery(name="FinNaturezaFinanceiraModel.findAll", query="SELECT t FROM FinNaturezaFinanceiraModel t")
public class FinNaturezaFinanceiraModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FinNaturezaFinanceiraModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="descricao")
	private String descricao;

	@Column(name="tipo")
	private String tipo;

	@Column(name="aplicacao")
	private String aplicacao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getAplicacao() { 
		return this.aplicacao; 
	} 

	public void setAplicacao(String aplicacao) { 
		this.aplicacao = aplicacao; 
	} 

		
}