package com.t2ti.esocial.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.esocial.util.Filter;
import com.t2ti.esocial.exception.GenericException;
import com.t2ti.esocial.model.EsocialClassificacaoTributModel;
import com.t2ti.esocial.repository.EsocialClassificacaoTributRepository;

@Service
public class EsocialClassificacaoTributService {

	@Autowired
	private EsocialClassificacaoTributRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EsocialClassificacaoTributModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EsocialClassificacaoTributModel> getList(Filter filter) {
		String sql = "select * from esocial_classificacao_tribut where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EsocialClassificacaoTributModel.class);
		return query.getResultList();
	}

	public EsocialClassificacaoTributModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EsocialClassificacaoTributModel save(EsocialClassificacaoTributModel obj) {
		EsocialClassificacaoTributModel esocialClassificacaoTributModel = repository.save(obj);
		return esocialClassificacaoTributModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EsocialClassificacaoTributModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EsocialClassificacaoTribut] - Exception: " + e.getMessage());
		}
	}

}