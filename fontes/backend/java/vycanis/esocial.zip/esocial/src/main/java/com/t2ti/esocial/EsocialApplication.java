package com.t2ti.esocial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsocialApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsocialApplication.class, args);
	}

}
