package com.t2ti.esocial.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.esocial.util.Filter;
import com.t2ti.esocial.exception.GenericException;
import com.t2ti.esocial.model.EsocialRubricaModel;
import com.t2ti.esocial.repository.EsocialRubricaRepository;

@Service
public class EsocialRubricaService {

	@Autowired
	private EsocialRubricaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EsocialRubricaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EsocialRubricaModel> getList(Filter filter) {
		String sql = "select * from esocial_rubrica where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EsocialRubricaModel.class);
		return query.getResultList();
	}

	public EsocialRubricaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EsocialRubricaModel save(EsocialRubricaModel obj) {
		EsocialRubricaModel esocialRubricaModel = repository.save(obj);
		return esocialRubricaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EsocialRubricaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EsocialRubrica] - Exception: " + e.getMessage());
		}
	}

}