package com.t2ti.esocial.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="esocial_natureza_juridica")
@NamedQuery(name="EsocialNaturezaJuridicaModel.findAll", query="SELECT t FROM EsocialNaturezaJuridicaModel t")
public class EsocialNaturezaJuridicaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EsocialNaturezaJuridicaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="grupo")
	private Integer grupo;

	@Column(name="codigo")
	private String codigo;

	@Column(name="descricao")
	private String descricao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getGrupo() { 
		return this.grupo; 
	} 

	public void setGrupo(Integer grupo) { 
		this.grupo = grupo; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

		
}