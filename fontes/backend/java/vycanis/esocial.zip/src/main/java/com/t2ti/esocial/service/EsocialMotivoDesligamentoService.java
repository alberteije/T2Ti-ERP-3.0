package com.t2ti.esocial.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.esocial.util.Filter;
import com.t2ti.esocial.exception.GenericException;
import com.t2ti.esocial.model.EsocialMotivoDesligamentoModel;
import com.t2ti.esocial.repository.EsocialMotivoDesligamentoRepository;

@Service
public class EsocialMotivoDesligamentoService {

	@Autowired
	private EsocialMotivoDesligamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EsocialMotivoDesligamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EsocialMotivoDesligamentoModel> getList(Filter filter) {
		String sql = "select * from esocial_motivo_desligamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EsocialMotivoDesligamentoModel.class);
		return query.getResultList();
	}

	public EsocialMotivoDesligamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EsocialMotivoDesligamentoModel save(EsocialMotivoDesligamentoModel obj) {
		EsocialMotivoDesligamentoModel esocialMotivoDesligamentoModel = repository.save(obj);
		return esocialMotivoDesligamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EsocialMotivoDesligamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EsocialMotivoDesligamento] - Exception: " + e.getMessage());
		}
	}

}