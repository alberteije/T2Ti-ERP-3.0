package com.t2ti.esocial.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.esocial.model.EsocialRubricaModel;

public interface EsocialRubricaRepository extends JpaRepository<EsocialRubricaModel, Integer> {}