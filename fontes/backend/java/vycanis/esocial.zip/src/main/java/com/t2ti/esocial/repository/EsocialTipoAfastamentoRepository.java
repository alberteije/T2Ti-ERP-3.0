package com.t2ti.esocial.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.esocial.model.EsocialTipoAfastamentoModel;

public interface EsocialTipoAfastamentoRepository extends JpaRepository<EsocialTipoAfastamentoModel, Integer> {}