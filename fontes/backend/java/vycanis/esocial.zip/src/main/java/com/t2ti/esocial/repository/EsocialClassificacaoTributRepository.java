package com.t2ti.esocial.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.esocial.model.EsocialClassificacaoTributModel;

public interface EsocialClassificacaoTributRepository extends JpaRepository<EsocialClassificacaoTributModel, Integer> {}