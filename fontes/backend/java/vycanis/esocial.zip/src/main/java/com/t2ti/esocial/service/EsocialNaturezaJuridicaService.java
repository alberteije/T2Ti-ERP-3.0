package com.t2ti.esocial.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.esocial.util.Filter;
import com.t2ti.esocial.exception.GenericException;
import com.t2ti.esocial.model.EsocialNaturezaJuridicaModel;
import com.t2ti.esocial.repository.EsocialNaturezaJuridicaRepository;

@Service
public class EsocialNaturezaJuridicaService {

	@Autowired
	private EsocialNaturezaJuridicaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EsocialNaturezaJuridicaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EsocialNaturezaJuridicaModel> getList(Filter filter) {
		String sql = "select * from esocial_natureza_juridica where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EsocialNaturezaJuridicaModel.class);
		return query.getResultList();
	}

	public EsocialNaturezaJuridicaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EsocialNaturezaJuridicaModel save(EsocialNaturezaJuridicaModel obj) {
		EsocialNaturezaJuridicaModel esocialNaturezaJuridicaModel = repository.save(obj);
		return esocialNaturezaJuridicaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EsocialNaturezaJuridicaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EsocialNaturezaJuridica] - Exception: " + e.getMessage());
		}
	}

}