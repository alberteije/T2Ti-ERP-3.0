package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_veiculo")
@NamedQuery(name="FrotaVeiculoModel.findAll", query="SELECT t FROM FrotaVeiculoModel t")
public class FrotaVeiculoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaVeiculoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="marca")
	private String marca;

	@Column(name="modelo")
	private String modelo;

	@Column(name="modelo_ano")
	private String modeloAno;

	@Column(name="placa")
	private String placa;

	@Column(name="codigo_fipe")
	private String codigoFipe;

	@Column(name="renavam")
	private String renavam;

	@Column(name="ipva_mes_vencimento")
	private String ipvaMesVencimento;

	@Column(name="dpvat_mes_vencimento")
	private String dpvatMesVencimento;

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaIpvaControleModel> frotaIpvaControleModelList; 

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaDpvatControleModel> frotaDpvatControleModelList; 

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaVeiculoSinistroModel> frotaVeiculoSinistroModelList; 

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaVeiculoMovimentacaoModel> frotaVeiculoMovimentacaoModelList; 

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaVeiculoPneuModel> frotaVeiculoPneuModelList; 

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaVeiculoManutencaoModel> frotaVeiculoManutencaoModelList; 

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaMultaControleModel> frotaMultaControleModelList; 

	@OneToMany(mappedBy = "frotaVeiculoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FrotaCombustivelControleModel> frotaCombustivelControleModelList; 

	@ManyToOne 
	@JoinColumn(name="id_frota_veiculo_tipo")
	private FrotaVeiculoTipoModel frotaVeiculoTipoModel; 

	@ManyToOne 
	@JoinColumn(name="id_frota_combustivel_tipo")
	private FrotaCombustivelTipoModel frotaCombustivelTipoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getMarca() { 
		return this.marca; 
	} 

	public void setMarca(String marca) { 
		this.marca = marca; 
	} 

	public String getModelo() { 
		return this.modelo; 
	} 

	public void setModelo(String modelo) { 
		this.modelo = modelo; 
	} 

	public String getModeloAno() { 
		return this.modeloAno; 
	} 

	public void setModeloAno(String modeloAno) { 
		this.modeloAno = modeloAno; 
	} 

	public String getPlaca() { 
		return this.placa; 
	} 

	public void setPlaca(String placa) { 
		this.placa = placa; 
	} 

	public String getCodigoFipe() { 
		return this.codigoFipe; 
	} 

	public void setCodigoFipe(String codigoFipe) { 
		this.codigoFipe = codigoFipe; 
	} 

	public String getRenavam() { 
		return this.renavam; 
	} 

	public void setRenavam(String renavam) { 
		this.renavam = renavam; 
	} 

	public String getIpvaMesVencimento() { 
		return this.ipvaMesVencimento; 
	} 

	public void setIpvaMesVencimento(String ipvaMesVencimento) { 
		this.ipvaMesVencimento = ipvaMesVencimento; 
	} 

	public String getDpvatMesVencimento() { 
		return this.dpvatMesVencimento; 
	} 

	public void setDpvatMesVencimento(String dpvatMesVencimento) { 
		this.dpvatMesVencimento = dpvatMesVencimento; 
	} 

	public Set<FrotaIpvaControleModel> getFrotaIpvaControleModelList() { 
	return this.frotaIpvaControleModelList; 
	} 

	public void setFrotaIpvaControleModelList(Set<FrotaIpvaControleModel> frotaIpvaControleModelList) { 
	this.frotaIpvaControleModelList = frotaIpvaControleModelList; 
		for (FrotaIpvaControleModel frotaIpvaControleModel : frotaIpvaControleModelList) { 
			frotaIpvaControleModel.setFrotaVeiculoModel(this); 
		}
	} 

	public Set<FrotaDpvatControleModel> getFrotaDpvatControleModelList() { 
	return this.frotaDpvatControleModelList; 
	} 

	public void setFrotaDpvatControleModelList(Set<FrotaDpvatControleModel> frotaDpvatControleModelList) { 
	this.frotaDpvatControleModelList = frotaDpvatControleModelList; 
		for (FrotaDpvatControleModel frotaDpvatControleModel : frotaDpvatControleModelList) { 
			frotaDpvatControleModel.setFrotaVeiculoModel(this); 
		}
	} 

	public Set<FrotaVeiculoSinistroModel> getFrotaVeiculoSinistroModelList() { 
	return this.frotaVeiculoSinistroModelList; 
	} 

	public void setFrotaVeiculoSinistroModelList(Set<FrotaVeiculoSinistroModel> frotaVeiculoSinistroModelList) { 
	this.frotaVeiculoSinistroModelList = frotaVeiculoSinistroModelList; 
		for (FrotaVeiculoSinistroModel frotaVeiculoSinistroModel : frotaVeiculoSinistroModelList) { 
			frotaVeiculoSinistroModel.setFrotaVeiculoModel(this); 
		}
	} 

	public Set<FrotaVeiculoMovimentacaoModel> getFrotaVeiculoMovimentacaoModelList() { 
	return this.frotaVeiculoMovimentacaoModelList; 
	} 

	public void setFrotaVeiculoMovimentacaoModelList(Set<FrotaVeiculoMovimentacaoModel> frotaVeiculoMovimentacaoModelList) { 
	this.frotaVeiculoMovimentacaoModelList = frotaVeiculoMovimentacaoModelList; 
		for (FrotaVeiculoMovimentacaoModel frotaVeiculoMovimentacaoModel : frotaVeiculoMovimentacaoModelList) { 
			frotaVeiculoMovimentacaoModel.setFrotaVeiculoModel(this); 
		}
	} 

	public Set<FrotaVeiculoPneuModel> getFrotaVeiculoPneuModelList() { 
	return this.frotaVeiculoPneuModelList; 
	} 

	public void setFrotaVeiculoPneuModelList(Set<FrotaVeiculoPneuModel> frotaVeiculoPneuModelList) { 
	this.frotaVeiculoPneuModelList = frotaVeiculoPneuModelList; 
		for (FrotaVeiculoPneuModel frotaVeiculoPneuModel : frotaVeiculoPneuModelList) { 
			frotaVeiculoPneuModel.setFrotaVeiculoModel(this); 
		}
	} 

	public Set<FrotaVeiculoManutencaoModel> getFrotaVeiculoManutencaoModelList() { 
	return this.frotaVeiculoManutencaoModelList; 
	} 

	public void setFrotaVeiculoManutencaoModelList(Set<FrotaVeiculoManutencaoModel> frotaVeiculoManutencaoModelList) { 
	this.frotaVeiculoManutencaoModelList = frotaVeiculoManutencaoModelList; 
		for (FrotaVeiculoManutencaoModel frotaVeiculoManutencaoModel : frotaVeiculoManutencaoModelList) { 
			frotaVeiculoManutencaoModel.setFrotaVeiculoModel(this); 
		}
	} 

	public Set<FrotaMultaControleModel> getFrotaMultaControleModelList() { 
	return this.frotaMultaControleModelList; 
	} 

	public void setFrotaMultaControleModelList(Set<FrotaMultaControleModel> frotaMultaControleModelList) { 
	this.frotaMultaControleModelList = frotaMultaControleModelList; 
		for (FrotaMultaControleModel frotaMultaControleModel : frotaMultaControleModelList) { 
			frotaMultaControleModel.setFrotaVeiculoModel(this); 
		}
	} 

	public Set<FrotaCombustivelControleModel> getFrotaCombustivelControleModelList() { 
	return this.frotaCombustivelControleModelList; 
	} 

	public void setFrotaCombustivelControleModelList(Set<FrotaCombustivelControleModel> frotaCombustivelControleModelList) { 
	this.frotaCombustivelControleModelList = frotaCombustivelControleModelList; 
		for (FrotaCombustivelControleModel frotaCombustivelControleModel : frotaCombustivelControleModelList) { 
			frotaCombustivelControleModel.setFrotaVeiculoModel(this); 
		}
	} 

	public FrotaVeiculoTipoModel getFrotaVeiculoTipoModel() { 
	return this.frotaVeiculoTipoModel; 
	} 

	public void setFrotaVeiculoTipoModel(FrotaVeiculoTipoModel frotaVeiculoTipoModel) { 
	this.frotaVeiculoTipoModel = frotaVeiculoTipoModel; 
	} 

	public FrotaCombustivelTipoModel getFrotaCombustivelTipoModel() { 
	return this.frotaCombustivelTipoModel; 
	} 

	public void setFrotaCombustivelTipoModel(FrotaCombustivelTipoModel frotaCombustivelTipoModel) { 
	this.frotaCombustivelTipoModel = frotaCombustivelTipoModel; 
	} 

		
}