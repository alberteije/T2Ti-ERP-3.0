package com.t2ti.frotas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.frotas.util.Filter;
import com.t2ti.frotas.exception.GenericException;
import com.t2ti.frotas.model.FrotaVeiculoModel;
import com.t2ti.frotas.repository.FrotaVeiculoRepository;

@Service
public class FrotaVeiculoService {

	@Autowired
	private FrotaVeiculoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FrotaVeiculoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FrotaVeiculoModel> getList(Filter filter) {
		String sql = "select * from frota_veiculo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FrotaVeiculoModel.class);
		return query.getResultList();
	}

	public FrotaVeiculoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FrotaVeiculoModel save(FrotaVeiculoModel obj) {
		FrotaVeiculoModel frotaVeiculoModel = repository.save(obj);
		return frotaVeiculoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FrotaVeiculoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FrotaVeiculo] - Exception: " + e.getMessage());
		}
	}

}