package com.t2ti.frotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.frotas.model.FrotaVeiculoTipoModel;

public interface FrotaVeiculoTipoRepository extends JpaRepository<FrotaVeiculoTipoModel, Integer> {}