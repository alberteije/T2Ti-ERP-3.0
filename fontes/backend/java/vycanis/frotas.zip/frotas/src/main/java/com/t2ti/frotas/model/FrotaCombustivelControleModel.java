package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_combustivel_controle")
@NamedQuery(name="FrotaCombustivelControleModel.findAll", query="SELECT t FROM FrotaCombustivelControleModel t")
public class FrotaCombustivelControleModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaCombustivelControleModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_abastecimento")
	private Date dataAbastecimento;

	@Column(name="hora_abastecimento")
	private String horaAbastecimento;

	@Column(name="valor_abastecimento")
	private BigDecimal valorAbastecimento;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_frota_veiculo")
	private FrotaVeiculoModel frotaVeiculoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataAbastecimento() { 
		return this.dataAbastecimento; 
	} 

	public void setDataAbastecimento(Date dataAbastecimento) { 
		this.dataAbastecimento = dataAbastecimento; 
	} 

	public String getHoraAbastecimento() { 
		return this.horaAbastecimento; 
	} 

	public void setHoraAbastecimento(String horaAbastecimento) { 
		this.horaAbastecimento = horaAbastecimento; 
	} 

	public BigDecimal getValorAbastecimento() { 
		return this.valorAbastecimento; 
	} 

	public void setValorAbastecimento(BigDecimal valorAbastecimento) { 
		this.valorAbastecimento = valorAbastecimento; 
	} 

	public FrotaVeiculoModel getFrotaVeiculoModel() { 
	return this.frotaVeiculoModel; 
	} 

	public void setFrotaVeiculoModel(FrotaVeiculoModel frotaVeiculoModel) { 
	this.frotaVeiculoModel = frotaVeiculoModel; 
	} 

		
}