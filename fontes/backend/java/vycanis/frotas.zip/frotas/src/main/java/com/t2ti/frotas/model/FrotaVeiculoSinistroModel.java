package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_veiculo_sinistro")
@NamedQuery(name="FrotaVeiculoSinistroModel.findAll", query="SELECT t FROM FrotaVeiculoSinistroModel t")
public class FrotaVeiculoSinistroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaVeiculoSinistroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_sinistro")
	private Date dataSinistro;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_frota_veiculo")
	private FrotaVeiculoModel frotaVeiculoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataSinistro() { 
		return this.dataSinistro; 
	} 

	public void setDataSinistro(Date dataSinistro) { 
		this.dataSinistro = dataSinistro; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public FrotaVeiculoModel getFrotaVeiculoModel() { 
	return this.frotaVeiculoModel; 
	} 

	public void setFrotaVeiculoModel(FrotaVeiculoModel frotaVeiculoModel) { 
	this.frotaVeiculoModel = frotaVeiculoModel; 
	} 

		
}