package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_veiculo_pneu")
@NamedQuery(name="FrotaVeiculoPneuModel.findAll", query="SELECT t FROM FrotaVeiculoPneuModel t")
public class FrotaVeiculoPneuModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaVeiculoPneuModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_troca")
	private Date dataTroca;

	@Column(name="valor_troca")
	private BigDecimal valorTroca;

	@Column(name="posicao_pneu")
	private String posicaoPneu;

	@Column(name="marca_pneu")
	private String marcaPneu;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_frota_veiculo")
	private FrotaVeiculoModel frotaVeiculoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataTroca() { 
		return this.dataTroca; 
	} 

	public void setDataTroca(Date dataTroca) { 
		this.dataTroca = dataTroca; 
	} 

	public BigDecimal getValorTroca() { 
		return this.valorTroca; 
	} 

	public void setValorTroca(BigDecimal valorTroca) { 
		this.valorTroca = valorTroca; 
	} 

	public String getPosicaoPneu() { 
		return this.posicaoPneu; 
	} 

	public void setPosicaoPneu(String posicaoPneu) { 
		this.posicaoPneu = posicaoPneu; 
	} 

	public String getMarcaPneu() { 
		return this.marcaPneu; 
	} 

	public void setMarcaPneu(String marcaPneu) { 
		this.marcaPneu = marcaPneu; 
	} 

	public FrotaVeiculoModel getFrotaVeiculoModel() { 
	return this.frotaVeiculoModel; 
	} 

	public void setFrotaVeiculoModel(FrotaVeiculoModel frotaVeiculoModel) { 
	this.frotaVeiculoModel = frotaVeiculoModel; 
	} 

		
}