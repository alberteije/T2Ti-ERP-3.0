package com.t2ti.frotas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.frotas.util.Filter;
import com.t2ti.frotas.exception.GenericException;
import com.t2ti.frotas.model.FrotaVeiculoTipoModel;
import com.t2ti.frotas.repository.FrotaVeiculoTipoRepository;

@Service
public class FrotaVeiculoTipoService {

	@Autowired
	private FrotaVeiculoTipoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FrotaVeiculoTipoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FrotaVeiculoTipoModel> getList(Filter filter) {
		String sql = "select * from frota_veiculo_tipo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FrotaVeiculoTipoModel.class);
		return query.getResultList();
	}

	public FrotaVeiculoTipoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FrotaVeiculoTipoModel save(FrotaVeiculoTipoModel obj) {
		FrotaVeiculoTipoModel frotaVeiculoTipoModel = repository.save(obj);
		return frotaVeiculoTipoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FrotaVeiculoTipoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FrotaVeiculoTipo] - Exception: " + e.getMessage());
		}
	}

}