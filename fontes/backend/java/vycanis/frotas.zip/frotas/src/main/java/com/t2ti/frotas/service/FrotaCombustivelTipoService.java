package com.t2ti.frotas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.frotas.util.Filter;
import com.t2ti.frotas.exception.GenericException;
import com.t2ti.frotas.model.FrotaCombustivelTipoModel;
import com.t2ti.frotas.repository.FrotaCombustivelTipoRepository;

@Service
public class FrotaCombustivelTipoService {

	@Autowired
	private FrotaCombustivelTipoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FrotaCombustivelTipoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FrotaCombustivelTipoModel> getList(Filter filter) {
		String sql = "select * from frota_combustivel_tipo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FrotaCombustivelTipoModel.class);
		return query.getResultList();
	}

	public FrotaCombustivelTipoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FrotaCombustivelTipoModel save(FrotaCombustivelTipoModel obj) {
		FrotaCombustivelTipoModel frotaCombustivelTipoModel = repository.save(obj);
		return frotaCombustivelTipoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FrotaCombustivelTipoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FrotaCombustivelTipo] - Exception: " + e.getMessage());
		}
	}

}