package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_multa_controle")
@NamedQuery(name="FrotaMultaControleModel.findAll", query="SELECT t FROM FrotaMultaControleModel t")
public class FrotaMultaControleModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaMultaControleModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_multa")
	private Date dataMulta;

	@Column(name="pontos")
	private Integer pontos;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_frota_veiculo")
	private FrotaVeiculoModel frotaVeiculoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataMulta() { 
		return this.dataMulta; 
	} 

	public void setDataMulta(Date dataMulta) { 
		this.dataMulta = dataMulta; 
	} 

	public Integer getPontos() { 
		return this.pontos; 
	} 

	public void setPontos(Integer pontos) { 
		this.pontos = pontos; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public FrotaVeiculoModel getFrotaVeiculoModel() { 
	return this.frotaVeiculoModel; 
	} 

	public void setFrotaVeiculoModel(FrotaVeiculoModel frotaVeiculoModel) { 
	this.frotaVeiculoModel = frotaVeiculoModel; 
	} 

		
}