package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_veiculo_movimentacao")
@NamedQuery(name="FrotaVeiculoMovimentacaoModel.findAll", query="SELECT t FROM FrotaVeiculoMovimentacaoModel t")
public class FrotaVeiculoMovimentacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaVeiculoMovimentacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_saida")
	private Date dataSaida;

	@Column(name="hora_saida")
	private String horaSaida;

	@Temporal(TemporalType.DATE)
@Column(name="data_entrada")
	private Date dataEntrada;

	@Column(name="hora_entrada")
	private String horaEntrada;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_frota_veiculo")
	private FrotaVeiculoModel frotaVeiculoModel; 

	@ManyToOne 
	@JoinColumn(name="id_frota_motorista")
	private FrotaMotoristaModel frotaMotoristaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataSaida() { 
		return this.dataSaida; 
	} 

	public void setDataSaida(Date dataSaida) { 
		this.dataSaida = dataSaida; 
	} 

	public String getHoraSaida() { 
		return this.horaSaida; 
	} 

	public void setHoraSaida(String horaSaida) { 
		this.horaSaida = horaSaida; 
	} 

	public Date getDataEntrada() { 
		return this.dataEntrada; 
	} 

	public void setDataEntrada(Date dataEntrada) { 
		this.dataEntrada = dataEntrada; 
	} 

	public String getHoraEntrada() { 
		return this.horaEntrada; 
	} 

	public void setHoraEntrada(String horaEntrada) { 
		this.horaEntrada = horaEntrada; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public FrotaVeiculoModel getFrotaVeiculoModel() { 
	return this.frotaVeiculoModel; 
	} 

	public void setFrotaVeiculoModel(FrotaVeiculoModel frotaVeiculoModel) { 
	this.frotaVeiculoModel = frotaVeiculoModel; 
	} 

	public FrotaMotoristaModel getFrotaMotoristaModel() { 
	return this.frotaMotoristaModel; 
	} 

	public void setFrotaMotoristaModel(FrotaMotoristaModel frotaMotoristaModel) { 
	this.frotaMotoristaModel = frotaMotoristaModel; 
	} 

		
}