package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_veiculo_manutencao")
@NamedQuery(name="FrotaVeiculoManutencaoModel.findAll", query="SELECT t FROM FrotaVeiculoManutencaoModel t")
public class FrotaVeiculoManutencaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaVeiculoManutencaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo")
	private String tipo;

	@Temporal(TemporalType.DATE)
@Column(name="data_manutencao")
	private Date dataManutencao;

	@Column(name="valor_manutencao")
	private BigDecimal valorManutencao;

	@Column(name="observacao")
	private String observacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_frota_veiculo")
	private FrotaVeiculoModel frotaVeiculoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public Date getDataManutencao() { 
		return this.dataManutencao; 
	} 

	public void setDataManutencao(Date dataManutencao) { 
		this.dataManutencao = dataManutencao; 
	} 

	public BigDecimal getValorManutencao() { 
		return this.valorManutencao; 
	} 

	public void setValorManutencao(BigDecimal valorManutencao) { 
		this.valorManutencao = valorManutencao; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public FrotaVeiculoModel getFrotaVeiculoModel() { 
	return this.frotaVeiculoModel; 
	} 

	public void setFrotaVeiculoModel(FrotaVeiculoModel frotaVeiculoModel) { 
	this.frotaVeiculoModel = frotaVeiculoModel; 
	} 

		
}