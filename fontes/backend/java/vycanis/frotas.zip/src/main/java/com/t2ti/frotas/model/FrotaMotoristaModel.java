package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_motorista")
@NamedQuery(name="FrotaMotoristaModel.findAll", query="SELECT t FROM FrotaMotoristaModel t")
public class FrotaMotoristaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaMotoristaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="numero_cnh")
	private String numeroCnh;

	@Column(name="cnh_categoria")
	private String cnhCategoria;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getNumeroCnh() { 
		return this.numeroCnh; 
	} 

	public void setNumeroCnh(String numeroCnh) { 
		this.numeroCnh = numeroCnh; 
	} 

	public String getCnhCategoria() { 
		return this.cnhCategoria; 
	} 

	public void setCnhCategoria(String cnhCategoria) { 
		this.cnhCategoria = cnhCategoria; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}