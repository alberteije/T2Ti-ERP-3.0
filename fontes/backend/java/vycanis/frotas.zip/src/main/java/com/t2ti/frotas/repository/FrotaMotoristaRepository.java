package com.t2ti.frotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.frotas.model.FrotaMotoristaModel;

public interface FrotaMotoristaRepository extends JpaRepository<FrotaMotoristaModel, Integer> {}