package com.t2ti.frotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.frotas.model.ViewPessoaColaboradorModel;

public interface ViewPessoaColaboradorRepository extends JpaRepository<ViewPessoaColaboradorModel, Integer> {}