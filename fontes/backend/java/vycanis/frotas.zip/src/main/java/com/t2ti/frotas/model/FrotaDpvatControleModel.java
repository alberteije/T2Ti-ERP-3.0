package com.t2ti.frotas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="frota_dpvat_controle")
@NamedQuery(name="FrotaDpvatControleModel.findAll", query="SELECT t FROM FrotaDpvatControleModel t")
public class FrotaDpvatControleModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FrotaDpvatControleModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="ano")
	private String ano;

	@Column(name="parcela")
	private String parcela;

	@Temporal(TemporalType.DATE)
@Column(name="data_vencimento")
	private Date dataVencimento;

	@Temporal(TemporalType.DATE)
@Column(name="data_pagamento")
	private Date dataPagamento;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_frota_veiculo")
	private FrotaVeiculoModel frotaVeiculoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getAno() { 
		return this.ano; 
	} 

	public void setAno(String ano) { 
		this.ano = ano; 
	} 

	public String getParcela() { 
		return this.parcela; 
	} 

	public void setParcela(String parcela) { 
		this.parcela = parcela; 
	} 

	public Date getDataVencimento() { 
		return this.dataVencimento; 
	} 

	public void setDataVencimento(Date dataVencimento) { 
		this.dataVencimento = dataVencimento; 
	} 

	public Date getDataPagamento() { 
		return this.dataPagamento; 
	} 

	public void setDataPagamento(Date dataPagamento) { 
		this.dataPagamento = dataPagamento; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public FrotaVeiculoModel getFrotaVeiculoModel() { 
	return this.frotaVeiculoModel; 
	} 

	public void setFrotaVeiculoModel(FrotaVeiculoModel frotaVeiculoModel) { 
	this.frotaVeiculoModel = frotaVeiculoModel; 
	} 

		
}