package com.t2ti.agenda.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.agenda.util.Filter;
import com.t2ti.agenda.exception.GenericException;
import com.t2ti.agenda.model.AgendaCompromissoModel;
import com.t2ti.agenda.repository.AgendaCompromissoRepository;

@Service
public class AgendaCompromissoService {

	@Autowired
	private AgendaCompromissoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<AgendaCompromissoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<AgendaCompromissoModel> getList(Filter filter) {
		String sql = "select * from agenda_compromisso where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, AgendaCompromissoModel.class);
		return query.getResultList();
	}

	public AgendaCompromissoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public AgendaCompromissoModel save(AgendaCompromissoModel obj) {
		AgendaCompromissoModel agendaCompromissoModel = repository.save(obj);
		return agendaCompromissoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		AgendaCompromissoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete AgendaCompromisso] - Exception: " + e.getMessage());
		}
	}

}