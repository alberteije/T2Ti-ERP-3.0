package com.t2ti.agenda.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="recado_destinatario")
@NamedQuery(name="RecadoDestinatarioModel.findAll", query="SELECT t FROM RecadoDestinatarioModel t")
public class RecadoDestinatarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public RecadoDestinatarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_recado_remetente")
	private RecadoRemetenteModel recadoRemetenteModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public RecadoRemetenteModel getRecadoRemetenteModel() { 
	return this.recadoRemetenteModel; 
	} 

	public void setRecadoRemetenteModel(RecadoRemetenteModel recadoRemetenteModel) { 
	this.recadoRemetenteModel = recadoRemetenteModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}