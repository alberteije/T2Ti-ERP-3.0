package com.t2ti.agenda.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="agenda_compromisso_convidado")
@NamedQuery(name="AgendaCompromissoConvidadoModel.findAll", query="SELECT t FROM AgendaCompromissoConvidadoModel t")
public class AgendaCompromissoConvidadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public AgendaCompromissoConvidadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_agenda_compromisso")
	private AgendaCompromissoModel agendaCompromissoModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public AgendaCompromissoModel getAgendaCompromissoModel() { 
	return this.agendaCompromissoModel; 
	} 

	public void setAgendaCompromissoModel(AgendaCompromissoModel agendaCompromissoModel) { 
	this.agendaCompromissoModel = agendaCompromissoModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}