package com.t2ti.agenda.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="agenda_compromisso")
@NamedQuery(name="AgendaCompromissoModel.findAll", query="SELECT t FROM AgendaCompromissoModel t")
public class AgendaCompromissoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public AgendaCompromissoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_compromisso")
	private Date dataCompromisso;

	@Column(name="hora")
	private String hora;

	@Column(name="duracao")
	private Integer duracao;

	@Column(name="tipo")
	private String tipo;

	@Column(name="onde")
	private String onde;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "agendaCompromissoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<AgendaNotificacaoModel> agendaNotificacaoModelList; 

	@OneToMany(mappedBy = "agendaCompromissoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<AgendaCompromissoConvidadoModel> agendaCompromissoConvidadoModelList; 

	@OneToMany(mappedBy = "agendaCompromissoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ReuniaoSalaEventoModel> reuniaoSalaEventoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_agenda_categoria_compromisso")
	private AgendaCategoriaCompromissoModel agendaCategoriaCompromissoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataCompromisso() { 
		return this.dataCompromisso; 
	} 

	public void setDataCompromisso(Date dataCompromisso) { 
		this.dataCompromisso = dataCompromisso; 
	} 

	public String getHora() { 
		return this.hora; 
	} 

	public void setHora(String hora) { 
		this.hora = hora; 
	} 

	public Integer getDuracao() { 
		return this.duracao; 
	} 

	public void setDuracao(Integer duracao) { 
		this.duracao = duracao; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getOnde() { 
		return this.onde; 
	} 

	public void setOnde(String onde) { 
		this.onde = onde; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<AgendaNotificacaoModel> getAgendaNotificacaoModelList() { 
	return this.agendaNotificacaoModelList; 
	} 

	public void setAgendaNotificacaoModelList(Set<AgendaNotificacaoModel> agendaNotificacaoModelList) { 
	this.agendaNotificacaoModelList = agendaNotificacaoModelList; 
		for (AgendaNotificacaoModel agendaNotificacaoModel : agendaNotificacaoModelList) { 
			agendaNotificacaoModel.setAgendaCompromissoModel(this); 
		}
	} 

	public Set<AgendaCompromissoConvidadoModel> getAgendaCompromissoConvidadoModelList() { 
	return this.agendaCompromissoConvidadoModelList; 
	} 

	public void setAgendaCompromissoConvidadoModelList(Set<AgendaCompromissoConvidadoModel> agendaCompromissoConvidadoModelList) { 
	this.agendaCompromissoConvidadoModelList = agendaCompromissoConvidadoModelList; 
		for (AgendaCompromissoConvidadoModel agendaCompromissoConvidadoModel : agendaCompromissoConvidadoModelList) { 
			agendaCompromissoConvidadoModel.setAgendaCompromissoModel(this); 
		}
	} 

	public Set<ReuniaoSalaEventoModel> getReuniaoSalaEventoModelList() { 
	return this.reuniaoSalaEventoModelList; 
	} 

	public void setReuniaoSalaEventoModelList(Set<ReuniaoSalaEventoModel> reuniaoSalaEventoModelList) { 
	this.reuniaoSalaEventoModelList = reuniaoSalaEventoModelList; 
		for (ReuniaoSalaEventoModel reuniaoSalaEventoModel : reuniaoSalaEventoModelList) { 
			reuniaoSalaEventoModel.setAgendaCompromissoModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public AgendaCategoriaCompromissoModel getAgendaCategoriaCompromissoModel() { 
	return this.agendaCategoriaCompromissoModel; 
	} 

	public void setAgendaCategoriaCompromissoModel(AgendaCategoriaCompromissoModel agendaCategoriaCompromissoModel) { 
	this.agendaCategoriaCompromissoModel = agendaCategoriaCompromissoModel; 
	} 

		
}