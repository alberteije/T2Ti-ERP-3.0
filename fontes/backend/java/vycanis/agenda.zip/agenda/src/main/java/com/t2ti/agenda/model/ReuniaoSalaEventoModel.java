package com.t2ti.agenda.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="reuniao_sala_evento")
@NamedQuery(name="ReuniaoSalaEventoModel.findAll", query="SELECT t FROM ReuniaoSalaEventoModel t")
public class ReuniaoSalaEventoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ReuniaoSalaEventoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_reserva")
	private Date dataReserva;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_agenda_compromisso")
	private AgendaCompromissoModel agendaCompromissoModel; 

	@ManyToOne 
	@JoinColumn(name="id_reuniao_sala")
	private ReuniaoSalaModel reuniaoSalaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataReserva() { 
		return this.dataReserva; 
	} 

	public void setDataReserva(Date dataReserva) { 
		this.dataReserva = dataReserva; 
	} 

	public AgendaCompromissoModel getAgendaCompromissoModel() { 
	return this.agendaCompromissoModel; 
	} 

	public void setAgendaCompromissoModel(AgendaCompromissoModel agendaCompromissoModel) { 
	this.agendaCompromissoModel = agendaCompromissoModel; 
	} 

	public ReuniaoSalaModel getReuniaoSalaModel() { 
	return this.reuniaoSalaModel; 
	} 

	public void setReuniaoSalaModel(ReuniaoSalaModel reuniaoSalaModel) { 
	this.reuniaoSalaModel = reuniaoSalaModel; 
	} 

		
}