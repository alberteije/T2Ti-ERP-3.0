package com.t2ti.agenda.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="recado_remetente")
@NamedQuery(name="RecadoRemetenteModel.findAll", query="SELECT t FROM RecadoRemetenteModel t")
public class RecadoRemetenteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public RecadoRemetenteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_envio")
	private Date dataEnvio;

	@Column(name="hora_envio")
	private String horaEnvio;

	@Column(name="assunto")
	private String assunto;

	@Column(name="texto")
	private String texto;

	@OneToMany(mappedBy = "recadoRemetenteModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<RecadoDestinatarioModel> recadoDestinatarioModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataEnvio() { 
		return this.dataEnvio; 
	} 

	public void setDataEnvio(Date dataEnvio) { 
		this.dataEnvio = dataEnvio; 
	} 

	public String getHoraEnvio() { 
		return this.horaEnvio; 
	} 

	public void setHoraEnvio(String horaEnvio) { 
		this.horaEnvio = horaEnvio; 
	} 

	public String getAssunto() { 
		return this.assunto; 
	} 

	public void setAssunto(String assunto) { 
		this.assunto = assunto; 
	} 

	public String getTexto() { 
		return this.texto; 
	} 

	public void setTexto(String texto) { 
		this.texto = texto; 
	} 

	public Set<RecadoDestinatarioModel> getRecadoDestinatarioModelList() { 
	return this.recadoDestinatarioModelList; 
	} 

	public void setRecadoDestinatarioModelList(Set<RecadoDestinatarioModel> recadoDestinatarioModelList) { 
	this.recadoDestinatarioModelList = recadoDestinatarioModelList; 
		for (RecadoDestinatarioModel recadoDestinatarioModel : recadoDestinatarioModelList) { 
			recadoDestinatarioModel.setRecadoRemetenteModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}