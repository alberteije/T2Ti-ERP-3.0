package com.t2ti.agenda.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.agenda.util.Filter;
import com.t2ti.agenda.exception.GenericException;
import com.t2ti.agenda.model.RecadoRemetenteModel;
import com.t2ti.agenda.repository.RecadoRemetenteRepository;

@Service
public class RecadoRemetenteService {

	@Autowired
	private RecadoRemetenteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<RecadoRemetenteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<RecadoRemetenteModel> getList(Filter filter) {
		String sql = "select * from recado_remetente where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, RecadoRemetenteModel.class);
		return query.getResultList();
	}

	public RecadoRemetenteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public RecadoRemetenteModel save(RecadoRemetenteModel obj) {
		RecadoRemetenteModel recadoRemetenteModel = repository.save(obj);
		return recadoRemetenteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		RecadoRemetenteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete RecadoRemetente] - Exception: " + e.getMessage());
		}
	}

}