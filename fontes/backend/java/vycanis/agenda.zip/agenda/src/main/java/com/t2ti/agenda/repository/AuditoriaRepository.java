package com.t2ti.agenda.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.agenda.model.AuditoriaModel;

public interface AuditoriaRepository extends JpaRepository<AuditoriaModel, Integer> {}