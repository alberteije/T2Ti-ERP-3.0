package com.t2ti.agenda.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.agenda.model.AgendaCategoriaCompromissoModel;

public interface AgendaCategoriaCompromissoRepository extends JpaRepository<AgendaCategoriaCompromissoModel, Integer> {}