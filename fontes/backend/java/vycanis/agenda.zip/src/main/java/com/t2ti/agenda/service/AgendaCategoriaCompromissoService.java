package com.t2ti.agenda.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.agenda.util.Filter;
import com.t2ti.agenda.exception.GenericException;
import com.t2ti.agenda.model.AgendaCategoriaCompromissoModel;
import com.t2ti.agenda.repository.AgendaCategoriaCompromissoRepository;

@Service
public class AgendaCategoriaCompromissoService {

	@Autowired
	private AgendaCategoriaCompromissoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<AgendaCategoriaCompromissoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<AgendaCategoriaCompromissoModel> getList(Filter filter) {
		String sql = "select * from agenda_categoria_compromisso where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, AgendaCategoriaCompromissoModel.class);
		return query.getResultList();
	}

	public AgendaCategoriaCompromissoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public AgendaCategoriaCompromissoModel save(AgendaCategoriaCompromissoModel obj) {
		AgendaCategoriaCompromissoModel agendaCategoriaCompromissoModel = repository.save(obj);
		return agendaCategoriaCompromissoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		AgendaCategoriaCompromissoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete AgendaCategoriaCompromisso] - Exception: " + e.getMessage());
		}
	}

}