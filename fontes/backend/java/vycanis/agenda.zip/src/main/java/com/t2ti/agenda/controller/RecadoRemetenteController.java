package com.t2ti.agenda.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.agenda.exception.GenericException;
import com.t2ti.agenda.exception.ResourseNotFoundException;
import com.t2ti.agenda.exception.BadRequestException;
import com.t2ti.agenda.util.Filter;
import com.t2ti.agenda.model.RecadoRemetenteModel;
import com.t2ti.agenda.service.RecadoRemetenteService;

@RestController
@RequestMapping(value = "/recado-remetente", produces = "application/json;charset=UTF-8")
public class RecadoRemetenteController {

	@Autowired
	private RecadoRemetenteService service;
	
	@GetMapping({ "", "/" })
	public List<RecadoRemetenteModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [RecadoRemetente] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public RecadoRemetenteModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found RecadoRemetente].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found RecadoRemetente] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public RecadoRemetenteModel insert(@RequestBody RecadoRemetenteModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert RecadoRemetente] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public RecadoRemetenteModel update(@RequestBody RecadoRemetenteModel objJson) {	
		try {			
			RecadoRemetenteModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update RecadoRemetente].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update RecadoRemetente] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete RecadoRemetente] - Exception: " + e.getMessage());
		}
	}
	
}