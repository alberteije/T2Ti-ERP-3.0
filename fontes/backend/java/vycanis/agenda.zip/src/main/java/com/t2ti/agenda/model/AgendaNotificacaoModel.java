package com.t2ti.agenda.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="agenda_notificacao")
@NamedQuery(name="AgendaNotificacaoModel.findAll", query="SELECT t FROM AgendaNotificacaoModel t")
public class AgendaNotificacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public AgendaNotificacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_notificacao")
	private Date dataNotificacao;

	@Column(name="hora")
	private String hora;

	@Column(name="tipo")
	private String tipo;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_agenda_compromisso")
	private AgendaCompromissoModel agendaCompromissoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataNotificacao() { 
		return this.dataNotificacao; 
	} 

	public void setDataNotificacao(Date dataNotificacao) { 
		this.dataNotificacao = dataNotificacao; 
	} 

	public String getHora() { 
		return this.hora; 
	} 

	public void setHora(String hora) { 
		this.hora = hora; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public AgendaCompromissoModel getAgendaCompromissoModel() { 
	return this.agendaCompromissoModel; 
	} 

	public void setAgendaCompromissoModel(AgendaCompromissoModel agendaCompromissoModel) { 
	this.agendaCompromissoModel = agendaCompromissoModel; 
	} 

		
}