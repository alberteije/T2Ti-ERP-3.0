package com.t2ti.agenda.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.agenda.exception.GenericException;
import com.t2ti.agenda.exception.ResourseNotFoundException;
import com.t2ti.agenda.exception.BadRequestException;
import com.t2ti.agenda.util.Filter;
import com.t2ti.agenda.model.AgendaCompromissoModel;
import com.t2ti.agenda.service.AgendaCompromissoService;

@RestController
@RequestMapping(value = "/agenda-compromisso", produces = "application/json;charset=UTF-8")
public class AgendaCompromissoController {

	@Autowired
	private AgendaCompromissoService service;
	
	@GetMapping({ "", "/" })
	public List<AgendaCompromissoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [AgendaCompromisso] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public AgendaCompromissoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found AgendaCompromisso].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found AgendaCompromisso] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public AgendaCompromissoModel insert(@RequestBody AgendaCompromissoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert AgendaCompromisso] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public AgendaCompromissoModel update(@RequestBody AgendaCompromissoModel objJson) {	
		try {			
			AgendaCompromissoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update AgendaCompromisso].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update AgendaCompromisso] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete AgendaCompromisso] - Exception: " + e.getMessage());
		}
	}
	
}