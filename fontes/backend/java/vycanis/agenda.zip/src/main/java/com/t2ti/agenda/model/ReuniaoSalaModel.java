package com.t2ti.agenda.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="reuniao_sala")
@NamedQuery(name="ReuniaoSalaModel.findAll", query="SELECT t FROM ReuniaoSalaModel t")
public class ReuniaoSalaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ReuniaoSalaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="predio")
	private String predio;

	@Column(name="nome")
	private String nome;

	@Column(name="andar")
	private String andar;

	@Column(name="numero")
	private String numero;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getPredio() { 
		return this.predio; 
	} 

	public void setPredio(String predio) { 
		this.predio = predio; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getAndar() { 
		return this.andar; 
	} 

	public void setAndar(String andar) { 
		this.andar = andar; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

		
}