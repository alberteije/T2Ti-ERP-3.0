package com.t2ti.agenda.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.agenda.model.ViewPessoaColaboradorModel;

public interface ViewPessoaColaboradorRepository extends JpaRepository<ViewPessoaColaboradorModel, Integer> {}