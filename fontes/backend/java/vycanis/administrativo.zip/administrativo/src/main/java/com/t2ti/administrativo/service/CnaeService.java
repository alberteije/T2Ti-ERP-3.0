package com.t2ti.administrativo.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.administrativo.util.Filter;
import com.t2ti.administrativo.exception.GenericException;
import com.t2ti.administrativo.model.CnaeModel;
import com.t2ti.administrativo.repository.CnaeRepository;

@Service
public class CnaeService {

	@Autowired
	private CnaeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CnaeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CnaeModel> getList(Filter filter) {
		String sql = "select * from cnae where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CnaeModel.class);
		return query.getResultList();
	}

	public CnaeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CnaeModel save(CnaeModel obj) {
		CnaeModel cnaeModel = repository.save(obj);
		return cnaeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CnaeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Cnae] - Exception: " + e.getMessage());
		}
	}

}