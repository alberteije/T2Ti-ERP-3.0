package com.t2ti.administrativo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdministrativoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdministrativoApplication.class, args);
	}

}
