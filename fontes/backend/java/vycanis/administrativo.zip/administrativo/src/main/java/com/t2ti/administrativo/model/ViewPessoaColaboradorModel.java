package com.t2ti.administrativo.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="view_pessoa_colaborador")
@NamedQuery(name="ViewPessoaColaboradorModel.findAll", query="SELECT t FROM ViewPessoaColaboradorModel t")
public class ViewPessoaColaboradorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ViewPessoaColaboradorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="tipo")
	private String tipo;

	@Column(name="email")
	private String email;

	@Column(name="site")
	private String site;

	@Column(name="cpf_cnpj")
	private String cpfCnpj;

	@Column(name="rg_ie")
	private String rgIe;

	@Column(name="matricula")
	private String matricula;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
@Column(name="data_admissao")
	private Date dataAdmissao;

	@Temporal(TemporalType.DATE)
@Column(name="data_demissao")
	private Date dataDemissao;

	@Column(name="ctps_numero")
	private String ctpsNumero;

	@Column(name="ctps_serie")
	private String ctpsSerie;

	@Temporal(TemporalType.DATE)
@Column(name="ctps_data_expedicao")
	private Date ctpsDataExpedicao;

	@Column(name="ctps_uf")
	private String ctpsUf;

	@Column(name="observacao")
	private String observacao;

	@Column(name="logradouro")
	private String logradouro;

	@Column(name="numero")
	private String numero;

	@Column(name="complemento")
	private String complemento;

	@Column(name="bairro")
	private String bairro;

	@Column(name="cidade")
	private String cidade;

	@Column(name="cep")
	private String cep;

	@Column(name="municipio_ibge")
	private String municipioIbge;

	@Column(name="uf")
	private String uf;

	@Column(name="id_pessoa")
	private Integer idPessoa;

	@Column(name="id_cargo")
	private Integer idCargo;

	@Column(name="id_setor")
	private Integer idSetor;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public String getSite() { 
		return this.site; 
	} 

	public void setSite(String site) { 
		this.site = site; 
	} 

	public String getCpfCnpj() { 
		return this.cpfCnpj; 
	} 

	public void setCpfCnpj(String cpfCnpj) { 
		this.cpfCnpj = cpfCnpj; 
	} 

	public String getRgIe() { 
		return this.rgIe; 
	} 

	public void setRgIe(String rgIe) { 
		this.rgIe = rgIe; 
	} 

	public String getMatricula() { 
		return this.matricula; 
	} 

	public void setMatricula(String matricula) { 
		this.matricula = matricula; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public Date getDataAdmissao() { 
		return this.dataAdmissao; 
	} 

	public void setDataAdmissao(Date dataAdmissao) { 
		this.dataAdmissao = dataAdmissao; 
	} 

	public Date getDataDemissao() { 
		return this.dataDemissao; 
	} 

	public void setDataDemissao(Date dataDemissao) { 
		this.dataDemissao = dataDemissao; 
	} 

	public String getCtpsNumero() { 
		return this.ctpsNumero; 
	} 

	public void setCtpsNumero(String ctpsNumero) { 
		this.ctpsNumero = ctpsNumero; 
	} 

	public String getCtpsSerie() { 
		return this.ctpsSerie; 
	} 

	public void setCtpsSerie(String ctpsSerie) { 
		this.ctpsSerie = ctpsSerie; 
	} 

	public Date getCtpsDataExpedicao() { 
		return this.ctpsDataExpedicao; 
	} 

	public void setCtpsDataExpedicao(Date ctpsDataExpedicao) { 
		this.ctpsDataExpedicao = ctpsDataExpedicao; 
	} 

	public String getCtpsUf() { 
		return this.ctpsUf; 
	} 

	public void setCtpsUf(String ctpsUf) { 
		this.ctpsUf = ctpsUf; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public String getLogradouro() { 
		return this.logradouro; 
	} 

	public void setLogradouro(String logradouro) { 
		this.logradouro = logradouro; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getComplemento() { 
		return this.complemento; 
	} 

	public void setComplemento(String complemento) { 
		this.complemento = complemento; 
	} 

	public String getBairro() { 
		return this.bairro; 
	} 

	public void setBairro(String bairro) { 
		this.bairro = bairro; 
	} 

	public String getCidade() { 
		return this.cidade; 
	} 

	public void setCidade(String cidade) { 
		this.cidade = cidade; 
	} 

	public String getCep() { 
		return this.cep; 
	} 

	public void setCep(String cep) { 
		this.cep = cep; 
	} 

	public String getMunicipioIbge() { 
		return this.municipioIbge; 
	} 

	public void setMunicipioIbge(String municipioIbge) { 
		this.municipioIbge = municipioIbge; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public Integer getIdPessoa() { 
		return this.idPessoa; 
	} 

	public void setIdPessoa(Integer idPessoa) { 
		this.idPessoa = idPessoa; 
	} 

	public Integer getIdCargo() { 
		return this.idCargo; 
	} 

	public void setIdCargo(Integer idCargo) { 
		this.idCargo = idCargo; 
	} 

	public Integer getIdSetor() { 
		return this.idSetor; 
	} 

	public void setIdSetor(Integer idSetor) { 
		this.idSetor = idSetor; 
	} 

		
}