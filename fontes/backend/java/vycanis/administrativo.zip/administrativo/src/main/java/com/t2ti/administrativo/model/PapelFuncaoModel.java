package com.t2ti.administrativo.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="papel_funcao")
@NamedQuery(name="PapelFuncaoModel.findAll", query="SELECT t FROM PapelFuncaoModel t")
public class PapelFuncaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PapelFuncaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="habilitado")
	private String habilitado;

	@Column(name="pode_inserir")
	private String podeInserir;

	@Column(name="pode_alterar")
	private String podeAlterar;

	@Column(name="pode_excluir")
	private String podeExcluir;

	@ManyToOne 
	@JoinColumn(name="id_funcao")
	private FuncaoModel funcaoModel; 

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_papel")
	private PapelModel papelModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getHabilitado() { 
		return this.habilitado; 
	} 

	public void setHabilitado(String habilitado) { 
		this.habilitado = habilitado; 
	} 

	public String getPodeInserir() { 
		return this.podeInserir; 
	} 

	public void setPodeInserir(String podeInserir) { 
		this.podeInserir = podeInserir; 
	} 

	public String getPodeAlterar() { 
		return this.podeAlterar; 
	} 

	public void setPodeAlterar(String podeAlterar) { 
		this.podeAlterar = podeAlterar; 
	} 

	public String getPodeExcluir() { 
		return this.podeExcluir; 
	} 

	public void setPodeExcluir(String podeExcluir) { 
		this.podeExcluir = podeExcluir; 
	} 

	public FuncaoModel getFuncaoModel() { 
	return this.funcaoModel; 
	} 

	public void setFuncaoModel(FuncaoModel funcaoModel) { 
	this.funcaoModel = funcaoModel; 
	} 

	public PapelModel getPapelModel() { 
	return this.papelModel; 
	} 

	public void setPapelModel(PapelModel papelModel) { 
	this.papelModel = papelModel; 
	} 

		
}