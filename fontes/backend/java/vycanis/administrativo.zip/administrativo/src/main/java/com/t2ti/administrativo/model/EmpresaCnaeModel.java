package com.t2ti.administrativo.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="empresa_cnae")
@NamedQuery(name="EmpresaCnaeModel.findAll", query="SELECT t FROM EmpresaCnaeModel t")
public class EmpresaCnaeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EmpresaCnaeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="principal")
	private String principal;

	@Column(name="ramo_atividade")
	private String ramoAtividade;

	@Column(name="objeto_social")
	private String objetoSocial;

	@ManyToOne 
	@JoinColumn(name="id_cnae")
	private CnaeModel cnaeModel; 

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_empresa")
	private EmpresaModel empresaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getPrincipal() { 
		return this.principal; 
	} 

	public void setPrincipal(String principal) { 
		this.principal = principal; 
	} 

	public String getRamoAtividade() { 
		return this.ramoAtividade; 
	} 

	public void setRamoAtividade(String ramoAtividade) { 
		this.ramoAtividade = ramoAtividade; 
	} 

	public String getObjetoSocial() { 
		return this.objetoSocial; 
	} 

	public void setObjetoSocial(String objetoSocial) { 
		this.objetoSocial = objetoSocial; 
	} 

	public CnaeModel getCnaeModel() { 
	return this.cnaeModel; 
	} 

	public void setCnaeModel(CnaeModel cnaeModel) { 
	this.cnaeModel = cnaeModel; 
	} 

	public EmpresaModel getEmpresaModel() { 
	return this.empresaModel; 
	} 

	public void setEmpresaModel(EmpresaModel empresaModel) { 
	this.empresaModel = empresaModel; 
	} 

		
}