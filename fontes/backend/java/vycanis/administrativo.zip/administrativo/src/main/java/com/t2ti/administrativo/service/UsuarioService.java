package com.t2ti.administrativo.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.administrativo.util.Filter;
import com.t2ti.administrativo.exception.GenericException;
import com.t2ti.administrativo.model.UsuarioModel;
import com.t2ti.administrativo.repository.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<UsuarioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<UsuarioModel> getList(Filter filter) {
		String sql = "select * from usuario where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, UsuarioModel.class);
		return query.getResultList();
	}

	public UsuarioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public UsuarioModel getObjectFilter(String filtro) {
		String sql = "select * from usuario where " + filtro;
		Query query = entityManager.createNativeQuery(sql, UsuarioModel.class);
		if (query.getResultList().size() > 0) {
			return (UsuarioModel) query.getResultList().get(0);
		} else {
			return null;
		}
	}
	public UsuarioModel save(UsuarioModel obj) {
		UsuarioModel usuarioModel = repository.save(obj);
		return usuarioModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		UsuarioModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Usuario] - Exception: " + e.getMessage());
		}
	}

}