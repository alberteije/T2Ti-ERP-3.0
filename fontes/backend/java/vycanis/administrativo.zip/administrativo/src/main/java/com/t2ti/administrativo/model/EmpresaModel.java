package com.t2ti.administrativo.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="empresa")
@NamedQuery(name="EmpresaModel.findAll", query="SELECT t FROM EmpresaModel t")
public class EmpresaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EmpresaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="razao_social")
	private String razaoSocial;

	@Column(name="nome_fantasia")
	private String nomeFantasia;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="inscricao_estadual")
	private String inscricaoEstadual;

	@Column(name="inscricao_municipal")
	private String inscricaoMunicipal;

	@Column(name="tipo_regime")
	private String tipoRegime;

	@Column(name="crt")
	private String crt;

	@Column(name="email")
	private String email;

	@Column(name="site")
	private String site;

	@Column(name="contato")
	private String contato;

	@Temporal(TemporalType.DATE)
@Column(name="data_constituicao")
	private Date dataConstituicao;

	@Column(name="tipo")
	private String tipo;

	@Column(name="inscricao_junta_comercial")
	private String inscricaoJuntaComercial;

	@Temporal(TemporalType.DATE)
@Column(name="data_insc_junta_comercial")
	private Date dataInscJuntaComercial;

	@Column(name="codigo_ibge_cidade")
	private Integer codigoIbgeCidade;

	@Column(name="codigo_ibge_uf")
	private Integer codigoIbgeUf;

	@Column(name="cei")
	private String cei;

	@Column(name="codigo_cnae_principal")
	private String codigoCnaePrincipal;

	@Column(name="imagem_logotipo")
	private String imagemLogotipo;

	@OneToMany(mappedBy = "empresaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<EmpresaContatoModel> empresaContatoModelList; 

	@OneToMany(mappedBy = "empresaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<EmpresaTelefoneModel> empresaTelefoneModelList; 

	@OneToMany(mappedBy = "empresaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<EmpresaCnaeModel> empresaCnaeModelList; 

	@OneToMany(mappedBy = "empresaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<EmpresaEnderecoModel> empresaEnderecoModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getRazaoSocial() { 
		return this.razaoSocial; 
	} 

	public void setRazaoSocial(String razaoSocial) { 
		this.razaoSocial = razaoSocial; 
	} 

	public String getNomeFantasia() { 
		return this.nomeFantasia; 
	} 

	public void setNomeFantasia(String nomeFantasia) { 
		this.nomeFantasia = nomeFantasia; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getInscricaoEstadual() { 
		return this.inscricaoEstadual; 
	} 

	public void setInscricaoEstadual(String inscricaoEstadual) { 
		this.inscricaoEstadual = inscricaoEstadual; 
	} 

	public String getInscricaoMunicipal() { 
		return this.inscricaoMunicipal; 
	} 

	public void setInscricaoMunicipal(String inscricaoMunicipal) { 
		this.inscricaoMunicipal = inscricaoMunicipal; 
	} 

	public String getTipoRegime() { 
		return this.tipoRegime; 
	} 

	public void setTipoRegime(String tipoRegime) { 
		this.tipoRegime = tipoRegime; 
	} 

	public String getCrt() { 
		return this.crt; 
	} 

	public void setCrt(String crt) { 
		this.crt = crt; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public String getSite() { 
		return this.site; 
	} 

	public void setSite(String site) { 
		this.site = site; 
	} 

	public String getContato() { 
		return this.contato; 
	} 

	public void setContato(String contato) { 
		this.contato = contato; 
	} 

	public Date getDataConstituicao() { 
		return this.dataConstituicao; 
	} 

	public void setDataConstituicao(Date dataConstituicao) { 
		this.dataConstituicao = dataConstituicao; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getInscricaoJuntaComercial() { 
		return this.inscricaoJuntaComercial; 
	} 

	public void setInscricaoJuntaComercial(String inscricaoJuntaComercial) { 
		this.inscricaoJuntaComercial = inscricaoJuntaComercial; 
	} 

	public Date getDataInscJuntaComercial() { 
		return this.dataInscJuntaComercial; 
	} 

	public void setDataInscJuntaComercial(Date dataInscJuntaComercial) { 
		this.dataInscJuntaComercial = dataInscJuntaComercial; 
	} 

	public Integer getCodigoIbgeCidade() { 
		return this.codigoIbgeCidade; 
	} 

	public void setCodigoIbgeCidade(Integer codigoIbgeCidade) { 
		this.codigoIbgeCidade = codigoIbgeCidade; 
	} 

	public Integer getCodigoIbgeUf() { 
		return this.codigoIbgeUf; 
	} 

	public void setCodigoIbgeUf(Integer codigoIbgeUf) { 
		this.codigoIbgeUf = codigoIbgeUf; 
	} 

	public String getCei() { 
		return this.cei; 
	} 

	public void setCei(String cei) { 
		this.cei = cei; 
	} 

	public String getCodigoCnaePrincipal() { 
		return this.codigoCnaePrincipal; 
	} 

	public void setCodigoCnaePrincipal(String codigoCnaePrincipal) { 
		this.codigoCnaePrincipal = codigoCnaePrincipal; 
	} 

	public String getImagemLogotipo() { 
		return this.imagemLogotipo; 
	} 

	public void setImagemLogotipo(String imagemLogotipo) { 
		this.imagemLogotipo = imagemLogotipo; 
	} 

	public Set<EmpresaContatoModel> getEmpresaContatoModelList() { 
	return this.empresaContatoModelList; 
	} 

	public void setEmpresaContatoModelList(Set<EmpresaContatoModel> empresaContatoModelList) { 
	this.empresaContatoModelList = empresaContatoModelList; 
		for (EmpresaContatoModel empresaContatoModel : empresaContatoModelList) { 
			empresaContatoModel.setEmpresaModel(this); 
		}
	} 

	public Set<EmpresaTelefoneModel> getEmpresaTelefoneModelList() { 
	return this.empresaTelefoneModelList; 
	} 

	public void setEmpresaTelefoneModelList(Set<EmpresaTelefoneModel> empresaTelefoneModelList) { 
	this.empresaTelefoneModelList = empresaTelefoneModelList; 
		for (EmpresaTelefoneModel empresaTelefoneModel : empresaTelefoneModelList) { 
			empresaTelefoneModel.setEmpresaModel(this); 
		}
	} 

	public Set<EmpresaCnaeModel> getEmpresaCnaeModelList() { 
	return this.empresaCnaeModelList; 
	} 

	public void setEmpresaCnaeModelList(Set<EmpresaCnaeModel> empresaCnaeModelList) { 
	this.empresaCnaeModelList = empresaCnaeModelList; 
		for (EmpresaCnaeModel empresaCnaeModel : empresaCnaeModelList) { 
			empresaCnaeModel.setEmpresaModel(this); 
		}
	} 

	public Set<EmpresaEnderecoModel> getEmpresaEnderecoModelList() { 
	return this.empresaEnderecoModelList; 
	} 

	public void setEmpresaEnderecoModelList(Set<EmpresaEnderecoModel> empresaEnderecoModelList) { 
	this.empresaEnderecoModelList = empresaEnderecoModelList; 
		for (EmpresaEnderecoModel empresaEnderecoModel : empresaEnderecoModelList) { 
			empresaEnderecoModel.setEmpresaModel(this); 
		}
	} 

		
}