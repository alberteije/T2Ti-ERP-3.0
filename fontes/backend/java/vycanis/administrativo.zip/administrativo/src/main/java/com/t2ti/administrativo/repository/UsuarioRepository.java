package com.t2ti.administrativo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.administrativo.model.UsuarioModel;

public interface UsuarioRepository extends JpaRepository<UsuarioModel, Integer> {}