package com.t2ti.administrativo.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.administrativo.util.Filter;
import com.t2ti.administrativo.exception.GenericException;
import com.t2ti.administrativo.model.FuncaoModel;
import com.t2ti.administrativo.repository.FuncaoRepository;

@Service
public class FuncaoService {

	@Autowired
	private FuncaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<FuncaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<FuncaoModel> getList(Filter filter) {
		String sql = "select * from funcao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, FuncaoModel.class);
		return query.getResultList();
	}

	public FuncaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public FuncaoModel save(FuncaoModel obj) {
		FuncaoModel funcaoModel = repository.save(obj);
		return funcaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		FuncaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Funcao] - Exception: " + e.getMessage());
		}
	}

}