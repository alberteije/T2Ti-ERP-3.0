package com.t2ti.administrativo.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.administrativo.exception.GenericException;
import com.t2ti.administrativo.exception.ResourseNotFoundException;
import com.t2ti.administrativo.exception.BadRequestException;
import com.t2ti.administrativo.util.Filter;
import com.t2ti.administrativo.model.UsuarioModel;
import com.t2ti.administrativo.service.UsuarioService;

@RestController
@RequestMapping(value = "/usuario", produces = "application/json;charset=UTF-8")
public class UsuarioController {

	@Autowired
	private UsuarioService service;
	
	@GetMapping({ "", "/" })
	public List<UsuarioModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Usuario] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public UsuarioModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found Usuario].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found Usuario] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public UsuarioModel insert(@RequestBody UsuarioModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert Usuario] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public UsuarioModel update(@RequestBody UsuarioModel objJson) {	
		try {			
			UsuarioModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update Usuario].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update Usuario] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Usuario] - Exception: " + e.getMessage());
		}
	}
	
	@GetMapping("/verifica-login/{login}")
	public UsuarioModel getUsuarioPorLogin(@PathVariable String login) {
		try {
			String filtro = "login = '" + login + "'";		
			var retorno = service.getObjectFilter(filtro);
			if (retorno == null) {
				throw new NoSuchElementException("Registro não localizado [Consultar Objeto Usuário].");
			}
			return retorno;
		} catch (NoSuchElementException e) {
			throw new ResourseNotFoundException("Registro não localizado [Consultar Objeto Usuário].");
		} catch (Exception e) {
			throw new GenericException(
					"Erro no Servidor [Consultar Objeto Usuário] - Exceção: " + e.getMessage());
		}
	}
	
}