package com.t2ti.administrativo.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="empresa_endereco")
@NamedQuery(name="EmpresaEnderecoModel.findAll", query="SELECT t FROM EmpresaEnderecoModel t")
public class EmpresaEnderecoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EmpresaEnderecoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="logradouro")
	private String logradouro;

	@Column(name="numero")
	private String numero;

	@Column(name="bairro")
	private String bairro;

	@Column(name="cidade")
	private String cidade;

	@Column(name="uf")
	private String uf;

	@Column(name="cep")
	private String cep;

	@Column(name="municipio_ibge")
	private Integer municipioIbge;

	@Column(name="complemento")
	private String complemento;

	@Column(name="principal")
	private String principal;

	@Column(name="entrega")
	private String entrega;

	@Column(name="cobranca")
	private String cobranca;

	@Column(name="correspondencia")
	private String correspondencia;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_empresa")
	private EmpresaModel empresaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getLogradouro() { 
		return this.logradouro; 
	} 

	public void setLogradouro(String logradouro) { 
		this.logradouro = logradouro; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getBairro() { 
		return this.bairro; 
	} 

	public void setBairro(String bairro) { 
		this.bairro = bairro; 
	} 

	public String getCidade() { 
		return this.cidade; 
	} 

	public void setCidade(String cidade) { 
		this.cidade = cidade; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getCep() { 
		return this.cep; 
	} 

	public void setCep(String cep) { 
		this.cep = cep; 
	} 

	public Integer getMunicipioIbge() { 
		return this.municipioIbge; 
	} 

	public void setMunicipioIbge(Integer municipioIbge) { 
		this.municipioIbge = municipioIbge; 
	} 

	public String getComplemento() { 
		return this.complemento; 
	} 

	public void setComplemento(String complemento) { 
		this.complemento = complemento; 
	} 

	public String getPrincipal() { 
		return this.principal; 
	} 

	public void setPrincipal(String principal) { 
		this.principal = principal; 
	} 

	public String getEntrega() { 
		return this.entrega; 
	} 

	public void setEntrega(String entrega) { 
		this.entrega = entrega; 
	} 

	public String getCobranca() { 
		return this.cobranca; 
	} 

	public void setCobranca(String cobranca) { 
		this.cobranca = cobranca; 
	} 

	public String getCorrespondencia() { 
		return this.correspondencia; 
	} 

	public void setCorrespondencia(String correspondencia) { 
		this.correspondencia = correspondencia; 
	} 

	public EmpresaModel getEmpresaModel() { 
	return this.empresaModel; 
	} 

	public void setEmpresaModel(EmpresaModel empresaModel) { 
	this.empresaModel = empresaModel; 
	} 

		
}