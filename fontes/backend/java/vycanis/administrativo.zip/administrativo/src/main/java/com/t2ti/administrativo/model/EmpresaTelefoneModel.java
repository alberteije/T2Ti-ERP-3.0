package com.t2ti.administrativo.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="empresa_telefone")
@NamedQuery(name="EmpresaTelefoneModel.findAll", query="SELECT t FROM EmpresaTelefoneModel t")
public class EmpresaTelefoneModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EmpresaTelefoneModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo")
	private String tipo;

	@Column(name="numero")
	private String numero;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_empresa")
	private EmpresaModel empresaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public EmpresaModel getEmpresaModel() { 
	return this.empresaModel; 
	} 

	public void setEmpresaModel(EmpresaModel empresaModel) { 
	this.empresaModel = empresaModel; 
	} 

		
}