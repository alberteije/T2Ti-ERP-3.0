package com.t2ti.administrativo.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="usuario")
@NamedQuery(name="UsuarioModel.findAll", query="SELECT t FROM UsuarioModel t")
public class UsuarioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public UsuarioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="login")
	private String login;

	@Column(name="senha")
	private String senha;

	@Column(name="administrador")
	private String administrador;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_papel")
	private PapelModel papelModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getLogin() { 
		return this.login; 
	} 

	public void setLogin(String login) { 
		this.login = login; 
	} 

	public String getSenha() { 
		return this.senha; 
	} 

	public void setSenha(String senha) { 
		this.senha = senha; 
	} 

	public String getAdministrador() { 
		return this.administrador; 
	} 

	public void setAdministrador(String administrador) { 
		this.administrador = administrador; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public PapelModel getPapelModel() { 
	return this.papelModel; 
	} 

	public void setPapelModel(PapelModel papelModel) { 
	this.papelModel = papelModel; 
	} 

		
}