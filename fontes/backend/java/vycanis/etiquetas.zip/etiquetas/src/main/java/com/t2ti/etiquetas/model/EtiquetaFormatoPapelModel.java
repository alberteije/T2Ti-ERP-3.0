package com.t2ti.etiquetas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="etiqueta_formato_papel")
@NamedQuery(name="EtiquetaFormatoPapelModel.findAll", query="SELECT t FROM EtiquetaFormatoPapelModel t")
public class EtiquetaFormatoPapelModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EtiquetaFormatoPapelModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="altura")
	private Integer altura;

	@Column(name="largura")
	private Integer largura;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Integer getAltura() { 
		return this.altura; 
	} 

	public void setAltura(Integer altura) { 
		this.altura = altura; 
	} 

	public Integer getLargura() { 
		return this.largura; 
	} 

	public void setLargura(Integer largura) { 
		this.largura = largura; 
	} 

		
}