package com.t2ti.etiquetas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.etiquetas.util.Filter;
import com.t2ti.etiquetas.exception.GenericException;
import com.t2ti.etiquetas.model.EtiquetaFormatoPapelModel;
import com.t2ti.etiquetas.repository.EtiquetaFormatoPapelRepository;

@Service
public class EtiquetaFormatoPapelService {

	@Autowired
	private EtiquetaFormatoPapelRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EtiquetaFormatoPapelModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EtiquetaFormatoPapelModel> getList(Filter filter) {
		String sql = "select * from etiqueta_formato_papel where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EtiquetaFormatoPapelModel.class);
		return query.getResultList();
	}

	public EtiquetaFormatoPapelModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EtiquetaFormatoPapelModel save(EtiquetaFormatoPapelModel obj) {
		EtiquetaFormatoPapelModel etiquetaFormatoPapelModel = repository.save(obj);
		return etiquetaFormatoPapelModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EtiquetaFormatoPapelModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EtiquetaFormatoPapel] - Exception: " + e.getMessage());
		}
	}

}