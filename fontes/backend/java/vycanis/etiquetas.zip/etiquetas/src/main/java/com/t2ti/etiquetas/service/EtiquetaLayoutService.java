package com.t2ti.etiquetas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.etiquetas.util.Filter;
import com.t2ti.etiquetas.exception.GenericException;
import com.t2ti.etiquetas.model.EtiquetaLayoutModel;
import com.t2ti.etiquetas.repository.EtiquetaLayoutRepository;

@Service
public class EtiquetaLayoutService {

	@Autowired
	private EtiquetaLayoutRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EtiquetaLayoutModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EtiquetaLayoutModel> getList(Filter filter) {
		String sql = "select * from etiqueta_layout where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EtiquetaLayoutModel.class);
		return query.getResultList();
	}

	public EtiquetaLayoutModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EtiquetaLayoutModel save(EtiquetaLayoutModel obj) {
		EtiquetaLayoutModel etiquetaLayoutModel = repository.save(obj);
		return etiquetaLayoutModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EtiquetaLayoutModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EtiquetaLayout] - Exception: " + e.getMessage());
		}
	}

}