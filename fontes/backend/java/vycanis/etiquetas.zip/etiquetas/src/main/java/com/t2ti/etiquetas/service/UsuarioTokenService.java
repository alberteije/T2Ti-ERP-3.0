package com.t2ti.etiquetas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.etiquetas.util.Filter;
import com.t2ti.etiquetas.exception.GenericException;
import com.t2ti.etiquetas.model.UsuarioTokenModel;
import com.t2ti.etiquetas.repository.UsuarioTokenRepository;

@Service
public class UsuarioTokenService {

	@Autowired
	private UsuarioTokenRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<UsuarioTokenModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<UsuarioTokenModel> getList(Filter filter) {
		String sql = "select * from usuario_token where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, UsuarioTokenModel.class);
		return query.getResultList();
	}

	public UsuarioTokenModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public UsuarioTokenModel save(UsuarioTokenModel obj) {
		UsuarioTokenModel usuarioTokenModel = repository.save(obj);
		return usuarioTokenModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		UsuarioTokenModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete UsuarioToken] - Exception: " + e.getMessage());
		}
	}

}