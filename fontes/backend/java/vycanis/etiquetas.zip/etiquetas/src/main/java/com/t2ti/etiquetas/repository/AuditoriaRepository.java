package com.t2ti.etiquetas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.etiquetas.model.AuditoriaModel;

public interface AuditoriaRepository extends JpaRepository<AuditoriaModel, Integer> {}