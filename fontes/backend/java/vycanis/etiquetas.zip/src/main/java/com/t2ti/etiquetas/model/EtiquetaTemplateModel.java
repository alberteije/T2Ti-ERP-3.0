package com.t2ti.etiquetas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="etiqueta_template")
@NamedQuery(name="EtiquetaTemplateModel.findAll", query="SELECT t FROM EtiquetaTemplateModel t")
public class EtiquetaTemplateModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EtiquetaTemplateModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tabela")
	private String tabela;

	@Column(name="campo")
	private String campo;

	@Column(name="formato")
	private String formato;

	@Column(name="quantidade_repeticoes")
	private Integer quantidadeRepeticoes;

	@Column(name="filtro")
	private String filtro;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_etiqueta_layout")
	private EtiquetaLayoutModel etiquetaLayoutModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTabela() { 
		return this.tabela; 
	} 

	public void setTabela(String tabela) { 
		this.tabela = tabela; 
	} 

	public String getCampo() { 
		return this.campo; 
	} 

	public void setCampo(String campo) { 
		this.campo = campo; 
	} 

	public String getFormato() { 
		return this.formato; 
	} 

	public void setFormato(String formato) { 
		this.formato = formato; 
	} 

	public Integer getQuantidadeRepeticoes() { 
		return this.quantidadeRepeticoes; 
	} 

	public void setQuantidadeRepeticoes(Integer quantidadeRepeticoes) { 
		this.quantidadeRepeticoes = quantidadeRepeticoes; 
	} 

	public String getFiltro() { 
		return this.filtro; 
	} 

	public void setFiltro(String filtro) { 
		this.filtro = filtro; 
	} 

	public EtiquetaLayoutModel getEtiquetaLayoutModel() { 
	return this.etiquetaLayoutModel; 
	} 

	public void setEtiquetaLayoutModel(EtiquetaLayoutModel etiquetaLayoutModel) { 
	this.etiquetaLayoutModel = etiquetaLayoutModel; 
	} 

		
}