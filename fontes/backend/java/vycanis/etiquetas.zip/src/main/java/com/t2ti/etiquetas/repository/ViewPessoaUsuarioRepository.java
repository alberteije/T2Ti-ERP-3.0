package com.t2ti.etiquetas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.etiquetas.model.ViewPessoaUsuarioModel;

public interface ViewPessoaUsuarioRepository extends JpaRepository<ViewPessoaUsuarioModel, Integer> {}