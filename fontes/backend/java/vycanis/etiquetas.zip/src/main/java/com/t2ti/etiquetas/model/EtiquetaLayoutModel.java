package com.t2ti.etiquetas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="etiqueta_layout")
@NamedQuery(name="EtiquetaLayoutModel.findAll", query="SELECT t FROM EtiquetaLayoutModel t")
public class EtiquetaLayoutModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EtiquetaLayoutModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_fabricante")
	private String codigoFabricante;

	@Column(name="quantidade")
	private Integer quantidade;

	@Column(name="quantidade_horizontal")
	private Integer quantidadeHorizontal;

	@Column(name="quantidade_vertical")
	private Integer quantidadeVertical;

	@Column(name="margem_superior")
	private Integer margemSuperior;

	@Column(name="margem_inferior")
	private Integer margemInferior;

	@Column(name="margem_esquerda")
	private Integer margemEsquerda;

	@Column(name="margem_direita")
	private Integer margemDireita;

	@Column(name="espacamento_horizontal")
	private Integer espacamentoHorizontal;

	@Column(name="espacamento_vertical")
	private Integer espacamentoVertical;

	@OneToMany(mappedBy = "etiquetaLayoutModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<EtiquetaTemplateModel> etiquetaTemplateModelList; 

	@ManyToOne 
	@JoinColumn(name="id_formato_papel")
	private EtiquetaFormatoPapelModel etiquetaFormatoPapelModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoFabricante() { 
		return this.codigoFabricante; 
	} 

	public void setCodigoFabricante(String codigoFabricante) { 
		this.codigoFabricante = codigoFabricante; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public Integer getQuantidadeHorizontal() { 
		return this.quantidadeHorizontal; 
	} 

	public void setQuantidadeHorizontal(Integer quantidadeHorizontal) { 
		this.quantidadeHorizontal = quantidadeHorizontal; 
	} 

	public Integer getQuantidadeVertical() { 
		return this.quantidadeVertical; 
	} 

	public void setQuantidadeVertical(Integer quantidadeVertical) { 
		this.quantidadeVertical = quantidadeVertical; 
	} 

	public Integer getMargemSuperior() { 
		return this.margemSuperior; 
	} 

	public void setMargemSuperior(Integer margemSuperior) { 
		this.margemSuperior = margemSuperior; 
	} 

	public Integer getMargemInferior() { 
		return this.margemInferior; 
	} 

	public void setMargemInferior(Integer margemInferior) { 
		this.margemInferior = margemInferior; 
	} 

	public Integer getMargemEsquerda() { 
		return this.margemEsquerda; 
	} 

	public void setMargemEsquerda(Integer margemEsquerda) { 
		this.margemEsquerda = margemEsquerda; 
	} 

	public Integer getMargemDireita() { 
		return this.margemDireita; 
	} 

	public void setMargemDireita(Integer margemDireita) { 
		this.margemDireita = margemDireita; 
	} 

	public Integer getEspacamentoHorizontal() { 
		return this.espacamentoHorizontal; 
	} 

	public void setEspacamentoHorizontal(Integer espacamentoHorizontal) { 
		this.espacamentoHorizontal = espacamentoHorizontal; 
	} 

	public Integer getEspacamentoVertical() { 
		return this.espacamentoVertical; 
	} 

	public void setEspacamentoVertical(Integer espacamentoVertical) { 
		this.espacamentoVertical = espacamentoVertical; 
	} 

	public Set<EtiquetaTemplateModel> getEtiquetaTemplateModelList() { 
	return this.etiquetaTemplateModelList; 
	} 

	public void setEtiquetaTemplateModelList(Set<EtiquetaTemplateModel> etiquetaTemplateModelList) { 
	this.etiquetaTemplateModelList = etiquetaTemplateModelList; 
		for (EtiquetaTemplateModel etiquetaTemplateModel : etiquetaTemplateModelList) { 
			etiquetaTemplateModel.setEtiquetaLayoutModel(this); 
		}
	} 

	public EtiquetaFormatoPapelModel getEtiquetaFormatoPapelModel() { 
	return this.etiquetaFormatoPapelModel; 
	} 

	public void setEtiquetaFormatoPapelModel(EtiquetaFormatoPapelModel etiquetaFormatoPapelModel) { 
	this.etiquetaFormatoPapelModel = etiquetaFormatoPapelModel; 
	} 

		
}