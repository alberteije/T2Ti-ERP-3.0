package com.t2ti.etiquetas.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.etiquetas.exception.GenericException;
import com.t2ti.etiquetas.exception.ResourseNotFoundException;
import com.t2ti.etiquetas.exception.BadRequestException;
import com.t2ti.etiquetas.util.Filter;
import com.t2ti.etiquetas.model.EtiquetaFormatoPapelModel;
import com.t2ti.etiquetas.service.EtiquetaFormatoPapelService;

@RestController
@RequestMapping(value = "/etiqueta-formato-papel", produces = "application/json;charset=UTF-8")
public class EtiquetaFormatoPapelController {

	@Autowired
	private EtiquetaFormatoPapelService service;
	
	@GetMapping({ "", "/" })
	public List<EtiquetaFormatoPapelModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [EtiquetaFormatoPapel] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public EtiquetaFormatoPapelModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found EtiquetaFormatoPapel].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found EtiquetaFormatoPapel] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public EtiquetaFormatoPapelModel insert(@RequestBody EtiquetaFormatoPapelModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert EtiquetaFormatoPapel] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public EtiquetaFormatoPapelModel update(@RequestBody EtiquetaFormatoPapelModel objJson) {	
		try {			
			EtiquetaFormatoPapelModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update EtiquetaFormatoPapel].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update EtiquetaFormatoPapel] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EtiquetaFormatoPapel] - Exception: " + e.getMessage());
		}
	}
	
}