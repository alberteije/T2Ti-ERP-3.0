package com.t2ti.inventario.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="inventario_contagem_det")
@NamedQuery(name="InventarioContagemDetModel.findAll", query="SELECT t FROM InventarioContagemDetModel t")
public class InventarioContagemDetModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public InventarioContagemDetModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="contagem01")
	private BigDecimal contagem01;

	@Column(name="contagem02")
	private BigDecimal contagem02;

	@Column(name="contagem03")
	private BigDecimal contagem03;

	@Column(name="fechado_contagem")
	private String fechadoContagem;

	@Column(name="quantidade_sistema")
	private BigDecimal quantidadeSistema;

	@Column(name="acuracidade")
	private BigDecimal acuracidade;

	@Column(name="divergencia")
	private BigDecimal divergencia;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_inventario_contagem_cab")
	private InventarioContagemCabModel inventarioContagemCabModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getContagem01() { 
		return this.contagem01; 
	} 

	public void setContagem01(BigDecimal contagem01) { 
		this.contagem01 = contagem01; 
	} 

	public BigDecimal getContagem02() { 
		return this.contagem02; 
	} 

	public void setContagem02(BigDecimal contagem02) { 
		this.contagem02 = contagem02; 
	} 

	public BigDecimal getContagem03() { 
		return this.contagem03; 
	} 

	public void setContagem03(BigDecimal contagem03) { 
		this.contagem03 = contagem03; 
	} 

	public String getFechadoContagem() { 
		return this.fechadoContagem; 
	} 

	public void setFechadoContagem(String fechadoContagem) { 
		this.fechadoContagem = fechadoContagem; 
	} 

	public BigDecimal getQuantidadeSistema() { 
		return this.quantidadeSistema; 
	} 

	public void setQuantidadeSistema(BigDecimal quantidadeSistema) { 
		this.quantidadeSistema = quantidadeSistema; 
	} 

	public BigDecimal getAcuracidade() { 
		return this.acuracidade; 
	} 

	public void setAcuracidade(BigDecimal acuracidade) { 
		this.acuracidade = acuracidade; 
	} 

	public BigDecimal getDivergencia() { 
		return this.divergencia; 
	} 

	public void setDivergencia(BigDecimal divergencia) { 
		this.divergencia = divergencia; 
	} 

	public InventarioContagemCabModel getInventarioContagemCabModel() { 
	return this.inventarioContagemCabModel; 
	} 

	public void setInventarioContagemCabModel(InventarioContagemCabModel inventarioContagemCabModel) { 
	this.inventarioContagemCabModel = inventarioContagemCabModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}