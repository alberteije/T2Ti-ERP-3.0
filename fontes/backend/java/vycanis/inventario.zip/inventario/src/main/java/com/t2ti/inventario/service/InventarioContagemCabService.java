package com.t2ti.inventario.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.inventario.util.Filter;
import com.t2ti.inventario.exception.GenericException;
import com.t2ti.inventario.model.InventarioContagemCabModel;
import com.t2ti.inventario.repository.InventarioContagemCabRepository;

@Service
public class InventarioContagemCabService {

	@Autowired
	private InventarioContagemCabRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<InventarioContagemCabModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<InventarioContagemCabModel> getList(Filter filter) {
		String sql = "select * from inventario_contagem_cab where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, InventarioContagemCabModel.class);
		return query.getResultList();
	}

	public InventarioContagemCabModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public InventarioContagemCabModel save(InventarioContagemCabModel obj) {
		InventarioContagemCabModel inventarioContagemCabModel = repository.save(obj);
		return inventarioContagemCabModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		InventarioContagemCabModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete InventarioContagemCab] - Exception: " + e.getMessage());
		}
	}

}