package com.t2ti.inventario.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="inventario_ajuste_cab")
@NamedQuery(name="InventarioAjusteCabModel.findAll", query="SELECT t FROM InventarioAjusteCabModel t")
public class InventarioAjusteCabModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public InventarioAjusteCabModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_ajuste")
	private Date dataAjuste;

	@Column(name="tipo")
	private String tipo;

	@Column(name="taxa")
	private BigDecimal taxa;

	@Column(name="justificativa")
	private String justificativa;

	@ManyToOne 
	@JoinColumn(name="id_view_pessoa_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@OneToMany(mappedBy = "inventarioAjusteCabModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<InventarioAjusteDetModel> inventarioAjusteDetModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataAjuste() { 
		return this.dataAjuste; 
	} 

	public void setDataAjuste(Date dataAjuste) { 
		this.dataAjuste = dataAjuste; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

	public String getJustificativa() { 
		return this.justificativa; 
	} 

	public void setJustificativa(String justificativa) { 
		this.justificativa = justificativa; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public Set<InventarioAjusteDetModel> getInventarioAjusteDetModelList() { 
	return this.inventarioAjusteDetModelList; 
	} 

	public void setInventarioAjusteDetModelList(Set<InventarioAjusteDetModel> inventarioAjusteDetModelList) { 
	this.inventarioAjusteDetModelList = inventarioAjusteDetModelList; 
		for (InventarioAjusteDetModel inventarioAjusteDetModel : inventarioAjusteDetModelList) { 
			inventarioAjusteDetModel.setInventarioAjusteCabModel(this); 
		}
	} 

		
}