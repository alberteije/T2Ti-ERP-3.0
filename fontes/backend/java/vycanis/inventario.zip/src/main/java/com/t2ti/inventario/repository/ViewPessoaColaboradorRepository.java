package com.t2ti.inventario.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.inventario.model.ViewPessoaColaboradorModel;

public interface ViewPessoaColaboradorRepository extends JpaRepository<ViewPessoaColaboradorModel, Integer> {}