package com.t2ti.inventario.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="inventario_contagem_cab")
@NamedQuery(name="InventarioContagemCabModel.findAll", query="SELECT t FROM InventarioContagemCabModel t")
public class InventarioContagemCabModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public InventarioContagemCabModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_contagem")
	private Date dataContagem;

	@Column(name="estoque_atualizado")
	private String estoqueAtualizado;

	@Column(name="tipo")
	private String tipo;

	@OneToMany(mappedBy = "inventarioContagemCabModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<InventarioContagemDetModel> inventarioContagemDetModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataContagem() { 
		return this.dataContagem; 
	} 

	public void setDataContagem(Date dataContagem) { 
		this.dataContagem = dataContagem; 
	} 

	public String getEstoqueAtualizado() { 
		return this.estoqueAtualizado; 
	} 

	public void setEstoqueAtualizado(String estoqueAtualizado) { 
		this.estoqueAtualizado = estoqueAtualizado; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public Set<InventarioContagemDetModel> getInventarioContagemDetModelList() { 
	return this.inventarioContagemDetModelList; 
	} 

	public void setInventarioContagemDetModelList(Set<InventarioContagemDetModel> inventarioContagemDetModelList) { 
	this.inventarioContagemDetModelList = inventarioContagemDetModelList; 
		for (InventarioContagemDetModel inventarioContagemDetModel : inventarioContagemDetModelList) { 
			inventarioContagemDetModel.setInventarioContagemCabModel(this); 
		}
	} 

		
}