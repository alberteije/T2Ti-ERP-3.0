package com.t2ti.orcamentos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="orcamento_fluxo_caixa_detalhe")
@NamedQuery(name="OrcamentoFluxoCaixaDetalheModel.findAll", query="SELECT t FROM OrcamentoFluxoCaixaDetalheModel t")
public class OrcamentoFluxoCaixaDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OrcamentoFluxoCaixaDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="periodo")
	private String periodo;

	@Column(name="valor_orcado")
	private BigDecimal valorOrcado;

	@Column(name="valor_realizado")
	private BigDecimal valorRealizado;

	@Column(name="taxa_variacao")
	private BigDecimal taxaVariacao;

	@Column(name="valor_variacao")
	private BigDecimal valorVariacao;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_orcamento_fluxo_caixa")
	private OrcamentoFluxoCaixaModel orcamentoFluxoCaixaModel; 

	@ManyToOne 
	@JoinColumn(name="id_fin_natureza_financeira")
	private FinNaturezaFinanceiraModel finNaturezaFinanceiraModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getPeriodo() { 
		return this.periodo; 
	} 

	public void setPeriodo(String periodo) { 
		this.periodo = periodo; 
	} 

	public BigDecimal getValorOrcado() { 
		return this.valorOrcado; 
	} 

	public void setValorOrcado(BigDecimal valorOrcado) { 
		this.valorOrcado = valorOrcado; 
	} 

	public BigDecimal getValorRealizado() { 
		return this.valorRealizado; 
	} 

	public void setValorRealizado(BigDecimal valorRealizado) { 
		this.valorRealizado = valorRealizado; 
	} 

	public BigDecimal getTaxaVariacao() { 
		return this.taxaVariacao; 
	} 

	public void setTaxaVariacao(BigDecimal taxaVariacao) { 
		this.taxaVariacao = taxaVariacao; 
	} 

	public BigDecimal getValorVariacao() { 
		return this.valorVariacao; 
	} 

	public void setValorVariacao(BigDecimal valorVariacao) { 
		this.valorVariacao = valorVariacao; 
	} 

	public OrcamentoFluxoCaixaModel getOrcamentoFluxoCaixaModel() { 
	return this.orcamentoFluxoCaixaModel; 
	} 

	public void setOrcamentoFluxoCaixaModel(OrcamentoFluxoCaixaModel orcamentoFluxoCaixaModel) { 
	this.orcamentoFluxoCaixaModel = orcamentoFluxoCaixaModel; 
	} 

	public FinNaturezaFinanceiraModel getFinNaturezaFinanceiraModel() { 
	return this.finNaturezaFinanceiraModel; 
	} 

	public void setFinNaturezaFinanceiraModel(FinNaturezaFinanceiraModel finNaturezaFinanceiraModel) { 
	this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel; 
	} 

		
}