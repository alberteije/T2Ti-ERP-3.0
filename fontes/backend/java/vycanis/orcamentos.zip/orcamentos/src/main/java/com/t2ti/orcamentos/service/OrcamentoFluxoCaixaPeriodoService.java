package com.t2ti.orcamentos.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.orcamentos.util.Filter;
import com.t2ti.orcamentos.exception.GenericException;
import com.t2ti.orcamentos.model.OrcamentoFluxoCaixaPeriodoModel;
import com.t2ti.orcamentos.repository.OrcamentoFluxoCaixaPeriodoRepository;

@Service
public class OrcamentoFluxoCaixaPeriodoService {

	@Autowired
	private OrcamentoFluxoCaixaPeriodoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<OrcamentoFluxoCaixaPeriodoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<OrcamentoFluxoCaixaPeriodoModel> getList(Filter filter) {
		String sql = "select * from orcamento_fluxo_caixa_periodo where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, OrcamentoFluxoCaixaPeriodoModel.class);
		return query.getResultList();
	}

	public OrcamentoFluxoCaixaPeriodoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public OrcamentoFluxoCaixaPeriodoModel save(OrcamentoFluxoCaixaPeriodoModel obj) {
		OrcamentoFluxoCaixaPeriodoModel orcamentoFluxoCaixaPeriodoModel = repository.save(obj);
		return orcamentoFluxoCaixaPeriodoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		OrcamentoFluxoCaixaPeriodoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete OrcamentoFluxoCaixaPeriodo] - Exception: " + e.getMessage());
		}
	}

}