package com.t2ti.orcamentos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.orcamentos.model.OrcamentoEmpresarialModel;

public interface OrcamentoEmpresarialRepository extends JpaRepository<OrcamentoEmpresarialModel, Integer> {}