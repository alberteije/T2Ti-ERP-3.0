package com.t2ti.orcamentos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.orcamentos.model.OrcamentoFluxoCaixaModel;

public interface OrcamentoFluxoCaixaRepository extends JpaRepository<OrcamentoFluxoCaixaModel, Integer> {}