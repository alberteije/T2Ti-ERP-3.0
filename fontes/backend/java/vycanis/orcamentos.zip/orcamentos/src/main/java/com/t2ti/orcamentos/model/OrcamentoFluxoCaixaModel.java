package com.t2ti.orcamentos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="orcamento_fluxo_caixa")
@NamedQuery(name="OrcamentoFluxoCaixaModel.findAll", query="SELECT t FROM OrcamentoFluxoCaixaModel t")
public class OrcamentoFluxoCaixaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OrcamentoFluxoCaixaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicial")
	private Date dataInicial;

	@Column(name="numero_periodos")
	private Integer numeroPeriodos;

	@Temporal(TemporalType.DATE)
@Column(name="data_base")
	private Date dataBase;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "orcamentoFluxoCaixaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<OrcamentoFluxoCaixaDetalheModel> orcamentoFluxoCaixaDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_orc_fluxo_caixa_periodo")
	private OrcamentoFluxoCaixaPeriodoModel orcamentoFluxoCaixaPeriodoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Date getDataInicial() { 
		return this.dataInicial; 
	} 

	public void setDataInicial(Date dataInicial) { 
		this.dataInicial = dataInicial; 
	} 

	public Integer getNumeroPeriodos() { 
		return this.numeroPeriodos; 
	} 

	public void setNumeroPeriodos(Integer numeroPeriodos) { 
		this.numeroPeriodos = numeroPeriodos; 
	} 

	public Date getDataBase() { 
		return this.dataBase; 
	} 

	public void setDataBase(Date dataBase) { 
		this.dataBase = dataBase; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<OrcamentoFluxoCaixaDetalheModel> getOrcamentoFluxoCaixaDetalheModelList() { 
	return this.orcamentoFluxoCaixaDetalheModelList; 
	} 

	public void setOrcamentoFluxoCaixaDetalheModelList(Set<OrcamentoFluxoCaixaDetalheModel> orcamentoFluxoCaixaDetalheModelList) { 
	this.orcamentoFluxoCaixaDetalheModelList = orcamentoFluxoCaixaDetalheModelList; 
		for (OrcamentoFluxoCaixaDetalheModel orcamentoFluxoCaixaDetalheModel : orcamentoFluxoCaixaDetalheModelList) { 
			orcamentoFluxoCaixaDetalheModel.setOrcamentoFluxoCaixaModel(this); 
		}
	} 

	public OrcamentoFluxoCaixaPeriodoModel getOrcamentoFluxoCaixaPeriodoModel() { 
	return this.orcamentoFluxoCaixaPeriodoModel; 
	} 

	public void setOrcamentoFluxoCaixaPeriodoModel(OrcamentoFluxoCaixaPeriodoModel orcamentoFluxoCaixaPeriodoModel) { 
	this.orcamentoFluxoCaixaPeriodoModel = orcamentoFluxoCaixaPeriodoModel; 
	} 

		
}