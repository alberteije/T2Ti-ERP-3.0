package com.t2ti.orcamentos.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.orcamentos.util.Filter;
import com.t2ti.orcamentos.exception.GenericException;
import com.t2ti.orcamentos.model.OrcamentoFluxoCaixaModel;
import com.t2ti.orcamentos.repository.OrcamentoFluxoCaixaRepository;

@Service
public class OrcamentoFluxoCaixaService {

	@Autowired
	private OrcamentoFluxoCaixaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<OrcamentoFluxoCaixaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<OrcamentoFluxoCaixaModel> getList(Filter filter) {
		String sql = "select * from orcamento_fluxo_caixa where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, OrcamentoFluxoCaixaModel.class);
		return query.getResultList();
	}

	public OrcamentoFluxoCaixaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public OrcamentoFluxoCaixaModel save(OrcamentoFluxoCaixaModel obj) {
		OrcamentoFluxoCaixaModel orcamentoFluxoCaixaModel = repository.save(obj);
		return orcamentoFluxoCaixaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		OrcamentoFluxoCaixaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete OrcamentoFluxoCaixa] - Exception: " + e.getMessage());
		}
	}

}