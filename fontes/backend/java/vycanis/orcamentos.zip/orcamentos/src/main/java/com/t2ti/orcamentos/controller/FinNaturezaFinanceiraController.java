package com.t2ti.orcamentos.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.orcamentos.exception.GenericException;
import com.t2ti.orcamentos.exception.ResourseNotFoundException;
import com.t2ti.orcamentos.exception.BadRequestException;
import com.t2ti.orcamentos.util.Filter;
import com.t2ti.orcamentos.model.FinNaturezaFinanceiraModel;
import com.t2ti.orcamentos.service.FinNaturezaFinanceiraService;

@RestController
@RequestMapping(value = "/fin-natureza-financeira", produces = "application/json;charset=UTF-8")
public class FinNaturezaFinanceiraController {

	@Autowired
	private FinNaturezaFinanceiraService service;
	
	@GetMapping({ "", "/" })
	public List<FinNaturezaFinanceiraModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [FinNaturezaFinanceira] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public FinNaturezaFinanceiraModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found FinNaturezaFinanceira].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found FinNaturezaFinanceira] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public FinNaturezaFinanceiraModel insert(@RequestBody FinNaturezaFinanceiraModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert FinNaturezaFinanceira] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public FinNaturezaFinanceiraModel update(@RequestBody FinNaturezaFinanceiraModel objJson) {	
		try {			
			FinNaturezaFinanceiraModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update FinNaturezaFinanceira].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update FinNaturezaFinanceira] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete FinNaturezaFinanceira] - Exception: " + e.getMessage());
		}
	}
	
}