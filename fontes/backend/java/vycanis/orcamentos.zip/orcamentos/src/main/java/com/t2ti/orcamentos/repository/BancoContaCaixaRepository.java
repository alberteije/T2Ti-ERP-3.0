package com.t2ti.orcamentos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.orcamentos.model.BancoContaCaixaModel;

public interface BancoContaCaixaRepository extends JpaRepository<BancoContaCaixaModel, Integer> {}