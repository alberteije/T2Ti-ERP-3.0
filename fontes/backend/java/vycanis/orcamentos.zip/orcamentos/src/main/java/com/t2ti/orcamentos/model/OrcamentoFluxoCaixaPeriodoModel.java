package com.t2ti.orcamentos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="orcamento_fluxo_caixa_periodo")
@NamedQuery(name="OrcamentoFluxoCaixaPeriodoModel.findAll", query="SELECT t FROM OrcamentoFluxoCaixaPeriodoModel t")
public class OrcamentoFluxoCaixaPeriodoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OrcamentoFluxoCaixaPeriodoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="periodo")
	private String periodo;

	@Column(name="nome")
	private String nome;

	@ManyToOne 
	@JoinColumn(name="id_banco_conta_caixa")
	private BancoContaCaixaModel bancoContaCaixaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getPeriodo() { 
		return this.periodo; 
	} 

	public void setPeriodo(String periodo) { 
		this.periodo = periodo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public BancoContaCaixaModel getBancoContaCaixaModel() { 
	return this.bancoContaCaixaModel; 
	} 

	public void setBancoContaCaixaModel(BancoContaCaixaModel bancoContaCaixaModel) { 
	this.bancoContaCaixaModel = bancoContaCaixaModel; 
	} 

		
}