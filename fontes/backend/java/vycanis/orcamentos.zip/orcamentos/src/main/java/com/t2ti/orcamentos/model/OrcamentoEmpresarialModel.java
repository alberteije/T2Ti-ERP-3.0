package com.t2ti.orcamentos.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="orcamento_empresarial")
@NamedQuery(name="OrcamentoEmpresarialModel.findAll", query="SELECT t FROM OrcamentoEmpresarialModel t")
public class OrcamentoEmpresarialModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public OrcamentoEmpresarialModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicial")
	private Date dataInicial;

	@Column(name="numero_periodos")
	private Integer numeroPeriodos;

	@Temporal(TemporalType.DATE)
@Column(name="data_base")
	private Date dataBase;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "orcamentoEmpresarialModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<OrcamentoDetalheModel> orcamentoDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_orcamento_periodo")
	private OrcamentoPeriodoModel orcamentoPeriodoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Date getDataInicial() { 
		return this.dataInicial; 
	} 

	public void setDataInicial(Date dataInicial) { 
		this.dataInicial = dataInicial; 
	} 

	public Integer getNumeroPeriodos() { 
		return this.numeroPeriodos; 
	} 

	public void setNumeroPeriodos(Integer numeroPeriodos) { 
		this.numeroPeriodos = numeroPeriodos; 
	} 

	public Date getDataBase() { 
		return this.dataBase; 
	} 

	public void setDataBase(Date dataBase) { 
		this.dataBase = dataBase; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<OrcamentoDetalheModel> getOrcamentoDetalheModelList() { 
	return this.orcamentoDetalheModelList; 
	} 

	public void setOrcamentoDetalheModelList(Set<OrcamentoDetalheModel> orcamentoDetalheModelList) { 
	this.orcamentoDetalheModelList = orcamentoDetalheModelList; 
		for (OrcamentoDetalheModel orcamentoDetalheModel : orcamentoDetalheModelList) { 
			orcamentoDetalheModel.setOrcamentoEmpresarialModel(this); 
		}
	} 

	public OrcamentoPeriodoModel getOrcamentoPeriodoModel() { 
	return this.orcamentoPeriodoModel; 
	} 

	public void setOrcamentoPeriodoModel(OrcamentoPeriodoModel orcamentoPeriodoModel) { 
	this.orcamentoPeriodoModel = orcamentoPeriodoModel; 
	} 

		
}