package com.t2ti.orcamentos.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.orcamentos.util.Filter;
import com.t2ti.orcamentos.exception.GenericException;
import com.t2ti.orcamentos.model.OrcamentoEmpresarialModel;
import com.t2ti.orcamentos.repository.OrcamentoEmpresarialRepository;

@Service
public class OrcamentoEmpresarialService {

	@Autowired
	private OrcamentoEmpresarialRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<OrcamentoEmpresarialModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<OrcamentoEmpresarialModel> getList(Filter filter) {
		String sql = "select * from orcamento_empresarial where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, OrcamentoEmpresarialModel.class);
		return query.getResultList();
	}

	public OrcamentoEmpresarialModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public OrcamentoEmpresarialModel save(OrcamentoEmpresarialModel obj) {
		OrcamentoEmpresarialModel orcamentoEmpresarialModel = repository.save(obj);
		return orcamentoEmpresarialModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		OrcamentoEmpresarialModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete OrcamentoEmpresarial] - Exception: " + e.getMessage());
		}
	}

}