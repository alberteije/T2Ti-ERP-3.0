package com.t2ti.pcp.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="patrim_bem")
@NamedQuery(name="PatrimBemModel.findAll", query="SELECT t FROM PatrimBemModel t")
public class PatrimBemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PatrimBemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_centro_resultado")
	private Integer idCentroResultado;

	@Column(name="id_patrim_tipo_aquisicao_bem")
	private Integer idPatrimTipoAquisicaoBem;

	@Column(name="id_patrim_estado_conservacao")
	private Integer idPatrimEstadoConservacao;

	@Column(name="id_patrim_grupo_bem")
	private Integer idPatrimGrupoBem;

	@Column(name="id_fornecedor")
	private Integer idFornecedor;

	@Column(name="id_setor")
	private Integer idSetor;

	@Column(name="numero_nb")
	private String numeroNb;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="numero_serie")
	private String numeroSerie;

	@Temporal(TemporalType.DATE)
@Column(name="data_aquisicao")
	private Date dataAquisicao;

	@Temporal(TemporalType.DATE)
@Column(name="data_aceite")
	private Date dataAceite;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;

	@Temporal(TemporalType.DATE)
@Column(name="data_contabilizado")
	private Date dataContabilizado;

	@Temporal(TemporalType.DATE)
@Column(name="data_vistoria")
	private Date dataVistoria;

	@Temporal(TemporalType.DATE)
@Column(name="data_marcacao")
	private Date dataMarcacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_baixa")
	private Date dataBaixa;

	@Temporal(TemporalType.DATE)
@Column(name="vencimento_garantia")
	private Date vencimentoGarantia;

	@Column(name="numero_nota_fiscal")
	private String numeroNotaFiscal;

	@Column(name="chave_nfe")
	private String chaveNfe;

	@Column(name="valor_original")
	private BigDecimal valorOriginal;

	@Column(name="valor_compra")
	private BigDecimal valorCompra;

	@Column(name="valor_atualizado")
	private BigDecimal valorAtualizado;

	@Column(name="valor_baixa")
	private BigDecimal valorBaixa;

	@Column(name="deprecia")
	private String deprecia;

	@Column(name="metodo_depreciacao")
	private String metodoDepreciacao;

	@Temporal(TemporalType.DATE)
@Column(name="inicio_depreciacao")
	private Date inicioDepreciacao;

	@Temporal(TemporalType.DATE)
@Column(name="ultima_depreciacao")
	private Date ultimaDepreciacao;

	@Column(name="tipo_depreciacao")
	private String tipoDepreciacao;

	@Column(name="taxa_anual_depreciacao")
	private BigDecimal taxaAnualDepreciacao;

	@Column(name="taxa_mensal_depreciacao")
	private BigDecimal taxaMensalDepreciacao;

	@Column(name="taxa_depreciacao_acelerada")
	private BigDecimal taxaDepreciacaoAcelerada;

	@Column(name="taxa_depreciacao_incentivada")
	private BigDecimal taxaDepreciacaoIncentivada;

	@Column(name="funcao")
	private String funcao;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdCentroResultado() { 
		return this.idCentroResultado; 
	} 

	public void setIdCentroResultado(Integer idCentroResultado) { 
		this.idCentroResultado = idCentroResultado; 
	} 

	public Integer getIdPatrimTipoAquisicaoBem() { 
		return this.idPatrimTipoAquisicaoBem; 
	} 

	public void setIdPatrimTipoAquisicaoBem(Integer idPatrimTipoAquisicaoBem) { 
		this.idPatrimTipoAquisicaoBem = idPatrimTipoAquisicaoBem; 
	} 

	public Integer getIdPatrimEstadoConservacao() { 
		return this.idPatrimEstadoConservacao; 
	} 

	public void setIdPatrimEstadoConservacao(Integer idPatrimEstadoConservacao) { 
		this.idPatrimEstadoConservacao = idPatrimEstadoConservacao; 
	} 

	public Integer getIdPatrimGrupoBem() { 
		return this.idPatrimGrupoBem; 
	} 

	public void setIdPatrimGrupoBem(Integer idPatrimGrupoBem) { 
		this.idPatrimGrupoBem = idPatrimGrupoBem; 
	} 

	public Integer getIdFornecedor() { 
		return this.idFornecedor; 
	} 

	public void setIdFornecedor(Integer idFornecedor) { 
		this.idFornecedor = idFornecedor; 
	} 

	public Integer getIdSetor() { 
		return this.idSetor; 
	} 

	public void setIdSetor(Integer idSetor) { 
		this.idSetor = idSetor; 
	} 

	public String getNumeroNb() { 
		return this.numeroNb; 
	} 

	public void setNumeroNb(String numeroNb) { 
		this.numeroNb = numeroNb; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getNumeroSerie() { 
		return this.numeroSerie; 
	} 

	public void setNumeroSerie(String numeroSerie) { 
		this.numeroSerie = numeroSerie; 
	} 

	public Date getDataAquisicao() { 
		return this.dataAquisicao; 
	} 

	public void setDataAquisicao(Date dataAquisicao) { 
		this.dataAquisicao = dataAquisicao; 
	} 

	public Date getDataAceite() { 
		return this.dataAceite; 
	} 

	public void setDataAceite(Date dataAceite) { 
		this.dataAceite = dataAceite; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

	public Date getDataContabilizado() { 
		return this.dataContabilizado; 
	} 

	public void setDataContabilizado(Date dataContabilizado) { 
		this.dataContabilizado = dataContabilizado; 
	} 

	public Date getDataVistoria() { 
		return this.dataVistoria; 
	} 

	public void setDataVistoria(Date dataVistoria) { 
		this.dataVistoria = dataVistoria; 
	} 

	public Date getDataMarcacao() { 
		return this.dataMarcacao; 
	} 

	public void setDataMarcacao(Date dataMarcacao) { 
		this.dataMarcacao = dataMarcacao; 
	} 

	public Date getDataBaixa() { 
		return this.dataBaixa; 
	} 

	public void setDataBaixa(Date dataBaixa) { 
		this.dataBaixa = dataBaixa; 
	} 

	public Date getVencimentoGarantia() { 
		return this.vencimentoGarantia; 
	} 

	public void setVencimentoGarantia(Date vencimentoGarantia) { 
		this.vencimentoGarantia = vencimentoGarantia; 
	} 

	public String getNumeroNotaFiscal() { 
		return this.numeroNotaFiscal; 
	} 

	public void setNumeroNotaFiscal(String numeroNotaFiscal) { 
		this.numeroNotaFiscal = numeroNotaFiscal; 
	} 

	public String getChaveNfe() { 
		return this.chaveNfe; 
	} 

	public void setChaveNfe(String chaveNfe) { 
		this.chaveNfe = chaveNfe; 
	} 

	public BigDecimal getValorOriginal() { 
		return this.valorOriginal; 
	} 

	public void setValorOriginal(BigDecimal valorOriginal) { 
		this.valorOriginal = valorOriginal; 
	} 

	public BigDecimal getValorCompra() { 
		return this.valorCompra; 
	} 

	public void setValorCompra(BigDecimal valorCompra) { 
		this.valorCompra = valorCompra; 
	} 

	public BigDecimal getValorAtualizado() { 
		return this.valorAtualizado; 
	} 

	public void setValorAtualizado(BigDecimal valorAtualizado) { 
		this.valorAtualizado = valorAtualizado; 
	} 

	public BigDecimal getValorBaixa() { 
		return this.valorBaixa; 
	} 

	public void setValorBaixa(BigDecimal valorBaixa) { 
		this.valorBaixa = valorBaixa; 
	} 

	public String getDeprecia() { 
		return this.deprecia; 
	} 

	public void setDeprecia(String deprecia) { 
		this.deprecia = deprecia; 
	} 

	public String getMetodoDepreciacao() { 
		return this.metodoDepreciacao; 
	} 

	public void setMetodoDepreciacao(String metodoDepreciacao) { 
		this.metodoDepreciacao = metodoDepreciacao; 
	} 

	public Date getInicioDepreciacao() { 
		return this.inicioDepreciacao; 
	} 

	public void setInicioDepreciacao(Date inicioDepreciacao) { 
		this.inicioDepreciacao = inicioDepreciacao; 
	} 

	public Date getUltimaDepreciacao() { 
		return this.ultimaDepreciacao; 
	} 

	public void setUltimaDepreciacao(Date ultimaDepreciacao) { 
		this.ultimaDepreciacao = ultimaDepreciacao; 
	} 

	public String getTipoDepreciacao() { 
		return this.tipoDepreciacao; 
	} 

	public void setTipoDepreciacao(String tipoDepreciacao) { 
		this.tipoDepreciacao = tipoDepreciacao; 
	} 

	public BigDecimal getTaxaAnualDepreciacao() { 
		return this.taxaAnualDepreciacao; 
	} 

	public void setTaxaAnualDepreciacao(BigDecimal taxaAnualDepreciacao) { 
		this.taxaAnualDepreciacao = taxaAnualDepreciacao; 
	} 

	public BigDecimal getTaxaMensalDepreciacao() { 
		return this.taxaMensalDepreciacao; 
	} 

	public void setTaxaMensalDepreciacao(BigDecimal taxaMensalDepreciacao) { 
		this.taxaMensalDepreciacao = taxaMensalDepreciacao; 
	} 

	public BigDecimal getTaxaDepreciacaoAcelerada() { 
		return this.taxaDepreciacaoAcelerada; 
	} 

	public void setTaxaDepreciacaoAcelerada(BigDecimal taxaDepreciacaoAcelerada) { 
		this.taxaDepreciacaoAcelerada = taxaDepreciacaoAcelerada; 
	} 

	public BigDecimal getTaxaDepreciacaoIncentivada() { 
		return this.taxaDepreciacaoIncentivada; 
	} 

	public void setTaxaDepreciacaoIncentivada(BigDecimal taxaDepreciacaoIncentivada) { 
		this.taxaDepreciacaoIncentivada = taxaDepreciacaoIncentivada; 
	} 

	public String getFuncao() { 
		return this.funcao; 
	} 

	public void setFuncao(String funcao) { 
		this.funcao = funcao; 
	} 

		
}