package com.t2ti.pcp.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.pcp.util.Filter;
import com.t2ti.pcp.exception.GenericException;
import com.t2ti.pcp.model.PcpInstrucaoModel;
import com.t2ti.pcp.repository.PcpInstrucaoRepository;

@Service
public class PcpInstrucaoService {

	@Autowired
	private PcpInstrucaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PcpInstrucaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PcpInstrucaoModel> getList(Filter filter) {
		String sql = "select * from pcp_instrucao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PcpInstrucaoModel.class);
		return query.getResultList();
	}

	public PcpInstrucaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PcpInstrucaoModel save(PcpInstrucaoModel obj) {
		PcpInstrucaoModel pcpInstrucaoModel = repository.save(obj);
		return pcpInstrucaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PcpInstrucaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PcpInstrucao] - Exception: " + e.getMessage());
		}
	}

}