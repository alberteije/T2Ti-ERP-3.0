package com.t2ti.pcp.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pcp_instrucao_op")
@NamedQuery(name="PcpInstrucaoOpModel.findAll", query="SELECT t FROM PcpInstrucaoOpModel t")
public class PcpInstrucaoOpModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PcpInstrucaoOpModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pcp_op_cabecalho")
	private PcpOpCabecalhoModel pcpOpCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_pcp_instrucao")
	private PcpInstrucaoModel pcpInstrucaoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public PcpOpCabecalhoModel getPcpOpCabecalhoModel() { 
	return this.pcpOpCabecalhoModel; 
	} 

	public void setPcpOpCabecalhoModel(PcpOpCabecalhoModel pcpOpCabecalhoModel) { 
	this.pcpOpCabecalhoModel = pcpOpCabecalhoModel; 
	} 

	public PcpInstrucaoModel getPcpInstrucaoModel() { 
	return this.pcpInstrucaoModel; 
	} 

	public void setPcpInstrucaoModel(PcpInstrucaoModel pcpInstrucaoModel) { 
	this.pcpInstrucaoModel = pcpInstrucaoModel; 
	} 

		
}