package com.t2ti.pcp.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pcp_servico_equipamento")
@NamedQuery(name="PcpServicoEquipamentoModel.findAll", query="SELECT t FROM PcpServicoEquipamentoModel t")
public class PcpServicoEquipamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PcpServicoEquipamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pcp_servico")
	private PcpServicoModel pcpServicoModel; 

	@ManyToOne 
	@JoinColumn(name="id_patrim_bem")
	private PatrimBemModel patrimBemModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public PcpServicoModel getPcpServicoModel() { 
	return this.pcpServicoModel; 
	} 

	public void setPcpServicoModel(PcpServicoModel pcpServicoModel) { 
	this.pcpServicoModel = pcpServicoModel; 
	} 

	public PatrimBemModel getPatrimBemModel() { 
	return this.patrimBemModel; 
	} 

	public void setPatrimBemModel(PatrimBemModel patrimBemModel) { 
	this.patrimBemModel = patrimBemModel; 
	} 

		
}