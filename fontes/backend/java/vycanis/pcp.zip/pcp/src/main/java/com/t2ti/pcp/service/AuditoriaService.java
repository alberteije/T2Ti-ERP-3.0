package com.t2ti.pcp.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.pcp.util.Filter;
import com.t2ti.pcp.exception.GenericException;
import com.t2ti.pcp.model.AuditoriaModel;
import com.t2ti.pcp.repository.AuditoriaRepository;

@Service
public class AuditoriaService {

	@Autowired
	private AuditoriaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<AuditoriaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<AuditoriaModel> getList(Filter filter) {
		String sql = "select * from auditoria where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, AuditoriaModel.class);
		return query.getResultList();
	}

	public AuditoriaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public AuditoriaModel save(AuditoriaModel obj) {
		AuditoriaModel auditoriaModel = repository.save(obj);
		return auditoriaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		AuditoriaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete Auditoria] - Exception: " + e.getMessage());
		}
	}

}