package com.t2ti.pcp.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pcp_op_detalhe")
@NamedQuery(name="PcpOpDetalheModel.findAll", query="SELECT t FROM PcpOpDetalheModel t")
public class PcpOpDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PcpOpDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade_produzir")
	private BigDecimal quantidadeProduzir;

	@Column(name="quantidade_produzida")
	private BigDecimal quantidadeProduzida;

	@Column(name="quantidade_entregue")
	private BigDecimal quantidadeEntregue;

	@Column(name="custo_previsto")
	private BigDecimal custoPrevisto;

	@Column(name="custo_realizado")
	private BigDecimal custoRealizado;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pcp_op_cabecalho")
	private PcpOpCabecalhoModel pcpOpCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getQuantidadeProduzir() { 
		return this.quantidadeProduzir; 
	} 

	public void setQuantidadeProduzir(BigDecimal quantidadeProduzir) { 
		this.quantidadeProduzir = quantidadeProduzir; 
	} 

	public BigDecimal getQuantidadeProduzida() { 
		return this.quantidadeProduzida; 
	} 

	public void setQuantidadeProduzida(BigDecimal quantidadeProduzida) { 
		this.quantidadeProduzida = quantidadeProduzida; 
	} 

	public BigDecimal getQuantidadeEntregue() { 
		return this.quantidadeEntregue; 
	} 

	public void setQuantidadeEntregue(BigDecimal quantidadeEntregue) { 
		this.quantidadeEntregue = quantidadeEntregue; 
	} 

	public BigDecimal getCustoPrevisto() { 
		return this.custoPrevisto; 
	} 

	public void setCustoPrevisto(BigDecimal custoPrevisto) { 
		this.custoPrevisto = custoPrevisto; 
	} 

	public BigDecimal getCustoRealizado() { 
		return this.custoRealizado; 
	} 

	public void setCustoRealizado(BigDecimal custoRealizado) { 
		this.custoRealizado = custoRealizado; 
	} 

	public PcpOpCabecalhoModel getPcpOpCabecalhoModel() { 
	return this.pcpOpCabecalhoModel; 
	} 

	public void setPcpOpCabecalhoModel(PcpOpCabecalhoModel pcpOpCabecalhoModel) { 
	this.pcpOpCabecalhoModel = pcpOpCabecalhoModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}