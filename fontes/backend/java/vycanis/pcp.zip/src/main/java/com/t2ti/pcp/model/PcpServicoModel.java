package com.t2ti.pcp.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pcp_servico")
@NamedQuery(name="PcpServicoModel.findAll", query="SELECT t FROM PcpServicoModel t")
public class PcpServicoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PcpServicoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="inicio_realizado")
	private Date inicioRealizado;

	@Temporal(TemporalType.DATE)
@Column(name="termino_realizado")
	private Date terminoRealizado;

	@Column(name="horas_realizado")
	private Integer horasRealizado;

	@Column(name="minutos_realizado")
	private Integer minutosRealizado;

	@Column(name="segundos_realizado")
	private Integer segundosRealizado;

	@Column(name="custo_realizado")
	private BigDecimal custoRealizado;

	@Temporal(TemporalType.DATE)
@Column(name="inicio_previsto")
	private Date inicioPrevisto;

	@Temporal(TemporalType.DATE)
@Column(name="termino_previsto")
	private Date terminoPrevisto;

	@Column(name="horas_previsto")
	private Integer horasPrevisto;

	@Column(name="minutos_previsto")
	private Integer minutosPrevisto;

	@Column(name="segundos_previsto")
	private Integer segundosPrevisto;

	@Column(name="custo_previsto")
	private BigDecimal custoPrevisto;

	@OneToMany(mappedBy = "pcpServicoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PcpServicoColaboradorModel> pcpServicoColaboradorModelList; 

	@OneToMany(mappedBy = "pcpServicoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PcpServicoEquipamentoModel> pcpServicoEquipamentoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_pcp_op_detalhe")
	private PcpOpDetalheModel pcpOpDetalheModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getInicioRealizado() { 
		return this.inicioRealizado; 
	} 

	public void setInicioRealizado(Date inicioRealizado) { 
		this.inicioRealizado = inicioRealizado; 
	} 

	public Date getTerminoRealizado() { 
		return this.terminoRealizado; 
	} 

	public void setTerminoRealizado(Date terminoRealizado) { 
		this.terminoRealizado = terminoRealizado; 
	} 

	public Integer getHorasRealizado() { 
		return this.horasRealizado; 
	} 

	public void setHorasRealizado(Integer horasRealizado) { 
		this.horasRealizado = horasRealizado; 
	} 

	public Integer getMinutosRealizado() { 
		return this.minutosRealizado; 
	} 

	public void setMinutosRealizado(Integer minutosRealizado) { 
		this.minutosRealizado = minutosRealizado; 
	} 

	public Integer getSegundosRealizado() { 
		return this.segundosRealizado; 
	} 

	public void setSegundosRealizado(Integer segundosRealizado) { 
		this.segundosRealizado = segundosRealizado; 
	} 

	public BigDecimal getCustoRealizado() { 
		return this.custoRealizado; 
	} 

	public void setCustoRealizado(BigDecimal custoRealizado) { 
		this.custoRealizado = custoRealizado; 
	} 

	public Date getInicioPrevisto() { 
		return this.inicioPrevisto; 
	} 

	public void setInicioPrevisto(Date inicioPrevisto) { 
		this.inicioPrevisto = inicioPrevisto; 
	} 

	public Date getTerminoPrevisto() { 
		return this.terminoPrevisto; 
	} 

	public void setTerminoPrevisto(Date terminoPrevisto) { 
		this.terminoPrevisto = terminoPrevisto; 
	} 

	public Integer getHorasPrevisto() { 
		return this.horasPrevisto; 
	} 

	public void setHorasPrevisto(Integer horasPrevisto) { 
		this.horasPrevisto = horasPrevisto; 
	} 

	public Integer getMinutosPrevisto() { 
		return this.minutosPrevisto; 
	} 

	public void setMinutosPrevisto(Integer minutosPrevisto) { 
		this.minutosPrevisto = minutosPrevisto; 
	} 

	public Integer getSegundosPrevisto() { 
		return this.segundosPrevisto; 
	} 

	public void setSegundosPrevisto(Integer segundosPrevisto) { 
		this.segundosPrevisto = segundosPrevisto; 
	} 

	public BigDecimal getCustoPrevisto() { 
		return this.custoPrevisto; 
	} 

	public void setCustoPrevisto(BigDecimal custoPrevisto) { 
		this.custoPrevisto = custoPrevisto; 
	} 

	public Set<PcpServicoColaboradorModel> getPcpServicoColaboradorModelList() { 
	return this.pcpServicoColaboradorModelList; 
	} 

	public void setPcpServicoColaboradorModelList(Set<PcpServicoColaboradorModel> pcpServicoColaboradorModelList) { 
	this.pcpServicoColaboradorModelList = pcpServicoColaboradorModelList; 
		for (PcpServicoColaboradorModel pcpServicoColaboradorModel : pcpServicoColaboradorModelList) { 
			pcpServicoColaboradorModel.setPcpServicoModel(this); 
		}
	} 

	public Set<PcpServicoEquipamentoModel> getPcpServicoEquipamentoModelList() { 
	return this.pcpServicoEquipamentoModelList; 
	} 

	public void setPcpServicoEquipamentoModelList(Set<PcpServicoEquipamentoModel> pcpServicoEquipamentoModelList) { 
	this.pcpServicoEquipamentoModelList = pcpServicoEquipamentoModelList; 
		for (PcpServicoEquipamentoModel pcpServicoEquipamentoModel : pcpServicoEquipamentoModelList) { 
			pcpServicoEquipamentoModel.setPcpServicoModel(this); 
		}
	} 

	public PcpOpDetalheModel getPcpOpDetalheModel() { 
	return this.pcpOpDetalheModel; 
	} 

	public void setPcpOpDetalheModel(PcpOpDetalheModel pcpOpDetalheModel) { 
	this.pcpOpDetalheModel = pcpOpDetalheModel; 
	} 

		
}