package com.t2ti.pcp.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="pcp_op_cabecalho")
@NamedQuery(name="PcpOpCabecalhoModel.findAll", query="SELECT t FROM PcpOpCabecalhoModel t")
public class PcpOpCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PcpOpCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_previsao_entrega")
	private Date dataPrevisaoEntrega;

	@Temporal(TemporalType.DATE)
@Column(name="data_termino")
	private Date dataTermino;

	@Column(name="custo_total_previsto")
	private BigDecimal custoTotalPrevisto;

	@Column(name="custo_total_realizado")
	private BigDecimal custoTotalRealizado;

	@Column(name="porcento_venda")
	private BigDecimal porcentoVenda;

	@Column(name="porcento_estoque")
	private BigDecimal porcentoEstoque;

	@OneToMany(mappedBy = "pcpOpCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PcpOpDetalheModel> pcpOpDetalheModelList; 

	@OneToMany(mappedBy = "pcpOpCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PcpInstrucaoOpModel> pcpInstrucaoOpModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataPrevisaoEntrega() { 
		return this.dataPrevisaoEntrega; 
	} 

	public void setDataPrevisaoEntrega(Date dataPrevisaoEntrega) { 
		this.dataPrevisaoEntrega = dataPrevisaoEntrega; 
	} 

	public Date getDataTermino() { 
		return this.dataTermino; 
	} 

	public void setDataTermino(Date dataTermino) { 
		this.dataTermino = dataTermino; 
	} 

	public BigDecimal getCustoTotalPrevisto() { 
		return this.custoTotalPrevisto; 
	} 

	public void setCustoTotalPrevisto(BigDecimal custoTotalPrevisto) { 
		this.custoTotalPrevisto = custoTotalPrevisto; 
	} 

	public BigDecimal getCustoTotalRealizado() { 
		return this.custoTotalRealizado; 
	} 

	public void setCustoTotalRealizado(BigDecimal custoTotalRealizado) { 
		this.custoTotalRealizado = custoTotalRealizado; 
	} 

	public BigDecimal getPorcentoVenda() { 
		return this.porcentoVenda; 
	} 

	public void setPorcentoVenda(BigDecimal porcentoVenda) { 
		this.porcentoVenda = porcentoVenda; 
	} 

	public BigDecimal getPorcentoEstoque() { 
		return this.porcentoEstoque; 
	} 

	public void setPorcentoEstoque(BigDecimal porcentoEstoque) { 
		this.porcentoEstoque = porcentoEstoque; 
	} 

	public Set<PcpOpDetalheModel> getPcpOpDetalheModelList() { 
	return this.pcpOpDetalheModelList; 
	} 

	public void setPcpOpDetalheModelList(Set<PcpOpDetalheModel> pcpOpDetalheModelList) { 
	this.pcpOpDetalheModelList = pcpOpDetalheModelList; 
		for (PcpOpDetalheModel pcpOpDetalheModel : pcpOpDetalheModelList) { 
			pcpOpDetalheModel.setPcpOpCabecalhoModel(this); 
		}
	} 

	public Set<PcpInstrucaoOpModel> getPcpInstrucaoOpModelList() { 
	return this.pcpInstrucaoOpModelList; 
	} 

	public void setPcpInstrucaoOpModelList(Set<PcpInstrucaoOpModel> pcpInstrucaoOpModelList) { 
	this.pcpInstrucaoOpModelList = pcpInstrucaoOpModelList; 
		for (PcpInstrucaoOpModel pcpInstrucaoOpModel : pcpInstrucaoOpModelList) { 
			pcpInstrucaoOpModel.setPcpOpCabecalhoModel(this); 
		}
	} 

		
}