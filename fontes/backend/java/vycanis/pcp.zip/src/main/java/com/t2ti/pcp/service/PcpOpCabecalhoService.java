package com.t2ti.pcp.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.pcp.util.Filter;
import com.t2ti.pcp.exception.GenericException;
import com.t2ti.pcp.model.PcpOpCabecalhoModel;
import com.t2ti.pcp.repository.PcpOpCabecalhoRepository;

@Service
public class PcpOpCabecalhoService {

	@Autowired
	private PcpOpCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<PcpOpCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<PcpOpCabecalhoModel> getList(Filter filter) {
		String sql = "select * from pcp_op_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, PcpOpCabecalhoModel.class);
		return query.getResultList();
	}

	public PcpOpCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public PcpOpCabecalhoModel save(PcpOpCabecalhoModel obj) {
		PcpOpCabecalhoModel pcpOpCabecalhoModel = repository.save(obj);
		return pcpOpCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		PcpOpCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete PcpOpCabecalho] - Exception: " + e.getMessage());
		}
	}

}