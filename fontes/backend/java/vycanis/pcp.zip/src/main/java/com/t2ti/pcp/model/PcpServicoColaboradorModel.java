package com.t2ti.pcp.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="pcp_servico_colaborador")
@NamedQuery(name="PcpServicoColaboradorModel.findAll", query="SELECT t FROM PcpServicoColaboradorModel t")
public class PcpServicoColaboradorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PcpServicoColaboradorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_pcp_servico")
	private PcpServicoModel pcpServicoModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public PcpServicoModel getPcpServicoModel() { 
	return this.pcpServicoModel; 
	} 

	public void setPcpServicoModel(PcpServicoModel pcpServicoModel) { 
	this.pcpServicoModel = pcpServicoModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}