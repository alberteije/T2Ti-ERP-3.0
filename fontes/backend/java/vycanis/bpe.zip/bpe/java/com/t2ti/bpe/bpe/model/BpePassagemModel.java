package com.t2ti.bpe.bpe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="bpe_passagem")
@NamedQuery(name="BpePassagemModel.findAll", query="SELECT t FROM BpePassagemModel t")
public class BpePassagemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public BpePassagemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_localidade_origem")
	private String codigoLocalidadeOrigem;

	@Column(name="descricao_localidade_origem")
	private String descricaoLocalidadeOrigem;

	@Column(name="codigo_localidade_destino")
	private String codigoLocalidadeDestino;

	@Column(name="descricao_localidade_destino")
	private String descricaoLocalidadeDestino;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_embarque")
	private Date dataHoraEmbarque;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_validade")
	private Date dataHoraValidade;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_bpe_cabecalho")
	private BpeCabecalhoModel bpeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoLocalidadeOrigem() { 
		return this.codigoLocalidadeOrigem; 
	} 

	public void setCodigoLocalidadeOrigem(String codigoLocalidadeOrigem) { 
		this.codigoLocalidadeOrigem = codigoLocalidadeOrigem; 
	} 

	public String getDescricaoLocalidadeOrigem() { 
		return this.descricaoLocalidadeOrigem; 
	} 

	public void setDescricaoLocalidadeOrigem(String descricaoLocalidadeOrigem) { 
		this.descricaoLocalidadeOrigem = descricaoLocalidadeOrigem; 
	} 

	public String getCodigoLocalidadeDestino() { 
		return this.codigoLocalidadeDestino; 
	} 

	public void setCodigoLocalidadeDestino(String codigoLocalidadeDestino) { 
		this.codigoLocalidadeDestino = codigoLocalidadeDestino; 
	} 

	public String getDescricaoLocalidadeDestino() { 
		return this.descricaoLocalidadeDestino; 
	} 

	public void setDescricaoLocalidadeDestino(String descricaoLocalidadeDestino) { 
		this.descricaoLocalidadeDestino = descricaoLocalidadeDestino; 
	} 

	public Date getDataHoraEmbarque() { 
		return this.dataHoraEmbarque; 
	} 

	public void setDataHoraEmbarque(Date dataHoraEmbarque) { 
		this.dataHoraEmbarque = dataHoraEmbarque; 
	} 

	public Date getDataHoraValidade() { 
		return this.dataHoraValidade; 
	} 

	public void setDataHoraValidade(Date dataHoraValidade) { 
		this.dataHoraValidade = dataHoraValidade; 
	} 

	public BpeCabecalhoModel getBpeCabecalhoModel() { 
	return this.bpeCabecalhoModel; 
	} 

	public void setBpeCabecalhoModel(BpeCabecalhoModel bpeCabecalhoModel) { 
	this.bpeCabecalhoModel = bpeCabecalhoModel; 
	} 

		
}