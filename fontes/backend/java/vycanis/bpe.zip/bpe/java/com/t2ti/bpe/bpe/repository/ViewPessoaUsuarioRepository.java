package com.t2ti.bpe.bpe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.bpe.bpe.model.ViewPessoaUsuarioModel;

public interface ViewPessoaUsuarioRepository extends JpaRepository<ViewPessoaUsuarioModel, Integer> {}