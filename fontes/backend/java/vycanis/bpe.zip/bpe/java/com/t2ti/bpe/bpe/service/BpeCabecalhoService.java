package com.t2ti.bpe.bpe.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.bpe.bpe.util.Filter;
import com.t2ti.bpe.bpe.exception.GenericException;
import com.t2ti.bpe.bpe.model.BpeCabecalhoModel;
import com.t2ti.bpe.bpe.repository.BpeCabecalhoRepository;

@Service
public class BpeCabecalhoService {

	@Autowired
	private BpeCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<BpeCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<BpeCabecalhoModel> getList(Filter filter) {
		String sql = "select * from bpe_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, BpeCabecalhoModel.class);
		return query.getResultList();
	}

	public BpeCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public BpeCabecalhoModel save(BpeCabecalhoModel obj) {
		BpeCabecalhoModel bpeCabecalhoModel = repository.save(obj);
		return bpeCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		BpeCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete BpeCabecalho] - Exception: " + e.getMessage());
		}
	}

}