package com.t2ti.bpe.bpe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.bpe.bpe.model.BpeCabecalhoModel;

public interface BpeCabecalhoRepository extends JpaRepository<BpeCabecalhoModel, Integer> {}