package com.t2ti.bpe.bpe.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.bpe.bpe.exception.GenericException;
import com.t2ti.bpe.bpe.exception.ResourseNotFoundException;
import com.t2ti.bpe.bpe.exception.BadRequestException;
import com.t2ti.bpe.bpe.util.Filter;
import com.t2ti.bpe.bpe.model.ViewControleAcessoModel;
import com.t2ti.bpe.bpe.service.ViewControleAcessoService;

@RestController
@RequestMapping(value = "/view-controle-acesso", produces = "application/json;charset=UTF-8")
public class ViewControleAcessoController {

	@Autowired
	private ViewControleAcessoService service;
	
	@GetMapping({ "", "/" })
	public List<ViewControleAcessoModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [ViewControleAcesso] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public ViewControleAcessoModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found ViewControleAcesso].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found ViewControleAcesso] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public ViewControleAcessoModel insert(@RequestBody ViewControleAcessoModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert ViewControleAcesso] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public ViewControleAcessoModel update(@RequestBody ViewControleAcessoModel objJson) {	
		try {			
			ViewControleAcessoModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update ViewControleAcesso].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update ViewControleAcesso] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ViewControleAcesso] - Exception: " + e.getMessage());
		}
	}
	
}