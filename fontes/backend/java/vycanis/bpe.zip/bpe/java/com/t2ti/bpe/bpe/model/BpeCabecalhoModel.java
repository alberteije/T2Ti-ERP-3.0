package com.t2ti.bpe.bpe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="bpe_cabecalho")
@NamedQuery(name="BpeCabecalhoModel.findAll", query="SELECT t FROM BpeCabecalhoModel t")
public class BpeCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public BpeCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="uf_emitente")
	private String ufEmitente;

	@Column(name="ambiente")
	private String ambiente;

	@Column(name="modelo")
	private String modelo;

	@Column(name="serie")
	private String serie;

	@Column(name="numero")
	private String numero;

	@Column(name="codigo_numerico")
	private String codigoNumerico;

	@Column(name="chave_acesso")
	private String chaveAcesso;

	@Column(name="digito_chave_acesso")
	private String digitoChaveAcesso;

	@Column(name="modal")
	private String modal;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_emissao")
	private Date dataHoraEmissao;

	@Column(name="tipo_emissao")
	private String tipoEmissao;

	@Column(name="versao_processo_emissao")
	private String versaoProcessoEmissao;

	@Column(name="tipo_bpe")
	private String tipoBpe;

	@Column(name="consumidor_presenca")
	private String consumidorPresenca;

	@Column(name="uf_inicio_viagem")
	private String ufInicioViagem;

	@Column(name="codigo_municipio_inicio_viagem")
	private Integer codigoMunicipioInicioViagem;

	@Column(name="uf_fim_viagem")
	private String ufFimViagem;

	@Column(name="codigo_municipio_fim_viagem")
	private Integer codigoMunicipioFimViagem;

	@Column(name="valor_bilhete")
	private BigDecimal valorBilhete;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_pago")
	private BigDecimal valorPago;

	@Column(name="valor_troco")
	private BigDecimal valorTroco;

	@Column(name="tipo_desconto")
	private String tipoDesconto;

	@Column(name="desconto_descricao")
	private String descontoDescricao;

	@Column(name="desconto_concedido_outros")
	private String descontoConcedidoOutros;

	@Column(name="forma_pagamento")
	private String formaPagamento;

	@Column(name="forma_pagamento_outros")
	private String formaPagamentoOutros;

	@Column(name="forma_pagamento_documento")
	private String formaPagamentoDocumento;

	@Column(name="cst")
	private String cst;

	@Column(name="base_calculo_icms")
	private BigDecimal baseCalculoIcms;

	@Column(name="aliquota_icms")
	private BigDecimal aliquotaIcms;

	@Column(name="valor_icms")
	private BigDecimal valorIcms;

	@Column(name="percentual_reducao_bc_icms")
	private BigDecimal percentualReducaoBcIcms;

	@Column(name="informacoes_add_fisco")
	private String informacoesAddFisco;

	@OneToMany(mappedBy = "bpeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<BpeEmitenteModel> bpeEmitenteModelList; 

	@OneToMany(mappedBy = "bpeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<BpePassageiroModel> bpePassageiroModelList; 

	@OneToMany(mappedBy = "bpeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<BpeCompradorModel> bpeCompradorModelList; 

	@OneToMany(mappedBy = "bpeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<BpeViagemModel> bpeViagemModelList; 

	@OneToMany(mappedBy = "bpeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<BpeAgenciaModel> bpeAgenciaModelList; 

	@OneToMany(mappedBy = "bpeCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<BpePassagemModel> bpePassagemModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getUfEmitente() { 
		return this.ufEmitente; 
	} 

	public void setUfEmitente(String ufEmitente) { 
		this.ufEmitente = ufEmitente; 
	} 

	public String getAmbiente() { 
		return this.ambiente; 
	} 

	public void setAmbiente(String ambiente) { 
		this.ambiente = ambiente; 
	} 

	public String getModelo() { 
		return this.modelo; 
	} 

	public void setModelo(String modelo) { 
		this.modelo = modelo; 
	} 

	public String getSerie() { 
		return this.serie; 
	} 

	public void setSerie(String serie) { 
		this.serie = serie; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getCodigoNumerico() { 
		return this.codigoNumerico; 
	} 

	public void setCodigoNumerico(String codigoNumerico) { 
		this.codigoNumerico = codigoNumerico; 
	} 

	public String getChaveAcesso() { 
		return this.chaveAcesso; 
	} 

	public void setChaveAcesso(String chaveAcesso) { 
		this.chaveAcesso = chaveAcesso; 
	} 

	public String getDigitoChaveAcesso() { 
		return this.digitoChaveAcesso; 
	} 

	public void setDigitoChaveAcesso(String digitoChaveAcesso) { 
		this.digitoChaveAcesso = digitoChaveAcesso; 
	} 

	public String getModal() { 
		return this.modal; 
	} 

	public void setModal(String modal) { 
		this.modal = modal; 
	} 

	public Date getDataHoraEmissao() { 
		return this.dataHoraEmissao; 
	} 

	public void setDataHoraEmissao(Date dataHoraEmissao) { 
		this.dataHoraEmissao = dataHoraEmissao; 
	} 

	public String getTipoEmissao() { 
		return this.tipoEmissao; 
	} 

	public void setTipoEmissao(String tipoEmissao) { 
		this.tipoEmissao = tipoEmissao; 
	} 

	public String getVersaoProcessoEmissao() { 
		return this.versaoProcessoEmissao; 
	} 

	public void setVersaoProcessoEmissao(String versaoProcessoEmissao) { 
		this.versaoProcessoEmissao = versaoProcessoEmissao; 
	} 

	public String getTipoBpe() { 
		return this.tipoBpe; 
	} 

	public void setTipoBpe(String tipoBpe) { 
		this.tipoBpe = tipoBpe; 
	} 

	public String getConsumidorPresenca() { 
		return this.consumidorPresenca; 
	} 

	public void setConsumidorPresenca(String consumidorPresenca) { 
		this.consumidorPresenca = consumidorPresenca; 
	} 

	public String getUfInicioViagem() { 
		return this.ufInicioViagem; 
	} 

	public void setUfInicioViagem(String ufInicioViagem) { 
		this.ufInicioViagem = ufInicioViagem; 
	} 

	public Integer getCodigoMunicipioInicioViagem() { 
		return this.codigoMunicipioInicioViagem; 
	} 

	public void setCodigoMunicipioInicioViagem(Integer codigoMunicipioInicioViagem) { 
		this.codigoMunicipioInicioViagem = codigoMunicipioInicioViagem; 
	} 

	public String getUfFimViagem() { 
		return this.ufFimViagem; 
	} 

	public void setUfFimViagem(String ufFimViagem) { 
		this.ufFimViagem = ufFimViagem; 
	} 

	public Integer getCodigoMunicipioFimViagem() { 
		return this.codigoMunicipioFimViagem; 
	} 

	public void setCodigoMunicipioFimViagem(Integer codigoMunicipioFimViagem) { 
		this.codigoMunicipioFimViagem = codigoMunicipioFimViagem; 
	} 

	public BigDecimal getValorBilhete() { 
		return this.valorBilhete; 
	} 

	public void setValorBilhete(BigDecimal valorBilhete) { 
		this.valorBilhete = valorBilhete; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorPago() { 
		return this.valorPago; 
	} 

	public void setValorPago(BigDecimal valorPago) { 
		this.valorPago = valorPago; 
	} 

	public BigDecimal getValorTroco() { 
		return this.valorTroco; 
	} 

	public void setValorTroco(BigDecimal valorTroco) { 
		this.valorTroco = valorTroco; 
	} 

	public String getTipoDesconto() { 
		return this.tipoDesconto; 
	} 

	public void setTipoDesconto(String tipoDesconto) { 
		this.tipoDesconto = tipoDesconto; 
	} 

	public String getDescontoDescricao() { 
		return this.descontoDescricao; 
	} 

	public void setDescontoDescricao(String descontoDescricao) { 
		this.descontoDescricao = descontoDescricao; 
	} 

	public String getDescontoConcedidoOutros() { 
		return this.descontoConcedidoOutros; 
	} 

	public void setDescontoConcedidoOutros(String descontoConcedidoOutros) { 
		this.descontoConcedidoOutros = descontoConcedidoOutros; 
	} 

	public String getFormaPagamento() { 
		return this.formaPagamento; 
	} 

	public void setFormaPagamento(String formaPagamento) { 
		this.formaPagamento = formaPagamento; 
	} 

	public String getFormaPagamentoOutros() { 
		return this.formaPagamentoOutros; 
	} 

	public void setFormaPagamentoOutros(String formaPagamentoOutros) { 
		this.formaPagamentoOutros = formaPagamentoOutros; 
	} 

	public String getFormaPagamentoDocumento() { 
		return this.formaPagamentoDocumento; 
	} 

	public void setFormaPagamentoDocumento(String formaPagamentoDocumento) { 
		this.formaPagamentoDocumento = formaPagamentoDocumento; 
	} 

	public String getCst() { 
		return this.cst; 
	} 

	public void setCst(String cst) { 
		this.cst = cst; 
	} 

	public BigDecimal getBaseCalculoIcms() { 
		return this.baseCalculoIcms; 
	} 

	public void setBaseCalculoIcms(BigDecimal baseCalculoIcms) { 
		this.baseCalculoIcms = baseCalculoIcms; 
	} 

	public BigDecimal getAliquotaIcms() { 
		return this.aliquotaIcms; 
	} 

	public void setAliquotaIcms(BigDecimal aliquotaIcms) { 
		this.aliquotaIcms = aliquotaIcms; 
	} 

	public BigDecimal getValorIcms() { 
		return this.valorIcms; 
	} 

	public void setValorIcms(BigDecimal valorIcms) { 
		this.valorIcms = valorIcms; 
	} 

	public BigDecimal getPercentualReducaoBcIcms() { 
		return this.percentualReducaoBcIcms; 
	} 

	public void setPercentualReducaoBcIcms(BigDecimal percentualReducaoBcIcms) { 
		this.percentualReducaoBcIcms = percentualReducaoBcIcms; 
	} 

	public String getInformacoesAddFisco() { 
		return this.informacoesAddFisco; 
	} 

	public void setInformacoesAddFisco(String informacoesAddFisco) { 
		this.informacoesAddFisco = informacoesAddFisco; 
	} 

	public Set<BpeEmitenteModel> getBpeEmitenteModelList() { 
	return this.bpeEmitenteModelList; 
	} 

	public void setBpeEmitenteModelList(Set<BpeEmitenteModel> bpeEmitenteModelList) { 
	this.bpeEmitenteModelList = bpeEmitenteModelList; 
		for (BpeEmitenteModel bpeEmitenteModel : bpeEmitenteModelList) { 
			bpeEmitenteModel.setBpeCabecalhoModel(this); 
		}
	} 

	public Set<BpePassageiroModel> getBpePassageiroModelList() { 
	return this.bpePassageiroModelList; 
	} 

	public void setBpePassageiroModelList(Set<BpePassageiroModel> bpePassageiroModelList) { 
	this.bpePassageiroModelList = bpePassageiroModelList; 
		for (BpePassageiroModel bpePassageiroModel : bpePassageiroModelList) { 
			bpePassageiroModel.setBpeCabecalhoModel(this); 
		}
	} 

	public Set<BpeCompradorModel> getBpeCompradorModelList() { 
	return this.bpeCompradorModelList; 
	} 

	public void setBpeCompradorModelList(Set<BpeCompradorModel> bpeCompradorModelList) { 
	this.bpeCompradorModelList = bpeCompradorModelList; 
		for (BpeCompradorModel bpeCompradorModel : bpeCompradorModelList) { 
			bpeCompradorModel.setBpeCabecalhoModel(this); 
		}
	} 

	public Set<BpeViagemModel> getBpeViagemModelList() { 
	return this.bpeViagemModelList; 
	} 

	public void setBpeViagemModelList(Set<BpeViagemModel> bpeViagemModelList) { 
	this.bpeViagemModelList = bpeViagemModelList; 
		for (BpeViagemModel bpeViagemModel : bpeViagemModelList) { 
			bpeViagemModel.setBpeCabecalhoModel(this); 
		}
	} 

	public Set<BpeAgenciaModel> getBpeAgenciaModelList() { 
	return this.bpeAgenciaModelList; 
	} 

	public void setBpeAgenciaModelList(Set<BpeAgenciaModel> bpeAgenciaModelList) { 
	this.bpeAgenciaModelList = bpeAgenciaModelList; 
		for (BpeAgenciaModel bpeAgenciaModel : bpeAgenciaModelList) { 
			bpeAgenciaModel.setBpeCabecalhoModel(this); 
		}
	} 

	public Set<BpePassagemModel> getBpePassagemModelList() { 
	return this.bpePassagemModelList; 
	} 

	public void setBpePassagemModelList(Set<BpePassagemModel> bpePassagemModelList) { 
	this.bpePassagemModelList = bpePassagemModelList; 
		for (BpePassagemModel bpePassagemModel : bpePassagemModelList) { 
			bpePassagemModel.setBpeCabecalhoModel(this); 
		}
	} 

		
}