package com.t2ti.bpe.bpe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="bpe_emitente")
@NamedQuery(name="BpeEmitenteModel.findAll", query="SELECT t FROM BpeEmitenteModel t")
public class BpeEmitenteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public BpeEmitenteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cnpj")
	private String cnpj;

	@Column(name="ie")
	private String ie;

	@Column(name="iest")
	private String iest;

	@Column(name="im")
	private String im;

	@Column(name="cnae")
	private String cnae;

	@Column(name="crt")
	private String crt;

	@Column(name="nome")
	private String nome;

	@Column(name="fantasia")
	private String fantasia;

	@Column(name="logradouro")
	private String logradouro;

	@Column(name="numero")
	private String numero;

	@Column(name="complemento")
	private String complemento;

	@Column(name="bairro")
	private String bairro;

	@Column(name="codigo_municipio")
	private Integer codigoMunicipio;

	@Column(name="nome_municipio")
	private String nomeMunicipio;

	@Column(name="uf")
	private String uf;

	@Column(name="cep")
	private String cep;

	@Column(name="telefone")
	private String telefone;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_bpe_cabecalho")
	private BpeCabecalhoModel bpeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCnpj() { 
		return this.cnpj; 
	} 

	public void setCnpj(String cnpj) { 
		this.cnpj = cnpj; 
	} 

	public String getIe() { 
		return this.ie; 
	} 

	public void setIe(String ie) { 
		this.ie = ie; 
	} 

	public String getIest() { 
		return this.iest; 
	} 

	public void setIest(String iest) { 
		this.iest = iest; 
	} 

	public String getIm() { 
		return this.im; 
	} 

	public void setIm(String im) { 
		this.im = im; 
	} 

	public String getCnae() { 
		return this.cnae; 
	} 

	public void setCnae(String cnae) { 
		this.cnae = cnae; 
	} 

	public String getCrt() { 
		return this.crt; 
	} 

	public void setCrt(String crt) { 
		this.crt = crt; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getFantasia() { 
		return this.fantasia; 
	} 

	public void setFantasia(String fantasia) { 
		this.fantasia = fantasia; 
	} 

	public String getLogradouro() { 
		return this.logradouro; 
	} 

	public void setLogradouro(String logradouro) { 
		this.logradouro = logradouro; 
	} 

	public String getNumero() { 
		return this.numero; 
	} 

	public void setNumero(String numero) { 
		this.numero = numero; 
	} 

	public String getComplemento() { 
		return this.complemento; 
	} 

	public void setComplemento(String complemento) { 
		this.complemento = complemento; 
	} 

	public String getBairro() { 
		return this.bairro; 
	} 

	public void setBairro(String bairro) { 
		this.bairro = bairro; 
	} 

	public Integer getCodigoMunicipio() { 
		return this.codigoMunicipio; 
	} 

	public void setCodigoMunicipio(Integer codigoMunicipio) { 
		this.codigoMunicipio = codigoMunicipio; 
	} 

	public String getNomeMunicipio() { 
		return this.nomeMunicipio; 
	} 

	public void setNomeMunicipio(String nomeMunicipio) { 
		this.nomeMunicipio = nomeMunicipio; 
	} 

	public String getUf() { 
		return this.uf; 
	} 

	public void setUf(String uf) { 
		this.uf = uf; 
	} 

	public String getCep() { 
		return this.cep; 
	} 

	public void setCep(String cep) { 
		this.cep = cep; 
	} 

	public String getTelefone() { 
		return this.telefone; 
	} 

	public void setTelefone(String telefone) { 
		this.telefone = telefone; 
	} 

	public BpeCabecalhoModel getBpeCabecalhoModel() { 
	return this.bpeCabecalhoModel; 
	} 

	public void setBpeCabecalhoModel(BpeCabecalhoModel bpeCabecalhoModel) { 
	this.bpeCabecalhoModel = bpeCabecalhoModel; 
	} 

		
}