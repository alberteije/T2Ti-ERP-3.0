package com.t2ti.bpe.bpe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="bpe_viagem")
@NamedQuery(name="BpeViagemModel.findAll", query="SELECT t FROM BpeViagemModel t")
public class BpeViagemModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public BpeViagemModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_percurso")
	private String codigoPercurso;

	@Column(name="descricao_percurso")
	private String descricaoPercurso;

	@Column(name="tipo_viagem")
	private String tipoViagem;

	@Column(name="tipo_servico")
	private String tipoServico;

	@Column(name="tipo_acomodacao")
	private String tipoAcomodacao;

	@Column(name="tipo_trecho")
	private String tipoTrecho;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_viagem")
	private Date dataHoraViagem;

	@Temporal(TemporalType.DATE)
@Column(name="data_hora_conexao")
	private Date dataHoraConexao;

	@Column(name="prefixo_linha")
	private String prefixoLinha;

	@Column(name="poltrona")
	private String poltrona;

	@Column(name="plataforma")
	private String plataforma;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_bpe_cabecalho")
	private BpeCabecalhoModel bpeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoPercurso() { 
		return this.codigoPercurso; 
	} 

	public void setCodigoPercurso(String codigoPercurso) { 
		this.codigoPercurso = codigoPercurso; 
	} 

	public String getDescricaoPercurso() { 
		return this.descricaoPercurso; 
	} 

	public void setDescricaoPercurso(String descricaoPercurso) { 
		this.descricaoPercurso = descricaoPercurso; 
	} 

	public String getTipoViagem() { 
		return this.tipoViagem; 
	} 

	public void setTipoViagem(String tipoViagem) { 
		this.tipoViagem = tipoViagem; 
	} 

	public String getTipoServico() { 
		return this.tipoServico; 
	} 

	public void setTipoServico(String tipoServico) { 
		this.tipoServico = tipoServico; 
	} 

	public String getTipoAcomodacao() { 
		return this.tipoAcomodacao; 
	} 

	public void setTipoAcomodacao(String tipoAcomodacao) { 
		this.tipoAcomodacao = tipoAcomodacao; 
	} 

	public String getTipoTrecho() { 
		return this.tipoTrecho; 
	} 

	public void setTipoTrecho(String tipoTrecho) { 
		this.tipoTrecho = tipoTrecho; 
	} 

	public Date getDataHoraViagem() { 
		return this.dataHoraViagem; 
	} 

	public void setDataHoraViagem(Date dataHoraViagem) { 
		this.dataHoraViagem = dataHoraViagem; 
	} 

	public Date getDataHoraConexao() { 
		return this.dataHoraConexao; 
	} 

	public void setDataHoraConexao(Date dataHoraConexao) { 
		this.dataHoraConexao = dataHoraConexao; 
	} 

	public String getPrefixoLinha() { 
		return this.prefixoLinha; 
	} 

	public void setPrefixoLinha(String prefixoLinha) { 
		this.prefixoLinha = prefixoLinha; 
	} 

	public String getPoltrona() { 
		return this.poltrona; 
	} 

	public void setPoltrona(String poltrona) { 
		this.poltrona = poltrona; 
	} 

	public String getPlataforma() { 
		return this.plataforma; 
	} 

	public void setPlataforma(String plataforma) { 
		this.plataforma = plataforma; 
	} 

	public BpeCabecalhoModel getBpeCabecalhoModel() { 
	return this.bpeCabecalhoModel; 
	} 

	public void setBpeCabecalhoModel(BpeCabecalhoModel bpeCabecalhoModel) { 
	this.bpeCabecalhoModel = bpeCabecalhoModel; 
	} 

		
}