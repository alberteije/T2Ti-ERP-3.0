package com.t2ti.bpe.bpe.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="bpe_passageiro")
@NamedQuery(name="BpePassageiroModel.findAll", query="SELECT t FROM BpePassageiroModel t")
public class BpePassageiroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public BpePassageiroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="cpf")
	private String cpf;

	@Column(name="tipo_documento_identificacao")
	private String tipoDocumentoIdentificacao;

	@Column(name="numero_documento")
	private String numeroDocumento;

	@Column(name="documento_outros_descricao")
	private String documentoOutrosDescricao;

	@Temporal(TemporalType.DATE)
@Column(name="data_nascimento")
	private Date dataNascimento;

	@Column(name="telefone")
	private String telefone;

	@Column(name="email")
	private String email;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_bpe_cabecalho")
	private BpeCabecalhoModel bpeCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getCpf() { 
		return this.cpf; 
	} 

	public void setCpf(String cpf) { 
		this.cpf = cpf; 
	} 

	public String getTipoDocumentoIdentificacao() { 
		return this.tipoDocumentoIdentificacao; 
	} 

	public void setTipoDocumentoIdentificacao(String tipoDocumentoIdentificacao) { 
		this.tipoDocumentoIdentificacao = tipoDocumentoIdentificacao; 
	} 

	public String getNumeroDocumento() { 
		return this.numeroDocumento; 
	} 

	public void setNumeroDocumento(String numeroDocumento) { 
		this.numeroDocumento = numeroDocumento; 
	} 

	public String getDocumentoOutrosDescricao() { 
		return this.documentoOutrosDescricao; 
	} 

	public void setDocumentoOutrosDescricao(String documentoOutrosDescricao) { 
		this.documentoOutrosDescricao = documentoOutrosDescricao; 
	} 

	public Date getDataNascimento() { 
		return this.dataNascimento; 
	} 

	public void setDataNascimento(Date dataNascimento) { 
		this.dataNascimento = dataNascimento; 
	} 

	public String getTelefone() { 
		return this.telefone; 
	} 

	public void setTelefone(String telefone) { 
		this.telefone = telefone; 
	} 

	public String getEmail() { 
		return this.email; 
	} 

	public void setEmail(String email) { 
		this.email = email; 
	} 

	public BpeCabecalhoModel getBpeCabecalhoModel() { 
	return this.bpeCabecalhoModel; 
	} 

	public void setBpeCabecalhoModel(BpeCabecalhoModel bpeCabecalhoModel) { 
	this.bpeCabecalhoModel = bpeCabecalhoModel; 
	} 

		
}