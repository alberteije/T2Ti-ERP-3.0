package com.t2ti.compras.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="compra_fornecedor_cotacao")
@NamedQuery(name="CompraFornecedorCotacaoModel.findAll", query="SELECT t FROM CompraFornecedorCotacaoModel t")
public class CompraFornecedorCotacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CompraFornecedorCotacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="prazo_entrega")
	private String prazoEntrega;

	@Column(name="venda_condicoes_pagamento")
	private String vendaCondicoesPagamento;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@ManyToOne 
	@JoinColumn(name="id_fornecedor")
	private ViewPessoaFornecedorModel viewPessoaFornecedorModel; 

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_compra_cotacao")
	private CompraCotacaoModel compraCotacaoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getPrazoEntrega() { 
		return this.prazoEntrega; 
	} 

	public void setPrazoEntrega(String prazoEntrega) { 
		this.prazoEntrega = prazoEntrega; 
	} 

	public String getVendaCondicoesPagamento() { 
		return this.vendaCondicoesPagamento; 
	} 

	public void setVendaCondicoesPagamento(String vendaCondicoesPagamento) { 
		this.vendaCondicoesPagamento = vendaCondicoesPagamento; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public ViewPessoaFornecedorModel getViewPessoaFornecedorModel() { 
	return this.viewPessoaFornecedorModel; 
	} 

	public void setViewPessoaFornecedorModel(ViewPessoaFornecedorModel viewPessoaFornecedorModel) { 
	this.viewPessoaFornecedorModel = viewPessoaFornecedorModel; 
	} 

	public CompraCotacaoModel getCompraCotacaoModel() { 
	return this.compraCotacaoModel; 
	} 

	public void setCompraCotacaoModel(CompraCotacaoModel compraCotacaoModel) { 
	this.compraCotacaoModel = compraCotacaoModel; 
	} 

		
}