package com.t2ti.compras.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.compras.util.Filter;
import com.t2ti.compras.exception.GenericException;
import com.t2ti.compras.model.CompraTipoPedidoModel;
import com.t2ti.compras.repository.CompraTipoPedidoRepository;

@Service
public class CompraTipoPedidoService {

	@Autowired
	private CompraTipoPedidoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CompraTipoPedidoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CompraTipoPedidoModel> getList(Filter filter) {
		String sql = "select * from compra_tipo_pedido where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CompraTipoPedidoModel.class);
		return query.getResultList();
	}

	public CompraTipoPedidoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CompraTipoPedidoModel save(CompraTipoPedidoModel obj) {
		CompraTipoPedidoModel compraTipoPedidoModel = repository.save(obj);
		return compraTipoPedidoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CompraTipoPedidoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CompraTipoPedido] - Exception: " + e.getMessage());
		}
	}

}