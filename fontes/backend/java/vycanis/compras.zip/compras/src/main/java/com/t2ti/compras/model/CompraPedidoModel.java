package com.t2ti.compras.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="compra_pedido")
@NamedQuery(name="CompraPedidoModel.findAll", query="SELECT t FROM CompraPedidoModel t")
public class CompraPedidoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CompraPedidoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo_cotacao")
	private String codigoCotacao;

	@Temporal(TemporalType.DATE)
@Column(name="data_pedido")
	private Date dataPedido;

	@Temporal(TemporalType.DATE)
@Column(name="data_prevista_entrega")
	private Date dataPrevistaEntrega;

	@Temporal(TemporalType.DATE)
@Column(name="data_previsao_pagamento")
	private Date dataPrevisaoPagamento;

	@Column(name="local_entrega")
	private String localEntrega;

	@Column(name="local_cobranca")
	private String localCobranca;

	@Column(name="contato")
	private String contato;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="tipo_frete")
	private String tipoFrete;

	@Column(name="forma_pagamento")
	private String formaPagamento;

	@Column(name="base_calculo_icms")
	private BigDecimal baseCalculoIcms;

	@Column(name="valor_icms")
	private BigDecimal valorIcms;

	@Column(name="base_calculo_icms_st")
	private BigDecimal baseCalculoIcmsSt;

	@Column(name="valor_icms_st")
	private BigDecimal valorIcmsSt;

	@Column(name="valor_total_produtos")
	private BigDecimal valorTotalProdutos;

	@Column(name="valor_frete")
	private BigDecimal valorFrete;

	@Column(name="valor_seguro")
	private BigDecimal valorSeguro;

	@Column(name="valor_outras_despesas")
	private BigDecimal valorOutrasDespesas;

	@Column(name="valor_ipi")
	private BigDecimal valorIpi;

	@Column(name="valor_total_nf")
	private BigDecimal valorTotalNf;

	@Column(name="quantidade_parcelas")
	private Integer quantidadeParcelas;

	@Column(name="dia_primeiro_vencimento")
	private String diaPrimeiroVencimento;

	@Column(name="intervalo_entre_parcelas")
	private Integer intervaloEntreParcelas;

	@Column(name="dia_fixo_parcela")
	private String diaFixoParcela;

	@OneToMany(mappedBy = "compraPedidoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CompraPedidoDetalheModel> compraPedidoDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_compra_tipo_pedido")
	private CompraTipoPedidoModel compraTipoPedidoModel; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_fornecedor")
	private ViewPessoaFornecedorModel viewPessoaFornecedorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigoCotacao() { 
		return this.codigoCotacao; 
	} 

	public void setCodigoCotacao(String codigoCotacao) { 
		this.codigoCotacao = codigoCotacao; 
	} 

	public Date getDataPedido() { 
		return this.dataPedido; 
	} 

	public void setDataPedido(Date dataPedido) { 
		this.dataPedido = dataPedido; 
	} 

	public Date getDataPrevistaEntrega() { 
		return this.dataPrevistaEntrega; 
	} 

	public void setDataPrevistaEntrega(Date dataPrevistaEntrega) { 
		this.dataPrevistaEntrega = dataPrevistaEntrega; 
	} 

	public Date getDataPrevisaoPagamento() { 
		return this.dataPrevisaoPagamento; 
	} 

	public void setDataPrevisaoPagamento(Date dataPrevisaoPagamento) { 
		this.dataPrevisaoPagamento = dataPrevisaoPagamento; 
	} 

	public String getLocalEntrega() { 
		return this.localEntrega; 
	} 

	public void setLocalEntrega(String localEntrega) { 
		this.localEntrega = localEntrega; 
	} 

	public String getLocalCobranca() { 
		return this.localCobranca; 
	} 

	public void setLocalCobranca(String localCobranca) { 
		this.localCobranca = localCobranca; 
	} 

	public String getContato() { 
		return this.contato; 
	} 

	public void setContato(String contato) { 
		this.contato = contato; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public String getTipoFrete() { 
		return this.tipoFrete; 
	} 

	public void setTipoFrete(String tipoFrete) { 
		this.tipoFrete = tipoFrete; 
	} 

	public String getFormaPagamento() { 
		return this.formaPagamento; 
	} 

	public void setFormaPagamento(String formaPagamento) { 
		this.formaPagamento = formaPagamento; 
	} 

	public BigDecimal getBaseCalculoIcms() { 
		return this.baseCalculoIcms; 
	} 

	public void setBaseCalculoIcms(BigDecimal baseCalculoIcms) { 
		this.baseCalculoIcms = baseCalculoIcms; 
	} 

	public BigDecimal getValorIcms() { 
		return this.valorIcms; 
	} 

	public void setValorIcms(BigDecimal valorIcms) { 
		this.valorIcms = valorIcms; 
	} 

	public BigDecimal getBaseCalculoIcmsSt() { 
		return this.baseCalculoIcmsSt; 
	} 

	public void setBaseCalculoIcmsSt(BigDecimal baseCalculoIcmsSt) { 
		this.baseCalculoIcmsSt = baseCalculoIcmsSt; 
	} 

	public BigDecimal getValorIcmsSt() { 
		return this.valorIcmsSt; 
	} 

	public void setValorIcmsSt(BigDecimal valorIcmsSt) { 
		this.valorIcmsSt = valorIcmsSt; 
	} 

	public BigDecimal getValorTotalProdutos() { 
		return this.valorTotalProdutos; 
	} 

	public void setValorTotalProdutos(BigDecimal valorTotalProdutos) { 
		this.valorTotalProdutos = valorTotalProdutos; 
	} 

	public BigDecimal getValorFrete() { 
		return this.valorFrete; 
	} 

	public void setValorFrete(BigDecimal valorFrete) { 
		this.valorFrete = valorFrete; 
	} 

	public BigDecimal getValorSeguro() { 
		return this.valorSeguro; 
	} 

	public void setValorSeguro(BigDecimal valorSeguro) { 
		this.valorSeguro = valorSeguro; 
	} 

	public BigDecimal getValorOutrasDespesas() { 
		return this.valorOutrasDespesas; 
	} 

	public void setValorOutrasDespesas(BigDecimal valorOutrasDespesas) { 
		this.valorOutrasDespesas = valorOutrasDespesas; 
	} 

	public BigDecimal getValorIpi() { 
		return this.valorIpi; 
	} 

	public void setValorIpi(BigDecimal valorIpi) { 
		this.valorIpi = valorIpi; 
	} 

	public BigDecimal getValorTotalNf() { 
		return this.valorTotalNf; 
	} 

	public void setValorTotalNf(BigDecimal valorTotalNf) { 
		this.valorTotalNf = valorTotalNf; 
	} 

	public Integer getQuantidadeParcelas() { 
		return this.quantidadeParcelas; 
	} 

	public void setQuantidadeParcelas(Integer quantidadeParcelas) { 
		this.quantidadeParcelas = quantidadeParcelas; 
	} 

	public String getDiaPrimeiroVencimento() { 
		return this.diaPrimeiroVencimento; 
	} 

	public void setDiaPrimeiroVencimento(String diaPrimeiroVencimento) { 
		this.diaPrimeiroVencimento = diaPrimeiroVencimento; 
	} 

	public Integer getIntervaloEntreParcelas() { 
		return this.intervaloEntreParcelas; 
	} 

	public void setIntervaloEntreParcelas(Integer intervaloEntreParcelas) { 
		this.intervaloEntreParcelas = intervaloEntreParcelas; 
	} 

	public String getDiaFixoParcela() { 
		return this.diaFixoParcela; 
	} 

	public void setDiaFixoParcela(String diaFixoParcela) { 
		this.diaFixoParcela = diaFixoParcela; 
	} 

	public Set<CompraPedidoDetalheModel> getCompraPedidoDetalheModelList() { 
	return this.compraPedidoDetalheModelList; 
	} 

	public void setCompraPedidoDetalheModelList(Set<CompraPedidoDetalheModel> compraPedidoDetalheModelList) { 
	this.compraPedidoDetalheModelList = compraPedidoDetalheModelList; 
		for (CompraPedidoDetalheModel compraPedidoDetalheModel : compraPedidoDetalheModelList) { 
			compraPedidoDetalheModel.setCompraPedidoModel(this); 
		}
	} 

	public CompraTipoPedidoModel getCompraTipoPedidoModel() { 
	return this.compraTipoPedidoModel; 
	} 

	public void setCompraTipoPedidoModel(CompraTipoPedidoModel compraTipoPedidoModel) { 
	this.compraTipoPedidoModel = compraTipoPedidoModel; 
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public ViewPessoaFornecedorModel getViewPessoaFornecedorModel() { 
	return this.viewPessoaFornecedorModel; 
	} 

	public void setViewPessoaFornecedorModel(ViewPessoaFornecedorModel viewPessoaFornecedorModel) { 
	this.viewPessoaFornecedorModel = viewPessoaFornecedorModel; 
	} 

		
}