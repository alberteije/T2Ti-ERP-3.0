package com.t2ti.compras.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.compras.util.Filter;
import com.t2ti.compras.exception.GenericException;
import com.t2ti.compras.model.CompraRequisicaoModel;
import com.t2ti.compras.repository.CompraRequisicaoRepository;

@Service
public class CompraRequisicaoService {

	@Autowired
	private CompraRequisicaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CompraRequisicaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CompraRequisicaoModel> getList(Filter filter) {
		String sql = "select * from compra_requisicao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CompraRequisicaoModel.class);
		return query.getResultList();
	}

	public CompraRequisicaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CompraRequisicaoModel save(CompraRequisicaoModel obj) {
		CompraRequisicaoModel compraRequisicaoModel = repository.save(obj);
		return compraRequisicaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CompraRequisicaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CompraRequisicao] - Exception: " + e.getMessage());
		}
	}

}