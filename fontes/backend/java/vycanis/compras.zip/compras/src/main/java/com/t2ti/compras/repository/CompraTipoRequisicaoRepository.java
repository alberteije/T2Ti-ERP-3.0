package com.t2ti.compras.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.compras.model.CompraTipoRequisicaoModel;

public interface CompraTipoRequisicaoRepository extends JpaRepository<CompraTipoRequisicaoModel, Integer> {}