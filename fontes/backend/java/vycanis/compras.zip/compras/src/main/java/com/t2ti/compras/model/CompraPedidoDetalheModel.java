package com.t2ti.compras.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="compra_pedido_detalhe")
@NamedQuery(name="CompraPedidoDetalheModel.findAll", query="SELECT t FROM CompraPedidoDetalheModel t")
public class CompraPedidoDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CompraPedidoDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private BigDecimal quantidade;

	@Column(name="valor_unitario")
	private BigDecimal valorUnitario;

	@Column(name="valor_subtotal")
	private BigDecimal valorSubtotal;

	@Column(name="taxa_desconto")
	private BigDecimal taxaDesconto;

	@Column(name="valor_desconto")
	private BigDecimal valorDesconto;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="cst")
	private String cst;

	@Column(name="csosn")
	private String csosn;

	@Column(name="cfop")
	private Integer cfop;

	@Column(name="base_calculo_icms")
	private BigDecimal baseCalculoIcms;

	@Column(name="valor_icms")
	private BigDecimal valorIcms;

	@Column(name="valor_ipi")
	private BigDecimal valorIpi;

	@Column(name="aliquota_icms")
	private BigDecimal aliquotaIcms;

	@Column(name="aliquota_ipi")
	private BigDecimal aliquotaIpi;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_compra_pedido")
	private CompraPedidoModel compraPedidoModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(BigDecimal quantidade) { 
		this.quantidade = quantidade; 
	} 

	public BigDecimal getValorUnitario() { 
		return this.valorUnitario; 
	} 

	public void setValorUnitario(BigDecimal valorUnitario) { 
		this.valorUnitario = valorUnitario; 
	} 

	public BigDecimal getValorSubtotal() { 
		return this.valorSubtotal; 
	} 

	public void setValorSubtotal(BigDecimal valorSubtotal) { 
		this.valorSubtotal = valorSubtotal; 
	} 

	public BigDecimal getTaxaDesconto() { 
		return this.taxaDesconto; 
	} 

	public void setTaxaDesconto(BigDecimal taxaDesconto) { 
		this.taxaDesconto = taxaDesconto; 
	} 

	public BigDecimal getValorDesconto() { 
		return this.valorDesconto; 
	} 

	public void setValorDesconto(BigDecimal valorDesconto) { 
		this.valorDesconto = valorDesconto; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public String getCst() { 
		return this.cst; 
	} 

	public void setCst(String cst) { 
		this.cst = cst; 
	} 

	public String getCsosn() { 
		return this.csosn; 
	} 

	public void setCsosn(String csosn) { 
		this.csosn = csosn; 
	} 

	public Integer getCfop() { 
		return this.cfop; 
	} 

	public void setCfop(Integer cfop) { 
		this.cfop = cfop; 
	} 

	public BigDecimal getBaseCalculoIcms() { 
		return this.baseCalculoIcms; 
	} 

	public void setBaseCalculoIcms(BigDecimal baseCalculoIcms) { 
		this.baseCalculoIcms = baseCalculoIcms; 
	} 

	public BigDecimal getValorIcms() { 
		return this.valorIcms; 
	} 

	public void setValorIcms(BigDecimal valorIcms) { 
		this.valorIcms = valorIcms; 
	} 

	public BigDecimal getValorIpi() { 
		return this.valorIpi; 
	} 

	public void setValorIpi(BigDecimal valorIpi) { 
		this.valorIpi = valorIpi; 
	} 

	public BigDecimal getAliquotaIcms() { 
		return this.aliquotaIcms; 
	} 

	public void setAliquotaIcms(BigDecimal aliquotaIcms) { 
		this.aliquotaIcms = aliquotaIcms; 
	} 

	public BigDecimal getAliquotaIpi() { 
		return this.aliquotaIpi; 
	} 

	public void setAliquotaIpi(BigDecimal aliquotaIpi) { 
		this.aliquotaIpi = aliquotaIpi; 
	} 

	public CompraPedidoModel getCompraPedidoModel() { 
	return this.compraPedidoModel; 
	} 

	public void setCompraPedidoModel(CompraPedidoModel compraPedidoModel) { 
	this.compraPedidoModel = compraPedidoModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}