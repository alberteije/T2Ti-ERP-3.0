package com.t2ti.compras.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="compra_requisicao")
@NamedQuery(name="CompraRequisicaoModel.findAll", query="SELECT t FROM CompraRequisicaoModel t")
public class CompraRequisicaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CompraRequisicaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Temporal(TemporalType.DATE)
@Column(name="data_requisicao")
	private Date dataRequisicao;

	@Column(name="observacao")
	private String observacao;

	@OneToMany(mappedBy = "compraRequisicaoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CompraRequisicaoDetalheModel> compraRequisicaoDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 

	@ManyToOne 
	@JoinColumn(name="id_compra_tipo_requisicao")
	private CompraTipoRequisicaoModel compraTipoRequisicaoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Date getDataRequisicao() { 
		return this.dataRequisicao; 
	} 

	public void setDataRequisicao(Date dataRequisicao) { 
		this.dataRequisicao = dataRequisicao; 
	} 

	public String getObservacao() { 
		return this.observacao; 
	} 

	public void setObservacao(String observacao) { 
		this.observacao = observacao; 
	} 

	public Set<CompraRequisicaoDetalheModel> getCompraRequisicaoDetalheModelList() { 
	return this.compraRequisicaoDetalheModelList; 
	} 

	public void setCompraRequisicaoDetalheModelList(Set<CompraRequisicaoDetalheModel> compraRequisicaoDetalheModelList) { 
	this.compraRequisicaoDetalheModelList = compraRequisicaoDetalheModelList; 
		for (CompraRequisicaoDetalheModel compraRequisicaoDetalheModel : compraRequisicaoDetalheModelList) { 
			compraRequisicaoDetalheModel.setCompraRequisicaoModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

	public CompraTipoRequisicaoModel getCompraTipoRequisicaoModel() { 
	return this.compraTipoRequisicaoModel; 
	} 

	public void setCompraTipoRequisicaoModel(CompraTipoRequisicaoModel compraTipoRequisicaoModel) { 
	this.compraTipoRequisicaoModel = compraTipoRequisicaoModel; 
	} 

		
}