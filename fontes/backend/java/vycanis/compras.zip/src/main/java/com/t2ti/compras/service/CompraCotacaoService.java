package com.t2ti.compras.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.compras.util.Filter;
import com.t2ti.compras.exception.GenericException;
import com.t2ti.compras.model.CompraCotacaoModel;
import com.t2ti.compras.repository.CompraCotacaoRepository;

@Service
public class CompraCotacaoService {

	@Autowired
	private CompraCotacaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CompraCotacaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CompraCotacaoModel> getList(Filter filter) {
		String sql = "select * from compra_cotacao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CompraCotacaoModel.class);
		return query.getResultList();
	}

	public CompraCotacaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CompraCotacaoModel save(CompraCotacaoModel obj) {
		CompraCotacaoModel compraCotacaoModel = repository.save(obj);
		return compraCotacaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CompraCotacaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CompraCotacao] - Exception: " + e.getMessage());
		}
	}

}