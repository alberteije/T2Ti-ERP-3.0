package com.t2ti.compras.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="compra_cotacao")
@NamedQuery(name="CompraCotacaoModel.findAll", query="SELECT t FROM CompraCotacaoModel t")
public class CompraCotacaoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CompraCotacaoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_cotacao")
	private Date dataCotacao;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "compraCotacaoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CompraFornecedorCotacaoModel> compraFornecedorCotacaoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_compra_requisicao")
	private CompraRequisicaoModel compraRequisicaoModel; 

	@OneToMany(mappedBy = "compraCotacaoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CompraCotacaoDetalheModel> compraCotacaoDetalheModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataCotacao() { 
		return this.dataCotacao; 
	} 

	public void setDataCotacao(Date dataCotacao) { 
		this.dataCotacao = dataCotacao; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<CompraFornecedorCotacaoModel> getCompraFornecedorCotacaoModelList() { 
	return this.compraFornecedorCotacaoModelList; 
	} 

	public void setCompraFornecedorCotacaoModelList(Set<CompraFornecedorCotacaoModel> compraFornecedorCotacaoModelList) { 
	this.compraFornecedorCotacaoModelList = compraFornecedorCotacaoModelList; 
		for (CompraFornecedorCotacaoModel compraFornecedorCotacaoModel : compraFornecedorCotacaoModelList) { 
			compraFornecedorCotacaoModel.setCompraCotacaoModel(this); 
		}
	} 

	public CompraRequisicaoModel getCompraRequisicaoModel() { 
	return this.compraRequisicaoModel; 
	} 

	public void setCompraRequisicaoModel(CompraRequisicaoModel compraRequisicaoModel) { 
	this.compraRequisicaoModel = compraRequisicaoModel; 
	} 

	public Set<CompraCotacaoDetalheModel> getCompraCotacaoDetalheModelList() { 
	return this.compraCotacaoDetalheModelList; 
	} 

	public void setCompraCotacaoDetalheModelList(Set<CompraCotacaoDetalheModel> compraCotacaoDetalheModelList) { 
	this.compraCotacaoDetalheModelList = compraCotacaoDetalheModelList; 
		for (CompraCotacaoDetalheModel compraCotacaoDetalheModel : compraCotacaoDetalheModelList) { 
			compraCotacaoDetalheModel.setCompraCotacaoModel(this); 
		}
	} 

		
}