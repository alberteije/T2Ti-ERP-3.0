package com.t2ti.compras.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.compras.model.ViewPessoaUsuarioModel;

public interface ViewPessoaUsuarioRepository extends JpaRepository<ViewPessoaUsuarioModel, Integer> {}