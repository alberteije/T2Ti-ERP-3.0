package com.t2ti.compras.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.compras.util.Filter;
import com.t2ti.compras.exception.GenericException;
import com.t2ti.compras.model.CompraTipoRequisicaoModel;
import com.t2ti.compras.repository.CompraTipoRequisicaoRepository;

@Service
public class CompraTipoRequisicaoService {

	@Autowired
	private CompraTipoRequisicaoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<CompraTipoRequisicaoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<CompraTipoRequisicaoModel> getList(Filter filter) {
		String sql = "select * from compra_tipo_requisicao where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, CompraTipoRequisicaoModel.class);
		return query.getResultList();
	}

	public CompraTipoRequisicaoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public CompraTipoRequisicaoModel save(CompraTipoRequisicaoModel obj) {
		CompraTipoRequisicaoModel compraTipoRequisicaoModel = repository.save(obj);
		return compraTipoRequisicaoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		CompraTipoRequisicaoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete CompraTipoRequisicao] - Exception: " + e.getMessage());
		}
	}

}