package com.t2ti.compras.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.compras.model.CompraCotacaoModel;

public interface CompraCotacaoRepository extends JpaRepository<CompraCotacaoModel, Integer> {}