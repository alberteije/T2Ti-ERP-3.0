package com.t2ti.compras.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="produto_unidade")
@NamedQuery(name="ProdutoUnidadeModel.findAll", query="SELECT t FROM ProdutoUnidadeModel t")
public class ProdutoUnidadeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProdutoUnidadeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="sigla")
	private String sigla;

	@Column(name="descricao")
	private String descricao;

	@Column(name="pode_fracionar")
	private String podeFracionar;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getSigla() { 
		return this.sigla; 
	} 

	public void setSigla(String sigla) { 
		this.sigla = sigla; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getPodeFracionar() { 
		return this.podeFracionar; 
	} 

	public void setPodeFracionar(String podeFracionar) { 
		this.podeFracionar = podeFracionar; 
	} 

		
}