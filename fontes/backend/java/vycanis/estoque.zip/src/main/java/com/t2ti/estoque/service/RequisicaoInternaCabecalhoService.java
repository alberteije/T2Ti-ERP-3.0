package com.t2ti.estoque.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.model.RequisicaoInternaCabecalhoModel;
import com.t2ti.estoque.repository.RequisicaoInternaCabecalhoRepository;

@Service
public class RequisicaoInternaCabecalhoService {

	@Autowired
	private RequisicaoInternaCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<RequisicaoInternaCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<RequisicaoInternaCabecalhoModel> getList(Filter filter) {
		String sql = "select * from requisicao_interna_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, RequisicaoInternaCabecalhoModel.class);
		return query.getResultList();
	}

	public RequisicaoInternaCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public RequisicaoInternaCabecalhoModel save(RequisicaoInternaCabecalhoModel obj) {
		RequisicaoInternaCabecalhoModel requisicaoInternaCabecalhoModel = repository.save(obj);
		return requisicaoInternaCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		RequisicaoInternaCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete RequisicaoInternaCabecalho] - Exception: " + e.getMessage());
		}
	}

}