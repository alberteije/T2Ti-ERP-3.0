package com.t2ti.estoque.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="estoque_reajuste_cabecalho")
@NamedQuery(name="EstoqueReajusteCabecalhoModel.findAll", query="SELECT t FROM EstoqueReajusteCabecalhoModel t")
public class EstoqueReajusteCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EstoqueReajusteCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_reajuste")
	private Date dataReajuste;

	@Column(name="taxa")
	private BigDecimal taxa;

	@Column(name="tipo_reajuste")
	private String tipoReajuste;

	@Column(name="justificativa")
	private String justificativa;

	@OneToMany(mappedBy = "estoqueReajusteCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<EstoqueReajusteDetalheModel> estoqueReajusteDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataReajuste() { 
		return this.dataReajuste; 
	} 

	public void setDataReajuste(Date dataReajuste) { 
		this.dataReajuste = dataReajuste; 
	} 

	public BigDecimal getTaxa() { 
		return this.taxa; 
	} 

	public void setTaxa(BigDecimal taxa) { 
		this.taxa = taxa; 
	} 

	public String getTipoReajuste() { 
		return this.tipoReajuste; 
	} 

	public void setTipoReajuste(String tipoReajuste) { 
		this.tipoReajuste = tipoReajuste; 
	} 

	public String getJustificativa() { 
		return this.justificativa; 
	} 

	public void setJustificativa(String justificativa) { 
		this.justificativa = justificativa; 
	} 

	public Set<EstoqueReajusteDetalheModel> getEstoqueReajusteDetalheModelList() { 
	return this.estoqueReajusteDetalheModelList; 
	} 

	public void setEstoqueReajusteDetalheModelList(Set<EstoqueReajusteDetalheModel> estoqueReajusteDetalheModelList) { 
	this.estoqueReajusteDetalheModelList = estoqueReajusteDetalheModelList; 
		for (EstoqueReajusteDetalheModel estoqueReajusteDetalheModel : estoqueReajusteDetalheModelList) { 
			estoqueReajusteDetalheModel.setEstoqueReajusteCabecalhoModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}