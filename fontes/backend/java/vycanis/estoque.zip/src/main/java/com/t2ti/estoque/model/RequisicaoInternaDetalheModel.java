package com.t2ti.estoque.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="requisicao_interna_detalhe")
@NamedQuery(name="RequisicaoInternaDetalheModel.findAll", query="SELECT t FROM RequisicaoInternaDetalheModel t")
public class RequisicaoInternaDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public RequisicaoInternaDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private BigDecimal quantidade;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_requisicao_interna_cabecalho")
	private RequisicaoInternaCabecalhoModel requisicaoInternaCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(BigDecimal quantidade) { 
		this.quantidade = quantidade; 
	} 

	public RequisicaoInternaCabecalhoModel getRequisicaoInternaCabecalhoModel() { 
	return this.requisicaoInternaCabecalhoModel; 
	} 

	public void setRequisicaoInternaCabecalhoModel(RequisicaoInternaCabecalhoModel requisicaoInternaCabecalhoModel) { 
	this.requisicaoInternaCabecalhoModel = requisicaoInternaCabecalhoModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}