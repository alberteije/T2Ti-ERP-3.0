package com.t2ti.estoque.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.model.EstoqueReajusteCabecalhoModel;
import com.t2ti.estoque.repository.EstoqueReajusteCabecalhoRepository;

@Service
public class EstoqueReajusteCabecalhoService {

	@Autowired
	private EstoqueReajusteCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EstoqueReajusteCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EstoqueReajusteCabecalhoModel> getList(Filter filter) {
		String sql = "select * from estoque_reajuste_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EstoqueReajusteCabecalhoModel.class);
		return query.getResultList();
	}

	public EstoqueReajusteCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EstoqueReajusteCabecalhoModel save(EstoqueReajusteCabecalhoModel obj) {
		EstoqueReajusteCabecalhoModel estoqueReajusteCabecalhoModel = repository.save(obj);
		return estoqueReajusteCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EstoqueReajusteCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EstoqueReajusteCabecalho] - Exception: " + e.getMessage());
		}
	}

}