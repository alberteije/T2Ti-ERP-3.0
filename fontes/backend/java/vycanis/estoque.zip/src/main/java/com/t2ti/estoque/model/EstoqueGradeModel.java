package com.t2ti.estoque.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="estoque_grade")
@NamedQuery(name="EstoqueGradeModel.findAll", query="SELECT t FROM EstoqueGradeModel t")
public class EstoqueGradeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EstoqueGradeModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="quantidade")
	private BigDecimal quantidade;

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 

	@ManyToOne 
	@JoinColumn(name="id_estoque_cor")
	private EstoqueCorModel estoqueCorModel; 

	@ManyToOne 
	@JoinColumn(name="id_estoque_tamanho")
	private EstoqueTamanhoModel estoqueTamanhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_estoque_sabor")
	private EstoqueSaborModel estoqueSaborModel; 

	@ManyToOne 
	@JoinColumn(name="id_estoque_marca")
	private EstoqueMarcaModel estoqueMarcaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public BigDecimal getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(BigDecimal quantidade) { 
		this.quantidade = quantidade; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

	public EstoqueCorModel getEstoqueCorModel() { 
	return this.estoqueCorModel; 
	} 

	public void setEstoqueCorModel(EstoqueCorModel estoqueCorModel) { 
	this.estoqueCorModel = estoqueCorModel; 
	} 

	public EstoqueTamanhoModel getEstoqueTamanhoModel() { 
	return this.estoqueTamanhoModel; 
	} 

	public void setEstoqueTamanhoModel(EstoqueTamanhoModel estoqueTamanhoModel) { 
	this.estoqueTamanhoModel = estoqueTamanhoModel; 
	} 

	public EstoqueSaborModel getEstoqueSaborModel() { 
	return this.estoqueSaborModel; 
	} 

	public void setEstoqueSaborModel(EstoqueSaborModel estoqueSaborModel) { 
	this.estoqueSaborModel = estoqueSaborModel; 
	} 

	public EstoqueMarcaModel getEstoqueMarcaModel() { 
	return this.estoqueMarcaModel; 
	} 

	public void setEstoqueMarcaModel(EstoqueMarcaModel estoqueMarcaModel) { 
	this.estoqueMarcaModel = estoqueMarcaModel; 
	} 

		
}