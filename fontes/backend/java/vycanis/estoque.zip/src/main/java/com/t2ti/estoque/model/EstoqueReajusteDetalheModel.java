package com.t2ti.estoque.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="estoque_reajuste_detalhe")
@NamedQuery(name="EstoqueReajusteDetalheModel.findAll", query="SELECT t FROM EstoqueReajusteDetalheModel t")
public class EstoqueReajusteDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EstoqueReajusteDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor_original")
	private BigDecimal valorOriginal;

	@Column(name="valor_reajuste")
	private BigDecimal valorReajuste;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_estoque_reajuste_cabecalho")
	private EstoqueReajusteCabecalhoModel estoqueReajusteCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValorOriginal() { 
		return this.valorOriginal; 
	} 

	public void setValorOriginal(BigDecimal valorOriginal) { 
		this.valorOriginal = valorOriginal; 
	} 

	public BigDecimal getValorReajuste() { 
		return this.valorReajuste; 
	} 

	public void setValorReajuste(BigDecimal valorReajuste) { 
		this.valorReajuste = valorReajuste; 
	} 

	public EstoqueReajusteCabecalhoModel getEstoqueReajusteCabecalhoModel() { 
	return this.estoqueReajusteCabecalhoModel; 
	} 

	public void setEstoqueReajusteCabecalhoModel(EstoqueReajusteCabecalhoModel estoqueReajusteCabecalhoModel) { 
	this.estoqueReajusteCabecalhoModel = estoqueReajusteCabecalhoModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}