package com.t2ti.estoque.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.model.EstoqueSaborModel;
import com.t2ti.estoque.repository.EstoqueSaborRepository;

@Service
public class EstoqueSaborService {

	@Autowired
	private EstoqueSaborRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EstoqueSaborModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EstoqueSaborModel> getList(Filter filter) {
		String sql = "select * from estoque_sabor where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EstoqueSaborModel.class);
		return query.getResultList();
	}

	public EstoqueSaborModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EstoqueSaborModel save(EstoqueSaborModel obj) {
		EstoqueSaborModel estoqueSaborModel = repository.save(obj);
		return estoqueSaborModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EstoqueSaborModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EstoqueSabor] - Exception: " + e.getMessage());
		}
	}

}