package com.t2ti.estoque.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.exception.ResourseNotFoundException;
import com.t2ti.estoque.exception.BadRequestException;
import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.model.EstoqueSaborModel;
import com.t2ti.estoque.service.EstoqueSaborService;

@RestController
@RequestMapping(value = "/estoque-sabor", produces = "application/json;charset=UTF-8")
public class EstoqueSaborController {

	@Autowired
	private EstoqueSaborService service;
	
	@GetMapping({ "", "/" })
	public List<EstoqueSaborModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [EstoqueSabor] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public EstoqueSaborModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found EstoqueSabor].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found EstoqueSabor] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public EstoqueSaborModel insert(@RequestBody EstoqueSaborModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert EstoqueSabor] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public EstoqueSaborModel update(@RequestBody EstoqueSaborModel objJson) {	
		try {			
			EstoqueSaborModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update EstoqueSabor].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update EstoqueSabor] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EstoqueSabor] - Exception: " + e.getMessage());
		}
	}
	
}