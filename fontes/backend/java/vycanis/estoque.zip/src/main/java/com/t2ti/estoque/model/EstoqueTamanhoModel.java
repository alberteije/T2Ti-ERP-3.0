package com.t2ti.estoque.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name="estoque_tamanho")
@NamedQuery(name="EstoqueTamanhoModel.findAll", query="SELECT t FROM EstoqueTamanhoModel t")
public class EstoqueTamanhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EstoqueTamanhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="nome")
	private String nome;

	@Column(name="altura")
	private BigDecimal altura;

	@Column(name="comprimento")
	private BigDecimal comprimento;

	@Column(name="largura")
	private BigDecimal largura;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public BigDecimal getAltura() { 
		return this.altura; 
	} 

	public void setAltura(BigDecimal altura) { 
		this.altura = altura; 
	} 

	public BigDecimal getComprimento() { 
		return this.comprimento; 
	} 

	public void setComprimento(BigDecimal comprimento) { 
		this.comprimento = comprimento; 
	} 

	public BigDecimal getLargura() { 
		return this.largura; 
	} 

	public void setLargura(BigDecimal largura) { 
		this.largura = largura; 
	} 

		
}