package com.t2ti.estoque.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.estoque.model.ProdutoMarcaModel;

public interface ProdutoMarcaRepository extends JpaRepository<ProdutoMarcaModel, Integer> {}