package com.t2ti.estoque.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.model.ProdutoUnidadeModel;
import com.t2ti.estoque.repository.ProdutoUnidadeRepository;

@Service
public class ProdutoUnidadeService {

	@Autowired
	private ProdutoUnidadeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ProdutoUnidadeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ProdutoUnidadeModel> getList(Filter filter) {
		String sql = "select * from produto_unidade where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ProdutoUnidadeModel.class);
		return query.getResultList();
	}

	public ProdutoUnidadeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ProdutoUnidadeModel save(ProdutoUnidadeModel obj) {
		ProdutoUnidadeModel produtoUnidadeModel = repository.save(obj);
		return produtoUnidadeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ProdutoUnidadeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ProdutoUnidade] - Exception: " + e.getMessage());
		}
	}

}