package com.t2ti.estoque.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="produto_subgrupo")
@NamedQuery(name="ProdutoSubgrupoModel.findAll", query="SELECT t FROM ProdutoSubgrupoModel t")
public class ProdutoSubgrupoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProdutoSubgrupoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@ManyToOne 
	@JoinColumn(name="id_produto_grupo")
	private ProdutoGrupoModel produtoGrupoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public ProdutoGrupoModel getProdutoGrupoModel() { 
	return this.produtoGrupoModel; 
	} 

	public void setProdutoGrupoModel(ProdutoGrupoModel produtoGrupoModel) { 
	this.produtoGrupoModel = produtoGrupoModel; 
	} 

		
}