package com.t2ti.estoque.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.model.EstoqueTamanhoModel;
import com.t2ti.estoque.repository.EstoqueTamanhoRepository;

@Service
public class EstoqueTamanhoService {

	@Autowired
	private EstoqueTamanhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EstoqueTamanhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EstoqueTamanhoModel> getList(Filter filter) {
		String sql = "select * from estoque_tamanho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EstoqueTamanhoModel.class);
		return query.getResultList();
	}

	public EstoqueTamanhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EstoqueTamanhoModel save(EstoqueTamanhoModel obj) {
		EstoqueTamanhoModel estoqueTamanhoModel = repository.save(obj);
		return estoqueTamanhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EstoqueTamanhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EstoqueTamanho] - Exception: " + e.getMessage());
		}
	}

}