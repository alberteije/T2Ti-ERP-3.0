/*******************************************************************************
Title: T2Ti ERP 3.0
Description: Classe responsável por interceptar todas as requisições realizadas 
para o servidor que necessitam de autenticação.
                                                                                
The MIT License                                                                 
                                                                                
Copyright: Copyright (C) 2020 T2Ti.COM                                          
                                                                                
Permission is hereby granted, free of charge, to any person                     
obtaining a copy of this software and associated documentation                  
files (the "Software"), to deal in the Software without                         
restriction, including without limitation the rights to use,                    
copy, modify, merge, publish, distribute, sublicense, and/or sell               
copies of the Software, and to permit persons to whom the                       
Software is furnished to do so, subject to the following                        
conditions:                                                                     
                                                                                
The above copyright notice and this permission notice shall be                  
included in all copies or substantial portions of the Software.                 
                                                                                
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,                 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES                 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND                        
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT                     
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,                    
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING                    
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR                   
OTHER DEALINGS IN THE SOFTWARE.                                                 
                                                                                
       The author may be contacted at:                                          
           t2ti.com@gmail.com                                                   
                                                                                
@author Albert Eije (alberteije@gmail.com)                    
@version 1.0.0
*******************************************************************************/
package com.t2ti.estoque.jwt;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.t2ti.estoque.config.TenantContext;
import com.t2ti.estoque.model.AuditoriaModel;
import com.t2ti.estoque.service.AuditoriaService;
import com.t2ti.estoque.service.ViewPessoaUsuarioService;
import com.t2ti.estoque.util.CachedBodyHttpServletRequest;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/*
 * Classe responsável por interceptar todas as requisições realizadas para o servidor
 * 
 * */
public class JWTFilter extends OncePerRequestFilter {

    @Autowired
    ViewPessoaUsuarioService viewPessoaUsuarioService;
	
    @Autowired
    private AuditoriaService auditoriaService;
    
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
		CachedBodyHttpServletRequest cachedRequest = new CachedBodyHttpServletRequest(request);
		
		try {
	        String cnpj = cachedRequest.getHeader("cnpj");

	        if (cnpj != null) {
	            TenantContext.setCurrentTenant(cnpj);
	        } else {
	        	TenantContext.setCurrentTenant("fenix");
	        }
	        
			String token = null;
			Authentication authentication = null;
			
			String headerAuth = request.getHeader("Authorization");
		    if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) {
		    	token = headerAuth.substring(7);
		    }
		    			
			if (token != null) {
				// verifica se o token é válido
				String login = JWTManager.verificaToken(token);

                // auditoria
                AuditoriaModel auditoria = new AuditoriaModel();
                auditoria.setDataRegistro(new Date());
                auditoria.setHoraRegistro(new SimpleDateFormat("HH:mm:ss").format(new Date()));
                auditoria.setJanelaController(cachedRequest.getRequestURI());
                auditoria.setAcao(cachedRequest.getMethod());

                String requestBody = new String(cachedRequest.getBody());
                auditoria.setConteudo(!requestBody.isEmpty() ? requestBody : cachedRequest.getQueryString() != null ? cachedRequest.getQueryString() : "");
                
                auditoria.setTokenJwt(token);
                auditoriaService.save(auditoria);
				
				// define os dados do usuário autenticado
				authentication = new UsernamePasswordAuthenticationToken(login, null, new ArrayList<>());
			} 
			
			SecurityContextHolder.getContext().setAuthentication(authentication);
			
		    filterChain.doFilter(cachedRequest, response);
		} catch (Exception e) {
			response.sendError(jakarta.servlet.http.HttpServletResponse.SC_UNAUTHORIZED, e.getMessage());
		} finally {
		    TenantContext.clear();
		}
	}

}
