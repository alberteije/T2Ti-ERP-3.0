package com.t2ti.estoque.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.model.EstoqueCorModel;
import com.t2ti.estoque.repository.EstoqueCorRepository;

@Service
public class EstoqueCorService {

	@Autowired
	private EstoqueCorRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EstoqueCorModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EstoqueCorModel> getList(Filter filter) {
		String sql = "select * from estoque_cor where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EstoqueCorModel.class);
		return query.getResultList();
	}

	public EstoqueCorModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EstoqueCorModel save(EstoqueCorModel obj) {
		EstoqueCorModel estoqueCorModel = repository.save(obj);
		return estoqueCorModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EstoqueCorModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EstoqueCor] - Exception: " + e.getMessage());
		}
	}

}