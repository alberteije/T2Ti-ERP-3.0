package com.t2ti.estoque.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="requisicao_interna_cabecalho")
@NamedQuery(name="RequisicaoInternaCabecalhoModel.findAll", query="SELECT t FROM RequisicaoInternaCabecalhoModel t")
public class RequisicaoInternaCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public RequisicaoInternaCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_requisicao")
	private Date dataRequisicao;

	@Column(name="situacao")
	private String situacao;

	@OneToMany(mappedBy = "requisicaoInternaCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<RequisicaoInternaDetalheModel> requisicaoInternaDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_colaborador")
	private ViewPessoaColaboradorModel viewPessoaColaboradorModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataRequisicao() { 
		return this.dataRequisicao; 
	} 

	public void setDataRequisicao(Date dataRequisicao) { 
		this.dataRequisicao = dataRequisicao; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public Set<RequisicaoInternaDetalheModel> getRequisicaoInternaDetalheModelList() { 
	return this.requisicaoInternaDetalheModelList; 
	} 

	public void setRequisicaoInternaDetalheModelList(Set<RequisicaoInternaDetalheModel> requisicaoInternaDetalheModelList) { 
	this.requisicaoInternaDetalheModelList = requisicaoInternaDetalheModelList; 
		for (RequisicaoInternaDetalheModel requisicaoInternaDetalheModel : requisicaoInternaDetalheModelList) { 
			requisicaoInternaDetalheModel.setRequisicaoInternaCabecalhoModel(this); 
		}
	} 

	public ViewPessoaColaboradorModel getViewPessoaColaboradorModel() { 
	return this.viewPessoaColaboradorModel; 
	} 

	public void setViewPessoaColaboradorModel(ViewPessoaColaboradorModel viewPessoaColaboradorModel) { 
	this.viewPessoaColaboradorModel = viewPessoaColaboradorModel; 
	} 

		
}