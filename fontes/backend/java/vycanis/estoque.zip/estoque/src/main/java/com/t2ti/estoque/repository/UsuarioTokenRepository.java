package com.t2ti.estoque.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.estoque.model.UsuarioTokenModel;

public interface UsuarioTokenRepository extends JpaRepository<UsuarioTokenModel, Integer> {}