package com.t2ti.estoque.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.estoque.util.Filter;
import com.t2ti.estoque.exception.GenericException;
import com.t2ti.estoque.model.EstoqueGradeModel;
import com.t2ti.estoque.repository.EstoqueGradeRepository;

@Service
public class EstoqueGradeService {

	@Autowired
	private EstoqueGradeRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EstoqueGradeModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EstoqueGradeModel> getList(Filter filter) {
		String sql = "select * from estoque_grade where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EstoqueGradeModel.class);
		return query.getResultList();
	}

	public EstoqueGradeModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EstoqueGradeModel save(EstoqueGradeModel obj) {
		EstoqueGradeModel estoqueGradeModel = repository.save(obj);
		return estoqueGradeModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EstoqueGradeModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EstoqueGrade] - Exception: " + e.getMessage());
		}
	}

}