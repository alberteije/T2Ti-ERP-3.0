package com.t2ti.gondolas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.gondolas.util.Filter;
import com.t2ti.gondolas.exception.GenericException;
import com.t2ti.gondolas.model.GondolaCaixaModel;
import com.t2ti.gondolas.repository.GondolaCaixaRepository;

@Service
public class GondolaCaixaService {

	@Autowired
	private GondolaCaixaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<GondolaCaixaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<GondolaCaixaModel> getList(Filter filter) {
		String sql = "select * from gondola_caixa where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, GondolaCaixaModel.class);
		return query.getResultList();
	}

	public GondolaCaixaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public GondolaCaixaModel save(GondolaCaixaModel obj) {
		GondolaCaixaModel gondolaCaixaModel = repository.save(obj);
		return gondolaCaixaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		GondolaCaixaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete GondolaCaixa] - Exception: " + e.getMessage());
		}
	}

}