package com.t2ti.gondolas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="gondola_armazenamento")
@NamedQuery(name="GondolaArmazenamentoModel.findAll", query="SELECT t FROM GondolaArmazenamentoModel t")
public class GondolaArmazenamentoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GondolaArmazenamentoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="quantidade")
	private Integer quantidade;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_gondola_caixa")
	private GondolaCaixaModel gondolaCaixaModel; 

	@ManyToOne 
	@JoinColumn(name="id_produto")
	private ProdutoModel produtoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getQuantidade() { 
		return this.quantidade; 
	} 

	public void setQuantidade(Integer quantidade) { 
		this.quantidade = quantidade; 
	} 

	public GondolaCaixaModel getGondolaCaixaModel() { 
	return this.gondolaCaixaModel; 
	} 

	public void setGondolaCaixaModel(GondolaCaixaModel gondolaCaixaModel) { 
	this.gondolaCaixaModel = gondolaCaixaModel; 
	} 

	public ProdutoModel getProdutoModel() { 
	return this.produtoModel; 
	} 

	public void setProdutoModel(ProdutoModel produtoModel) { 
	this.produtoModel = produtoModel; 
	} 

		
}