package com.t2ti.gondolas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.gondolas.util.Filter;
import com.t2ti.gondolas.exception.GenericException;
import com.t2ti.gondolas.model.GondolaRuaModel;
import com.t2ti.gondolas.repository.GondolaRuaRepository;

@Service
public class GondolaRuaService {

	@Autowired
	private GondolaRuaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<GondolaRuaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<GondolaRuaModel> getList(Filter filter) {
		String sql = "select * from gondola_rua where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, GondolaRuaModel.class);
		return query.getResultList();
	}

	public GondolaRuaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public GondolaRuaModel save(GondolaRuaModel obj) {
		GondolaRuaModel gondolaRuaModel = repository.save(obj);
		return gondolaRuaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		GondolaRuaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete GondolaRua] - Exception: " + e.getMessage());
		}
	}

}