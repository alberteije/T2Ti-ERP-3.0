package com.t2ti.gondolas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GondolasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GondolasApplication.class, args);
	}

}
