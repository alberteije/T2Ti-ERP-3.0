package com.t2ti.gondolas.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.gondolas.util.Filter;
import com.t2ti.gondolas.exception.GenericException;
import com.t2ti.gondolas.model.GondolaEstanteModel;
import com.t2ti.gondolas.repository.GondolaEstanteRepository;

@Service
public class GondolaEstanteService {

	@Autowired
	private GondolaEstanteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<GondolaEstanteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<GondolaEstanteModel> getList(Filter filter) {
		String sql = "select * from gondola_estante where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, GondolaEstanteModel.class);
		return query.getResultList();
	}

	public GondolaEstanteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public GondolaEstanteModel save(GondolaEstanteModel obj) {
		GondolaEstanteModel gondolaEstanteModel = repository.save(obj);
		return gondolaEstanteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		GondolaEstanteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete GondolaEstante] - Exception: " + e.getMessage());
		}
	}

}