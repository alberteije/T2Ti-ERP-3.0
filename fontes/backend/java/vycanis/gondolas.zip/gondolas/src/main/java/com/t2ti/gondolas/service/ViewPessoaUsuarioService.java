package com.t2ti.gondolas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.t2ti.gondolas.model.ViewPessoaUsuarioModel;
import com.t2ti.gondolas.repository.ViewPessoaUsuarioRepository;
import com.t2ti.gondolas.util.Filter;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Service
public class ViewPessoaUsuarioService {

	@Autowired
	private ViewPessoaUsuarioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ViewPessoaUsuarioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ViewPessoaUsuarioModel> getList(Filter filter) {
		String sql = "select * from view_pessoa_usuario where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewPessoaUsuarioModel.class);
		return query.getResultList();
	}

	public ViewPessoaUsuarioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ViewPessoaUsuarioModel getObjectFilter(Filter filter) {
		String sql = "select * from view_pessoa_usuario where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewPessoaUsuarioModel.class);
		if (query.getResultList().size() > 0) {
			return (ViewPessoaUsuarioModel) query.getResultList().get(0);
		} else {
			return null;
		}
	}

}