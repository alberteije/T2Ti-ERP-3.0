package com.t2ti.gondolas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="produto")
@NamedQuery(name="ProdutoModel.findAll", query="SELECT t FROM ProdutoModel t")
public class ProdutoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ProdutoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_tribut_icms_custom_cab")
	private Integer idTributIcmsCustomCab;

	@Column(name="id_tribut_grupo_tributario")
	private Integer idTributGrupoTributario;

	@Column(name="nome")
	private String nome;

	@Column(name="descricao")
	private String descricao;

	@Column(name="gtin")
	private String gtin;

	@Column(name="codigo_interno")
	private String codigoInterno;

	@Column(name="valor_compra")
	private BigDecimal valorCompra;

	@Column(name="valor_venda")
	private BigDecimal valorVenda;

	@Column(name="codigo_ncm")
	private String codigoNcm;

	@Column(name="estoque_minimo")
	private BigDecimal estoqueMinimo;

	@Column(name="estoque_maximo")
	private BigDecimal estoqueMaximo;

	@Column(name="quantidade_estoque")
	private BigDecimal quantidadeEstoque;

	@Temporal(TemporalType.DATE)
@Column(name="data_cadastro")
	private Date dataCadastro;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdTributIcmsCustomCab() { 
		return this.idTributIcmsCustomCab; 
	} 

	public void setIdTributIcmsCustomCab(Integer idTributIcmsCustomCab) { 
		this.idTributIcmsCustomCab = idTributIcmsCustomCab; 
	} 

	public Integer getIdTributGrupoTributario() { 
		return this.idTributGrupoTributario; 
	} 

	public void setIdTributGrupoTributario(Integer idTributGrupoTributario) { 
		this.idTributGrupoTributario = idTributGrupoTributario; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getGtin() { 
		return this.gtin; 
	} 

	public void setGtin(String gtin) { 
		this.gtin = gtin; 
	} 

	public String getCodigoInterno() { 
		return this.codigoInterno; 
	} 

	public void setCodigoInterno(String codigoInterno) { 
		this.codigoInterno = codigoInterno; 
	} 

	public BigDecimal getValorCompra() { 
		return this.valorCompra; 
	} 

	public void setValorCompra(BigDecimal valorCompra) { 
		this.valorCompra = valorCompra; 
	} 

	public BigDecimal getValorVenda() { 
		return this.valorVenda; 
	} 

	public void setValorVenda(BigDecimal valorVenda) { 
		this.valorVenda = valorVenda; 
	} 

	public String getCodigoNcm() { 
		return this.codigoNcm; 
	} 

	public void setCodigoNcm(String codigoNcm) { 
		this.codigoNcm = codigoNcm; 
	} 

	public BigDecimal getEstoqueMinimo() { 
		return this.estoqueMinimo; 
	} 

	public void setEstoqueMinimo(BigDecimal estoqueMinimo) { 
		this.estoqueMinimo = estoqueMinimo; 
	} 

	public BigDecimal getEstoqueMaximo() { 
		return this.estoqueMaximo; 
	} 

	public void setEstoqueMaximo(BigDecimal estoqueMaximo) { 
		this.estoqueMaximo = estoqueMaximo; 
	} 

	public BigDecimal getQuantidadeEstoque() { 
		return this.quantidadeEstoque; 
	} 

	public void setQuantidadeEstoque(BigDecimal quantidadeEstoque) { 
		this.quantidadeEstoque = quantidadeEstoque; 
	} 

	public Date getDataCadastro() { 
		return this.dataCadastro; 
	} 

	public void setDataCadastro(Date dataCadastro) { 
		this.dataCadastro = dataCadastro; 
	} 

		
}