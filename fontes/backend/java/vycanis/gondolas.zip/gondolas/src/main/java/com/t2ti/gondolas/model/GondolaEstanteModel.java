package com.t2ti.gondolas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="gondola_estante")
@NamedQuery(name="GondolaEstanteModel.findAll", query="SELECT t FROM GondolaEstanteModel t")
public class GondolaEstanteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GondolaEstanteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="quantidade_caixa")
	private Integer quantidadeCaixa;

	@ManyToOne 
	@JoinColumn(name="id_gondola_rua")
	private GondolaRuaModel gondolaRuaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public Integer getQuantidadeCaixa() { 
		return this.quantidadeCaixa; 
	} 

	public void setQuantidadeCaixa(Integer quantidadeCaixa) { 
		this.quantidadeCaixa = quantidadeCaixa; 
	} 

	public GondolaRuaModel getGondolaRuaModel() { 
	return this.gondolaRuaModel; 
	} 

	public void setGondolaRuaModel(GondolaRuaModel gondolaRuaModel) { 
	this.gondolaRuaModel = gondolaRuaModel; 
	} 

		
}