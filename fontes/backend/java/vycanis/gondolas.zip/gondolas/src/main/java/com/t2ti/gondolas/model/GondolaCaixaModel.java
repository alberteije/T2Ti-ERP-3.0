package com.t2ti.gondolas.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="gondola_caixa")
@NamedQuery(name="GondolaCaixaModel.findAll", query="SELECT t FROM GondolaCaixaModel t")
public class GondolaCaixaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public GondolaCaixaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="codigo")
	private String codigo;

	@Column(name="altura")
	private Integer altura;

	@Column(name="largura")
	private Integer largura;

	@Column(name="profundidade")
	private Integer profundidade;

	@OneToMany(mappedBy = "gondolaCaixaModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<GondolaArmazenamentoModel> gondolaArmazenamentoModelList; 

	@ManyToOne 
	@JoinColumn(name="id_gondola_estante")
	private GondolaEstanteModel gondolaEstanteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodigo() { 
		return this.codigo; 
	} 

	public void setCodigo(String codigo) { 
		this.codigo = codigo; 
	} 

	public Integer getAltura() { 
		return this.altura; 
	} 

	public void setAltura(Integer altura) { 
		this.altura = altura; 
	} 

	public Integer getLargura() { 
		return this.largura; 
	} 

	public void setLargura(Integer largura) { 
		this.largura = largura; 
	} 

	public Integer getProfundidade() { 
		return this.profundidade; 
	} 

	public void setProfundidade(Integer profundidade) { 
		this.profundidade = profundidade; 
	} 

	public Set<GondolaArmazenamentoModel> getGondolaArmazenamentoModelList() { 
	return this.gondolaArmazenamentoModelList; 
	} 

	public void setGondolaArmazenamentoModelList(Set<GondolaArmazenamentoModel> gondolaArmazenamentoModelList) { 
	this.gondolaArmazenamentoModelList = gondolaArmazenamentoModelList; 
		for (GondolaArmazenamentoModel gondolaArmazenamentoModel : gondolaArmazenamentoModelList) { 
			gondolaArmazenamentoModel.setGondolaCaixaModel(this); 
		}
	} 

	public GondolaEstanteModel getGondolaEstanteModel() { 
	return this.gondolaEstanteModel; 
	} 

	public void setGondolaEstanteModel(GondolaEstanteModel gondolaEstanteModel) { 
	this.gondolaEstanteModel = gondolaEstanteModel; 
	} 

		
}