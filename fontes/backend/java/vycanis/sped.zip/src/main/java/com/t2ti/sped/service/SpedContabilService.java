package com.t2ti.sped.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.sped.util.Filter;
import com.t2ti.sped.exception.GenericException;
import com.t2ti.sped.model.SpedContabilModel;
import com.t2ti.sped.repository.SpedContabilRepository;

@Service
public class SpedContabilService {

	@Autowired
	private SpedContabilRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SpedContabilModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SpedContabilModel> getList(Filter filter) {
		String sql = "select * from sped_contabil where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SpedContabilModel.class);
		return query.getResultList();
	}

	public SpedContabilModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SpedContabilModel save(SpedContabilModel obj) {
		SpedContabilModel spedContabilModel = repository.save(obj);
		return spedContabilModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SpedContabilModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SpedContabil] - Exception: " + e.getMessage());
		}
	}

}