package com.t2ti.sped.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.sped.model.EfdContribuicoesModel;

public interface EfdContribuicoesRepository extends JpaRepository<EfdContribuicoesModel, Integer> {}