package com.t2ti.sped.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.sped.model.EfdReinfModel;

public interface EfdReinfRepository extends JpaRepository<EfdReinfModel, Integer> {}