package com.t2ti.sped.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.sped.model.SpedFiscalModel;

public interface SpedFiscalRepository extends JpaRepository<SpedFiscalModel, Integer> {}