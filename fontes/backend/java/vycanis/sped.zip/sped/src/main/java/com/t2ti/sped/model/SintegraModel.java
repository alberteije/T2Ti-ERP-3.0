package com.t2ti.sped.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="sintegra")
@NamedQuery(name="SintegraModel.findAll", query="SELECT t FROM SintegraModel t")
public class SintegraModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public SintegraModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="periodo_inicial")
	private Date periodoInicial;

	@Temporal(TemporalType.DATE)
@Column(name="periodo_final")
	private Date periodoFinal;

	@Column(name="codigo_convenio")
	private String codigoConvenio;

	@Column(name="inventario")
	private String inventario;

	@Column(name="finalidade_arquivo")
	private String finalidadeArquivo;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public Date getPeriodoInicial() { 
		return this.periodoInicial; 
	} 

	public void setPeriodoInicial(Date periodoInicial) { 
		this.periodoInicial = periodoInicial; 
	} 

	public Date getPeriodoFinal() { 
		return this.periodoFinal; 
	} 

	public void setPeriodoFinal(Date periodoFinal) { 
		this.periodoFinal = periodoFinal; 
	} 

	public String getCodigoConvenio() { 
		return this.codigoConvenio; 
	} 

	public void setCodigoConvenio(String codigoConvenio) { 
		this.codigoConvenio = codigoConvenio; 
	} 

	public String getInventario() { 
		return this.inventario; 
	} 

	public void setInventario(String inventario) { 
		this.inventario = inventario; 
	} 

	public String getFinalidadeArquivo() { 
		return this.finalidadeArquivo; 
	} 

	public void setFinalidadeArquivo(String finalidadeArquivo) { 
		this.finalidadeArquivo = finalidadeArquivo; 
	} 

		
}