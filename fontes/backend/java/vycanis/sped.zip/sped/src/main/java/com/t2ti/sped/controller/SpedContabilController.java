package com.t2ti.sped.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2ti.sped.exception.GenericException;
import com.t2ti.sped.exception.ResourseNotFoundException;
import com.t2ti.sped.exception.BadRequestException;
import com.t2ti.sped.util.Filter;
import com.t2ti.sped.model.SpedContabilModel;
import com.t2ti.sped.service.SpedContabilService;

@RestController
@RequestMapping(value = "/sped-contabil", produces = "application/json;charset=UTF-8")
public class SpedContabilController {

	@Autowired
	private SpedContabilService service;
	
	@GetMapping({ "", "/" })
	public List<SpedContabilModel> getList(@RequestParam(required = false) String filter) {
		try {
			if (filter == null) {
				return service.getList();
			} else {
				// defines filter
				Filter objFilter = new Filter(filter);
				return service.getList(objFilter);				
			}
		} catch (Exception e) {
			throw new GenericException("Error [SpedContabil] - Exception: " + e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public SpedContabilModel getObject(@PathVariable Integer id) {
		try {
			try {
				return service.getObject(id);
			} catch (NoSuchElementException e) {
				throw new ResourseNotFoundException("[Not Found SpedContabil].");
			}
		} catch (Exception e) {
			throw new GenericException("Error [Not Found SpedContabil] - Exception: " + e.getMessage());
		}
	}
	
	@PostMapping
	public SpedContabilModel insert(@RequestBody SpedContabilModel objJson) {
		try {
			return service.save(objJson);
		} catch (Exception e) {
			throw new GenericException("Error [Insert SpedContabil] - Exception: " + e.getMessage());
		}
	}

	@PutMapping
	public SpedContabilModel update(@RequestBody SpedContabilModel objJson) {	
		try {			
			SpedContabilModel obj = service.getObject(objJson.getId());
			if (obj != null) {
				return service.save(objJson);				
			} else
			{
				throw new BadRequestException("Invalid Object [Update SpedContabil].");				
			}
		} catch (Exception e) {
			throw new GenericException("Error [Update SpedContabil] - Exception: " + e.getMessage());
		}
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		try {
			service.delete(id);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SpedContabil] - Exception: " + e.getMessage());
		}
	}
	
}