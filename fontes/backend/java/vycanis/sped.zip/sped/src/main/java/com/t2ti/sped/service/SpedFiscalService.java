package com.t2ti.sped.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.sped.util.Filter;
import com.t2ti.sped.exception.GenericException;
import com.t2ti.sped.model.SpedFiscalModel;
import com.t2ti.sped.repository.SpedFiscalRepository;

@Service
public class SpedFiscalService {

	@Autowired
	private SpedFiscalRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<SpedFiscalModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<SpedFiscalModel> getList(Filter filter) {
		String sql = "select * from sped_fiscal where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, SpedFiscalModel.class);
		return query.getResultList();
	}

	public SpedFiscalModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public SpedFiscalModel save(SpedFiscalModel obj) {
		SpedFiscalModel spedFiscalModel = repository.save(obj);
		return spedFiscalModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		SpedFiscalModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete SpedFiscal] - Exception: " + e.getMessage());
		}
	}

}