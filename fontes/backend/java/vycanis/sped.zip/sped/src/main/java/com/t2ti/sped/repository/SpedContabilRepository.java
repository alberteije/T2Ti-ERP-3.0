package com.t2ti.sped.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.sped.model.SpedContabilModel;

public interface SpedContabilRepository extends JpaRepository<SpedContabilModel, Integer> {}