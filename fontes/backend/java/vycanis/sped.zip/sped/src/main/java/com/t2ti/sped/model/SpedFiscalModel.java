package com.t2ti.sped.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="sped_fiscal")
@NamedQuery(name="SpedFiscalModel.findAll", query="SELECT t FROM SpedFiscalModel t")
public class SpedFiscalModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public SpedFiscalModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_emissao")
	private Date dataEmissao;

	@Temporal(TemporalType.DATE)
@Column(name="periodo_inicial")
	private Date periodoInicial;

	@Temporal(TemporalType.DATE)
@Column(name="periodo_final")
	private Date periodoFinal;

	@Column(name="perfil_apresentacao")
	private String perfilApresentacao;

	@Column(name="finalidade_arquivo")
	private String finalidadeArquivo;

	@Column(name="versao_layout")
	private String versaoLayout;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataEmissao() { 
		return this.dataEmissao; 
	} 

	public void setDataEmissao(Date dataEmissao) { 
		this.dataEmissao = dataEmissao; 
	} 

	public Date getPeriodoInicial() { 
		return this.periodoInicial; 
	} 

	public void setPeriodoInicial(Date periodoInicial) { 
		this.periodoInicial = periodoInicial; 
	} 

	public Date getPeriodoFinal() { 
		return this.periodoFinal; 
	} 

	public void setPeriodoFinal(Date periodoFinal) { 
		this.periodoFinal = periodoFinal; 
	} 

	public String getPerfilApresentacao() { 
		return this.perfilApresentacao; 
	} 

	public void setPerfilApresentacao(String perfilApresentacao) { 
		this.perfilApresentacao = perfilApresentacao; 
	} 

	public String getFinalidadeArquivo() { 
		return this.finalidadeArquivo; 
	} 

	public void setFinalidadeArquivo(String finalidadeArquivo) { 
		this.finalidadeArquivo = finalidadeArquivo; 
	} 

	public String getVersaoLayout() { 
		return this.versaoLayout; 
	} 

	public void setVersaoLayout(String versaoLayout) { 
		this.versaoLayout = versaoLayout; 
	} 

		
}