package com.t2ti.sped;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpedApplication.class, args);
	}

}
