package com.t2ti.sped.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="view_controle_acesso")
@NamedQuery(name="ViewControleAcessoModel.findAll", query="SELECT t FROM ViewControleAcessoModel t")
public class ViewControleAcessoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ViewControleAcessoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_pessoa")
	private Integer idPessoa;

	@Column(name="pessoa_nome")
	private String pessoaNome;

	@Column(name="id_colaborador")
	private Integer idColaborador;

	@Column(name="id_usuario")
	private Integer idUsuario;

	@Column(name="administrador")
	private String administrador;

	@Column(name="id_papel")
	private Integer idPapel;

	@Column(name="papel_nome")
	private String papelNome;

	@Column(name="papel_descricao")
	private String papelDescricao;

	@Column(name="id_funcao")
	private Integer idFuncao;

	@Column(name="funcao_nome")
	private String funcaoNome;

	@Column(name="funcao_descricao")
	private String funcaoDescricao;

	@Column(name="id_papel_funcao")
	private Integer idPapelFuncao;

	@Column(name="habilitado")
	private String habilitado;

	@Column(name="pode_inserir")
	private String podeInserir;

	@Column(name="pode_alterar")
	private String podeAlterar;

	@Column(name="pode_excluir")
	private String podeExcluir;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdPessoa() { 
		return this.idPessoa; 
	} 

	public void setIdPessoa(Integer idPessoa) { 
		this.idPessoa = idPessoa; 
	} 

	public String getPessoaNome() { 
		return this.pessoaNome; 
	} 

	public void setPessoaNome(String pessoaNome) { 
		this.pessoaNome = pessoaNome; 
	} 

	public Integer getIdColaborador() { 
		return this.idColaborador; 
	} 

	public void setIdColaborador(Integer idColaborador) { 
		this.idColaborador = idColaborador; 
	} 

	public Integer getIdUsuario() { 
		return this.idUsuario; 
	} 

	public void setIdUsuario(Integer idUsuario) { 
		this.idUsuario = idUsuario; 
	} 

	public String getAdministrador() { 
		return this.administrador; 
	} 

	public void setAdministrador(String administrador) { 
		this.administrador = administrador; 
	} 

	public Integer getIdPapel() { 
		return this.idPapel; 
	} 

	public void setIdPapel(Integer idPapel) { 
		this.idPapel = idPapel; 
	} 

	public String getPapelNome() { 
		return this.papelNome; 
	} 

	public void setPapelNome(String papelNome) { 
		this.papelNome = papelNome; 
	} 

	public String getPapelDescricao() { 
		return this.papelDescricao; 
	} 

	public void setPapelDescricao(String papelDescricao) { 
		this.papelDescricao = papelDescricao; 
	} 

	public Integer getIdFuncao() { 
		return this.idFuncao; 
	} 

	public void setIdFuncao(Integer idFuncao) { 
		this.idFuncao = idFuncao; 
	} 

	public String getFuncaoNome() { 
		return this.funcaoNome; 
	} 

	public void setFuncaoNome(String funcaoNome) { 
		this.funcaoNome = funcaoNome; 
	} 

	public String getFuncaoDescricao() { 
		return this.funcaoDescricao; 
	} 

	public void setFuncaoDescricao(String funcaoDescricao) { 
		this.funcaoDescricao = funcaoDescricao; 
	} 

	public Integer getIdPapelFuncao() { 
		return this.idPapelFuncao; 
	} 

	public void setIdPapelFuncao(Integer idPapelFuncao) { 
		this.idPapelFuncao = idPapelFuncao; 
	} 

	public String getHabilitado() { 
		return this.habilitado; 
	} 

	public void setHabilitado(String habilitado) { 
		this.habilitado = habilitado; 
	} 

	public String getPodeInserir() { 
		return this.podeInserir; 
	} 

	public void setPodeInserir(String podeInserir) { 
		this.podeInserir = podeInserir; 
	} 

	public String getPodeAlterar() { 
		return this.podeAlterar; 
	} 

	public void setPodeAlterar(String podeAlterar) { 
		this.podeAlterar = podeAlterar; 
	} 

	public String getPodeExcluir() { 
		return this.podeExcluir; 
	} 

	public void setPodeExcluir(String podeExcluir) { 
		this.podeExcluir = podeExcluir; 
	} 

		
}