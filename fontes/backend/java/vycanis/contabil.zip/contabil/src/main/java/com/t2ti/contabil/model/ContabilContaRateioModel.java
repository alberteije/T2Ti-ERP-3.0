package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_conta_rateio")
@NamedQuery(name="ContabilContaRateioModel.findAll", query="SELECT t FROM ContabilContaRateioModel t")
public class ContabilContaRateioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilContaRateioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="porcento_rateio")
	private BigDecimal porcentoRateio;

	@ManyToOne 
	@JoinColumn(name="id_contabil_conta")
	private ContabilContaModel contabilContaModel; 

	@ManyToOne 
	@JoinColumn(name="id_centro_resultado")
	private CentroResultadoModel centroResultadoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getPorcentoRateio() { 
		return this.porcentoRateio; 
	} 

	public void setPorcentoRateio(BigDecimal porcentoRateio) { 
		this.porcentoRateio = porcentoRateio; 
	} 

	public ContabilContaModel getContabilContaModel() { 
	return this.contabilContaModel; 
	} 

	public void setContabilContaModel(ContabilContaModel contabilContaModel) { 
	this.contabilContaModel = contabilContaModel; 
	} 

	public CentroResultadoModel getCentroResultadoModel() { 
	return this.centroResultadoModel; 
	} 

	public void setCentroResultadoModel(CentroResultadoModel centroResultadoModel) { 
	this.centroResultadoModel = centroResultadoModel; 
	} 

		
}