package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="lanca_centro_resultado")
@NamedQuery(name="LancaCentroResultadoModel.findAll", query="SELECT t FROM LancaCentroResultadoModel t")
public class LancaCentroResultadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public LancaCentroResultadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="valor")
	private BigDecimal valor;

	@Temporal(TemporalType.DATE)
@Column(name="data_lancamento")
	private Date dataLancamento;

	@Temporal(TemporalType.DATE)
@Column(name="data_inclusao")
	private Date dataInclusao;

	@Column(name="origem_de_rateio")
	private String origemDeRateio;

	@Column(name="historico")
	private String historico;

	@ManyToOne 
	@JoinColumn(name="id_centro_resultado")
	private CentroResultadoModel centroResultadoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public Date getDataLancamento() { 
		return this.dataLancamento; 
	} 

	public void setDataLancamento(Date dataLancamento) { 
		this.dataLancamento = dataLancamento; 
	} 

	public Date getDataInclusao() { 
		return this.dataInclusao; 
	} 

	public void setDataInclusao(Date dataInclusao) { 
		this.dataInclusao = dataInclusao; 
	} 

	public String getOrigemDeRateio() { 
		return this.origemDeRateio; 
	} 

	public void setOrigemDeRateio(String origemDeRateio) { 
		this.origemDeRateio = origemDeRateio; 
	} 

	public String getHistorico() { 
		return this.historico; 
	} 

	public void setHistorico(String historico) { 
		this.historico = historico; 
	} 

	public CentroResultadoModel getCentroResultadoModel() { 
	return this.centroResultadoModel; 
	} 

	public void setCentroResultadoModel(CentroResultadoModel centroResultadoModel) { 
	this.centroResultadoModel = centroResultadoModel; 
	} 

		
}