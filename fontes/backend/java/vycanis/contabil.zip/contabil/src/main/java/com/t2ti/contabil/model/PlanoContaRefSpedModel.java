package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="plano_conta_ref_sped")
@NamedQuery(name="PlanoContaRefSpedModel.findAll", query="SELECT t FROM PlanoContaRefSpedModel t")
public class PlanoContaRefSpedModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PlanoContaRefSpedModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="cod_cta_ref")
	private String codCtaRef;

	@Temporal(TemporalType.DATE)
@Column(name="inicio_validade")
	private Date inicioValidade;

	@Temporal(TemporalType.DATE)
@Column(name="fim_validade")
	private Date fimValidade;

	@Column(name="tipo")
	private String tipo;

	@Column(name="descricao")
	private String descricao;

	@Column(name="orientacoes")
	private String orientacoes;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCodCtaRef() { 
		return this.codCtaRef; 
	} 

	public void setCodCtaRef(String codCtaRef) { 
		this.codCtaRef = codCtaRef; 
	} 

	public Date getInicioValidade() { 
		return this.inicioValidade; 
	} 

	public void setInicioValidade(Date inicioValidade) { 
		this.inicioValidade = inicioValidade; 
	} 

	public Date getFimValidade() { 
		return this.fimValidade; 
	} 

	public void setFimValidade(Date fimValidade) { 
		this.fimValidade = fimValidade; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getOrientacoes() { 
		return this.orientacoes; 
	} 

	public void setOrientacoes(String orientacoes) { 
		this.orientacoes = orientacoes; 
	} 

		
}