package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.AidfAimdfModel;
import com.t2ti.contabil.repository.AidfAimdfRepository;

@Service
public class AidfAimdfService {

	@Autowired
	private AidfAimdfRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<AidfAimdfModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<AidfAimdfModel> getList(Filter filter) {
		String sql = "select * from aidf_aimdf where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, AidfAimdfModel.class);
		return query.getResultList();
	}

	public AidfAimdfModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public AidfAimdfModel save(AidfAimdfModel obj) {
		AidfAimdfModel aidfAimdfModel = repository.save(obj);
		return aidfAimdfModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		AidfAimdfModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete AidfAimdf] - Exception: " + e.getMessage());
		}
	}

}