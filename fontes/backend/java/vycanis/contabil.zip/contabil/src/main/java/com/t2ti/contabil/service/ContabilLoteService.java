package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilLoteModel;
import com.t2ti.contabil.repository.ContabilLoteRepository;

@Service
public class ContabilLoteService {

	@Autowired
	private ContabilLoteRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilLoteModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilLoteModel> getList(Filter filter) {
		String sql = "select * from contabil_lote where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilLoteModel.class);
		return query.getResultList();
	}

	public ContabilLoteModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilLoteModel save(ContabilLoteModel obj) {
		ContabilLoteModel contabilLoteModel = repository.save(obj);
		return contabilLoteModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilLoteModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilLote] - Exception: " + e.getMessage());
		}
	}

}