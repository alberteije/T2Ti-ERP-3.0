package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="rateio_centro_resultado_cab")
@NamedQuery(name="RateioCentroResultadoCabModel.findAll", query="SELECT t FROM RateioCentroResultadoCabModel t")
public class RateioCentroResultadoCabModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public RateioCentroResultadoCabModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "rateioCentroResultadoCabModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<RateioCentroResultadoDetModel> rateioCentroResultadoDetModelList; 

	@ManyToOne 
	@JoinColumn(name="id_centro_resultado")
	private CentroResultadoModel centroResultadoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<RateioCentroResultadoDetModel> getRateioCentroResultadoDetModelList() { 
	return this.rateioCentroResultadoDetModelList; 
	} 

	public void setRateioCentroResultadoDetModelList(Set<RateioCentroResultadoDetModel> rateioCentroResultadoDetModelList) { 
	this.rateioCentroResultadoDetModelList = rateioCentroResultadoDetModelList; 
		for (RateioCentroResultadoDetModel rateioCentroResultadoDetModel : rateioCentroResultadoDetModelList) { 
			rateioCentroResultadoDetModel.setRateioCentroResultadoCabModel(this); 
		}
	} 

	public CentroResultadoModel getCentroResultadoModel() { 
	return this.centroResultadoModel; 
	} 

	public void setCentroResultadoModel(CentroResultadoModel centroResultadoModel) { 
	this.centroResultadoModel = centroResultadoModel; 
	} 

		
}