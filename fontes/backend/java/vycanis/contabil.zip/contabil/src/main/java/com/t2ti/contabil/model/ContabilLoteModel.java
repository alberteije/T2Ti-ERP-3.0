package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="contabil_lote")
@NamedQuery(name="ContabilLoteModel.findAll", query="SELECT t FROM ContabilLoteModel t")
public class ContabilLoteModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilLoteModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Temporal(TemporalType.DATE)
@Column(name="data_inclusao")
	private Date dataInclusao;

	@Temporal(TemporalType.DATE)
@Column(name="data_liberacao")
	private Date dataLiberacao;

	@Column(name="liberado")
	private String liberado;

	@Column(name="programado")
	private String programado;

	@Column(name="valor")
	private BigDecimal valor;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Date getDataInclusao() { 
		return this.dataInclusao; 
	} 

	public void setDataInclusao(Date dataInclusao) { 
		this.dataInclusao = dataInclusao; 
	} 

	public Date getDataLiberacao() { 
		return this.dataLiberacao; 
	} 

	public void setDataLiberacao(Date dataLiberacao) { 
		this.dataLiberacao = dataLiberacao; 
	} 

	public String getLiberado() { 
		return this.liberado; 
	} 

	public void setLiberado(String liberado) { 
		this.liberado = liberado; 
	} 

	public String getProgramado() { 
		return this.programado; 
	} 

	public void setProgramado(String programado) { 
		this.programado = programado; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

		
}