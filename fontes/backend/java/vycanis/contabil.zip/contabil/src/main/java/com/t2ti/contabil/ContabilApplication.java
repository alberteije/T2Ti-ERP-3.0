package com.t2ti.contabil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContabilApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContabilApplication.class, args);
	}

}
