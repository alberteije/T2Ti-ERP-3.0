package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.RegistroCartorioModel;
import com.t2ti.contabil.repository.RegistroCartorioRepository;

@Service
public class RegistroCartorioService {

	@Autowired
	private RegistroCartorioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<RegistroCartorioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<RegistroCartorioModel> getList(Filter filter) {
		String sql = "select * from registro_cartorio where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, RegistroCartorioModel.class);
		return query.getResultList();
	}

	public RegistroCartorioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public RegistroCartorioModel save(RegistroCartorioModel obj) {
		RegistroCartorioModel registroCartorioModel = repository.save(obj);
		return registroCartorioModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		RegistroCartorioModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete RegistroCartorio] - Exception: " + e.getMessage());
		}
	}

}