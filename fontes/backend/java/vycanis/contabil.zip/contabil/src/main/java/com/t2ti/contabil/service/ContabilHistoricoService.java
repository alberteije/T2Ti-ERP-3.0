package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilHistoricoModel;
import com.t2ti.contabil.repository.ContabilHistoricoRepository;

@Service
public class ContabilHistoricoService {

	@Autowired
	private ContabilHistoricoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilHistoricoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilHistoricoModel> getList(Filter filter) {
		String sql = "select * from contabil_historico where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilHistoricoModel.class);
		return query.getResultList();
	}

	public ContabilHistoricoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilHistoricoModel save(ContabilHistoricoModel obj) {
		ContabilHistoricoModel contabilHistoricoModel = repository.save(obj);
		return contabilHistoricoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilHistoricoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilHistorico] - Exception: " + e.getMessage());
		}
	}

}