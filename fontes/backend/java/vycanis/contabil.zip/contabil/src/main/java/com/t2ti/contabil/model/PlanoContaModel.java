package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="plano_conta")
@NamedQuery(name="PlanoContaModel.findAll", query="SELECT t FROM PlanoContaModel t")
public class PlanoContaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public PlanoContaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome")
	private String nome;

	@Temporal(TemporalType.DATE)
@Column(name="data_inclusao")
	private Date dataInclusao;

	@Column(name="mascara")
	private String mascara;

	@Column(name="niveis")
	private Integer niveis;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNome() { 
		return this.nome; 
	} 

	public void setNome(String nome) { 
		this.nome = nome; 
	} 

	public Date getDataInclusao() { 
		return this.dataInclusao; 
	} 

	public void setDataInclusao(Date dataInclusao) { 
		this.dataInclusao = dataInclusao; 
	} 

	public String getMascara() { 
		return this.mascara; 
	} 

	public void setMascara(String mascara) { 
		this.mascara = mascara; 
	} 

	public Integer getNiveis() { 
		return this.niveis; 
	} 

	public void setNiveis(Integer niveis) { 
		this.niveis = niveis; 
	} 

		
}