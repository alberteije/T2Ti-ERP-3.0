package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="ct_resultado_nt_financeira")
@NamedQuery(name="CtResultadoNtFinanceiraModel.findAll", query="SELECT t FROM CtResultadoNtFinanceiraModel t")
public class CtResultadoNtFinanceiraModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CtResultadoNtFinanceiraModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="percentual_rateio")
	private BigDecimal percentualRateio;

	@ManyToOne 
	@JoinColumn(name="id_fin_natureza_financeira")
	private FinNaturezaFinanceiraModel finNaturezaFinanceiraModel; 

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_centro_resultado")
	private CentroResultadoModel centroResultadoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getPercentualRateio() { 
		return this.percentualRateio; 
	} 

	public void setPercentualRateio(BigDecimal percentualRateio) { 
		this.percentualRateio = percentualRateio; 
	} 

	public FinNaturezaFinanceiraModel getFinNaturezaFinanceiraModel() { 
	return this.finNaturezaFinanceiraModel; 
	} 

	public void setFinNaturezaFinanceiraModel(FinNaturezaFinanceiraModel finNaturezaFinanceiraModel) { 
	this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel; 
	} 

	public CentroResultadoModel getCentroResultadoModel() { 
	return this.centroResultadoModel; 
	} 

	public void setCentroResultadoModel(CentroResultadoModel centroResultadoModel) { 
	this.centroResultadoModel = centroResultadoModel; 
	} 

		
}