package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_lancamento_orcado")
@NamedQuery(name="ContabilLancamentoOrcadoModel.findAll", query="SELECT t FROM ContabilLancamentoOrcadoModel t")
public class ContabilLancamentoOrcadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilLancamentoOrcadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="ano")
	private String ano;

	@Column(name="janeiro")
	private BigDecimal janeiro;

	@Column(name="fevereiro")
	private BigDecimal fevereiro;

	@Column(name="marco")
	private BigDecimal marco;

	@Column(name="abril")
	private BigDecimal abril;

	@Column(name="maio")
	private BigDecimal maio;

	@Column(name="junho")
	private BigDecimal junho;

	@Column(name="julho")
	private BigDecimal julho;

	@Column(name="agosto")
	private BigDecimal agosto;

	@Column(name="setembro")
	private BigDecimal setembro;

	@Column(name="outubro")
	private BigDecimal outubro;

	@Column(name="novembro")
	private BigDecimal novembro;

	@Column(name="dezembro")
	private BigDecimal dezembro;

	@ManyToOne 
	@JoinColumn(name="id_contabil_conta")
	private ContabilContaModel contabilContaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getAno() { 
		return this.ano; 
	} 

	public void setAno(String ano) { 
		this.ano = ano; 
	} 

	public BigDecimal getJaneiro() { 
		return this.janeiro; 
	} 

	public void setJaneiro(BigDecimal janeiro) { 
		this.janeiro = janeiro; 
	} 

	public BigDecimal getFevereiro() { 
		return this.fevereiro; 
	} 

	public void setFevereiro(BigDecimal fevereiro) { 
		this.fevereiro = fevereiro; 
	} 

	public BigDecimal getMarco() { 
		return this.marco; 
	} 

	public void setMarco(BigDecimal marco) { 
		this.marco = marco; 
	} 

	public BigDecimal getAbril() { 
		return this.abril; 
	} 

	public void setAbril(BigDecimal abril) { 
		this.abril = abril; 
	} 

	public BigDecimal getMaio() { 
		return this.maio; 
	} 

	public void setMaio(BigDecimal maio) { 
		this.maio = maio; 
	} 

	public BigDecimal getJunho() { 
		return this.junho; 
	} 

	public void setJunho(BigDecimal junho) { 
		this.junho = junho; 
	} 

	public BigDecimal getJulho() { 
		return this.julho; 
	} 

	public void setJulho(BigDecimal julho) { 
		this.julho = julho; 
	} 

	public BigDecimal getAgosto() { 
		return this.agosto; 
	} 

	public void setAgosto(BigDecimal agosto) { 
		this.agosto = agosto; 
	} 

	public BigDecimal getSetembro() { 
		return this.setembro; 
	} 

	public void setSetembro(BigDecimal setembro) { 
		this.setembro = setembro; 
	} 

	public BigDecimal getOutubro() { 
		return this.outubro; 
	} 

	public void setOutubro(BigDecimal outubro) { 
		this.outubro = outubro; 
	} 

	public BigDecimal getNovembro() { 
		return this.novembro; 
	} 

	public void setNovembro(BigDecimal novembro) { 
		this.novembro = novembro; 
	} 

	public BigDecimal getDezembro() { 
		return this.dezembro; 
	} 

	public void setDezembro(BigDecimal dezembro) { 
		this.dezembro = dezembro; 
	} 

	public ContabilContaModel getContabilContaModel() { 
	return this.contabilContaModel; 
	} 

	public void setContabilContaModel(ContabilContaModel contabilContaModel) { 
	this.contabilContaModel = contabilContaModel; 
	} 

		
}