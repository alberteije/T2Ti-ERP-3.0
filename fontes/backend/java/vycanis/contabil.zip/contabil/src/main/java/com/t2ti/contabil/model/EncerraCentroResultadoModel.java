package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="encerra_centro_resultado")
@NamedQuery(name="EncerraCentroResultadoModel.findAll", query="SELECT t FROM EncerraCentroResultadoModel t")
public class EncerraCentroResultadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public EncerraCentroResultadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="valor_total")
	private BigDecimal valorTotal;

	@Column(name="valor_sub_rateio")
	private BigDecimal valorSubRateio;

	@ManyToOne 
	@JoinColumn(name="id_centro_resultado")
	private CentroResultadoModel centroResultadoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public BigDecimal getValorTotal() { 
		return this.valorTotal; 
	} 

	public void setValorTotal(BigDecimal valorTotal) { 
		this.valorTotal = valorTotal; 
	} 

	public BigDecimal getValorSubRateio() { 
		return this.valorSubRateio; 
	} 

	public void setValorSubRateio(BigDecimal valorSubRateio) { 
		this.valorSubRateio = valorSubRateio; 
	} 

	public CentroResultadoModel getCentroResultadoModel() { 
	return this.centroResultadoModel; 
	} 

	public void setCentroResultadoModel(CentroResultadoModel centroResultadoModel) { 
	this.centroResultadoModel = centroResultadoModel; 
	} 

		
}