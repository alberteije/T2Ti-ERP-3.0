package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="aidf_aimdf")
@NamedQuery(name="AidfAimdfModel.findAll", query="SELECT t FROM AidfAimdfModel t")
public class AidfAimdfModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public AidfAimdfModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="numero")
	private Integer numero;

	@Temporal(TemporalType.DATE)
@Column(name="data_validade")
	private Date dataValidade;

	@Temporal(TemporalType.DATE)
@Column(name="data_autorizacao")
	private Date dataAutorizacao;

	@Column(name="numero_autorizacao")
	private String numeroAutorizacao;

	@Column(name="formulario_disponivel")
	private String formularioDisponivel;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public Date getDataValidade() { 
		return this.dataValidade; 
	} 

	public void setDataValidade(Date dataValidade) { 
		this.dataValidade = dataValidade; 
	} 

	public Date getDataAutorizacao() { 
		return this.dataAutorizacao; 
	} 

	public void setDataAutorizacao(Date dataAutorizacao) { 
		this.dataAutorizacao = dataAutorizacao; 
	} 

	public String getNumeroAutorizacao() { 
		return this.numeroAutorizacao; 
	} 

	public void setNumeroAutorizacao(String numeroAutorizacao) { 
		this.numeroAutorizacao = numeroAutorizacao; 
	} 

	public String getFormularioDisponivel() { 
		return this.formularioDisponivel; 
	} 

	public void setFormularioDisponivel(String formularioDisponivel) { 
		this.formularioDisponivel = formularioDisponivel; 
	} 

		
}