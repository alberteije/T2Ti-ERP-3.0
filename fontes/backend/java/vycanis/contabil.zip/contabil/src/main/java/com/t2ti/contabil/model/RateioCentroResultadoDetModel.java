package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="rateio_centro_resultado_det")
@NamedQuery(name="RateioCentroResultadoDetModel.findAll", query="SELECT t FROM RateioCentroResultadoDetModel t")
public class RateioCentroResultadoDetModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public RateioCentroResultadoDetModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="porcento_rateio")
	private BigDecimal porcentoRateio;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_rateio_centro_resul_cab")
	private RateioCentroResultadoCabModel rateioCentroResultadoCabModel; 

	@ManyToOne 
	@JoinColumn(name="id_centro_resultado_destino")
	private CentroResultadoModel centroResultadoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getPorcentoRateio() { 
		return this.porcentoRateio; 
	} 

	public void setPorcentoRateio(BigDecimal porcentoRateio) { 
		this.porcentoRateio = porcentoRateio; 
	} 

	public RateioCentroResultadoCabModel getRateioCentroResultadoCabModel() { 
	return this.rateioCentroResultadoCabModel; 
	} 

	public void setRateioCentroResultadoCabModel(RateioCentroResultadoCabModel rateioCentroResultadoCabModel) { 
	this.rateioCentroResultadoCabModel = rateioCentroResultadoCabModel; 
	} 

	public CentroResultadoModel getCentroResultadoModel() { 
	return this.centroResultadoModel; 
	} 

	public void setCentroResultadoModel(CentroResultadoModel centroResultadoModel) { 
	this.centroResultadoModel = centroResultadoModel; 
	} 

		
}