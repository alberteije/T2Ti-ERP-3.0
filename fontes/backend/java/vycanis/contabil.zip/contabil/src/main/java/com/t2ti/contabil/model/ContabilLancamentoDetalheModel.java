package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_lancamento_detalhe")
@NamedQuery(name="ContabilLancamentoDetalheModel.findAll", query="SELECT t FROM ContabilLancamentoDetalheModel t")
public class ContabilLancamentoDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilLancamentoDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="tipo")
	private String tipo;

	@Column(name="valor")
	private BigDecimal valor;

	@Column(name="historico")
	private String historico;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_contabil_lancamento_cab")
	private ContabilLancamentoCabecalhoModel contabilLancamentoCabecalhoModel; 

	@ManyToOne 
	@JoinColumn(name="id_contabil_historico")
	private ContabilHistoricoModel contabilHistoricoModel; 

	@ManyToOne 
	@JoinColumn(name="id_contabil_conta")
	private ContabilContaModel contabilContaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public String getHistorico() { 
		return this.historico; 
	} 

	public void setHistorico(String historico) { 
		this.historico = historico; 
	} 

	public ContabilLancamentoCabecalhoModel getContabilLancamentoCabecalhoModel() { 
	return this.contabilLancamentoCabecalhoModel; 
	} 

	public void setContabilLancamentoCabecalhoModel(ContabilLancamentoCabecalhoModel contabilLancamentoCabecalhoModel) { 
	this.contabilLancamentoCabecalhoModel = contabilLancamentoCabecalhoModel; 
	} 

	public ContabilHistoricoModel getContabilHistoricoModel() { 
	return this.contabilHistoricoModel; 
	} 

	public void setContabilHistoricoModel(ContabilHistoricoModel contabilHistoricoModel) { 
	this.contabilHistoricoModel = contabilHistoricoModel; 
	} 

	public ContabilContaModel getContabilContaModel() { 
	return this.contabilContaModel; 
	} 

	public void setContabilContaModel(ContabilContaModel contabilContaModel) { 
	this.contabilContaModel = contabilContaModel; 
	} 

		
}