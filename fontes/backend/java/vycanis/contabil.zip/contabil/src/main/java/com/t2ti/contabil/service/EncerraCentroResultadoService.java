package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.EncerraCentroResultadoModel;
import com.t2ti.contabil.repository.EncerraCentroResultadoRepository;

@Service
public class EncerraCentroResultadoService {

	@Autowired
	private EncerraCentroResultadoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<EncerraCentroResultadoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<EncerraCentroResultadoModel> getList(Filter filter) {
		String sql = "select * from encerra_centro_resultado where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, EncerraCentroResultadoModel.class);
		return query.getResultList();
	}

	public EncerraCentroResultadoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public EncerraCentroResultadoModel save(EncerraCentroResultadoModel obj) {
		EncerraCentroResultadoModel encerraCentroResultadoModel = repository.save(obj);
		return encerraCentroResultadoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		EncerraCentroResultadoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete EncerraCentroResultado] - Exception: " + e.getMessage());
		}
	}

}