package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="contabil_historico")
@NamedQuery(name="ContabilHistoricoModel.findAll", query="SELECT t FROM ContabilHistoricoModel t")
public class ContabilHistoricoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilHistoricoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Column(name="pede_complemento")
	private String pedeComplemento;

	@Column(name="historico")
	private String historico;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getPedeComplemento() { 
		return this.pedeComplemento; 
	} 

	public void setPedeComplemento(String pedeComplemento) { 
		this.pedeComplemento = pedeComplemento; 
	} 

	public String getHistorico() { 
		return this.historico; 
	} 

	public void setHistorico(String historico) { 
		this.historico = historico; 
	} 

		
}