package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilLancamentoOrcadoModel;
import com.t2ti.contabil.repository.ContabilLancamentoOrcadoRepository;

@Service
public class ContabilLancamentoOrcadoService {

	@Autowired
	private ContabilLancamentoOrcadoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilLancamentoOrcadoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilLancamentoOrcadoModel> getList(Filter filter) {
		String sql = "select * from contabil_lancamento_orcado where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilLancamentoOrcadoModel.class);
		return query.getResultList();
	}

	public ContabilLancamentoOrcadoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilLancamentoOrcadoModel save(ContabilLancamentoOrcadoModel obj) {
		ContabilLancamentoOrcadoModel contabilLancamentoOrcadoModel = repository.save(obj);
		return contabilLancamentoOrcadoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilLancamentoOrcadoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilLancamentoOrcado] - Exception: " + e.getMessage());
		}
	}

}