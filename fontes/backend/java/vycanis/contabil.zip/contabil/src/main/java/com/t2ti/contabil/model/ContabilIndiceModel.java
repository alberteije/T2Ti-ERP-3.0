package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="contabil_indice")
@NamedQuery(name="ContabilIndiceModel.findAll", query="SELECT t FROM ContabilIndiceModel t")
public class ContabilIndiceModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilIndiceModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="indice")
	private String indice;

	@Column(name="periodicidade")
	private String periodicidade;

	@Temporal(TemporalType.DATE)
@Column(name="diario_a_partir_de")
	private Date diarioAPartirDe;

	@Column(name="mensal_mes_ano")
	private String mensalMesAno;

	@OneToMany(mappedBy = "contabilIndiceModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContabilIndiceValorModel> contabilIndiceValorModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getIndice() { 
		return this.indice; 
	} 

	public void setIndice(String indice) { 
		this.indice = indice; 
	} 

	public String getPeriodicidade() { 
		return this.periodicidade; 
	} 

	public void setPeriodicidade(String periodicidade) { 
		this.periodicidade = periodicidade; 
	} 

	public Date getDiarioAPartirDe() { 
		return this.diarioAPartirDe; 
	} 

	public void setDiarioAPartirDe(Date diarioAPartirDe) { 
		this.diarioAPartirDe = diarioAPartirDe; 
	} 

	public String getMensalMesAno() { 
		return this.mensalMesAno; 
	} 

	public void setMensalMesAno(String mensalMesAno) { 
		this.mensalMesAno = mensalMesAno; 
	} 

	public Set<ContabilIndiceValorModel> getContabilIndiceValorModelList() { 
	return this.contabilIndiceValorModelList; 
	} 

	public void setContabilIndiceValorModelList(Set<ContabilIndiceValorModel> contabilIndiceValorModelList) { 
	this.contabilIndiceValorModelList = contabilIndiceValorModelList; 
		for (ContabilIndiceValorModel contabilIndiceValorModel : contabilIndiceValorModelList) { 
			contabilIndiceValorModel.setContabilIndiceModel(this); 
		}
	} 

		
}