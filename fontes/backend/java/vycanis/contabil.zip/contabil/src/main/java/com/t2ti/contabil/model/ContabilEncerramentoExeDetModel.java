package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_encerramento_exe_det")
@NamedQuery(name="ContabilEncerramentoExeDetModel.findAll", query="SELECT t FROM ContabilEncerramentoExeDetModel t")
public class ContabilEncerramentoExeDetModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilEncerramentoExeDetModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="saldo_anterior")
	private BigDecimal saldoAnterior;

	@Column(name="valor_debito")
	private BigDecimal valorDebito;

	@Column(name="valor_credito")
	private BigDecimal valorCredito;

	@Column(name="saldo")
	private BigDecimal saldo;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_contabil_encerramento_exe")
	private ContabilEncerramentoExeCabModel contabilEncerramentoExeCabModel; 

	@ManyToOne 
	@JoinColumn(name="id_contabil_conta")
	private ContabilContaModel contabilContaModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getSaldoAnterior() { 
		return this.saldoAnterior; 
	} 

	public void setSaldoAnterior(BigDecimal saldoAnterior) { 
		this.saldoAnterior = saldoAnterior; 
	} 

	public BigDecimal getValorDebito() { 
		return this.valorDebito; 
	} 

	public void setValorDebito(BigDecimal valorDebito) { 
		this.valorDebito = valorDebito; 
	} 

	public BigDecimal getValorCredito() { 
		return this.valorCredito; 
	} 

	public void setValorCredito(BigDecimal valorCredito) { 
		this.valorCredito = valorCredito; 
	} 

	public BigDecimal getSaldo() { 
		return this.saldo; 
	} 

	public void setSaldo(BigDecimal saldo) { 
		this.saldo = saldo; 
	} 

	public ContabilEncerramentoExeCabModel getContabilEncerramentoExeCabModel() { 
	return this.contabilEncerramentoExeCabModel; 
	} 

	public void setContabilEncerramentoExeCabModel(ContabilEncerramentoExeCabModel contabilEncerramentoExeCabModel) { 
	this.contabilEncerramentoExeCabModel = contabilEncerramentoExeCabModel; 
	} 

	public ContabilContaModel getContabilContaModel() { 
	return this.contabilContaModel; 
	} 

	public void setContabilContaModel(ContabilContaModel contabilContaModel) { 
	this.contabilContaModel = contabilContaModel; 
	} 

		
}