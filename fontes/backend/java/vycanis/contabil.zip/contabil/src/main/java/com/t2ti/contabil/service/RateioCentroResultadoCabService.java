package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.RateioCentroResultadoCabModel;
import com.t2ti.contabil.repository.RateioCentroResultadoCabRepository;

@Service
public class RateioCentroResultadoCabService {

	@Autowired
	private RateioCentroResultadoCabRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<RateioCentroResultadoCabModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<RateioCentroResultadoCabModel> getList(Filter filter) {
		String sql = "select * from rateio_centro_resultado_cab where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, RateioCentroResultadoCabModel.class);
		return query.getResultList();
	}

	public RateioCentroResultadoCabModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public RateioCentroResultadoCabModel save(RateioCentroResultadoCabModel obj) {
		RateioCentroResultadoCabModel rateioCentroResultadoCabModel = repository.save(obj);
		return rateioCentroResultadoCabModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		RateioCentroResultadoCabModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete RateioCentroResultadoCab] - Exception: " + e.getMessage());
		}
	}

}