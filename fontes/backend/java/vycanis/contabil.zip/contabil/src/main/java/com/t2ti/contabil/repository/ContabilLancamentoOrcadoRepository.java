package com.t2ti.contabil.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.contabil.model.ContabilLancamentoOrcadoModel;

public interface ContabilLancamentoOrcadoRepository extends JpaRepository<ContabilLancamentoOrcadoModel, Integer> {}