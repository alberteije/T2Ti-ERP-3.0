package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="contabil_livro")
@NamedQuery(name="ContabilLivroModel.findAll", query="SELECT t FROM ContabilLivroModel t")
public class ContabilLivroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilLivroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="competencia")
	private String competencia;

	@Column(name="forma_escrituracao")
	private String formaEscrituracao;

	@Column(name="descricao")
	private String descricao;

	@OneToMany(mappedBy = "contabilLivroModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContabilTermoModel> contabilTermoModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getCompetencia() { 
		return this.competencia; 
	} 

	public void setCompetencia(String competencia) { 
		this.competencia = competencia; 
	} 

	public String getFormaEscrituracao() { 
		return this.formaEscrituracao; 
	} 

	public void setFormaEscrituracao(String formaEscrituracao) { 
		this.formaEscrituracao = formaEscrituracao; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Set<ContabilTermoModel> getContabilTermoModelList() { 
	return this.contabilTermoModelList; 
	} 

	public void setContabilTermoModelList(Set<ContabilTermoModel> contabilTermoModelList) { 
	this.contabilTermoModelList = contabilTermoModelList; 
		for (ContabilTermoModel contabilTermoModel : contabilTermoModelList) { 
			contabilTermoModel.setContabilLivroModel(this); 
		}
	} 

		
}