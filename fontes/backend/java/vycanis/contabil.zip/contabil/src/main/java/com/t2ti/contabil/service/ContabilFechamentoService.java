package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilFechamentoModel;
import com.t2ti.contabil.repository.ContabilFechamentoRepository;

@Service
public class ContabilFechamentoService {

	@Autowired
	private ContabilFechamentoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilFechamentoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilFechamentoModel> getList(Filter filter) {
		String sql = "select * from contabil_fechamento where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilFechamentoModel.class);
		return query.getResultList();
	}

	public ContabilFechamentoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilFechamentoModel save(ContabilFechamentoModel obj) {
		ContabilFechamentoModel contabilFechamentoModel = repository.save(obj);
		return contabilFechamentoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilFechamentoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilFechamento] - Exception: " + e.getMessage());
		}
	}

}