package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="contabil_encerramento_exe_cab")
@NamedQuery(name="ContabilEncerramentoExeCabModel.findAll", query="SELECT t FROM ContabilEncerramentoExeCabModel t")
public class ContabilEncerramentoExeCabModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilEncerramentoExeCabModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicio")
	private Date dataInicio;

	@Temporal(TemporalType.DATE)
@Column(name="data_fim")
	private Date dataFim;

	@Temporal(TemporalType.DATE)
@Column(name="data_inclusao")
	private Date dataInclusao;

	@Column(name="motivo")
	private String motivo;

	@OneToMany(mappedBy = "contabilEncerramentoExeCabModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContabilEncerramentoExeDetModel> contabilEncerramentoExeDetModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataInicio() { 
		return this.dataInicio; 
	} 

	public void setDataInicio(Date dataInicio) { 
		this.dataInicio = dataInicio; 
	} 

	public Date getDataFim() { 
		return this.dataFim; 
	} 

	public void setDataFim(Date dataFim) { 
		this.dataFim = dataFim; 
	} 

	public Date getDataInclusao() { 
		return this.dataInclusao; 
	} 

	public void setDataInclusao(Date dataInclusao) { 
		this.dataInclusao = dataInclusao; 
	} 

	public String getMotivo() { 
		return this.motivo; 
	} 

	public void setMotivo(String motivo) { 
		this.motivo = motivo; 
	} 

	public Set<ContabilEncerramentoExeDetModel> getContabilEncerramentoExeDetModelList() { 
	return this.contabilEncerramentoExeDetModelList; 
	} 

	public void setContabilEncerramentoExeDetModelList(Set<ContabilEncerramentoExeDetModel> contabilEncerramentoExeDetModelList) { 
	this.contabilEncerramentoExeDetModelList = contabilEncerramentoExeDetModelList; 
		for (ContabilEncerramentoExeDetModel contabilEncerramentoExeDetModel : contabilEncerramentoExeDetModelList) { 
			contabilEncerramentoExeDetModel.setContabilEncerramentoExeCabModel(this); 
		}
	} 

		
}