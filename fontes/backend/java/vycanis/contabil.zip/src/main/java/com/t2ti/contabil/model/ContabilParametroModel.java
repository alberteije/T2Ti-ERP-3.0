package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="contabil_parametro")
@NamedQuery(name="ContabilParametroModel.findAll", query="SELECT t FROM ContabilParametroModel t")
public class ContabilParametroModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilParametroModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="mascara")
	private String mascara;

	@Column(name="niveis")
	private Integer niveis;

	@Column(name="informar_conta_por")
	private String informarContaPor;

	@Column(name="compartilha_plano_conta")
	private String compartilhaPlanoConta;

	@Column(name="compartilha_historicos")
	private String compartilhaHistoricos;

	@Column(name="altera_lancamento_outro")
	private String alteraLancamentoOutro;

	@Column(name="historico_obrigatorio")
	private String historicoObrigatorio;

	@Column(name="permite_lancamento_zerado")
	private String permiteLancamentoZerado;

	@Column(name="gera_informativo_sped")
	private String geraInformativoSped;

	@Column(name="sped_forma_escrit_diario")
	private String spedFormaEscritDiario;

	@Column(name="sped_nome_livro_diario")
	private String spedNomeLivroDiario;

	@Column(name="assinatura_direita")
	private String assinaturaDireita;

	@Column(name="assinatura_esquerda")
	private String assinaturaEsquerda;

	@Column(name="conta_ativo")
	private String contaAtivo;

	@Column(name="conta_passivo")
	private String contaPassivo;

	@Column(name="conta_patrimonio_liquido")
	private String contaPatrimonioLiquido;

	@Column(name="conta_depreciacao_acumulada")
	private String contaDepreciacaoAcumulada;

	@Column(name="conta_capital_social")
	private String contaCapitalSocial;

	@Column(name="conta_resultado_exercicio")
	private String contaResultadoExercicio;

	@Column(name="conta_prejuizo_acumulado")
	private String contaPrejuizoAcumulado;

	@Column(name="conta_lucro_acumulado")
	private String contaLucroAcumulado;

	@Column(name="conta_titulo_pagar")
	private String contaTituloPagar;

	@Column(name="conta_titulo_receber")
	private String contaTituloReceber;

	@Column(name="conta_juros_passivo")
	private String contaJurosPassivo;

	@Column(name="conta_juros_ativo")
	private String contaJurosAtivo;

	@Column(name="conta_desconto_obtido")
	private String contaDescontoObtido;

	@Column(name="conta_desconto_concedido")
	private String contaDescontoConcedido;

	@Column(name="conta_cmv")
	private String contaCmv;

	@Column(name="conta_venda")
	private String contaVenda;

	@Column(name="conta_venda_servico")
	private String contaVendaServico;

	@Column(name="conta_estoque")
	private String contaEstoque;

	@Column(name="conta_apura_resultado")
	private String contaApuraResultado;

	@Column(name="conta_juros_apropriar")
	private String contaJurosApropriar;

	@Column(name="id_hist_padrao_resultado")
	private Integer idHistPadraoResultado;

	@Column(name="id_hist_padrao_lucro")
	private Integer idHistPadraoLucro;

	@Column(name="id_hist_padrao_prejuizo")
	private Integer idHistPadraoPrejuizo;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getMascara() { 
		return this.mascara; 
	} 

	public void setMascara(String mascara) { 
		this.mascara = mascara; 
	} 

	public Integer getNiveis() { 
		return this.niveis; 
	} 

	public void setNiveis(Integer niveis) { 
		this.niveis = niveis; 
	} 

	public String getInformarContaPor() { 
		return this.informarContaPor; 
	} 

	public void setInformarContaPor(String informarContaPor) { 
		this.informarContaPor = informarContaPor; 
	} 

	public String getCompartilhaPlanoConta() { 
		return this.compartilhaPlanoConta; 
	} 

	public void setCompartilhaPlanoConta(String compartilhaPlanoConta) { 
		this.compartilhaPlanoConta = compartilhaPlanoConta; 
	} 

	public String getCompartilhaHistoricos() { 
		return this.compartilhaHistoricos; 
	} 

	public void setCompartilhaHistoricos(String compartilhaHistoricos) { 
		this.compartilhaHistoricos = compartilhaHistoricos; 
	} 

	public String getAlteraLancamentoOutro() { 
		return this.alteraLancamentoOutro; 
	} 

	public void setAlteraLancamentoOutro(String alteraLancamentoOutro) { 
		this.alteraLancamentoOutro = alteraLancamentoOutro; 
	} 

	public String getHistoricoObrigatorio() { 
		return this.historicoObrigatorio; 
	} 

	public void setHistoricoObrigatorio(String historicoObrigatorio) { 
		this.historicoObrigatorio = historicoObrigatorio; 
	} 

	public String getPermiteLancamentoZerado() { 
		return this.permiteLancamentoZerado; 
	} 

	public void setPermiteLancamentoZerado(String permiteLancamentoZerado) { 
		this.permiteLancamentoZerado = permiteLancamentoZerado; 
	} 

	public String getGeraInformativoSped() { 
		return this.geraInformativoSped; 
	} 

	public void setGeraInformativoSped(String geraInformativoSped) { 
		this.geraInformativoSped = geraInformativoSped; 
	} 

	public String getSpedFormaEscritDiario() { 
		return this.spedFormaEscritDiario; 
	} 

	public void setSpedFormaEscritDiario(String spedFormaEscritDiario) { 
		this.spedFormaEscritDiario = spedFormaEscritDiario; 
	} 

	public String getSpedNomeLivroDiario() { 
		return this.spedNomeLivroDiario; 
	} 

	public void setSpedNomeLivroDiario(String spedNomeLivroDiario) { 
		this.spedNomeLivroDiario = spedNomeLivroDiario; 
	} 

	public String getAssinaturaDireita() { 
		return this.assinaturaDireita; 
	} 

	public void setAssinaturaDireita(String assinaturaDireita) { 
		this.assinaturaDireita = assinaturaDireita; 
	} 

	public String getAssinaturaEsquerda() { 
		return this.assinaturaEsquerda; 
	} 

	public void setAssinaturaEsquerda(String assinaturaEsquerda) { 
		this.assinaturaEsquerda = assinaturaEsquerda; 
	} 

	public String getContaAtivo() { 
		return this.contaAtivo; 
	} 

	public void setContaAtivo(String contaAtivo) { 
		this.contaAtivo = contaAtivo; 
	} 

	public String getContaPassivo() { 
		return this.contaPassivo; 
	} 

	public void setContaPassivo(String contaPassivo) { 
		this.contaPassivo = contaPassivo; 
	} 

	public String getContaPatrimonioLiquido() { 
		return this.contaPatrimonioLiquido; 
	} 

	public void setContaPatrimonioLiquido(String contaPatrimonioLiquido) { 
		this.contaPatrimonioLiquido = contaPatrimonioLiquido; 
	} 

	public String getContaDepreciacaoAcumulada() { 
		return this.contaDepreciacaoAcumulada; 
	} 

	public void setContaDepreciacaoAcumulada(String contaDepreciacaoAcumulada) { 
		this.contaDepreciacaoAcumulada = contaDepreciacaoAcumulada; 
	} 

	public String getContaCapitalSocial() { 
		return this.contaCapitalSocial; 
	} 

	public void setContaCapitalSocial(String contaCapitalSocial) { 
		this.contaCapitalSocial = contaCapitalSocial; 
	} 

	public String getContaResultadoExercicio() { 
		return this.contaResultadoExercicio; 
	} 

	public void setContaResultadoExercicio(String contaResultadoExercicio) { 
		this.contaResultadoExercicio = contaResultadoExercicio; 
	} 

	public String getContaPrejuizoAcumulado() { 
		return this.contaPrejuizoAcumulado; 
	} 

	public void setContaPrejuizoAcumulado(String contaPrejuizoAcumulado) { 
		this.contaPrejuizoAcumulado = contaPrejuizoAcumulado; 
	} 

	public String getContaLucroAcumulado() { 
		return this.contaLucroAcumulado; 
	} 

	public void setContaLucroAcumulado(String contaLucroAcumulado) { 
		this.contaLucroAcumulado = contaLucroAcumulado; 
	} 

	public String getContaTituloPagar() { 
		return this.contaTituloPagar; 
	} 

	public void setContaTituloPagar(String contaTituloPagar) { 
		this.contaTituloPagar = contaTituloPagar; 
	} 

	public String getContaTituloReceber() { 
		return this.contaTituloReceber; 
	} 

	public void setContaTituloReceber(String contaTituloReceber) { 
		this.contaTituloReceber = contaTituloReceber; 
	} 

	public String getContaJurosPassivo() { 
		return this.contaJurosPassivo; 
	} 

	public void setContaJurosPassivo(String contaJurosPassivo) { 
		this.contaJurosPassivo = contaJurosPassivo; 
	} 

	public String getContaJurosAtivo() { 
		return this.contaJurosAtivo; 
	} 

	public void setContaJurosAtivo(String contaJurosAtivo) { 
		this.contaJurosAtivo = contaJurosAtivo; 
	} 

	public String getContaDescontoObtido() { 
		return this.contaDescontoObtido; 
	} 

	public void setContaDescontoObtido(String contaDescontoObtido) { 
		this.contaDescontoObtido = contaDescontoObtido; 
	} 

	public String getContaDescontoConcedido() { 
		return this.contaDescontoConcedido; 
	} 

	public void setContaDescontoConcedido(String contaDescontoConcedido) { 
		this.contaDescontoConcedido = contaDescontoConcedido; 
	} 

	public String getContaCmv() { 
		return this.contaCmv; 
	} 

	public void setContaCmv(String contaCmv) { 
		this.contaCmv = contaCmv; 
	} 

	public String getContaVenda() { 
		return this.contaVenda; 
	} 

	public void setContaVenda(String contaVenda) { 
		this.contaVenda = contaVenda; 
	} 

	public String getContaVendaServico() { 
		return this.contaVendaServico; 
	} 

	public void setContaVendaServico(String contaVendaServico) { 
		this.contaVendaServico = contaVendaServico; 
	} 

	public String getContaEstoque() { 
		return this.contaEstoque; 
	} 

	public void setContaEstoque(String contaEstoque) { 
		this.contaEstoque = contaEstoque; 
	} 

	public String getContaApuraResultado() { 
		return this.contaApuraResultado; 
	} 

	public void setContaApuraResultado(String contaApuraResultado) { 
		this.contaApuraResultado = contaApuraResultado; 
	} 

	public String getContaJurosApropriar() { 
		return this.contaJurosApropriar; 
	} 

	public void setContaJurosApropriar(String contaJurosApropriar) { 
		this.contaJurosApropriar = contaJurosApropriar; 
	} 

	public Integer getIdHistPadraoResultado() { 
		return this.idHistPadraoResultado; 
	} 

	public void setIdHistPadraoResultado(Integer idHistPadraoResultado) { 
		this.idHistPadraoResultado = idHistPadraoResultado; 
	} 

	public Integer getIdHistPadraoLucro() { 
		return this.idHistPadraoLucro; 
	} 

	public void setIdHistPadraoLucro(Integer idHistPadraoLucro) { 
		this.idHistPadraoLucro = idHistPadraoLucro; 
	} 

	public Integer getIdHistPadraoPrejuizo() { 
		return this.idHistPadraoPrejuizo; 
	} 

	public void setIdHistPadraoPrejuizo(Integer idHistPadraoPrejuizo) { 
		this.idHistPadraoPrejuizo = idHistPadraoPrejuizo; 
	} 

		
}