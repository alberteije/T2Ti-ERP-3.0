package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_indice_valor")
@NamedQuery(name="ContabilIndiceValorModel.findAll", query="SELECT t FROM ContabilIndiceValorModel t")
public class ContabilIndiceValorModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilIndiceValorModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_indice")
	private Date dataIndice;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_contabil_indice")
	private ContabilIndiceModel contabilIndiceModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataIndice() { 
		return this.dataIndice; 
	} 

	public void setDataIndice(Date dataIndice) { 
		this.dataIndice = dataIndice; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public ContabilIndiceModel getContabilIndiceModel() { 
	return this.contabilIndiceModel; 
	} 

	public void setContabilIndiceModel(ContabilIndiceModel contabilIndiceModel) { 
	this.contabilIndiceModel = contabilIndiceModel; 
	} 

		
}