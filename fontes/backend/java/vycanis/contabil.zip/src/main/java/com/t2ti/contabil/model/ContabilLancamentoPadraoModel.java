package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="contabil_lancamento_padrao")
@NamedQuery(name="ContabilLancamentoPadraoModel.findAll", query="SELECT t FROM ContabilLancamentoPadraoModel t")
public class ContabilLancamentoPadraoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilLancamentoPadraoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Column(name="historico")
	private String historico;

	@Column(name="id_conta_debito")
	private Integer idContaDebito;

	@Column(name="id_conta_credito")
	private Integer idContaCredito;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getHistorico() { 
		return this.historico; 
	} 

	public void setHistorico(String historico) { 
		this.historico = historico; 
	} 

	public Integer getIdContaDebito() { 
		return this.idContaDebito; 
	} 

	public void setIdContaDebito(Integer idContaDebito) { 
		this.idContaDebito = idContaDebito; 
	} 

	public Integer getIdContaCredito() { 
		return this.idContaCredito; 
	} 

	public void setIdContaCredito(Integer idContaCredito) { 
		this.idContaCredito = idContaCredito; 
	} 

		
}