package com.t2ti.contabil.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.contabil.model.ContabilFechamentoModel;

public interface ContabilFechamentoRepository extends JpaRepository<ContabilFechamentoModel, Integer> {}