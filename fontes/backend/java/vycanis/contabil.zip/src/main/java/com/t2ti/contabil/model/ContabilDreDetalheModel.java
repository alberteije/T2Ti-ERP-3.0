package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_dre_detalhe")
@NamedQuery(name="ContabilDreDetalheModel.findAll", query="SELECT t FROM ContabilDreDetalheModel t")
public class ContabilDreDetalheModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilDreDetalheModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="classificacao")
	private String classificacao;

	@Column(name="descricao")
	private String descricao;

	@Column(name="forma_calculo")
	private String formaCalculo;

	@Column(name="sinal")
	private String sinal;

	@Column(name="natureza")
	private String natureza;

	@Column(name="valor")
	private BigDecimal valor;

	@ManyToOne 
	@JsonIgnore 
	@JoinColumn(name="id_contabil_dre_cabecalho")
	private ContabilDreCabecalhoModel contabilDreCabecalhoModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getClassificacao() { 
		return this.classificacao; 
	} 

	public void setClassificacao(String classificacao) { 
		this.classificacao = classificacao; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getFormaCalculo() { 
		return this.formaCalculo; 
	} 

	public void setFormaCalculo(String formaCalculo) { 
		this.formaCalculo = formaCalculo; 
	} 

	public String getSinal() { 
		return this.sinal; 
	} 

	public void setSinal(String sinal) { 
		this.sinal = sinal; 
	} 

	public String getNatureza() { 
		return this.natureza; 
	} 

	public void setNatureza(String natureza) { 
		this.natureza = natureza; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public ContabilDreCabecalhoModel getContabilDreCabecalhoModel() { 
	return this.contabilDreCabecalhoModel; 
	} 

	public void setContabilDreCabecalhoModel(ContabilDreCabecalhoModel contabilDreCabecalhoModel) { 
	this.contabilDreCabecalhoModel = contabilDreCabecalhoModel; 
	} 

		
}