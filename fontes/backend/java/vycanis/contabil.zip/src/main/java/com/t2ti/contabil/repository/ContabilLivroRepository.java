package com.t2ti.contabil.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.contabil.model.ContabilLivroModel;

public interface ContabilLivroRepository extends JpaRepository<ContabilLivroModel, Integer> {}