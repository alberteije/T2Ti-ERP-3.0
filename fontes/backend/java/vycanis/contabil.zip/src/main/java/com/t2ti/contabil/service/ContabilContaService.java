package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilContaModel;
import com.t2ti.contabil.repository.ContabilContaRepository;

@Service
public class ContabilContaService {

	@Autowired
	private ContabilContaRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilContaModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilContaModel> getList(Filter filter) {
		String sql = "select * from contabil_conta where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilContaModel.class);
		return query.getResultList();
	}

	public ContabilContaModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilContaModel save(ContabilContaModel obj) {
		ContabilContaModel contabilContaModel = repository.save(obj);
		return contabilContaModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilContaModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilConta] - Exception: " + e.getMessage());
		}
	}

}