package com.t2ti.contabil.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.contabil.model.LancaCentroResultadoModel;

public interface LancaCentroResultadoRepository extends JpaRepository<LancaCentroResultadoModel, Integer> {}