package com.t2ti.contabil.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.contabil.model.RateioCentroResultadoCabModel;

public interface RateioCentroResultadoCabRepository extends JpaRepository<RateioCentroResultadoCabModel, Integer> {}