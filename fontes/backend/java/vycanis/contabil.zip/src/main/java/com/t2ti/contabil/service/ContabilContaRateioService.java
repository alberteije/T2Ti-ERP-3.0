package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilContaRateioModel;
import com.t2ti.contabil.repository.ContabilContaRateioRepository;

@Service
public class ContabilContaRateioService {

	@Autowired
	private ContabilContaRateioRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilContaRateioModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilContaRateioModel> getList(Filter filter) {
		String sql = "select * from contabil_conta_rateio where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilContaRateioModel.class);
		return query.getResultList();
	}

	public ContabilContaRateioModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilContaRateioModel save(ContabilContaRateioModel obj) {
		ContabilContaRateioModel contabilContaRateioModel = repository.save(obj);
		return contabilContaRateioModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilContaRateioModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilContaRateio] - Exception: " + e.getMessage());
		}
	}

}