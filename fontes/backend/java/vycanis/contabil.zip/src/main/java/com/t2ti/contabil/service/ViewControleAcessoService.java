package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ViewControleAcessoModel;
import com.t2ti.contabil.repository.ViewControleAcessoRepository;

@Service
public class ViewControleAcessoService {

	@Autowired
	private ViewControleAcessoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ViewControleAcessoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ViewControleAcessoModel> getList(Filter filter) {
		String sql = "select * from view_controle_acesso where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ViewControleAcessoModel.class);
		return query.getResultList();
	}

	public ViewControleAcessoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ViewControleAcessoModel save(ViewControleAcessoModel obj) {
		ViewControleAcessoModel viewControleAcessoModel = repository.save(obj);
		return viewControleAcessoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ViewControleAcessoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ViewControleAcesso] - Exception: " + e.getMessage());
		}
	}

}