package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilLancamentoCabecalhoModel;
import com.t2ti.contabil.repository.ContabilLancamentoCabecalhoRepository;

@Service
public class ContabilLancamentoCabecalhoService {

	@Autowired
	private ContabilLancamentoCabecalhoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilLancamentoCabecalhoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilLancamentoCabecalhoModel> getList(Filter filter) {
		String sql = "select * from contabil_lancamento_cabecalho where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilLancamentoCabecalhoModel.class);
		return query.getResultList();
	}

	public ContabilLancamentoCabecalhoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilLancamentoCabecalhoModel save(ContabilLancamentoCabecalhoModel obj) {
		ContabilLancamentoCabecalhoModel contabilLancamentoCabecalhoModel = repository.save(obj);
		return contabilLancamentoCabecalhoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilLancamentoCabecalhoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilLancamentoCabecalho] - Exception: " + e.getMessage());
		}
	}

}