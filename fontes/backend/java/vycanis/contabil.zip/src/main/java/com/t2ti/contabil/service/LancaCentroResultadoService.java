package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.LancaCentroResultadoModel;
import com.t2ti.contabil.repository.LancaCentroResultadoRepository;

@Service
public class LancaCentroResultadoService {

	@Autowired
	private LancaCentroResultadoRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<LancaCentroResultadoModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<LancaCentroResultadoModel> getList(Filter filter) {
		String sql = "select * from lanca_centro_resultado where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, LancaCentroResultadoModel.class);
		return query.getResultList();
	}

	public LancaCentroResultadoModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public LancaCentroResultadoModel save(LancaCentroResultadoModel obj) {
		LancaCentroResultadoModel lancaCentroResultadoModel = repository.save(obj);
		return lancaCentroResultadoModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		LancaCentroResultadoModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete LancaCentroResultado] - Exception: " + e.getMessage());
		}
	}

}