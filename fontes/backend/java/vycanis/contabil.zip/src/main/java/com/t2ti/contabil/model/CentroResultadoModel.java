package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="centro_resultado")
@NamedQuery(name="CentroResultadoModel.findAll", query="SELECT t FROM CentroResultadoModel t")
public class CentroResultadoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public CentroResultadoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Column(name="classificacao")
	private String classificacao;

	@Column(name="sofre_rateiro")
	private String sofreRateiro;

	@ManyToOne 
	@JoinColumn(name="id_plano_centro_resultado")
	private PlanoCentroResultadoModel planoCentroResultadoModel; 

	@OneToMany(mappedBy = "centroResultadoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<CtResultadoNtFinanceiraModel> ctResultadoNtFinanceiraModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getClassificacao() { 
		return this.classificacao; 
	} 

	public void setClassificacao(String classificacao) { 
		this.classificacao = classificacao; 
	} 

	public String getSofreRateiro() { 
		return this.sofreRateiro; 
	} 

	public void setSofreRateiro(String sofreRateiro) { 
		this.sofreRateiro = sofreRateiro; 
	} 

	public PlanoCentroResultadoModel getPlanoCentroResultadoModel() { 
	return this.planoCentroResultadoModel; 
	} 

	public void setPlanoCentroResultadoModel(PlanoCentroResultadoModel planoCentroResultadoModel) { 
	this.planoCentroResultadoModel = planoCentroResultadoModel; 
	} 

	public Set<CtResultadoNtFinanceiraModel> getCtResultadoNtFinanceiraModelList() { 
	return this.ctResultadoNtFinanceiraModelList; 
	} 

	public void setCtResultadoNtFinanceiraModelList(Set<CtResultadoNtFinanceiraModel> ctResultadoNtFinanceiraModelList) { 
	this.ctResultadoNtFinanceiraModelList = ctResultadoNtFinanceiraModelList; 
		for (CtResultadoNtFinanceiraModel ctResultadoNtFinanceiraModel : ctResultadoNtFinanceiraModelList) { 
			ctResultadoNtFinanceiraModel.setCentroResultadoModel(this); 
		}
	} 

		
}