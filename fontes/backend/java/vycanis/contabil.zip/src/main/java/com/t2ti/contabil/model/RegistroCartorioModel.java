package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="registro_cartorio")
@NamedQuery(name="RegistroCartorioModel.findAll", query="SELECT t FROM RegistroCartorioModel t")
public class RegistroCartorioModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public RegistroCartorioModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="nome_cartorio")
	private String nomeCartorio;

	@Temporal(TemporalType.DATE)
@Column(name="data_registro")
	private Date dataRegistro;

	@Column(name="numero")
	private Integer numero;

	@Column(name="folha")
	private Integer folha;

	@Column(name="livro")
	private Integer livro;

	@Column(name="nire")
	private String nire;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getNomeCartorio() { 
		return this.nomeCartorio; 
	} 

	public void setNomeCartorio(String nomeCartorio) { 
		this.nomeCartorio = nomeCartorio; 
	} 

	public Date getDataRegistro() { 
		return this.dataRegistro; 
	} 

	public void setDataRegistro(Date dataRegistro) { 
		this.dataRegistro = dataRegistro; 
	} 

	public Integer getNumero() { 
		return this.numero; 
	} 

	public void setNumero(Integer numero) { 
		this.numero = numero; 
	} 

	public Integer getFolha() { 
		return this.folha; 
	} 

	public void setFolha(Integer folha) { 
		this.folha = folha; 
	} 

	public Integer getLivro() { 
		return this.livro; 
	} 

	public void setLivro(Integer livro) { 
		this.livro = livro; 
	} 

	public String getNire() { 
		return this.nire; 
	} 

	public void setNire(String nire) { 
		this.nire = nire; 
	} 

		
}