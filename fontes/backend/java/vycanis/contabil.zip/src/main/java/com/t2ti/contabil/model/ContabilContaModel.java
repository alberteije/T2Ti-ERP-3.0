package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_conta")
@NamedQuery(name="ContabilContaModel.findAll", query="SELECT t FROM ContabilContaModel t")
public class ContabilContaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilContaModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="id_contabil_conta")
	private Integer idContabilConta;

	@Column(name="classificacao")
	private String classificacao;

	@Column(name="tipo")
	private String tipo;

	@Column(name="descricao")
	private String descricao;

	@Temporal(TemporalType.DATE)
@Column(name="data_inclusao")
	private Date dataInclusao;

	@Column(name="situacao")
	private String situacao;

	@Column(name="natureza")
	private String natureza;

	@Column(name="patrimonio_resultado")
	private String patrimonioResultado;

	@Column(name="livro_caixa")
	private String livroCaixa;

	@Column(name="dfc")
	private String dfc;

	@Column(name="codigo_efd")
	private String codigoEfd;

	@Column(name="ordem")
	private String ordem;

	@Column(name="codigo_reduzido")
	private String codigoReduzido;

	@ManyToOne 
	@JoinColumn(name="id_plano_conta")
	private PlanoContaModel planoContaModel; 

	@ManyToOne 
	@JoinColumn(name="id_plano_conta_ref_sped")
	private PlanoContaRefSpedModel planoContaRefSpedModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Integer getIdContabilConta() { 
		return this.idContabilConta; 
	} 

	public void setIdContabilConta(Integer idContabilConta) { 
		this.idContabilConta = idContabilConta; 
	} 

	public String getClassificacao() { 
		return this.classificacao; 
	} 

	public void setClassificacao(String classificacao) { 
		this.classificacao = classificacao; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public Date getDataInclusao() { 
		return this.dataInclusao; 
	} 

	public void setDataInclusao(Date dataInclusao) { 
		this.dataInclusao = dataInclusao; 
	} 

	public String getSituacao() { 
		return this.situacao; 
	} 

	public void setSituacao(String situacao) { 
		this.situacao = situacao; 
	} 

	public String getNatureza() { 
		return this.natureza; 
	} 

	public void setNatureza(String natureza) { 
		this.natureza = natureza; 
	} 

	public String getPatrimonioResultado() { 
		return this.patrimonioResultado; 
	} 

	public void setPatrimonioResultado(String patrimonioResultado) { 
		this.patrimonioResultado = patrimonioResultado; 
	} 

	public String getLivroCaixa() { 
		return this.livroCaixa; 
	} 

	public void setLivroCaixa(String livroCaixa) { 
		this.livroCaixa = livroCaixa; 
	} 

	public String getDfc() { 
		return this.dfc; 
	} 

	public void setDfc(String dfc) { 
		this.dfc = dfc; 
	} 

	public String getCodigoEfd() { 
		return this.codigoEfd; 
	} 

	public void setCodigoEfd(String codigoEfd) { 
		this.codigoEfd = codigoEfd; 
	} 

	public String getOrdem() { 
		return this.ordem; 
	} 

	public void setOrdem(String ordem) { 
		this.ordem = ordem; 
	} 

	public String getCodigoReduzido() { 
		return this.codigoReduzido; 
	} 

	public void setCodigoReduzido(String codigoReduzido) { 
		this.codigoReduzido = codigoReduzido; 
	} 

	public PlanoContaModel getPlanoContaModel() { 
	return this.planoContaModel; 
	} 

	public void setPlanoContaModel(PlanoContaModel planoContaModel) { 
	this.planoContaModel = planoContaModel; 
	} 

	public PlanoContaRefSpedModel getPlanoContaRefSpedModel() { 
	return this.planoContaRefSpedModel; 
	} 

	public void setPlanoContaRefSpedModel(PlanoContaRefSpedModel planoContaRefSpedModel) { 
	this.planoContaRefSpedModel = planoContaRefSpedModel; 
	} 

		
}