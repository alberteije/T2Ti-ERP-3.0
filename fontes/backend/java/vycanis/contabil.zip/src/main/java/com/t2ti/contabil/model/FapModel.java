package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;

@Entity
@Table(name="fap")
@NamedQuery(name="FapModel.findAll", query="SELECT t FROM FapModel t")
public class FapModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public FapModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="fap")
	private BigDecimal fap;

	@Temporal(TemporalType.DATE)
@Column(name="data_inicial")
	private Date dataInicial;

	@Temporal(TemporalType.DATE)
@Column(name="data_final")
	private Date dataFinal;


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public BigDecimal getFap() { 
		return this.fap; 
	} 

	public void setFap(BigDecimal fap) { 
		this.fap = fap; 
	} 

	public Date getDataInicial() { 
		return this.dataInicial; 
	} 

	public void setDataInicial(Date dataInicial) { 
		this.dataInicial = dataInicial; 
	} 

	public Date getDataFinal() { 
		return this.dataFinal; 
	} 

	public void setDataFinal(Date dataFinal) { 
		this.dataFinal = dataFinal; 
	} 

		
}