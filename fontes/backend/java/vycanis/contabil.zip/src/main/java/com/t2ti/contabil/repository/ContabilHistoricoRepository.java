package com.t2ti.contabil.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2ti.contabil.model.ContabilHistoricoModel;

public interface ContabilHistoricoRepository extends JpaRepository<ContabilHistoricoModel, Integer> {}