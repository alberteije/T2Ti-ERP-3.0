package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Date;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.math.BigDecimal;
import jakarta.persistence.ManyToOne;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="contabil_lancamento_cabecalho")
@NamedQuery(name="ContabilLancamentoCabecalhoModel.findAll", query="SELECT t FROM ContabilLancamentoCabecalhoModel t")
public class ContabilLancamentoCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilLancamentoCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Temporal(TemporalType.DATE)
@Column(name="data_lancamento")
	private Date dataLancamento;

	@Temporal(TemporalType.DATE)
@Column(name="data_inclusao")
	private Date dataInclusao;

	@Column(name="tipo")
	private String tipo;

	@Column(name="liberado")
	private String liberado;

	@Column(name="valor")
	private BigDecimal valor;

	@OneToMany(mappedBy = "contabilLancamentoCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContabilLancamentoDetalheModel> contabilLancamentoDetalheModelList; 

	@ManyToOne 
	@JoinColumn(name="id_contabil_lote")
	private ContabilLoteModel contabilLoteModel; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public Date getDataLancamento() { 
		return this.dataLancamento; 
	} 

	public void setDataLancamento(Date dataLancamento) { 
		this.dataLancamento = dataLancamento; 
	} 

	public Date getDataInclusao() { 
		return this.dataInclusao; 
	} 

	public void setDataInclusao(Date dataInclusao) { 
		this.dataInclusao = dataInclusao; 
	} 

	public String getTipo() { 
		return this.tipo; 
	} 

	public void setTipo(String tipo) { 
		this.tipo = tipo; 
	} 

	public String getLiberado() { 
		return this.liberado; 
	} 

	public void setLiberado(String liberado) { 
		this.liberado = liberado; 
	} 

	public BigDecimal getValor() { 
		return this.valor; 
	} 

	public void setValor(BigDecimal valor) { 
		this.valor = valor; 
	} 

	public Set<ContabilLancamentoDetalheModel> getContabilLancamentoDetalheModelList() { 
	return this.contabilLancamentoDetalheModelList; 
	} 

	public void setContabilLancamentoDetalheModelList(Set<ContabilLancamentoDetalheModel> contabilLancamentoDetalheModelList) { 
	this.contabilLancamentoDetalheModelList = contabilLancamentoDetalheModelList; 
		for (ContabilLancamentoDetalheModel contabilLancamentoDetalheModel : contabilLancamentoDetalheModelList) { 
			contabilLancamentoDetalheModel.setContabilLancamentoCabecalhoModel(this); 
		}
	} 

	public ContabilLoteModel getContabilLoteModel() { 
	return this.contabilLoteModel; 
	} 

	public void setContabilLoteModel(ContabilLoteModel contabilLoteModel) { 
	this.contabilLoteModel = contabilLoteModel; 
	} 

		
}