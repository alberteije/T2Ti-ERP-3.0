package com.t2ti.contabil.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import java.util.Set;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
@Table(name="contabil_dre_cabecalho")
@NamedQuery(name="ContabilDreCabecalhoModel.findAll", query="SELECT t FROM ContabilDreCabecalhoModel t")
public class ContabilDreCabecalhoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	public ContabilDreCabecalhoModel() {
		//standard constructor
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer id;

	@Column(name="descricao")
	private String descricao;

	@Column(name="padrao")
	private String padrao;

	@Column(name="periodo_inicial")
	private String periodoInicial;

	@Column(name="periodo_final")
	private String periodoFinal;

	@OneToMany(mappedBy = "contabilDreCabecalhoModel", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ContabilDreDetalheModel> contabilDreDetalheModelList; 


	public Integer getId() { 
		return this.id; 
	} 

	public void setId(Integer id) { 
		this.id = id; 
	} 

	public String getDescricao() { 
		return this.descricao; 
	} 

	public void setDescricao(String descricao) { 
		this.descricao = descricao; 
	} 

	public String getPadrao() { 
		return this.padrao; 
	} 

	public void setPadrao(String padrao) { 
		this.padrao = padrao; 
	} 

	public String getPeriodoInicial() { 
		return this.periodoInicial; 
	} 

	public void setPeriodoInicial(String periodoInicial) { 
		this.periodoInicial = periodoInicial; 
	} 

	public String getPeriodoFinal() { 
		return this.periodoFinal; 
	} 

	public void setPeriodoFinal(String periodoFinal) { 
		this.periodoFinal = periodoFinal; 
	} 

	public Set<ContabilDreDetalheModel> getContabilDreDetalheModelList() { 
	return this.contabilDreDetalheModelList; 
	} 

	public void setContabilDreDetalheModelList(Set<ContabilDreDetalheModel> contabilDreDetalheModelList) { 
	this.contabilDreDetalheModelList = contabilDreDetalheModelList; 
		for (ContabilDreDetalheModel contabilDreDetalheModel : contabilDreDetalheModelList) { 
			contabilDreDetalheModel.setContabilDreCabecalhoModel(this); 
		}
	} 

		
}