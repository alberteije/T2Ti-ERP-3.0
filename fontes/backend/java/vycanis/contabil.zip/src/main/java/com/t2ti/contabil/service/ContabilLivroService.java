package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilLivroModel;
import com.t2ti.contabil.repository.ContabilLivroRepository;

@Service
public class ContabilLivroService {

	@Autowired
	private ContabilLivroRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilLivroModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilLivroModel> getList(Filter filter) {
		String sql = "select * from contabil_livro where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilLivroModel.class);
		return query.getResultList();
	}

	public ContabilLivroModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilLivroModel save(ContabilLivroModel obj) {
		ContabilLivroModel contabilLivroModel = repository.save(obj);
		return contabilLivroModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilLivroModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilLivro] - Exception: " + e.getMessage());
		}
	}

}