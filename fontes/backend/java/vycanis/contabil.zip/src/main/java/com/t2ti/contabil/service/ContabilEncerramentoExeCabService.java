package com.t2ti.contabil.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.t2ti.contabil.util.Filter;
import com.t2ti.contabil.exception.GenericException;
import com.t2ti.contabil.model.ContabilEncerramentoExeCabModel;
import com.t2ti.contabil.repository.ContabilEncerramentoExeCabRepository;

@Service
public class ContabilEncerramentoExeCabService {

	@Autowired
	private ContabilEncerramentoExeCabRepository repository;
	@PersistenceContext
	private EntityManager entityManager;

	public List<ContabilEncerramentoExeCabModel> getList() {
		return repository.findAll();
	}

	@SuppressWarnings("unchecked")
	public List<ContabilEncerramentoExeCabModel> getList(Filter filter) {
		String sql = "select * from contabil_encerramento_exe_cab where " + filter.getWhere();
		Query query = entityManager.createNativeQuery(sql, ContabilEncerramentoExeCabModel.class);
		return query.getResultList();
	}

	public ContabilEncerramentoExeCabModel getObject(Integer id) {
		return repository.findById(id).get();
	}

	public ContabilEncerramentoExeCabModel save(ContabilEncerramentoExeCabModel obj) {
		ContabilEncerramentoExeCabModel contabilEncerramentoExeCabModel = repository.save(obj);
		return contabilEncerramentoExeCabModel;
	}

	
	@Transactional
	public void delete(Integer id) {
		ContabilEncerramentoExeCabModel obj = getObject(id);
		entityManager.joinTransaction();
		try {
			repository.delete(obj);
		} catch (Exception e) {
			throw new GenericException("Error [Delete ContabilEncerramentoExeCab] - Exception: " + e.getMessage());
		}
	}

}