unit ServiceBase;

interface

uses
  System.SysUtils, UDataModuleDBConnection, MVCFramework.Serializer.Commons,
  FireDAC.Comp.Client, Rtti;

type

  TServiceBase = class
  public
    class procedure Commit;
    class procedure Rollback;
    class procedure StartTransaction;
    class var FDataModuleConnection: TFDataModuleDBConnection;
    class function GetDataModuleConnection: TFDataModuleDBConnection;
    class function GetQuery(ASQL: string): TFDQuery;
    class function InsertBase(AObject: TObject; ATable: string): Integer;
    class function UpdateBase(AObject: TObject; ATable: string): Integer;
    class function DeleteBase(AId: Integer; ATable: string): Integer;
    class function DeleteBaseFilter(ATable: string; AFilter: string): Integer;
    class function DeleteChild(AId: Integer; ATable: string; AField: string): Integer;
    class function ExecuteQuery(AQuery: string): Integer;
  end;

var
  Query: TFDQuery;
  UpdateSQL: TFDUpdateSQL;

implementation

{ TServiceBase }

class function TServiceBase.GetDataModuleConnection: TFDataModuleDBConnection;
begin
  if not Assigned(FDataModuleConnection) then
    FDataModuleConnection := TFDataModuleDBConnection.Create(nil);
  Result := FDataModuleConnection;
end;

class function TServiceBase.GetQuery(ASQL: string): TFDQuery;
begin
  try
    Query := TFDQuery.Create(nil);
    Query.Connection := GetDataModuleConnection.Connection;
    Query.Open(ASQL);
    Result := Query;
  except
    on E: Exception do
    begin
    end
    else
      raise;
  end;
end;

class function TServiceBase.InsertBase(AObject: TObject; ATable: string): Integer;
var
  Context: TRttiContext;
  RttiType: TRttiType;
  RttiProperty: TRttiProperty;
  RttiAttribute: TCustomAttribute;
  SQLStatement, SQLFields, SQLValues: string;
  LastID: Integer;
  TypeName: string;
begin
  try
    Context := TRttiContext.Create;
    RttiType := Context.GetType(AObject.ClassType);

    // starts with the table name
    SQLStatement := 'INSERT INTO ' + ATable;

    // fills in the field names and valuesvalores
    for RttiProperty in RttiType.GetProperties do
    begin
      for RttiAttribute in RttiProperty.GetAttributes do
      begin
        if RttiAttribute is MVCColumnAttribute then
        begin
          if (RttiProperty.PropertyType.TypeKind in [tkInteger, tkInt64]) then
          begin
            if (RttiProperty.GetValue(AObject).AsInteger <> 0) then
            begin
              SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ',';
              SQLValues := SQLValues + RttiProperty.GetValue(AObject).ToString + ',';
            end;
          end
          else if (RttiProperty.PropertyType.TypeKind in [tkstring, tkUstring]) then
          begin
            if (RttiProperty.GetValue(AObject).Asstring <> '') then
            begin
              SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ',';
              SQLValues := SQLValues + QuotedStr(RttiProperty.GetValue(AObject).ToString) + ',';
            end;
          end
          else if (RttiProperty.PropertyType.TypeKind = tkFloat) then
          begin
            TypeName := LowerCase(RttiProperty.PropertyType.Name);
            if TypeName = 'tdatetime' then
            begin
              SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ',';

              if RttiProperty.GetValue(AObject).AsExtended > 0 then
                SQLValues := SQLValues + QuotedStr(FormatDateTime('yyyy-mm-dd', RttiProperty.GetValue(AObject).AsExtended)) + ','
              else
                SQLValues := SQLValues + 'null,';
            end
            else
            begin
              SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ',';
              SQLValues := SQLValues + QuotedStr(FormatFloat('0.000000', RttiProperty.GetValue(AObject).AsExtended)) + ',';
            end;
          end
          else
          begin
            SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ',';
            SQLValues := SQLValues + QuotedStr(RttiProperty.GetValue(AObject).ToString) + ',';
          end;
        end;
      end;
    end;

    // removing the leftover commas at the end
    Delete(SQLFields, Length(SQLFields), 1);
    Delete(SQLValues, Length(SQLValues), 1);

    SQLStatement := SQLStatement + '(' + SQLFields + ') VALUES (' + SQLValues + ')';

    if GetDataModuleConnection.Connection.DriverName = 'FB' then //firebird
    begin
      SQLStatement := SQLStatement + ' RETURNING ID ';
    end;

    Query := TFDQuery.Create(nil);
    try
      Query.Connection := GetDataModuleConnection.Connection;
      Query.sql.Text := SQLStatement;

      LastID := 0;
      if GetDataModuleConnection.Connection.DriverName = 'MySQL' then
      begin
        Query.ExecSQL();
        Query.sql.Text := 'select LAST_INSERT_ID() as id';
        Query.Open();
        LastID := Query.FieldByName('id').AsInteger;
      end
      else if GetDataModuleConnection.Connection.DriverName = 'Firebird' then
      begin
        Query.Open;
        LastID := Query.Fields[0].AsInteger;
      end;
    finally
      Query.Close;
      Query.Free;
    end;

    Result := LastID;
  finally
    Context.Free;
  end;
end;

class function TServiceBase.UpdateBase(AObject: TObject; ATable: string): Integer;
var
  Context: TRttiContext;
  RttiType: TRttiType;
  RttiProperty: TRttiProperty;
  RttiAttribute: TCustomAttribute;
  SQLStatement, SQLFields, SQLFilter: string;
  TypeName: string;
begin
  try
    Context := TRttiContext.Create;
    RttiType := Context.GetType(AObject.ClassType);

    // starts with the table name
    SQLStatement := 'UPDATE ' + ATable + ' SET ';

    // fills in the field names and filter
    for RttiProperty in RttiType.GetProperties do
    begin
      for RttiAttribute in RttiProperty.GetAttributes do
      begin
        if RttiAttribute is MVCColumnAttribute then
        begin
          if not (RttiAttribute as MVCColumnAttribute).IsPK then // if it's not the primary key
          begin
            if (RttiProperty.PropertyType.TypeKind in [tkInteger, tkInt64]) then
            begin
              if (RttiProperty.GetValue(AObject).AsInteger <> 0) then
                SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + RttiProperty.GetValue(AObject).ToString + ','
              else
                SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + 'null' + ',';
            end

            else if (RttiProperty.PropertyType.TypeKind in [tkString, tkUString]) then
            begin
              if (RttiProperty.GetValue(AObject).AsString <> '') then
                SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + QuotedStr(RttiProperty.GetValue(AObject).ToString) + ','
              else
                SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + 'null' + ',';
            end

            else if (RttiProperty.PropertyType.TypeKind = tkFloat) then
            begin
              if RttiProperty.GetValue(AObject).AsExtended <> 0 then
              begin
                TypeName := LowerCase(RttiProperty.PropertyType.Name);
                if TypeName = 'tdatetime' then
                  SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + QuotedStr(FormatDateTime('yyyy-mm-dd', RttiProperty.GetValue(AObject).AsExtended)) + ','
                else
                  SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + QuotedStr(FormatFloat('0.000000', RttiProperty.GetValue(AObject).AsExtended)) + ',';
              end
            end

            else if RttiProperty.GetValue(AObject).ToString <> '' then
              SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + QuotedStr(RttiProperty.GetValue(AObject).ToString) + ','
            else
              SQLFields := SQLFields + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + 'null' + ',';
          end
          else // if it's the primary key
          begin
            SQLFilter := ' WHERE ' + (RttiAttribute as MVCColumnAttribute).FieldName + ' = ' + QuotedStr(RttiProperty.GetValue(AObject).ToString);
          end;
        end;
      end;
    end;

    // removing the leftover commas at the end
    Delete(SQLFields, Length(SQLFields), 1);

    SQLStatement := SQLStatement + SQLFields + SQLFilter;

    Query := TFDQuery.Create(nil);
    Query.Connection := GetDataModuleConnection.Connection;
    Query.sql.Text := SQLStatement;
    Query.ExecSQL;
    Result := Query.RowsAffected;
  finally
    Context.Free;
    FreeAndNil(Query);
  end;
end;

class function TServiceBase.DeleteBase(AId: Integer; ATable: string): Integer;
var
  SQLStatement, SQLFilter: string;
begin
  try
    SQLStatement := 'DELETE FROM ' + ATable;
    SQLFilter := ' WHERE ID = ' + AId.ToString;
    SQLStatement := SQLStatement + SQLFilter;

    Query := TFDQuery.Create(nil);
    Query.Connection := GetDataModuleConnection.Connection;
    Query.sql.Text := SQLStatement;
    Query.ExecSQL;
    Result := Query.RowsAffected;
  finally
    FreeAndNil(Query);
  end;
end;

class function TServiceBase.DeleteBaseFilter(ATable: string; AFilter: string): Integer;
var
  SQLStatement, SQLFilter: string;
begin
  try
    SQLStatement := 'DELETE FROM ' + ATable;
    SQLFilter := ' WHERE ' + AFilter;
    SQLStatement := SQLStatement + SQLFilter;

    Query := TFDQuery.Create(nil);
    Query.Connection := GetDataModuleConnection.Connection;
    Query.sql.Text := SQLStatement;
    Query.ExecSQL;
    Result := Query.RowsAffected;
  finally
    FreeAndNil(Query);
  end;
end;

class function TServiceBase.DeleteChild(AId: Integer; ATable, AField: string): Integer;
var
  SQLStatement, SQLFilter: string;
begin
  try
    SQLStatement := 'DELETE FROM ' + ATable;
    SQLFilter := ' WHERE ' + AField + ' = ' + AId.ToString;
    SQLStatement := SQLStatement + SQLFilter;

    Query := TFDQuery.Create(nil);
    Query.Connection := GetDataModuleConnection.Connection;
    Query.sql.Text := SQLStatement;
    Query.ExecSQL;
    Result := Query.RowsAffected;
  finally
    FreeAndNil(Query);
  end;
end;

class function TServiceBase.ExecuteQuery(AQuery: string): Integer;
var
  SQLStatement, SQLFilter: string;
begin
  try
    Query := TFDQuery.Create(nil);
    Query.Connection := GetDataModuleConnection.Connection;
    Query.sql.Text := AQuery;
    Query.ExecSQL;
    Result := Query.RowsAffected;
  finally
    FreeAndNil(Query);
  end;
end;

class procedure TServiceBase.Commit;
begin
  GetDataModuleConnection.Connection.Commit;
end;

class procedure TServiceBase.Rollback;
begin
  GetDataModuleConnection.Connection.Rollback;
end;

class procedure TServiceBase.StartTransaction;
begin
  GetDataModuleConnection.Connection.StartTransaction;
end;

end.
