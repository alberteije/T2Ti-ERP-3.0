﻿unit GuiasAcumuladasService;

interface

uses
  GuiasAcumuladasModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TGuiasAcumuladasService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AGuiasAcumuladasModelList: TObjectList<TGuiasAcumuladasModel>); overload;
    class procedure AttachLinkedObjects(AGuiasAcumuladasModel: TGuiasAcumuladasModel); overload;
    class procedure InsertChildren(AGuiasAcumuladasModel: TGuiasAcumuladasModel);
    class procedure DeleteChildren(AGuiasAcumuladasModel: TGuiasAcumuladasModel);		
  public
    class function GetList: TObjectList<TGuiasAcumuladasModel>;
    class function GetListFilter(AWhere: string): TObjectList<TGuiasAcumuladasModel>;
    class function GetObject(APk: Integer): TGuiasAcumuladasModel;
    class procedure Insert(AGuiasAcumuladasModel: TGuiasAcumuladasModel);
    class function Update(AGuiasAcumuladasModel: TGuiasAcumuladasModel): Integer;
    class function Delete(AGuiasAcumuladasModel: TGuiasAcumuladasModel): Integer;
  end;

var
  sql: string;


implementation

{ TGuiasAcumuladasService }

class function TGuiasAcumuladasService.GetList: TObjectList<TGuiasAcumuladasModel>;
begin
  sql := 'SELECT * FROM guias_acumuladas';
  try
    Result := GetQuery(sql).AsObjectList<TGuiasAcumuladasModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TGuiasAcumuladasService.GetListFilter(AWhere: string): TObjectList<TGuiasAcumuladasModel>;
begin
  sql := 'SELECT * FROM guias_acumuladas where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TGuiasAcumuladasModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TGuiasAcumuladasService.GetObject(APk: Integer): TGuiasAcumuladasModel;
begin
  sql := 'SELECT * FROM guias_acumuladas WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TGuiasAcumuladasModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TGuiasAcumuladasService.Insert(AGuiasAcumuladasModel: TGuiasAcumuladasModel);
begin
  AGuiasAcumuladasModel.Id := InsertBase(AGuiasAcumuladasModel, 'guias_acumuladas');
	InsertChildren(AGuiasAcumuladasModel);
end;

class function TGuiasAcumuladasService.Update(AGuiasAcumuladasModel: TGuiasAcumuladasModel): Integer;
begin
  Result := UpdateBase(AGuiasAcumuladasModel, 'guias_acumuladas');
	DeleteChildren(AGuiasAcumuladasModel);
  InsertChildren(AGuiasAcumuladasModel);
end;

class function TGuiasAcumuladasService.Delete(AGuiasAcumuladasModel: TGuiasAcumuladasModel): Integer;
begin
	DeleteChildren(AGuiasAcumuladasModel);
	Result := DeleteBase(AGuiasAcumuladasModel.Id, 'guias_acumuladas');
end;

class procedure TGuiasAcumuladasService.AttachLinkedObjects(AGuiasAcumuladasModelList: TObjectList<TGuiasAcumuladasModel>);
var
  GuiasAcumuladasModel: TGuiasAcumuladasModel;
begin
  for GuiasAcumuladasModel in AGuiasAcumuladasModelList do
  begin
    AttachLinkedObjects(GuiasAcumuladasModel);
  end;
end;

class procedure TGuiasAcumuladasService.AttachLinkedObjects(AGuiasAcumuladasModel: TGuiasAcumuladasModel);
begin
end;

class procedure TGuiasAcumuladasService.InsertChildren(AGuiasAcumuladasModel: TGuiasAcumuladasModel);
begin
end;

class procedure TGuiasAcumuladasService.DeleteChildren(AGuiasAcumuladasModel: TGuiasAcumuladasModel);
begin
end;

end.
