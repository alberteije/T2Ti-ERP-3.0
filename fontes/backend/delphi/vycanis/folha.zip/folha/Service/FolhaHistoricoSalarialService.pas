﻿unit FolhaHistoricoSalarialService;

interface

uses
  FolhaHistoricoSalarialModel, 
  ViewPessoaColaboradorModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaHistoricoSalarialService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaHistoricoSalarialModelList: TObjectList<TFolhaHistoricoSalarialModel>); overload;
    class procedure AttachLinkedObjects(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel); overload;
    class procedure InsertChildren(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel);
    class procedure DeleteChildren(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel);		
  public
    class function GetList: TObjectList<TFolhaHistoricoSalarialModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaHistoricoSalarialModel>;
    class function GetObject(APk: Integer): TFolhaHistoricoSalarialModel;
    class procedure Insert(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel);
    class function Update(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel): Integer;
    class function Delete(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaHistoricoSalarialService }

class function TFolhaHistoricoSalarialService.GetList: TObjectList<TFolhaHistoricoSalarialModel>;
begin
  sql := 'SELECT * FROM folha_historico_salarial';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaHistoricoSalarialModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaHistoricoSalarialService.GetListFilter(AWhere: string): TObjectList<TFolhaHistoricoSalarialModel>;
begin
  sql := 'SELECT * FROM folha_historico_salarial where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaHistoricoSalarialModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaHistoricoSalarialService.GetObject(APk: Integer): TFolhaHistoricoSalarialModel;
begin
  sql := 'SELECT * FROM folha_historico_salarial WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaHistoricoSalarialModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaHistoricoSalarialService.Insert(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel);
begin
  AFolhaHistoricoSalarialModel.Id := InsertBase(AFolhaHistoricoSalarialModel, 'folha_historico_salarial');
	InsertChildren(AFolhaHistoricoSalarialModel);
end;

class function TFolhaHistoricoSalarialService.Update(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel): Integer;
begin
  Result := UpdateBase(AFolhaHistoricoSalarialModel, 'folha_historico_salarial');
	DeleteChildren(AFolhaHistoricoSalarialModel);
  InsertChildren(AFolhaHistoricoSalarialModel);
end;

class function TFolhaHistoricoSalarialService.Delete(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel): Integer;
begin
	DeleteChildren(AFolhaHistoricoSalarialModel);
	Result := DeleteBase(AFolhaHistoricoSalarialModel.Id, 'folha_historico_salarial');
end;

class procedure TFolhaHistoricoSalarialService.AttachLinkedObjects(AFolhaHistoricoSalarialModelList: TObjectList<TFolhaHistoricoSalarialModel>);
var
  FolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel;
begin
  for FolhaHistoricoSalarialModel in AFolhaHistoricoSalarialModelList do
  begin
    AttachLinkedObjects(FolhaHistoricoSalarialModel);
  end;
end;

class procedure TFolhaHistoricoSalarialService.AttachLinkedObjects(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel);
begin
  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaHistoricoSalarialModel.IdColaborador.ToString; 
	AFolhaHistoricoSalarialModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

end;

class procedure TFolhaHistoricoSalarialService.InsertChildren(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel);
begin
end;

class procedure TFolhaHistoricoSalarialService.DeleteChildren(AFolhaHistoricoSalarialModel: TFolhaHistoricoSalarialModel);
begin
end;

end.
