﻿unit FolhaRescisaoService;

interface

uses
  FolhaRescisaoModel, 
  ViewPessoaColaboradorModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaRescisaoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaRescisaoModelList: TObjectList<TFolhaRescisaoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaRescisaoModel: TFolhaRescisaoModel); overload;
    class procedure InsertChildren(AFolhaRescisaoModel: TFolhaRescisaoModel);
    class procedure DeleteChildren(AFolhaRescisaoModel: TFolhaRescisaoModel);		
  public
    class function GetList: TObjectList<TFolhaRescisaoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaRescisaoModel>;
    class function GetObject(APk: Integer): TFolhaRescisaoModel;
    class procedure Insert(AFolhaRescisaoModel: TFolhaRescisaoModel);
    class function Update(AFolhaRescisaoModel: TFolhaRescisaoModel): Integer;
    class function Delete(AFolhaRescisaoModel: TFolhaRescisaoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaRescisaoService }

class function TFolhaRescisaoService.GetList: TObjectList<TFolhaRescisaoModel>;
begin
  sql := 'SELECT * FROM folha_rescisao';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaRescisaoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaRescisaoService.GetListFilter(AWhere: string): TObjectList<TFolhaRescisaoModel>;
begin
  sql := 'SELECT * FROM folha_rescisao where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaRescisaoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaRescisaoService.GetObject(APk: Integer): TFolhaRescisaoModel;
begin
  sql := 'SELECT * FROM folha_rescisao WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaRescisaoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaRescisaoService.Insert(AFolhaRescisaoModel: TFolhaRescisaoModel);
begin
  AFolhaRescisaoModel.Id := InsertBase(AFolhaRescisaoModel, 'folha_rescisao');
	InsertChildren(AFolhaRescisaoModel);
end;

class function TFolhaRescisaoService.Update(AFolhaRescisaoModel: TFolhaRescisaoModel): Integer;
begin
  Result := UpdateBase(AFolhaRescisaoModel, 'folha_rescisao');
	DeleteChildren(AFolhaRescisaoModel);
  InsertChildren(AFolhaRescisaoModel);
end;

class function TFolhaRescisaoService.Delete(AFolhaRescisaoModel: TFolhaRescisaoModel): Integer;
begin
	DeleteChildren(AFolhaRescisaoModel);
	Result := DeleteBase(AFolhaRescisaoModel.Id, 'folha_rescisao');
end;

class procedure TFolhaRescisaoService.AttachLinkedObjects(AFolhaRescisaoModelList: TObjectList<TFolhaRescisaoModel>);
var
  FolhaRescisaoModel: TFolhaRescisaoModel;
begin
  for FolhaRescisaoModel in AFolhaRescisaoModelList do
  begin
    AttachLinkedObjects(FolhaRescisaoModel);
  end;
end;

class procedure TFolhaRescisaoService.AttachLinkedObjects(AFolhaRescisaoModel: TFolhaRescisaoModel);
begin
  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaRescisaoModel.IdColaborador.ToString; 
	AFolhaRescisaoModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

end;

class procedure TFolhaRescisaoService.InsertChildren(AFolhaRescisaoModel: TFolhaRescisaoModel);
begin
end;

class procedure TFolhaRescisaoService.DeleteChildren(AFolhaRescisaoModel: TFolhaRescisaoModel);
begin
end;

end.
