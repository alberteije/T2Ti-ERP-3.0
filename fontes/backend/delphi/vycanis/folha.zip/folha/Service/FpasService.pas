﻿unit FpasService;

interface

uses
  FpasModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFpasService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFpasModelList: TObjectList<TFpasModel>); overload;
    class procedure AttachLinkedObjects(AFpasModel: TFpasModel); overload;
    class procedure InsertChildren(AFpasModel: TFpasModel);
    class procedure DeleteChildren(AFpasModel: TFpasModel);		
  public
    class function GetList: TObjectList<TFpasModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFpasModel>;
    class function GetObject(APk: Integer): TFpasModel;
    class procedure Insert(AFpasModel: TFpasModel);
    class function Update(AFpasModel: TFpasModel): Integer;
    class function Delete(AFpasModel: TFpasModel): Integer;
  end;

var
  sql: string;


implementation

{ TFpasService }

class function TFpasService.GetList: TObjectList<TFpasModel>;
begin
  sql := 'SELECT * FROM fpas';
  try
    Result := GetQuery(sql).AsObjectList<TFpasModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFpasService.GetListFilter(AWhere: string): TObjectList<TFpasModel>;
begin
  sql := 'SELECT * FROM fpas where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFpasModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFpasService.GetObject(APk: Integer): TFpasModel;
begin
  sql := 'SELECT * FROM fpas WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFpasModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFpasService.Insert(AFpasModel: TFpasModel);
begin
  AFpasModel.Id := InsertBase(AFpasModel, 'fpas');
	InsertChildren(AFpasModel);
end;

class function TFpasService.Update(AFpasModel: TFpasModel): Integer;
begin
  Result := UpdateBase(AFpasModel, 'fpas');
	DeleteChildren(AFpasModel);
  InsertChildren(AFpasModel);
end;

class function TFpasService.Delete(AFpasModel: TFpasModel): Integer;
begin
	DeleteChildren(AFpasModel);
	Result := DeleteBase(AFpasModel.Id, 'fpas');
end;

class procedure TFpasService.AttachLinkedObjects(AFpasModelList: TObjectList<TFpasModel>);
var
  FpasModel: TFpasModel;
begin
  for FpasModel in AFpasModelList do
  begin
    AttachLinkedObjects(FpasModel);
  end;
end;

class procedure TFpasService.AttachLinkedObjects(AFpasModel: TFpasModel);
begin
end;

class procedure TFpasService.InsertChildren(AFpasModel: TFpasModel);
begin
end;

class procedure TFpasService.DeleteChildren(AFpasModel: TFpasModel);
begin
end;

end.
