﻿unit FolhaFechamentoService;

interface

uses
  FolhaFechamentoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaFechamentoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaFechamentoModelList: TObjectList<TFolhaFechamentoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaFechamentoModel: TFolhaFechamentoModel); overload;
    class procedure InsertChildren(AFolhaFechamentoModel: TFolhaFechamentoModel);
    class procedure DeleteChildren(AFolhaFechamentoModel: TFolhaFechamentoModel);		
  public
    class function GetList: TObjectList<TFolhaFechamentoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaFechamentoModel>;
    class function GetObject(APk: Integer): TFolhaFechamentoModel;
    class procedure Insert(AFolhaFechamentoModel: TFolhaFechamentoModel);
    class function Update(AFolhaFechamentoModel: TFolhaFechamentoModel): Integer;
    class function Delete(AFolhaFechamentoModel: TFolhaFechamentoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaFechamentoService }

class function TFolhaFechamentoService.GetList: TObjectList<TFolhaFechamentoModel>;
begin
  sql := 'SELECT * FROM folha_fechamento';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaFechamentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaFechamentoService.GetListFilter(AWhere: string): TObjectList<TFolhaFechamentoModel>;
begin
  sql := 'SELECT * FROM folha_fechamento where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaFechamentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaFechamentoService.GetObject(APk: Integer): TFolhaFechamentoModel;
begin
  sql := 'SELECT * FROM folha_fechamento WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaFechamentoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaFechamentoService.Insert(AFolhaFechamentoModel: TFolhaFechamentoModel);
begin
  AFolhaFechamentoModel.Id := InsertBase(AFolhaFechamentoModel, 'folha_fechamento');
	InsertChildren(AFolhaFechamentoModel);
end;

class function TFolhaFechamentoService.Update(AFolhaFechamentoModel: TFolhaFechamentoModel): Integer;
begin
  Result := UpdateBase(AFolhaFechamentoModel, 'folha_fechamento');
	DeleteChildren(AFolhaFechamentoModel);
  InsertChildren(AFolhaFechamentoModel);
end;

class function TFolhaFechamentoService.Delete(AFolhaFechamentoModel: TFolhaFechamentoModel): Integer;
begin
	DeleteChildren(AFolhaFechamentoModel);
	Result := DeleteBase(AFolhaFechamentoModel.Id, 'folha_fechamento');
end;

class procedure TFolhaFechamentoService.AttachLinkedObjects(AFolhaFechamentoModelList: TObjectList<TFolhaFechamentoModel>);
var
  FolhaFechamentoModel: TFolhaFechamentoModel;
begin
  for FolhaFechamentoModel in AFolhaFechamentoModelList do
  begin
    AttachLinkedObjects(FolhaFechamentoModel);
  end;
end;

class procedure TFolhaFechamentoService.AttachLinkedObjects(AFolhaFechamentoModel: TFolhaFechamentoModel);
begin
end;

class procedure TFolhaFechamentoService.InsertChildren(AFolhaFechamentoModel: TFolhaFechamentoModel);
begin
end;

class procedure TFolhaFechamentoService.DeleteChildren(AFolhaFechamentoModel: TFolhaFechamentoModel);
begin
end;

end.
