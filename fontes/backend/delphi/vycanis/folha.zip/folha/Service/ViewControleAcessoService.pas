﻿unit ViewControleAcessoService;

interface

uses
  ViewControleAcessoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TViewControleAcessoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AViewControleAcessoModelList: TObjectList<TViewControleAcessoModel>); overload;
    class procedure AttachLinkedObjects(AViewControleAcessoModel: TViewControleAcessoModel); overload;
    class procedure InsertChildren(AViewControleAcessoModel: TViewControleAcessoModel);
    class procedure DeleteChildren(AViewControleAcessoModel: TViewControleAcessoModel);		
  public
    class function GetList: TObjectList<TViewControleAcessoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TViewControleAcessoModel>;
    class function GetObject(APk: Integer): TViewControleAcessoModel;
    class procedure Insert(AViewControleAcessoModel: TViewControleAcessoModel);
    class function Update(AViewControleAcessoModel: TViewControleAcessoModel): Integer;
    class function Delete(AViewControleAcessoModel: TViewControleAcessoModel): Integer;
  end;

var
  sql: string;


implementation

{ TViewControleAcessoService }

class function TViewControleAcessoService.GetList: TObjectList<TViewControleAcessoModel>;
begin
  sql := 'SELECT * FROM view_controle_acesso';
  try
    Result := GetQuery(sql).AsObjectList<TViewControleAcessoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TViewControleAcessoService.GetListFilter(AWhere: string): TObjectList<TViewControleAcessoModel>;
begin
  sql := 'SELECT * FROM view_controle_acesso where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TViewControleAcessoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TViewControleAcessoService.GetObject(APk: Integer): TViewControleAcessoModel;
begin
  sql := 'SELECT * FROM view_controle_acesso WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TViewControleAcessoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TViewControleAcessoService.Insert(AViewControleAcessoModel: TViewControleAcessoModel);
begin
  AViewControleAcessoModel.Id := InsertBase(AViewControleAcessoModel, 'view_controle_acesso');
	InsertChildren(AViewControleAcessoModel);
end;

class function TViewControleAcessoService.Update(AViewControleAcessoModel: TViewControleAcessoModel): Integer;
begin
  Result := UpdateBase(AViewControleAcessoModel, 'view_controle_acesso');
	DeleteChildren(AViewControleAcessoModel);
  InsertChildren(AViewControleAcessoModel);
end;

class function TViewControleAcessoService.Delete(AViewControleAcessoModel: TViewControleAcessoModel): Integer;
begin
	DeleteChildren(AViewControleAcessoModel);
	Result := DeleteBase(AViewControleAcessoModel.Id, 'view_controle_acesso');
end;

class procedure TViewControleAcessoService.AttachLinkedObjects(AViewControleAcessoModelList: TObjectList<TViewControleAcessoModel>);
var
  ViewControleAcessoModel: TViewControleAcessoModel;
begin
  for ViewControleAcessoModel in AViewControleAcessoModelList do
  begin
    AttachLinkedObjects(ViewControleAcessoModel);
  end;
end;

class procedure TViewControleAcessoService.AttachLinkedObjects(AViewControleAcessoModel: TViewControleAcessoModel);
begin
end;

class procedure TViewControleAcessoService.InsertChildren(AViewControleAcessoModel: TViewControleAcessoModel);
begin
end;

class procedure TViewControleAcessoService.DeleteChildren(AViewControleAcessoModel: TViewControleAcessoModel);
begin
end;

end.
