﻿unit EmpresaTransporteService;

interface

uses
  EmpresaTransporteModel, 
  EmpresaTransporteItinerarioModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TEmpresaTransporteService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AEmpresaTransporteModelList: TObjectList<TEmpresaTransporteModel>); overload;
    class procedure AttachLinkedObjects(AEmpresaTransporteModel: TEmpresaTransporteModel); overload;
    class procedure InsertChildren(AEmpresaTransporteModel: TEmpresaTransporteModel);
    class procedure DeleteChildren(AEmpresaTransporteModel: TEmpresaTransporteModel);		
  public
    class function GetList: TObjectList<TEmpresaTransporteModel>;
    class function GetListFilter(AWhere: string): TObjectList<TEmpresaTransporteModel>;
    class function GetObject(APk: Integer): TEmpresaTransporteModel;
    class procedure Insert(AEmpresaTransporteModel: TEmpresaTransporteModel);
    class function Update(AEmpresaTransporteModel: TEmpresaTransporteModel): Integer;
    class function Delete(AEmpresaTransporteModel: TEmpresaTransporteModel): Integer;
  end;

var
  sql: string;


implementation

{ TEmpresaTransporteService }

class function TEmpresaTransporteService.GetList: TObjectList<TEmpresaTransporteModel>;
begin
  sql := 'SELECT * FROM empresa_transporte';
  try
    Result := GetQuery(sql).AsObjectList<TEmpresaTransporteModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TEmpresaTransporteService.GetListFilter(AWhere: string): TObjectList<TEmpresaTransporteModel>;
begin
  sql := 'SELECT * FROM empresa_transporte where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TEmpresaTransporteModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TEmpresaTransporteService.GetObject(APk: Integer): TEmpresaTransporteModel;
begin
  sql := 'SELECT * FROM empresa_transporte WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TEmpresaTransporteModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TEmpresaTransporteService.Insert(AEmpresaTransporteModel: TEmpresaTransporteModel);
begin
  AEmpresaTransporteModel.Id := InsertBase(AEmpresaTransporteModel, 'empresa_transporte');
	InsertChildren(AEmpresaTransporteModel);
end;

class function TEmpresaTransporteService.Update(AEmpresaTransporteModel: TEmpresaTransporteModel): Integer;
begin
  Result := UpdateBase(AEmpresaTransporteModel, 'empresa_transporte');
	DeleteChildren(AEmpresaTransporteModel);
  InsertChildren(AEmpresaTransporteModel);
end;

class function TEmpresaTransporteService.Delete(AEmpresaTransporteModel: TEmpresaTransporteModel): Integer;
begin
	DeleteChildren(AEmpresaTransporteModel);
	Result := DeleteBase(AEmpresaTransporteModel.Id, 'empresa_transporte');
end;

class procedure TEmpresaTransporteService.AttachLinkedObjects(AEmpresaTransporteModelList: TObjectList<TEmpresaTransporteModel>);
var
  EmpresaTransporteModel: TEmpresaTransporteModel;
begin
  for EmpresaTransporteModel in AEmpresaTransporteModelList do
  begin
    AttachLinkedObjects(EmpresaTransporteModel);
  end;
end;

class procedure TEmpresaTransporteService.AttachLinkedObjects(AEmpresaTransporteModel: TEmpresaTransporteModel);
begin
  // EmpresaTransporteItinerarioModel
	sql := 'SELECT * FROM empresa_transporte_itinerario WHERE id_empresa_transporte = ' + AEmpresaTransporteModel.Id.ToString; 
	AEmpresaTransporteModel.EmpresaTransporteItinerarioModelList := GetQuery(sql).AsObjectList<TEmpresaTransporteItinerarioModel>; 

end;

class procedure TEmpresaTransporteService.InsertChildren(AEmpresaTransporteModel: TEmpresaTransporteModel);
var
	EmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel;
begin
  // EmpresaTransporteItinerarioModel 
	for EmpresaTransporteItinerarioModel in AEmpresaTransporteModel.EmpresaTransporteItinerarioModelList do 
	begin 
	  EmpresaTransporteItinerarioModel.IdEmpresaTransporte := AEmpresaTransporteModel.Id;
	  InsertBase(EmpresaTransporteItinerarioModel, 'empresa_transporte_itinerario'); 
	end; 

end;

class procedure TEmpresaTransporteService.DeleteChildren(AEmpresaTransporteModel: TEmpresaTransporteModel);
begin
  DeleteChild(AEmpresaTransporteModel.Id, 'empresa_transporte_itinerario', 'id_empresa_transporte');
end;

end.
