﻿unit CboService;

interface

uses
  CboModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TCboService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(ACboModelList: TObjectList<TCboModel>); overload;
    class procedure AttachLinkedObjects(ACboModel: TCboModel); overload;
    class procedure InsertChildren(ACboModel: TCboModel);
    class procedure DeleteChildren(ACboModel: TCboModel);		
  public
    class function GetList: TObjectList<TCboModel>;
    class function GetListFilter(AWhere: string): TObjectList<TCboModel>;
    class function GetObject(APk: Integer): TCboModel;
    class procedure Insert(ACboModel: TCboModel);
    class function Update(ACboModel: TCboModel): Integer;
    class function Delete(ACboModel: TCboModel): Integer;
  end;

var
  sql: string;


implementation

{ TCboService }

class function TCboService.GetList: TObjectList<TCboModel>;
begin
  sql := 'SELECT * FROM cbo';
  try
    Result := GetQuery(sql).AsObjectList<TCboModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TCboService.GetListFilter(AWhere: string): TObjectList<TCboModel>;
begin
  sql := 'SELECT * FROM cbo where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TCboModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TCboService.GetObject(APk: Integer): TCboModel;
begin
  sql := 'SELECT * FROM cbo WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TCboModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TCboService.Insert(ACboModel: TCboModel);
begin
  ACboModel.Id := InsertBase(ACboModel, 'cbo');
	InsertChildren(ACboModel);
end;

class function TCboService.Update(ACboModel: TCboModel): Integer;
begin
  Result := UpdateBase(ACboModel, 'cbo');
	DeleteChildren(ACboModel);
  InsertChildren(ACboModel);
end;

class function TCboService.Delete(ACboModel: TCboModel): Integer;
begin
	DeleteChildren(ACboModel);
	Result := DeleteBase(ACboModel.Id, 'cbo');
end;

class procedure TCboService.AttachLinkedObjects(ACboModelList: TObjectList<TCboModel>);
var
  CboModel: TCboModel;
begin
  for CboModel in ACboModelList do
  begin
    AttachLinkedObjects(CboModel);
  end;
end;

class procedure TCboService.AttachLinkedObjects(ACboModel: TCboModel);
begin
end;

class procedure TCboService.InsertChildren(ACboModel: TCboModel);
begin
end;

class procedure TCboService.DeleteChildren(ACboModel: TCboModel);
begin
end;

end.
