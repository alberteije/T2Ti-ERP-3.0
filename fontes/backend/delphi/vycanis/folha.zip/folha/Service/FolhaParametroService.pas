﻿unit FolhaParametroService;

interface

uses
  FolhaParametroModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaParametroService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaParametroModelList: TObjectList<TFolhaParametroModel>); overload;
    class procedure AttachLinkedObjects(AFolhaParametroModel: TFolhaParametroModel); overload;
    class procedure InsertChildren(AFolhaParametroModel: TFolhaParametroModel);
    class procedure DeleteChildren(AFolhaParametroModel: TFolhaParametroModel);		
  public
    class function GetList: TObjectList<TFolhaParametroModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaParametroModel>;
    class function GetObject(APk: Integer): TFolhaParametroModel;
    class procedure Insert(AFolhaParametroModel: TFolhaParametroModel);
    class function Update(AFolhaParametroModel: TFolhaParametroModel): Integer;
    class function Delete(AFolhaParametroModel: TFolhaParametroModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaParametroService }

class function TFolhaParametroService.GetList: TObjectList<TFolhaParametroModel>;
begin
  sql := 'SELECT * FROM folha_parametro';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaParametroModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaParametroService.GetListFilter(AWhere: string): TObjectList<TFolhaParametroModel>;
begin
  sql := 'SELECT * FROM folha_parametro where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaParametroModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaParametroService.GetObject(APk: Integer): TFolhaParametroModel;
begin
  sql := 'SELECT * FROM folha_parametro WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaParametroModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaParametroService.Insert(AFolhaParametroModel: TFolhaParametroModel);
begin
  AFolhaParametroModel.Id := InsertBase(AFolhaParametroModel, 'folha_parametro');
	InsertChildren(AFolhaParametroModel);
end;

class function TFolhaParametroService.Update(AFolhaParametroModel: TFolhaParametroModel): Integer;
begin
  Result := UpdateBase(AFolhaParametroModel, 'folha_parametro');
	DeleteChildren(AFolhaParametroModel);
  InsertChildren(AFolhaParametroModel);
end;

class function TFolhaParametroService.Delete(AFolhaParametroModel: TFolhaParametroModel): Integer;
begin
	DeleteChildren(AFolhaParametroModel);
	Result := DeleteBase(AFolhaParametroModel.Id, 'folha_parametro');
end;

class procedure TFolhaParametroService.AttachLinkedObjects(AFolhaParametroModelList: TObjectList<TFolhaParametroModel>);
var
  FolhaParametroModel: TFolhaParametroModel;
begin
  for FolhaParametroModel in AFolhaParametroModelList do
  begin
    AttachLinkedObjects(FolhaParametroModel);
  end;
end;

class procedure TFolhaParametroService.AttachLinkedObjects(AFolhaParametroModel: TFolhaParametroModel);
begin
end;

class procedure TFolhaParametroService.InsertChildren(AFolhaParametroModel: TFolhaParametroModel);
begin
end;

class procedure TFolhaParametroService.DeleteChildren(AFolhaParametroModel: TFolhaParametroModel);
begin
end;

end.
