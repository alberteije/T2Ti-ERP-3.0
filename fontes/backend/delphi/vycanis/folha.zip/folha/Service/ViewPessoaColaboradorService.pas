﻿unit ViewPessoaColaboradorService;

interface

uses
  ViewPessoaColaboradorModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TViewPessoaColaboradorService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AViewPessoaColaboradorModelList: TObjectList<TViewPessoaColaboradorModel>); overload;
    class procedure AttachLinkedObjects(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel); overload;
    class procedure InsertChildren(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel);
    class procedure DeleteChildren(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel);		
  public
    class function GetList: TObjectList<TViewPessoaColaboradorModel>;
    class function GetListFilter(AWhere: string): TObjectList<TViewPessoaColaboradorModel>;
    class function GetObject(APk: Integer): TViewPessoaColaboradorModel;
    class procedure Insert(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel);
    class function Update(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel): Integer;
    class function Delete(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel): Integer;
  end;

var
  sql: string;


implementation

{ TViewPessoaColaboradorService }

class function TViewPessoaColaboradorService.GetList: TObjectList<TViewPessoaColaboradorModel>;
begin
  sql := 'SELECT * FROM view_pessoa_colaborador';
  try
    Result := GetQuery(sql).AsObjectList<TViewPessoaColaboradorModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TViewPessoaColaboradorService.GetListFilter(AWhere: string): TObjectList<TViewPessoaColaboradorModel>;
begin
  sql := 'SELECT * FROM view_pessoa_colaborador where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TViewPessoaColaboradorModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TViewPessoaColaboradorService.GetObject(APk: Integer): TViewPessoaColaboradorModel;
begin
  sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TViewPessoaColaboradorModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TViewPessoaColaboradorService.Insert(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel);
begin
  AViewPessoaColaboradorModel.Id := InsertBase(AViewPessoaColaboradorModel, 'view_pessoa_colaborador');
	InsertChildren(AViewPessoaColaboradorModel);
end;

class function TViewPessoaColaboradorService.Update(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel): Integer;
begin
  Result := UpdateBase(AViewPessoaColaboradorModel, 'view_pessoa_colaborador');
	DeleteChildren(AViewPessoaColaboradorModel);
  InsertChildren(AViewPessoaColaboradorModel);
end;

class function TViewPessoaColaboradorService.Delete(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel): Integer;
begin
	DeleteChildren(AViewPessoaColaboradorModel);
	Result := DeleteBase(AViewPessoaColaboradorModel.Id, 'view_pessoa_colaborador');
end;

class procedure TViewPessoaColaboradorService.AttachLinkedObjects(AViewPessoaColaboradorModelList: TObjectList<TViewPessoaColaboradorModel>);
var
  ViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
begin
  for ViewPessoaColaboradorModel in AViewPessoaColaboradorModelList do
  begin
    AttachLinkedObjects(ViewPessoaColaboradorModel);
  end;
end;

class procedure TViewPessoaColaboradorService.AttachLinkedObjects(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel);
begin
end;

class procedure TViewPessoaColaboradorService.InsertChildren(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel);
begin
end;

class procedure TViewPessoaColaboradorService.DeleteChildren(AViewPessoaColaboradorModel: TViewPessoaColaboradorModel);
begin
end;

end.
