﻿unit CodigoGpsService;

interface

uses
  CodigoGpsModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TCodigoGpsService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(ACodigoGpsModelList: TObjectList<TCodigoGpsModel>); overload;
    class procedure AttachLinkedObjects(ACodigoGpsModel: TCodigoGpsModel); overload;
    class procedure InsertChildren(ACodigoGpsModel: TCodigoGpsModel);
    class procedure DeleteChildren(ACodigoGpsModel: TCodigoGpsModel);		
  public
    class function GetList: TObjectList<TCodigoGpsModel>;
    class function GetListFilter(AWhere: string): TObjectList<TCodigoGpsModel>;
    class function GetObject(APk: Integer): TCodigoGpsModel;
    class procedure Insert(ACodigoGpsModel: TCodigoGpsModel);
    class function Update(ACodigoGpsModel: TCodigoGpsModel): Integer;
    class function Delete(ACodigoGpsModel: TCodigoGpsModel): Integer;
  end;

var
  sql: string;


implementation

{ TCodigoGpsService }

class function TCodigoGpsService.GetList: TObjectList<TCodigoGpsModel>;
begin
  sql := 'SELECT * FROM codigo_gps';
  try
    Result := GetQuery(sql).AsObjectList<TCodigoGpsModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TCodigoGpsService.GetListFilter(AWhere: string): TObjectList<TCodigoGpsModel>;
begin
  sql := 'SELECT * FROM codigo_gps where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TCodigoGpsModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TCodigoGpsService.GetObject(APk: Integer): TCodigoGpsModel;
begin
  sql := 'SELECT * FROM codigo_gps WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TCodigoGpsModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TCodigoGpsService.Insert(ACodigoGpsModel: TCodigoGpsModel);
begin
  ACodigoGpsModel.Id := InsertBase(ACodigoGpsModel, 'codigo_gps');
	InsertChildren(ACodigoGpsModel);
end;

class function TCodigoGpsService.Update(ACodigoGpsModel: TCodigoGpsModel): Integer;
begin
  Result := UpdateBase(ACodigoGpsModel, 'codigo_gps');
	DeleteChildren(ACodigoGpsModel);
  InsertChildren(ACodigoGpsModel);
end;

class function TCodigoGpsService.Delete(ACodigoGpsModel: TCodigoGpsModel): Integer;
begin
	DeleteChildren(ACodigoGpsModel);
	Result := DeleteBase(ACodigoGpsModel.Id, 'codigo_gps');
end;

class procedure TCodigoGpsService.AttachLinkedObjects(ACodigoGpsModelList: TObjectList<TCodigoGpsModel>);
var
  CodigoGpsModel: TCodigoGpsModel;
begin
  for CodigoGpsModel in ACodigoGpsModelList do
  begin
    AttachLinkedObjects(CodigoGpsModel);
  end;
end;

class procedure TCodigoGpsService.AttachLinkedObjects(ACodigoGpsModel: TCodigoGpsModel);
begin
end;

class procedure TCodigoGpsService.InsertChildren(ACodigoGpsModel: TCodigoGpsModel);
begin
end;

class procedure TCodigoGpsService.DeleteChildren(ACodigoGpsModel: TCodigoGpsModel);
begin
end;

end.
