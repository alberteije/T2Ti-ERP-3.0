﻿unit SefipCodigoRecolhimentoService;

interface

uses
  SefipCodigoRecolhimentoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TSefipCodigoRecolhimentoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(ASefipCodigoRecolhimentoModelList: TObjectList<TSefipCodigoRecolhimentoModel>); overload;
    class procedure AttachLinkedObjects(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel); overload;
    class procedure InsertChildren(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel);
    class procedure DeleteChildren(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel);		
  public
    class function GetList: TObjectList<TSefipCodigoRecolhimentoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TSefipCodigoRecolhimentoModel>;
    class function GetObject(APk: Integer): TSefipCodigoRecolhimentoModel;
    class procedure Insert(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel);
    class function Update(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel): Integer;
    class function Delete(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel): Integer;
  end;

var
  sql: string;


implementation

{ TSefipCodigoRecolhimentoService }

class function TSefipCodigoRecolhimentoService.GetList: TObjectList<TSefipCodigoRecolhimentoModel>;
begin
  sql := 'SELECT * FROM sefip_codigo_recolhimento';
  try
    Result := GetQuery(sql).AsObjectList<TSefipCodigoRecolhimentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSefipCodigoRecolhimentoService.GetListFilter(AWhere: string): TObjectList<TSefipCodigoRecolhimentoModel>;
begin
  sql := 'SELECT * FROM sefip_codigo_recolhimento where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TSefipCodigoRecolhimentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSefipCodigoRecolhimentoService.GetObject(APk: Integer): TSefipCodigoRecolhimentoModel;
begin
  sql := 'SELECT * FROM sefip_codigo_recolhimento WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TSefipCodigoRecolhimentoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TSefipCodigoRecolhimentoService.Insert(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel);
begin
  ASefipCodigoRecolhimentoModel.Id := InsertBase(ASefipCodigoRecolhimentoModel, 'sefip_codigo_recolhimento');
	InsertChildren(ASefipCodigoRecolhimentoModel);
end;

class function TSefipCodigoRecolhimentoService.Update(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel): Integer;
begin
  Result := UpdateBase(ASefipCodigoRecolhimentoModel, 'sefip_codigo_recolhimento');
	DeleteChildren(ASefipCodigoRecolhimentoModel);
  InsertChildren(ASefipCodigoRecolhimentoModel);
end;

class function TSefipCodigoRecolhimentoService.Delete(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel): Integer;
begin
	DeleteChildren(ASefipCodigoRecolhimentoModel);
	Result := DeleteBase(ASefipCodigoRecolhimentoModel.Id, 'sefip_codigo_recolhimento');
end;

class procedure TSefipCodigoRecolhimentoService.AttachLinkedObjects(ASefipCodigoRecolhimentoModelList: TObjectList<TSefipCodigoRecolhimentoModel>);
var
  SefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel;
begin
  for SefipCodigoRecolhimentoModel in ASefipCodigoRecolhimentoModelList do
  begin
    AttachLinkedObjects(SefipCodigoRecolhimentoModel);
  end;
end;

class procedure TSefipCodigoRecolhimentoService.AttachLinkedObjects(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel);
begin
end;

class procedure TSefipCodigoRecolhimentoService.InsertChildren(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel);
begin
end;

class procedure TSefipCodigoRecolhimentoService.DeleteChildren(ASefipCodigoRecolhimentoModel: TSefipCodigoRecolhimentoModel);
begin
end;

end.
