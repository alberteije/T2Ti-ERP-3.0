﻿unit SalarioMinimoService;

interface

uses
  SalarioMinimoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TSalarioMinimoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(ASalarioMinimoModelList: TObjectList<TSalarioMinimoModel>); overload;
    class procedure AttachLinkedObjects(ASalarioMinimoModel: TSalarioMinimoModel); overload;
    class procedure InsertChildren(ASalarioMinimoModel: TSalarioMinimoModel);
    class procedure DeleteChildren(ASalarioMinimoModel: TSalarioMinimoModel);		
  public
    class function GetList: TObjectList<TSalarioMinimoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TSalarioMinimoModel>;
    class function GetObject(APk: Integer): TSalarioMinimoModel;
    class procedure Insert(ASalarioMinimoModel: TSalarioMinimoModel);
    class function Update(ASalarioMinimoModel: TSalarioMinimoModel): Integer;
    class function Delete(ASalarioMinimoModel: TSalarioMinimoModel): Integer;
  end;

var
  sql: string;


implementation

{ TSalarioMinimoService }

class function TSalarioMinimoService.GetList: TObjectList<TSalarioMinimoModel>;
begin
  sql := 'SELECT * FROM salario_minimo';
  try
    Result := GetQuery(sql).AsObjectList<TSalarioMinimoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSalarioMinimoService.GetListFilter(AWhere: string): TObjectList<TSalarioMinimoModel>;
begin
  sql := 'SELECT * FROM salario_minimo where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TSalarioMinimoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSalarioMinimoService.GetObject(APk: Integer): TSalarioMinimoModel;
begin
  sql := 'SELECT * FROM salario_minimo WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TSalarioMinimoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TSalarioMinimoService.Insert(ASalarioMinimoModel: TSalarioMinimoModel);
begin
  ASalarioMinimoModel.Id := InsertBase(ASalarioMinimoModel, 'salario_minimo');
	InsertChildren(ASalarioMinimoModel);
end;

class function TSalarioMinimoService.Update(ASalarioMinimoModel: TSalarioMinimoModel): Integer;
begin
  Result := UpdateBase(ASalarioMinimoModel, 'salario_minimo');
	DeleteChildren(ASalarioMinimoModel);
  InsertChildren(ASalarioMinimoModel);
end;

class function TSalarioMinimoService.Delete(ASalarioMinimoModel: TSalarioMinimoModel): Integer;
begin
	DeleteChildren(ASalarioMinimoModel);
	Result := DeleteBase(ASalarioMinimoModel.Id, 'salario_minimo');
end;

class procedure TSalarioMinimoService.AttachLinkedObjects(ASalarioMinimoModelList: TObjectList<TSalarioMinimoModel>);
var
  SalarioMinimoModel: TSalarioMinimoModel;
begin
  for SalarioMinimoModel in ASalarioMinimoModelList do
  begin
    AttachLinkedObjects(SalarioMinimoModel);
  end;
end;

class procedure TSalarioMinimoService.AttachLinkedObjects(ASalarioMinimoModel: TSalarioMinimoModel);
begin
end;

class procedure TSalarioMinimoService.InsertChildren(ASalarioMinimoModel: TSalarioMinimoModel);
begin
end;

class procedure TSalarioMinimoService.DeleteChildren(ASalarioMinimoModel: TSalarioMinimoModel);
begin
end;

end.
