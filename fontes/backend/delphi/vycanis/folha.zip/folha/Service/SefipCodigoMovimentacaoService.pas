﻿unit SefipCodigoMovimentacaoService;

interface

uses
  SefipCodigoMovimentacaoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TSefipCodigoMovimentacaoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(ASefipCodigoMovimentacaoModelList: TObjectList<TSefipCodigoMovimentacaoModel>); overload;
    class procedure AttachLinkedObjects(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel); overload;
    class procedure InsertChildren(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel);
    class procedure DeleteChildren(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel);		
  public
    class function GetList: TObjectList<TSefipCodigoMovimentacaoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TSefipCodigoMovimentacaoModel>;
    class function GetObject(APk: Integer): TSefipCodigoMovimentacaoModel;
    class procedure Insert(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel);
    class function Update(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel): Integer;
    class function Delete(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel): Integer;
  end;

var
  sql: string;


implementation

{ TSefipCodigoMovimentacaoService }

class function TSefipCodigoMovimentacaoService.GetList: TObjectList<TSefipCodigoMovimentacaoModel>;
begin
  sql := 'SELECT * FROM sefip_codigo_movimentacao';
  try
    Result := GetQuery(sql).AsObjectList<TSefipCodigoMovimentacaoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSefipCodigoMovimentacaoService.GetListFilter(AWhere: string): TObjectList<TSefipCodigoMovimentacaoModel>;
begin
  sql := 'SELECT * FROM sefip_codigo_movimentacao where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TSefipCodigoMovimentacaoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSefipCodigoMovimentacaoService.GetObject(APk: Integer): TSefipCodigoMovimentacaoModel;
begin
  sql := 'SELECT * FROM sefip_codigo_movimentacao WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TSefipCodigoMovimentacaoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TSefipCodigoMovimentacaoService.Insert(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel);
begin
  ASefipCodigoMovimentacaoModel.Id := InsertBase(ASefipCodigoMovimentacaoModel, 'sefip_codigo_movimentacao');
	InsertChildren(ASefipCodigoMovimentacaoModel);
end;

class function TSefipCodigoMovimentacaoService.Update(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel): Integer;
begin
  Result := UpdateBase(ASefipCodigoMovimentacaoModel, 'sefip_codigo_movimentacao');
	DeleteChildren(ASefipCodigoMovimentacaoModel);
  InsertChildren(ASefipCodigoMovimentacaoModel);
end;

class function TSefipCodigoMovimentacaoService.Delete(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel): Integer;
begin
	DeleteChildren(ASefipCodigoMovimentacaoModel);
	Result := DeleteBase(ASefipCodigoMovimentacaoModel.Id, 'sefip_codigo_movimentacao');
end;

class procedure TSefipCodigoMovimentacaoService.AttachLinkedObjects(ASefipCodigoMovimentacaoModelList: TObjectList<TSefipCodigoMovimentacaoModel>);
var
  SefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel;
begin
  for SefipCodigoMovimentacaoModel in ASefipCodigoMovimentacaoModelList do
  begin
    AttachLinkedObjects(SefipCodigoMovimentacaoModel);
  end;
end;

class procedure TSefipCodigoMovimentacaoService.AttachLinkedObjects(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel);
begin
end;

class procedure TSefipCodigoMovimentacaoService.InsertChildren(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel);
begin
end;

class procedure TSefipCodigoMovimentacaoService.DeleteChildren(ASefipCodigoMovimentacaoModel: TSefipCodigoMovimentacaoModel);
begin
end;

end.
