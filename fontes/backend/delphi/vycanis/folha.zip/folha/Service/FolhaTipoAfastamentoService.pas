﻿unit FolhaTipoAfastamentoService;

interface

uses
  FolhaTipoAfastamentoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaTipoAfastamentoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaTipoAfastamentoModelList: TObjectList<TFolhaTipoAfastamentoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel); overload;
    class procedure InsertChildren(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel);
    class procedure DeleteChildren(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel);		
  public
    class function GetList: TObjectList<TFolhaTipoAfastamentoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaTipoAfastamentoModel>;
    class function GetObject(APk: Integer): TFolhaTipoAfastamentoModel;
    class procedure Insert(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel);
    class function Update(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel): Integer;
    class function Delete(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaTipoAfastamentoService }

class function TFolhaTipoAfastamentoService.GetList: TObjectList<TFolhaTipoAfastamentoModel>;
begin
  sql := 'SELECT * FROM folha_tipo_afastamento';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaTipoAfastamentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaTipoAfastamentoService.GetListFilter(AWhere: string): TObjectList<TFolhaTipoAfastamentoModel>;
begin
  sql := 'SELECT * FROM folha_tipo_afastamento where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaTipoAfastamentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaTipoAfastamentoService.GetObject(APk: Integer): TFolhaTipoAfastamentoModel;
begin
  sql := 'SELECT * FROM folha_tipo_afastamento WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaTipoAfastamentoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaTipoAfastamentoService.Insert(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel);
begin
  AFolhaTipoAfastamentoModel.Id := InsertBase(AFolhaTipoAfastamentoModel, 'folha_tipo_afastamento');
	InsertChildren(AFolhaTipoAfastamentoModel);
end;

class function TFolhaTipoAfastamentoService.Update(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel): Integer;
begin
  Result := UpdateBase(AFolhaTipoAfastamentoModel, 'folha_tipo_afastamento');
	DeleteChildren(AFolhaTipoAfastamentoModel);
  InsertChildren(AFolhaTipoAfastamentoModel);
end;

class function TFolhaTipoAfastamentoService.Delete(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel): Integer;
begin
	DeleteChildren(AFolhaTipoAfastamentoModel);
	Result := DeleteBase(AFolhaTipoAfastamentoModel.Id, 'folha_tipo_afastamento');
end;

class procedure TFolhaTipoAfastamentoService.AttachLinkedObjects(AFolhaTipoAfastamentoModelList: TObjectList<TFolhaTipoAfastamentoModel>);
var
  FolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel;
begin
  for FolhaTipoAfastamentoModel in AFolhaTipoAfastamentoModelList do
  begin
    AttachLinkedObjects(FolhaTipoAfastamentoModel);
  end;
end;

class procedure TFolhaTipoAfastamentoService.AttachLinkedObjects(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel);
begin
end;

class procedure TFolhaTipoAfastamentoService.InsertChildren(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel);
begin
end;

class procedure TFolhaTipoAfastamentoService.DeleteChildren(AFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel);
begin
end;

end.
