﻿unit FolhaLancamentoCabecalhoService;

interface

uses
  FolhaLancamentoCabecalhoModel, 
  FolhaLancamentoDetalheModel, 
  ViewPessoaColaboradorModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaLancamentoCabecalhoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaLancamentoCabecalhoModelList: TObjectList<TFolhaLancamentoCabecalhoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel); overload;
    class procedure InsertChildren(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel);
    class procedure DeleteChildren(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel);		
  public
    class function GetList: TObjectList<TFolhaLancamentoCabecalhoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaLancamentoCabecalhoModel>;
    class function GetObject(APk: Integer): TFolhaLancamentoCabecalhoModel;
    class procedure Insert(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel);
    class function Update(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel): Integer;
    class function Delete(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaLancamentoCabecalhoService }

class function TFolhaLancamentoCabecalhoService.GetList: TObjectList<TFolhaLancamentoCabecalhoModel>;
begin
  sql := 'SELECT * FROM folha_lancamento_cabecalho';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaLancamentoCabecalhoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaLancamentoCabecalhoService.GetListFilter(AWhere: string): TObjectList<TFolhaLancamentoCabecalhoModel>;
begin
  sql := 'SELECT * FROM folha_lancamento_cabecalho where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaLancamentoCabecalhoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaLancamentoCabecalhoService.GetObject(APk: Integer): TFolhaLancamentoCabecalhoModel;
begin
  sql := 'SELECT * FROM folha_lancamento_cabecalho WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaLancamentoCabecalhoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaLancamentoCabecalhoService.Insert(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel);
begin
  AFolhaLancamentoCabecalhoModel.Id := InsertBase(AFolhaLancamentoCabecalhoModel, 'folha_lancamento_cabecalho');
	InsertChildren(AFolhaLancamentoCabecalhoModel);
end;

class function TFolhaLancamentoCabecalhoService.Update(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel): Integer;
begin
  Result := UpdateBase(AFolhaLancamentoCabecalhoModel, 'folha_lancamento_cabecalho');
	DeleteChildren(AFolhaLancamentoCabecalhoModel);
  InsertChildren(AFolhaLancamentoCabecalhoModel);
end;

class function TFolhaLancamentoCabecalhoService.Delete(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel): Integer;
begin
	DeleteChildren(AFolhaLancamentoCabecalhoModel);
	Result := DeleteBase(AFolhaLancamentoCabecalhoModel.Id, 'folha_lancamento_cabecalho');
end;

class procedure TFolhaLancamentoCabecalhoService.AttachLinkedObjects(AFolhaLancamentoCabecalhoModelList: TObjectList<TFolhaLancamentoCabecalhoModel>);
var
  FolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel;
begin
  for FolhaLancamentoCabecalhoModel in AFolhaLancamentoCabecalhoModelList do
  begin
    AttachLinkedObjects(FolhaLancamentoCabecalhoModel);
  end;
end;

class procedure TFolhaLancamentoCabecalhoService.AttachLinkedObjects(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel);
begin
  // FolhaLancamentoDetalheModel
	sql := 'SELECT * FROM folha_lancamento_detalhe WHERE id_folha_lancamento_cabecalho = ' + AFolhaLancamentoCabecalhoModel.Id.ToString; 
	AFolhaLancamentoCabecalhoModel.FolhaLancamentoDetalheModelList := GetQuery(sql).AsObjectList<TFolhaLancamentoDetalheModel>; 

  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaLancamentoCabecalhoModel.IdColaborador.ToString; 
	AFolhaLancamentoCabecalhoModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

end;

class procedure TFolhaLancamentoCabecalhoService.InsertChildren(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel);
var
	FolhaLancamentoDetalheModel: TFolhaLancamentoDetalheModel;
begin
  // FolhaLancamentoDetalheModel 
	for FolhaLancamentoDetalheModel in AFolhaLancamentoCabecalhoModel.FolhaLancamentoDetalheModelList do 
	begin 
	  FolhaLancamentoDetalheModel.IdFolhaLancamentoCabecalho := AFolhaLancamentoCabecalhoModel.Id;
	  InsertBase(FolhaLancamentoDetalheModel, 'folha_lancamento_detalhe'); 
	end; 

end;

class procedure TFolhaLancamentoCabecalhoService.DeleteChildren(AFolhaLancamentoCabecalhoModel: TFolhaLancamentoCabecalhoModel);
begin
  DeleteChild(AFolhaLancamentoCabecalhoModel.Id, 'folha_lancamento_detalhe', 'id_folha_lancamento_cabecalho');
end;

end.
