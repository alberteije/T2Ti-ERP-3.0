﻿unit SefipCategoriaTrabalhoService;

interface

uses
  SefipCategoriaTrabalhoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TSefipCategoriaTrabalhoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(ASefipCategoriaTrabalhoModelList: TObjectList<TSefipCategoriaTrabalhoModel>); overload;
    class procedure AttachLinkedObjects(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel); overload;
    class procedure InsertChildren(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel);
    class procedure DeleteChildren(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel);		
  public
    class function GetList: TObjectList<TSefipCategoriaTrabalhoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TSefipCategoriaTrabalhoModel>;
    class function GetObject(APk: Integer): TSefipCategoriaTrabalhoModel;
    class procedure Insert(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel);
    class function Update(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel): Integer;
    class function Delete(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel): Integer;
  end;

var
  sql: string;


implementation

{ TSefipCategoriaTrabalhoService }

class function TSefipCategoriaTrabalhoService.GetList: TObjectList<TSefipCategoriaTrabalhoModel>;
begin
  sql := 'SELECT * FROM sefip_categoria_trabalho';
  try
    Result := GetQuery(sql).AsObjectList<TSefipCategoriaTrabalhoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSefipCategoriaTrabalhoService.GetListFilter(AWhere: string): TObjectList<TSefipCategoriaTrabalhoModel>;
begin
  sql := 'SELECT * FROM sefip_categoria_trabalho where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TSefipCategoriaTrabalhoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TSefipCategoriaTrabalhoService.GetObject(APk: Integer): TSefipCategoriaTrabalhoModel;
begin
  sql := 'SELECT * FROM sefip_categoria_trabalho WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TSefipCategoriaTrabalhoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TSefipCategoriaTrabalhoService.Insert(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel);
begin
  ASefipCategoriaTrabalhoModel.Id := InsertBase(ASefipCategoriaTrabalhoModel, 'sefip_categoria_trabalho');
	InsertChildren(ASefipCategoriaTrabalhoModel);
end;

class function TSefipCategoriaTrabalhoService.Update(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel): Integer;
begin
  Result := UpdateBase(ASefipCategoriaTrabalhoModel, 'sefip_categoria_trabalho');
	DeleteChildren(ASefipCategoriaTrabalhoModel);
  InsertChildren(ASefipCategoriaTrabalhoModel);
end;

class function TSefipCategoriaTrabalhoService.Delete(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel): Integer;
begin
	DeleteChildren(ASefipCategoriaTrabalhoModel);
	Result := DeleteBase(ASefipCategoriaTrabalhoModel.Id, 'sefip_categoria_trabalho');
end;

class procedure TSefipCategoriaTrabalhoService.AttachLinkedObjects(ASefipCategoriaTrabalhoModelList: TObjectList<TSefipCategoriaTrabalhoModel>);
var
  SefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel;
begin
  for SefipCategoriaTrabalhoModel in ASefipCategoriaTrabalhoModelList do
  begin
    AttachLinkedObjects(SefipCategoriaTrabalhoModel);
  end;
end;

class procedure TSefipCategoriaTrabalhoService.AttachLinkedObjects(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel);
begin
end;

class procedure TSefipCategoriaTrabalhoService.InsertChildren(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel);
begin
end;

class procedure TSefipCategoriaTrabalhoService.DeleteChildren(ASefipCategoriaTrabalhoModel: TSefipCategoriaTrabalhoModel);
begin
end;

end.
