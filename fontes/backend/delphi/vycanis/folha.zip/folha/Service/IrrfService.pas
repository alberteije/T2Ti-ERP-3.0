﻿unit IrrfService;

interface

uses
  IrrfModel, 
  IrrfDetalheModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TIrrfService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AIrrfModelList: TObjectList<TIrrfModel>); overload;
    class procedure AttachLinkedObjects(AIrrfModel: TIrrfModel); overload;
    class procedure InsertChildren(AIrrfModel: TIrrfModel);
    class procedure DeleteChildren(AIrrfModel: TIrrfModel);		
  public
    class function GetList: TObjectList<TIrrfModel>;
    class function GetListFilter(AWhere: string): TObjectList<TIrrfModel>;
    class function GetObject(APk: Integer): TIrrfModel;
    class procedure Insert(AIrrfModel: TIrrfModel);
    class function Update(AIrrfModel: TIrrfModel): Integer;
    class function Delete(AIrrfModel: TIrrfModel): Integer;
  end;

var
  sql: string;


implementation

{ TIrrfService }

class function TIrrfService.GetList: TObjectList<TIrrfModel>;
begin
  sql := 'SELECT * FROM irrf';
  try
    Result := GetQuery(sql).AsObjectList<TIrrfModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TIrrfService.GetListFilter(AWhere: string): TObjectList<TIrrfModel>;
begin
  sql := 'SELECT * FROM irrf where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TIrrfModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TIrrfService.GetObject(APk: Integer): TIrrfModel;
begin
  sql := 'SELECT * FROM irrf WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TIrrfModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TIrrfService.Insert(AIrrfModel: TIrrfModel);
begin
  AIrrfModel.Id := InsertBase(AIrrfModel, 'irrf');
	InsertChildren(AIrrfModel);
end;

class function TIrrfService.Update(AIrrfModel: TIrrfModel): Integer;
begin
  Result := UpdateBase(AIrrfModel, 'irrf');
	DeleteChildren(AIrrfModel);
  InsertChildren(AIrrfModel);
end;

class function TIrrfService.Delete(AIrrfModel: TIrrfModel): Integer;
begin
	DeleteChildren(AIrrfModel);
	Result := DeleteBase(AIrrfModel.Id, 'irrf');
end;

class procedure TIrrfService.AttachLinkedObjects(AIrrfModelList: TObjectList<TIrrfModel>);
var
  IrrfModel: TIrrfModel;
begin
  for IrrfModel in AIrrfModelList do
  begin
    AttachLinkedObjects(IrrfModel);
  end;
end;

class procedure TIrrfService.AttachLinkedObjects(AIrrfModel: TIrrfModel);
begin
  // IrrfDetalheModel
	sql := 'SELECT * FROM irrf_detalhe WHERE id_irrf = ' + AIrrfModel.Id.ToString; 
	AIrrfModel.IrrfDetalheModelList := GetQuery(sql).AsObjectList<TIrrfDetalheModel>; 

end;

class procedure TIrrfService.InsertChildren(AIrrfModel: TIrrfModel);
var
	IrrfDetalheModel: TIrrfDetalheModel;
begin
  // IrrfDetalheModel 
	for IrrfDetalheModel in AIrrfModel.IrrfDetalheModelList do 
	begin 
	  IrrfDetalheModel.IdIrrf := AIrrfModel.Id;
	  InsertBase(IrrfDetalheModel, 'irrf_detalhe'); 
	end; 

end;

class procedure TIrrfService.DeleteChildren(AIrrfModel: TIrrfModel);
begin
  DeleteChild(AIrrfModel.Id, 'irrf_detalhe', 'id_irrf');
end;

end.
