﻿unit FolhaEventoService;

interface

uses
  FolhaEventoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaEventoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaEventoModelList: TObjectList<TFolhaEventoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaEventoModel: TFolhaEventoModel); overload;
    class procedure InsertChildren(AFolhaEventoModel: TFolhaEventoModel);
    class procedure DeleteChildren(AFolhaEventoModel: TFolhaEventoModel);		
  public
    class function GetList: TObjectList<TFolhaEventoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaEventoModel>;
    class function GetObject(APk: Integer): TFolhaEventoModel;
    class procedure Insert(AFolhaEventoModel: TFolhaEventoModel);
    class function Update(AFolhaEventoModel: TFolhaEventoModel): Integer;
    class function Delete(AFolhaEventoModel: TFolhaEventoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaEventoService }

class function TFolhaEventoService.GetList: TObjectList<TFolhaEventoModel>;
begin
  sql := 'SELECT * FROM folha_evento';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaEventoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaEventoService.GetListFilter(AWhere: string): TObjectList<TFolhaEventoModel>;
begin
  sql := 'SELECT * FROM folha_evento where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaEventoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaEventoService.GetObject(APk: Integer): TFolhaEventoModel;
begin
  sql := 'SELECT * FROM folha_evento WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaEventoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaEventoService.Insert(AFolhaEventoModel: TFolhaEventoModel);
begin
  AFolhaEventoModel.Id := InsertBase(AFolhaEventoModel, 'folha_evento');
	InsertChildren(AFolhaEventoModel);
end;

class function TFolhaEventoService.Update(AFolhaEventoModel: TFolhaEventoModel): Integer;
begin
  Result := UpdateBase(AFolhaEventoModel, 'folha_evento');
	DeleteChildren(AFolhaEventoModel);
  InsertChildren(AFolhaEventoModel);
end;

class function TFolhaEventoService.Delete(AFolhaEventoModel: TFolhaEventoModel): Integer;
begin
	DeleteChildren(AFolhaEventoModel);
	Result := DeleteBase(AFolhaEventoModel.Id, 'folha_evento');
end;

class procedure TFolhaEventoService.AttachLinkedObjects(AFolhaEventoModelList: TObjectList<TFolhaEventoModel>);
var
  FolhaEventoModel: TFolhaEventoModel;
begin
  for FolhaEventoModel in AFolhaEventoModelList do
  begin
    AttachLinkedObjects(FolhaEventoModel);
  end;
end;

class procedure TFolhaEventoService.AttachLinkedObjects(AFolhaEventoModel: TFolhaEventoModel);
begin
end;

class procedure TFolhaEventoService.InsertChildren(AFolhaEventoModel: TFolhaEventoModel);
begin
end;

class procedure TFolhaEventoService.DeleteChildren(AFolhaEventoModel: TFolhaEventoModel);
begin
end;

end.
