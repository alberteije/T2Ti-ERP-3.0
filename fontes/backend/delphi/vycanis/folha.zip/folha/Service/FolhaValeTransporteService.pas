﻿unit FolhaValeTransporteService;

interface

uses
  FolhaValeTransporteModel, 
  ViewPessoaColaboradorModel, 
  EmpresaTransporteItinerarioModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaValeTransporteService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaValeTransporteModelList: TObjectList<TFolhaValeTransporteModel>); overload;
    class procedure AttachLinkedObjects(AFolhaValeTransporteModel: TFolhaValeTransporteModel); overload;
    class procedure InsertChildren(AFolhaValeTransporteModel: TFolhaValeTransporteModel);
    class procedure DeleteChildren(AFolhaValeTransporteModel: TFolhaValeTransporteModel);		
  public
    class function GetList: TObjectList<TFolhaValeTransporteModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaValeTransporteModel>;
    class function GetObject(APk: Integer): TFolhaValeTransporteModel;
    class procedure Insert(AFolhaValeTransporteModel: TFolhaValeTransporteModel);
    class function Update(AFolhaValeTransporteModel: TFolhaValeTransporteModel): Integer;
    class function Delete(AFolhaValeTransporteModel: TFolhaValeTransporteModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaValeTransporteService }

class function TFolhaValeTransporteService.GetList: TObjectList<TFolhaValeTransporteModel>;
begin
  sql := 'SELECT * FROM folha_vale_transporte';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaValeTransporteModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaValeTransporteService.GetListFilter(AWhere: string): TObjectList<TFolhaValeTransporteModel>;
begin
  sql := 'SELECT * FROM folha_vale_transporte where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaValeTransporteModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaValeTransporteService.GetObject(APk: Integer): TFolhaValeTransporteModel;
begin
  sql := 'SELECT * FROM folha_vale_transporte WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaValeTransporteModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaValeTransporteService.Insert(AFolhaValeTransporteModel: TFolhaValeTransporteModel);
begin
  AFolhaValeTransporteModel.Id := InsertBase(AFolhaValeTransporteModel, 'folha_vale_transporte');
	InsertChildren(AFolhaValeTransporteModel);
end;

class function TFolhaValeTransporteService.Update(AFolhaValeTransporteModel: TFolhaValeTransporteModel): Integer;
begin
  Result := UpdateBase(AFolhaValeTransporteModel, 'folha_vale_transporte');
	DeleteChildren(AFolhaValeTransporteModel);
  InsertChildren(AFolhaValeTransporteModel);
end;

class function TFolhaValeTransporteService.Delete(AFolhaValeTransporteModel: TFolhaValeTransporteModel): Integer;
begin
	DeleteChildren(AFolhaValeTransporteModel);
	Result := DeleteBase(AFolhaValeTransporteModel.Id, 'folha_vale_transporte');
end;

class procedure TFolhaValeTransporteService.AttachLinkedObjects(AFolhaValeTransporteModelList: TObjectList<TFolhaValeTransporteModel>);
var
  FolhaValeTransporteModel: TFolhaValeTransporteModel;
begin
  for FolhaValeTransporteModel in AFolhaValeTransporteModelList do
  begin
    AttachLinkedObjects(FolhaValeTransporteModel);
  end;
end;

class procedure TFolhaValeTransporteService.AttachLinkedObjects(AFolhaValeTransporteModel: TFolhaValeTransporteModel);
begin
  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaValeTransporteModel.IdColaborador.ToString; 
	AFolhaValeTransporteModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

  // EmpresaTransporteItinerarioModel 
	sql := 'SELECT * FROM empresa_transporte_itinerario WHERE id = ' + AFolhaValeTransporteModel.IdEmpresaTranspItin.ToString; 
	AFolhaValeTransporteModel.EmpresaTransporteItinerarioModel := GetQuery(sql).AsObject<TEmpresaTransporteItinerarioModel>; 

end;

class procedure TFolhaValeTransporteService.InsertChildren(AFolhaValeTransporteModel: TFolhaValeTransporteModel);
begin
end;

class procedure TFolhaValeTransporteService.DeleteChildren(AFolhaValeTransporteModel: TFolhaValeTransporteModel);
begin
end;

end.
