﻿unit FolhaFeriasColetivasService;

interface

uses
  FolhaFeriasColetivasModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaFeriasColetivasService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaFeriasColetivasModelList: TObjectList<TFolhaFeriasColetivasModel>); overload;
    class procedure AttachLinkedObjects(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel); overload;
    class procedure InsertChildren(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel);
    class procedure DeleteChildren(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel);		
  public
    class function GetList: TObjectList<TFolhaFeriasColetivasModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaFeriasColetivasModel>;
    class function GetObject(APk: Integer): TFolhaFeriasColetivasModel;
    class procedure Insert(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel);
    class function Update(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel): Integer;
    class function Delete(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaFeriasColetivasService }

class function TFolhaFeriasColetivasService.GetList: TObjectList<TFolhaFeriasColetivasModel>;
begin
  sql := 'SELECT * FROM folha_ferias_coletivas';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaFeriasColetivasModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaFeriasColetivasService.GetListFilter(AWhere: string): TObjectList<TFolhaFeriasColetivasModel>;
begin
  sql := 'SELECT * FROM folha_ferias_coletivas where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaFeriasColetivasModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaFeriasColetivasService.GetObject(APk: Integer): TFolhaFeriasColetivasModel;
begin
  sql := 'SELECT * FROM folha_ferias_coletivas WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaFeriasColetivasModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaFeriasColetivasService.Insert(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel);
begin
  AFolhaFeriasColetivasModel.Id := InsertBase(AFolhaFeriasColetivasModel, 'folha_ferias_coletivas');
	InsertChildren(AFolhaFeriasColetivasModel);
end;

class function TFolhaFeriasColetivasService.Update(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel): Integer;
begin
  Result := UpdateBase(AFolhaFeriasColetivasModel, 'folha_ferias_coletivas');
	DeleteChildren(AFolhaFeriasColetivasModel);
  InsertChildren(AFolhaFeriasColetivasModel);
end;

class function TFolhaFeriasColetivasService.Delete(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel): Integer;
begin
	DeleteChildren(AFolhaFeriasColetivasModel);
	Result := DeleteBase(AFolhaFeriasColetivasModel.Id, 'folha_ferias_coletivas');
end;

class procedure TFolhaFeriasColetivasService.AttachLinkedObjects(AFolhaFeriasColetivasModelList: TObjectList<TFolhaFeriasColetivasModel>);
var
  FolhaFeriasColetivasModel: TFolhaFeriasColetivasModel;
begin
  for FolhaFeriasColetivasModel in AFolhaFeriasColetivasModelList do
  begin
    AttachLinkedObjects(FolhaFeriasColetivasModel);
  end;
end;

class procedure TFolhaFeriasColetivasService.AttachLinkedObjects(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel);
begin
end;

class procedure TFolhaFeriasColetivasService.InsertChildren(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel);
begin
end;

class procedure TFolhaFeriasColetivasService.DeleteChildren(AFolhaFeriasColetivasModel: TFolhaFeriasColetivasModel);
begin
end;

end.
