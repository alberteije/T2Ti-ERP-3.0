﻿unit InssService;

interface

uses
  InssModel, 
  SalarioFamiliaModel, 
  InssDetalheModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TInssService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AInssModelList: TObjectList<TInssModel>); overload;
    class procedure AttachLinkedObjects(AInssModel: TInssModel); overload;
    class procedure InsertChildren(AInssModel: TInssModel);
    class procedure DeleteChildren(AInssModel: TInssModel);		
  public
    class function GetList: TObjectList<TInssModel>;
    class function GetListFilter(AWhere: string): TObjectList<TInssModel>;
    class function GetObject(APk: Integer): TInssModel;
    class procedure Insert(AInssModel: TInssModel);
    class function Update(AInssModel: TInssModel): Integer;
    class function Delete(AInssModel: TInssModel): Integer;
  end;

var
  sql: string;


implementation

{ TInssService }

class function TInssService.GetList: TObjectList<TInssModel>;
begin
  sql := 'SELECT * FROM inss';
  try
    Result := GetQuery(sql).AsObjectList<TInssModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TInssService.GetListFilter(AWhere: string): TObjectList<TInssModel>;
begin
  sql := 'SELECT * FROM inss where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TInssModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TInssService.GetObject(APk: Integer): TInssModel;
begin
  sql := 'SELECT * FROM inss WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TInssModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TInssService.Insert(AInssModel: TInssModel);
begin
  AInssModel.Id := InsertBase(AInssModel, 'inss');
	InsertChildren(AInssModel);
end;

class function TInssService.Update(AInssModel: TInssModel): Integer;
begin
  Result := UpdateBase(AInssModel, 'inss');
	DeleteChildren(AInssModel);
  InsertChildren(AInssModel);
end;

class function TInssService.Delete(AInssModel: TInssModel): Integer;
begin
	DeleteChildren(AInssModel);
	Result := DeleteBase(AInssModel.Id, 'inss');
end;

class procedure TInssService.AttachLinkedObjects(AInssModelList: TObjectList<TInssModel>);
var
  InssModel: TInssModel;
begin
  for InssModel in AInssModelList do
  begin
    AttachLinkedObjects(InssModel);
  end;
end;

class procedure TInssService.AttachLinkedObjects(AInssModel: TInssModel);
begin
  // SalarioFamiliaModel
	sql := 'SELECT * FROM salario_familia WHERE id_inss = ' + AInssModel.Id.ToString; 
	AInssModel.SalarioFamiliaModelList := GetQuery(sql).AsObjectList<TSalarioFamiliaModel>; 

  // InssDetalheModel
	sql := 'SELECT * FROM inss_detalhe WHERE id_inss = ' + AInssModel.Id.ToString; 
	AInssModel.InssDetalheModelList := GetQuery(sql).AsObjectList<TInssDetalheModel>; 

end;

class procedure TInssService.InsertChildren(AInssModel: TInssModel);
var
	SalarioFamiliaModel: TSalarioFamiliaModel;
	InssDetalheModel: TInssDetalheModel;
begin
  // SalarioFamiliaModel 
	for SalarioFamiliaModel in AInssModel.SalarioFamiliaModelList do 
	begin 
	  SalarioFamiliaModel.IdInss := AInssModel.Id;
	  InsertBase(SalarioFamiliaModel, 'salario_familia'); 
	end; 

  // InssDetalheModel 
	for InssDetalheModel in AInssModel.InssDetalheModelList do 
	begin 
	  InssDetalheModel.IdInss := AInssModel.Id;
	  InsertBase(InssDetalheModel, 'inss_detalhe'); 
	end; 

end;

class procedure TInssService.DeleteChildren(AInssModel: TInssModel);
begin
  DeleteChild(AInssModel.Id, 'salario_familia', 'id_inss');
  DeleteChild(AInssModel.Id, 'inss_detalhe', 'id_inss');
end;

end.
