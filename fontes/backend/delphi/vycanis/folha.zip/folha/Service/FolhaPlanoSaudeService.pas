﻿unit FolhaPlanoSaudeService;

interface

uses
  FolhaPlanoSaudeModel, 
  ViewPessoaColaboradorModel, 
  OperadoraPlanoSaudeModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaPlanoSaudeService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaPlanoSaudeModelList: TObjectList<TFolhaPlanoSaudeModel>); overload;
    class procedure AttachLinkedObjects(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel); overload;
    class procedure InsertChildren(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel);
    class procedure DeleteChildren(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel);		
  public
    class function GetList: TObjectList<TFolhaPlanoSaudeModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaPlanoSaudeModel>;
    class function GetObject(APk: Integer): TFolhaPlanoSaudeModel;
    class procedure Insert(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel);
    class function Update(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel): Integer;
    class function Delete(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaPlanoSaudeService }

class function TFolhaPlanoSaudeService.GetList: TObjectList<TFolhaPlanoSaudeModel>;
begin
  sql := 'SELECT * FROM folha_plano_saude';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaPlanoSaudeModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaPlanoSaudeService.GetListFilter(AWhere: string): TObjectList<TFolhaPlanoSaudeModel>;
begin
  sql := 'SELECT * FROM folha_plano_saude where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaPlanoSaudeModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaPlanoSaudeService.GetObject(APk: Integer): TFolhaPlanoSaudeModel;
begin
  sql := 'SELECT * FROM folha_plano_saude WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaPlanoSaudeModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaPlanoSaudeService.Insert(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel);
begin
  AFolhaPlanoSaudeModel.Id := InsertBase(AFolhaPlanoSaudeModel, 'folha_plano_saude');
	InsertChildren(AFolhaPlanoSaudeModel);
end;

class function TFolhaPlanoSaudeService.Update(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel): Integer;
begin
  Result := UpdateBase(AFolhaPlanoSaudeModel, 'folha_plano_saude');
	DeleteChildren(AFolhaPlanoSaudeModel);
  InsertChildren(AFolhaPlanoSaudeModel);
end;

class function TFolhaPlanoSaudeService.Delete(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel): Integer;
begin
	DeleteChildren(AFolhaPlanoSaudeModel);
	Result := DeleteBase(AFolhaPlanoSaudeModel.Id, 'folha_plano_saude');
end;

class procedure TFolhaPlanoSaudeService.AttachLinkedObjects(AFolhaPlanoSaudeModelList: TObjectList<TFolhaPlanoSaudeModel>);
var
  FolhaPlanoSaudeModel: TFolhaPlanoSaudeModel;
begin
  for FolhaPlanoSaudeModel in AFolhaPlanoSaudeModelList do
  begin
    AttachLinkedObjects(FolhaPlanoSaudeModel);
  end;
end;

class procedure TFolhaPlanoSaudeService.AttachLinkedObjects(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel);
begin
  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaPlanoSaudeModel.IdColaborador.ToString; 
	AFolhaPlanoSaudeModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

  // OperadoraPlanoSaudeModel 
	sql := 'SELECT * FROM operadora_plano_saude WHERE id = ' + AFolhaPlanoSaudeModel.IdOperadoraPlanoSaude.ToString; 
	AFolhaPlanoSaudeModel.OperadoraPlanoSaudeModel := GetQuery(sql).AsObject<TOperadoraPlanoSaudeModel>; 

end;

class procedure TFolhaPlanoSaudeService.InsertChildren(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel);
begin
end;

class procedure TFolhaPlanoSaudeService.DeleteChildren(AFolhaPlanoSaudeModel: TFolhaPlanoSaudeModel);
begin
end;

end.
