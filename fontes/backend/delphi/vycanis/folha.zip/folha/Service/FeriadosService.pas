﻿unit FeriadosService;

interface

uses
  FeriadosModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFeriadosService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFeriadosModelList: TObjectList<TFeriadosModel>); overload;
    class procedure AttachLinkedObjects(AFeriadosModel: TFeriadosModel); overload;
    class procedure InsertChildren(AFeriadosModel: TFeriadosModel);
    class procedure DeleteChildren(AFeriadosModel: TFeriadosModel);		
  public
    class function GetList: TObjectList<TFeriadosModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFeriadosModel>;
    class function GetObject(APk: Integer): TFeriadosModel;
    class procedure Insert(AFeriadosModel: TFeriadosModel);
    class function Update(AFeriadosModel: TFeriadosModel): Integer;
    class function Delete(AFeriadosModel: TFeriadosModel): Integer;
  end;

var
  sql: string;


implementation

{ TFeriadosService }

class function TFeriadosService.GetList: TObjectList<TFeriadosModel>;
begin
  sql := 'SELECT * FROM feriados';
  try
    Result := GetQuery(sql).AsObjectList<TFeriadosModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFeriadosService.GetListFilter(AWhere: string): TObjectList<TFeriadosModel>;
begin
  sql := 'SELECT * FROM feriados where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFeriadosModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFeriadosService.GetObject(APk: Integer): TFeriadosModel;
begin
  sql := 'SELECT * FROM feriados WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFeriadosModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFeriadosService.Insert(AFeriadosModel: TFeriadosModel);
begin
  AFeriadosModel.Id := InsertBase(AFeriadosModel, 'feriados');
	InsertChildren(AFeriadosModel);
end;

class function TFeriadosService.Update(AFeriadosModel: TFeriadosModel): Integer;
begin
  Result := UpdateBase(AFeriadosModel, 'feriados');
	DeleteChildren(AFeriadosModel);
  InsertChildren(AFeriadosModel);
end;

class function TFeriadosService.Delete(AFeriadosModel: TFeriadosModel): Integer;
begin
	DeleteChildren(AFeriadosModel);
	Result := DeleteBase(AFeriadosModel.Id, 'feriados');
end;

class procedure TFeriadosService.AttachLinkedObjects(AFeriadosModelList: TObjectList<TFeriadosModel>);
var
  FeriadosModel: TFeriadosModel;
begin
  for FeriadosModel in AFeriadosModelList do
  begin
    AttachLinkedObjects(FeriadosModel);
  end;
end;

class procedure TFeriadosService.AttachLinkedObjects(AFeriadosModel: TFeriadosModel);
begin
end;

class procedure TFeriadosService.InsertChildren(AFeriadosModel: TFeriadosModel);
begin
end;

class procedure TFeriadosService.DeleteChildren(AFeriadosModel: TFeriadosModel);
begin
end;

end.
