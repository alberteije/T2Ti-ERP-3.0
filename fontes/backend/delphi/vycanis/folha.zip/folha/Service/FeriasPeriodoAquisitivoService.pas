﻿unit FeriasPeriodoAquisitivoService;

interface

uses
  FeriasPeriodoAquisitivoModel, 
  ViewPessoaColaboradorModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFeriasPeriodoAquisitivoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFeriasPeriodoAquisitivoModelList: TObjectList<TFeriasPeriodoAquisitivoModel>); overload;
    class procedure AttachLinkedObjects(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel); overload;
    class procedure InsertChildren(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel);
    class procedure DeleteChildren(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel);		
  public
    class function GetList: TObjectList<TFeriasPeriodoAquisitivoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFeriasPeriodoAquisitivoModel>;
    class function GetObject(APk: Integer): TFeriasPeriodoAquisitivoModel;
    class procedure Insert(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel);
    class function Update(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel): Integer;
    class function Delete(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFeriasPeriodoAquisitivoService }

class function TFeriasPeriodoAquisitivoService.GetList: TObjectList<TFeriasPeriodoAquisitivoModel>;
begin
  sql := 'SELECT * FROM ferias_periodo_aquisitivo';
  try
    Result := GetQuery(sql).AsObjectList<TFeriasPeriodoAquisitivoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFeriasPeriodoAquisitivoService.GetListFilter(AWhere: string): TObjectList<TFeriasPeriodoAquisitivoModel>;
begin
  sql := 'SELECT * FROM ferias_periodo_aquisitivo where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFeriasPeriodoAquisitivoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFeriasPeriodoAquisitivoService.GetObject(APk: Integer): TFeriasPeriodoAquisitivoModel;
begin
  sql := 'SELECT * FROM ferias_periodo_aquisitivo WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFeriasPeriodoAquisitivoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFeriasPeriodoAquisitivoService.Insert(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel);
begin
  AFeriasPeriodoAquisitivoModel.Id := InsertBase(AFeriasPeriodoAquisitivoModel, 'ferias_periodo_aquisitivo');
	InsertChildren(AFeriasPeriodoAquisitivoModel);
end;

class function TFeriasPeriodoAquisitivoService.Update(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel): Integer;
begin
  Result := UpdateBase(AFeriasPeriodoAquisitivoModel, 'ferias_periodo_aquisitivo');
	DeleteChildren(AFeriasPeriodoAquisitivoModel);
  InsertChildren(AFeriasPeriodoAquisitivoModel);
end;

class function TFeriasPeriodoAquisitivoService.Delete(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel): Integer;
begin
	DeleteChildren(AFeriasPeriodoAquisitivoModel);
	Result := DeleteBase(AFeriasPeriodoAquisitivoModel.Id, 'ferias_periodo_aquisitivo');
end;

class procedure TFeriasPeriodoAquisitivoService.AttachLinkedObjects(AFeriasPeriodoAquisitivoModelList: TObjectList<TFeriasPeriodoAquisitivoModel>);
var
  FeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel;
begin
  for FeriasPeriodoAquisitivoModel in AFeriasPeriodoAquisitivoModelList do
  begin
    AttachLinkedObjects(FeriasPeriodoAquisitivoModel);
  end;
end;

class procedure TFeriasPeriodoAquisitivoService.AttachLinkedObjects(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel);
begin
  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFeriasPeriodoAquisitivoModel.IdColaborador.ToString; 
	AFeriasPeriodoAquisitivoModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

end;

class procedure TFeriasPeriodoAquisitivoService.InsertChildren(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel);
begin
end;

class procedure TFeriasPeriodoAquisitivoService.DeleteChildren(AFeriasPeriodoAquisitivoModel: TFeriasPeriodoAquisitivoModel);
begin
end;

end.
