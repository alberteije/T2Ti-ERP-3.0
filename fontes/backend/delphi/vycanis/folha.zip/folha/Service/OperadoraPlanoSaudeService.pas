﻿unit OperadoraPlanoSaudeService;

interface

uses
  OperadoraPlanoSaudeModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TOperadoraPlanoSaudeService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AOperadoraPlanoSaudeModelList: TObjectList<TOperadoraPlanoSaudeModel>); overload;
    class procedure AttachLinkedObjects(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel); overload;
    class procedure InsertChildren(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel);
    class procedure DeleteChildren(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel);		
  public
    class function GetList: TObjectList<TOperadoraPlanoSaudeModel>;
    class function GetListFilter(AWhere: string): TObjectList<TOperadoraPlanoSaudeModel>;
    class function GetObject(APk: Integer): TOperadoraPlanoSaudeModel;
    class procedure Insert(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel);
    class function Update(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel): Integer;
    class function Delete(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel): Integer;
  end;

var
  sql: string;


implementation

{ TOperadoraPlanoSaudeService }

class function TOperadoraPlanoSaudeService.GetList: TObjectList<TOperadoraPlanoSaudeModel>;
begin
  sql := 'SELECT * FROM operadora_plano_saude';
  try
    Result := GetQuery(sql).AsObjectList<TOperadoraPlanoSaudeModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TOperadoraPlanoSaudeService.GetListFilter(AWhere: string): TObjectList<TOperadoraPlanoSaudeModel>;
begin
  sql := 'SELECT * FROM operadora_plano_saude where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TOperadoraPlanoSaudeModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TOperadoraPlanoSaudeService.GetObject(APk: Integer): TOperadoraPlanoSaudeModel;
begin
  sql := 'SELECT * FROM operadora_plano_saude WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TOperadoraPlanoSaudeModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TOperadoraPlanoSaudeService.Insert(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel);
begin
  AOperadoraPlanoSaudeModel.Id := InsertBase(AOperadoraPlanoSaudeModel, 'operadora_plano_saude');
	InsertChildren(AOperadoraPlanoSaudeModel);
end;

class function TOperadoraPlanoSaudeService.Update(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel): Integer;
begin
  Result := UpdateBase(AOperadoraPlanoSaudeModel, 'operadora_plano_saude');
	DeleteChildren(AOperadoraPlanoSaudeModel);
  InsertChildren(AOperadoraPlanoSaudeModel);
end;

class function TOperadoraPlanoSaudeService.Delete(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel): Integer;
begin
	DeleteChildren(AOperadoraPlanoSaudeModel);
	Result := DeleteBase(AOperadoraPlanoSaudeModel.Id, 'operadora_plano_saude');
end;

class procedure TOperadoraPlanoSaudeService.AttachLinkedObjects(AOperadoraPlanoSaudeModelList: TObjectList<TOperadoraPlanoSaudeModel>);
var
  OperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel;
begin
  for OperadoraPlanoSaudeModel in AOperadoraPlanoSaudeModelList do
  begin
    AttachLinkedObjects(OperadoraPlanoSaudeModel);
  end;
end;

class procedure TOperadoraPlanoSaudeService.AttachLinkedObjects(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel);
begin
end;

class procedure TOperadoraPlanoSaudeService.InsertChildren(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel);
begin
end;

class procedure TOperadoraPlanoSaudeService.DeleteChildren(AOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel);
begin
end;

end.
