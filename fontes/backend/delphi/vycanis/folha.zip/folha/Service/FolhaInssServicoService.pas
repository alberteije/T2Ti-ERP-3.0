﻿unit FolhaInssServicoService;

interface

uses
  FolhaInssServicoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaInssServicoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaInssServicoModelList: TObjectList<TFolhaInssServicoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaInssServicoModel: TFolhaInssServicoModel); overload;
    class procedure InsertChildren(AFolhaInssServicoModel: TFolhaInssServicoModel);
    class procedure DeleteChildren(AFolhaInssServicoModel: TFolhaInssServicoModel);		
  public
    class function GetList: TObjectList<TFolhaInssServicoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaInssServicoModel>;
    class function GetObject(APk: Integer): TFolhaInssServicoModel;
    class procedure Insert(AFolhaInssServicoModel: TFolhaInssServicoModel);
    class function Update(AFolhaInssServicoModel: TFolhaInssServicoModel): Integer;
    class function Delete(AFolhaInssServicoModel: TFolhaInssServicoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaInssServicoService }

class function TFolhaInssServicoService.GetList: TObjectList<TFolhaInssServicoModel>;
begin
  sql := 'SELECT * FROM folha_inss_servico';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaInssServicoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaInssServicoService.GetListFilter(AWhere: string): TObjectList<TFolhaInssServicoModel>;
begin
  sql := 'SELECT * FROM folha_inss_servico where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaInssServicoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaInssServicoService.GetObject(APk: Integer): TFolhaInssServicoModel;
begin
  sql := 'SELECT * FROM folha_inss_servico WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaInssServicoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaInssServicoService.Insert(AFolhaInssServicoModel: TFolhaInssServicoModel);
begin
  AFolhaInssServicoModel.Id := InsertBase(AFolhaInssServicoModel, 'folha_inss_servico');
	InsertChildren(AFolhaInssServicoModel);
end;

class function TFolhaInssServicoService.Update(AFolhaInssServicoModel: TFolhaInssServicoModel): Integer;
begin
  Result := UpdateBase(AFolhaInssServicoModel, 'folha_inss_servico');
	DeleteChildren(AFolhaInssServicoModel);
  InsertChildren(AFolhaInssServicoModel);
end;

class function TFolhaInssServicoService.Delete(AFolhaInssServicoModel: TFolhaInssServicoModel): Integer;
begin
	DeleteChildren(AFolhaInssServicoModel);
	Result := DeleteBase(AFolhaInssServicoModel.Id, 'folha_inss_servico');
end;

class procedure TFolhaInssServicoService.AttachLinkedObjects(AFolhaInssServicoModelList: TObjectList<TFolhaInssServicoModel>);
var
  FolhaInssServicoModel: TFolhaInssServicoModel;
begin
  for FolhaInssServicoModel in AFolhaInssServicoModelList do
  begin
    AttachLinkedObjects(FolhaInssServicoModel);
  end;
end;

class procedure TFolhaInssServicoService.AttachLinkedObjects(AFolhaInssServicoModel: TFolhaInssServicoModel);
begin
end;

class procedure TFolhaInssServicoService.InsertChildren(AFolhaInssServicoModel: TFolhaInssServicoModel);
begin
end;

class procedure TFolhaInssServicoService.DeleteChildren(AFolhaInssServicoModel: TFolhaInssServicoModel);
begin
end;

end.
