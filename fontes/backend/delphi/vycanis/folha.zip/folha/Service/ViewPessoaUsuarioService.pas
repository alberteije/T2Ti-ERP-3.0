﻿unit ViewPessoaUsuarioService;

interface

uses
  ViewPessoaUsuarioModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TViewPessoaUsuarioService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AViewPessoaUsuarioModelList: TObjectList<TViewPessoaUsuarioModel>); overload;
    class procedure AttachLinkedObjects(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel); overload;
    class procedure InsertChildren(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel);
    class procedure DeleteChildren(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel);		
  public
    class function GetList: TObjectList<TViewPessoaUsuarioModel>;
    class function GetListFilter(AWhere: string): TObjectList<TViewPessoaUsuarioModel>;
    class function GetObject(APk: Integer): TViewPessoaUsuarioModel;
    class procedure Insert(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel);
    class function Update(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel): Integer;
    class function Delete(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel): Integer;
  end;

var
  sql: string;


implementation

{ TViewPessoaUsuarioService }

class function TViewPessoaUsuarioService.GetList: TObjectList<TViewPessoaUsuarioModel>;
begin
  sql := 'SELECT * FROM view_pessoa_usuario';
  try
    Result := GetQuery(sql).AsObjectList<TViewPessoaUsuarioModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TViewPessoaUsuarioService.GetListFilter(AWhere: string): TObjectList<TViewPessoaUsuarioModel>;
begin
  sql := 'SELECT * FROM view_pessoa_usuario where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TViewPessoaUsuarioModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TViewPessoaUsuarioService.GetObject(APk: Integer): TViewPessoaUsuarioModel;
begin
  sql := 'SELECT * FROM view_pessoa_usuario WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TViewPessoaUsuarioModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TViewPessoaUsuarioService.Insert(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel);
begin
  AViewPessoaUsuarioModel.Id := InsertBase(AViewPessoaUsuarioModel, 'view_pessoa_usuario');
	InsertChildren(AViewPessoaUsuarioModel);
end;

class function TViewPessoaUsuarioService.Update(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel): Integer;
begin
  Result := UpdateBase(AViewPessoaUsuarioModel, 'view_pessoa_usuario');
	DeleteChildren(AViewPessoaUsuarioModel);
  InsertChildren(AViewPessoaUsuarioModel);
end;

class function TViewPessoaUsuarioService.Delete(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel): Integer;
begin
	DeleteChildren(AViewPessoaUsuarioModel);
	Result := DeleteBase(AViewPessoaUsuarioModel.Id, 'view_pessoa_usuario');
end;

class procedure TViewPessoaUsuarioService.AttachLinkedObjects(AViewPessoaUsuarioModelList: TObjectList<TViewPessoaUsuarioModel>);
var
  ViewPessoaUsuarioModel: TViewPessoaUsuarioModel;
begin
  for ViewPessoaUsuarioModel in AViewPessoaUsuarioModelList do
  begin
    AttachLinkedObjects(ViewPessoaUsuarioModel);
  end;
end;

class procedure TViewPessoaUsuarioService.AttachLinkedObjects(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel);
begin
end;

class procedure TViewPessoaUsuarioService.InsertChildren(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel);
begin
end;

class procedure TViewPessoaUsuarioService.DeleteChildren(AViewPessoaUsuarioModel: TViewPessoaUsuarioModel);
begin
end;

end.
