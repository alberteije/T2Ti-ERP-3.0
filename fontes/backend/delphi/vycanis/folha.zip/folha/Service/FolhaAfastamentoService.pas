﻿unit FolhaAfastamentoService;

interface

uses
  FolhaAfastamentoModel, 
  ViewPessoaColaboradorModel, 
  FolhaTipoAfastamentoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaAfastamentoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaAfastamentoModelList: TObjectList<TFolhaAfastamentoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaAfastamentoModel: TFolhaAfastamentoModel); overload;
    class procedure InsertChildren(AFolhaAfastamentoModel: TFolhaAfastamentoModel);
    class procedure DeleteChildren(AFolhaAfastamentoModel: TFolhaAfastamentoModel);		
  public
    class function GetList: TObjectList<TFolhaAfastamentoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaAfastamentoModel>;
    class function GetObject(APk: Integer): TFolhaAfastamentoModel;
    class procedure Insert(AFolhaAfastamentoModel: TFolhaAfastamentoModel);
    class function Update(AFolhaAfastamentoModel: TFolhaAfastamentoModel): Integer;
    class function Delete(AFolhaAfastamentoModel: TFolhaAfastamentoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaAfastamentoService }

class function TFolhaAfastamentoService.GetList: TObjectList<TFolhaAfastamentoModel>;
begin
  sql := 'SELECT * FROM folha_afastamento';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaAfastamentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaAfastamentoService.GetListFilter(AWhere: string): TObjectList<TFolhaAfastamentoModel>;
begin
  sql := 'SELECT * FROM folha_afastamento where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaAfastamentoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaAfastamentoService.GetObject(APk: Integer): TFolhaAfastamentoModel;
begin
  sql := 'SELECT * FROM folha_afastamento WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaAfastamentoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaAfastamentoService.Insert(AFolhaAfastamentoModel: TFolhaAfastamentoModel);
begin
  AFolhaAfastamentoModel.Id := InsertBase(AFolhaAfastamentoModel, 'folha_afastamento');
	InsertChildren(AFolhaAfastamentoModel);
end;

class function TFolhaAfastamentoService.Update(AFolhaAfastamentoModel: TFolhaAfastamentoModel): Integer;
begin
  Result := UpdateBase(AFolhaAfastamentoModel, 'folha_afastamento');
	DeleteChildren(AFolhaAfastamentoModel);
  InsertChildren(AFolhaAfastamentoModel);
end;

class function TFolhaAfastamentoService.Delete(AFolhaAfastamentoModel: TFolhaAfastamentoModel): Integer;
begin
	DeleteChildren(AFolhaAfastamentoModel);
	Result := DeleteBase(AFolhaAfastamentoModel.Id, 'folha_afastamento');
end;

class procedure TFolhaAfastamentoService.AttachLinkedObjects(AFolhaAfastamentoModelList: TObjectList<TFolhaAfastamentoModel>);
var
  FolhaAfastamentoModel: TFolhaAfastamentoModel;
begin
  for FolhaAfastamentoModel in AFolhaAfastamentoModelList do
  begin
    AttachLinkedObjects(FolhaAfastamentoModel);
  end;
end;

class procedure TFolhaAfastamentoService.AttachLinkedObjects(AFolhaAfastamentoModel: TFolhaAfastamentoModel);
begin
  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaAfastamentoModel.IdColaborador.ToString; 
	AFolhaAfastamentoModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

  // FolhaTipoAfastamentoModel 
	sql := 'SELECT * FROM folha_tipo_afastamento WHERE id = ' + AFolhaAfastamentoModel.IdFolhaTipoAfastamento.ToString; 
	AFolhaAfastamentoModel.FolhaTipoAfastamentoModel := GetQuery(sql).AsObject<TFolhaTipoAfastamentoModel>; 

end;

class procedure TFolhaAfastamentoService.InsertChildren(AFolhaAfastamentoModel: TFolhaAfastamentoModel);
begin
end;

class procedure TFolhaAfastamentoService.DeleteChildren(AFolhaAfastamentoModel: TFolhaAfastamentoModel);
begin
end;

end.
