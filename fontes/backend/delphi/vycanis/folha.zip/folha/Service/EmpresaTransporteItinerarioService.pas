﻿unit EmpresaTransporteItinerarioService;

interface

uses
  EmpresaTransporteItinerarioModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TEmpresaTransporteItinerarioService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AEmpresaTransporteItinerarioModelList: TObjectList<TEmpresaTransporteItinerarioModel>); overload;
    class procedure AttachLinkedObjects(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel); overload;
    class procedure InsertChildren(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel);
    class procedure DeleteChildren(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel);		
  public
    class function GetList: TObjectList<TEmpresaTransporteItinerarioModel>;
    class function GetListFilter(AWhere: string): TObjectList<TEmpresaTransporteItinerarioModel>;
    class function GetObject(APk: Integer): TEmpresaTransporteItinerarioModel;
    class procedure Insert(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel);
    class function Update(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel): Integer;
    class function Delete(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel): Integer;
  end;

var
  sql: string;


implementation

{ TEmpresaTransporteItinerarioService }

class function TEmpresaTransporteItinerarioService.GetList: TObjectList<TEmpresaTransporteItinerarioModel>;
begin
  sql := 'SELECT * FROM empresa_transporte_itinerario';
  try
    Result := GetQuery(sql).AsObjectList<TEmpresaTransporteItinerarioModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TEmpresaTransporteItinerarioService.GetListFilter(AWhere: string): TObjectList<TEmpresaTransporteItinerarioModel>;
begin
  sql := 'SELECT * FROM empresa_transporte_itinerario where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TEmpresaTransporteItinerarioModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TEmpresaTransporteItinerarioService.GetObject(APk: Integer): TEmpresaTransporteItinerarioModel;
begin
  sql := 'SELECT * FROM empresa_transporte_itinerario WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TEmpresaTransporteItinerarioModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TEmpresaTransporteItinerarioService.Insert(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel);
begin
  AEmpresaTransporteItinerarioModel.Id := InsertBase(AEmpresaTransporteItinerarioModel, 'empresa_transporte_itinerario');
	InsertChildren(AEmpresaTransporteItinerarioModel);
end;

class function TEmpresaTransporteItinerarioService.Update(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel): Integer;
begin
  Result := UpdateBase(AEmpresaTransporteItinerarioModel, 'empresa_transporte_itinerario');
	DeleteChildren(AEmpresaTransporteItinerarioModel);
  InsertChildren(AEmpresaTransporteItinerarioModel);
end;

class function TEmpresaTransporteItinerarioService.Delete(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel): Integer;
begin
	DeleteChildren(AEmpresaTransporteItinerarioModel);
	Result := DeleteBase(AEmpresaTransporteItinerarioModel.Id, 'empresa_transporte_itinerario');
end;

class procedure TEmpresaTransporteItinerarioService.AttachLinkedObjects(AEmpresaTransporteItinerarioModelList: TObjectList<TEmpresaTransporteItinerarioModel>);
var
  EmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel;
begin
  for EmpresaTransporteItinerarioModel in AEmpresaTransporteItinerarioModelList do
  begin
    AttachLinkedObjects(EmpresaTransporteItinerarioModel);
  end;
end;

class procedure TEmpresaTransporteItinerarioService.AttachLinkedObjects(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel);
begin
end;

class procedure TEmpresaTransporteItinerarioService.InsertChildren(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel);
begin
end;

class procedure TEmpresaTransporteItinerarioService.DeleteChildren(AEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel);
begin
end;

end.
