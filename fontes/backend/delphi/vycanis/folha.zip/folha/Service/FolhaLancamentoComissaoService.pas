﻿unit FolhaLancamentoComissaoService;

interface

uses
  FolhaLancamentoComissaoModel, 
  ViewPessoaColaboradorModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaLancamentoComissaoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaLancamentoComissaoModelList: TObjectList<TFolhaLancamentoComissaoModel>); overload;
    class procedure AttachLinkedObjects(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel); overload;
    class procedure InsertChildren(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel);
    class procedure DeleteChildren(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel);		
  public
    class function GetList: TObjectList<TFolhaLancamentoComissaoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaLancamentoComissaoModel>;
    class function GetObject(APk: Integer): TFolhaLancamentoComissaoModel;
    class procedure Insert(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel);
    class function Update(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel): Integer;
    class function Delete(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaLancamentoComissaoService }

class function TFolhaLancamentoComissaoService.GetList: TObjectList<TFolhaLancamentoComissaoModel>;
begin
  sql := 'SELECT * FROM folha_lancamento_comissao';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaLancamentoComissaoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaLancamentoComissaoService.GetListFilter(AWhere: string): TObjectList<TFolhaLancamentoComissaoModel>;
begin
  sql := 'SELECT * FROM folha_lancamento_comissao where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaLancamentoComissaoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaLancamentoComissaoService.GetObject(APk: Integer): TFolhaLancamentoComissaoModel;
begin
  sql := 'SELECT * FROM folha_lancamento_comissao WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaLancamentoComissaoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaLancamentoComissaoService.Insert(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel);
begin
  AFolhaLancamentoComissaoModel.Id := InsertBase(AFolhaLancamentoComissaoModel, 'folha_lancamento_comissao');
	InsertChildren(AFolhaLancamentoComissaoModel);
end;

class function TFolhaLancamentoComissaoService.Update(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel): Integer;
begin
  Result := UpdateBase(AFolhaLancamentoComissaoModel, 'folha_lancamento_comissao');
	DeleteChildren(AFolhaLancamentoComissaoModel);
  InsertChildren(AFolhaLancamentoComissaoModel);
end;

class function TFolhaLancamentoComissaoService.Delete(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel): Integer;
begin
	DeleteChildren(AFolhaLancamentoComissaoModel);
	Result := DeleteBase(AFolhaLancamentoComissaoModel.Id, 'folha_lancamento_comissao');
end;

class procedure TFolhaLancamentoComissaoService.AttachLinkedObjects(AFolhaLancamentoComissaoModelList: TObjectList<TFolhaLancamentoComissaoModel>);
var
  FolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel;
begin
  for FolhaLancamentoComissaoModel in AFolhaLancamentoComissaoModelList do
  begin
    AttachLinkedObjects(FolhaLancamentoComissaoModel);
  end;
end;

class procedure TFolhaLancamentoComissaoService.AttachLinkedObjects(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel);
begin
  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaLancamentoComissaoModel.IdColaborador.ToString; 
	AFolhaLancamentoComissaoModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

end;

class procedure TFolhaLancamentoComissaoService.InsertChildren(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel);
begin
end;

class procedure TFolhaLancamentoComissaoService.DeleteChildren(AFolhaLancamentoComissaoModel: TFolhaLancamentoComissaoModel);
begin
end;

end.
