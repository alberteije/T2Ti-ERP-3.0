﻿unit FolhaInssService;

interface

uses
  FolhaInssModel, 
  FolhaInssRetencaoModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaInssService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaInssModelList: TObjectList<TFolhaInssModel>); overload;
    class procedure AttachLinkedObjects(AFolhaInssModel: TFolhaInssModel); overload;
    class procedure InsertChildren(AFolhaInssModel: TFolhaInssModel);
    class procedure DeleteChildren(AFolhaInssModel: TFolhaInssModel);		
  public
    class function GetList: TObjectList<TFolhaInssModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaInssModel>;
    class function GetObject(APk: Integer): TFolhaInssModel;
    class procedure Insert(AFolhaInssModel: TFolhaInssModel);
    class function Update(AFolhaInssModel: TFolhaInssModel): Integer;
    class function Delete(AFolhaInssModel: TFolhaInssModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaInssService }

class function TFolhaInssService.GetList: TObjectList<TFolhaInssModel>;
begin
  sql := 'SELECT * FROM folha_inss';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaInssModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaInssService.GetListFilter(AWhere: string): TObjectList<TFolhaInssModel>;
begin
  sql := 'SELECT * FROM folha_inss where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaInssModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaInssService.GetObject(APk: Integer): TFolhaInssModel;
begin
  sql := 'SELECT * FROM folha_inss WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaInssModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaInssService.Insert(AFolhaInssModel: TFolhaInssModel);
begin
  AFolhaInssModel.Id := InsertBase(AFolhaInssModel, 'folha_inss');
	InsertChildren(AFolhaInssModel);
end;

class function TFolhaInssService.Update(AFolhaInssModel: TFolhaInssModel): Integer;
begin
  Result := UpdateBase(AFolhaInssModel, 'folha_inss');
	DeleteChildren(AFolhaInssModel);
  InsertChildren(AFolhaInssModel);
end;

class function TFolhaInssService.Delete(AFolhaInssModel: TFolhaInssModel): Integer;
begin
	DeleteChildren(AFolhaInssModel);
	Result := DeleteBase(AFolhaInssModel.Id, 'folha_inss');
end;

class procedure TFolhaInssService.AttachLinkedObjects(AFolhaInssModelList: TObjectList<TFolhaInssModel>);
var
  FolhaInssModel: TFolhaInssModel;
begin
  for FolhaInssModel in AFolhaInssModelList do
  begin
    AttachLinkedObjects(FolhaInssModel);
  end;
end;

class procedure TFolhaInssService.AttachLinkedObjects(AFolhaInssModel: TFolhaInssModel);
begin
  // FolhaInssRetencaoModel
	sql := 'SELECT * FROM folha_inss_retencao WHERE id_folha_inss = ' + AFolhaInssModel.Id.ToString; 
	AFolhaInssModel.FolhaInssRetencaoModelList := GetQuery(sql).AsObjectList<TFolhaInssRetencaoModel>; 

end;

class procedure TFolhaInssService.InsertChildren(AFolhaInssModel: TFolhaInssModel);
var
	FolhaInssRetencaoModel: TFolhaInssRetencaoModel;
begin
  // FolhaInssRetencaoModel 
	for FolhaInssRetencaoModel in AFolhaInssModel.FolhaInssRetencaoModelList do 
	begin 
	  FolhaInssRetencaoModel.IdFolhaInss := AFolhaInssModel.Id;
	  InsertBase(FolhaInssRetencaoModel, 'folha_inss_retencao'); 
	end; 

end;

class procedure TFolhaInssService.DeleteChildren(AFolhaInssModel: TFolhaInssModel);
begin
  DeleteChild(AFolhaInssModel.Id, 'folha_inss_retencao', 'id_folha_inss');
end;

end.
