﻿unit FolhaPppService;

interface

uses
  FolhaPppModel, 
  FolhaPppCatModel, 
  FolhaPppAtividadeModel, 
  FolhaPppFatorRiscoModel, 
  FolhaPppExameMedicoModel, 
  ViewPessoaColaboradorModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TFolhaPppService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(AFolhaPppModelList: TObjectList<TFolhaPppModel>); overload;
    class procedure AttachLinkedObjects(AFolhaPppModel: TFolhaPppModel); overload;
    class procedure InsertChildren(AFolhaPppModel: TFolhaPppModel);
    class procedure DeleteChildren(AFolhaPppModel: TFolhaPppModel);		
  public
    class function GetList: TObjectList<TFolhaPppModel>;
    class function GetListFilter(AWhere: string): TObjectList<TFolhaPppModel>;
    class function GetObject(APk: Integer): TFolhaPppModel;
    class procedure Insert(AFolhaPppModel: TFolhaPppModel);
    class function Update(AFolhaPppModel: TFolhaPppModel): Integer;
    class function Delete(AFolhaPppModel: TFolhaPppModel): Integer;
  end;

var
  sql: string;


implementation

{ TFolhaPppService }

class function TFolhaPppService.GetList: TObjectList<TFolhaPppModel>;
begin
  sql := 'SELECT * FROM folha_ppp';
  try
    Result := GetQuery(sql).AsObjectList<TFolhaPppModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaPppService.GetListFilter(AWhere: string): TObjectList<TFolhaPppModel>;
begin
  sql := 'SELECT * FROM folha_ppp where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TFolhaPppModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TFolhaPppService.GetObject(APk: Integer): TFolhaPppModel;
begin
  sql := 'SELECT * FROM folha_ppp WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TFolhaPppModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TFolhaPppService.Insert(AFolhaPppModel: TFolhaPppModel);
begin
  AFolhaPppModel.Id := InsertBase(AFolhaPppModel, 'folha_ppp');
	InsertChildren(AFolhaPppModel);
end;

class function TFolhaPppService.Update(AFolhaPppModel: TFolhaPppModel): Integer;
begin
  Result := UpdateBase(AFolhaPppModel, 'folha_ppp');
	DeleteChildren(AFolhaPppModel);
  InsertChildren(AFolhaPppModel);
end;

class function TFolhaPppService.Delete(AFolhaPppModel: TFolhaPppModel): Integer;
begin
	DeleteChildren(AFolhaPppModel);
	Result := DeleteBase(AFolhaPppModel.Id, 'folha_ppp');
end;

class procedure TFolhaPppService.AttachLinkedObjects(AFolhaPppModelList: TObjectList<TFolhaPppModel>);
var
  FolhaPppModel: TFolhaPppModel;
begin
  for FolhaPppModel in AFolhaPppModelList do
  begin
    AttachLinkedObjects(FolhaPppModel);
  end;
end;

class procedure TFolhaPppService.AttachLinkedObjects(AFolhaPppModel: TFolhaPppModel);
begin
  // FolhaPppCatModel
	sql := 'SELECT * FROM folha_ppp_cat WHERE id_folha_ppp = ' + AFolhaPppModel.Id.ToString; 
	AFolhaPppModel.FolhaPppCatModelList := GetQuery(sql).AsObjectList<TFolhaPppCatModel>; 

  // FolhaPppAtividadeModel
	sql := 'SELECT * FROM folha_ppp_atividade WHERE id_folha_ppp = ' + AFolhaPppModel.Id.ToString; 
	AFolhaPppModel.FolhaPppAtividadeModelList := GetQuery(sql).AsObjectList<TFolhaPppAtividadeModel>; 

  // FolhaPppFatorRiscoModel
	sql := 'SELECT * FROM folha_ppp_fator_risco WHERE id_folha_ppp = ' + AFolhaPppModel.Id.ToString; 
	AFolhaPppModel.FolhaPppFatorRiscoModelList := GetQuery(sql).AsObjectList<TFolhaPppFatorRiscoModel>; 

  // FolhaPppExameMedicoModel
	sql := 'SELECT * FROM folha_ppp_exame_medico WHERE id_folha_ppp = ' + AFolhaPppModel.Id.ToString; 
	AFolhaPppModel.FolhaPppExameMedicoModelList := GetQuery(sql).AsObjectList<TFolhaPppExameMedicoModel>; 

  // ViewPessoaColaboradorModel 
	sql := 'SELECT * FROM view_pessoa_colaborador WHERE id = ' + AFolhaPppModel.IdColaborador.ToString; 
	AFolhaPppModel.ViewPessoaColaboradorModel := GetQuery(sql).AsObject<TViewPessoaColaboradorModel>; 

end;

class procedure TFolhaPppService.InsertChildren(AFolhaPppModel: TFolhaPppModel);
var
	FolhaPppCatModel: TFolhaPppCatModel;
	FolhaPppAtividadeModel: TFolhaPppAtividadeModel;
	FolhaPppFatorRiscoModel: TFolhaPppFatorRiscoModel;
	FolhaPppExameMedicoModel: TFolhaPppExameMedicoModel;
begin
  // FolhaPppCatModel 
	for FolhaPppCatModel in AFolhaPppModel.FolhaPppCatModelList do 
	begin 
	  FolhaPppCatModel.IdFolhaPpp := AFolhaPppModel.Id;
	  InsertBase(FolhaPppCatModel, 'folha_ppp_cat'); 
	end; 

  // FolhaPppAtividadeModel 
	for FolhaPppAtividadeModel in AFolhaPppModel.FolhaPppAtividadeModelList do 
	begin 
	  FolhaPppAtividadeModel.IdFolhaPpp := AFolhaPppModel.Id;
	  InsertBase(FolhaPppAtividadeModel, 'folha_ppp_atividade'); 
	end; 

  // FolhaPppFatorRiscoModel 
	for FolhaPppFatorRiscoModel in AFolhaPppModel.FolhaPppFatorRiscoModelList do 
	begin 
	  FolhaPppFatorRiscoModel.IdFolhaPpp := AFolhaPppModel.Id;
	  InsertBase(FolhaPppFatorRiscoModel, 'folha_ppp_fator_risco'); 
	end; 

  // FolhaPppExameMedicoModel 
	for FolhaPppExameMedicoModel in AFolhaPppModel.FolhaPppExameMedicoModelList do 
	begin 
	  FolhaPppExameMedicoModel.IdFolhaPpp := AFolhaPppModel.Id;
	  InsertBase(FolhaPppExameMedicoModel, 'folha_ppp_exame_medico'); 
	end; 

end;

class procedure TFolhaPppService.DeleteChildren(AFolhaPppModel: TFolhaPppModel);
begin
  DeleteChild(AFolhaPppModel.Id, 'folha_ppp_cat', 'id_folha_ppp');
  DeleteChild(AFolhaPppModel.Id, 'folha_ppp_atividade', 'id_folha_ppp');
  DeleteChild(AFolhaPppModel.Id, 'folha_ppp_fator_risco', 'id_folha_ppp');
  DeleteChild(AFolhaPppModel.Id, 'folha_ppp_exame_medico', 'id_folha_ppp');
end;

end.
