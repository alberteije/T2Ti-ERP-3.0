unit UWebModule;

interface

uses System.SysUtils, System.Classes, Web.HTTPApp,
  UAuthCriteria,
  mvcframework, MVCFramework.JWT;

type
  TFWebModule = class(TWebModule)
    procedure WebModuleCreate(Sender: TObject);
  private
    FEngine: TMVCEngine;
  public
    { Public declarations }
  end;

var
  WebModuleClass: TComponentClass = TFWebModule;

implementation

{ %CLASSGROUP 'Vcl.Controls.TControl' }

uses
  // MVC classes
  MVCFramework.Commons,
  MVCFramework.Middleware.JWT,
  MVCFramework.Middleware.Compression,

  // modules
	EmpresaTransporteItinerarioController,
	EmpresaTransporteController,
	FolhaLancamentoCabecalhoController,
	FolhaInssController,
	FolhaPppController,
	IrrfController,
	InssController,
	OperadoraPlanoSaudeController,
	FolhaLancamentoComissaoController,
	FolhaParametroController,
	GuiasAcumuladasController,
	FolhaFechamentoController,
	FeriasPeriodoAquisitivoController,
	FolhaTipoAfastamentoController,
	FolhaAfastamentoController,
	FolhaPlanoSaudeController,
	FolhaEventoController,
	FolhaRescisaoController,
	FolhaFeriasColetivasController,
	FolhaValeTransporteController,
	FolhaInssServicoController,
	FolhaHistoricoSalarialController,
	FeriadosController,
	ViewControleAcessoController,
	ViewPessoaUsuarioController,
	ViewPessoaColaboradorController,
	CboController,
	CodigoGpsController,
	FpasController,
	SalarioMinimoController,
	SefipCodigoMovimentacaoController,
	SefipCategoriaTrabalhoController,
	SefipCodigoRecolhimentoController,
	
  MVCFramework.Middleware.CORS;

{$R *.dfm}

procedure TFWebModule.WebModuleCreate(Sender: TObject);
var
  lClaimsSetup: TJWTClaimsSetup;
begin
  // Token - JWT
  lClaimsSetup := procedure(const JWT: TJWT)
    begin
      JWT.Claims.Issuer := 'Delphi MVC Framework JWT Middleware Sample';
      JWT.Claims.ExpirationTime := Now + 1000;
      JWT.Claims.NotBefore := Now; // valid since now
      JWT.Claims.IssuedAt := Now;
      JWT.CustomClaims['folha'] := 'folha';
    end;

  FEngine := TMVCEngine.Create(self);

  FEngine.AddMiddleware(TMVCJWTAuthenticationMiddleware.Create(
    TAuthCriteria.Create,
    lClaimsSetup,
    '#Your--32--character--key--here#',
    '/login'
    ));

  // modules
	FEngine.AddController(TEmpresaTransporteItinerarioController);
	FEngine.AddController(TEmpresaTransporteController);
	FEngine.AddController(TFolhaLancamentoCabecalhoController);
	FEngine.AddController(TFolhaInssController);
	FEngine.AddController(TFolhaPppController);
	FEngine.AddController(TIrrfController);
	FEngine.AddController(TInssController);
	FEngine.AddController(TOperadoraPlanoSaudeController);
	FEngine.AddController(TFolhaLancamentoComissaoController);
	FEngine.AddController(TFolhaParametroController);
	FEngine.AddController(TGuiasAcumuladasController);
	FEngine.AddController(TFolhaFechamentoController);
	FEngine.AddController(TFeriasPeriodoAquisitivoController);
	FEngine.AddController(TFolhaTipoAfastamentoController);
	FEngine.AddController(TFolhaAfastamentoController);
	FEngine.AddController(TFolhaPlanoSaudeController);
	FEngine.AddController(TFolhaEventoController);
	FEngine.AddController(TFolhaRescisaoController);
	FEngine.AddController(TFolhaFeriasColetivasController);
	FEngine.AddController(TFolhaValeTransporteController);
	FEngine.AddController(TFolhaInssServicoController);
	FEngine.AddController(TFolhaHistoricoSalarialController);
	FEngine.AddController(TFeriadosController);
	FEngine.AddController(TViewControleAcessoController);
	FEngine.AddController(TViewPessoaUsuarioController);
	FEngine.AddController(TViewPessoaColaboradorController);
	FEngine.AddController(TCboController);
	FEngine.AddController(TCodigoGpsController);
	FEngine.AddController(TFpasController);
	FEngine.AddController(TSalarioMinimoController);
	FEngine.AddController(TSefipCodigoMovimentacaoController);
	FEngine.AddController(TSefipCategoriaTrabalhoController);
	FEngine.AddController(TSefipCodigoRecolhimentoController);
end;

end.
