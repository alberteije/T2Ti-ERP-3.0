unit FolhaRescisaoModel;

interface

uses
  Generics.Collections, System.SysUtils,
	ViewPessoaColaboradorModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaRescisaoModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FDataDemissao: TDateTime;
    FDataPagamento: TDateTime;
    FMotivo: string;
    FMotivoEsocial: string;
    FDataAvisoPrevio: TDateTime;
    FDiasAvisoPrevio: Integer;
    FComprovouNovoEmprego: string;
    FDispensouEmpregado: string;
    FPensaoAlimenticia: Extended;
    FPensaoAlimenticiaFgts: Extended;
    FFgtsValorRescisao: Extended;
    FFgtsSaldoBanco: Extended;
    FFgtsComplementoSaldo: Extended;
    FFgtsCodigoAfastamento: string;
    FFgtsCodigoSaque: string;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('data_demissao')] 
		[MVCNameAsAttribute('dataDemissao')] 
		property DataDemissao: TDateTime read FDataDemissao write FDataDemissao; 

    [MVCColumnAttribute('data_pagamento')] 
		[MVCNameAsAttribute('dataPagamento')] 
		property DataPagamento: TDateTime read FDataPagamento write FDataPagamento; 

    [MVCColumnAttribute('motivo')] 
		[MVCNameAsAttribute('motivo')] 
		property Motivo: string read FMotivo write FMotivo; 

    [MVCColumnAttribute('motivo_esocial')] 
		[MVCNameAsAttribute('motivoEsocial')] 
		property MotivoEsocial: string read FMotivoEsocial write FMotivoEsocial; 

    [MVCColumnAttribute('data_aviso_previo')] 
		[MVCNameAsAttribute('dataAvisoPrevio')] 
		property DataAvisoPrevio: TDateTime read FDataAvisoPrevio write FDataAvisoPrevio; 

    [MVCColumnAttribute('dias_aviso_previo')] 
		[MVCNameAsAttribute('diasAvisoPrevio')] 
		property DiasAvisoPrevio: Integer read FDiasAvisoPrevio write FDiasAvisoPrevio; 

    [MVCColumnAttribute('comprovou_novo_emprego')] 
		[MVCNameAsAttribute('comprovouNovoEmprego')] 
		property ComprovouNovoEmprego: string read FComprovouNovoEmprego write FComprovouNovoEmprego; 

    [MVCColumnAttribute('dispensou_empregado')] 
		[MVCNameAsAttribute('dispensouEmpregado')] 
		property DispensouEmpregado: string read FDispensouEmpregado write FDispensouEmpregado; 

    [MVCColumnAttribute('pensao_alimenticia')] 
		[MVCNameAsAttribute('pensaoAlimenticia')] 
		property PensaoAlimenticia: Extended read FPensaoAlimenticia write FPensaoAlimenticia; 

    [MVCColumnAttribute('pensao_alimenticia_fgts')] 
		[MVCNameAsAttribute('pensaoAlimenticiaFgts')] 
		property PensaoAlimenticiaFgts: Extended read FPensaoAlimenticiaFgts write FPensaoAlimenticiaFgts; 

    [MVCColumnAttribute('fgts_valor_rescisao')] 
		[MVCNameAsAttribute('fgtsValorRescisao')] 
		property FgtsValorRescisao: Extended read FFgtsValorRescisao write FFgtsValorRescisao; 

    [MVCColumnAttribute('fgts_saldo_banco')] 
		[MVCNameAsAttribute('fgtsSaldoBanco')] 
		property FgtsSaldoBanco: Extended read FFgtsSaldoBanco write FFgtsSaldoBanco; 

    [MVCColumnAttribute('fgts_complemento_saldo')] 
		[MVCNameAsAttribute('fgtsComplementoSaldo')] 
		property FgtsComplementoSaldo: Extended read FFgtsComplementoSaldo write FFgtsComplementoSaldo; 

    [MVCColumnAttribute('fgts_codigo_afastamento')] 
		[MVCNameAsAttribute('fgtsCodigoAfastamento')] 
		property FgtsCodigoAfastamento: string read FFgtsCodigoAfastamento write FFgtsCodigoAfastamento; 

    [MVCColumnAttribute('fgts_codigo_saque')] 
		[MVCNameAsAttribute('fgtsCodigoSaque')] 
		property FgtsCodigoSaque: string read FFgtsCodigoSaque write FFgtsCodigoSaque; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

  end;

implementation

{ TFolhaRescisaoModel }

constructor TFolhaRescisaoModel.Create;
begin
  inherited;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
end;

destructor TFolhaRescisaoModel.Destroy;
begin
	FreeAndNil(FViewPessoaColaboradorModel);
  inherited;
end;


end.