unit FolhaInssServicoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaInssServicoModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: string;
    FNome: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: string read FCodigo write FCodigo; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

      
  end;

implementation

{ TFolhaInssServicoModel }

constructor TFolhaInssServicoModel.Create;
begin
  inherited;
end;

destructor TFolhaInssServicoModel.Destroy;
begin
  inherited;
end;


end.