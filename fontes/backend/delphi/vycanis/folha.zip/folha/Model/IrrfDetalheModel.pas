unit IrrfDetalheModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TIrrfDetalheModel = class(TModelBase)
  private
    FId: Integer;
    FIdIrrf: Integer;
    FFaixa: Integer;
    FDe: Extended;
    FAte: Extended;
    FTaxa: Extended;
    FDesconto: Extended;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_irrf')] 
		[MVCNameAsAttribute('idIrrf')] 
		property IdIrrf: Integer read FIdIrrf write FIdIrrf; 

    [MVCColumnAttribute('faixa')] 
		[MVCNameAsAttribute('faixa')] 
		property Faixa: Integer read FFaixa write FFaixa; 

    [MVCColumnAttribute('de')] 
		[MVCNameAsAttribute('de')] 
		property De: Extended read FDe write FDe; 

    [MVCColumnAttribute('ate')] 
		[MVCNameAsAttribute('ate')] 
		property Ate: Extended read FAte write FAte; 

    [MVCColumnAttribute('taxa')] 
		[MVCNameAsAttribute('taxa')] 
		property Taxa: Extended read FTaxa write FTaxa; 

    [MVCColumnAttribute('desconto')] 
		[MVCNameAsAttribute('desconto')] 
		property Desconto: Extended read FDesconto write FDesconto; 

      
  end;

implementation

{ TIrrfDetalheModel }

constructor TIrrfDetalheModel.Create;
begin
  inherited;
end;

destructor TIrrfDetalheModel.Destroy;
begin
  inherited;
end;


end.