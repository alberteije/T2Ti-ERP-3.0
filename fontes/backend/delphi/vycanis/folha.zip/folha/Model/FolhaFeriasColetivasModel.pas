unit FolhaFeriasColetivasModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaFeriasColetivasModel = class(TModelBase)
  private
    FId: Integer;
    FDataInicio: TDateTime;
    FDataFim: TDateTime;
    FDiasGozo: Integer;
    FAbonoPecuniarioInicio: TDateTime;
    FAbonoPecuniarioFim: TDateTime;
    FDiasAbono: Integer;
    FDataPagamento: TDateTime;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('data_inicio')] 
		[MVCNameAsAttribute('dataInicio')] 
		property DataInicio: TDateTime read FDataInicio write FDataInicio; 

    [MVCColumnAttribute('data_fim')] 
		[MVCNameAsAttribute('dataFim')] 
		property DataFim: TDateTime read FDataFim write FDataFim; 

    [MVCColumnAttribute('dias_gozo')] 
		[MVCNameAsAttribute('diasGozo')] 
		property DiasGozo: Integer read FDiasGozo write FDiasGozo; 

    [MVCColumnAttribute('abono_pecuniario_inicio')] 
		[MVCNameAsAttribute('abonoPecuniarioInicio')] 
		property AbonoPecuniarioInicio: TDateTime read FAbonoPecuniarioInicio write FAbonoPecuniarioInicio; 

    [MVCColumnAttribute('abono_pecuniario_fim')] 
		[MVCNameAsAttribute('abonoPecuniarioFim')] 
		property AbonoPecuniarioFim: TDateTime read FAbonoPecuniarioFim write FAbonoPecuniarioFim; 

    [MVCColumnAttribute('dias_abono')] 
		[MVCNameAsAttribute('diasAbono')] 
		property DiasAbono: Integer read FDiasAbono write FDiasAbono; 

    [MVCColumnAttribute('data_pagamento')] 
		[MVCNameAsAttribute('dataPagamento')] 
		property DataPagamento: TDateTime read FDataPagamento write FDataPagamento; 

      
  end;

implementation

{ TFolhaFeriasColetivasModel }

constructor TFolhaFeriasColetivasModel.Create;
begin
  inherited;
end;

destructor TFolhaFeriasColetivasModel.Destroy;
begin
  inherited;
end;


end.