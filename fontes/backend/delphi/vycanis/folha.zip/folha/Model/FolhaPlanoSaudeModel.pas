unit FolhaPlanoSaudeModel;

interface

uses
  Generics.Collections, System.SysUtils,
	ViewPessoaColaboradorModel, 
	OperadoraPlanoSaudeModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaPlanoSaudeModel = class(TModelBase)
  private
    FId: Integer;
    FIdOperadoraPlanoSaude: Integer;
    FIdColaborador: Integer;
    FDataInicio: TDateTime;
    FBeneficiario: string;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
    FOperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_operadora_plano_saude')] 
		[MVCNameAsAttribute('idOperadoraPlanoSaude')] 
		property IdOperadoraPlanoSaude: Integer read FIdOperadoraPlanoSaude write FIdOperadoraPlanoSaude; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('data_inicio')] 
		[MVCNameAsAttribute('dataInicio')] 
		property DataInicio: TDateTime read FDataInicio write FDataInicio; 

    [MVCColumnAttribute('beneficiario')] 
		[MVCNameAsAttribute('beneficiario')] 
		property Beneficiario: string read FBeneficiario write FBeneficiario; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

    		[MVCNameAsAttribute('operadoraPlanoSaudeModel')] 
		property OperadoraPlanoSaudeModel: TOperadoraPlanoSaudeModel read FOperadoraPlanoSaudeModel write FOperadoraPlanoSaudeModel; 

  end;

implementation

{ TFolhaPlanoSaudeModel }

constructor TFolhaPlanoSaudeModel.Create;
begin
  inherited;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
	FOperadoraPlanoSaudeModel := TOperadoraPlanoSaudeModel.Create;
end;

destructor TFolhaPlanoSaudeModel.Destroy;
begin
	FreeAndNil(FViewPessoaColaboradorModel);
	FreeAndNil(FOperadoraPlanoSaudeModel);
  inherited;
end;


end.