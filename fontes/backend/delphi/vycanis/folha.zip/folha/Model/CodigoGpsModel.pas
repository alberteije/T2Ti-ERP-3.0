unit CodigoGpsModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TCodigoGpsModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: Integer;
    FDescricao: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: Integer read FCodigo write FCodigo; 

    [MVCColumnAttribute('descricao')] 
		[MVCNameAsAttribute('descricao')] 
		property Descricao: string read FDescricao write FDescricao; 

      
  end;

implementation

{ TCodigoGpsModel }

constructor TCodigoGpsModel.Create;
begin
  inherited;
end;

destructor TCodigoGpsModel.Destroy;
begin
  inherited;
end;


end.