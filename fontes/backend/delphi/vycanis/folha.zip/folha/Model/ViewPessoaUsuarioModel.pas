unit ViewPessoaUsuarioModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TViewPessoaUsuarioModel = class(TModelBase)
  private
    FId: Integer;
    FIdPessoa: Integer;
    FPessoaNome: string;
    FTipo: string;
    FEmail: string;
    FIdColaborador: Integer;
    FIdUsuario: Integer;
    FLogin: string;
    FSenha: string;
    FDataCadastro: TDateTime;
    FAdministrador: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_pessoa')] 
		[MVCNameAsAttribute('idPessoa')] 
		property IdPessoa: Integer read FIdPessoa write FIdPessoa; 

    [MVCColumnAttribute('pessoa_nome')] 
		[MVCNameAsAttribute('pessoaNome')] 
		property PessoaNome: string read FPessoaNome write FPessoaNome; 

    [MVCColumnAttribute('tipo')] 
		[MVCNameAsAttribute('tipo')] 
		property Tipo: string read FTipo write FTipo; 

    [MVCColumnAttribute('email')] 
		[MVCNameAsAttribute('email')] 
		property Email: string read FEmail write FEmail; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('id_usuario')] 
		[MVCNameAsAttribute('idUsuario')] 
		property IdUsuario: Integer read FIdUsuario write FIdUsuario; 

    [MVCColumnAttribute('login')] 
		[MVCNameAsAttribute('login')] 
		property Login: string read FLogin write FLogin; 

    [MVCColumnAttribute('senha')] 
		[MVCNameAsAttribute('senha')] 
		property Senha: string read FSenha write FSenha; 

    [MVCColumnAttribute('data_cadastro')] 
		[MVCNameAsAttribute('dataCadastro')] 
		property DataCadastro: TDateTime read FDataCadastro write FDataCadastro; 

    [MVCColumnAttribute('administrador')] 
		[MVCNameAsAttribute('administrador')] 
		property Administrador: string read FAdministrador write FAdministrador; 

      
  end;

implementation

{ TViewPessoaUsuarioModel }

constructor TViewPessoaUsuarioModel.Create;
begin
  inherited;
end;

destructor TViewPessoaUsuarioModel.Destroy;
begin
  inherited;
end;


end.