unit FolhaPppModel;

interface

uses
  Generics.Collections, System.SysUtils,
	FolhaPppCatModel, 
	FolhaPppAtividadeModel, 
	FolhaPppFatorRiscoModel, 
	FolhaPppExameMedicoModel, 
	ViewPessoaColaboradorModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaPppModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FObservacao: string;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
    FFolhaPppCatModelList: TObjectList<TFolhaPppCatModel>;
    FFolhaPppAtividadeModelList: TObjectList<TFolhaPppAtividadeModel>;
    FFolhaPppFatorRiscoModelList: TObjectList<TFolhaPppFatorRiscoModel>;
    FFolhaPppExameMedicoModelList: TObjectList<TFolhaPppExameMedicoModel>;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('observacao')] 
		[MVCNameAsAttribute('observacao')] 
		property Observacao: string read FObservacao write FObservacao; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

    [MapperListOf(TFolhaPppCatModel)] 
		[MVCNameAsAttribute('folhaPppCatModelList')] 
		property FolhaPppCatModelList: TObjectList<TFolhaPppCatModel> read FFolhaPppCatModelList write FFolhaPppCatModelList; 

    [MapperListOf(TFolhaPppAtividadeModel)] 
		[MVCNameAsAttribute('folhaPppAtividadeModelList')] 
		property FolhaPppAtividadeModelList: TObjectList<TFolhaPppAtividadeModel> read FFolhaPppAtividadeModelList write FFolhaPppAtividadeModelList; 

    [MapperListOf(TFolhaPppFatorRiscoModel)] 
		[MVCNameAsAttribute('folhaPppFatorRiscoModelList')] 
		property FolhaPppFatorRiscoModelList: TObjectList<TFolhaPppFatorRiscoModel> read FFolhaPppFatorRiscoModelList write FFolhaPppFatorRiscoModelList; 

    [MapperListOf(TFolhaPppExameMedicoModel)] 
		[MVCNameAsAttribute('folhaPppExameMedicoModelList')] 
		property FolhaPppExameMedicoModelList: TObjectList<TFolhaPppExameMedicoModel> read FFolhaPppExameMedicoModelList write FFolhaPppExameMedicoModelList; 

  end;

implementation

{ TFolhaPppModel }

constructor TFolhaPppModel.Create;
begin
  inherited;
	FFolhaPppCatModelList := TObjectList<TFolhaPppCatModel>.Create;
	FFolhaPppAtividadeModelList := TObjectList<TFolhaPppAtividadeModel>.Create;
	FFolhaPppFatorRiscoModelList := TObjectList<TFolhaPppFatorRiscoModel>.Create;
	FFolhaPppExameMedicoModelList := TObjectList<TFolhaPppExameMedicoModel>.Create;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
end;

destructor TFolhaPppModel.Destroy;
begin
	FreeAndNil(FFolhaPppCatModelList);
	FreeAndNil(FFolhaPppAtividadeModelList);
	FreeAndNil(FFolhaPppFatorRiscoModelList);
	FreeAndNil(FFolhaPppExameMedicoModelList);
	FreeAndNil(FViewPessoaColaboradorModel);
  inherited;
end;


end.