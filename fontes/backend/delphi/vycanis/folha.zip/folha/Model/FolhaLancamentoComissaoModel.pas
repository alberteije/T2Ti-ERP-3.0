unit FolhaLancamentoComissaoModel;

interface

uses
  Generics.Collections, System.SysUtils,
	ViewPessoaColaboradorModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaLancamentoComissaoModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FCompetencia: string;
    FVencimento: TDateTime;
    FBaseCalculo: Extended;
    FValorComissao: Extended;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('competencia')] 
		[MVCNameAsAttribute('competencia')] 
		property Competencia: string read FCompetencia write FCompetencia; 

    [MVCColumnAttribute('vencimento')] 
		[MVCNameAsAttribute('vencimento')] 
		property Vencimento: TDateTime read FVencimento write FVencimento; 

    [MVCColumnAttribute('base_calculo')] 
		[MVCNameAsAttribute('baseCalculo')] 
		property BaseCalculo: Extended read FBaseCalculo write FBaseCalculo; 

    [MVCColumnAttribute('valor_comissao')] 
		[MVCNameAsAttribute('valorComissao')] 
		property ValorComissao: Extended read FValorComissao write FValorComissao; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

  end;

implementation

{ TFolhaLancamentoComissaoModel }

constructor TFolhaLancamentoComissaoModel.Create;
begin
  inherited;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
end;

destructor TFolhaLancamentoComissaoModel.Destroy;
begin
	FreeAndNil(FViewPessoaColaboradorModel);
  inherited;
end;


end.