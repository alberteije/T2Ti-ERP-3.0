unit InssDetalheModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TInssDetalheModel = class(TModelBase)
  private
    FId: Integer;
    FIdInss: Integer;
    FFaixa: Integer;
    FDe: Extended;
    FAte: Extended;
    FTaxa: Extended;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_inss')] 
		[MVCNameAsAttribute('idInss')] 
		property IdInss: Integer read FIdInss write FIdInss; 

    [MVCColumnAttribute('faixa')] 
		[MVCNameAsAttribute('faixa')] 
		property Faixa: Integer read FFaixa write FFaixa; 

    [MVCColumnAttribute('de')] 
		[MVCNameAsAttribute('de')] 
		property De: Extended read FDe write FDe; 

    [MVCColumnAttribute('ate')] 
		[MVCNameAsAttribute('ate')] 
		property Ate: Extended read FAte write FAte; 

    [MVCColumnAttribute('taxa')] 
		[MVCNameAsAttribute('taxa')] 
		property Taxa: Extended read FTaxa write FTaxa; 

      
  end;

implementation

{ TInssDetalheModel }

constructor TInssDetalheModel.Create;
begin
  inherited;
end;

destructor TInssDetalheModel.Destroy;
begin
  inherited;
end;


end.