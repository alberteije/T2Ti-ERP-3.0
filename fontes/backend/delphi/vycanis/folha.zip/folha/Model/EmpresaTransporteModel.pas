unit EmpresaTransporteModel;

interface

uses
  Generics.Collections, System.SysUtils,
	EmpresaTransporteItinerarioModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TEmpresaTransporteModel = class(TModelBase)
  private
    FId: Integer;
    FNome: string;
    FUf: string;
    FClassificacaoContabilConta: string;
      
    FEmpresaTransporteItinerarioModelList: TObjectList<TEmpresaTransporteItinerarioModel>;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('uf')] 
		[MVCNameAsAttribute('uf')] 
		property Uf: string read FUf write FUf; 

    [MVCColumnAttribute('classificacao_contabil_conta')] 
		[MVCNameAsAttribute('classificacaoContabilConta')] 
		property ClassificacaoContabilConta: string read FClassificacaoContabilConta write FClassificacaoContabilConta; 

      
    [MapperListOf(TEmpresaTransporteItinerarioModel)] 
		[MVCNameAsAttribute('empresaTransporteItinerarioModelList')] 
		property EmpresaTransporteItinerarioModelList: TObjectList<TEmpresaTransporteItinerarioModel> read FEmpresaTransporteItinerarioModelList write FEmpresaTransporteItinerarioModelList; 

  end;

implementation

{ TEmpresaTransporteModel }

constructor TEmpresaTransporteModel.Create;
begin
  inherited;
	FEmpresaTransporteItinerarioModelList := TObjectList<TEmpresaTransporteItinerarioModel>.Create;
end;

destructor TEmpresaTransporteModel.Destroy;
begin
	FreeAndNil(FEmpresaTransporteItinerarioModelList);
  inherited;
end;


end.