unit CboModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TCboModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: string;
    FCodigo1994: string;
    FNome: string;
    FObservacao: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: string read FCodigo write FCodigo; 

    [MVCColumnAttribute('codigo_1994')] 
		[MVCNameAsAttribute('codigo1994')] 
		property Codigo1994: string read FCodigo1994 write FCodigo1994; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('observacao')] 
		[MVCNameAsAttribute('observacao')] 
		property Observacao: string read FObservacao write FObservacao; 

      
  end;

implementation

{ TCboModel }

constructor TCboModel.Create;
begin
  inherited;
end;

destructor TCboModel.Destroy;
begin
  inherited;
end;


end.