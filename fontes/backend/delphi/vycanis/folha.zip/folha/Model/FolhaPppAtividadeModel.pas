unit FolhaPppAtividadeModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaPppAtividadeModel = class(TModelBase)
  private
    FId: Integer;
    FIdFolhaPpp: Integer;
    FDataInicio: TDateTime;
    FDataFim: TDateTime;
    FDescricao: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_folha_ppp')] 
		[MVCNameAsAttribute('idFolhaPpp')] 
		property IdFolhaPpp: Integer read FIdFolhaPpp write FIdFolhaPpp; 

    [MVCColumnAttribute('data_inicio')] 
		[MVCNameAsAttribute('dataInicio')] 
		property DataInicio: TDateTime read FDataInicio write FDataInicio; 

    [MVCColumnAttribute('data_fim')] 
		[MVCNameAsAttribute('dataFim')] 
		property DataFim: TDateTime read FDataFim write FDataFim; 

    [MVCColumnAttribute('descricao')] 
		[MVCNameAsAttribute('descricao')] 
		property Descricao: string read FDescricao write FDescricao; 

      
  end;

implementation

{ TFolhaPppAtividadeModel }

constructor TFolhaPppAtividadeModel.Create;
begin
  inherited;
end;

destructor TFolhaPppAtividadeModel.Destroy;
begin
  inherited;
end;


end.