unit SalarioMinimoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TSalarioMinimoModel = class(TModelBase)
  private
    FId: Integer;
    FVigencia: TDateTime;
    FValorMensal: Extended;
    FValorDiario: Extended;
    FValorHora: Extended;
    FNormaLegal: string;
    FDou: TDateTime;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('vigencia')] 
		[MVCNameAsAttribute('vigencia')] 
		property Vigencia: TDateTime read FVigencia write FVigencia; 

    [MVCColumnAttribute('valor_mensal')] 
		[MVCNameAsAttribute('valorMensal')] 
		property ValorMensal: Extended read FValorMensal write FValorMensal; 

    [MVCColumnAttribute('valor_diario')] 
		[MVCNameAsAttribute('valorDiario')] 
		property ValorDiario: Extended read FValorDiario write FValorDiario; 

    [MVCColumnAttribute('valor_hora')] 
		[MVCNameAsAttribute('valorHora')] 
		property ValorHora: Extended read FValorHora write FValorHora; 

    [MVCColumnAttribute('norma_legal')] 
		[MVCNameAsAttribute('normaLegal')] 
		property NormaLegal: string read FNormaLegal write FNormaLegal; 

    [MVCColumnAttribute('dou')] 
		[MVCNameAsAttribute('dou')] 
		property Dou: TDateTime read FDou write FDou; 

      
  end;

implementation

{ TSalarioMinimoModel }

constructor TSalarioMinimoModel.Create;
begin
  inherited;
end;

destructor TSalarioMinimoModel.Destroy;
begin
  inherited;
end;


end.