unit FolhaInssModel;

interface

uses
  Generics.Collections, System.SysUtils,
	FolhaInssRetencaoModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaInssModel = class(TModelBase)
  private
    FId: Integer;
    FCompetencia: string;
      
    FFolhaInssRetencaoModelList: TObjectList<TFolhaInssRetencaoModel>;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('competencia')] 
		[MVCNameAsAttribute('competencia')] 
		property Competencia: string read FCompetencia write FCompetencia; 

      
    [MapperListOf(TFolhaInssRetencaoModel)] 
		[MVCNameAsAttribute('folhaInssRetencaoModelList')] 
		property FolhaInssRetencaoModelList: TObjectList<TFolhaInssRetencaoModel> read FFolhaInssRetencaoModelList write FFolhaInssRetencaoModelList; 

  end;

implementation

{ TFolhaInssModel }

constructor TFolhaInssModel.Create;
begin
  inherited;
	FFolhaInssRetencaoModelList := TObjectList<TFolhaInssRetencaoModel>.Create;
end;

destructor TFolhaInssModel.Destroy;
begin
	FreeAndNil(FFolhaInssRetencaoModelList);
  inherited;
end;


end.