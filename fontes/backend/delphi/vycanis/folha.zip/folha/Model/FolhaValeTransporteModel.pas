unit FolhaValeTransporteModel;

interface

uses
  Generics.Collections, System.SysUtils,
	ViewPessoaColaboradorModel, 
	EmpresaTransporteItinerarioModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaValeTransporteModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FIdEmpresaTranspItin: Integer;
    FQuantidade: Integer;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
    FEmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('id_empresa_transp_itin')] 
		[MVCNameAsAttribute('idEmpresaTranspItin')] 
		property IdEmpresaTranspItin: Integer read FIdEmpresaTranspItin write FIdEmpresaTranspItin; 

    [MVCColumnAttribute('quantidade')] 
		[MVCNameAsAttribute('quantidade')] 
		property Quantidade: Integer read FQuantidade write FQuantidade; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

    		[MVCNameAsAttribute('empresaTransporteItinerarioModel')] 
		property EmpresaTransporteItinerarioModel: TEmpresaTransporteItinerarioModel read FEmpresaTransporteItinerarioModel write FEmpresaTransporteItinerarioModel; 

  end;

implementation

{ TFolhaValeTransporteModel }

constructor TFolhaValeTransporteModel.Create;
begin
  inherited;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
	FEmpresaTransporteItinerarioModel := TEmpresaTransporteItinerarioModel.Create;
end;

destructor TFolhaValeTransporteModel.Destroy;
begin
	FreeAndNil(FViewPessoaColaboradorModel);
	FreeAndNil(FEmpresaTransporteItinerarioModel);
  inherited;
end;


end.