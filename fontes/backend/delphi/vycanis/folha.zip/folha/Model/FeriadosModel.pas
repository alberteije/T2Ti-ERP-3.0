unit FeriadosModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFeriadosModel = class(TModelBase)
  private
    FId: Integer;
    FAno: string;
    FNome: string;
    FAbrangencia: string;
    FUf: string;
    FMunicipioIbge: Integer;
    FTipo: string;
    FDataFeriado: TDateTime;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('ano')] 
		[MVCNameAsAttribute('ano')] 
		property Ano: string read FAno write FAno; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('abrangencia')] 
		[MVCNameAsAttribute('abrangencia')] 
		property Abrangencia: string read FAbrangencia write FAbrangencia; 

    [MVCColumnAttribute('uf')] 
		[MVCNameAsAttribute('uf')] 
		property Uf: string read FUf write FUf; 

    [MVCColumnAttribute('municipio_ibge')] 
		[MVCNameAsAttribute('municipioIbge')] 
		property MunicipioIbge: Integer read FMunicipioIbge write FMunicipioIbge; 

    [MVCColumnAttribute('tipo')] 
		[MVCNameAsAttribute('tipo')] 
		property Tipo: string read FTipo write FTipo; 

    [MVCColumnAttribute('data_feriado')] 
		[MVCNameAsAttribute('dataFeriado')] 
		property DataFeriado: TDateTime read FDataFeriado write FDataFeriado; 

      
  end;

implementation

{ TFeriadosModel }

constructor TFeriadosModel.Create;
begin
  inherited;
end;

destructor TFeriadosModel.Destroy;
begin
  inherited;
end;


end.