unit ViewControleAcessoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TViewControleAcessoModel = class(TModelBase)
  private
    FId: Integer;
    FIdPessoa: Integer;
    FPessoaNome: string;
    FIdColaborador: Integer;
    FIdUsuario: Integer;
    FAdministrador: string;
    FIdPapel: Integer;
    FPapelNome: string;
    FPapelDescricao: string;
    FIdFuncao: Integer;
    FFuncaoNome: string;
    FFuncaoDescricao: string;
    FIdPapelFuncao: Integer;
    FHabilitado: string;
    FPodeInserir: string;
    FPodeAlterar: string;
    FPodeExcluir: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_pessoa')] 
		[MVCNameAsAttribute('idPessoa')] 
		property IdPessoa: Integer read FIdPessoa write FIdPessoa; 

    [MVCColumnAttribute('pessoa_nome')] 
		[MVCNameAsAttribute('pessoaNome')] 
		property PessoaNome: string read FPessoaNome write FPessoaNome; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('id_usuario')] 
		[MVCNameAsAttribute('idUsuario')] 
		property IdUsuario: Integer read FIdUsuario write FIdUsuario; 

    [MVCColumnAttribute('administrador')] 
		[MVCNameAsAttribute('administrador')] 
		property Administrador: string read FAdministrador write FAdministrador; 

    [MVCColumnAttribute('id_papel')] 
		[MVCNameAsAttribute('idPapel')] 
		property IdPapel: Integer read FIdPapel write FIdPapel; 

    [MVCColumnAttribute('papel_nome')] 
		[MVCNameAsAttribute('papelNome')] 
		property PapelNome: string read FPapelNome write FPapelNome; 

    [MVCColumnAttribute('papel_descricao')] 
		[MVCNameAsAttribute('papelDescricao')] 
		property PapelDescricao: string read FPapelDescricao write FPapelDescricao; 

    [MVCColumnAttribute('id_funcao')] 
		[MVCNameAsAttribute('idFuncao')] 
		property IdFuncao: Integer read FIdFuncao write FIdFuncao; 

    [MVCColumnAttribute('funcao_nome')] 
		[MVCNameAsAttribute('funcaoNome')] 
		property FuncaoNome: string read FFuncaoNome write FFuncaoNome; 

    [MVCColumnAttribute('funcao_descricao')] 
		[MVCNameAsAttribute('funcaoDescricao')] 
		property FuncaoDescricao: string read FFuncaoDescricao write FFuncaoDescricao; 

    [MVCColumnAttribute('id_papel_funcao')] 
		[MVCNameAsAttribute('idPapelFuncao')] 
		property IdPapelFuncao: Integer read FIdPapelFuncao write FIdPapelFuncao; 

    [MVCColumnAttribute('habilitado')] 
		[MVCNameAsAttribute('habilitado')] 
		property Habilitado: string read FHabilitado write FHabilitado; 

    [MVCColumnAttribute('pode_inserir')] 
		[MVCNameAsAttribute('podeInserir')] 
		property PodeInserir: string read FPodeInserir write FPodeInserir; 

    [MVCColumnAttribute('pode_alterar')] 
		[MVCNameAsAttribute('podeAlterar')] 
		property PodeAlterar: string read FPodeAlterar write FPodeAlterar; 

    [MVCColumnAttribute('pode_excluir')] 
		[MVCNameAsAttribute('podeExcluir')] 
		property PodeExcluir: string read FPodeExcluir write FPodeExcluir; 

      
  end;

implementation

{ TViewControleAcessoModel }

constructor TViewControleAcessoModel.Create;
begin
  inherited;
end;

destructor TViewControleAcessoModel.Destroy;
begin
  inherited;
end;


end.