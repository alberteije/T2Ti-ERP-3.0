unit FolhaInssRetencaoModel;

interface

uses
  Generics.Collections, System.SysUtils,
	FolhaInssServicoModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaInssRetencaoModel = class(TModelBase)
  private
    FId: Integer;
    FIdFolhaInss: Integer;
    FIdFolhaInssServico: Integer;
    FValorMensal: Extended;
    FValor13: Extended;
      
    FFolhaInssServicoModel: TFolhaInssServicoModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_folha_inss')] 
		[MVCNameAsAttribute('idFolhaInss')] 
		property IdFolhaInss: Integer read FIdFolhaInss write FIdFolhaInss; 

    [MVCColumnAttribute('id_folha_inss_servico')] 
		[MVCNameAsAttribute('idFolhaInssServico')] 
		property IdFolhaInssServico: Integer read FIdFolhaInssServico write FIdFolhaInssServico; 

    [MVCColumnAttribute('valor_mensal')] 
		[MVCNameAsAttribute('valorMensal')] 
		property ValorMensal: Extended read FValorMensal write FValorMensal; 

    [MVCColumnAttribute('valor_13')] 
		[MVCNameAsAttribute('valor13')] 
		property Valor13: Extended read FValor13 write FValor13; 

      
    		[MVCNameAsAttribute('folhaInssServicoModel')] 
		property FolhaInssServicoModel: TFolhaInssServicoModel read FFolhaInssServicoModel write FFolhaInssServicoModel; 

  end;

implementation

{ TFolhaInssRetencaoModel }

constructor TFolhaInssRetencaoModel.Create;
begin
  inherited;
	FFolhaInssServicoModel := TFolhaInssServicoModel.Create;
end;

destructor TFolhaInssRetencaoModel.Destroy;
begin
	FreeAndNil(FFolhaInssServicoModel);
  inherited;
end;


end.