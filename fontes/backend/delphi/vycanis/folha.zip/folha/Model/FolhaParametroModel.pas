unit FolhaParametroModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaParametroModel = class(TModelBase)
  private
    FId: Integer;
    FCompetencia: string;
    FContribuiPis: string;
    FAliquotaPis: Extended;
    FDiscriminarDsr: string;
    FDiaPagamento: string;
    FCalculoProporcionalidade: string;
    FDescontarFaltas13: string;
    FPagarAdicionais13: string;
    FPagarEstagiarios13: string;
    FMesAdiantamento13: string;
    FPercentualAdiantam13: Extended;
    FFeriasDescontarFaltas: string;
    FFeriasPagarAdicionais: string;
    FFeriasAdiantar13: string;
    FFeriasPagarEstagiarios: string;
    FFeriasCalcJustaCausa: string;
    FFeriasMovimentoMensal: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('competencia')] 
		[MVCNameAsAttribute('competencia')] 
		property Competencia: string read FCompetencia write FCompetencia; 

    [MVCColumnAttribute('contribui_pis')] 
		[MVCNameAsAttribute('contribuiPis')] 
		property ContribuiPis: string read FContribuiPis write FContribuiPis; 

    [MVCColumnAttribute('aliquota_pis')] 
		[MVCNameAsAttribute('aliquotaPis')] 
		property AliquotaPis: Extended read FAliquotaPis write FAliquotaPis; 

    [MVCColumnAttribute('discriminar_dsr')] 
		[MVCNameAsAttribute('discriminarDsr')] 
		property DiscriminarDsr: string read FDiscriminarDsr write FDiscriminarDsr; 

    [MVCColumnAttribute('dia_pagamento')] 
		[MVCNameAsAttribute('diaPagamento')] 
		property DiaPagamento: string read FDiaPagamento write FDiaPagamento; 

    [MVCColumnAttribute('calculo_proporcionalidade')] 
		[MVCNameAsAttribute('calculoProporcionalidade')] 
		property CalculoProporcionalidade: string read FCalculoProporcionalidade write FCalculoProporcionalidade; 

    [MVCColumnAttribute('descontar_faltas_13')] 
		[MVCNameAsAttribute('descontarFaltas13')] 
		property DescontarFaltas13: string read FDescontarFaltas13 write FDescontarFaltas13; 

    [MVCColumnAttribute('pagar_adicionais_13')] 
		[MVCNameAsAttribute('pagarAdicionais13')] 
		property PagarAdicionais13: string read FPagarAdicionais13 write FPagarAdicionais13; 

    [MVCColumnAttribute('pagar_estagiarios_13')] 
		[MVCNameAsAttribute('pagarEstagiarios13')] 
		property PagarEstagiarios13: string read FPagarEstagiarios13 write FPagarEstagiarios13; 

    [MVCColumnAttribute('mes_adiantamento_13')] 
		[MVCNameAsAttribute('mesAdiantamento13')] 
		property MesAdiantamento13: string read FMesAdiantamento13 write FMesAdiantamento13; 

    [MVCColumnAttribute('percentual_adiantam_13')] 
		[MVCNameAsAttribute('percentualAdiantam13')] 
		property PercentualAdiantam13: Extended read FPercentualAdiantam13 write FPercentualAdiantam13; 

    [MVCColumnAttribute('ferias_descontar_faltas')] 
		[MVCNameAsAttribute('feriasDescontarFaltas')] 
		property FeriasDescontarFaltas: string read FFeriasDescontarFaltas write FFeriasDescontarFaltas; 

    [MVCColumnAttribute('ferias_pagar_adicionais')] 
		[MVCNameAsAttribute('feriasPagarAdicionais')] 
		property FeriasPagarAdicionais: string read FFeriasPagarAdicionais write FFeriasPagarAdicionais; 

    [MVCColumnAttribute('ferias_adiantar_13')] 
		[MVCNameAsAttribute('feriasAdiantar13')] 
		property FeriasAdiantar13: string read FFeriasAdiantar13 write FFeriasAdiantar13; 

    [MVCColumnAttribute('ferias_pagar_estagiarios')] 
		[MVCNameAsAttribute('feriasPagarEstagiarios')] 
		property FeriasPagarEstagiarios: string read FFeriasPagarEstagiarios write FFeriasPagarEstagiarios; 

    [MVCColumnAttribute('ferias_calc_justa_causa')] 
		[MVCNameAsAttribute('feriasCalcJustaCausa')] 
		property FeriasCalcJustaCausa: string read FFeriasCalcJustaCausa write FFeriasCalcJustaCausa; 

    [MVCColumnAttribute('ferias_movimento_mensal')] 
		[MVCNameAsAttribute('feriasMovimentoMensal')] 
		property FeriasMovimentoMensal: string read FFeriasMovimentoMensal write FFeriasMovimentoMensal; 

      
  end;

implementation

{ TFolhaParametroModel }

constructor TFolhaParametroModel.Create;
begin
  inherited;
end;

destructor TFolhaParametroModel.Destroy;
begin
  inherited;
end;


end.