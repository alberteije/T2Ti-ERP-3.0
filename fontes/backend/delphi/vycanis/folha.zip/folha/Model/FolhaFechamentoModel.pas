unit FolhaFechamentoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaFechamentoModel = class(TModelBase)
  private
    FId: Integer;
    FFechamentoAtual: string;
    FProximoFechamento: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('fechamento_atual')] 
		[MVCNameAsAttribute('fechamentoAtual')] 
		property FechamentoAtual: string read FFechamentoAtual write FFechamentoAtual; 

    [MVCColumnAttribute('proximo_fechamento')] 
		[MVCNameAsAttribute('proximoFechamento')] 
		property ProximoFechamento: string read FProximoFechamento write FProximoFechamento; 

      
  end;

implementation

{ TFolhaFechamentoModel }

constructor TFolhaFechamentoModel.Create;
begin
  inherited;
end;

destructor TFolhaFechamentoModel.Destroy;
begin
  inherited;
end;


end.