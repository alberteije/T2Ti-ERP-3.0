unit SefipCategoriaTrabalhoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TSefipCategoriaTrabalhoModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: Integer;
    FNome: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: Integer read FCodigo write FCodigo; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

      
  end;

implementation

{ TSefipCategoriaTrabalhoModel }

constructor TSefipCategoriaTrabalhoModel.Create;
begin
  inherited;
end;

destructor TSefipCategoriaTrabalhoModel.Destroy;
begin
  inherited;
end;


end.