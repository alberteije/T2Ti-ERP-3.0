unit FolhaLancamentoDetalheModel;

interface

uses
  Generics.Collections, System.SysUtils,
	FolhaEventoModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaLancamentoDetalheModel = class(TModelBase)
  private
    FId: Integer;
    FIdFolhaLancamentoCabecalho: Integer;
    FIdFolhaEvento: Integer;
    FOrigem: Extended;
    FProvento: Extended;
    FDesconto: Extended;
      
    FFolhaEventoModel: TFolhaEventoModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_folha_lancamento_cabecalho')] 
		[MVCNameAsAttribute('idFolhaLancamentoCabecalho')] 
		property IdFolhaLancamentoCabecalho: Integer read FIdFolhaLancamentoCabecalho write FIdFolhaLancamentoCabecalho; 

    [MVCColumnAttribute('id_folha_evento')] 
		[MVCNameAsAttribute('idFolhaEvento')] 
		property IdFolhaEvento: Integer read FIdFolhaEvento write FIdFolhaEvento; 

    [MVCColumnAttribute('origem')] 
		[MVCNameAsAttribute('origem')] 
		property Origem: Extended read FOrigem write FOrigem; 

    [MVCColumnAttribute('provento')] 
		[MVCNameAsAttribute('provento')] 
		property Provento: Extended read FProvento write FProvento; 

    [MVCColumnAttribute('desconto')] 
		[MVCNameAsAttribute('desconto')] 
		property Desconto: Extended read FDesconto write FDesconto; 

      
    		[MVCNameAsAttribute('folhaEventoModel')] 
		property FolhaEventoModel: TFolhaEventoModel read FFolhaEventoModel write FFolhaEventoModel; 

  end;

implementation

{ TFolhaLancamentoDetalheModel }

constructor TFolhaLancamentoDetalheModel.Create;
begin
  inherited;
	FFolhaEventoModel := TFolhaEventoModel.Create;
end;

destructor TFolhaLancamentoDetalheModel.Destroy;
begin
	FreeAndNil(FFolhaEventoModel);
  inherited;
end;


end.