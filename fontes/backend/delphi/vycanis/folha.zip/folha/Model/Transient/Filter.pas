/// Transient class that controls the filter
/// Take as a basis the following scheme to create filter conditions
/// https://github.com/nestjsx/crud/wiki/Requests
/// Syntax:
///    ?filter=field||$condition||value

unit Filter;

interface

uses
  Classes, System.StrUtils, System.SysUtils;

type

  TFilter = class
  private
    FField: string;
    FValue: string;
    FStartDate: string;
    FEndDate: string;
    FCondition: string;
    FWhere: string;
  public
    constructor Create(Filter: string);

    property Field: string read FField write FField;
    property Value: string read FValue write FValue;
    property StartDate: string read FStartDate write FStartDate;
    property EndDate: string read FEndDate write FEndDate;
    property Condition: string read FCondition write FCondition;
    property Where: string read FWhere write FWhere;
  end;

implementation

{ TFilter }

constructor TFilter.Create(Filter: string);
var
  Conditions: TStrings;
  Dates: TStrings;
  FilterParts: TStrings;
  I: Integer;
begin
  FilterParts := TStringList.Create;
  Conditions := TStringList.Create;
  Dates := TStringList.Create;
  try
    Filter := StringReplace(Filter, '||', '*', [rfReplaceAll, rfIgnoreCase]);

    // Split filter into parts if they exist
    ExtractStrings(['?'], [], PChar(Filter), FilterParts);

    for I := 0 to FilterParts.Count - 1 do
    begin
      Conditions.Clear;
      ExtractStrings(['*'], [], PChar(FilterParts[I]), Conditions);

      Condition := Conditions[1];

      if I > 0 then
        Where := Where + ' AND ';

      // $cont (LIKE %val%, contains)
      if Condition = '$cont' then
      begin
        Field := Conditions[0];
        Value := Conditions[2];
        Where := Where + Field + ' like "%' + Value + '%"';
      end;

      // $eq (=, equal)
      if Condition = '$eq' then
      begin
        Field := Conditions[0];
        Value := Conditions[2];
        Where := Where + Field + ' = "' + Value + '"';
      end;

      // $between (BETWEEN, between, accepts two values)
      if Condition = '$between' then
      begin
        Field := Conditions[0];
        ExtractStrings([','], [], PChar(Conditions[2]), Dates);
        StartDate := Dates[0];
        EndDate := Dates[1];
        Where := Where + Field + ' between ' + QuotedStr(StartDate) + ' and ' + QuotedStr(EndDate);
      end;
    end;

  finally
    Conditions.Free;
    Dates.Free;
    FilterParts.Free;
  end;
end;

end.
