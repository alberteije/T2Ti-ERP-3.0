unit InssModel;

interface

uses
  Generics.Collections, System.SysUtils,
	SalarioFamiliaModel, 
	InssDetalheModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TInssModel = class(TModelBase)
  private
    FId: Integer;
    FCompetencia: string;
      
    FSalarioFamiliaModelList: TObjectList<TSalarioFamiliaModel>;
    FInssDetalheModelList: TObjectList<TInssDetalheModel>;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('competencia')] 
		[MVCNameAsAttribute('competencia')] 
		property Competencia: string read FCompetencia write FCompetencia; 

      
    [MapperListOf(TSalarioFamiliaModel)] 
		[MVCNameAsAttribute('salarioFamiliaModelList')] 
		property SalarioFamiliaModelList: TObjectList<TSalarioFamiliaModel> read FSalarioFamiliaModelList write FSalarioFamiliaModelList; 

    [MapperListOf(TInssDetalheModel)] 
		[MVCNameAsAttribute('inssDetalheModelList')] 
		property InssDetalheModelList: TObjectList<TInssDetalheModel> read FInssDetalheModelList write FInssDetalheModelList; 

  end;

implementation

{ TInssModel }

constructor TInssModel.Create;
begin
  inherited;
	FSalarioFamiliaModelList := TObjectList<TSalarioFamiliaModel>.Create;
	FInssDetalheModelList := TObjectList<TInssDetalheModel>.Create;
end;

destructor TInssModel.Destroy;
begin
	FreeAndNil(FSalarioFamiliaModelList);
	FreeAndNil(FInssDetalheModelList);
  inherited;
end;


end.