unit FolhaPppExameMedicoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaPppExameMedicoModel = class(TModelBase)
  private
    FId: Integer;
    FIdFolhaPpp: Integer;
    FDataUltimo: TDateTime;
    FTipo: string;
    FExame: string;
    FNatureza: string;
    FIndicacaoResultados: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_folha_ppp')] 
		[MVCNameAsAttribute('idFolhaPpp')] 
		property IdFolhaPpp: Integer read FIdFolhaPpp write FIdFolhaPpp; 

    [MVCColumnAttribute('data_ultimo')] 
		[MVCNameAsAttribute('dataUltimo')] 
		property DataUltimo: TDateTime read FDataUltimo write FDataUltimo; 

    [MVCColumnAttribute('tipo')] 
		[MVCNameAsAttribute('tipo')] 
		property Tipo: string read FTipo write FTipo; 

    [MVCColumnAttribute('exame')] 
		[MVCNameAsAttribute('exame')] 
		property Exame: string read FExame write FExame; 

    [MVCColumnAttribute('natureza')] 
		[MVCNameAsAttribute('natureza')] 
		property Natureza: string read FNatureza write FNatureza; 

    [MVCColumnAttribute('indicacao_resultados')] 
		[MVCNameAsAttribute('indicacaoResultados')] 
		property IndicacaoResultados: string read FIndicacaoResultados write FIndicacaoResultados; 

      
  end;

implementation

{ TFolhaPppExameMedicoModel }

constructor TFolhaPppExameMedicoModel.Create;
begin
  inherited;
end;

destructor TFolhaPppExameMedicoModel.Destroy;
begin
  inherited;
end;


end.