unit FeriasPeriodoAquisitivoModel;

interface

uses
  Generics.Collections, System.SysUtils,
	ViewPessoaColaboradorModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFeriasPeriodoAquisitivoModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FDataInicio: TDateTime;
    FDataFim: TDateTime;
    FSituacao: string;
    FLimiteParaGozo: TDateTime;
    FDescontarFaltas: string;
    FDesconsiderarAfastamento: string;
    FAfastamentoPrevidencia: Integer;
    FAfastamentoSemRemun: Integer;
    FAfastamentoComRemun: Integer;
    FDiasDireito: Integer;
    FDiasGozados: Integer;
    FDiasFaltas: Integer;
    FDiasRestantes: Integer;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('data_inicio')] 
		[MVCNameAsAttribute('dataInicio')] 
		property DataInicio: TDateTime read FDataInicio write FDataInicio; 

    [MVCColumnAttribute('data_fim')] 
		[MVCNameAsAttribute('dataFim')] 
		property DataFim: TDateTime read FDataFim write FDataFim; 

    [MVCColumnAttribute('situacao')] 
		[MVCNameAsAttribute('situacao')] 
		property Situacao: string read FSituacao write FSituacao; 

    [MVCColumnAttribute('limite_para_gozo')] 
		[MVCNameAsAttribute('limiteParaGozo')] 
		property LimiteParaGozo: TDateTime read FLimiteParaGozo write FLimiteParaGozo; 

    [MVCColumnAttribute('descontar_faltas')] 
		[MVCNameAsAttribute('descontarFaltas')] 
		property DescontarFaltas: string read FDescontarFaltas write FDescontarFaltas; 

    [MVCColumnAttribute('desconsiderar_afastamento')] 
		[MVCNameAsAttribute('desconsiderarAfastamento')] 
		property DesconsiderarAfastamento: string read FDesconsiderarAfastamento write FDesconsiderarAfastamento; 

    [MVCColumnAttribute('afastamento_previdencia')] 
		[MVCNameAsAttribute('afastamentoPrevidencia')] 
		property AfastamentoPrevidencia: Integer read FAfastamentoPrevidencia write FAfastamentoPrevidencia; 

    [MVCColumnAttribute('afastamento_sem_remun')] 
		[MVCNameAsAttribute('afastamentoSemRemun')] 
		property AfastamentoSemRemun: Integer read FAfastamentoSemRemun write FAfastamentoSemRemun; 

    [MVCColumnAttribute('afastamento_com_remun')] 
		[MVCNameAsAttribute('afastamentoComRemun')] 
		property AfastamentoComRemun: Integer read FAfastamentoComRemun write FAfastamentoComRemun; 

    [MVCColumnAttribute('dias_direito')] 
		[MVCNameAsAttribute('diasDireito')] 
		property DiasDireito: Integer read FDiasDireito write FDiasDireito; 

    [MVCColumnAttribute('dias_gozados')] 
		[MVCNameAsAttribute('diasGozados')] 
		property DiasGozados: Integer read FDiasGozados write FDiasGozados; 

    [MVCColumnAttribute('dias_faltas')] 
		[MVCNameAsAttribute('diasFaltas')] 
		property DiasFaltas: Integer read FDiasFaltas write FDiasFaltas; 

    [MVCColumnAttribute('dias_restantes')] 
		[MVCNameAsAttribute('diasRestantes')] 
		property DiasRestantes: Integer read FDiasRestantes write FDiasRestantes; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

  end;

implementation

{ TFeriasPeriodoAquisitivoModel }

constructor TFeriasPeriodoAquisitivoModel.Create;
begin
  inherited;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
end;

destructor TFeriasPeriodoAquisitivoModel.Destroy;
begin
	FreeAndNil(FViewPessoaColaboradorModel);
  inherited;
end;


end.