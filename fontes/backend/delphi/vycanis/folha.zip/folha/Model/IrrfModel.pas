unit IrrfModel;

interface

uses
  Generics.Collections, System.SysUtils,
	IrrfDetalheModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TIrrfModel = class(TModelBase)
  private
    FId: Integer;
    FCompetencia: string;
    FDescontoPorDependente: Extended;
    FMinimoParaRetencao: Extended;
      
    FIrrfDetalheModelList: TObjectList<TIrrfDetalheModel>;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('competencia')] 
		[MVCNameAsAttribute('competencia')] 
		property Competencia: string read FCompetencia write FCompetencia; 

    [MVCColumnAttribute('desconto_por_dependente')] 
		[MVCNameAsAttribute('descontoPorDependente')] 
		property DescontoPorDependente: Extended read FDescontoPorDependente write FDescontoPorDependente; 

    [MVCColumnAttribute('minimo_para_retencao')] 
		[MVCNameAsAttribute('minimoParaRetencao')] 
		property MinimoParaRetencao: Extended read FMinimoParaRetencao write FMinimoParaRetencao; 

      
    [MapperListOf(TIrrfDetalheModel)] 
		[MVCNameAsAttribute('irrfDetalheModelList')] 
		property IrrfDetalheModelList: TObjectList<TIrrfDetalheModel> read FIrrfDetalheModelList write FIrrfDetalheModelList; 

  end;

implementation

{ TIrrfModel }

constructor TIrrfModel.Create;
begin
  inherited;
	FIrrfDetalheModelList := TObjectList<TIrrfDetalheModel>.Create;
end;

destructor TIrrfModel.Destroy;
begin
	FreeAndNil(FIrrfDetalheModelList);
  inherited;
end;


end.