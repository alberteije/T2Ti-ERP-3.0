unit GuiasAcumuladasModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TGuiasAcumuladasModel = class(TModelBase)
  private
    FId: Integer;
    FGpsTipo: string;
    FGpsCompetencia: string;
    FGpsValorInss: Extended;
    FGpsValorOutrasEnt: Extended;
    FGpsDataPagamento: TDateTime;
    FIrrfCompetencia: string;
    FIrrfCodigoRecolhimento: Integer;
    FIrrfValorAcumulado: Extended;
    FIrrfDataPagamento: TDateTime;
    FPisCompetencia: string;
    FPisValorAcumulado: Extended;
    FPisDataPagamento: TDateTime;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('gps_tipo')] 
		[MVCNameAsAttribute('gpsTipo')] 
		property GpsTipo: string read FGpsTipo write FGpsTipo; 

    [MVCColumnAttribute('gps_competencia')] 
		[MVCNameAsAttribute('gpsCompetencia')] 
		property GpsCompetencia: string read FGpsCompetencia write FGpsCompetencia; 

    [MVCColumnAttribute('gps_valor_inss')] 
		[MVCNameAsAttribute('gpsValorInss')] 
		property GpsValorInss: Extended read FGpsValorInss write FGpsValorInss; 

    [MVCColumnAttribute('gps_valor_outras_ent')] 
		[MVCNameAsAttribute('gpsValorOutrasEnt')] 
		property GpsValorOutrasEnt: Extended read FGpsValorOutrasEnt write FGpsValorOutrasEnt; 

    [MVCColumnAttribute('gps_data_pagamento')] 
		[MVCNameAsAttribute('gpsDataPagamento')] 
		property GpsDataPagamento: TDateTime read FGpsDataPagamento write FGpsDataPagamento; 

    [MVCColumnAttribute('irrf_competencia')] 
		[MVCNameAsAttribute('irrfCompetencia')] 
		property IrrfCompetencia: string read FIrrfCompetencia write FIrrfCompetencia; 

    [MVCColumnAttribute('irrf_codigo_recolhimento')] 
		[MVCNameAsAttribute('irrfCodigoRecolhimento')] 
		property IrrfCodigoRecolhimento: Integer read FIrrfCodigoRecolhimento write FIrrfCodigoRecolhimento; 

    [MVCColumnAttribute('irrf_valor_acumulado')] 
		[MVCNameAsAttribute('irrfValorAcumulado')] 
		property IrrfValorAcumulado: Extended read FIrrfValorAcumulado write FIrrfValorAcumulado; 

    [MVCColumnAttribute('irrf_data_pagamento')] 
		[MVCNameAsAttribute('irrfDataPagamento')] 
		property IrrfDataPagamento: TDateTime read FIrrfDataPagamento write FIrrfDataPagamento; 

    [MVCColumnAttribute('pis_competencia')] 
		[MVCNameAsAttribute('pisCompetencia')] 
		property PisCompetencia: string read FPisCompetencia write FPisCompetencia; 

    [MVCColumnAttribute('pis_valor_acumulado')] 
		[MVCNameAsAttribute('pisValorAcumulado')] 
		property PisValorAcumulado: Extended read FPisValorAcumulado write FPisValorAcumulado; 

    [MVCColumnAttribute('pis_data_pagamento')] 
		[MVCNameAsAttribute('pisDataPagamento')] 
		property PisDataPagamento: TDateTime read FPisDataPagamento write FPisDataPagamento; 

      
  end;

implementation

{ TGuiasAcumuladasModel }

constructor TGuiasAcumuladasModel.Create;
begin
  inherited;
end;

destructor TGuiasAcumuladasModel.Destroy;
begin
  inherited;
end;


end.