unit OperadoraPlanoSaudeModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TOperadoraPlanoSaudeModel = class(TModelBase)
  private
    FId: Integer;
    FNome: string;
    FRegistroAns: string;
    FClassificacaoContabilConta: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('registro_ans')] 
		[MVCNameAsAttribute('registroAns')] 
		property RegistroAns: string read FRegistroAns write FRegistroAns; 

    [MVCColumnAttribute('classificacao_contabil_conta')] 
		[MVCNameAsAttribute('classificacaoContabilConta')] 
		property ClassificacaoContabilConta: string read FClassificacaoContabilConta write FClassificacaoContabilConta; 

      
  end;

implementation

{ TOperadoraPlanoSaudeModel }

constructor TOperadoraPlanoSaudeModel.Create;
begin
  inherited;
end;

destructor TOperadoraPlanoSaudeModel.Destroy;
begin
  inherited;
end;


end.