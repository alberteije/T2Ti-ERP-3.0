unit FolhaHistoricoSalarialModel;

interface

uses
  Generics.Collections, System.SysUtils,
	ViewPessoaColaboradorModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaHistoricoSalarialModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FCompetencia: string;
    FSalarioAtual: Extended;
    FPercentualAumento: Extended;
    FSalarioNovo: Extended;
    FValidoAPartir: string;
    FMotivo: string;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('competencia')] 
		[MVCNameAsAttribute('competencia')] 
		property Competencia: string read FCompetencia write FCompetencia; 

    [MVCColumnAttribute('salario_atual')] 
		[MVCNameAsAttribute('salarioAtual')] 
		property SalarioAtual: Extended read FSalarioAtual write FSalarioAtual; 

    [MVCColumnAttribute('percentual_aumento')] 
		[MVCNameAsAttribute('percentualAumento')] 
		property PercentualAumento: Extended read FPercentualAumento write FPercentualAumento; 

    [MVCColumnAttribute('salario_novo')] 
		[MVCNameAsAttribute('salarioNovo')] 
		property SalarioNovo: Extended read FSalarioNovo write FSalarioNovo; 

    [MVCColumnAttribute('valido_a_partir')] 
		[MVCNameAsAttribute('validoAPartir')] 
		property ValidoAPartir: string read FValidoAPartir write FValidoAPartir; 

    [MVCColumnAttribute('motivo')] 
		[MVCNameAsAttribute('motivo')] 
		property Motivo: string read FMotivo write FMotivo; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

  end;

implementation

{ TFolhaHistoricoSalarialModel }

constructor TFolhaHistoricoSalarialModel.Create;
begin
  inherited;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
end;

destructor TFolhaHistoricoSalarialModel.Destroy;
begin
	FreeAndNil(FViewPessoaColaboradorModel);
  inherited;
end;


end.