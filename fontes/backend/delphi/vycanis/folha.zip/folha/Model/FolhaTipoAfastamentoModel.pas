unit FolhaTipoAfastamentoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaTipoAfastamentoModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: string;
    FNome: string;
    FCodigoEsocial: string;
    FDescricao: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: string read FCodigo write FCodigo; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('codigo_esocial')] 
		[MVCNameAsAttribute('codigoEsocial')] 
		property CodigoEsocial: string read FCodigoEsocial write FCodigoEsocial; 

    [MVCColumnAttribute('descricao')] 
		[MVCNameAsAttribute('descricao')] 
		property Descricao: string read FDescricao write FDescricao; 

      
  end;

implementation

{ TFolhaTipoAfastamentoModel }

constructor TFolhaTipoAfastamentoModel.Create;
begin
  inherited;
end;

destructor TFolhaTipoAfastamentoModel.Destroy;
begin
  inherited;
end;


end.