unit FolhaPppFatorRiscoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaPppFatorRiscoModel = class(TModelBase)
  private
    FId: Integer;
    FIdFolhaPpp: Integer;
    FDataInicio: TDateTime;
    FDataFim: TDateTime;
    FTipo: string;
    FFatorRisco: string;
    FIntensidade: string;
    FTecnicaUtilizada: string;
    FEpcEficaz: string;
    FEpiEficaz: string;
    FCaEpi: Integer;
    FAtendimentoNr061: string;
    FAtendimentoNr062: string;
    FAtendimentoNr063: string;
    FAtendimentoNr064: string;
    FAtendimentoNr065: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_folha_ppp')] 
		[MVCNameAsAttribute('idFolhaPpp')] 
		property IdFolhaPpp: Integer read FIdFolhaPpp write FIdFolhaPpp; 

    [MVCColumnAttribute('data_inicio')] 
		[MVCNameAsAttribute('dataInicio')] 
		property DataInicio: TDateTime read FDataInicio write FDataInicio; 

    [MVCColumnAttribute('data_fim')] 
		[MVCNameAsAttribute('dataFim')] 
		property DataFim: TDateTime read FDataFim write FDataFim; 

    [MVCColumnAttribute('tipo')] 
		[MVCNameAsAttribute('tipo')] 
		property Tipo: string read FTipo write FTipo; 

    [MVCColumnAttribute('fator_risco')] 
		[MVCNameAsAttribute('fatorRisco')] 
		property FatorRisco: string read FFatorRisco write FFatorRisco; 

    [MVCColumnAttribute('intensidade')] 
		[MVCNameAsAttribute('intensidade')] 
		property Intensidade: string read FIntensidade write FIntensidade; 

    [MVCColumnAttribute('tecnica_utilizada')] 
		[MVCNameAsAttribute('tecnicaUtilizada')] 
		property TecnicaUtilizada: string read FTecnicaUtilizada write FTecnicaUtilizada; 

    [MVCColumnAttribute('epc_eficaz')] 
		[MVCNameAsAttribute('epcEficaz')] 
		property EpcEficaz: string read FEpcEficaz write FEpcEficaz; 

    [MVCColumnAttribute('epi_eficaz')] 
		[MVCNameAsAttribute('epiEficaz')] 
		property EpiEficaz: string read FEpiEficaz write FEpiEficaz; 

    [MVCColumnAttribute('ca_epi')] 
		[MVCNameAsAttribute('caEpi')] 
		property CaEpi: Integer read FCaEpi write FCaEpi; 

    [MVCColumnAttribute('atendimento_nr06_1')] 
		[MVCNameAsAttribute('atendimentoNr061')] 
		property AtendimentoNr061: string read FAtendimentoNr061 write FAtendimentoNr061; 

    [MVCColumnAttribute('atendimento_nr06_2')] 
		[MVCNameAsAttribute('atendimentoNr062')] 
		property AtendimentoNr062: string read FAtendimentoNr062 write FAtendimentoNr062; 

    [MVCColumnAttribute('atendimento_nr06_3')] 
		[MVCNameAsAttribute('atendimentoNr063')] 
		property AtendimentoNr063: string read FAtendimentoNr063 write FAtendimentoNr063; 

    [MVCColumnAttribute('atendimento_nr06_4')] 
		[MVCNameAsAttribute('atendimentoNr064')] 
		property AtendimentoNr064: string read FAtendimentoNr064 write FAtendimentoNr064; 

    [MVCColumnAttribute('atendimento_nr06_5')] 
		[MVCNameAsAttribute('atendimentoNr065')] 
		property AtendimentoNr065: string read FAtendimentoNr065 write FAtendimentoNr065; 

      
  end;

implementation

{ TFolhaPppFatorRiscoModel }

constructor TFolhaPppFatorRiscoModel.Create;
begin
  inherited;
end;

destructor TFolhaPppFatorRiscoModel.Destroy;
begin
  inherited;
end;


end.