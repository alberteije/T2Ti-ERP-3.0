unit ModelBase;

interface

uses
  MVCFramework.Serializer.Commons;

type
  TModelBase = class
  private
  public
  end;

implementation

{ TModelBase }

end.
