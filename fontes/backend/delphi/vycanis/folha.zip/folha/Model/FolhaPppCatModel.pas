unit FolhaPppCatModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaPppCatModel = class(TModelBase)
  private
    FId: Integer;
    FIdFolhaPpp: Integer;
    FNumeroCat: Integer;
    FDataAfastamento: TDateTime;
    FDataRegistro: TDateTime;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_folha_ppp')] 
		[MVCNameAsAttribute('idFolhaPpp')] 
		property IdFolhaPpp: Integer read FIdFolhaPpp write FIdFolhaPpp; 

    [MVCColumnAttribute('numero_cat')] 
		[MVCNameAsAttribute('numeroCat')] 
		property NumeroCat: Integer read FNumeroCat write FNumeroCat; 

    [MVCColumnAttribute('data_afastamento')] 
		[MVCNameAsAttribute('dataAfastamento')] 
		property DataAfastamento: TDateTime read FDataAfastamento write FDataAfastamento; 

    [MVCColumnAttribute('data_registro')] 
		[MVCNameAsAttribute('dataRegistro')] 
		property DataRegistro: TDateTime read FDataRegistro write FDataRegistro; 

      
  end;

implementation

{ TFolhaPppCatModel }

constructor TFolhaPppCatModel.Create;
begin
  inherited;
end;

destructor TFolhaPppCatModel.Destroy;
begin
  inherited;
end;


end.