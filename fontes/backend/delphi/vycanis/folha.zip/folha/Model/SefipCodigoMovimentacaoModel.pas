unit SefipCodigoMovimentacaoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TSefipCodigoMovimentacaoModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: string;
    FDescricao: string;
    FAplicacao: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: string read FCodigo write FCodigo; 

    [MVCColumnAttribute('descricao')] 
		[MVCNameAsAttribute('descricao')] 
		property Descricao: string read FDescricao write FDescricao; 

    [MVCColumnAttribute('aplicacao')] 
		[MVCNameAsAttribute('aplicacao')] 
		property Aplicacao: string read FAplicacao write FAplicacao; 

      
  end;

implementation

{ TSefipCodigoMovimentacaoModel }

constructor TSefipCodigoMovimentacaoModel.Create;
begin
  inherited;
end;

destructor TSefipCodigoMovimentacaoModel.Destroy;
begin
  inherited;
end;


end.