unit FpasModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFpasModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: Integer;
    FCnae: string;
    FAliquotaSat: Extended;
    FDescricao: string;
    FPercentualInssPatronal: Extended;
    FCodigoTerceiro: string;
    FPercentualTerceiros: Extended;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: Integer read FCodigo write FCodigo; 

    [MVCColumnAttribute('cnae')] 
		[MVCNameAsAttribute('cnae')] 
		property Cnae: string read FCnae write FCnae; 

    [MVCColumnAttribute('aliquota_sat')] 
		[MVCNameAsAttribute('aliquotaSat')] 
		property AliquotaSat: Extended read FAliquotaSat write FAliquotaSat; 

    [MVCColumnAttribute('descricao')] 
		[MVCNameAsAttribute('descricao')] 
		property Descricao: string read FDescricao write FDescricao; 

    [MVCColumnAttribute('percentual_inss_patronal')] 
		[MVCNameAsAttribute('percentualInssPatronal')] 
		property PercentualInssPatronal: Extended read FPercentualInssPatronal write FPercentualInssPatronal; 

    [MVCColumnAttribute('codigo_terceiro')] 
		[MVCNameAsAttribute('codigoTerceiro')] 
		property CodigoTerceiro: string read FCodigoTerceiro write FCodigoTerceiro; 

    [MVCColumnAttribute('percentual_terceiros')] 
		[MVCNameAsAttribute('percentualTerceiros')] 
		property PercentualTerceiros: Extended read FPercentualTerceiros write FPercentualTerceiros; 

      
  end;

implementation

{ TFpasModel }

constructor TFpasModel.Create;
begin
  inherited;
end;

destructor TFpasModel.Destroy;
begin
  inherited;
end;


end.