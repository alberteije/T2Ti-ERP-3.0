unit ViewPessoaColaboradorModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TViewPessoaColaboradorModel = class(TModelBase)
  private
    FId: Integer;
    FNome: string;
    FTipo: string;
    FEmail: string;
    FSite: string;
    FCpfCnpj: string;
    FRgIe: string;
    FMatricula: string;
    FDataCadastro: TDateTime;
    FDataAdmissao: TDateTime;
    FDataDemissao: TDateTime;
    FCtpsNumero: string;
    FCtpsSerie: string;
    FCtpsDataExpedicao: TDateTime;
    FCtpsUf: string;
    FObservacao: string;
    FLogradouro: string;
    FNumero: string;
    FComplemento: string;
    FBairro: string;
    FCidade: string;
    FCep: string;
    FMunicipioIbge: string;
    FUf: string;
    FIdPessoa: Integer;
    FIdCargo: Integer;
    FIdSetor: Integer;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('tipo')] 
		[MVCNameAsAttribute('tipo')] 
		property Tipo: string read FTipo write FTipo; 

    [MVCColumnAttribute('email')] 
		[MVCNameAsAttribute('email')] 
		property Email: string read FEmail write FEmail; 

    [MVCColumnAttribute('site')] 
		[MVCNameAsAttribute('site')] 
		property Site: string read FSite write FSite; 

    [MVCColumnAttribute('cpf_cnpj')] 
		[MVCNameAsAttribute('cpfCnpj')] 
		property CpfCnpj: string read FCpfCnpj write FCpfCnpj; 

    [MVCColumnAttribute('rg_ie')] 
		[MVCNameAsAttribute('rgIe')] 
		property RgIe: string read FRgIe write FRgIe; 

    [MVCColumnAttribute('matricula')] 
		[MVCNameAsAttribute('matricula')] 
		property Matricula: string read FMatricula write FMatricula; 

    [MVCColumnAttribute('data_cadastro')] 
		[MVCNameAsAttribute('dataCadastro')] 
		property DataCadastro: TDateTime read FDataCadastro write FDataCadastro; 

    [MVCColumnAttribute('data_admissao')] 
		[MVCNameAsAttribute('dataAdmissao')] 
		property DataAdmissao: TDateTime read FDataAdmissao write FDataAdmissao; 

    [MVCColumnAttribute('data_demissao')] 
		[MVCNameAsAttribute('dataDemissao')] 
		property DataDemissao: TDateTime read FDataDemissao write FDataDemissao; 

    [MVCColumnAttribute('ctps_numero')] 
		[MVCNameAsAttribute('ctpsNumero')] 
		property CtpsNumero: string read FCtpsNumero write FCtpsNumero; 

    [MVCColumnAttribute('ctps_serie')] 
		[MVCNameAsAttribute('ctpsSerie')] 
		property CtpsSerie: string read FCtpsSerie write FCtpsSerie; 

    [MVCColumnAttribute('ctps_data_expedicao')] 
		[MVCNameAsAttribute('ctpsDataExpedicao')] 
		property CtpsDataExpedicao: TDateTime read FCtpsDataExpedicao write FCtpsDataExpedicao; 

    [MVCColumnAttribute('ctps_uf')] 
		[MVCNameAsAttribute('ctpsUf')] 
		property CtpsUf: string read FCtpsUf write FCtpsUf; 

    [MVCColumnAttribute('observacao')] 
		[MVCNameAsAttribute('observacao')] 
		property Observacao: string read FObservacao write FObservacao; 

    [MVCColumnAttribute('logradouro')] 
		[MVCNameAsAttribute('logradouro')] 
		property Logradouro: string read FLogradouro write FLogradouro; 

    [MVCColumnAttribute('numero')] 
		[MVCNameAsAttribute('numero')] 
		property Numero: string read FNumero write FNumero; 

    [MVCColumnAttribute('complemento')] 
		[MVCNameAsAttribute('complemento')] 
		property Complemento: string read FComplemento write FComplemento; 

    [MVCColumnAttribute('bairro')] 
		[MVCNameAsAttribute('bairro')] 
		property Bairro: string read FBairro write FBairro; 

    [MVCColumnAttribute('cidade')] 
		[MVCNameAsAttribute('cidade')] 
		property Cidade: string read FCidade write FCidade; 

    [MVCColumnAttribute('cep')] 
		[MVCNameAsAttribute('cep')] 
		property Cep: string read FCep write FCep; 

    [MVCColumnAttribute('municipio_ibge')] 
		[MVCNameAsAttribute('municipioIbge')] 
		property MunicipioIbge: string read FMunicipioIbge write FMunicipioIbge; 

    [MVCColumnAttribute('uf')] 
		[MVCNameAsAttribute('uf')] 
		property Uf: string read FUf write FUf; 

    [MVCColumnAttribute('id_pessoa')] 
		[MVCNameAsAttribute('idPessoa')] 
		property IdPessoa: Integer read FIdPessoa write FIdPessoa; 

    [MVCColumnAttribute('id_cargo')] 
		[MVCNameAsAttribute('idCargo')] 
		property IdCargo: Integer read FIdCargo write FIdCargo; 

    [MVCColumnAttribute('id_setor')] 
		[MVCNameAsAttribute('idSetor')] 
		property IdSetor: Integer read FIdSetor write FIdSetor; 

      
  end;

implementation

{ TViewPessoaColaboradorModel }

constructor TViewPessoaColaboradorModel.Create;
begin
  inherited;
end;

destructor TViewPessoaColaboradorModel.Destroy;
begin
  inherited;
end;


end.