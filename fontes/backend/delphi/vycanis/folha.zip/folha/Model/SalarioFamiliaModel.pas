unit SalarioFamiliaModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TSalarioFamiliaModel = class(TModelBase)
  private
    FId: Integer;
    FIdInss: Integer;
    FFaixa: Integer;
    FDe: Extended;
    FAte: Extended;
    FValor: Extended;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_inss')] 
		[MVCNameAsAttribute('idInss')] 
		property IdInss: Integer read FIdInss write FIdInss; 

    [MVCColumnAttribute('faixa')] 
		[MVCNameAsAttribute('faixa')] 
		property Faixa: Integer read FFaixa write FFaixa; 

    [MVCColumnAttribute('de')] 
		[MVCNameAsAttribute('de')] 
		property De: Extended read FDe write FDe; 

    [MVCColumnAttribute('ate')] 
		[MVCNameAsAttribute('ate')] 
		property Ate: Extended read FAte write FAte; 

    [MVCColumnAttribute('valor')] 
		[MVCNameAsAttribute('valor')] 
		property Valor: Extended read FValor write FValor; 

      
  end;

implementation

{ TSalarioFamiliaModel }

constructor TSalarioFamiliaModel.Create;
begin
  inherited;
end;

destructor TSalarioFamiliaModel.Destroy;
begin
  inherited;
end;


end.