unit EmpresaTransporteItinerarioModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TEmpresaTransporteItinerarioModel = class(TModelBase)
  private
    FId: Integer;
    FIdEmpresaTransporte: Integer;
    FNome: string;
    FTarifa: Extended;
    FTrajeto: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_empresa_transporte')] 
		[MVCNameAsAttribute('idEmpresaTransporte')] 
		property IdEmpresaTransporte: Integer read FIdEmpresaTransporte write FIdEmpresaTransporte; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('tarifa')] 
		[MVCNameAsAttribute('tarifa')] 
		property Tarifa: Extended read FTarifa write FTarifa; 

    [MVCColumnAttribute('trajeto')] 
		[MVCNameAsAttribute('trajeto')] 
		property Trajeto: string read FTrajeto write FTrajeto; 

      
  end;

implementation

{ TEmpresaTransporteItinerarioModel }

constructor TEmpresaTransporteItinerarioModel.Create;
begin
  inherited;
end;

destructor TEmpresaTransporteItinerarioModel.Destroy;
begin
  inherited;
end;


end.