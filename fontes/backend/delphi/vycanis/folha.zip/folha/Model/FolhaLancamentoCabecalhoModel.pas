unit FolhaLancamentoCabecalhoModel;

interface

uses
  Generics.Collections, System.SysUtils,
	FolhaLancamentoDetalheModel, 
	ViewPessoaColaboradorModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaLancamentoCabecalhoModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FCompetencia: string;
    FTipo: string;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
    FFolhaLancamentoDetalheModelList: TObjectList<TFolhaLancamentoDetalheModel>;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('competencia')] 
		[MVCNameAsAttribute('competencia')] 
		property Competencia: string read FCompetencia write FCompetencia; 

    [MVCColumnAttribute('tipo')] 
		[MVCNameAsAttribute('tipo')] 
		property Tipo: string read FTipo write FTipo; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

    [MapperListOf(TFolhaLancamentoDetalheModel)] 
		[MVCNameAsAttribute('folhaLancamentoDetalheModelList')] 
		property FolhaLancamentoDetalheModelList: TObjectList<TFolhaLancamentoDetalheModel> read FFolhaLancamentoDetalheModelList write FFolhaLancamentoDetalheModelList; 

  end;

implementation

{ TFolhaLancamentoCabecalhoModel }

constructor TFolhaLancamentoCabecalhoModel.Create;
begin
  inherited;
	FFolhaLancamentoDetalheModelList := TObjectList<TFolhaLancamentoDetalheModel>.Create;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
end;

destructor TFolhaLancamentoCabecalhoModel.Destroy;
begin
	FreeAndNil(FFolhaLancamentoDetalheModelList);
	FreeAndNil(FViewPessoaColaboradorModel);
  inherited;
end;


end.