unit FolhaEventoModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaEventoModel = class(TModelBase)
  private
    FId: Integer;
    FCodigo: string;
    FNome: string;
    FDescricao: string;
    FBaseCalculo: string;
    FTipo: string;
    FUnidade: string;
    FTaxa: Extended;
    FRubricaEsocial: string;
    FCodIncidenciaPrevidencia: string;
    FCodIncidenciaIrrf: string;
    FCodIncidenciaFgts: string;
    FCodIncidenciaSindicato: string;
    FRepercuteDsr: string;
    FRepercute13: string;
    FRepercuteFerias: string;
    FRepercuteAviso: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('codigo')] 
		[MVCNameAsAttribute('codigo')] 
		property Codigo: string read FCodigo write FCodigo; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('descricao')] 
		[MVCNameAsAttribute('descricao')] 
		property Descricao: string read FDescricao write FDescricao; 

    [MVCColumnAttribute('base_calculo')] 
		[MVCNameAsAttribute('baseCalculo')] 
		property BaseCalculo: string read FBaseCalculo write FBaseCalculo; 

    [MVCColumnAttribute('tipo')] 
		[MVCNameAsAttribute('tipo')] 
		property Tipo: string read FTipo write FTipo; 

    [MVCColumnAttribute('unidade')] 
		[MVCNameAsAttribute('unidade')] 
		property Unidade: string read FUnidade write FUnidade; 

    [MVCColumnAttribute('taxa')] 
		[MVCNameAsAttribute('taxa')] 
		property Taxa: Extended read FTaxa write FTaxa; 

    [MVCColumnAttribute('rubrica_esocial')] 
		[MVCNameAsAttribute('rubricaEsocial')] 
		property RubricaEsocial: string read FRubricaEsocial write FRubricaEsocial; 

    [MVCColumnAttribute('cod_incidencia_previdencia')] 
		[MVCNameAsAttribute('codIncidenciaPrevidencia')] 
		property CodIncidenciaPrevidencia: string read FCodIncidenciaPrevidencia write FCodIncidenciaPrevidencia; 

    [MVCColumnAttribute('cod_incidencia_irrf')] 
		[MVCNameAsAttribute('codIncidenciaIrrf')] 
		property CodIncidenciaIrrf: string read FCodIncidenciaIrrf write FCodIncidenciaIrrf; 

    [MVCColumnAttribute('cod_incidencia_fgts')] 
		[MVCNameAsAttribute('codIncidenciaFgts')] 
		property CodIncidenciaFgts: string read FCodIncidenciaFgts write FCodIncidenciaFgts; 

    [MVCColumnAttribute('cod_incidencia_sindicato')] 
		[MVCNameAsAttribute('codIncidenciaSindicato')] 
		property CodIncidenciaSindicato: string read FCodIncidenciaSindicato write FCodIncidenciaSindicato; 

    [MVCColumnAttribute('repercute_dsr')] 
		[MVCNameAsAttribute('repercuteDsr')] 
		property RepercuteDsr: string read FRepercuteDsr write FRepercuteDsr; 

    [MVCColumnAttribute('repercute_13')] 
		[MVCNameAsAttribute('repercute13')] 
		property Repercute13: string read FRepercute13 write FRepercute13; 

    [MVCColumnAttribute('repercute_ferias')] 
		[MVCNameAsAttribute('repercuteFerias')] 
		property RepercuteFerias: string read FRepercuteFerias write FRepercuteFerias; 

    [MVCColumnAttribute('repercute_aviso')] 
		[MVCNameAsAttribute('repercuteAviso')] 
		property RepercuteAviso: string read FRepercuteAviso write FRepercuteAviso; 

      
  end;

implementation

{ TFolhaEventoModel }

constructor TFolhaEventoModel.Create;
begin
  inherited;
end;

destructor TFolhaEventoModel.Destroy;
begin
  inherited;
end;


end.