unit FolhaAfastamentoModel;

interface

uses
  Generics.Collections, System.SysUtils,
	ViewPessoaColaboradorModel, 
	FolhaTipoAfastamentoModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TFolhaAfastamentoModel = class(TModelBase)
  private
    FId: Integer;
    FIdColaborador: Integer;
    FIdFolhaTipoAfastamento: Integer;
    FDataInicio: TDateTime;
    FDataFim: TDateTime;
    FDiasAfastado: Integer;
      
    FViewPessoaColaboradorModel: TViewPessoaColaboradorModel;
    FFolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_colaborador')] 
		[MVCNameAsAttribute('idColaborador')] 
		property IdColaborador: Integer read FIdColaborador write FIdColaborador; 

    [MVCColumnAttribute('id_folha_tipo_afastamento')] 
		[MVCNameAsAttribute('idFolhaTipoAfastamento')] 
		property IdFolhaTipoAfastamento: Integer read FIdFolhaTipoAfastamento write FIdFolhaTipoAfastamento; 

    [MVCColumnAttribute('data_inicio')] 
		[MVCNameAsAttribute('dataInicio')] 
		property DataInicio: TDateTime read FDataInicio write FDataInicio; 

    [MVCColumnAttribute('data_fim')] 
		[MVCNameAsAttribute('dataFim')] 
		property DataFim: TDateTime read FDataFim write FDataFim; 

    [MVCColumnAttribute('dias_afastado')] 
		[MVCNameAsAttribute('diasAfastado')] 
		property DiasAfastado: Integer read FDiasAfastado write FDiasAfastado; 

      
    		[MVCNameAsAttribute('viewPessoaColaboradorModel')] 
		property ViewPessoaColaboradorModel: TViewPessoaColaboradorModel read FViewPessoaColaboradorModel write FViewPessoaColaboradorModel; 

    		[MVCNameAsAttribute('folhaTipoAfastamentoModel')] 
		property FolhaTipoAfastamentoModel: TFolhaTipoAfastamentoModel read FFolhaTipoAfastamentoModel write FFolhaTipoAfastamentoModel; 

  end;

implementation

{ TFolhaAfastamentoModel }

constructor TFolhaAfastamentoModel.Create;
begin
  inherited;
	FViewPessoaColaboradorModel := TViewPessoaColaboradorModel.Create;
	FFolhaTipoAfastamentoModel := TFolhaTipoAfastamentoModel.Create;
end;

destructor TFolhaAfastamentoModel.Destroy;
begin
	FreeAndNil(FViewPessoaColaboradorModel);
	FreeAndNil(FFolhaTipoAfastamentoModel);
  inherited;
end;


end.