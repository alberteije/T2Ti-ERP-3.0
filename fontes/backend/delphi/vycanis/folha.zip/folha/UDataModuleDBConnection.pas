unit UDataModuleDBConnection;

interface

uses
  System.SysUtils, System.Classes, FireDAC.Stan.Intf, FireDAC.Stan.Option,
  FireDAC.Stan.Error, FireDAC.UI.Intf, FireDAC.Phys.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Stan.Async, FireDAC.Phys, FireDAC.VCLUI.Wait,
  Data.DB, FireDAC.Comp.Client, FireDAC.Phys.MySQLDef, FireDAC.Phys.MySQL,
  FireDAC.DApt.Intf,
  FireDAC.DApt;

type
  TFDataModuleDBConnection = class(TDataModule)
    Connection: TFDConnection;
    FDTransaction: TFDTransaction;
    FDPhysMySQLDriverLink: TFDPhysMySQLDriverLink;
    procedure DataModuleCreate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FDataModuleDBConnection: TFDataModuleDBConnection;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

procedure TFDataModuleDBConnection.DataModuleCreate(Sender: TObject);
begin
  Connection.Params.Clear;
  Connection.Params.Add('DriverID=MySQL');
  Connection.Params.Add('Server=localhost');
  Connection.Params.Add('Port=3306');
  Connection.Params.Add('Database=folha');
  Connection.Params.Add('CharacterSet=utf8');
  Connection.Params.Add('User_Name=root');
  Connection.Params.Add('Password=root');
  Connection.DriverName := 'MySQL';
  Connection.Connected := True;
end;

end.
