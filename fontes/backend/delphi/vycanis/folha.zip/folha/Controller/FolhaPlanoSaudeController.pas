﻿unit FolhaPlanoSaudeController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaPlanoSaude')]
  [MVCPath('/folha-plano-saude')]
  TFolhaPlanoSaudeController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaPlanoSaudeController }

uses FolhaPlanoSaudeService, FolhaPlanoSaudeModel, Commons, Filter;

procedure TFolhaPlanoSaudeController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaPlanoSaudeModel>(TFolhaPlanoSaudeService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaPlanoSaudeModel>(TFolhaPlanoSaudeService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaPlanoSaude] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaPlanoSaudeController.GetObject(id: Integer);
var
  FolhaPlanoSaude: TFolhaPlanoSaudeModel;
begin
  try
    FolhaPlanoSaude := TFolhaPlanoSaudeService.GetObject(id);

    if Assigned(FolhaPlanoSaude) then
      Render(FolhaPlanoSaude)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaPlanoSaude]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaPlanoSaude] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaPlanoSaudeController.Insert(Context: TWebContext);
var
  FolhaPlanoSaude: TFolhaPlanoSaudeModel;
begin
  try
    FolhaPlanoSaude := Context.Request.BodyAs<TFolhaPlanoSaudeModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaPlanoSaude] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaPlanoSaudeService.Insert(FolhaPlanoSaude);
    Render(TFolhaPlanoSaudeService.GetObject(FolhaPlanoSaude.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaPlanoSaude] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaPlanoSaudeController.Update(Context: TWebContext);
var
  FolhaPlanoSaude, FolhaPlanoSaudeDB: TFolhaPlanoSaudeModel;
begin
  try
    FolhaPlanoSaude := Context.Request.BodyAs<TFolhaPlanoSaudeModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaPlanoSaude] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaPlanoSaudeDB := TFolhaPlanoSaudeService.GetObject(FolhaPlanoSaude.id);

  if not Assigned(FolhaPlanoSaudeDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaPlanoSaude]',
      '', 0, 400);

  try
    if TFolhaPlanoSaudeService.Update(FolhaPlanoSaude) > 0 then
      Render(TFolhaPlanoSaudeService.GetObject(FolhaPlanoSaude.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaPlanoSaude]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaPlanoSaudeDB);
  end;
end;

procedure TFolhaPlanoSaudeController.Delete(id: Integer);
var
  FolhaPlanoSaude: TFolhaPlanoSaudeModel;
begin
  FolhaPlanoSaude := TFolhaPlanoSaudeService.GetObject(id);

  if not Assigned(FolhaPlanoSaude) then
    raise EMVCException.Create('Invalid Object [Delete FolhaPlanoSaude]',
      '', 0, 400);

  try
    if TFolhaPlanoSaudeService.Delete(FolhaPlanoSaude) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaPlanoSaude]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaPlanoSaude);
  end;
end;

end.
