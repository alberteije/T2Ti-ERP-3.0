﻿unit OperadoraPlanoSaudeController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD OperadoraPlanoSaude')]
  [MVCPath('/operadora-plano-saude')]
  TOperadoraPlanoSaudeController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TOperadoraPlanoSaudeController }

uses OperadoraPlanoSaudeService, OperadoraPlanoSaudeModel, Commons, Filter;

procedure TOperadoraPlanoSaudeController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TOperadoraPlanoSaudeModel>(TOperadoraPlanoSaudeService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TOperadoraPlanoSaudeModel>(TOperadoraPlanoSaudeService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList OperadoraPlanoSaude] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TOperadoraPlanoSaudeController.GetObject(id: Integer);
var
  OperadoraPlanoSaude: TOperadoraPlanoSaudeModel;
begin
  try
    OperadoraPlanoSaude := TOperadoraPlanoSaudeService.GetObject(id);

    if Assigned(OperadoraPlanoSaude) then
      Render(OperadoraPlanoSaude)
    else
      raise EMVCException.Create
        ('Not Found [GetObject OperadoraPlanoSaude]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject OperadoraPlanoSaude] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TOperadoraPlanoSaudeController.Insert(Context: TWebContext);
var
  OperadoraPlanoSaude: TOperadoraPlanoSaudeModel;
begin
  try
    OperadoraPlanoSaude := Context.Request.BodyAs<TOperadoraPlanoSaudeModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert OperadoraPlanoSaude] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TOperadoraPlanoSaudeService.Insert(OperadoraPlanoSaude);
    Render(TOperadoraPlanoSaudeService.GetObject(OperadoraPlanoSaude.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert OperadoraPlanoSaude] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TOperadoraPlanoSaudeController.Update(Context: TWebContext);
var
  OperadoraPlanoSaude, OperadoraPlanoSaudeDB: TOperadoraPlanoSaudeModel;
begin
  try
    OperadoraPlanoSaude := Context.Request.BodyAs<TOperadoraPlanoSaudeModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update OperadoraPlanoSaude] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  OperadoraPlanoSaudeDB := TOperadoraPlanoSaudeService.GetObject(OperadoraPlanoSaude.id);

  if not Assigned(OperadoraPlanoSaudeDB) then
    raise EMVCException.Create('Invalid Object [Update OperadoraPlanoSaude]',
      '', 0, 400);

  try
    if TOperadoraPlanoSaudeService.Update(OperadoraPlanoSaude) > 0 then
      Render(TOperadoraPlanoSaudeService.GetObject(OperadoraPlanoSaude.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update OperadoraPlanoSaude]',
        '', 0, 500);
  finally
    FreeAndNil(OperadoraPlanoSaudeDB);
  end;
end;

procedure TOperadoraPlanoSaudeController.Delete(id: Integer);
var
  OperadoraPlanoSaude: TOperadoraPlanoSaudeModel;
begin
  OperadoraPlanoSaude := TOperadoraPlanoSaudeService.GetObject(id);

  if not Assigned(OperadoraPlanoSaude) then
    raise EMVCException.Create('Invalid Object [Delete OperadoraPlanoSaude]',
      '', 0, 400);

  try
    if TOperadoraPlanoSaudeService.Delete(OperadoraPlanoSaude) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete OperadoraPlanoSaude]',
        '', 0, 500);
  finally
    FreeAndNil(OperadoraPlanoSaude);
  end;
end;

end.
