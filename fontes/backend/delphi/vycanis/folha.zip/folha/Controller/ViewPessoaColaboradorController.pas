﻿unit ViewPessoaColaboradorController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD ViewPessoaColaborador')]
  [MVCPath('/view-pessoa-colaborador')]
  TViewPessoaColaboradorController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TViewPessoaColaboradorController }

uses ViewPessoaColaboradorService, ViewPessoaColaboradorModel, Commons, Filter;

procedure TViewPessoaColaboradorController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TViewPessoaColaboradorModel>(TViewPessoaColaboradorService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TViewPessoaColaboradorModel>(TViewPessoaColaboradorService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList ViewPessoaColaborador] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TViewPessoaColaboradorController.GetObject(id: Integer);
var
  ViewPessoaColaborador: TViewPessoaColaboradorModel;
begin
  try
    ViewPessoaColaborador := TViewPessoaColaboradorService.GetObject(id);

    if Assigned(ViewPessoaColaborador) then
      Render(ViewPessoaColaborador)
    else
      raise EMVCException.Create
        ('Not Found [GetObject ViewPessoaColaborador]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject ViewPessoaColaborador] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TViewPessoaColaboradorController.Insert(Context: TWebContext);
var
  ViewPessoaColaborador: TViewPessoaColaboradorModel;
begin
  try
    ViewPessoaColaborador := Context.Request.BodyAs<TViewPessoaColaboradorModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert ViewPessoaColaborador] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TViewPessoaColaboradorService.Insert(ViewPessoaColaborador);
    Render(TViewPessoaColaboradorService.GetObject(ViewPessoaColaborador.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert ViewPessoaColaborador] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TViewPessoaColaboradorController.Update(Context: TWebContext);
var
  ViewPessoaColaborador, ViewPessoaColaboradorDB: TViewPessoaColaboradorModel;
begin
  try
    ViewPessoaColaborador := Context.Request.BodyAs<TViewPessoaColaboradorModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update ViewPessoaColaborador] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  ViewPessoaColaboradorDB := TViewPessoaColaboradorService.GetObject(ViewPessoaColaborador.id);

  if not Assigned(ViewPessoaColaboradorDB) then
    raise EMVCException.Create('Invalid Object [Update ViewPessoaColaborador]',
      '', 0, 400);

  try
    if TViewPessoaColaboradorService.Update(ViewPessoaColaborador) > 0 then
      Render(TViewPessoaColaboradorService.GetObject(ViewPessoaColaborador.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update ViewPessoaColaborador]',
        '', 0, 500);
  finally
    FreeAndNil(ViewPessoaColaboradorDB);
  end;
end;

procedure TViewPessoaColaboradorController.Delete(id: Integer);
var
  ViewPessoaColaborador: TViewPessoaColaboradorModel;
begin
  ViewPessoaColaborador := TViewPessoaColaboradorService.GetObject(id);

  if not Assigned(ViewPessoaColaborador) then
    raise EMVCException.Create('Invalid Object [Delete ViewPessoaColaborador]',
      '', 0, 400);

  try
    if TViewPessoaColaboradorService.Delete(ViewPessoaColaborador) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete ViewPessoaColaborador]',
        '', 0, 500);
  finally
    FreeAndNil(ViewPessoaColaborador);
  end;
end;

end.
