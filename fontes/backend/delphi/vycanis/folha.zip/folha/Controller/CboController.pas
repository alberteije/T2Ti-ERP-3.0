﻿unit CboController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD Cbo')]
  [MVCPath('/cbo')]
  TCboController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TCboController }

uses CboService, CboModel, Commons, Filter;

procedure TCboController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TCboModel>(TCboService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TCboModel>(TCboService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList Cbo] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TCboController.GetObject(id: Integer);
var
  Cbo: TCboModel;
begin
  try
    Cbo := TCboService.GetObject(id);

    if Assigned(Cbo) then
      Render(Cbo)
    else
      raise EMVCException.Create
        ('Not Found [GetObject Cbo]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject Cbo] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TCboController.Insert(Context: TWebContext);
var
  Cbo: TCboModel;
begin
  try
    Cbo := Context.Request.BodyAs<TCboModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert Cbo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TCboService.Insert(Cbo);
    Render(TCboService.GetObject(Cbo.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert Cbo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TCboController.Update(Context: TWebContext);
var
  Cbo, CboDB: TCboModel;
begin
  try
    Cbo := Context.Request.BodyAs<TCboModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update Cbo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  CboDB := TCboService.GetObject(Cbo.id);

  if not Assigned(CboDB) then
    raise EMVCException.Create('Invalid Object [Update Cbo]',
      '', 0, 400);

  try
    if TCboService.Update(Cbo) > 0 then
      Render(TCboService.GetObject(Cbo.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update Cbo]',
        '', 0, 500);
  finally
    FreeAndNil(CboDB);
  end;
end;

procedure TCboController.Delete(id: Integer);
var
  Cbo: TCboModel;
begin
  Cbo := TCboService.GetObject(id);

  if not Assigned(Cbo) then
    raise EMVCException.Create('Invalid Object [Delete Cbo]',
      '', 0, 400);

  try
    if TCboService.Delete(Cbo) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete Cbo]',
        '', 0, 500);
  finally
    FreeAndNil(Cbo);
  end;
end;

end.
