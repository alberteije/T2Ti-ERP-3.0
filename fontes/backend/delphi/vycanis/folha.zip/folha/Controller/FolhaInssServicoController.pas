﻿unit FolhaInssServicoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaInssServico')]
  [MVCPath('/folha-inss-servico')]
  TFolhaInssServicoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaInssServicoController }

uses FolhaInssServicoService, FolhaInssServicoModel, Commons, Filter;

procedure TFolhaInssServicoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaInssServicoModel>(TFolhaInssServicoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaInssServicoModel>(TFolhaInssServicoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaInssServico] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaInssServicoController.GetObject(id: Integer);
var
  FolhaInssServico: TFolhaInssServicoModel;
begin
  try
    FolhaInssServico := TFolhaInssServicoService.GetObject(id);

    if Assigned(FolhaInssServico) then
      Render(FolhaInssServico)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaInssServico]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaInssServico] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaInssServicoController.Insert(Context: TWebContext);
var
  FolhaInssServico: TFolhaInssServicoModel;
begin
  try
    FolhaInssServico := Context.Request.BodyAs<TFolhaInssServicoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaInssServico] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaInssServicoService.Insert(FolhaInssServico);
    Render(TFolhaInssServicoService.GetObject(FolhaInssServico.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaInssServico] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaInssServicoController.Update(Context: TWebContext);
var
  FolhaInssServico, FolhaInssServicoDB: TFolhaInssServicoModel;
begin
  try
    FolhaInssServico := Context.Request.BodyAs<TFolhaInssServicoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaInssServico] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaInssServicoDB := TFolhaInssServicoService.GetObject(FolhaInssServico.id);

  if not Assigned(FolhaInssServicoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaInssServico]',
      '', 0, 400);

  try
    if TFolhaInssServicoService.Update(FolhaInssServico) > 0 then
      Render(TFolhaInssServicoService.GetObject(FolhaInssServico.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaInssServico]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaInssServicoDB);
  end;
end;

procedure TFolhaInssServicoController.Delete(id: Integer);
var
  FolhaInssServico: TFolhaInssServicoModel;
begin
  FolhaInssServico := TFolhaInssServicoService.GetObject(id);

  if not Assigned(FolhaInssServico) then
    raise EMVCException.Create('Invalid Object [Delete FolhaInssServico]',
      '', 0, 400);

  try
    if TFolhaInssServicoService.Delete(FolhaInssServico) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaInssServico]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaInssServico);
  end;
end;

end.
