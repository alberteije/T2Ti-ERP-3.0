﻿unit ViewPessoaUsuarioController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD ViewPessoaUsuario')]
  [MVCPath('/view-pessoa-usuario')]
  TViewPessoaUsuarioController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TViewPessoaUsuarioController }

uses ViewPessoaUsuarioService, ViewPessoaUsuarioModel, Commons, Filter;

procedure TViewPessoaUsuarioController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TViewPessoaUsuarioModel>(TViewPessoaUsuarioService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TViewPessoaUsuarioModel>(TViewPessoaUsuarioService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList ViewPessoaUsuario] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TViewPessoaUsuarioController.GetObject(id: Integer);
var
  ViewPessoaUsuario: TViewPessoaUsuarioModel;
begin
  try
    ViewPessoaUsuario := TViewPessoaUsuarioService.GetObject(id);

    if Assigned(ViewPessoaUsuario) then
      Render(ViewPessoaUsuario)
    else
      raise EMVCException.Create
        ('Not Found [GetObject ViewPessoaUsuario]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject ViewPessoaUsuario] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TViewPessoaUsuarioController.Insert(Context: TWebContext);
var
  ViewPessoaUsuario: TViewPessoaUsuarioModel;
begin
  try
    ViewPessoaUsuario := Context.Request.BodyAs<TViewPessoaUsuarioModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert ViewPessoaUsuario] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TViewPessoaUsuarioService.Insert(ViewPessoaUsuario);
    Render(TViewPessoaUsuarioService.GetObject(ViewPessoaUsuario.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert ViewPessoaUsuario] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TViewPessoaUsuarioController.Update(Context: TWebContext);
var
  ViewPessoaUsuario, ViewPessoaUsuarioDB: TViewPessoaUsuarioModel;
begin
  try
    ViewPessoaUsuario := Context.Request.BodyAs<TViewPessoaUsuarioModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update ViewPessoaUsuario] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  ViewPessoaUsuarioDB := TViewPessoaUsuarioService.GetObject(ViewPessoaUsuario.id);

  if not Assigned(ViewPessoaUsuarioDB) then
    raise EMVCException.Create('Invalid Object [Update ViewPessoaUsuario]',
      '', 0, 400);

  try
    if TViewPessoaUsuarioService.Update(ViewPessoaUsuario) > 0 then
      Render(TViewPessoaUsuarioService.GetObject(ViewPessoaUsuario.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update ViewPessoaUsuario]',
        '', 0, 500);
  finally
    FreeAndNil(ViewPessoaUsuarioDB);
  end;
end;

procedure TViewPessoaUsuarioController.Delete(id: Integer);
var
  ViewPessoaUsuario: TViewPessoaUsuarioModel;
begin
  ViewPessoaUsuario := TViewPessoaUsuarioService.GetObject(id);

  if not Assigned(ViewPessoaUsuario) then
    raise EMVCException.Create('Invalid Object [Delete ViewPessoaUsuario]',
      '', 0, 400);

  try
    if TViewPessoaUsuarioService.Delete(ViewPessoaUsuario) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete ViewPessoaUsuario]',
        '', 0, 500);
  finally
    FreeAndNil(ViewPessoaUsuario);
  end;
end;

end.
