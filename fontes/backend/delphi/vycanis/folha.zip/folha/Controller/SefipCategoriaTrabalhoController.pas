﻿unit SefipCategoriaTrabalhoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD SefipCategoriaTrabalho')]
  [MVCPath('/sefip-categoria-trabalho')]
  TSefipCategoriaTrabalhoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TSefipCategoriaTrabalhoController }

uses SefipCategoriaTrabalhoService, SefipCategoriaTrabalhoModel, Commons, Filter;

procedure TSefipCategoriaTrabalhoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TSefipCategoriaTrabalhoModel>(TSefipCategoriaTrabalhoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TSefipCategoriaTrabalhoModel>(TSefipCategoriaTrabalhoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList SefipCategoriaTrabalho] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSefipCategoriaTrabalhoController.GetObject(id: Integer);
var
  SefipCategoriaTrabalho: TSefipCategoriaTrabalhoModel;
begin
  try
    SefipCategoriaTrabalho := TSefipCategoriaTrabalhoService.GetObject(id);

    if Assigned(SefipCategoriaTrabalho) then
      Render(SefipCategoriaTrabalho)
    else
      raise EMVCException.Create
        ('Not Found [GetObject SefipCategoriaTrabalho]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject SefipCategoriaTrabalho] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSefipCategoriaTrabalhoController.Insert(Context: TWebContext);
var
  SefipCategoriaTrabalho: TSefipCategoriaTrabalhoModel;
begin
  try
    SefipCategoriaTrabalho := Context.Request.BodyAs<TSefipCategoriaTrabalhoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert SefipCategoriaTrabalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TSefipCategoriaTrabalhoService.Insert(SefipCategoriaTrabalho);
    Render(TSefipCategoriaTrabalhoService.GetObject(SefipCategoriaTrabalho.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert SefipCategoriaTrabalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TSefipCategoriaTrabalhoController.Update(Context: TWebContext);
var
  SefipCategoriaTrabalho, SefipCategoriaTrabalhoDB: TSefipCategoriaTrabalhoModel;
begin
  try
    SefipCategoriaTrabalho := Context.Request.BodyAs<TSefipCategoriaTrabalhoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update SefipCategoriaTrabalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  SefipCategoriaTrabalhoDB := TSefipCategoriaTrabalhoService.GetObject(SefipCategoriaTrabalho.id);

  if not Assigned(SefipCategoriaTrabalhoDB) then
    raise EMVCException.Create('Invalid Object [Update SefipCategoriaTrabalho]',
      '', 0, 400);

  try
    if TSefipCategoriaTrabalhoService.Update(SefipCategoriaTrabalho) > 0 then
      Render(TSefipCategoriaTrabalhoService.GetObject(SefipCategoriaTrabalho.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update SefipCategoriaTrabalho]',
        '', 0, 500);
  finally
    FreeAndNil(SefipCategoriaTrabalhoDB);
  end;
end;

procedure TSefipCategoriaTrabalhoController.Delete(id: Integer);
var
  SefipCategoriaTrabalho: TSefipCategoriaTrabalhoModel;
begin
  SefipCategoriaTrabalho := TSefipCategoriaTrabalhoService.GetObject(id);

  if not Assigned(SefipCategoriaTrabalho) then
    raise EMVCException.Create('Invalid Object [Delete SefipCategoriaTrabalho]',
      '', 0, 400);

  try
    if TSefipCategoriaTrabalhoService.Delete(SefipCategoriaTrabalho) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete SefipCategoriaTrabalho]',
        '', 0, 500);
  finally
    FreeAndNil(SefipCategoriaTrabalho);
  end;
end;

end.
