﻿unit FolhaAfastamentoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaAfastamento')]
  [MVCPath('/folha-afastamento')]
  TFolhaAfastamentoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaAfastamentoController }

uses FolhaAfastamentoService, FolhaAfastamentoModel, Commons, Filter;

procedure TFolhaAfastamentoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaAfastamentoModel>(TFolhaAfastamentoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaAfastamentoModel>(TFolhaAfastamentoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaAfastamento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaAfastamentoController.GetObject(id: Integer);
var
  FolhaAfastamento: TFolhaAfastamentoModel;
begin
  try
    FolhaAfastamento := TFolhaAfastamentoService.GetObject(id);

    if Assigned(FolhaAfastamento) then
      Render(FolhaAfastamento)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaAfastamento]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaAfastamento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaAfastamentoController.Insert(Context: TWebContext);
var
  FolhaAfastamento: TFolhaAfastamentoModel;
begin
  try
    FolhaAfastamento := Context.Request.BodyAs<TFolhaAfastamentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaAfastamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaAfastamentoService.Insert(FolhaAfastamento);
    Render(TFolhaAfastamentoService.GetObject(FolhaAfastamento.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaAfastamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaAfastamentoController.Update(Context: TWebContext);
var
  FolhaAfastamento, FolhaAfastamentoDB: TFolhaAfastamentoModel;
begin
  try
    FolhaAfastamento := Context.Request.BodyAs<TFolhaAfastamentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaAfastamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaAfastamentoDB := TFolhaAfastamentoService.GetObject(FolhaAfastamento.id);

  if not Assigned(FolhaAfastamentoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaAfastamento]',
      '', 0, 400);

  try
    if TFolhaAfastamentoService.Update(FolhaAfastamento) > 0 then
      Render(TFolhaAfastamentoService.GetObject(FolhaAfastamento.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaAfastamento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaAfastamentoDB);
  end;
end;

procedure TFolhaAfastamentoController.Delete(id: Integer);
var
  FolhaAfastamento: TFolhaAfastamentoModel;
begin
  FolhaAfastamento := TFolhaAfastamentoService.GetObject(id);

  if not Assigned(FolhaAfastamento) then
    raise EMVCException.Create('Invalid Object [Delete FolhaAfastamento]',
      '', 0, 400);

  try
    if TFolhaAfastamentoService.Delete(FolhaAfastamento) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaAfastamento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaAfastamento);
  end;
end;

end.
