﻿unit FeriasPeriodoAquisitivoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FeriasPeriodoAquisitivo')]
  [MVCPath('/ferias-periodo-aquisitivo')]
  TFeriasPeriodoAquisitivoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFeriasPeriodoAquisitivoController }

uses FeriasPeriodoAquisitivoService, FeriasPeriodoAquisitivoModel, Commons, Filter;

procedure TFeriasPeriodoAquisitivoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFeriasPeriodoAquisitivoModel>(TFeriasPeriodoAquisitivoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFeriasPeriodoAquisitivoModel>(TFeriasPeriodoAquisitivoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FeriasPeriodoAquisitivo] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFeriasPeriodoAquisitivoController.GetObject(id: Integer);
var
  FeriasPeriodoAquisitivo: TFeriasPeriodoAquisitivoModel;
begin
  try
    FeriasPeriodoAquisitivo := TFeriasPeriodoAquisitivoService.GetObject(id);

    if Assigned(FeriasPeriodoAquisitivo) then
      Render(FeriasPeriodoAquisitivo)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FeriasPeriodoAquisitivo]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FeriasPeriodoAquisitivo] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFeriasPeriodoAquisitivoController.Insert(Context: TWebContext);
var
  FeriasPeriodoAquisitivo: TFeriasPeriodoAquisitivoModel;
begin
  try
    FeriasPeriodoAquisitivo := Context.Request.BodyAs<TFeriasPeriodoAquisitivoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FeriasPeriodoAquisitivo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFeriasPeriodoAquisitivoService.Insert(FeriasPeriodoAquisitivo);
    Render(TFeriasPeriodoAquisitivoService.GetObject(FeriasPeriodoAquisitivo.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FeriasPeriodoAquisitivo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFeriasPeriodoAquisitivoController.Update(Context: TWebContext);
var
  FeriasPeriodoAquisitivo, FeriasPeriodoAquisitivoDB: TFeriasPeriodoAquisitivoModel;
begin
  try
    FeriasPeriodoAquisitivo := Context.Request.BodyAs<TFeriasPeriodoAquisitivoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FeriasPeriodoAquisitivo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FeriasPeriodoAquisitivoDB := TFeriasPeriodoAquisitivoService.GetObject(FeriasPeriodoAquisitivo.id);

  if not Assigned(FeriasPeriodoAquisitivoDB) then
    raise EMVCException.Create('Invalid Object [Update FeriasPeriodoAquisitivo]',
      '', 0, 400);

  try
    if TFeriasPeriodoAquisitivoService.Update(FeriasPeriodoAquisitivo) > 0 then
      Render(TFeriasPeriodoAquisitivoService.GetObject(FeriasPeriodoAquisitivo.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FeriasPeriodoAquisitivo]',
        '', 0, 500);
  finally
    FreeAndNil(FeriasPeriodoAquisitivoDB);
  end;
end;

procedure TFeriasPeriodoAquisitivoController.Delete(id: Integer);
var
  FeriasPeriodoAquisitivo: TFeriasPeriodoAquisitivoModel;
begin
  FeriasPeriodoAquisitivo := TFeriasPeriodoAquisitivoService.GetObject(id);

  if not Assigned(FeriasPeriodoAquisitivo) then
    raise EMVCException.Create('Invalid Object [Delete FeriasPeriodoAquisitivo]',
      '', 0, 400);

  try
    if TFeriasPeriodoAquisitivoService.Delete(FeriasPeriodoAquisitivo) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FeriasPeriodoAquisitivo]',
        '', 0, 500);
  finally
    FreeAndNil(FeriasPeriodoAquisitivo);
  end;
end;

end.
