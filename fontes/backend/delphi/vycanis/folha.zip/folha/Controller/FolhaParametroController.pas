﻿unit FolhaParametroController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaParametro')]
  [MVCPath('/folha-parametro')]
  TFolhaParametroController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaParametroController }

uses FolhaParametroService, FolhaParametroModel, Commons, Filter;

procedure TFolhaParametroController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaParametroModel>(TFolhaParametroService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaParametroModel>(TFolhaParametroService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaParametro] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaParametroController.GetObject(id: Integer);
var
  FolhaParametro: TFolhaParametroModel;
begin
  try
    FolhaParametro := TFolhaParametroService.GetObject(id);

    if Assigned(FolhaParametro) then
      Render(FolhaParametro)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaParametro]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaParametro] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaParametroController.Insert(Context: TWebContext);
var
  FolhaParametro: TFolhaParametroModel;
begin
  try
    FolhaParametro := Context.Request.BodyAs<TFolhaParametroModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaParametro] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaParametroService.Insert(FolhaParametro);
    Render(TFolhaParametroService.GetObject(FolhaParametro.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaParametro] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaParametroController.Update(Context: TWebContext);
var
  FolhaParametro, FolhaParametroDB: TFolhaParametroModel;
begin
  try
    FolhaParametro := Context.Request.BodyAs<TFolhaParametroModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaParametro] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaParametroDB := TFolhaParametroService.GetObject(FolhaParametro.id);

  if not Assigned(FolhaParametroDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaParametro]',
      '', 0, 400);

  try
    if TFolhaParametroService.Update(FolhaParametro) > 0 then
      Render(TFolhaParametroService.GetObject(FolhaParametro.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaParametro]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaParametroDB);
  end;
end;

procedure TFolhaParametroController.Delete(id: Integer);
var
  FolhaParametro: TFolhaParametroModel;
begin
  FolhaParametro := TFolhaParametroService.GetObject(id);

  if not Assigned(FolhaParametro) then
    raise EMVCException.Create('Invalid Object [Delete FolhaParametro]',
      '', 0, 400);

  try
    if TFolhaParametroService.Delete(FolhaParametro) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaParametro]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaParametro);
  end;
end;

end.
