﻿unit FeriadosController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD Feriados')]
  [MVCPath('/feriados')]
  TFeriadosController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFeriadosController }

uses FeriadosService, FeriadosModel, Commons, Filter;

procedure TFeriadosController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFeriadosModel>(TFeriadosService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFeriadosModel>(TFeriadosService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList Feriados] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFeriadosController.GetObject(id: Integer);
var
  Feriados: TFeriadosModel;
begin
  try
    Feriados := TFeriadosService.GetObject(id);

    if Assigned(Feriados) then
      Render(Feriados)
    else
      raise EMVCException.Create
        ('Not Found [GetObject Feriados]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject Feriados] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFeriadosController.Insert(Context: TWebContext);
var
  Feriados: TFeriadosModel;
begin
  try
    Feriados := Context.Request.BodyAs<TFeriadosModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert Feriados] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFeriadosService.Insert(Feriados);
    Render(TFeriadosService.GetObject(Feriados.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert Feriados] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFeriadosController.Update(Context: TWebContext);
var
  Feriados, FeriadosDB: TFeriadosModel;
begin
  try
    Feriados := Context.Request.BodyAs<TFeriadosModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update Feriados] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FeriadosDB := TFeriadosService.GetObject(Feriados.id);

  if not Assigned(FeriadosDB) then
    raise EMVCException.Create('Invalid Object [Update Feriados]',
      '', 0, 400);

  try
    if TFeriadosService.Update(Feriados) > 0 then
      Render(TFeriadosService.GetObject(Feriados.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update Feriados]',
        '', 0, 500);
  finally
    FreeAndNil(FeriadosDB);
  end;
end;

procedure TFeriadosController.Delete(id: Integer);
var
  Feriados: TFeriadosModel;
begin
  Feriados := TFeriadosService.GetObject(id);

  if not Assigned(Feriados) then
    raise EMVCException.Create('Invalid Object [Delete Feriados]',
      '', 0, 400);

  try
    if TFeriadosService.Delete(Feriados) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete Feriados]',
        '', 0, 500);
  finally
    FreeAndNil(Feriados);
  end;
end;

end.
