﻿unit FolhaValeTransporteController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaValeTransporte')]
  [MVCPath('/folha-vale-transporte')]
  TFolhaValeTransporteController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaValeTransporteController }

uses FolhaValeTransporteService, FolhaValeTransporteModel, Commons, Filter;

procedure TFolhaValeTransporteController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaValeTransporteModel>(TFolhaValeTransporteService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaValeTransporteModel>(TFolhaValeTransporteService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaValeTransporte] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaValeTransporteController.GetObject(id: Integer);
var
  FolhaValeTransporte: TFolhaValeTransporteModel;
begin
  try
    FolhaValeTransporte := TFolhaValeTransporteService.GetObject(id);

    if Assigned(FolhaValeTransporte) then
      Render(FolhaValeTransporte)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaValeTransporte]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaValeTransporte] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaValeTransporteController.Insert(Context: TWebContext);
var
  FolhaValeTransporte: TFolhaValeTransporteModel;
begin
  try
    FolhaValeTransporte := Context.Request.BodyAs<TFolhaValeTransporteModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaValeTransporte] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaValeTransporteService.Insert(FolhaValeTransporte);
    Render(TFolhaValeTransporteService.GetObject(FolhaValeTransporte.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaValeTransporte] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaValeTransporteController.Update(Context: TWebContext);
var
  FolhaValeTransporte, FolhaValeTransporteDB: TFolhaValeTransporteModel;
begin
  try
    FolhaValeTransporte := Context.Request.BodyAs<TFolhaValeTransporteModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaValeTransporte] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaValeTransporteDB := TFolhaValeTransporteService.GetObject(FolhaValeTransporte.id);

  if not Assigned(FolhaValeTransporteDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaValeTransporte]',
      '', 0, 400);

  try
    if TFolhaValeTransporteService.Update(FolhaValeTransporte) > 0 then
      Render(TFolhaValeTransporteService.GetObject(FolhaValeTransporte.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaValeTransporte]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaValeTransporteDB);
  end;
end;

procedure TFolhaValeTransporteController.Delete(id: Integer);
var
  FolhaValeTransporte: TFolhaValeTransporteModel;
begin
  FolhaValeTransporte := TFolhaValeTransporteService.GetObject(id);

  if not Assigned(FolhaValeTransporte) then
    raise EMVCException.Create('Invalid Object [Delete FolhaValeTransporte]',
      '', 0, 400);

  try
    if TFolhaValeTransporteService.Delete(FolhaValeTransporte) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaValeTransporte]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaValeTransporte);
  end;
end;

end.
