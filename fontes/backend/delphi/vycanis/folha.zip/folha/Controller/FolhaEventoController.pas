﻿unit FolhaEventoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaEvento')]
  [MVCPath('/folha-evento')]
  TFolhaEventoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaEventoController }

uses FolhaEventoService, FolhaEventoModel, Commons, Filter;

procedure TFolhaEventoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaEventoModel>(TFolhaEventoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaEventoModel>(TFolhaEventoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaEvento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaEventoController.GetObject(id: Integer);
var
  FolhaEvento: TFolhaEventoModel;
begin
  try
    FolhaEvento := TFolhaEventoService.GetObject(id);

    if Assigned(FolhaEvento) then
      Render(FolhaEvento)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaEvento]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaEvento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaEventoController.Insert(Context: TWebContext);
var
  FolhaEvento: TFolhaEventoModel;
begin
  try
    FolhaEvento := Context.Request.BodyAs<TFolhaEventoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaEvento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaEventoService.Insert(FolhaEvento);
    Render(TFolhaEventoService.GetObject(FolhaEvento.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaEvento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaEventoController.Update(Context: TWebContext);
var
  FolhaEvento, FolhaEventoDB: TFolhaEventoModel;
begin
  try
    FolhaEvento := Context.Request.BodyAs<TFolhaEventoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaEvento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaEventoDB := TFolhaEventoService.GetObject(FolhaEvento.id);

  if not Assigned(FolhaEventoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaEvento]',
      '', 0, 400);

  try
    if TFolhaEventoService.Update(FolhaEvento) > 0 then
      Render(TFolhaEventoService.GetObject(FolhaEvento.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaEvento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaEventoDB);
  end;
end;

procedure TFolhaEventoController.Delete(id: Integer);
var
  FolhaEvento: TFolhaEventoModel;
begin
  FolhaEvento := TFolhaEventoService.GetObject(id);

  if not Assigned(FolhaEvento) then
    raise EMVCException.Create('Invalid Object [Delete FolhaEvento]',
      '', 0, 400);

  try
    if TFolhaEventoService.Delete(FolhaEvento) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaEvento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaEvento);
  end;
end;

end.
