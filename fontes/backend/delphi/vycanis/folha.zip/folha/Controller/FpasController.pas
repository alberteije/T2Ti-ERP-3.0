﻿unit FpasController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD Fpas')]
  [MVCPath('/fpas')]
  TFpasController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFpasController }

uses FpasService, FpasModel, Commons, Filter;

procedure TFpasController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFpasModel>(TFpasService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFpasModel>(TFpasService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList Fpas] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFpasController.GetObject(id: Integer);
var
  Fpas: TFpasModel;
begin
  try
    Fpas := TFpasService.GetObject(id);

    if Assigned(Fpas) then
      Render(Fpas)
    else
      raise EMVCException.Create
        ('Not Found [GetObject Fpas]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject Fpas] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFpasController.Insert(Context: TWebContext);
var
  Fpas: TFpasModel;
begin
  try
    Fpas := Context.Request.BodyAs<TFpasModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert Fpas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFpasService.Insert(Fpas);
    Render(TFpasService.GetObject(Fpas.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert Fpas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFpasController.Update(Context: TWebContext);
var
  Fpas, FpasDB: TFpasModel;
begin
  try
    Fpas := Context.Request.BodyAs<TFpasModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update Fpas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FpasDB := TFpasService.GetObject(Fpas.id);

  if not Assigned(FpasDB) then
    raise EMVCException.Create('Invalid Object [Update Fpas]',
      '', 0, 400);

  try
    if TFpasService.Update(Fpas) > 0 then
      Render(TFpasService.GetObject(Fpas.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update Fpas]',
        '', 0, 500);
  finally
    FreeAndNil(FpasDB);
  end;
end;

procedure TFpasController.Delete(id: Integer);
var
  Fpas: TFpasModel;
begin
  Fpas := TFpasService.GetObject(id);

  if not Assigned(Fpas) then
    raise EMVCException.Create('Invalid Object [Delete Fpas]',
      '', 0, 400);

  try
    if TFpasService.Delete(Fpas) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete Fpas]',
        '', 0, 500);
  finally
    FreeAndNil(Fpas);
  end;
end;

end.
