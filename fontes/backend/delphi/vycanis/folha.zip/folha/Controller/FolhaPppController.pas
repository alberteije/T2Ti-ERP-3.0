﻿unit FolhaPppController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaPpp')]
  [MVCPath('/folha-ppp')]
  TFolhaPppController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaPppController }

uses FolhaPppService, FolhaPppModel, Commons, Filter;

procedure TFolhaPppController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaPppModel>(TFolhaPppService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaPppModel>(TFolhaPppService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaPpp] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaPppController.GetObject(id: Integer);
var
  FolhaPpp: TFolhaPppModel;
begin
  try
    FolhaPpp := TFolhaPppService.GetObject(id);

    if Assigned(FolhaPpp) then
      Render(FolhaPpp)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaPpp]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaPpp] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaPppController.Insert(Context: TWebContext);
var
  FolhaPpp: TFolhaPppModel;
begin
  try
    FolhaPpp := Context.Request.BodyAs<TFolhaPppModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaPpp] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaPppService.Insert(FolhaPpp);
    Render(TFolhaPppService.GetObject(FolhaPpp.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaPpp] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaPppController.Update(Context: TWebContext);
var
  FolhaPpp, FolhaPppDB: TFolhaPppModel;
begin
  try
    FolhaPpp := Context.Request.BodyAs<TFolhaPppModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaPpp] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaPppDB := TFolhaPppService.GetObject(FolhaPpp.id);

  if not Assigned(FolhaPppDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaPpp]',
      '', 0, 400);

  try
    if TFolhaPppService.Update(FolhaPpp) > 0 then
      Render(TFolhaPppService.GetObject(FolhaPpp.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaPpp]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaPppDB);
  end;
end;

procedure TFolhaPppController.Delete(id: Integer);
var
  FolhaPpp: TFolhaPppModel;
begin
  FolhaPpp := TFolhaPppService.GetObject(id);

  if not Assigned(FolhaPpp) then
    raise EMVCException.Create('Invalid Object [Delete FolhaPpp]',
      '', 0, 400);

  try
    if TFolhaPppService.Delete(FolhaPpp) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaPpp]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaPpp);
  end;
end;

end.
