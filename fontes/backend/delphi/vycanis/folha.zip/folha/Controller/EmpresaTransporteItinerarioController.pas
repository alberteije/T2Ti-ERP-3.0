﻿unit EmpresaTransporteItinerarioController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD EmpresaTransporteItinerario')]
  [MVCPath('/empresa-transporte-itinerario')]
  TEmpresaTransporteItinerarioController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TEmpresaTransporteItinerarioController }

uses EmpresaTransporteItinerarioService, EmpresaTransporteItinerarioModel, Commons, Filter;

procedure TEmpresaTransporteItinerarioController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TEmpresaTransporteItinerarioModel>(TEmpresaTransporteItinerarioService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TEmpresaTransporteItinerarioModel>(TEmpresaTransporteItinerarioService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList EmpresaTransporteItinerario] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TEmpresaTransporteItinerarioController.GetObject(id: Integer);
var
  EmpresaTransporteItinerario: TEmpresaTransporteItinerarioModel;
begin
  try
    EmpresaTransporteItinerario := TEmpresaTransporteItinerarioService.GetObject(id);

    if Assigned(EmpresaTransporteItinerario) then
      Render(EmpresaTransporteItinerario)
    else
      raise EMVCException.Create
        ('Not Found [GetObject EmpresaTransporteItinerario]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject EmpresaTransporteItinerario] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TEmpresaTransporteItinerarioController.Insert(Context: TWebContext);
var
  EmpresaTransporteItinerario: TEmpresaTransporteItinerarioModel;
begin
  try
    EmpresaTransporteItinerario := Context.Request.BodyAs<TEmpresaTransporteItinerarioModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert EmpresaTransporteItinerario] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TEmpresaTransporteItinerarioService.Insert(EmpresaTransporteItinerario);
    Render(TEmpresaTransporteItinerarioService.GetObject(EmpresaTransporteItinerario.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert EmpresaTransporteItinerario] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TEmpresaTransporteItinerarioController.Update(Context: TWebContext);
var
  EmpresaTransporteItinerario, EmpresaTransporteItinerarioDB: TEmpresaTransporteItinerarioModel;
begin
  try
    EmpresaTransporteItinerario := Context.Request.BodyAs<TEmpresaTransporteItinerarioModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update EmpresaTransporteItinerario] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  EmpresaTransporteItinerarioDB := TEmpresaTransporteItinerarioService.GetObject(EmpresaTransporteItinerario.id);

  if not Assigned(EmpresaTransporteItinerarioDB) then
    raise EMVCException.Create('Invalid Object [Update EmpresaTransporteItinerario]',
      '', 0, 400);

  try
    if TEmpresaTransporteItinerarioService.Update(EmpresaTransporteItinerario) > 0 then
      Render(TEmpresaTransporteItinerarioService.GetObject(EmpresaTransporteItinerario.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update EmpresaTransporteItinerario]',
        '', 0, 500);
  finally
    FreeAndNil(EmpresaTransporteItinerarioDB);
  end;
end;

procedure TEmpresaTransporteItinerarioController.Delete(id: Integer);
var
  EmpresaTransporteItinerario: TEmpresaTransporteItinerarioModel;
begin
  EmpresaTransporteItinerario := TEmpresaTransporteItinerarioService.GetObject(id);

  if not Assigned(EmpresaTransporteItinerario) then
    raise EMVCException.Create('Invalid Object [Delete EmpresaTransporteItinerario]',
      '', 0, 400);

  try
    if TEmpresaTransporteItinerarioService.Delete(EmpresaTransporteItinerario) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete EmpresaTransporteItinerario]',
        '', 0, 500);
  finally
    FreeAndNil(EmpresaTransporteItinerario);
  end;
end;

end.
