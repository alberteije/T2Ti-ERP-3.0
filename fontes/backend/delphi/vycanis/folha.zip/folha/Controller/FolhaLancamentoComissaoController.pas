﻿unit FolhaLancamentoComissaoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaLancamentoComissao')]
  [MVCPath('/folha-lancamento-comissao')]
  TFolhaLancamentoComissaoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaLancamentoComissaoController }

uses FolhaLancamentoComissaoService, FolhaLancamentoComissaoModel, Commons, Filter;

procedure TFolhaLancamentoComissaoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaLancamentoComissaoModel>(TFolhaLancamentoComissaoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaLancamentoComissaoModel>(TFolhaLancamentoComissaoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaLancamentoComissao] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaLancamentoComissaoController.GetObject(id: Integer);
var
  FolhaLancamentoComissao: TFolhaLancamentoComissaoModel;
begin
  try
    FolhaLancamentoComissao := TFolhaLancamentoComissaoService.GetObject(id);

    if Assigned(FolhaLancamentoComissao) then
      Render(FolhaLancamentoComissao)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaLancamentoComissao]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaLancamentoComissao] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaLancamentoComissaoController.Insert(Context: TWebContext);
var
  FolhaLancamentoComissao: TFolhaLancamentoComissaoModel;
begin
  try
    FolhaLancamentoComissao := Context.Request.BodyAs<TFolhaLancamentoComissaoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaLancamentoComissao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaLancamentoComissaoService.Insert(FolhaLancamentoComissao);
    Render(TFolhaLancamentoComissaoService.GetObject(FolhaLancamentoComissao.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaLancamentoComissao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaLancamentoComissaoController.Update(Context: TWebContext);
var
  FolhaLancamentoComissao, FolhaLancamentoComissaoDB: TFolhaLancamentoComissaoModel;
begin
  try
    FolhaLancamentoComissao := Context.Request.BodyAs<TFolhaLancamentoComissaoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaLancamentoComissao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaLancamentoComissaoDB := TFolhaLancamentoComissaoService.GetObject(FolhaLancamentoComissao.id);

  if not Assigned(FolhaLancamentoComissaoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaLancamentoComissao]',
      '', 0, 400);

  try
    if TFolhaLancamentoComissaoService.Update(FolhaLancamentoComissao) > 0 then
      Render(TFolhaLancamentoComissaoService.GetObject(FolhaLancamentoComissao.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaLancamentoComissao]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaLancamentoComissaoDB);
  end;
end;

procedure TFolhaLancamentoComissaoController.Delete(id: Integer);
var
  FolhaLancamentoComissao: TFolhaLancamentoComissaoModel;
begin
  FolhaLancamentoComissao := TFolhaLancamentoComissaoService.GetObject(id);

  if not Assigned(FolhaLancamentoComissao) then
    raise EMVCException.Create('Invalid Object [Delete FolhaLancamentoComissao]',
      '', 0, 400);

  try
    if TFolhaLancamentoComissaoService.Delete(FolhaLancamentoComissao) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaLancamentoComissao]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaLancamentoComissao);
  end;
end;

end.
