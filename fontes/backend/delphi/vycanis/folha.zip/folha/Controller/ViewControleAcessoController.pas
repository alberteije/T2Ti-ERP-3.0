﻿unit ViewControleAcessoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD ViewControleAcesso')]
  [MVCPath('/view-controle-acesso')]
  TViewControleAcessoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TViewControleAcessoController }

uses ViewControleAcessoService, ViewControleAcessoModel, Commons, Filter;

procedure TViewControleAcessoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TViewControleAcessoModel>(TViewControleAcessoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TViewControleAcessoModel>(TViewControleAcessoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList ViewControleAcesso] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TViewControleAcessoController.GetObject(id: Integer);
var
  ViewControleAcesso: TViewControleAcessoModel;
begin
  try
    ViewControleAcesso := TViewControleAcessoService.GetObject(id);

    if Assigned(ViewControleAcesso) then
      Render(ViewControleAcesso)
    else
      raise EMVCException.Create
        ('Not Found [GetObject ViewControleAcesso]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject ViewControleAcesso] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TViewControleAcessoController.Insert(Context: TWebContext);
var
  ViewControleAcesso: TViewControleAcessoModel;
begin
  try
    ViewControleAcesso := Context.Request.BodyAs<TViewControleAcessoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert ViewControleAcesso] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TViewControleAcessoService.Insert(ViewControleAcesso);
    Render(TViewControleAcessoService.GetObject(ViewControleAcesso.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert ViewControleAcesso] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TViewControleAcessoController.Update(Context: TWebContext);
var
  ViewControleAcesso, ViewControleAcessoDB: TViewControleAcessoModel;
begin
  try
    ViewControleAcesso := Context.Request.BodyAs<TViewControleAcessoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update ViewControleAcesso] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  ViewControleAcessoDB := TViewControleAcessoService.GetObject(ViewControleAcesso.id);

  if not Assigned(ViewControleAcessoDB) then
    raise EMVCException.Create('Invalid Object [Update ViewControleAcesso]',
      '', 0, 400);

  try
    if TViewControleAcessoService.Update(ViewControleAcesso) > 0 then
      Render(TViewControleAcessoService.GetObject(ViewControleAcesso.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update ViewControleAcesso]',
        '', 0, 500);
  finally
    FreeAndNil(ViewControleAcessoDB);
  end;
end;

procedure TViewControleAcessoController.Delete(id: Integer);
var
  ViewControleAcesso: TViewControleAcessoModel;
begin
  ViewControleAcesso := TViewControleAcessoService.GetObject(id);

  if not Assigned(ViewControleAcesso) then
    raise EMVCException.Create('Invalid Object [Delete ViewControleAcesso]',
      '', 0, 400);

  try
    if TViewControleAcessoService.Delete(ViewControleAcesso) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete ViewControleAcesso]',
        '', 0, 500);
  finally
    FreeAndNil(ViewControleAcesso);
  end;
end;

end.
