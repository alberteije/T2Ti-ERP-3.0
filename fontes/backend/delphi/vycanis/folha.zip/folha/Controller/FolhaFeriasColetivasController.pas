﻿unit FolhaFeriasColetivasController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaFeriasColetivas')]
  [MVCPath('/folha-ferias-coletivas')]
  TFolhaFeriasColetivasController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaFeriasColetivasController }

uses FolhaFeriasColetivasService, FolhaFeriasColetivasModel, Commons, Filter;

procedure TFolhaFeriasColetivasController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaFeriasColetivasModel>(TFolhaFeriasColetivasService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaFeriasColetivasModel>(TFolhaFeriasColetivasService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaFeriasColetivas] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaFeriasColetivasController.GetObject(id: Integer);
var
  FolhaFeriasColetivas: TFolhaFeriasColetivasModel;
begin
  try
    FolhaFeriasColetivas := TFolhaFeriasColetivasService.GetObject(id);

    if Assigned(FolhaFeriasColetivas) then
      Render(FolhaFeriasColetivas)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaFeriasColetivas]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaFeriasColetivas] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaFeriasColetivasController.Insert(Context: TWebContext);
var
  FolhaFeriasColetivas: TFolhaFeriasColetivasModel;
begin
  try
    FolhaFeriasColetivas := Context.Request.BodyAs<TFolhaFeriasColetivasModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaFeriasColetivas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaFeriasColetivasService.Insert(FolhaFeriasColetivas);
    Render(TFolhaFeriasColetivasService.GetObject(FolhaFeriasColetivas.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaFeriasColetivas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaFeriasColetivasController.Update(Context: TWebContext);
var
  FolhaFeriasColetivas, FolhaFeriasColetivasDB: TFolhaFeriasColetivasModel;
begin
  try
    FolhaFeriasColetivas := Context.Request.BodyAs<TFolhaFeriasColetivasModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaFeriasColetivas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaFeriasColetivasDB := TFolhaFeriasColetivasService.GetObject(FolhaFeriasColetivas.id);

  if not Assigned(FolhaFeriasColetivasDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaFeriasColetivas]',
      '', 0, 400);

  try
    if TFolhaFeriasColetivasService.Update(FolhaFeriasColetivas) > 0 then
      Render(TFolhaFeriasColetivasService.GetObject(FolhaFeriasColetivas.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaFeriasColetivas]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaFeriasColetivasDB);
  end;
end;

procedure TFolhaFeriasColetivasController.Delete(id: Integer);
var
  FolhaFeriasColetivas: TFolhaFeriasColetivasModel;
begin
  FolhaFeriasColetivas := TFolhaFeriasColetivasService.GetObject(id);

  if not Assigned(FolhaFeriasColetivas) then
    raise EMVCException.Create('Invalid Object [Delete FolhaFeriasColetivas]',
      '', 0, 400);

  try
    if TFolhaFeriasColetivasService.Delete(FolhaFeriasColetivas) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaFeriasColetivas]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaFeriasColetivas);
  end;
end;

end.
