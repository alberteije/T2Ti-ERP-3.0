﻿unit FolhaHistoricoSalarialController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaHistoricoSalarial')]
  [MVCPath('/folha-historico-salarial')]
  TFolhaHistoricoSalarialController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaHistoricoSalarialController }

uses FolhaHistoricoSalarialService, FolhaHistoricoSalarialModel, Commons, Filter;

procedure TFolhaHistoricoSalarialController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaHistoricoSalarialModel>(TFolhaHistoricoSalarialService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaHistoricoSalarialModel>(TFolhaHistoricoSalarialService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaHistoricoSalarial] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaHistoricoSalarialController.GetObject(id: Integer);
var
  FolhaHistoricoSalarial: TFolhaHistoricoSalarialModel;
begin
  try
    FolhaHistoricoSalarial := TFolhaHistoricoSalarialService.GetObject(id);

    if Assigned(FolhaHistoricoSalarial) then
      Render(FolhaHistoricoSalarial)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaHistoricoSalarial]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaHistoricoSalarial] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaHistoricoSalarialController.Insert(Context: TWebContext);
var
  FolhaHistoricoSalarial: TFolhaHistoricoSalarialModel;
begin
  try
    FolhaHistoricoSalarial := Context.Request.BodyAs<TFolhaHistoricoSalarialModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaHistoricoSalarial] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaHistoricoSalarialService.Insert(FolhaHistoricoSalarial);
    Render(TFolhaHistoricoSalarialService.GetObject(FolhaHistoricoSalarial.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaHistoricoSalarial] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaHistoricoSalarialController.Update(Context: TWebContext);
var
  FolhaHistoricoSalarial, FolhaHistoricoSalarialDB: TFolhaHistoricoSalarialModel;
begin
  try
    FolhaHistoricoSalarial := Context.Request.BodyAs<TFolhaHistoricoSalarialModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaHistoricoSalarial] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaHistoricoSalarialDB := TFolhaHistoricoSalarialService.GetObject(FolhaHistoricoSalarial.id);

  if not Assigned(FolhaHistoricoSalarialDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaHistoricoSalarial]',
      '', 0, 400);

  try
    if TFolhaHistoricoSalarialService.Update(FolhaHistoricoSalarial) > 0 then
      Render(TFolhaHistoricoSalarialService.GetObject(FolhaHistoricoSalarial.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaHistoricoSalarial]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaHistoricoSalarialDB);
  end;
end;

procedure TFolhaHistoricoSalarialController.Delete(id: Integer);
var
  FolhaHistoricoSalarial: TFolhaHistoricoSalarialModel;
begin
  FolhaHistoricoSalarial := TFolhaHistoricoSalarialService.GetObject(id);

  if not Assigned(FolhaHistoricoSalarial) then
    raise EMVCException.Create('Invalid Object [Delete FolhaHistoricoSalarial]',
      '', 0, 400);

  try
    if TFolhaHistoricoSalarialService.Delete(FolhaHistoricoSalarial) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaHistoricoSalarial]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaHistoricoSalarial);
  end;
end;

end.
