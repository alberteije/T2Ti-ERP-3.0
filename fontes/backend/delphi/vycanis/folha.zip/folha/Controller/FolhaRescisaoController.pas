﻿unit FolhaRescisaoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaRescisao')]
  [MVCPath('/folha-rescisao')]
  TFolhaRescisaoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaRescisaoController }

uses FolhaRescisaoService, FolhaRescisaoModel, Commons, Filter;

procedure TFolhaRescisaoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaRescisaoModel>(TFolhaRescisaoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaRescisaoModel>(TFolhaRescisaoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaRescisao] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaRescisaoController.GetObject(id: Integer);
var
  FolhaRescisao: TFolhaRescisaoModel;
begin
  try
    FolhaRescisao := TFolhaRescisaoService.GetObject(id);

    if Assigned(FolhaRescisao) then
      Render(FolhaRescisao)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaRescisao]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaRescisao] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaRescisaoController.Insert(Context: TWebContext);
var
  FolhaRescisao: TFolhaRescisaoModel;
begin
  try
    FolhaRescisao := Context.Request.BodyAs<TFolhaRescisaoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaRescisao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaRescisaoService.Insert(FolhaRescisao);
    Render(TFolhaRescisaoService.GetObject(FolhaRescisao.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaRescisao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaRescisaoController.Update(Context: TWebContext);
var
  FolhaRescisao, FolhaRescisaoDB: TFolhaRescisaoModel;
begin
  try
    FolhaRescisao := Context.Request.BodyAs<TFolhaRescisaoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaRescisao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaRescisaoDB := TFolhaRescisaoService.GetObject(FolhaRescisao.id);

  if not Assigned(FolhaRescisaoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaRescisao]',
      '', 0, 400);

  try
    if TFolhaRescisaoService.Update(FolhaRescisao) > 0 then
      Render(TFolhaRescisaoService.GetObject(FolhaRescisao.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaRescisao]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaRescisaoDB);
  end;
end;

procedure TFolhaRescisaoController.Delete(id: Integer);
var
  FolhaRescisao: TFolhaRescisaoModel;
begin
  FolhaRescisao := TFolhaRescisaoService.GetObject(id);

  if not Assigned(FolhaRescisao) then
    raise EMVCException.Create('Invalid Object [Delete FolhaRescisao]',
      '', 0, 400);

  try
    if TFolhaRescisaoService.Delete(FolhaRescisao) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaRescisao]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaRescisao);
  end;
end;

end.
