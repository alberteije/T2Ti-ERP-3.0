﻿unit EmpresaTransporteController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD EmpresaTransporte')]
  [MVCPath('/empresa-transporte')]
  TEmpresaTransporteController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TEmpresaTransporteController }

uses EmpresaTransporteService, EmpresaTransporteModel, Commons, Filter;

procedure TEmpresaTransporteController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TEmpresaTransporteModel>(TEmpresaTransporteService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TEmpresaTransporteModel>(TEmpresaTransporteService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList EmpresaTransporte] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TEmpresaTransporteController.GetObject(id: Integer);
var
  EmpresaTransporte: TEmpresaTransporteModel;
begin
  try
    EmpresaTransporte := TEmpresaTransporteService.GetObject(id);

    if Assigned(EmpresaTransporte) then
      Render(EmpresaTransporte)
    else
      raise EMVCException.Create
        ('Not Found [GetObject EmpresaTransporte]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject EmpresaTransporte] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TEmpresaTransporteController.Insert(Context: TWebContext);
var
  EmpresaTransporte: TEmpresaTransporteModel;
begin
  try
    EmpresaTransporte := Context.Request.BodyAs<TEmpresaTransporteModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert EmpresaTransporte] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TEmpresaTransporteService.Insert(EmpresaTransporte);
    Render(TEmpresaTransporteService.GetObject(EmpresaTransporte.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert EmpresaTransporte] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TEmpresaTransporteController.Update(Context: TWebContext);
var
  EmpresaTransporte, EmpresaTransporteDB: TEmpresaTransporteModel;
begin
  try
    EmpresaTransporte := Context.Request.BodyAs<TEmpresaTransporteModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update EmpresaTransporte] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  EmpresaTransporteDB := TEmpresaTransporteService.GetObject(EmpresaTransporte.id);

  if not Assigned(EmpresaTransporteDB) then
    raise EMVCException.Create('Invalid Object [Update EmpresaTransporte]',
      '', 0, 400);

  try
    if TEmpresaTransporteService.Update(EmpresaTransporte) > 0 then
      Render(TEmpresaTransporteService.GetObject(EmpresaTransporte.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update EmpresaTransporte]',
        '', 0, 500);
  finally
    FreeAndNil(EmpresaTransporteDB);
  end;
end;

procedure TEmpresaTransporteController.Delete(id: Integer);
var
  EmpresaTransporte: TEmpresaTransporteModel;
begin
  EmpresaTransporte := TEmpresaTransporteService.GetObject(id);

  if not Assigned(EmpresaTransporte) then
    raise EMVCException.Create('Invalid Object [Delete EmpresaTransporte]',
      '', 0, 400);

  try
    if TEmpresaTransporteService.Delete(EmpresaTransporte) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete EmpresaTransporte]',
        '', 0, 500);
  finally
    FreeAndNil(EmpresaTransporte);
  end;
end;

end.
