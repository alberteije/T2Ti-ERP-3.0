﻿unit InssController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD Inss')]
  [MVCPath('/inss')]
  TInssController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TInssController }

uses InssService, InssModel, Commons, Filter;

procedure TInssController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TInssModel>(TInssService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TInssModel>(TInssService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList Inss] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TInssController.GetObject(id: Integer);
var
  Inss: TInssModel;
begin
  try
    Inss := TInssService.GetObject(id);

    if Assigned(Inss) then
      Render(Inss)
    else
      raise EMVCException.Create
        ('Not Found [GetObject Inss]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject Inss] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TInssController.Insert(Context: TWebContext);
var
  Inss: TInssModel;
begin
  try
    Inss := Context.Request.BodyAs<TInssModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert Inss] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TInssService.Insert(Inss);
    Render(TInssService.GetObject(Inss.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert Inss] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TInssController.Update(Context: TWebContext);
var
  Inss, InssDB: TInssModel;
begin
  try
    Inss := Context.Request.BodyAs<TInssModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update Inss] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  InssDB := TInssService.GetObject(Inss.id);

  if not Assigned(InssDB) then
    raise EMVCException.Create('Invalid Object [Update Inss]',
      '', 0, 400);

  try
    if TInssService.Update(Inss) > 0 then
      Render(TInssService.GetObject(Inss.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update Inss]',
        '', 0, 500);
  finally
    FreeAndNil(InssDB);
  end;
end;

procedure TInssController.Delete(id: Integer);
var
  Inss: TInssModel;
begin
  Inss := TInssService.GetObject(id);

  if not Assigned(Inss) then
    raise EMVCException.Create('Invalid Object [Delete Inss]',
      '', 0, 400);

  try
    if TInssService.Delete(Inss) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete Inss]',
        '', 0, 500);
  finally
    FreeAndNil(Inss);
  end;
end;

end.
