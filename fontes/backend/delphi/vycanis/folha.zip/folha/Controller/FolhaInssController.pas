﻿unit FolhaInssController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaInss')]
  [MVCPath('/folha-inss')]
  TFolhaInssController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaInssController }

uses FolhaInssService, FolhaInssModel, Commons, Filter;

procedure TFolhaInssController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaInssModel>(TFolhaInssService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaInssModel>(TFolhaInssService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaInss] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaInssController.GetObject(id: Integer);
var
  FolhaInss: TFolhaInssModel;
begin
  try
    FolhaInss := TFolhaInssService.GetObject(id);

    if Assigned(FolhaInss) then
      Render(FolhaInss)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaInss]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaInss] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaInssController.Insert(Context: TWebContext);
var
  FolhaInss: TFolhaInssModel;
begin
  try
    FolhaInss := Context.Request.BodyAs<TFolhaInssModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaInss] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaInssService.Insert(FolhaInss);
    Render(TFolhaInssService.GetObject(FolhaInss.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaInss] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaInssController.Update(Context: TWebContext);
var
  FolhaInss, FolhaInssDB: TFolhaInssModel;
begin
  try
    FolhaInss := Context.Request.BodyAs<TFolhaInssModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaInss] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaInssDB := TFolhaInssService.GetObject(FolhaInss.id);

  if not Assigned(FolhaInssDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaInss]',
      '', 0, 400);

  try
    if TFolhaInssService.Update(FolhaInss) > 0 then
      Render(TFolhaInssService.GetObject(FolhaInss.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaInss]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaInssDB);
  end;
end;

procedure TFolhaInssController.Delete(id: Integer);
var
  FolhaInss: TFolhaInssModel;
begin
  FolhaInss := TFolhaInssService.GetObject(id);

  if not Assigned(FolhaInss) then
    raise EMVCException.Create('Invalid Object [Delete FolhaInss]',
      '', 0, 400);

  try
    if TFolhaInssService.Delete(FolhaInss) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaInss]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaInss);
  end;
end;

end.
