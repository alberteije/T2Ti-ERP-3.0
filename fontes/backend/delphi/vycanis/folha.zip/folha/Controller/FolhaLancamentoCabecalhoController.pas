﻿unit FolhaLancamentoCabecalhoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaLancamentoCabecalho')]
  [MVCPath('/folha-lancamento-cabecalho')]
  TFolhaLancamentoCabecalhoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaLancamentoCabecalhoController }

uses FolhaLancamentoCabecalhoService, FolhaLancamentoCabecalhoModel, Commons, Filter;

procedure TFolhaLancamentoCabecalhoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaLancamentoCabecalhoModel>(TFolhaLancamentoCabecalhoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaLancamentoCabecalhoModel>(TFolhaLancamentoCabecalhoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaLancamentoCabecalho] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaLancamentoCabecalhoController.GetObject(id: Integer);
var
  FolhaLancamentoCabecalho: TFolhaLancamentoCabecalhoModel;
begin
  try
    FolhaLancamentoCabecalho := TFolhaLancamentoCabecalhoService.GetObject(id);

    if Assigned(FolhaLancamentoCabecalho) then
      Render(FolhaLancamentoCabecalho)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaLancamentoCabecalho]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaLancamentoCabecalho] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaLancamentoCabecalhoController.Insert(Context: TWebContext);
var
  FolhaLancamentoCabecalho: TFolhaLancamentoCabecalhoModel;
begin
  try
    FolhaLancamentoCabecalho := Context.Request.BodyAs<TFolhaLancamentoCabecalhoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaLancamentoCabecalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaLancamentoCabecalhoService.Insert(FolhaLancamentoCabecalho);
    Render(TFolhaLancamentoCabecalhoService.GetObject(FolhaLancamentoCabecalho.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaLancamentoCabecalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaLancamentoCabecalhoController.Update(Context: TWebContext);
var
  FolhaLancamentoCabecalho, FolhaLancamentoCabecalhoDB: TFolhaLancamentoCabecalhoModel;
begin
  try
    FolhaLancamentoCabecalho := Context.Request.BodyAs<TFolhaLancamentoCabecalhoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaLancamentoCabecalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaLancamentoCabecalhoDB := TFolhaLancamentoCabecalhoService.GetObject(FolhaLancamentoCabecalho.id);

  if not Assigned(FolhaLancamentoCabecalhoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaLancamentoCabecalho]',
      '', 0, 400);

  try
    if TFolhaLancamentoCabecalhoService.Update(FolhaLancamentoCabecalho) > 0 then
      Render(TFolhaLancamentoCabecalhoService.GetObject(FolhaLancamentoCabecalho.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaLancamentoCabecalho]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaLancamentoCabecalhoDB);
  end;
end;

procedure TFolhaLancamentoCabecalhoController.Delete(id: Integer);
var
  FolhaLancamentoCabecalho: TFolhaLancamentoCabecalhoModel;
begin
  FolhaLancamentoCabecalho := TFolhaLancamentoCabecalhoService.GetObject(id);

  if not Assigned(FolhaLancamentoCabecalho) then
    raise EMVCException.Create('Invalid Object [Delete FolhaLancamentoCabecalho]',
      '', 0, 400);

  try
    if TFolhaLancamentoCabecalhoService.Delete(FolhaLancamentoCabecalho) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaLancamentoCabecalho]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaLancamentoCabecalho);
  end;
end;

end.
