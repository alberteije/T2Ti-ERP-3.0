﻿unit SalarioMinimoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD SalarioMinimo')]
  [MVCPath('/salario-minimo')]
  TSalarioMinimoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TSalarioMinimoController }

uses SalarioMinimoService, SalarioMinimoModel, Commons, Filter;

procedure TSalarioMinimoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TSalarioMinimoModel>(TSalarioMinimoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TSalarioMinimoModel>(TSalarioMinimoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList SalarioMinimo] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSalarioMinimoController.GetObject(id: Integer);
var
  SalarioMinimo: TSalarioMinimoModel;
begin
  try
    SalarioMinimo := TSalarioMinimoService.GetObject(id);

    if Assigned(SalarioMinimo) then
      Render(SalarioMinimo)
    else
      raise EMVCException.Create
        ('Not Found [GetObject SalarioMinimo]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject SalarioMinimo] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSalarioMinimoController.Insert(Context: TWebContext);
var
  SalarioMinimo: TSalarioMinimoModel;
begin
  try
    SalarioMinimo := Context.Request.BodyAs<TSalarioMinimoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert SalarioMinimo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TSalarioMinimoService.Insert(SalarioMinimo);
    Render(TSalarioMinimoService.GetObject(SalarioMinimo.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert SalarioMinimo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TSalarioMinimoController.Update(Context: TWebContext);
var
  SalarioMinimo, SalarioMinimoDB: TSalarioMinimoModel;
begin
  try
    SalarioMinimo := Context.Request.BodyAs<TSalarioMinimoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update SalarioMinimo] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  SalarioMinimoDB := TSalarioMinimoService.GetObject(SalarioMinimo.id);

  if not Assigned(SalarioMinimoDB) then
    raise EMVCException.Create('Invalid Object [Update SalarioMinimo]',
      '', 0, 400);

  try
    if TSalarioMinimoService.Update(SalarioMinimo) > 0 then
      Render(TSalarioMinimoService.GetObject(SalarioMinimo.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update SalarioMinimo]',
        '', 0, 500);
  finally
    FreeAndNil(SalarioMinimoDB);
  end;
end;

procedure TSalarioMinimoController.Delete(id: Integer);
var
  SalarioMinimo: TSalarioMinimoModel;
begin
  SalarioMinimo := TSalarioMinimoService.GetObject(id);

  if not Assigned(SalarioMinimo) then
    raise EMVCException.Create('Invalid Object [Delete SalarioMinimo]',
      '', 0, 400);

  try
    if TSalarioMinimoService.Delete(SalarioMinimo) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete SalarioMinimo]',
        '', 0, 500);
  finally
    FreeAndNil(SalarioMinimo);
  end;
end;

end.
