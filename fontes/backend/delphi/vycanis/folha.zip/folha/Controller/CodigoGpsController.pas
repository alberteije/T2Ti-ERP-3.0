﻿unit CodigoGpsController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD CodigoGps')]
  [MVCPath('/codigo-gps')]
  TCodigoGpsController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TCodigoGpsController }

uses CodigoGpsService, CodigoGpsModel, Commons, Filter;

procedure TCodigoGpsController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TCodigoGpsModel>(TCodigoGpsService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TCodigoGpsModel>(TCodigoGpsService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList CodigoGps] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TCodigoGpsController.GetObject(id: Integer);
var
  CodigoGps: TCodigoGpsModel;
begin
  try
    CodigoGps := TCodigoGpsService.GetObject(id);

    if Assigned(CodigoGps) then
      Render(CodigoGps)
    else
      raise EMVCException.Create
        ('Not Found [GetObject CodigoGps]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject CodigoGps] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TCodigoGpsController.Insert(Context: TWebContext);
var
  CodigoGps: TCodigoGpsModel;
begin
  try
    CodigoGps := Context.Request.BodyAs<TCodigoGpsModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert CodigoGps] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TCodigoGpsService.Insert(CodigoGps);
    Render(TCodigoGpsService.GetObject(CodigoGps.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert CodigoGps] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TCodigoGpsController.Update(Context: TWebContext);
var
  CodigoGps, CodigoGpsDB: TCodigoGpsModel;
begin
  try
    CodigoGps := Context.Request.BodyAs<TCodigoGpsModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update CodigoGps] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  CodigoGpsDB := TCodigoGpsService.GetObject(CodigoGps.id);

  if not Assigned(CodigoGpsDB) then
    raise EMVCException.Create('Invalid Object [Update CodigoGps]',
      '', 0, 400);

  try
    if TCodigoGpsService.Update(CodigoGps) > 0 then
      Render(TCodigoGpsService.GetObject(CodigoGps.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update CodigoGps]',
        '', 0, 500);
  finally
    FreeAndNil(CodigoGpsDB);
  end;
end;

procedure TCodigoGpsController.Delete(id: Integer);
var
  CodigoGps: TCodigoGpsModel;
begin
  CodigoGps := TCodigoGpsService.GetObject(id);

  if not Assigned(CodigoGps) then
    raise EMVCException.Create('Invalid Object [Delete CodigoGps]',
      '', 0, 400);

  try
    if TCodigoGpsService.Delete(CodigoGps) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete CodigoGps]',
        '', 0, 500);
  finally
    FreeAndNil(CodigoGps);
  end;
end;

end.
