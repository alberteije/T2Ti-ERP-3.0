﻿unit FolhaTipoAfastamentoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaTipoAfastamento')]
  [MVCPath('/folha-tipo-afastamento')]
  TFolhaTipoAfastamentoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaTipoAfastamentoController }

uses FolhaTipoAfastamentoService, FolhaTipoAfastamentoModel, Commons, Filter;

procedure TFolhaTipoAfastamentoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaTipoAfastamentoModel>(TFolhaTipoAfastamentoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaTipoAfastamentoModel>(TFolhaTipoAfastamentoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaTipoAfastamento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaTipoAfastamentoController.GetObject(id: Integer);
var
  FolhaTipoAfastamento: TFolhaTipoAfastamentoModel;
begin
  try
    FolhaTipoAfastamento := TFolhaTipoAfastamentoService.GetObject(id);

    if Assigned(FolhaTipoAfastamento) then
      Render(FolhaTipoAfastamento)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaTipoAfastamento]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaTipoAfastamento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaTipoAfastamentoController.Insert(Context: TWebContext);
var
  FolhaTipoAfastamento: TFolhaTipoAfastamentoModel;
begin
  try
    FolhaTipoAfastamento := Context.Request.BodyAs<TFolhaTipoAfastamentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaTipoAfastamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaTipoAfastamentoService.Insert(FolhaTipoAfastamento);
    Render(TFolhaTipoAfastamentoService.GetObject(FolhaTipoAfastamento.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaTipoAfastamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaTipoAfastamentoController.Update(Context: TWebContext);
var
  FolhaTipoAfastamento, FolhaTipoAfastamentoDB: TFolhaTipoAfastamentoModel;
begin
  try
    FolhaTipoAfastamento := Context.Request.BodyAs<TFolhaTipoAfastamentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaTipoAfastamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaTipoAfastamentoDB := TFolhaTipoAfastamentoService.GetObject(FolhaTipoAfastamento.id);

  if not Assigned(FolhaTipoAfastamentoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaTipoAfastamento]',
      '', 0, 400);

  try
    if TFolhaTipoAfastamentoService.Update(FolhaTipoAfastamento) > 0 then
      Render(TFolhaTipoAfastamentoService.GetObject(FolhaTipoAfastamento.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaTipoAfastamento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaTipoAfastamentoDB);
  end;
end;

procedure TFolhaTipoAfastamentoController.Delete(id: Integer);
var
  FolhaTipoAfastamento: TFolhaTipoAfastamentoModel;
begin
  FolhaTipoAfastamento := TFolhaTipoAfastamentoService.GetObject(id);

  if not Assigned(FolhaTipoAfastamento) then
    raise EMVCException.Create('Invalid Object [Delete FolhaTipoAfastamento]',
      '', 0, 400);

  try
    if TFolhaTipoAfastamentoService.Delete(FolhaTipoAfastamento) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaTipoAfastamento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaTipoAfastamento);
  end;
end;

end.
