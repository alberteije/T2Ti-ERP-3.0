﻿unit IrrfController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD Irrf')]
  [MVCPath('/irrf')]
  TIrrfController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TIrrfController }

uses IrrfService, IrrfModel, Commons, Filter;

procedure TIrrfController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TIrrfModel>(TIrrfService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TIrrfModel>(TIrrfService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList Irrf] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TIrrfController.GetObject(id: Integer);
var
  Irrf: TIrrfModel;
begin
  try
    Irrf := TIrrfService.GetObject(id);

    if Assigned(Irrf) then
      Render(Irrf)
    else
      raise EMVCException.Create
        ('Not Found [GetObject Irrf]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject Irrf] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TIrrfController.Insert(Context: TWebContext);
var
  Irrf: TIrrfModel;
begin
  try
    Irrf := Context.Request.BodyAs<TIrrfModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert Irrf] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TIrrfService.Insert(Irrf);
    Render(TIrrfService.GetObject(Irrf.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert Irrf] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TIrrfController.Update(Context: TWebContext);
var
  Irrf, IrrfDB: TIrrfModel;
begin
  try
    Irrf := Context.Request.BodyAs<TIrrfModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update Irrf] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  IrrfDB := TIrrfService.GetObject(Irrf.id);

  if not Assigned(IrrfDB) then
    raise EMVCException.Create('Invalid Object [Update Irrf]',
      '', 0, 400);

  try
    if TIrrfService.Update(Irrf) > 0 then
      Render(TIrrfService.GetObject(Irrf.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update Irrf]',
        '', 0, 500);
  finally
    FreeAndNil(IrrfDB);
  end;
end;

procedure TIrrfController.Delete(id: Integer);
var
  Irrf: TIrrfModel;
begin
  Irrf := TIrrfService.GetObject(id);

  if not Assigned(Irrf) then
    raise EMVCException.Create('Invalid Object [Delete Irrf]',
      '', 0, 400);

  try
    if TIrrfService.Delete(Irrf) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete Irrf]',
        '', 0, 500);
  finally
    FreeAndNil(Irrf);
  end;
end;

end.
