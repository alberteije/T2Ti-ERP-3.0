﻿unit FolhaFechamentoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD FolhaFechamento')]
  [MVCPath('/folha-fechamento')]
  TFolhaFechamentoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TFolhaFechamentoController }

uses FolhaFechamentoService, FolhaFechamentoModel, Commons, Filter;

procedure TFolhaFechamentoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TFolhaFechamentoModel>(TFolhaFechamentoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TFolhaFechamentoModel>(TFolhaFechamentoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList FolhaFechamento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaFechamentoController.GetObject(id: Integer);
var
  FolhaFechamento: TFolhaFechamentoModel;
begin
  try
    FolhaFechamento := TFolhaFechamentoService.GetObject(id);

    if Assigned(FolhaFechamento) then
      Render(FolhaFechamento)
    else
      raise EMVCException.Create
        ('Not Found [GetObject FolhaFechamento]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject FolhaFechamento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TFolhaFechamentoController.Insert(Context: TWebContext);
var
  FolhaFechamento: TFolhaFechamentoModel;
begin
  try
    FolhaFechamento := Context.Request.BodyAs<TFolhaFechamentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert FolhaFechamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TFolhaFechamentoService.Insert(FolhaFechamento);
    Render(TFolhaFechamentoService.GetObject(FolhaFechamento.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert FolhaFechamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TFolhaFechamentoController.Update(Context: TWebContext);
var
  FolhaFechamento, FolhaFechamentoDB: TFolhaFechamentoModel;
begin
  try
    FolhaFechamento := Context.Request.BodyAs<TFolhaFechamentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update FolhaFechamento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  FolhaFechamentoDB := TFolhaFechamentoService.GetObject(FolhaFechamento.id);

  if not Assigned(FolhaFechamentoDB) then
    raise EMVCException.Create('Invalid Object [Update FolhaFechamento]',
      '', 0, 400);

  try
    if TFolhaFechamentoService.Update(FolhaFechamento) > 0 then
      Render(TFolhaFechamentoService.GetObject(FolhaFechamento.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update FolhaFechamento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaFechamentoDB);
  end;
end;

procedure TFolhaFechamentoController.Delete(id: Integer);
var
  FolhaFechamento: TFolhaFechamentoModel;
begin
  FolhaFechamento := TFolhaFechamentoService.GetObject(id);

  if not Assigned(FolhaFechamento) then
    raise EMVCException.Create('Invalid Object [Delete FolhaFechamento]',
      '', 0, 400);

  try
    if TFolhaFechamentoService.Delete(FolhaFechamento) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete FolhaFechamento]',
        '', 0, 500);
  finally
    FreeAndNil(FolhaFechamento);
  end;
end;

end.
