﻿unit GuiasAcumuladasController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD GuiasAcumuladas')]
  [MVCPath('/guias-acumuladas')]
  TGuiasAcumuladasController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TGuiasAcumuladasController }

uses GuiasAcumuladasService, GuiasAcumuladasModel, Commons, Filter;

procedure TGuiasAcumuladasController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TGuiasAcumuladasModel>(TGuiasAcumuladasService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TGuiasAcumuladasModel>(TGuiasAcumuladasService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList GuiasAcumuladas] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TGuiasAcumuladasController.GetObject(id: Integer);
var
  GuiasAcumuladas: TGuiasAcumuladasModel;
begin
  try
    GuiasAcumuladas := TGuiasAcumuladasService.GetObject(id);

    if Assigned(GuiasAcumuladas) then
      Render(GuiasAcumuladas)
    else
      raise EMVCException.Create
        ('Not Found [GetObject GuiasAcumuladas]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject GuiasAcumuladas] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TGuiasAcumuladasController.Insert(Context: TWebContext);
var
  GuiasAcumuladas: TGuiasAcumuladasModel;
begin
  try
    GuiasAcumuladas := Context.Request.BodyAs<TGuiasAcumuladasModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert GuiasAcumuladas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TGuiasAcumuladasService.Insert(GuiasAcumuladas);
    Render(TGuiasAcumuladasService.GetObject(GuiasAcumuladas.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert GuiasAcumuladas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TGuiasAcumuladasController.Update(Context: TWebContext);
var
  GuiasAcumuladas, GuiasAcumuladasDB: TGuiasAcumuladasModel;
begin
  try
    GuiasAcumuladas := Context.Request.BodyAs<TGuiasAcumuladasModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update GuiasAcumuladas] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  GuiasAcumuladasDB := TGuiasAcumuladasService.GetObject(GuiasAcumuladas.id);

  if not Assigned(GuiasAcumuladasDB) then
    raise EMVCException.Create('Invalid Object [Update GuiasAcumuladas]',
      '', 0, 400);

  try
    if TGuiasAcumuladasService.Update(GuiasAcumuladas) > 0 then
      Render(TGuiasAcumuladasService.GetObject(GuiasAcumuladas.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update GuiasAcumuladas]',
        '', 0, 500);
  finally
    FreeAndNil(GuiasAcumuladasDB);
  end;
end;

procedure TGuiasAcumuladasController.Delete(id: Integer);
var
  GuiasAcumuladas: TGuiasAcumuladasModel;
begin
  GuiasAcumuladas := TGuiasAcumuladasService.GetObject(id);

  if not Assigned(GuiasAcumuladas) then
    raise EMVCException.Create('Invalid Object [Delete GuiasAcumuladas]',
      '', 0, 400);

  try
    if TGuiasAcumuladasService.Delete(GuiasAcumuladas) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete GuiasAcumuladas]',
        '', 0, 500);
  finally
    FreeAndNil(GuiasAcumuladas);
  end;
end;

end.
