﻿unit SefipCodigoMovimentacaoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD SefipCodigoMovimentacao')]
  [MVCPath('/sefip-codigo-movimentacao')]
  TSefipCodigoMovimentacaoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TSefipCodigoMovimentacaoController }

uses SefipCodigoMovimentacaoService, SefipCodigoMovimentacaoModel, Commons, Filter;

procedure TSefipCodigoMovimentacaoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TSefipCodigoMovimentacaoModel>(TSefipCodigoMovimentacaoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TSefipCodigoMovimentacaoModel>(TSefipCodigoMovimentacaoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList SefipCodigoMovimentacao] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSefipCodigoMovimentacaoController.GetObject(id: Integer);
var
  SefipCodigoMovimentacao: TSefipCodigoMovimentacaoModel;
begin
  try
    SefipCodigoMovimentacao := TSefipCodigoMovimentacaoService.GetObject(id);

    if Assigned(SefipCodigoMovimentacao) then
      Render(SefipCodigoMovimentacao)
    else
      raise EMVCException.Create
        ('Not Found [GetObject SefipCodigoMovimentacao]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject SefipCodigoMovimentacao] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSefipCodigoMovimentacaoController.Insert(Context: TWebContext);
var
  SefipCodigoMovimentacao: TSefipCodigoMovimentacaoModel;
begin
  try
    SefipCodigoMovimentacao := Context.Request.BodyAs<TSefipCodigoMovimentacaoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert SefipCodigoMovimentacao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TSefipCodigoMovimentacaoService.Insert(SefipCodigoMovimentacao);
    Render(TSefipCodigoMovimentacaoService.GetObject(SefipCodigoMovimentacao.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert SefipCodigoMovimentacao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TSefipCodigoMovimentacaoController.Update(Context: TWebContext);
var
  SefipCodigoMovimentacao, SefipCodigoMovimentacaoDB: TSefipCodigoMovimentacaoModel;
begin
  try
    SefipCodigoMovimentacao := Context.Request.BodyAs<TSefipCodigoMovimentacaoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update SefipCodigoMovimentacao] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  SefipCodigoMovimentacaoDB := TSefipCodigoMovimentacaoService.GetObject(SefipCodigoMovimentacao.id);

  if not Assigned(SefipCodigoMovimentacaoDB) then
    raise EMVCException.Create('Invalid Object [Update SefipCodigoMovimentacao]',
      '', 0, 400);

  try
    if TSefipCodigoMovimentacaoService.Update(SefipCodigoMovimentacao) > 0 then
      Render(TSefipCodigoMovimentacaoService.GetObject(SefipCodigoMovimentacao.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update SefipCodigoMovimentacao]',
        '', 0, 500);
  finally
    FreeAndNil(SefipCodigoMovimentacaoDB);
  end;
end;

procedure TSefipCodigoMovimentacaoController.Delete(id: Integer);
var
  SefipCodigoMovimentacao: TSefipCodigoMovimentacaoModel;
begin
  SefipCodigoMovimentacao := TSefipCodigoMovimentacaoService.GetObject(id);

  if not Assigned(SefipCodigoMovimentacao) then
    raise EMVCException.Create('Invalid Object [Delete SefipCodigoMovimentacao]',
      '', 0, 400);

  try
    if TSefipCodigoMovimentacaoService.Delete(SefipCodigoMovimentacao) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete SefipCodigoMovimentacao]',
        '', 0, 500);
  finally
    FreeAndNil(SefipCodigoMovimentacao);
  end;
end;

end.
