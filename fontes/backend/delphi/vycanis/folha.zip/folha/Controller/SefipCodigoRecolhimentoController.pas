﻿unit SefipCodigoRecolhimentoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD SefipCodigoRecolhimento')]
  [MVCPath('/sefip-codigo-recolhimento')]
  TSefipCodigoRecolhimentoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TSefipCodigoRecolhimentoController }

uses SefipCodigoRecolhimentoService, SefipCodigoRecolhimentoModel, Commons, Filter;

procedure TSefipCodigoRecolhimentoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TSefipCodigoRecolhimentoModel>(TSefipCodigoRecolhimentoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TSefipCodigoRecolhimentoModel>(TSefipCodigoRecolhimentoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList SefipCodigoRecolhimento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSefipCodigoRecolhimentoController.GetObject(id: Integer);
var
  SefipCodigoRecolhimento: TSefipCodigoRecolhimentoModel;
begin
  try
    SefipCodigoRecolhimento := TSefipCodigoRecolhimentoService.GetObject(id);

    if Assigned(SefipCodigoRecolhimento) then
      Render(SefipCodigoRecolhimento)
    else
      raise EMVCException.Create
        ('Not Found [GetObject SefipCodigoRecolhimento]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject SefipCodigoRecolhimento] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TSefipCodigoRecolhimentoController.Insert(Context: TWebContext);
var
  SefipCodigoRecolhimento: TSefipCodigoRecolhimentoModel;
begin
  try
    SefipCodigoRecolhimento := Context.Request.BodyAs<TSefipCodigoRecolhimentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert SefipCodigoRecolhimento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TSefipCodigoRecolhimentoService.Insert(SefipCodigoRecolhimento);
    Render(TSefipCodigoRecolhimentoService.GetObject(SefipCodigoRecolhimento.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert SefipCodigoRecolhimento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TSefipCodigoRecolhimentoController.Update(Context: TWebContext);
var
  SefipCodigoRecolhimento, SefipCodigoRecolhimentoDB: TSefipCodigoRecolhimentoModel;
begin
  try
    SefipCodigoRecolhimento := Context.Request.BodyAs<TSefipCodigoRecolhimentoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update SefipCodigoRecolhimento] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  SefipCodigoRecolhimentoDB := TSefipCodigoRecolhimentoService.GetObject(SefipCodigoRecolhimento.id);

  if not Assigned(SefipCodigoRecolhimentoDB) then
    raise EMVCException.Create('Invalid Object [Update SefipCodigoRecolhimento]',
      '', 0, 400);

  try
    if TSefipCodigoRecolhimentoService.Update(SefipCodigoRecolhimento) > 0 then
      Render(TSefipCodigoRecolhimentoService.GetObject(SefipCodigoRecolhimento.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update SefipCodigoRecolhimento]',
        '', 0, 500);
  finally
    FreeAndNil(SefipCodigoRecolhimentoDB);
  end;
end;

procedure TSefipCodigoRecolhimentoController.Delete(id: Integer);
var
  SefipCodigoRecolhimento: TSefipCodigoRecolhimentoModel;
begin
  SefipCodigoRecolhimento := TSefipCodigoRecolhimentoService.GetObject(id);

  if not Assigned(SefipCodigoRecolhimento) then
    raise EMVCException.Create('Invalid Object [Delete SefipCodigoRecolhimento]',
      '', 0, 400);

  try
    if TSefipCodigoRecolhimentoService.Delete(SefipCodigoRecolhimento) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete SefipCodigoRecolhimento]',
        '', 0, 500);
  finally
    FreeAndNil(SefipCodigoRecolhimento);
  end;
end;

end.
