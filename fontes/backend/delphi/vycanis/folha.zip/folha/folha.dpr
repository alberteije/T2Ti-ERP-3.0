program folha;

{$APPTYPE CONSOLE}

uses
  System.SysUtils,
  IdHTTPWebBrokerBridge,
  Web.WebReq,
  Web.WebBroker,
  UWebModule in 'UWebModule.pas' {FWebModule: TWebModule},
  Commons in 'Commons.pas',
  UAuthCriteria in 'UAuthCriteria.pas',
  UDataModuleDBConnection in 'UDataModuleDBConnection.pas' {FDataModuleDBConnection: TDataModule},
  ModelBase in 'Model\ModelBase.pas',
  ServiceBase in 'Service\ServiceBase.pas',
	EmpresaTransporteItinerarioModel in 'Model\EmpresaTransporteItinerarioModel.pas',
	FolhaLancamentoDetalheModel in 'Model\FolhaLancamentoDetalheModel.pas',
	FolhaInssRetencaoModel in 'Model\FolhaInssRetencaoModel.pas',
	FolhaPppCatModel in 'Model\FolhaPppCatModel.pas',
	FolhaPppAtividadeModel in 'Model\FolhaPppAtividadeModel.pas',
	FolhaPppFatorRiscoModel in 'Model\FolhaPppFatorRiscoModel.pas',
	FolhaPppExameMedicoModel in 'Model\FolhaPppExameMedicoModel.pas',
	IrrfDetalheModel in 'Model\IrrfDetalheModel.pas',
	InssDetalheModel in 'Model\InssDetalheModel.pas',
	SalarioFamiliaModel in 'Model\SalarioFamiliaModel.pas',
	EmpresaTransporteModel in 'Model\EmpresaTransporteModel.pas',
	FolhaLancamentoCabecalhoModel in 'Model\FolhaLancamentoCabecalhoModel.pas',
	FolhaInssModel in 'Model\FolhaInssModel.pas',
	FolhaPppModel in 'Model\FolhaPppModel.pas',
	IrrfModel in 'Model\IrrfModel.pas',
	InssModel in 'Model\InssModel.pas',
	OperadoraPlanoSaudeModel in 'Model\OperadoraPlanoSaudeModel.pas',
	FolhaLancamentoComissaoModel in 'Model\FolhaLancamentoComissaoModel.pas',
	FolhaParametroModel in 'Model\FolhaParametroModel.pas',
	GuiasAcumuladasModel in 'Model\GuiasAcumuladasModel.pas',
	FolhaFechamentoModel in 'Model\FolhaFechamentoModel.pas',
	FeriasPeriodoAquisitivoModel in 'Model\FeriasPeriodoAquisitivoModel.pas',
	FolhaTipoAfastamentoModel in 'Model\FolhaTipoAfastamentoModel.pas',
	FolhaAfastamentoModel in 'Model\FolhaAfastamentoModel.pas',
	FolhaPlanoSaudeModel in 'Model\FolhaPlanoSaudeModel.pas',
	FolhaEventoModel in 'Model\FolhaEventoModel.pas',
	FolhaRescisaoModel in 'Model\FolhaRescisaoModel.pas',
	FolhaFeriasColetivasModel in 'Model\FolhaFeriasColetivasModel.pas',
	FolhaValeTransporteModel in 'Model\FolhaValeTransporteModel.pas',
	FolhaInssServicoModel in 'Model\FolhaInssServicoModel.pas',
	FolhaHistoricoSalarialModel in 'Model\FolhaHistoricoSalarialModel.pas',
	FeriadosModel in 'Model\FeriadosModel.pas',
	ViewControleAcessoModel in 'Model\ViewControleAcessoModel.pas',
	ViewPessoaUsuarioModel in 'Model\ViewPessoaUsuarioModel.pas',
	ViewPessoaColaboradorModel in 'Model\ViewPessoaColaboradorModel.pas',
	CboModel in 'Model\CboModel.pas',
	CodigoGpsModel in 'Model\CodigoGpsModel.pas',
	FpasModel in 'Model\FpasModel.pas',
	SalarioMinimoModel in 'Model\SalarioMinimoModel.pas',
	SefipCodigoMovimentacaoModel in 'Model\SefipCodigoMovimentacaoModel.pas',
	SefipCategoriaTrabalhoModel in 'Model\SefipCategoriaTrabalhoModel.pas',
	SefipCodigoRecolhimentoModel in 'Model\SefipCodigoRecolhimentoModel.pas',
	EmpresaTransporteItinerarioController in 'Controller\EmpresaTransporteItinerarioController.pas',
	EmpresaTransporteController in 'Controller\EmpresaTransporteController.pas',
	FolhaLancamentoCabecalhoController in 'Controller\FolhaLancamentoCabecalhoController.pas',
	FolhaInssController in 'Controller\FolhaInssController.pas',
	FolhaPppController in 'Controller\FolhaPppController.pas',
	IrrfController in 'Controller\IrrfController.pas',
	InssController in 'Controller\InssController.pas',
	OperadoraPlanoSaudeController in 'Controller\OperadoraPlanoSaudeController.pas',
	FolhaLancamentoComissaoController in 'Controller\FolhaLancamentoComissaoController.pas',
	FolhaParametroController in 'Controller\FolhaParametroController.pas',
	GuiasAcumuladasController in 'Controller\GuiasAcumuladasController.pas',
	FolhaFechamentoController in 'Controller\FolhaFechamentoController.pas',
	FeriasPeriodoAquisitivoController in 'Controller\FeriasPeriodoAquisitivoController.pas',
	FolhaTipoAfastamentoController in 'Controller\FolhaTipoAfastamentoController.pas',
	FolhaAfastamentoController in 'Controller\FolhaAfastamentoController.pas',
	FolhaPlanoSaudeController in 'Controller\FolhaPlanoSaudeController.pas',
	FolhaEventoController in 'Controller\FolhaEventoController.pas',
	FolhaRescisaoController in 'Controller\FolhaRescisaoController.pas',
	FolhaFeriasColetivasController in 'Controller\FolhaFeriasColetivasController.pas',
	FolhaValeTransporteController in 'Controller\FolhaValeTransporteController.pas',
	FolhaInssServicoController in 'Controller\FolhaInssServicoController.pas',
	FolhaHistoricoSalarialController in 'Controller\FolhaHistoricoSalarialController.pas',
	FeriadosController in 'Controller\FeriadosController.pas',
	ViewControleAcessoController in 'Controller\ViewControleAcessoController.pas',
	ViewPessoaUsuarioController in 'Controller\ViewPessoaUsuarioController.pas',
	ViewPessoaColaboradorController in 'Controller\ViewPessoaColaboradorController.pas',
	CboController in 'Controller\CboController.pas',
	CodigoGpsController in 'Controller\CodigoGpsController.pas',
	FpasController in 'Controller\FpasController.pas',
	SalarioMinimoController in 'Controller\SalarioMinimoController.pas',
	SefipCodigoMovimentacaoController in 'Controller\SefipCodigoMovimentacaoController.pas',
	SefipCategoriaTrabalhoController in 'Controller\SefipCategoriaTrabalhoController.pas',
	SefipCodigoRecolhimentoController in 'Controller\SefipCodigoRecolhimentoController.pas',
	EmpresaTransporteItinerarioService in 'Service\EmpresaTransporteItinerarioService.pas',
	EmpresaTransporteService in 'Service\EmpresaTransporteService.pas',
	FolhaLancamentoCabecalhoService in 'Service\FolhaLancamentoCabecalhoService.pas',
	FolhaInssService in 'Service\FolhaInssService.pas',
	FolhaPppService in 'Service\FolhaPppService.pas',
	IrrfService in 'Service\IrrfService.pas',
	InssService in 'Service\InssService.pas',
	OperadoraPlanoSaudeService in 'Service\OperadoraPlanoSaudeService.pas',
	FolhaLancamentoComissaoService in 'Service\FolhaLancamentoComissaoService.pas',
	FolhaParametroService in 'Service\FolhaParametroService.pas',
	GuiasAcumuladasService in 'Service\GuiasAcumuladasService.pas',
	FolhaFechamentoService in 'Service\FolhaFechamentoService.pas',
	FeriasPeriodoAquisitivoService in 'Service\FeriasPeriodoAquisitivoService.pas',
	FolhaTipoAfastamentoService in 'Service\FolhaTipoAfastamentoService.pas',
	FolhaAfastamentoService in 'Service\FolhaAfastamentoService.pas',
	FolhaPlanoSaudeService in 'Service\FolhaPlanoSaudeService.pas',
	FolhaEventoService in 'Service\FolhaEventoService.pas',
	FolhaRescisaoService in 'Service\FolhaRescisaoService.pas',
	FolhaFeriasColetivasService in 'Service\FolhaFeriasColetivasService.pas',
	FolhaValeTransporteService in 'Service\FolhaValeTransporteService.pas',
	FolhaInssServicoService in 'Service\FolhaInssServicoService.pas',
	FolhaHistoricoSalarialService in 'Service\FolhaHistoricoSalarialService.pas',
	FeriadosService in 'Service\FeriadosService.pas',
	ViewControleAcessoService in 'Service\ViewControleAcessoService.pas',
	ViewPessoaUsuarioService in 'Service\ViewPessoaUsuarioService.pas',
	ViewPessoaColaboradorService in 'Service\ViewPessoaColaboradorService.pas',
	CboService in 'Service\CboService.pas',
	CodigoGpsService in 'Service\CodigoGpsService.pas',
	FpasService in 'Service\FpasService.pas',
	SalarioMinimoService in 'Service\SalarioMinimoService.pas',
	SefipCodigoMovimentacaoService in 'Service\SefipCodigoMovimentacaoService.pas',
	SefipCategoriaTrabalhoService in 'Service\SefipCategoriaTrabalhoService.pas',
	SefipCodigoRecolhimentoService in 'Service\SefipCodigoRecolhimentoService.pas',
  Filter in 'Model\Transient\Filter.pas';
	
{$R *.res}

procedure RunServer(APort: Integer);
var
  LServer: TIdHTTPWebBrokerBridge;
begin
  WriteLn('T2Ti ERP 3.0 - Folha de Pagamento (com.t2ti) - ver 1.0.0 - DMVC');
  WriteLn(Format('Server started at port %d', [APort]));
  LServer := TIdHTTPWebBrokerBridge.Create(nil);
  try
    FormatSettings.DecimalSeparator := '.';
    LServer.DefaultPort := APort;
    LServer.MaxConnections := 1024;
    LServer.Active := True;
    WriteLn('Press ENTER to Kill the Server');
    ReadLn;
  finally
    LServer.Free;
  end;
end;

begin
  ReportMemoryLeaksOnShutdown := True;
  try
    if WebRequestHandler <> nil then
      WebRequestHandler.WebModuleClass := WebModuleClass;
    RunServer(8085);
  except
    on E: Exception do
      WriteLn(E.ClassName, ': ', E.Message);
  end
end.
