unit UWebModule;

interface

uses System.SysUtils, System.Classes, Web.HTTPApp,
  UAuthCriteria,
  mvcframework, MVCFramework.JWT;

type
  TFWebModule = class(TWebModule)
    procedure WebModuleCreate(Sender: TObject);
  private
    FEngine: TMVCEngine;
  public
    { Public declarations }
  end;

var
  WebModuleClass: TComponentClass = TFWebModule;

implementation

{ %CLASSGROUP 'Vcl.Controls.TControl' }

uses
  // MVC classes
  MVCFramework.Commons,
  MVCFramework.Middleware.JWT,
  MVCFramework.Middleware.Compression,

  // modules
	BpeCabecalhoController,
	ViewControleAcessoController,
	ViewPessoaUsuarioController,
	
  MVCFramework.Middleware.CORS;

{$R *.dfm}

procedure TFWebModule.WebModuleCreate(Sender: TObject);
var
  lClaimsSetup: TJWTClaimsSetup;
begin
  // Token - JWT
  lClaimsSetup := procedure(const JWT: TJWT)
    begin
      JWT.Claims.Issuer := 'Delphi MVC Framework JWT Middleware Sample';
      JWT.Claims.ExpirationTime := Now + 1000;
      JWT.Claims.NotBefore := Now; // valid since now
      JWT.Claims.IssuedAt := Now;
      JWT.CustomClaims['bpe'] := 'bpe';
    end;

  FEngine := TMVCEngine.Create(self);

  FEngine.AddMiddleware(TMVCJWTAuthenticationMiddleware.Create(
    TAuthCriteria.Create,
    lClaimsSetup,
    '#Your--32--character--key--here#',
    '/login'
    ));

  // modules
	FEngine.AddController(TBpeCabecalhoController);
	FEngine.AddController(TViewControleAcessoController);
	FEngine.AddController(TViewPessoaUsuarioController);
end;

end.
