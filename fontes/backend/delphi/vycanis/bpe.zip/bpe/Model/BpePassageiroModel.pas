unit BpePassageiroModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TBpePassageiroModel = class(TModelBase)
  private
    FId: Integer;
    FIdBpeCabecalho: Integer;
    FNome: string;
    FCpf: string;
    FTipoDocumentoIdentificacao: string;
    FNumeroDocumento: string;
    FDocumentoOutrosDescricao: string;
    FDataNascimento: TDateTime;
    FTelefone: string;
    FEmail: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_bpe_cabecalho')] 
		[MVCNameAsAttribute('idBpeCabecalho')] 
		property IdBpeCabecalho: Integer read FIdBpeCabecalho write FIdBpeCabecalho; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('cpf')] 
		[MVCNameAsAttribute('cpf')] 
		property Cpf: string read FCpf write FCpf; 

    [MVCColumnAttribute('tipo_documento_identificacao')] 
		[MVCNameAsAttribute('tipoDocumentoIdentificacao')] 
		property TipoDocumentoIdentificacao: string read FTipoDocumentoIdentificacao write FTipoDocumentoIdentificacao; 

    [MVCColumnAttribute('numero_documento')] 
		[MVCNameAsAttribute('numeroDocumento')] 
		property NumeroDocumento: string read FNumeroDocumento write FNumeroDocumento; 

    [MVCColumnAttribute('documento_outros_descricao')] 
		[MVCNameAsAttribute('documentoOutrosDescricao')] 
		property DocumentoOutrosDescricao: string read FDocumentoOutrosDescricao write FDocumentoOutrosDescricao; 

    [MVCColumnAttribute('data_nascimento')] 
		[MVCNameAsAttribute('dataNascimento')] 
		property DataNascimento: TDateTime read FDataNascimento write FDataNascimento; 

    [MVCColumnAttribute('telefone')] 
		[MVCNameAsAttribute('telefone')] 
		property Telefone: string read FTelefone write FTelefone; 

    [MVCColumnAttribute('email')] 
		[MVCNameAsAttribute('email')] 
		property Email: string read FEmail write FEmail; 

      
  end;

implementation

{ TBpePassageiroModel }

constructor TBpePassageiroModel.Create;
begin
  inherited;
end;

destructor TBpePassageiroModel.Destroy;
begin
  inherited;
end;


end.