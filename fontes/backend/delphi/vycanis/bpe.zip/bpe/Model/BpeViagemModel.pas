unit BpeViagemModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TBpeViagemModel = class(TModelBase)
  private
    FId: Integer;
    FIdBpeCabecalho: Integer;
    FCodigoPercurso: string;
    FDescricaoPercurso: string;
    FTipoViagem: string;
    FTipoServico: string;
    FTipoAcomodacao: string;
    FTipoTrecho: string;
    FDataHoraViagem: TDateTime;
    FDataHoraConexao: TDateTime;
    FPrefixoLinha: string;
    FPoltrona: string;
    FPlataforma: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_bpe_cabecalho')] 
		[MVCNameAsAttribute('idBpeCabecalho')] 
		property IdBpeCabecalho: Integer read FIdBpeCabecalho write FIdBpeCabecalho; 

    [MVCColumnAttribute('codigo_percurso')] 
		[MVCNameAsAttribute('codigoPercurso')] 
		property CodigoPercurso: string read FCodigoPercurso write FCodigoPercurso; 

    [MVCColumnAttribute('descricao_percurso')] 
		[MVCNameAsAttribute('descricaoPercurso')] 
		property DescricaoPercurso: string read FDescricaoPercurso write FDescricaoPercurso; 

    [MVCColumnAttribute('tipo_viagem')] 
		[MVCNameAsAttribute('tipoViagem')] 
		property TipoViagem: string read FTipoViagem write FTipoViagem; 

    [MVCColumnAttribute('tipo_servico')] 
		[MVCNameAsAttribute('tipoServico')] 
		property TipoServico: string read FTipoServico write FTipoServico; 

    [MVCColumnAttribute('tipo_acomodacao')] 
		[MVCNameAsAttribute('tipoAcomodacao')] 
		property TipoAcomodacao: string read FTipoAcomodacao write FTipoAcomodacao; 

    [MVCColumnAttribute('tipo_trecho')] 
		[MVCNameAsAttribute('tipoTrecho')] 
		property TipoTrecho: string read FTipoTrecho write FTipoTrecho; 

    [MVCColumnAttribute('data_hora_viagem')] 
		[MVCNameAsAttribute('dataHoraViagem')] 
		property DataHoraViagem: TDateTime read FDataHoraViagem write FDataHoraViagem; 

    [MVCColumnAttribute('data_hora_conexao')] 
		[MVCNameAsAttribute('dataHoraConexao')] 
		property DataHoraConexao: TDateTime read FDataHoraConexao write FDataHoraConexao; 

    [MVCColumnAttribute('prefixo_linha')] 
		[MVCNameAsAttribute('prefixoLinha')] 
		property PrefixoLinha: string read FPrefixoLinha write FPrefixoLinha; 

    [MVCColumnAttribute('poltrona')] 
		[MVCNameAsAttribute('poltrona')] 
		property Poltrona: string read FPoltrona write FPoltrona; 

    [MVCColumnAttribute('plataforma')] 
		[MVCNameAsAttribute('plataforma')] 
		property Plataforma: string read FPlataforma write FPlataforma; 

      
  end;

implementation

{ TBpeViagemModel }

constructor TBpeViagemModel.Create;
begin
  inherited;
end;

destructor TBpeViagemModel.Destroy;
begin
  inherited;
end;


end.