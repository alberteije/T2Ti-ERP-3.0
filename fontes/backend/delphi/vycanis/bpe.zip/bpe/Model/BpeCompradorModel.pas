unit BpeCompradorModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TBpeCompradorModel = class(TModelBase)
  private
    FId: Integer;
    FIdBpeCabecalho: Integer;
    FCnpj: string;
    FCpf: string;
    FIe: string;
    FNome: string;
    FFantasia: string;
    FTelefone: string;
    FLogradouro: string;
    FNumero: string;
    FComplemento: string;
    FBairro: string;
    FCodigoMunicipio: Integer;
    FNomeMunicipio: string;
    FUf: string;
    FCep: string;
    FCodigoPais: Integer;
    FNomePais: string;
    FEmail: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_bpe_cabecalho')] 
		[MVCNameAsAttribute('idBpeCabecalho')] 
		property IdBpeCabecalho: Integer read FIdBpeCabecalho write FIdBpeCabecalho; 

    [MVCColumnAttribute('cnpj')] 
		[MVCNameAsAttribute('cnpj')] 
		property Cnpj: string read FCnpj write FCnpj; 

    [MVCColumnAttribute('cpf')] 
		[MVCNameAsAttribute('cpf')] 
		property Cpf: string read FCpf write FCpf; 

    [MVCColumnAttribute('ie')] 
		[MVCNameAsAttribute('ie')] 
		property Ie: string read FIe write FIe; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('fantasia')] 
		[MVCNameAsAttribute('fantasia')] 
		property Fantasia: string read FFantasia write FFantasia; 

    [MVCColumnAttribute('telefone')] 
		[MVCNameAsAttribute('telefone')] 
		property Telefone: string read FTelefone write FTelefone; 

    [MVCColumnAttribute('logradouro')] 
		[MVCNameAsAttribute('logradouro')] 
		property Logradouro: string read FLogradouro write FLogradouro; 

    [MVCColumnAttribute('numero')] 
		[MVCNameAsAttribute('numero')] 
		property Numero: string read FNumero write FNumero; 

    [MVCColumnAttribute('complemento')] 
		[MVCNameAsAttribute('complemento')] 
		property Complemento: string read FComplemento write FComplemento; 

    [MVCColumnAttribute('bairro')] 
		[MVCNameAsAttribute('bairro')] 
		property Bairro: string read FBairro write FBairro; 

    [MVCColumnAttribute('codigo_municipio')] 
		[MVCNameAsAttribute('codigoMunicipio')] 
		property CodigoMunicipio: Integer read FCodigoMunicipio write FCodigoMunicipio; 

    [MVCColumnAttribute('nome_municipio')] 
		[MVCNameAsAttribute('nomeMunicipio')] 
		property NomeMunicipio: string read FNomeMunicipio write FNomeMunicipio; 

    [MVCColumnAttribute('uf')] 
		[MVCNameAsAttribute('uf')] 
		property Uf: string read FUf write FUf; 

    [MVCColumnAttribute('cep')] 
		[MVCNameAsAttribute('cep')] 
		property Cep: string read FCep write FCep; 

    [MVCColumnAttribute('codigo_pais')] 
		[MVCNameAsAttribute('codigoPais')] 
		property CodigoPais: Integer read FCodigoPais write FCodigoPais; 

    [MVCColumnAttribute('nome_pais')] 
		[MVCNameAsAttribute('nomePais')] 
		property NomePais: string read FNomePais write FNomePais; 

    [MVCColumnAttribute('email')] 
		[MVCNameAsAttribute('email')] 
		property Email: string read FEmail write FEmail; 

      
  end;

implementation

{ TBpeCompradorModel }

constructor TBpeCompradorModel.Create;
begin
  inherited;
end;

destructor TBpeCompradorModel.Destroy;
begin
  inherited;
end;


end.