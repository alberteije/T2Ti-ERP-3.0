unit BpeCabecalhoModel;

interface

uses
  Generics.Collections, System.SysUtils,
	BpeEmitenteModel, 
	BpePassageiroModel, 
	BpeCompradorModel, 
	BpeViagemModel, 
	BpeAgenciaModel, 
	BpePassagemModel, 
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TBpeCabecalhoModel = class(TModelBase)
  private
    FId: Integer;
    FUfEmitente: string;
    FAmbiente: string;
    FModelo: string;
    FSerie: string;
    FNumero: string;
    FCodigoNumerico: string;
    FChaveAcesso: string;
    FDigitoChaveAcesso: string;
    FModal: string;
    FDataHoraEmissao: TDateTime;
    FTipoEmissao: string;
    FVersaoProcessoEmissao: string;
    FTipoBpe: string;
    FConsumidorPresenca: string;
    FUfInicioViagem: string;
    FCodigoMunicipioInicioViagem: Integer;
    FUfFimViagem: string;
    FCodigoMunicipioFimViagem: Integer;
    FValorBilhete: Extended;
    FValorDesconto: Extended;
    FValorPago: Extended;
    FValorTroco: Extended;
    FTipoDesconto: string;
    FDescontoDescricao: string;
    FDescontoConcedidoOutros: string;
    FFormaPagamento: string;
    FFormaPagamentoOutros: string;
    FFormaPagamentoDocumento: string;
    FCst: string;
    FBaseCalculoIcms: Extended;
    FAliquotaIcms: Extended;
    FValorIcms: Extended;
    FPercentualReducaoBcIcms: Extended;
    FInformacoesAddFisco: string;
      
    FBpeEmitenteModelList: TObjectList<TBpeEmitenteModel>;
    FBpePassageiroModelList: TObjectList<TBpePassageiroModel>;
    FBpeCompradorModelList: TObjectList<TBpeCompradorModel>;
    FBpeViagemModelList: TObjectList<TBpeViagemModel>;
    FBpeAgenciaModelList: TObjectList<TBpeAgenciaModel>;
    FBpePassagemModelList: TObjectList<TBpePassagemModel>;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('uf_emitente')] 
		[MVCNameAsAttribute('ufEmitente')] 
		property UfEmitente: string read FUfEmitente write FUfEmitente; 

    [MVCColumnAttribute('ambiente')] 
		[MVCNameAsAttribute('ambiente')] 
		property Ambiente: string read FAmbiente write FAmbiente; 

    [MVCColumnAttribute('modelo')] 
		[MVCNameAsAttribute('modelo')] 
		property Modelo: string read FModelo write FModelo; 

    [MVCColumnAttribute('serie')] 
		[MVCNameAsAttribute('serie')] 
		property Serie: string read FSerie write FSerie; 

    [MVCColumnAttribute('numero')] 
		[MVCNameAsAttribute('numero')] 
		property Numero: string read FNumero write FNumero; 

    [MVCColumnAttribute('codigo_numerico')] 
		[MVCNameAsAttribute('codigoNumerico')] 
		property CodigoNumerico: string read FCodigoNumerico write FCodigoNumerico; 

    [MVCColumnAttribute('chave_acesso')] 
		[MVCNameAsAttribute('chaveAcesso')] 
		property ChaveAcesso: string read FChaveAcesso write FChaveAcesso; 

    [MVCColumnAttribute('digito_chave_acesso')] 
		[MVCNameAsAttribute('digitoChaveAcesso')] 
		property DigitoChaveAcesso: string read FDigitoChaveAcesso write FDigitoChaveAcesso; 

    [MVCColumnAttribute('modal')] 
		[MVCNameAsAttribute('modal')] 
		property Modal: string read FModal write FModal; 

    [MVCColumnAttribute('data_hora_emissao')] 
		[MVCNameAsAttribute('dataHoraEmissao')] 
		property DataHoraEmissao: TDateTime read FDataHoraEmissao write FDataHoraEmissao; 

    [MVCColumnAttribute('tipo_emissao')] 
		[MVCNameAsAttribute('tipoEmissao')] 
		property TipoEmissao: string read FTipoEmissao write FTipoEmissao; 

    [MVCColumnAttribute('versao_processo_emissao')] 
		[MVCNameAsAttribute('versaoProcessoEmissao')] 
		property VersaoProcessoEmissao: string read FVersaoProcessoEmissao write FVersaoProcessoEmissao; 

    [MVCColumnAttribute('tipo_bpe')] 
		[MVCNameAsAttribute('tipoBpe')] 
		property TipoBpe: string read FTipoBpe write FTipoBpe; 

    [MVCColumnAttribute('consumidor_presenca')] 
		[MVCNameAsAttribute('consumidorPresenca')] 
		property ConsumidorPresenca: string read FConsumidorPresenca write FConsumidorPresenca; 

    [MVCColumnAttribute('uf_inicio_viagem')] 
		[MVCNameAsAttribute('ufInicioViagem')] 
		property UfInicioViagem: string read FUfInicioViagem write FUfInicioViagem; 

    [MVCColumnAttribute('codigo_municipio_inicio_viagem')] 
		[MVCNameAsAttribute('codigoMunicipioInicioViagem')] 
		property CodigoMunicipioInicioViagem: Integer read FCodigoMunicipioInicioViagem write FCodigoMunicipioInicioViagem; 

    [MVCColumnAttribute('uf_fim_viagem')] 
		[MVCNameAsAttribute('ufFimViagem')] 
		property UfFimViagem: string read FUfFimViagem write FUfFimViagem; 

    [MVCColumnAttribute('codigo_municipio_fim_viagem')] 
		[MVCNameAsAttribute('codigoMunicipioFimViagem')] 
		property CodigoMunicipioFimViagem: Integer read FCodigoMunicipioFimViagem write FCodigoMunicipioFimViagem; 

    [MVCColumnAttribute('valor_bilhete')] 
		[MVCNameAsAttribute('valorBilhete')] 
		property ValorBilhete: Extended read FValorBilhete write FValorBilhete; 

    [MVCColumnAttribute('valor_desconto')] 
		[MVCNameAsAttribute('valorDesconto')] 
		property ValorDesconto: Extended read FValorDesconto write FValorDesconto; 

    [MVCColumnAttribute('valor_pago')] 
		[MVCNameAsAttribute('valorPago')] 
		property ValorPago: Extended read FValorPago write FValorPago; 

    [MVCColumnAttribute('valor_troco')] 
		[MVCNameAsAttribute('valorTroco')] 
		property ValorTroco: Extended read FValorTroco write FValorTroco; 

    [MVCColumnAttribute('tipo_desconto')] 
		[MVCNameAsAttribute('tipoDesconto')] 
		property TipoDesconto: string read FTipoDesconto write FTipoDesconto; 

    [MVCColumnAttribute('desconto_descricao')] 
		[MVCNameAsAttribute('descontoDescricao')] 
		property DescontoDescricao: string read FDescontoDescricao write FDescontoDescricao; 

    [MVCColumnAttribute('desconto_concedido_outros')] 
		[MVCNameAsAttribute('descontoConcedidoOutros')] 
		property DescontoConcedidoOutros: string read FDescontoConcedidoOutros write FDescontoConcedidoOutros; 

    [MVCColumnAttribute('forma_pagamento')] 
		[MVCNameAsAttribute('formaPagamento')] 
		property FormaPagamento: string read FFormaPagamento write FFormaPagamento; 

    [MVCColumnAttribute('forma_pagamento_outros')] 
		[MVCNameAsAttribute('formaPagamentoOutros')] 
		property FormaPagamentoOutros: string read FFormaPagamentoOutros write FFormaPagamentoOutros; 

    [MVCColumnAttribute('forma_pagamento_documento')] 
		[MVCNameAsAttribute('formaPagamentoDocumento')] 
		property FormaPagamentoDocumento: string read FFormaPagamentoDocumento write FFormaPagamentoDocumento; 

    [MVCColumnAttribute('cst')] 
		[MVCNameAsAttribute('cst')] 
		property Cst: string read FCst write FCst; 

    [MVCColumnAttribute('base_calculo_icms')] 
		[MVCNameAsAttribute('baseCalculoIcms')] 
		property BaseCalculoIcms: Extended read FBaseCalculoIcms write FBaseCalculoIcms; 

    [MVCColumnAttribute('aliquota_icms')] 
		[MVCNameAsAttribute('aliquotaIcms')] 
		property AliquotaIcms: Extended read FAliquotaIcms write FAliquotaIcms; 

    [MVCColumnAttribute('valor_icms')] 
		[MVCNameAsAttribute('valorIcms')] 
		property ValorIcms: Extended read FValorIcms write FValorIcms; 

    [MVCColumnAttribute('percentual_reducao_bc_icms')] 
		[MVCNameAsAttribute('percentualReducaoBcIcms')] 
		property PercentualReducaoBcIcms: Extended read FPercentualReducaoBcIcms write FPercentualReducaoBcIcms; 

    [MVCColumnAttribute('informacoes_add_fisco')] 
		[MVCNameAsAttribute('informacoesAddFisco')] 
		property InformacoesAddFisco: string read FInformacoesAddFisco write FInformacoesAddFisco; 

      
    [MapperListOf(TBpeEmitenteModel)] 
		[MVCNameAsAttribute('bpeEmitenteModelList')] 
		property BpeEmitenteModelList: TObjectList<TBpeEmitenteModel> read FBpeEmitenteModelList write FBpeEmitenteModelList; 

    [MapperListOf(TBpePassageiroModel)] 
		[MVCNameAsAttribute('bpePassageiroModelList')] 
		property BpePassageiroModelList: TObjectList<TBpePassageiroModel> read FBpePassageiroModelList write FBpePassageiroModelList; 

    [MapperListOf(TBpeCompradorModel)] 
		[MVCNameAsAttribute('bpeCompradorModelList')] 
		property BpeCompradorModelList: TObjectList<TBpeCompradorModel> read FBpeCompradorModelList write FBpeCompradorModelList; 

    [MapperListOf(TBpeViagemModel)] 
		[MVCNameAsAttribute('bpeViagemModelList')] 
		property BpeViagemModelList: TObjectList<TBpeViagemModel> read FBpeViagemModelList write FBpeViagemModelList; 

    [MapperListOf(TBpeAgenciaModel)] 
		[MVCNameAsAttribute('bpeAgenciaModelList')] 
		property BpeAgenciaModelList: TObjectList<TBpeAgenciaModel> read FBpeAgenciaModelList write FBpeAgenciaModelList; 

    [MapperListOf(TBpePassagemModel)] 
		[MVCNameAsAttribute('bpePassagemModelList')] 
		property BpePassagemModelList: TObjectList<TBpePassagemModel> read FBpePassagemModelList write FBpePassagemModelList; 

  end;

implementation

{ TBpeCabecalhoModel }

constructor TBpeCabecalhoModel.Create;
begin
  inherited;
	FBpeEmitenteModelList := TObjectList<TBpeEmitenteModel>.Create;
	FBpePassageiroModelList := TObjectList<TBpePassageiroModel>.Create;
	FBpeCompradorModelList := TObjectList<TBpeCompradorModel>.Create;
	FBpeViagemModelList := TObjectList<TBpeViagemModel>.Create;
	FBpeAgenciaModelList := TObjectList<TBpeAgenciaModel>.Create;
	FBpePassagemModelList := TObjectList<TBpePassagemModel>.Create;
end;

destructor TBpeCabecalhoModel.Destroy;
begin
	FreeAndNil(FBpeEmitenteModelList);
	FreeAndNil(FBpePassageiroModelList);
	FreeAndNil(FBpeCompradorModelList);
	FreeAndNil(FBpeViagemModelList);
	FreeAndNil(FBpeAgenciaModelList);
	FreeAndNil(FBpePassagemModelList);
  inherited;
end;


end.