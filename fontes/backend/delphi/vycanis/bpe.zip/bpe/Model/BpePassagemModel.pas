unit BpePassagemModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TBpePassagemModel = class(TModelBase)
  private
    FId: Integer;
    FIdBpeCabecalho: Integer;
    FCodigoLocalidadeOrigem: string;
    FDescricaoLocalidadeOrigem: string;
    FCodigoLocalidadeDestino: string;
    FDescricaoLocalidadeDestino: string;
    FDataHoraEmbarque: TDateTime;
    FDataHoraValidade: TDateTime;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_bpe_cabecalho')] 
		[MVCNameAsAttribute('idBpeCabecalho')] 
		property IdBpeCabecalho: Integer read FIdBpeCabecalho write FIdBpeCabecalho; 

    [MVCColumnAttribute('codigo_localidade_origem')] 
		[MVCNameAsAttribute('codigoLocalidadeOrigem')] 
		property CodigoLocalidadeOrigem: string read FCodigoLocalidadeOrigem write FCodigoLocalidadeOrigem; 

    [MVCColumnAttribute('descricao_localidade_origem')] 
		[MVCNameAsAttribute('descricaoLocalidadeOrigem')] 
		property DescricaoLocalidadeOrigem: string read FDescricaoLocalidadeOrigem write FDescricaoLocalidadeOrigem; 

    [MVCColumnAttribute('codigo_localidade_destino')] 
		[MVCNameAsAttribute('codigoLocalidadeDestino')] 
		property CodigoLocalidadeDestino: string read FCodigoLocalidadeDestino write FCodigoLocalidadeDestino; 

    [MVCColumnAttribute('descricao_localidade_destino')] 
		[MVCNameAsAttribute('descricaoLocalidadeDestino')] 
		property DescricaoLocalidadeDestino: string read FDescricaoLocalidadeDestino write FDescricaoLocalidadeDestino; 

    [MVCColumnAttribute('data_hora_embarque')] 
		[MVCNameAsAttribute('dataHoraEmbarque')] 
		property DataHoraEmbarque: TDateTime read FDataHoraEmbarque write FDataHoraEmbarque; 

    [MVCColumnAttribute('data_hora_validade')] 
		[MVCNameAsAttribute('dataHoraValidade')] 
		property DataHoraValidade: TDateTime read FDataHoraValidade write FDataHoraValidade; 

      
  end;

implementation

{ TBpePassagemModel }

constructor TBpePassagemModel.Create;
begin
  inherited;
end;

destructor TBpePassagemModel.Destroy;
begin
  inherited;
end;


end.