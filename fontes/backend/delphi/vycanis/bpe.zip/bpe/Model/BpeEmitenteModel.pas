unit BpeEmitenteModel;

interface

uses
  Generics.Collections, System.SysUtils,
  MVCFramework.Serializer.Commons, ModelBase;

type

  [MVCNameCase(ncCamelCase)]
  TBpeEmitenteModel = class(TModelBase)
  private
    FId: Integer;
    FIdBpeCabecalho: Integer;
    FCnpj: string;
    FIe: string;
    FIest: string;
    FIm: string;
    FCnae: string;
    FCrt: string;
    FNome: string;
    FFantasia: string;
    FLogradouro: string;
    FNumero: string;
    FComplemento: string;
    FBairro: string;
    FCodigoMunicipio: Integer;
    FNomeMunicipio: string;
    FUf: string;
    FCep: string;
    FTelefone: string;
      
  public
    constructor Create; virtual;
    destructor Destroy; override;

    [MVCColumnAttribute('id', True)] 
		[MVCNameAsAttribute('id')] 
		property Id: Integer read FId write FId; 

    [MVCColumnAttribute('id_bpe_cabecalho')] 
		[MVCNameAsAttribute('idBpeCabecalho')] 
		property IdBpeCabecalho: Integer read FIdBpeCabecalho write FIdBpeCabecalho; 

    [MVCColumnAttribute('cnpj')] 
		[MVCNameAsAttribute('cnpj')] 
		property Cnpj: string read FCnpj write FCnpj; 

    [MVCColumnAttribute('ie')] 
		[MVCNameAsAttribute('ie')] 
		property Ie: string read FIe write FIe; 

    [MVCColumnAttribute('iest')] 
		[MVCNameAsAttribute('iest')] 
		property Iest: string read FIest write FIest; 

    [MVCColumnAttribute('im')] 
		[MVCNameAsAttribute('im')] 
		property Im: string read FIm write FIm; 

    [MVCColumnAttribute('cnae')] 
		[MVCNameAsAttribute('cnae')] 
		property Cnae: string read FCnae write FCnae; 

    [MVCColumnAttribute('crt')] 
		[MVCNameAsAttribute('crt')] 
		property Crt: string read FCrt write FCrt; 

    [MVCColumnAttribute('nome')] 
		[MVCNameAsAttribute('nome')] 
		property Nome: string read FNome write FNome; 

    [MVCColumnAttribute('fantasia')] 
		[MVCNameAsAttribute('fantasia')] 
		property Fantasia: string read FFantasia write FFantasia; 

    [MVCColumnAttribute('logradouro')] 
		[MVCNameAsAttribute('logradouro')] 
		property Logradouro: string read FLogradouro write FLogradouro; 

    [MVCColumnAttribute('numero')] 
		[MVCNameAsAttribute('numero')] 
		property Numero: string read FNumero write FNumero; 

    [MVCColumnAttribute('complemento')] 
		[MVCNameAsAttribute('complemento')] 
		property Complemento: string read FComplemento write FComplemento; 

    [MVCColumnAttribute('bairro')] 
		[MVCNameAsAttribute('bairro')] 
		property Bairro: string read FBairro write FBairro; 

    [MVCColumnAttribute('codigo_municipio')] 
		[MVCNameAsAttribute('codigoMunicipio')] 
		property CodigoMunicipio: Integer read FCodigoMunicipio write FCodigoMunicipio; 

    [MVCColumnAttribute('nome_municipio')] 
		[MVCNameAsAttribute('nomeMunicipio')] 
		property NomeMunicipio: string read FNomeMunicipio write FNomeMunicipio; 

    [MVCColumnAttribute('uf')] 
		[MVCNameAsAttribute('uf')] 
		property Uf: string read FUf write FUf; 

    [MVCColumnAttribute('cep')] 
		[MVCNameAsAttribute('cep')] 
		property Cep: string read FCep write FCep; 

    [MVCColumnAttribute('telefone')] 
		[MVCNameAsAttribute('telefone')] 
		property Telefone: string read FTelefone write FTelefone; 

      
  end;

implementation

{ TBpeEmitenteModel }

constructor TBpeEmitenteModel.Create;
begin
  inherited;
end;

destructor TBpeEmitenteModel.Destroy;
begin
  inherited;
end;


end.