program bpe;

{$APPTYPE CONSOLE}

uses
  System.SysUtils,
  IdHTTPWebBrokerBridge,
  Web.WebReq,
  Web.WebBroker,
  UWebModule in 'UWebModule.pas' {FWebModule: TWebModule},
  Commons in 'Commons.pas',
  UAuthCriteria in 'UAuthCriteria.pas',
  UDataModuleDBConnection in 'UDataModuleDBConnection.pas' {FDataModuleDBConnection: TDataModule},
  ModelBase in 'Model\ModelBase.pas',
  ServiceBase in 'Service\ServiceBase.pas',
	BpeEmitenteModel in 'Model\BpeEmitenteModel.pas',
	BpePassageiroModel in 'Model\BpePassageiroModel.pas',
	BpeCompradorModel in 'Model\BpeCompradorModel.pas',
	BpeViagemModel in 'Model\BpeViagemModel.pas',
	BpeAgenciaModel in 'Model\BpeAgenciaModel.pas',
	BpePassagemModel in 'Model\BpePassagemModel.pas',
	BpeCabecalhoModel in 'Model\BpeCabecalhoModel.pas',
	ViewControleAcessoModel in 'Model\ViewControleAcessoModel.pas',
	ViewPessoaUsuarioModel in 'Model\ViewPessoaUsuarioModel.pas',
	BpeCabecalhoController in 'Controller\BpeCabecalhoController.pas',
	ViewControleAcessoController in 'Controller\ViewControleAcessoController.pas',
	ViewPessoaUsuarioController in 'Controller\ViewPessoaUsuarioController.pas',
	BpeCabecalhoService in 'Service\BpeCabecalhoService.pas',
	ViewControleAcessoService in 'Service\ViewControleAcessoService.pas',
	ViewPessoaUsuarioService in 'Service\ViewPessoaUsuarioService.pas',
  Filter in 'Model\Transient\Filter.pas';
	
{$R *.res}

procedure RunServer(APort: Integer);
var
  LServer: TIdHTTPWebBrokerBridge;
begin
  WriteLn('BPe (com.t2ti.bpe) - ver 1.0.0 - DMVC');
  WriteLn(Format('Server started at port %d', [APort]));
  LServer := TIdHTTPWebBrokerBridge.Create(nil);
  try
    FormatSettings.DecimalSeparator := '.';
    LServer.DefaultPort := APort;
    LServer.MaxConnections := 1024;
    LServer.Active := True;
    WriteLn('Press ENTER to Kill the Server');
    ReadLn;
  finally
    LServer.Free;
  end;
end;

begin
  ReportMemoryLeaksOnShutdown := True;
  try
    if WebRequestHandler <> nil then
      WebRequestHandler.WebModuleClass := WebModuleClass;
    RunServer(8085);
  except
    on E: Exception do
      WriteLn(E.ClassName, ': ', E.Message);
  end
end.
