﻿unit BpeCabecalhoService;

interface

uses
  BpeCabecalhoModel, 
  BpeEmitenteModel, 
  BpePassageiroModel, 
  BpeCompradorModel, 
  BpeViagemModel, 
  BpeAgenciaModel, 
  BpePassagemModel, 
  System.SysUtils, System.Generics.Collections, ServiceBase, MVCFramework.DataSet.Utils;

type

  TBpeCabecalhoService = class(TServiceBase)
  private
    class procedure AttachLinkedObjects(ABpeCabecalhoModelList: TObjectList<TBpeCabecalhoModel>); overload;
    class procedure AttachLinkedObjects(ABpeCabecalhoModel: TBpeCabecalhoModel); overload;
    class procedure InsertChildren(ABpeCabecalhoModel: TBpeCabecalhoModel);
    class procedure DeleteChildren(ABpeCabecalhoModel: TBpeCabecalhoModel);		
  public
    class function GetList: TObjectList<TBpeCabecalhoModel>;
    class function GetListFilter(AWhere: string): TObjectList<TBpeCabecalhoModel>;
    class function GetObject(APk: Integer): TBpeCabecalhoModel;
    class procedure Insert(ABpeCabecalhoModel: TBpeCabecalhoModel);
    class function Update(ABpeCabecalhoModel: TBpeCabecalhoModel): Integer;
    class function Delete(ABpeCabecalhoModel: TBpeCabecalhoModel): Integer;
  end;

var
  sql: string;


implementation

{ TBpeCabecalhoService }

class function TBpeCabecalhoService.GetList: TObjectList<TBpeCabecalhoModel>;
begin
  sql := 'SELECT * FROM bpe_cabecalho';
  try
    Result := GetQuery(sql).AsObjectList<TBpeCabecalhoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TBpeCabecalhoService.GetListFilter(AWhere: string): TObjectList<TBpeCabecalhoModel>;
begin
  sql := 'SELECT * FROM bpe_cabecalho where ' + AWhere;
  try
    Result := GetQuery(sql).AsObjectList<TBpeCabecalhoModel>;
    AttachLinkedObjects(Result);
  finally
    Query.Close;
    Query.Free;
  end;
end;

class function TBpeCabecalhoService.GetObject(APk: Integer): TBpeCabecalhoModel;
begin
  sql := 'SELECT * FROM bpe_cabecalho WHERE id = ' + IntToStr(APk);
  try
    GetQuery(sql);
    if not Query.Eof then
    begin
      Result := Query.AsObject<TBpeCabecalhoModel>;
      AttachLinkedObjects(Result);
    end
    else
      Result := nil;
  finally
    Query.Close;
    Query.Free;
  end;
end;

class procedure TBpeCabecalhoService.Insert(ABpeCabecalhoModel: TBpeCabecalhoModel);
begin
  ABpeCabecalhoModel.Id := InsertBase(ABpeCabecalhoModel, 'bpe_cabecalho');
	InsertChildren(ABpeCabecalhoModel);
end;

class function TBpeCabecalhoService.Update(ABpeCabecalhoModel: TBpeCabecalhoModel): Integer;
begin
  Result := UpdateBase(ABpeCabecalhoModel, 'bpe_cabecalho');
	DeleteChildren(ABpeCabecalhoModel);
  InsertChildren(ABpeCabecalhoModel);
end;

class function TBpeCabecalhoService.Delete(ABpeCabecalhoModel: TBpeCabecalhoModel): Integer;
begin
	DeleteChildren(ABpeCabecalhoModel);
	Result := DeleteBase(ABpeCabecalhoModel.Id, 'bpe_cabecalho');
end;

class procedure TBpeCabecalhoService.AttachLinkedObjects(ABpeCabecalhoModelList: TObjectList<TBpeCabecalhoModel>);
var
  BpeCabecalhoModel: TBpeCabecalhoModel;
begin
  for BpeCabecalhoModel in ABpeCabecalhoModelList do
  begin
    AttachLinkedObjects(BpeCabecalhoModel);
  end;
end;

class procedure TBpeCabecalhoService.AttachLinkedObjects(ABpeCabecalhoModel: TBpeCabecalhoModel);
begin
  // BpeEmitenteModel
	sql := 'SELECT * FROM bpe_emitente WHERE id_bpe_cabecalho = ' + ABpeCabecalhoModel.Id.ToString; 
	ABpeCabecalhoModel.BpeEmitenteModelList := GetQuery(sql).AsObjectList<TBpeEmitenteModel>; 

  // BpePassageiroModel
	sql := 'SELECT * FROM bpe_passageiro WHERE id_bpe_cabecalho = ' + ABpeCabecalhoModel.Id.ToString; 
	ABpeCabecalhoModel.BpePassageiroModelList := GetQuery(sql).AsObjectList<TBpePassageiroModel>; 

  // BpeCompradorModel
	sql := 'SELECT * FROM bpe_comprador WHERE id_bpe_cabecalho = ' + ABpeCabecalhoModel.Id.ToString; 
	ABpeCabecalhoModel.BpeCompradorModelList := GetQuery(sql).AsObjectList<TBpeCompradorModel>; 

  // BpeViagemModel
	sql := 'SELECT * FROM bpe_viagem WHERE id_bpe_cabecalho = ' + ABpeCabecalhoModel.Id.ToString; 
	ABpeCabecalhoModel.BpeViagemModelList := GetQuery(sql).AsObjectList<TBpeViagemModel>; 

  // BpeAgenciaModel
	sql := 'SELECT * FROM bpe_agencia WHERE id_bpe_cabecalho = ' + ABpeCabecalhoModel.Id.ToString; 
	ABpeCabecalhoModel.BpeAgenciaModelList := GetQuery(sql).AsObjectList<TBpeAgenciaModel>; 

  // BpePassagemModel
	sql := 'SELECT * FROM bpe_passagem WHERE id_bpe_cabecalho = ' + ABpeCabecalhoModel.Id.ToString; 
	ABpeCabecalhoModel.BpePassagemModelList := GetQuery(sql).AsObjectList<TBpePassagemModel>; 

end;

class procedure TBpeCabecalhoService.InsertChildren(ABpeCabecalhoModel: TBpeCabecalhoModel);
var
	BpeEmitenteModel: TBpeEmitenteModel;
	BpePassageiroModel: TBpePassageiroModel;
	BpeCompradorModel: TBpeCompradorModel;
	BpeViagemModel: TBpeViagemModel;
	BpeAgenciaModel: TBpeAgenciaModel;
	BpePassagemModel: TBpePassagemModel;
begin
  // BpeEmitenteModel 
	for BpeEmitenteModel in ABpeCabecalhoModel.BpeEmitenteModelList do 
	begin 
	  BpeEmitenteModel.IdBpeCabecalho := ABpeCabecalhoModel.Id;
	  InsertBase(BpeEmitenteModel, 'bpe_emitente'); 
	end; 

  // BpePassageiroModel 
	for BpePassageiroModel in ABpeCabecalhoModel.BpePassageiroModelList do 
	begin 
	  BpePassageiroModel.IdBpeCabecalho := ABpeCabecalhoModel.Id;
	  InsertBase(BpePassageiroModel, 'bpe_passageiro'); 
	end; 

  // BpeCompradorModel 
	for BpeCompradorModel in ABpeCabecalhoModel.BpeCompradorModelList do 
	begin 
	  BpeCompradorModel.IdBpeCabecalho := ABpeCabecalhoModel.Id;
	  InsertBase(BpeCompradorModel, 'bpe_comprador'); 
	end; 

  // BpeViagemModel 
	for BpeViagemModel in ABpeCabecalhoModel.BpeViagemModelList do 
	begin 
	  BpeViagemModel.IdBpeCabecalho := ABpeCabecalhoModel.Id;
	  InsertBase(BpeViagemModel, 'bpe_viagem'); 
	end; 

  // BpeAgenciaModel 
	for BpeAgenciaModel in ABpeCabecalhoModel.BpeAgenciaModelList do 
	begin 
	  BpeAgenciaModel.IdBpeCabecalho := ABpeCabecalhoModel.Id;
	  InsertBase(BpeAgenciaModel, 'bpe_agencia'); 
	end; 

  // BpePassagemModel 
	for BpePassagemModel in ABpeCabecalhoModel.BpePassagemModelList do 
	begin 
	  BpePassagemModel.IdBpeCabecalho := ABpeCabecalhoModel.Id;
	  InsertBase(BpePassagemModel, 'bpe_passagem'); 
	end; 

end;

class procedure TBpeCabecalhoService.DeleteChildren(ABpeCabecalhoModel: TBpeCabecalhoModel);
begin
  DeleteChild(ABpeCabecalhoModel.Id, 'bpe_emitente', 'id_bpe_cabecalho');
  DeleteChild(ABpeCabecalhoModel.Id, 'bpe_passageiro', 'id_bpe_cabecalho');
  DeleteChild(ABpeCabecalhoModel.Id, 'bpe_comprador', 'id_bpe_cabecalho');
  DeleteChild(ABpeCabecalhoModel.Id, 'bpe_viagem', 'id_bpe_cabecalho');
  DeleteChild(ABpeCabecalhoModel.Id, 'bpe_agencia', 'id_bpe_cabecalho');
  DeleteChild(ABpeCabecalhoModel.Id, 'bpe_passagem', 'id_bpe_cabecalho');
end;

end.
