﻿unit BpeCabecalhoController;

interface

uses mvcframework, mvcframework.Commons,
  System.SysUtils,
  MVCFramework.SystemJSONUtils;

type

  [MVCDoc('CRUD BpeCabecalho')]
  [MVCPath('/bpe-cabecalho')]
  TBpeCabecalhoController = class(TMVCController)
  public
    [MVCDoc('Returns a list of objects')]
    [MVCPath('/($param)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetList(Context: TWebContext);

    [MVCDoc('Returns an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpGET])]
    procedure GetObject(id: Integer);

    [MVCDoc('Inserts a new object')]
    [MVCPath]
    [MVCHTTPMethod([httpPOST])]
    procedure Insert(Context: TWebContext);

    [MVCDoc('Updates an object based on ID')]
    [MVCPath]
    [MVCHTTPMethod([httpPUT])]
    procedure Update(Context: TWebContext);

    [MVCDoc('Deletes an object based on ID')]
    [MVCPath('/($id)')]
    [MVCHTTPMethod([httpDelete])]
    procedure Delete(id: Integer);
  end;

implementation

{ TBpeCabecalhoController }

uses BpeCabecalhoService, BpeCabecalhoModel, Commons, Filter;

procedure TBpeCabecalhoController.GetList(Context: TWebContext);
var
  FilterUrl, FilterWhere: string;
  FilterObj: TFilter;
begin
  FilterUrl := Context.Request.Params['param'];
  if FilterUrl <> '' then
  begin
    GetObject(StrToInt(FilterUrl));
    exit;
  end;

  FilterWhere := Context.Request.Params['filter'];
  try
    if FilterWhere = '' then
    begin
      Render<TBpeCabecalhoModel>(TBpeCabecalhoService.GetList);
    end
    else begin
      // define Filter object
      FilterObj := TFilter.Create(FilterWhere);
      Render<TBpeCabecalhoModel>(TBpeCabecalhoService.GetListFilter(FilterObj.Where));
    end;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetList BpeCabecalho] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TBpeCabecalhoController.GetObject(id: Integer);
var
  BpeCabecalho: TBpeCabecalhoModel;
begin
  try
    BpeCabecalho := TBpeCabecalhoService.GetObject(id);

    if Assigned(BpeCabecalho) then
      Render(BpeCabecalho)
    else
      raise EMVCException.Create
        ('Not Found [GetObject BpeCabecalho]', '', 0, 404);
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create
        ('Error [GetObject BpeCabecalho] - Exception: ' + E.Message,
        E.StackTrace, 0, 500);
    end
    else
      raise;
  end;
end;

procedure TBpeCabecalhoController.Insert(Context: TWebContext);
var
  BpeCabecalho: TBpeCabecalhoModel;
begin
  try
    BpeCabecalho := Context.Request.BodyAs<TBpeCabecalhoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Insert BpeCabecalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  try
    TBpeCabecalhoService.Insert(BpeCabecalho);
    Render(TBpeCabecalhoService.GetObject(BpeCabecalho.Id));
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Error [Insert BpeCabecalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

end;

procedure TBpeCabecalhoController.Update(Context: TWebContext);
var
  BpeCabecalho, BpeCabecalhoDB: TBpeCabecalhoModel;
begin
  try
    BpeCabecalho := Context.Request.BodyAs<TBpeCabecalhoModel>;
  except
    on E: EServiceException do
    begin
      raise EMVCException.Create('Invalid Object [Update BpeCabecalho] - Exception: ' +
        E.Message, E.StackTrace, 0, 400);
    end
    else
      raise;
  end;

  BpeCabecalhoDB := TBpeCabecalhoService.GetObject(BpeCabecalho.id);

  if not Assigned(BpeCabecalhoDB) then
    raise EMVCException.Create('Invalid Object [Update BpeCabecalho]',
      '', 0, 400);

  try
    if TBpeCabecalhoService.Update(BpeCabecalho) > 0 then
      Render(TBpeCabecalhoService.GetObject(BpeCabecalho.Id))
    else
      raise EMVCException.Create('Nenhum registro foi alterado [Update BpeCabecalho]',
        '', 0, 500);
  finally
    FreeAndNil(BpeCabecalhoDB);
  end;
end;

procedure TBpeCabecalhoController.Delete(id: Integer);
var
  BpeCabecalho: TBpeCabecalhoModel;
begin
  BpeCabecalho := TBpeCabecalhoService.GetObject(id);

  if not Assigned(BpeCabecalho) then
    raise EMVCException.Create('Invalid Object [Delete BpeCabecalho]',
      '', 0, 400);

  try
    if TBpeCabecalhoService.Delete(BpeCabecalho) > 0 then
      Render(200, 'OK')
    else
      raise EMVCException.Create('Error [Delete BpeCabecalho]',
        '', 0, 500);
  finally
    FreeAndNil(BpeCabecalho);
  end;
end;

end.
