using afv.Models;
using afv.NHibernate;
using ISession = NHibernate.ISession;

namespace afv.Services
{
    public class VendedorRotaService
    {

        public IEnumerable<VendedorRotaModel> GetList()
        {
            IList<VendedorRotaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorRotaModel> DAL = new NHibernateDAL<VendedorRotaModel>(Session);
                Result = DAL.Select(new VendedorRotaModel());
            }
            return Result;
        }

        public IEnumerable<VendedorRotaModel> GetListFilter(Filter filterObj)
        {
            IList<VendedorRotaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from VendedorRotaModel where " + filterObj.Where;
                NHibernateDAL<VendedorRotaModel> DAL = new NHibernateDAL<VendedorRotaModel>(Session);
                Result = DAL.SelectListSql<VendedorRotaModel>(Query);
            }
            return Result;
        }
		
        public VendedorRotaModel GetObject(int id)
        {
            VendedorRotaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorRotaModel> DAL = new NHibernateDAL<VendedorRotaModel>(Session);
                Result = DAL.SelectId<VendedorRotaModel>(id);
            }
            return Result;
        }
		
        public void Insert(VendedorRotaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorRotaModel> DAL = new NHibernateDAL<VendedorRotaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(VendedorRotaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorRotaModel> DAL = new NHibernateDAL<VendedorRotaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(VendedorRotaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorRotaModel> DAL = new NHibernateDAL<VendedorRotaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}