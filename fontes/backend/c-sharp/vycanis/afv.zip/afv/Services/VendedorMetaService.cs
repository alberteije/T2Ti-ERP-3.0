using afv.Models;
using afv.NHibernate;
using ISession = NHibernate.ISession;

namespace afv.Services
{
    public class VendedorMetaService
    {

        public IEnumerable<VendedorMetaModel> GetList()
        {
            IList<VendedorMetaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorMetaModel> DAL = new NHibernateDAL<VendedorMetaModel>(Session);
                Result = DAL.Select(new VendedorMetaModel());
            }
            return Result;
        }

        public IEnumerable<VendedorMetaModel> GetListFilter(Filter filterObj)
        {
            IList<VendedorMetaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from VendedorMetaModel where " + filterObj.Where;
                NHibernateDAL<VendedorMetaModel> DAL = new NHibernateDAL<VendedorMetaModel>(Session);
                Result = DAL.SelectListSql<VendedorMetaModel>(Query);
            }
            return Result;
        }
		
        public VendedorMetaModel GetObject(int id)
        {
            VendedorMetaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorMetaModel> DAL = new NHibernateDAL<VendedorMetaModel>(Session);
                Result = DAL.SelectId<VendedorMetaModel>(id);
            }
            return Result;
        }
		
        public void Insert(VendedorMetaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorMetaModel> DAL = new NHibernateDAL<VendedorMetaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(VendedorMetaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorMetaModel> DAL = new NHibernateDAL<VendedorMetaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(VendedorMetaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendedorMetaModel> DAL = new NHibernateDAL<VendedorMetaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}