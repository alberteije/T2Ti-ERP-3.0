using afv.Models;
using afv.NHibernate;
using ISession = NHibernate.ISession;

namespace afv.Services
{
    public class ViewPessoaUsuarioService
    {

        public IEnumerable<ViewPessoaUsuarioModel> GetList()
        {
            IList<ViewPessoaUsuarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                Result = DAL.Select(new ViewPessoaUsuarioModel());
            }
            return Result;
        }

        public IEnumerable<ViewPessoaUsuarioModel> GetListFilter(Filter filterObj)
        {
            IList<ViewPessoaUsuarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewPessoaUsuarioModel where " + filterObj.Where;
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                Result = DAL.SelectListSql<ViewPessoaUsuarioModel>(Query);
            }
            return Result;
        }
		
        public ViewPessoaUsuarioModel GetObject(int id)
        {
            ViewPessoaUsuarioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                Result = DAL.SelectId<ViewPessoaUsuarioModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewPessoaUsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewPessoaUsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewPessoaUsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}