using System.Security.Cryptography;
using System.Text;

namespace afv.Utils
{

    public static class Util
    {

        public static string QuotedStr(string pValor)
        {
            return "'" + pValor + "'";
        }

        public static string VerificaNULL(string Texto, int Tipo)
        {
            switch (Tipo)
            {
                case 0:
                    if (Texto.Trim() == "")
                        return "NULL";
                    else
                        return Texto.Trim();
                case 1:
                    if (Texto.Trim() == "")
                        return "NULL";
                    else
                        return QuotedStr(Texto.Trim());
                case 2:
                    if (Texto.Trim() == "")
                        return "";
                    else
                        return (Texto.Trim());
                default:
                    return "";
            }
        }

        public static string MD5String(string texto)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] byteArray = Encoding.ASCII.GetBytes(texto);

            byteArray = md5.ComputeHash(byteArray);

            StringBuilder hashedValue = new StringBuilder();

            foreach (byte b in byteArray)
            {
                hashedValue.Append(b.ToString("x2"));
            }

            return hashedValue.ToString();
        }


    }
}
