using Microsoft.AspNetCore.Mvc;
using afv.Models;
using afv.Services;

namespace afv.Controllers
{
    [Route("vendedor-meta")]
    [Produces("application/json")]
    public class VendedorMetaController : Controller
    {
		private readonly VendedorMetaService _service;

        public VendedorMetaController()
        {
            _service = new VendedorMetaService();
        }

        [HttpGet]
        public IActionResult GetListVendedorMeta([FromQuery]string filter)
        {
            try
            {
                IEnumerable<VendedorMetaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList VendedorMeta]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectVendedorMeta")]
        public IActionResult GetObjectVendedorMeta(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject VendedorMeta]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject VendedorMeta]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertVendedorMeta([FromBody]VendedorMetaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert VendedorMeta]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectVendedorMeta", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert VendedorMeta]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateVendedorMeta([FromBody]VendedorMetaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update VendedorMeta]", null));
                }

                _service.Update(objJson);

                return GetObjectVendedorMeta(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update VendedorMeta]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteVendedorMeta(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete VendedorMeta]", ex));
            }
        }

    }
}