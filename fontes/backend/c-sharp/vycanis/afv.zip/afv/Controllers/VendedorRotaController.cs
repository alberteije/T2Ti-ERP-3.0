using Microsoft.AspNetCore.Mvc;
using afv.Models;
using afv.Services;

namespace afv.Controllers
{
    [Route("vendedor-rota")]
    [Produces("application/json")]
    public class VendedorRotaController : Controller
    {
		private readonly VendedorRotaService _service;

        public VendedorRotaController()
        {
            _service = new VendedorRotaService();
        }

        [HttpGet]
        public IActionResult GetListVendedorRota([FromQuery]string filter)
        {
            try
            {
                IEnumerable<VendedorRotaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList VendedorRota]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectVendedorRota")]
        public IActionResult GetObjectVendedorRota(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject VendedorRota]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject VendedorRota]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertVendedorRota([FromBody]VendedorRotaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert VendedorRota]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectVendedorRota", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert VendedorRota]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateVendedorRota([FromBody]VendedorRotaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update VendedorRota]", null));
                }

                _service.Update(objJson);

                return GetObjectVendedorRota(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update VendedorRota]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteVendedorRota(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete VendedorRota]", ex));
            }
        }

    }
}