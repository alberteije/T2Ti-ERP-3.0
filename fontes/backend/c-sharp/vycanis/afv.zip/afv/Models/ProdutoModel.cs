namespace afv.Models
{
	public class ProdutoModel
	{	
		public int? Id { get; set; } 

		public string? TipoItem { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public string? Gtin { get; set; } 

		public string? CodigoInterno { get; set; } 

		public System.Nullable<System.Decimal> ValorCompra { get; set; } 

		public System.Nullable<System.Decimal> ValorVenda { get; set; } 

		public string? CodigoNcm { get; set; } 

		public string? CodigoNbs { get; set; } 

		public string? CodigoCest { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeEstoque { get; set; } 

		public System.Nullable<System.Decimal> EstoqueMinimo { get; set; } 

		public System.Nullable<System.Decimal> EstoqueMaximo { get; set; } 

		public System.Nullable<System.Decimal> EstoqueIdeal { get; set; } 

		public string? Pesavel { get; set; } 

		public System.Nullable<System.Decimal> Peso { get; set; } 

		public System.Nullable<System.Decimal> Markup { get; set; } 

		public System.Nullable<System.Decimal> PrecoSugerido { get; set; } 

		public System.Nullable<System.Decimal> PrecoVendaMinimo { get; set; } 

		public System.Nullable<System.Decimal> CustoPercentual { get; set; } 

		public System.Nullable<System.Decimal> CustoUnitario { get; set; } 

		public System.Nullable<System.Decimal> CustoProducao { get; set; } 

		public System.Nullable<System.Decimal> CustoMedioLiquido { get; set; } 

		public System.Nullable<System.Decimal> PrecoLucroZero { get; set; } 

		public System.Nullable<System.Decimal> PrecoLucroMinimo { get; set; } 

		public System.Nullable<System.Decimal> PrecoLucroMaximo { get; set; } 

		public System.Nullable<System.Decimal> MargemLucro { get; set; } 

		public int? CodigoBalanca { get; set; } 

		public string? ClasseAbc { get; set; } 

		public string? Ativo { get; set; } 

		public string? InformacoesAdicionaisNfe { get; set; } 

		public ProdutoMarcaModel? ProdutoMarcaModel { get; set; } 

		public ProdutoUnidadeModel? ProdutoUnidadeModel { get; set; } 

		public ProdutoSubgrupoModel? ProdutoSubgrupoModel { get; set; } 

		private IList<ProdutoPromocaoModel>? produtoPromocaoModelList; 
		public IList<ProdutoPromocaoModel>? ProdutoPromocaoModelList 
		{ 
			get 
			{ 
				return produtoPromocaoModelList; 
			} 
			set 
			{ 
				produtoPromocaoModelList = value; 
				foreach (ProdutoPromocaoModel produtoPromocaoModel in produtoPromocaoModelList!) 
				{ 
					produtoPromocaoModel.ProdutoModel = this; 
				} 
			} 
		} 

	}
}
