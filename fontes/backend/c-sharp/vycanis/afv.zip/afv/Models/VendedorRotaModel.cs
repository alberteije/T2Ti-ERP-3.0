namespace afv.Models
{
	public class VendedorRotaModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataRota { get; set; } 

		public string? Status { get; set; } 

		public string? Observacao { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public ViewPessoaVendedorModel? ViewPessoaVendedorModel { get; set; } 

		private IList<VendedorVisitaModel>? vendedorVisitaModelList; 
		public IList<VendedorVisitaModel>? VendedorVisitaModelList 
		{ 
			get 
			{ 
				return vendedorVisitaModelList; 
			} 
			set 
			{ 
				vendedorVisitaModelList = value; 
				foreach (VendedorVisitaModel vendedorVisitaModel in vendedorVisitaModelList!) 
				{ 
					vendedorVisitaModel.VendedorRotaModel = this; 
				} 
			} 
		} 

	}
}
