namespace afv.Models
{
	public class VendedorVisitaModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataPrevista { get; set; } 

		public System.Nullable<System.DateTime> DataRealizada { get; set; } 

		public string? HoraInicio { get; set; } 

		public string? HoraFim { get; set; } 

		public System.Nullable<System.Decimal> Latitude { get; set; } 

		public System.Nullable<System.Decimal> Longitude { get; set; } 

		public string? Observacao { get; set; } 

		public VendedorRotaModel? VendedorRotaModel { get; set; } 

		public VendaCabecalhoModel? VendaCabecalhoModel { get; set; } 

		public VendaOrcamentoCabecalhoModel? VendaOrcamentoCabecalhoModel { get; set; } 

	}
}
