namespace afv.Models
{
	public class PessoaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Tipo { get; set; } 

		public string? Site { get; set; } 

		public string? Email { get; set; } 

		public string? EhCliente { get; set; } 

		public string? EhFornecedor { get; set; } 

		public string? EhTransportadora { get; set; } 

		public string? EhColaborador { get; set; } 

		public string? EhContador { get; set; } 

		public string? SituacaoContribuinte { get; set; } 

		public string? Ativo { get; set; } 

		private PessoaJuridicaModel? pessoaJuridicaModel; 
		public PessoaJuridicaModel? PessoaJuridicaModel 
		{ 
			get 
			{ 
				return pessoaJuridicaModel; 
			} 
			set 
			{ 
				pessoaJuridicaModel = value; 
				if (value != null) 
				{ 
					pessoaJuridicaModel!.PessoaModel = this; 
				} 
			} 
		} 

		private ClienteModel? clienteModel; 
		public ClienteModel? ClienteModel 
		{ 
			get 
			{ 
				return clienteModel; 
			} 
			set 
			{ 
				clienteModel = value; 
				if (value != null) 
				{ 
					clienteModel!.PessoaModel = this; 
				} 
			} 
		} 

		private IList<PessoaContatoModel>? pessoaContatoModelList; 
		public IList<PessoaContatoModel>? PessoaContatoModelList 
		{ 
			get 
			{ 
				return pessoaContatoModelList; 
			} 
			set 
			{ 
				pessoaContatoModelList = value; 
				foreach (PessoaContatoModel pessoaContatoModel in pessoaContatoModelList!) 
				{ 
					pessoaContatoModel.PessoaModel = this; 
				} 
			} 
		} 

		private IList<PessoaTelefoneModel>? pessoaTelefoneModelList; 
		public IList<PessoaTelefoneModel>? PessoaTelefoneModelList 
		{ 
			get 
			{ 
				return pessoaTelefoneModelList; 
			} 
			set 
			{ 
				pessoaTelefoneModelList = value; 
				foreach (PessoaTelefoneModel pessoaTelefoneModel in pessoaTelefoneModelList!) 
				{ 
					pessoaTelefoneModel.PessoaModel = this; 
				} 
			} 
		} 

		private IList<PessoaEnderecoModel>? pessoaEnderecoModelList; 
		public IList<PessoaEnderecoModel>? PessoaEnderecoModelList 
		{ 
			get 
			{ 
				return pessoaEnderecoModelList; 
			} 
			set 
			{ 
				pessoaEnderecoModelList = value; 
				foreach (PessoaEnderecoModel pessoaEnderecoModel in pessoaEnderecoModelList!) 
				{ 
					pessoaEnderecoModel.PessoaModel = this; 
				} 
			} 
		} 

		private IList<ViewFinLancamentoReceberModel>? viewFinLancamentoReceberModelList; 
		public IList<ViewFinLancamentoReceberModel>? ViewFinLancamentoReceberModelList 
		{ 
			get 
			{ 
				return viewFinLancamentoReceberModelList; 
			} 
			set 
			{ 
				viewFinLancamentoReceberModelList = value; 
				foreach (ViewFinLancamentoReceberModel viewFinLancamentoReceberModel in viewFinLancamentoReceberModelList!) 
				{ 
					viewFinLancamentoReceberModel.PessoaModel = this; 
				} 
			} 
		} 

	}
}
