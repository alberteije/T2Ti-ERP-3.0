namespace afv.Models
{
	public class ProdutoSubgrupoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public ProdutoGrupoModel? ProdutoGrupoModel { get; set; } 

	}
}
