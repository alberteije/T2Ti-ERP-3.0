namespace afv.Models
{
	public class ProdutoUnidadeModel
	{	
		public int? Id { get; set; } 

		public string? Sigla { get; set; } 

		public string? PodeFracionar { get; set; } 

		public string? Descricao { get; set; } 

	}
}
