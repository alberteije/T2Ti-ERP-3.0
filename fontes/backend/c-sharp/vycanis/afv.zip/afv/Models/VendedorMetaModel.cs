namespace afv.Models
{
	public class VendedorMetaModel
	{	
		public int? Id { get; set; } 

		public string? PeriodoMeta { get; set; } 

		public System.Nullable<System.Decimal> MetaOrcada { get; set; } 

		public System.Nullable<System.Decimal> MetaRealizada { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public ViewPessoaVendedorModel? ViewPessoaVendedorModel { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

	}
}
