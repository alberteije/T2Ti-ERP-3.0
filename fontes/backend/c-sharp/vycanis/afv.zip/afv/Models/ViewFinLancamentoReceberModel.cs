namespace afv.Models
{
	public class ViewFinLancamentoReceberModel
	{	
		public int? Id { get; set; } 

		public int? IdFinLancamentoReceber { get; set; } 

		public int? QuantidadeParcela { get; set; } 

		public System.Nullable<System.Decimal> ValorLancamento { get; set; } 

		public System.Nullable<System.DateTime> DataLancamento { get; set; } 

		public string? NumeroDocumento { get; set; } 

		public int? IdFinParcelaReceber { get; set; } 

		public int? NumeroParcela { get; set; } 

		public System.Nullable<System.DateTime> DataVencimento { get; set; } 

		public System.Nullable<System.DateTime> DataRecebimento { get; set; } 

		public System.Nullable<System.Decimal> ValorParcela { get; set; } 

		public System.Nullable<System.Decimal> TaxaJuro { get; set; } 

		public System.Nullable<System.Decimal> ValorJuro { get; set; } 

		public System.Nullable<System.Decimal> TaxaMulta { get; set; } 

		public System.Nullable<System.Decimal> ValorMulta { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public string? SiglaDocumento { get; set; } 

		public int? IdCliente { get; set; } 

		public int? IdPessoa { get; set; } 

		public string? NomeCliente { get; set; } 

		public int? IdFinStatusParcela { get; set; } 

		public string? SituacaoParcela { get; set; } 

		public string? DescricaoSituacaoParcela { get; set; } 

		public int? IdBancoContaCaixa { get; set; } 

		public string? NomeContaCaixa { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
