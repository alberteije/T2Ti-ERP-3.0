namespace afv.Models
{
	public class ViewPessoaVendedorModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Tipo { get; set; } 

		public string? Email { get; set; } 

		public string? Site { get; set; } 

		public string? CpfCnpj { get; set; } 

		public string? RgIe { get; set; } 

		public string? Matricula { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.DateTime> DataAdmissao { get; set; } 

		public System.Nullable<System.DateTime> DataDemissao { get; set; } 

		public string? CtpsNumero { get; set; } 

		public string? CtpsSerie { get; set; } 

		public System.Nullable<System.DateTime> CtpsDataExpedicao { get; set; } 

		public string? CtpsUf { get; set; } 

		public string? Observacao { get; set; } 

		public string? Logradouro { get; set; } 

		public string? Numero { get; set; } 

		public string? Complemento { get; set; } 

		public string? Bairro { get; set; } 

		public string? Cidade { get; set; } 

		public string? Cep { get; set; } 

		public string? MunicipioIbge { get; set; } 

		public string? Uf { get; set; } 

		public int? IdPessoa { get; set; } 

		public int? IdCargo { get; set; } 

		public int? IdSetor { get; set; } 

		public System.Nullable<System.Decimal> Comissao { get; set; } 

		public System.Nullable<System.Decimal> MetaVenda { get; set; } 

	}
}
