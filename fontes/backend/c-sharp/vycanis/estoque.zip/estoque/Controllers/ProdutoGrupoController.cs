using Microsoft.AspNetCore.Mvc;
using estoque.Models;
using estoque.Services;

namespace estoque.Controllers
{
    [Route("produto-grupo")]
    [Produces("application/json")]
    public class ProdutoGrupoController : Controller
    {
		private readonly ProdutoGrupoService _service;

        public ProdutoGrupoController()
        {
            _service = new ProdutoGrupoService();
        }

        [HttpGet]
        public IActionResult GetListProdutoGrupo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ProdutoGrupoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ProdutoGrupo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectProdutoGrupo")]
        public IActionResult GetObjectProdutoGrupo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ProdutoGrupo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ProdutoGrupo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertProdutoGrupo([FromBody]ProdutoGrupoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ProdutoGrupo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectProdutoGrupo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ProdutoGrupo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateProdutoGrupo([FromBody]ProdutoGrupoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ProdutoGrupo]", null));
                }

                _service.Update(objJson);

                return GetObjectProdutoGrupo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ProdutoGrupo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProdutoGrupo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ProdutoGrupo]", ex));
            }
        }

    }
}