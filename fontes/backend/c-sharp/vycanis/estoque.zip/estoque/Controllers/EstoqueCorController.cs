using Microsoft.AspNetCore.Mvc;
using estoque.Models;
using estoque.Services;

namespace estoque.Controllers
{
    [Route("estoque-cor")]
    [Produces("application/json")]
    public class EstoqueCorController : Controller
    {
		private readonly EstoqueCorService _service;

        public EstoqueCorController()
        {
            _service = new EstoqueCorService();
        }

        [HttpGet]
        public IActionResult GetListEstoqueCor([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EstoqueCorModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EstoqueCor]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEstoqueCor")]
        public IActionResult GetObjectEstoqueCor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EstoqueCor]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EstoqueCor]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEstoqueCor([FromBody]EstoqueCorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EstoqueCor]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEstoqueCor", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EstoqueCor]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEstoqueCor([FromBody]EstoqueCorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EstoqueCor]", null));
                }

                _service.Update(objJson);

                return GetObjectEstoqueCor(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EstoqueCor]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstoqueCor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EstoqueCor]", ex));
            }
        }

    }
}