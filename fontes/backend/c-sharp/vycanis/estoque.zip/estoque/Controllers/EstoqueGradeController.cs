using Microsoft.AspNetCore.Mvc;
using estoque.Models;
using estoque.Services;

namespace estoque.Controllers
{
    [Route("estoque-grade")]
    [Produces("application/json")]
    public class EstoqueGradeController : Controller
    {
		private readonly EstoqueGradeService _service;

        public EstoqueGradeController()
        {
            _service = new EstoqueGradeService();
        }

        [HttpGet]
        public IActionResult GetListEstoqueGrade([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EstoqueGradeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EstoqueGrade]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEstoqueGrade")]
        public IActionResult GetObjectEstoqueGrade(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EstoqueGrade]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EstoqueGrade]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEstoqueGrade([FromBody]EstoqueGradeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EstoqueGrade]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEstoqueGrade", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EstoqueGrade]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEstoqueGrade([FromBody]EstoqueGradeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EstoqueGrade]", null));
                }

                _service.Update(objJson);

                return GetObjectEstoqueGrade(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EstoqueGrade]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstoqueGrade(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EstoqueGrade]", ex));
            }
        }

    }
}