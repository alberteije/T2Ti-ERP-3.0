namespace estoque.Models
{
	public class ViewPessoaUsuarioModel
	{	
		public int? Id { get; set; } 

		public int? IdPessoa { get; set; } 

		public string? PessoaNome { get; set; } 

		public string? Tipo { get; set; } 

		public string? Email { get; set; } 

		public int? IdColaborador { get; set; } 

		public int? IdUsuario { get; set; } 

		public string? Login { get; set; } 

		public string? Senha { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public string? Administrador { get; set; } 

	}
}
