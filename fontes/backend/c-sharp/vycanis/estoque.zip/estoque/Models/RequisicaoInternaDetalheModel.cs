namespace estoque.Models
{
	public class RequisicaoInternaDetalheModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public RequisicaoInternaCabecalhoModel? RequisicaoInternaCabecalhoModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
