namespace estoque.Models
{
	public class EstoqueReajusteCabecalhoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataReajuste { get; set; } 

		public System.Nullable<System.Decimal> Taxa { get; set; } 

		public string? TipoReajuste { get; set; } 

		public string? Justificativa { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<EstoqueReajusteDetalheModel>? estoqueReajusteDetalheModelList; 
		public IList<EstoqueReajusteDetalheModel>? EstoqueReajusteDetalheModelList 
		{ 
			get 
			{ 
				return estoqueReajusteDetalheModelList; 
			} 
			set 
			{ 
				estoqueReajusteDetalheModelList = value; 
				foreach (EstoqueReajusteDetalheModel estoqueReajusteDetalheModel in estoqueReajusteDetalheModelList!) 
				{ 
					estoqueReajusteDetalheModel.EstoqueReajusteCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
