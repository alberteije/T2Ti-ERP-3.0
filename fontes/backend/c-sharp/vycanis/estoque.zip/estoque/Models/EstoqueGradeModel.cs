namespace estoque.Models
{
	public class EstoqueGradeModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

		public EstoqueCorModel? EstoqueCorModel { get; set; } 

		public EstoqueTamanhoModel? EstoqueTamanhoModel { get; set; } 

		public EstoqueSaborModel? EstoqueSaborModel { get; set; } 

		public EstoqueMarcaModel? EstoqueMarcaModel { get; set; } 

	}
}
