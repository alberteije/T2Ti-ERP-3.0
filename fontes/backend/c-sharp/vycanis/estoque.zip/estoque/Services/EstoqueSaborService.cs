using estoque.Models;
using estoque.NHibernate;
using ISession = NHibernate.ISession;

namespace estoque.Services
{
    public class EstoqueSaborService
    {

        public IEnumerable<EstoqueSaborModel> GetList()
        {
            IList<EstoqueSaborModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueSaborModel> DAL = new NHibernateDAL<EstoqueSaborModel>(Session);
                Result = DAL.Select(new EstoqueSaborModel());
            }
            return Result;
        }

        public IEnumerable<EstoqueSaborModel> GetListFilter(Filter filterObj)
        {
            IList<EstoqueSaborModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EstoqueSaborModel where " + filterObj.Where;
                NHibernateDAL<EstoqueSaborModel> DAL = new NHibernateDAL<EstoqueSaborModel>(Session);
                Result = DAL.SelectListSql<EstoqueSaborModel>(Query);
            }
            return Result;
        }
		
        public EstoqueSaborModel GetObject(int id)
        {
            EstoqueSaborModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueSaborModel> DAL = new NHibernateDAL<EstoqueSaborModel>(Session);
                Result = DAL.SelectId<EstoqueSaborModel>(id);
            }
            return Result;
        }
		
        public void Insert(EstoqueSaborModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueSaborModel> DAL = new NHibernateDAL<EstoqueSaborModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EstoqueSaborModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueSaborModel> DAL = new NHibernateDAL<EstoqueSaborModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EstoqueSaborModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueSaborModel> DAL = new NHibernateDAL<EstoqueSaborModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}