using estoque.Models;
using estoque.NHibernate;
using ISession = NHibernate.ISession;

namespace estoque.Services
{
    public class RequisicaoInternaCabecalhoService
    {

        public IEnumerable<RequisicaoInternaCabecalhoModel> GetList()
        {
            IList<RequisicaoInternaCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RequisicaoInternaCabecalhoModel> DAL = new NHibernateDAL<RequisicaoInternaCabecalhoModel>(Session);
                Result = DAL.Select(new RequisicaoInternaCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<RequisicaoInternaCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<RequisicaoInternaCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from RequisicaoInternaCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<RequisicaoInternaCabecalhoModel> DAL = new NHibernateDAL<RequisicaoInternaCabecalhoModel>(Session);
                Result = DAL.SelectListSql<RequisicaoInternaCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public RequisicaoInternaCabecalhoModel GetObject(int id)
        {
            RequisicaoInternaCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RequisicaoInternaCabecalhoModel> DAL = new NHibernateDAL<RequisicaoInternaCabecalhoModel>(Session);
                Result = DAL.SelectId<RequisicaoInternaCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(RequisicaoInternaCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RequisicaoInternaCabecalhoModel> DAL = new NHibernateDAL<RequisicaoInternaCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(RequisicaoInternaCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RequisicaoInternaCabecalhoModel> DAL = new NHibernateDAL<RequisicaoInternaCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(RequisicaoInternaCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RequisicaoInternaCabecalhoModel> DAL = new NHibernateDAL<RequisicaoInternaCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}