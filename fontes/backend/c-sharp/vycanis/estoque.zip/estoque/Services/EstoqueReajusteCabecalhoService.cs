using estoque.Models;
using estoque.NHibernate;
using ISession = NHibernate.ISession;

namespace estoque.Services
{
    public class EstoqueReajusteCabecalhoService
    {

        public IEnumerable<EstoqueReajusteCabecalhoModel> GetList()
        {
            IList<EstoqueReajusteCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueReajusteCabecalhoModel> DAL = new NHibernateDAL<EstoqueReajusteCabecalhoModel>(Session);
                Result = DAL.Select(new EstoqueReajusteCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<EstoqueReajusteCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<EstoqueReajusteCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EstoqueReajusteCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<EstoqueReajusteCabecalhoModel> DAL = new NHibernateDAL<EstoqueReajusteCabecalhoModel>(Session);
                Result = DAL.SelectListSql<EstoqueReajusteCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public EstoqueReajusteCabecalhoModel GetObject(int id)
        {
            EstoqueReajusteCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueReajusteCabecalhoModel> DAL = new NHibernateDAL<EstoqueReajusteCabecalhoModel>(Session);
                Result = DAL.SelectId<EstoqueReajusteCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(EstoqueReajusteCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueReajusteCabecalhoModel> DAL = new NHibernateDAL<EstoqueReajusteCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EstoqueReajusteCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueReajusteCabecalhoModel> DAL = new NHibernateDAL<EstoqueReajusteCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EstoqueReajusteCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueReajusteCabecalhoModel> DAL = new NHibernateDAL<EstoqueReajusteCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}