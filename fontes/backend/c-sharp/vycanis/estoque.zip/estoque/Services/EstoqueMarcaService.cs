using estoque.Models;
using estoque.NHibernate;
using ISession = NHibernate.ISession;

namespace estoque.Services
{
    public class EstoqueMarcaService
    {

        public IEnumerable<EstoqueMarcaModel> GetList()
        {
            IList<EstoqueMarcaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueMarcaModel> DAL = new NHibernateDAL<EstoqueMarcaModel>(Session);
                Result = DAL.Select(new EstoqueMarcaModel());
            }
            return Result;
        }

        public IEnumerable<EstoqueMarcaModel> GetListFilter(Filter filterObj)
        {
            IList<EstoqueMarcaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EstoqueMarcaModel where " + filterObj.Where;
                NHibernateDAL<EstoqueMarcaModel> DAL = new NHibernateDAL<EstoqueMarcaModel>(Session);
                Result = DAL.SelectListSql<EstoqueMarcaModel>(Query);
            }
            return Result;
        }
		
        public EstoqueMarcaModel GetObject(int id)
        {
            EstoqueMarcaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueMarcaModel> DAL = new NHibernateDAL<EstoqueMarcaModel>(Session);
                Result = DAL.SelectId<EstoqueMarcaModel>(id);
            }
            return Result;
        }
		
        public void Insert(EstoqueMarcaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueMarcaModel> DAL = new NHibernateDAL<EstoqueMarcaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EstoqueMarcaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueMarcaModel> DAL = new NHibernateDAL<EstoqueMarcaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EstoqueMarcaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueMarcaModel> DAL = new NHibernateDAL<EstoqueMarcaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}