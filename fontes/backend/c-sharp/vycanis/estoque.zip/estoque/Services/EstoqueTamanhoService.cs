using estoque.Models;
using estoque.NHibernate;
using ISession = NHibernate.ISession;

namespace estoque.Services
{
    public class EstoqueTamanhoService
    {

        public IEnumerable<EstoqueTamanhoModel> GetList()
        {
            IList<EstoqueTamanhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueTamanhoModel> DAL = new NHibernateDAL<EstoqueTamanhoModel>(Session);
                Result = DAL.Select(new EstoqueTamanhoModel());
            }
            return Result;
        }

        public IEnumerable<EstoqueTamanhoModel> GetListFilter(Filter filterObj)
        {
            IList<EstoqueTamanhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EstoqueTamanhoModel where " + filterObj.Where;
                NHibernateDAL<EstoqueTamanhoModel> DAL = new NHibernateDAL<EstoqueTamanhoModel>(Session);
                Result = DAL.SelectListSql<EstoqueTamanhoModel>(Query);
            }
            return Result;
        }
		
        public EstoqueTamanhoModel GetObject(int id)
        {
            EstoqueTamanhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueTamanhoModel> DAL = new NHibernateDAL<EstoqueTamanhoModel>(Session);
                Result = DAL.SelectId<EstoqueTamanhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(EstoqueTamanhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueTamanhoModel> DAL = new NHibernateDAL<EstoqueTamanhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EstoqueTamanhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueTamanhoModel> DAL = new NHibernateDAL<EstoqueTamanhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EstoqueTamanhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueTamanhoModel> DAL = new NHibernateDAL<EstoqueTamanhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}