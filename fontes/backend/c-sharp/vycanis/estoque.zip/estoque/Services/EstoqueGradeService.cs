using estoque.Models;
using estoque.NHibernate;
using ISession = NHibernate.ISession;

namespace estoque.Services
{
    public class EstoqueGradeService
    {

        public IEnumerable<EstoqueGradeModel> GetList()
        {
            IList<EstoqueGradeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueGradeModel> DAL = new NHibernateDAL<EstoqueGradeModel>(Session);
                Result = DAL.Select(new EstoqueGradeModel());
            }
            return Result;
        }

        public IEnumerable<EstoqueGradeModel> GetListFilter(Filter filterObj)
        {
            IList<EstoqueGradeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EstoqueGradeModel where " + filterObj.Where;
                NHibernateDAL<EstoqueGradeModel> DAL = new NHibernateDAL<EstoqueGradeModel>(Session);
                Result = DAL.SelectListSql<EstoqueGradeModel>(Query);
            }
            return Result;
        }
		
        public EstoqueGradeModel GetObject(int id)
        {
            EstoqueGradeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueGradeModel> DAL = new NHibernateDAL<EstoqueGradeModel>(Session);
                Result = DAL.SelectId<EstoqueGradeModel>(id);
            }
            return Result;
        }
		
        public void Insert(EstoqueGradeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueGradeModel> DAL = new NHibernateDAL<EstoqueGradeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EstoqueGradeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueGradeModel> DAL = new NHibernateDAL<EstoqueGradeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EstoqueGradeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueGradeModel> DAL = new NHibernateDAL<EstoqueGradeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}