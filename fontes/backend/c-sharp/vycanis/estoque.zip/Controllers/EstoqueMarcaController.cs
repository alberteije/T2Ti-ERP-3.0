using Microsoft.AspNetCore.Mvc;
using estoque.Models;
using estoque.Services;

namespace estoque.Controllers
{
    [Route("estoque-marca")]
    [Produces("application/json")]
    public class EstoqueMarcaController : Controller
    {
		private readonly EstoqueMarcaService _service;

        public EstoqueMarcaController()
        {
            _service = new EstoqueMarcaService();
        }

        [HttpGet]
        public IActionResult GetListEstoqueMarca([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EstoqueMarcaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EstoqueMarca]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEstoqueMarca")]
        public IActionResult GetObjectEstoqueMarca(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EstoqueMarca]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EstoqueMarca]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEstoqueMarca([FromBody]EstoqueMarcaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EstoqueMarca]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEstoqueMarca", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EstoqueMarca]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEstoqueMarca([FromBody]EstoqueMarcaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EstoqueMarca]", null));
                }

                _service.Update(objJson);

                return GetObjectEstoqueMarca(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EstoqueMarca]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstoqueMarca(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EstoqueMarca]", ex));
            }
        }

    }
}