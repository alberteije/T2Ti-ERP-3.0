using Microsoft.AspNetCore.Mvc;
using estoque.Models;
using estoque.Services;

namespace estoque.Controllers
{
    [Route("estoque-reajuste-cabecalho")]
    [Produces("application/json")]
    public class EstoqueReajusteCabecalhoController : Controller
    {
		private readonly EstoqueReajusteCabecalhoService _service;

        public EstoqueReajusteCabecalhoController()
        {
            _service = new EstoqueReajusteCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListEstoqueReajusteCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EstoqueReajusteCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EstoqueReajusteCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEstoqueReajusteCabecalho")]
        public IActionResult GetObjectEstoqueReajusteCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EstoqueReajusteCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EstoqueReajusteCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEstoqueReajusteCabecalho([FromBody]EstoqueReajusteCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EstoqueReajusteCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEstoqueReajusteCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EstoqueReajusteCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEstoqueReajusteCabecalho([FromBody]EstoqueReajusteCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EstoqueReajusteCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectEstoqueReajusteCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EstoqueReajusteCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstoqueReajusteCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EstoqueReajusteCabecalho]", ex));
            }
        }

    }
}