using Microsoft.AspNetCore.Mvc;
using estoque.Models;
using estoque.Services;

namespace estoque.Controllers
{
    [Route("estoque-tamanho")]
    [Produces("application/json")]
    public class EstoqueTamanhoController : Controller
    {
		private readonly EstoqueTamanhoService _service;

        public EstoqueTamanhoController()
        {
            _service = new EstoqueTamanhoService();
        }

        [HttpGet]
        public IActionResult GetListEstoqueTamanho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EstoqueTamanhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EstoqueTamanho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEstoqueTamanho")]
        public IActionResult GetObjectEstoqueTamanho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EstoqueTamanho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EstoqueTamanho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEstoqueTamanho([FromBody]EstoqueTamanhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EstoqueTamanho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEstoqueTamanho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EstoqueTamanho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEstoqueTamanho([FromBody]EstoqueTamanhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EstoqueTamanho]", null));
                }

                _service.Update(objJson);

                return GetObjectEstoqueTamanho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EstoqueTamanho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstoqueTamanho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EstoqueTamanho]", ex));
            }
        }

    }
}