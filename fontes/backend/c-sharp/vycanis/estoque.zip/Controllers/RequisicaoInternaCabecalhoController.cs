using Microsoft.AspNetCore.Mvc;
using estoque.Models;
using estoque.Services;

namespace estoque.Controllers
{
    [Route("requisicao-interna-cabecalho")]
    [Produces("application/json")]
    public class RequisicaoInternaCabecalhoController : Controller
    {
		private readonly RequisicaoInternaCabecalhoService _service;

        public RequisicaoInternaCabecalhoController()
        {
            _service = new RequisicaoInternaCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListRequisicaoInternaCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<RequisicaoInternaCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList RequisicaoInternaCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectRequisicaoInternaCabecalho")]
        public IActionResult GetObjectRequisicaoInternaCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject RequisicaoInternaCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject RequisicaoInternaCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertRequisicaoInternaCabecalho([FromBody]RequisicaoInternaCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert RequisicaoInternaCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectRequisicaoInternaCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert RequisicaoInternaCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateRequisicaoInternaCabecalho([FromBody]RequisicaoInternaCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update RequisicaoInternaCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectRequisicaoInternaCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update RequisicaoInternaCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteRequisicaoInternaCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete RequisicaoInternaCabecalho]", ex));
            }
        }

    }
}