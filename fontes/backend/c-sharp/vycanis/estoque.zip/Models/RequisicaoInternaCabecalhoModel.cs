namespace estoque.Models
{
	public class RequisicaoInternaCabecalhoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataRequisicao { get; set; } 

		public string? Situacao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<RequisicaoInternaDetalheModel>? requisicaoInternaDetalheModelList; 
		public IList<RequisicaoInternaDetalheModel>? RequisicaoInternaDetalheModelList 
		{ 
			get 
			{ 
				return requisicaoInternaDetalheModelList; 
			} 
			set 
			{ 
				requisicaoInternaDetalheModelList = value; 
				foreach (RequisicaoInternaDetalheModel requisicaoInternaDetalheModel in requisicaoInternaDetalheModelList!) 
				{ 
					requisicaoInternaDetalheModel.RequisicaoInternaCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
