namespace estoque.Models
{
	public class EstoqueReajusteDetalheModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorOriginal { get; set; } 

		public System.Nullable<System.Decimal> ValorReajuste { get; set; } 

		public EstoqueReajusteCabecalhoModel? EstoqueReajusteCabecalhoModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
