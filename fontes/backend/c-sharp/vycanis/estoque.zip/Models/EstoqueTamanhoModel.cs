namespace estoque.Models
{
	public class EstoqueTamanhoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.Decimal> Altura { get; set; } 

		public System.Nullable<System.Decimal> Comprimento { get; set; } 

		public System.Nullable<System.Decimal> Largura { get; set; } 

	}
}
