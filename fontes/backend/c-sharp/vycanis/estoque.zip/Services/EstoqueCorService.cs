using estoque.Models;
using estoque.NHibernate;
using ISession = NHibernate.ISession;

namespace estoque.Services
{
    public class EstoqueCorService
    {

        public IEnumerable<EstoqueCorModel> GetList()
        {
            IList<EstoqueCorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueCorModel> DAL = new NHibernateDAL<EstoqueCorModel>(Session);
                Result = DAL.Select(new EstoqueCorModel());
            }
            return Result;
        }

        public IEnumerable<EstoqueCorModel> GetListFilter(Filter filterObj)
        {
            IList<EstoqueCorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EstoqueCorModel where " + filterObj.Where;
                NHibernateDAL<EstoqueCorModel> DAL = new NHibernateDAL<EstoqueCorModel>(Session);
                Result = DAL.SelectListSql<EstoqueCorModel>(Query);
            }
            return Result;
        }
		
        public EstoqueCorModel GetObject(int id)
        {
            EstoqueCorModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueCorModel> DAL = new NHibernateDAL<EstoqueCorModel>(Session);
                Result = DAL.SelectId<EstoqueCorModel>(id);
            }
            return Result;
        }
		
        public void Insert(EstoqueCorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueCorModel> DAL = new NHibernateDAL<EstoqueCorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EstoqueCorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueCorModel> DAL = new NHibernateDAL<EstoqueCorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EstoqueCorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstoqueCorModel> DAL = new NHibernateDAL<EstoqueCorModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}