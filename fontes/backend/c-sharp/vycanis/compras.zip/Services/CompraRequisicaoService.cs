using compras.Models;
using compras.NHibernate;
using ISession = NHibernate.ISession;

namespace compras.Services
{
    public class CompraRequisicaoService
    {

        public IEnumerable<CompraRequisicaoModel> GetList()
        {
            IList<CompraRequisicaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraRequisicaoModel> DAL = new NHibernateDAL<CompraRequisicaoModel>(Session);
                Result = DAL.Select(new CompraRequisicaoModel());
            }
            return Result;
        }

        public IEnumerable<CompraRequisicaoModel> GetListFilter(Filter filterObj)
        {
            IList<CompraRequisicaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CompraRequisicaoModel where " + filterObj.Where;
                NHibernateDAL<CompraRequisicaoModel> DAL = new NHibernateDAL<CompraRequisicaoModel>(Session);
                Result = DAL.SelectListSql<CompraRequisicaoModel>(Query);
            }
            return Result;
        }
		
        public CompraRequisicaoModel GetObject(int id)
        {
            CompraRequisicaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraRequisicaoModel> DAL = new NHibernateDAL<CompraRequisicaoModel>(Session);
                Result = DAL.SelectId<CompraRequisicaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CompraRequisicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraRequisicaoModel> DAL = new NHibernateDAL<CompraRequisicaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CompraRequisicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraRequisicaoModel> DAL = new NHibernateDAL<CompraRequisicaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CompraRequisicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraRequisicaoModel> DAL = new NHibernateDAL<CompraRequisicaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}