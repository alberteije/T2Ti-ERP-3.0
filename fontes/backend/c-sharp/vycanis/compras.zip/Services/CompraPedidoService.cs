using compras.Models;
using compras.NHibernate;
using ISession = NHibernate.ISession;

namespace compras.Services
{
    public class CompraPedidoService
    {

        public IEnumerable<CompraPedidoModel> GetList()
        {
            IList<CompraPedidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraPedidoModel> DAL = new NHibernateDAL<CompraPedidoModel>(Session);
                Result = DAL.Select(new CompraPedidoModel());
            }
            return Result;
        }

        public IEnumerable<CompraPedidoModel> GetListFilter(Filter filterObj)
        {
            IList<CompraPedidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CompraPedidoModel where " + filterObj.Where;
                NHibernateDAL<CompraPedidoModel> DAL = new NHibernateDAL<CompraPedidoModel>(Session);
                Result = DAL.SelectListSql<CompraPedidoModel>(Query);
            }
            return Result;
        }
		
        public CompraPedidoModel GetObject(int id)
        {
            CompraPedidoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraPedidoModel> DAL = new NHibernateDAL<CompraPedidoModel>(Session);
                Result = DAL.SelectId<CompraPedidoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CompraPedidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraPedidoModel> DAL = new NHibernateDAL<CompraPedidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CompraPedidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraPedidoModel> DAL = new NHibernateDAL<CompraPedidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CompraPedidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraPedidoModel> DAL = new NHibernateDAL<CompraPedidoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}