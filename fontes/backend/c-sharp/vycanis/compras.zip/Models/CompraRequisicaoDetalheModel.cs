namespace compras.Models
{
	public class CompraRequisicaoDetalheModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public CompraRequisicaoModel? CompraRequisicaoModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
