namespace compras.Models
{
	public class CompraPedidoModel
	{	
		public int? Id { get; set; } 

		public string? CodigoCotacao { get; set; } 

		public System.Nullable<System.DateTime> DataPedido { get; set; } 

		public System.Nullable<System.DateTime> DataPrevistaEntrega { get; set; } 

		public System.Nullable<System.DateTime> DataPrevisaoPagamento { get; set; } 

		public string? LocalEntrega { get; set; } 

		public string? LocalCobranca { get; set; } 

		public string? Contato { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public string? TipoFrete { get; set; } 

		public string? FormaPagamento { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcms { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalProdutos { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public System.Nullable<System.Decimal> ValorSeguro { get; set; } 

		public System.Nullable<System.Decimal> ValorOutrasDespesas { get; set; } 

		public System.Nullable<System.Decimal> ValorIpi { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalNf { get; set; } 

		public int? QuantidadeParcelas { get; set; } 

		public string? DiaPrimeiroVencimento { get; set; } 

		public int? IntervaloEntreParcelas { get; set; } 

		public string? DiaFixoParcela { get; set; } 

		public CompraTipoPedidoModel? CompraTipoPedidoModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public ViewPessoaFornecedorModel? ViewPessoaFornecedorModel { get; set; } 

		private IList<CompraPedidoDetalheModel>? compraPedidoDetalheModelList; 
		public IList<CompraPedidoDetalheModel>? CompraPedidoDetalheModelList 
		{ 
			get 
			{ 
				return compraPedidoDetalheModelList; 
			} 
			set 
			{ 
				compraPedidoDetalheModelList = value; 
				foreach (CompraPedidoDetalheModel compraPedidoDetalheModel in compraPedidoDetalheModelList!) 
				{ 
					compraPedidoDetalheModel.CompraPedidoModel = this; 
				} 
			} 
		} 

	}
}
