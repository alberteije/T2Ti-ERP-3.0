namespace compras.Models
{
	public class CompraCotacaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataCotacao { get; set; } 

		public string? Descricao { get; set; } 

		public CompraRequisicaoModel? CompraRequisicaoModel { get; set; } 

		private IList<CompraFornecedorCotacaoModel>? compraFornecedorCotacaoModelList; 
		public IList<CompraFornecedorCotacaoModel>? CompraFornecedorCotacaoModelList 
		{ 
			get 
			{ 
				return compraFornecedorCotacaoModelList; 
			} 
			set 
			{ 
				compraFornecedorCotacaoModelList = value; 
				foreach (CompraFornecedorCotacaoModel compraFornecedorCotacaoModel in compraFornecedorCotacaoModelList!) 
				{ 
					compraFornecedorCotacaoModel.CompraCotacaoModel = this; 
				} 
			} 
		} 

		private IList<CompraCotacaoDetalheModel>? compraCotacaoDetalheModelList; 
		public IList<CompraCotacaoDetalheModel>? CompraCotacaoDetalheModelList 
		{ 
			get 
			{ 
				return compraCotacaoDetalheModelList; 
			} 
			set 
			{ 
				compraCotacaoDetalheModelList = value; 
				foreach (CompraCotacaoDetalheModel compraCotacaoDetalheModel in compraCotacaoDetalheModelList!) 
				{ 
					compraCotacaoDetalheModel.CompraCotacaoModel = this; 
				} 
			} 
		} 

	}
}
