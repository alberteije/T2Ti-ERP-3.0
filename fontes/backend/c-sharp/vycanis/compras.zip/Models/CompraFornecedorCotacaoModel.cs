namespace compras.Models
{
	public class CompraFornecedorCotacaoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? PrazoEntrega { get; set; } 

		public string? VendaCondicoesPagamento { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public ViewPessoaFornecedorModel? ViewPessoaFornecedorModel { get; set; } 

		public CompraCotacaoModel? CompraCotacaoModel { get; set; } 

	}
}
