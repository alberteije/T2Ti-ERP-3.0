using Microsoft.AspNetCore.Mvc;
using compras.Models;
using compras.Services;

namespace compras.Controllers
{
    [Route("produto-marca")]
    [Produces("application/json")]
    public class ProdutoMarcaController : Controller
    {
		private readonly ProdutoMarcaService _service;

        public ProdutoMarcaController()
        {
            _service = new ProdutoMarcaService();
        }

        [HttpGet]
        public IActionResult GetListProdutoMarca([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ProdutoMarcaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ProdutoMarca]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectProdutoMarca")]
        public IActionResult GetObjectProdutoMarca(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ProdutoMarca]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ProdutoMarca]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertProdutoMarca([FromBody]ProdutoMarcaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ProdutoMarca]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectProdutoMarca", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ProdutoMarca]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateProdutoMarca([FromBody]ProdutoMarcaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ProdutoMarca]", null));
                }

                _service.Update(objJson);

                return GetObjectProdutoMarca(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ProdutoMarca]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProdutoMarca(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ProdutoMarca]", ex));
            }
        }

    }
}