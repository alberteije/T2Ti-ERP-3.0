using Microsoft.AspNetCore.Mvc;
using compras.Models;
using compras.Services;

namespace compras.Controllers
{
    [Route("compra-cotacao")]
    [Produces("application/json")]
    public class CompraCotacaoController : Controller
    {
		private readonly CompraCotacaoService _service;

        public CompraCotacaoController()
        {
            _service = new CompraCotacaoService();
        }

        [HttpGet]
        public IActionResult GetListCompraCotacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CompraCotacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CompraCotacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCompraCotacao")]
        public IActionResult GetObjectCompraCotacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CompraCotacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CompraCotacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCompraCotacao([FromBody]CompraCotacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CompraCotacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCompraCotacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CompraCotacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCompraCotacao([FromBody]CompraCotacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CompraCotacao]", null));
                }

                _service.Update(objJson);

                return GetObjectCompraCotacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CompraCotacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCompraCotacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CompraCotacao]", ex));
            }
        }

    }
}