using Microsoft.AspNetCore.Mvc;
using compras.Models;
using compras.Services;

namespace compras.Controllers
{
    [Route("compra-tipo-pedido")]
    [Produces("application/json")]
    public class CompraTipoPedidoController : Controller
    {
		private readonly CompraTipoPedidoService _service;

        public CompraTipoPedidoController()
        {
            _service = new CompraTipoPedidoService();
        }

        [HttpGet]
        public IActionResult GetListCompraTipoPedido([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CompraTipoPedidoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CompraTipoPedido]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCompraTipoPedido")]
        public IActionResult GetObjectCompraTipoPedido(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CompraTipoPedido]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CompraTipoPedido]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCompraTipoPedido([FromBody]CompraTipoPedidoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CompraTipoPedido]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCompraTipoPedido", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CompraTipoPedido]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCompraTipoPedido([FromBody]CompraTipoPedidoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CompraTipoPedido]", null));
                }

                _service.Update(objJson);

                return GetObjectCompraTipoPedido(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CompraTipoPedido]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCompraTipoPedido(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CompraTipoPedido]", ex));
            }
        }

    }
}