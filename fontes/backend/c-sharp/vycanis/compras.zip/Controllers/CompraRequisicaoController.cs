using Microsoft.AspNetCore.Mvc;
using compras.Models;
using compras.Services;

namespace compras.Controllers
{
    [Route("compra-requisicao")]
    [Produces("application/json")]
    public class CompraRequisicaoController : Controller
    {
		private readonly CompraRequisicaoService _service;

        public CompraRequisicaoController()
        {
            _service = new CompraRequisicaoService();
        }

        [HttpGet]
        public IActionResult GetListCompraRequisicao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CompraRequisicaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CompraRequisicao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCompraRequisicao")]
        public IActionResult GetObjectCompraRequisicao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CompraRequisicao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CompraRequisicao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCompraRequisicao([FromBody]CompraRequisicaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CompraRequisicao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCompraRequisicao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CompraRequisicao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCompraRequisicao([FromBody]CompraRequisicaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CompraRequisicao]", null));
                }

                _service.Update(objJson);

                return GetObjectCompraRequisicao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CompraRequisicao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCompraRequisicao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CompraRequisicao]", ex));
            }
        }

    }
}