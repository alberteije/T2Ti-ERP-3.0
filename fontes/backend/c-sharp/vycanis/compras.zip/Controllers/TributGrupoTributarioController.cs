using Microsoft.AspNetCore.Mvc;
using compras.Models;
using compras.Services;

namespace compras.Controllers
{
    [Route("tribut-grupo-tributario")]
    [Produces("application/json")]
    public class TributGrupoTributarioController : Controller
    {
		private readonly TributGrupoTributarioService _service;

        public TributGrupoTributarioController()
        {
            _service = new TributGrupoTributarioService();
        }

        [HttpGet]
        public IActionResult GetListTributGrupoTributario([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TributGrupoTributarioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TributGrupoTributario]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTributGrupoTributario")]
        public IActionResult GetObjectTributGrupoTributario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TributGrupoTributario]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TributGrupoTributario]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTributGrupoTributario([FromBody]TributGrupoTributarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TributGrupoTributario]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTributGrupoTributario", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TributGrupoTributario]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTributGrupoTributario([FromBody]TributGrupoTributarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TributGrupoTributario]", null));
                }

                _service.Update(objJson);

                return GetObjectTributGrupoTributario(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TributGrupoTributario]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTributGrupoTributario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TributGrupoTributario]", ex));
            }
        }

    }
}