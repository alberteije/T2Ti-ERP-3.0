using Microsoft.AspNetCore.Mvc;
using compras.Models;
using compras.Services;

namespace compras.Controllers
{
    [Route("view-controle-acesso")]
    [Produces("application/json")]
    public class ViewControleAcessoController : Controller
    {
		private readonly ViewControleAcessoService _service;

        public ViewControleAcessoController()
        {
            _service = new ViewControleAcessoService();
        }

        [HttpGet]
        public IActionResult GetListViewControleAcesso([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ViewControleAcessoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ViewControleAcesso]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectViewControleAcesso")]
        public IActionResult GetObjectViewControleAcesso(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ViewControleAcesso]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ViewControleAcesso]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertViewControleAcesso([FromBody]ViewControleAcessoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ViewControleAcesso]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectViewControleAcesso", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ViewControleAcesso]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateViewControleAcesso([FromBody]ViewControleAcessoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ViewControleAcesso]", null));
                }

                _service.Update(objJson);

                return GetObjectViewControleAcesso(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ViewControleAcesso]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteViewControleAcesso(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ViewControleAcesso]", ex));
            }
        }

    }
}