namespace compras.Models
{
	public class ProdutoGrupoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

	}
}
