namespace compras.Models
{
	public class CompraRequisicaoModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.DateTime> DataRequisicao { get; set; } 

		public string? Observacao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public CompraTipoRequisicaoModel? CompraTipoRequisicaoModel { get; set; } 

		private IList<CompraRequisicaoDetalheModel>? compraRequisicaoDetalheModelList; 
		public IList<CompraRequisicaoDetalheModel>? CompraRequisicaoDetalheModelList 
		{ 
			get 
			{ 
				return compraRequisicaoDetalheModelList; 
			} 
			set 
			{ 
				compraRequisicaoDetalheModelList = value; 
				foreach (CompraRequisicaoDetalheModel compraRequisicaoDetalheModel in compraRequisicaoDetalheModelList!) 
				{ 
					compraRequisicaoDetalheModel.CompraRequisicaoModel = this; 
				} 
			} 
		} 

	}
}
