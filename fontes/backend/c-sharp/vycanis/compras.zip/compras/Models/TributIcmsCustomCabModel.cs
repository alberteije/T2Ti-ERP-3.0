namespace compras.Models
{
	public class TributIcmsCustomCabModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public string? OrigemMercadoria { get; set; } 

	}
}
