using ISession = NHibernate.ISession;
using compras.Models;
using compras.NHibernate;
using compras.Utils;

namespace compras.Services
{
    public class ViewPessoaUsuarioService
    {

        public IEnumerable<ViewPessoaUsuarioModel> GetList()
        {
            IList<ViewPessoaUsuarioModel>? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                Result = DAL.Select(new ViewPessoaUsuarioModel());
            }
            return Result;
        }

        public IEnumerable<ViewPessoaUsuarioModel> GetListFilter(Filter filterObj)
        {
            IList<ViewPessoaUsuarioModel>? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewPessoaUsuarioModel where " + filterObj.Where;
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                Result = DAL.SelectListSql<ViewPessoaUsuarioModel>(Query);
            }
            return Result;
        }
		
        public ViewPessoaUsuarioModel GetObject(int id)
        {
            ViewPessoaUsuarioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                Result = DAL.SelectId<ViewPessoaUsuarioModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewPessoaUsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewPessoaUsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewPessoaUsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }

        public ViewPessoaUsuarioModel? Autenticar(string login, string senha)
        {
            ViewPessoaUsuarioModel? Resultado = null;
            string consultaSql = "from ViewPessoaUsuarioModel where Login="
                + Util.QuotedStr(login)
                + " and Senha="
                + Util.QuotedStr(Util.MD5String(login + senha));
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaUsuarioModel> DAL = new NHibernateDAL<ViewPessoaUsuarioModel>(Session);
                Resultado = DAL.SelectObjSql<ViewPessoaUsuarioModel>(consultaSql);
            }
            return Resultado;
        }


    }

}