using compras.Models;
using compras.NHibernate;
using ISession = NHibernate.ISession;

namespace compras.Services
{
    public class CompraTipoRequisicaoService
    {

        public IEnumerable<CompraTipoRequisicaoModel> GetList()
        {
            IList<CompraTipoRequisicaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoRequisicaoModel> DAL = new NHibernateDAL<CompraTipoRequisicaoModel>(Session);
                Result = DAL.Select(new CompraTipoRequisicaoModel());
            }
            return Result;
        }

        public IEnumerable<CompraTipoRequisicaoModel> GetListFilter(Filter filterObj)
        {
            IList<CompraTipoRequisicaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CompraTipoRequisicaoModel where " + filterObj.Where;
                NHibernateDAL<CompraTipoRequisicaoModel> DAL = new NHibernateDAL<CompraTipoRequisicaoModel>(Session);
                Result = DAL.SelectListSql<CompraTipoRequisicaoModel>(Query);
            }
            return Result;
        }
		
        public CompraTipoRequisicaoModel GetObject(int id)
        {
            CompraTipoRequisicaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoRequisicaoModel> DAL = new NHibernateDAL<CompraTipoRequisicaoModel>(Session);
                Result = DAL.SelectId<CompraTipoRequisicaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CompraTipoRequisicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoRequisicaoModel> DAL = new NHibernateDAL<CompraTipoRequisicaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CompraTipoRequisicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoRequisicaoModel> DAL = new NHibernateDAL<CompraTipoRequisicaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CompraTipoRequisicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoRequisicaoModel> DAL = new NHibernateDAL<CompraTipoRequisicaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}