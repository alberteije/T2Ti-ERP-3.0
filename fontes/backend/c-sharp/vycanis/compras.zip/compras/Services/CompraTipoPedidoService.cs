using compras.Models;
using compras.NHibernate;
using ISession = NHibernate.ISession;

namespace compras.Services
{
    public class CompraTipoPedidoService
    {

        public IEnumerable<CompraTipoPedidoModel> GetList()
        {
            IList<CompraTipoPedidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoPedidoModel> DAL = new NHibernateDAL<CompraTipoPedidoModel>(Session);
                Result = DAL.Select(new CompraTipoPedidoModel());
            }
            return Result;
        }

        public IEnumerable<CompraTipoPedidoModel> GetListFilter(Filter filterObj)
        {
            IList<CompraTipoPedidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CompraTipoPedidoModel where " + filterObj.Where;
                NHibernateDAL<CompraTipoPedidoModel> DAL = new NHibernateDAL<CompraTipoPedidoModel>(Session);
                Result = DAL.SelectListSql<CompraTipoPedidoModel>(Query);
            }
            return Result;
        }
		
        public CompraTipoPedidoModel GetObject(int id)
        {
            CompraTipoPedidoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoPedidoModel> DAL = new NHibernateDAL<CompraTipoPedidoModel>(Session);
                Result = DAL.SelectId<CompraTipoPedidoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CompraTipoPedidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoPedidoModel> DAL = new NHibernateDAL<CompraTipoPedidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CompraTipoPedidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoPedidoModel> DAL = new NHibernateDAL<CompraTipoPedidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CompraTipoPedidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraTipoPedidoModel> DAL = new NHibernateDAL<CompraTipoPedidoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}