using compras.Models;
using compras.NHibernate;
using ISession = NHibernate.ISession;

namespace compras.Services
{
    public class ProdutoUnidadeService
    {

        public IEnumerable<ProdutoUnidadeModel> GetList()
        {
            IList<ProdutoUnidadeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoUnidadeModel> DAL = new NHibernateDAL<ProdutoUnidadeModel>(Session);
                Result = DAL.Select(new ProdutoUnidadeModel());
            }
            return Result;
        }

        public IEnumerable<ProdutoUnidadeModel> GetListFilter(Filter filterObj)
        {
            IList<ProdutoUnidadeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ProdutoUnidadeModel where " + filterObj.Where;
                NHibernateDAL<ProdutoUnidadeModel> DAL = new NHibernateDAL<ProdutoUnidadeModel>(Session);
                Result = DAL.SelectListSql<ProdutoUnidadeModel>(Query);
            }
            return Result;
        }
		
        public ProdutoUnidadeModel GetObject(int id)
        {
            ProdutoUnidadeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoUnidadeModel> DAL = new NHibernateDAL<ProdutoUnidadeModel>(Session);
                Result = DAL.SelectId<ProdutoUnidadeModel>(id);
            }
            return Result;
        }
		
        public void Insert(ProdutoUnidadeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoUnidadeModel> DAL = new NHibernateDAL<ProdutoUnidadeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ProdutoUnidadeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoUnidadeModel> DAL = new NHibernateDAL<ProdutoUnidadeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ProdutoUnidadeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoUnidadeModel> DAL = new NHibernateDAL<ProdutoUnidadeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}