using compras.Models;
using compras.NHibernate;
using ISession = NHibernate.ISession;

namespace compras.Services
{
    public class ProdutoGrupoService
    {

        public IEnumerable<ProdutoGrupoModel> GetList()
        {
            IList<ProdutoGrupoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoGrupoModel> DAL = new NHibernateDAL<ProdutoGrupoModel>(Session);
                Result = DAL.Select(new ProdutoGrupoModel());
            }
            return Result;
        }

        public IEnumerable<ProdutoGrupoModel> GetListFilter(Filter filterObj)
        {
            IList<ProdutoGrupoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ProdutoGrupoModel where " + filterObj.Where;
                NHibernateDAL<ProdutoGrupoModel> DAL = new NHibernateDAL<ProdutoGrupoModel>(Session);
                Result = DAL.SelectListSql<ProdutoGrupoModel>(Query);
            }
            return Result;
        }
		
        public ProdutoGrupoModel GetObject(int id)
        {
            ProdutoGrupoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoGrupoModel> DAL = new NHibernateDAL<ProdutoGrupoModel>(Session);
                Result = DAL.SelectId<ProdutoGrupoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ProdutoGrupoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoGrupoModel> DAL = new NHibernateDAL<ProdutoGrupoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ProdutoGrupoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoGrupoModel> DAL = new NHibernateDAL<ProdutoGrupoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ProdutoGrupoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoGrupoModel> DAL = new NHibernateDAL<ProdutoGrupoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}