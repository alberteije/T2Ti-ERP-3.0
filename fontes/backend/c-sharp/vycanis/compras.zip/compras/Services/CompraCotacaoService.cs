using compras.Models;
using compras.NHibernate;
using ISession = NHibernate.ISession;

namespace compras.Services
{
    public class CompraCotacaoService
    {

        public IEnumerable<CompraCotacaoModel> GetList()
        {
            IList<CompraCotacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraCotacaoModel> DAL = new NHibernateDAL<CompraCotacaoModel>(Session);
                Result = DAL.Select(new CompraCotacaoModel());
            }
            return Result;
        }

        public IEnumerable<CompraCotacaoModel> GetListFilter(Filter filterObj)
        {
            IList<CompraCotacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CompraCotacaoModel where " + filterObj.Where;
                NHibernateDAL<CompraCotacaoModel> DAL = new NHibernateDAL<CompraCotacaoModel>(Session);
                Result = DAL.SelectListSql<CompraCotacaoModel>(Query);
            }
            return Result;
        }
		
        public CompraCotacaoModel GetObject(int id)
        {
            CompraCotacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraCotacaoModel> DAL = new NHibernateDAL<CompraCotacaoModel>(Session);
                Result = DAL.SelectId<CompraCotacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CompraCotacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraCotacaoModel> DAL = new NHibernateDAL<CompraCotacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CompraCotacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraCotacaoModel> DAL = new NHibernateDAL<CompraCotacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CompraCotacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CompraCotacaoModel> DAL = new NHibernateDAL<CompraCotacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}