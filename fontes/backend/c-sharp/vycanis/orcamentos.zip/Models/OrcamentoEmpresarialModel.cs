namespace orcamentos.Models
{
	public class OrcamentoEmpresarialModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.DateTime> DataInicial { get; set; } 

		public int? NumeroPeriodos { get; set; } 

		public System.Nullable<System.DateTime> DataBase { get; set; } 

		public string? Descricao { get; set; } 

		public OrcamentoPeriodoModel? OrcamentoPeriodoModel { get; set; } 

		private IList<OrcamentoDetalheModel>? orcamentoDetalheModelList; 
		public IList<OrcamentoDetalheModel>? OrcamentoDetalheModelList 
		{ 
			get 
			{ 
				return orcamentoDetalheModelList; 
			} 
			set 
			{ 
				orcamentoDetalheModelList = value; 
				foreach (OrcamentoDetalheModel orcamentoDetalheModel in orcamentoDetalheModelList!) 
				{ 
					orcamentoDetalheModel.OrcamentoEmpresarialModel = this; 
				} 
			} 
		} 

	}
}
