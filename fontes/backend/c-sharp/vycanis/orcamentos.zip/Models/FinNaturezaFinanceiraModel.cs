namespace orcamentos.Models
{
	public class FinNaturezaFinanceiraModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Tipo { get; set; } 

		public string? Aplicacao { get; set; } 

	}
}
