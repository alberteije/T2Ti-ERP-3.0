namespace orcamentos.Models
{
	public class OrcamentoFluxoCaixaDetalheModel
	{	
		public int? Id { get; set; } 

		public string? Periodo { get; set; } 

		public System.Nullable<System.Decimal> ValorOrcado { get; set; } 

		public System.Nullable<System.Decimal> ValorRealizado { get; set; } 

		public System.Nullable<System.Decimal> TaxaVariacao { get; set; } 

		public System.Nullable<System.Decimal> ValorVariacao { get; set; } 

		public OrcamentoFluxoCaixaModel? OrcamentoFluxoCaixaModel { get; set; } 

		public FinNaturezaFinanceiraModel? FinNaturezaFinanceiraModel { get; set; } 

	}
}
