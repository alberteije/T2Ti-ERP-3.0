using orcamentos.Models;
using orcamentos.NHibernate;
using ISession = NHibernate.ISession;

namespace orcamentos.Services
{
    public class FinNaturezaFinanceiraService
    {

        public IEnumerable<FinNaturezaFinanceiraModel> GetList()
        {
            IList<FinNaturezaFinanceiraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinNaturezaFinanceiraModel> DAL = new NHibernateDAL<FinNaturezaFinanceiraModel>(Session);
                Result = DAL.Select(new FinNaturezaFinanceiraModel());
            }
            return Result;
        }

        public IEnumerable<FinNaturezaFinanceiraModel> GetListFilter(Filter filterObj)
        {
            IList<FinNaturezaFinanceiraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinNaturezaFinanceiraModel where " + filterObj.Where;
                NHibernateDAL<FinNaturezaFinanceiraModel> DAL = new NHibernateDAL<FinNaturezaFinanceiraModel>(Session);
                Result = DAL.SelectListSql<FinNaturezaFinanceiraModel>(Query);
            }
            return Result;
        }
		
        public FinNaturezaFinanceiraModel GetObject(int id)
        {
            FinNaturezaFinanceiraModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinNaturezaFinanceiraModel> DAL = new NHibernateDAL<FinNaturezaFinanceiraModel>(Session);
                Result = DAL.SelectId<FinNaturezaFinanceiraModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinNaturezaFinanceiraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinNaturezaFinanceiraModel> DAL = new NHibernateDAL<FinNaturezaFinanceiraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinNaturezaFinanceiraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinNaturezaFinanceiraModel> DAL = new NHibernateDAL<FinNaturezaFinanceiraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinNaturezaFinanceiraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinNaturezaFinanceiraModel> DAL = new NHibernateDAL<FinNaturezaFinanceiraModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}