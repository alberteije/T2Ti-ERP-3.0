using orcamentos.Models;
using orcamentos.NHibernate;
using ISession = NHibernate.ISession;

namespace orcamentos.Services
{
    public class OrcamentoPeriodoService
    {

        public IEnumerable<OrcamentoPeriodoModel> GetList()
        {
            IList<OrcamentoPeriodoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoPeriodoModel> DAL = new NHibernateDAL<OrcamentoPeriodoModel>(Session);
                Result = DAL.Select(new OrcamentoPeriodoModel());
            }
            return Result;
        }

        public IEnumerable<OrcamentoPeriodoModel> GetListFilter(Filter filterObj)
        {
            IList<OrcamentoPeriodoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OrcamentoPeriodoModel where " + filterObj.Where;
                NHibernateDAL<OrcamentoPeriodoModel> DAL = new NHibernateDAL<OrcamentoPeriodoModel>(Session);
                Result = DAL.SelectListSql<OrcamentoPeriodoModel>(Query);
            }
            return Result;
        }
		
        public OrcamentoPeriodoModel GetObject(int id)
        {
            OrcamentoPeriodoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoPeriodoModel> DAL = new NHibernateDAL<OrcamentoPeriodoModel>(Session);
                Result = DAL.SelectId<OrcamentoPeriodoModel>(id);
            }
            return Result;
        }
		
        public void Insert(OrcamentoPeriodoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoPeriodoModel> DAL = new NHibernateDAL<OrcamentoPeriodoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OrcamentoPeriodoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoPeriodoModel> DAL = new NHibernateDAL<OrcamentoPeriodoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OrcamentoPeriodoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoPeriodoModel> DAL = new NHibernateDAL<OrcamentoPeriodoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}