using Microsoft.AspNetCore.Mvc;
using orcamentos.Models;
using orcamentos.Services;

namespace orcamentos.Controllers
{
    [Route("orcamento-fluxo-caixa")]
    [Produces("application/json")]
    public class OrcamentoFluxoCaixaController : Controller
    {
		private readonly OrcamentoFluxoCaixaService _service;

        public OrcamentoFluxoCaixaController()
        {
            _service = new OrcamentoFluxoCaixaService();
        }

        [HttpGet]
        public IActionResult GetListOrcamentoFluxoCaixa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<OrcamentoFluxoCaixaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList OrcamentoFluxoCaixa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectOrcamentoFluxoCaixa")]
        public IActionResult GetObjectOrcamentoFluxoCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject OrcamentoFluxoCaixa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject OrcamentoFluxoCaixa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertOrcamentoFluxoCaixa([FromBody]OrcamentoFluxoCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert OrcamentoFluxoCaixa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectOrcamentoFluxoCaixa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert OrcamentoFluxoCaixa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateOrcamentoFluxoCaixa([FromBody]OrcamentoFluxoCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update OrcamentoFluxoCaixa]", null));
                }

                _service.Update(objJson);

                return GetObjectOrcamentoFluxoCaixa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update OrcamentoFluxoCaixa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOrcamentoFluxoCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete OrcamentoFluxoCaixa]", ex));
            }
        }

    }
}