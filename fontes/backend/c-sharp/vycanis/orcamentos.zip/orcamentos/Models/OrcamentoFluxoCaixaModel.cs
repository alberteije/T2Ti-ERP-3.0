namespace orcamentos.Models
{
	public class OrcamentoFluxoCaixaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.DateTime> DataInicial { get; set; } 

		public int? NumeroPeriodos { get; set; } 

		public System.Nullable<System.DateTime> DataBase { get; set; } 

		public string? Descricao { get; set; } 

		public OrcamentoFluxoCaixaPeriodoModel? OrcamentoFluxoCaixaPeriodoModel { get; set; } 

		private IList<OrcamentoFluxoCaixaDetalheModel>? orcamentoFluxoCaixaDetalheModelList; 
		public IList<OrcamentoFluxoCaixaDetalheModel>? OrcamentoFluxoCaixaDetalheModelList 
		{ 
			get 
			{ 
				return orcamentoFluxoCaixaDetalheModelList; 
			} 
			set 
			{ 
				orcamentoFluxoCaixaDetalheModelList = value; 
				foreach (OrcamentoFluxoCaixaDetalheModel orcamentoFluxoCaixaDetalheModel in orcamentoFluxoCaixaDetalheModelList!) 
				{ 
					orcamentoFluxoCaixaDetalheModel.OrcamentoFluxoCaixaModel = this; 
				} 
			} 
		} 

	}
}
