namespace orcamentos.Models
{
	public class OrcamentoDetalheModel
	{	
		public int? Id { get; set; } 

		public string? Periodo { get; set; } 

		public System.Nullable<System.Decimal> ValorOrcado { get; set; } 

		public System.Nullable<System.Decimal> ValorRealizado { get; set; } 

		public System.Nullable<System.Decimal> TaxaVariacao { get; set; } 

		public System.Nullable<System.Decimal> ValorVariacao { get; set; } 

		public OrcamentoEmpresarialModel? OrcamentoEmpresarialModel { get; set; } 

		public FinNaturezaFinanceiraModel? FinNaturezaFinanceiraModel { get; set; } 

	}
}
