namespace orcamentos.Models
{
	public class OrcamentoPeriodoModel
	{	
		public int? Id { get; set; } 

		public string? Periodo { get; set; } 

		public string? Nome { get; set; } 

	}
}
