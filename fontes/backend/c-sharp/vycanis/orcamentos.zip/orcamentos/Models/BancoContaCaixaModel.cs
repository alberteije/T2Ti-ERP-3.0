namespace orcamentos.Models
{
	public class BancoContaCaixaModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public string? Digito { get; set; } 

		public string? Nome { get; set; } 

		public string? Tipo { get; set; } 

		public string? Descricao { get; set; } 

	}
}
