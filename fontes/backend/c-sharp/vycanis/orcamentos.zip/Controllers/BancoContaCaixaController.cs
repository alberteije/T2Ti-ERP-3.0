using Microsoft.AspNetCore.Mvc;
using orcamentos.Models;
using orcamentos.Services;

namespace orcamentos.Controllers
{
    [Route("banco-conta-caixa")]
    [Produces("application/json")]
    public class BancoContaCaixaController : Controller
    {
		private readonly BancoContaCaixaService _service;

        public BancoContaCaixaController()
        {
            _service = new BancoContaCaixaService();
        }

        [HttpGet]
        public IActionResult GetListBancoContaCaixa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<BancoContaCaixaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList BancoContaCaixa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectBancoContaCaixa")]
        public IActionResult GetObjectBancoContaCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject BancoContaCaixa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject BancoContaCaixa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertBancoContaCaixa([FromBody]BancoContaCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert BancoContaCaixa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectBancoContaCaixa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert BancoContaCaixa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateBancoContaCaixa([FromBody]BancoContaCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update BancoContaCaixa]", null));
                }

                _service.Update(objJson);

                return GetObjectBancoContaCaixa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update BancoContaCaixa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBancoContaCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete BancoContaCaixa]", ex));
            }
        }

    }
}