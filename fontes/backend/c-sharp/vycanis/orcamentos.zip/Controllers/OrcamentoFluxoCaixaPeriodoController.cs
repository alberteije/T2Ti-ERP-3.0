using Microsoft.AspNetCore.Mvc;
using orcamentos.Models;
using orcamentos.Services;

namespace orcamentos.Controllers
{
    [Route("orcamento-fluxo-caixa-periodo")]
    [Produces("application/json")]
    public class OrcamentoFluxoCaixaPeriodoController : Controller
    {
		private readonly OrcamentoFluxoCaixaPeriodoService _service;

        public OrcamentoFluxoCaixaPeriodoController()
        {
            _service = new OrcamentoFluxoCaixaPeriodoService();
        }

        [HttpGet]
        public IActionResult GetListOrcamentoFluxoCaixaPeriodo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<OrcamentoFluxoCaixaPeriodoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList OrcamentoFluxoCaixaPeriodo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectOrcamentoFluxoCaixaPeriodo")]
        public IActionResult GetObjectOrcamentoFluxoCaixaPeriodo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject OrcamentoFluxoCaixaPeriodo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject OrcamentoFluxoCaixaPeriodo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertOrcamentoFluxoCaixaPeriodo([FromBody]OrcamentoFluxoCaixaPeriodoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert OrcamentoFluxoCaixaPeriodo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectOrcamentoFluxoCaixaPeriodo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert OrcamentoFluxoCaixaPeriodo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateOrcamentoFluxoCaixaPeriodo([FromBody]OrcamentoFluxoCaixaPeriodoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update OrcamentoFluxoCaixaPeriodo]", null));
                }

                _service.Update(objJson);

                return GetObjectOrcamentoFluxoCaixaPeriodo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update OrcamentoFluxoCaixaPeriodo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOrcamentoFluxoCaixaPeriodo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete OrcamentoFluxoCaixaPeriodo]", ex));
            }
        }

    }
}