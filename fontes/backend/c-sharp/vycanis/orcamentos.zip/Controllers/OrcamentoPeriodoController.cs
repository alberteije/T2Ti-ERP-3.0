using Microsoft.AspNetCore.Mvc;
using orcamentos.Models;
using orcamentos.Services;

namespace orcamentos.Controllers
{
    [Route("orcamento-periodo")]
    [Produces("application/json")]
    public class OrcamentoPeriodoController : Controller
    {
		private readonly OrcamentoPeriodoService _service;

        public OrcamentoPeriodoController()
        {
            _service = new OrcamentoPeriodoService();
        }

        [HttpGet]
        public IActionResult GetListOrcamentoPeriodo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<OrcamentoPeriodoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList OrcamentoPeriodo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectOrcamentoPeriodo")]
        public IActionResult GetObjectOrcamentoPeriodo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject OrcamentoPeriodo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject OrcamentoPeriodo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertOrcamentoPeriodo([FromBody]OrcamentoPeriodoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert OrcamentoPeriodo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectOrcamentoPeriodo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert OrcamentoPeriodo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateOrcamentoPeriodo([FromBody]OrcamentoPeriodoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update OrcamentoPeriodo]", null));
                }

                _service.Update(objJson);

                return GetObjectOrcamentoPeriodo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update OrcamentoPeriodo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOrcamentoPeriodo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete OrcamentoPeriodo]", ex));
            }
        }

    }
}