using orcamentos.Models;
using orcamentos.NHibernate;
using ISession = NHibernate.ISession;

namespace orcamentos.Services
{
    public class BancoContaCaixaService
    {

        public IEnumerable<BancoContaCaixaModel> GetList()
        {
            IList<BancoContaCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoContaCaixaModel> DAL = new NHibernateDAL<BancoContaCaixaModel>(Session);
                Result = DAL.Select(new BancoContaCaixaModel());
            }
            return Result;
        }

        public IEnumerable<BancoContaCaixaModel> GetListFilter(Filter filterObj)
        {
            IList<BancoContaCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from BancoContaCaixaModel where " + filterObj.Where;
                NHibernateDAL<BancoContaCaixaModel> DAL = new NHibernateDAL<BancoContaCaixaModel>(Session);
                Result = DAL.SelectListSql<BancoContaCaixaModel>(Query);
            }
            return Result;
        }
		
        public BancoContaCaixaModel GetObject(int id)
        {
            BancoContaCaixaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoContaCaixaModel> DAL = new NHibernateDAL<BancoContaCaixaModel>(Session);
                Result = DAL.SelectId<BancoContaCaixaModel>(id);
            }
            return Result;
        }
		
        public void Insert(BancoContaCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoContaCaixaModel> DAL = new NHibernateDAL<BancoContaCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(BancoContaCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoContaCaixaModel> DAL = new NHibernateDAL<BancoContaCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(BancoContaCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoContaCaixaModel> DAL = new NHibernateDAL<BancoContaCaixaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}