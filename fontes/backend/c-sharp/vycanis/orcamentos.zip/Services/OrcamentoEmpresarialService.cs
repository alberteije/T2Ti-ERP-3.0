using orcamentos.Models;
using orcamentos.NHibernate;
using ISession = NHibernate.ISession;

namespace orcamentos.Services
{
    public class OrcamentoEmpresarialService
    {

        public IEnumerable<OrcamentoEmpresarialModel> GetList()
        {
            IList<OrcamentoEmpresarialModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoEmpresarialModel> DAL = new NHibernateDAL<OrcamentoEmpresarialModel>(Session);
                Result = DAL.Select(new OrcamentoEmpresarialModel());
            }
            return Result;
        }

        public IEnumerable<OrcamentoEmpresarialModel> GetListFilter(Filter filterObj)
        {
            IList<OrcamentoEmpresarialModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OrcamentoEmpresarialModel where " + filterObj.Where;
                NHibernateDAL<OrcamentoEmpresarialModel> DAL = new NHibernateDAL<OrcamentoEmpresarialModel>(Session);
                Result = DAL.SelectListSql<OrcamentoEmpresarialModel>(Query);
            }
            return Result;
        }
		
        public OrcamentoEmpresarialModel GetObject(int id)
        {
            OrcamentoEmpresarialModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoEmpresarialModel> DAL = new NHibernateDAL<OrcamentoEmpresarialModel>(Session);
                Result = DAL.SelectId<OrcamentoEmpresarialModel>(id);
            }
            return Result;
        }
		
        public void Insert(OrcamentoEmpresarialModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoEmpresarialModel> DAL = new NHibernateDAL<OrcamentoEmpresarialModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OrcamentoEmpresarialModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoEmpresarialModel> DAL = new NHibernateDAL<OrcamentoEmpresarialModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OrcamentoEmpresarialModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoEmpresarialModel> DAL = new NHibernateDAL<OrcamentoEmpresarialModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}