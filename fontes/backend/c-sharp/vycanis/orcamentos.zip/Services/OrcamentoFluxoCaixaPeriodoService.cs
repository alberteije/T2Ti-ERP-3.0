using orcamentos.Models;
using orcamentos.NHibernate;
using ISession = NHibernate.ISession;

namespace orcamentos.Services
{
    public class OrcamentoFluxoCaixaPeriodoService
    {

        public IEnumerable<OrcamentoFluxoCaixaPeriodoModel> GetList()
        {
            IList<OrcamentoFluxoCaixaPeriodoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel>(Session);
                Result = DAL.Select(new OrcamentoFluxoCaixaPeriodoModel());
            }
            return Result;
        }

        public IEnumerable<OrcamentoFluxoCaixaPeriodoModel> GetListFilter(Filter filterObj)
        {
            IList<OrcamentoFluxoCaixaPeriodoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OrcamentoFluxoCaixaPeriodoModel where " + filterObj.Where;
                NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel>(Session);
                Result = DAL.SelectListSql<OrcamentoFluxoCaixaPeriodoModel>(Query);
            }
            return Result;
        }
		
        public OrcamentoFluxoCaixaPeriodoModel GetObject(int id)
        {
            OrcamentoFluxoCaixaPeriodoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel>(Session);
                Result = DAL.SelectId<OrcamentoFluxoCaixaPeriodoModel>(id);
            }
            return Result;
        }
		
        public void Insert(OrcamentoFluxoCaixaPeriodoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OrcamentoFluxoCaixaPeriodoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OrcamentoFluxoCaixaPeriodoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaPeriodoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}