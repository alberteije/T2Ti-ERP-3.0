using orcamentos.Models;
using orcamentos.NHibernate;
using ISession = NHibernate.ISession;

namespace orcamentos.Services
{
    public class OrcamentoFluxoCaixaService
    {

        public IEnumerable<OrcamentoFluxoCaixaModel> GetList()
        {
            IList<OrcamentoFluxoCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaModel>(Session);
                Result = DAL.Select(new OrcamentoFluxoCaixaModel());
            }
            return Result;
        }

        public IEnumerable<OrcamentoFluxoCaixaModel> GetListFilter(Filter filterObj)
        {
            IList<OrcamentoFluxoCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OrcamentoFluxoCaixaModel where " + filterObj.Where;
                NHibernateDAL<OrcamentoFluxoCaixaModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaModel>(Session);
                Result = DAL.SelectListSql<OrcamentoFluxoCaixaModel>(Query);
            }
            return Result;
        }
		
        public OrcamentoFluxoCaixaModel GetObject(int id)
        {
            OrcamentoFluxoCaixaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaModel>(Session);
                Result = DAL.SelectId<OrcamentoFluxoCaixaModel>(id);
            }
            return Result;
        }
		
        public void Insert(OrcamentoFluxoCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OrcamentoFluxoCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OrcamentoFluxoCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OrcamentoFluxoCaixaModel> DAL = new NHibernateDAL<OrcamentoFluxoCaixaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}