﻿using NHibernate;
using NHibernate.Cfg;

namespace crm.NHibernate
{
    public class NHibernateHelper
    {
        private static ISessionFactory? SessionFactory;

        public static ISessionFactory GetSessionFactory()
        {
            try
            {
                if (SessionFactory == null)
                {
                    lock(typeof (NHibernateHelper))
                    {
                        Configuration config = new Configuration();
                        config.Configure();
                        config.AddAssembly("crm");
                        SessionFactory = config.BuildSessionFactory();
                    }
                }
                return SessionFactory;
            }
            catch
            {
                throw;
            }
        }
    }
}
