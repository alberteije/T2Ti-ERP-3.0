using crm.Models;
using crm.NHibernate;
using ISession = NHibernate.ISession;

namespace crm.Services
{
    public class CrmContatoService
    {

        public IEnumerable<CrmContatoModel> GetList()
        {
            IList<CrmContatoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmContatoModel> DAL = new NHibernateDAL<CrmContatoModel>(Session);
                Result = DAL.Select(new CrmContatoModel());
            }
            return Result;
        }

        public IEnumerable<CrmContatoModel> GetListFilter(Filter filterObj)
        {
            IList<CrmContatoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CrmContatoModel where " + filterObj.Where;
                NHibernateDAL<CrmContatoModel> DAL = new NHibernateDAL<CrmContatoModel>(Session);
                Result = DAL.SelectListSql<CrmContatoModel>(Query);
            }
            return Result;
        }
		
        public CrmContatoModel GetObject(int id)
        {
            CrmContatoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmContatoModel> DAL = new NHibernateDAL<CrmContatoModel>(Session);
                Result = DAL.SelectId<CrmContatoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CrmContatoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmContatoModel> DAL = new NHibernateDAL<CrmContatoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CrmContatoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmContatoModel> DAL = new NHibernateDAL<CrmContatoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CrmContatoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmContatoModel> DAL = new NHibernateDAL<CrmContatoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}