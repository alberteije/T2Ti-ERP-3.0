using crm.Models;
using crm.NHibernate;
using ISession = NHibernate.ISession;

namespace crm.Services
{
    public class CrmTarefaService
    {

        public IEnumerable<CrmTarefaModel> GetList()
        {
            IList<CrmTarefaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmTarefaModel> DAL = new NHibernateDAL<CrmTarefaModel>(Session);
                Result = DAL.Select(new CrmTarefaModel());
            }
            return Result;
        }

        public IEnumerable<CrmTarefaModel> GetListFilter(Filter filterObj)
        {
            IList<CrmTarefaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CrmTarefaModel where " + filterObj.Where;
                NHibernateDAL<CrmTarefaModel> DAL = new NHibernateDAL<CrmTarefaModel>(Session);
                Result = DAL.SelectListSql<CrmTarefaModel>(Query);
            }
            return Result;
        }
		
        public CrmTarefaModel GetObject(int id)
        {
            CrmTarefaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmTarefaModel> DAL = new NHibernateDAL<CrmTarefaModel>(Session);
                Result = DAL.SelectId<CrmTarefaModel>(id);
            }
            return Result;
        }
		
        public void Insert(CrmTarefaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmTarefaModel> DAL = new NHibernateDAL<CrmTarefaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CrmTarefaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmTarefaModel> DAL = new NHibernateDAL<CrmTarefaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CrmTarefaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmTarefaModel> DAL = new NHibernateDAL<CrmTarefaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}