using crm.Models;
using crm.NHibernate;
using ISession = NHibernate.ISession;

namespace crm.Services
{
    public class CrmSacCabecalhoService
    {

        public IEnumerable<CrmSacCabecalhoModel> GetList()
        {
            IList<CrmSacCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmSacCabecalhoModel> DAL = new NHibernateDAL<CrmSacCabecalhoModel>(Session);
                Result = DAL.Select(new CrmSacCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<CrmSacCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<CrmSacCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CrmSacCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<CrmSacCabecalhoModel> DAL = new NHibernateDAL<CrmSacCabecalhoModel>(Session);
                Result = DAL.SelectListSql<CrmSacCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public CrmSacCabecalhoModel GetObject(int id)
        {
            CrmSacCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmSacCabecalhoModel> DAL = new NHibernateDAL<CrmSacCabecalhoModel>(Session);
                Result = DAL.SelectId<CrmSacCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CrmSacCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmSacCabecalhoModel> DAL = new NHibernateDAL<CrmSacCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CrmSacCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmSacCabecalhoModel> DAL = new NHibernateDAL<CrmSacCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CrmSacCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmSacCabecalhoModel> DAL = new NHibernateDAL<CrmSacCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}