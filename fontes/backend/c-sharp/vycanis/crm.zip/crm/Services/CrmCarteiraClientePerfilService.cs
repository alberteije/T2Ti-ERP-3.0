using crm.Models;
using crm.NHibernate;
using ISession = NHibernate.ISession;

namespace crm.Services
{
    public class CrmCarteiraClientePerfilService
    {

        public IEnumerable<CrmCarteiraClientePerfilModel> GetList()
        {
            IList<CrmCarteiraClientePerfilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCarteiraClientePerfilModel> DAL = new NHibernateDAL<CrmCarteiraClientePerfilModel>(Session);
                Result = DAL.Select(new CrmCarteiraClientePerfilModel());
            }
            return Result;
        }

        public IEnumerable<CrmCarteiraClientePerfilModel> GetListFilter(Filter filterObj)
        {
            IList<CrmCarteiraClientePerfilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CrmCarteiraClientePerfilModel where " + filterObj.Where;
                NHibernateDAL<CrmCarteiraClientePerfilModel> DAL = new NHibernateDAL<CrmCarteiraClientePerfilModel>(Session);
                Result = DAL.SelectListSql<CrmCarteiraClientePerfilModel>(Query);
            }
            return Result;
        }
		
        public CrmCarteiraClientePerfilModel GetObject(int id)
        {
            CrmCarteiraClientePerfilModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCarteiraClientePerfilModel> DAL = new NHibernateDAL<CrmCarteiraClientePerfilModel>(Session);
                Result = DAL.SelectId<CrmCarteiraClientePerfilModel>(id);
            }
            return Result;
        }
		
        public void Insert(CrmCarteiraClientePerfilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCarteiraClientePerfilModel> DAL = new NHibernateDAL<CrmCarteiraClientePerfilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CrmCarteiraClientePerfilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCarteiraClientePerfilModel> DAL = new NHibernateDAL<CrmCarteiraClientePerfilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CrmCarteiraClientePerfilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCarteiraClientePerfilModel> DAL = new NHibernateDAL<CrmCarteiraClientePerfilModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}