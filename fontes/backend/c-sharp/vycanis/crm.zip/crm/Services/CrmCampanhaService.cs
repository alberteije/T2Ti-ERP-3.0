using crm.Models;
using crm.NHibernate;
using ISession = NHibernate.ISession;

namespace crm.Services
{
    public class CrmCampanhaService
    {

        public IEnumerable<CrmCampanhaModel> GetList()
        {
            IList<CrmCampanhaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCampanhaModel> DAL = new NHibernateDAL<CrmCampanhaModel>(Session);
                Result = DAL.Select(new CrmCampanhaModel());
            }
            return Result;
        }

        public IEnumerable<CrmCampanhaModel> GetListFilter(Filter filterObj)
        {
            IList<CrmCampanhaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CrmCampanhaModel where " + filterObj.Where;
                NHibernateDAL<CrmCampanhaModel> DAL = new NHibernateDAL<CrmCampanhaModel>(Session);
                Result = DAL.SelectListSql<CrmCampanhaModel>(Query);
            }
            return Result;
        }
		
        public CrmCampanhaModel GetObject(int id)
        {
            CrmCampanhaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCampanhaModel> DAL = new NHibernateDAL<CrmCampanhaModel>(Session);
                Result = DAL.SelectId<CrmCampanhaModel>(id);
            }
            return Result;
        }
		
        public void Insert(CrmCampanhaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCampanhaModel> DAL = new NHibernateDAL<CrmCampanhaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CrmCampanhaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCampanhaModel> DAL = new NHibernateDAL<CrmCampanhaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CrmCampanhaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmCampanhaModel> DAL = new NHibernateDAL<CrmCampanhaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}