using crm.Models;
using crm.NHibernate;
using ISession = NHibernate.ISession;

namespace crm.Services
{
    public class CrmOportunidadeService
    {

        public IEnumerable<CrmOportunidadeModel> GetList()
        {
            IList<CrmOportunidadeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmOportunidadeModel> DAL = new NHibernateDAL<CrmOportunidadeModel>(Session);
                Result = DAL.Select(new CrmOportunidadeModel());
            }
            return Result;
        }

        public IEnumerable<CrmOportunidadeModel> GetListFilter(Filter filterObj)
        {
            IList<CrmOportunidadeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CrmOportunidadeModel where " + filterObj.Where;
                NHibernateDAL<CrmOportunidadeModel> DAL = new NHibernateDAL<CrmOportunidadeModel>(Session);
                Result = DAL.SelectListSql<CrmOportunidadeModel>(Query);
            }
            return Result;
        }
		
        public CrmOportunidadeModel GetObject(int id)
        {
            CrmOportunidadeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmOportunidadeModel> DAL = new NHibernateDAL<CrmOportunidadeModel>(Session);
                Result = DAL.SelectId<CrmOportunidadeModel>(id);
            }
            return Result;
        }
		
        public void Insert(CrmOportunidadeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmOportunidadeModel> DAL = new NHibernateDAL<CrmOportunidadeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CrmOportunidadeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmOportunidadeModel> DAL = new NHibernateDAL<CrmOportunidadeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CrmOportunidadeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmOportunidadeModel> DAL = new NHibernateDAL<CrmOportunidadeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}