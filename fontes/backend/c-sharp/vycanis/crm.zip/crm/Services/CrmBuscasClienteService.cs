using crm.Models;
using crm.NHibernate;
using ISession = NHibernate.ISession;

namespace crm.Services
{
    public class CrmBuscasClienteService
    {

        public IEnumerable<CrmBuscasClienteModel> GetList()
        {
            IList<CrmBuscasClienteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmBuscasClienteModel> DAL = new NHibernateDAL<CrmBuscasClienteModel>(Session);
                Result = DAL.Select(new CrmBuscasClienteModel());
            }
            return Result;
        }

        public IEnumerable<CrmBuscasClienteModel> GetListFilter(Filter filterObj)
        {
            IList<CrmBuscasClienteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CrmBuscasClienteModel where " + filterObj.Where;
                NHibernateDAL<CrmBuscasClienteModel> DAL = new NHibernateDAL<CrmBuscasClienteModel>(Session);
                Result = DAL.SelectListSql<CrmBuscasClienteModel>(Query);
            }
            return Result;
        }
		
        public CrmBuscasClienteModel GetObject(int id)
        {
            CrmBuscasClienteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmBuscasClienteModel> DAL = new NHibernateDAL<CrmBuscasClienteModel>(Session);
                Result = DAL.SelectId<CrmBuscasClienteModel>(id);
            }
            return Result;
        }
		
        public void Insert(CrmBuscasClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmBuscasClienteModel> DAL = new NHibernateDAL<CrmBuscasClienteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CrmBuscasClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmBuscasClienteModel> DAL = new NHibernateDAL<CrmBuscasClienteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CrmBuscasClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CrmBuscasClienteModel> DAL = new NHibernateDAL<CrmBuscasClienteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}