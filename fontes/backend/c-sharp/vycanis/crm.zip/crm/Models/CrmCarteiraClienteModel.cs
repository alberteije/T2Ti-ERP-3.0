namespace crm.Models
{
	public class CrmCarteiraClienteModel
	{	
		public int? Id { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public CrmCarteiraClientePerfilModel? CrmCarteiraClientePerfilModel { get; set; } 

	}
}
