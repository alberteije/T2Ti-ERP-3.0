namespace crm.Models
{
	public class CrmContatoModel
	{	
		public int? Id { get; set; } 

		public string? TipoContato { get; set; } 

		public string? HoraContato { get; set; } 

		public string? Assunto { get; set; } 

		public string? Descricao { get; set; } 

		public string? Resultado { get; set; } 

		public System.Nullable<System.DateTime> ProximaData { get; set; } 

		public string? ProximaAcao { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
