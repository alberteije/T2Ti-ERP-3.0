namespace crm.Models
{
	public class CrmOportunidadeModel
	{	
		public int? Id { get; set; } 

		public string? Titulo { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.Decimal> ValorEstimado { get; set; } 

		public System.Nullable<System.DateTime> DataAbertura { get; set; } 

		public System.Nullable<System.DateTime> DataFechamentoPrevisto { get; set; } 

		public System.Nullable<System.DateTime> DataFechamentoReal { get; set; } 

		public string? Status { get; set; } 

		public string? MotivoFechamento { get; set; } 

		public int? Probabilidade { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
