namespace crm.Models
{
	public class CrmSacCabecalhoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataAbertura { get; set; } 

		public string? HoraAbertura { get; set; } 

		public string? NivelReclamacao { get; set; } 

		public string? NumeroProtocolo { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		private IList<CrmSacDetalheModel>? crmSacDetalheModelList; 
		public IList<CrmSacDetalheModel>? CrmSacDetalheModelList 
		{ 
			get 
			{ 
				return crmSacDetalheModelList; 
			} 
			set 
			{ 
				crmSacDetalheModelList = value; 
				foreach (CrmSacDetalheModel crmSacDetalheModel in crmSacDetalheModelList!) 
				{ 
					crmSacDetalheModel.CrmSacCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
