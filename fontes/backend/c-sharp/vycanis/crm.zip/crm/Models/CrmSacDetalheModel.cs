namespace crm.Models
{
	public class CrmSacDetalheModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataRegistro { get; set; } 

		public string? HoraRegistro { get; set; } 

		public string? Historico { get; set; } 

		public CrmSacCabecalhoModel? CrmSacCabecalhoModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
