namespace crm.Models
{
	public class CrmTarefaModel
	{	
		public int? Id { get; set; } 

		public string? Titulo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Prioridade { get; set; } 

		public System.Nullable<System.DateTime> DataCriacao { get; set; } 

		public System.Nullable<System.DateTime> DataVencimento { get; set; } 

		public System.Nullable<System.DateTime> DataConclusao { get; set; } 

		public string? Status { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public CrmOportunidadeModel? CrmOportunidadeModel { get; set; } 

	}
}
