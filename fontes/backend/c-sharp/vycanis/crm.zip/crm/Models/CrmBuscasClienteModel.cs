namespace crm.Models
{
	public class CrmBuscasClienteModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataBusca { get; set; } 

		public string? HoraBusca { get; set; } 

		public string? Detalhes { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

	}
}
