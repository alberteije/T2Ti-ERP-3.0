namespace crm.Models
{
	public class CrmCampanhaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public string? Tipo { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public System.Nullable<System.Decimal> Orcamento { get; set; } 

		public string? Status { get; set; } 

		private IList<CrmCampanhaClienteModel>? crmCampanhaClienteModelList; 
		public IList<CrmCampanhaClienteModel>? CrmCampanhaClienteModelList 
		{ 
			get 
			{ 
				return crmCampanhaClienteModelList; 
			} 
			set 
			{ 
				crmCampanhaClienteModelList = value; 
				foreach (CrmCampanhaClienteModel crmCampanhaClienteModel in crmCampanhaClienteModelList!) 
				{ 
					crmCampanhaClienteModel.CrmCampanhaModel = this; 
				} 
			} 
		} 

	}
}
