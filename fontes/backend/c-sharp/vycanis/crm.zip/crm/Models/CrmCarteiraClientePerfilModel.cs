namespace crm.Models
{
	public class CrmCarteiraClientePerfilModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		private IList<CrmCarteiraClienteModel>? crmCarteiraClienteModelList; 
		public IList<CrmCarteiraClienteModel>? CrmCarteiraClienteModelList 
		{ 
			get 
			{ 
				return crmCarteiraClienteModelList; 
			} 
			set 
			{ 
				crmCarteiraClienteModelList = value; 
				foreach (CrmCarteiraClienteModel crmCarteiraClienteModel in crmCarteiraClienteModelList!) 
				{ 
					crmCarteiraClienteModel.CrmCarteiraClientePerfilModel = this; 
				} 
			} 
		} 

	}
}
