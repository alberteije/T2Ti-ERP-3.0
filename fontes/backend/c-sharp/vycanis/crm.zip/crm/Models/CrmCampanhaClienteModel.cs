namespace crm.Models
{
	public class CrmCampanhaClienteModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInscricao { get; set; } 

		public string? Status { get; set; } 

		public string? Observacoes { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public CrmCampanhaModel? CrmCampanhaModel { get; set; } 

	}
}
