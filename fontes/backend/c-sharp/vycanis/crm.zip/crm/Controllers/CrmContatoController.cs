using Microsoft.AspNetCore.Mvc;
using crm.Models;
using crm.Services;

namespace crm.Controllers
{
    [Route("crm-contato")]
    [Produces("application/json")]
    public class CrmContatoController : Controller
    {
		private readonly CrmContatoService _service;

        public CrmContatoController()
        {
            _service = new CrmContatoService();
        }

        [HttpGet]
        public IActionResult GetListCrmContato([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CrmContatoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CrmContato]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCrmContato")]
        public IActionResult GetObjectCrmContato(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CrmContato]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CrmContato]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCrmContato([FromBody]CrmContatoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CrmContato]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCrmContato", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CrmContato]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCrmContato([FromBody]CrmContatoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CrmContato]", null));
                }

                _service.Update(objJson);

                return GetObjectCrmContato(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CrmContato]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCrmContato(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CrmContato]", ex));
            }
        }

    }
}