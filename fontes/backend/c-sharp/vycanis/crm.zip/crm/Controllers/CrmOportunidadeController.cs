using Microsoft.AspNetCore.Mvc;
using crm.Models;
using crm.Services;

namespace crm.Controllers
{
    [Route("crm-oportunidade")]
    [Produces("application/json")]
    public class CrmOportunidadeController : Controller
    {
		private readonly CrmOportunidadeService _service;

        public CrmOportunidadeController()
        {
            _service = new CrmOportunidadeService();
        }

        [HttpGet]
        public IActionResult GetListCrmOportunidade([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CrmOportunidadeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CrmOportunidade]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCrmOportunidade")]
        public IActionResult GetObjectCrmOportunidade(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CrmOportunidade]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CrmOportunidade]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCrmOportunidade([FromBody]CrmOportunidadeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CrmOportunidade]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCrmOportunidade", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CrmOportunidade]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCrmOportunidade([FromBody]CrmOportunidadeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CrmOportunidade]", null));
                }

                _service.Update(objJson);

                return GetObjectCrmOportunidade(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CrmOportunidade]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCrmOportunidade(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CrmOportunidade]", ex));
            }
        }

    }
}