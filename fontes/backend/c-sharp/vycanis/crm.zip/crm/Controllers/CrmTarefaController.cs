using Microsoft.AspNetCore.Mvc;
using crm.Models;
using crm.Services;

namespace crm.Controllers
{
    [Route("crm-tarefa")]
    [Produces("application/json")]
    public class CrmTarefaController : Controller
    {
		private readonly CrmTarefaService _service;

        public CrmTarefaController()
        {
            _service = new CrmTarefaService();
        }

        [HttpGet]
        public IActionResult GetListCrmTarefa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CrmTarefaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CrmTarefa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCrmTarefa")]
        public IActionResult GetObjectCrmTarefa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CrmTarefa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CrmTarefa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCrmTarefa([FromBody]CrmTarefaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CrmTarefa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCrmTarefa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CrmTarefa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCrmTarefa([FromBody]CrmTarefaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CrmTarefa]", null));
                }

                _service.Update(objJson);

                return GetObjectCrmTarefa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CrmTarefa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCrmTarefa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CrmTarefa]", ex));
            }
        }

    }
}