using Microsoft.AspNetCore.Mvc;
using crm.Models;
using crm.Services;

namespace crm.Controllers
{
    [Route("crm-carteira-cliente-perfil")]
    [Produces("application/json")]
    public class CrmCarteiraClientePerfilController : Controller
    {
		private readonly CrmCarteiraClientePerfilService _service;

        public CrmCarteiraClientePerfilController()
        {
            _service = new CrmCarteiraClientePerfilService();
        }

        [HttpGet]
        public IActionResult GetListCrmCarteiraClientePerfil([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CrmCarteiraClientePerfilModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CrmCarteiraClientePerfil]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCrmCarteiraClientePerfil")]
        public IActionResult GetObjectCrmCarteiraClientePerfil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CrmCarteiraClientePerfil]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CrmCarteiraClientePerfil]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCrmCarteiraClientePerfil([FromBody]CrmCarteiraClientePerfilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CrmCarteiraClientePerfil]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCrmCarteiraClientePerfil", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CrmCarteiraClientePerfil]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCrmCarteiraClientePerfil([FromBody]CrmCarteiraClientePerfilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CrmCarteiraClientePerfil]", null));
                }

                _service.Update(objJson);

                return GetObjectCrmCarteiraClientePerfil(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CrmCarteiraClientePerfil]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCrmCarteiraClientePerfil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CrmCarteiraClientePerfil]", ex));
            }
        }

    }
}