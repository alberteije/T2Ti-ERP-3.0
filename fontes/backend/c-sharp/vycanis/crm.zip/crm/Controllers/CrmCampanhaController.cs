using Microsoft.AspNetCore.Mvc;
using crm.Models;
using crm.Services;

namespace crm.Controllers
{
    [Route("crm-campanha")]
    [Produces("application/json")]
    public class CrmCampanhaController : Controller
    {
		private readonly CrmCampanhaService _service;

        public CrmCampanhaController()
        {
            _service = new CrmCampanhaService();
        }

        [HttpGet]
        public IActionResult GetListCrmCampanha([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CrmCampanhaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CrmCampanha]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCrmCampanha")]
        public IActionResult GetObjectCrmCampanha(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CrmCampanha]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CrmCampanha]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCrmCampanha([FromBody]CrmCampanhaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CrmCampanha]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCrmCampanha", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CrmCampanha]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCrmCampanha([FromBody]CrmCampanhaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CrmCampanha]", null));
                }

                _service.Update(objJson);

                return GetObjectCrmCampanha(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CrmCampanha]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCrmCampanha(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CrmCampanha]", ex));
            }
        }

    }
}