using Microsoft.AspNetCore.Mvc;
using crm.Models;
using crm.Services;

namespace crm.Controllers
{
    [Route("crm-sac-cabecalho")]
    [Produces("application/json")]
    public class CrmSacCabecalhoController : Controller
    {
		private readonly CrmSacCabecalhoService _service;

        public CrmSacCabecalhoController()
        {
            _service = new CrmSacCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListCrmSacCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CrmSacCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CrmSacCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCrmSacCabecalho")]
        public IActionResult GetObjectCrmSacCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CrmSacCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CrmSacCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCrmSacCabecalho([FromBody]CrmSacCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CrmSacCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCrmSacCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CrmSacCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCrmSacCabecalho([FromBody]CrmSacCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CrmSacCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectCrmSacCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CrmSacCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCrmSacCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CrmSacCabecalho]", ex));
            }
        }

    }
}