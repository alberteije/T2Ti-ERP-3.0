using Microsoft.AspNetCore.Mvc;
using crm.Models;
using crm.Services;

namespace crm.Controllers
{
    [Route("crm-buscas-cliente")]
    [Produces("application/json")]
    public class CrmBuscasClienteController : Controller
    {
		private readonly CrmBuscasClienteService _service;

        public CrmBuscasClienteController()
        {
            _service = new CrmBuscasClienteService();
        }

        [HttpGet]
        public IActionResult GetListCrmBuscasCliente([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CrmBuscasClienteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CrmBuscasCliente]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCrmBuscasCliente")]
        public IActionResult GetObjectCrmBuscasCliente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CrmBuscasCliente]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CrmBuscasCliente]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCrmBuscasCliente([FromBody]CrmBuscasClienteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CrmBuscasCliente]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCrmBuscasCliente", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CrmBuscasCliente]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCrmBuscasCliente([FromBody]CrmBuscasClienteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CrmBuscasCliente]", null));
                }

                _service.Update(objJson);

                return GetObjectCrmBuscasCliente(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CrmBuscasCliente]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCrmBuscasCliente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CrmBuscasCliente]", ex));
            }
        }

    }
}