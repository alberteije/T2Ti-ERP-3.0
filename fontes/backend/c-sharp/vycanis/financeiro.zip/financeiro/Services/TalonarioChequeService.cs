using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class TalonarioChequeService
    {

        public IEnumerable<TalonarioChequeModel> GetList()
        {
            IList<TalonarioChequeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TalonarioChequeModel> DAL = new NHibernateDAL<TalonarioChequeModel>(Session);
                Result = DAL.Select(new TalonarioChequeModel());
            }
            return Result;
        }

        public IEnumerable<TalonarioChequeModel> GetListFilter(Filter filterObj)
        {
            IList<TalonarioChequeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TalonarioChequeModel where " + filterObj.Where;
                NHibernateDAL<TalonarioChequeModel> DAL = new NHibernateDAL<TalonarioChequeModel>(Session);
                Result = DAL.SelectListSql<TalonarioChequeModel>(Query);
            }
            return Result;
        }
		
        public TalonarioChequeModel GetObject(int id)
        {
            TalonarioChequeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TalonarioChequeModel> DAL = new NHibernateDAL<TalonarioChequeModel>(Session);
                Result = DAL.SelectId<TalonarioChequeModel>(id);
            }
            return Result;
        }
		
        public void Insert(TalonarioChequeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TalonarioChequeModel> DAL = new NHibernateDAL<TalonarioChequeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TalonarioChequeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TalonarioChequeModel> DAL = new NHibernateDAL<TalonarioChequeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TalonarioChequeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TalonarioChequeModel> DAL = new NHibernateDAL<TalonarioChequeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}