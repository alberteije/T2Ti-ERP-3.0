using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinChequeEmitidoService
    {

        public IEnumerable<FinChequeEmitidoModel> GetList()
        {
            IList<FinChequeEmitidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeEmitidoModel> DAL = new NHibernateDAL<FinChequeEmitidoModel>(Session);
                Result = DAL.Select(new FinChequeEmitidoModel());
            }
            return Result;
        }

        public IEnumerable<FinChequeEmitidoModel> GetListFilter(Filter filterObj)
        {
            IList<FinChequeEmitidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinChequeEmitidoModel where " + filterObj.Where;
                NHibernateDAL<FinChequeEmitidoModel> DAL = new NHibernateDAL<FinChequeEmitidoModel>(Session);
                Result = DAL.SelectListSql<FinChequeEmitidoModel>(Query);
            }
            return Result;
        }
		
        public FinChequeEmitidoModel GetObject(int id)
        {
            FinChequeEmitidoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeEmitidoModel> DAL = new NHibernateDAL<FinChequeEmitidoModel>(Session);
                Result = DAL.SelectId<FinChequeEmitidoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinChequeEmitidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeEmitidoModel> DAL = new NHibernateDAL<FinChequeEmitidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinChequeEmitidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeEmitidoModel> DAL = new NHibernateDAL<FinChequeEmitidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinChequeEmitidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeEmitidoModel> DAL = new NHibernateDAL<FinChequeEmitidoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}