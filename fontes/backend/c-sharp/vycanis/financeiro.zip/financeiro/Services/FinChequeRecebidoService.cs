using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinChequeRecebidoService
    {

        public IEnumerable<FinChequeRecebidoModel> GetList()
        {
            IList<FinChequeRecebidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeRecebidoModel> DAL = new NHibernateDAL<FinChequeRecebidoModel>(Session);
                Result = DAL.Select(new FinChequeRecebidoModel());
            }
            return Result;
        }

        public IEnumerable<FinChequeRecebidoModel> GetListFilter(Filter filterObj)
        {
            IList<FinChequeRecebidoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinChequeRecebidoModel where " + filterObj.Where;
                NHibernateDAL<FinChequeRecebidoModel> DAL = new NHibernateDAL<FinChequeRecebidoModel>(Session);
                Result = DAL.SelectListSql<FinChequeRecebidoModel>(Query);
            }
            return Result;
        }
		
        public FinChequeRecebidoModel GetObject(int id)
        {
            FinChequeRecebidoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeRecebidoModel> DAL = new NHibernateDAL<FinChequeRecebidoModel>(Session);
                Result = DAL.SelectId<FinChequeRecebidoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinChequeRecebidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeRecebidoModel> DAL = new NHibernateDAL<FinChequeRecebidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinChequeRecebidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeRecebidoModel> DAL = new NHibernateDAL<FinChequeRecebidoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinChequeRecebidoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinChequeRecebidoModel> DAL = new NHibernateDAL<FinChequeRecebidoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}