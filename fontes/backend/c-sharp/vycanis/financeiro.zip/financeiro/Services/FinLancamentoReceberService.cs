using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinLancamentoReceberService
    {

        public IEnumerable<FinLancamentoReceberModel> GetList()
        {
            IList<FinLancamentoReceberModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoReceberModel> DAL = new NHibernateDAL<FinLancamentoReceberModel>(Session);
                Result = DAL.Select(new FinLancamentoReceberModel());
            }
            return Result;
        }

        public IEnumerable<FinLancamentoReceberModel> GetListFilter(Filter filterObj)
        {
            IList<FinLancamentoReceberModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinLancamentoReceberModel where " + filterObj.Where;
                NHibernateDAL<FinLancamentoReceberModel> DAL = new NHibernateDAL<FinLancamentoReceberModel>(Session);
                Result = DAL.SelectListSql<FinLancamentoReceberModel>(Query);
            }
            return Result;
        }
		
        public FinLancamentoReceberModel GetObject(int id)
        {
            FinLancamentoReceberModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoReceberModel> DAL = new NHibernateDAL<FinLancamentoReceberModel>(Session);
                Result = DAL.SelectId<FinLancamentoReceberModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinLancamentoReceberModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoReceberModel> DAL = new NHibernateDAL<FinLancamentoReceberModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinLancamentoReceberModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoReceberModel> DAL = new NHibernateDAL<FinLancamentoReceberModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinLancamentoReceberModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoReceberModel> DAL = new NHibernateDAL<FinLancamentoReceberModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}