using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinFechamentoCaixaBancoService
    {

        public IEnumerable<FinFechamentoCaixaBancoModel> GetList()
        {
            IList<FinFechamentoCaixaBancoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinFechamentoCaixaBancoModel> DAL = new NHibernateDAL<FinFechamentoCaixaBancoModel>(Session);
                Result = DAL.Select(new FinFechamentoCaixaBancoModel());
            }
            return Result;
        }

        public IEnumerable<FinFechamentoCaixaBancoModel> GetListFilter(Filter filterObj)
        {
            IList<FinFechamentoCaixaBancoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinFechamentoCaixaBancoModel where " + filterObj.Where;
                NHibernateDAL<FinFechamentoCaixaBancoModel> DAL = new NHibernateDAL<FinFechamentoCaixaBancoModel>(Session);
                Result = DAL.SelectListSql<FinFechamentoCaixaBancoModel>(Query);
            }
            return Result;
        }
		
        public FinFechamentoCaixaBancoModel GetObject(int id)
        {
            FinFechamentoCaixaBancoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinFechamentoCaixaBancoModel> DAL = new NHibernateDAL<FinFechamentoCaixaBancoModel>(Session);
                Result = DAL.SelectId<FinFechamentoCaixaBancoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinFechamentoCaixaBancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinFechamentoCaixaBancoModel> DAL = new NHibernateDAL<FinFechamentoCaixaBancoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinFechamentoCaixaBancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinFechamentoCaixaBancoModel> DAL = new NHibernateDAL<FinFechamentoCaixaBancoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinFechamentoCaixaBancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinFechamentoCaixaBancoModel> DAL = new NHibernateDAL<FinFechamentoCaixaBancoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}