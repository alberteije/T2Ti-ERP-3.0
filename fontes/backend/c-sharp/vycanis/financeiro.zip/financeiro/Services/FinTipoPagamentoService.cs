using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinTipoPagamentoService
    {

        public IEnumerable<FinTipoPagamentoModel> GetList()
        {
            IList<FinTipoPagamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoPagamentoModel> DAL = new NHibernateDAL<FinTipoPagamentoModel>(Session);
                Result = DAL.Select(new FinTipoPagamentoModel());
            }
            return Result;
        }

        public IEnumerable<FinTipoPagamentoModel> GetListFilter(Filter filterObj)
        {
            IList<FinTipoPagamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinTipoPagamentoModel where " + filterObj.Where;
                NHibernateDAL<FinTipoPagamentoModel> DAL = new NHibernateDAL<FinTipoPagamentoModel>(Session);
                Result = DAL.SelectListSql<FinTipoPagamentoModel>(Query);
            }
            return Result;
        }
		
        public FinTipoPagamentoModel GetObject(int id)
        {
            FinTipoPagamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoPagamentoModel> DAL = new NHibernateDAL<FinTipoPagamentoModel>(Session);
                Result = DAL.SelectId<FinTipoPagamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinTipoPagamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoPagamentoModel> DAL = new NHibernateDAL<FinTipoPagamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinTipoPagamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoPagamentoModel> DAL = new NHibernateDAL<FinTipoPagamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinTipoPagamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoPagamentoModel> DAL = new NHibernateDAL<FinTipoPagamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}