using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("banco")]
    [Produces("application/json")]
    public class BancoController : Controller
    {
		private readonly BancoService _service;

        public BancoController()
        {
            _service = new BancoService();
        }

        [HttpGet]
        public IActionResult GetListBanco([FromQuery]string filter)
        {
            try
            {
                IEnumerable<BancoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Banco]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectBanco")]
        public IActionResult GetObjectBanco(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Banco]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Banco]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertBanco([FromBody]BancoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Banco]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectBanco", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Banco]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateBanco([FromBody]BancoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Banco]", null));
                }

                _service.Update(objJson);

                return GetObjectBanco(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Banco]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBanco(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Banco]", ex));
            }
        }

    }
}