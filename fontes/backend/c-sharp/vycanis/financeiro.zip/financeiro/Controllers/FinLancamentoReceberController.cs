using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-lancamento-receber")]
    [Produces("application/json")]
    public class FinLancamentoReceberController : Controller
    {
		private readonly FinLancamentoReceberService _service;

        public FinLancamentoReceberController()
        {
            _service = new FinLancamentoReceberService();
        }

        [HttpGet]
        public IActionResult GetListFinLancamentoReceber([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinLancamentoReceberModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinLancamentoReceber]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinLancamentoReceber")]
        public IActionResult GetObjectFinLancamentoReceber(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinLancamentoReceber]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinLancamentoReceber]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinLancamentoReceber([FromBody]FinLancamentoReceberModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinLancamentoReceber]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinLancamentoReceber", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinLancamentoReceber]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinLancamentoReceber([FromBody]FinLancamentoReceberModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinLancamentoReceber]", null));
                }

                _service.Update(objJson);

                return GetObjectFinLancamentoReceber(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinLancamentoReceber]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinLancamentoReceber(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinLancamentoReceber]", ex));
            }
        }

    }
}