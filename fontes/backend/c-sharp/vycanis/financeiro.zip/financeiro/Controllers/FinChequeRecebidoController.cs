using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-cheque-recebido")]
    [Produces("application/json")]
    public class FinChequeRecebidoController : Controller
    {
		private readonly FinChequeRecebidoService _service;

        public FinChequeRecebidoController()
        {
            _service = new FinChequeRecebidoService();
        }

        [HttpGet]
        public IActionResult GetListFinChequeRecebido([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinChequeRecebidoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinChequeRecebido]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinChequeRecebido")]
        public IActionResult GetObjectFinChequeRecebido(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinChequeRecebido]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinChequeRecebido]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinChequeRecebido([FromBody]FinChequeRecebidoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinChequeRecebido]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinChequeRecebido", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinChequeRecebido]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinChequeRecebido([FromBody]FinChequeRecebidoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinChequeRecebido]", null));
                }

                _service.Update(objJson);

                return GetObjectFinChequeRecebido(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinChequeRecebido]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinChequeRecebido(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinChequeRecebido]", ex));
            }
        }

    }
}