using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-lancamento-pagar")]
    [Produces("application/json")]
    public class FinLancamentoPagarController : Controller
    {
		private readonly FinLancamentoPagarService _service;

        public FinLancamentoPagarController()
        {
            _service = new FinLancamentoPagarService();
        }

        [HttpGet]
        public IActionResult GetListFinLancamentoPagar([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinLancamentoPagarModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinLancamentoPagar]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinLancamentoPagar")]
        public IActionResult GetObjectFinLancamentoPagar(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinLancamentoPagar]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinLancamentoPagar]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinLancamentoPagar([FromBody]FinLancamentoPagarModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinLancamentoPagar]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinLancamentoPagar", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinLancamentoPagar]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinLancamentoPagar([FromBody]FinLancamentoPagarModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinLancamentoPagar]", null));
                }

                _service.Update(objJson);

                return GetObjectFinLancamentoPagar(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinLancamentoPagar]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinLancamentoPagar(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinLancamentoPagar]", ex));
            }
        }

    }
}