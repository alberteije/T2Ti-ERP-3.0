using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-extrato-conta-banco")]
    [Produces("application/json")]
    public class FinExtratoContaBancoController : Controller
    {
		private readonly FinExtratoContaBancoService _service;

        public FinExtratoContaBancoController()
        {
            _service = new FinExtratoContaBancoService();
        }

        [HttpGet]
        public IActionResult GetListFinExtratoContaBanco([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinExtratoContaBancoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinExtratoContaBanco]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinExtratoContaBanco")]
        public IActionResult GetObjectFinExtratoContaBanco(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinExtratoContaBanco]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinExtratoContaBanco]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinExtratoContaBanco([FromBody]FinExtratoContaBancoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinExtratoContaBanco]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinExtratoContaBanco", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinExtratoContaBanco]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinExtratoContaBanco([FromBody]FinExtratoContaBancoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinExtratoContaBanco]", null));
                }

                _service.Update(objJson);

                return GetObjectFinExtratoContaBanco(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinExtratoContaBanco]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinExtratoContaBanco(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinExtratoContaBanco]", ex));
            }
        }

    }
}