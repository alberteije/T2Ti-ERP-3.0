using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("view-pessoa-fornecedor")]
    [Produces("application/json")]
    public class ViewPessoaFornecedorController : Controller
    {
		private readonly ViewPessoaFornecedorService _service;

        public ViewPessoaFornecedorController()
        {
            _service = new ViewPessoaFornecedorService();
        }

        [HttpGet]
        public IActionResult GetListViewPessoaFornecedor([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ViewPessoaFornecedorModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ViewPessoaFornecedor]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectViewPessoaFornecedor")]
        public IActionResult GetObjectViewPessoaFornecedor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ViewPessoaFornecedor]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ViewPessoaFornecedor]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertViewPessoaFornecedor([FromBody]ViewPessoaFornecedorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ViewPessoaFornecedor]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectViewPessoaFornecedor", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ViewPessoaFornecedor]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateViewPessoaFornecedor([FromBody]ViewPessoaFornecedorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ViewPessoaFornecedor]", null));
                }

                _service.Update(objJson);

                return GetObjectViewPessoaFornecedor(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ViewPessoaFornecedor]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteViewPessoaFornecedor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ViewPessoaFornecedor]", ex));
            }
        }

    }
}