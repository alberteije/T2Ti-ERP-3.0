using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-documento-origem")]
    [Produces("application/json")]
    public class FinDocumentoOrigemController : Controller
    {
		private readonly FinDocumentoOrigemService _service;

        public FinDocumentoOrigemController()
        {
            _service = new FinDocumentoOrigemService();
        }

        [HttpGet]
        public IActionResult GetListFinDocumentoOrigem([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinDocumentoOrigemModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinDocumentoOrigem]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinDocumentoOrigem")]
        public IActionResult GetObjectFinDocumentoOrigem(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinDocumentoOrigem]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinDocumentoOrigem]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinDocumentoOrigem([FromBody]FinDocumentoOrigemModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinDocumentoOrigem]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinDocumentoOrigem", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinDocumentoOrigem]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinDocumentoOrigem([FromBody]FinDocumentoOrigemModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinDocumentoOrigem]", null));
                }

                _service.Update(objJson);

                return GetObjectFinDocumentoOrigem(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinDocumentoOrigem]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinDocumentoOrigem(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinDocumentoOrigem]", ex));
            }
        }

    }
}