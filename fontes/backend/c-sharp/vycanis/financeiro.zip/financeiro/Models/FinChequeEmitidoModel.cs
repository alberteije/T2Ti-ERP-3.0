namespace financeiro.Models
{
	public class FinChequeEmitidoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public System.Nullable<System.DateTime> BomPara { get; set; } 

		public System.Nullable<System.DateTime> DataCompensacao { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public string? NominalA { get; set; } 

		public ChequeModel? ChequeModel { get; set; } 

	}
}
