namespace financeiro.Models
{
	public class FinParcelaReceberModel
	{	
		public int? Id { get; set; } 

		public int? NumeroParcela { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public System.Nullable<System.DateTime> DataVencimento { get; set; } 

		public System.Nullable<System.DateTime> DataRecebimento { get; set; } 

		public System.Nullable<System.DateTime> DescontoAte { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public System.Nullable<System.Decimal> TaxaJuro { get; set; } 

		public System.Nullable<System.Decimal> TaxaMulta { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorJuro { get; set; } 

		public System.Nullable<System.Decimal> ValorMulta { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public string? EmitiuBoleto { get; set; } 

		public string? BoletoNossoNumero { get; set; } 

		public System.Nullable<System.Decimal> ValorRecebido { get; set; } 

		public string? Historico { get; set; } 

		public FinLancamentoReceberModel? FinLancamentoReceberModel { get; set; } 

		public FinStatusParcelaModel? FinStatusParcelaModel { get; set; } 

		public FinTipoRecebimentoModel? FinTipoRecebimentoModel { get; set; } 

	}
}
