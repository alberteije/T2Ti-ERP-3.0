namespace financeiro.Models
{
	public class FinFechamentoCaixaBancoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataFechamento { get; set; } 

		public string? MesAno { get; set; } 

		public string? Mes { get; set; } 

		public string? Ano { get; set; } 

		public System.Nullable<System.Decimal> SaldoAnterior { get; set; } 

		public System.Nullable<System.Decimal> Recebimentos { get; set; } 

		public System.Nullable<System.Decimal> Pagamentos { get; set; } 

		public System.Nullable<System.Decimal> SaldoConta { get; set; } 

		public System.Nullable<System.Decimal> ChequeNaoCompensado { get; set; } 

		public System.Nullable<System.Decimal> SaldoDisponivel { get; set; } 

		public BancoContaCaixaModel? BancoContaCaixaModel { get; set; } 

	}
}
