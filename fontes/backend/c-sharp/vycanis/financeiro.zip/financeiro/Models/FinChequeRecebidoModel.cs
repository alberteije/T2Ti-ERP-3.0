namespace financeiro.Models
{
	public class FinChequeRecebidoModel
	{	
		public int? Id { get; set; } 

		public string? Cpf { get; set; } 

		public string? Cnpj { get; set; } 

		public string? Nome { get; set; } 

		public string? CodigoBanco { get; set; } 

		public string? CodigoAgencia { get; set; } 

		public string? Conta { get; set; } 

		public int? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public System.Nullable<System.DateTime> BomPara { get; set; } 

		public System.Nullable<System.DateTime> DataCompensacao { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public System.Nullable<System.DateTime> CustodiaData { get; set; } 

		public System.Nullable<System.Decimal> CustodiaTarifa { get; set; } 

		public System.Nullable<System.Decimal> CustodiaComissao { get; set; } 

		public System.Nullable<System.DateTime> DescontoData { get; set; } 

		public System.Nullable<System.Decimal> DescontoTarifa { get; set; } 

		public System.Nullable<System.Decimal> DescontoComissao { get; set; } 

		public System.Nullable<System.Decimal> ValorRecebido { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

	}
}
