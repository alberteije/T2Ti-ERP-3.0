using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-status-parcela")]
    [Produces("application/json")]
    public class FinStatusParcelaController : Controller
    {
		private readonly FinStatusParcelaService _service;

        public FinStatusParcelaController()
        {
            _service = new FinStatusParcelaService();
        }

        [HttpGet]
        public IActionResult GetListFinStatusParcela([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinStatusParcelaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinStatusParcela]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinStatusParcela")]
        public IActionResult GetObjectFinStatusParcela(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinStatusParcela]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinStatusParcela]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinStatusParcela([FromBody]FinStatusParcelaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinStatusParcela]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinStatusParcela", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinStatusParcela]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinStatusParcela([FromBody]FinStatusParcelaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinStatusParcela]", null));
                }

                _service.Update(objJson);

                return GetObjectFinStatusParcela(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinStatusParcela]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinStatusParcela(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinStatusParcela]", ex));
            }
        }

    }
}