using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("view-pessoa-cliente")]
    [Produces("application/json")]
    public class ViewPessoaClienteController : Controller
    {
		private readonly ViewPessoaClienteService _service;

        public ViewPessoaClienteController()
        {
            _service = new ViewPessoaClienteService();
        }

        [HttpGet]
        public IActionResult GetListViewPessoaCliente([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ViewPessoaClienteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ViewPessoaCliente]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectViewPessoaCliente")]
        public IActionResult GetObjectViewPessoaCliente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ViewPessoaCliente]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ViewPessoaCliente]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertViewPessoaCliente([FromBody]ViewPessoaClienteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ViewPessoaCliente]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectViewPessoaCliente", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ViewPessoaCliente]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateViewPessoaCliente([FromBody]ViewPessoaClienteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ViewPessoaCliente]", null));
                }

                _service.Update(objJson);

                return GetObjectViewPessoaCliente(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ViewPessoaCliente]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteViewPessoaCliente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ViewPessoaCliente]", ex));
            }
        }

    }
}