using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-cheque-emitido")]
    [Produces("application/json")]
    public class FinChequeEmitidoController : Controller
    {
		private readonly FinChequeEmitidoService _service;

        public FinChequeEmitidoController()
        {
            _service = new FinChequeEmitidoService();
        }

        [HttpGet]
        public IActionResult GetListFinChequeEmitido([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinChequeEmitidoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinChequeEmitido]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinChequeEmitido")]
        public IActionResult GetObjectFinChequeEmitido(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinChequeEmitido]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinChequeEmitido]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinChequeEmitido([FromBody]FinChequeEmitidoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinChequeEmitido]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinChequeEmitido", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinChequeEmitido]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinChequeEmitido([FromBody]FinChequeEmitidoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinChequeEmitido]", null));
                }

                _service.Update(objJson);

                return GetObjectFinChequeEmitido(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinChequeEmitido]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinChequeEmitido(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinChequeEmitido]", ex));
            }
        }

    }
}