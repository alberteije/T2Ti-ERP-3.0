using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-tipo-pagamento")]
    [Produces("application/json")]
    public class FinTipoPagamentoController : Controller
    {
		private readonly FinTipoPagamentoService _service;

        public FinTipoPagamentoController()
        {
            _service = new FinTipoPagamentoService();
        }

        [HttpGet]
        public IActionResult GetListFinTipoPagamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinTipoPagamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinTipoPagamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinTipoPagamento")]
        public IActionResult GetObjectFinTipoPagamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinTipoPagamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinTipoPagamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinTipoPagamento([FromBody]FinTipoPagamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinTipoPagamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinTipoPagamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinTipoPagamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinTipoPagamento([FromBody]FinTipoPagamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinTipoPagamento]", null));
                }

                _service.Update(objJson);

                return GetObjectFinTipoPagamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinTipoPagamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinTipoPagamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinTipoPagamento]", ex));
            }
        }

    }
}