using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("talonario-cheque")]
    [Produces("application/json")]
    public class TalonarioChequeController : Controller
    {
		private readonly TalonarioChequeService _service;

        public TalonarioChequeController()
        {
            _service = new TalonarioChequeService();
        }

        [HttpGet]
        public IActionResult GetListTalonarioCheque([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TalonarioChequeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TalonarioCheque]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTalonarioCheque")]
        public IActionResult GetObjectTalonarioCheque(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TalonarioCheque]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TalonarioCheque]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTalonarioCheque([FromBody]TalonarioChequeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TalonarioCheque]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTalonarioCheque", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TalonarioCheque]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTalonarioCheque([FromBody]TalonarioChequeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TalonarioCheque]", null));
                }

                _service.Update(objJson);

                return GetObjectTalonarioCheque(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TalonarioCheque]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTalonarioCheque(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TalonarioCheque]", ex));
            }
        }

    }
}