using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-tipo-recebimento")]
    [Produces("application/json")]
    public class FinTipoRecebimentoController : Controller
    {
		private readonly FinTipoRecebimentoService _service;

        public FinTipoRecebimentoController()
        {
            _service = new FinTipoRecebimentoService();
        }

        [HttpGet]
        public IActionResult GetListFinTipoRecebimento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinTipoRecebimentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinTipoRecebimento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinTipoRecebimento")]
        public IActionResult GetObjectFinTipoRecebimento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinTipoRecebimento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinTipoRecebimento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinTipoRecebimento([FromBody]FinTipoRecebimentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinTipoRecebimento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinTipoRecebimento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinTipoRecebimento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinTipoRecebimento([FromBody]FinTipoRecebimentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinTipoRecebimento]", null));
                }

                _service.Update(objJson);

                return GetObjectFinTipoRecebimento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinTipoRecebimento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinTipoRecebimento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinTipoRecebimento]", ex));
            }
        }

    }
}