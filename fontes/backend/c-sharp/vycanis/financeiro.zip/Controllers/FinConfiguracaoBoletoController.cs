using Microsoft.AspNetCore.Mvc;
using financeiro.Models;
using financeiro.Services;

namespace financeiro.Controllers
{
    [Route("fin-configuracao-boleto")]
    [Produces("application/json")]
    public class FinConfiguracaoBoletoController : Controller
    {
		private readonly FinConfiguracaoBoletoService _service;

        public FinConfiguracaoBoletoController()
        {
            _service = new FinConfiguracaoBoletoService();
        }

        [HttpGet]
        public IActionResult GetListFinConfiguracaoBoleto([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinConfiguracaoBoletoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinConfiguracaoBoleto]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinConfiguracaoBoleto")]
        public IActionResult GetObjectFinConfiguracaoBoleto(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinConfiguracaoBoleto]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinConfiguracaoBoleto]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinConfiguracaoBoleto([FromBody]FinConfiguracaoBoletoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinConfiguracaoBoleto]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinConfiguracaoBoleto", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinConfiguracaoBoleto]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinConfiguracaoBoleto([FromBody]FinConfiguracaoBoletoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinConfiguracaoBoleto]", null));
                }

                _service.Update(objJson);

                return GetObjectFinConfiguracaoBoleto(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinConfiguracaoBoleto]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinConfiguracaoBoleto(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinConfiguracaoBoleto]", ex));
            }
        }

    }
}