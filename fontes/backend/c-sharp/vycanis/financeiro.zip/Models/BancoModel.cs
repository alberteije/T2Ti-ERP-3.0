namespace financeiro.Models
{
	public class BancoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		public string? Url { get; set; } 

	}
}
