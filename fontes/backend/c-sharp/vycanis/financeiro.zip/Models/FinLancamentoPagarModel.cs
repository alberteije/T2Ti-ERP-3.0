namespace financeiro.Models
{
	public class FinLancamentoPagarModel
	{	
		public int? Id { get; set; } 

		public int? QuantidadeParcela { get; set; } 

		public System.Nullable<System.Decimal> ValorAPagar { get; set; } 

		public System.Nullable<System.DateTime> DataLancamento { get; set; } 

		public string? NumeroDocumento { get; set; } 

		public System.Nullable<System.DateTime> PrimeiroVencimento { get; set; } 

		public int? IntervaloEntreParcelas { get; set; } 

		public string? DiaFixo { get; set; } 

		public string? ImagemDocumento { get; set; } 

		public FinDocumentoOrigemModel? FinDocumentoOrigemModel { get; set; } 

		public BancoContaCaixaModel? BancoContaCaixaModel { get; set; } 

		public FinNaturezaFinanceiraModel? FinNaturezaFinanceiraModel { get; set; } 

		public ViewPessoaFornecedorModel? ViewPessoaFornecedorModel { get; set; } 

		private IList<FinParcelaPagarModel>? finParcelaPagarModelList; 
		public IList<FinParcelaPagarModel>? FinParcelaPagarModelList 
		{ 
			get 
			{ 
				return finParcelaPagarModelList; 
			} 
			set 
			{ 
				finParcelaPagarModelList = value; 
				foreach (FinParcelaPagarModel finParcelaPagarModel in finParcelaPagarModelList!) 
				{ 
					finParcelaPagarModel.FinLancamentoPagarModel = this; 
				} 
			} 
		} 

	}
}
