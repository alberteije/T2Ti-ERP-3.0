namespace financeiro.Models
{
	public class FinLancamentoReceberModel
	{	
		public int? Id { get; set; } 

		public int? QuantidadeParcela { get; set; } 

		public System.Nullable<System.Decimal> ValorAReceber { get; set; } 

		public System.Nullable<System.DateTime> DataLancamento { get; set; } 

		public string? NumeroDocumento { get; set; } 

		public System.Nullable<System.DateTime> PrimeiroVencimento { get; set; } 

		public System.Nullable<System.Decimal> TaxaComissao { get; set; } 

		public System.Nullable<System.Decimal> ValorComissao { get; set; } 

		public int? IntervaloEntreParcelas { get; set; } 

		public string? DiaFixo { get; set; } 

		public FinDocumentoOrigemModel? FinDocumentoOrigemModel { get; set; } 

		public BancoContaCaixaModel? BancoContaCaixaModel { get; set; } 

		public FinNaturezaFinanceiraModel? FinNaturezaFinanceiraModel { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		private IList<FinParcelaReceberModel>? finParcelaReceberModelList; 
		public IList<FinParcelaReceberModel>? FinParcelaReceberModelList 
		{ 
			get 
			{ 
				return finParcelaReceberModelList; 
			} 
			set 
			{ 
				finParcelaReceberModelList = value; 
				foreach (FinParcelaReceberModel finParcelaReceberModel in finParcelaReceberModelList!) 
				{ 
					finParcelaReceberModel.FinLancamentoReceberModel = this; 
				} 
			} 
		} 

	}
}
