namespace financeiro.Models
{
	public class ChequeModel
	{	
		public int? Id { get; set; } 

		public int? Numero { get; set; } 

		public string? StatusCheque { get; set; } 

		public System.Nullable<System.DateTime> DataStatus { get; set; } 

		public TalonarioChequeModel? TalonarioChequeModel { get; set; } 

	}
}
