namespace financeiro.Models
{
	public class FinParcelaPagarModel
	{	
		public int? Id { get; set; } 

		public int? NumeroParcela { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public System.Nullable<System.DateTime> DataVencimento { get; set; } 

		public System.Nullable<System.DateTime> DataPagamento { get; set; } 

		public System.Nullable<System.DateTime> DescontoAte { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public System.Nullable<System.Decimal> TaxaJuro { get; set; } 

		public System.Nullable<System.Decimal> TaxaMulta { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorJuro { get; set; } 

		public System.Nullable<System.Decimal> ValorMulta { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorPago { get; set; } 

		public string? Historico { get; set; } 

		public FinLancamentoPagarModel? FinLancamentoPagarModel { get; set; } 

		public FinStatusParcelaModel? FinStatusParcelaModel { get; set; } 

		public FinTipoPagamentoModel? FinTipoPagamentoModel { get; set; } 

	}
}
