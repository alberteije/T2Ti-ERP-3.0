namespace financeiro.Models
{
	public class TalonarioChequeModel
	{	
		public int? Id { get; set; } 

		public string? Talao { get; set; } 

		public int? Numero { get; set; } 

		public string? StatusTalao { get; set; } 

		public BancoContaCaixaModel? BancoContaCaixaModel { get; set; } 

		private IList<ChequeModel>? chequeModelList; 
		public IList<ChequeModel>? ChequeModelList 
		{ 
			get 
			{ 
				return chequeModelList; 
			} 
			set 
			{ 
				chequeModelList = value; 
				foreach (ChequeModel chequeModel in chequeModelList!) 
				{ 
					chequeModel.TalonarioChequeModel = this; 
				} 
			} 
		} 

	}
}
