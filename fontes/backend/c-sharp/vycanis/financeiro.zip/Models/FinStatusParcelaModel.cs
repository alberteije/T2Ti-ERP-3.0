namespace financeiro.Models
{
	public class FinStatusParcelaModel
	{	
		public int? Id { get; set; } 

		public string? Situacao { get; set; } 

		public string? Descricao { get; set; } 

		public string? Procedimento { get; set; } 

	}
}
