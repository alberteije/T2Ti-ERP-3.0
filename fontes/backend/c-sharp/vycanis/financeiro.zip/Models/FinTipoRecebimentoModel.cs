namespace financeiro.Models
{
	public class FinTipoRecebimentoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

	}
}
