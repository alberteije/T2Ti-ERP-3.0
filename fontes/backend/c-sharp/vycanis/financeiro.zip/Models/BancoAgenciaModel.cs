namespace financeiro.Models
{
	public class BancoAgenciaModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public string? Digito { get; set; } 

		public string? Nome { get; set; } 

		public string? Telefone { get; set; } 

		public string? Contato { get; set; } 

		public string? Gerente { get; set; } 

		public string? Observacao { get; set; } 

		public BancoModel? BancoModel { get; set; } 

	}
}
