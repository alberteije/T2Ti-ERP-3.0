using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinTipoRecebimentoService
    {

        public IEnumerable<FinTipoRecebimentoModel> GetList()
        {
            IList<FinTipoRecebimentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoRecebimentoModel> DAL = new NHibernateDAL<FinTipoRecebimentoModel>(Session);
                Result = DAL.Select(new FinTipoRecebimentoModel());
            }
            return Result;
        }

        public IEnumerable<FinTipoRecebimentoModel> GetListFilter(Filter filterObj)
        {
            IList<FinTipoRecebimentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinTipoRecebimentoModel where " + filterObj.Where;
                NHibernateDAL<FinTipoRecebimentoModel> DAL = new NHibernateDAL<FinTipoRecebimentoModel>(Session);
                Result = DAL.SelectListSql<FinTipoRecebimentoModel>(Query);
            }
            return Result;
        }
		
        public FinTipoRecebimentoModel GetObject(int id)
        {
            FinTipoRecebimentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoRecebimentoModel> DAL = new NHibernateDAL<FinTipoRecebimentoModel>(Session);
                Result = DAL.SelectId<FinTipoRecebimentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinTipoRecebimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoRecebimentoModel> DAL = new NHibernateDAL<FinTipoRecebimentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinTipoRecebimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoRecebimentoModel> DAL = new NHibernateDAL<FinTipoRecebimentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinTipoRecebimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinTipoRecebimentoModel> DAL = new NHibernateDAL<FinTipoRecebimentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}