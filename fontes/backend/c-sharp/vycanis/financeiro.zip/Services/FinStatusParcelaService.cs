using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinStatusParcelaService
    {

        public IEnumerable<FinStatusParcelaModel> GetList()
        {
            IList<FinStatusParcelaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinStatusParcelaModel> DAL = new NHibernateDAL<FinStatusParcelaModel>(Session);
                Result = DAL.Select(new FinStatusParcelaModel());
            }
            return Result;
        }

        public IEnumerable<FinStatusParcelaModel> GetListFilter(Filter filterObj)
        {
            IList<FinStatusParcelaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinStatusParcelaModel where " + filterObj.Where;
                NHibernateDAL<FinStatusParcelaModel> DAL = new NHibernateDAL<FinStatusParcelaModel>(Session);
                Result = DAL.SelectListSql<FinStatusParcelaModel>(Query);
            }
            return Result;
        }
		
        public FinStatusParcelaModel GetObject(int id)
        {
            FinStatusParcelaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinStatusParcelaModel> DAL = new NHibernateDAL<FinStatusParcelaModel>(Session);
                Result = DAL.SelectId<FinStatusParcelaModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinStatusParcelaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinStatusParcelaModel> DAL = new NHibernateDAL<FinStatusParcelaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinStatusParcelaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinStatusParcelaModel> DAL = new NHibernateDAL<FinStatusParcelaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinStatusParcelaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinStatusParcelaModel> DAL = new NHibernateDAL<FinStatusParcelaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}