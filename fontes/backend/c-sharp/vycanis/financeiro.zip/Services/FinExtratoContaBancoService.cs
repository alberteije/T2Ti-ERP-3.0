using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinExtratoContaBancoService
    {

        public IEnumerable<FinExtratoContaBancoModel> GetList()
        {
            IList<FinExtratoContaBancoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinExtratoContaBancoModel> DAL = new NHibernateDAL<FinExtratoContaBancoModel>(Session);
                Result = DAL.Select(new FinExtratoContaBancoModel());
            }
            return Result;
        }

        public IEnumerable<FinExtratoContaBancoModel> GetListFilter(Filter filterObj)
        {
            IList<FinExtratoContaBancoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinExtratoContaBancoModel where " + filterObj.Where;
                NHibernateDAL<FinExtratoContaBancoModel> DAL = new NHibernateDAL<FinExtratoContaBancoModel>(Session);
                Result = DAL.SelectListSql<FinExtratoContaBancoModel>(Query);
            }
            return Result;
        }
		
        public FinExtratoContaBancoModel GetObject(int id)
        {
            FinExtratoContaBancoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinExtratoContaBancoModel> DAL = new NHibernateDAL<FinExtratoContaBancoModel>(Session);
                Result = DAL.SelectId<FinExtratoContaBancoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinExtratoContaBancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinExtratoContaBancoModel> DAL = new NHibernateDAL<FinExtratoContaBancoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinExtratoContaBancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinExtratoContaBancoModel> DAL = new NHibernateDAL<FinExtratoContaBancoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinExtratoContaBancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinExtratoContaBancoModel> DAL = new NHibernateDAL<FinExtratoContaBancoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}