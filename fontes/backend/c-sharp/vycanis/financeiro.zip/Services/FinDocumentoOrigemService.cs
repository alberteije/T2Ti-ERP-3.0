using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinDocumentoOrigemService
    {

        public IEnumerable<FinDocumentoOrigemModel> GetList()
        {
            IList<FinDocumentoOrigemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinDocumentoOrigemModel> DAL = new NHibernateDAL<FinDocumentoOrigemModel>(Session);
                Result = DAL.Select(new FinDocumentoOrigemModel());
            }
            return Result;
        }

        public IEnumerable<FinDocumentoOrigemModel> GetListFilter(Filter filterObj)
        {
            IList<FinDocumentoOrigemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinDocumentoOrigemModel where " + filterObj.Where;
                NHibernateDAL<FinDocumentoOrigemModel> DAL = new NHibernateDAL<FinDocumentoOrigemModel>(Session);
                Result = DAL.SelectListSql<FinDocumentoOrigemModel>(Query);
            }
            return Result;
        }
		
        public FinDocumentoOrigemModel GetObject(int id)
        {
            FinDocumentoOrigemModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinDocumentoOrigemModel> DAL = new NHibernateDAL<FinDocumentoOrigemModel>(Session);
                Result = DAL.SelectId<FinDocumentoOrigemModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinDocumentoOrigemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinDocumentoOrigemModel> DAL = new NHibernateDAL<FinDocumentoOrigemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinDocumentoOrigemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinDocumentoOrigemModel> DAL = new NHibernateDAL<FinDocumentoOrigemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinDocumentoOrigemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinDocumentoOrigemModel> DAL = new NHibernateDAL<FinDocumentoOrigemModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}