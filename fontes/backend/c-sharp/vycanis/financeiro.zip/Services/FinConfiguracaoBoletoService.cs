using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinConfiguracaoBoletoService
    {

        public IEnumerable<FinConfiguracaoBoletoModel> GetList()
        {
            IList<FinConfiguracaoBoletoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinConfiguracaoBoletoModel> DAL = new NHibernateDAL<FinConfiguracaoBoletoModel>(Session);
                Result = DAL.Select(new FinConfiguracaoBoletoModel());
            }
            return Result;
        }

        public IEnumerable<FinConfiguracaoBoletoModel> GetListFilter(Filter filterObj)
        {
            IList<FinConfiguracaoBoletoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinConfiguracaoBoletoModel where " + filterObj.Where;
                NHibernateDAL<FinConfiguracaoBoletoModel> DAL = new NHibernateDAL<FinConfiguracaoBoletoModel>(Session);
                Result = DAL.SelectListSql<FinConfiguracaoBoletoModel>(Query);
            }
            return Result;
        }
		
        public FinConfiguracaoBoletoModel GetObject(int id)
        {
            FinConfiguracaoBoletoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinConfiguracaoBoletoModel> DAL = new NHibernateDAL<FinConfiguracaoBoletoModel>(Session);
                Result = DAL.SelectId<FinConfiguracaoBoletoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinConfiguracaoBoletoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinConfiguracaoBoletoModel> DAL = new NHibernateDAL<FinConfiguracaoBoletoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinConfiguracaoBoletoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinConfiguracaoBoletoModel> DAL = new NHibernateDAL<FinConfiguracaoBoletoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinConfiguracaoBoletoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinConfiguracaoBoletoModel> DAL = new NHibernateDAL<FinConfiguracaoBoletoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}