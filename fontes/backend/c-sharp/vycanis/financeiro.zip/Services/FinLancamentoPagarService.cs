using financeiro.Models;
using financeiro.NHibernate;
using ISession = NHibernate.ISession;

namespace financeiro.Services
{
    public class FinLancamentoPagarService
    {

        public IEnumerable<FinLancamentoPagarModel> GetList()
        {
            IList<FinLancamentoPagarModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoPagarModel> DAL = new NHibernateDAL<FinLancamentoPagarModel>(Session);
                Result = DAL.Select(new FinLancamentoPagarModel());
            }
            return Result;
        }

        public IEnumerable<FinLancamentoPagarModel> GetListFilter(Filter filterObj)
        {
            IList<FinLancamentoPagarModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FinLancamentoPagarModel where " + filterObj.Where;
                NHibernateDAL<FinLancamentoPagarModel> DAL = new NHibernateDAL<FinLancamentoPagarModel>(Session);
                Result = DAL.SelectListSql<FinLancamentoPagarModel>(Query);
            }
            return Result;
        }
		
        public FinLancamentoPagarModel GetObject(int id)
        {
            FinLancamentoPagarModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoPagarModel> DAL = new NHibernateDAL<FinLancamentoPagarModel>(Session);
                Result = DAL.SelectId<FinLancamentoPagarModel>(id);
            }
            return Result;
        }
		
        public void Insert(FinLancamentoPagarModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoPagarModel> DAL = new NHibernateDAL<FinLancamentoPagarModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FinLancamentoPagarModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoPagarModel> DAL = new NHibernateDAL<FinLancamentoPagarModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FinLancamentoPagarModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FinLancamentoPagarModel> DAL = new NHibernateDAL<FinLancamentoPagarModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}