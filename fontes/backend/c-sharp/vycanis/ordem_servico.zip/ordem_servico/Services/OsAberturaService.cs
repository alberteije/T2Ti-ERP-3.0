using ordem_servico.Models;
using ordem_servico.NHibernate;
using ISession = NHibernate.ISession;

namespace ordem_servico.Services
{
    public class OsAberturaService
    {

        public IEnumerable<OsAberturaModel> GetList()
        {
            IList<OsAberturaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsAberturaModel> DAL = new NHibernateDAL<OsAberturaModel>(Session);
                Result = DAL.Select(new OsAberturaModel());
            }
            return Result;
        }

        public IEnumerable<OsAberturaModel> GetListFilter(Filter filterObj)
        {
            IList<OsAberturaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OsAberturaModel where " + filterObj.Where;
                NHibernateDAL<OsAberturaModel> DAL = new NHibernateDAL<OsAberturaModel>(Session);
                Result = DAL.SelectListSql<OsAberturaModel>(Query);
            }
            return Result;
        }
		
        public OsAberturaModel GetObject(int id)
        {
            OsAberturaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsAberturaModel> DAL = new NHibernateDAL<OsAberturaModel>(Session);
                Result = DAL.SelectId<OsAberturaModel>(id);
            }
            return Result;
        }
		
        public void Insert(OsAberturaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsAberturaModel> DAL = new NHibernateDAL<OsAberturaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OsAberturaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsAberturaModel> DAL = new NHibernateDAL<OsAberturaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OsAberturaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsAberturaModel> DAL = new NHibernateDAL<OsAberturaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}