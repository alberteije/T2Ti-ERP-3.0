using ordem_servico.Models;
using ordem_servico.NHibernate;
using ISession = NHibernate.ISession;

namespace ordem_servico.Services
{
    public class OsStatusService
    {

        public IEnumerable<OsStatusModel> GetList()
        {
            IList<OsStatusModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsStatusModel> DAL = new NHibernateDAL<OsStatusModel>(Session);
                Result = DAL.Select(new OsStatusModel());
            }
            return Result;
        }

        public IEnumerable<OsStatusModel> GetListFilter(Filter filterObj)
        {
            IList<OsStatusModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OsStatusModel where " + filterObj.Where;
                NHibernateDAL<OsStatusModel> DAL = new NHibernateDAL<OsStatusModel>(Session);
                Result = DAL.SelectListSql<OsStatusModel>(Query);
            }
            return Result;
        }
		
        public OsStatusModel GetObject(int id)
        {
            OsStatusModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsStatusModel> DAL = new NHibernateDAL<OsStatusModel>(Session);
                Result = DAL.SelectId<OsStatusModel>(id);
            }
            return Result;
        }
		
        public void Insert(OsStatusModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsStatusModel> DAL = new NHibernateDAL<OsStatusModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OsStatusModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsStatusModel> DAL = new NHibernateDAL<OsStatusModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OsStatusModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsStatusModel> DAL = new NHibernateDAL<OsStatusModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}