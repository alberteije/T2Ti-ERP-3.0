namespace ordem_servico.Models
{
	public class OsEquipamentoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

	}
}
