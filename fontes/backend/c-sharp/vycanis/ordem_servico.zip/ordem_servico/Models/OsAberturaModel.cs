namespace ordem_servico.Models
{
	public class OsAberturaModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public string? HoraInicio { get; set; } 

		public System.Nullable<System.DateTime> DataPrevisao { get; set; } 

		public string? HoraPrevisao { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public string? HoraFim { get; set; } 

		public string? NomeContato { get; set; } 

		public string? FoneContato { get; set; } 

		public string? ObservacaoCliente { get; set; } 

		public string? ObservacaoAbertura { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public OsStatusModel? OsStatusModel { get; set; } 

		private IList<OsAberturaEquipamentoModel>? osAberturaEquipamentoModelList; 
		public IList<OsAberturaEquipamentoModel>? OsAberturaEquipamentoModelList 
		{ 
			get 
			{ 
				return osAberturaEquipamentoModelList; 
			} 
			set 
			{ 
				osAberturaEquipamentoModelList = value; 
				foreach (OsAberturaEquipamentoModel osAberturaEquipamentoModel in osAberturaEquipamentoModelList!) 
				{ 
					osAberturaEquipamentoModel.OsAberturaModel = this; 
				} 
			} 
		} 

		private IList<OsProdutoServicoModel>? osProdutoServicoModelList; 
		public IList<OsProdutoServicoModel>? OsProdutoServicoModelList 
		{ 
			get 
			{ 
				return osProdutoServicoModelList; 
			} 
			set 
			{ 
				osProdutoServicoModelList = value; 
				foreach (OsProdutoServicoModel osProdutoServicoModel in osProdutoServicoModelList!) 
				{ 
					osProdutoServicoModel.OsAberturaModel = this; 
				} 
			} 
		} 

		private IList<OsEvolucaoModel>? osEvolucaoModelList; 
		public IList<OsEvolucaoModel>? OsEvolucaoModelList 
		{ 
			get 
			{ 
				return osEvolucaoModelList; 
			} 
			set 
			{ 
				osEvolucaoModelList = value; 
				foreach (OsEvolucaoModel osEvolucaoModel in osEvolucaoModelList!) 
				{ 
					osEvolucaoModel.OsAberturaModel = this; 
				} 
			} 
		} 

	}
}
