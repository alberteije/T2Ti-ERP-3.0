namespace ordem_servico.Models
{
	public class ProdutoUnidadeModel
	{	
		public int? Id { get; set; } 

		public string? Sigla { get; set; } 

		public string? Descricao { get; set; } 

		public string? PodeFracionar { get; set; } 

		private IList<ProdutoModel>? produtoModelList; 
		public IList<ProdutoModel>? ProdutoModelList 
		{ 
			get 
			{ 
				return produtoModelList; 
			} 
			set 
			{ 
				produtoModelList = value; 
				foreach (ProdutoModel produtoModel in produtoModelList!) 
				{ 
					produtoModel.ProdutoUnidadeModel = this; 
				} 
			} 
		} 

	}
}
