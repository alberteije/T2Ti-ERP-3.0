using Microsoft.AspNetCore.Mvc;
using ordem_servico.Models;
using ordem_servico.Services;

namespace ordem_servico.Controllers
{
    [Route("os-abertura")]
    [Produces("application/json")]
    public class OsAberturaController : Controller
    {
		private readonly OsAberturaService _service;

        public OsAberturaController()
        {
            _service = new OsAberturaService();
        }

        [HttpGet]
        public IActionResult GetListOsAbertura([FromQuery]string filter)
        {
            try
            {
                IEnumerable<OsAberturaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList OsAbertura]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectOsAbertura")]
        public IActionResult GetObjectOsAbertura(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject OsAbertura]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject OsAbertura]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertOsAbertura([FromBody]OsAberturaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert OsAbertura]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectOsAbertura", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert OsAbertura]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateOsAbertura([FromBody]OsAberturaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update OsAbertura]", null));
                }

                _service.Update(objJson);

                return GetObjectOsAbertura(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update OsAbertura]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOsAbertura(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete OsAbertura]", ex));
            }
        }

    }
}