namespace ordem_servico.Models
{
	public class ProdutoGrupoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		private IList<ProdutoSubgrupoModel>? produtoSubgrupoModelList; 
		public IList<ProdutoSubgrupoModel>? ProdutoSubgrupoModelList 
		{ 
			get 
			{ 
				return produtoSubgrupoModelList; 
			} 
			set 
			{ 
				produtoSubgrupoModelList = value; 
				foreach (ProdutoSubgrupoModel produtoSubgrupoModel in produtoSubgrupoModelList!) 
				{ 
					produtoSubgrupoModel.ProdutoGrupoModel = this; 
				} 
			} 
		} 

	}
}
