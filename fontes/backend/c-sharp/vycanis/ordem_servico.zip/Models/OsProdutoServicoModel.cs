namespace ordem_servico.Models
{
	public class OsProdutoServicoModel
	{	
		public int? Id { get; set; } 

		public string? Tipo { get; set; } 

		public string? Complemento { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public System.Nullable<System.Decimal> ValorUnitario { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public OsAberturaModel? OsAberturaModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
