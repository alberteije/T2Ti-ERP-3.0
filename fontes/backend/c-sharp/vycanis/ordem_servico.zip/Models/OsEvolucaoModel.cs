namespace ordem_servico.Models
{
	public class OsEvolucaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataRegistro { get; set; } 

		public string? HoraRegistro { get; set; } 

		public string? EnviarEmail { get; set; } 

		public string? Observacao { get; set; } 

		public OsAberturaModel? OsAberturaModel { get; set; } 

	}
}
