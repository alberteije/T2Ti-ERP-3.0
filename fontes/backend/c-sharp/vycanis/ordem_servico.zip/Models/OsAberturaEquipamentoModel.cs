namespace ordem_servico.Models
{
	public class OsAberturaEquipamentoModel
	{	
		public int? Id { get; set; } 

		public string? TipoCobertura { get; set; } 

		public string? NumeroSerie { get; set; } 

		public OsAberturaModel? OsAberturaModel { get; set; } 

		public OsEquipamentoModel? OsEquipamentoModel { get; set; } 

	}
}
