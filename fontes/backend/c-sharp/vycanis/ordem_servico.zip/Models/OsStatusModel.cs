namespace ordem_servico.Models
{
	public class OsStatusModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

	}
}
