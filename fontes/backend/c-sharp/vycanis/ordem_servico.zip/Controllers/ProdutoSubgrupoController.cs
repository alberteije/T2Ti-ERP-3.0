using Microsoft.AspNetCore.Mvc;
using ordem_servico.Models;
using ordem_servico.Services;

namespace ordem_servico.Controllers
{
    [Route("produto-subgrupo")]
    [Produces("application/json")]
    public class ProdutoSubgrupoController : Controller
    {
		private readonly ProdutoSubgrupoService _service;

        public ProdutoSubgrupoController()
        {
            _service = new ProdutoSubgrupoService();
        }

        [HttpGet]
        public IActionResult GetListProdutoSubgrupo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ProdutoSubgrupoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ProdutoSubgrupo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectProdutoSubgrupo")]
        public IActionResult GetObjectProdutoSubgrupo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ProdutoSubgrupo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ProdutoSubgrupo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertProdutoSubgrupo([FromBody]ProdutoSubgrupoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ProdutoSubgrupo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectProdutoSubgrupo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ProdutoSubgrupo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateProdutoSubgrupo([FromBody]ProdutoSubgrupoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ProdutoSubgrupo]", null));
                }

                _service.Update(objJson);

                return GetObjectProdutoSubgrupo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ProdutoSubgrupo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProdutoSubgrupo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ProdutoSubgrupo]", ex));
            }
        }

    }
}