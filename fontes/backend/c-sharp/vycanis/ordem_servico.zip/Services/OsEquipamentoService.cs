using ordem_servico.Models;
using ordem_servico.NHibernate;
using ISession = NHibernate.ISession;

namespace ordem_servico.Services
{
    public class OsEquipamentoService
    {

        public IEnumerable<OsEquipamentoModel> GetList()
        {
            IList<OsEquipamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsEquipamentoModel> DAL = new NHibernateDAL<OsEquipamentoModel>(Session);
                Result = DAL.Select(new OsEquipamentoModel());
            }
            return Result;
        }

        public IEnumerable<OsEquipamentoModel> GetListFilter(Filter filterObj)
        {
            IList<OsEquipamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OsEquipamentoModel where " + filterObj.Where;
                NHibernateDAL<OsEquipamentoModel> DAL = new NHibernateDAL<OsEquipamentoModel>(Session);
                Result = DAL.SelectListSql<OsEquipamentoModel>(Query);
            }
            return Result;
        }
		
        public OsEquipamentoModel GetObject(int id)
        {
            OsEquipamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsEquipamentoModel> DAL = new NHibernateDAL<OsEquipamentoModel>(Session);
                Result = DAL.SelectId<OsEquipamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(OsEquipamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsEquipamentoModel> DAL = new NHibernateDAL<OsEquipamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OsEquipamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsEquipamentoModel> DAL = new NHibernateDAL<OsEquipamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OsEquipamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OsEquipamentoModel> DAL = new NHibernateDAL<OsEquipamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}