using ordem_servico.Models;
using ordem_servico.NHibernate;
using ISession = NHibernate.ISession;

namespace ordem_servico.Services
{
    public class ProdutoMarcaService
    {

        public IEnumerable<ProdutoMarcaModel> GetList()
        {
            IList<ProdutoMarcaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoMarcaModel> DAL = new NHibernateDAL<ProdutoMarcaModel>(Session);
                Result = DAL.Select(new ProdutoMarcaModel());
            }
            return Result;
        }

        public IEnumerable<ProdutoMarcaModel> GetListFilter(Filter filterObj)
        {
            IList<ProdutoMarcaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ProdutoMarcaModel where " + filterObj.Where;
                NHibernateDAL<ProdutoMarcaModel> DAL = new NHibernateDAL<ProdutoMarcaModel>(Session);
                Result = DAL.SelectListSql<ProdutoMarcaModel>(Query);
            }
            return Result;
        }
		
        public ProdutoMarcaModel GetObject(int id)
        {
            ProdutoMarcaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoMarcaModel> DAL = new NHibernateDAL<ProdutoMarcaModel>(Session);
                Result = DAL.SelectId<ProdutoMarcaModel>(id);
            }
            return Result;
        }
		
        public void Insert(ProdutoMarcaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoMarcaModel> DAL = new NHibernateDAL<ProdutoMarcaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ProdutoMarcaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoMarcaModel> DAL = new NHibernateDAL<ProdutoMarcaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ProdutoMarcaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoMarcaModel> DAL = new NHibernateDAL<ProdutoMarcaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}