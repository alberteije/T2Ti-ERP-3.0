using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-rodoviario-motorista")]
    [Produces("application/json")]
    public class CteRodoviarioMotoristaController : Controller
    {
		private readonly CteRodoviarioMotoristaService _service;

        public CteRodoviarioMotoristaController()
        {
            _service = new CteRodoviarioMotoristaService();
        }

        [HttpGet]
        public IActionResult GetListCteRodoviarioMotorista([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteRodoviarioMotoristaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteRodoviarioMotorista]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteRodoviarioMotorista")]
        public IActionResult GetObjectCteRodoviarioMotorista(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteRodoviarioMotorista]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteRodoviarioMotorista]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteRodoviarioMotorista([FromBody]CteRodoviarioMotoristaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteRodoviarioMotorista]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteRodoviarioMotorista", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteRodoviarioMotorista]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteRodoviarioMotorista([FromBody]CteRodoviarioMotoristaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteRodoviarioMotorista]", null));
                }

                _service.Update(objJson);

                return GetObjectCteRodoviarioMotorista(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteRodoviarioMotorista]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteRodoviarioMotorista(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteRodoviarioMotorista]", ex));
            }
        }

    }
}