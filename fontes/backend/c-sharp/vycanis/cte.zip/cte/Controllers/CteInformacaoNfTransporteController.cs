using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-informacao-nf-transporte")]
    [Produces("application/json")]
    public class CteInformacaoNfTransporteController : Controller
    {
		private readonly CteInformacaoNfTransporteService _service;

        public CteInformacaoNfTransporteController()
        {
            _service = new CteInformacaoNfTransporteService();
        }

        [HttpGet]
        public IActionResult GetListCteInformacaoNfTransporte([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteInformacaoNfTransporteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteInformacaoNfTransporte]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteInformacaoNfTransporte")]
        public IActionResult GetObjectCteInformacaoNfTransporte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteInformacaoNfTransporte]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteInformacaoNfTransporte]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteInformacaoNfTransporte([FromBody]CteInformacaoNfTransporteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteInformacaoNfTransporte]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteInformacaoNfTransporte", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteInformacaoNfTransporte]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteInformacaoNfTransporte([FromBody]CteInformacaoNfTransporteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteInformacaoNfTransporte]", null));
                }

                _service.Update(objJson);

                return GetObjectCteInformacaoNfTransporte(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteInformacaoNfTransporte]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteInformacaoNfTransporte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteInformacaoNfTransporte]", ex));
            }
        }

    }
}