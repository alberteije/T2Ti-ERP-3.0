using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-ferroviario-vagao")]
    [Produces("application/json")]
    public class CteFerroviarioVagaoController : Controller
    {
		private readonly CteFerroviarioVagaoService _service;

        public CteFerroviarioVagaoController()
        {
            _service = new CteFerroviarioVagaoService();
        }

        [HttpGet]
        public IActionResult GetListCteFerroviarioVagao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteFerroviarioVagaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteFerroviarioVagao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteFerroviarioVagao")]
        public IActionResult GetObjectCteFerroviarioVagao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteFerroviarioVagao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteFerroviarioVagao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteFerroviarioVagao([FromBody]CteFerroviarioVagaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteFerroviarioVagao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteFerroviarioVagao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteFerroviarioVagao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteFerroviarioVagao([FromBody]CteFerroviarioVagaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteFerroviarioVagao]", null));
                }

                _service.Update(objJson);

                return GetObjectCteFerroviarioVagao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteFerroviarioVagao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteFerroviarioVagao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteFerroviarioVagao]", ex));
            }
        }

    }
}