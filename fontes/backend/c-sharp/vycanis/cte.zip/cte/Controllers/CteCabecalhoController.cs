using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-cabecalho")]
    [Produces("application/json")]
    public class CteCabecalhoController : Controller
    {
		private readonly CteCabecalhoService _service;

        public CteCabecalhoController()
        {
            _service = new CteCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListCteCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteCabecalho")]
        public IActionResult GetObjectCteCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteCabecalho([FromBody]CteCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteCabecalho([FromBody]CteCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectCteCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteCabecalho]", ex));
            }
        }

    }
}