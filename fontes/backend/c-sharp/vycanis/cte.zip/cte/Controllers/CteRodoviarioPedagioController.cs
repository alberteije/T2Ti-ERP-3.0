using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-rodoviario-pedagio")]
    [Produces("application/json")]
    public class CteRodoviarioPedagioController : Controller
    {
		private readonly CteRodoviarioPedagioService _service;

        public CteRodoviarioPedagioController()
        {
            _service = new CteRodoviarioPedagioService();
        }

        [HttpGet]
        public IActionResult GetListCteRodoviarioPedagio([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteRodoviarioPedagioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteRodoviarioPedagio]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteRodoviarioPedagio")]
        public IActionResult GetObjectCteRodoviarioPedagio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteRodoviarioPedagio]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteRodoviarioPedagio]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteRodoviarioPedagio([FromBody]CteRodoviarioPedagioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteRodoviarioPedagio]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteRodoviarioPedagio", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteRodoviarioPedagio]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteRodoviarioPedagio([FromBody]CteRodoviarioPedagioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteRodoviarioPedagio]", null));
                }

                _service.Update(objJson);

                return GetObjectCteRodoviarioPedagio(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteRodoviarioPedagio]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteRodoviarioPedagio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteRodoviarioPedagio]", ex));
            }
        }

    }
}