using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteInformacaoNfCargaService
    {

        public IEnumerable<CteInformacaoNfCargaModel> GetList()
        {
            IList<CteInformacaoNfCargaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfCargaModel> DAL = new NHibernateDAL<CteInformacaoNfCargaModel>(Session);
                Result = DAL.Select(new CteInformacaoNfCargaModel());
            }
            return Result;
        }

        public IEnumerable<CteInformacaoNfCargaModel> GetListFilter(Filter filterObj)
        {
            IList<CteInformacaoNfCargaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteInformacaoNfCargaModel where " + filterObj.Where;
                NHibernateDAL<CteInformacaoNfCargaModel> DAL = new NHibernateDAL<CteInformacaoNfCargaModel>(Session);
                Result = DAL.SelectListSql<CteInformacaoNfCargaModel>(Query);
            }
            return Result;
        }
		
        public CteInformacaoNfCargaModel GetObject(int id)
        {
            CteInformacaoNfCargaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfCargaModel> DAL = new NHibernateDAL<CteInformacaoNfCargaModel>(Session);
                Result = DAL.SelectId<CteInformacaoNfCargaModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteInformacaoNfCargaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfCargaModel> DAL = new NHibernateDAL<CteInformacaoNfCargaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteInformacaoNfCargaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfCargaModel> DAL = new NHibernateDAL<CteInformacaoNfCargaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteInformacaoNfCargaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfCargaModel> DAL = new NHibernateDAL<CteInformacaoNfCargaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}