using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteAquaviarioBalsaService
    {

        public IEnumerable<CteAquaviarioBalsaModel> GetList()
        {
            IList<CteAquaviarioBalsaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteAquaviarioBalsaModel> DAL = new NHibernateDAL<CteAquaviarioBalsaModel>(Session);
                Result = DAL.Select(new CteAquaviarioBalsaModel());
            }
            return Result;
        }

        public IEnumerable<CteAquaviarioBalsaModel> GetListFilter(Filter filterObj)
        {
            IList<CteAquaviarioBalsaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteAquaviarioBalsaModel where " + filterObj.Where;
                NHibernateDAL<CteAquaviarioBalsaModel> DAL = new NHibernateDAL<CteAquaviarioBalsaModel>(Session);
                Result = DAL.SelectListSql<CteAquaviarioBalsaModel>(Query);
            }
            return Result;
        }
		
        public CteAquaviarioBalsaModel GetObject(int id)
        {
            CteAquaviarioBalsaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteAquaviarioBalsaModel> DAL = new NHibernateDAL<CteAquaviarioBalsaModel>(Session);
                Result = DAL.SelectId<CteAquaviarioBalsaModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteAquaviarioBalsaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteAquaviarioBalsaModel> DAL = new NHibernateDAL<CteAquaviarioBalsaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteAquaviarioBalsaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteAquaviarioBalsaModel> DAL = new NHibernateDAL<CteAquaviarioBalsaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteAquaviarioBalsaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteAquaviarioBalsaModel> DAL = new NHibernateDAL<CteAquaviarioBalsaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}