using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteRodoviarioVeiculoService
    {

        public IEnumerable<CteRodoviarioVeiculoModel> GetList()
        {
            IList<CteRodoviarioVeiculoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioVeiculoModel> DAL = new NHibernateDAL<CteRodoviarioVeiculoModel>(Session);
                Result = DAL.Select(new CteRodoviarioVeiculoModel());
            }
            return Result;
        }

        public IEnumerable<CteRodoviarioVeiculoModel> GetListFilter(Filter filterObj)
        {
            IList<CteRodoviarioVeiculoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteRodoviarioVeiculoModel where " + filterObj.Where;
                NHibernateDAL<CteRodoviarioVeiculoModel> DAL = new NHibernateDAL<CteRodoviarioVeiculoModel>(Session);
                Result = DAL.SelectListSql<CteRodoviarioVeiculoModel>(Query);
            }
            return Result;
        }
		
        public CteRodoviarioVeiculoModel GetObject(int id)
        {
            CteRodoviarioVeiculoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioVeiculoModel> DAL = new NHibernateDAL<CteRodoviarioVeiculoModel>(Session);
                Result = DAL.SelectId<CteRodoviarioVeiculoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteRodoviarioVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioVeiculoModel> DAL = new NHibernateDAL<CteRodoviarioVeiculoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteRodoviarioVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioVeiculoModel> DAL = new NHibernateDAL<CteRodoviarioVeiculoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteRodoviarioVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioVeiculoModel> DAL = new NHibernateDAL<CteRodoviarioVeiculoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}