using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteRodoviarioOccService
    {

        public IEnumerable<CteRodoviarioOccModel> GetList()
        {
            IList<CteRodoviarioOccModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioOccModel> DAL = new NHibernateDAL<CteRodoviarioOccModel>(Session);
                Result = DAL.Select(new CteRodoviarioOccModel());
            }
            return Result;
        }

        public IEnumerable<CteRodoviarioOccModel> GetListFilter(Filter filterObj)
        {
            IList<CteRodoviarioOccModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteRodoviarioOccModel where " + filterObj.Where;
                NHibernateDAL<CteRodoviarioOccModel> DAL = new NHibernateDAL<CteRodoviarioOccModel>(Session);
                Result = DAL.SelectListSql<CteRodoviarioOccModel>(Query);
            }
            return Result;
        }
		
        public CteRodoviarioOccModel GetObject(int id)
        {
            CteRodoviarioOccModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioOccModel> DAL = new NHibernateDAL<CteRodoviarioOccModel>(Session);
                Result = DAL.SelectId<CteRodoviarioOccModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteRodoviarioOccModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioOccModel> DAL = new NHibernateDAL<CteRodoviarioOccModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteRodoviarioOccModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioOccModel> DAL = new NHibernateDAL<CteRodoviarioOccModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteRodoviarioOccModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioOccModel> DAL = new NHibernateDAL<CteRodoviarioOccModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}