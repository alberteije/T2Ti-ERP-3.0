using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteInfNfCargaLacreService
    {

        public IEnumerable<CteInfNfCargaLacreModel> GetList()
        {
            IList<CteInfNfCargaLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfCargaLacreModel> DAL = new NHibernateDAL<CteInfNfCargaLacreModel>(Session);
                Result = DAL.Select(new CteInfNfCargaLacreModel());
            }
            return Result;
        }

        public IEnumerable<CteInfNfCargaLacreModel> GetListFilter(Filter filterObj)
        {
            IList<CteInfNfCargaLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteInfNfCargaLacreModel where " + filterObj.Where;
                NHibernateDAL<CteInfNfCargaLacreModel> DAL = new NHibernateDAL<CteInfNfCargaLacreModel>(Session);
                Result = DAL.SelectListSql<CteInfNfCargaLacreModel>(Query);
            }
            return Result;
        }
		
        public CteInfNfCargaLacreModel GetObject(int id)
        {
            CteInfNfCargaLacreModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfCargaLacreModel> DAL = new NHibernateDAL<CteInfNfCargaLacreModel>(Session);
                Result = DAL.SelectId<CteInfNfCargaLacreModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteInfNfCargaLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfCargaLacreModel> DAL = new NHibernateDAL<CteInfNfCargaLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteInfNfCargaLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfCargaLacreModel> DAL = new NHibernateDAL<CteInfNfCargaLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteInfNfCargaLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfCargaLacreModel> DAL = new NHibernateDAL<CteInfNfCargaLacreModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}