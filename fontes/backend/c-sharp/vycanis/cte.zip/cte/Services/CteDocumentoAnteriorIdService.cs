using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteDocumentoAnteriorIdService
    {

        public IEnumerable<CteDocumentoAnteriorIdModel> GetList()
        {
            IList<CteDocumentoAnteriorIdModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteDocumentoAnteriorIdModel> DAL = new NHibernateDAL<CteDocumentoAnteriorIdModel>(Session);
                Result = DAL.Select(new CteDocumentoAnteriorIdModel());
            }
            return Result;
        }

        public IEnumerable<CteDocumentoAnteriorIdModel> GetListFilter(Filter filterObj)
        {
            IList<CteDocumentoAnteriorIdModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteDocumentoAnteriorIdModel where " + filterObj.Where;
                NHibernateDAL<CteDocumentoAnteriorIdModel> DAL = new NHibernateDAL<CteDocumentoAnteriorIdModel>(Session);
                Result = DAL.SelectListSql<CteDocumentoAnteriorIdModel>(Query);
            }
            return Result;
        }
		
        public CteDocumentoAnteriorIdModel GetObject(int id)
        {
            CteDocumentoAnteriorIdModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteDocumentoAnteriorIdModel> DAL = new NHibernateDAL<CteDocumentoAnteriorIdModel>(Session);
                Result = DAL.SelectId<CteDocumentoAnteriorIdModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteDocumentoAnteriorIdModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteDocumentoAnteriorIdModel> DAL = new NHibernateDAL<CteDocumentoAnteriorIdModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteDocumentoAnteriorIdModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteDocumentoAnteriorIdModel> DAL = new NHibernateDAL<CteDocumentoAnteriorIdModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteDocumentoAnteriorIdModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteDocumentoAnteriorIdModel> DAL = new NHibernateDAL<CteDocumentoAnteriorIdModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}