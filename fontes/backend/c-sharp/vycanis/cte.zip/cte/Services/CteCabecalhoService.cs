using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteCabecalhoService
    {

        public IEnumerable<CteCabecalhoModel> GetList()
        {
            IList<CteCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteCabecalhoModel> DAL = new NHibernateDAL<CteCabecalhoModel>(Session);
                Result = DAL.Select(new CteCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<CteCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<CteCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<CteCabecalhoModel> DAL = new NHibernateDAL<CteCabecalhoModel>(Session);
                Result = DAL.SelectListSql<CteCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public CteCabecalhoModel GetObject(int id)
        {
            CteCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteCabecalhoModel> DAL = new NHibernateDAL<CteCabecalhoModel>(Session);
                Result = DAL.SelectId<CteCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteCabecalhoModel> DAL = new NHibernateDAL<CteCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteCabecalhoModel> DAL = new NHibernateDAL<CteCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteCabecalhoModel> DAL = new NHibernateDAL<CteCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}