namespace cte.Models
{
	public class CteInfNfCargaLacreModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeRateada { get; set; } 

		public CteInformacaoNfCargaModel? CteInformacaoNfCargaModel { get; set; } 

	}
}
