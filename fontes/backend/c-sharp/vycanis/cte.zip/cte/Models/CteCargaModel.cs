namespace cte.Models
{
	public class CteCargaModel
	{	
		public int? Id { get; set; } 

		public string? CodigoUnidadeMedida { get; set; } 

		public string? TipoMedida { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
