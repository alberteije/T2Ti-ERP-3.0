namespace cte.Models
{
	public class CteDocumentoAnteriorIdModel
	{	
		public int? Id { get; set; } 

		public string? Tipo { get; set; } 

		public string? Serie { get; set; } 

		public string? Subserie { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public string? ChaveCte { get; set; } 

	}
}
