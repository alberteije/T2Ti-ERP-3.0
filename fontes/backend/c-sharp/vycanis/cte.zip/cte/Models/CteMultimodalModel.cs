namespace cte.Models
{
	public class CteMultimodalModel
	{	
		public int? Id { get; set; } 

		public string? Cotm { get; set; } 

		public string? IndicadorNegociavel { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
