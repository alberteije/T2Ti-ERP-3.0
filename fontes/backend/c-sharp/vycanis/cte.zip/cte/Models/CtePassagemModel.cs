namespace cte.Models
{
	public class CtePassagemModel
	{	
		public int? Id { get; set; } 

		public string? SiglaPassagem { get; set; } 

		public string? SiglaDestino { get; set; } 

		public string? Rota { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
