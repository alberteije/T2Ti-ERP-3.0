namespace cte.Models
{
	public class CteVeiculoNovoModel
	{	
		public int? Id { get; set; } 

		public string? Chassi { get; set; } 

		public string? Cor { get; set; } 

		public string? DescricaoCor { get; set; } 

		public string? CodigoMarcaModelo { get; set; } 

		public System.Nullable<System.Decimal> ValorUnitario { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
