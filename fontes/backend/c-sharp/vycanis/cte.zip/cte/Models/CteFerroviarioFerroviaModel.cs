namespace cte.Models
{
	public class CteFerroviarioFerroviaModel
	{	
		public int? Id { get; set; } 

		public string? Cnpj { get; set; } 

		public string? CodigoInterno { get; set; } 

		public string? Ie { get; set; } 

		public string? Nome { get; set; } 

		public string? Logradouro { get; set; } 

		public string? Numero { get; set; } 

		public string? Complemento { get; set; } 

		public string? Bairro { get; set; } 

		public int? CodigoMunicipio { get; set; } 

		public string? NomeMunicipio { get; set; } 

		public string? Uf { get; set; } 

		public string? Cep { get; set; } 

		public CteFerroviarioModel? CteFerroviarioModel { get; set; } 

	}
}
