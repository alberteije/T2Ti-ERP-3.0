namespace cte.Models
{
	public class CteFerroviarioVagaoModel
	{	
		public int? Id { get; set; } 

		public int? NumeroVagao { get; set; } 

		public System.Nullable<System.Decimal> Capacidade { get; set; } 

		public string? TipoVagao { get; set; } 

		public System.Nullable<System.Decimal> PesoReal { get; set; } 

		public System.Nullable<System.Decimal> PesoBc { get; set; } 

		public CteFerroviarioModel? CteFerroviarioModel { get; set; } 

	}
}
