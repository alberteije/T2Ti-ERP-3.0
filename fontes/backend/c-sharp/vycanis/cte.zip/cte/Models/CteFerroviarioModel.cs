namespace cte.Models
{
	public class CteFerroviarioModel
	{	
		public int? Id { get; set; } 

		public string? TipoTrafego { get; set; } 

		public string? ResponsavelFaturamento { get; set; } 

		public string? FerroviaEmitenteCte { get; set; } 

		public string? Fluxo { get; set; } 

		public string? IdTrem { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
