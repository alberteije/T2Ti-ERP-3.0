namespace cte.Models
{
	public class CteRodoviarioModel
	{	
		public int? Id { get; set; } 

		public string? Rntrc { get; set; } 

		public System.Nullable<System.DateTime> DataPrevistaEntrega { get; set; } 

		public string? IndicadorLotacao { get; set; } 

		public int? Ciot { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
