namespace cte.Models
{
	public class CteLocalEntregaModel
	{	
		public int? Id { get; set; } 

		public string? Cnpj { get; set; } 

		public string? Cpf { get; set; } 

		public string? Nome { get; set; } 

		public string? Logradouro { get; set; } 

		public string? Numero { get; set; } 

		public string? Complemento { get; set; } 

		public string? Bairro { get; set; } 

		public int? CodigoMunicipio { get; set; } 

		public string? NomeMunicipio { get; set; } 

		public string? Uf { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
