namespace cte.Models
{
	public class CteDutoviarioModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorTarifa { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
