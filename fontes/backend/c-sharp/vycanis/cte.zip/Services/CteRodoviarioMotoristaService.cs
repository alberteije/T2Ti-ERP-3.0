using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteRodoviarioMotoristaService
    {

        public IEnumerable<CteRodoviarioMotoristaModel> GetList()
        {
            IList<CteRodoviarioMotoristaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioMotoristaModel> DAL = new NHibernateDAL<CteRodoviarioMotoristaModel>(Session);
                Result = DAL.Select(new CteRodoviarioMotoristaModel());
            }
            return Result;
        }

        public IEnumerable<CteRodoviarioMotoristaModel> GetListFilter(Filter filterObj)
        {
            IList<CteRodoviarioMotoristaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteRodoviarioMotoristaModel where " + filterObj.Where;
                NHibernateDAL<CteRodoviarioMotoristaModel> DAL = new NHibernateDAL<CteRodoviarioMotoristaModel>(Session);
                Result = DAL.SelectListSql<CteRodoviarioMotoristaModel>(Query);
            }
            return Result;
        }
		
        public CteRodoviarioMotoristaModel GetObject(int id)
        {
            CteRodoviarioMotoristaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioMotoristaModel> DAL = new NHibernateDAL<CteRodoviarioMotoristaModel>(Session);
                Result = DAL.SelectId<CteRodoviarioMotoristaModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteRodoviarioMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioMotoristaModel> DAL = new NHibernateDAL<CteRodoviarioMotoristaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteRodoviarioMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioMotoristaModel> DAL = new NHibernateDAL<CteRodoviarioMotoristaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteRodoviarioMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioMotoristaModel> DAL = new NHibernateDAL<CteRodoviarioMotoristaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}