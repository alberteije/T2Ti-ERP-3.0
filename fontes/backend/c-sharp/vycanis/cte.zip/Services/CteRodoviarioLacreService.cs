using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteRodoviarioLacreService
    {

        public IEnumerable<CteRodoviarioLacreModel> GetList()
        {
            IList<CteRodoviarioLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioLacreModel> DAL = new NHibernateDAL<CteRodoviarioLacreModel>(Session);
                Result = DAL.Select(new CteRodoviarioLacreModel());
            }
            return Result;
        }

        public IEnumerable<CteRodoviarioLacreModel> GetListFilter(Filter filterObj)
        {
            IList<CteRodoviarioLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteRodoviarioLacreModel where " + filterObj.Where;
                NHibernateDAL<CteRodoviarioLacreModel> DAL = new NHibernateDAL<CteRodoviarioLacreModel>(Session);
                Result = DAL.SelectListSql<CteRodoviarioLacreModel>(Query);
            }
            return Result;
        }
		
        public CteRodoviarioLacreModel GetObject(int id)
        {
            CteRodoviarioLacreModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioLacreModel> DAL = new NHibernateDAL<CteRodoviarioLacreModel>(Session);
                Result = DAL.SelectId<CteRodoviarioLacreModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteRodoviarioLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioLacreModel> DAL = new NHibernateDAL<CteRodoviarioLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteRodoviarioLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioLacreModel> DAL = new NHibernateDAL<CteRodoviarioLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteRodoviarioLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioLacreModel> DAL = new NHibernateDAL<CteRodoviarioLacreModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}