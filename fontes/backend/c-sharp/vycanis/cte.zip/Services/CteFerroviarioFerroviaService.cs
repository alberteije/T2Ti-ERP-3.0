using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteFerroviarioFerroviaService
    {

        public IEnumerable<CteFerroviarioFerroviaModel> GetList()
        {
            IList<CteFerroviarioFerroviaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioFerroviaModel> DAL = new NHibernateDAL<CteFerroviarioFerroviaModel>(Session);
                Result = DAL.Select(new CteFerroviarioFerroviaModel());
            }
            return Result;
        }

        public IEnumerable<CteFerroviarioFerroviaModel> GetListFilter(Filter filterObj)
        {
            IList<CteFerroviarioFerroviaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteFerroviarioFerroviaModel where " + filterObj.Where;
                NHibernateDAL<CteFerroviarioFerroviaModel> DAL = new NHibernateDAL<CteFerroviarioFerroviaModel>(Session);
                Result = DAL.SelectListSql<CteFerroviarioFerroviaModel>(Query);
            }
            return Result;
        }
		
        public CteFerroviarioFerroviaModel GetObject(int id)
        {
            CteFerroviarioFerroviaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioFerroviaModel> DAL = new NHibernateDAL<CteFerroviarioFerroviaModel>(Session);
                Result = DAL.SelectId<CteFerroviarioFerroviaModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteFerroviarioFerroviaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioFerroviaModel> DAL = new NHibernateDAL<CteFerroviarioFerroviaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteFerroviarioFerroviaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioFerroviaModel> DAL = new NHibernateDAL<CteFerroviarioFerroviaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteFerroviarioFerroviaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioFerroviaModel> DAL = new NHibernateDAL<CteFerroviarioFerroviaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}