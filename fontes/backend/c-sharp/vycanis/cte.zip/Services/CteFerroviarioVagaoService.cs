using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteFerroviarioVagaoService
    {

        public IEnumerable<CteFerroviarioVagaoModel> GetList()
        {
            IList<CteFerroviarioVagaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioVagaoModel> DAL = new NHibernateDAL<CteFerroviarioVagaoModel>(Session);
                Result = DAL.Select(new CteFerroviarioVagaoModel());
            }
            return Result;
        }

        public IEnumerable<CteFerroviarioVagaoModel> GetListFilter(Filter filterObj)
        {
            IList<CteFerroviarioVagaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteFerroviarioVagaoModel where " + filterObj.Where;
                NHibernateDAL<CteFerroviarioVagaoModel> DAL = new NHibernateDAL<CteFerroviarioVagaoModel>(Session);
                Result = DAL.SelectListSql<CteFerroviarioVagaoModel>(Query);
            }
            return Result;
        }
		
        public CteFerroviarioVagaoModel GetObject(int id)
        {
            CteFerroviarioVagaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioVagaoModel> DAL = new NHibernateDAL<CteFerroviarioVagaoModel>(Session);
                Result = DAL.SelectId<CteFerroviarioVagaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteFerroviarioVagaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioVagaoModel> DAL = new NHibernateDAL<CteFerroviarioVagaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteFerroviarioVagaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioVagaoModel> DAL = new NHibernateDAL<CteFerroviarioVagaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteFerroviarioVagaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteFerroviarioVagaoModel> DAL = new NHibernateDAL<CteFerroviarioVagaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}