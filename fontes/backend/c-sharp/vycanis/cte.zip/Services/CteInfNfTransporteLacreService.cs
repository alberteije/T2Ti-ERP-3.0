using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteInfNfTransporteLacreService
    {

        public IEnumerable<CteInfNfTransporteLacreModel> GetList()
        {
            IList<CteInfNfTransporteLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfTransporteLacreModel> DAL = new NHibernateDAL<CteInfNfTransporteLacreModel>(Session);
                Result = DAL.Select(new CteInfNfTransporteLacreModel());
            }
            return Result;
        }

        public IEnumerable<CteInfNfTransporteLacreModel> GetListFilter(Filter filterObj)
        {
            IList<CteInfNfTransporteLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteInfNfTransporteLacreModel where " + filterObj.Where;
                NHibernateDAL<CteInfNfTransporteLacreModel> DAL = new NHibernateDAL<CteInfNfTransporteLacreModel>(Session);
                Result = DAL.SelectListSql<CteInfNfTransporteLacreModel>(Query);
            }
            return Result;
        }
		
        public CteInfNfTransporteLacreModel GetObject(int id)
        {
            CteInfNfTransporteLacreModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfTransporteLacreModel> DAL = new NHibernateDAL<CteInfNfTransporteLacreModel>(Session);
                Result = DAL.SelectId<CteInfNfTransporteLacreModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteInfNfTransporteLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfTransporteLacreModel> DAL = new NHibernateDAL<CteInfNfTransporteLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteInfNfTransporteLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfTransporteLacreModel> DAL = new NHibernateDAL<CteInfNfTransporteLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteInfNfTransporteLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInfNfTransporteLacreModel> DAL = new NHibernateDAL<CteInfNfTransporteLacreModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}