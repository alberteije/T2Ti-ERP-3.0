using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteRodoviarioPedagioService
    {

        public IEnumerable<CteRodoviarioPedagioModel> GetList()
        {
            IList<CteRodoviarioPedagioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioPedagioModel> DAL = new NHibernateDAL<CteRodoviarioPedagioModel>(Session);
                Result = DAL.Select(new CteRodoviarioPedagioModel());
            }
            return Result;
        }

        public IEnumerable<CteRodoviarioPedagioModel> GetListFilter(Filter filterObj)
        {
            IList<CteRodoviarioPedagioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteRodoviarioPedagioModel where " + filterObj.Where;
                NHibernateDAL<CteRodoviarioPedagioModel> DAL = new NHibernateDAL<CteRodoviarioPedagioModel>(Session);
                Result = DAL.SelectListSql<CteRodoviarioPedagioModel>(Query);
            }
            return Result;
        }
		
        public CteRodoviarioPedagioModel GetObject(int id)
        {
            CteRodoviarioPedagioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioPedagioModel> DAL = new NHibernateDAL<CteRodoviarioPedagioModel>(Session);
                Result = DAL.SelectId<CteRodoviarioPedagioModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteRodoviarioPedagioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioPedagioModel> DAL = new NHibernateDAL<CteRodoviarioPedagioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteRodoviarioPedagioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioPedagioModel> DAL = new NHibernateDAL<CteRodoviarioPedagioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteRodoviarioPedagioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteRodoviarioPedagioModel> DAL = new NHibernateDAL<CteRodoviarioPedagioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}