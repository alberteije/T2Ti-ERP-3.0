using cte.Models;
using cte.NHibernate;
using ISession = NHibernate.ISession;

namespace cte.Services
{
    public class CteInformacaoNfTransporteService
    {

        public IEnumerable<CteInformacaoNfTransporteModel> GetList()
        {
            IList<CteInformacaoNfTransporteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfTransporteModel> DAL = new NHibernateDAL<CteInformacaoNfTransporteModel>(Session);
                Result = DAL.Select(new CteInformacaoNfTransporteModel());
            }
            return Result;
        }

        public IEnumerable<CteInformacaoNfTransporteModel> GetListFilter(Filter filterObj)
        {
            IList<CteInformacaoNfTransporteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CteInformacaoNfTransporteModel where " + filterObj.Where;
                NHibernateDAL<CteInformacaoNfTransporteModel> DAL = new NHibernateDAL<CteInformacaoNfTransporteModel>(Session);
                Result = DAL.SelectListSql<CteInformacaoNfTransporteModel>(Query);
            }
            return Result;
        }
		
        public CteInformacaoNfTransporteModel GetObject(int id)
        {
            CteInformacaoNfTransporteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfTransporteModel> DAL = new NHibernateDAL<CteInformacaoNfTransporteModel>(Session);
                Result = DAL.SelectId<CteInformacaoNfTransporteModel>(id);
            }
            return Result;
        }
		
        public void Insert(CteInformacaoNfTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfTransporteModel> DAL = new NHibernateDAL<CteInformacaoNfTransporteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CteInformacaoNfTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfTransporteModel> DAL = new NHibernateDAL<CteInformacaoNfTransporteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CteInformacaoNfTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CteInformacaoNfTransporteModel> DAL = new NHibernateDAL<CteInformacaoNfTransporteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}