namespace cte.Models
{
	public class CteInformacaoNfCargaModel
	{	
		public int? Id { get; set; } 

		public string? TipoUnidadeCarga { get; set; } 

		public string? IdUnidadeCarga { get; set; } 

		public CteInformacaoNfOutrosModel? CteInformacaoNfOutrosModel { get; set; } 

	}
}
