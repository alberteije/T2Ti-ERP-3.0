namespace cte.Models
{
	public class CteRodoviarioVeiculoModel
	{	
		public int? Id { get; set; } 

		public string? CodigoInterno { get; set; } 

		public string? Renavam { get; set; } 

		public string? Placa { get; set; } 

		public int? Tara { get; set; } 

		public int? CapacidadeKg { get; set; } 

		public int? CapacidadeM3 { get; set; } 

		public string? TipoPropriedade { get; set; } 

		public string? TipoVeiculo { get; set; } 

		public string? TipoRodado { get; set; } 

		public string? TipoCarroceria { get; set; } 

		public string? Uf { get; set; } 

		public string? ProprietarioCpf { get; set; } 

		public string? ProprietarioCnpj { get; set; } 

		public string? ProprietarioRntrc { get; set; } 

		public string? ProprietarioNome { get; set; } 

		public string? ProprietarioIe { get; set; } 

		public string? ProprietarioUf { get; set; } 

		public string? ProprietarioTipo { get; set; } 

		public CteRodoviarioModel? CteRodoviarioModel { get; set; } 

	}
}
