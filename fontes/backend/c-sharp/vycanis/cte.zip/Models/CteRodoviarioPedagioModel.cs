namespace cte.Models
{
	public class CteRodoviarioPedagioModel
	{	
		public int? Id { get; set; } 

		public string? CnpjFornecedor { get; set; } 

		public string? ComprovanteCompra { get; set; } 

		public string? CnpjResponsavel { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public CteRodoviarioModel? CteRodoviarioModel { get; set; } 

	}
}
