namespace cte.Models
{
	public class CteRodoviarioMotoristaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Cpf { get; set; } 

		public CteRodoviarioModel? CteRodoviarioModel { get; set; } 

	}
}
