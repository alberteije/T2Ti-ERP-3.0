namespace cte.Models
{
	public class CtePerigosoModel
	{	
		public int? Id { get; set; } 

		public string? NumeroOnu { get; set; } 

		public string? NomeApropriado { get; set; } 

		public string? ClasseRisco { get; set; } 

		public string? GrupoEmbalagem { get; set; } 

		public string? QuantidadeTotalProduto { get; set; } 

		public string? QuantidadeTipoVolume { get; set; } 

		public string? PontoFulgor { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
