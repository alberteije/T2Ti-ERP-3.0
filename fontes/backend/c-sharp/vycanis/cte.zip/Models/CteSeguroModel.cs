namespace cte.Models
{
	public class CteSeguroModel
	{	
		public int? Id { get; set; } 

		public string? Responsavel { get; set; } 

		public string? Seguradora { get; set; } 

		public string? Apolice { get; set; } 

		public string? Averbacao { get; set; } 

		public System.Nullable<System.Decimal> ValorCarga { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
