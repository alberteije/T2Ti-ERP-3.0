namespace cte.Models
{
	public class CteComponenteModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
