namespace cte.Models
{
	public class CteInformacaoNfOutrosModel
	{	
		public int? Id { get; set; } 

		public string? NumeroRomaneio { get; set; } 

		public string? NumeroPedido { get; set; } 

		public string? ChaveAcessoNfe { get; set; } 

		public string? CodigoModelo { get; set; } 

		public string? Serie { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public int? UfEmitente { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcms { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalProdutos { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public int? CfopPredominante { get; set; } 

		public System.Nullable<System.Decimal> PesoTotalKg { get; set; } 

		public int? PinSuframa { get; set; } 

		public System.Nullable<System.DateTime> DataPrevistaEntrega { get; set; } 

		public string? OutroTipoDocOrig { get; set; } 

		public string? OutroDescricao { get; set; } 

		public System.Nullable<System.Decimal> OutroValorDocumento { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
