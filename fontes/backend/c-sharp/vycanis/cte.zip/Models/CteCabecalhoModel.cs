namespace cte.Models
{
	public class CteCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? NaturezaOperacao { get; set; } 

		public string? ChaveAcesso { get; set; } 

		public string? DigitoChaveAcesso { get; set; } 

		public string? CodigoNumerico { get; set; } 

		public string? Serie { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataHoraEmissao { get; set; } 

		public string? UfEmitente { get; set; } 

		public int? Cfop { get; set; } 

		public string? FormaPagamento { get; set; } 

		public string? Modelo { get; set; } 

		public string? FormatoImpressaoDacte { get; set; } 

		public string? TipoEmissao { get; set; } 

		public string? Ambiente { get; set; } 

		public string? TipoCte { get; set; } 

		public string? ProcessoEmissao { get; set; } 

		public string? VersaoProcessoEmissao { get; set; } 

		public string? ChaveReferenciado { get; set; } 

		public int? CodigoMunicipioEnvio { get; set; } 

		public string? NomeMunicipioEnvio { get; set; } 

		public string? UfEnvio { get; set; } 

		public string? Modal { get; set; } 

		public string? TipoServico { get; set; } 

		public int? CodigoMunicipioIniPrestacao { get; set; } 

		public string? NomeMunicipioIniPrestacao { get; set; } 

		public string? UfIniPrestacao { get; set; } 

		public int? CodigoMunicipioFimPrestacao { get; set; } 

		public string? NomeMunicipioFimPrestacao { get; set; } 

		public string? UfFimPrestacao { get; set; } 

		public string? Retira { get; set; } 

		public string? RetiraDetalhe { get; set; } 

		public string? Tomador { get; set; } 

		public System.Nullable<System.DateTime> DataEntradaContingencia { get; set; } 

		public string? JustificativaContingencia { get; set; } 

		public string? CaracAdicionalTransporte { get; set; } 

		public string? CaracAdicionalServico { get; set; } 

		public string? FuncionarioEmissor { get; set; } 

		public string? FluxoOrigem { get; set; } 

		public string? EntregaTipoPeriodo { get; set; } 

		public System.Nullable<System.DateTime> EntregaDataProgramada { get; set; } 

		public System.Nullable<System.DateTime> EntregaDataInicial { get; set; } 

		public System.Nullable<System.DateTime> EntregaDataFinal { get; set; } 

		public string? EntregaTipoHora { get; set; } 

		public string? EntregaHoraProgramada { get; set; } 

		public string? EntregaHoraInicial { get; set; } 

		public string? EntregaHoraFinal { get; set; } 

		public string? MunicipioOrigemCalculo { get; set; } 

		public string? MunicipioDestinoCalculo { get; set; } 

		public string? ObservacoesGerais { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalServico { get; set; } 

		public System.Nullable<System.Decimal> ValorReceber { get; set; } 

		public string? Cst { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcms { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcms { get; set; } 

		public System.Nullable<System.Decimal> PercentualReducaoBcIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcmsStRetido { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsStRetido { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcmsStRetido { get; set; } 

		public System.Nullable<System.Decimal> ValorCreditoPresumidoIcms { get; set; } 

		public System.Nullable<System.Decimal> PercentualBcIcmsOutraUf { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcmsOutraUf { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcmsOutraUf { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsOutraUf { get; set; } 

		public string? SimplesNacionalIndicador { get; set; } 

		public System.Nullable<System.Decimal> SimplesNacionalTotal { get; set; } 

		public string? InformacoesAddFisco { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalCarga { get; set; } 

		public string? ProdutoPredominante { get; set; } 

		public string? CargaOutrasCaracteristicas { get; set; } 

		public int? ModalVersaoLayout { get; set; } 

		public string? ChaveCteSubstituido { get; set; } 

		private IList<CteEmitenteModel>? cteEmitenteModelList; 
		public IList<CteEmitenteModel>? CteEmitenteModelList 
		{ 
			get 
			{ 
				return cteEmitenteModelList; 
			} 
			set 
			{ 
				cteEmitenteModelList = value; 
				foreach (CteEmitenteModel cteEmitenteModel in cteEmitenteModelList!) 
				{ 
					cteEmitenteModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteLocalColetaModel>? cteLocalColetaModelList; 
		public IList<CteLocalColetaModel>? CteLocalColetaModelList 
		{ 
			get 
			{ 
				return cteLocalColetaModelList; 
			} 
			set 
			{ 
				cteLocalColetaModelList = value; 
				foreach (CteLocalColetaModel cteLocalColetaModel in cteLocalColetaModelList!) 
				{ 
					cteLocalColetaModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteTomadorModel>? cteTomadorModelList; 
		public IList<CteTomadorModel>? CteTomadorModelList 
		{ 
			get 
			{ 
				return cteTomadorModelList; 
			} 
			set 
			{ 
				cteTomadorModelList = value; 
				foreach (CteTomadorModel cteTomadorModel in cteTomadorModelList!) 
				{ 
					cteTomadorModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CtePassagemModel>? ctePassagemModelList; 
		public IList<CtePassagemModel>? CtePassagemModelList 
		{ 
			get 
			{ 
				return ctePassagemModelList; 
			} 
			set 
			{ 
				ctePassagemModelList = value; 
				foreach (CtePassagemModel ctePassagemModel in ctePassagemModelList!) 
				{ 
					ctePassagemModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteRemetenteModel>? cteRemetenteModelList; 
		public IList<CteRemetenteModel>? CteRemetenteModelList 
		{ 
			get 
			{ 
				return cteRemetenteModelList; 
			} 
			set 
			{ 
				cteRemetenteModelList = value; 
				foreach (CteRemetenteModel cteRemetenteModel in cteRemetenteModelList!) 
				{ 
					cteRemetenteModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteExpedidorModel>? cteExpedidorModelList; 
		public IList<CteExpedidorModel>? CteExpedidorModelList 
		{ 
			get 
			{ 
				return cteExpedidorModelList; 
			} 
			set 
			{ 
				cteExpedidorModelList = value; 
				foreach (CteExpedidorModel cteExpedidorModel in cteExpedidorModelList!) 
				{ 
					cteExpedidorModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteRecebedorModel>? cteRecebedorModelList; 
		public IList<CteRecebedorModel>? CteRecebedorModelList 
		{ 
			get 
			{ 
				return cteRecebedorModelList; 
			} 
			set 
			{ 
				cteRecebedorModelList = value; 
				foreach (CteRecebedorModel cteRecebedorModel in cteRecebedorModelList!) 
				{ 
					cteRecebedorModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteDestinatarioModel>? cteDestinatarioModelList; 
		public IList<CteDestinatarioModel>? CteDestinatarioModelList 
		{ 
			get 
			{ 
				return cteDestinatarioModelList; 
			} 
			set 
			{ 
				cteDestinatarioModelList = value; 
				foreach (CteDestinatarioModel cteDestinatarioModel in cteDestinatarioModelList!) 
				{ 
					cteDestinatarioModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteLocalEntregaModel>? cteLocalEntregaModelList; 
		public IList<CteLocalEntregaModel>? CteLocalEntregaModelList 
		{ 
			get 
			{ 
				return cteLocalEntregaModelList; 
			} 
			set 
			{ 
				cteLocalEntregaModelList = value; 
				foreach (CteLocalEntregaModel cteLocalEntregaModel in cteLocalEntregaModelList!) 
				{ 
					cteLocalEntregaModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteComponenteModel>? cteComponenteModelList; 
		public IList<CteComponenteModel>? CteComponenteModelList 
		{ 
			get 
			{ 
				return cteComponenteModelList; 
			} 
			set 
			{ 
				cteComponenteModelList = value; 
				foreach (CteComponenteModel cteComponenteModel in cteComponenteModelList!) 
				{ 
					cteComponenteModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteCargaModel>? cteCargaModelList; 
		public IList<CteCargaModel>? CteCargaModelList 
		{ 
			get 
			{ 
				return cteCargaModelList; 
			} 
			set 
			{ 
				cteCargaModelList = value; 
				foreach (CteCargaModel cteCargaModel in cteCargaModelList!) 
				{ 
					cteCargaModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteInformacaoNfOutrosModel>? cteInformacaoNfOutrosModelList; 
		public IList<CteInformacaoNfOutrosModel>? CteInformacaoNfOutrosModelList 
		{ 
			get 
			{ 
				return cteInformacaoNfOutrosModelList; 
			} 
			set 
			{ 
				cteInformacaoNfOutrosModelList = value; 
				foreach (CteInformacaoNfOutrosModel cteInformacaoNfOutrosModel in cteInformacaoNfOutrosModelList!) 
				{ 
					cteInformacaoNfOutrosModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteSeguroModel>? cteSeguroModelList; 
		public IList<CteSeguroModel>? CteSeguroModelList 
		{ 
			get 
			{ 
				return cteSeguroModelList; 
			} 
			set 
			{ 
				cteSeguroModelList = value; 
				foreach (CteSeguroModel cteSeguroModel in cteSeguroModelList!) 
				{ 
					cteSeguroModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CtePerigosoModel>? ctePerigosoModelList; 
		public IList<CtePerigosoModel>? CtePerigosoModelList 
		{ 
			get 
			{ 
				return ctePerigosoModelList; 
			} 
			set 
			{ 
				ctePerigosoModelList = value; 
				foreach (CtePerigosoModel ctePerigosoModel in ctePerigosoModelList!) 
				{ 
					ctePerigosoModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteVeiculoNovoModel>? cteVeiculoNovoModelList; 
		public IList<CteVeiculoNovoModel>? CteVeiculoNovoModelList 
		{ 
			get 
			{ 
				return cteVeiculoNovoModelList; 
			} 
			set 
			{ 
				cteVeiculoNovoModelList = value; 
				foreach (CteVeiculoNovoModel cteVeiculoNovoModel in cteVeiculoNovoModelList!) 
				{ 
					cteVeiculoNovoModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteFaturaModel>? cteFaturaModelList; 
		public IList<CteFaturaModel>? CteFaturaModelList 
		{ 
			get 
			{ 
				return cteFaturaModelList; 
			} 
			set 
			{ 
				cteFaturaModelList = value; 
				foreach (CteFaturaModel cteFaturaModel in cteFaturaModelList!) 
				{ 
					cteFaturaModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteDuplicataModel>? cteDuplicataModelList; 
		public IList<CteDuplicataModel>? CteDuplicataModelList 
		{ 
			get 
			{ 
				return cteDuplicataModelList; 
			} 
			set 
			{ 
				cteDuplicataModelList = value; 
				foreach (CteDuplicataModel cteDuplicataModel in cteDuplicataModelList!) 
				{ 
					cteDuplicataModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteRodoviarioModel>? cteRodoviarioModelList; 
		public IList<CteRodoviarioModel>? CteRodoviarioModelList 
		{ 
			get 
			{ 
				return cteRodoviarioModelList; 
			} 
			set 
			{ 
				cteRodoviarioModelList = value; 
				foreach (CteRodoviarioModel cteRodoviarioModel in cteRodoviarioModelList!) 
				{ 
					cteRodoviarioModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteAereoModel>? cteAereoModelList; 
		public IList<CteAereoModel>? CteAereoModelList 
		{ 
			get 
			{ 
				return cteAereoModelList; 
			} 
			set 
			{ 
				cteAereoModelList = value; 
				foreach (CteAereoModel cteAereoModel in cteAereoModelList!) 
				{ 
					cteAereoModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteAquaviarioModel>? cteAquaviarioModelList; 
		public IList<CteAquaviarioModel>? CteAquaviarioModelList 
		{ 
			get 
			{ 
				return cteAquaviarioModelList; 
			} 
			set 
			{ 
				cteAquaviarioModelList = value; 
				foreach (CteAquaviarioModel cteAquaviarioModel in cteAquaviarioModelList!) 
				{ 
					cteAquaviarioModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteFerroviarioModel>? cteFerroviarioModelList; 
		public IList<CteFerroviarioModel>? CteFerroviarioModelList 
		{ 
			get 
			{ 
				return cteFerroviarioModelList; 
			} 
			set 
			{ 
				cteFerroviarioModelList = value; 
				foreach (CteFerroviarioModel cteFerroviarioModel in cteFerroviarioModelList!) 
				{ 
					cteFerroviarioModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteDutoviarioModel>? cteDutoviarioModelList; 
		public IList<CteDutoviarioModel>? CteDutoviarioModelList 
		{ 
			get 
			{ 
				return cteDutoviarioModelList; 
			} 
			set 
			{ 
				cteDutoviarioModelList = value; 
				foreach (CteDutoviarioModel cteDutoviarioModel in cteDutoviarioModelList!) 
				{ 
					cteDutoviarioModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<CteMultimodalModel>? cteMultimodalModelList; 
		public IList<CteMultimodalModel>? CteMultimodalModelList 
		{ 
			get 
			{ 
				return cteMultimodalModelList; 
			} 
			set 
			{ 
				cteMultimodalModelList = value; 
				foreach (CteMultimodalModel cteMultimodalModel in cteMultimodalModelList!) 
				{ 
					cteMultimodalModel.CteCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
