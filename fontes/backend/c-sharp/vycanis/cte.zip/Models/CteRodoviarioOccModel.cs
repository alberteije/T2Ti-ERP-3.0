namespace cte.Models
{
	public class CteRodoviarioOccModel
	{	
		public int? Id { get; set; } 

		public string? Serie { get; set; } 

		public int? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public string? Cnpj { get; set; } 

		public string? CodigoInterno { get; set; } 

		public string? Ie { get; set; } 

		public string? Uf { get; set; } 

		public string? Telefone { get; set; } 

		public CteRodoviarioModel? CteRodoviarioModel { get; set; } 

	}
}
