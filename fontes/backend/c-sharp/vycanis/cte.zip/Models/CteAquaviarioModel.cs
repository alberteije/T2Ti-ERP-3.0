namespace cte.Models
{
	public class CteAquaviarioModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorPrestacao { get; set; } 

		public System.Nullable<System.Decimal> Afrmm { get; set; } 

		public string? NumeroBooking { get; set; } 

		public string? NumeroControle { get; set; } 

		public string? IdNavio { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
