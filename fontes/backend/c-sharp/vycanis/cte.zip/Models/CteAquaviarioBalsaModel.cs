namespace cte.Models
{
	public class CteAquaviarioBalsaModel
	{	
		public int? Id { get; set; } 

		public string? IdBalsa { get; set; } 

		public int? NumeroViagem { get; set; } 

		public string? Direcao { get; set; } 

		public string? PortoEmbarque { get; set; } 

		public string? PortoTransbordo { get; set; } 

		public string? PortoDestino { get; set; } 

		public string? TipoNavegacao { get; set; } 

		public string? Irin { get; set; } 

		public CteAquaviarioModel? CteAquaviarioModel { get; set; } 

	}
}
