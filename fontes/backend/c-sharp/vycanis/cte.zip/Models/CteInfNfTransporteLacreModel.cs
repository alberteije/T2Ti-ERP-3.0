namespace cte.Models
{
	public class CteInfNfTransporteLacreModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public CteInformacaoNfTransporteModel? CteInformacaoNfTransporteModel { get; set; } 

	}
}
