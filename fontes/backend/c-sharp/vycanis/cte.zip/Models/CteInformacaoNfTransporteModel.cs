namespace cte.Models
{
	public class CteInformacaoNfTransporteModel
	{	
		public int? Id { get; set; } 

		public string? TipoUnidadeTransporte { get; set; } 

		public string? IdUnidadeTransporte { get; set; } 

		public CteInformacaoNfOutrosModel? CteInformacaoNfOutrosModel { get; set; } 

	}
}
