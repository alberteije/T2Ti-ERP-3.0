namespace cte.Models
{
	public class CteAereoModel
	{	
		public int? Id { get; set; } 

		public int? NumeroMinuta { get; set; } 

		public int? NumeroConhecimento { get; set; } 

		public System.Nullable<System.DateTime> DataPrevistaEntrega { get; set; } 

		public string? IdEmissor { get; set; } 

		public string? IdInternaTomador { get; set; } 

		public string? TarifaClasse { get; set; } 

		public string? TarifaCodigo { get; set; } 

		public System.Nullable<System.Decimal> TarifaValor { get; set; } 

		public string? CargaDimensao { get; set; } 

		public string? CargaInformacaoManuseio { get; set; } 

		public string? CargaEspecial { get; set; } 

		public CteCabecalhoModel? CteCabecalhoModel { get; set; } 

	}
}
