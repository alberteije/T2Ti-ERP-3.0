namespace cte.Models
{
	public class CteRodoviarioLacreModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public CteRodoviarioModel? CteRodoviarioModel { get; set; } 

	}
}
