using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-aquaviario-balsa")]
    [Produces("application/json")]
    public class CteAquaviarioBalsaController : Controller
    {
		private readonly CteAquaviarioBalsaService _service;

        public CteAquaviarioBalsaController()
        {
            _service = new CteAquaviarioBalsaService();
        }

        [HttpGet]
        public IActionResult GetListCteAquaviarioBalsa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteAquaviarioBalsaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteAquaviarioBalsa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteAquaviarioBalsa")]
        public IActionResult GetObjectCteAquaviarioBalsa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteAquaviarioBalsa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteAquaviarioBalsa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteAquaviarioBalsa([FromBody]CteAquaviarioBalsaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteAquaviarioBalsa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteAquaviarioBalsa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteAquaviarioBalsa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteAquaviarioBalsa([FromBody]CteAquaviarioBalsaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteAquaviarioBalsa]", null));
                }

                _service.Update(objJson);

                return GetObjectCteAquaviarioBalsa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteAquaviarioBalsa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteAquaviarioBalsa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteAquaviarioBalsa]", ex));
            }
        }

    }
}