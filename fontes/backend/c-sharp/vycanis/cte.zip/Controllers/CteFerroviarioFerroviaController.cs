using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-ferroviario-ferrovia")]
    [Produces("application/json")]
    public class CteFerroviarioFerroviaController : Controller
    {
		private readonly CteFerroviarioFerroviaService _service;

        public CteFerroviarioFerroviaController()
        {
            _service = new CteFerroviarioFerroviaService();
        }

        [HttpGet]
        public IActionResult GetListCteFerroviarioFerrovia([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteFerroviarioFerroviaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteFerroviarioFerrovia]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteFerroviarioFerrovia")]
        public IActionResult GetObjectCteFerroviarioFerrovia(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteFerroviarioFerrovia]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteFerroviarioFerrovia]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteFerroviarioFerrovia([FromBody]CteFerroviarioFerroviaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteFerroviarioFerrovia]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteFerroviarioFerrovia", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteFerroviarioFerrovia]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteFerroviarioFerrovia([FromBody]CteFerroviarioFerroviaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteFerroviarioFerrovia]", null));
                }

                _service.Update(objJson);

                return GetObjectCteFerroviarioFerrovia(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteFerroviarioFerrovia]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteFerroviarioFerrovia(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteFerroviarioFerrovia]", ex));
            }
        }

    }
}