using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-rodoviario-occ")]
    [Produces("application/json")]
    public class CteRodoviarioOccController : Controller
    {
		private readonly CteRodoviarioOccService _service;

        public CteRodoviarioOccController()
        {
            _service = new CteRodoviarioOccService();
        }

        [HttpGet]
        public IActionResult GetListCteRodoviarioOcc([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteRodoviarioOccModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteRodoviarioOcc]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteRodoviarioOcc")]
        public IActionResult GetObjectCteRodoviarioOcc(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteRodoviarioOcc]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteRodoviarioOcc]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteRodoviarioOcc([FromBody]CteRodoviarioOccModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteRodoviarioOcc]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteRodoviarioOcc", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteRodoviarioOcc]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteRodoviarioOcc([FromBody]CteRodoviarioOccModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteRodoviarioOcc]", null));
                }

                _service.Update(objJson);

                return GetObjectCteRodoviarioOcc(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteRodoviarioOcc]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteRodoviarioOcc(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteRodoviarioOcc]", ex));
            }
        }

    }
}