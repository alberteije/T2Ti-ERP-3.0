using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-informacao-nf-carga")]
    [Produces("application/json")]
    public class CteInformacaoNfCargaController : Controller
    {
		private readonly CteInformacaoNfCargaService _service;

        public CteInformacaoNfCargaController()
        {
            _service = new CteInformacaoNfCargaService();
        }

        [HttpGet]
        public IActionResult GetListCteInformacaoNfCarga([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteInformacaoNfCargaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteInformacaoNfCarga]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteInformacaoNfCarga")]
        public IActionResult GetObjectCteInformacaoNfCarga(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteInformacaoNfCarga]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteInformacaoNfCarga]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteInformacaoNfCarga([FromBody]CteInformacaoNfCargaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteInformacaoNfCarga]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteInformacaoNfCarga", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteInformacaoNfCarga]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteInformacaoNfCarga([FromBody]CteInformacaoNfCargaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteInformacaoNfCarga]", null));
                }

                _service.Update(objJson);

                return GetObjectCteInformacaoNfCarga(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteInformacaoNfCarga]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteInformacaoNfCarga(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteInformacaoNfCarga]", ex));
            }
        }

    }
}