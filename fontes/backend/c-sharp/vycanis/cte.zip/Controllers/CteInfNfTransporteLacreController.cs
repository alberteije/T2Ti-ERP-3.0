using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-inf-nf-transporte-lacre")]
    [Produces("application/json")]
    public class CteInfNfTransporteLacreController : Controller
    {
		private readonly CteInfNfTransporteLacreService _service;

        public CteInfNfTransporteLacreController()
        {
            _service = new CteInfNfTransporteLacreService();
        }

        [HttpGet]
        public IActionResult GetListCteInfNfTransporteLacre([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteInfNfTransporteLacreModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteInfNfTransporteLacre]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteInfNfTransporteLacre")]
        public IActionResult GetObjectCteInfNfTransporteLacre(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteInfNfTransporteLacre]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteInfNfTransporteLacre]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteInfNfTransporteLacre([FromBody]CteInfNfTransporteLacreModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteInfNfTransporteLacre]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteInfNfTransporteLacre", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteInfNfTransporteLacre]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteInfNfTransporteLacre([FromBody]CteInfNfTransporteLacreModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteInfNfTransporteLacre]", null));
                }

                _service.Update(objJson);

                return GetObjectCteInfNfTransporteLacre(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteInfNfTransporteLacre]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteInfNfTransporteLacre(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteInfNfTransporteLacre]", ex));
            }
        }

    }
}