using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-rodoviario-veiculo")]
    [Produces("application/json")]
    public class CteRodoviarioVeiculoController : Controller
    {
		private readonly CteRodoviarioVeiculoService _service;

        public CteRodoviarioVeiculoController()
        {
            _service = new CteRodoviarioVeiculoService();
        }

        [HttpGet]
        public IActionResult GetListCteRodoviarioVeiculo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteRodoviarioVeiculoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteRodoviarioVeiculo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteRodoviarioVeiculo")]
        public IActionResult GetObjectCteRodoviarioVeiculo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteRodoviarioVeiculo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteRodoviarioVeiculo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteRodoviarioVeiculo([FromBody]CteRodoviarioVeiculoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteRodoviarioVeiculo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteRodoviarioVeiculo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteRodoviarioVeiculo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteRodoviarioVeiculo([FromBody]CteRodoviarioVeiculoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteRodoviarioVeiculo]", null));
                }

                _service.Update(objJson);

                return GetObjectCteRodoviarioVeiculo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteRodoviarioVeiculo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteRodoviarioVeiculo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteRodoviarioVeiculo]", ex));
            }
        }

    }
}