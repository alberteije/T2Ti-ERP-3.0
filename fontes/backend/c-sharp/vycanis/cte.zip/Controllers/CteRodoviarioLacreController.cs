using Microsoft.AspNetCore.Mvc;
using cte.Models;
using cte.Services;

namespace cte.Controllers
{
    [Route("cte-rodoviario-lacre")]
    [Produces("application/json")]
    public class CteRodoviarioLacreController : Controller
    {
		private readonly CteRodoviarioLacreService _service;

        public CteRodoviarioLacreController()
        {
            _service = new CteRodoviarioLacreService();
        }

        [HttpGet]
        public IActionResult GetListCteRodoviarioLacre([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CteRodoviarioLacreModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CteRodoviarioLacre]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCteRodoviarioLacre")]
        public IActionResult GetObjectCteRodoviarioLacre(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CteRodoviarioLacre]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CteRodoviarioLacre]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCteRodoviarioLacre([FromBody]CteRodoviarioLacreModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CteRodoviarioLacre]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCteRodoviarioLacre", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CteRodoviarioLacre]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCteRodoviarioLacre([FromBody]CteRodoviarioLacreModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CteRodoviarioLacre]", null));
                }

                _service.Update(objJson);

                return GetObjectCteRodoviarioLacre(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CteRodoviarioLacre]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCteRodoviarioLacre(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CteRodoviarioLacre]", ex));
            }
        }

    }
}