using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoParametroService
    {

        public IEnumerable<PontoParametroModel> GetList()
        {
            IList<PontoParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoParametroModel> DAL = new NHibernateDAL<PontoParametroModel>(Session);
                Result = DAL.Select(new PontoParametroModel());
            }
            return Result;
        }

        public IEnumerable<PontoParametroModel> GetListFilter(Filter filterObj)
        {
            IList<PontoParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoParametroModel where " + filterObj.Where;
                NHibernateDAL<PontoParametroModel> DAL = new NHibernateDAL<PontoParametroModel>(Session);
                Result = DAL.SelectListSql<PontoParametroModel>(Query);
            }
            return Result;
        }
		
        public PontoParametroModel GetObject(int id)
        {
            PontoParametroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoParametroModel> DAL = new NHibernateDAL<PontoParametroModel>(Session);
                Result = DAL.SelectId<PontoParametroModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoParametroModel> DAL = new NHibernateDAL<PontoParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoParametroModel> DAL = new NHibernateDAL<PontoParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoParametroModel> DAL = new NHibernateDAL<PontoParametroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}