using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoEscalaService
    {

        public IEnumerable<PontoEscalaModel> GetList()
        {
            IList<PontoEscalaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoEscalaModel> DAL = new NHibernateDAL<PontoEscalaModel>(Session);
                Result = DAL.Select(new PontoEscalaModel());
            }
            return Result;
        }

        public IEnumerable<PontoEscalaModel> GetListFilter(Filter filterObj)
        {
            IList<PontoEscalaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoEscalaModel where " + filterObj.Where;
                NHibernateDAL<PontoEscalaModel> DAL = new NHibernateDAL<PontoEscalaModel>(Session);
                Result = DAL.SelectListSql<PontoEscalaModel>(Query);
            }
            return Result;
        }
		
        public PontoEscalaModel GetObject(int id)
        {
            PontoEscalaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoEscalaModel> DAL = new NHibernateDAL<PontoEscalaModel>(Session);
                Result = DAL.SelectId<PontoEscalaModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoEscalaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoEscalaModel> DAL = new NHibernateDAL<PontoEscalaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoEscalaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoEscalaModel> DAL = new NHibernateDAL<PontoEscalaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoEscalaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoEscalaModel> DAL = new NHibernateDAL<PontoEscalaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}