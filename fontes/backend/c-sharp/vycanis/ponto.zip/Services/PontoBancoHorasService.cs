using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoBancoHorasService
    {

        public IEnumerable<PontoBancoHorasModel> GetList()
        {
            IList<PontoBancoHorasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoBancoHorasModel> DAL = new NHibernateDAL<PontoBancoHorasModel>(Session);
                Result = DAL.Select(new PontoBancoHorasModel());
            }
            return Result;
        }

        public IEnumerable<PontoBancoHorasModel> GetListFilter(Filter filterObj)
        {
            IList<PontoBancoHorasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoBancoHorasModel where " + filterObj.Where;
                NHibernateDAL<PontoBancoHorasModel> DAL = new NHibernateDAL<PontoBancoHorasModel>(Session);
                Result = DAL.SelectListSql<PontoBancoHorasModel>(Query);
            }
            return Result;
        }
		
        public PontoBancoHorasModel GetObject(int id)
        {
            PontoBancoHorasModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoBancoHorasModel> DAL = new NHibernateDAL<PontoBancoHorasModel>(Session);
                Result = DAL.SelectId<PontoBancoHorasModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoBancoHorasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoBancoHorasModel> DAL = new NHibernateDAL<PontoBancoHorasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoBancoHorasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoBancoHorasModel> DAL = new NHibernateDAL<PontoBancoHorasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoBancoHorasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoBancoHorasModel> DAL = new NHibernateDAL<PontoBancoHorasModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}