using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoRelogioService
    {

        public IEnumerable<PontoRelogioModel> GetList()
        {
            IList<PontoRelogioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoRelogioModel> DAL = new NHibernateDAL<PontoRelogioModel>(Session);
                Result = DAL.Select(new PontoRelogioModel());
            }
            return Result;
        }

        public IEnumerable<PontoRelogioModel> GetListFilter(Filter filterObj)
        {
            IList<PontoRelogioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoRelogioModel where " + filterObj.Where;
                NHibernateDAL<PontoRelogioModel> DAL = new NHibernateDAL<PontoRelogioModel>(Session);
                Result = DAL.SelectListSql<PontoRelogioModel>(Query);
            }
            return Result;
        }
		
        public PontoRelogioModel GetObject(int id)
        {
            PontoRelogioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoRelogioModel> DAL = new NHibernateDAL<PontoRelogioModel>(Session);
                Result = DAL.SelectId<PontoRelogioModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoRelogioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoRelogioModel> DAL = new NHibernateDAL<PontoRelogioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoRelogioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoRelogioModel> DAL = new NHibernateDAL<PontoRelogioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoRelogioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoRelogioModel> DAL = new NHibernateDAL<PontoRelogioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}