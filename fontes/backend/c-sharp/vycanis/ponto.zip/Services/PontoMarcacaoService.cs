using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoMarcacaoService
    {

        public IEnumerable<PontoMarcacaoModel> GetList()
        {
            IList<PontoMarcacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoMarcacaoModel> DAL = new NHibernateDAL<PontoMarcacaoModel>(Session);
                Result = DAL.Select(new PontoMarcacaoModel());
            }
            return Result;
        }

        public IEnumerable<PontoMarcacaoModel> GetListFilter(Filter filterObj)
        {
            IList<PontoMarcacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoMarcacaoModel where " + filterObj.Where;
                NHibernateDAL<PontoMarcacaoModel> DAL = new NHibernateDAL<PontoMarcacaoModel>(Session);
                Result = DAL.SelectListSql<PontoMarcacaoModel>(Query);
            }
            return Result;
        }
		
        public PontoMarcacaoModel GetObject(int id)
        {
            PontoMarcacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoMarcacaoModel> DAL = new NHibernateDAL<PontoMarcacaoModel>(Session);
                Result = DAL.SelectId<PontoMarcacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoMarcacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoMarcacaoModel> DAL = new NHibernateDAL<PontoMarcacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoMarcacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoMarcacaoModel> DAL = new NHibernateDAL<PontoMarcacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoMarcacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoMarcacaoModel> DAL = new NHibernateDAL<PontoMarcacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}