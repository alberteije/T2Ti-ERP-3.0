using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoHorarioService
    {

        public IEnumerable<PontoHorarioModel> GetList()
        {
            IList<PontoHorarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioModel> DAL = new NHibernateDAL<PontoHorarioModel>(Session);
                Result = DAL.Select(new PontoHorarioModel());
            }
            return Result;
        }

        public IEnumerable<PontoHorarioModel> GetListFilter(Filter filterObj)
        {
            IList<PontoHorarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoHorarioModel where " + filterObj.Where;
                NHibernateDAL<PontoHorarioModel> DAL = new NHibernateDAL<PontoHorarioModel>(Session);
                Result = DAL.SelectListSql<PontoHorarioModel>(Query);
            }
            return Result;
        }
		
        public PontoHorarioModel GetObject(int id)
        {
            PontoHorarioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioModel> DAL = new NHibernateDAL<PontoHorarioModel>(Session);
                Result = DAL.SelectId<PontoHorarioModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoHorarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioModel> DAL = new NHibernateDAL<PontoHorarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoHorarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioModel> DAL = new NHibernateDAL<PontoHorarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoHorarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioModel> DAL = new NHibernateDAL<PontoHorarioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}