namespace ponto.Models
{
	public class PontoBancoHorasUtilizacaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataUtilizacao { get; set; } 

		public string? QuantidadeUtilizada { get; set; } 

		public string? Observacao { get; set; } 

		public PontoBancoHorasModel? PontoBancoHorasModel { get; set; } 

	}
}
