namespace ponto.Models
{
	public class PontoTurmaModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		public PontoEscalaModel? PontoEscalaModel { get; set; } 

	}
}
