using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-relogio")]
    [Produces("application/json")]
    public class PontoRelogioController : Controller
    {
		private readonly PontoRelogioService _service;

        public PontoRelogioController()
        {
            _service = new PontoRelogioService();
        }

        [HttpGet]
        public IActionResult GetListPontoRelogio([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoRelogioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoRelogio]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoRelogio")]
        public IActionResult GetObjectPontoRelogio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoRelogio]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoRelogio]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoRelogio([FromBody]PontoRelogioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoRelogio]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoRelogio", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoRelogio]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoRelogio([FromBody]PontoRelogioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoRelogio]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoRelogio(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoRelogio]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoRelogio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoRelogio]", ex));
            }
        }

    }
}