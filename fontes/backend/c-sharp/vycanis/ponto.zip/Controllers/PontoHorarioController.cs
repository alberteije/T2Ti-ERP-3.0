using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-horario")]
    [Produces("application/json")]
    public class PontoHorarioController : Controller
    {
		private readonly PontoHorarioService _service;

        public PontoHorarioController()
        {
            _service = new PontoHorarioService();
        }

        [HttpGet]
        public IActionResult GetListPontoHorario([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoHorarioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoHorario]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoHorario")]
        public IActionResult GetObjectPontoHorario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoHorario]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoHorario]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoHorario([FromBody]PontoHorarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoHorario]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoHorario", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoHorario]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoHorario([FromBody]PontoHorarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoHorario]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoHorario(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoHorario]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoHorario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoHorario]", ex));
            }
        }

    }
}