using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-parametro")]
    [Produces("application/json")]
    public class PontoParametroController : Controller
    {
		private readonly PontoParametroService _service;

        public PontoParametroController()
        {
            _service = new PontoParametroService();
        }

        [HttpGet]
        public IActionResult GetListPontoParametro([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoParametroModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoParametro]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoParametro")]
        public IActionResult GetObjectPontoParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoParametro]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoParametro]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoParametro([FromBody]PontoParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoParametro]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoParametro", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoParametro]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoParametro([FromBody]PontoParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoParametro]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoParametro(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoParametro]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoParametro]", ex));
            }
        }

    }
}