using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-fechamento-jornada")]
    [Produces("application/json")]
    public class PontoFechamentoJornadaController : Controller
    {
		private readonly PontoFechamentoJornadaService _service;

        public PontoFechamentoJornadaController()
        {
            _service = new PontoFechamentoJornadaService();
        }

        [HttpGet]
        public IActionResult GetListPontoFechamentoJornada([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoFechamentoJornadaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoFechamentoJornada]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoFechamentoJornada")]
        public IActionResult GetObjectPontoFechamentoJornada(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoFechamentoJornada]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoFechamentoJornada]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoFechamentoJornada([FromBody]PontoFechamentoJornadaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoFechamentoJornada]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoFechamentoJornada", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoFechamentoJornada]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoFechamentoJornada([FromBody]PontoFechamentoJornadaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoFechamentoJornada]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoFechamentoJornada(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoFechamentoJornada]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoFechamentoJornada(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoFechamentoJornada]", ex));
            }
        }

    }
}