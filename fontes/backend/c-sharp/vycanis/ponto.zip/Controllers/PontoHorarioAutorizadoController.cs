using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-horario-autorizado")]
    [Produces("application/json")]
    public class PontoHorarioAutorizadoController : Controller
    {
		private readonly PontoHorarioAutorizadoService _service;

        public PontoHorarioAutorizadoController()
        {
            _service = new PontoHorarioAutorizadoService();
        }

        [HttpGet]
        public IActionResult GetListPontoHorarioAutorizado([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoHorarioAutorizadoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoHorarioAutorizado]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoHorarioAutorizado")]
        public IActionResult GetObjectPontoHorarioAutorizado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoHorarioAutorizado]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoHorarioAutorizado]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoHorarioAutorizado([FromBody]PontoHorarioAutorizadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoHorarioAutorizado]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoHorarioAutorizado", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoHorarioAutorizado]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoHorarioAutorizado([FromBody]PontoHorarioAutorizadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoHorarioAutorizado]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoHorarioAutorizado(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoHorarioAutorizado]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoHorarioAutorizado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoHorarioAutorizado]", ex));
            }
        }

    }
}