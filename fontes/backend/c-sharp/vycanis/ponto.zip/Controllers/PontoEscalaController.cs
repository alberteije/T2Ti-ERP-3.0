using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-escala")]
    [Produces("application/json")]
    public class PontoEscalaController : Controller
    {
		private readonly PontoEscalaService _service;

        public PontoEscalaController()
        {
            _service = new PontoEscalaService();
        }

        [HttpGet]
        public IActionResult GetListPontoEscala([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoEscalaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoEscala]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoEscala")]
        public IActionResult GetObjectPontoEscala(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoEscala]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoEscala]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoEscala([FromBody]PontoEscalaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoEscala]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoEscala", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoEscala]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoEscala([FromBody]PontoEscalaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoEscala]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoEscala(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoEscala]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoEscala(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoEscala]", ex));
            }
        }

    }
}