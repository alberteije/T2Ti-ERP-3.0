namespace ponto.Models
{
	public class PontoRelogioModel
	{	
		public int? Id { get; set; } 

		public string? Localizacao { get; set; } 

		public string? Marca { get; set; } 

		public string? Fabricante { get; set; } 

		public string? NumeroSerie { get; set; } 

		public string? Utilizacao { get; set; } 

	}
}
