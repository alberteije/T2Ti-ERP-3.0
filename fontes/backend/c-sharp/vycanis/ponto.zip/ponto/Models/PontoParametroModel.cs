namespace ponto.Models
{
	public class PontoParametroModel
	{	
		public int? Id { get; set; } 

		public string? MesAno { get; set; } 

		public int? DiaInicialApuracao { get; set; } 

		public string? HoraNoturnaInicio { get; set; } 

		public string? HoraNoturnaFim { get; set; } 

		public string? PeriodoMinimoInterjornada { get; set; } 

		public System.Nullable<System.Decimal> PercentualHeDiurna { get; set; } 

		public System.Nullable<System.Decimal> PercentualHeNoturna { get; set; } 

		public string? DuracaoHoraNoturna { get; set; } 

		public string? TratamentoHoraMais { get; set; } 

		public string? TratamentoHoraMenos { get; set; } 

	}
}
