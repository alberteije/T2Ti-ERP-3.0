namespace ponto.Models
{
	public class PontoAbonoUtilizacaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataUtilizacao { get; set; } 

		public string? Observacao { get; set; } 

		public PontoAbonoModel? PontoAbonoModel { get; set; } 

	}
}
