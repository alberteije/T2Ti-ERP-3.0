namespace ponto.Models
{
	public class PontoEscalaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? DescontoHoraDia { get; set; } 

		public string? DescontoDsr { get; set; } 

		public string? CodigoHorarioDomingo { get; set; } 

		public string? CodigoHorarioSegunda { get; set; } 

		public string? CodigoHorarioTerca { get; set; } 

		public string? CodigoHorarioQuarta { get; set; } 

		public string? CodigoHorarioQuinta { get; set; } 

		public string? CodigoHorarioSexta { get; set; } 

		public string? CodigoHorarioSabado { get; set; } 

		private IList<PontoTurmaModel>? pontoTurmaModelList; 
		public IList<PontoTurmaModel>? PontoTurmaModelList 
		{ 
			get 
			{ 
				return pontoTurmaModelList; 
			} 
			set 
			{ 
				pontoTurmaModelList = value; 
				foreach (PontoTurmaModel pontoTurmaModel in pontoTurmaModelList!) 
				{ 
					pontoTurmaModel.PontoEscalaModel = this; 
				} 
			} 
		} 

	}
}
