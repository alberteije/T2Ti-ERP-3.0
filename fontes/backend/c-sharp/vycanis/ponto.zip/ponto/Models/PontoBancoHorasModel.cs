namespace ponto.Models
{
	public class PontoBancoHorasModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataTrabalho { get; set; } 

		public string? Quantidade { get; set; } 

		public string? Situacao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<PontoBancoHorasUtilizacaoModel>? pontoBancoHorasUtilizacaoModelList; 
		public IList<PontoBancoHorasUtilizacaoModel>? PontoBancoHorasUtilizacaoModelList 
		{ 
			get 
			{ 
				return pontoBancoHorasUtilizacaoModelList; 
			} 
			set 
			{ 
				pontoBancoHorasUtilizacaoModelList = value; 
				foreach (PontoBancoHorasUtilizacaoModel pontoBancoHorasUtilizacaoModel in pontoBancoHorasUtilizacaoModelList!) 
				{ 
					pontoBancoHorasUtilizacaoModel.PontoBancoHorasModel = this; 
				} 
			} 
		} 

	}
}
