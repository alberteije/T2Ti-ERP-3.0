namespace ponto.Models
{
	public class PontoClassificacaoJornadaModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public string? Padrao { get; set; } 

		public string? DescontarHoras { get; set; } 

	}
}
