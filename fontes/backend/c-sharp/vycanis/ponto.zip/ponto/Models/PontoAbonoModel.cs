namespace ponto.Models
{
	public class PontoAbonoModel
	{	
		public int? Id { get; set; } 

		public int? Quantidade { get; set; } 

		public int? Utilizado { get; set; } 

		public int? Saldo { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.DateTime> InicioUtilizacao { get; set; } 

		public System.Nullable<System.DateTime> DataValidade { get; set; } 

		public string? Observacao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<PontoAbonoUtilizacaoModel>? pontoAbonoUtilizacaoModelList; 
		public IList<PontoAbonoUtilizacaoModel>? PontoAbonoUtilizacaoModelList 
		{ 
			get 
			{ 
				return pontoAbonoUtilizacaoModelList; 
			} 
			set 
			{ 
				pontoAbonoUtilizacaoModelList = value; 
				foreach (PontoAbonoUtilizacaoModel pontoAbonoUtilizacaoModel in pontoAbonoUtilizacaoModelList!) 
				{ 
					pontoAbonoUtilizacaoModel.PontoAbonoModel = this; 
				} 
			} 
		} 

	}
}
