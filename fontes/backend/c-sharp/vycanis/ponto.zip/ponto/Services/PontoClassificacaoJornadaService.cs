using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoClassificacaoJornadaService
    {

        public IEnumerable<PontoClassificacaoJornadaModel> GetList()
        {
            IList<PontoClassificacaoJornadaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoClassificacaoJornadaModel> DAL = new NHibernateDAL<PontoClassificacaoJornadaModel>(Session);
                Result = DAL.Select(new PontoClassificacaoJornadaModel());
            }
            return Result;
        }

        public IEnumerable<PontoClassificacaoJornadaModel> GetListFilter(Filter filterObj)
        {
            IList<PontoClassificacaoJornadaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoClassificacaoJornadaModel where " + filterObj.Where;
                NHibernateDAL<PontoClassificacaoJornadaModel> DAL = new NHibernateDAL<PontoClassificacaoJornadaModel>(Session);
                Result = DAL.SelectListSql<PontoClassificacaoJornadaModel>(Query);
            }
            return Result;
        }
		
        public PontoClassificacaoJornadaModel GetObject(int id)
        {
            PontoClassificacaoJornadaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoClassificacaoJornadaModel> DAL = new NHibernateDAL<PontoClassificacaoJornadaModel>(Session);
                Result = DAL.SelectId<PontoClassificacaoJornadaModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoClassificacaoJornadaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoClassificacaoJornadaModel> DAL = new NHibernateDAL<PontoClassificacaoJornadaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoClassificacaoJornadaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoClassificacaoJornadaModel> DAL = new NHibernateDAL<PontoClassificacaoJornadaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoClassificacaoJornadaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoClassificacaoJornadaModel> DAL = new NHibernateDAL<PontoClassificacaoJornadaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}