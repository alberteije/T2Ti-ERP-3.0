using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoFechamentoJornadaService
    {

        public IEnumerable<PontoFechamentoJornadaModel> GetList()
        {
            IList<PontoFechamentoJornadaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoFechamentoJornadaModel> DAL = new NHibernateDAL<PontoFechamentoJornadaModel>(Session);
                Result = DAL.Select(new PontoFechamentoJornadaModel());
            }
            return Result;
        }

        public IEnumerable<PontoFechamentoJornadaModel> GetListFilter(Filter filterObj)
        {
            IList<PontoFechamentoJornadaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoFechamentoJornadaModel where " + filterObj.Where;
                NHibernateDAL<PontoFechamentoJornadaModel> DAL = new NHibernateDAL<PontoFechamentoJornadaModel>(Session);
                Result = DAL.SelectListSql<PontoFechamentoJornadaModel>(Query);
            }
            return Result;
        }
		
        public PontoFechamentoJornadaModel GetObject(int id)
        {
            PontoFechamentoJornadaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoFechamentoJornadaModel> DAL = new NHibernateDAL<PontoFechamentoJornadaModel>(Session);
                Result = DAL.SelectId<PontoFechamentoJornadaModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoFechamentoJornadaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoFechamentoJornadaModel> DAL = new NHibernateDAL<PontoFechamentoJornadaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoFechamentoJornadaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoFechamentoJornadaModel> DAL = new NHibernateDAL<PontoFechamentoJornadaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoFechamentoJornadaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoFechamentoJornadaModel> DAL = new NHibernateDAL<PontoFechamentoJornadaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}