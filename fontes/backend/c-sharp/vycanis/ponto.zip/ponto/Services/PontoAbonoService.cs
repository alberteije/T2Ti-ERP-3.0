using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoAbonoService
    {

        public IEnumerable<PontoAbonoModel> GetList()
        {
            IList<PontoAbonoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoAbonoModel> DAL = new NHibernateDAL<PontoAbonoModel>(Session);
                Result = DAL.Select(new PontoAbonoModel());
            }
            return Result;
        }

        public IEnumerable<PontoAbonoModel> GetListFilter(Filter filterObj)
        {
            IList<PontoAbonoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoAbonoModel where " + filterObj.Where;
                NHibernateDAL<PontoAbonoModel> DAL = new NHibernateDAL<PontoAbonoModel>(Session);
                Result = DAL.SelectListSql<PontoAbonoModel>(Query);
            }
            return Result;
        }
		
        public PontoAbonoModel GetObject(int id)
        {
            PontoAbonoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoAbonoModel> DAL = new NHibernateDAL<PontoAbonoModel>(Session);
                Result = DAL.SelectId<PontoAbonoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoAbonoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoAbonoModel> DAL = new NHibernateDAL<PontoAbonoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoAbonoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoAbonoModel> DAL = new NHibernateDAL<PontoAbonoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoAbonoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoAbonoModel> DAL = new NHibernateDAL<PontoAbonoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}