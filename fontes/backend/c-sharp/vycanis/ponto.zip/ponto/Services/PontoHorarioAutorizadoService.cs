using ponto.Models;
using ponto.NHibernate;
using ISession = NHibernate.ISession;

namespace ponto.Services
{
    public class PontoHorarioAutorizadoService
    {

        public IEnumerable<PontoHorarioAutorizadoModel> GetList()
        {
            IList<PontoHorarioAutorizadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioAutorizadoModel> DAL = new NHibernateDAL<PontoHorarioAutorizadoModel>(Session);
                Result = DAL.Select(new PontoHorarioAutorizadoModel());
            }
            return Result;
        }

        public IEnumerable<PontoHorarioAutorizadoModel> GetListFilter(Filter filterObj)
        {
            IList<PontoHorarioAutorizadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PontoHorarioAutorizadoModel where " + filterObj.Where;
                NHibernateDAL<PontoHorarioAutorizadoModel> DAL = new NHibernateDAL<PontoHorarioAutorizadoModel>(Session);
                Result = DAL.SelectListSql<PontoHorarioAutorizadoModel>(Query);
            }
            return Result;
        }
		
        public PontoHorarioAutorizadoModel GetObject(int id)
        {
            PontoHorarioAutorizadoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioAutorizadoModel> DAL = new NHibernateDAL<PontoHorarioAutorizadoModel>(Session);
                Result = DAL.SelectId<PontoHorarioAutorizadoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PontoHorarioAutorizadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioAutorizadoModel> DAL = new NHibernateDAL<PontoHorarioAutorizadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PontoHorarioAutorizadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioAutorizadoModel> DAL = new NHibernateDAL<PontoHorarioAutorizadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PontoHorarioAutorizadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PontoHorarioAutorizadoModel> DAL = new NHibernateDAL<PontoHorarioAutorizadoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}