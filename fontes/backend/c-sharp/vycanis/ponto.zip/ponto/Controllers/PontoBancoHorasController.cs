using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-banco-horas")]
    [Produces("application/json")]
    public class PontoBancoHorasController : Controller
    {
		private readonly PontoBancoHorasService _service;

        public PontoBancoHorasController()
        {
            _service = new PontoBancoHorasService();
        }

        [HttpGet]
        public IActionResult GetListPontoBancoHoras([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoBancoHorasModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoBancoHoras]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoBancoHoras")]
        public IActionResult GetObjectPontoBancoHoras(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoBancoHoras]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoBancoHoras]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoBancoHoras([FromBody]PontoBancoHorasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoBancoHoras]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoBancoHoras", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoBancoHoras]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoBancoHoras([FromBody]PontoBancoHorasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoBancoHoras]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoBancoHoras(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoBancoHoras]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoBancoHoras(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoBancoHoras]", ex));
            }
        }

    }
}