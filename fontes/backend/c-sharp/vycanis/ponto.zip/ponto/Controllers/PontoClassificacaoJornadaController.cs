using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-classificacao-jornada")]
    [Produces("application/json")]
    public class PontoClassificacaoJornadaController : Controller
    {
		private readonly PontoClassificacaoJornadaService _service;

        public PontoClassificacaoJornadaController()
        {
            _service = new PontoClassificacaoJornadaService();
        }

        [HttpGet]
        public IActionResult GetListPontoClassificacaoJornada([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoClassificacaoJornadaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoClassificacaoJornada]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoClassificacaoJornada")]
        public IActionResult GetObjectPontoClassificacaoJornada(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoClassificacaoJornada]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoClassificacaoJornada]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoClassificacaoJornada([FromBody]PontoClassificacaoJornadaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoClassificacaoJornada]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoClassificacaoJornada", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoClassificacaoJornada]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoClassificacaoJornada([FromBody]PontoClassificacaoJornadaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoClassificacaoJornada]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoClassificacaoJornada(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoClassificacaoJornada]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoClassificacaoJornada(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoClassificacaoJornada]", ex));
            }
        }

    }
}