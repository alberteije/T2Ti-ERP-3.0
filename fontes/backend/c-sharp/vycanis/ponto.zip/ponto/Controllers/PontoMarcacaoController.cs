using Microsoft.AspNetCore.Mvc;
using ponto.Models;
using ponto.Services;

namespace ponto.Controllers
{
    [Route("ponto-marcacao")]
    [Produces("application/json")]
    public class PontoMarcacaoController : Controller
    {
		private readonly PontoMarcacaoService _service;

        public PontoMarcacaoController()
        {
            _service = new PontoMarcacaoService();
        }

        [HttpGet]
        public IActionResult GetListPontoMarcacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PontoMarcacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PontoMarcacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPontoMarcacao")]
        public IActionResult GetObjectPontoMarcacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PontoMarcacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PontoMarcacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPontoMarcacao([FromBody]PontoMarcacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PontoMarcacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPontoMarcacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PontoMarcacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePontoMarcacao([FromBody]PontoMarcacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PontoMarcacao]", null));
                }

                _service.Update(objJson);

                return GetObjectPontoMarcacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PontoMarcacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePontoMarcacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PontoMarcacao]", ex));
            }
        }

    }
}