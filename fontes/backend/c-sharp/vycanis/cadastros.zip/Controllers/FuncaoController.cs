using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("funcao")]
    [Produces("application/json")]
    public class FuncaoController : Controller
    {
		private readonly FuncaoService _service;

        public FuncaoController()
        {
            _service = new FuncaoService();
        }

        [HttpGet]
        public IActionResult GetListFuncao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FuncaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Funcao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFuncao")]
        public IActionResult GetObjectFuncao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Funcao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Funcao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFuncao([FromBody]FuncaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Funcao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFuncao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Funcao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFuncao([FromBody]FuncaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Funcao]", null));
                }

                _service.Update(objJson);

                return GetObjectFuncao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Funcao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFuncao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Funcao]", ex));
            }
        }

    }
}