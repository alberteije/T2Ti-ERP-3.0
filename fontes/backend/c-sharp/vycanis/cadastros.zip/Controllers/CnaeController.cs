using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("cnae")]
    [Produces("application/json")]
    public class CnaeController : Controller
    {
		private readonly CnaeService _service;

        public CnaeController()
        {
            _service = new CnaeService();
        }

        [HttpGet]
        public IActionResult GetListCnae([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CnaeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Cnae]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCnae")]
        public IActionResult GetObjectCnae(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Cnae]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Cnae]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCnae([FromBody]CnaeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Cnae]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCnae", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Cnae]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCnae([FromBody]CnaeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Cnae]", null));
                }

                _service.Update(objJson);

                return GetObjectCnae(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Cnae]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCnae(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Cnae]", ex));
            }
        }

    }
}