using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("tipo-relacionamento")]
    [Produces("application/json")]
    public class TipoRelacionamentoController : Controller
    {
		private readonly TipoRelacionamentoService _service;

        public TipoRelacionamentoController()
        {
            _service = new TipoRelacionamentoService();
        }

        [HttpGet]
        public IActionResult GetListTipoRelacionamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TipoRelacionamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TipoRelacionamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTipoRelacionamento")]
        public IActionResult GetObjectTipoRelacionamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TipoRelacionamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TipoRelacionamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTipoRelacionamento([FromBody]TipoRelacionamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TipoRelacionamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTipoRelacionamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TipoRelacionamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTipoRelacionamento([FromBody]TipoRelacionamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TipoRelacionamento]", null));
                }

                _service.Update(objJson);

                return GetObjectTipoRelacionamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TipoRelacionamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTipoRelacionamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TipoRelacionamento]", ex));
            }
        }

    }
}