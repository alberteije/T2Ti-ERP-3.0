using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("pais")]
    [Produces("application/json")]
    public class PaisController : Controller
    {
		private readonly PaisService _service;

        public PaisController()
        {
            _service = new PaisService();
        }

        [HttpGet]
        public IActionResult GetListPais([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PaisModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Pais]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPais")]
        public IActionResult GetObjectPais(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Pais]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Pais]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPais([FromBody]PaisModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Pais]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPais", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Pais]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePais([FromBody]PaisModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Pais]", null));
                }

                _service.Update(objJson);

                return GetObjectPais(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Pais]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePais(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Pais]", ex));
            }
        }

    }
}