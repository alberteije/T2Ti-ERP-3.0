using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("municipio")]
    [Produces("application/json")]
    public class MunicipioController : Controller
    {
		private readonly MunicipioService _service;

        public MunicipioController()
        {
            _service = new MunicipioService();
        }

        [HttpGet]
        public IActionResult GetListMunicipio([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MunicipioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Municipio]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMunicipio")]
        public IActionResult GetObjectMunicipio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Municipio]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Municipio]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMunicipio([FromBody]MunicipioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Municipio]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMunicipio", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Municipio]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMunicipio([FromBody]MunicipioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Municipio]", null));
                }

                _service.Update(objJson);

                return GetObjectMunicipio(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Municipio]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMunicipio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Municipio]", ex));
            }
        }

    }
}