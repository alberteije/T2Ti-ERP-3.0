using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("nivel-formacao")]
    [Produces("application/json")]
    public class NivelFormacaoController : Controller
    {
		private readonly NivelFormacaoService _service;

        public NivelFormacaoController()
        {
            _service = new NivelFormacaoService();
        }

        [HttpGet]
        public IActionResult GetListNivelFormacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NivelFormacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NivelFormacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNivelFormacao")]
        public IActionResult GetObjectNivelFormacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NivelFormacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NivelFormacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNivelFormacao([FromBody]NivelFormacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NivelFormacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNivelFormacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NivelFormacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNivelFormacao([FromBody]NivelFormacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NivelFormacao]", null));
                }

                _service.Update(objJson);

                return GetObjectNivelFormacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NivelFormacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNivelFormacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NivelFormacao]", ex));
            }
        }

    }
}