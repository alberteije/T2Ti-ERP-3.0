using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("pessoa")]
    [Produces("application/json")]
    public class PessoaController : Controller
    {
		private readonly PessoaService _service;

        public PessoaController()
        {
            _service = new PessoaService();
        }

        [HttpGet]
        public IActionResult GetListPessoa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PessoaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Pessoa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPessoa")]
        public IActionResult GetObjectPessoa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Pessoa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Pessoa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPessoa([FromBody]PessoaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Pessoa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPessoa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Pessoa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePessoa([FromBody]PessoaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Pessoa]", null));
                }

                _service.Update(objJson);

                return GetObjectPessoa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Pessoa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePessoa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Pessoa]", ex));
            }
        }

    }
}