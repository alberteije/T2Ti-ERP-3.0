using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("banco-agencia")]
    [Produces("application/json")]
    public class BancoAgenciaController : Controller
    {
		private readonly BancoAgenciaService _service;

        public BancoAgenciaController()
        {
            _service = new BancoAgenciaService();
        }

        [HttpGet]
        public IActionResult GetListBancoAgencia([FromQuery]string filter)
        {
            try
            {
                IEnumerable<BancoAgenciaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList BancoAgencia]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectBancoAgencia")]
        public IActionResult GetObjectBancoAgencia(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject BancoAgencia]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject BancoAgencia]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertBancoAgencia([FromBody]BancoAgenciaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert BancoAgencia]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectBancoAgencia", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert BancoAgencia]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateBancoAgencia([FromBody]BancoAgenciaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update BancoAgencia]", null));
                }

                _service.Update(objJson);

                return GetObjectBancoAgencia(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update BancoAgencia]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBancoAgencia(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete BancoAgencia]", ex));
            }
        }

    }
}