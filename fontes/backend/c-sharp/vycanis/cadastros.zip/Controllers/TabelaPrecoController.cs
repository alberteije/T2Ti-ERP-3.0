using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("tabela-preco")]
    [Produces("application/json")]
    public class TabelaPrecoController : Controller
    {
		private readonly TabelaPrecoService _service;

        public TabelaPrecoController()
        {
            _service = new TabelaPrecoService();
        }

        [HttpGet]
        public IActionResult GetListTabelaPreco([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TabelaPrecoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TabelaPreco]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTabelaPreco")]
        public IActionResult GetObjectTabelaPreco(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TabelaPreco]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TabelaPreco]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTabelaPreco([FromBody]TabelaPrecoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TabelaPreco]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTabelaPreco", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TabelaPreco]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTabelaPreco([FromBody]TabelaPrecoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TabelaPreco]", null));
                }

                _service.Update(objJson);

                return GetObjectTabelaPreco(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TabelaPreco]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTabelaPreco(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TabelaPreco]", ex));
            }
        }

    }
}