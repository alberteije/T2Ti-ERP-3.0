using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("colaborador-tipo")]
    [Produces("application/json")]
    public class ColaboradorTipoController : Controller
    {
		private readonly ColaboradorTipoService _service;

        public ColaboradorTipoController()
        {
            _service = new ColaboradorTipoService();
        }

        [HttpGet]
        public IActionResult GetListColaboradorTipo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ColaboradorTipoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ColaboradorTipo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectColaboradorTipo")]
        public IActionResult GetObjectColaboradorTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ColaboradorTipo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ColaboradorTipo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertColaboradorTipo([FromBody]ColaboradorTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ColaboradorTipo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectColaboradorTipo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ColaboradorTipo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateColaboradorTipo([FromBody]ColaboradorTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ColaboradorTipo]", null));
                }

                _service.Update(objJson);

                return GetObjectColaboradorTipo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ColaboradorTipo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteColaboradorTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ColaboradorTipo]", ex));
            }
        }

    }
}