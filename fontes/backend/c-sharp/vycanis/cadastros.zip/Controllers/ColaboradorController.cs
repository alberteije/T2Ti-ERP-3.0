using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("colaborador")]
    [Produces("application/json")]
    public class ColaboradorController : Controller
    {
		private readonly ColaboradorService _service;

        public ColaboradorController()
        {
            _service = new ColaboradorService();
        }

        [HttpGet]
        public IActionResult GetListColaborador([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ColaboradorModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Colaborador]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectColaborador")]
        public IActionResult GetObjectColaborador(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Colaborador]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Colaborador]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertColaborador([FromBody]ColaboradorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Colaborador]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectColaborador", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Colaborador]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateColaborador([FromBody]ColaboradorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Colaborador]", null));
                }

                _service.Update(objJson);

                return GetObjectColaborador(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Colaborador]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteColaborador(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Colaborador]", ex));
            }
        }

    }
}