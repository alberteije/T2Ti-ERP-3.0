using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("setor")]
    [Produces("application/json")]
    public class SetorController : Controller
    {
		private readonly SetorService _service;

        public SetorController()
        {
            _service = new SetorService();
        }

        [HttpGet]
        public IActionResult GetListSetor([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SetorModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Setor]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSetor")]
        public IActionResult GetObjectSetor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Setor]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Setor]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSetor([FromBody]SetorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Setor]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSetor", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Setor]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSetor([FromBody]SetorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Setor]", null));
                }

                _service.Update(objJson);

                return GetObjectSetor(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Setor]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSetor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Setor]", ex));
            }
        }

    }
}