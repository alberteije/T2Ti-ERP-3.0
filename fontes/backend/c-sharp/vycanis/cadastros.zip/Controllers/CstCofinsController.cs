using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("cst-cofins")]
    [Produces("application/json")]
    public class CstCofinsController : Controller
    {
		private readonly CstCofinsService _service;

        public CstCofinsController()
        {
            _service = new CstCofinsService();
        }

        [HttpGet]
        public IActionResult GetListCstCofins([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CstCofinsModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CstCofins]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCstCofins")]
        public IActionResult GetObjectCstCofins(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CstCofins]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CstCofins]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCstCofins([FromBody]CstCofinsModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CstCofins]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCstCofins", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CstCofins]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCstCofins([FromBody]CstCofinsModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CstCofins]", null));
                }

                _service.Update(objJson);

                return GetObjectCstCofins(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CstCofins]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCstCofins(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CstCofins]", ex));
            }
        }

    }
}