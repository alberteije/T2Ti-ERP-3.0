using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("cst-icms")]
    [Produces("application/json")]
    public class CstIcmsController : Controller
    {
		private readonly CstIcmsService _service;

        public CstIcmsController()
        {
            _service = new CstIcmsService();
        }

        [HttpGet]
        public IActionResult GetListCstIcms([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CstIcmsModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CstIcms]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCstIcms")]
        public IActionResult GetObjectCstIcms(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CstIcms]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CstIcms]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCstIcms([FromBody]CstIcmsModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CstIcms]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCstIcms", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CstIcms]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCstIcms([FromBody]CstIcmsModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CstIcms]", null));
                }

                _service.Update(objJson);

                return GetObjectCstIcms(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CstIcms]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCstIcms(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CstIcms]", ex));
            }
        }

    }
}