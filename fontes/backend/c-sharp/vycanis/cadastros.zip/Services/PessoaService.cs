using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class PessoaService
    {

        public IEnumerable<PessoaModel> GetList()
        {
            IList<PessoaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PessoaModel> DAL = new NHibernateDAL<PessoaModel>(Session);
                Result = DAL.Select(new PessoaModel());
            }
            return Result;
        }

        public IEnumerable<PessoaModel> GetListFilter(Filter filterObj)
        {
            IList<PessoaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PessoaModel where " + filterObj.Where;
                NHibernateDAL<PessoaModel> DAL = new NHibernateDAL<PessoaModel>(Session);
                Result = DAL.SelectListSql<PessoaModel>(Query);
            }
            return Result;
        }
		
        public PessoaModel GetObject(int id)
        {
            PessoaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PessoaModel> DAL = new NHibernateDAL<PessoaModel>(Session);
                Result = DAL.SelectId<PessoaModel>(id);
            }
            return Result;
        }
		
        public void Insert(PessoaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PessoaModel> DAL = new NHibernateDAL<PessoaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PessoaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PessoaModel> DAL = new NHibernateDAL<PessoaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PessoaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PessoaModel> DAL = new NHibernateDAL<PessoaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}