using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class BancoService
    {

        public IEnumerable<BancoModel> GetList()
        {
            IList<BancoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoModel> DAL = new NHibernateDAL<BancoModel>(Session);
                Result = DAL.Select(new BancoModel());
            }
            return Result;
        }

        public IEnumerable<BancoModel> GetListFilter(Filter filterObj)
        {
            IList<BancoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from BancoModel where " + filterObj.Where;
                NHibernateDAL<BancoModel> DAL = new NHibernateDAL<BancoModel>(Session);
                Result = DAL.SelectListSql<BancoModel>(Query);
            }
            return Result;
        }
		
        public BancoModel GetObject(int id)
        {
            BancoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoModel> DAL = new NHibernateDAL<BancoModel>(Session);
                Result = DAL.SelectId<BancoModel>(id);
            }
            return Result;
        }
		
        public void Insert(BancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoModel> DAL = new NHibernateDAL<BancoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(BancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoModel> DAL = new NHibernateDAL<BancoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(BancoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoModel> DAL = new NHibernateDAL<BancoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}