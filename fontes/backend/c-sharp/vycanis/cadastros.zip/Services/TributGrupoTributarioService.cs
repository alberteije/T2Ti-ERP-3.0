using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class TributGrupoTributarioService
    {

        public IEnumerable<TributGrupoTributarioModel> GetList()
        {
            IList<TributGrupoTributarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributGrupoTributarioModel> DAL = new NHibernateDAL<TributGrupoTributarioModel>(Session);
                Result = DAL.Select(new TributGrupoTributarioModel());
            }
            return Result;
        }

        public IEnumerable<TributGrupoTributarioModel> GetListFilter(Filter filterObj)
        {
            IList<TributGrupoTributarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TributGrupoTributarioModel where " + filterObj.Where;
                NHibernateDAL<TributGrupoTributarioModel> DAL = new NHibernateDAL<TributGrupoTributarioModel>(Session);
                Result = DAL.SelectListSql<TributGrupoTributarioModel>(Query);
            }
            return Result;
        }
		
        public TributGrupoTributarioModel GetObject(int id)
        {
            TributGrupoTributarioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributGrupoTributarioModel> DAL = new NHibernateDAL<TributGrupoTributarioModel>(Session);
                Result = DAL.SelectId<TributGrupoTributarioModel>(id);
            }
            return Result;
        }
		
        public void Insert(TributGrupoTributarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributGrupoTributarioModel> DAL = new NHibernateDAL<TributGrupoTributarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TributGrupoTributarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributGrupoTributarioModel> DAL = new NHibernateDAL<TributGrupoTributarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TributGrupoTributarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributGrupoTributarioModel> DAL = new NHibernateDAL<TributGrupoTributarioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}