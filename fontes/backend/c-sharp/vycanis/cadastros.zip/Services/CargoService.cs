using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CargoService
    {

        public IEnumerable<CargoModel> GetList()
        {
            IList<CargoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CargoModel> DAL = new NHibernateDAL<CargoModel>(Session);
                Result = DAL.Select(new CargoModel());
            }
            return Result;
        }

        public IEnumerable<CargoModel> GetListFilter(Filter filterObj)
        {
            IList<CargoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CargoModel where " + filterObj.Where;
                NHibernateDAL<CargoModel> DAL = new NHibernateDAL<CargoModel>(Session);
                Result = DAL.SelectListSql<CargoModel>(Query);
            }
            return Result;
        }
		
        public CargoModel GetObject(int id)
        {
            CargoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CargoModel> DAL = new NHibernateDAL<CargoModel>(Session);
                Result = DAL.SelectId<CargoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CargoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CargoModel> DAL = new NHibernateDAL<CargoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CargoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CargoModel> DAL = new NHibernateDAL<CargoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CargoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CargoModel> DAL = new NHibernateDAL<CargoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}