using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class NivelFormacaoService
    {

        public IEnumerable<NivelFormacaoModel> GetList()
        {
            IList<NivelFormacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NivelFormacaoModel> DAL = new NHibernateDAL<NivelFormacaoModel>(Session);
                Result = DAL.Select(new NivelFormacaoModel());
            }
            return Result;
        }

        public IEnumerable<NivelFormacaoModel> GetListFilter(Filter filterObj)
        {
            IList<NivelFormacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NivelFormacaoModel where " + filterObj.Where;
                NHibernateDAL<NivelFormacaoModel> DAL = new NHibernateDAL<NivelFormacaoModel>(Session);
                Result = DAL.SelectListSql<NivelFormacaoModel>(Query);
            }
            return Result;
        }
		
        public NivelFormacaoModel GetObject(int id)
        {
            NivelFormacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NivelFormacaoModel> DAL = new NHibernateDAL<NivelFormacaoModel>(Session);
                Result = DAL.SelectId<NivelFormacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(NivelFormacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NivelFormacaoModel> DAL = new NHibernateDAL<NivelFormacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NivelFormacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NivelFormacaoModel> DAL = new NHibernateDAL<NivelFormacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NivelFormacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NivelFormacaoModel> DAL = new NHibernateDAL<NivelFormacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}