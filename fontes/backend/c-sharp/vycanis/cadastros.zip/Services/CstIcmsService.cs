using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CstIcmsService
    {

        public IEnumerable<CstIcmsModel> GetList()
        {
            IList<CstIcmsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIcmsModel> DAL = new NHibernateDAL<CstIcmsModel>(Session);
                Result = DAL.Select(new CstIcmsModel());
            }
            return Result;
        }

        public IEnumerable<CstIcmsModel> GetListFilter(Filter filterObj)
        {
            IList<CstIcmsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CstIcmsModel where " + filterObj.Where;
                NHibernateDAL<CstIcmsModel> DAL = new NHibernateDAL<CstIcmsModel>(Session);
                Result = DAL.SelectListSql<CstIcmsModel>(Query);
            }
            return Result;
        }
		
        public CstIcmsModel GetObject(int id)
        {
            CstIcmsModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIcmsModel> DAL = new NHibernateDAL<CstIcmsModel>(Session);
                Result = DAL.SelectId<CstIcmsModel>(id);
            }
            return Result;
        }
		
        public void Insert(CstIcmsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIcmsModel> DAL = new NHibernateDAL<CstIcmsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CstIcmsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIcmsModel> DAL = new NHibernateDAL<CstIcmsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CstIcmsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIcmsModel> DAL = new NHibernateDAL<CstIcmsModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}