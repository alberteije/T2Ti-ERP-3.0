using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CepService
    {

        public IEnumerable<CepModel> GetList()
        {
            IList<CepModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CepModel> DAL = new NHibernateDAL<CepModel>(Session);
                Result = DAL.Select(new CepModel());
            }
            return Result;
        }

        public IEnumerable<CepModel> GetListFilter(Filter filterObj)
        {
            IList<CepModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CepModel where " + filterObj.Where;
                NHibernateDAL<CepModel> DAL = new NHibernateDAL<CepModel>(Session);
                Result = DAL.SelectListSql<CepModel>(Query);
            }
            return Result;
        }
		
        public CepModel GetObject(int id)
        {
            CepModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CepModel> DAL = new NHibernateDAL<CepModel>(Session);
                Result = DAL.SelectId<CepModel>(id);
            }
            return Result;
        }
		
        public void Insert(CepModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CepModel> DAL = new NHibernateDAL<CepModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CepModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CepModel> DAL = new NHibernateDAL<CepModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CepModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CepModel> DAL = new NHibernateDAL<CepModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}