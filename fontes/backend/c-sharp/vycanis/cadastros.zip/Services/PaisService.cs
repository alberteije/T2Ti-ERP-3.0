using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class PaisService
    {

        public IEnumerable<PaisModel> GetList()
        {
            IList<PaisModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PaisModel> DAL = new NHibernateDAL<PaisModel>(Session);
                Result = DAL.Select(new PaisModel());
            }
            return Result;
        }

        public IEnumerable<PaisModel> GetListFilter(Filter filterObj)
        {
            IList<PaisModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PaisModel where " + filterObj.Where;
                NHibernateDAL<PaisModel> DAL = new NHibernateDAL<PaisModel>(Session);
                Result = DAL.SelectListSql<PaisModel>(Query);
            }
            return Result;
        }
		
        public PaisModel GetObject(int id)
        {
            PaisModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PaisModel> DAL = new NHibernateDAL<PaisModel>(Session);
                Result = DAL.SelectId<PaisModel>(id);
            }
            return Result;
        }
		
        public void Insert(PaisModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PaisModel> DAL = new NHibernateDAL<PaisModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PaisModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PaisModel> DAL = new NHibernateDAL<PaisModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PaisModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PaisModel> DAL = new NHibernateDAL<PaisModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}