using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class PapelService
    {

        public IEnumerable<PapelModel> GetList()
        {
            IList<PapelModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PapelModel> DAL = new NHibernateDAL<PapelModel>(Session);
                Result = DAL.Select(new PapelModel());
            }
            return Result;
        }

        public IEnumerable<PapelModel> GetListFilter(Filter filterObj)
        {
            IList<PapelModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PapelModel where " + filterObj.Where;
                NHibernateDAL<PapelModel> DAL = new NHibernateDAL<PapelModel>(Session);
                Result = DAL.SelectListSql<PapelModel>(Query);
            }
            return Result;
        }
		
        public PapelModel GetObject(int id)
        {
            PapelModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PapelModel> DAL = new NHibernateDAL<PapelModel>(Session);
                Result = DAL.SelectId<PapelModel>(id);
            }
            return Result;
        }
		
        public void Insert(PapelModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PapelModel> DAL = new NHibernateDAL<PapelModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PapelModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PapelModel> DAL = new NHibernateDAL<PapelModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PapelModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PapelModel> DAL = new NHibernateDAL<PapelModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}