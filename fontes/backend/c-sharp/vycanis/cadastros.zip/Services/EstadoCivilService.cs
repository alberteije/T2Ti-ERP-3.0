using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class EstadoCivilService
    {

        public IEnumerable<EstadoCivilModel> GetList()
        {
            IList<EstadoCivilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstadoCivilModel> DAL = new NHibernateDAL<EstadoCivilModel>(Session);
                Result = DAL.Select(new EstadoCivilModel());
            }
            return Result;
        }

        public IEnumerable<EstadoCivilModel> GetListFilter(Filter filterObj)
        {
            IList<EstadoCivilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EstadoCivilModel where " + filterObj.Where;
                NHibernateDAL<EstadoCivilModel> DAL = new NHibernateDAL<EstadoCivilModel>(Session);
                Result = DAL.SelectListSql<EstadoCivilModel>(Query);
            }
            return Result;
        }
		
        public EstadoCivilModel GetObject(int id)
        {
            EstadoCivilModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstadoCivilModel> DAL = new NHibernateDAL<EstadoCivilModel>(Session);
                Result = DAL.SelectId<EstadoCivilModel>(id);
            }
            return Result;
        }
		
        public void Insert(EstadoCivilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstadoCivilModel> DAL = new NHibernateDAL<EstadoCivilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EstadoCivilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstadoCivilModel> DAL = new NHibernateDAL<EstadoCivilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EstadoCivilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EstadoCivilModel> DAL = new NHibernateDAL<EstadoCivilModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}