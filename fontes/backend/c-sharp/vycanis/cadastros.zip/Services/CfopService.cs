using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CfopService
    {

        public IEnumerable<CfopModel> GetList()
        {
            IList<CfopModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CfopModel> DAL = new NHibernateDAL<CfopModel>(Session);
                Result = DAL.Select(new CfopModel());
            }
            return Result;
        }

        public IEnumerable<CfopModel> GetListFilter(Filter filterObj)
        {
            IList<CfopModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CfopModel where " + filterObj.Where;
                NHibernateDAL<CfopModel> DAL = new NHibernateDAL<CfopModel>(Session);
                Result = DAL.SelectListSql<CfopModel>(Query);
            }
            return Result;
        }
		
        public CfopModel GetObject(int id)
        {
            CfopModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CfopModel> DAL = new NHibernateDAL<CfopModel>(Session);
                Result = DAL.SelectId<CfopModel>(id);
            }
            return Result;
        }
		
        public void Insert(CfopModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CfopModel> DAL = new NHibernateDAL<CfopModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CfopModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CfopModel> DAL = new NHibernateDAL<CfopModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CfopModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CfopModel> DAL = new NHibernateDAL<CfopModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}