using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class BancoAgenciaService
    {

        public IEnumerable<BancoAgenciaModel> GetList()
        {
            IList<BancoAgenciaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoAgenciaModel> DAL = new NHibernateDAL<BancoAgenciaModel>(Session);
                Result = DAL.Select(new BancoAgenciaModel());
            }
            return Result;
        }

        public IEnumerable<BancoAgenciaModel> GetListFilter(Filter filterObj)
        {
            IList<BancoAgenciaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from BancoAgenciaModel where " + filterObj.Where;
                NHibernateDAL<BancoAgenciaModel> DAL = new NHibernateDAL<BancoAgenciaModel>(Session);
                Result = DAL.SelectListSql<BancoAgenciaModel>(Query);
            }
            return Result;
        }
		
        public BancoAgenciaModel GetObject(int id)
        {
            BancoAgenciaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoAgenciaModel> DAL = new NHibernateDAL<BancoAgenciaModel>(Session);
                Result = DAL.SelectId<BancoAgenciaModel>(id);
            }
            return Result;
        }
		
        public void Insert(BancoAgenciaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoAgenciaModel> DAL = new NHibernateDAL<BancoAgenciaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(BancoAgenciaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoAgenciaModel> DAL = new NHibernateDAL<BancoAgenciaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(BancoAgenciaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BancoAgenciaModel> DAL = new NHibernateDAL<BancoAgenciaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}