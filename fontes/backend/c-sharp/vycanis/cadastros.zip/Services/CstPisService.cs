using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CstPisService
    {

        public IEnumerable<CstPisModel> GetList()
        {
            IList<CstPisModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstPisModel> DAL = new NHibernateDAL<CstPisModel>(Session);
                Result = DAL.Select(new CstPisModel());
            }
            return Result;
        }

        public IEnumerable<CstPisModel> GetListFilter(Filter filterObj)
        {
            IList<CstPisModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CstPisModel where " + filterObj.Where;
                NHibernateDAL<CstPisModel> DAL = new NHibernateDAL<CstPisModel>(Session);
                Result = DAL.SelectListSql<CstPisModel>(Query);
            }
            return Result;
        }
		
        public CstPisModel GetObject(int id)
        {
            CstPisModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstPisModel> DAL = new NHibernateDAL<CstPisModel>(Session);
                Result = DAL.SelectId<CstPisModel>(id);
            }
            return Result;
        }
		
        public void Insert(CstPisModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstPisModel> DAL = new NHibernateDAL<CstPisModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CstPisModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstPisModel> DAL = new NHibernateDAL<CstPisModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CstPisModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstPisModel> DAL = new NHibernateDAL<CstPisModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}