using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CstCofinsService
    {

        public IEnumerable<CstCofinsModel> GetList()
        {
            IList<CstCofinsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstCofinsModel> DAL = new NHibernateDAL<CstCofinsModel>(Session);
                Result = DAL.Select(new CstCofinsModel());
            }
            return Result;
        }

        public IEnumerable<CstCofinsModel> GetListFilter(Filter filterObj)
        {
            IList<CstCofinsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CstCofinsModel where " + filterObj.Where;
                NHibernateDAL<CstCofinsModel> DAL = new NHibernateDAL<CstCofinsModel>(Session);
                Result = DAL.SelectListSql<CstCofinsModel>(Query);
            }
            return Result;
        }
		
        public CstCofinsModel GetObject(int id)
        {
            CstCofinsModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstCofinsModel> DAL = new NHibernateDAL<CstCofinsModel>(Session);
                Result = DAL.SelectId<CstCofinsModel>(id);
            }
            return Result;
        }
		
        public void Insert(CstCofinsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstCofinsModel> DAL = new NHibernateDAL<CstCofinsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CstCofinsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstCofinsModel> DAL = new NHibernateDAL<CstCofinsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CstCofinsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstCofinsModel> DAL = new NHibernateDAL<CstCofinsModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}