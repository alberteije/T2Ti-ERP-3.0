using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CsosnService
    {

        public IEnumerable<CsosnModel> GetList()
        {
            IList<CsosnModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CsosnModel> DAL = new NHibernateDAL<CsosnModel>(Session);
                Result = DAL.Select(new CsosnModel());
            }
            return Result;
        }

        public IEnumerable<CsosnModel> GetListFilter(Filter filterObj)
        {
            IList<CsosnModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CsosnModel where " + filterObj.Where;
                NHibernateDAL<CsosnModel> DAL = new NHibernateDAL<CsosnModel>(Session);
                Result = DAL.SelectListSql<CsosnModel>(Query);
            }
            return Result;
        }
		
        public CsosnModel GetObject(int id)
        {
            CsosnModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CsosnModel> DAL = new NHibernateDAL<CsosnModel>(Session);
                Result = DAL.SelectId<CsosnModel>(id);
            }
            return Result;
        }
		
        public void Insert(CsosnModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CsosnModel> DAL = new NHibernateDAL<CsosnModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CsosnModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CsosnModel> DAL = new NHibernateDAL<CsosnModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CsosnModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CsosnModel> DAL = new NHibernateDAL<CsosnModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}