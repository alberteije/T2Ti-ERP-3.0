using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class SindicatoService
    {

        public IEnumerable<SindicatoModel> GetList()
        {
            IList<SindicatoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SindicatoModel> DAL = new NHibernateDAL<SindicatoModel>(Session);
                Result = DAL.Select(new SindicatoModel());
            }
            return Result;
        }

        public IEnumerable<SindicatoModel> GetListFilter(Filter filterObj)
        {
            IList<SindicatoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SindicatoModel where " + filterObj.Where;
                NHibernateDAL<SindicatoModel> DAL = new NHibernateDAL<SindicatoModel>(Session);
                Result = DAL.SelectListSql<SindicatoModel>(Query);
            }
            return Result;
        }
		
        public SindicatoModel GetObject(int id)
        {
            SindicatoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SindicatoModel> DAL = new NHibernateDAL<SindicatoModel>(Session);
                Result = DAL.SelectId<SindicatoModel>(id);
            }
            return Result;
        }
		
        public void Insert(SindicatoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SindicatoModel> DAL = new NHibernateDAL<SindicatoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SindicatoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SindicatoModel> DAL = new NHibernateDAL<SindicatoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SindicatoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SindicatoModel> DAL = new NHibernateDAL<SindicatoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}