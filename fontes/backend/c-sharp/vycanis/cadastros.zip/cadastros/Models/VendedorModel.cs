namespace cadastros.Models
{
	public class VendedorModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Comissao { get; set; } 

		public System.Nullable<System.Decimal> MetaVenda { get; set; } 

		public ColaboradorModel? ColaboradorModel { get; set; } 

		public ComissaoPerfilModel? ComissaoPerfilModel { get; set; } 

	}
}
