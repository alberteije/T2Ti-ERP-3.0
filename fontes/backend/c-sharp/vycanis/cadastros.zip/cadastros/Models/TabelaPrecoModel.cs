namespace cadastros.Models
{
	public class TabelaPrecoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Principal { get; set; } 

		public System.Nullable<System.Decimal> Coeficiente { get; set; } 

	}
}
