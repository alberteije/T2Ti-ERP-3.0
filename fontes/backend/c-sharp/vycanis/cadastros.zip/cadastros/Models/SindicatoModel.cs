namespace cadastros.Models
{
	public class SindicatoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public int? CodigoBanco { get; set; } 

		public int? CodigoAgencia { get; set; } 

		public string? ContaBanco { get; set; } 

		public string? CodigoCedente { get; set; } 

		public string? Logradouro { get; set; } 

		public string? Numero { get; set; } 

		public string? Bairro { get; set; } 

		public int? MunicipioIbge { get; set; } 

		public string? Uf { get; set; } 

		public string? Fone1 { get; set; } 

		public string? Fone2 { get; set; } 

		public string? Email { get; set; } 

		public string? TipoSindicato { get; set; } 

		public System.Nullable<System.DateTime> DataBase { get; set; } 

		public System.Nullable<System.Decimal> PisoSalarial { get; set; } 

		public string? Cnpj { get; set; } 

		public string? ClassificacaoContabilConta { get; set; } 

	}
}
