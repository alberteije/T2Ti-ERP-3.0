namespace cadastros.Models
{
	public class PessoaFisicaModel
	{	
		public int? Id { get; set; } 

		public string? Cpf { get; set; } 

		public string? Rg { get; set; } 

		public string? OrgaoRg { get; set; } 

		public System.Nullable<System.DateTime> DataEmissaoRg { get; set; } 

		public System.Nullable<System.DateTime> DataNascimento { get; set; } 

		public string? Sexo { get; set; } 

		public string? Raca { get; set; } 

		public string? Nacionalidade { get; set; } 

		public string? Naturalidade { get; set; } 

		public string? NomePai { get; set; } 

		public string? NomeMae { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

		public EstadoCivilModel? EstadoCivilModel { get; set; } 

		public NivelFormacaoModel? NivelFormacaoModel { get; set; } 

	}
}
