namespace cadastros.Models
{
	public class FuncaoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		private IList<PapelFuncaoModel>? papelFuncaoModelList; 
		public IList<PapelFuncaoModel>? PapelFuncaoModelList 
		{ 
			get 
			{ 
				return papelFuncaoModelList; 
			} 
			set 
			{ 
				papelFuncaoModelList = value; 
				foreach (PapelFuncaoModel papelFuncaoModel in papelFuncaoModelList!) 
				{ 
					papelFuncaoModel.FuncaoModel = this; 
				} 
			} 
		} 

	}
}
