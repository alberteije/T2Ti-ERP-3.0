namespace cadastros.Models
{
	public class PaisModel
	{	
		public int? Id { get; set; } 

		public string? NomePtbr { get; set; } 

		public string? NomeEn { get; set; } 

		public int? Codigo { get; set; } 

		public string? Sigla2 { get; set; } 

		public string? Sigla3 { get; set; } 

		public int? CodigoBacen { get; set; } 

	}
}
