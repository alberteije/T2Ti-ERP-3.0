namespace cadastros.Models
{
	public class PessoaJuridicaModel
	{	
		public int? Id { get; set; } 

		public string? Cnpj { get; set; } 

		public string? NomeFantasia { get; set; } 

		public string? InscricaoEstadual { get; set; } 

		public string? InscricaoMunicipal { get; set; } 

		public System.Nullable<System.DateTime> DataConstituicao { get; set; } 

		public string? TipoRegime { get; set; } 

		public string? Crt { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
