namespace cadastros.Models
{
	public class MunicipioModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public int? CodigoIbge { get; set; } 

		public int? CodigoReceitaFederal { get; set; } 

		public int? CodigoEstadual { get; set; } 

		public UfModel? UfModel { get; set; } 

	}
}
