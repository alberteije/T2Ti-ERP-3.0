namespace cadastros.Models
{
	public class PessoaTelefoneModel
	{	
		public int? Id { get; set; } 

		public string? Tipo { get; set; } 

		public string? Numero { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
