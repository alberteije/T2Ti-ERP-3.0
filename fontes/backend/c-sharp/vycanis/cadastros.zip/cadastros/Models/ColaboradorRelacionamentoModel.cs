namespace cadastros.Models
{
	public class ColaboradorRelacionamentoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.DateTime> DataNascimento { get; set; } 

		public string? Cpf { get; set; } 

		public string? RegistroMatricula { get; set; } 

		public string? RegistroCartorio { get; set; } 

		public string? RegistroCartorioNumero { get; set; } 

		public string? RegistroNumeroLivro { get; set; } 

		public string? RegistroNumeroFolha { get; set; } 

		public System.Nullable<System.DateTime> DataEntregaDocumento { get; set; } 

		public string? SalarioFamilia { get; set; } 

		public int? SalarioFamiliaIdadeLimite { get; set; } 

		public System.Nullable<System.DateTime> SalarioFamiliaDataFim { get; set; } 

		public int? ImpostoRendaIdadeLimite { get; set; } 

		public int? ImpostoRendaDataFim { get; set; } 

		public ColaboradorModel? ColaboradorModel { get; set; } 

		public TipoRelacionamentoModel? TipoRelacionamentoModel { get; set; } 

	}
}
