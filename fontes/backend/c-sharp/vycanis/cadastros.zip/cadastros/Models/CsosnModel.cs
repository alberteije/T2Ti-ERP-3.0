namespace cadastros.Models
{
	public class CsosnModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Observacao { get; set; } 

	}
}
