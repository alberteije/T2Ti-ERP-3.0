using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("cfop")]
    [Produces("application/json")]
    public class CfopController : Controller
    {
		private readonly CfopService _service;

        public CfopController()
        {
            _service = new CfopService();
        }

        [HttpGet]
        public IActionResult GetListCfop([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CfopModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Cfop]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCfop")]
        public IActionResult GetObjectCfop(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Cfop]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Cfop]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCfop([FromBody]CfopModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Cfop]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCfop", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Cfop]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCfop([FromBody]CfopModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Cfop]", null));
                }

                _service.Update(objJson);

                return GetObjectCfop(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Cfop]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCfop(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Cfop]", ex));
            }
        }

    }
}