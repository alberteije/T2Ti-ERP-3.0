using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("cargo")]
    [Produces("application/json")]
    public class CargoController : Controller
    {
		private readonly CargoService _service;

        public CargoController()
        {
            _service = new CargoService();
        }

        [HttpGet]
        public IActionResult GetListCargo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CargoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Cargo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCargo")]
        public IActionResult GetObjectCargo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Cargo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Cargo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCargo([FromBody]CargoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Cargo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCargo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Cargo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCargo([FromBody]CargoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Cargo]", null));
                }

                _service.Update(objJson);

                return GetObjectCargo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Cargo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCargo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Cargo]", ex));
            }
        }

    }
}