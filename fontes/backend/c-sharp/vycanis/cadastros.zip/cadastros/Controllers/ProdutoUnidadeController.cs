using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("produto-unidade")]
    [Produces("application/json")]
    public class ProdutoUnidadeController : Controller
    {
		private readonly ProdutoUnidadeService _service;

        public ProdutoUnidadeController()
        {
            _service = new ProdutoUnidadeService();
        }

        [HttpGet]
        public IActionResult GetListProdutoUnidade([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ProdutoUnidadeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ProdutoUnidade]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectProdutoUnidade")]
        public IActionResult GetObjectProdutoUnidade(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ProdutoUnidade]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ProdutoUnidade]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertProdutoUnidade([FromBody]ProdutoUnidadeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ProdutoUnidade]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectProdutoUnidade", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ProdutoUnidade]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateProdutoUnidade([FromBody]ProdutoUnidadeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ProdutoUnidade]", null));
                }

                _service.Update(objJson);

                return GetObjectProdutoUnidade(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ProdutoUnidade]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProdutoUnidade(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ProdutoUnidade]", ex));
            }
        }

    }
}