using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("tipo-admissao")]
    [Produces("application/json")]
    public class TipoAdmissaoController : Controller
    {
		private readonly TipoAdmissaoService _service;

        public TipoAdmissaoController()
        {
            _service = new TipoAdmissaoService();
        }

        [HttpGet]
        public IActionResult GetListTipoAdmissao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TipoAdmissaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TipoAdmissao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTipoAdmissao")]
        public IActionResult GetObjectTipoAdmissao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TipoAdmissao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TipoAdmissao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTipoAdmissao([FromBody]TipoAdmissaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TipoAdmissao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTipoAdmissao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TipoAdmissao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTipoAdmissao([FromBody]TipoAdmissaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TipoAdmissao]", null));
                }

                _service.Update(objJson);

                return GetObjectTipoAdmissao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TipoAdmissao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTipoAdmissao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TipoAdmissao]", ex));
            }
        }

    }
}