using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("cep")]
    [Produces("application/json")]
    public class CepController : Controller
    {
		private readonly CepService _service;

        public CepController()
        {
            _service = new CepService();
        }

        [HttpGet]
        public IActionResult GetListCep([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CepModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Cep]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCep")]
        public IActionResult GetObjectCep(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Cep]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Cep]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCep([FromBody]CepModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Cep]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCep", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Cep]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCep([FromBody]CepModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Cep]", null));
                }

                _service.Update(objJson);

                return GetObjectCep(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Cep]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCep(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Cep]", ex));
            }
        }

    }
}