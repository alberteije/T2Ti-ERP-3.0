using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("cst-ipi")]
    [Produces("application/json")]
    public class CstIpiController : Controller
    {
		private readonly CstIpiService _service;

        public CstIpiController()
        {
            _service = new CstIpiService();
        }

        [HttpGet]
        public IActionResult GetListCstIpi([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CstIpiModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CstIpi]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCstIpi")]
        public IActionResult GetObjectCstIpi(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CstIpi]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CstIpi]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCstIpi([FromBody]CstIpiModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CstIpi]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCstIpi", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CstIpi]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCstIpi([FromBody]CstIpiModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CstIpi]", null));
                }

                _service.Update(objJson);

                return GetObjectCstIpi(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CstIpi]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCstIpi(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CstIpi]", ex));
            }
        }

    }
}