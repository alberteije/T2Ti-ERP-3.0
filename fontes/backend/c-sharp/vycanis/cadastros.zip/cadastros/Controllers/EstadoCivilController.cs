using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("estado-civil")]
    [Produces("application/json")]
    public class EstadoCivilController : Controller
    {
		private readonly EstadoCivilService _service;

        public EstadoCivilController()
        {
            _service = new EstadoCivilService();
        }

        [HttpGet]
        public IActionResult GetListEstadoCivil([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EstadoCivilModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EstadoCivil]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEstadoCivil")]
        public IActionResult GetObjectEstadoCivil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EstadoCivil]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EstadoCivil]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEstadoCivil([FromBody]EstadoCivilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EstadoCivil]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEstadoCivil", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EstadoCivil]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEstadoCivil([FromBody]EstadoCivilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EstadoCivil]", null));
                }

                _service.Update(objJson);

                return GetObjectEstadoCivil(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EstadoCivil]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEstadoCivil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EstadoCivil]", ex));
            }
        }

    }
}