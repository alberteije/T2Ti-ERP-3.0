using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("uf")]
    [Produces("application/json")]
    public class UfController : Controller
    {
		private readonly UfService _service;

        public UfController()
        {
            _service = new UfService();
        }

        [HttpGet]
        public IActionResult GetListUf([FromQuery]string filter)
        {
            try
            {
                IEnumerable<UfModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Uf]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectUf")]
        public IActionResult GetObjectUf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Uf]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Uf]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertUf([FromBody]UfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Uf]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectUf", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Uf]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateUf([FromBody]UfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Uf]", null));
                }

                _service.Update(objJson);

                return GetObjectUf(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Uf]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Uf]", ex));
            }
        }

    }
}