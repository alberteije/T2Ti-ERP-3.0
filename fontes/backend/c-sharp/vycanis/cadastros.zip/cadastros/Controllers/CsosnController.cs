using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("csosn")]
    [Produces("application/json")]
    public class CsosnController : Controller
    {
		private readonly CsosnService _service;

        public CsosnController()
        {
            _service = new CsosnService();
        }

        [HttpGet]
        public IActionResult GetListCsosn([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CsosnModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Csosn]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCsosn")]
        public IActionResult GetObjectCsosn(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Csosn]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Csosn]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCsosn([FromBody]CsosnModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Csosn]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCsosn", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Csosn]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCsosn([FromBody]CsosnModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Csosn]", null));
                }

                _service.Update(objJson);

                return GetObjectCsosn(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Csosn]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCsosn(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Csosn]", ex));
            }
        }

    }
}