using Microsoft.AspNetCore.Mvc;
using cadastros.Models;
using cadastros.Services;

namespace cadastros.Controllers
{
    [Route("sindicato")]
    [Produces("application/json")]
    public class SindicatoController : Controller
    {
		private readonly SindicatoService _service;

        public SindicatoController()
        {
            _service = new SindicatoService();
        }

        [HttpGet]
        public IActionResult GetListSindicato([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SindicatoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Sindicato]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSindicato")]
        public IActionResult GetObjectSindicato(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Sindicato]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Sindicato]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSindicato([FromBody]SindicatoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Sindicato]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSindicato", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Sindicato]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSindicato([FromBody]SindicatoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Sindicato]", null));
                }

                _service.Update(objJson);

                return GetObjectSindicato(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Sindicato]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSindicato(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Sindicato]", ex));
            }
        }

    }
}