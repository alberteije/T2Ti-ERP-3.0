using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class CstIpiService
    {

        public IEnumerable<CstIpiModel> GetList()
        {
            IList<CstIpiModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIpiModel> DAL = new NHibernateDAL<CstIpiModel>(Session);
                Result = DAL.Select(new CstIpiModel());
            }
            return Result;
        }

        public IEnumerable<CstIpiModel> GetListFilter(Filter filterObj)
        {
            IList<CstIpiModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CstIpiModel where " + filterObj.Where;
                NHibernateDAL<CstIpiModel> DAL = new NHibernateDAL<CstIpiModel>(Session);
                Result = DAL.SelectListSql<CstIpiModel>(Query);
            }
            return Result;
        }
		
        public CstIpiModel GetObject(int id)
        {
            CstIpiModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIpiModel> DAL = new NHibernateDAL<CstIpiModel>(Session);
                Result = DAL.SelectId<CstIpiModel>(id);
            }
            return Result;
        }
		
        public void Insert(CstIpiModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIpiModel> DAL = new NHibernateDAL<CstIpiModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CstIpiModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIpiModel> DAL = new NHibernateDAL<CstIpiModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CstIpiModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CstIpiModel> DAL = new NHibernateDAL<CstIpiModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}