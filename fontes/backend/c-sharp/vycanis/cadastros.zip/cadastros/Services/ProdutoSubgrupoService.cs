using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class ProdutoSubgrupoService
    {

        public IEnumerable<ProdutoSubgrupoModel> GetList()
        {
            IList<ProdutoSubgrupoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoSubgrupoModel> DAL = new NHibernateDAL<ProdutoSubgrupoModel>(Session);
                Result = DAL.Select(new ProdutoSubgrupoModel());
            }
            return Result;
        }

        public IEnumerable<ProdutoSubgrupoModel> GetListFilter(Filter filterObj)
        {
            IList<ProdutoSubgrupoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ProdutoSubgrupoModel where " + filterObj.Where;
                NHibernateDAL<ProdutoSubgrupoModel> DAL = new NHibernateDAL<ProdutoSubgrupoModel>(Session);
                Result = DAL.SelectListSql<ProdutoSubgrupoModel>(Query);
            }
            return Result;
        }
		
        public ProdutoSubgrupoModel GetObject(int id)
        {
            ProdutoSubgrupoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoSubgrupoModel> DAL = new NHibernateDAL<ProdutoSubgrupoModel>(Session);
                Result = DAL.SelectId<ProdutoSubgrupoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ProdutoSubgrupoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoSubgrupoModel> DAL = new NHibernateDAL<ProdutoSubgrupoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ProdutoSubgrupoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoSubgrupoModel> DAL = new NHibernateDAL<ProdutoSubgrupoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ProdutoSubgrupoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoSubgrupoModel> DAL = new NHibernateDAL<ProdutoSubgrupoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}