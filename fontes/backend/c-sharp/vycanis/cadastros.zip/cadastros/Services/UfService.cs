using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class UfService
    {

        public IEnumerable<UfModel> GetList()
        {
            IList<UfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UfModel> DAL = new NHibernateDAL<UfModel>(Session);
                Result = DAL.Select(new UfModel());
            }
            return Result;
        }

        public IEnumerable<UfModel> GetListFilter(Filter filterObj)
        {
            IList<UfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from UfModel where " + filterObj.Where;
                NHibernateDAL<UfModel> DAL = new NHibernateDAL<UfModel>(Session);
                Result = DAL.SelectListSql<UfModel>(Query);
            }
            return Result;
        }
		
        public UfModel GetObject(int id)
        {
            UfModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UfModel> DAL = new NHibernateDAL<UfModel>(Session);
                Result = DAL.SelectId<UfModel>(id);
            }
            return Result;
        }
		
        public void Insert(UfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UfModel> DAL = new NHibernateDAL<UfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(UfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UfModel> DAL = new NHibernateDAL<UfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(UfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UfModel> DAL = new NHibernateDAL<UfModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}