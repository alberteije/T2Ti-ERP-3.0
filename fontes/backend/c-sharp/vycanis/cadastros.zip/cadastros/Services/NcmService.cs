using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class NcmService
    {

        public IEnumerable<NcmModel> GetList()
        {
            IList<NcmModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NcmModel> DAL = new NHibernateDAL<NcmModel>(Session);
                Result = DAL.Select(new NcmModel());
            }
            return Result;
        }

        public IEnumerable<NcmModel> GetListFilter(Filter filterObj)
        {
            IList<NcmModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NcmModel where " + filterObj.Where;
                NHibernateDAL<NcmModel> DAL = new NHibernateDAL<NcmModel>(Session);
                Result = DAL.SelectListSql<NcmModel>(Query);
            }
            return Result;
        }
		
        public NcmModel GetObject(int id)
        {
            NcmModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NcmModel> DAL = new NHibernateDAL<NcmModel>(Session);
                Result = DAL.SelectId<NcmModel>(id);
            }
            return Result;
        }
		
        public void Insert(NcmModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NcmModel> DAL = new NHibernateDAL<NcmModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NcmModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NcmModel> DAL = new NHibernateDAL<NcmModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NcmModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NcmModel> DAL = new NHibernateDAL<NcmModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}