using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class ColaboradorTipoService
    {

        public IEnumerable<ColaboradorTipoModel> GetList()
        {
            IList<ColaboradorTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorTipoModel> DAL = new NHibernateDAL<ColaboradorTipoModel>(Session);
                Result = DAL.Select(new ColaboradorTipoModel());
            }
            return Result;
        }

        public IEnumerable<ColaboradorTipoModel> GetListFilter(Filter filterObj)
        {
            IList<ColaboradorTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ColaboradorTipoModel where " + filterObj.Where;
                NHibernateDAL<ColaboradorTipoModel> DAL = new NHibernateDAL<ColaboradorTipoModel>(Session);
                Result = DAL.SelectListSql<ColaboradorTipoModel>(Query);
            }
            return Result;
        }
		
        public ColaboradorTipoModel GetObject(int id)
        {
            ColaboradorTipoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorTipoModel> DAL = new NHibernateDAL<ColaboradorTipoModel>(Session);
                Result = DAL.SelectId<ColaboradorTipoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ColaboradorTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorTipoModel> DAL = new NHibernateDAL<ColaboradorTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ColaboradorTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorTipoModel> DAL = new NHibernateDAL<ColaboradorTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ColaboradorTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorTipoModel> DAL = new NHibernateDAL<ColaboradorTipoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}