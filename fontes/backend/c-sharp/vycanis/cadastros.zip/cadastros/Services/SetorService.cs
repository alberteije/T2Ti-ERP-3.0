using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class SetorService
    {

        public IEnumerable<SetorModel> GetList()
        {
            IList<SetorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SetorModel> DAL = new NHibernateDAL<SetorModel>(Session);
                Result = DAL.Select(new SetorModel());
            }
            return Result;
        }

        public IEnumerable<SetorModel> GetListFilter(Filter filterObj)
        {
            IList<SetorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SetorModel where " + filterObj.Where;
                NHibernateDAL<SetorModel> DAL = new NHibernateDAL<SetorModel>(Session);
                Result = DAL.SelectListSql<SetorModel>(Query);
            }
            return Result;
        }
		
        public SetorModel GetObject(int id)
        {
            SetorModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SetorModel> DAL = new NHibernateDAL<SetorModel>(Session);
                Result = DAL.SelectId<SetorModel>(id);
            }
            return Result;
        }
		
        public void Insert(SetorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SetorModel> DAL = new NHibernateDAL<SetorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SetorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SetorModel> DAL = new NHibernateDAL<SetorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SetorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SetorModel> DAL = new NHibernateDAL<SetorModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}