using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class TipoRelacionamentoService
    {

        public IEnumerable<TipoRelacionamentoModel> GetList()
        {
            IList<TipoRelacionamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoRelacionamentoModel> DAL = new NHibernateDAL<TipoRelacionamentoModel>(Session);
                Result = DAL.Select(new TipoRelacionamentoModel());
            }
            return Result;
        }

        public IEnumerable<TipoRelacionamentoModel> GetListFilter(Filter filterObj)
        {
            IList<TipoRelacionamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TipoRelacionamentoModel where " + filterObj.Where;
                NHibernateDAL<TipoRelacionamentoModel> DAL = new NHibernateDAL<TipoRelacionamentoModel>(Session);
                Result = DAL.SelectListSql<TipoRelacionamentoModel>(Query);
            }
            return Result;
        }
		
        public TipoRelacionamentoModel GetObject(int id)
        {
            TipoRelacionamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoRelacionamentoModel> DAL = new NHibernateDAL<TipoRelacionamentoModel>(Session);
                Result = DAL.SelectId<TipoRelacionamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(TipoRelacionamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoRelacionamentoModel> DAL = new NHibernateDAL<TipoRelacionamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TipoRelacionamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoRelacionamentoModel> DAL = new NHibernateDAL<TipoRelacionamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TipoRelacionamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoRelacionamentoModel> DAL = new NHibernateDAL<TipoRelacionamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}