using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class TabelaPrecoService
    {

        public IEnumerable<TabelaPrecoModel> GetList()
        {
            IList<TabelaPrecoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TabelaPrecoModel> DAL = new NHibernateDAL<TabelaPrecoModel>(Session);
                Result = DAL.Select(new TabelaPrecoModel());
            }
            return Result;
        }

        public IEnumerable<TabelaPrecoModel> GetListFilter(Filter filterObj)
        {
            IList<TabelaPrecoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TabelaPrecoModel where " + filterObj.Where;
                NHibernateDAL<TabelaPrecoModel> DAL = new NHibernateDAL<TabelaPrecoModel>(Session);
                Result = DAL.SelectListSql<TabelaPrecoModel>(Query);
            }
            return Result;
        }
		
        public TabelaPrecoModel GetObject(int id)
        {
            TabelaPrecoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TabelaPrecoModel> DAL = new NHibernateDAL<TabelaPrecoModel>(Session);
                Result = DAL.SelectId<TabelaPrecoModel>(id);
            }
            return Result;
        }
		
        public void Insert(TabelaPrecoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TabelaPrecoModel> DAL = new NHibernateDAL<TabelaPrecoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TabelaPrecoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TabelaPrecoModel> DAL = new NHibernateDAL<TabelaPrecoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TabelaPrecoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TabelaPrecoModel> DAL = new NHibernateDAL<TabelaPrecoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}