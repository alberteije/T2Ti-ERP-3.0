using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class ColaboradorSituacaoService
    {

        public IEnumerable<ColaboradorSituacaoModel> GetList()
        {
            IList<ColaboradorSituacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorSituacaoModel> DAL = new NHibernateDAL<ColaboradorSituacaoModel>(Session);
                Result = DAL.Select(new ColaboradorSituacaoModel());
            }
            return Result;
        }

        public IEnumerable<ColaboradorSituacaoModel> GetListFilter(Filter filterObj)
        {
            IList<ColaboradorSituacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ColaboradorSituacaoModel where " + filterObj.Where;
                NHibernateDAL<ColaboradorSituacaoModel> DAL = new NHibernateDAL<ColaboradorSituacaoModel>(Session);
                Result = DAL.SelectListSql<ColaboradorSituacaoModel>(Query);
            }
            return Result;
        }
		
        public ColaboradorSituacaoModel GetObject(int id)
        {
            ColaboradorSituacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorSituacaoModel> DAL = new NHibernateDAL<ColaboradorSituacaoModel>(Session);
                Result = DAL.SelectId<ColaboradorSituacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ColaboradorSituacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorSituacaoModel> DAL = new NHibernateDAL<ColaboradorSituacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ColaboradorSituacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorSituacaoModel> DAL = new NHibernateDAL<ColaboradorSituacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ColaboradorSituacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorSituacaoModel> DAL = new NHibernateDAL<ColaboradorSituacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}