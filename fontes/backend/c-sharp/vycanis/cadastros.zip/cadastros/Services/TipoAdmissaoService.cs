using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class TipoAdmissaoService
    {

        public IEnumerable<TipoAdmissaoModel> GetList()
        {
            IList<TipoAdmissaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoAdmissaoModel> DAL = new NHibernateDAL<TipoAdmissaoModel>(Session);
                Result = DAL.Select(new TipoAdmissaoModel());
            }
            return Result;
        }

        public IEnumerable<TipoAdmissaoModel> GetListFilter(Filter filterObj)
        {
            IList<TipoAdmissaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TipoAdmissaoModel where " + filterObj.Where;
                NHibernateDAL<TipoAdmissaoModel> DAL = new NHibernateDAL<TipoAdmissaoModel>(Session);
                Result = DAL.SelectListSql<TipoAdmissaoModel>(Query);
            }
            return Result;
        }
		
        public TipoAdmissaoModel GetObject(int id)
        {
            TipoAdmissaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoAdmissaoModel> DAL = new NHibernateDAL<TipoAdmissaoModel>(Session);
                Result = DAL.SelectId<TipoAdmissaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(TipoAdmissaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoAdmissaoModel> DAL = new NHibernateDAL<TipoAdmissaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TipoAdmissaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoAdmissaoModel> DAL = new NHibernateDAL<TipoAdmissaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TipoAdmissaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoAdmissaoModel> DAL = new NHibernateDAL<TipoAdmissaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}