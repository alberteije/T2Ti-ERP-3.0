using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class ColaboradorService
    {

        public IEnumerable<ColaboradorModel> GetList()
        {
            IList<ColaboradorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorModel> DAL = new NHibernateDAL<ColaboradorModel>(Session);
                Result = DAL.Select(new ColaboradorModel());
            }
            return Result;
        }

        public IEnumerable<ColaboradorModel> GetListFilter(Filter filterObj)
        {
            IList<ColaboradorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ColaboradorModel where " + filterObj.Where;
                NHibernateDAL<ColaboradorModel> DAL = new NHibernateDAL<ColaboradorModel>(Session);
                Result = DAL.SelectListSql<ColaboradorModel>(Query);
            }
            return Result;
        }
		
        public ColaboradorModel GetObject(int id)
        {
            ColaboradorModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorModel> DAL = new NHibernateDAL<ColaboradorModel>(Session);
                Result = DAL.SelectId<ColaboradorModel>(id);
            }
            return Result;
        }
		
        public void Insert(ColaboradorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorModel> DAL = new NHibernateDAL<ColaboradorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ColaboradorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorModel> DAL = new NHibernateDAL<ColaboradorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ColaboradorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ColaboradorModel> DAL = new NHibernateDAL<ColaboradorModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}