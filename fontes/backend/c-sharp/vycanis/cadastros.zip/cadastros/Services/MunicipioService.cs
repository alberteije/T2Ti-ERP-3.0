using cadastros.Models;
using cadastros.NHibernate;
using ISession = NHibernate.ISession;

namespace cadastros.Services
{
    public class MunicipioService
    {

        public IEnumerable<MunicipioModel> GetList()
        {
            IList<MunicipioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MunicipioModel> DAL = new NHibernateDAL<MunicipioModel>(Session);
                Result = DAL.Select(new MunicipioModel());
            }
            return Result;
        }

        public IEnumerable<MunicipioModel> GetListFilter(Filter filterObj)
        {
            IList<MunicipioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MunicipioModel where " + filterObj.Where;
                NHibernateDAL<MunicipioModel> DAL = new NHibernateDAL<MunicipioModel>(Session);
                Result = DAL.SelectListSql<MunicipioModel>(Query);
            }
            return Result;
        }
		
        public MunicipioModel GetObject(int id)
        {
            MunicipioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MunicipioModel> DAL = new NHibernateDAL<MunicipioModel>(Session);
                Result = DAL.SelectId<MunicipioModel>(id);
            }
            return Result;
        }
		
        public void Insert(MunicipioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MunicipioModel> DAL = new NHibernateDAL<MunicipioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MunicipioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MunicipioModel> DAL = new NHibernateDAL<MunicipioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MunicipioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MunicipioModel> DAL = new NHibernateDAL<MunicipioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}