namespace cadastros.Models
{
	public class PessoaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Tipo { get; set; } 

		public string? Site { get; set; } 

		public string? Email { get; set; } 

		public string? EhCliente { get; set; } 

		public string? EhFornecedor { get; set; } 

		public string? EhTransportadora { get; set; } 

		public string? EhColaborador { get; set; } 

		public string? EhContador { get; set; } 

		private PessoaJuridicaModel? pessoaJuridicaModel; 
		public PessoaJuridicaModel? PessoaJuridicaModel 
		{ 
			get 
			{ 
				return pessoaJuridicaModel; 
			} 
			set 
			{ 
				pessoaJuridicaModel = value; 
				if (value != null) 
				{ 
					pessoaJuridicaModel!.PessoaModel = this; 
				} 
			} 
		} 

		private FornecedorModel? fornecedorModel; 
		public FornecedorModel? FornecedorModel 
		{ 
			get 
			{ 
				return fornecedorModel; 
			} 
			set 
			{ 
				fornecedorModel = value; 
				if (value != null) 
				{ 
					fornecedorModel!.PessoaModel = this; 
				} 
			} 
		} 

		private ClienteModel? clienteModel; 
		public ClienteModel? ClienteModel 
		{ 
			get 
			{ 
				return clienteModel; 
			} 
			set 
			{ 
				clienteModel = value; 
				if (value != null) 
				{ 
					clienteModel!.PessoaModel = this; 
				} 
			} 
		} 

		private PessoaFisicaModel? pessoaFisicaModel; 
		public PessoaFisicaModel? PessoaFisicaModel 
		{ 
			get 
			{ 
				return pessoaFisicaModel; 
			} 
			set 
			{ 
				pessoaFisicaModel = value; 
				if (value != null) 
				{ 
					pessoaFisicaModel!.PessoaModel = this; 
				} 
			} 
		} 

		private TransportadoraModel? transportadoraModel; 
		public TransportadoraModel? TransportadoraModel 
		{ 
			get 
			{ 
				return transportadoraModel; 
			} 
			set 
			{ 
				transportadoraModel = value; 
				if (value != null) 
				{ 
					transportadoraModel!.PessoaModel = this; 
				} 
			} 
		} 

		private ContadorModel? contadorModel; 
		public ContadorModel? ContadorModel 
		{ 
			get 
			{ 
				return contadorModel; 
			} 
			set 
			{ 
				contadorModel = value; 
				if (value != null) 
				{ 
					contadorModel!.PessoaModel = this; 
				} 
			} 
		} 

		private IList<PessoaContatoModel>? pessoaContatoModelList; 
		public IList<PessoaContatoModel>? PessoaContatoModelList 
		{ 
			get 
			{ 
				return pessoaContatoModelList; 
			} 
			set 
			{ 
				pessoaContatoModelList = value; 
				foreach (PessoaContatoModel pessoaContatoModel in pessoaContatoModelList!) 
				{ 
					pessoaContatoModel.PessoaModel = this; 
				} 
			} 
		} 

		private IList<PessoaTelefoneModel>? pessoaTelefoneModelList; 
		public IList<PessoaTelefoneModel>? PessoaTelefoneModelList 
		{ 
			get 
			{ 
				return pessoaTelefoneModelList; 
			} 
			set 
			{ 
				pessoaTelefoneModelList = value; 
				foreach (PessoaTelefoneModel pessoaTelefoneModel in pessoaTelefoneModelList!) 
				{ 
					pessoaTelefoneModel.PessoaModel = this; 
				} 
			} 
		} 

		private IList<PessoaEnderecoModel>? pessoaEnderecoModelList; 
		public IList<PessoaEnderecoModel>? PessoaEnderecoModelList 
		{ 
			get 
			{ 
				return pessoaEnderecoModelList; 
			} 
			set 
			{ 
				pessoaEnderecoModelList = value; 
				foreach (PessoaEnderecoModel pessoaEnderecoModel in pessoaEnderecoModelList!) 
				{ 
					pessoaEnderecoModel.PessoaModel = this; 
				} 
			} 
		} 

	}
}
