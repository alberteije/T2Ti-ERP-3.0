namespace cadastros.Models
{
	public class CfopModel
	{	
		public int? Id { get; set; } 

		public int? Codigo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Aplicacao { get; set; } 

	}
}
