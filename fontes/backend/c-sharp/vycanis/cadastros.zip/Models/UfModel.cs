namespace cadastros.Models
{
	public class UfModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Sigla { get; set; } 

		public int? CodigoIbge { get; set; } 

	}
}
