namespace cadastros.Models
{
	public class CstCofinsModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Observacao { get; set; } 

	}
}
