namespace cadastros.Models
{
	public class ContadorModel
	{	
		public int? Id { get; set; } 

		public string? CrcInscricao { get; set; } 

		public string? CrcUf { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
