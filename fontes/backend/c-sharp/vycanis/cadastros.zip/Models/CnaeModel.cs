namespace cadastros.Models
{
	public class CnaeModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Denominacao { get; set; } 

	}
}
