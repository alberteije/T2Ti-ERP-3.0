namespace cadastros.Models
{
	public class CargoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.Decimal> Salario { get; set; } 

		public string? Cbo1994 { get; set; } 

		public string? Cbo2002 { get; set; } 

	}
}
