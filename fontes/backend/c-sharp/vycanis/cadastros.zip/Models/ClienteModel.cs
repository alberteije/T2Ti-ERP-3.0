namespace cadastros.Models
{
	public class ClienteModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> Desde { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> LimiteCredito { get; set; } 

		public string? Observacao { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

		public TabelaPrecoModel? TabelaPrecoModel { get; set; } 

	}
}
