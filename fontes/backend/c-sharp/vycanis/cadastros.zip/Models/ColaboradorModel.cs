namespace cadastros.Models
{
	public class ColaboradorModel
	{	
		public int? Id { get; set; } 

		public string? Matricula { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.DateTime> DataAdmissao { get; set; } 

		public System.Nullable<System.DateTime> DataDemissao { get; set; } 

		public string? CtpsNumero { get; set; } 

		public string? CtpsSerie { get; set; } 

		public System.Nullable<System.DateTime> CtpsDataExpedicao { get; set; } 

		public string? CtpsUf { get; set; } 

		public string? Observacao { get; set; } 

		private VendedorModel? vendedorModel; 
		public VendedorModel? VendedorModel 
		{ 
			get 
			{ 
				return vendedorModel; 
			} 
			set 
			{ 
				vendedorModel = value; 
				if (value != null) 
				{ 
					vendedorModel!.ColaboradorModel = this; 
				} 
			} 
		} 

		public PessoaModel? PessoaModel { get; set; } 

		public ColaboradorSituacaoModel? ColaboradorSituacaoModel { get; set; } 

		public ColaboradorTipoModel? ColaboradorTipoModel { get; set; } 

		public SetorModel? SetorModel { get; set; } 

		public CargoModel? CargoModel { get; set; } 

		public TipoAdmissaoModel? TipoAdmissaoModel { get; set; } 

		public SindicatoModel? SindicatoModel { get; set; } 

		private IList<ColaboradorRelacionamentoModel>? colaboradorRelacionamentoModelList; 
		public IList<ColaboradorRelacionamentoModel>? ColaboradorRelacionamentoModelList 
		{ 
			get 
			{ 
				return colaboradorRelacionamentoModelList; 
			} 
			set 
			{ 
				colaboradorRelacionamentoModelList = value; 
				foreach (ColaboradorRelacionamentoModel colaboradorRelacionamentoModel in colaboradorRelacionamentoModelList!) 
				{ 
					colaboradorRelacionamentoModel.ColaboradorModel = this; 
				} 
			} 
		} 

	}
}
