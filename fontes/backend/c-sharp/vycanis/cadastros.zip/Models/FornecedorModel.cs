namespace cadastros.Models
{
	public class FornecedorModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> Desde { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public string? Observacao { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
