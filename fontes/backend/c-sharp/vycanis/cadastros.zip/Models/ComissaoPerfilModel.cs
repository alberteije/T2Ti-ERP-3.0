namespace cadastros.Models
{
	public class ComissaoPerfilModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

	}
}
