namespace comissoes.Models
{
	public class ComissaoObjetivoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.Decimal> TaxaPagamento { get; set; } 

		public System.Nullable<System.Decimal> ValorPagamento { get; set; } 

		public System.Nullable<System.Decimal> ValorMeta { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public ComissaoPerfilModel? ComissaoPerfilModel { get; set; } 

	}
}
