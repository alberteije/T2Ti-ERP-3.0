using comissoes.Models;
using comissoes.NHibernate;
using ISession = NHibernate.ISession;

namespace comissoes.Services
{
    public class ComissaoPerfilService
    {

        public IEnumerable<ComissaoPerfilModel> GetList()
        {
            IList<ComissaoPerfilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoPerfilModel> DAL = new NHibernateDAL<ComissaoPerfilModel>(Session);
                Result = DAL.Select(new ComissaoPerfilModel());
            }
            return Result;
        }

        public IEnumerable<ComissaoPerfilModel> GetListFilter(Filter filterObj)
        {
            IList<ComissaoPerfilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ComissaoPerfilModel where " + filterObj.Where;
                NHibernateDAL<ComissaoPerfilModel> DAL = new NHibernateDAL<ComissaoPerfilModel>(Session);
                Result = DAL.SelectListSql<ComissaoPerfilModel>(Query);
            }
            return Result;
        }
		
        public ComissaoPerfilModel GetObject(int id)
        {
            ComissaoPerfilModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoPerfilModel> DAL = new NHibernateDAL<ComissaoPerfilModel>(Session);
                Result = DAL.SelectId<ComissaoPerfilModel>(id);
            }
            return Result;
        }
		
        public void Insert(ComissaoPerfilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoPerfilModel> DAL = new NHibernateDAL<ComissaoPerfilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ComissaoPerfilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoPerfilModel> DAL = new NHibernateDAL<ComissaoPerfilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ComissaoPerfilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoPerfilModel> DAL = new NHibernateDAL<ComissaoPerfilModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}