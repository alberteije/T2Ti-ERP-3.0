using Microsoft.AspNetCore.Mvc;
using comissoes.Models;
using comissoes.Services;

namespace comissoes.Controllers
{
    [Route("comissao-perfil")]
    [Produces("application/json")]
    public class ComissaoPerfilController : Controller
    {
		private readonly ComissaoPerfilService _service;

        public ComissaoPerfilController()
        {
            _service = new ComissaoPerfilService();
        }

        [HttpGet]
        public IActionResult GetListComissaoPerfil([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ComissaoPerfilModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ComissaoPerfil]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectComissaoPerfil")]
        public IActionResult GetObjectComissaoPerfil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ComissaoPerfil]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ComissaoPerfil]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertComissaoPerfil([FromBody]ComissaoPerfilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ComissaoPerfil]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectComissaoPerfil", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ComissaoPerfil]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateComissaoPerfil([FromBody]ComissaoPerfilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ComissaoPerfil]", null));
                }

                _service.Update(objJson);

                return GetObjectComissaoPerfil(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ComissaoPerfil]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteComissaoPerfil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ComissaoPerfil]", ex));
            }
        }

    }
}