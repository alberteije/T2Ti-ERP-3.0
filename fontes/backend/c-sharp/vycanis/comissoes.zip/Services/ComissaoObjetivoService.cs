using comissoes.Models;
using comissoes.NHibernate;
using ISession = NHibernate.ISession;

namespace comissoes.Services
{
    public class ComissaoObjetivoService
    {

        public IEnumerable<ComissaoObjetivoModel> GetList()
        {
            IList<ComissaoObjetivoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoObjetivoModel> DAL = new NHibernateDAL<ComissaoObjetivoModel>(Session);
                Result = DAL.Select(new ComissaoObjetivoModel());
            }
            return Result;
        }

        public IEnumerable<ComissaoObjetivoModel> GetListFilter(Filter filterObj)
        {
            IList<ComissaoObjetivoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ComissaoObjetivoModel where " + filterObj.Where;
                NHibernateDAL<ComissaoObjetivoModel> DAL = new NHibernateDAL<ComissaoObjetivoModel>(Session);
                Result = DAL.SelectListSql<ComissaoObjetivoModel>(Query);
            }
            return Result;
        }
		
        public ComissaoObjetivoModel GetObject(int id)
        {
            ComissaoObjetivoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoObjetivoModel> DAL = new NHibernateDAL<ComissaoObjetivoModel>(Session);
                Result = DAL.SelectId<ComissaoObjetivoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ComissaoObjetivoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoObjetivoModel> DAL = new NHibernateDAL<ComissaoObjetivoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ComissaoObjetivoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoObjetivoModel> DAL = new NHibernateDAL<ComissaoObjetivoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ComissaoObjetivoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ComissaoObjetivoModel> DAL = new NHibernateDAL<ComissaoObjetivoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}