using Microsoft.AspNetCore.Mvc;
using vendas.Models;
using vendas.Services;

namespace vendas.Controllers
{
    [Route("venda-orcamento-cabecalho")]
    [Produces("application/json")]
    public class VendaOrcamentoCabecalhoController : Controller
    {
		private readonly VendaOrcamentoCabecalhoService _service;

        public VendaOrcamentoCabecalhoController()
        {
            _service = new VendaOrcamentoCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListVendaOrcamentoCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<VendaOrcamentoCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList VendaOrcamentoCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectVendaOrcamentoCabecalho")]
        public IActionResult GetObjectVendaOrcamentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject VendaOrcamentoCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject VendaOrcamentoCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertVendaOrcamentoCabecalho([FromBody]VendaOrcamentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert VendaOrcamentoCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectVendaOrcamentoCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert VendaOrcamentoCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateVendaOrcamentoCabecalho([FromBody]VendaOrcamentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update VendaOrcamentoCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectVendaOrcamentoCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update VendaOrcamentoCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteVendaOrcamentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete VendaOrcamentoCabecalho]", ex));
            }
        }

    }
}