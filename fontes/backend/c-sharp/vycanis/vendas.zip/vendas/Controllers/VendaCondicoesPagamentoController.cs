using Microsoft.AspNetCore.Mvc;
using vendas.Models;
using vendas.Services;

namespace vendas.Controllers
{
    [Route("venda-condicoes-pagamento")]
    [Produces("application/json")]
    public class VendaCondicoesPagamentoController : Controller
    {
		private readonly VendaCondicoesPagamentoService _service;

        public VendaCondicoesPagamentoController()
        {
            _service = new VendaCondicoesPagamentoService();
        }

        [HttpGet]
        public IActionResult GetListVendaCondicoesPagamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<VendaCondicoesPagamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList VendaCondicoesPagamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectVendaCondicoesPagamento")]
        public IActionResult GetObjectVendaCondicoesPagamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject VendaCondicoesPagamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject VendaCondicoesPagamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertVendaCondicoesPagamento([FromBody]VendaCondicoesPagamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert VendaCondicoesPagamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectVendaCondicoesPagamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert VendaCondicoesPagamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateVendaCondicoesPagamento([FromBody]VendaCondicoesPagamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update VendaCondicoesPagamento]", null));
                }

                _service.Update(objJson);

                return GetObjectVendaCondicoesPagamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update VendaCondicoesPagamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteVendaCondicoesPagamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete VendaCondicoesPagamento]", ex));
            }
        }

    }
}