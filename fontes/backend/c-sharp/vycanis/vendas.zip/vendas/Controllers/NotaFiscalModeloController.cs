using Microsoft.AspNetCore.Mvc;
using vendas.Models;
using vendas.Services;

namespace vendas.Controllers
{
    [Route("nota-fiscal-modelo")]
    [Produces("application/json")]
    public class NotaFiscalModeloController : Controller
    {
		private readonly NotaFiscalModeloService _service;

        public NotaFiscalModeloController()
        {
            _service = new NotaFiscalModeloService();
        }

        [HttpGet]
        public IActionResult GetListNotaFiscalModelo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NotaFiscalModeloModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NotaFiscalModelo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNotaFiscalModelo")]
        public IActionResult GetObjectNotaFiscalModelo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NotaFiscalModelo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NotaFiscalModelo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNotaFiscalModelo([FromBody]NotaFiscalModeloModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NotaFiscalModelo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNotaFiscalModelo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NotaFiscalModelo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNotaFiscalModelo([FromBody]NotaFiscalModeloModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NotaFiscalModelo]", null));
                }

                _service.Update(objJson);

                return GetObjectNotaFiscalModelo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NotaFiscalModelo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNotaFiscalModelo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NotaFiscalModelo]", ex));
            }
        }

    }
}