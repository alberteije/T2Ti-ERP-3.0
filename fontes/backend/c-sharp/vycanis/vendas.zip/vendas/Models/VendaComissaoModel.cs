namespace vendas.Models
{
	public class VendaComissaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorVenda { get; set; } 

		public string? TipoContabil { get; set; } 

		public System.Nullable<System.Decimal> ValorComissao { get; set; } 

		public string? Situacao { get; set; } 

		public System.Nullable<System.DateTime> DataLancamento { get; set; } 

		public VendaCabecalhoModel? VendaCabecalhoModel { get; set; } 

		public ViewPessoaVendedorModel? ViewPessoaVendedorModel { get; set; } 

	}
}
