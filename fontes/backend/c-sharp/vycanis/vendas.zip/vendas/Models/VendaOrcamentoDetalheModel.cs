namespace vendas.Models
{
	public class VendaOrcamentoDetalheModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public System.Nullable<System.Decimal> ValorUnitario { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public VendaOrcamentoCabecalhoModel? VendaOrcamentoCabecalhoModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
