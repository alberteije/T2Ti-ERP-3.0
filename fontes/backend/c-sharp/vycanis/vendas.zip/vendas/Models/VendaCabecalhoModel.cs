namespace vendas.Models
{
	public class VendaCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? LocalEntrega { get; set; } 

		public string? LocalCobranca { get; set; } 

		public string? TipoFrete { get; set; } 

		public string? FormaPagamento { get; set; } 

		public System.Nullable<System.DateTime> DataVenda { get; set; } 

		public System.Nullable<System.DateTime> DataSaida { get; set; } 

		public string? HoraSaida { get; set; } 

		public int? NumeroFatura { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public System.Nullable<System.Decimal> ValorSeguro { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> TaxaComissao { get; set; } 

		public System.Nullable<System.Decimal> ValorComissao { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public string? Situacao { get; set; } 

		public string? DiaFixoParcela { get; set; } 

		public string? Observacao { get; set; } 

		private VendaComissaoModel? vendaComissaoModel; 
		public VendaComissaoModel? VendaComissaoModel 
		{ 
			get 
			{ 
				return vendaComissaoModel; 
			} 
			set 
			{ 
				vendaComissaoModel = value; 
				if (value != null) 
				{ 
					vendaComissaoModel!.VendaCabecalhoModel = this; 
				} 
			} 
		} 

		public VendaCondicoesPagamentoModel? VendaCondicoesPagamentoModel { get; set; } 

		public ViewPessoaVendedorModel? ViewPessoaVendedorModel { get; set; } 

		public ViewPessoaTransportadoraModel? ViewPessoaTransportadoraModel { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public VendaOrcamentoCabecalhoModel? VendaOrcamentoCabecalhoModel { get; set; } 

		public NotaFiscalTipoModel? NotaFiscalTipoModel { get; set; } 

		private IList<VendaDetalheModel>? vendaDetalheModelList; 
		public IList<VendaDetalheModel>? VendaDetalheModelList 
		{ 
			get 
			{ 
				return vendaDetalheModelList; 
			} 
			set 
			{ 
				vendaDetalheModelList = value; 
				foreach (VendaDetalheModel vendaDetalheModel in vendaDetalheModelList!) 
				{ 
					vendaDetalheModel.VendaCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<VendaFreteModel>? vendaFreteModelList; 
		public IList<VendaFreteModel>? VendaFreteModelList 
		{ 
			get 
			{ 
				return vendaFreteModelList; 
			} 
			set 
			{ 
				vendaFreteModelList = value; 
				foreach (VendaFreteModel vendaFreteModel in vendaFreteModelList!) 
				{ 
					vendaFreteModel.VendaCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
