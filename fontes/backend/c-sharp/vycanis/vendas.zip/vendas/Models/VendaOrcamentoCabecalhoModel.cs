namespace vendas.Models
{
	public class VendaOrcamentoCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? TipoFrete { get; set; } 

		public string? Codigo { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.DateTime> DataEntrega { get; set; } 

		public System.Nullable<System.DateTime> DataValidade { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public System.Nullable<System.Decimal> TaxaComissao { get; set; } 

		public System.Nullable<System.Decimal> ValorComissao { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public string? Observacao { get; set; } 

		public VendaCondicoesPagamentoModel? VendaCondicoesPagamentoModel { get; set; } 

		public ViewPessoaVendedorModel? ViewPessoaVendedorModel { get; set; } 

		public ViewPessoaTransportadoraModel? ViewPessoaTransportadoraModel { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		private IList<VendaOrcamentoDetalheModel>? vendaOrcamentoDetalheModelList; 
		public IList<VendaOrcamentoDetalheModel>? VendaOrcamentoDetalheModelList 
		{ 
			get 
			{ 
				return vendaOrcamentoDetalheModelList; 
			} 
			set 
			{ 
				vendaOrcamentoDetalheModelList = value; 
				foreach (VendaOrcamentoDetalheModel vendaOrcamentoDetalheModel in vendaOrcamentoDetalheModelList!) 
				{ 
					vendaOrcamentoDetalheModel.VendaOrcamentoCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
