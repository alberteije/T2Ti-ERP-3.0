namespace vendas.Models
{
	public class VendaFreteModel
	{	
		public int? Id { get; set; } 

		public string? Responsavel { get; set; } 

		public int? Conhecimento { get; set; } 

		public string? Placa { get; set; } 

		public string? UfPlaca { get; set; } 

		public int? SeloFiscal { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeVolume { get; set; } 

		public string? MarcaVolume { get; set; } 

		public string? EspecieVolume { get; set; } 

		public System.Nullable<System.Decimal> PesoBruto { get; set; } 

		public System.Nullable<System.Decimal> PesoLiquido { get; set; } 

		public VendaCabecalhoModel? VendaCabecalhoModel { get; set; } 

		public ViewPessoaTransportadoraModel? ViewPessoaTransportadoraModel { get; set; } 

	}
}
