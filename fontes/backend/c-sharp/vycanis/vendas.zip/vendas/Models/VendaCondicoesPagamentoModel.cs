namespace vendas.Models
{
	public class VendaCondicoesPagamentoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.Decimal> FaturamentoMinimo { get; set; } 

		public System.Nullable<System.Decimal> FaturamentoMaximo { get; set; } 

		public System.Nullable<System.Decimal> IndiceCorrecao { get; set; } 

		public int? DiasTolerancia { get; set; } 

		public System.Nullable<System.Decimal> ValorTolerancia { get; set; } 

		public int? PrazoMedio { get; set; } 

		public string? VistaPrazo { get; set; } 

		private IList<VendaCondicoesParcelasModel>? vendaCondicoesParcelasModelList; 
		public IList<VendaCondicoesParcelasModel>? VendaCondicoesParcelasModelList 
		{ 
			get 
			{ 
				return vendaCondicoesParcelasModelList; 
			} 
			set 
			{ 
				vendaCondicoesParcelasModelList = value; 
				foreach (VendaCondicoesParcelasModel vendaCondicoesParcelasModel in vendaCondicoesParcelasModelList!) 
				{ 
					vendaCondicoesParcelasModel.VendaCondicoesPagamentoModel = this; 
				} 
			} 
		} 

	}
}
