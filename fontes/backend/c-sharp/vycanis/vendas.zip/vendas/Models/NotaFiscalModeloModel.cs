namespace vendas.Models
{
	public class NotaFiscalModeloModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Modelo { get; set; } 

	}
}
