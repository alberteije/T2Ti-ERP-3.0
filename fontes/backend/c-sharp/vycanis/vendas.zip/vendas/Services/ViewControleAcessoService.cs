using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class ViewControleAcessoService
    {

        public IEnumerable<ViewControleAcessoModel> GetList()
        {
            IList<ViewControleAcessoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewControleAcessoModel> DAL = new NHibernateDAL<ViewControleAcessoModel>(Session);
                Result = DAL.Select(new ViewControleAcessoModel());
            }
            return Result;
        }

        public IEnumerable<ViewControleAcessoModel> GetListFilter(Filter filterObj)
        {
            IList<ViewControleAcessoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewControleAcessoModel where " + filterObj.Where;
                NHibernateDAL<ViewControleAcessoModel> DAL = new NHibernateDAL<ViewControleAcessoModel>(Session);
                Result = DAL.SelectListSql<ViewControleAcessoModel>(Query);
            }
            return Result;
        }
		
        public ViewControleAcessoModel GetObject(int id)
        {
            ViewControleAcessoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewControleAcessoModel> DAL = new NHibernateDAL<ViewControleAcessoModel>(Session);
                Result = DAL.SelectId<ViewControleAcessoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewControleAcessoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewControleAcessoModel> DAL = new NHibernateDAL<ViewControleAcessoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewControleAcessoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewControleAcessoModel> DAL = new NHibernateDAL<ViewControleAcessoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewControleAcessoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewControleAcessoModel> DAL = new NHibernateDAL<ViewControleAcessoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}