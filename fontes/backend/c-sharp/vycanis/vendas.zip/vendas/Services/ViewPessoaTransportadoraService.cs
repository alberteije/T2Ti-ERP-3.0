using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class ViewPessoaTransportadoraService
    {

        public IEnumerable<ViewPessoaTransportadoraModel> GetList()
        {
            IList<ViewPessoaTransportadoraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaTransportadoraModel> DAL = new NHibernateDAL<ViewPessoaTransportadoraModel>(Session);
                Result = DAL.Select(new ViewPessoaTransportadoraModel());
            }
            return Result;
        }

        public IEnumerable<ViewPessoaTransportadoraModel> GetListFilter(Filter filterObj)
        {
            IList<ViewPessoaTransportadoraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewPessoaTransportadoraModel where " + filterObj.Where;
                NHibernateDAL<ViewPessoaTransportadoraModel> DAL = new NHibernateDAL<ViewPessoaTransportadoraModel>(Session);
                Result = DAL.SelectListSql<ViewPessoaTransportadoraModel>(Query);
            }
            return Result;
        }
		
        public ViewPessoaTransportadoraModel GetObject(int id)
        {
            ViewPessoaTransportadoraModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaTransportadoraModel> DAL = new NHibernateDAL<ViewPessoaTransportadoraModel>(Session);
                Result = DAL.SelectId<ViewPessoaTransportadoraModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewPessoaTransportadoraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaTransportadoraModel> DAL = new NHibernateDAL<ViewPessoaTransportadoraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewPessoaTransportadoraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaTransportadoraModel> DAL = new NHibernateDAL<ViewPessoaTransportadoraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewPessoaTransportadoraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaTransportadoraModel> DAL = new NHibernateDAL<ViewPessoaTransportadoraModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}