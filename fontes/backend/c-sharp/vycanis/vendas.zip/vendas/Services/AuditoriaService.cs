using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class AuditoriaService
    {

        public IEnumerable<AuditoriaModel> GetList()
        {
            IList<AuditoriaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                Result = DAL.Select(new AuditoriaModel());
            }
            return Result;
        }

        public IEnumerable<AuditoriaModel> GetListFilter(Filter filterObj)
        {
            IList<AuditoriaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from AuditoriaModel where " + filterObj.Where;
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                Result = DAL.SelectListSql<AuditoriaModel>(Query);
            }
            return Result;
        }
		
        public AuditoriaModel GetObject(int id)
        {
            AuditoriaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                Result = DAL.SelectId<AuditoriaModel>(id);
            }
            return Result;
        }
		
        public void Insert(AuditoriaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(AuditoriaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(AuditoriaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}