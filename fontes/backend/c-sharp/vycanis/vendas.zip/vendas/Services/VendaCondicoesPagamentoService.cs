using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class VendaCondicoesPagamentoService
    {

        public IEnumerable<VendaCondicoesPagamentoModel> GetList()
        {
            IList<VendaCondicoesPagamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCondicoesPagamentoModel> DAL = new NHibernateDAL<VendaCondicoesPagamentoModel>(Session);
                Result = DAL.Select(new VendaCondicoesPagamentoModel());
            }
            return Result;
        }

        public IEnumerable<VendaCondicoesPagamentoModel> GetListFilter(Filter filterObj)
        {
            IList<VendaCondicoesPagamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from VendaCondicoesPagamentoModel where " + filterObj.Where;
                NHibernateDAL<VendaCondicoesPagamentoModel> DAL = new NHibernateDAL<VendaCondicoesPagamentoModel>(Session);
                Result = DAL.SelectListSql<VendaCondicoesPagamentoModel>(Query);
            }
            return Result;
        }
		
        public VendaCondicoesPagamentoModel GetObject(int id)
        {
            VendaCondicoesPagamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCondicoesPagamentoModel> DAL = new NHibernateDAL<VendaCondicoesPagamentoModel>(Session);
                Result = DAL.SelectId<VendaCondicoesPagamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(VendaCondicoesPagamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCondicoesPagamentoModel> DAL = new NHibernateDAL<VendaCondicoesPagamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(VendaCondicoesPagamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCondicoesPagamentoModel> DAL = new NHibernateDAL<VendaCondicoesPagamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(VendaCondicoesPagamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCondicoesPagamentoModel> DAL = new NHibernateDAL<VendaCondicoesPagamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}