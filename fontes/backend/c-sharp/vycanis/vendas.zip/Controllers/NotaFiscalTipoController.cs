using Microsoft.AspNetCore.Mvc;
using vendas.Models;
using vendas.Services;

namespace vendas.Controllers
{
    [Route("nota-fiscal-tipo")]
    [Produces("application/json")]
    public class NotaFiscalTipoController : Controller
    {
		private readonly NotaFiscalTipoService _service;

        public NotaFiscalTipoController()
        {
            _service = new NotaFiscalTipoService();
        }

        [HttpGet]
        public IActionResult GetListNotaFiscalTipo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NotaFiscalTipoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NotaFiscalTipo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNotaFiscalTipo")]
        public IActionResult GetObjectNotaFiscalTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NotaFiscalTipo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NotaFiscalTipo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNotaFiscalTipo([FromBody]NotaFiscalTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NotaFiscalTipo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNotaFiscalTipo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NotaFiscalTipo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNotaFiscalTipo([FromBody]NotaFiscalTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NotaFiscalTipo]", null));
                }

                _service.Update(objJson);

                return GetObjectNotaFiscalTipo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NotaFiscalTipo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNotaFiscalTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NotaFiscalTipo]", ex));
            }
        }

    }
}