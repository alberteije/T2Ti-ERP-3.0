using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class NotaFiscalTipoService
    {

        public IEnumerable<NotaFiscalTipoModel> GetList()
        {
            IList<NotaFiscalTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalTipoModel> DAL = new NHibernateDAL<NotaFiscalTipoModel>(Session);
                Result = DAL.Select(new NotaFiscalTipoModel());
            }
            return Result;
        }

        public IEnumerable<NotaFiscalTipoModel> GetListFilter(Filter filterObj)
        {
            IList<NotaFiscalTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NotaFiscalTipoModel where " + filterObj.Where;
                NHibernateDAL<NotaFiscalTipoModel> DAL = new NHibernateDAL<NotaFiscalTipoModel>(Session);
                Result = DAL.SelectListSql<NotaFiscalTipoModel>(Query);
            }
            return Result;
        }
		
        public NotaFiscalTipoModel GetObject(int id)
        {
            NotaFiscalTipoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalTipoModel> DAL = new NHibernateDAL<NotaFiscalTipoModel>(Session);
                Result = DAL.SelectId<NotaFiscalTipoModel>(id);
            }
            return Result;
        }
		
        public void Insert(NotaFiscalTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalTipoModel> DAL = new NHibernateDAL<NotaFiscalTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NotaFiscalTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalTipoModel> DAL = new NHibernateDAL<NotaFiscalTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NotaFiscalTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalTipoModel> DAL = new NHibernateDAL<NotaFiscalTipoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}