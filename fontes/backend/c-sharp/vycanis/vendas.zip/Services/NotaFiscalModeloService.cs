using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class NotaFiscalModeloService
    {

        public IEnumerable<NotaFiscalModeloModel> GetList()
        {
            IList<NotaFiscalModeloModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalModeloModel> DAL = new NHibernateDAL<NotaFiscalModeloModel>(Session);
                Result = DAL.Select(new NotaFiscalModeloModel());
            }
            return Result;
        }

        public IEnumerable<NotaFiscalModeloModel> GetListFilter(Filter filterObj)
        {
            IList<NotaFiscalModeloModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NotaFiscalModeloModel where " + filterObj.Where;
                NHibernateDAL<NotaFiscalModeloModel> DAL = new NHibernateDAL<NotaFiscalModeloModel>(Session);
                Result = DAL.SelectListSql<NotaFiscalModeloModel>(Query);
            }
            return Result;
        }
		
        public NotaFiscalModeloModel GetObject(int id)
        {
            NotaFiscalModeloModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalModeloModel> DAL = new NHibernateDAL<NotaFiscalModeloModel>(Session);
                Result = DAL.SelectId<NotaFiscalModeloModel>(id);
            }
            return Result;
        }
		
        public void Insert(NotaFiscalModeloModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalModeloModel> DAL = new NHibernateDAL<NotaFiscalModeloModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NotaFiscalModeloModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalModeloModel> DAL = new NHibernateDAL<NotaFiscalModeloModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NotaFiscalModeloModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NotaFiscalModeloModel> DAL = new NHibernateDAL<NotaFiscalModeloModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}