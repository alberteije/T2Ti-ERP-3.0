using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class ViewPessoaVendedorService
    {

        public IEnumerable<ViewPessoaVendedorModel> GetList()
        {
            IList<ViewPessoaVendedorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaVendedorModel> DAL = new NHibernateDAL<ViewPessoaVendedorModel>(Session);
                Result = DAL.Select(new ViewPessoaVendedorModel());
            }
            return Result;
        }

        public IEnumerable<ViewPessoaVendedorModel> GetListFilter(Filter filterObj)
        {
            IList<ViewPessoaVendedorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewPessoaVendedorModel where " + filterObj.Where;
                NHibernateDAL<ViewPessoaVendedorModel> DAL = new NHibernateDAL<ViewPessoaVendedorModel>(Session);
                Result = DAL.SelectListSql<ViewPessoaVendedorModel>(Query);
            }
            return Result;
        }
		
        public ViewPessoaVendedorModel GetObject(int id)
        {
            ViewPessoaVendedorModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaVendedorModel> DAL = new NHibernateDAL<ViewPessoaVendedorModel>(Session);
                Result = DAL.SelectId<ViewPessoaVendedorModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewPessoaVendedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaVendedorModel> DAL = new NHibernateDAL<ViewPessoaVendedorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewPessoaVendedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaVendedorModel> DAL = new NHibernateDAL<ViewPessoaVendedorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewPessoaVendedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaVendedorModel> DAL = new NHibernateDAL<ViewPessoaVendedorModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}