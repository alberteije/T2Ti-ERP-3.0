using vendas.Models;
using vendas.NHibernate;
using ISession = NHibernate.ISession;

namespace vendas.Services
{
    public class VendaOrcamentoCabecalhoService
    {

        public IEnumerable<VendaOrcamentoCabecalhoModel> GetList()
        {
            IList<VendaOrcamentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaOrcamentoCabecalhoModel> DAL = new NHibernateDAL<VendaOrcamentoCabecalhoModel>(Session);
                Result = DAL.Select(new VendaOrcamentoCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<VendaOrcamentoCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<VendaOrcamentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from VendaOrcamentoCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<VendaOrcamentoCabecalhoModel> DAL = new NHibernateDAL<VendaOrcamentoCabecalhoModel>(Session);
                Result = DAL.SelectListSql<VendaOrcamentoCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public VendaOrcamentoCabecalhoModel GetObject(int id)
        {
            VendaOrcamentoCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaOrcamentoCabecalhoModel> DAL = new NHibernateDAL<VendaOrcamentoCabecalhoModel>(Session);
                Result = DAL.SelectId<VendaOrcamentoCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(VendaOrcamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaOrcamentoCabecalhoModel> DAL = new NHibernateDAL<VendaOrcamentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(VendaOrcamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaOrcamentoCabecalhoModel> DAL = new NHibernateDAL<VendaOrcamentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(VendaOrcamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaOrcamentoCabecalhoModel> DAL = new NHibernateDAL<VendaOrcamentoCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}