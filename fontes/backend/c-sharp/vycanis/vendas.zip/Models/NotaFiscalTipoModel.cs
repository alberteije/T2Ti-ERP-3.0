namespace vendas.Models
{
	public class NotaFiscalTipoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public string? Serie { get; set; } 

		public string? SerieScan { get; set; } 

		public int? UltimoNumero { get; set; } 

		public NotaFiscalModeloModel? NotaFiscalModeloModel { get; set; } 

	}
}
