namespace vendas.Models
{
	public class VendaCondicoesParcelasModel
	{	
		public int? Id { get; set; } 

		public int? Parcela { get; set; } 

		public int? Dias { get; set; } 

		public System.Nullable<System.Decimal> Taxa { get; set; } 

		public VendaCondicoesPagamentoModel? VendaCondicoesPagamentoModel { get; set; } 

	}
}
