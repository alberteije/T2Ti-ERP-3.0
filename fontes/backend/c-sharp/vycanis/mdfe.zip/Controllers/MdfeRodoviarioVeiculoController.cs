using Microsoft.AspNetCore.Mvc;
using mdfe.Models;
using mdfe.Services;

namespace mdfe.Controllers
{
    [Route("mdfe-rodoviario-veiculo")]
    [Produces("application/json")]
    public class MdfeRodoviarioVeiculoController : Controller
    {
		private readonly MdfeRodoviarioVeiculoService _service;

        public MdfeRodoviarioVeiculoController()
        {
            _service = new MdfeRodoviarioVeiculoService();
        }

        [HttpGet]
        public IActionResult GetListMdfeRodoviarioVeiculo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MdfeRodoviarioVeiculoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList MdfeRodoviarioVeiculo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMdfeRodoviarioVeiculo")]
        public IActionResult GetObjectMdfeRodoviarioVeiculo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject MdfeRodoviarioVeiculo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject MdfeRodoviarioVeiculo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMdfeRodoviarioVeiculo([FromBody]MdfeRodoviarioVeiculoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert MdfeRodoviarioVeiculo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMdfeRodoviarioVeiculo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert MdfeRodoviarioVeiculo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMdfeRodoviarioVeiculo([FromBody]MdfeRodoviarioVeiculoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update MdfeRodoviarioVeiculo]", null));
                }

                _service.Update(objJson);

                return GetObjectMdfeRodoviarioVeiculo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update MdfeRodoviarioVeiculo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMdfeRodoviarioVeiculo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete MdfeRodoviarioVeiculo]", ex));
            }
        }

    }
}