using Microsoft.AspNetCore.Mvc;
using mdfe.Models;
using mdfe.Services;

namespace mdfe.Controllers
{
    [Route("mdfe-cabecalho")]
    [Produces("application/json")]
    public class MdfeCabecalhoController : Controller
    {
		private readonly MdfeCabecalhoService _service;

        public MdfeCabecalhoController()
        {
            _service = new MdfeCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListMdfeCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MdfeCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList MdfeCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMdfeCabecalho")]
        public IActionResult GetObjectMdfeCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject MdfeCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject MdfeCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMdfeCabecalho([FromBody]MdfeCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert MdfeCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMdfeCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert MdfeCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMdfeCabecalho([FromBody]MdfeCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update MdfeCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectMdfeCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update MdfeCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMdfeCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete MdfeCabecalho]", ex));
            }
        }

    }
}