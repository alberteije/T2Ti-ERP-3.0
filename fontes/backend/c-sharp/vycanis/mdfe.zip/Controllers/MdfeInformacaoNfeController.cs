using Microsoft.AspNetCore.Mvc;
using mdfe.Models;
using mdfe.Services;

namespace mdfe.Controllers
{
    [Route("mdfe-informacao-nfe")]
    [Produces("application/json")]
    public class MdfeInformacaoNfeController : Controller
    {
		private readonly MdfeInformacaoNfeService _service;

        public MdfeInformacaoNfeController()
        {
            _service = new MdfeInformacaoNfeService();
        }

        [HttpGet]
        public IActionResult GetListMdfeInformacaoNfe([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MdfeInformacaoNfeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList MdfeInformacaoNfe]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMdfeInformacaoNfe")]
        public IActionResult GetObjectMdfeInformacaoNfe(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject MdfeInformacaoNfe]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject MdfeInformacaoNfe]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMdfeInformacaoNfe([FromBody]MdfeInformacaoNfeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert MdfeInformacaoNfe]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMdfeInformacaoNfe", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert MdfeInformacaoNfe]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMdfeInformacaoNfe([FromBody]MdfeInformacaoNfeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update MdfeInformacaoNfe]", null));
                }

                _service.Update(objJson);

                return GetObjectMdfeInformacaoNfe(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update MdfeInformacaoNfe]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMdfeInformacaoNfe(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete MdfeInformacaoNfe]", ex));
            }
        }

    }
}