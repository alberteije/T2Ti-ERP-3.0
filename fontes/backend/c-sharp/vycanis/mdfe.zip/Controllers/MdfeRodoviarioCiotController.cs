using Microsoft.AspNetCore.Mvc;
using mdfe.Models;
using mdfe.Services;

namespace mdfe.Controllers
{
    [Route("mdfe-rodoviario-ciot")]
    [Produces("application/json")]
    public class MdfeRodoviarioCiotController : Controller
    {
		private readonly MdfeRodoviarioCiotService _service;

        public MdfeRodoviarioCiotController()
        {
            _service = new MdfeRodoviarioCiotService();
        }

        [HttpGet]
        public IActionResult GetListMdfeRodoviarioCiot([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MdfeRodoviarioCiotModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList MdfeRodoviarioCiot]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMdfeRodoviarioCiot")]
        public IActionResult GetObjectMdfeRodoviarioCiot(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject MdfeRodoviarioCiot]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject MdfeRodoviarioCiot]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMdfeRodoviarioCiot([FromBody]MdfeRodoviarioCiotModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert MdfeRodoviarioCiot]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMdfeRodoviarioCiot", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert MdfeRodoviarioCiot]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMdfeRodoviarioCiot([FromBody]MdfeRodoviarioCiotModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update MdfeRodoviarioCiot]", null));
                }

                _service.Update(objJson);

                return GetObjectMdfeRodoviarioCiot(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update MdfeRodoviarioCiot]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMdfeRodoviarioCiot(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete MdfeRodoviarioCiot]", ex));
            }
        }

    }
}