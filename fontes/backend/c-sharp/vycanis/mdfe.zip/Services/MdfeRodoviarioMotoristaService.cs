using mdfe.Models;
using mdfe.NHibernate;
using ISession = NHibernate.ISession;

namespace mdfe.Services
{
    public class MdfeRodoviarioMotoristaService
    {

        public IEnumerable<MdfeRodoviarioMotoristaModel> GetList()
        {
            IList<MdfeRodoviarioMotoristaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioMotoristaModel> DAL = new NHibernateDAL<MdfeRodoviarioMotoristaModel>(Session);
                Result = DAL.Select(new MdfeRodoviarioMotoristaModel());
            }
            return Result;
        }

        public IEnumerable<MdfeRodoviarioMotoristaModel> GetListFilter(Filter filterObj)
        {
            IList<MdfeRodoviarioMotoristaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MdfeRodoviarioMotoristaModel where " + filterObj.Where;
                NHibernateDAL<MdfeRodoviarioMotoristaModel> DAL = new NHibernateDAL<MdfeRodoviarioMotoristaModel>(Session);
                Result = DAL.SelectListSql<MdfeRodoviarioMotoristaModel>(Query);
            }
            return Result;
        }
		
        public MdfeRodoviarioMotoristaModel GetObject(int id)
        {
            MdfeRodoviarioMotoristaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioMotoristaModel> DAL = new NHibernateDAL<MdfeRodoviarioMotoristaModel>(Session);
                Result = DAL.SelectId<MdfeRodoviarioMotoristaModel>(id);
            }
            return Result;
        }
		
        public void Insert(MdfeRodoviarioMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioMotoristaModel> DAL = new NHibernateDAL<MdfeRodoviarioMotoristaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MdfeRodoviarioMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioMotoristaModel> DAL = new NHibernateDAL<MdfeRodoviarioMotoristaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MdfeRodoviarioMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioMotoristaModel> DAL = new NHibernateDAL<MdfeRodoviarioMotoristaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}