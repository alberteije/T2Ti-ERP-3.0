using mdfe.Models;
using mdfe.NHibernate;
using ISession = NHibernate.ISession;

namespace mdfe.Services
{
    public class MdfeRodoviarioPedagioService
    {

        public IEnumerable<MdfeRodoviarioPedagioModel> GetList()
        {
            IList<MdfeRodoviarioPedagioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioPedagioModel> DAL = new NHibernateDAL<MdfeRodoviarioPedagioModel>(Session);
                Result = DAL.Select(new MdfeRodoviarioPedagioModel());
            }
            return Result;
        }

        public IEnumerable<MdfeRodoviarioPedagioModel> GetListFilter(Filter filterObj)
        {
            IList<MdfeRodoviarioPedagioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MdfeRodoviarioPedagioModel where " + filterObj.Where;
                NHibernateDAL<MdfeRodoviarioPedagioModel> DAL = new NHibernateDAL<MdfeRodoviarioPedagioModel>(Session);
                Result = DAL.SelectListSql<MdfeRodoviarioPedagioModel>(Query);
            }
            return Result;
        }
		
        public MdfeRodoviarioPedagioModel GetObject(int id)
        {
            MdfeRodoviarioPedagioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioPedagioModel> DAL = new NHibernateDAL<MdfeRodoviarioPedagioModel>(Session);
                Result = DAL.SelectId<MdfeRodoviarioPedagioModel>(id);
            }
            return Result;
        }
		
        public void Insert(MdfeRodoviarioPedagioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioPedagioModel> DAL = new NHibernateDAL<MdfeRodoviarioPedagioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MdfeRodoviarioPedagioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioPedagioModel> DAL = new NHibernateDAL<MdfeRodoviarioPedagioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MdfeRodoviarioPedagioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioPedagioModel> DAL = new NHibernateDAL<MdfeRodoviarioPedagioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}