using mdfe.Models;
using mdfe.NHibernate;
using ISession = NHibernate.ISession;

namespace mdfe.Services
{
    public class MdfeRodoviarioCiotService
    {

        public IEnumerable<MdfeRodoviarioCiotModel> GetList()
        {
            IList<MdfeRodoviarioCiotModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioCiotModel> DAL = new NHibernateDAL<MdfeRodoviarioCiotModel>(Session);
                Result = DAL.Select(new MdfeRodoviarioCiotModel());
            }
            return Result;
        }

        public IEnumerable<MdfeRodoviarioCiotModel> GetListFilter(Filter filterObj)
        {
            IList<MdfeRodoviarioCiotModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MdfeRodoviarioCiotModel where " + filterObj.Where;
                NHibernateDAL<MdfeRodoviarioCiotModel> DAL = new NHibernateDAL<MdfeRodoviarioCiotModel>(Session);
                Result = DAL.SelectListSql<MdfeRodoviarioCiotModel>(Query);
            }
            return Result;
        }
		
        public MdfeRodoviarioCiotModel GetObject(int id)
        {
            MdfeRodoviarioCiotModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioCiotModel> DAL = new NHibernateDAL<MdfeRodoviarioCiotModel>(Session);
                Result = DAL.SelectId<MdfeRodoviarioCiotModel>(id);
            }
            return Result;
        }
		
        public void Insert(MdfeRodoviarioCiotModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioCiotModel> DAL = new NHibernateDAL<MdfeRodoviarioCiotModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MdfeRodoviarioCiotModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioCiotModel> DAL = new NHibernateDAL<MdfeRodoviarioCiotModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MdfeRodoviarioCiotModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioCiotModel> DAL = new NHibernateDAL<MdfeRodoviarioCiotModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}