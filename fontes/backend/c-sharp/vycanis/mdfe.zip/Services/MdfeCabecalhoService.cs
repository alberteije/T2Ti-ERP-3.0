using mdfe.Models;
using mdfe.NHibernate;
using ISession = NHibernate.ISession;

namespace mdfe.Services
{
    public class MdfeCabecalhoService
    {

        public IEnumerable<MdfeCabecalhoModel> GetList()
        {
            IList<MdfeCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeCabecalhoModel> DAL = new NHibernateDAL<MdfeCabecalhoModel>(Session);
                Result = DAL.Select(new MdfeCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<MdfeCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<MdfeCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MdfeCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<MdfeCabecalhoModel> DAL = new NHibernateDAL<MdfeCabecalhoModel>(Session);
                Result = DAL.SelectListSql<MdfeCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public MdfeCabecalhoModel GetObject(int id)
        {
            MdfeCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeCabecalhoModel> DAL = new NHibernateDAL<MdfeCabecalhoModel>(Session);
                Result = DAL.SelectId<MdfeCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(MdfeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeCabecalhoModel> DAL = new NHibernateDAL<MdfeCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MdfeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeCabecalhoModel> DAL = new NHibernateDAL<MdfeCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MdfeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeCabecalhoModel> DAL = new NHibernateDAL<MdfeCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}