using mdfe.Models;
using mdfe.NHibernate;
using ISession = NHibernate.ISession;

namespace mdfe.Services
{
    public class MdfeInformacaoCteService
    {

        public IEnumerable<MdfeInformacaoCteModel> GetList()
        {
            IList<MdfeInformacaoCteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoCteModel> DAL = new NHibernateDAL<MdfeInformacaoCteModel>(Session);
                Result = DAL.Select(new MdfeInformacaoCteModel());
            }
            return Result;
        }

        public IEnumerable<MdfeInformacaoCteModel> GetListFilter(Filter filterObj)
        {
            IList<MdfeInformacaoCteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MdfeInformacaoCteModel where " + filterObj.Where;
                NHibernateDAL<MdfeInformacaoCteModel> DAL = new NHibernateDAL<MdfeInformacaoCteModel>(Session);
                Result = DAL.SelectListSql<MdfeInformacaoCteModel>(Query);
            }
            return Result;
        }
		
        public MdfeInformacaoCteModel GetObject(int id)
        {
            MdfeInformacaoCteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoCteModel> DAL = new NHibernateDAL<MdfeInformacaoCteModel>(Session);
                Result = DAL.SelectId<MdfeInformacaoCteModel>(id);
            }
            return Result;
        }
		
        public void Insert(MdfeInformacaoCteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoCteModel> DAL = new NHibernateDAL<MdfeInformacaoCteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MdfeInformacaoCteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoCteModel> DAL = new NHibernateDAL<MdfeInformacaoCteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MdfeInformacaoCteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoCteModel> DAL = new NHibernateDAL<MdfeInformacaoCteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}