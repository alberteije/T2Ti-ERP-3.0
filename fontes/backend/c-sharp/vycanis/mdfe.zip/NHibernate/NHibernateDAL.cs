﻿using NHibernate;
using NHibernate.Criterion;
using mdfe.Utils;
using ISession = NHibernate.ISession;

namespace mdfe.NHibernate
{
    public class NHibernateDAL<DTO>(ISession Session) : IDAL<DTO>
    {
        protected ISession Session = Session;

        public virtual T Save<T>(T obj)
        {
            try
            {
                Session.Save(obj);
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public virtual T SaveOrUpdate<T>(T obj)
        {
            try
            {
                Session.SaveOrUpdate(obj);
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public virtual T Update<T>(T obj)
        {
            try
            {
                Session.Update(obj);
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public virtual int SqlStatement(String query)
        {
            try
            {
                int Result = -1;
                Result = Session.CreateSQLQuery(query).ExecuteUpdate();
                return Result;
            }
            catch
            {
                throw;
            }
        }

        public virtual int Delete<T>(T obj)
        {
            try
            {
                int Result = -1;
                Session.Delete(obj);
                Result = 0;
                return Result;
            }
            catch
            {
                throw;
            }
        }

        public virtual IList<T> Select<T>(T obj)
        {
            try
            {
                IList<T> Result = new List<T>();
                Example Example = Example.Create(obj).EnableLike(MatchMode.Anywhere).IgnoreCase().ExcludeNulls().ExcludeZeroes();
                //Result = Session.CreateCriteria(typeof(T)).Add(Example).List<T>();
                Result = Session.CreateCriteria(typeof(T)).Add(Example).SetMaxResults(Constants.MAX_ROWS).List<T>();
                return Result;
            }
            catch
            {
                throw;
            }
        }

        public virtual T? SelectObj<T>(T obj)
        {
            try
            {
                IList<T> ResultList = [];
                Example Example = Example.Create(obj).EnableLike(MatchMode.Anywhere).IgnoreCase().ExcludeNulls().ExcludeZeroes();
                ResultList = Session.CreateCriteria(typeof(T)).Add(Example).List<T>();

                T? Result = default;

                if (ResultList.Count > 0)
                {
                    Result = ResultList[0];
                }

                return Result;
            }
            catch
            {
                throw;
            }
        }

        public virtual T SelectId<T>(int id)
        {
            try
            {
                T Result = Session.Get<T>(id);
                return Result;
            }
            catch
            {
                throw;
            }
        }

        public virtual IList<T> SelectPage<T>(int firstResult, int maxResults, T obj)
        {
            try
            {
                IList<T> Result = [];
                Example Example = Example.Create(obj).EnableLike(MatchMode.Anywhere).IgnoreCase().ExcludeNulls().ExcludeZeroes();
                Result = Session.CreateCriteria(typeof(T)).Add(Example).SetFirstResult(firstResult)
                    .SetMaxResults(maxResults).List<T>();
                return Result;
            }
            catch
            {
                throw;
            }
        }

        public virtual T? SelectObjSql<T>(String query)
        {
            try
            {
                IQuery Query = Session.CreateQuery(query);
                IList<T> ResultList = Query.List<T>();

                T? Result = default;

                if (ResultList.Count > 0)
                {
                    Result = ResultList[0];
                }

                return Result;
            }
            catch
            {
                throw;
            }
        }

        public virtual IList<T> SelectListSql<T>(String query)
        {
            try
            {
                IQuery Query = Session.CreateQuery(query);
                //IList<T> Result = Query.List<T>();
                IList<T> Result = Query.SetMaxResults(Constants.MAX_ROWS).List<T>();
                return Result;
            }
            catch
            {
                throw;
            }
        }

    }
}