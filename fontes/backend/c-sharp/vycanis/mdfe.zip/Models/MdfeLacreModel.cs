namespace mdfe.Models
{
	public class MdfeLacreModel
	{	
		public int? Id { get; set; } 

		public string? NumeroLacre { get; set; } 

		public MdfeCabecalhoModel? MdfeCabecalhoModel { get; set; } 

	}
}
