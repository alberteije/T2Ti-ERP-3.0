namespace mdfe.Models
{
	public class MdfeRodoviarioPedagioModel
	{	
		public int? Id { get; set; } 

		public string? CnpjFornecedor { get; set; } 

		public string? CnpjResponsavel { get; set; } 

		public string? CpfResponsavel { get; set; } 

		public string? NumeroComprovante { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public MdfeRodoviarioModel? MdfeRodoviarioModel { get; set; } 

	}
}
