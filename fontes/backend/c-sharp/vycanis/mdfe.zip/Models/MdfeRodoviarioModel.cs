namespace mdfe.Models
{
	public class MdfeRodoviarioModel
	{	
		public int? Id { get; set; } 

		public string? Rntrc { get; set; } 

		public string? CodigoAgendamento { get; set; } 

		public MdfeCabecalhoModel? MdfeCabecalhoModel { get; set; } 

	}
}
