namespace mdfe.Models
{
	public class MdfeRodoviarioCiotModel
	{	
		public int? Id { get; set; } 

		public string? Ciot { get; set; } 

		public string? Cpf { get; set; } 

		public string? Cnpj { get; set; } 

		public MdfeRodoviarioModel? MdfeRodoviarioModel { get; set; } 

	}
}
