namespace mdfe.Models
{
	public class MdfeInformacaoNfeModel
	{	
		public int? Id { get; set; } 

		public string? ChaveNfe { get; set; } 

		public string? SegundoCodigoBarra { get; set; } 

		public int? IndicadorReentrega { get; set; } 

		public MdfeMunicipioDescarregaModel? MdfeMunicipioDescarregaModel { get; set; } 

	}
}
