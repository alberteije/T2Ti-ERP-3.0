namespace mdfe.Models
{
	public class MdfePercursoModel
	{	
		public int? Id { get; set; } 

		public string? UfPercurso { get; set; } 

		public System.Nullable<System.DateTime> DataInicioViagem { get; set; } 

		public MdfeCabecalhoModel? MdfeCabecalhoModel { get; set; } 

	}
}
