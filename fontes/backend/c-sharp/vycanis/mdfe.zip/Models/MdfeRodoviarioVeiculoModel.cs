namespace mdfe.Models
{
	public class MdfeRodoviarioVeiculoModel
	{	
		public int? Id { get; set; } 

		public string? CodigoInterno { get; set; } 

		public string? Placa { get; set; } 

		public string? Renavam { get; set; } 

		public int? Tara { get; set; } 

		public int? CapacidadeKg { get; set; } 

		public int? CapacidadeM3 { get; set; } 

		public string? TipoRodado { get; set; } 

		public string? TipoCarroceria { get; set; } 

		public string? UfLicenciamento { get; set; } 

		public string? ProprietarioCpf { get; set; } 

		public string? ProprietarioCnpj { get; set; } 

		public string? ProprietarioRntrc { get; set; } 

		public string? ProprietarioNome { get; set; } 

		public string? ProprietarioIe { get; set; } 

		public int? ProprietarioTipo { get; set; } 

		public MdfeRodoviarioModel? MdfeRodoviarioModel { get; set; } 

	}
}
