using mdfe.Models;
using mdfe.NHibernate;
using ISession = NHibernate.ISession;

namespace mdfe.Services
{
    public class MdfeRodoviarioVeiculoService
    {

        public IEnumerable<MdfeRodoviarioVeiculoModel> GetList()
        {
            IList<MdfeRodoviarioVeiculoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioVeiculoModel> DAL = new NHibernateDAL<MdfeRodoviarioVeiculoModel>(Session);
                Result = DAL.Select(new MdfeRodoviarioVeiculoModel());
            }
            return Result;
        }

        public IEnumerable<MdfeRodoviarioVeiculoModel> GetListFilter(Filter filterObj)
        {
            IList<MdfeRodoviarioVeiculoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MdfeRodoviarioVeiculoModel where " + filterObj.Where;
                NHibernateDAL<MdfeRodoviarioVeiculoModel> DAL = new NHibernateDAL<MdfeRodoviarioVeiculoModel>(Session);
                Result = DAL.SelectListSql<MdfeRodoviarioVeiculoModel>(Query);
            }
            return Result;
        }
		
        public MdfeRodoviarioVeiculoModel GetObject(int id)
        {
            MdfeRodoviarioVeiculoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioVeiculoModel> DAL = new NHibernateDAL<MdfeRodoviarioVeiculoModel>(Session);
                Result = DAL.SelectId<MdfeRodoviarioVeiculoModel>(id);
            }
            return Result;
        }
		
        public void Insert(MdfeRodoviarioVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioVeiculoModel> DAL = new NHibernateDAL<MdfeRodoviarioVeiculoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MdfeRodoviarioVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioVeiculoModel> DAL = new NHibernateDAL<MdfeRodoviarioVeiculoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MdfeRodoviarioVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeRodoviarioVeiculoModel> DAL = new NHibernateDAL<MdfeRodoviarioVeiculoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}