using mdfe.Models;
using mdfe.NHibernate;
using ISession = NHibernate.ISession;

namespace mdfe.Services
{
    public class MdfeInformacaoNfeService
    {

        public IEnumerable<MdfeInformacaoNfeModel> GetList()
        {
            IList<MdfeInformacaoNfeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoNfeModel> DAL = new NHibernateDAL<MdfeInformacaoNfeModel>(Session);
                Result = DAL.Select(new MdfeInformacaoNfeModel());
            }
            return Result;
        }

        public IEnumerable<MdfeInformacaoNfeModel> GetListFilter(Filter filterObj)
        {
            IList<MdfeInformacaoNfeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from MdfeInformacaoNfeModel where " + filterObj.Where;
                NHibernateDAL<MdfeInformacaoNfeModel> DAL = new NHibernateDAL<MdfeInformacaoNfeModel>(Session);
                Result = DAL.SelectListSql<MdfeInformacaoNfeModel>(Query);
            }
            return Result;
        }
		
        public MdfeInformacaoNfeModel GetObject(int id)
        {
            MdfeInformacaoNfeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoNfeModel> DAL = new NHibernateDAL<MdfeInformacaoNfeModel>(Session);
                Result = DAL.SelectId<MdfeInformacaoNfeModel>(id);
            }
            return Result;
        }
		
        public void Insert(MdfeInformacaoNfeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoNfeModel> DAL = new NHibernateDAL<MdfeInformacaoNfeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(MdfeInformacaoNfeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoNfeModel> DAL = new NHibernateDAL<MdfeInformacaoNfeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(MdfeInformacaoNfeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<MdfeInformacaoNfeModel> DAL = new NHibernateDAL<MdfeInformacaoNfeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}