namespace mdfe.Models
{
	public class MdfeCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? Uf { get; set; } 

		public string? TipoAmbiente { get; set; } 

		public string? TipoEmitente { get; set; } 

		public string? TipoTransportadora { get; set; } 

		public string? Modelo { get; set; } 

		public string? Serie { get; set; } 

		public string? NumeroMdfe { get; set; } 

		public string? CodigoNumerico { get; set; } 

		public string? ChaveAcesso { get; set; } 

		public int? DigitoVerificador { get; set; } 

		public string? Modal { get; set; } 

		public System.Nullable<System.DateTime> DataHoraEmissao { get; set; } 

		public string? TipoEmissao { get; set; } 

		public string? ProcessoEmissao { get; set; } 

		public string? VersaoProcessoEmissao { get; set; } 

		public string? UfInicio { get; set; } 

		public string? UfFim { get; set; } 

		public System.Nullable<System.DateTime> DataHoraPrevisaoViagem { get; set; } 

		public int? QuantidadeTotalCte { get; set; } 

		public int? QuantidadeTotalNfe { get; set; } 

		public int? QuantidadeTotalMdfe { get; set; } 

		public string? CodigoUnidadeMedida { get; set; } 

		public System.Nullable<System.Decimal> PesoBrutoCarga { get; set; } 

		public System.Nullable<System.Decimal> ValorCarga { get; set; } 

		public string? NumeroProtocolo { get; set; } 

		private IList<MdfeLacreModel>? mdfeLacreModelList; 
		public IList<MdfeLacreModel>? MdfeLacreModelList 
		{ 
			get 
			{ 
				return mdfeLacreModelList; 
			} 
			set 
			{ 
				mdfeLacreModelList = value; 
				foreach (MdfeLacreModel mdfeLacreModel in mdfeLacreModelList!) 
				{ 
					mdfeLacreModel.MdfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<MdfeMunicipioDescarregaModel>? mdfeMunicipioDescarregaModelList; 
		public IList<MdfeMunicipioDescarregaModel>? MdfeMunicipioDescarregaModelList 
		{ 
			get 
			{ 
				return mdfeMunicipioDescarregaModelList; 
			} 
			set 
			{ 
				mdfeMunicipioDescarregaModelList = value; 
				foreach (MdfeMunicipioDescarregaModel mdfeMunicipioDescarregaModel in mdfeMunicipioDescarregaModelList!) 
				{ 
					mdfeMunicipioDescarregaModel.MdfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<MdfeEmitenteModel>? mdfeEmitenteModelList; 
		public IList<MdfeEmitenteModel>? MdfeEmitenteModelList 
		{ 
			get 
			{ 
				return mdfeEmitenteModelList; 
			} 
			set 
			{ 
				mdfeEmitenteModelList = value; 
				foreach (MdfeEmitenteModel mdfeEmitenteModel in mdfeEmitenteModelList!) 
				{ 
					mdfeEmitenteModel.MdfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<MdfePercursoModel>? mdfePercursoModelList; 
		public IList<MdfePercursoModel>? MdfePercursoModelList 
		{ 
			get 
			{ 
				return mdfePercursoModelList; 
			} 
			set 
			{ 
				mdfePercursoModelList = value; 
				foreach (MdfePercursoModel mdfePercursoModel in mdfePercursoModelList!) 
				{ 
					mdfePercursoModel.MdfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<MdfeMunicipioCarregamentoModel>? mdfeMunicipioCarregamentoModelList; 
		public IList<MdfeMunicipioCarregamentoModel>? MdfeMunicipioCarregamentoModelList 
		{ 
			get 
			{ 
				return mdfeMunicipioCarregamentoModelList; 
			} 
			set 
			{ 
				mdfeMunicipioCarregamentoModelList = value; 
				foreach (MdfeMunicipioCarregamentoModel mdfeMunicipioCarregamentoModel in mdfeMunicipioCarregamentoModelList!) 
				{ 
					mdfeMunicipioCarregamentoModel.MdfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<MdfeRodoviarioModel>? mdfeRodoviarioModelList; 
		public IList<MdfeRodoviarioModel>? MdfeRodoviarioModelList 
		{ 
			get 
			{ 
				return mdfeRodoviarioModelList; 
			} 
			set 
			{ 
				mdfeRodoviarioModelList = value; 
				foreach (MdfeRodoviarioModel mdfeRodoviarioModel in mdfeRodoviarioModelList!) 
				{ 
					mdfeRodoviarioModel.MdfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<MdfeInformacaoSeguroModel>? mdfeInformacaoSeguroModelList; 
		public IList<MdfeInformacaoSeguroModel>? MdfeInformacaoSeguroModelList 
		{ 
			get 
			{ 
				return mdfeInformacaoSeguroModelList; 
			} 
			set 
			{ 
				mdfeInformacaoSeguroModelList = value; 
				foreach (MdfeInformacaoSeguroModel mdfeInformacaoSeguroModel in mdfeInformacaoSeguroModelList!) 
				{ 
					mdfeInformacaoSeguroModel.MdfeCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
