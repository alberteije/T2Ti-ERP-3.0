namespace mdfe.Models
{
	public class MdfeMunicipioCarregamentoModel
	{	
		public int? Id { get; set; } 

		public string? CodigoMunicipio { get; set; } 

		public string? NomeMunicipio { get; set; } 

		public MdfeCabecalhoModel? MdfeCabecalhoModel { get; set; } 

	}
}
