namespace mdfe.Models
{
	public class MdfeInformacaoSeguroModel
	{	
		public int? Id { get; set; } 

		public int? Responsavel { get; set; } 

		public string? CnpjCpf { get; set; } 

		public string? Seguradora { get; set; } 

		public string? CnpjSeguradora { get; set; } 

		public string? Apolice { get; set; } 

		public string? Averbacao { get; set; } 

		public MdfeCabecalhoModel? MdfeCabecalhoModel { get; set; } 

	}
}
