namespace mdfe.Models
{
	public class MdfeInformacaoCteModel
	{	
		public int? Id { get; set; } 

		public string? ChaveCte { get; set; } 

		public string? SegundoCodigoBarra { get; set; } 

		public int? IndicadorReentrega { get; set; } 

		public MdfeMunicipioDescarregaModel? MdfeMunicipioDescarregaModel { get; set; } 

	}
}
