using Microsoft.AspNetCore.Mvc;
using mdfe.Models;
using mdfe.Services;

namespace mdfe.Controllers
{
    [Route("mdfe-rodoviario-pedagio")]
    [Produces("application/json")]
    public class MdfeRodoviarioPedagioController : Controller
    {
		private readonly MdfeRodoviarioPedagioService _service;

        public MdfeRodoviarioPedagioController()
        {
            _service = new MdfeRodoviarioPedagioService();
        }

        [HttpGet]
        public IActionResult GetListMdfeRodoviarioPedagio([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MdfeRodoviarioPedagioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList MdfeRodoviarioPedagio]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMdfeRodoviarioPedagio")]
        public IActionResult GetObjectMdfeRodoviarioPedagio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject MdfeRodoviarioPedagio]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject MdfeRodoviarioPedagio]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMdfeRodoviarioPedagio([FromBody]MdfeRodoviarioPedagioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert MdfeRodoviarioPedagio]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMdfeRodoviarioPedagio", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert MdfeRodoviarioPedagio]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMdfeRodoviarioPedagio([FromBody]MdfeRodoviarioPedagioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update MdfeRodoviarioPedagio]", null));
                }

                _service.Update(objJson);

                return GetObjectMdfeRodoviarioPedagio(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update MdfeRodoviarioPedagio]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMdfeRodoviarioPedagio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete MdfeRodoviarioPedagio]", ex));
            }
        }

    }
}