using Microsoft.AspNetCore.Mvc;
using mdfe.Models;
using mdfe.Services;

namespace mdfe.Controllers
{
    [Route("mdfe-informacao-cte")]
    [Produces("application/json")]
    public class MdfeInformacaoCteController : Controller
    {
		private readonly MdfeInformacaoCteService _service;

        public MdfeInformacaoCteController()
        {
            _service = new MdfeInformacaoCteService();
        }

        [HttpGet]
        public IActionResult GetListMdfeInformacaoCte([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MdfeInformacaoCteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList MdfeInformacaoCte]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMdfeInformacaoCte")]
        public IActionResult GetObjectMdfeInformacaoCte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject MdfeInformacaoCte]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject MdfeInformacaoCte]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMdfeInformacaoCte([FromBody]MdfeInformacaoCteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert MdfeInformacaoCte]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMdfeInformacaoCte", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert MdfeInformacaoCte]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMdfeInformacaoCte([FromBody]MdfeInformacaoCteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update MdfeInformacaoCte]", null));
                }

                _service.Update(objJson);

                return GetObjectMdfeInformacaoCte(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update MdfeInformacaoCte]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMdfeInformacaoCte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete MdfeInformacaoCte]", ex));
            }
        }

    }
}