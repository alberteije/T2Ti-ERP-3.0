using Microsoft.AspNetCore.Mvc;
using mdfe.Models;
using mdfe.Services;

namespace mdfe.Controllers
{
    [Route("mdfe-rodoviario-motorista")]
    [Produces("application/json")]
    public class MdfeRodoviarioMotoristaController : Controller
    {
		private readonly MdfeRodoviarioMotoristaService _service;

        public MdfeRodoviarioMotoristaController()
        {
            _service = new MdfeRodoviarioMotoristaService();
        }

        [HttpGet]
        public IActionResult GetListMdfeRodoviarioMotorista([FromQuery]string filter)
        {
            try
            {
                IEnumerable<MdfeRodoviarioMotoristaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList MdfeRodoviarioMotorista]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectMdfeRodoviarioMotorista")]
        public IActionResult GetObjectMdfeRodoviarioMotorista(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject MdfeRodoviarioMotorista]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject MdfeRodoviarioMotorista]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertMdfeRodoviarioMotorista([FromBody]MdfeRodoviarioMotoristaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert MdfeRodoviarioMotorista]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectMdfeRodoviarioMotorista", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert MdfeRodoviarioMotorista]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateMdfeRodoviarioMotorista([FromBody]MdfeRodoviarioMotoristaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update MdfeRodoviarioMotorista]", null));
                }

                _service.Update(objJson);

                return GetObjectMdfeRodoviarioMotorista(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update MdfeRodoviarioMotorista]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteMdfeRodoviarioMotorista(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete MdfeRodoviarioMotorista]", ex));
            }
        }

    }
}