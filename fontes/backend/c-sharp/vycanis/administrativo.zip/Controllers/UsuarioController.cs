using Microsoft.AspNetCore.Mvc;
using administrativo.Models;
using administrativo.Services;

namespace administrativo.Controllers
{
    [Route("usuario")]
    [Produces("application/json")]
    public class UsuarioController : Controller
    {
		private readonly UsuarioService _service;

        public UsuarioController()
        {
            _service = new UsuarioService();
        }

        [HttpGet]
        public IActionResult GetListUsuario([FromQuery]string filter)
        {
            try
            {
                IEnumerable<UsuarioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Usuario]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectUsuario")]
        public IActionResult GetObjectUsuario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Usuario]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Usuario]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertUsuario([FromBody]UsuarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Usuario]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectUsuario", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Usuario]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateUsuario([FromBody]UsuarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Usuario]", null));
                }

                _service.Update(objJson);

                return GetObjectUsuario(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Usuario]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUsuario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Usuario]", ex));
            }
        }


        [HttpGet("verifica-login/{login}", Name = "GetUsuarioLogin")]
        public IActionResult GetUsuarioLogin(string login)
        {
            try
            {
                var objeto = _service.GetOjectFilter(login);

                if (objeto == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Registro n�o localizado [Consultar Objeto Usuario]", null));
                }
                else
                {
                    return Ok(objeto);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Erro no Servidor [Consultar Objeto Usuario]", ex));
            }
        }

    }
}