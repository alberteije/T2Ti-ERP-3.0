using Microsoft.AspNetCore.Mvc;
using administrativo.Models;
using administrativo.Services;

namespace administrativo.Controllers
{
    [Route("auditoria")]
    [Produces("application/json")]
    public class AuditoriaController : Controller
    {
		private readonly AuditoriaService _service;

        public AuditoriaController()
        {
            _service = new AuditoriaService();
        }

        [HttpGet]
        public IActionResult GetListAuditoria([FromQuery]string filter)
        {
            try
            {
                IEnumerable<AuditoriaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Auditoria]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectAuditoria")]
        public IActionResult GetObjectAuditoria(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Auditoria]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Auditoria]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertAuditoria([FromBody]AuditoriaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Auditoria]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectAuditoria", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Auditoria]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateAuditoria([FromBody]AuditoriaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Auditoria]", null));
                }

                _service.Update(objJson);

                return GetObjectAuditoria(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Auditoria]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteAuditoria(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Auditoria]", ex));
            }
        }

    }
}