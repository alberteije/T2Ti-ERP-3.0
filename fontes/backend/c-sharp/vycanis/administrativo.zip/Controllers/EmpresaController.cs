using Microsoft.AspNetCore.Mvc;
using administrativo.Models;
using administrativo.Services;

namespace administrativo.Controllers
{
    [Route("empresa")]
    [Produces("application/json")]
    public class EmpresaController : Controller
    {
		private readonly EmpresaService _service;

        public EmpresaController()
        {
            _service = new EmpresaService();
        }

        [HttpGet]
        public IActionResult GetListEmpresa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EmpresaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Empresa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEmpresa")]
        public IActionResult GetObjectEmpresa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Empresa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Empresa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEmpresa([FromBody]EmpresaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Empresa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEmpresa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Empresa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEmpresa([FromBody]EmpresaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Empresa]", null));
                }

                _service.Update(objJson);

                return GetObjectEmpresa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Empresa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmpresa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Empresa]", ex));
            }
        }

    }
}