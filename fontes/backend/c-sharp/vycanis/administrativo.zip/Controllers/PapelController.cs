using Microsoft.AspNetCore.Mvc;
using administrativo.Models;
using administrativo.Services;

namespace administrativo.Controllers
{
    [Route("papel")]
    [Produces("application/json")]
    public class PapelController : Controller
    {
		private readonly PapelService _service;

        public PapelController()
        {
            _service = new PapelService();
        }

        [HttpGet]
        public IActionResult GetListPapel([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PapelModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Papel]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPapel")]
        public IActionResult GetObjectPapel(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Papel]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Papel]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPapel([FromBody]PapelModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Papel]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPapel", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Papel]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePapel([FromBody]PapelModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Papel]", null));
                }

                _service.Update(objJson);

                return GetObjectPapel(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Papel]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePapel(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Papel]", ex));
            }
        }

    }
}