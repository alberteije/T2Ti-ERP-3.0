using administrativo.Models;
using administrativo.NHibernate;
using administrativo.Utils;
using NHibernate.Mapping;
using ISession = NHibernate.ISession;

namespace administrativo.Services
{
    public class AuditoriaService
    {
        public IEnumerable<AuditoriaModel> GetList()
        {
            IList<AuditoriaModel> Result;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                Result = DAL.Select(new AuditoriaModel());

                // Para cada auditoria, buscar o UsuarioToken associado
                foreach (var auditoria in Result)
                {
                    if (!string.IsNullOrEmpty(auditoria.TokenJwt))
                    {
                        string consultaSql = "from UsuarioTokenModel where Token="
                            + Util.QuotedStr(auditoria.TokenJwt);
                        var usuarioToken = DAL.SelectObjSql<UsuarioTokenModel>(consultaSql);
                        auditoria.UsuarioTokenModel = usuarioToken;
                    }
                }
            }
            return Result;
        }

        public IEnumerable<AuditoriaModel> GetListFilter(Filter filterObj)
        {
            IList<AuditoriaModel> Result;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from AuditoriaModel where " + filterObj.Where;
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                Result = DAL.SelectListSql<AuditoriaModel>(Query);

                // Para cada auditoria, buscar o UsuarioToken associado
                foreach (var auditoria in Result)
                {
                    if (!string.IsNullOrEmpty(auditoria.TokenJwt))
                    {
                        string consultaSql = "from UsuarioTokenModel where Token="
                            + Util.QuotedStr(auditoria.TokenJwt);
                        var usuarioToken = DAL.SelectObjSql<UsuarioTokenModel>(consultaSql);
                        auditoria.UsuarioTokenModel = usuarioToken;
                    }
                }
            }
            return Result;
        }

        public AuditoriaModel? GetObject(int id)
        {
            AuditoriaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                Result = DAL.SelectId<AuditoriaModel>(id);

                // Buscar o UsuarioToken associado, se existir
                if (Result != null && !string.IsNullOrEmpty(Result.TokenJwt))
                {
                    string consultaSql = "from UsuarioTokenModel where Token="
                        + Util.QuotedStr(Result.TokenJwt);
                    var usuarioToken = DAL.SelectObjSql<UsuarioTokenModel>(consultaSql);
                    Result.UsuarioTokenModel = usuarioToken;
                }
            }
            return Result;
        }

        public void Insert(AuditoriaModel obj)
        {
            try
            {
                using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
                {
                    NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                    DAL.SaveOrUpdate(obj);
                    Session.Flush();
                }
            }
            catch (Exception ex)
            {
                // Adicionar log de erro, se necess�rio
                throw new Exception("Erro ao inserir Auditoria", ex);
            }
        }

        public void Update(AuditoriaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(AuditoriaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AuditoriaModel> DAL = new NHibernateDAL<AuditoriaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
    }
}
