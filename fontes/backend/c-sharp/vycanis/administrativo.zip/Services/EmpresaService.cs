using administrativo.Models;
using administrativo.NHibernate;
using ISession = NHibernate.ISession;

namespace administrativo.Services
{
    public class EmpresaService
    {

        public IEnumerable<EmpresaModel> GetList()
        {
            IList<EmpresaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaModel> DAL = new NHibernateDAL<EmpresaModel>(Session);
                Result = DAL.Select(new EmpresaModel());
            }
            return Result;
        }

        public IEnumerable<EmpresaModel> GetListFilter(Filter filterObj)
        {
            IList<EmpresaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EmpresaModel where " + filterObj.Where;
                NHibernateDAL<EmpresaModel> DAL = new NHibernateDAL<EmpresaModel>(Session);
                Result = DAL.SelectListSql<EmpresaModel>(Query);
            }
            return Result;
        }
		
        public EmpresaModel GetObject(int id)
        {
            EmpresaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaModel> DAL = new NHibernateDAL<EmpresaModel>(Session);
                Result = DAL.SelectId<EmpresaModel>(id);
            }
            return Result;
        }
		
        public void Insert(EmpresaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaModel> DAL = new NHibernateDAL<EmpresaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EmpresaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaModel> DAL = new NHibernateDAL<EmpresaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EmpresaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaModel> DAL = new NHibernateDAL<EmpresaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}