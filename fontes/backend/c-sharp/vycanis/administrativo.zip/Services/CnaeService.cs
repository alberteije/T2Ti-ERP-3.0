using administrativo.Models;
using administrativo.NHibernate;
using ISession = NHibernate.ISession;

namespace administrativo.Services
{
    public class CnaeService
    {

        public IEnumerable<CnaeModel> GetList()
        {
            IList<CnaeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CnaeModel> DAL = new NHibernateDAL<CnaeModel>(Session);
                Result = DAL.Select(new CnaeModel());
            }
            return Result;
        }

        public IEnumerable<CnaeModel> GetListFilter(Filter filterObj)
        {
            IList<CnaeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CnaeModel where " + filterObj.Where;
                NHibernateDAL<CnaeModel> DAL = new NHibernateDAL<CnaeModel>(Session);
                Result = DAL.SelectListSql<CnaeModel>(Query);
            }
            return Result;
        }
		
        public CnaeModel GetObject(int id)
        {
            CnaeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CnaeModel> DAL = new NHibernateDAL<CnaeModel>(Session);
                Result = DAL.SelectId<CnaeModel>(id);
            }
            return Result;
        }
		
        public void Insert(CnaeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CnaeModel> DAL = new NHibernateDAL<CnaeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CnaeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CnaeModel> DAL = new NHibernateDAL<CnaeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CnaeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CnaeModel> DAL = new NHibernateDAL<CnaeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}