using administrativo.Models;
using administrativo.NHibernate;
using administrativo.Utils;
using MySqlX.XDevAPI.Common;
using ISession = NHibernate.ISession;

namespace administrativo.Services
{
    public class UsuarioService
    {

        public IEnumerable<UsuarioModel> GetList()
        {
            IList<UsuarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioModel> DAL = new NHibernateDAL<UsuarioModel>(Session);
                Result = DAL.Select(new UsuarioModel());
            }
            return Result;
        }

        public IEnumerable<UsuarioModel> GetListFilter(Filter filterObj)
        {
            IList<UsuarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from UsuarioModel where " + filterObj.Where;
                NHibernateDAL<UsuarioModel> DAL = new NHibernateDAL<UsuarioModel>(Session);
                Result = DAL.SelectListSql<UsuarioModel>(Query);
            }
            return Result;
        }
		
        public UsuarioModel GetObject(int id)
        {
            UsuarioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioModel> DAL = new NHibernateDAL<UsuarioModel>(Session);
                Result = DAL.SelectId<UsuarioModel>(id);
            }
            return Result;
        }

        public UsuarioModel? GetOjectFilter(string login)
        {
            UsuarioModel? Resultado = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioModel> DAL = new NHibernateDAL<UsuarioModel>(Session);
                string consultaSql = "from UsuarioModel where Login="
                    + Util.QuotedStr(login);
                Resultado = DAL.SelectObjSql<UsuarioModel>(consultaSql);
            }
            return Resultado;
        }
        public void Insert(UsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioModel> DAL = new NHibernateDAL<UsuarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(UsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioModel> DAL = new NHibernateDAL<UsuarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(UsuarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioModel> DAL = new NHibernateDAL<UsuarioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}