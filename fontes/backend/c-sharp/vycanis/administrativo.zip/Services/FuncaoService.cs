using administrativo.Models;
using administrativo.NHibernate;
using ISession = NHibernate.ISession;

namespace administrativo.Services
{
    public class FuncaoService
    {

        public IEnumerable<FuncaoModel> GetList()
        {
            IList<FuncaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FuncaoModel> DAL = new NHibernateDAL<FuncaoModel>(Session);
                Result = DAL.Select(new FuncaoModel());
            }
            return Result;
        }

        public IEnumerable<FuncaoModel> GetListFilter(Filter filterObj)
        {
            IList<FuncaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FuncaoModel where " + filterObj.Where;
                NHibernateDAL<FuncaoModel> DAL = new NHibernateDAL<FuncaoModel>(Session);
                Result = DAL.SelectListSql<FuncaoModel>(Query);
            }
            return Result;
        }
		
        public FuncaoModel GetObject(int id)
        {
            FuncaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FuncaoModel> DAL = new NHibernateDAL<FuncaoModel>(Session);
                Result = DAL.SelectId<FuncaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FuncaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FuncaoModel> DAL = new NHibernateDAL<FuncaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FuncaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FuncaoModel> DAL = new NHibernateDAL<FuncaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FuncaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FuncaoModel> DAL = new NHibernateDAL<FuncaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}