namespace administrativo.Models
{
	public class UsuarioModel
	{	
		public int? Id { get; set; } 

		public string? Login { get; set; } 

		public string? Senha { get; set; } 

		public string? Administrador { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public PapelModel? PapelModel { get; set; } 

	}
}
