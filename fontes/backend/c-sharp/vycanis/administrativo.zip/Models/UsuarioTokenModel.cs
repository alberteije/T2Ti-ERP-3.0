namespace administrativo.Models
{
    public class UsuarioTokenModel
    {
        public int? Id { get; set; }

        public string? Login { get; set; }

        public string? Token { get; set; }

        public DateTime? DataCriacao { get; set; }

        public string? HoraCriacao { get; set; }

        public DateTime? DataExpiracao { get; set; }

        public string? HoraExpiracao { get; set; }

        // Relacionamento com AuditoriaModel
        public virtual AuditoriaModel? AuditoriaModel { get; set; }
    }
}
