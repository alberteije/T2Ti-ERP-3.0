namespace administrativo.Models
{
	public class EmpresaContatoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Email { get; set; } 

		public string? Observacao { get; set; } 

		public EmpresaModel? EmpresaModel { get; set; } 

	}
}
