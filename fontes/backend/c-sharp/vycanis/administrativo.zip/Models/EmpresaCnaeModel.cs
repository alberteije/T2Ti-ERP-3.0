namespace administrativo.Models
{
	public class EmpresaCnaeModel
	{	
		public int? Id { get; set; } 

		public string? Principal { get; set; } 

		public string? RamoAtividade { get; set; } 

		public string? ObjetoSocial { get; set; } 

		public CnaeModel? CnaeModel { get; set; } 

		public EmpresaModel? EmpresaModel { get; set; } 

	}
}
