namespace administrativo.Models
{
	public class EmpresaModel
	{	
		public int? Id { get; set; } 

		public string? RazaoSocial { get; set; } 

		public string? NomeFantasia { get; set; } 

		public string? Cnpj { get; set; } 

		public string? InscricaoEstadual { get; set; } 

		public string? InscricaoMunicipal { get; set; } 

		public string? TipoRegime { get; set; } 

		public string? Crt { get; set; } 

		public string? Email { get; set; } 

		public string? Site { get; set; } 

		public string? Contato { get; set; } 

		public System.Nullable<System.DateTime> DataConstituicao { get; set; } 

		public string? Tipo { get; set; } 

		public string? InscricaoJuntaComercial { get; set; } 

		public System.Nullable<System.DateTime> DataInscJuntaComercial { get; set; } 

		public int? CodigoIbgeCidade { get; set; } 

		public int? CodigoIbgeUf { get; set; } 

		public string? Cei { get; set; } 

		public string? CodigoCnaePrincipal { get; set; } 

		public string? ImagemLogotipo { get; set; } 

		private IList<EmpresaContatoModel>? empresaContatoModelList; 
		public IList<EmpresaContatoModel>? EmpresaContatoModelList 
		{ 
			get 
			{ 
				return empresaContatoModelList; 
			} 
			set 
			{ 
				empresaContatoModelList = value; 
				foreach (EmpresaContatoModel empresaContatoModel in empresaContatoModelList!) 
				{ 
					empresaContatoModel.EmpresaModel = this; 
				} 
			} 
		} 

		private IList<EmpresaTelefoneModel>? empresaTelefoneModelList; 
		public IList<EmpresaTelefoneModel>? EmpresaTelefoneModelList 
		{ 
			get 
			{ 
				return empresaTelefoneModelList; 
			} 
			set 
			{ 
				empresaTelefoneModelList = value; 
				foreach (EmpresaTelefoneModel empresaTelefoneModel in empresaTelefoneModelList!) 
				{ 
					empresaTelefoneModel.EmpresaModel = this; 
				} 
			} 
		} 

		private IList<EmpresaCnaeModel>? empresaCnaeModelList; 
		public IList<EmpresaCnaeModel>? EmpresaCnaeModelList 
		{ 
			get 
			{ 
				return empresaCnaeModelList; 
			} 
			set 
			{ 
				empresaCnaeModelList = value; 
				foreach (EmpresaCnaeModel empresaCnaeModel in empresaCnaeModelList!) 
				{ 
					empresaCnaeModel.EmpresaModel = this; 
				} 
			} 
		} 

		private IList<EmpresaEnderecoModel>? empresaEnderecoModelList; 
		public IList<EmpresaEnderecoModel>? EmpresaEnderecoModelList 
		{ 
			get 
			{ 
				return empresaEnderecoModelList; 
			} 
			set 
			{ 
				empresaEnderecoModelList = value; 
				foreach (EmpresaEnderecoModel empresaEnderecoModel in empresaEnderecoModelList!) 
				{ 
					empresaEnderecoModel.EmpresaModel = this; 
				} 
			} 
		} 

	}
}
