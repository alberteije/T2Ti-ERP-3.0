namespace administrativo.Models
{
	public class EmpresaTelefoneModel
	{	
		public int? Id { get; set; } 

		public string? Tipo { get; set; } 

		public string? Numero { get; set; } 

		public EmpresaModel? EmpresaModel { get; set; } 

	}
}
