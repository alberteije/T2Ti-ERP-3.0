namespace administrativo.Models
{
	public class PapelFuncaoModel
	{	
		public int? Id { get; set; } 

		public string? Habilitado { get; set; } 

		public string? PodeInserir { get; set; } 

		public string? PodeAlterar { get; set; } 

		public string? PodeExcluir { get; set; } 

		public FuncaoModel? FuncaoModel { get; set; } 

		public PapelModel? PapelModel { get; set; } 

	}
}
