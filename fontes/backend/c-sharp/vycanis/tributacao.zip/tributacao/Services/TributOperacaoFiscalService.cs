using tributacao.Models;
using tributacao.NHibernate;
using ISession = NHibernate.ISession;

namespace tributacao.Services
{
    public class TributOperacaoFiscalService
    {

        public IEnumerable<TributOperacaoFiscalModel> GetList()
        {
            IList<TributOperacaoFiscalModel> Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributOperacaoFiscalModel> DAL = new NHibernateDAL<TributOperacaoFiscalModel>(Session);
                Result = DAL.Select(new TributOperacaoFiscalModel());
            }
            return Result;
        }

        public IEnumerable<TributOperacaoFiscalModel> GetListFilter(Filter filterObj)
        {
            IList<TributOperacaoFiscalModel> Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TributOperacaoFiscalModel where " + filterObj.Where;
                NHibernateDAL<TributOperacaoFiscalModel> DAL = new NHibernateDAL<TributOperacaoFiscalModel>(Session);
                Result = DAL.SelectListSql<TributOperacaoFiscalModel>(Query);
            }
            return Result;
        }
		
        public TributOperacaoFiscalModel GetObject(int id)
        {
            TributOperacaoFiscalModel Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributOperacaoFiscalModel> DAL = new NHibernateDAL<TributOperacaoFiscalModel>(Session);
                Result = DAL.SelectId<TributOperacaoFiscalModel>(id);
            }
            return Result;
        }
		
        public void Insert(TributOperacaoFiscalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributOperacaoFiscalModel> DAL = new NHibernateDAL<TributOperacaoFiscalModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TributOperacaoFiscalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributOperacaoFiscalModel> DAL = new NHibernateDAL<TributOperacaoFiscalModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TributOperacaoFiscalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributOperacaoFiscalModel> DAL = new NHibernateDAL<TributOperacaoFiscalModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}