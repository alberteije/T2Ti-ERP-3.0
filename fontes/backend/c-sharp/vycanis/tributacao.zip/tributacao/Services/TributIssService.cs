using tributacao.Models;
using tributacao.NHibernate;
using ISession = NHibernate.ISession;

namespace tributacao.Services
{
    public class TributIssService
    {

        public IEnumerable<TributIssModel> GetList()
        {
            IList<TributIssModel> Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIssModel> DAL = new NHibernateDAL<TributIssModel>(Session);
                Result = DAL.Select(new TributIssModel());
            }
            return Result;
        }

        public IEnumerable<TributIssModel> GetListFilter(Filter filterObj)
        {
            IList<TributIssModel> Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TributIssModel where " + filterObj.Where;
                NHibernateDAL<TributIssModel> DAL = new NHibernateDAL<TributIssModel>(Session);
                Result = DAL.SelectListSql<TributIssModel>(Query);
            }
            return Result;
        }
		
        public TributIssModel GetObject(int id)
        {
            TributIssModel Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIssModel> DAL = new NHibernateDAL<TributIssModel>(Session);
                Result = DAL.SelectId<TributIssModel>(id);
            }
            return Result;
        }
		
        public void Insert(TributIssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIssModel> DAL = new NHibernateDAL<TributIssModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TributIssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIssModel> DAL = new NHibernateDAL<TributIssModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TributIssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIssModel> DAL = new NHibernateDAL<TributIssModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}