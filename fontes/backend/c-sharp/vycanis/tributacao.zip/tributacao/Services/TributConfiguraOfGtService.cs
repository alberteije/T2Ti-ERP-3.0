using tributacao.Models;
using tributacao.NHibernate;
using ISession = NHibernate.ISession;

namespace tributacao.Services
{
    public class TributConfiguraOfGtService
    {

        public IEnumerable<TributConfiguraOfGtModel> GetList()
        {
            IList<TributConfiguraOfGtModel> Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributConfiguraOfGtModel> DAL = new NHibernateDAL<TributConfiguraOfGtModel>(Session);
                Result = DAL.Select(new TributConfiguraOfGtModel());
            }
            return Result;
        }

        public IEnumerable<TributConfiguraOfGtModel> GetListFilter(Filter filterObj)
        {
            IList<TributConfiguraOfGtModel> Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TributConfiguraOfGtModel where " + filterObj.Where;
                NHibernateDAL<TributConfiguraOfGtModel> DAL = new NHibernateDAL<TributConfiguraOfGtModel>(Session);
                Result = DAL.SelectListSql<TributConfiguraOfGtModel>(Query);
            }
            return Result;
        }
		
        public TributConfiguraOfGtModel GetObject(int id)
        {
            TributConfiguraOfGtModel Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributConfiguraOfGtModel> DAL = new NHibernateDAL<TributConfiguraOfGtModel>(Session);
                Result = DAL.SelectId<TributConfiguraOfGtModel>(id);
            }
            return Result;
        }
		
        public void Insert(TributConfiguraOfGtModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributConfiguraOfGtModel> DAL = new NHibernateDAL<TributConfiguraOfGtModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TributConfiguraOfGtModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributConfiguraOfGtModel> DAL = new NHibernateDAL<TributConfiguraOfGtModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TributConfiguraOfGtModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributConfiguraOfGtModel> DAL = new NHibernateDAL<TributConfiguraOfGtModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}