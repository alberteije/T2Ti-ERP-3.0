using tributacao.Models;
using tributacao.NHibernate;
using ISession = NHibernate.ISession;

namespace tributacao.Services
{
    public class TributIcmsCustomCabService
    {

        public IEnumerable<TributIcmsCustomCabModel> GetList()
        {
            IList<TributIcmsCustomCabModel>? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIcmsCustomCabModel> DAL = new NHibernateDAL<TributIcmsCustomCabModel>(Session);
                Result = DAL.Select(new TributIcmsCustomCabModel());
            }
            return Result;
        }

        public IEnumerable<TributIcmsCustomCabModel> GetListFilter(Filter filterObj)
        {
            IList<TributIcmsCustomCabModel> Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TributIcmsCustomCabModel where " + filterObj.Where;
                NHibernateDAL<TributIcmsCustomCabModel> DAL = new NHibernateDAL<TributIcmsCustomCabModel>(Session);
                Result = DAL.SelectListSql<TributIcmsCustomCabModel>(Query);
            }
            return Result;
        }
		
        public TributIcmsCustomCabModel GetObject(int id)
        {
            TributIcmsCustomCabModel Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIcmsCustomCabModel> DAL = new NHibernateDAL<TributIcmsCustomCabModel>(Session);
                Result = DAL.SelectId<TributIcmsCustomCabModel>(id);
            }
            return Result;
        }
		
        public void Insert(TributIcmsCustomCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIcmsCustomCabModel> DAL = new NHibernateDAL<TributIcmsCustomCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TributIcmsCustomCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIcmsCustomCabModel> DAL = new NHibernateDAL<TributIcmsCustomCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TributIcmsCustomCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TributIcmsCustomCabModel> DAL = new NHibernateDAL<TributIcmsCustomCabModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}