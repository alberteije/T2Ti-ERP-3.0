using System.Collections.Generic;

namespace tributacao.Models
{
	public class TributIcmsUfModel
	{	
		public int? Id{ get; set; } 

		public string? UfDestino{ get; set; } 

		public string? Cst{ get; set; } 

		public string? Csosn{ get; set; } 

		public string? ModalidadeBc{ get; set; } 

		public int? Cfop{ get; set; } 

		public System.Nullable<System.Decimal> Aliquota{ get; set; } 

		public System.Nullable<System.Decimal> ValorPauta{ get; set; } 

		public System.Nullable<System.Decimal> ValorPrecoMaximo{ get; set; } 

		public System.Nullable<System.Decimal> Mva{ get; set; } 

		public System.Nullable<System.Decimal> PorcentoBc{ get; set; } 

		public string? ModalidadeBcSt{ get; set; } 

		public System.Nullable<System.Decimal> AliquotaInternaSt{ get; set; } 

		public System.Nullable<System.Decimal> AliquotaInterestadualSt{ get; set; } 

		public System.Nullable<System.Decimal> PorcentoBcSt{ get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcmsSt{ get; set; } 

		public System.Nullable<System.Decimal> ValorPautaSt{ get; set; } 

		public System.Nullable<System.Decimal> ValorPrecoMaximoSt{ get; set; } 

		public TributConfiguraOfGtModel? TributConfiguraOfGtModel { get; set; } 

	}
}
