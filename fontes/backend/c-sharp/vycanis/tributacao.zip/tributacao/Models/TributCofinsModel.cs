using System.Collections.Generic;

namespace tributacao.Models
{
	public class TributCofinsModel
	{	
		public int? Id { get; set; } 

		public string? CstCofins { get; set; } 

		public string? ModalidadeBaseCalculo { get; set; } 

		public string? EfdTabela435 { get; set; } 

		public System.Nullable<System.Decimal> PorcentoBaseCalculo { get; set; } 

		public System.Nullable<System.Decimal> AliquotaPorcento { get; set; } 

		public System.Nullable<System.Decimal> AliquotaUnidade { get; set; } 

		public System.Nullable<System.Decimal> ValorPrecoMaximo { get; set; } 

		public System.Nullable<System.Decimal> ValorPautaFiscal { get; set; } 

		public TributConfiguraOfGtModel? TributConfiguraOfGtModel { get; set; } 

	}
}
