using System.Collections.Generic;

namespace tributacao.Models
{
	public class TributOperacaoFiscalModel
	{	
		public int? Id{ get; set; } 

		public int? Cfop{ get; set; } 

		public string? Descricao{ get; set; } 

		public string? DescricaoNaNf{ get; set; } 

		public string? Observacao{ get; set; } 

	}
}
