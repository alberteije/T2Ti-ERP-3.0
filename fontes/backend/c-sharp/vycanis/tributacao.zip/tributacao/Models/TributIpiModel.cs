using System.Collections.Generic;

namespace tributacao.Models
{
	public class TributIpiModel
	{	
		public int? Id{ get; set; } 

		public string? CstIpi{ get; set; } 

		public string? ModalidadeBaseCalculo{ get; set; } 

		public System.Nullable<System.Decimal> PorcentoBaseCalculo{ get; set; } 

		public System.Nullable<System.Decimal> AliquotaPorcento{ get; set; } 

		public System.Nullable<System.Decimal> AliquotaUnidade{ get; set; } 

		public System.Nullable<System.Decimal> ValorPrecoMaximo{ get; set; } 

		public System.Nullable<System.Decimal> ValorPautaFiscal{ get; set; } 

		public TributConfiguraOfGtModel? TributConfiguraOfGtModel { get; set; } 

	}
}
