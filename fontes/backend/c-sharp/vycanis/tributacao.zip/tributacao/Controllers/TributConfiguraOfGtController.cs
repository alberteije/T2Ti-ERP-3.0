using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using tributacao.Models;
using tributacao.Services;

namespace tributacao.Controllers
{
    [Route("tribut-configura-of-gt")]
    [Produces("application/json")]
    public class TributConfiguraOfGtController : Controller
    {
		private readonly TributConfiguraOfGtService _service;

        public TributConfiguraOfGtController()
        {
            _service = new TributConfiguraOfGtService();
        }

        [HttpGet]
        public IActionResult GetListTributConfiguraOfGt([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TributConfiguraOfGtModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TributConfiguraOfGt]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTributConfiguraOfGt")]
        public IActionResult GetObjectTributConfiguraOfGt(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TributConfiguraOfGt]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TributConfiguraOfGt]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTributConfiguraOfGt([FromBody]TributConfiguraOfGtModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TributConfiguraOfGt]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTributConfiguraOfGt", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TributConfiguraOfGt]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTributConfiguraOfGt([FromBody]TributConfiguraOfGtModel objJson, int id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TributConfiguraOfGt]", null));
                }

                _service.Update(objJson);

                return GetObjectTributConfiguraOfGt(id);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TributConfiguraOfGt]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTributConfiguraOfGt(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TributConfiguraOfGt]", ex));
            }
        }

    }
}