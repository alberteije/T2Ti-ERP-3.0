using System.Collections.Generic;

namespace tributacao.Models
{
	public class TributConfiguraOfGtModel
	{
        public int? Id { get; set; }

        private TributIpiModel? tributIpiModel; 
		public TributIpiModel? TributIpiModel 
		{ 
			get 
			{ 
				return tributIpiModel; 
			} 
			set 
			{ 
				tributIpiModel = value; 
				if (value != null)
                {
                    tributIpiModel!.TributConfiguraOfGtModel = this;
                } 
			} 
		} 

		private TributCofinsModel? tributCofinsModel; 
		public TributCofinsModel? TributCofinsModel 
		{ 
			get 
			{ 
				return tributCofinsModel; 
			} 
			set 
			{ 
				tributCofinsModel = value; 
				if (value != null) 
				{ 
					tributCofinsModel!.TributConfiguraOfGtModel = this; 
				} 
			} 
		} 

		private TributPisModel? tributPisModel; 
		public TributPisModel? TributPisModel 
		{ 
			get 
			{ 
				return tributPisModel; 
			} 
			set 
			{ 
				tributPisModel = value; 
				if (value != null) 
				{ 
					tributPisModel!.TributConfiguraOfGtModel = this; 
				} 
			} 
		} 

		public TributGrupoTributarioModel? TributGrupoTributarioModel { get; set; } 

		public TributOperacaoFiscalModel? TributOperacaoFiscalModel { get; set; } 

		private IList<TributIcmsUfModel>? tributIcmsUfModelList; 
		public IList<TributIcmsUfModel>? TributIcmsUfModelList 
		{ 
			get 
			{ 
				return tributIcmsUfModelList; 
			} 
			set 
			{ 
				tributIcmsUfModelList = value; 
				foreach (TributIcmsUfModel tributIcmsUfModel in tributIcmsUfModelList!) 
				{ 
					tributIcmsUfModel.TributConfiguraOfGtModel = this; 
				} 
			} 
		} 

	}
}
