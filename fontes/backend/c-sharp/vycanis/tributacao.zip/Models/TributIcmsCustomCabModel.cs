using System.Collections.Generic;

namespace tributacao.Models
{
	public class TributIcmsCustomCabModel
	{	
		public int? Id{ get; set; } 

		public string? Descricao{ get; set; } 

		public string? OrigemMercadoria{ get; set; } 

		private IList<TributIcmsCustomDetModel>? tributIcmsCustomDetModelList; 
		public IList<TributIcmsCustomDetModel>? TributIcmsCustomDetModelList 
		{ 
			get 
			{ 
				return tributIcmsCustomDetModelList; 
			} 
			set 
			{ 
				tributIcmsCustomDetModelList = value; 
				foreach (TributIcmsCustomDetModel tributIcmsCustomDetModel in tributIcmsCustomDetModelList!) 
				{ 
					tributIcmsCustomDetModel.TributIcmsCustomCabModel = this; 
				} 
			} 
		} 

	}
}
