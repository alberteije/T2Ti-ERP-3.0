using System.Collections.Generic;

namespace tributacao.Models
{
	public class TributIssModel
	{	
		public int? Id{ get; set; } 

		public string? ModalidadeBaseCalculo{ get; set; } 

		public string? CodigoTributacao{ get; set; } 

		public int? ItemListaServico{ get; set; } 

		public System.Nullable<System.Decimal> PorcentoBaseCalculo{ get; set; } 

		public System.Nullable<System.Decimal> AliquotaPorcento{ get; set; } 

		public System.Nullable<System.Decimal> AliquotaUnidade{ get; set; } 

		public System.Nullable<System.Decimal> ValorPrecoMaximo{ get; set; } 

		public System.Nullable<System.Decimal> ValorPautaFiscal{ get; set; } 

		public TributOperacaoFiscalModel? TributOperacaoFiscalModel { get; set; } 

	}
}
