using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using tributacao.Models;
using tributacao.Services;

namespace tributacao.Controllers
{
    [Route("tribut-icms-custom-cab")]
    [Produces("application/json")]
    public class TributIcmsCustomCabController : Controller
    {
		private readonly TributIcmsCustomCabService _service;

        public TributIcmsCustomCabController()
        {
            _service = new TributIcmsCustomCabService();
        }

        [HttpGet]
        public IActionResult GetListTributIcmsCustomCab([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TributIcmsCustomCabModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TributIcmsCustomCab]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTributIcmsCustomCab")]
        public IActionResult GetObjectTributIcmsCustomCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TributIcmsCustomCab]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TributIcmsCustomCab]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTributIcmsCustomCab([FromBody]TributIcmsCustomCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TributIcmsCustomCab]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTributIcmsCustomCab", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TributIcmsCustomCab]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTributIcmsCustomCab([FromBody]TributIcmsCustomCabModel objJson, int id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TributIcmsCustomCab]", null));
                }

                _service.Update(objJson);

                return GetObjectTributIcmsCustomCab(id);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TributIcmsCustomCab]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTributIcmsCustomCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TributIcmsCustomCab]", ex));
            }
        }

    }
}