using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using tributacao.Models;
using tributacao.Services;

namespace tributacao.Controllers
{
    [Route("tribut-operacao-fiscal")]
    [Produces("application/json")]
    public class TributOperacaoFiscalController : Controller
    {
		private readonly TributOperacaoFiscalService _service;

        public TributOperacaoFiscalController()
        {
            _service = new TributOperacaoFiscalService();
        }

        [HttpGet]
        public IActionResult GetListTributOperacaoFiscal([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TributOperacaoFiscalModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TributOperacaoFiscal]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTributOperacaoFiscal")]
        public IActionResult GetObjectTributOperacaoFiscal(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TributOperacaoFiscal]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TributOperacaoFiscal]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTributOperacaoFiscal([FromBody]TributOperacaoFiscalModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TributOperacaoFiscal]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTributOperacaoFiscal", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TributOperacaoFiscal]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTributOperacaoFiscal([FromBody]TributOperacaoFiscalModel objJson, int id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TributOperacaoFiscal]", null));
                }

                _service.Update(objJson);

                return GetObjectTributOperacaoFiscal(id);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TributOperacaoFiscal]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTributOperacaoFiscal(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TributOperacaoFiscal]", ex));
            }
        }

    }
}