using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using tributacao.Models;
using tributacao.Services;

namespace tributacao.Controllers
{
    [Route("tribut-iss")]
    [Produces("application/json")]
    public class TributIssController : Controller
    {
		private readonly TributIssService _service;

        public TributIssController()
        {
            _service = new TributIssService();
        }

        [HttpGet]
        public IActionResult GetListTributIss([FromQuery]string filter)
        {
            try
            {
                IEnumerable<TributIssModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList TributIss]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectTributIss")]
        public IActionResult GetObjectTributIss(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject TributIss]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject TributIss]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertTributIss([FromBody]TributIssModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert TributIss]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectTributIss", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert TributIss]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateTributIss([FromBody]TributIssModel objJson, int id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update TributIss]", null));
                }

                _service.Update(objJson);

                return GetObjectTributIss(id);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update TributIss]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTributIss(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete TributIss]", ex));
            }
        }

    }
}