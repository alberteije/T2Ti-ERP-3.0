using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-cana-deducoes-safra")]
    [Produces("application/json")]
    public class NfeCanaDeducoesSafraController : Controller
    {
		private readonly NfeCanaDeducoesSafraService _service;

        public NfeCanaDeducoesSafraController()
        {
            _service = new NfeCanaDeducoesSafraService();
        }

        [HttpGet]
        public IActionResult GetListNfeCanaDeducoesSafra([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeCanaDeducoesSafraModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeCanaDeducoesSafra]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeCanaDeducoesSafra")]
        public IActionResult GetObjectNfeCanaDeducoesSafra(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeCanaDeducoesSafra]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeCanaDeducoesSafra]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeCanaDeducoesSafra([FromBody]NfeCanaDeducoesSafraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeCanaDeducoesSafra]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeCanaDeducoesSafra", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeCanaDeducoesSafra]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeCanaDeducoesSafra([FromBody]NfeCanaDeducoesSafraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeCanaDeducoesSafra]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeCanaDeducoesSafra(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeCanaDeducoesSafra]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeCanaDeducoesSafra(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeCanaDeducoesSafra]", ex));
            }
        }

    }
}