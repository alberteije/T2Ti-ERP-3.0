using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-duplicata")]
    [Produces("application/json")]
    public class NfeDuplicataController : Controller
    {
		private readonly NfeDuplicataService _service;

        public NfeDuplicataController()
        {
            _service = new NfeDuplicataService();
        }

        [HttpGet]
        public IActionResult GetListNfeDuplicata([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeDuplicataModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeDuplicata]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeDuplicata")]
        public IActionResult GetObjectNfeDuplicata(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeDuplicata]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeDuplicata]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeDuplicata([FromBody]NfeDuplicataModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeDuplicata]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeDuplicata", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeDuplicata]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeDuplicata([FromBody]NfeDuplicataModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeDuplicata]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeDuplicata(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeDuplicata]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeDuplicata(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeDuplicata]", ex));
            }
        }

    }
}