using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-transporte-volume")]
    [Produces("application/json")]
    public class NfeTransporteVolumeController : Controller
    {
		private readonly NfeTransporteVolumeService _service;

        public NfeTransporteVolumeController()
        {
            _service = new NfeTransporteVolumeService();
        }

        [HttpGet]
        public IActionResult GetListNfeTransporteVolume([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeTransporteVolumeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeTransporteVolume]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeTransporteVolume")]
        public IActionResult GetObjectNfeTransporteVolume(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeTransporteVolume]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeTransporteVolume]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeTransporteVolume([FromBody]NfeTransporteVolumeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeTransporteVolume]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeTransporteVolume", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeTransporteVolume]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeTransporteVolume([FromBody]NfeTransporteVolumeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeTransporteVolume]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeTransporteVolume(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeTransporteVolume]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeTransporteVolume(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeTransporteVolume]", ex));
            }
        }

    }
}