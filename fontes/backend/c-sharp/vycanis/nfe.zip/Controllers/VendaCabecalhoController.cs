using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("venda-cabecalho")]
    [Produces("application/json")]
    public class VendaCabecalhoController : Controller
    {
		private readonly VendaCabecalhoService _service;

        public VendaCabecalhoController()
        {
            _service = new VendaCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListVendaCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<VendaCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList VendaCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectVendaCabecalho")]
        public IActionResult GetObjectVendaCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject VendaCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject VendaCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertVendaCabecalho([FromBody]VendaCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert VendaCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectVendaCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert VendaCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateVendaCabecalho([FromBody]VendaCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update VendaCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectVendaCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update VendaCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteVendaCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete VendaCabecalho]", ex));
            }
        }

    }
}