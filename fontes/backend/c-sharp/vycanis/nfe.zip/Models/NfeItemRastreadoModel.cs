namespace nfe.Models
{
	public class NfeItemRastreadoModel
	{	
		public int? Id { get; set; } 

		public string? NumeroLote { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeItens { get; set; } 

		public System.Nullable<System.DateTime> DataFabricacao { get; set; } 

		public System.Nullable<System.DateTime> DataValidade { get; set; } 

		public string? CodigoAgregacao { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
