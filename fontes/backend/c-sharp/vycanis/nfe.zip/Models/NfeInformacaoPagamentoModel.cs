namespace nfe.Models
{
	public class NfeInformacaoPagamentoModel
	{	
		public int? Id { get; set; } 

		public string? IndicadorPagamento { get; set; } 

		public string? MeioPagamento { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public string? TipoIntegracao { get; set; } 

		public string? CnpjOperadoraCartao { get; set; } 

		public string? Bandeira { get; set; } 

		public string? NumeroAutorizacao { get; set; } 

		public System.Nullable<System.Decimal> Troco { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
