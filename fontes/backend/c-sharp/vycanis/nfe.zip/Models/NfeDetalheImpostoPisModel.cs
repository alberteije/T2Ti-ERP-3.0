namespace nfe.Models
{
	public class NfeDetalheImpostoPisModel
	{	
		public int? Id { get; set; } 

		public string? CstPis { get; set; } 

		public System.Nullable<System.Decimal> ValorBaseCalculoPis { get; set; } 

		public System.Nullable<System.Decimal> AliquotaPisPercentual { get; set; } 

		public System.Nullable<System.Decimal> ValorPis { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeVendida { get; set; } 

		public System.Nullable<System.Decimal> AliquotaPisReais { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
