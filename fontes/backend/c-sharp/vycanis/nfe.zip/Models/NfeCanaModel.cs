namespace nfe.Models
{
	public class NfeCanaModel
	{	
		public int? Id { get; set; } 

		public string? Safra { get; set; } 

		public string? MesAnoReferencia { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
