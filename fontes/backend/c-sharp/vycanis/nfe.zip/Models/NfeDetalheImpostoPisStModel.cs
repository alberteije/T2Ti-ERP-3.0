namespace nfe.Models
{
	public class NfeDetalheImpostoPisStModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorBaseCalculoPisSt { get; set; } 

		public System.Nullable<System.Decimal> AliquotaPisStPercentual { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeVendidaPisSt { get; set; } 

		public System.Nullable<System.Decimal> AliquotaPisStReais { get; set; } 

		public System.Nullable<System.Decimal> ValorPisSt { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
