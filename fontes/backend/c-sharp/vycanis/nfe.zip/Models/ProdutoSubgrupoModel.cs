namespace nfe.Models
{
	public class ProdutoSubgrupoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public ProdutoGrupoModel? ProdutoGrupoModel { get; set; } 

		private IList<ProdutoModel>? produtoModelList; 
		public IList<ProdutoModel>? ProdutoModelList 
		{ 
			get 
			{ 
				return produtoModelList; 
			} 
			set 
			{ 
				produtoModelList = value; 
				foreach (ProdutoModel produtoModel in produtoModelList!) 
				{ 
					produtoModel.ProdutoSubgrupoModel = this; 
				} 
			} 
		} 

	}
}
