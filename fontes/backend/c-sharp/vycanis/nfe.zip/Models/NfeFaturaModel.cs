namespace nfe.Models
{
	public class NfeFaturaModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.Decimal> ValorOriginal { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorLiquido { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
