namespace nfe.Models
{
	public class NfeNfReferenciadaModel
	{	
		public int? Id { get; set; } 

		public int? CodigoUf { get; set; } 

		public string? AnoMes { get; set; } 

		public string? Cnpj { get; set; } 

		public string? Modelo { get; set; } 

		public string? Serie { get; set; } 

		public int? NumeroNf { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
