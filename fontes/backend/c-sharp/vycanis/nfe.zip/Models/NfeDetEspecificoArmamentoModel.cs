namespace nfe.Models
{
	public class NfeDetEspecificoArmamentoModel
	{	
		public int? Id { get; set; } 

		public string? TipoArma { get; set; } 

		public string? NumeroSerieArma { get; set; } 

		public string? NumeroSerieCano { get; set; } 

		public string? Descricao { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
