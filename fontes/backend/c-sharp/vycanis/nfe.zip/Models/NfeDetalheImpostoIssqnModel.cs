namespace nfe.Models
{
	public class NfeDetalheImpostoIssqnModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIssqn { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIssqn { get; set; } 

		public System.Nullable<System.Decimal> ValorIssqn { get; set; } 

		public int? MunicipioIssqn { get; set; } 

		public int? ItemListaServicos { get; set; } 

		public System.Nullable<System.Decimal> ValorDeducao { get; set; } 

		public System.Nullable<System.Decimal> ValorOutrasRetencoes { get; set; } 

		public System.Nullable<System.Decimal> ValorDescontoIncondicionado { get; set; } 

		public System.Nullable<System.Decimal> ValorDescontoCondicionado { get; set; } 

		public System.Nullable<System.Decimal> ValorRetencaoIss { get; set; } 

		public string? IndicadorExigibilidadeIss { get; set; } 

		public string? CodigoServico { get; set; } 

		public int? MunicipioIncidencia { get; set; } 

		public int? PaisSevicoPrestado { get; set; } 

		public string? NumeroProcesso { get; set; } 

		public string? IndicadorIncentivoFiscal { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
