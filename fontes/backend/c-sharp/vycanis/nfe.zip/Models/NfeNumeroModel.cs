namespace nfe.Models
{
	public class NfeNumeroModel
	{	
		public int? Id { get; set; } 

		public string? Serie { get; set; } 

		public int? Numero { get; set; } 

	}
}
