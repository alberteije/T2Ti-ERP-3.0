namespace nfe.Models
{
	public class NfeDetalheModel
	{	
		public int? Id { get; set; } 

		public int? NumeroItem { get; set; } 

		public string? CodigoProduto { get; set; } 

		public string? Gtin { get; set; } 

		public string? NomeProduto { get; set; } 

		public string? Ncm { get; set; } 

		public string? Nve { get; set; } 

		public string? Cest { get; set; } 

		public string? IndicadorEscalaRelevante { get; set; } 

		public string? CnpjFabricante { get; set; } 

		public string? CodigoBeneficioFiscal { get; set; } 

		public int? ExTipi { get; set; } 

		public int? Cfop { get; set; } 

		public string? UnidadeComercial { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeComercial { get; set; } 

		public string? NumeroPedidoCompra { get; set; } 

		public int? ItemPedidoCompra { get; set; } 

		public string? NumeroFci { get; set; } 

		public string? NumeroRecopi { get; set; } 

		public System.Nullable<System.Decimal> ValorUnitarioComercial { get; set; } 

		public System.Nullable<System.Decimal> ValorBrutoProduto { get; set; } 

		public string? GtinUnidadeTributavel { get; set; } 

		public string? UnidadeTributavel { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeTributavel { get; set; } 

		public System.Nullable<System.Decimal> ValorUnitarioTributavel { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public System.Nullable<System.Decimal> ValorSeguro { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorOutrasDespesas { get; set; } 

		public string? EntraTotal { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalTributos { get; set; } 

		public System.Nullable<System.Decimal> PercentualDevolvido { get; set; } 

		public System.Nullable<System.Decimal> ValorIpiDevolvido { get; set; } 

		public string? InformacoesAdicionais { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

		private IList<NfeDetEspecificoVeiculoModel>? nfeDetEspecificoVeiculoModelList; 
		public IList<NfeDetEspecificoVeiculoModel>? NfeDetEspecificoVeiculoModelList 
		{ 
			get 
			{ 
				return nfeDetEspecificoVeiculoModelList; 
			} 
			set 
			{ 
				nfeDetEspecificoVeiculoModelList = value; 
				foreach (NfeDetEspecificoVeiculoModel nfeDetEspecificoVeiculoModel in nfeDetEspecificoVeiculoModelList!) 
				{ 
					nfeDetEspecificoVeiculoModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetEspecificoMedicamentoModel>? nfeDetEspecificoMedicamentoModelList; 
		public IList<NfeDetEspecificoMedicamentoModel>? NfeDetEspecificoMedicamentoModelList 
		{ 
			get 
			{ 
				return nfeDetEspecificoMedicamentoModelList; 
			} 
			set 
			{ 
				nfeDetEspecificoMedicamentoModelList = value; 
				foreach (NfeDetEspecificoMedicamentoModel nfeDetEspecificoMedicamentoModel in nfeDetEspecificoMedicamentoModelList!) 
				{ 
					nfeDetEspecificoMedicamentoModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetEspecificoArmamentoModel>? nfeDetEspecificoArmamentoModelList; 
		public IList<NfeDetEspecificoArmamentoModel>? NfeDetEspecificoArmamentoModelList 
		{ 
			get 
			{ 
				return nfeDetEspecificoArmamentoModelList; 
			} 
			set 
			{ 
				nfeDetEspecificoArmamentoModelList = value; 
				foreach (NfeDetEspecificoArmamentoModel nfeDetEspecificoArmamentoModel in nfeDetEspecificoArmamentoModelList!) 
				{ 
					nfeDetEspecificoArmamentoModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetEspecificoCombustivelModel>? nfeDetEspecificoCombustivelModelList; 
		public IList<NfeDetEspecificoCombustivelModel>? NfeDetEspecificoCombustivelModelList 
		{ 
			get 
			{ 
				return nfeDetEspecificoCombustivelModelList; 
			} 
			set 
			{ 
				nfeDetEspecificoCombustivelModelList = value; 
				foreach (NfeDetEspecificoCombustivelModel nfeDetEspecificoCombustivelModel in nfeDetEspecificoCombustivelModelList!) 
				{ 
					nfeDetEspecificoCombustivelModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDeclaracaoImportacaoModel>? nfeDeclaracaoImportacaoModelList; 
		public IList<NfeDeclaracaoImportacaoModel>? NfeDeclaracaoImportacaoModelList 
		{ 
			get 
			{ 
				return nfeDeclaracaoImportacaoModelList; 
			} 
			set 
			{ 
				nfeDeclaracaoImportacaoModelList = value; 
				foreach (NfeDeclaracaoImportacaoModel nfeDeclaracaoImportacaoModel in nfeDeclaracaoImportacaoModelList!) 
				{ 
					nfeDeclaracaoImportacaoModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoIcmsModel>? nfeDetalheImpostoIcmsModelList; 
		public IList<NfeDetalheImpostoIcmsModel>? NfeDetalheImpostoIcmsModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoIcmsModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoIcmsModelList = value; 
				foreach (NfeDetalheImpostoIcmsModel nfeDetalheImpostoIcmsModel in nfeDetalheImpostoIcmsModelList!) 
				{ 
					nfeDetalheImpostoIcmsModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoIpiModel>? nfeDetalheImpostoIpiModelList; 
		public IList<NfeDetalheImpostoIpiModel>? NfeDetalheImpostoIpiModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoIpiModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoIpiModelList = value; 
				foreach (NfeDetalheImpostoIpiModel nfeDetalheImpostoIpiModel in nfeDetalheImpostoIpiModelList!) 
				{ 
					nfeDetalheImpostoIpiModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoIiModel>? nfeDetalheImpostoIiModelList; 
		public IList<NfeDetalheImpostoIiModel>? NfeDetalheImpostoIiModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoIiModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoIiModelList = value; 
				foreach (NfeDetalheImpostoIiModel nfeDetalheImpostoIiModel in nfeDetalheImpostoIiModelList!) 
				{ 
					nfeDetalheImpostoIiModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoPisModel>? nfeDetalheImpostoPisModelList; 
		public IList<NfeDetalheImpostoPisModel>? NfeDetalheImpostoPisModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoPisModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoPisModelList = value; 
				foreach (NfeDetalheImpostoPisModel nfeDetalheImpostoPisModel in nfeDetalheImpostoPisModelList!) 
				{ 
					nfeDetalheImpostoPisModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoCofinsModel>? nfeDetalheImpostoCofinsModelList; 
		public IList<NfeDetalheImpostoCofinsModel>? NfeDetalheImpostoCofinsModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoCofinsModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoCofinsModelList = value; 
				foreach (NfeDetalheImpostoCofinsModel nfeDetalheImpostoCofinsModel in nfeDetalheImpostoCofinsModelList!) 
				{ 
					nfeDetalheImpostoCofinsModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoIssqnModel>? nfeDetalheImpostoIssqnModelList; 
		public IList<NfeDetalheImpostoIssqnModel>? NfeDetalheImpostoIssqnModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoIssqnModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoIssqnModelList = value; 
				foreach (NfeDetalheImpostoIssqnModel nfeDetalheImpostoIssqnModel in nfeDetalheImpostoIssqnModelList!) 
				{ 
					nfeDetalheImpostoIssqnModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeExportacaoModel>? nfeExportacaoModelList; 
		public IList<NfeExportacaoModel>? NfeExportacaoModelList 
		{ 
			get 
			{ 
				return nfeExportacaoModelList; 
			} 
			set 
			{ 
				nfeExportacaoModelList = value; 
				foreach (NfeExportacaoModel nfeExportacaoModel in nfeExportacaoModelList!) 
				{ 
					nfeExportacaoModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeItemRastreadoModel>? nfeItemRastreadoModelList; 
		public IList<NfeItemRastreadoModel>? NfeItemRastreadoModelList 
		{ 
			get 
			{ 
				return nfeItemRastreadoModelList; 
			} 
			set 
			{ 
				nfeItemRastreadoModelList = value; 
				foreach (NfeItemRastreadoModel nfeItemRastreadoModel in nfeItemRastreadoModelList!) 
				{ 
					nfeItemRastreadoModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoPisStModel>? nfeDetalheImpostoPisStModelList; 
		public IList<NfeDetalheImpostoPisStModel>? NfeDetalheImpostoPisStModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoPisStModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoPisStModelList = value; 
				foreach (NfeDetalheImpostoPisStModel nfeDetalheImpostoPisStModel in nfeDetalheImpostoPisStModelList!) 
				{ 
					nfeDetalheImpostoPisStModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoIcmsUfdestModel>? nfeDetalheImpostoIcmsUfdestModelList; 
		public IList<NfeDetalheImpostoIcmsUfdestModel>? NfeDetalheImpostoIcmsUfdestModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoIcmsUfdestModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoIcmsUfdestModelList = value; 
				foreach (NfeDetalheImpostoIcmsUfdestModel nfeDetalheImpostoIcmsUfdestModel in nfeDetalheImpostoIcmsUfdestModelList!) 
				{ 
					nfeDetalheImpostoIcmsUfdestModel.NfeDetalheModel = this; 
				} 
			} 
		} 

		private IList<NfeDetalheImpostoCofinsStModel>? nfeDetalheImpostoCofinsStModelList; 
		public IList<NfeDetalheImpostoCofinsStModel>? NfeDetalheImpostoCofinsStModelList 
		{ 
			get 
			{ 
				return nfeDetalheImpostoCofinsStModelList; 
			} 
			set 
			{ 
				nfeDetalheImpostoCofinsStModelList = value; 
				foreach (NfeDetalheImpostoCofinsStModel nfeDetalheImpostoCofinsStModel in nfeDetalheImpostoCofinsStModelList!) 
				{ 
					nfeDetalheImpostoCofinsStModel.NfeDetalheModel = this; 
				} 
			} 
		} 

	}
}
