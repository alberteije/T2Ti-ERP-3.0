namespace nfe.Models
{
	public class NfeDetalheImpostoIcmsUfdestModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcmsUfDestino { get; set; } 

		public System.Nullable<System.Decimal> ValorBcFcpUfDestino { get; set; } 

		public System.Nullable<System.Decimal> PercentualFcpUfDestino { get; set; } 

		public System.Nullable<System.Decimal> AliquotaInternaUfDestino { get; set; } 

		public System.Nullable<System.Decimal> AliquotaInteresdatualUfEnvolvidas { get; set; } 

		public System.Nullable<System.Decimal> PercentualProvisorioPartilhaIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsFcpUfDestino { get; set; } 

		public System.Nullable<System.Decimal> ValorInterestadualUfDestino { get; set; } 

		public System.Nullable<System.Decimal> ValorInterestadualUfRemetente { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
