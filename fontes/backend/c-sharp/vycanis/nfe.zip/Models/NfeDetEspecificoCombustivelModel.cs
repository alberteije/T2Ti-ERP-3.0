namespace nfe.Models
{
	public class NfeDetEspecificoCombustivelModel
	{	
		public int? Id { get; set; } 

		public int? CodigoAnp { get; set; } 

		public string? DescricaoAnp { get; set; } 

		public System.Nullable<System.Decimal> PercentualGlp { get; set; } 

		public System.Nullable<System.Decimal> PercentualGasNacional { get; set; } 

		public System.Nullable<System.Decimal> PercentualGasImportado { get; set; } 

		public System.Nullable<System.Decimal> ValorPartida { get; set; } 

		public string? Codif { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeTempAmbiente { get; set; } 

		public string? UfConsumo { get; set; } 

		public System.Nullable<System.Decimal> CideBaseCalculo { get; set; } 

		public System.Nullable<System.Decimal> CideAliquota { get; set; } 

		public System.Nullable<System.Decimal> CideValor { get; set; } 

		public int? EncerranteBico { get; set; } 

		public int? EncerranteBomba { get; set; } 

		public int? EncerranteTanque { get; set; } 

		public System.Nullable<System.Decimal> EncerranteValorInicio { get; set; } 

		public System.Nullable<System.Decimal> EncerranteValorFim { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
