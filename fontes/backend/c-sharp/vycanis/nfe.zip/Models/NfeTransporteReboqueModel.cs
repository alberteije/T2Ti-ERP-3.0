namespace nfe.Models
{
	public class NfeTransporteReboqueModel
	{	
		public int? Id { get; set; } 

		public string? Placa { get; set; } 

		public string? Uf { get; set; } 

		public string? Rntc { get; set; } 

		public string? Vagao { get; set; } 

		public string? Balsa { get; set; } 

		public NfeTransporteModel? NfeTransporteModel { get; set; } 

	}
}
