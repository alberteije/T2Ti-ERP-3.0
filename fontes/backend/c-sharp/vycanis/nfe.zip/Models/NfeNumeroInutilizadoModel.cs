namespace nfe.Models
{
	public class NfeNumeroInutilizadoModel
	{	
		public int? Id { get; set; } 

		public string? Serie { get; set; } 

		public int? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataInutilizacao { get; set; } 

		public string? Observacao { get; set; } 

	}
}
