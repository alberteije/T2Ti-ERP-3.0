namespace nfe.Models
{
	public class NfeDeclaracaoImportacaoModel
	{	
		public int? Id { get; set; } 

		public string? NumeroDocumento { get; set; } 

		public System.Nullable<System.DateTime> DataRegistro { get; set; } 

		public string? LocalDesembaraco { get; set; } 

		public string? UfDesembaraco { get; set; } 

		public System.Nullable<System.DateTime> DataDesembaraco { get; set; } 

		public string? ViaTransporte { get; set; } 

		public System.Nullable<System.Decimal> ValorAfrmm { get; set; } 

		public string? FormaIntermediacao { get; set; } 

		public string? Cnpj { get; set; } 

		public string? UfTerceiro { get; set; } 

		public string? CodigoExportador { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
