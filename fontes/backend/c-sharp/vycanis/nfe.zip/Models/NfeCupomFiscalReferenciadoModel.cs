namespace nfe.Models
{
	public class NfeCupomFiscalReferenciadoModel
	{	
		public int? Id { get; set; } 

		public string? ModeloDocumentoFiscal { get; set; } 

		public int? NumeroOrdemEcf { get; set; } 

		public int? Coo { get; set; } 

		public System.Nullable<System.DateTime> DataEmissaoCupom { get; set; } 

		public int? NumeroCaixa { get; set; } 

		public string? NumeroSerieEcf { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
