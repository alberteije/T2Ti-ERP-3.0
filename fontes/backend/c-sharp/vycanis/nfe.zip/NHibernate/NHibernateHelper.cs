﻿using NHibernate;
using NHibernate.Cfg;

public class NHibernateHelper
{
    private static ISessionFactory? SessionFactory;
    private static string? CurrentCnpj;
    private static readonly object Lock = new object();

    public static void SetCurrentCnpj(string cnpj)
    {
        lock (Lock)
        {
            if (CurrentCnpj != cnpj)
            {
                CurrentCnpj = cnpj;
                SessionFactory = null; // Força a recriação da SessionFactory na próxima chamada
            }
        }
    }

    public static ISessionFactory GetSessionFactory()
    {
        try
        {
            lock (Lock)
            {
                if (SessionFactory == null)
                {
                    if (CurrentCnpj == null)
                    {
                        throw new InvalidOperationException("CNPJ not set.");
                    }

                    Configuration config = new Configuration();
                    config.Configure(); // Carrega configurações padrão do hibernate.cfg.xml
                    config.AddAssembly("nfe");

                    // Atualiza a string de conexão
                    string connectionString = $"Server=localhost;Database={CurrentCnpj};Uid=root;Pwd=root;";
                    config.SetProperty(NHibernate.Cfg.Environment.ConnectionString, connectionString);

                    // Reconstrua a SessionFactory com a nova configuração
                    SessionFactory = config.BuildSessionFactory();
                }
                return SessionFactory;
            }
        }
        catch
        {
            throw;
        }
    }
}