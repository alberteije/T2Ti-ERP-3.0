using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeDetalheService
    {

        public IEnumerable<NfeDetalheModel> GetList()
        {
            IList<NfeDetalheModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDetalheModel> DAL = new NHibernateDAL<NfeDetalheModel>(Session);
                Result = DAL.Select(new NfeDetalheModel());
            }
            return Result;
        }

        public IEnumerable<NfeDetalheModel> GetListFilter(Filter filterObj)
        {
            IList<NfeDetalheModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeDetalheModel where " + filterObj.Where;
                NHibernateDAL<NfeDetalheModel> DAL = new NHibernateDAL<NfeDetalheModel>(Session);
                Result = DAL.SelectListSql<NfeDetalheModel>(Query);
            }
            return Result;
        }
		
        public NfeDetalheModel GetObject(int id)
        {
            NfeDetalheModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDetalheModel> DAL = new NHibernateDAL<NfeDetalheModel>(Session);
                Result = DAL.SelectId<NfeDetalheModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeDetalheModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDetalheModel> DAL = new NHibernateDAL<NfeDetalheModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeDetalheModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDetalheModel> DAL = new NHibernateDAL<NfeDetalheModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeDetalheModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDetalheModel> DAL = new NHibernateDAL<NfeDetalheModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}