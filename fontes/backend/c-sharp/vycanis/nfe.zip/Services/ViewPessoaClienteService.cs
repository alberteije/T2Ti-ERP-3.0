using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class ViewPessoaClienteService
    {

        public IEnumerable<ViewPessoaClienteModel> GetList()
        {
            IList<ViewPessoaClienteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaClienteModel> DAL = new NHibernateDAL<ViewPessoaClienteModel>(Session);
                Result = DAL.Select(new ViewPessoaClienteModel());
            }
            return Result;
        }

        public IEnumerable<ViewPessoaClienteModel> GetListFilter(Filter filterObj)
        {
            IList<ViewPessoaClienteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewPessoaClienteModel where " + filterObj.Where;
                NHibernateDAL<ViewPessoaClienteModel> DAL = new NHibernateDAL<ViewPessoaClienteModel>(Session);
                Result = DAL.SelectListSql<ViewPessoaClienteModel>(Query);
            }
            return Result;
        }
		
        public ViewPessoaClienteModel GetObject(int id)
        {
            ViewPessoaClienteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaClienteModel> DAL = new NHibernateDAL<ViewPessoaClienteModel>(Session);
                Result = DAL.SelectId<ViewPessoaClienteModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewPessoaClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaClienteModel> DAL = new NHibernateDAL<ViewPessoaClienteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewPessoaClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaClienteModel> DAL = new NHibernateDAL<ViewPessoaClienteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewPessoaClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaClienteModel> DAL = new NHibernateDAL<ViewPessoaClienteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}