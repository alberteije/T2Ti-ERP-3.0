using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeImportacaoDetalheService
    {

        public IEnumerable<NfeImportacaoDetalheModel> GetList()
        {
            IList<NfeImportacaoDetalheModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeImportacaoDetalheModel> DAL = new NHibernateDAL<NfeImportacaoDetalheModel>(Session);
                Result = DAL.Select(new NfeImportacaoDetalheModel());
            }
            return Result;
        }

        public IEnumerable<NfeImportacaoDetalheModel> GetListFilter(Filter filterObj)
        {
            IList<NfeImportacaoDetalheModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeImportacaoDetalheModel where " + filterObj.Where;
                NHibernateDAL<NfeImportacaoDetalheModel> DAL = new NHibernateDAL<NfeImportacaoDetalheModel>(Session);
                Result = DAL.SelectListSql<NfeImportacaoDetalheModel>(Query);
            }
            return Result;
        }
		
        public NfeImportacaoDetalheModel GetObject(int id)
        {
            NfeImportacaoDetalheModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeImportacaoDetalheModel> DAL = new NHibernateDAL<NfeImportacaoDetalheModel>(Session);
                Result = DAL.SelectId<NfeImportacaoDetalheModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeImportacaoDetalheModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeImportacaoDetalheModel> DAL = new NHibernateDAL<NfeImportacaoDetalheModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeImportacaoDetalheModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeImportacaoDetalheModel> DAL = new NHibernateDAL<NfeImportacaoDetalheModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeImportacaoDetalheModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeImportacaoDetalheModel> DAL = new NHibernateDAL<NfeImportacaoDetalheModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}