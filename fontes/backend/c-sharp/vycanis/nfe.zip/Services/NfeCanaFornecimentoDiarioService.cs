using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeCanaFornecimentoDiarioService
    {

        public IEnumerable<NfeCanaFornecimentoDiarioModel> GetList()
        {
            IList<NfeCanaFornecimentoDiarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaFornecimentoDiarioModel> DAL = new NHibernateDAL<NfeCanaFornecimentoDiarioModel>(Session);
                Result = DAL.Select(new NfeCanaFornecimentoDiarioModel());
            }
            return Result;
        }

        public IEnumerable<NfeCanaFornecimentoDiarioModel> GetListFilter(Filter filterObj)
        {
            IList<NfeCanaFornecimentoDiarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeCanaFornecimentoDiarioModel where " + filterObj.Where;
                NHibernateDAL<NfeCanaFornecimentoDiarioModel> DAL = new NHibernateDAL<NfeCanaFornecimentoDiarioModel>(Session);
                Result = DAL.SelectListSql<NfeCanaFornecimentoDiarioModel>(Query);
            }
            return Result;
        }
		
        public NfeCanaFornecimentoDiarioModel GetObject(int id)
        {
            NfeCanaFornecimentoDiarioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaFornecimentoDiarioModel> DAL = new NHibernateDAL<NfeCanaFornecimentoDiarioModel>(Session);
                Result = DAL.SelectId<NfeCanaFornecimentoDiarioModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeCanaFornecimentoDiarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaFornecimentoDiarioModel> DAL = new NHibernateDAL<NfeCanaFornecimentoDiarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeCanaFornecimentoDiarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaFornecimentoDiarioModel> DAL = new NHibernateDAL<NfeCanaFornecimentoDiarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeCanaFornecimentoDiarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaFornecimentoDiarioModel> DAL = new NHibernateDAL<NfeCanaFornecimentoDiarioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}