using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeCanaDeducoesSafraService
    {

        public IEnumerable<NfeCanaDeducoesSafraModel> GetList()
        {
            IList<NfeCanaDeducoesSafraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaDeducoesSafraModel> DAL = new NHibernateDAL<NfeCanaDeducoesSafraModel>(Session);
                Result = DAL.Select(new NfeCanaDeducoesSafraModel());
            }
            return Result;
        }

        public IEnumerable<NfeCanaDeducoesSafraModel> GetListFilter(Filter filterObj)
        {
            IList<NfeCanaDeducoesSafraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeCanaDeducoesSafraModel where " + filterObj.Where;
                NHibernateDAL<NfeCanaDeducoesSafraModel> DAL = new NHibernateDAL<NfeCanaDeducoesSafraModel>(Session);
                Result = DAL.SelectListSql<NfeCanaDeducoesSafraModel>(Query);
            }
            return Result;
        }
		
        public NfeCanaDeducoesSafraModel GetObject(int id)
        {
            NfeCanaDeducoesSafraModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaDeducoesSafraModel> DAL = new NHibernateDAL<NfeCanaDeducoesSafraModel>(Session);
                Result = DAL.SelectId<NfeCanaDeducoesSafraModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeCanaDeducoesSafraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaDeducoesSafraModel> DAL = new NHibernateDAL<NfeCanaDeducoesSafraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeCanaDeducoesSafraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaDeducoesSafraModel> DAL = new NHibernateDAL<NfeCanaDeducoesSafraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeCanaDeducoesSafraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCanaDeducoesSafraModel> DAL = new NHibernateDAL<NfeCanaDeducoesSafraModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}