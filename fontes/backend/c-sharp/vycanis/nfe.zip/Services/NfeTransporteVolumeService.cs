using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeTransporteVolumeService
    {

        public IEnumerable<NfeTransporteVolumeModel> GetList()
        {
            IList<NfeTransporteVolumeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeModel> DAL = new NHibernateDAL<NfeTransporteVolumeModel>(Session);
                Result = DAL.Select(new NfeTransporteVolumeModel());
            }
            return Result;
        }

        public IEnumerable<NfeTransporteVolumeModel> GetListFilter(Filter filterObj)
        {
            IList<NfeTransporteVolumeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeTransporteVolumeModel where " + filterObj.Where;
                NHibernateDAL<NfeTransporteVolumeModel> DAL = new NHibernateDAL<NfeTransporteVolumeModel>(Session);
                Result = DAL.SelectListSql<NfeTransporteVolumeModel>(Query);
            }
            return Result;
        }
		
        public NfeTransporteVolumeModel GetObject(int id)
        {
            NfeTransporteVolumeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeModel> DAL = new NHibernateDAL<NfeTransporteVolumeModel>(Session);
                Result = DAL.SelectId<NfeTransporteVolumeModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeTransporteVolumeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeModel> DAL = new NHibernateDAL<NfeTransporteVolumeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeTransporteVolumeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeModel> DAL = new NHibernateDAL<NfeTransporteVolumeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeTransporteVolumeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeModel> DAL = new NHibernateDAL<NfeTransporteVolumeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}