using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeNumeroInutilizadoService
    {

        public IEnumerable<NfeNumeroInutilizadoModel> GetList()
        {
            IList<NfeNumeroInutilizadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroInutilizadoModel> DAL = new NHibernateDAL<NfeNumeroInutilizadoModel>(Session);
                Result = DAL.Select(new NfeNumeroInutilizadoModel());
            }
            return Result;
        }

        public IEnumerable<NfeNumeroInutilizadoModel> GetListFilter(Filter filterObj)
        {
            IList<NfeNumeroInutilizadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeNumeroInutilizadoModel where " + filterObj.Where;
                NHibernateDAL<NfeNumeroInutilizadoModel> DAL = new NHibernateDAL<NfeNumeroInutilizadoModel>(Session);
                Result = DAL.SelectListSql<NfeNumeroInutilizadoModel>(Query);
            }
            return Result;
        }
		
        public NfeNumeroInutilizadoModel GetObject(int id)
        {
            NfeNumeroInutilizadoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroInutilizadoModel> DAL = new NHibernateDAL<NfeNumeroInutilizadoModel>(Session);
                Result = DAL.SelectId<NfeNumeroInutilizadoModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeNumeroInutilizadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroInutilizadoModel> DAL = new NHibernateDAL<NfeNumeroInutilizadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeNumeroInutilizadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroInutilizadoModel> DAL = new NHibernateDAL<NfeNumeroInutilizadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeNumeroInutilizadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroInutilizadoModel> DAL = new NHibernateDAL<NfeNumeroInutilizadoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}