using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeDuplicataService
    {

        public IEnumerable<NfeDuplicataModel> GetList()
        {
            IList<NfeDuplicataModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDuplicataModel> DAL = new NHibernateDAL<NfeDuplicataModel>(Session);
                Result = DAL.Select(new NfeDuplicataModel());
            }
            return Result;
        }

        public IEnumerable<NfeDuplicataModel> GetListFilter(Filter filterObj)
        {
            IList<NfeDuplicataModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeDuplicataModel where " + filterObj.Where;
                NHibernateDAL<NfeDuplicataModel> DAL = new NHibernateDAL<NfeDuplicataModel>(Session);
                Result = DAL.SelectListSql<NfeDuplicataModel>(Query);
            }
            return Result;
        }
		
        public NfeDuplicataModel GetObject(int id)
        {
            NfeDuplicataModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDuplicataModel> DAL = new NHibernateDAL<NfeDuplicataModel>(Session);
                Result = DAL.SelectId<NfeDuplicataModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeDuplicataModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDuplicataModel> DAL = new NHibernateDAL<NfeDuplicataModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeDuplicataModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDuplicataModel> DAL = new NHibernateDAL<NfeDuplicataModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeDuplicataModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeDuplicataModel> DAL = new NHibernateDAL<NfeDuplicataModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}