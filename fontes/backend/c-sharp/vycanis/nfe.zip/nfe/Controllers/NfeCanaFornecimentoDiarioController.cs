using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-cana-fornecimento-diario")]
    [Produces("application/json")]
    public class NfeCanaFornecimentoDiarioController : Controller
    {
		private readonly NfeCanaFornecimentoDiarioService _service;

        public NfeCanaFornecimentoDiarioController()
        {
            _service = new NfeCanaFornecimentoDiarioService();
        }

        [HttpGet]
        public IActionResult GetListNfeCanaFornecimentoDiario([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeCanaFornecimentoDiarioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeCanaFornecimentoDiario]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeCanaFornecimentoDiario")]
        public IActionResult GetObjectNfeCanaFornecimentoDiario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeCanaFornecimentoDiario]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeCanaFornecimentoDiario]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeCanaFornecimentoDiario([FromBody]NfeCanaFornecimentoDiarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeCanaFornecimentoDiario]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeCanaFornecimentoDiario", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeCanaFornecimentoDiario]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeCanaFornecimentoDiario([FromBody]NfeCanaFornecimentoDiarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeCanaFornecimentoDiario]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeCanaFornecimentoDiario(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeCanaFornecimentoDiario]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeCanaFornecimentoDiario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeCanaFornecimentoDiario]", ex));
            }
        }

    }
}