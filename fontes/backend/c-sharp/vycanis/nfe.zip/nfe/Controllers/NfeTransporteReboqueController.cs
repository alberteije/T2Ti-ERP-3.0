using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-transporte-reboque")]
    [Produces("application/json")]
    public class NfeTransporteReboqueController : Controller
    {
		private readonly NfeTransporteReboqueService _service;

        public NfeTransporteReboqueController()
        {
            _service = new NfeTransporteReboqueService();
        }

        [HttpGet]
        public IActionResult GetListNfeTransporteReboque([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeTransporteReboqueModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeTransporteReboque]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeTransporteReboque")]
        public IActionResult GetObjectNfeTransporteReboque(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeTransporteReboque]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeTransporteReboque]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeTransporteReboque([FromBody]NfeTransporteReboqueModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeTransporteReboque]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeTransporteReboque", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeTransporteReboque]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeTransporteReboque([FromBody]NfeTransporteReboqueModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeTransporteReboque]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeTransporteReboque(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeTransporteReboque]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeTransporteReboque(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeTransporteReboque]", ex));
            }
        }

    }
}