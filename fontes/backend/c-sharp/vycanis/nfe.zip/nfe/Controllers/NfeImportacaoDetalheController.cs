using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-importacao-detalhe")]
    [Produces("application/json")]
    public class NfeImportacaoDetalheController : Controller
    {
		private readonly NfeImportacaoDetalheService _service;

        public NfeImportacaoDetalheController()
        {
            _service = new NfeImportacaoDetalheService();
        }

        [HttpGet]
        public IActionResult GetListNfeImportacaoDetalhe([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeImportacaoDetalheModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeImportacaoDetalhe]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeImportacaoDetalhe")]
        public IActionResult GetObjectNfeImportacaoDetalhe(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeImportacaoDetalhe]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeImportacaoDetalhe]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeImportacaoDetalhe([FromBody]NfeImportacaoDetalheModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeImportacaoDetalhe]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeImportacaoDetalhe", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeImportacaoDetalhe]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeImportacaoDetalhe([FromBody]NfeImportacaoDetalheModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeImportacaoDetalhe]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeImportacaoDetalhe(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeImportacaoDetalhe]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeImportacaoDetalhe(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeImportacaoDetalhe]", ex));
            }
        }

    }
}