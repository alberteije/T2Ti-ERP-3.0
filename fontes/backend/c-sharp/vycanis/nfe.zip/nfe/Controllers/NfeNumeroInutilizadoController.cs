using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-numero-inutilizado")]
    [Produces("application/json")]
    public class NfeNumeroInutilizadoController : Controller
    {
		private readonly NfeNumeroInutilizadoService _service;

        public NfeNumeroInutilizadoController()
        {
            _service = new NfeNumeroInutilizadoService();
        }

        [HttpGet]
        public IActionResult GetListNfeNumeroInutilizado([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeNumeroInutilizadoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeNumeroInutilizado]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeNumeroInutilizado")]
        public IActionResult GetObjectNfeNumeroInutilizado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeNumeroInutilizado]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeNumeroInutilizado]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeNumeroInutilizado([FromBody]NfeNumeroInutilizadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeNumeroInutilizado]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeNumeroInutilizado", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeNumeroInutilizado]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeNumeroInutilizado([FromBody]NfeNumeroInutilizadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeNumeroInutilizado]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeNumeroInutilizado(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeNumeroInutilizado]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeNumeroInutilizado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeNumeroInutilizado]", ex));
            }
        }

    }
}