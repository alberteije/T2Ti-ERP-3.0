using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-numero")]
    [Produces("application/json")]
    public class NfeNumeroController : Controller
    {
		private readonly NfeNumeroService _service;

        public NfeNumeroController()
        {
            _service = new NfeNumeroService();
        }

        [HttpGet]
        public IActionResult GetListNfeNumero([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeNumeroModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeNumero]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeNumero")]
        public IActionResult GetObjectNfeNumero(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeNumero]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeNumero]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeNumero([FromBody]NfeNumeroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeNumero]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeNumero", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeNumero]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeNumero([FromBody]NfeNumeroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeNumero]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeNumero(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeNumero]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeNumero(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeNumero]", ex));
            }
        }

    }
}