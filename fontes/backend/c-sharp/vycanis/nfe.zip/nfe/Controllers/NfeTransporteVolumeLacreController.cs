using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-transporte-volume-lacre")]
    [Produces("application/json")]
    public class NfeTransporteVolumeLacreController : Controller
    {
		private readonly NfeTransporteVolumeLacreService _service;

        public NfeTransporteVolumeLacreController()
        {
            _service = new NfeTransporteVolumeLacreService();
        }

        [HttpGet]
        public IActionResult GetListNfeTransporteVolumeLacre([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeTransporteVolumeLacreModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeTransporteVolumeLacre]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeTransporteVolumeLacre")]
        public IActionResult GetObjectNfeTransporteVolumeLacre(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeTransporteVolumeLacre]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeTransporteVolumeLacre]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeTransporteVolumeLacre([FromBody]NfeTransporteVolumeLacreModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeTransporteVolumeLacre]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeTransporteVolumeLacre", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeTransporteVolumeLacre]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeTransporteVolumeLacre([FromBody]NfeTransporteVolumeLacreModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeTransporteVolumeLacre]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeTransporteVolumeLacre(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeTransporteVolumeLacre]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeTransporteVolumeLacre(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeTransporteVolumeLacre]", ex));
            }
        }

    }
}