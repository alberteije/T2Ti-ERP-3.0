using Microsoft.AspNetCore.Mvc;
using nfe.Models;
using nfe.Services;

namespace nfe.Controllers
{
    [Route("nfe-cabecalho")]
    [Produces("application/json")]
    public class NfeCabecalhoController : Controller
    {
		private readonly NfeCabecalhoService _service;

        public NfeCabecalhoController()
        {
            _service = new NfeCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListNfeCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfeCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfeCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfeCabecalho")]
        public IActionResult GetObjectNfeCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfeCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfeCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfeCabecalho([FromBody]NfeCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfeCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfeCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfeCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfeCabecalho([FromBody]NfeCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfeCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectNfeCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfeCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfeCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfeCabecalho]", ex));
            }
        }

    }
}