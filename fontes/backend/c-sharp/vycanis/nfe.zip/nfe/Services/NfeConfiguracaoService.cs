using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeConfiguracaoService
    {

        public IEnumerable<NfeConfiguracaoModel> GetList()
        {
            IList<NfeConfiguracaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeConfiguracaoModel> DAL = new NHibernateDAL<NfeConfiguracaoModel>(Session);
                Result = DAL.Select(new NfeConfiguracaoModel());
            }
            return Result;
        }

        public IEnumerable<NfeConfiguracaoModel> GetListFilter(Filter filterObj)
        {
            IList<NfeConfiguracaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeConfiguracaoModel where " + filterObj.Where;
                NHibernateDAL<NfeConfiguracaoModel> DAL = new NHibernateDAL<NfeConfiguracaoModel>(Session);
                Result = DAL.SelectListSql<NfeConfiguracaoModel>(Query);
            }
            return Result;
        }
		
        public NfeConfiguracaoModel GetObject(int id)
        {
            NfeConfiguracaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeConfiguracaoModel> DAL = new NHibernateDAL<NfeConfiguracaoModel>(Session);
                Result = DAL.SelectId<NfeConfiguracaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeConfiguracaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeConfiguracaoModel> DAL = new NHibernateDAL<NfeConfiguracaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeConfiguracaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeConfiguracaoModel> DAL = new NHibernateDAL<NfeConfiguracaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeConfiguracaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeConfiguracaoModel> DAL = new NHibernateDAL<NfeConfiguracaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}