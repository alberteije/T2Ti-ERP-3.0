using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class ViewPessoaFornecedorService
    {

        public IEnumerable<ViewPessoaFornecedorModel> GetList()
        {
            IList<ViewPessoaFornecedorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaFornecedorModel> DAL = new NHibernateDAL<ViewPessoaFornecedorModel>(Session);
                Result = DAL.Select(new ViewPessoaFornecedorModel());
            }
            return Result;
        }

        public IEnumerable<ViewPessoaFornecedorModel> GetListFilter(Filter filterObj)
        {
            IList<ViewPessoaFornecedorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewPessoaFornecedorModel where " + filterObj.Where;
                NHibernateDAL<ViewPessoaFornecedorModel> DAL = new NHibernateDAL<ViewPessoaFornecedorModel>(Session);
                Result = DAL.SelectListSql<ViewPessoaFornecedorModel>(Query);
            }
            return Result;
        }
		
        public ViewPessoaFornecedorModel GetObject(int id)
        {
            ViewPessoaFornecedorModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaFornecedorModel> DAL = new NHibernateDAL<ViewPessoaFornecedorModel>(Session);
                Result = DAL.SelectId<ViewPessoaFornecedorModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewPessoaFornecedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaFornecedorModel> DAL = new NHibernateDAL<ViewPessoaFornecedorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewPessoaFornecedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaFornecedorModel> DAL = new NHibernateDAL<ViewPessoaFornecedorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewPessoaFornecedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaFornecedorModel> DAL = new NHibernateDAL<ViewPessoaFornecedorModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}