using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeTransporteVolumeLacreService
    {

        public IEnumerable<NfeTransporteVolumeLacreModel> GetList()
        {
            IList<NfeTransporteVolumeLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeLacreModel> DAL = new NHibernateDAL<NfeTransporteVolumeLacreModel>(Session);
                Result = DAL.Select(new NfeTransporteVolumeLacreModel());
            }
            return Result;
        }

        public IEnumerable<NfeTransporteVolumeLacreModel> GetListFilter(Filter filterObj)
        {
            IList<NfeTransporteVolumeLacreModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeTransporteVolumeLacreModel where " + filterObj.Where;
                NHibernateDAL<NfeTransporteVolumeLacreModel> DAL = new NHibernateDAL<NfeTransporteVolumeLacreModel>(Session);
                Result = DAL.SelectListSql<NfeTransporteVolumeLacreModel>(Query);
            }
            return Result;
        }
		
        public NfeTransporteVolumeLacreModel GetObject(int id)
        {
            NfeTransporteVolumeLacreModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeLacreModel> DAL = new NHibernateDAL<NfeTransporteVolumeLacreModel>(Session);
                Result = DAL.SelectId<NfeTransporteVolumeLacreModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeTransporteVolumeLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeLacreModel> DAL = new NHibernateDAL<NfeTransporteVolumeLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeTransporteVolumeLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeLacreModel> DAL = new NHibernateDAL<NfeTransporteVolumeLacreModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeTransporteVolumeLacreModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteVolumeLacreModel> DAL = new NHibernateDAL<NfeTransporteVolumeLacreModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}