using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeTransporteReboqueService
    {

        public IEnumerable<NfeTransporteReboqueModel> GetList()
        {
            IList<NfeTransporteReboqueModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteReboqueModel> DAL = new NHibernateDAL<NfeTransporteReboqueModel>(Session);
                Result = DAL.Select(new NfeTransporteReboqueModel());
            }
            return Result;
        }

        public IEnumerable<NfeTransporteReboqueModel> GetListFilter(Filter filterObj)
        {
            IList<NfeTransporteReboqueModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeTransporteReboqueModel where " + filterObj.Where;
                NHibernateDAL<NfeTransporteReboqueModel> DAL = new NHibernateDAL<NfeTransporteReboqueModel>(Session);
                Result = DAL.SelectListSql<NfeTransporteReboqueModel>(Query);
            }
            return Result;
        }
		
        public NfeTransporteReboqueModel GetObject(int id)
        {
            NfeTransporteReboqueModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteReboqueModel> DAL = new NHibernateDAL<NfeTransporteReboqueModel>(Session);
                Result = DAL.SelectId<NfeTransporteReboqueModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeTransporteReboqueModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteReboqueModel> DAL = new NHibernateDAL<NfeTransporteReboqueModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeTransporteReboqueModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteReboqueModel> DAL = new NHibernateDAL<NfeTransporteReboqueModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeTransporteReboqueModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeTransporteReboqueModel> DAL = new NHibernateDAL<NfeTransporteReboqueModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}