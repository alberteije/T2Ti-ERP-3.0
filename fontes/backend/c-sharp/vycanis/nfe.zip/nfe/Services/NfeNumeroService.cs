using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class NfeNumeroService
    {

        public IEnumerable<NfeNumeroModel> GetList()
        {
            IList<NfeNumeroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroModel> DAL = new NHibernateDAL<NfeNumeroModel>(Session);
                Result = DAL.Select(new NfeNumeroModel());
            }
            return Result;
        }

        public IEnumerable<NfeNumeroModel> GetListFilter(Filter filterObj)
        {
            IList<NfeNumeroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeNumeroModel where " + filterObj.Where;
                NHibernateDAL<NfeNumeroModel> DAL = new NHibernateDAL<NfeNumeroModel>(Session);
                Result = DAL.SelectListSql<NfeNumeroModel>(Query);
            }
            return Result;
        }
		
        public NfeNumeroModel GetObject(int id)
        {
            NfeNumeroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroModel> DAL = new NHibernateDAL<NfeNumeroModel>(Session);
                Result = DAL.SelectId<NfeNumeroModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeNumeroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroModel> DAL = new NHibernateDAL<NfeNumeroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeNumeroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroModel> DAL = new NHibernateDAL<NfeNumeroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeNumeroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeNumeroModel> DAL = new NHibernateDAL<NfeNumeroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}