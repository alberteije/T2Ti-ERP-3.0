using nfe.Models;
using nfe.NHibernate;
using ISession = NHibernate.ISession;

namespace nfe.Services
{
    public class VendaCabecalhoService
    {

        public IEnumerable<VendaCabecalhoModel> GetList()
        {
            IList<VendaCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCabecalhoModel> DAL = new NHibernateDAL<VendaCabecalhoModel>(Session);
                Result = DAL.Select(new VendaCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<VendaCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<VendaCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from VendaCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<VendaCabecalhoModel> DAL = new NHibernateDAL<VendaCabecalhoModel>(Session);
                Result = DAL.SelectListSql<VendaCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public VendaCabecalhoModel GetObject(int id)
        {
            VendaCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCabecalhoModel> DAL = new NHibernateDAL<VendaCabecalhoModel>(Session);
                Result = DAL.SelectId<VendaCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(VendaCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCabecalhoModel> DAL = new NHibernateDAL<VendaCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(VendaCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCabecalhoModel> DAL = new NHibernateDAL<VendaCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(VendaCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<VendaCabecalhoModel> DAL = new NHibernateDAL<VendaCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}