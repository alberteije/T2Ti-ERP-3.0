namespace nfe.Models
{
	public class NfeDetalheImpostoIpiModel
	{	
		public int? Id { get; set; } 

		public string? CnpjProdutor { get; set; } 

		public string? CodigoSeloIpi { get; set; } 

		public int? QuantidadeSeloIpi { get; set; } 

		public string? EnquadramentoLegalIpi { get; set; } 

		public string? CstIpi { get; set; } 

		public System.Nullable<System.Decimal> ValorBaseCalculoIpi { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeUnidadeTributavel { get; set; } 

		public System.Nullable<System.Decimal> ValorUnidadeTributavel { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIpi { get; set; } 

		public System.Nullable<System.Decimal> ValorIpi { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
