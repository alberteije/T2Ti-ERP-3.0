namespace nfe.Models
{
	public class NfeCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? UfEmitente { get; set; } 

		public string? CodigoNumerico { get; set; } 

		public string? NaturezaOperacao { get; set; } 

		public string? CodigoModelo { get; set; } 

		public string? Serie { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataHoraEmissao { get; set; } 

		public System.Nullable<System.DateTime> DataHoraEntradaSaida { get; set; } 

		public string? TipoOperacao { get; set; } 

		public string? LocalDestino { get; set; } 

		public int? CodigoMunicipio { get; set; } 

		public string? FormatoImpressaoDanfe { get; set; } 

		public string? TipoEmissao { get; set; } 

		public string? ChaveAcesso { get; set; } 

		public string? DigitoChaveAcesso { get; set; } 

		public string? Ambiente { get; set; } 

		public string? FinalidadeEmissao { get; set; } 

		public string? ConsumidorOperacao { get; set; } 

		public string? ConsumidorPresenca { get; set; } 

		public string? ProcessoEmissao { get; set; } 

		public string? VersaoProcessoEmissao { get; set; } 

		public System.Nullable<System.DateTime> DataEntradaContingencia { get; set; } 

		public string? JustificativaContingencia { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsDesonerado { get; set; } 

		public System.Nullable<System.Decimal> TotalIcmsFcpUfDestino { get; set; } 

		public System.Nullable<System.Decimal> TotalIcmsInterestadualUfDestino { get; set; } 

		public System.Nullable<System.Decimal> TotalIcmsInterestadualUfRemetente { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalFcp { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalFcpSt { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalFcpStRetido { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalProdutos { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public System.Nullable<System.Decimal> ValorSeguro { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorImpostoImportacao { get; set; } 

		public System.Nullable<System.Decimal> ValorIpi { get; set; } 

		public System.Nullable<System.Decimal> ValorIpiDevolvido { get; set; } 

		public System.Nullable<System.Decimal> ValorPis { get; set; } 

		public System.Nullable<System.Decimal> ValorCofins { get; set; } 

		public System.Nullable<System.Decimal> ValorDespesasAcessorias { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalTributos { get; set; } 

		public System.Nullable<System.Decimal> ValorServicos { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIssqn { get; set; } 

		public System.Nullable<System.Decimal> ValorIssqn { get; set; } 

		public System.Nullable<System.Decimal> ValorPisIssqn { get; set; } 

		public System.Nullable<System.Decimal> ValorCofinsIssqn { get; set; } 

		public System.Nullable<System.DateTime> DataPrestacaoServico { get; set; } 

		public System.Nullable<System.Decimal> ValorDeducaoIssqn { get; set; } 

		public System.Nullable<System.Decimal> OutrasRetencoesIssqn { get; set; } 

		public System.Nullable<System.Decimal> DescontoIncondicionadoIssqn { get; set; } 

		public System.Nullable<System.Decimal> DescontoCondicionadoIssqn { get; set; } 

		public System.Nullable<System.Decimal> TotalRetencaoIssqn { get; set; } 

		public string? RegimeEspecialTributacao { get; set; } 

		public System.Nullable<System.Decimal> ValorRetidoPis { get; set; } 

		public System.Nullable<System.Decimal> ValorRetidoCofins { get; set; } 

		public System.Nullable<System.Decimal> ValorRetidoCsll { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIrrf { get; set; } 

		public System.Nullable<System.Decimal> ValorRetidoIrrf { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoPrevidencia { get; set; } 

		public System.Nullable<System.Decimal> ValorRetidoPrevidencia { get; set; } 

		public string? InformacoesAddFisco { get; set; } 

		public string? InformacoesAddContribuinte { get; set; } 

		public string? ComexUfEmbarque { get; set; } 

		public string? ComexLocalEmbarque { get; set; } 

		public string? ComexLocalDespacho { get; set; } 

		public string? CompraNotaEmpenho { get; set; } 

		public string? CompraPedido { get; set; } 

		public string? CompraContrato { get; set; } 

		public string? Qrcode { get; set; } 

		public string? UrlChave { get; set; } 

		public string? StatusNota { get; set; } 

		public TributOperacaoFiscalModel? TributOperacaoFiscalModel { get; set; } 

		public VendaCabecalhoModel? VendaCabecalhoModel { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public ViewPessoaFornecedorModel? ViewPessoaFornecedorModel { get; set; } 

		private IList<NfeReferenciadaModel>? nfeReferenciadaModelList; 
		public IList<NfeReferenciadaModel>? NfeReferenciadaModelList 
		{ 
			get 
			{ 
				return nfeReferenciadaModelList; 
			} 
			set 
			{ 
				nfeReferenciadaModelList = value; 
				foreach (NfeReferenciadaModel nfeReferenciadaModel in nfeReferenciadaModelList!) 
				{ 
					nfeReferenciadaModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeEmitenteModel>? nfeEmitenteModelList; 
		public IList<NfeEmitenteModel>? NfeEmitenteModelList 
		{ 
			get 
			{ 
				return nfeEmitenteModelList; 
			} 
			set 
			{ 
				nfeEmitenteModelList = value; 
				foreach (NfeEmitenteModel nfeEmitenteModel in nfeEmitenteModelList!) 
				{ 
					nfeEmitenteModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeDestinatarioModel>? nfeDestinatarioModelList; 
		public IList<NfeDestinatarioModel>? NfeDestinatarioModelList 
		{ 
			get 
			{ 
				return nfeDestinatarioModelList; 
			} 
			set 
			{ 
				nfeDestinatarioModelList = value; 
				foreach (NfeDestinatarioModel nfeDestinatarioModel in nfeDestinatarioModelList!) 
				{ 
					nfeDestinatarioModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeLocalRetiradaModel>? nfeLocalRetiradaModelList; 
		public IList<NfeLocalRetiradaModel>? NfeLocalRetiradaModelList 
		{ 
			get 
			{ 
				return nfeLocalRetiradaModelList; 
			} 
			set 
			{ 
				nfeLocalRetiradaModelList = value; 
				foreach (NfeLocalRetiradaModel nfeLocalRetiradaModel in nfeLocalRetiradaModelList!) 
				{ 
					nfeLocalRetiradaModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeLocalEntregaModel>? nfeLocalEntregaModelList; 
		public IList<NfeLocalEntregaModel>? NfeLocalEntregaModelList 
		{ 
			get 
			{ 
				return nfeLocalEntregaModelList; 
			} 
			set 
			{ 
				nfeLocalEntregaModelList = value; 
				foreach (NfeLocalEntregaModel nfeLocalEntregaModel in nfeLocalEntregaModelList!) 
				{ 
					nfeLocalEntregaModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeTransporteModel>? nfeTransporteModelList; 
		public IList<NfeTransporteModel>? NfeTransporteModelList 
		{ 
			get 
			{ 
				return nfeTransporteModelList; 
			} 
			set 
			{ 
				nfeTransporteModelList = value; 
				foreach (NfeTransporteModel nfeTransporteModel in nfeTransporteModelList!) 
				{ 
					nfeTransporteModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeFaturaModel>? nfeFaturaModelList; 
		public IList<NfeFaturaModel>? NfeFaturaModelList 
		{ 
			get 
			{ 
				return nfeFaturaModelList; 
			} 
			set 
			{ 
				nfeFaturaModelList = value; 
				foreach (NfeFaturaModel nfeFaturaModel in nfeFaturaModelList!) 
				{ 
					nfeFaturaModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeCanaModel>? nfeCanaModelList; 
		public IList<NfeCanaModel>? NfeCanaModelList 
		{ 
			get 
			{ 
				return nfeCanaModelList; 
			} 
			set 
			{ 
				nfeCanaModelList = value; 
				foreach (NfeCanaModel nfeCanaModel in nfeCanaModelList!) 
				{ 
					nfeCanaModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeProdRuralReferenciadaModel>? nfeProdRuralReferenciadaModelList; 
		public IList<NfeProdRuralReferenciadaModel>? NfeProdRuralReferenciadaModelList 
		{ 
			get 
			{ 
				return nfeProdRuralReferenciadaModelList; 
			} 
			set 
			{ 
				nfeProdRuralReferenciadaModelList = value; 
				foreach (NfeProdRuralReferenciadaModel nfeProdRuralReferenciadaModel in nfeProdRuralReferenciadaModelList!) 
				{ 
					nfeProdRuralReferenciadaModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeNfReferenciadaModel>? nfeNfReferenciadaModelList; 
		public IList<NfeNfReferenciadaModel>? NfeNfReferenciadaModelList 
		{ 
			get 
			{ 
				return nfeNfReferenciadaModelList; 
			} 
			set 
			{ 
				nfeNfReferenciadaModelList = value; 
				foreach (NfeNfReferenciadaModel nfeNfReferenciadaModel in nfeNfReferenciadaModelList!) 
				{ 
					nfeNfReferenciadaModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeProcessoReferenciadoModel>? nfeProcessoReferenciadoModelList; 
		public IList<NfeProcessoReferenciadoModel>? NfeProcessoReferenciadoModelList 
		{ 
			get 
			{ 
				return nfeProcessoReferenciadoModelList; 
			} 
			set 
			{ 
				nfeProcessoReferenciadoModelList = value; 
				foreach (NfeProcessoReferenciadoModel nfeProcessoReferenciadoModel in nfeProcessoReferenciadoModelList!) 
				{ 
					nfeProcessoReferenciadoModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeAcessoXmlModel>? nfeAcessoXmlModelList; 
		public IList<NfeAcessoXmlModel>? NfeAcessoXmlModelList 
		{ 
			get 
			{ 
				return nfeAcessoXmlModelList; 
			} 
			set 
			{ 
				nfeAcessoXmlModelList = value; 
				foreach (NfeAcessoXmlModel nfeAcessoXmlModel in nfeAcessoXmlModelList!) 
				{ 
					nfeAcessoXmlModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeInformacaoPagamentoModel>? nfeInformacaoPagamentoModelList; 
		public IList<NfeInformacaoPagamentoModel>? NfeInformacaoPagamentoModelList 
		{ 
			get 
			{ 
				return nfeInformacaoPagamentoModelList; 
			} 
			set 
			{ 
				nfeInformacaoPagamentoModelList = value; 
				foreach (NfeInformacaoPagamentoModel nfeInformacaoPagamentoModel in nfeInformacaoPagamentoModelList!) 
				{ 
					nfeInformacaoPagamentoModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeResponsavelTecnicoModel>? nfeResponsavelTecnicoModelList; 
		public IList<NfeResponsavelTecnicoModel>? NfeResponsavelTecnicoModelList 
		{ 
			get 
			{ 
				return nfeResponsavelTecnicoModelList; 
			} 
			set 
			{ 
				nfeResponsavelTecnicoModelList = value; 
				foreach (NfeResponsavelTecnicoModel nfeResponsavelTecnicoModel in nfeResponsavelTecnicoModelList!) 
				{ 
					nfeResponsavelTecnicoModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeCteReferenciadoModel>? nfeCteReferenciadoModelList; 
		public IList<NfeCteReferenciadoModel>? NfeCteReferenciadoModelList 
		{ 
			get 
			{ 
				return nfeCteReferenciadoModelList; 
			} 
			set 
			{ 
				nfeCteReferenciadoModelList = value; 
				foreach (NfeCteReferenciadoModel nfeCteReferenciadoModel in nfeCteReferenciadoModelList!) 
				{ 
					nfeCteReferenciadoModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfeCupomFiscalReferenciadoModel>? nfeCupomFiscalReferenciadoModelList; 
		public IList<NfeCupomFiscalReferenciadoModel>? NfeCupomFiscalReferenciadoModelList 
		{ 
			get 
			{ 
				return nfeCupomFiscalReferenciadoModelList; 
			} 
			set 
			{ 
				nfeCupomFiscalReferenciadoModelList = value; 
				foreach (NfeCupomFiscalReferenciadoModel nfeCupomFiscalReferenciadoModel in nfeCupomFiscalReferenciadoModelList!) 
				{ 
					nfeCupomFiscalReferenciadoModel.NfeCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
