namespace nfe.Models
{
	public class NfeDetEspecificoMedicamentoModel
	{	
		public int? Id { get; set; } 

		public string? CodigoAnvisa { get; set; } 

		public string? MotivoIsencao { get; set; } 

		public System.Nullable<System.Decimal> PrecoMaximoConsumidor { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
