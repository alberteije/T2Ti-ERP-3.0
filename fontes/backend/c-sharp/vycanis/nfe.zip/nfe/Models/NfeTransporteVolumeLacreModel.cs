namespace nfe.Models
{
	public class NfeTransporteVolumeLacreModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public NfeTransporteVolumeModel? NfeTransporteVolumeModel { get; set; } 

	}
}
