namespace nfe.Models
{
	public class NfeCanaFornecimentoDiarioModel
	{	
		public int? Id { get; set; } 

		public string? Dia { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeTotalMes { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeTotalAnterior { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeTotalGeral { get; set; } 

		public NfeCanaModel? NfeCanaModel { get; set; } 

	}
}
