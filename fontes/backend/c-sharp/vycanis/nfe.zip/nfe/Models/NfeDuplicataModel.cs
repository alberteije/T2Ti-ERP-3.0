namespace nfe.Models
{
	public class NfeDuplicataModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataVencimento { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public NfeFaturaModel? NfeFaturaModel { get; set; } 

	}
}
