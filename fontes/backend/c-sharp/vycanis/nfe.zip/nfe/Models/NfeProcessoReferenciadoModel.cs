namespace nfe.Models
{
	public class NfeProcessoReferenciadoModel
	{	
		public int? Id { get; set; } 

		public string? Identificador { get; set; } 

		public string? Origem { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
