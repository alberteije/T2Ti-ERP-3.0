namespace nfe.Models
{
	public class NfeResponsavelTecnicoModel
	{	
		public int? Id { get; set; } 

		public string? Cnpj { get; set; } 

		public string? Contato { get; set; } 

		public string? Email { get; set; } 

		public string? Telefone { get; set; } 

		public string? IdentificadorCsrt { get; set; } 

		public string? HashCsrt { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
