namespace nfe.Models
{
	public class VendaCabecalhoModel
	{	
		public int? Id { get; set; } 

		public int? IdVendaOrcamentoCabecalho { get; set; } 

		public int? IdVendaCondicoesPagamento { get; set; } 

		public int? IdNotaFiscalTipo { get; set; } 

		public int? IdTransportadora { get; set; } 

		public System.Nullable<System.DateTime> DataVenda { get; set; } 

		public System.Nullable<System.DateTime> DataSaida { get; set; } 

		public string? HoraSaida { get; set; } 

		public int? NumeroFatura { get; set; } 

		public string? LocalEntrega { get; set; } 

		public string? LocalCobranca { get; set; } 

		public System.Nullable<System.Decimal> ValorSubtotal { get; set; } 

		public System.Nullable<System.Decimal> TaxaComissao { get; set; } 

		public System.Nullable<System.Decimal> ValorComissao { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public string? TipoFrete { get; set; } 

		public string? FormaPagamento { get; set; } 

		public System.Nullable<System.Decimal> ValorFrete { get; set; } 

		public System.Nullable<System.Decimal> ValorSeguro { get; set; } 

		public string? Observacao { get; set; } 

		public string? Situacao { get; set; } 

		public string? DiaFixoParcela { get; set; } 

	}
}
