namespace nfe.Models
{
	public class NfeDetalheImpostoIcmsModel
	{	
		public int? Id { get; set; } 

		public string? OrigemMercadoria { get; set; } 

		public string? CstIcms { get; set; } 

		public string? Csosn { get; set; } 

		public string? ModalidadeBcIcms { get; set; } 

		public System.Nullable<System.Decimal> PercentualReducaoBcIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcms { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsOperacao { get; set; } 

		public System.Nullable<System.Decimal> PercentualDiferimento { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsDiferido { get; set; } 

		public System.Nullable<System.Decimal> ValorIcms { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoFcp { get; set; } 

		public System.Nullable<System.Decimal> PercentualFcp { get; set; } 

		public System.Nullable<System.Decimal> ValorFcp { get; set; } 

		public string? ModalidadeBcIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> PercentualMvaIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> PercentualReducaoBcIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorBaseCalculoIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsSt { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoFcpSt { get; set; } 

		public System.Nullable<System.Decimal> PercentualFcpSt { get; set; } 

		public System.Nullable<System.Decimal> ValorFcpSt { get; set; } 

		public string? UfSt { get; set; } 

		public System.Nullable<System.Decimal> PercentualBcOperacaoPropria { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcmsStRetido { get; set; } 

		public System.Nullable<System.Decimal> AliquotaSuportadaConsumidor { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsSubstituto { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsStRetido { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoFcpStRetido { get; set; } 

		public System.Nullable<System.Decimal> PercentualFcpStRetido { get; set; } 

		public System.Nullable<System.Decimal> ValorFcpStRetido { get; set; } 

		public string? MotivoDesoneracaoIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsDesonerado { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCreditoIcmsSn { get; set; } 

		public System.Nullable<System.Decimal> ValorCreditoIcmsSn { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcmsStDestino { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsStDestino { get; set; } 

		public System.Nullable<System.Decimal> PercentualReducaoBcEfetivo { get; set; } 

		public System.Nullable<System.Decimal> ValorBcEfetivo { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcmsEfetivo { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsEfetivo { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
