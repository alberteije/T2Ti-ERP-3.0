namespace nfe.Models
{
	public class NfeDetalheImpostoIiModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIi { get; set; } 

		public System.Nullable<System.Decimal> ValorDespesasAduaneiras { get; set; } 

		public System.Nullable<System.Decimal> ValorImpostoImportacao { get; set; } 

		public System.Nullable<System.Decimal> ValorIof { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
