namespace nfe.Models
{
	public class NfeExportacaoModel
	{	
		public int? Id { get; set; } 

		public int? Drawback { get; set; } 

		public int? NumeroRegistro { get; set; } 

		public string? ChaveAcesso { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
