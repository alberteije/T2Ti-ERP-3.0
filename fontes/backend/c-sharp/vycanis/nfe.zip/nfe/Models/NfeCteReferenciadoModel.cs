namespace nfe.Models
{
	public class NfeCteReferenciadoModel
	{	
		public int? Id { get; set; } 

		public string? ChaveAcesso { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
