namespace nfe.Models
{
	public class NfeTransporteModel
	{	
		public int? Id { get; set; } 

		public int? IdTransportadora { get; set; } 

		public string? ModalidadeFrete { get; set; } 

		public string? Cnpj { get; set; } 

		public string? Cpf { get; set; } 

		public string? Nome { get; set; } 

		public string? InscricaoEstadual { get; set; } 

		public string? Endereco { get; set; } 

		public string? NomeMunicipio { get; set; } 

		public string? Uf { get; set; } 

		public System.Nullable<System.Decimal> ValorServico { get; set; } 

		public System.Nullable<System.Decimal> ValorBcRetencaoIcms { get; set; } 

		public System.Nullable<System.Decimal> AliquotaRetencaoIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsRetido { get; set; } 

		public int? Cfop { get; set; } 

		public int? Municipio { get; set; } 

		public string? PlacaVeiculo { get; set; } 

		public string? UfVeiculo { get; set; } 

		public string? RntcVeiculo { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
