namespace nfe.Models
{
	public class NfeDetalheImpostoCofinsModel
	{	
		public int? Id { get; set; } 

		public string? CstCofins { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoCofins { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCofinsPercentual { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeVendida { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCofinsReais { get; set; } 

		public System.Nullable<System.Decimal> ValorCofins { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
