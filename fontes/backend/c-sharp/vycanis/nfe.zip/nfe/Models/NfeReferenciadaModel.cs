namespace nfe.Models
{
	public class NfeReferenciadaModel
	{	
		public int? Id { get; set; } 

		public string? ChaveAcesso { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
