namespace nfe.Models
{
	public class NfeCanaDeducoesSafraModel
	{	
		public int? Id { get; set; } 

		public string? Decricao { get; set; } 

		public System.Nullable<System.Decimal> ValorDeducao { get; set; } 

		public System.Nullable<System.Decimal> ValorFornecimento { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalDeducao { get; set; } 

		public System.Nullable<System.Decimal> ValorLiquidoFornecimento { get; set; } 

		public NfeCanaModel? NfeCanaModel { get; set; } 

	}
}
