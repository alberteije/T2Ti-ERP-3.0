namespace nfe.Models
{
	public class NfeDetalheImpostoCofinsStModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoCofinsSt { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCofinsStPercentual { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeVendidaCofinsSt { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCofinsStReais { get; set; } 

		public System.Nullable<System.Decimal> ValorCofinsSt { get; set; } 

		public NfeDetalheModel? NfeDetalheModel { get; set; } 

	}
}
