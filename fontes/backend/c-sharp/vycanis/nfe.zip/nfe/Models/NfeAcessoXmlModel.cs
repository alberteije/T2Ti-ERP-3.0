namespace nfe.Models
{
	public class NfeAcessoXmlModel
	{	
		public int? Id { get; set; } 

		public string? Cnpj { get; set; } 

		public string? Cpf { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
