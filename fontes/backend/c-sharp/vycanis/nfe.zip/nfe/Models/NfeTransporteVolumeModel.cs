namespace nfe.Models
{
	public class NfeTransporteVolumeModel
	{	
		public int? Id { get; set; } 

		public int? Quantidade { get; set; } 

		public string? Especie { get; set; } 

		public string? Marca { get; set; } 

		public string? Numeracao { get; set; } 

		public System.Nullable<System.Decimal> PesoLiquido { get; set; } 

		public System.Nullable<System.Decimal> PesoBruto { get; set; } 

		public NfeTransporteModel? NfeTransporteModel { get; set; } 

	}
}
