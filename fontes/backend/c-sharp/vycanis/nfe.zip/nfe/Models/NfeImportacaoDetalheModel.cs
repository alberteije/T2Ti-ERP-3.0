namespace nfe.Models
{
	public class NfeImportacaoDetalheModel
	{	
		public int? Id { get; set; } 

		public int? NumeroAdicao { get; set; } 

		public int? NumeroSequencial { get; set; } 

		public string? CodigoFabricanteEstrangeiro { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public int? Drawback { get; set; } 

		public NfeDeclaracaoImportacaoModel? NfeDeclaracaoImportacaoModel { get; set; } 

	}
}
