namespace gondolas.Models
{
	public class GondolaArmazenamentoModel
	{	
		public int? Id { get; set; } 

		public int? Quantidade { get; set; } 

		public GondolaCaixaModel? GondolaCaixaModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
