namespace gondolas.Models
{
	public class GondolaEstanteModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public int? QuantidadeCaixa { get; set; } 

		public GondolaRuaModel? GondolaRuaModel { get; set; } 

	}
}
