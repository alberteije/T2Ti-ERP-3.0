using Microsoft.AspNetCore.Mvc;
using gondolas.Models;
using gondolas.Services;

namespace gondolas.Controllers
{
    [Route("gondola-rua")]
    [Produces("application/json")]
    public class GondolaRuaController : Controller
    {
		private readonly GondolaRuaService _service;

        public GondolaRuaController()
        {
            _service = new GondolaRuaService();
        }

        [HttpGet]
        public IActionResult GetListGondolaRua([FromQuery]string filter)
        {
            try
            {
                IEnumerable<GondolaRuaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList GondolaRua]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectGondolaRua")]
        public IActionResult GetObjectGondolaRua(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject GondolaRua]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject GondolaRua]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertGondolaRua([FromBody]GondolaRuaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert GondolaRua]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectGondolaRua", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert GondolaRua]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateGondolaRua([FromBody]GondolaRuaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update GondolaRua]", null));
                }

                _service.Update(objJson);

                return GetObjectGondolaRua(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update GondolaRua]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteGondolaRua(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete GondolaRua]", ex));
            }
        }

    }
}