using Microsoft.AspNetCore.Mvc;
using gondolas.Models;
using gondolas.Services;

namespace gondolas.Controllers
{
    [Route("gondola-estante")]
    [Produces("application/json")]
    public class GondolaEstanteController : Controller
    {
		private readonly GondolaEstanteService _service;

        public GondolaEstanteController()
        {
            _service = new GondolaEstanteService();
        }

        [HttpGet]
        public IActionResult GetListGondolaEstante([FromQuery]string filter)
        {
            try
            {
                IEnumerable<GondolaEstanteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList GondolaEstante]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectGondolaEstante")]
        public IActionResult GetObjectGondolaEstante(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject GondolaEstante]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject GondolaEstante]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertGondolaEstante([FromBody]GondolaEstanteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert GondolaEstante]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectGondolaEstante", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert GondolaEstante]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateGondolaEstante([FromBody]GondolaEstanteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update GondolaEstante]", null));
                }

                _service.Update(objJson);

                return GetObjectGondolaEstante(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update GondolaEstante]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteGondolaEstante(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete GondolaEstante]", ex));
            }
        }

    }
}