using gondolas.Models;
using gondolas.NHibernate;
using ISession = NHibernate.ISession;

namespace gondolas.Services
{
    public class GondolaRuaService
    {

        public IEnumerable<GondolaRuaModel> GetList()
        {
            IList<GondolaRuaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaRuaModel> DAL = new NHibernateDAL<GondolaRuaModel>(Session);
                Result = DAL.Select(new GondolaRuaModel());
            }
            return Result;
        }

        public IEnumerable<GondolaRuaModel> GetListFilter(Filter filterObj)
        {
            IList<GondolaRuaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from GondolaRuaModel where " + filterObj.Where;
                NHibernateDAL<GondolaRuaModel> DAL = new NHibernateDAL<GondolaRuaModel>(Session);
                Result = DAL.SelectListSql<GondolaRuaModel>(Query);
            }
            return Result;
        }
		
        public GondolaRuaModel GetObject(int id)
        {
            GondolaRuaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaRuaModel> DAL = new NHibernateDAL<GondolaRuaModel>(Session);
                Result = DAL.SelectId<GondolaRuaModel>(id);
            }
            return Result;
        }
		
        public void Insert(GondolaRuaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaRuaModel> DAL = new NHibernateDAL<GondolaRuaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(GondolaRuaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaRuaModel> DAL = new NHibernateDAL<GondolaRuaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(GondolaRuaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaRuaModel> DAL = new NHibernateDAL<GondolaRuaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}