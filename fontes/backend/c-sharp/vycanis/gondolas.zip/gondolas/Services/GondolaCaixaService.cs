using gondolas.Models;
using gondolas.NHibernate;
using ISession = NHibernate.ISession;

namespace gondolas.Services
{
    public class GondolaCaixaService
    {

        public IEnumerable<GondolaCaixaModel> GetList()
        {
            IList<GondolaCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaCaixaModel> DAL = new NHibernateDAL<GondolaCaixaModel>(Session);
                Result = DAL.Select(new GondolaCaixaModel());
            }
            return Result;
        }

        public IEnumerable<GondolaCaixaModel> GetListFilter(Filter filterObj)
        {
            IList<GondolaCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from GondolaCaixaModel where " + filterObj.Where;
                NHibernateDAL<GondolaCaixaModel> DAL = new NHibernateDAL<GondolaCaixaModel>(Session);
                Result = DAL.SelectListSql<GondolaCaixaModel>(Query);
            }
            return Result;
        }
		
        public GondolaCaixaModel GetObject(int id)
        {
            GondolaCaixaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaCaixaModel> DAL = new NHibernateDAL<GondolaCaixaModel>(Session);
                Result = DAL.SelectId<GondolaCaixaModel>(id);
            }
            return Result;
        }
		
        public void Insert(GondolaCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaCaixaModel> DAL = new NHibernateDAL<GondolaCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(GondolaCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaCaixaModel> DAL = new NHibernateDAL<GondolaCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(GondolaCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaCaixaModel> DAL = new NHibernateDAL<GondolaCaixaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}