namespace gondolas.Models
{
	public class GondolaCaixaModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public int? Altura { get; set; } 

		public int? Largura { get; set; } 

		public int? Profundidade { get; set; } 

		public GondolaEstanteModel? GondolaEstanteModel { get; set; } 

		private IList<GondolaArmazenamentoModel>? gondolaArmazenamentoModelList; 
		public IList<GondolaArmazenamentoModel>? GondolaArmazenamentoModelList 
		{ 
			get 
			{ 
				return gondolaArmazenamentoModelList; 
			} 
			set 
			{ 
				gondolaArmazenamentoModelList = value; 
				foreach (GondolaArmazenamentoModel gondolaArmazenamentoModel in gondolaArmazenamentoModelList!) 
				{ 
					gondolaArmazenamentoModel.GondolaCaixaModel = this; 
				} 
			} 
		} 

	}
}
