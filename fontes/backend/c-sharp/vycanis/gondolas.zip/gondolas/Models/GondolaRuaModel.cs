namespace gondolas.Models
{
	public class GondolaRuaModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public int? QuantidadeEstante { get; set; } 

		public string? Nome { get; set; } 

	}
}
