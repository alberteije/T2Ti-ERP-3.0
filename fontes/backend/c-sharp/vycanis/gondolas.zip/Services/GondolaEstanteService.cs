using gondolas.Models;
using gondolas.NHibernate;
using ISession = NHibernate.ISession;

namespace gondolas.Services
{
    public class GondolaEstanteService
    {

        public IEnumerable<GondolaEstanteModel> GetList()
        {
            IList<GondolaEstanteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaEstanteModel> DAL = new NHibernateDAL<GondolaEstanteModel>(Session);
                Result = DAL.Select(new GondolaEstanteModel());
            }
            return Result;
        }

        public IEnumerable<GondolaEstanteModel> GetListFilter(Filter filterObj)
        {
            IList<GondolaEstanteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from GondolaEstanteModel where " + filterObj.Where;
                NHibernateDAL<GondolaEstanteModel> DAL = new NHibernateDAL<GondolaEstanteModel>(Session);
                Result = DAL.SelectListSql<GondolaEstanteModel>(Query);
            }
            return Result;
        }
		
        public GondolaEstanteModel GetObject(int id)
        {
            GondolaEstanteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaEstanteModel> DAL = new NHibernateDAL<GondolaEstanteModel>(Session);
                Result = DAL.SelectId<GondolaEstanteModel>(id);
            }
            return Result;
        }
		
        public void Insert(GondolaEstanteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaEstanteModel> DAL = new NHibernateDAL<GondolaEstanteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(GondolaEstanteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaEstanteModel> DAL = new NHibernateDAL<GondolaEstanteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(GondolaEstanteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GondolaEstanteModel> DAL = new NHibernateDAL<GondolaEstanteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}