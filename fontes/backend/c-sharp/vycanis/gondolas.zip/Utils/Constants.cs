namespace gondolas.Utils
{

    public static class Constants
    {
        public static int DECIMAIS_QUANTIDADE = 3;
        public static int DECIMAIS_VALOR = 2;
        public static int QUANTIDADE_POR_PAGINA = 50;
        public static int MAX_ROWS = 50;
        public static string ENDERECO_SERVIDOR = "127.0.0.1";
        public static string CHAVE = "#Sua-Chave-de-32-caracteres-aqui"; // TODO: altere para produção
        public static string VETOR = "#Seu-Vetor-aqui#"; // TODO: altere para produção
    }
}
