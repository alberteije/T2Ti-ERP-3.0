using Microsoft.AspNetCore.Mvc;
using gondolas.Models;
using gondolas.Services;

namespace gondolas.Controllers
{
    [Route("gondola-caixa")]
    [Produces("application/json")]
    public class GondolaCaixaController : Controller
    {
		private readonly GondolaCaixaService _service;

        public GondolaCaixaController()
        {
            _service = new GondolaCaixaService();
        }

        [HttpGet]
        public IActionResult GetListGondolaCaixa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<GondolaCaixaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList GondolaCaixa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectGondolaCaixa")]
        public IActionResult GetObjectGondolaCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject GondolaCaixa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject GondolaCaixa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertGondolaCaixa([FromBody]GondolaCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert GondolaCaixa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectGondolaCaixa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert GondolaCaixa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateGondolaCaixa([FromBody]GondolaCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update GondolaCaixa]", null));
                }

                _service.Update(objJson);

                return GetObjectGondolaCaixa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update GondolaCaixa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteGondolaCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete GondolaCaixa]", ex));
            }
        }

    }
}