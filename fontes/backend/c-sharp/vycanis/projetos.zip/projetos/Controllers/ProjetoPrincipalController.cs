using Microsoft.AspNetCore.Mvc;
using projetos.Models;
using projetos.Services;

namespace projetos.Controllers
{
    [Route("projeto-principal")]
    [Produces("application/json")]
    public class ProjetoPrincipalController : Controller
    {
		private readonly ProjetoPrincipalService _service;

        public ProjetoPrincipalController()
        {
            _service = new ProjetoPrincipalService();
        }

        [HttpGet]
        public IActionResult GetListProjetoPrincipal([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ProjetoPrincipalModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ProjetoPrincipal]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectProjetoPrincipal")]
        public IActionResult GetObjectProjetoPrincipal(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ProjetoPrincipal]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ProjetoPrincipal]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertProjetoPrincipal([FromBody]ProjetoPrincipalModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ProjetoPrincipal]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectProjetoPrincipal", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ProjetoPrincipal]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateProjetoPrincipal([FromBody]ProjetoPrincipalModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ProjetoPrincipal]", null));
                }

                _service.Update(objJson);

                return GetObjectProjetoPrincipal(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ProjetoPrincipal]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProjetoPrincipal(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ProjetoPrincipal]", ex));
            }
        }

    }
}