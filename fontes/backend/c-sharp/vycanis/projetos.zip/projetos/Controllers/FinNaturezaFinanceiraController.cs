using Microsoft.AspNetCore.Mvc;
using projetos.Models;
using projetos.Services;

namespace projetos.Controllers
{
    [Route("fin-natureza-financeira")]
    [Produces("application/json")]
    public class FinNaturezaFinanceiraController : Controller
    {
		private readonly FinNaturezaFinanceiraService _service;

        public FinNaturezaFinanceiraController()
        {
            _service = new FinNaturezaFinanceiraService();
        }

        [HttpGet]
        public IActionResult GetListFinNaturezaFinanceira([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FinNaturezaFinanceiraModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FinNaturezaFinanceira]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFinNaturezaFinanceira")]
        public IActionResult GetObjectFinNaturezaFinanceira(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FinNaturezaFinanceira]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FinNaturezaFinanceira]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFinNaturezaFinanceira([FromBody]FinNaturezaFinanceiraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FinNaturezaFinanceira]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFinNaturezaFinanceira", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FinNaturezaFinanceira]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFinNaturezaFinanceira([FromBody]FinNaturezaFinanceiraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FinNaturezaFinanceira]", null));
                }

                _service.Update(objJson);

                return GetObjectFinNaturezaFinanceira(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FinNaturezaFinanceira]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFinNaturezaFinanceira(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FinNaturezaFinanceira]", ex));
            }
        }

    }
}