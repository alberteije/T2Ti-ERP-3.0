using projetos.Models;
using projetos.NHibernate;
using ISession = NHibernate.ISession;

namespace projetos.Services
{
    public class ProjetoPrincipalService
    {

        public IEnumerable<ProjetoPrincipalModel> GetList()
        {
            IList<ProjetoPrincipalModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProjetoPrincipalModel> DAL = new NHibernateDAL<ProjetoPrincipalModel>(Session);
                Result = DAL.Select(new ProjetoPrincipalModel());
            }
            return Result;
        }

        public IEnumerable<ProjetoPrincipalModel> GetListFilter(Filter filterObj)
        {
            IList<ProjetoPrincipalModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ProjetoPrincipalModel where " + filterObj.Where;
                NHibernateDAL<ProjetoPrincipalModel> DAL = new NHibernateDAL<ProjetoPrincipalModel>(Session);
                Result = DAL.SelectListSql<ProjetoPrincipalModel>(Query);
            }
            return Result;
        }
		
        public ProjetoPrincipalModel GetObject(int id)
        {
            ProjetoPrincipalModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProjetoPrincipalModel> DAL = new NHibernateDAL<ProjetoPrincipalModel>(Session);
                Result = DAL.SelectId<ProjetoPrincipalModel>(id);
            }
            return Result;
        }
		
        public void Insert(ProjetoPrincipalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProjetoPrincipalModel> DAL = new NHibernateDAL<ProjetoPrincipalModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ProjetoPrincipalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProjetoPrincipalModel> DAL = new NHibernateDAL<ProjetoPrincipalModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ProjetoPrincipalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProjetoPrincipalModel> DAL = new NHibernateDAL<ProjetoPrincipalModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}