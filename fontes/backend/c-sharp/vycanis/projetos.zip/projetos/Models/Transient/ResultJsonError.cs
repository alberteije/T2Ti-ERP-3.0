﻿using System;

namespace projetos.Models
{
    public class ResultJsonError
    {
        public ResultJsonError(int code, string message, Exception? ex)
        {
            Status = code;
            Message = message;

            Error = Status switch
            {
                400 => "Bad Request",
                404 => "Not Found",
                500 => "Internal Server Error",
                _ => "Error",
            };
            if (ex != null)
            {
                Message = Message + " - Exception: " + ex.Message;
                Trace = ex.StackTrace;
            }

        }


        public int Status { get; set; }
        public string Error { get; set; }
        public string Message { get; set; }
        public string? Trace { get; set; }

    }
}
