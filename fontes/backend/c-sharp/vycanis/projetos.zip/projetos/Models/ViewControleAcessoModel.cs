namespace projetos.Models
{
	public class ViewControleAcessoModel
	{	
		public int? Id { get; set; } 

		public int? IdPessoa { get; set; } 

		public string? PessoaNome { get; set; } 

		public int? IdColaborador { get; set; } 

		public int? IdUsuario { get; set; } 

		public string? Administrador { get; set; } 

		public int? IdPapel { get; set; } 

		public string? PapelNome { get; set; } 

		public string? PapelDescricao { get; set; } 

		public int? IdFuncao { get; set; } 

		public string? FuncaoNome { get; set; } 

		public string? FuncaoDescricao { get; set; } 

		public int? IdPapelFuncao { get; set; } 

		public string? Habilitado { get; set; } 

		public string? PodeInserir { get; set; } 

		public string? PodeAlterar { get; set; } 

		public string? PodeExcluir { get; set; } 

	}
}
