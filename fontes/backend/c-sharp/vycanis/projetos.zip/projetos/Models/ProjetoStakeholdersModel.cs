namespace projetos.Models
{
	public class ProjetoStakeholdersModel
	{	
		public int? Id { get; set; } 

		public ProjetoPrincipalModel? ProjetoPrincipalModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
