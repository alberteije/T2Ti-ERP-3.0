namespace projetos.Models
{
	public class ProjetoRiscoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public int? Probabilidade { get; set; } 

		public int? Impacto { get; set; } 

		public string? Descricao { get; set; } 

		public ProjetoPrincipalModel? ProjetoPrincipalModel { get; set; } 

	}
}
