namespace projetos.Models
{
	public class ProjetoPrincipalModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataPrevisaoFim { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public System.Nullable<System.Decimal> ValorOrcamento { get; set; } 

		public string? LinkQuadroKanban { get; set; } 

		public string? Observacao { get; set; } 

		private IList<ProjetoCronogramaModel>? projetoCronogramaModelList; 
		public IList<ProjetoCronogramaModel>? ProjetoCronogramaModelList 
		{ 
			get 
			{ 
				return projetoCronogramaModelList; 
			} 
			set 
			{ 
				projetoCronogramaModelList = value; 
				foreach (ProjetoCronogramaModel projetoCronogramaModel in projetoCronogramaModelList!) 
				{ 
					projetoCronogramaModel.ProjetoPrincipalModel = this; 
				} 
			} 
		} 

		private IList<ProjetoRiscoModel>? projetoRiscoModelList; 
		public IList<ProjetoRiscoModel>? ProjetoRiscoModelList 
		{ 
			get 
			{ 
				return projetoRiscoModelList; 
			} 
			set 
			{ 
				projetoRiscoModelList = value; 
				foreach (ProjetoRiscoModel projetoRiscoModel in projetoRiscoModelList!) 
				{ 
					projetoRiscoModel.ProjetoPrincipalModel = this; 
				} 
			} 
		} 

		private IList<ProjetoCustoModel>? projetoCustoModelList; 
		public IList<ProjetoCustoModel>? ProjetoCustoModelList 
		{ 
			get 
			{ 
				return projetoCustoModelList; 
			} 
			set 
			{ 
				projetoCustoModelList = value; 
				foreach (ProjetoCustoModel projetoCustoModel in projetoCustoModelList!) 
				{ 
					projetoCustoModel.ProjetoPrincipalModel = this; 
				} 
			} 
		} 

		private IList<ProjetoStakeholdersModel>? projetoStakeholdersModelList; 
		public IList<ProjetoStakeholdersModel>? ProjetoStakeholdersModelList 
		{ 
			get 
			{ 
				return projetoStakeholdersModelList; 
			} 
			set 
			{ 
				projetoStakeholdersModelList = value; 
				foreach (ProjetoStakeholdersModel projetoStakeholdersModel in projetoStakeholdersModelList!) 
				{ 
					projetoStakeholdersModel.ProjetoPrincipalModel = this; 
				} 
			} 
		} 

	}
}
