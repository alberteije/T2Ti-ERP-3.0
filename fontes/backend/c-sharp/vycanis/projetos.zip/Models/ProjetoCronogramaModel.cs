namespace projetos.Models
{
	public class ProjetoCronogramaModel
	{	
		public int? Id { get; set; } 

		public string? Tarefa { get; set; } 

		public System.Nullable<System.DateTime> DataTarefa { get; set; } 

		public string? Descricao { get; set; } 

		public ProjetoPrincipalModel? ProjetoPrincipalModel { get; set; } 

	}
}
