namespace projetos.Models
{
	public class ProjetoCustoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.Decimal> ValorMensal { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public string? Justificativa { get; set; } 

		public ProjetoPrincipalModel? ProjetoPrincipalModel { get; set; } 

		public FinNaturezaFinanceiraModel? FinNaturezaFinanceiraModel { get; set; } 

	}
}
