using Microsoft.AspNetCore.Mvc;
using bi.Models;
using bi.Services;

namespace bi.Controllers
{
    [Route("dim-tempo")]
    [Produces("application/json")]
    public class DimTempoController : Controller
    {
		private readonly DimTempoService _service;

        public DimTempoController()
        {
            _service = new DimTempoService();
        }

        [HttpGet]
        public IActionResult GetListDimTempo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<DimTempoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList DimTempo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectDimTempo")]
        public IActionResult GetObjectDimTempo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject DimTempo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject DimTempo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertDimTempo([FromBody]DimTempoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert DimTempo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectDimTempo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert DimTempo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateDimTempo([FromBody]DimTempoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update DimTempo]", null));
                }

                _service.Update(objJson);

                return GetObjectDimTempo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update DimTempo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteDimTempo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete DimTempo]", ex));
            }
        }

    }
}