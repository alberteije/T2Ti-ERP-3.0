using Microsoft.AspNetCore.Mvc;
using bi.Models;
using bi.Services;

namespace bi.Controllers
{
    [Route("dim-vendedor")]
    [Produces("application/json")]
    public class DimVendedorController : Controller
    {
		private readonly DimVendedorService _service;

        public DimVendedorController()
        {
            _service = new DimVendedorService();
        }

        [HttpGet]
        public IActionResult GetListDimVendedor([FromQuery]string filter)
        {
            try
            {
                IEnumerable<DimVendedorModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList DimVendedor]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectDimVendedor")]
        public IActionResult GetObjectDimVendedor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject DimVendedor]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject DimVendedor]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertDimVendedor([FromBody]DimVendedorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert DimVendedor]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectDimVendedor", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert DimVendedor]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateDimVendedor([FromBody]DimVendedorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update DimVendedor]", null));
                }

                _service.Update(objJson);

                return GetObjectDimVendedor(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update DimVendedor]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteDimVendedor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete DimVendedor]", ex));
            }
        }

    }
}