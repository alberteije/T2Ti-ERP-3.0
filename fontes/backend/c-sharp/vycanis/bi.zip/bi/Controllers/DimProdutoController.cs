using Microsoft.AspNetCore.Mvc;
using bi.Models;
using bi.Services;

namespace bi.Controllers
{
    [Route("dim-produto")]
    [Produces("application/json")]
    public class DimProdutoController : Controller
    {
		private readonly DimProdutoService _service;

        public DimProdutoController()
        {
            _service = new DimProdutoService();
        }

        [HttpGet]
        public IActionResult GetListDimProduto([FromQuery]string filter)
        {
            try
            {
                IEnumerable<DimProdutoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList DimProduto]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectDimProduto")]
        public IActionResult GetObjectDimProduto(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject DimProduto]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject DimProduto]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertDimProduto([FromBody]DimProdutoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert DimProduto]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectDimProduto", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert DimProduto]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateDimProduto([FromBody]DimProdutoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update DimProduto]", null));
                }

                _service.Update(objJson);

                return GetObjectDimProduto(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update DimProduto]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteDimProduto(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete DimProduto]", ex));
            }
        }

    }
}