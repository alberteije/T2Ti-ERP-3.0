using Microsoft.AspNetCore.Mvc;
using bi.Models;
using bi.Services;

namespace bi.Controllers
{
    [Route("fato-recebimento")]
    [Produces("application/json")]
    public class FatoRecebimentoController : Controller
    {
		private readonly FatoRecebimentoService _service;

        public FatoRecebimentoController()
        {
            _service = new FatoRecebimentoService();
        }

        [HttpGet]
        public IActionResult GetListFatoRecebimento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FatoRecebimentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FatoRecebimento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFatoRecebimento")]
        public IActionResult GetObjectFatoRecebimento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FatoRecebimento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FatoRecebimento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFatoRecebimento([FromBody]FatoRecebimentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FatoRecebimento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFatoRecebimento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FatoRecebimento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFatoRecebimento([FromBody]FatoRecebimentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FatoRecebimento]", null));
                }

                _service.Update(objJson);

                return GetObjectFatoRecebimento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FatoRecebimento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFatoRecebimento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FatoRecebimento]", ex));
            }
        }

    }
}