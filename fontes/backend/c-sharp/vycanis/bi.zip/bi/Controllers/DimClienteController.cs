using Microsoft.AspNetCore.Mvc;
using bi.Models;
using bi.Services;

namespace bi.Controllers
{
    [Route("dim-cliente")]
    [Produces("application/json")]
    public class DimClienteController : Controller
    {
		private readonly DimClienteService _service;

        public DimClienteController()
        {
            _service = new DimClienteService();
        }

        [HttpGet]
        public IActionResult GetListDimCliente([FromQuery]string filter)
        {
            try
            {
                IEnumerable<DimClienteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList DimCliente]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectDimCliente")]
        public IActionResult GetObjectDimCliente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject DimCliente]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject DimCliente]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertDimCliente([FromBody]DimClienteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert DimCliente]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectDimCliente", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert DimCliente]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateDimCliente([FromBody]DimClienteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update DimCliente]", null));
                }

                _service.Update(objJson);

                return GetObjectDimCliente(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update DimCliente]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteDimCliente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete DimCliente]", ex));
            }
        }

    }
}