using Microsoft.AspNetCore.Mvc;
using bi.Models;
using bi.Services;

namespace bi.Controllers
{
    [Route("fato-venda")]
    [Produces("application/json")]
    public class FatoVendaController : Controller
    {
		private readonly FatoVendaService _service;

        public FatoVendaController()
        {
            _service = new FatoVendaService();
        }

        [HttpGet]
        public IActionResult GetListFatoVenda([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FatoVendaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FatoVenda]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFatoVenda")]
        public IActionResult GetObjectFatoVenda(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FatoVenda]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FatoVenda]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFatoVenda([FromBody]FatoVendaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FatoVenda]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFatoVenda", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FatoVenda]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFatoVenda([FromBody]FatoVendaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FatoVenda]", null));
                }

                _service.Update(objJson);

                return GetObjectFatoVenda(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FatoVenda]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFatoVenda(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FatoVenda]", ex));
            }
        }

    }
}