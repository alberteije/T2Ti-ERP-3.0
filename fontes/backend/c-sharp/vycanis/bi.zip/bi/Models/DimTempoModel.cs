namespace bi.Models
{
	public class DimTempoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> Data { get; set; } 

		public int? Ano { get; set; } 

		public int? Mes { get; set; } 

		public string? NomeMes { get; set; } 

		public int? Trimestre { get; set; } 

		public int? Dia { get; set; } 

		public int? DiaSemana { get; set; } 

	}
}
