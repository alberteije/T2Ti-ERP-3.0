namespace bi.Models
{
	public class FatoRecebimentoModel
	{	
		public int? Id { get; set; } 

		public int? IdTempo { get; set; } 

		public int? IdCliente { get; set; } 

		public System.Nullable<System.Decimal> ValorRecebido { get; set; } 

		public System.Nullable<System.Decimal> ValorEmAberto { get; set; } 

		public int? AtrasoDias { get; set; } 

	}
}
