namespace bi.Models
{
	public class DimVendedorModel
	{	
		public int? Id { get; set; } 

		public string? NomeVendedor { get; set; } 

		public string? Equipe { get; set; } 

		public string? Regiao { get; set; } 

	}
}
