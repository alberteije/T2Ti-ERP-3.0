namespace bi.Models
{
	public class FatoVendaModel
	{	
		public int? Id { get; set; } 

		public int? IdTempo { get; set; } 

		public int? IdCliente { get; set; } 

		public int? IdVendedor { get; set; } 

		public int? IdProduto { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public System.Nullable<System.Decimal> CustoTotal { get; set; } 

		public System.Nullable<System.Decimal> Lucro { get; set; } 

	}
}
