namespace bi.Models
{
	public class DimProdutoModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public string? Categoria { get; set; } 

		public string? Marca { get; set; } 

	}
}
