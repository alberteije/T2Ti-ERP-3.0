namespace bi.Models
{
	public class DimClienteModel
	{	
		public int? Id { get; set; } 

		public string? NomeCliente { get; set; } 

		public string? TipoCliente { get; set; } 

		public string? Cidade { get; set; } 

		public string? Estado { get; set; } 

		public string? Segmento { get; set; } 

	}
}
