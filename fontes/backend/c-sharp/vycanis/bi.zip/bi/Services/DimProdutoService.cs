using bi.Models;
using bi.NHibernate;
using ISession = NHibernate.ISession;

namespace bi.Services
{
    public class DimProdutoService
    {

        public IEnumerable<DimProdutoModel> GetList()
        {
            IList<DimProdutoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimProdutoModel> DAL = new NHibernateDAL<DimProdutoModel>(Session);
                Result = DAL.Select(new DimProdutoModel());
            }
            return Result;
        }

        public IEnumerable<DimProdutoModel> GetListFilter(Filter filterObj)
        {
            IList<DimProdutoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from DimProdutoModel where " + filterObj.Where;
                NHibernateDAL<DimProdutoModel> DAL = new NHibernateDAL<DimProdutoModel>(Session);
                Result = DAL.SelectListSql<DimProdutoModel>(Query);
            }
            return Result;
        }
		
        public DimProdutoModel GetObject(int id)
        {
            DimProdutoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimProdutoModel> DAL = new NHibernateDAL<DimProdutoModel>(Session);
                Result = DAL.SelectId<DimProdutoModel>(id);
            }
            return Result;
        }
		
        public void Insert(DimProdutoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimProdutoModel> DAL = new NHibernateDAL<DimProdutoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(DimProdutoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimProdutoModel> DAL = new NHibernateDAL<DimProdutoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(DimProdutoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimProdutoModel> DAL = new NHibernateDAL<DimProdutoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}