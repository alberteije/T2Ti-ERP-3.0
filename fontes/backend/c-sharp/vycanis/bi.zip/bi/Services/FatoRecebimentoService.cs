using bi.Models;
using bi.NHibernate;
using ISession = NHibernate.ISession;

namespace bi.Services
{
    public class FatoRecebimentoService
    {

        public IEnumerable<FatoRecebimentoModel> GetList()
        {
            IList<FatoRecebimentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoRecebimentoModel> DAL = new NHibernateDAL<FatoRecebimentoModel>(Session);
                Result = DAL.Select(new FatoRecebimentoModel());
            }
            return Result;
        }

        public IEnumerable<FatoRecebimentoModel> GetListFilter(Filter filterObj)
        {
            IList<FatoRecebimentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FatoRecebimentoModel where " + filterObj.Where;
                NHibernateDAL<FatoRecebimentoModel> DAL = new NHibernateDAL<FatoRecebimentoModel>(Session);
                Result = DAL.SelectListSql<FatoRecebimentoModel>(Query);
            }
            return Result;
        }
		
        public FatoRecebimentoModel GetObject(int id)
        {
            FatoRecebimentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoRecebimentoModel> DAL = new NHibernateDAL<FatoRecebimentoModel>(Session);
                Result = DAL.SelectId<FatoRecebimentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FatoRecebimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoRecebimentoModel> DAL = new NHibernateDAL<FatoRecebimentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FatoRecebimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoRecebimentoModel> DAL = new NHibernateDAL<FatoRecebimentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FatoRecebimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoRecebimentoModel> DAL = new NHibernateDAL<FatoRecebimentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}