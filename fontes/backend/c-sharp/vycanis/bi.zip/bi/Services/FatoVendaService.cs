using bi.Models;
using bi.NHibernate;
using ISession = NHibernate.ISession;

namespace bi.Services
{
    public class FatoVendaService
    {

        public IEnumerable<FatoVendaModel> GetList()
        {
            IList<FatoVendaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoVendaModel> DAL = new NHibernateDAL<FatoVendaModel>(Session);
                Result = DAL.Select(new FatoVendaModel());
            }
            return Result;
        }

        public IEnumerable<FatoVendaModel> GetListFilter(Filter filterObj)
        {
            IList<FatoVendaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FatoVendaModel where " + filterObj.Where;
                NHibernateDAL<FatoVendaModel> DAL = new NHibernateDAL<FatoVendaModel>(Session);
                Result = DAL.SelectListSql<FatoVendaModel>(Query);
            }
            return Result;
        }
		
        public FatoVendaModel GetObject(int id)
        {
            FatoVendaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoVendaModel> DAL = new NHibernateDAL<FatoVendaModel>(Session);
                Result = DAL.SelectId<FatoVendaModel>(id);
            }
            return Result;
        }
		
        public void Insert(FatoVendaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoVendaModel> DAL = new NHibernateDAL<FatoVendaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FatoVendaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoVendaModel> DAL = new NHibernateDAL<FatoVendaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FatoVendaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FatoVendaModel> DAL = new NHibernateDAL<FatoVendaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}