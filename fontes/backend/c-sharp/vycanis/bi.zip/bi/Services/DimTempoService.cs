using bi.Models;
using bi.NHibernate;
using ISession = NHibernate.ISession;

namespace bi.Services
{
    public class DimTempoService
    {

        public IEnumerable<DimTempoModel> GetList()
        {
            IList<DimTempoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimTempoModel> DAL = new NHibernateDAL<DimTempoModel>(Session);
                Result = DAL.Select(new DimTempoModel());
            }
            return Result;
        }

        public IEnumerable<DimTempoModel> GetListFilter(Filter filterObj)
        {
            IList<DimTempoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from DimTempoModel where " + filterObj.Where;
                NHibernateDAL<DimTempoModel> DAL = new NHibernateDAL<DimTempoModel>(Session);
                Result = DAL.SelectListSql<DimTempoModel>(Query);
            }
            return Result;
        }
		
        public DimTempoModel GetObject(int id)
        {
            DimTempoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimTempoModel> DAL = new NHibernateDAL<DimTempoModel>(Session);
                Result = DAL.SelectId<DimTempoModel>(id);
            }
            return Result;
        }
		
        public void Insert(DimTempoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimTempoModel> DAL = new NHibernateDAL<DimTempoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(DimTempoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimTempoModel> DAL = new NHibernateDAL<DimTempoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(DimTempoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimTempoModel> DAL = new NHibernateDAL<DimTempoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}