using bi.Models;
using bi.NHibernate;
using ISession = NHibernate.ISession;

namespace bi.Services
{
    public class DimVendedorService
    {

        public IEnumerable<DimVendedorModel> GetList()
        {
            IList<DimVendedorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimVendedorModel> DAL = new NHibernateDAL<DimVendedorModel>(Session);
                Result = DAL.Select(new DimVendedorModel());
            }
            return Result;
        }

        public IEnumerable<DimVendedorModel> GetListFilter(Filter filterObj)
        {
            IList<DimVendedorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from DimVendedorModel where " + filterObj.Where;
                NHibernateDAL<DimVendedorModel> DAL = new NHibernateDAL<DimVendedorModel>(Session);
                Result = DAL.SelectListSql<DimVendedorModel>(Query);
            }
            return Result;
        }
		
        public DimVendedorModel GetObject(int id)
        {
            DimVendedorModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimVendedorModel> DAL = new NHibernateDAL<DimVendedorModel>(Session);
                Result = DAL.SelectId<DimVendedorModel>(id);
            }
            return Result;
        }
		
        public void Insert(DimVendedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimVendedorModel> DAL = new NHibernateDAL<DimVendedorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(DimVendedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimVendedorModel> DAL = new NHibernateDAL<DimVendedorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(DimVendedorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimVendedorModel> DAL = new NHibernateDAL<DimVendedorModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}