using bi.Models;
using bi.NHibernate;
using ISession = NHibernate.ISession;

namespace bi.Services
{
    public class DimClienteService
    {

        public IEnumerable<DimClienteModel> GetList()
        {
            IList<DimClienteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimClienteModel> DAL = new NHibernateDAL<DimClienteModel>(Session);
                Result = DAL.Select(new DimClienteModel());
            }
            return Result;
        }

        public IEnumerable<DimClienteModel> GetListFilter(Filter filterObj)
        {
            IList<DimClienteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from DimClienteModel where " + filterObj.Where;
                NHibernateDAL<DimClienteModel> DAL = new NHibernateDAL<DimClienteModel>(Session);
                Result = DAL.SelectListSql<DimClienteModel>(Query);
            }
            return Result;
        }
		
        public DimClienteModel GetObject(int id)
        {
            DimClienteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimClienteModel> DAL = new NHibernateDAL<DimClienteModel>(Session);
                Result = DAL.SelectId<DimClienteModel>(id);
            }
            return Result;
        }
		
        public void Insert(DimClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimClienteModel> DAL = new NHibernateDAL<DimClienteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(DimClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimClienteModel> DAL = new NHibernateDAL<DimClienteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(DimClienteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<DimClienteModel> DAL = new NHibernateDAL<DimClienteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}