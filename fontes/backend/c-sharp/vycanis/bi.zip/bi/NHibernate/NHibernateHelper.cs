﻿using NHibernate;
using NHibernate.Cfg;

namespace bi.NHibernate
{
    public class NHibernateHelper
    {
        private static ISessionFactory? SessionFactory;

        public static ISessionFactory GetSessionFactory()
        {
            try
            {
                if (SessionFactory == null)
                {
                    lock(typeof (NHibernateHelper))
                    {
                        Configuration config = new Configuration();
                        config.Configure();
                        config.AddAssembly("bi");
                        SessionFactory = config.BuildSessionFactory();
                    }
                }
                return SessionFactory;
            }
            catch
            {
                throw;
            }
        }
    }
}
