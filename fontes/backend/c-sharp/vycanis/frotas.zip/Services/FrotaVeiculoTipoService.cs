using frotas.Models;
using frotas.NHibernate;
using ISession = NHibernate.ISession;

namespace frotas.Services
{
    public class FrotaVeiculoTipoService
    {

        public IEnumerable<FrotaVeiculoTipoModel> GetList()
        {
            IList<FrotaVeiculoTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoTipoModel> DAL = new NHibernateDAL<FrotaVeiculoTipoModel>(Session);
                Result = DAL.Select(new FrotaVeiculoTipoModel());
            }
            return Result;
        }

        public IEnumerable<FrotaVeiculoTipoModel> GetListFilter(Filter filterObj)
        {
            IList<FrotaVeiculoTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FrotaVeiculoTipoModel where " + filterObj.Where;
                NHibernateDAL<FrotaVeiculoTipoModel> DAL = new NHibernateDAL<FrotaVeiculoTipoModel>(Session);
                Result = DAL.SelectListSql<FrotaVeiculoTipoModel>(Query);
            }
            return Result;
        }
		
        public FrotaVeiculoTipoModel GetObject(int id)
        {
            FrotaVeiculoTipoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoTipoModel> DAL = new NHibernateDAL<FrotaVeiculoTipoModel>(Session);
                Result = DAL.SelectId<FrotaVeiculoTipoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FrotaVeiculoTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoTipoModel> DAL = new NHibernateDAL<FrotaVeiculoTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FrotaVeiculoTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoTipoModel> DAL = new NHibernateDAL<FrotaVeiculoTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FrotaVeiculoTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoTipoModel> DAL = new NHibernateDAL<FrotaVeiculoTipoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}