using frotas.Models;
using frotas.NHibernate;
using ISession = NHibernate.ISession;

namespace frotas.Services
{
    public class FrotaVeiculoService
    {

        public IEnumerable<FrotaVeiculoModel> GetList()
        {
            IList<FrotaVeiculoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoModel> DAL = new NHibernateDAL<FrotaVeiculoModel>(Session);
                Result = DAL.Select(new FrotaVeiculoModel());
            }
            return Result;
        }

        public IEnumerable<FrotaVeiculoModel> GetListFilter(Filter filterObj)
        {
            IList<FrotaVeiculoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FrotaVeiculoModel where " + filterObj.Where;
                NHibernateDAL<FrotaVeiculoModel> DAL = new NHibernateDAL<FrotaVeiculoModel>(Session);
                Result = DAL.SelectListSql<FrotaVeiculoModel>(Query);
            }
            return Result;
        }
		
        public FrotaVeiculoModel GetObject(int id)
        {
            FrotaVeiculoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoModel> DAL = new NHibernateDAL<FrotaVeiculoModel>(Session);
                Result = DAL.SelectId<FrotaVeiculoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FrotaVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoModel> DAL = new NHibernateDAL<FrotaVeiculoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FrotaVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoModel> DAL = new NHibernateDAL<FrotaVeiculoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FrotaVeiculoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaVeiculoModel> DAL = new NHibernateDAL<FrotaVeiculoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}