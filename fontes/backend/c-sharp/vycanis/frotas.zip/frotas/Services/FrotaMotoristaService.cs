using frotas.Models;
using frotas.NHibernate;
using ISession = NHibernate.ISession;

namespace frotas.Services
{
    public class FrotaMotoristaService
    {

        public IEnumerable<FrotaMotoristaModel> GetList()
        {
            IList<FrotaMotoristaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaMotoristaModel> DAL = new NHibernateDAL<FrotaMotoristaModel>(Session);
                Result = DAL.Select(new FrotaMotoristaModel());
            }
            return Result;
        }

        public IEnumerable<FrotaMotoristaModel> GetListFilter(Filter filterObj)
        {
            IList<FrotaMotoristaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FrotaMotoristaModel where " + filterObj.Where;
                NHibernateDAL<FrotaMotoristaModel> DAL = new NHibernateDAL<FrotaMotoristaModel>(Session);
                Result = DAL.SelectListSql<FrotaMotoristaModel>(Query);
            }
            return Result;
        }
		
        public FrotaMotoristaModel GetObject(int id)
        {
            FrotaMotoristaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaMotoristaModel> DAL = new NHibernateDAL<FrotaMotoristaModel>(Session);
                Result = DAL.SelectId<FrotaMotoristaModel>(id);
            }
            return Result;
        }
		
        public void Insert(FrotaMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaMotoristaModel> DAL = new NHibernateDAL<FrotaMotoristaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FrotaMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaMotoristaModel> DAL = new NHibernateDAL<FrotaMotoristaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FrotaMotoristaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaMotoristaModel> DAL = new NHibernateDAL<FrotaMotoristaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}