using frotas.Models;
using frotas.NHibernate;
using ISession = NHibernate.ISession;

namespace frotas.Services
{
    public class FrotaCombustivelTipoService
    {

        public IEnumerable<FrotaCombustivelTipoModel> GetList()
        {
            IList<FrotaCombustivelTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaCombustivelTipoModel> DAL = new NHibernateDAL<FrotaCombustivelTipoModel>(Session);
                Result = DAL.Select(new FrotaCombustivelTipoModel());
            }
            return Result;
        }

        public IEnumerable<FrotaCombustivelTipoModel> GetListFilter(Filter filterObj)
        {
            IList<FrotaCombustivelTipoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FrotaCombustivelTipoModel where " + filterObj.Where;
                NHibernateDAL<FrotaCombustivelTipoModel> DAL = new NHibernateDAL<FrotaCombustivelTipoModel>(Session);
                Result = DAL.SelectListSql<FrotaCombustivelTipoModel>(Query);
            }
            return Result;
        }
		
        public FrotaCombustivelTipoModel GetObject(int id)
        {
            FrotaCombustivelTipoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaCombustivelTipoModel> DAL = new NHibernateDAL<FrotaCombustivelTipoModel>(Session);
                Result = DAL.SelectId<FrotaCombustivelTipoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FrotaCombustivelTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaCombustivelTipoModel> DAL = new NHibernateDAL<FrotaCombustivelTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FrotaCombustivelTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaCombustivelTipoModel> DAL = new NHibernateDAL<FrotaCombustivelTipoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FrotaCombustivelTipoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FrotaCombustivelTipoModel> DAL = new NHibernateDAL<FrotaCombustivelTipoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}