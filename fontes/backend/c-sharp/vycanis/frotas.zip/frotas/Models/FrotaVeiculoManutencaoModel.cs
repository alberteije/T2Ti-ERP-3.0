namespace frotas.Models
{
	public class FrotaVeiculoManutencaoModel
	{	
		public int? Id { get; set; } 

		public string? Tipo { get; set; } 

		public System.Nullable<System.DateTime> DataManutencao { get; set; } 

		public System.Nullable<System.Decimal> ValorManutencao { get; set; } 

		public string? Observacao { get; set; } 

		public FrotaVeiculoModel? FrotaVeiculoModel { get; set; } 

	}
}
