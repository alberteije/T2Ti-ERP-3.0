namespace frotas.Models
{
	public class FrotaVeiculoTipoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

	}
}
