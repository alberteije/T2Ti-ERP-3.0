namespace frotas.Models
{
	public class FrotaCombustivelControleModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataAbastecimento { get; set; } 

		public string? HoraAbastecimento { get; set; } 

		public System.Nullable<System.Decimal> ValorAbastecimento { get; set; } 

		public FrotaVeiculoModel? FrotaVeiculoModel { get; set; } 

	}
}
