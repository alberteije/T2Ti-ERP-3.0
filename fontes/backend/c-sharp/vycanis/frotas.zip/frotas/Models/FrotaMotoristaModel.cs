namespace frotas.Models
{
	public class FrotaMotoristaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? NumeroCnh { get; set; } 

		public string? CnhCategoria { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
