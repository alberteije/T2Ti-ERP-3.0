namespace frotas.Models
{
	public class FrotaIpvaControleModel
	{	
		public int? Id { get; set; } 

		public string? Ano { get; set; } 

		public string? Parcela { get; set; } 

		public System.Nullable<System.DateTime> DataVencimento { get; set; } 

		public System.Nullable<System.DateTime> DataPagamento { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public FrotaVeiculoModel? FrotaVeiculoModel { get; set; } 

	}
}
