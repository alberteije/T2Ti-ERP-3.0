namespace frotas.Models
{
	public class FrotaVeiculoSinistroModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataSinistro { get; set; } 

		public string? Observacao { get; set; } 

		public FrotaVeiculoModel? FrotaVeiculoModel { get; set; } 

	}
}
