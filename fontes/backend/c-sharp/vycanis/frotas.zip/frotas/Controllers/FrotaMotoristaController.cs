using Microsoft.AspNetCore.Mvc;
using frotas.Models;
using frotas.Services;

namespace frotas.Controllers
{
    [Route("frota-motorista")]
    [Produces("application/json")]
    public class FrotaMotoristaController : Controller
    {
		private readonly FrotaMotoristaService _service;

        public FrotaMotoristaController()
        {
            _service = new FrotaMotoristaService();
        }

        [HttpGet]
        public IActionResult GetListFrotaMotorista([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FrotaMotoristaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FrotaMotorista]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFrotaMotorista")]
        public IActionResult GetObjectFrotaMotorista(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FrotaMotorista]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FrotaMotorista]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFrotaMotorista([FromBody]FrotaMotoristaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FrotaMotorista]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFrotaMotorista", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FrotaMotorista]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFrotaMotorista([FromBody]FrotaMotoristaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FrotaMotorista]", null));
                }

                _service.Update(objJson);

                return GetObjectFrotaMotorista(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FrotaMotorista]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFrotaMotorista(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FrotaMotorista]", ex));
            }
        }

    }
}