using Microsoft.AspNetCore.Mvc;
using frotas.Models;
using frotas.Services;

namespace frotas.Controllers
{
    [Route("frota-veiculo")]
    [Produces("application/json")]
    public class FrotaVeiculoController : Controller
    {
		private readonly FrotaVeiculoService _service;

        public FrotaVeiculoController()
        {
            _service = new FrotaVeiculoService();
        }

        [HttpGet]
        public IActionResult GetListFrotaVeiculo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FrotaVeiculoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FrotaVeiculo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFrotaVeiculo")]
        public IActionResult GetObjectFrotaVeiculo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FrotaVeiculo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FrotaVeiculo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFrotaVeiculo([FromBody]FrotaVeiculoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FrotaVeiculo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFrotaVeiculo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FrotaVeiculo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFrotaVeiculo([FromBody]FrotaVeiculoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FrotaVeiculo]", null));
                }

                _service.Update(objJson);

                return GetObjectFrotaVeiculo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FrotaVeiculo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFrotaVeiculo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FrotaVeiculo]", ex));
            }
        }

    }
}