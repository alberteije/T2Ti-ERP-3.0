using Microsoft.AspNetCore.Mvc;
using frotas.Models;
using frotas.Services;

namespace frotas.Controllers
{
    [Route("frota-veiculo-tipo")]
    [Produces("application/json")]
    public class FrotaVeiculoTipoController : Controller
    {
		private readonly FrotaVeiculoTipoService _service;

        public FrotaVeiculoTipoController()
        {
            _service = new FrotaVeiculoTipoService();
        }

        [HttpGet]
        public IActionResult GetListFrotaVeiculoTipo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FrotaVeiculoTipoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FrotaVeiculoTipo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFrotaVeiculoTipo")]
        public IActionResult GetObjectFrotaVeiculoTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FrotaVeiculoTipo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FrotaVeiculoTipo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFrotaVeiculoTipo([FromBody]FrotaVeiculoTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FrotaVeiculoTipo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFrotaVeiculoTipo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FrotaVeiculoTipo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFrotaVeiculoTipo([FromBody]FrotaVeiculoTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FrotaVeiculoTipo]", null));
                }

                _service.Update(objJson);

                return GetObjectFrotaVeiculoTipo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FrotaVeiculoTipo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFrotaVeiculoTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FrotaVeiculoTipo]", ex));
            }
        }

    }
}