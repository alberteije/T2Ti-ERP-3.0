using Microsoft.AspNetCore.Mvc;
using frotas.Models;
using frotas.Services;

namespace frotas.Controllers
{
    [Route("frota-combustivel-tipo")]
    [Produces("application/json")]
    public class FrotaCombustivelTipoController : Controller
    {
		private readonly FrotaCombustivelTipoService _service;

        public FrotaCombustivelTipoController()
        {
            _service = new FrotaCombustivelTipoService();
        }

        [HttpGet]
        public IActionResult GetListFrotaCombustivelTipo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FrotaCombustivelTipoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FrotaCombustivelTipo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFrotaCombustivelTipo")]
        public IActionResult GetObjectFrotaCombustivelTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FrotaCombustivelTipo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FrotaCombustivelTipo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFrotaCombustivelTipo([FromBody]FrotaCombustivelTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FrotaCombustivelTipo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFrotaCombustivelTipo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FrotaCombustivelTipo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFrotaCombustivelTipo([FromBody]FrotaCombustivelTipoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FrotaCombustivelTipo]", null));
                }

                _service.Update(objJson);

                return GetObjectFrotaCombustivelTipo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FrotaCombustivelTipo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFrotaCombustivelTipo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FrotaCombustivelTipo]", ex));
            }
        }

    }
}