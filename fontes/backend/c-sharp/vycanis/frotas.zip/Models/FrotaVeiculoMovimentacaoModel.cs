namespace frotas.Models
{
	public class FrotaVeiculoMovimentacaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataSaida { get; set; } 

		public string? HoraSaida { get; set; } 

		public System.Nullable<System.DateTime> DataEntrada { get; set; } 

		public string? HoraEntrada { get; set; } 

		public string? Observacao { get; set; } 

		public FrotaVeiculoModel? FrotaVeiculoModel { get; set; } 

		public FrotaMotoristaModel? FrotaMotoristaModel { get; set; } 

	}
}
