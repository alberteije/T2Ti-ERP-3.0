namespace frotas.Models
{
	public class FrotaVeiculoModel
	{	
		public int? Id { get; set; } 

		public string? Marca { get; set; } 

		public string? Modelo { get; set; } 

		public string? ModeloAno { get; set; } 

		public string? Placa { get; set; } 

		public string? CodigoFipe { get; set; } 

		public string? Renavam { get; set; } 

		public string? IpvaMesVencimento { get; set; } 

		public string? DpvatMesVencimento { get; set; } 

		public FrotaVeiculoTipoModel? FrotaVeiculoTipoModel { get; set; } 

		public FrotaCombustivelTipoModel? FrotaCombustivelTipoModel { get; set; } 

		private IList<FrotaIpvaControleModel>? frotaIpvaControleModelList; 
		public IList<FrotaIpvaControleModel>? FrotaIpvaControleModelList 
		{ 
			get 
			{ 
				return frotaIpvaControleModelList; 
			} 
			set 
			{ 
				frotaIpvaControleModelList = value; 
				foreach (FrotaIpvaControleModel frotaIpvaControleModel in frotaIpvaControleModelList!) 
				{ 
					frotaIpvaControleModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

		private IList<FrotaDpvatControleModel>? frotaDpvatControleModelList; 
		public IList<FrotaDpvatControleModel>? FrotaDpvatControleModelList 
		{ 
			get 
			{ 
				return frotaDpvatControleModelList; 
			} 
			set 
			{ 
				frotaDpvatControleModelList = value; 
				foreach (FrotaDpvatControleModel frotaDpvatControleModel in frotaDpvatControleModelList!) 
				{ 
					frotaDpvatControleModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

		private IList<FrotaVeiculoSinistroModel>? frotaVeiculoSinistroModelList; 
		public IList<FrotaVeiculoSinistroModel>? FrotaVeiculoSinistroModelList 
		{ 
			get 
			{ 
				return frotaVeiculoSinistroModelList; 
			} 
			set 
			{ 
				frotaVeiculoSinistroModelList = value; 
				foreach (FrotaVeiculoSinistroModel frotaVeiculoSinistroModel in frotaVeiculoSinistroModelList!) 
				{ 
					frotaVeiculoSinistroModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

		private IList<FrotaVeiculoMovimentacaoModel>? frotaVeiculoMovimentacaoModelList; 
		public IList<FrotaVeiculoMovimentacaoModel>? FrotaVeiculoMovimentacaoModelList 
		{ 
			get 
			{ 
				return frotaVeiculoMovimentacaoModelList; 
			} 
			set 
			{ 
				frotaVeiculoMovimentacaoModelList = value; 
				foreach (FrotaVeiculoMovimentacaoModel frotaVeiculoMovimentacaoModel in frotaVeiculoMovimentacaoModelList!) 
				{ 
					frotaVeiculoMovimentacaoModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

		private IList<FrotaVeiculoPneuModel>? frotaVeiculoPneuModelList; 
		public IList<FrotaVeiculoPneuModel>? FrotaVeiculoPneuModelList 
		{ 
			get 
			{ 
				return frotaVeiculoPneuModelList; 
			} 
			set 
			{ 
				frotaVeiculoPneuModelList = value; 
				foreach (FrotaVeiculoPneuModel frotaVeiculoPneuModel in frotaVeiculoPneuModelList!) 
				{ 
					frotaVeiculoPneuModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

		private IList<FrotaVeiculoManutencaoModel>? frotaVeiculoManutencaoModelList; 
		public IList<FrotaVeiculoManutencaoModel>? FrotaVeiculoManutencaoModelList 
		{ 
			get 
			{ 
				return frotaVeiculoManutencaoModelList; 
			} 
			set 
			{ 
				frotaVeiculoManutencaoModelList = value; 
				foreach (FrotaVeiculoManutencaoModel frotaVeiculoManutencaoModel in frotaVeiculoManutencaoModelList!) 
				{ 
					frotaVeiculoManutencaoModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

		private IList<FrotaMultaControleModel>? frotaMultaControleModelList; 
		public IList<FrotaMultaControleModel>? FrotaMultaControleModelList 
		{ 
			get 
			{ 
				return frotaMultaControleModelList; 
			} 
			set 
			{ 
				frotaMultaControleModelList = value; 
				foreach (FrotaMultaControleModel frotaMultaControleModel in frotaMultaControleModelList!) 
				{ 
					frotaMultaControleModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

		private IList<FrotaCombustivelControleModel>? frotaCombustivelControleModelList; 
		public IList<FrotaCombustivelControleModel>? FrotaCombustivelControleModelList 
		{ 
			get 
			{ 
				return frotaCombustivelControleModelList; 
			} 
			set 
			{ 
				frotaCombustivelControleModelList = value; 
				foreach (FrotaCombustivelControleModel frotaCombustivelControleModel in frotaCombustivelControleModelList!) 
				{ 
					frotaCombustivelControleModel.FrotaVeiculoModel = this; 
				} 
			} 
		} 

	}
}
