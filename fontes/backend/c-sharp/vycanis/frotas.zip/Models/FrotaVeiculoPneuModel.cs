namespace frotas.Models
{
	public class FrotaVeiculoPneuModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataTroca { get; set; } 

		public System.Nullable<System.Decimal> ValorTroca { get; set; } 

		public string? PosicaoPneu { get; set; } 

		public string? MarcaPneu { get; set; } 

		public FrotaVeiculoModel? FrotaVeiculoModel { get; set; } 

	}
}
