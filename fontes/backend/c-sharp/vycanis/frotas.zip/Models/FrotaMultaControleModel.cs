namespace frotas.Models
{
	public class FrotaMultaControleModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataMulta { get; set; } 

		public int? Pontos { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public string? Observacao { get; set; } 

		public FrotaVeiculoModel? FrotaVeiculoModel { get; set; } 

	}
}
