using bpe.Models;
using bpe.NHibernate;
using ISession = NHibernate.ISession;

namespace bpe.Services
{
    public class BpeCabecalhoService
    {

        public IEnumerable<BpeCabecalhoModel> GetList()
        {
            IList<BpeCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BpeCabecalhoModel> DAL = new NHibernateDAL<BpeCabecalhoModel>(Session);
                Result = DAL.Select(new BpeCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<BpeCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<BpeCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from BpeCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<BpeCabecalhoModel> DAL = new NHibernateDAL<BpeCabecalhoModel>(Session);
                Result = DAL.SelectListSql<BpeCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public BpeCabecalhoModel GetObject(int id)
        {
            BpeCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BpeCabecalhoModel> DAL = new NHibernateDAL<BpeCabecalhoModel>(Session);
                Result = DAL.SelectId<BpeCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(BpeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BpeCabecalhoModel> DAL = new NHibernateDAL<BpeCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(BpeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BpeCabecalhoModel> DAL = new NHibernateDAL<BpeCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(BpeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<BpeCabecalhoModel> DAL = new NHibernateDAL<BpeCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}