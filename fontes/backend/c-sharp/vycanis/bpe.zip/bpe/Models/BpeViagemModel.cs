namespace bpe.Models
{
	public class BpeViagemModel
	{	
		public int? Id { get; set; } 

		public string? CodigoPercurso { get; set; } 

		public string? DescricaoPercurso { get; set; } 

		public string? TipoViagem { get; set; } 

		public string? TipoServico { get; set; } 

		public string? TipoAcomodacao { get; set; } 

		public string? TipoTrecho { get; set; } 

		public System.Nullable<System.DateTime> DataHoraViagem { get; set; } 

		public System.Nullable<System.DateTime> DataHoraConexao { get; set; } 

		public string? PrefixoLinha { get; set; } 

		public string? Poltrona { get; set; } 

		public string? Plataforma { get; set; } 

		public BpeCabecalhoModel? BpeCabecalhoModel { get; set; } 

	}
}
