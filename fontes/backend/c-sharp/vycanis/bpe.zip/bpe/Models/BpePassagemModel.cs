namespace bpe.Models
{
	public class BpePassagemModel
	{	
		public int? Id { get; set; } 

		public string? CodigoLocalidadeOrigem { get; set; } 

		public string? DescricaoLocalidadeOrigem { get; set; } 

		public string? CodigoLocalidadeDestino { get; set; } 

		public string? DescricaoLocalidadeDestino { get; set; } 

		public System.Nullable<System.DateTime> DataHoraEmbarque { get; set; } 

		public System.Nullable<System.DateTime> DataHoraValidade { get; set; } 

		public BpeCabecalhoModel? BpeCabecalhoModel { get; set; } 

	}
}
