namespace bpe.Models
{
	public class BpePassageiroModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Cpf { get; set; } 

		public string? TipoDocumentoIdentificacao { get; set; } 

		public string? NumeroDocumento { get; set; } 

		public string? DocumentoOutrosDescricao { get; set; } 

		public System.Nullable<System.DateTime> DataNascimento { get; set; } 

		public string? Telefone { get; set; } 

		public string? Email { get; set; } 

		public BpeCabecalhoModel? BpeCabecalhoModel { get; set; } 

	}
}
