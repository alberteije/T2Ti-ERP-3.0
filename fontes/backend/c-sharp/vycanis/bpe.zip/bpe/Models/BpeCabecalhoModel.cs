namespace bpe.Models
{
	public class BpeCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? UfEmitente { get; set; } 

		public string? Ambiente { get; set; } 

		public string? Modelo { get; set; } 

		public string? Serie { get; set; } 

		public string? Numero { get; set; } 

		public string? CodigoNumerico { get; set; } 

		public string? ChaveAcesso { get; set; } 

		public string? DigitoChaveAcesso { get; set; } 

		public string? Modal { get; set; } 

		public System.Nullable<System.DateTime> DataHoraEmissao { get; set; } 

		public string? TipoEmissao { get; set; } 

		public string? VersaoProcessoEmissao { get; set; } 

		public string? TipoBpe { get; set; } 

		public string? ConsumidorPresenca { get; set; } 

		public string? UfInicioViagem { get; set; } 

		public int? CodigoMunicipioInicioViagem { get; set; } 

		public string? UfFimViagem { get; set; } 

		public int? CodigoMunicipioFimViagem { get; set; } 

		public System.Nullable<System.Decimal> ValorBilhete { get; set; } 

		public System.Nullable<System.Decimal> ValorDesconto { get; set; } 

		public System.Nullable<System.Decimal> ValorPago { get; set; } 

		public System.Nullable<System.Decimal> ValorTroco { get; set; } 

		public string? TipoDesconto { get; set; } 

		public string? DescontoDescricao { get; set; } 

		public string? DescontoConcedidoOutros { get; set; } 

		public string? FormaPagamento { get; set; } 

		public string? FormaPagamentoOutros { get; set; } 

		public string? FormaPagamentoDocumento { get; set; } 

		public string? Cst { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculoIcms { get; set; } 

		public System.Nullable<System.Decimal> AliquotaIcms { get; set; } 

		public System.Nullable<System.Decimal> ValorIcms { get; set; } 

		public System.Nullable<System.Decimal> PercentualReducaoBcIcms { get; set; } 

		public string? InformacoesAddFisco { get; set; } 

		private IList<BpeEmitenteModel>? bpeEmitenteModelList; 
		public IList<BpeEmitenteModel>? BpeEmitenteModelList 
		{ 
			get 
			{ 
				return bpeEmitenteModelList; 
			} 
			set 
			{ 
				bpeEmitenteModelList = value; 
				foreach (BpeEmitenteModel bpeEmitenteModel in bpeEmitenteModelList!) 
				{ 
					bpeEmitenteModel.BpeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<BpePassageiroModel>? bpePassageiroModelList; 
		public IList<BpePassageiroModel>? BpePassageiroModelList 
		{ 
			get 
			{ 
				return bpePassageiroModelList; 
			} 
			set 
			{ 
				bpePassageiroModelList = value; 
				foreach (BpePassageiroModel bpePassageiroModel in bpePassageiroModelList!) 
				{ 
					bpePassageiroModel.BpeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<BpeCompradorModel>? bpeCompradorModelList; 
		public IList<BpeCompradorModel>? BpeCompradorModelList 
		{ 
			get 
			{ 
				return bpeCompradorModelList; 
			} 
			set 
			{ 
				bpeCompradorModelList = value; 
				foreach (BpeCompradorModel bpeCompradorModel in bpeCompradorModelList!) 
				{ 
					bpeCompradorModel.BpeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<BpeViagemModel>? bpeViagemModelList; 
		public IList<BpeViagemModel>? BpeViagemModelList 
		{ 
			get 
			{ 
				return bpeViagemModelList; 
			} 
			set 
			{ 
				bpeViagemModelList = value; 
				foreach (BpeViagemModel bpeViagemModel in bpeViagemModelList!) 
				{ 
					bpeViagemModel.BpeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<BpeAgenciaModel>? bpeAgenciaModelList; 
		public IList<BpeAgenciaModel>? BpeAgenciaModelList 
		{ 
			get 
			{ 
				return bpeAgenciaModelList; 
			} 
			set 
			{ 
				bpeAgenciaModelList = value; 
				foreach (BpeAgenciaModel bpeAgenciaModel in bpeAgenciaModelList!) 
				{ 
					bpeAgenciaModel.BpeCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<BpePassagemModel>? bpePassagemModelList; 
		public IList<BpePassagemModel>? BpePassagemModelList 
		{ 
			get 
			{ 
				return bpePassagemModelList; 
			} 
			set 
			{ 
				bpePassagemModelList = value; 
				foreach (BpePassagemModel bpePassagemModel in bpePassagemModelList!) 
				{ 
					bpePassagemModel.BpeCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
