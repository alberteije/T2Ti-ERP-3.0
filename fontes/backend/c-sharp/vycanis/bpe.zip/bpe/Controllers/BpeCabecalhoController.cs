using Microsoft.AspNetCore.Mvc;
using bpe.Models;
using bpe.Services;

namespace bpe.Controllers
{
    [Route("bpe-cabecalho")]
    [Produces("application/json")]
    public class BpeCabecalhoController : Controller
    {
		private readonly BpeCabecalhoService _service;

        public BpeCabecalhoController()
        {
            _service = new BpeCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListBpeCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<BpeCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList BpeCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectBpeCabecalho")]
        public IActionResult GetObjectBpeCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject BpeCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject BpeCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertBpeCabecalho([FromBody]BpeCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert BpeCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectBpeCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert BpeCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateBpeCabecalho([FromBody]BpeCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update BpeCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectBpeCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update BpeCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBpeCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete BpeCabecalho]", ex));
            }
        }

    }
}