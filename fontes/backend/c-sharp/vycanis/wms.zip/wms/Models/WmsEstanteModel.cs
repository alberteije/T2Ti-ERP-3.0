namespace wms.Models
{
	public class WmsEstanteModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public int? QuantidadeCaixa { get; set; } 

		public WmsRuaModel? WmsRuaModel { get; set; } 

	}
}
