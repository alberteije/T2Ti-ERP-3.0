namespace wms.Models
{
	public class WmsOrdemSeparacaoDetModel
	{	
		public int? Id { get; set; } 

		public int? Quantidade { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

		public WmsOrdemSeparacaoCabModel? WmsOrdemSeparacaoCabModel { get; set; } 

	}
}
