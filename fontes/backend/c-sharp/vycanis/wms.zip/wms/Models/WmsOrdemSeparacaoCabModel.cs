namespace wms.Models
{
	public class WmsOrdemSeparacaoCabModel
	{	
		public int? Id { get; set; } 

		public string? Origem { get; set; } 

		public System.Nullable<System.DateTime> DataSolicitacao { get; set; } 

		public System.Nullable<System.DateTime> DataLimite { get; set; } 

		private IList<WmsOrdemSeparacaoDetModel>? wmsOrdemSeparacaoDetModelList; 
		public IList<WmsOrdemSeparacaoDetModel>? WmsOrdemSeparacaoDetModelList 
		{ 
			get 
			{ 
				return wmsOrdemSeparacaoDetModelList; 
			} 
			set 
			{ 
				wmsOrdemSeparacaoDetModelList = value; 
				foreach (WmsOrdemSeparacaoDetModel wmsOrdemSeparacaoDetModel in wmsOrdemSeparacaoDetModelList!) 
				{ 
					wmsOrdemSeparacaoDetModel.WmsOrdemSeparacaoCabModel = this; 
				} 
			} 
		} 

	}
}
