namespace wms.Models
{
	public class WmsArmazenamentoModel
	{	
		public int? Id { get; set; } 

		public int? Quantidade { get; set; } 

		public WmsCaixaModel? WmsCaixaModel { get; set; } 

		public WmsRecebimentoDetalheModel? WmsRecebimentoDetalheModel { get; set; } 

	}
}
