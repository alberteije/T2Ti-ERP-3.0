using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-caixa")]
    [Produces("application/json")]
    public class WmsCaixaController : Controller
    {
		private readonly WmsCaixaService _service;

        public WmsCaixaController()
        {
            _service = new WmsCaixaService();
        }

        [HttpGet]
        public IActionResult GetListWmsCaixa([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsCaixaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsCaixa]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsCaixa")]
        public IActionResult GetObjectWmsCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsCaixa]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsCaixa]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsCaixa([FromBody]WmsCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsCaixa]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsCaixa", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsCaixa]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsCaixa([FromBody]WmsCaixaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsCaixa]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsCaixa(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsCaixa]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsCaixa(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsCaixa]", ex));
            }
        }

    }
}