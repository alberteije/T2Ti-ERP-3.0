using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-rua")]
    [Produces("application/json")]
    public class WmsRuaController : Controller
    {
		private readonly WmsRuaService _service;

        public WmsRuaController()
        {
            _service = new WmsRuaService();
        }

        [HttpGet]
        public IActionResult GetListWmsRua([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsRuaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsRua]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsRua")]
        public IActionResult GetObjectWmsRua(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsRua]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsRua]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsRua([FromBody]WmsRuaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsRua]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsRua", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsRua]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsRua([FromBody]WmsRuaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsRua]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsRua(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsRua]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsRua(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsRua]", ex));
            }
        }

    }
}