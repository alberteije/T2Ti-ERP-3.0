using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-parametro")]
    [Produces("application/json")]
    public class WmsParametroController : Controller
    {
		private readonly WmsParametroService _service;

        public WmsParametroController()
        {
            _service = new WmsParametroService();
        }

        [HttpGet]
        public IActionResult GetListWmsParametro([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsParametroModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsParametro]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsParametro")]
        public IActionResult GetObjectWmsParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsParametro]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsParametro]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsParametro([FromBody]WmsParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsParametro]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsParametro", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsParametro]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsParametro([FromBody]WmsParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsParametro]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsParametro(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsParametro]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsParametro]", ex));
            }
        }

    }
}