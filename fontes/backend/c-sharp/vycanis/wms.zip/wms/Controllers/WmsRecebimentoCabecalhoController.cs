using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-recebimento-cabecalho")]
    [Produces("application/json")]
    public class WmsRecebimentoCabecalhoController : Controller
    {
		private readonly WmsRecebimentoCabecalhoService _service;

        public WmsRecebimentoCabecalhoController()
        {
            _service = new WmsRecebimentoCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListWmsRecebimentoCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsRecebimentoCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsRecebimentoCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsRecebimentoCabecalho")]
        public IActionResult GetObjectWmsRecebimentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsRecebimentoCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsRecebimentoCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsRecebimentoCabecalho([FromBody]WmsRecebimentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsRecebimentoCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsRecebimentoCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsRecebimentoCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsRecebimentoCabecalho([FromBody]WmsRecebimentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsRecebimentoCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsRecebimentoCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsRecebimentoCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsRecebimentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsRecebimentoCabecalho]", ex));
            }
        }

    }
}