using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsRuaService
    {

        public IEnumerable<WmsRuaModel> GetList()
        {
            IList<WmsRuaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRuaModel> DAL = new NHibernateDAL<WmsRuaModel>(Session);
                Result = DAL.Select(new WmsRuaModel());
            }
            return Result;
        }

        public IEnumerable<WmsRuaModel> GetListFilter(Filter filterObj)
        {
            IList<WmsRuaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsRuaModel where " + filterObj.Where;
                NHibernateDAL<WmsRuaModel> DAL = new NHibernateDAL<WmsRuaModel>(Session);
                Result = DAL.SelectListSql<WmsRuaModel>(Query);
            }
            return Result;
        }
		
        public WmsRuaModel GetObject(int id)
        {
            WmsRuaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRuaModel> DAL = new NHibernateDAL<WmsRuaModel>(Session);
                Result = DAL.SelectId<WmsRuaModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsRuaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRuaModel> DAL = new NHibernateDAL<WmsRuaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsRuaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRuaModel> DAL = new NHibernateDAL<WmsRuaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsRuaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRuaModel> DAL = new NHibernateDAL<WmsRuaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}