using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsParametroService
    {

        public IEnumerable<WmsParametroModel> GetList()
        {
            IList<WmsParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsParametroModel> DAL = new NHibernateDAL<WmsParametroModel>(Session);
                Result = DAL.Select(new WmsParametroModel());
            }
            return Result;
        }

        public IEnumerable<WmsParametroModel> GetListFilter(Filter filterObj)
        {
            IList<WmsParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsParametroModel where " + filterObj.Where;
                NHibernateDAL<WmsParametroModel> DAL = new NHibernateDAL<WmsParametroModel>(Session);
                Result = DAL.SelectListSql<WmsParametroModel>(Query);
            }
            return Result;
        }
		
        public WmsParametroModel GetObject(int id)
        {
            WmsParametroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsParametroModel> DAL = new NHibernateDAL<WmsParametroModel>(Session);
                Result = DAL.SelectId<WmsParametroModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsParametroModel> DAL = new NHibernateDAL<WmsParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsParametroModel> DAL = new NHibernateDAL<WmsParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsParametroModel> DAL = new NHibernateDAL<WmsParametroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}