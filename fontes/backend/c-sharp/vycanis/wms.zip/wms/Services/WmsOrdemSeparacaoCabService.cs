using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsOrdemSeparacaoCabService
    {

        public IEnumerable<WmsOrdemSeparacaoCabModel> GetList()
        {
            IList<WmsOrdemSeparacaoCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsOrdemSeparacaoCabModel> DAL = new NHibernateDAL<WmsOrdemSeparacaoCabModel>(Session);
                Result = DAL.Select(new WmsOrdemSeparacaoCabModel());
            }
            return Result;
        }

        public IEnumerable<WmsOrdemSeparacaoCabModel> GetListFilter(Filter filterObj)
        {
            IList<WmsOrdemSeparacaoCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsOrdemSeparacaoCabModel where " + filterObj.Where;
                NHibernateDAL<WmsOrdemSeparacaoCabModel> DAL = new NHibernateDAL<WmsOrdemSeparacaoCabModel>(Session);
                Result = DAL.SelectListSql<WmsOrdemSeparacaoCabModel>(Query);
            }
            return Result;
        }
		
        public WmsOrdemSeparacaoCabModel GetObject(int id)
        {
            WmsOrdemSeparacaoCabModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsOrdemSeparacaoCabModel> DAL = new NHibernateDAL<WmsOrdemSeparacaoCabModel>(Session);
                Result = DAL.SelectId<WmsOrdemSeparacaoCabModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsOrdemSeparacaoCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsOrdemSeparacaoCabModel> DAL = new NHibernateDAL<WmsOrdemSeparacaoCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsOrdemSeparacaoCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsOrdemSeparacaoCabModel> DAL = new NHibernateDAL<WmsOrdemSeparacaoCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsOrdemSeparacaoCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsOrdemSeparacaoCabModel> DAL = new NHibernateDAL<WmsOrdemSeparacaoCabModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}