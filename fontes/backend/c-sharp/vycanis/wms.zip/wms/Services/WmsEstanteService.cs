using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsEstanteService
    {

        public IEnumerable<WmsEstanteModel> GetList()
        {
            IList<WmsEstanteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsEstanteModel> DAL = new NHibernateDAL<WmsEstanteModel>(Session);
                Result = DAL.Select(new WmsEstanteModel());
            }
            return Result;
        }

        public IEnumerable<WmsEstanteModel> GetListFilter(Filter filterObj)
        {
            IList<WmsEstanteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsEstanteModel where " + filterObj.Where;
                NHibernateDAL<WmsEstanteModel> DAL = new NHibernateDAL<WmsEstanteModel>(Session);
                Result = DAL.SelectListSql<WmsEstanteModel>(Query);
            }
            return Result;
        }
		
        public WmsEstanteModel GetObject(int id)
        {
            WmsEstanteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsEstanteModel> DAL = new NHibernateDAL<WmsEstanteModel>(Session);
                Result = DAL.SelectId<WmsEstanteModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsEstanteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsEstanteModel> DAL = new NHibernateDAL<WmsEstanteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsEstanteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsEstanteModel> DAL = new NHibernateDAL<WmsEstanteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsEstanteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsEstanteModel> DAL = new NHibernateDAL<WmsEstanteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}