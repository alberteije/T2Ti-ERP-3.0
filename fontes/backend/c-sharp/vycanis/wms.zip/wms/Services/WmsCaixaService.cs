using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsCaixaService
    {

        public IEnumerable<WmsCaixaModel> GetList()
        {
            IList<WmsCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsCaixaModel> DAL = new NHibernateDAL<WmsCaixaModel>(Session);
                Result = DAL.Select(new WmsCaixaModel());
            }
            return Result;
        }

        public IEnumerable<WmsCaixaModel> GetListFilter(Filter filterObj)
        {
            IList<WmsCaixaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsCaixaModel where " + filterObj.Where;
                NHibernateDAL<WmsCaixaModel> DAL = new NHibernateDAL<WmsCaixaModel>(Session);
                Result = DAL.SelectListSql<WmsCaixaModel>(Query);
            }
            return Result;
        }
		
        public WmsCaixaModel GetObject(int id)
        {
            WmsCaixaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsCaixaModel> DAL = new NHibernateDAL<WmsCaixaModel>(Session);
                Result = DAL.SelectId<WmsCaixaModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsCaixaModel> DAL = new NHibernateDAL<WmsCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsCaixaModel> DAL = new NHibernateDAL<WmsCaixaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsCaixaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsCaixaModel> DAL = new NHibernateDAL<WmsCaixaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}