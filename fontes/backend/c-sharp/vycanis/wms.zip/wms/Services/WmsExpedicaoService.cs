using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsExpedicaoService
    {

        public IEnumerable<WmsExpedicaoModel> GetList()
        {
            IList<WmsExpedicaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsExpedicaoModel> DAL = new NHibernateDAL<WmsExpedicaoModel>(Session);
                Result = DAL.Select(new WmsExpedicaoModel());
            }
            return Result;
        }

        public IEnumerable<WmsExpedicaoModel> GetListFilter(Filter filterObj)
        {
            IList<WmsExpedicaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsExpedicaoModel where " + filterObj.Where;
                NHibernateDAL<WmsExpedicaoModel> DAL = new NHibernateDAL<WmsExpedicaoModel>(Session);
                Result = DAL.SelectListSql<WmsExpedicaoModel>(Query);
            }
            return Result;
        }
		
        public WmsExpedicaoModel GetObject(int id)
        {
            WmsExpedicaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsExpedicaoModel> DAL = new NHibernateDAL<WmsExpedicaoModel>(Session);
                Result = DAL.SelectId<WmsExpedicaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsExpedicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsExpedicaoModel> DAL = new NHibernateDAL<WmsExpedicaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsExpedicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsExpedicaoModel> DAL = new NHibernateDAL<WmsExpedicaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsExpedicaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsExpedicaoModel> DAL = new NHibernateDAL<WmsExpedicaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}