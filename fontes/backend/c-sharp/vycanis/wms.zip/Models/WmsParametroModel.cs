namespace wms.Models
{
	public class WmsParametroModel
	{	
		public int? Id { get; set; } 

		public int? HoraPorVolume { get; set; } 

		public int? PessoaPorVolume { get; set; } 

		public int? HoraPorPeso { get; set; } 

		public int? PessoaPorPeso { get; set; } 

		public string? ItemDiferenteCaixa { get; set; } 

	}
}
