namespace wms.Models
{
	public class WmsRecebimentoDetalheModel
	{	
		public int? Id { get; set; } 

		public int? QuantidadeVolume { get; set; } 

		public int? QuantidadeItemPorVolume { get; set; } 

		public int? QuantidadeRecebida { get; set; } 

		public string? Destino { get; set; } 

		public WmsRecebimentoCabecalhoModel? WmsRecebimentoCabecalhoModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
