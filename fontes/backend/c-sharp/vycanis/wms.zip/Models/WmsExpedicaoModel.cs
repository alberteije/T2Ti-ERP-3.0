namespace wms.Models
{
	public class WmsExpedicaoModel
	{	
		public int? Id { get; set; } 

		public int? Quantidade { get; set; } 

		public System.Nullable<System.DateTime> DataSaida { get; set; } 

		public WmsOrdemSeparacaoDetModel? WmsOrdemSeparacaoDetModel { get; set; } 

		public WmsArmazenamentoModel? WmsArmazenamentoModel { get; set; } 

	}
}
