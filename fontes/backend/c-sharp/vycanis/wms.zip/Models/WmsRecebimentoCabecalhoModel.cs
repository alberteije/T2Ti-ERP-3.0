namespace wms.Models
{
	public class WmsRecebimentoCabecalhoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataRecebimento { get; set; } 

		public string? HoraInicio { get; set; } 

		public string? HoraFim { get; set; } 

		public int? VolumeRecebido { get; set; } 

		public System.Nullable<System.Decimal> PesoRecebido { get; set; } 

		public string? Inconsistencia { get; set; } 

		public string? Observacao { get; set; } 

		public WmsAgendamentoModel? WmsAgendamentoModel { get; set; } 

		private IList<WmsRecebimentoDetalheModel>? wmsRecebimentoDetalheModelList; 
		public IList<WmsRecebimentoDetalheModel>? WmsRecebimentoDetalheModelList 
		{ 
			get 
			{ 
				return wmsRecebimentoDetalheModelList; 
			} 
			set 
			{ 
				wmsRecebimentoDetalheModelList = value; 
				foreach (WmsRecebimentoDetalheModel wmsRecebimentoDetalheModel in wmsRecebimentoDetalheModelList!) 
				{ 
					wmsRecebimentoDetalheModel.WmsRecebimentoCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
