namespace wms.Models
{
	public class WmsAgendamentoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataOperacao { get; set; } 

		public string? HoraOperacao { get; set; } 

		public string? LocalOperacao { get; set; } 

		public int? QuantidadeVolume { get; set; } 

		public System.Nullable<System.Decimal> PesoTotalVolume { get; set; } 

		public int? QuantidadePessoa { get; set; } 

		public int? QuantidadeHora { get; set; } 

	}
}
