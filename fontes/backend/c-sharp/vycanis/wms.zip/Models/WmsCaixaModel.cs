namespace wms.Models
{
	public class WmsCaixaModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public int? Altura { get; set; } 

		public int? Largura { get; set; } 

		public int? Profundidade { get; set; } 

		public WmsEstanteModel? WmsEstanteModel { get; set; } 

		private IList<WmsArmazenamentoModel>? wmsArmazenamentoModelList; 
		public IList<WmsArmazenamentoModel>? WmsArmazenamentoModelList 
		{ 
			get 
			{ 
				return wmsArmazenamentoModelList; 
			} 
			set 
			{ 
				wmsArmazenamentoModelList = value; 
				foreach (WmsArmazenamentoModel wmsArmazenamentoModel in wmsArmazenamentoModelList!) 
				{ 
					wmsArmazenamentoModel.WmsCaixaModel = this; 
				} 
			} 
		} 

	}
}
