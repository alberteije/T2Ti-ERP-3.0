using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsRecebimentoCabecalhoService
    {

        public IEnumerable<WmsRecebimentoCabecalhoModel> GetList()
        {
            IList<WmsRecebimentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRecebimentoCabecalhoModel> DAL = new NHibernateDAL<WmsRecebimentoCabecalhoModel>(Session);
                Result = DAL.Select(new WmsRecebimentoCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<WmsRecebimentoCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<WmsRecebimentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsRecebimentoCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<WmsRecebimentoCabecalhoModel> DAL = new NHibernateDAL<WmsRecebimentoCabecalhoModel>(Session);
                Result = DAL.SelectListSql<WmsRecebimentoCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public WmsRecebimentoCabecalhoModel GetObject(int id)
        {
            WmsRecebimentoCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRecebimentoCabecalhoModel> DAL = new NHibernateDAL<WmsRecebimentoCabecalhoModel>(Session);
                Result = DAL.SelectId<WmsRecebimentoCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsRecebimentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRecebimentoCabecalhoModel> DAL = new NHibernateDAL<WmsRecebimentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsRecebimentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRecebimentoCabecalhoModel> DAL = new NHibernateDAL<WmsRecebimentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsRecebimentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsRecebimentoCabecalhoModel> DAL = new NHibernateDAL<WmsRecebimentoCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}