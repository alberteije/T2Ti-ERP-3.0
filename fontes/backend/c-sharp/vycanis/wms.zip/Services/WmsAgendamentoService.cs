using wms.Models;
using wms.NHibernate;
using ISession = NHibernate.ISession;

namespace wms.Services
{
    public class WmsAgendamentoService
    {

        public IEnumerable<WmsAgendamentoModel> GetList()
        {
            IList<WmsAgendamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsAgendamentoModel> DAL = new NHibernateDAL<WmsAgendamentoModel>(Session);
                Result = DAL.Select(new WmsAgendamentoModel());
            }
            return Result;
        }

        public IEnumerable<WmsAgendamentoModel> GetListFilter(Filter filterObj)
        {
            IList<WmsAgendamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from WmsAgendamentoModel where " + filterObj.Where;
                NHibernateDAL<WmsAgendamentoModel> DAL = new NHibernateDAL<WmsAgendamentoModel>(Session);
                Result = DAL.SelectListSql<WmsAgendamentoModel>(Query);
            }
            return Result;
        }
		
        public WmsAgendamentoModel GetObject(int id)
        {
            WmsAgendamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsAgendamentoModel> DAL = new NHibernateDAL<WmsAgendamentoModel>(Session);
                Result = DAL.SelectId<WmsAgendamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(WmsAgendamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsAgendamentoModel> DAL = new NHibernateDAL<WmsAgendamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(WmsAgendamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsAgendamentoModel> DAL = new NHibernateDAL<WmsAgendamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(WmsAgendamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<WmsAgendamentoModel> DAL = new NHibernateDAL<WmsAgendamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}