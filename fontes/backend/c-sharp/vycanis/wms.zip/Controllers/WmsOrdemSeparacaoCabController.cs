using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-ordem-separacao-cab")]
    [Produces("application/json")]
    public class WmsOrdemSeparacaoCabController : Controller
    {
		private readonly WmsOrdemSeparacaoCabService _service;

        public WmsOrdemSeparacaoCabController()
        {
            _service = new WmsOrdemSeparacaoCabService();
        }

        [HttpGet]
        public IActionResult GetListWmsOrdemSeparacaoCab([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsOrdemSeparacaoCabModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsOrdemSeparacaoCab]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsOrdemSeparacaoCab")]
        public IActionResult GetObjectWmsOrdemSeparacaoCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsOrdemSeparacaoCab]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsOrdemSeparacaoCab]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsOrdemSeparacaoCab([FromBody]WmsOrdemSeparacaoCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsOrdemSeparacaoCab]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsOrdemSeparacaoCab", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsOrdemSeparacaoCab]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsOrdemSeparacaoCab([FromBody]WmsOrdemSeparacaoCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsOrdemSeparacaoCab]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsOrdemSeparacaoCab(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsOrdemSeparacaoCab]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsOrdemSeparacaoCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsOrdemSeparacaoCab]", ex));
            }
        }

    }
}