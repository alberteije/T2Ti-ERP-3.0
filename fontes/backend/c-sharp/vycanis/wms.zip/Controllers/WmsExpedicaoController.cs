using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-expedicao")]
    [Produces("application/json")]
    public class WmsExpedicaoController : Controller
    {
		private readonly WmsExpedicaoService _service;

        public WmsExpedicaoController()
        {
            _service = new WmsExpedicaoService();
        }

        [HttpGet]
        public IActionResult GetListWmsExpedicao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsExpedicaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsExpedicao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsExpedicao")]
        public IActionResult GetObjectWmsExpedicao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsExpedicao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsExpedicao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsExpedicao([FromBody]WmsExpedicaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsExpedicao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsExpedicao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsExpedicao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsExpedicao([FromBody]WmsExpedicaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsExpedicao]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsExpedicao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsExpedicao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsExpedicao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsExpedicao]", ex));
            }
        }

    }
}