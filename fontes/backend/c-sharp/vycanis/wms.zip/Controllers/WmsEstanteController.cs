using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-estante")]
    [Produces("application/json")]
    public class WmsEstanteController : Controller
    {
		private readonly WmsEstanteService _service;

        public WmsEstanteController()
        {
            _service = new WmsEstanteService();
        }

        [HttpGet]
        public IActionResult GetListWmsEstante([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsEstanteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsEstante]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsEstante")]
        public IActionResult GetObjectWmsEstante(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsEstante]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsEstante]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsEstante([FromBody]WmsEstanteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsEstante]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsEstante", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsEstante]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsEstante([FromBody]WmsEstanteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsEstante]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsEstante(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsEstante]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsEstante(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsEstante]", ex));
            }
        }

    }
}