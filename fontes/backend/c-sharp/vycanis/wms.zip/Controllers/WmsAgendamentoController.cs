using Microsoft.AspNetCore.Mvc;
using wms.Models;
using wms.Services;

namespace wms.Controllers
{
    [Route("wms-agendamento")]
    [Produces("application/json")]
    public class WmsAgendamentoController : Controller
    {
		private readonly WmsAgendamentoService _service;

        public WmsAgendamentoController()
        {
            _service = new WmsAgendamentoService();
        }

        [HttpGet]
        public IActionResult GetListWmsAgendamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<WmsAgendamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList WmsAgendamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectWmsAgendamento")]
        public IActionResult GetObjectWmsAgendamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject WmsAgendamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject WmsAgendamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertWmsAgendamento([FromBody]WmsAgendamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert WmsAgendamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectWmsAgendamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert WmsAgendamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateWmsAgendamento([FromBody]WmsAgendamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update WmsAgendamento]", null));
                }

                _service.Update(objJson);

                return GetObjectWmsAgendamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update WmsAgendamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWmsAgendamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete WmsAgendamento]", ex));
            }
        }

    }
}