using esocial.Models;
using esocial.NHibernate;
using ISession = NHibernate.ISession;

namespace esocial.Services
{
    public class EsocialTipoAfastamentoService
    {

        public IEnumerable<EsocialTipoAfastamentoModel> GetList()
        {
            IList<EsocialTipoAfastamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialTipoAfastamentoModel> DAL = new NHibernateDAL<EsocialTipoAfastamentoModel>(Session);
                Result = DAL.Select(new EsocialTipoAfastamentoModel());
            }
            return Result;
        }

        public IEnumerable<EsocialTipoAfastamentoModel> GetListFilter(Filter filterObj)
        {
            IList<EsocialTipoAfastamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EsocialTipoAfastamentoModel where " + filterObj.Where;
                NHibernateDAL<EsocialTipoAfastamentoModel> DAL = new NHibernateDAL<EsocialTipoAfastamentoModel>(Session);
                Result = DAL.SelectListSql<EsocialTipoAfastamentoModel>(Query);
            }
            return Result;
        }
		
        public EsocialTipoAfastamentoModel GetObject(int id)
        {
            EsocialTipoAfastamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialTipoAfastamentoModel> DAL = new NHibernateDAL<EsocialTipoAfastamentoModel>(Session);
                Result = DAL.SelectId<EsocialTipoAfastamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(EsocialTipoAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialTipoAfastamentoModel> DAL = new NHibernateDAL<EsocialTipoAfastamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EsocialTipoAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialTipoAfastamentoModel> DAL = new NHibernateDAL<EsocialTipoAfastamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EsocialTipoAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialTipoAfastamentoModel> DAL = new NHibernateDAL<EsocialTipoAfastamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}