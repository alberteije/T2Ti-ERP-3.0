using esocial.Models;
using esocial.NHibernate;
using ISession = NHibernate.ISession;

namespace esocial.Services
{
    public class EsocialNaturezaJuridicaService
    {

        public IEnumerable<EsocialNaturezaJuridicaModel> GetList()
        {
            IList<EsocialNaturezaJuridicaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialNaturezaJuridicaModel> DAL = new NHibernateDAL<EsocialNaturezaJuridicaModel>(Session);
                Result = DAL.Select(new EsocialNaturezaJuridicaModel());
            }
            return Result;
        }

        public IEnumerable<EsocialNaturezaJuridicaModel> GetListFilter(Filter filterObj)
        {
            IList<EsocialNaturezaJuridicaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EsocialNaturezaJuridicaModel where " + filterObj.Where;
                NHibernateDAL<EsocialNaturezaJuridicaModel> DAL = new NHibernateDAL<EsocialNaturezaJuridicaModel>(Session);
                Result = DAL.SelectListSql<EsocialNaturezaJuridicaModel>(Query);
            }
            return Result;
        }
		
        public EsocialNaturezaJuridicaModel GetObject(int id)
        {
            EsocialNaturezaJuridicaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialNaturezaJuridicaModel> DAL = new NHibernateDAL<EsocialNaturezaJuridicaModel>(Session);
                Result = DAL.SelectId<EsocialNaturezaJuridicaModel>(id);
            }
            return Result;
        }
		
        public void Insert(EsocialNaturezaJuridicaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialNaturezaJuridicaModel> DAL = new NHibernateDAL<EsocialNaturezaJuridicaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EsocialNaturezaJuridicaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialNaturezaJuridicaModel> DAL = new NHibernateDAL<EsocialNaturezaJuridicaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EsocialNaturezaJuridicaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialNaturezaJuridicaModel> DAL = new NHibernateDAL<EsocialNaturezaJuridicaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}