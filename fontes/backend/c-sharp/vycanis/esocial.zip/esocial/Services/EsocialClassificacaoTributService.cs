using esocial.Models;
using esocial.NHibernate;
using ISession = NHibernate.ISession;

namespace esocial.Services
{
    public class EsocialClassificacaoTributService
    {

        public IEnumerable<EsocialClassificacaoTributModel> GetList()
        {
            IList<EsocialClassificacaoTributModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialClassificacaoTributModel> DAL = new NHibernateDAL<EsocialClassificacaoTributModel>(Session);
                Result = DAL.Select(new EsocialClassificacaoTributModel());
            }
            return Result;
        }

        public IEnumerable<EsocialClassificacaoTributModel> GetListFilter(Filter filterObj)
        {
            IList<EsocialClassificacaoTributModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EsocialClassificacaoTributModel where " + filterObj.Where;
                NHibernateDAL<EsocialClassificacaoTributModel> DAL = new NHibernateDAL<EsocialClassificacaoTributModel>(Session);
                Result = DAL.SelectListSql<EsocialClassificacaoTributModel>(Query);
            }
            return Result;
        }
		
        public EsocialClassificacaoTributModel GetObject(int id)
        {
            EsocialClassificacaoTributModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialClassificacaoTributModel> DAL = new NHibernateDAL<EsocialClassificacaoTributModel>(Session);
                Result = DAL.SelectId<EsocialClassificacaoTributModel>(id);
            }
            return Result;
        }
		
        public void Insert(EsocialClassificacaoTributModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialClassificacaoTributModel> DAL = new NHibernateDAL<EsocialClassificacaoTributModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EsocialClassificacaoTributModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialClassificacaoTributModel> DAL = new NHibernateDAL<EsocialClassificacaoTributModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EsocialClassificacaoTributModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialClassificacaoTributModel> DAL = new NHibernateDAL<EsocialClassificacaoTributModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}