using esocial.Models;
using esocial.NHibernate;
using ISession = NHibernate.ISession;

namespace esocial.Services
{
    public class EsocialMotivoDesligamentoService
    {

        public IEnumerable<EsocialMotivoDesligamentoModel> GetList()
        {
            IList<EsocialMotivoDesligamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialMotivoDesligamentoModel> DAL = new NHibernateDAL<EsocialMotivoDesligamentoModel>(Session);
                Result = DAL.Select(new EsocialMotivoDesligamentoModel());
            }
            return Result;
        }

        public IEnumerable<EsocialMotivoDesligamentoModel> GetListFilter(Filter filterObj)
        {
            IList<EsocialMotivoDesligamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EsocialMotivoDesligamentoModel where " + filterObj.Where;
                NHibernateDAL<EsocialMotivoDesligamentoModel> DAL = new NHibernateDAL<EsocialMotivoDesligamentoModel>(Session);
                Result = DAL.SelectListSql<EsocialMotivoDesligamentoModel>(Query);
            }
            return Result;
        }
		
        public EsocialMotivoDesligamentoModel GetObject(int id)
        {
            EsocialMotivoDesligamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialMotivoDesligamentoModel> DAL = new NHibernateDAL<EsocialMotivoDesligamentoModel>(Session);
                Result = DAL.SelectId<EsocialMotivoDesligamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(EsocialMotivoDesligamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialMotivoDesligamentoModel> DAL = new NHibernateDAL<EsocialMotivoDesligamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EsocialMotivoDesligamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialMotivoDesligamentoModel> DAL = new NHibernateDAL<EsocialMotivoDesligamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EsocialMotivoDesligamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialMotivoDesligamentoModel> DAL = new NHibernateDAL<EsocialMotivoDesligamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}