using Microsoft.AspNetCore.Mvc;
using esocial.Models;
using esocial.Services;

namespace esocial.Controllers
{
    [Route("esocial-rubrica")]
    [Produces("application/json")]
    public class EsocialRubricaController : Controller
    {
		private readonly EsocialRubricaService _service;

        public EsocialRubricaController()
        {
            _service = new EsocialRubricaService();
        }

        [HttpGet]
        public IActionResult GetListEsocialRubrica([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EsocialRubricaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EsocialRubrica]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEsocialRubrica")]
        public IActionResult GetObjectEsocialRubrica(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EsocialRubrica]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EsocialRubrica]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEsocialRubrica([FromBody]EsocialRubricaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EsocialRubrica]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEsocialRubrica", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EsocialRubrica]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEsocialRubrica([FromBody]EsocialRubricaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EsocialRubrica]", null));
                }

                _service.Update(objJson);

                return GetObjectEsocialRubrica(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EsocialRubrica]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEsocialRubrica(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EsocialRubrica]", ex));
            }
        }

    }
}