using Microsoft.AspNetCore.Mvc;
using esocial.Models;
using esocial.Services;

namespace esocial.Controllers
{
    [Route("esocial-natureza-juridica")]
    [Produces("application/json")]
    public class EsocialNaturezaJuridicaController : Controller
    {
		private readonly EsocialNaturezaJuridicaService _service;

        public EsocialNaturezaJuridicaController()
        {
            _service = new EsocialNaturezaJuridicaService();
        }

        [HttpGet]
        public IActionResult GetListEsocialNaturezaJuridica([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EsocialNaturezaJuridicaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EsocialNaturezaJuridica]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEsocialNaturezaJuridica")]
        public IActionResult GetObjectEsocialNaturezaJuridica(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EsocialNaturezaJuridica]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EsocialNaturezaJuridica]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEsocialNaturezaJuridica([FromBody]EsocialNaturezaJuridicaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EsocialNaturezaJuridica]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEsocialNaturezaJuridica", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EsocialNaturezaJuridica]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEsocialNaturezaJuridica([FromBody]EsocialNaturezaJuridicaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EsocialNaturezaJuridica]", null));
                }

                _service.Update(objJson);

                return GetObjectEsocialNaturezaJuridica(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EsocialNaturezaJuridica]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEsocialNaturezaJuridica(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EsocialNaturezaJuridica]", ex));
            }
        }

    }
}