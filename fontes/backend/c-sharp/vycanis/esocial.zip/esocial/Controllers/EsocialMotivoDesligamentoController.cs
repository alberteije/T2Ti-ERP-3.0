using Microsoft.AspNetCore.Mvc;
using esocial.Models;
using esocial.Services;

namespace esocial.Controllers
{
    [Route("esocial-motivo-desligamento")]
    [Produces("application/json")]
    public class EsocialMotivoDesligamentoController : Controller
    {
		private readonly EsocialMotivoDesligamentoService _service;

        public EsocialMotivoDesligamentoController()
        {
            _service = new EsocialMotivoDesligamentoService();
        }

        [HttpGet]
        public IActionResult GetListEsocialMotivoDesligamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EsocialMotivoDesligamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EsocialMotivoDesligamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEsocialMotivoDesligamento")]
        public IActionResult GetObjectEsocialMotivoDesligamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EsocialMotivoDesligamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EsocialMotivoDesligamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEsocialMotivoDesligamento([FromBody]EsocialMotivoDesligamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EsocialMotivoDesligamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEsocialMotivoDesligamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EsocialMotivoDesligamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEsocialMotivoDesligamento([FromBody]EsocialMotivoDesligamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EsocialMotivoDesligamento]", null));
                }

                _service.Update(objJson);

                return GetObjectEsocialMotivoDesligamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EsocialMotivoDesligamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEsocialMotivoDesligamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EsocialMotivoDesligamento]", ex));
            }
        }

    }
}