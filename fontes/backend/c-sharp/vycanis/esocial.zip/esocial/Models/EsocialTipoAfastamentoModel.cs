namespace esocial.Models
{
	public class EsocialTipoAfastamentoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

	}
}
