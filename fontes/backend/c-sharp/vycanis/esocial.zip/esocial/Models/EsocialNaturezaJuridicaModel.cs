namespace esocial.Models
{
	public class EsocialNaturezaJuridicaModel
	{	
		public int? Id { get; set; } 

		public int? Grupo { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

	}
}
