using Microsoft.AspNetCore.Mvc;
using esocial.Models;
using esocial.Services;

namespace esocial.Controllers
{
    [Route("esocial-tipo-afastamento")]
    [Produces("application/json")]
    public class EsocialTipoAfastamentoController : Controller
    {
		private readonly EsocialTipoAfastamentoService _service;

        public EsocialTipoAfastamentoController()
        {
            _service = new EsocialTipoAfastamentoService();
        }

        [HttpGet]
        public IActionResult GetListEsocialTipoAfastamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EsocialTipoAfastamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EsocialTipoAfastamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEsocialTipoAfastamento")]
        public IActionResult GetObjectEsocialTipoAfastamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EsocialTipoAfastamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EsocialTipoAfastamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEsocialTipoAfastamento([FromBody]EsocialTipoAfastamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EsocialTipoAfastamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEsocialTipoAfastamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EsocialTipoAfastamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEsocialTipoAfastamento([FromBody]EsocialTipoAfastamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EsocialTipoAfastamento]", null));
                }

                _service.Update(objJson);

                return GetObjectEsocialTipoAfastamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EsocialTipoAfastamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEsocialTipoAfastamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EsocialTipoAfastamento]", ex));
            }
        }

    }
}