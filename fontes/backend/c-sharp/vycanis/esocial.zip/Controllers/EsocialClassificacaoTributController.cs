using Microsoft.AspNetCore.Mvc;
using esocial.Models;
using esocial.Services;

namespace esocial.Controllers
{
    [Route("esocial-classificacao-tribut")]
    [Produces("application/json")]
    public class EsocialClassificacaoTributController : Controller
    {
		private readonly EsocialClassificacaoTributService _service;

        public EsocialClassificacaoTributController()
        {
            _service = new EsocialClassificacaoTributService();
        }

        [HttpGet]
        public IActionResult GetListEsocialClassificacaoTribut([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EsocialClassificacaoTributModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EsocialClassificacaoTribut]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEsocialClassificacaoTribut")]
        public IActionResult GetObjectEsocialClassificacaoTribut(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EsocialClassificacaoTribut]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EsocialClassificacaoTribut]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEsocialClassificacaoTribut([FromBody]EsocialClassificacaoTributModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EsocialClassificacaoTribut]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEsocialClassificacaoTribut", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EsocialClassificacaoTribut]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEsocialClassificacaoTribut([FromBody]EsocialClassificacaoTributModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EsocialClassificacaoTribut]", null));
                }

                _service.Update(objJson);

                return GetObjectEsocialClassificacaoTribut(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EsocialClassificacaoTribut]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEsocialClassificacaoTribut(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EsocialClassificacaoTribut]", ex));
            }
        }

    }
}