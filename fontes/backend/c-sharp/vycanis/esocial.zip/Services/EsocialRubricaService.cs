using esocial.Models;
using esocial.NHibernate;
using ISession = NHibernate.ISession;

namespace esocial.Services
{
    public class EsocialRubricaService
    {

        public IEnumerable<EsocialRubricaModel> GetList()
        {
            IList<EsocialRubricaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialRubricaModel> DAL = new NHibernateDAL<EsocialRubricaModel>(Session);
                Result = DAL.Select(new EsocialRubricaModel());
            }
            return Result;
        }

        public IEnumerable<EsocialRubricaModel> GetListFilter(Filter filterObj)
        {
            IList<EsocialRubricaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EsocialRubricaModel where " + filterObj.Where;
                NHibernateDAL<EsocialRubricaModel> DAL = new NHibernateDAL<EsocialRubricaModel>(Session);
                Result = DAL.SelectListSql<EsocialRubricaModel>(Query);
            }
            return Result;
        }
		
        public EsocialRubricaModel GetObject(int id)
        {
            EsocialRubricaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialRubricaModel> DAL = new NHibernateDAL<EsocialRubricaModel>(Session);
                Result = DAL.SelectId<EsocialRubricaModel>(id);
            }
            return Result;
        }
		
        public void Insert(EsocialRubricaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialRubricaModel> DAL = new NHibernateDAL<EsocialRubricaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EsocialRubricaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialRubricaModel> DAL = new NHibernateDAL<EsocialRubricaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EsocialRubricaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EsocialRubricaModel> DAL = new NHibernateDAL<EsocialRubricaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}