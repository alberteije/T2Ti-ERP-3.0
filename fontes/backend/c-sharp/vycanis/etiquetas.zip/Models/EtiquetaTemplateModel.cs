namespace etiquetas.Models
{
	public class EtiquetaTemplateModel
	{	
		public int? Id { get; set; } 

		public string? Tabela { get; set; } 

		public string? Campo { get; set; } 

		public string? Formato { get; set; } 

		public int? QuantidadeRepeticoes { get; set; } 

		public string? Filtro { get; set; } 

		public EtiquetaLayoutModel? EtiquetaLayoutModel { get; set; } 

	}
}
