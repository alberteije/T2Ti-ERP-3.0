namespace etiquetas.Models
{
	public class EtiquetaLayoutModel
	{	
		public int? Id { get; set; } 

		public string? CodigoFabricante { get; set; } 

		public int? Quantidade { get; set; } 

		public int? QuantidadeHorizontal { get; set; } 

		public int? QuantidadeVertical { get; set; } 

		public int? MargemSuperior { get; set; } 

		public int? MargemInferior { get; set; } 

		public int? MargemEsquerda { get; set; } 

		public int? MargemDireita { get; set; } 

		public int? EspacamentoHorizontal { get; set; } 

		public int? EspacamentoVertical { get; set; } 

		public EtiquetaFormatoPapelModel? EtiquetaFormatoPapelModel { get; set; } 

		private IList<EtiquetaTemplateModel>? etiquetaTemplateModelList; 
		public IList<EtiquetaTemplateModel>? EtiquetaTemplateModelList 
		{ 
			get 
			{ 
				return etiquetaTemplateModelList; 
			} 
			set 
			{ 
				etiquetaTemplateModelList = value; 
				foreach (EtiquetaTemplateModel etiquetaTemplateModel in etiquetaTemplateModelList!) 
				{ 
					etiquetaTemplateModel.EtiquetaLayoutModel = this; 
				} 
			} 
		} 

	}
}
