using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using System.Security.Cryptography;
using System.Text;

namespace etiquetas.Utils
{

    public static class Util
    {

        public static string QuotedStr(string pValor)
        {
            return "'" + pValor + "'";
        }

        public static string VerificaNULL(string Texto, int Tipo)
        {
            switch (Tipo)
            {
                case 0:
                    if (Texto.Trim() == "")
                        return "NULL";
                    else
                        return Texto.Trim();
                case 1:
                    if (Texto.Trim() == "")
                        return "NULL";
                    else
                        return Util.QuotedStr(Texto.Trim());
                case 2:
                    if (Texto.Trim() == "")
                        return "";
                    else
                        return (Texto.Trim());
                default:
                    return "";
            }
        }

        public static string MD5String(string texto)
        {
            var byteArray = Encoding.ASCII.GetBytes(texto);
            byteArray = MD5.HashData(byteArray);
            StringBuilder hashedValue = new StringBuilder();
            foreach (byte b in byteArray)
            {
                hashedValue.Append(b.ToString("x2"));
            }
            return hashedValue.ToString();
        }

        public static String Cifrar(String valor)
        {
            var key = Encoding.ASCII.GetBytes(Constants.CHAVE);
            var iv = Encoding.ASCII.GetBytes(Constants.VETOR);
            var input = Encoding.UTF8.GetBytes(valor);

            // cifrar
            IBufferedCipher cipher = CipherUtilities.GetCipher("AES/CTR/NoPadding");
            cipher.Init(true, new ParametersWithIV(ParameterUtilities.CreateKeyParameter("AES", key), iv));
            byte[] encryptedBytes = cipher.DoFinal(input);

            return Convert.ToBase64String(encryptedBytes);
        }

        public static String Decifrar(String valor)
        {
            if (valor.Substring(0, 1) == "\"")
            {
                valor = valor.Substring(1, valor.Length - 2);
            }

            var key = Encoding.ASCII.GetBytes(Constants.CHAVE);
            var iv = Encoding.ASCII.GetBytes(Constants.VETOR);
            var input = Encoding.UTF8.GetBytes(valor);

            // decifrar
            IBufferedCipher cipher = CipherUtilities.GetCipher("AES/CTR/NoPadding");
            byte[] toDecrypt = Convert.FromBase64String(valor);
            cipher.Init(false, new ParametersWithIV(ParameterUtilities.CreateKeyParameter("AES", key), iv));
            byte[] plainBytes = cipher.DoFinal(toDecrypt);

            return Encoding.UTF8.GetString(plainBytes);
        }

    }
}
