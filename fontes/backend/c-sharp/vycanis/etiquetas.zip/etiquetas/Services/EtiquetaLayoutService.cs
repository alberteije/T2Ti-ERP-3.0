using etiquetas.Models;
using etiquetas.NHibernate;
using ISession = NHibernate.ISession;

namespace etiquetas.Services
{
    public class EtiquetaLayoutService
    {

        public IEnumerable<EtiquetaLayoutModel> GetList()
        {
            IList<EtiquetaLayoutModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaLayoutModel> DAL = new NHibernateDAL<EtiquetaLayoutModel>(Session);
                Result = DAL.Select(new EtiquetaLayoutModel());
            }
            return Result;
        }

        public IEnumerable<EtiquetaLayoutModel> GetListFilter(Filter filterObj)
        {
            IList<EtiquetaLayoutModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EtiquetaLayoutModel where " + filterObj.Where;
                NHibernateDAL<EtiquetaLayoutModel> DAL = new NHibernateDAL<EtiquetaLayoutModel>(Session);
                Result = DAL.SelectListSql<EtiquetaLayoutModel>(Query);
            }
            return Result;
        }
		
        public EtiquetaLayoutModel GetObject(int id)
        {
            EtiquetaLayoutModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaLayoutModel> DAL = new NHibernateDAL<EtiquetaLayoutModel>(Session);
                Result = DAL.SelectId<EtiquetaLayoutModel>(id);
            }
            return Result;
        }
		
        public void Insert(EtiquetaLayoutModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaLayoutModel> DAL = new NHibernateDAL<EtiquetaLayoutModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EtiquetaLayoutModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaLayoutModel> DAL = new NHibernateDAL<EtiquetaLayoutModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EtiquetaLayoutModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaLayoutModel> DAL = new NHibernateDAL<EtiquetaLayoutModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}