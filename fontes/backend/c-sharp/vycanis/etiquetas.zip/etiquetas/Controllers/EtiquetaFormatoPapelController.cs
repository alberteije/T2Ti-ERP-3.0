using Microsoft.AspNetCore.Mvc;
using etiquetas.Models;
using etiquetas.Services;

namespace etiquetas.Controllers
{
    [Route("etiqueta-formato-papel")]
    [Produces("application/json")]
    public class EtiquetaFormatoPapelController : Controller
    {
		private readonly EtiquetaFormatoPapelService _service;

        public EtiquetaFormatoPapelController()
        {
            _service = new EtiquetaFormatoPapelService();
        }

        [HttpGet]
        public IActionResult GetListEtiquetaFormatoPapel([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EtiquetaFormatoPapelModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EtiquetaFormatoPapel]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEtiquetaFormatoPapel")]
        public IActionResult GetObjectEtiquetaFormatoPapel(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EtiquetaFormatoPapel]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EtiquetaFormatoPapel]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEtiquetaFormatoPapel([FromBody]EtiquetaFormatoPapelModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EtiquetaFormatoPapel]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEtiquetaFormatoPapel", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EtiquetaFormatoPapel]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEtiquetaFormatoPapel([FromBody]EtiquetaFormatoPapelModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EtiquetaFormatoPapel]", null));
                }

                _service.Update(objJson);

                return GetObjectEtiquetaFormatoPapel(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EtiquetaFormatoPapel]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEtiquetaFormatoPapel(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EtiquetaFormatoPapel]", ex));
            }
        }

    }
}