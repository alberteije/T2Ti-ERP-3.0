using Microsoft.AspNetCore.Mvc;
using etiquetas.Models;
using etiquetas.Services;

namespace etiquetas.Controllers
{
    [Route("etiqueta-layout")]
    [Produces("application/json")]
    public class EtiquetaLayoutController : Controller
    {
		private readonly EtiquetaLayoutService _service;

        public EtiquetaLayoutController()
        {
            _service = new EtiquetaLayoutService();
        }

        [HttpGet]
        public IActionResult GetListEtiquetaLayout([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EtiquetaLayoutModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EtiquetaLayout]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEtiquetaLayout")]
        public IActionResult GetObjectEtiquetaLayout(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EtiquetaLayout]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EtiquetaLayout]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEtiquetaLayout([FromBody]EtiquetaLayoutModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EtiquetaLayout]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEtiquetaLayout", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EtiquetaLayout]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEtiquetaLayout([FromBody]EtiquetaLayoutModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EtiquetaLayout]", null));
                }

                _service.Update(objJson);

                return GetObjectEtiquetaLayout(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EtiquetaLayout]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEtiquetaLayout(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EtiquetaLayout]", ex));
            }
        }

    }
}