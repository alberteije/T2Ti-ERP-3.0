﻿namespace etiquetas.NHibernate
{
    public interface IDAL<DTO>
    {
        T Save<T>(T obj);
        T SaveOrUpdate<T>(T obj);
        T Update<T>(T obj);
        int Delete<T>(T obj);
        IList<T> Select<T>(T obj); 
        T? SelectObj<T>(T obj);
        T SelectId<T>(int id);
        IList<T> SelectPage<T>(int firstResult, int maxResults, T obj);
        T? SelectObjSql<T>(String query);
        IList<T> SelectListSql<T>(String query);
    }
}
