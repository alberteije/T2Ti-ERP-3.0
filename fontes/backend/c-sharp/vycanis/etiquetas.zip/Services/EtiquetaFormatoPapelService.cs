using etiquetas.Models;
using etiquetas.NHibernate;
using ISession = NHibernate.ISession;

namespace etiquetas.Services
{
    public class EtiquetaFormatoPapelService
    {

        public IEnumerable<EtiquetaFormatoPapelModel> GetList()
        {
            IList<EtiquetaFormatoPapelModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaFormatoPapelModel> DAL = new NHibernateDAL<EtiquetaFormatoPapelModel>(Session);
                Result = DAL.Select(new EtiquetaFormatoPapelModel());
            }
            return Result;
        }

        public IEnumerable<EtiquetaFormatoPapelModel> GetListFilter(Filter filterObj)
        {
            IList<EtiquetaFormatoPapelModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EtiquetaFormatoPapelModel where " + filterObj.Where;
                NHibernateDAL<EtiquetaFormatoPapelModel> DAL = new NHibernateDAL<EtiquetaFormatoPapelModel>(Session);
                Result = DAL.SelectListSql<EtiquetaFormatoPapelModel>(Query);
            }
            return Result;
        }
		
        public EtiquetaFormatoPapelModel GetObject(int id)
        {
            EtiquetaFormatoPapelModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaFormatoPapelModel> DAL = new NHibernateDAL<EtiquetaFormatoPapelModel>(Session);
                Result = DAL.SelectId<EtiquetaFormatoPapelModel>(id);
            }
            return Result;
        }
		
        public void Insert(EtiquetaFormatoPapelModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaFormatoPapelModel> DAL = new NHibernateDAL<EtiquetaFormatoPapelModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EtiquetaFormatoPapelModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaFormatoPapelModel> DAL = new NHibernateDAL<EtiquetaFormatoPapelModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EtiquetaFormatoPapelModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EtiquetaFormatoPapelModel> DAL = new NHibernateDAL<EtiquetaFormatoPapelModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}