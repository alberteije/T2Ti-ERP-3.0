namespace nfse.Models
{
	public class NfseDetalheModel
	{	
		public int? Id { get; set; } 

		public string? CodigoCnae { get; set; } 

		public string? CodigoTributacaoMunicipio { get; set; } 

		public System.Nullable<System.Decimal> ValorServicos { get; set; } 

		public System.Nullable<System.Decimal> ValorDeducoes { get; set; } 

		public System.Nullable<System.Decimal> ValorPis { get; set; } 

		public System.Nullable<System.Decimal> ValorCofins { get; set; } 

		public System.Nullable<System.Decimal> ValorInss { get; set; } 

		public System.Nullable<System.Decimal> ValorIr { get; set; } 

		public System.Nullable<System.Decimal> ValorCsll { get; set; } 

		public System.Nullable<System.Decimal> ValorBaseCalculo { get; set; } 

		public System.Nullable<System.Decimal> Aliquota { get; set; } 

		public System.Nullable<System.Decimal> ValorIss { get; set; } 

		public System.Nullable<System.Decimal> ValorLiquido { get; set; } 

		public System.Nullable<System.Decimal> OutrasRetencoes { get; set; } 

		public System.Nullable<System.Decimal> ValorCredito { get; set; } 

		public string? IssRetido { get; set; } 

		public System.Nullable<System.Decimal> ValorIssRetido { get; set; } 

		public System.Nullable<System.Decimal> ValorDescontoCondicionado { get; set; } 

		public System.Nullable<System.Decimal> ValorDescontoIncondicionado { get; set; } 

		public int? MunicipioPrestacao { get; set; } 

		public string? Discriminacao { get; set; } 

		public NfseCabecalhoModel? NfseCabecalhoModel { get; set; } 

		public NfseListaServicoModel? NfseListaServicoModel { get; set; } 

	}
}
