namespace nfse.Models
{
	public class NfseCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public string? CodigoVerificacao { get; set; } 

		public System.Nullable<System.DateTime> DataHoraEmissao { get; set; } 

		public string? Competencia { get; set; } 

		public string? NumeroSubstituida { get; set; } 

		public string? NaturezaOperacao { get; set; } 

		public string? RegimeEspecialTributacao { get; set; } 

		public string? OptanteSimplesNacional { get; set; } 

		public string? IncentivadorCultural { get; set; } 

		public string? NumeroRps { get; set; } 

		public string? SerieRps { get; set; } 

		public string? TipoRps { get; set; } 

		public System.Nullable<System.DateTime> DataEmissaoRps { get; set; } 

		public string? OutrasInformacoes { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public OsAberturaModel? OsAberturaModel { get; set; } 

		private IList<NfseDetalheModel>? nfseDetalheModelList; 
		public IList<NfseDetalheModel>? NfseDetalheModelList 
		{ 
			get 
			{ 
				return nfseDetalheModelList; 
			} 
			set 
			{ 
				nfseDetalheModelList = value; 
				foreach (NfseDetalheModel nfseDetalheModel in nfseDetalheModelList!) 
				{ 
					nfseDetalheModel.NfseCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<NfseIntermediarioModel>? nfseIntermediarioModelList; 
		public IList<NfseIntermediarioModel>? NfseIntermediarioModelList 
		{ 
			get 
			{ 
				return nfseIntermediarioModelList; 
			} 
			set 
			{ 
				nfseIntermediarioModelList = value; 
				foreach (NfseIntermediarioModel nfseIntermediarioModel in nfseIntermediarioModelList!) 
				{ 
					nfseIntermediarioModel.NfseCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
