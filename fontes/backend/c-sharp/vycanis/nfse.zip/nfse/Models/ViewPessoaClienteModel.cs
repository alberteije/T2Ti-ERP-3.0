namespace nfse.Models
{
	public class ViewPessoaClienteModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Tipo { get; set; } 

		public string? Email { get; set; } 

		public string? Site { get; set; } 

		public string? CpfCnpj { get; set; } 

		public string? RgIe { get; set; } 

		public System.Nullable<System.DateTime> Desde { get; set; } 

		public System.Nullable<System.Decimal> TaxaDesconto { get; set; } 

		public System.Nullable<System.Decimal> LimiteCredito { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public string? Observacao { get; set; } 

		public int? IdPessoa { get; set; } 

	}
}
