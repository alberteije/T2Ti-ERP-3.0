namespace nfse.Models
{
	public class OsAberturaModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public string? HoraInicio { get; set; } 

		public System.Nullable<System.DateTime> DataPrevisao { get; set; } 

		public string? HoraPrevisao { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public string? HoraFim { get; set; } 

		public string? NomeContato { get; set; } 

		public string? FoneContato { get; set; } 

		public string? ObservacaoCliente { get; set; } 

		public string? ObservacaoAbertura { get; set; } 

		public OsStatusModel? OsStatusModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

	}
}
