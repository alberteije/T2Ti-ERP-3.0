namespace nfse.Models
{
	public class OsStatusModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		private IList<OsAberturaModel>? osAberturaModelList; 
		public IList<OsAberturaModel>? OsAberturaModelList 
		{ 
			get 
			{ 
				return osAberturaModelList; 
			} 
			set 
			{ 
				osAberturaModelList = value; 
				foreach (OsAberturaModel osAberturaModel in osAberturaModelList!) 
				{ 
					osAberturaModel.OsStatusModel = this; 
				} 
			} 
		} 

	}
}
