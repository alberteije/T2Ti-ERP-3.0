namespace nfse.Models
{
	public class NfseIntermediarioModel
	{	
		public int? Id { get; set; } 

		public string? Cnpj { get; set; } 

		public string? InscricaoMunicipal { get; set; } 

		public string? Razao { get; set; } 

		public NfseCabecalhoModel? NfseCabecalhoModel { get; set; } 

	}
}
