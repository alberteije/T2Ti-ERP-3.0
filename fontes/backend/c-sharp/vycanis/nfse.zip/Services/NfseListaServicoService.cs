using nfse.Models;
using nfse.NHibernate;
using ISession = NHibernate.ISession;

namespace nfse.Services
{
    public class NfseListaServicoService
    {

        public IEnumerable<NfseListaServicoModel> GetList()
        {
            IList<NfseListaServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseListaServicoModel> DAL = new NHibernateDAL<NfseListaServicoModel>(Session);
                Result = DAL.Select(new NfseListaServicoModel());
            }
            return Result;
        }

        public IEnumerable<NfseListaServicoModel> GetListFilter(Filter filterObj)
        {
            IList<NfseListaServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfseListaServicoModel where " + filterObj.Where;
                NHibernateDAL<NfseListaServicoModel> DAL = new NHibernateDAL<NfseListaServicoModel>(Session);
                Result = DAL.SelectListSql<NfseListaServicoModel>(Query);
            }
            return Result;
        }
		
        public NfseListaServicoModel GetObject(int id)
        {
            NfseListaServicoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseListaServicoModel> DAL = new NHibernateDAL<NfseListaServicoModel>(Session);
                Result = DAL.SelectId<NfseListaServicoModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfseListaServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseListaServicoModel> DAL = new NHibernateDAL<NfseListaServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfseListaServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseListaServicoModel> DAL = new NHibernateDAL<NfseListaServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfseListaServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseListaServicoModel> DAL = new NHibernateDAL<NfseListaServicoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}