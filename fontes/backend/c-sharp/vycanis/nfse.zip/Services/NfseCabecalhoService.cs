using nfse.Models;
using nfse.NHibernate;
using ISession = NHibernate.ISession;

namespace nfse.Services
{
    public class NfseCabecalhoService
    {

        public IEnumerable<NfseCabecalhoModel> GetList()
        {
            IList<NfseCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseCabecalhoModel> DAL = new NHibernateDAL<NfseCabecalhoModel>(Session);
                Result = DAL.Select(new NfseCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<NfseCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<NfseCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfseCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<NfseCabecalhoModel> DAL = new NHibernateDAL<NfseCabecalhoModel>(Session);
                Result = DAL.SelectListSql<NfseCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public NfseCabecalhoModel GetObject(int id)
        {
            NfseCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseCabecalhoModel> DAL = new NHibernateDAL<NfseCabecalhoModel>(Session);
                Result = DAL.SelectId<NfseCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfseCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseCabecalhoModel> DAL = new NHibernateDAL<NfseCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfseCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseCabecalhoModel> DAL = new NHibernateDAL<NfseCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfseCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfseCabecalhoModel> DAL = new NHibernateDAL<NfseCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}