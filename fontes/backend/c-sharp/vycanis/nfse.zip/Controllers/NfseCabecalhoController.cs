using Microsoft.AspNetCore.Mvc;
using nfse.Models;
using nfse.Services;

namespace nfse.Controllers
{
    [Route("nfse-cabecalho")]
    [Produces("application/json")]
    public class NfseCabecalhoController : Controller
    {
		private readonly NfseCabecalhoService _service;

        public NfseCabecalhoController()
        {
            _service = new NfseCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListNfseCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfseCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfseCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfseCabecalho")]
        public IActionResult GetObjectNfseCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfseCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfseCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfseCabecalho([FromBody]NfseCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfseCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfseCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfseCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfseCabecalho([FromBody]NfseCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfseCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectNfseCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfseCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfseCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfseCabecalho]", ex));
            }
        }

    }
}