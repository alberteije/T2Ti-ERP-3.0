using Microsoft.AspNetCore.Mvc;
using nfse.Models;
using nfse.Services;

namespace nfse.Controllers
{
    [Route("nfse-lista-servico")]
    [Produces("application/json")]
    public class NfseListaServicoController : Controller
    {
		private readonly NfseListaServicoService _service;

        public NfseListaServicoController()
        {
            _service = new NfseListaServicoService();
        }

        [HttpGet]
        public IActionResult GetListNfseListaServico([FromQuery]string filter)
        {
            try
            {
                IEnumerable<NfseListaServicoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList NfseListaServico]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectNfseListaServico")]
        public IActionResult GetObjectNfseListaServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject NfseListaServico]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject NfseListaServico]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertNfseListaServico([FromBody]NfseListaServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert NfseListaServico]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectNfseListaServico", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert NfseListaServico]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateNfseListaServico([FromBody]NfseListaServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update NfseListaServico]", null));
                }

                _service.Update(objJson);

                return GetObjectNfseListaServico(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update NfseListaServico]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNfseListaServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete NfseListaServico]", ex));
            }
        }

    }
}