using contratos.Models;
using contratos.NHibernate;
using ISession = NHibernate.ISession;

namespace contratos.Services
{
    public class ContratoTemplateService
    {

        public IEnumerable<ContratoTemplateModel> GetList()
        {
            IList<ContratoTemplateModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTemplateModel> DAL = new NHibernateDAL<ContratoTemplateModel>(Session);
                Result = DAL.Select(new ContratoTemplateModel());
            }
            return Result;
        }

        public IEnumerable<ContratoTemplateModel> GetListFilter(Filter filterObj)
        {
            IList<ContratoTemplateModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContratoTemplateModel where " + filterObj.Where;
                NHibernateDAL<ContratoTemplateModel> DAL = new NHibernateDAL<ContratoTemplateModel>(Session);
                Result = DAL.SelectListSql<ContratoTemplateModel>(Query);
            }
            return Result;
        }
		
        public ContratoTemplateModel GetObject(int id)
        {
            ContratoTemplateModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTemplateModel> DAL = new NHibernateDAL<ContratoTemplateModel>(Session);
                Result = DAL.SelectId<ContratoTemplateModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContratoTemplateModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTemplateModel> DAL = new NHibernateDAL<ContratoTemplateModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContratoTemplateModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTemplateModel> DAL = new NHibernateDAL<ContratoTemplateModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContratoTemplateModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTemplateModel> DAL = new NHibernateDAL<ContratoTemplateModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}