using Microsoft.AspNetCore.Mvc;
using contratos.Models;
using contratos.Services;

namespace contratos.Controllers
{
    [Route("contrato-solicitacao-servico")]
    [Produces("application/json")]
    public class ContratoSolicitacaoServicoController : Controller
    {
		private readonly ContratoSolicitacaoServicoService _service;

        public ContratoSolicitacaoServicoController()
        {
            _service = new ContratoSolicitacaoServicoService();
        }

        [HttpGet]
        public IActionResult GetListContratoSolicitacaoServico([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContratoSolicitacaoServicoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContratoSolicitacaoServico]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContratoSolicitacaoServico")]
        public IActionResult GetObjectContratoSolicitacaoServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContratoSolicitacaoServico]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContratoSolicitacaoServico]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContratoSolicitacaoServico([FromBody]ContratoSolicitacaoServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContratoSolicitacaoServico]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContratoSolicitacaoServico", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContratoSolicitacaoServico]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContratoSolicitacaoServico([FromBody]ContratoSolicitacaoServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContratoSolicitacaoServico]", null));
                }

                _service.Update(objJson);

                return GetObjectContratoSolicitacaoServico(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContratoSolicitacaoServico]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContratoSolicitacaoServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContratoSolicitacaoServico]", ex));
            }
        }

    }
}