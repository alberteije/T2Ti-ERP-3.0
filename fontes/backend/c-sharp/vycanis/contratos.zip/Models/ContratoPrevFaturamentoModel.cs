namespace contratos.Models
{
	public class ContratoPrevFaturamentoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataPrevista { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public ContratoModel? ContratoModel { get; set; } 

	}
}
