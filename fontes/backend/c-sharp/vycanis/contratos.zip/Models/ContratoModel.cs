namespace contratos.Models
{
	public class ContratoModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.DateTime> DataInicioVigencia { get; set; } 

		public System.Nullable<System.DateTime> DataFimVigencia { get; set; } 

		public string? DiaFaturamento { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public int? QuantidadeParcelas { get; set; } 

		public int? IntervaloEntreParcelas { get; set; } 

		public string? ClassificacaoContabilConta { get; set; } 

		public string? Observacao { get; set; } 

		public TipoContratoModel? TipoContratoModel { get; set; } 

		public ContratoSolicitacaoServicoModel? ContratoSolicitacaoServicoModel { get; set; } 

		private IList<ContratoHistoricoReajusteModel>? contratoHistoricoReajusteModelList; 
		public IList<ContratoHistoricoReajusteModel>? ContratoHistoricoReajusteModelList 
		{ 
			get 
			{ 
				return contratoHistoricoReajusteModelList; 
			} 
			set 
			{ 
				contratoHistoricoReajusteModelList = value; 
				foreach (ContratoHistoricoReajusteModel contratoHistoricoReajusteModel in contratoHistoricoReajusteModelList!) 
				{ 
					contratoHistoricoReajusteModel.ContratoModel = this; 
				} 
			} 
		} 

		private IList<ContratoPrevFaturamentoModel>? contratoPrevFaturamentoModelList; 
		public IList<ContratoPrevFaturamentoModel>? ContratoPrevFaturamentoModelList 
		{ 
			get 
			{ 
				return contratoPrevFaturamentoModelList; 
			} 
			set 
			{ 
				contratoPrevFaturamentoModelList = value; 
				foreach (ContratoPrevFaturamentoModel contratoPrevFaturamentoModel in contratoPrevFaturamentoModelList!) 
				{ 
					contratoPrevFaturamentoModel.ContratoModel = this; 
				} 
			} 
		} 

		private IList<ContratoHistFaturamentoModel>? contratoHistFaturamentoModelList; 
		public IList<ContratoHistFaturamentoModel>? ContratoHistFaturamentoModelList 
		{ 
			get 
			{ 
				return contratoHistFaturamentoModelList; 
			} 
			set 
			{ 
				contratoHistFaturamentoModelList = value; 
				foreach (ContratoHistFaturamentoModel contratoHistFaturamentoModel in contratoHistFaturamentoModelList!) 
				{ 
					contratoHistFaturamentoModel.ContratoModel = this; 
				} 
			} 
		} 

	}
}
