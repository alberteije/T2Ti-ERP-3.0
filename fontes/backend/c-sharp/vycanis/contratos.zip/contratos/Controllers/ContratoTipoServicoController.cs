using Microsoft.AspNetCore.Mvc;
using contratos.Models;
using contratos.Services;

namespace contratos.Controllers
{
    [Route("contrato-tipo-servico")]
    [Produces("application/json")]
    public class ContratoTipoServicoController : Controller
    {
		private readonly ContratoTipoServicoService _service;

        public ContratoTipoServicoController()
        {
            _service = new ContratoTipoServicoService();
        }

        [HttpGet]
        public IActionResult GetListContratoTipoServico([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContratoTipoServicoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContratoTipoServico]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContratoTipoServico")]
        public IActionResult GetObjectContratoTipoServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContratoTipoServico]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContratoTipoServico]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContratoTipoServico([FromBody]ContratoTipoServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContratoTipoServico]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContratoTipoServico", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContratoTipoServico]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContratoTipoServico([FromBody]ContratoTipoServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContratoTipoServico]", null));
                }

                _service.Update(objJson);

                return GetObjectContratoTipoServico(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContratoTipoServico]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContratoTipoServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContratoTipoServico]", ex));
            }
        }

    }
}