using Microsoft.AspNetCore.Mvc;
using contratos.Models;
using contratos.Services;

namespace contratos.Controllers
{
    [Route("contrato")]
    [Produces("application/json")]
    public class ContratoController : Controller
    {
		private readonly ContratoService _service;

        public ContratoController()
        {
            _service = new ContratoService();
        }

        [HttpGet]
        public IActionResult GetListContrato([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContratoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Contrato]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContrato")]
        public IActionResult GetObjectContrato(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Contrato]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Contrato]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContrato([FromBody]ContratoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Contrato]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContrato", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Contrato]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContrato([FromBody]ContratoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Contrato]", null));
                }

                _service.Update(objJson);

                return GetObjectContrato(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Contrato]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContrato(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Contrato]", ex));
            }
        }

    }
}