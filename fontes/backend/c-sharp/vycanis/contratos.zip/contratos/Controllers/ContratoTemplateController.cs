using Microsoft.AspNetCore.Mvc;
using contratos.Models;
using contratos.Services;

namespace contratos.Controllers
{
    [Route("contrato-template")]
    [Produces("application/json")]
    public class ContratoTemplateController : Controller
    {
		private readonly ContratoTemplateService _service;

        public ContratoTemplateController()
        {
            _service = new ContratoTemplateService();
        }

        [HttpGet]
        public IActionResult GetListContratoTemplate([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContratoTemplateModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContratoTemplate]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContratoTemplate")]
        public IActionResult GetObjectContratoTemplate(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContratoTemplate]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContratoTemplate]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContratoTemplate([FromBody]ContratoTemplateModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContratoTemplate]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContratoTemplate", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContratoTemplate]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContratoTemplate([FromBody]ContratoTemplateModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContratoTemplate]", null));
                }

                _service.Update(objJson);

                return GetObjectContratoTemplate(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContratoTemplate]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContratoTemplate(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContratoTemplate]", ex));
            }
        }

    }
}