namespace contratos.Models
{
	public class ContratoHistFaturamentoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataFatura { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public ContratoModel? ContratoModel { get; set; } 

	}
}
