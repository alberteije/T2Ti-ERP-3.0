namespace contratos.Models
{
	public class ContratoHistoricoReajusteModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Indice { get; set; } 

		public System.Nullable<System.Decimal> ValorAnterior { get; set; } 

		public System.Nullable<System.Decimal> ValorAtual { get; set; } 

		public System.Nullable<System.DateTime> DataReajuste { get; set; } 

		public string? Observacao { get; set; } 

		public ContratoModel? ContratoModel { get; set; } 

	}
}
