namespace contratos.Models
{
	public class ContratoSolicitacaoServicoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataSolicitacao { get; set; } 

		public System.Nullable<System.DateTime> DataDesejadaInicio { get; set; } 

		public string? Urgente { get; set; } 

		public string? StatusSolicitacao { get; set; } 

		public string? Descricao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public ViewPessoaClienteModel? ViewPessoaClienteModel { get; set; } 

		public ViewPessoaFornecedorModel? ViewPessoaFornecedorModel { get; set; } 

		public SetorModel? SetorModel { get; set; } 

		public ContratoTipoServicoModel? ContratoTipoServicoModel { get; set; } 

	}
}
