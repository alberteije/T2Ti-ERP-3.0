﻿using contratos.Models;
using auditoria.Services;
using System.Text;

namespace contratos.Utils
{
    public class FilterMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly AuditoriaService _auditoriaService;

        public FilterMiddleware(RequestDelegate next)
        {
            _next = next;
            _auditoriaService = new AuditoriaService();
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Headers.TryGetValue("cnpj", out var cnpj))
            {
                // Configurar o banco de dados dinamicamente
                NHibernateHelper.SetCurrentCnpj(cnpj.ToString());
            }

            // persistir a auditoria
            await PersistirAuditoria(context);

            await _next(context);
        }

        private async Task PersistirAuditoria(HttpContext context)
        {
            // Obtenha os dados necessários para a auditoria
            var request = context.Request;
            var tokenJwt = context.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
            var urlAcessada = $"{request.Scheme}://{request.Host}{request.Path}{request.QueryString}";
            var metodoHttp = request.Method;
            string corpoRequisicao = "";

            if (request.ContentLength > 0 && request.Body.CanRead)
            {
                // Leia o corpo da requisição
                request.EnableBuffering();
                using (var reader = new StreamReader(request.Body, Encoding.UTF8, true, 1024, true))
                {
                    corpoRequisicao = await reader.ReadToEndAsync();
                    request.Body.Position = 0; // Resetar o stream para permitir que outros middlewares o leiam
                }
            }

            // Crie o objeto de auditoria
            var auditoria = new AuditoriaModel
            {
                DataRegistro = DateTime.Now,
                HoraRegistro = DateTime.Now.ToString("HH:mm:ss"),
                JanelaController = urlAcessada,
                Acao = metodoHttp,
                Conteudo = corpoRequisicao,
                TokenJwt = tokenJwt
            };

            // Persistir a auditoria usando o serviço
            _auditoriaService.Insert(auditoria);
        }

    }



}
