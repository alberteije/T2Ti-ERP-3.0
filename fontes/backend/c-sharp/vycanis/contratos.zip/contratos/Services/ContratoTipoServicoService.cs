using contratos.Models;
using contratos.NHibernate;
using ISession = NHibernate.ISession;

namespace contratos.Services
{
    public class ContratoTipoServicoService
    {

        public IEnumerable<ContratoTipoServicoModel> GetList()
        {
            IList<ContratoTipoServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTipoServicoModel> DAL = new NHibernateDAL<ContratoTipoServicoModel>(Session);
                Result = DAL.Select(new ContratoTipoServicoModel());
            }
            return Result;
        }

        public IEnumerable<ContratoTipoServicoModel> GetListFilter(Filter filterObj)
        {
            IList<ContratoTipoServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContratoTipoServicoModel where " + filterObj.Where;
                NHibernateDAL<ContratoTipoServicoModel> DAL = new NHibernateDAL<ContratoTipoServicoModel>(Session);
                Result = DAL.SelectListSql<ContratoTipoServicoModel>(Query);
            }
            return Result;
        }
		
        public ContratoTipoServicoModel GetObject(int id)
        {
            ContratoTipoServicoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTipoServicoModel> DAL = new NHibernateDAL<ContratoTipoServicoModel>(Session);
                Result = DAL.SelectId<ContratoTipoServicoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContratoTipoServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTipoServicoModel> DAL = new NHibernateDAL<ContratoTipoServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContratoTipoServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTipoServicoModel> DAL = new NHibernateDAL<ContratoTipoServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContratoTipoServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoTipoServicoModel> DAL = new NHibernateDAL<ContratoTipoServicoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}