using contratos.Models;
using contratos.NHibernate;
using ISession = NHibernate.ISession;

namespace contratos.Services
{
    public class UsuarioTokenService
    {

        public IEnumerable<UsuarioTokenModel> GetList()
        {
            IList<UsuarioTokenModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioTokenModel> DAL = new NHibernateDAL<UsuarioTokenModel>(Session);
                Result = DAL.Select(new UsuarioTokenModel());
            }
            return Result;
        }

        public IEnumerable<UsuarioTokenModel> GetListFilter(Filter filterObj)
        {
            IList<UsuarioTokenModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from UsuarioTokenModel where " + filterObj.Where;
                NHibernateDAL<UsuarioTokenModel> DAL = new NHibernateDAL<UsuarioTokenModel>(Session);
                Result = DAL.SelectListSql<UsuarioTokenModel>(Query);
            }
            return Result;
        }
		
        public UsuarioTokenModel GetObject(int id)
        {
            UsuarioTokenModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioTokenModel> DAL = new NHibernateDAL<UsuarioTokenModel>(Session);
                Result = DAL.SelectId<UsuarioTokenModel>(id);
            }
            return Result;
        }
		
        public void Insert(UsuarioTokenModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioTokenModel> DAL = new NHibernateDAL<UsuarioTokenModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(UsuarioTokenModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioTokenModel> DAL = new NHibernateDAL<UsuarioTokenModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(UsuarioTokenModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<UsuarioTokenModel> DAL = new NHibernateDAL<UsuarioTokenModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}