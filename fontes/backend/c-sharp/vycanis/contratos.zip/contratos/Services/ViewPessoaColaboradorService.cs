using contratos.Models;
using contratos.NHibernate;
using ISession = NHibernate.ISession;

namespace contratos.Services
{
    public class ViewPessoaColaboradorService
    {

        public IEnumerable<ViewPessoaColaboradorModel> GetList()
        {
            IList<ViewPessoaColaboradorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaColaboradorModel> DAL = new NHibernateDAL<ViewPessoaColaboradorModel>(Session);
                Result = DAL.Select(new ViewPessoaColaboradorModel());
            }
            return Result;
        }

        public IEnumerable<ViewPessoaColaboradorModel> GetListFilter(Filter filterObj)
        {
            IList<ViewPessoaColaboradorModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ViewPessoaColaboradorModel where " + filterObj.Where;
                NHibernateDAL<ViewPessoaColaboradorModel> DAL = new NHibernateDAL<ViewPessoaColaboradorModel>(Session);
                Result = DAL.SelectListSql<ViewPessoaColaboradorModel>(Query);
            }
            return Result;
        }
		
        public ViewPessoaColaboradorModel GetObject(int id)
        {
            ViewPessoaColaboradorModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaColaboradorModel> DAL = new NHibernateDAL<ViewPessoaColaboradorModel>(Session);
                Result = DAL.SelectId<ViewPessoaColaboradorModel>(id);
            }
            return Result;
        }
		
        public void Insert(ViewPessoaColaboradorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaColaboradorModel> DAL = new NHibernateDAL<ViewPessoaColaboradorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ViewPessoaColaboradorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaColaboradorModel> DAL = new NHibernateDAL<ViewPessoaColaboradorModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ViewPessoaColaboradorModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ViewPessoaColaboradorModel> DAL = new NHibernateDAL<ViewPessoaColaboradorModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}