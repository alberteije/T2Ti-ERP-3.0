using contratos.Models;
using contratos.NHibernate;
using ISession = NHibernate.ISession;

namespace contratos.Services
{
    public class TipoContratoService
    {

        public IEnumerable<TipoContratoModel> GetList()
        {
            IList<TipoContratoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoContratoModel> DAL = new NHibernateDAL<TipoContratoModel>(Session);
                Result = DAL.Select(new TipoContratoModel());
            }
            return Result;
        }

        public IEnumerable<TipoContratoModel> GetListFilter(Filter filterObj)
        {
            IList<TipoContratoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from TipoContratoModel where " + filterObj.Where;
                NHibernateDAL<TipoContratoModel> DAL = new NHibernateDAL<TipoContratoModel>(Session);
                Result = DAL.SelectListSql<TipoContratoModel>(Query);
            }
            return Result;
        }
		
        public TipoContratoModel GetObject(int id)
        {
            TipoContratoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoContratoModel> DAL = new NHibernateDAL<TipoContratoModel>(Session);
                Result = DAL.SelectId<TipoContratoModel>(id);
            }
            return Result;
        }
		
        public void Insert(TipoContratoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoContratoModel> DAL = new NHibernateDAL<TipoContratoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(TipoContratoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoContratoModel> DAL = new NHibernateDAL<TipoContratoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(TipoContratoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<TipoContratoModel> DAL = new NHibernateDAL<TipoContratoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}