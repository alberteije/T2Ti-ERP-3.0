using contratos.Models;
using contratos.NHibernate;
using ISession = NHibernate.ISession;

namespace contratos.Services
{
    public class ContratoService
    {

        public IEnumerable<ContratoModel> GetList()
        {
            IList<ContratoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoModel> DAL = new NHibernateDAL<ContratoModel>(Session);
                Result = DAL.Select(new ContratoModel());
            }
            return Result;
        }

        public IEnumerable<ContratoModel> GetListFilter(Filter filterObj)
        {
            IList<ContratoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContratoModel where " + filterObj.Where;
                NHibernateDAL<ContratoModel> DAL = new NHibernateDAL<ContratoModel>(Session);
                Result = DAL.SelectListSql<ContratoModel>(Query);
            }
            return Result;
        }
		
        public ContratoModel GetObject(int id)
        {
            ContratoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoModel> DAL = new NHibernateDAL<ContratoModel>(Session);
                Result = DAL.SelectId<ContratoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContratoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoModel> DAL = new NHibernateDAL<ContratoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContratoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoModel> DAL = new NHibernateDAL<ContratoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContratoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoModel> DAL = new NHibernateDAL<ContratoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}