using contratos.Models;
using contratos.NHibernate;
using ISession = NHibernate.ISession;

namespace contratos.Services
{
    public class ContratoSolicitacaoServicoService
    {

        public IEnumerable<ContratoSolicitacaoServicoModel> GetList()
        {
            IList<ContratoSolicitacaoServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoSolicitacaoServicoModel> DAL = new NHibernateDAL<ContratoSolicitacaoServicoModel>(Session);
                Result = DAL.Select(new ContratoSolicitacaoServicoModel());
            }
            return Result;
        }

        public IEnumerable<ContratoSolicitacaoServicoModel> GetListFilter(Filter filterObj)
        {
            IList<ContratoSolicitacaoServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContratoSolicitacaoServicoModel where " + filterObj.Where;
                NHibernateDAL<ContratoSolicitacaoServicoModel> DAL = new NHibernateDAL<ContratoSolicitacaoServicoModel>(Session);
                Result = DAL.SelectListSql<ContratoSolicitacaoServicoModel>(Query);
            }
            return Result;
        }
		
        public ContratoSolicitacaoServicoModel GetObject(int id)
        {
            ContratoSolicitacaoServicoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoSolicitacaoServicoModel> DAL = new NHibernateDAL<ContratoSolicitacaoServicoModel>(Session);
                Result = DAL.SelectId<ContratoSolicitacaoServicoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContratoSolicitacaoServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoSolicitacaoServicoModel> DAL = new NHibernateDAL<ContratoSolicitacaoServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContratoSolicitacaoServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoSolicitacaoServicoModel> DAL = new NHibernateDAL<ContratoSolicitacaoServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContratoSolicitacaoServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContratoSolicitacaoServicoModel> DAL = new NHibernateDAL<ContratoSolicitacaoServicoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}