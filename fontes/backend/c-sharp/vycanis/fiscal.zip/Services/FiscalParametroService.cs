using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalParametroService
    {

        public IEnumerable<FiscalParametroModel> GetList()
        {
            IList<FiscalParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalParametroModel> DAL = new NHibernateDAL<FiscalParametroModel>(Session);
                Result = DAL.Select(new FiscalParametroModel());
            }
            return Result;
        }

        public IEnumerable<FiscalParametroModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalParametroModel where " + filterObj.Where;
                NHibernateDAL<FiscalParametroModel> DAL = new NHibernateDAL<FiscalParametroModel>(Session);
                Result = DAL.SelectListSql<FiscalParametroModel>(Query);
            }
            return Result;
        }
		
        public FiscalParametroModel GetObject(int id)
        {
            FiscalParametroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalParametroModel> DAL = new NHibernateDAL<FiscalParametroModel>(Session);
                Result = DAL.SelectId<FiscalParametroModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalParametroModel> DAL = new NHibernateDAL<FiscalParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalParametroModel> DAL = new NHibernateDAL<FiscalParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalParametroModel> DAL = new NHibernateDAL<FiscalParametroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}