using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalEstadualRegimeService
    {

        public IEnumerable<FiscalEstadualRegimeModel> GetList()
        {
            IList<FiscalEstadualRegimeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualRegimeModel> DAL = new NHibernateDAL<FiscalEstadualRegimeModel>(Session);
                Result = DAL.Select(new FiscalEstadualRegimeModel());
            }
            return Result;
        }

        public IEnumerable<FiscalEstadualRegimeModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalEstadualRegimeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalEstadualRegimeModel where " + filterObj.Where;
                NHibernateDAL<FiscalEstadualRegimeModel> DAL = new NHibernateDAL<FiscalEstadualRegimeModel>(Session);
                Result = DAL.SelectListSql<FiscalEstadualRegimeModel>(Query);
            }
            return Result;
        }
		
        public FiscalEstadualRegimeModel GetObject(int id)
        {
            FiscalEstadualRegimeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualRegimeModel> DAL = new NHibernateDAL<FiscalEstadualRegimeModel>(Session);
                Result = DAL.SelectId<FiscalEstadualRegimeModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalEstadualRegimeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualRegimeModel> DAL = new NHibernateDAL<FiscalEstadualRegimeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalEstadualRegimeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualRegimeModel> DAL = new NHibernateDAL<FiscalEstadualRegimeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalEstadualRegimeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualRegimeModel> DAL = new NHibernateDAL<FiscalEstadualRegimeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}