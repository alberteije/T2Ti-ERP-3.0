using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalApuracaoIcmsService
    {

        public IEnumerable<FiscalApuracaoIcmsModel> GetList()
        {
            IList<FiscalApuracaoIcmsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalApuracaoIcmsModel> DAL = new NHibernateDAL<FiscalApuracaoIcmsModel>(Session);
                Result = DAL.Select(new FiscalApuracaoIcmsModel());
            }
            return Result;
        }

        public IEnumerable<FiscalApuracaoIcmsModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalApuracaoIcmsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalApuracaoIcmsModel where " + filterObj.Where;
                NHibernateDAL<FiscalApuracaoIcmsModel> DAL = new NHibernateDAL<FiscalApuracaoIcmsModel>(Session);
                Result = DAL.SelectListSql<FiscalApuracaoIcmsModel>(Query);
            }
            return Result;
        }
		
        public FiscalApuracaoIcmsModel GetObject(int id)
        {
            FiscalApuracaoIcmsModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalApuracaoIcmsModel> DAL = new NHibernateDAL<FiscalApuracaoIcmsModel>(Session);
                Result = DAL.SelectId<FiscalApuracaoIcmsModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalApuracaoIcmsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalApuracaoIcmsModel> DAL = new NHibernateDAL<FiscalApuracaoIcmsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalApuracaoIcmsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalApuracaoIcmsModel> DAL = new NHibernateDAL<FiscalApuracaoIcmsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalApuracaoIcmsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalApuracaoIcmsModel> DAL = new NHibernateDAL<FiscalApuracaoIcmsModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}