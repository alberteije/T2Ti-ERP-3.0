using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalNotaFiscalEntradaService
    {

        public IEnumerable<FiscalNotaFiscalEntradaModel> GetList()
        {
            IList<FiscalNotaFiscalEntradaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalEntradaModel> DAL = new NHibernateDAL<FiscalNotaFiscalEntradaModel>(Session);
                Result = DAL.Select(new FiscalNotaFiscalEntradaModel());
            }
            return Result;
        }

        public IEnumerable<FiscalNotaFiscalEntradaModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalNotaFiscalEntradaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalNotaFiscalEntradaModel where " + filterObj.Where;
                NHibernateDAL<FiscalNotaFiscalEntradaModel> DAL = new NHibernateDAL<FiscalNotaFiscalEntradaModel>(Session);
                Result = DAL.SelectListSql<FiscalNotaFiscalEntradaModel>(Query);
            }
            return Result;
        }
		
        public FiscalNotaFiscalEntradaModel GetObject(int id)
        {
            FiscalNotaFiscalEntradaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalEntradaModel> DAL = new NHibernateDAL<FiscalNotaFiscalEntradaModel>(Session);
                Result = DAL.SelectId<FiscalNotaFiscalEntradaModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalNotaFiscalEntradaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalEntradaModel> DAL = new NHibernateDAL<FiscalNotaFiscalEntradaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalNotaFiscalEntradaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalEntradaModel> DAL = new NHibernateDAL<FiscalNotaFiscalEntradaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalNotaFiscalEntradaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalEntradaModel> DAL = new NHibernateDAL<FiscalNotaFiscalEntradaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}