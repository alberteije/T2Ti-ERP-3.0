namespace fiscal.Models
{
	public class FiscalNotaFiscalEntradaModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public int? CfopEntrada { get; set; } 

		public System.Nullable<System.Decimal> ValorRateioFrete { get; set; } 

		public System.Nullable<System.Decimal> ValorCustoMedio { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsAntecipado { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcmsAntecipado { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIcmsCreditado { get; set; } 

		public System.Nullable<System.Decimal> ValorBcPisCreditado { get; set; } 

		public System.Nullable<System.Decimal> ValorBcCofinsCreditado { get; set; } 

		public System.Nullable<System.Decimal> ValorBcIpiCreditado { get; set; } 

		public string? CstCreditoIcms { get; set; } 

		public string? CstCreditoPis { get; set; } 

		public string? CstCreditoCofins { get; set; } 

		public string? CstCreditoIpi { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsCreditado { get; set; } 

		public System.Nullable<System.Decimal> ValorPisCreditado { get; set; } 

		public System.Nullable<System.Decimal> ValorCofinsCreditado { get; set; } 

		public System.Nullable<System.Decimal> ValorIpiCreditado { get; set; } 

		public int? QtdeParcelaCreditoPis { get; set; } 

		public int? QtdeParcelaCreditoCofins { get; set; } 

		public int? QtdeParcelaCreditoIcms { get; set; } 

		public int? QtdeParcelaCreditoIpi { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCreditoIcms { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCreditoPis { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCreditoCofins { get; set; } 

		public System.Nullable<System.Decimal> AliquotaCreditoIpi { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
