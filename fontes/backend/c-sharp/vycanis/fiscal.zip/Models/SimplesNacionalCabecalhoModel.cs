namespace fiscal.Models
{
	public class SimplesNacionalCabecalhoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> VigenciaInicial { get; set; } 

		public System.Nullable<System.DateTime> VigenciaFinal { get; set; } 

		public string? Anexo { get; set; } 

		public string? Tabela { get; set; } 

		private IList<SimplesNacionalDetalheModel>? simplesNacionalDetalheModelList; 
		public IList<SimplesNacionalDetalheModel>? SimplesNacionalDetalheModelList 
		{ 
			get 
			{ 
				return simplesNacionalDetalheModelList; 
			} 
			set 
			{ 
				simplesNacionalDetalheModelList = value; 
				foreach (SimplesNacionalDetalheModel simplesNacionalDetalheModel in simplesNacionalDetalheModelList!) 
				{ 
					simplesNacionalDetalheModel.SimplesNacionalCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
