namespace fiscal.Models
{
	public class FiscalNotaFiscalSaidaModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public NfeCabecalhoModel? NfeCabecalhoModel { get; set; } 

	}
}
