namespace fiscal.Models
{
	public class FiscalInscricoesSubstitutasModel
	{	
		public int? Id { get; set; } 

		public string? Uf { get; set; } 

		public string? InscricaoEstadual { get; set; } 

		public string? Pmpf { get; set; } 

		public FiscalParametroModel? FiscalParametroModel { get; set; } 

	}
}
