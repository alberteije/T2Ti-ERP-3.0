namespace fiscal.Models
{
	public class FiscalApuracaoIcmsModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalDebito { get; set; } 

		public System.Nullable<System.Decimal> ValorAjusteDebito { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalAjusteDebito { get; set; } 

		public System.Nullable<System.Decimal> ValorEstornoCredito { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalCredito { get; set; } 

		public System.Nullable<System.Decimal> ValorAjusteCredito { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalAjusteCredito { get; set; } 

		public System.Nullable<System.Decimal> ValorEstornoDebito { get; set; } 

		public System.Nullable<System.Decimal> ValorSaldoCredorAnterior { get; set; } 

		public System.Nullable<System.Decimal> ValorSaldoApurado { get; set; } 

		public System.Nullable<System.Decimal> ValorTotalDeducao { get; set; } 

		public System.Nullable<System.Decimal> ValorIcmsRecolher { get; set; } 

		public System.Nullable<System.Decimal> ValorSaldoCredorTransp { get; set; } 

		public System.Nullable<System.Decimal> ValorDebitoEspecial { get; set; } 

	}
}
