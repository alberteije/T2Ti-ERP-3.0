namespace fiscal.Models
{
	public class FiscalEstadualRegimeModel
	{	
		public int? Id { get; set; } 

		public string? Uf { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

	}
}
