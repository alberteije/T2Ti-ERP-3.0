namespace fiscal.Models
{
	public class FiscalLivroModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		private IList<FiscalTermoModel>? fiscalTermoModelList; 
		public IList<FiscalTermoModel>? FiscalTermoModelList 
		{ 
			get 
			{ 
				return fiscalTermoModelList; 
			} 
			set 
			{ 
				fiscalTermoModelList = value; 
				foreach (FiscalTermoModel fiscalTermoModel in fiscalTermoModelList!) 
				{ 
					fiscalTermoModel.FiscalLivroModel = this; 
				} 
			} 
		} 

	}
}
