namespace fiscal.Models
{
	public class SimplesNacionalDetalheModel
	{	
		public int? Id { get; set; } 

		public int? Faixa { get; set; } 

		public System.Nullable<System.Decimal> ValorInicial { get; set; } 

		public System.Nullable<System.Decimal> ValorFinal { get; set; } 

		public System.Nullable<System.Decimal> Aliquota { get; set; } 

		public System.Nullable<System.Decimal> Irpj { get; set; } 

		public System.Nullable<System.Decimal> Csll { get; set; } 

		public System.Nullable<System.Decimal> Cofins { get; set; } 

		public System.Nullable<System.Decimal> PisPasep { get; set; } 

		public System.Nullable<System.Decimal> Cpp { get; set; } 

		public System.Nullable<System.Decimal> Icms { get; set; } 

		public System.Nullable<System.Decimal> Ipi { get; set; } 

		public System.Nullable<System.Decimal> Iss { get; set; } 

		public SimplesNacionalCabecalhoModel? SimplesNacionalCabecalhoModel { get; set; } 

	}
}
