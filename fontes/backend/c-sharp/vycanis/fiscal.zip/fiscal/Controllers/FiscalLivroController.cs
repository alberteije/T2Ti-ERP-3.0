using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("fiscal-livro")]
    [Produces("application/json")]
    public class FiscalLivroController : Controller
    {
		private readonly FiscalLivroService _service;

        public FiscalLivroController()
        {
            _service = new FiscalLivroService();
        }

        [HttpGet]
        public IActionResult GetListFiscalLivro([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FiscalLivroModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FiscalLivro]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFiscalLivro")]
        public IActionResult GetObjectFiscalLivro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FiscalLivro]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FiscalLivro]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFiscalLivro([FromBody]FiscalLivroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FiscalLivro]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFiscalLivro", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FiscalLivro]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFiscalLivro([FromBody]FiscalLivroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FiscalLivro]", null));
                }

                _service.Update(objJson);

                return GetObjectFiscalLivro(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FiscalLivro]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFiscalLivro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FiscalLivro]", ex));
            }
        }

    }
}