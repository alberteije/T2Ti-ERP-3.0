using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("fiscal-nota-fiscal-saida")]
    [Produces("application/json")]
    public class FiscalNotaFiscalSaidaController : Controller
    {
		private readonly FiscalNotaFiscalSaidaService _service;

        public FiscalNotaFiscalSaidaController()
        {
            _service = new FiscalNotaFiscalSaidaService();
        }

        [HttpGet]
        public IActionResult GetListFiscalNotaFiscalSaida([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FiscalNotaFiscalSaidaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FiscalNotaFiscalSaida]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFiscalNotaFiscalSaida")]
        public IActionResult GetObjectFiscalNotaFiscalSaida(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FiscalNotaFiscalSaida]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FiscalNotaFiscalSaida]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFiscalNotaFiscalSaida([FromBody]FiscalNotaFiscalSaidaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FiscalNotaFiscalSaida]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFiscalNotaFiscalSaida", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FiscalNotaFiscalSaida]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFiscalNotaFiscalSaida([FromBody]FiscalNotaFiscalSaidaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FiscalNotaFiscalSaida]", null));
                }

                _service.Update(objJson);

                return GetObjectFiscalNotaFiscalSaida(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FiscalNotaFiscalSaida]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFiscalNotaFiscalSaida(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FiscalNotaFiscalSaida]", ex));
            }
        }

    }
}