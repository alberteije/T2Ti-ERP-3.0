using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("simples-nacional-cabecalho")]
    [Produces("application/json")]
    public class SimplesNacionalCabecalhoController : Controller
    {
		private readonly SimplesNacionalCabecalhoService _service;

        public SimplesNacionalCabecalhoController()
        {
            _service = new SimplesNacionalCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListSimplesNacionalCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SimplesNacionalCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList SimplesNacionalCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSimplesNacionalCabecalho")]
        public IActionResult GetObjectSimplesNacionalCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject SimplesNacionalCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject SimplesNacionalCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSimplesNacionalCabecalho([FromBody]SimplesNacionalCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert SimplesNacionalCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSimplesNacionalCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert SimplesNacionalCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSimplesNacionalCabecalho([FromBody]SimplesNacionalCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update SimplesNacionalCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectSimplesNacionalCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update SimplesNacionalCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSimplesNacionalCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete SimplesNacionalCabecalho]", ex));
            }
        }

    }
}