using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("fiscal-estadual-porte")]
    [Produces("application/json")]
    public class FiscalEstadualPorteController : Controller
    {
		private readonly FiscalEstadualPorteService _service;

        public FiscalEstadualPorteController()
        {
            _service = new FiscalEstadualPorteService();
        }

        [HttpGet]
        public IActionResult GetListFiscalEstadualPorte([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FiscalEstadualPorteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FiscalEstadualPorte]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFiscalEstadualPorte")]
        public IActionResult GetObjectFiscalEstadualPorte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FiscalEstadualPorte]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FiscalEstadualPorte]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFiscalEstadualPorte([FromBody]FiscalEstadualPorteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FiscalEstadualPorte]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFiscalEstadualPorte", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FiscalEstadualPorte]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFiscalEstadualPorte([FromBody]FiscalEstadualPorteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FiscalEstadualPorte]", null));
                }

                _service.Update(objJson);

                return GetObjectFiscalEstadualPorte(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FiscalEstadualPorte]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFiscalEstadualPorte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FiscalEstadualPorte]", ex));
            }
        }

    }
}