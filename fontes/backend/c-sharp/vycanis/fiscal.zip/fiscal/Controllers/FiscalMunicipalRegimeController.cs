using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("fiscal-municipal-regime")]
    [Produces("application/json")]
    public class FiscalMunicipalRegimeController : Controller
    {
		private readonly FiscalMunicipalRegimeService _service;

        public FiscalMunicipalRegimeController()
        {
            _service = new FiscalMunicipalRegimeService();
        }

        [HttpGet]
        public IActionResult GetListFiscalMunicipalRegime([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FiscalMunicipalRegimeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FiscalMunicipalRegime]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFiscalMunicipalRegime")]
        public IActionResult GetObjectFiscalMunicipalRegime(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FiscalMunicipalRegime]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FiscalMunicipalRegime]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFiscalMunicipalRegime([FromBody]FiscalMunicipalRegimeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FiscalMunicipalRegime]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFiscalMunicipalRegime", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FiscalMunicipalRegime]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFiscalMunicipalRegime([FromBody]FiscalMunicipalRegimeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FiscalMunicipalRegime]", null));
                }

                _service.Update(objJson);

                return GetObjectFiscalMunicipalRegime(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FiscalMunicipalRegime]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFiscalMunicipalRegime(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FiscalMunicipalRegime]", ex));
            }
        }

    }
}