using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalNotaFiscalSaidaService
    {

        public IEnumerable<FiscalNotaFiscalSaidaModel> GetList()
        {
            IList<FiscalNotaFiscalSaidaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalSaidaModel> DAL = new NHibernateDAL<FiscalNotaFiscalSaidaModel>(Session);
                Result = DAL.Select(new FiscalNotaFiscalSaidaModel());
            }
            return Result;
        }

        public IEnumerable<FiscalNotaFiscalSaidaModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalNotaFiscalSaidaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalNotaFiscalSaidaModel where " + filterObj.Where;
                NHibernateDAL<FiscalNotaFiscalSaidaModel> DAL = new NHibernateDAL<FiscalNotaFiscalSaidaModel>(Session);
                Result = DAL.SelectListSql<FiscalNotaFiscalSaidaModel>(Query);
            }
            return Result;
        }
		
        public FiscalNotaFiscalSaidaModel GetObject(int id)
        {
            FiscalNotaFiscalSaidaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalSaidaModel> DAL = new NHibernateDAL<FiscalNotaFiscalSaidaModel>(Session);
                Result = DAL.SelectId<FiscalNotaFiscalSaidaModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalNotaFiscalSaidaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalSaidaModel> DAL = new NHibernateDAL<FiscalNotaFiscalSaidaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalNotaFiscalSaidaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalSaidaModel> DAL = new NHibernateDAL<FiscalNotaFiscalSaidaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalNotaFiscalSaidaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalNotaFiscalSaidaModel> DAL = new NHibernateDAL<FiscalNotaFiscalSaidaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}