using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalEstadualPorteService
    {

        public IEnumerable<FiscalEstadualPorteModel> GetList()
        {
            IList<FiscalEstadualPorteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualPorteModel> DAL = new NHibernateDAL<FiscalEstadualPorteModel>(Session);
                Result = DAL.Select(new FiscalEstadualPorteModel());
            }
            return Result;
        }

        public IEnumerable<FiscalEstadualPorteModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalEstadualPorteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalEstadualPorteModel where " + filterObj.Where;
                NHibernateDAL<FiscalEstadualPorteModel> DAL = new NHibernateDAL<FiscalEstadualPorteModel>(Session);
                Result = DAL.SelectListSql<FiscalEstadualPorteModel>(Query);
            }
            return Result;
        }
		
        public FiscalEstadualPorteModel GetObject(int id)
        {
            FiscalEstadualPorteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualPorteModel> DAL = new NHibernateDAL<FiscalEstadualPorteModel>(Session);
                Result = DAL.SelectId<FiscalEstadualPorteModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalEstadualPorteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualPorteModel> DAL = new NHibernateDAL<FiscalEstadualPorteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalEstadualPorteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualPorteModel> DAL = new NHibernateDAL<FiscalEstadualPorteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalEstadualPorteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalEstadualPorteModel> DAL = new NHibernateDAL<FiscalEstadualPorteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}