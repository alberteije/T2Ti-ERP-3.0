using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalMunicipalRegimeService
    {

        public IEnumerable<FiscalMunicipalRegimeModel> GetList()
        {
            IList<FiscalMunicipalRegimeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalMunicipalRegimeModel> DAL = new NHibernateDAL<FiscalMunicipalRegimeModel>(Session);
                Result = DAL.Select(new FiscalMunicipalRegimeModel());
            }
            return Result;
        }

        public IEnumerable<FiscalMunicipalRegimeModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalMunicipalRegimeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalMunicipalRegimeModel where " + filterObj.Where;
                NHibernateDAL<FiscalMunicipalRegimeModel> DAL = new NHibernateDAL<FiscalMunicipalRegimeModel>(Session);
                Result = DAL.SelectListSql<FiscalMunicipalRegimeModel>(Query);
            }
            return Result;
        }
		
        public FiscalMunicipalRegimeModel GetObject(int id)
        {
            FiscalMunicipalRegimeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalMunicipalRegimeModel> DAL = new NHibernateDAL<FiscalMunicipalRegimeModel>(Session);
                Result = DAL.SelectId<FiscalMunicipalRegimeModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalMunicipalRegimeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalMunicipalRegimeModel> DAL = new NHibernateDAL<FiscalMunicipalRegimeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalMunicipalRegimeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalMunicipalRegimeModel> DAL = new NHibernateDAL<FiscalMunicipalRegimeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalMunicipalRegimeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalMunicipalRegimeModel> DAL = new NHibernateDAL<FiscalMunicipalRegimeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}