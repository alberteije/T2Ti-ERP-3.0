using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class FiscalLivroService
    {

        public IEnumerable<FiscalLivroModel> GetList()
        {
            IList<FiscalLivroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalLivroModel> DAL = new NHibernateDAL<FiscalLivroModel>(Session);
                Result = DAL.Select(new FiscalLivroModel());
            }
            return Result;
        }

        public IEnumerable<FiscalLivroModel> GetListFilter(Filter filterObj)
        {
            IList<FiscalLivroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FiscalLivroModel where " + filterObj.Where;
                NHibernateDAL<FiscalLivroModel> DAL = new NHibernateDAL<FiscalLivroModel>(Session);
                Result = DAL.SelectListSql<FiscalLivroModel>(Query);
            }
            return Result;
        }
		
        public FiscalLivroModel GetObject(int id)
        {
            FiscalLivroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalLivroModel> DAL = new NHibernateDAL<FiscalLivroModel>(Session);
                Result = DAL.SelectId<FiscalLivroModel>(id);
            }
            return Result;
        }
		
        public void Insert(FiscalLivroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalLivroModel> DAL = new NHibernateDAL<FiscalLivroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FiscalLivroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalLivroModel> DAL = new NHibernateDAL<FiscalLivroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FiscalLivroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FiscalLivroModel> DAL = new NHibernateDAL<FiscalLivroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}