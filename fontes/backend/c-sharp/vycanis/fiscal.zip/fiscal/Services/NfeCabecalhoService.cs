using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class NfeCabecalhoService
    {

        public IEnumerable<NfeCabecalhoModel> GetList()
        {
            IList<NfeCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCabecalhoModel> DAL = new NHibernateDAL<NfeCabecalhoModel>(Session);
                Result = DAL.Select(new NfeCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<NfeCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<NfeCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from NfeCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<NfeCabecalhoModel> DAL = new NHibernateDAL<NfeCabecalhoModel>(Session);
                Result = DAL.SelectListSql<NfeCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public NfeCabecalhoModel GetObject(int id)
        {
            NfeCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCabecalhoModel> DAL = new NHibernateDAL<NfeCabecalhoModel>(Session);
                Result = DAL.SelectId<NfeCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(NfeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCabecalhoModel> DAL = new NHibernateDAL<NfeCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(NfeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCabecalhoModel> DAL = new NHibernateDAL<NfeCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(NfeCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<NfeCabecalhoModel> DAL = new NHibernateDAL<NfeCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}