using fiscal.Models;
using fiscal.NHibernate;
using ISession = NHibernate.ISession;

namespace fiscal.Services
{
    public class SimplesNacionalCabecalhoService
    {

        public IEnumerable<SimplesNacionalCabecalhoModel> GetList()
        {
            IList<SimplesNacionalCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SimplesNacionalCabecalhoModel> DAL = new NHibernateDAL<SimplesNacionalCabecalhoModel>(Session);
                Result = DAL.Select(new SimplesNacionalCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<SimplesNacionalCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<SimplesNacionalCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SimplesNacionalCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<SimplesNacionalCabecalhoModel> DAL = new NHibernateDAL<SimplesNacionalCabecalhoModel>(Session);
                Result = DAL.SelectListSql<SimplesNacionalCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public SimplesNacionalCabecalhoModel GetObject(int id)
        {
            SimplesNacionalCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SimplesNacionalCabecalhoModel> DAL = new NHibernateDAL<SimplesNacionalCabecalhoModel>(Session);
                Result = DAL.SelectId<SimplesNacionalCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(SimplesNacionalCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SimplesNacionalCabecalhoModel> DAL = new NHibernateDAL<SimplesNacionalCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SimplesNacionalCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SimplesNacionalCabecalhoModel> DAL = new NHibernateDAL<SimplesNacionalCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SimplesNacionalCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SimplesNacionalCabecalhoModel> DAL = new NHibernateDAL<SimplesNacionalCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}