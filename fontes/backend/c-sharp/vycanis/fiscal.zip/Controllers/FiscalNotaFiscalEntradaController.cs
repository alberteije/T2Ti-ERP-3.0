using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("fiscal-nota-fiscal-entrada")]
    [Produces("application/json")]
    public class FiscalNotaFiscalEntradaController : Controller
    {
		private readonly FiscalNotaFiscalEntradaService _service;

        public FiscalNotaFiscalEntradaController()
        {
            _service = new FiscalNotaFiscalEntradaService();
        }

        [HttpGet]
        public IActionResult GetListFiscalNotaFiscalEntrada([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FiscalNotaFiscalEntradaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FiscalNotaFiscalEntrada]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFiscalNotaFiscalEntrada")]
        public IActionResult GetObjectFiscalNotaFiscalEntrada(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FiscalNotaFiscalEntrada]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FiscalNotaFiscalEntrada]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFiscalNotaFiscalEntrada([FromBody]FiscalNotaFiscalEntradaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FiscalNotaFiscalEntrada]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFiscalNotaFiscalEntrada", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FiscalNotaFiscalEntrada]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFiscalNotaFiscalEntrada([FromBody]FiscalNotaFiscalEntradaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FiscalNotaFiscalEntrada]", null));
                }

                _service.Update(objJson);

                return GetObjectFiscalNotaFiscalEntrada(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FiscalNotaFiscalEntrada]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFiscalNotaFiscalEntrada(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FiscalNotaFiscalEntrada]", ex));
            }
        }

    }
}