using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("fiscal-estadual-regime")]
    [Produces("application/json")]
    public class FiscalEstadualRegimeController : Controller
    {
		private readonly FiscalEstadualRegimeService _service;

        public FiscalEstadualRegimeController()
        {
            _service = new FiscalEstadualRegimeService();
        }

        [HttpGet]
        public IActionResult GetListFiscalEstadualRegime([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FiscalEstadualRegimeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FiscalEstadualRegime]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFiscalEstadualRegime")]
        public IActionResult GetObjectFiscalEstadualRegime(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FiscalEstadualRegime]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FiscalEstadualRegime]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFiscalEstadualRegime([FromBody]FiscalEstadualRegimeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FiscalEstadualRegime]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFiscalEstadualRegime", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FiscalEstadualRegime]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFiscalEstadualRegime([FromBody]FiscalEstadualRegimeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FiscalEstadualRegime]", null));
                }

                _service.Update(objJson);

                return GetObjectFiscalEstadualRegime(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FiscalEstadualRegime]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFiscalEstadualRegime(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FiscalEstadualRegime]", ex));
            }
        }

    }
}