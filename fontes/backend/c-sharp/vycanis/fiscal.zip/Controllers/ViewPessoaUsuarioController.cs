using Microsoft.AspNetCore.Mvc;
using fiscal.Models;
using fiscal.Services;

namespace fiscal.Controllers
{
    [Route("view-pessoa-usuario")]
    [Produces("application/json")]
    public class ViewPessoaUsuarioController : Controller
    {
		private readonly ViewPessoaUsuarioService _service;

        public ViewPessoaUsuarioController()
        {
            _service = new ViewPessoaUsuarioService();
        }

        [HttpGet]
        public IActionResult GetListViewPessoaUsuario([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ViewPessoaUsuarioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ViewPessoaUsuario]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectViewPessoaUsuario")]
        public IActionResult GetObjectViewPessoaUsuario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ViewPessoaUsuario]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ViewPessoaUsuario]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertViewPessoaUsuario([FromBody]ViewPessoaUsuarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ViewPessoaUsuario]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectViewPessoaUsuario", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ViewPessoaUsuario]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateViewPessoaUsuario([FromBody]ViewPessoaUsuarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ViewPessoaUsuario]", null));
                }

                _service.Update(objJson);

                return GetObjectViewPessoaUsuario(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ViewPessoaUsuario]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteViewPessoaUsuario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ViewPessoaUsuario]", ex));
            }
        }

    }
}