namespace inventario.Models
{
	public class InventarioAjusteCabModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataAjuste { get; set; } 

		public string? Tipo { get; set; } 

		public System.Nullable<System.Decimal> Taxa { get; set; } 

		public string? Justificativa { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<InventarioAjusteDetModel>? inventarioAjusteDetModelList; 
		public IList<InventarioAjusteDetModel>? InventarioAjusteDetModelList 
		{ 
			get 
			{ 
				return inventarioAjusteDetModelList; 
			} 
			set 
			{ 
				inventarioAjusteDetModelList = value; 
				foreach (InventarioAjusteDetModel inventarioAjusteDetModel in inventarioAjusteDetModelList!) 
				{ 
					inventarioAjusteDetModel.InventarioAjusteCabModel = this; 
				} 
			} 
		} 

	}
}
