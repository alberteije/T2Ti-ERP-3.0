namespace inventario.Models
{
	public class InventarioAjusteDetModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorOriginal { get; set; } 

		public System.Nullable<System.Decimal> ValorReajuste { get; set; } 

		public InventarioAjusteCabModel? InventarioAjusteCabModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
