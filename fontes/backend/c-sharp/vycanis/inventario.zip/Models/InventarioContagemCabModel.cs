namespace inventario.Models
{
	public class InventarioContagemCabModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataContagem { get; set; } 

		public string? EstoqueAtualizado { get; set; } 

		public string? Tipo { get; set; } 

		private IList<InventarioContagemDetModel>? inventarioContagemDetModelList; 
		public IList<InventarioContagemDetModel>? InventarioContagemDetModelList 
		{ 
			get 
			{ 
				return inventarioContagemDetModelList; 
			} 
			set 
			{ 
				inventarioContagemDetModelList = value; 
				foreach (InventarioContagemDetModel inventarioContagemDetModel in inventarioContagemDetModelList!) 
				{ 
					inventarioContagemDetModel.InventarioContagemCabModel = this; 
				} 
			} 
		} 

	}
}
