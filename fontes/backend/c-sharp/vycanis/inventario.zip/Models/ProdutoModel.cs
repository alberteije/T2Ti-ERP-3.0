namespace inventario.Models
{
	public class ProdutoModel
	{	
		public int? Id { get; set; } 

		public int? IdTributIcmsCustomCab { get; set; } 

		public int? IdTributGrupoTributario { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public string? Gtin { get; set; } 

		public string? CodigoInterno { get; set; } 

		public System.Nullable<System.Decimal> ValorCompra { get; set; } 

		public System.Nullable<System.Decimal> ValorVenda { get; set; } 

		public string? CodigoNcm { get; set; } 

		public System.Nullable<System.Decimal> EstoqueMinimo { get; set; } 

		public System.Nullable<System.Decimal> EstoqueMaximo { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeEstoque { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

	}
}
