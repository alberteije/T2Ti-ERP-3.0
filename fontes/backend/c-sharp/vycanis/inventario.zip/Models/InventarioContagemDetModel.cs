namespace inventario.Models
{
	public class InventarioContagemDetModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Contagem01 { get; set; } 

		public System.Nullable<System.Decimal> Contagem02 { get; set; } 

		public System.Nullable<System.Decimal> Contagem03 { get; set; } 

		public string? FechadoContagem { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeSistema { get; set; } 

		public System.Nullable<System.Decimal> Acuracidade { get; set; } 

		public System.Nullable<System.Decimal> Divergencia { get; set; } 

		public InventarioContagemCabModel? InventarioContagemCabModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
