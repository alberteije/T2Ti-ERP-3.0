using Microsoft.AspNetCore.Mvc;
using inventario.Models;
using inventario.Services;

namespace inventario.Controllers
{
    [Route("produto")]
    [Produces("application/json")]
    public class ProdutoController : Controller
    {
		private readonly ProdutoService _service;

        public ProdutoController()
        {
            _service = new ProdutoService();
        }

        [HttpGet]
        public IActionResult GetListProduto([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ProdutoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Produto]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectProduto")]
        public IActionResult GetObjectProduto(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Produto]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Produto]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertProduto([FromBody]ProdutoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Produto]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectProduto", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Produto]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateProduto([FromBody]ProdutoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Produto]", null));
                }

                _service.Update(objJson);

                return GetObjectProduto(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Produto]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProduto(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Produto]", ex));
            }
        }

    }
}