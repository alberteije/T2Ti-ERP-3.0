using Microsoft.AspNetCore.Mvc;
using inventario.Models;
using inventario.Services;

namespace inventario.Controllers
{
    [Route("inventario-contagem-cab")]
    [Produces("application/json")]
    public class InventarioContagemCabController : Controller
    {
		private readonly InventarioContagemCabService _service;

        public InventarioContagemCabController()
        {
            _service = new InventarioContagemCabService();
        }

        [HttpGet]
        public IActionResult GetListInventarioContagemCab([FromQuery]string filter)
        {
            try
            {
                IEnumerable<InventarioContagemCabModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList InventarioContagemCab]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectInventarioContagemCab")]
        public IActionResult GetObjectInventarioContagemCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject InventarioContagemCab]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject InventarioContagemCab]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertInventarioContagemCab([FromBody]InventarioContagemCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert InventarioContagemCab]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectInventarioContagemCab", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert InventarioContagemCab]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateInventarioContagemCab([FromBody]InventarioContagemCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update InventarioContagemCab]", null));
                }

                _service.Update(objJson);

                return GetObjectInventarioContagemCab(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update InventarioContagemCab]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteInventarioContagemCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete InventarioContagemCab]", ex));
            }
        }

    }
}