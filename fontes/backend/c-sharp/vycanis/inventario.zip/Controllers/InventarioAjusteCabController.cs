using Microsoft.AspNetCore.Mvc;
using inventario.Models;
using inventario.Services;

namespace inventario.Controllers
{
    [Route("inventario-ajuste-cab")]
    [Produces("application/json")]
    public class InventarioAjusteCabController : Controller
    {
		private readonly InventarioAjusteCabService _service;

        public InventarioAjusteCabController()
        {
            _service = new InventarioAjusteCabService();
        }

        [HttpGet]
        public IActionResult GetListInventarioAjusteCab([FromQuery]string filter)
        {
            try
            {
                IEnumerable<InventarioAjusteCabModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList InventarioAjusteCab]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectInventarioAjusteCab")]
        public IActionResult GetObjectInventarioAjusteCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject InventarioAjusteCab]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject InventarioAjusteCab]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertInventarioAjusteCab([FromBody]InventarioAjusteCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert InventarioAjusteCab]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectInventarioAjusteCab", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert InventarioAjusteCab]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateInventarioAjusteCab([FromBody]InventarioAjusteCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update InventarioAjusteCab]", null));
                }

                _service.Update(objJson);

                return GetObjectInventarioAjusteCab(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update InventarioAjusteCab]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteInventarioAjusteCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete InventarioAjusteCab]", ex));
            }
        }

    }
}