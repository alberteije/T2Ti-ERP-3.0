using inventario.Models;
using inventario.NHibernate;
using ISession = NHibernate.ISession;

namespace inventario.Services
{
    public class InventarioAjusteCabService
    {

        public IEnumerable<InventarioAjusteCabModel> GetList()
        {
            IList<InventarioAjusteCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioAjusteCabModel> DAL = new NHibernateDAL<InventarioAjusteCabModel>(Session);
                Result = DAL.Select(new InventarioAjusteCabModel());
            }
            return Result;
        }

        public IEnumerable<InventarioAjusteCabModel> GetListFilter(Filter filterObj)
        {
            IList<InventarioAjusteCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from InventarioAjusteCabModel where " + filterObj.Where;
                NHibernateDAL<InventarioAjusteCabModel> DAL = new NHibernateDAL<InventarioAjusteCabModel>(Session);
                Result = DAL.SelectListSql<InventarioAjusteCabModel>(Query);
            }
            return Result;
        }
		
        public InventarioAjusteCabModel GetObject(int id)
        {
            InventarioAjusteCabModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioAjusteCabModel> DAL = new NHibernateDAL<InventarioAjusteCabModel>(Session);
                Result = DAL.SelectId<InventarioAjusteCabModel>(id);
            }
            return Result;
        }
		
        public void Insert(InventarioAjusteCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioAjusteCabModel> DAL = new NHibernateDAL<InventarioAjusteCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(InventarioAjusteCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioAjusteCabModel> DAL = new NHibernateDAL<InventarioAjusteCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(InventarioAjusteCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioAjusteCabModel> DAL = new NHibernateDAL<InventarioAjusteCabModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}