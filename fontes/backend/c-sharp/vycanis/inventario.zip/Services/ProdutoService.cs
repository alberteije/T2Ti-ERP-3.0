using inventario.Models;
using inventario.NHibernate;
using ISession = NHibernate.ISession;

namespace inventario.Services
{
    public class ProdutoService
    {

        public IEnumerable<ProdutoModel> GetList()
        {
            IList<ProdutoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoModel> DAL = new NHibernateDAL<ProdutoModel>(Session);
                Result = DAL.Select(new ProdutoModel());
            }
            return Result;
        }

        public IEnumerable<ProdutoModel> GetListFilter(Filter filterObj)
        {
            IList<ProdutoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ProdutoModel where " + filterObj.Where;
                NHibernateDAL<ProdutoModel> DAL = new NHibernateDAL<ProdutoModel>(Session);
                Result = DAL.SelectListSql<ProdutoModel>(Query);
            }
            return Result;
        }
		
        public ProdutoModel GetObject(int id)
        {
            ProdutoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoModel> DAL = new NHibernateDAL<ProdutoModel>(Session);
                Result = DAL.SelectId<ProdutoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ProdutoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoModel> DAL = new NHibernateDAL<ProdutoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ProdutoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoModel> DAL = new NHibernateDAL<ProdutoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ProdutoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ProdutoModel> DAL = new NHibernateDAL<ProdutoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}