using inventario.Models;
using inventario.NHibernate;
using ISession = NHibernate.ISession;

namespace inventario.Services
{
    public class InventarioContagemCabService
    {

        public IEnumerable<InventarioContagemCabModel> GetList()
        {
            IList<InventarioContagemCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioContagemCabModel> DAL = new NHibernateDAL<InventarioContagemCabModel>(Session);
                Result = DAL.Select(new InventarioContagemCabModel());
            }
            return Result;
        }

        public IEnumerable<InventarioContagemCabModel> GetListFilter(Filter filterObj)
        {
            IList<InventarioContagemCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from InventarioContagemCabModel where " + filterObj.Where;
                NHibernateDAL<InventarioContagemCabModel> DAL = new NHibernateDAL<InventarioContagemCabModel>(Session);
                Result = DAL.SelectListSql<InventarioContagemCabModel>(Query);
            }
            return Result;
        }
		
        public InventarioContagemCabModel GetObject(int id)
        {
            InventarioContagemCabModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioContagemCabModel> DAL = new NHibernateDAL<InventarioContagemCabModel>(Session);
                Result = DAL.SelectId<InventarioContagemCabModel>(id);
            }
            return Result;
        }
		
        public void Insert(InventarioContagemCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioContagemCabModel> DAL = new NHibernateDAL<InventarioContagemCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(InventarioContagemCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioContagemCabModel> DAL = new NHibernateDAL<InventarioContagemCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(InventarioContagemCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InventarioContagemCabModel> DAL = new NHibernateDAL<InventarioContagemCabModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}