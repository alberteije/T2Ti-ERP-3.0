using Microsoft.AspNetCore.Mvc;
using pcp.Models;
using pcp.Services;

namespace pcp.Controllers
{
    [Route("pcp-servico")]
    [Produces("application/json")]
    public class PcpServicoController : Controller
    {
		private readonly PcpServicoService _service;

        public PcpServicoController()
        {
            _service = new PcpServicoService();
        }

        [HttpGet]
        public IActionResult GetListPcpServico([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PcpServicoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PcpServico]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPcpServico")]
        public IActionResult GetObjectPcpServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PcpServico]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PcpServico]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPcpServico([FromBody]PcpServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PcpServico]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPcpServico", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PcpServico]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePcpServico([FromBody]PcpServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PcpServico]", null));
                }

                _service.Update(objJson);

                return GetObjectPcpServico(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PcpServico]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePcpServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PcpServico]", ex));
            }
        }

    }
}