/*******************************************************************************
Title: T2Ti ERP 3.0                                                             
Description: Controller utilizado para controlar a autenticação via JWT
                                                                                
The MIT License                                                                 
                                                                                
Copyright: Copyright (C) 2024 T2Ti.COM                                          
                                                                                
Permission is hereby granted, free of charge, to any person                     
obtaining a copy of this software and associated documentation                  
files (the "Software"), to deal in the Software without                         
restriction, including without limitation the rights to use,                    
copy, modify, merge, publish, distribute, sublicense, and/or sell               
copies of the Software, and to permit persons to whom the                       
Software is furnished to do so, subject to the following                        
conditions:                                                                     
                                                                                
The above copyright notice and this permission notice shall be                  
included in all copies or substantial portions of the Software.                 
                                                                                
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,                 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES                 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND                        
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT                     
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,                    
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING                    
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR                   
OTHER DEALINGS IN THE SOFTWARE.                                                 
                                                                                
       The author may be contacted at:                                          
           t2ti.com@gmail.com                                                   
                                                                                
@author Albert Eije (alberteije@gmail.com)                    
@version 1.0.0
*******************************************************************************/
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using pcp.Models;
using pcp.Services;
using pcp.Utils;

namespace pcp.Controllers.JWT
{
    [Route("login")]
    [Produces("application/json")]
    public class LoginController(IConfiguration config) : Controller
    {
		private readonly ViewPessoaUsuarioService _service = new();
        private readonly IConfiguration _config = config;

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login([FromBody]String corpoRequisicao)
        {
            try
            {
                IActionResult response = Unauthorized();
                
                string corpo = Util.Decifrar(corpoRequisicao.ToString());               
                ViewPessoaUsuarioModel Usuario = JsonConvert.DeserializeObject<ViewPessoaUsuarioModel>(corpo);
                var Retorno = _service.Autenticar(Usuario.Login!, Usuario.Senha!);

                if (Retorno != null)
                {
                    var TokenString = GerarToken(Retorno);
                    var UsuarioRetorno = JsonConvert.SerializeObject(Retorno, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
                    return Ok(new { user = Util.Cifrar(UsuarioRetorno), token = Util.Cifrar(TokenString) });
                }

                return response;
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Erro no Servidor [Login]", ex));
            }
        }


        private string GerarToken(ViewPessoaUsuarioModel usuario)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"] ?? ""));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Sub, usuario.Login!),
                //new Claim(JwtRegisteredClaimNames.Email, usuario.Email),
                new Claim("T2Ti", "Fenix"),
                //new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Issuer"],
                claims,
                expires: DateTime.Now.AddMinutes(12000),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}