using Microsoft.AspNetCore.Mvc;
using pcp.Models;
using pcp.Services;

namespace pcp.Controllers
{
    [Route("pcp-op-cabecalho")]
    [Produces("application/json")]
    public class PcpOpCabecalhoController : Controller
    {
		private readonly PcpOpCabecalhoService _service;

        public PcpOpCabecalhoController()
        {
            _service = new PcpOpCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListPcpOpCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PcpOpCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PcpOpCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPcpOpCabecalho")]
        public IActionResult GetObjectPcpOpCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PcpOpCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PcpOpCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPcpOpCabecalho([FromBody]PcpOpCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PcpOpCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPcpOpCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PcpOpCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePcpOpCabecalho([FromBody]PcpOpCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PcpOpCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectPcpOpCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PcpOpCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePcpOpCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PcpOpCabecalho]", ex));
            }
        }

    }
}