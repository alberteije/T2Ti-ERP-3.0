using pcp.Models;
using pcp.NHibernate;
using ISession = NHibernate.ISession;

namespace pcp.Services
{
    public class PcpInstrucaoService
    {

        public IEnumerable<PcpInstrucaoModel> GetList()
        {
            IList<PcpInstrucaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpInstrucaoModel> DAL = new NHibernateDAL<PcpInstrucaoModel>(Session);
                Result = DAL.Select(new PcpInstrucaoModel());
            }
            return Result;
        }

        public IEnumerable<PcpInstrucaoModel> GetListFilter(Filter filterObj)
        {
            IList<PcpInstrucaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PcpInstrucaoModel where " + filterObj.Where;
                NHibernateDAL<PcpInstrucaoModel> DAL = new NHibernateDAL<PcpInstrucaoModel>(Session);
                Result = DAL.SelectListSql<PcpInstrucaoModel>(Query);
            }
            return Result;
        }
		
        public PcpInstrucaoModel GetObject(int id)
        {
            PcpInstrucaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpInstrucaoModel> DAL = new NHibernateDAL<PcpInstrucaoModel>(Session);
                Result = DAL.SelectId<PcpInstrucaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PcpInstrucaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpInstrucaoModel> DAL = new NHibernateDAL<PcpInstrucaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PcpInstrucaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpInstrucaoModel> DAL = new NHibernateDAL<PcpInstrucaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PcpInstrucaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpInstrucaoModel> DAL = new NHibernateDAL<PcpInstrucaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}