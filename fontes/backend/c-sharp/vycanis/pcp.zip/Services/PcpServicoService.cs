using pcp.Models;
using pcp.NHibernate;
using ISession = NHibernate.ISession;

namespace pcp.Services
{
    public class PcpServicoService
    {

        public IEnumerable<PcpServicoModel> GetList()
        {
            IList<PcpServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpServicoModel> DAL = new NHibernateDAL<PcpServicoModel>(Session);
                Result = DAL.Select(new PcpServicoModel());
            }
            return Result;
        }

        public IEnumerable<PcpServicoModel> GetListFilter(Filter filterObj)
        {
            IList<PcpServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PcpServicoModel where " + filterObj.Where;
                NHibernateDAL<PcpServicoModel> DAL = new NHibernateDAL<PcpServicoModel>(Session);
                Result = DAL.SelectListSql<PcpServicoModel>(Query);
            }
            return Result;
        }
		
        public PcpServicoModel GetObject(int id)
        {
            PcpServicoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpServicoModel> DAL = new NHibernateDAL<PcpServicoModel>(Session);
                Result = DAL.SelectId<PcpServicoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PcpServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpServicoModel> DAL = new NHibernateDAL<PcpServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PcpServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpServicoModel> DAL = new NHibernateDAL<PcpServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PcpServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpServicoModel> DAL = new NHibernateDAL<PcpServicoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}