using pcp.Models;
using pcp.NHibernate;
using ISession = NHibernate.ISession;

namespace pcp.Services
{
    public class PatrimBemService
    {

        public IEnumerable<PatrimBemModel> GetList()
        {
            IList<PatrimBemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimBemModel> DAL = new NHibernateDAL<PatrimBemModel>(Session);
                Result = DAL.Select(new PatrimBemModel());
            }
            return Result;
        }

        public IEnumerable<PatrimBemModel> GetListFilter(Filter filterObj)
        {
            IList<PatrimBemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PatrimBemModel where " + filterObj.Where;
                NHibernateDAL<PatrimBemModel> DAL = new NHibernateDAL<PatrimBemModel>(Session);
                Result = DAL.SelectListSql<PatrimBemModel>(Query);
            }
            return Result;
        }
		
        public PatrimBemModel GetObject(int id)
        {
            PatrimBemModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimBemModel> DAL = new NHibernateDAL<PatrimBemModel>(Session);
                Result = DAL.SelectId<PatrimBemModel>(id);
            }
            return Result;
        }
		
        public void Insert(PatrimBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimBemModel> DAL = new NHibernateDAL<PatrimBemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PatrimBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimBemModel> DAL = new NHibernateDAL<PatrimBemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PatrimBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimBemModel> DAL = new NHibernateDAL<PatrimBemModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}