﻿/**
 * Transient class that controls the filter
 * Take as a basis the following scheme to create filter conditions
 * https://github.com/nestjsx/crud/wiki/Requests
 */
namespace pcp.Models
{
    public class Filter
    {
        public Filter() { }

        public Filter(string filter)
        {
            string[] filterParts = filter.Split("?");

            for (int i = 0; i < filterParts.Length; i++)
            {
                string[] conditions = filterParts[i].Split("||");

                if (i > 0)
                {
                    Where = Where + " AND ";
                }

                // $cont (LIKE %val%, contains)
                if (conditions[1] == "$cont")
                {
                    Field = conditions[0];
                    Value = conditions[2];
                    Where = Where + Field + " like '%" + Value + "%'";
                }

                // $eq (=, equal)
                if (conditions[1] == "$eq")
                {
                    Field = conditions[0];
                    Value = conditions[2];
                    Where = Where + Field + " = " + Value + "'";
                }

                // $between (BETWEEN 'DATA1' and 'DATA2')
                if (conditions[1] == "$between")
                {
                    string[] dates = conditions[2].Split(",");
                    Field = conditions[0];
                    StartDate = dates[0];
                    EndDate = dates[1];
                    Where = Where + Field + " between '" + StartDate + "' and '" + EndDate + "'";
                }
            }

        }

        public string? Field { get; set; }
        public string? Value { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }

        public string? Where { get; set; }
    }
}
