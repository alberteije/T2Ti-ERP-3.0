namespace pcp.Models
{
	public class PcpServicoEquipamentoModel
	{	
		public int? Id { get; set; } 

		public PcpServicoModel? PcpServicoModel { get; set; } 

		public PatrimBemModel? PatrimBemModel { get; set; } 

	}
}
