namespace pcp.Models
{
	public class PcpInstrucaoOpModel
	{	
		public int? Id { get; set; } 

		public PcpOpCabecalhoModel? PcpOpCabecalhoModel { get; set; } 

		public PcpInstrucaoModel? PcpInstrucaoModel { get; set; } 

	}
}
