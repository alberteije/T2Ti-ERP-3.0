namespace pcp.Models
{
	public class PcpInstrucaoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

	}
}
