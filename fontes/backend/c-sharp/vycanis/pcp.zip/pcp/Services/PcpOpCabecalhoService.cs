using pcp.Models;
using pcp.NHibernate;
using ISession = NHibernate.ISession;

namespace pcp.Services
{
    public class PcpOpCabecalhoService
    {

        public IEnumerable<PcpOpCabecalhoModel> GetList()
        {
            IList<PcpOpCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpOpCabecalhoModel> DAL = new NHibernateDAL<PcpOpCabecalhoModel>(Session);
                Result = DAL.Select(new PcpOpCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<PcpOpCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<PcpOpCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PcpOpCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<PcpOpCabecalhoModel> DAL = new NHibernateDAL<PcpOpCabecalhoModel>(Session);
                Result = DAL.SelectListSql<PcpOpCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public PcpOpCabecalhoModel GetObject(int id)
        {
            PcpOpCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpOpCabecalhoModel> DAL = new NHibernateDAL<PcpOpCabecalhoModel>(Session);
                Result = DAL.SelectId<PcpOpCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PcpOpCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpOpCabecalhoModel> DAL = new NHibernateDAL<PcpOpCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PcpOpCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpOpCabecalhoModel> DAL = new NHibernateDAL<PcpOpCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PcpOpCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PcpOpCabecalhoModel> DAL = new NHibernateDAL<PcpOpCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}