namespace pcp.Models
{
	public class PcpOpDetalheModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeProduzir { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeProduzida { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeEntregue { get; set; } 

		public System.Nullable<System.Decimal> CustoPrevisto { get; set; } 

		public System.Nullable<System.Decimal> CustoRealizado { get; set; } 

		public PcpOpCabecalhoModel? PcpOpCabecalhoModel { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
