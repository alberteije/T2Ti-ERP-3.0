namespace pcp.Models
{
	public class PcpServicoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> InicioRealizado { get; set; } 

		public System.Nullable<System.DateTime> TerminoRealizado { get; set; } 

		public int? HorasRealizado { get; set; } 

		public int? MinutosRealizado { get; set; } 

		public int? SegundosRealizado { get; set; } 

		public System.Nullable<System.Decimal> CustoRealizado { get; set; } 

		public System.Nullable<System.DateTime> InicioPrevisto { get; set; } 

		public System.Nullable<System.DateTime> TerminoPrevisto { get; set; } 

		public int? HorasPrevisto { get; set; } 

		public int? MinutosPrevisto { get; set; } 

		public int? SegundosPrevisto { get; set; } 

		public System.Nullable<System.Decimal> CustoPrevisto { get; set; } 

		public PcpOpDetalheModel? PcpOpDetalheModel { get; set; } 

		private IList<PcpServicoColaboradorModel>? pcpServicoColaboradorModelList; 
		public IList<PcpServicoColaboradorModel>? PcpServicoColaboradorModelList 
		{ 
			get 
			{ 
				return pcpServicoColaboradorModelList; 
			} 
			set 
			{ 
				pcpServicoColaboradorModelList = value; 
				foreach (PcpServicoColaboradorModel pcpServicoColaboradorModel in pcpServicoColaboradorModelList!) 
				{ 
					pcpServicoColaboradorModel.PcpServicoModel = this; 
				} 
			} 
		} 

		private IList<PcpServicoEquipamentoModel>? pcpServicoEquipamentoModelList; 
		public IList<PcpServicoEquipamentoModel>? PcpServicoEquipamentoModelList 
		{ 
			get 
			{ 
				return pcpServicoEquipamentoModelList; 
			} 
			set 
			{ 
				pcpServicoEquipamentoModelList = value; 
				foreach (PcpServicoEquipamentoModel pcpServicoEquipamentoModel in pcpServicoEquipamentoModelList!) 
				{ 
					pcpServicoEquipamentoModel.PcpServicoModel = this; 
				} 
			} 
		} 

	}
}
