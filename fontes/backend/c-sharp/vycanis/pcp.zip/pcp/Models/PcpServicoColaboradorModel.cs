namespace pcp.Models
{
	public class PcpServicoColaboradorModel
	{	
		public int? Id { get; set; } 

		public PcpServicoModel? PcpServicoModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
