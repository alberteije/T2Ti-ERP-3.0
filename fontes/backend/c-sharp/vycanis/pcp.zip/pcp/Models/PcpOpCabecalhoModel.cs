namespace pcp.Models
{
	public class PcpOpCabecalhoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataPrevisaoEntrega { get; set; } 

		public System.Nullable<System.DateTime> DataTermino { get; set; } 

		public System.Nullable<System.Decimal> CustoTotalPrevisto { get; set; } 

		public System.Nullable<System.Decimal> CustoTotalRealizado { get; set; } 

		public System.Nullable<System.Decimal> PorcentoVenda { get; set; } 

		public System.Nullable<System.Decimal> PorcentoEstoque { get; set; } 

		private IList<PcpOpDetalheModel>? pcpOpDetalheModelList; 
		public IList<PcpOpDetalheModel>? PcpOpDetalheModelList 
		{ 
			get 
			{ 
				return pcpOpDetalheModelList; 
			} 
			set 
			{ 
				pcpOpDetalheModelList = value; 
				foreach (PcpOpDetalheModel pcpOpDetalheModel in pcpOpDetalheModelList!) 
				{ 
					pcpOpDetalheModel.PcpOpCabecalhoModel = this; 
				} 
			} 
		} 

		private IList<PcpInstrucaoOpModel>? pcpInstrucaoOpModelList; 
		public IList<PcpInstrucaoOpModel>? PcpInstrucaoOpModelList 
		{ 
			get 
			{ 
				return pcpInstrucaoOpModelList; 
			} 
			set 
			{ 
				pcpInstrucaoOpModelList = value; 
				foreach (PcpInstrucaoOpModel pcpInstrucaoOpModel in pcpInstrucaoOpModelList!) 
				{ 
					pcpInstrucaoOpModel.PcpOpCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
