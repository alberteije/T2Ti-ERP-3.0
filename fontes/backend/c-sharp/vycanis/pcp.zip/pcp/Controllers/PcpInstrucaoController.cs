using Microsoft.AspNetCore.Mvc;
using pcp.Models;
using pcp.Services;

namespace pcp.Controllers
{
    [Route("pcp-instrucao")]
    [Produces("application/json")]
    public class PcpInstrucaoController : Controller
    {
		private readonly PcpInstrucaoService _service;

        public PcpInstrucaoController()
        {
            _service = new PcpInstrucaoService();
        }

        [HttpGet]
        public IActionResult GetListPcpInstrucao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PcpInstrucaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PcpInstrucao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPcpInstrucao")]
        public IActionResult GetObjectPcpInstrucao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PcpInstrucao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PcpInstrucao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPcpInstrucao([FromBody]PcpInstrucaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PcpInstrucao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPcpInstrucao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PcpInstrucao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePcpInstrucao([FromBody]PcpInstrucaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PcpInstrucao]", null));
                }

                _service.Update(objJson);

                return GetObjectPcpInstrucao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PcpInstrucao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePcpInstrucao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PcpInstrucao]", ex));
            }
        }

    }
}