using Microsoft.AspNetCore.Mvc;
using sped.Models;
using sped.Services;

namespace sped.Controllers
{
    [Route("sped-fiscal")]
    [Produces("application/json")]
    public class SpedFiscalController : Controller
    {
		private readonly SpedFiscalService _service;

        public SpedFiscalController()
        {
            _service = new SpedFiscalService();
        }

        [HttpGet]
        public IActionResult GetListSpedFiscal([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SpedFiscalModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList SpedFiscal]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSpedFiscal")]
        public IActionResult GetObjectSpedFiscal(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject SpedFiscal]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject SpedFiscal]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSpedFiscal([FromBody]SpedFiscalModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert SpedFiscal]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSpedFiscal", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert SpedFiscal]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSpedFiscal([FromBody]SpedFiscalModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update SpedFiscal]", null));
                }

                _service.Update(objJson);

                return GetObjectSpedFiscal(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update SpedFiscal]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSpedFiscal(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete SpedFiscal]", ex));
            }
        }

    }
}