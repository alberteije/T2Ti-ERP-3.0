using Microsoft.AspNetCore.Mvc;
using sped.Models;
using sped.Services;

namespace sped.Controllers
{
    [Route("sped-contabil")]
    [Produces("application/json")]
    public class SpedContabilController : Controller
    {
		private readonly SpedContabilService _service;

        public SpedContabilController()
        {
            _service = new SpedContabilService();
        }

        [HttpGet]
        public IActionResult GetListSpedContabil([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SpedContabilModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList SpedContabil]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSpedContabil")]
        public IActionResult GetObjectSpedContabil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject SpedContabil]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject SpedContabil]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSpedContabil([FromBody]SpedContabilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert SpedContabil]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSpedContabil", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert SpedContabil]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSpedContabil([FromBody]SpedContabilModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update SpedContabil]", null));
                }

                _service.Update(objJson);

                return GetObjectSpedContabil(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update SpedContabil]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSpedContabil(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete SpedContabil]", ex));
            }
        }

    }
}