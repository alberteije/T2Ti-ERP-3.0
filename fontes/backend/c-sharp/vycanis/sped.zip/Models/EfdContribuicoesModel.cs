namespace sped.Models
{
	public class EfdContribuicoesModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public System.Nullable<System.DateTime> PeriodoInicial { get; set; } 

		public System.Nullable<System.DateTime> PeriodoFinal { get; set; } 

		public string? FinalidadeArquivo { get; set; } 

	}
}
