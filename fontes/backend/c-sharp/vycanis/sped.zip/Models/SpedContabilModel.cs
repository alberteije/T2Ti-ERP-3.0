namespace sped.Models
{
	public class SpedContabilModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public System.Nullable<System.DateTime> PeriodoInicial { get; set; } 

		public System.Nullable<System.DateTime> PeriodoFinal { get; set; } 

		public string? FormaEscrituracao { get; set; } 

		public string? VersaoLayout { get; set; } 

	}
}
