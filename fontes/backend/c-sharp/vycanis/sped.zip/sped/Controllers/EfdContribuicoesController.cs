using Microsoft.AspNetCore.Mvc;
using sped.Models;
using sped.Services;

namespace sped.Controllers
{
    [Route("efd-contribuicoes")]
    [Produces("application/json")]
    public class EfdContribuicoesController : Controller
    {
		private readonly EfdContribuicoesService _service;

        public EfdContribuicoesController()
        {
            _service = new EfdContribuicoesService();
        }

        [HttpGet]
        public IActionResult GetListEfdContribuicoes([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EfdContribuicoesModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EfdContribuicoes]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEfdContribuicoes")]
        public IActionResult GetObjectEfdContribuicoes(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EfdContribuicoes]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EfdContribuicoes]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEfdContribuicoes([FromBody]EfdContribuicoesModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EfdContribuicoes]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEfdContribuicoes", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EfdContribuicoes]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEfdContribuicoes([FromBody]EfdContribuicoesModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EfdContribuicoes]", null));
                }

                _service.Update(objJson);

                return GetObjectEfdContribuicoes(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EfdContribuicoes]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEfdContribuicoes(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EfdContribuicoes]", ex));
            }
        }

    }
}