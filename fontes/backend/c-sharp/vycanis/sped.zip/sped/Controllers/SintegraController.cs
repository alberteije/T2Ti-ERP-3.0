using Microsoft.AspNetCore.Mvc;
using sped.Models;
using sped.Services;

namespace sped.Controllers
{
    [Route("sintegra")]
    [Produces("application/json")]
    public class SintegraController : Controller
    {
		private readonly SintegraService _service;

        public SintegraController()
        {
            _service = new SintegraService();
        }

        [HttpGet]
        public IActionResult GetListSintegra([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SintegraModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Sintegra]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSintegra")]
        public IActionResult GetObjectSintegra(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Sintegra]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Sintegra]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSintegra([FromBody]SintegraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Sintegra]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSintegra", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Sintegra]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSintegra([FromBody]SintegraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Sintegra]", null));
                }

                _service.Update(objJson);

                return GetObjectSintegra(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Sintegra]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSintegra(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Sintegra]", ex));
            }
        }

    }
}