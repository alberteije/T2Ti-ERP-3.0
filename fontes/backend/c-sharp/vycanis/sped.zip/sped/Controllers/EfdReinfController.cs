using Microsoft.AspNetCore.Mvc;
using sped.Models;
using sped.Services;

namespace sped.Controllers
{
    [Route("efd-reinf")]
    [Produces("application/json")]
    public class EfdReinfController : Controller
    {
		private readonly EfdReinfService _service;

        public EfdReinfController()
        {
            _service = new EfdReinfService();
        }

        [HttpGet]
        public IActionResult GetListEfdReinf([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EfdReinfModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EfdReinf]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEfdReinf")]
        public IActionResult GetObjectEfdReinf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EfdReinf]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EfdReinf]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEfdReinf([FromBody]EfdReinfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EfdReinf]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEfdReinf", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EfdReinf]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEfdReinf([FromBody]EfdReinfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EfdReinf]", null));
                }

                _service.Update(objJson);

                return GetObjectEfdReinf(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EfdReinf]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEfdReinf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EfdReinf]", ex));
            }
        }

    }
}