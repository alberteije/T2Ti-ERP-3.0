using sped.Models;
using sped.NHibernate;
using ISession = NHibernate.ISession;

namespace sped.Services
{
    public class EfdReinfService
    {

        public IEnumerable<EfdReinfModel> GetList()
        {
            IList<EfdReinfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdReinfModel> DAL = new NHibernateDAL<EfdReinfModel>(Session);
                Result = DAL.Select(new EfdReinfModel());
            }
            return Result;
        }

        public IEnumerable<EfdReinfModel> GetListFilter(Filter filterObj)
        {
            IList<EfdReinfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EfdReinfModel where " + filterObj.Where;
                NHibernateDAL<EfdReinfModel> DAL = new NHibernateDAL<EfdReinfModel>(Session);
                Result = DAL.SelectListSql<EfdReinfModel>(Query);
            }
            return Result;
        }
		
        public EfdReinfModel GetObject(int id)
        {
            EfdReinfModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdReinfModel> DAL = new NHibernateDAL<EfdReinfModel>(Session);
                Result = DAL.SelectId<EfdReinfModel>(id);
            }
            return Result;
        }
		
        public void Insert(EfdReinfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdReinfModel> DAL = new NHibernateDAL<EfdReinfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EfdReinfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdReinfModel> DAL = new NHibernateDAL<EfdReinfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EfdReinfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdReinfModel> DAL = new NHibernateDAL<EfdReinfModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}