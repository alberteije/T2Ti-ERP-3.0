using sped.Models;
using sped.NHibernate;
using ISession = NHibernate.ISession;

namespace sped.Services
{
    public class SpedContabilService
    {

        public IEnumerable<SpedContabilModel> GetList()
        {
            IList<SpedContabilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedContabilModel> DAL = new NHibernateDAL<SpedContabilModel>(Session);
                Result = DAL.Select(new SpedContabilModel());
            }
            return Result;
        }

        public IEnumerable<SpedContabilModel> GetListFilter(Filter filterObj)
        {
            IList<SpedContabilModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SpedContabilModel where " + filterObj.Where;
                NHibernateDAL<SpedContabilModel> DAL = new NHibernateDAL<SpedContabilModel>(Session);
                Result = DAL.SelectListSql<SpedContabilModel>(Query);
            }
            return Result;
        }
		
        public SpedContabilModel GetObject(int id)
        {
            SpedContabilModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedContabilModel> DAL = new NHibernateDAL<SpedContabilModel>(Session);
                Result = DAL.SelectId<SpedContabilModel>(id);
            }
            return Result;
        }
		
        public void Insert(SpedContabilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedContabilModel> DAL = new NHibernateDAL<SpedContabilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SpedContabilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedContabilModel> DAL = new NHibernateDAL<SpedContabilModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SpedContabilModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedContabilModel> DAL = new NHibernateDAL<SpedContabilModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}