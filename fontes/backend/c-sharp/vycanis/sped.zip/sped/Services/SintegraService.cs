using sped.Models;
using sped.NHibernate;
using ISession = NHibernate.ISession;

namespace sped.Services
{
    public class SintegraService
    {

        public IEnumerable<SintegraModel> GetList()
        {
            IList<SintegraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SintegraModel> DAL = new NHibernateDAL<SintegraModel>(Session);
                Result = DAL.Select(new SintegraModel());
            }
            return Result;
        }

        public IEnumerable<SintegraModel> GetListFilter(Filter filterObj)
        {
            IList<SintegraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SintegraModel where " + filterObj.Where;
                NHibernateDAL<SintegraModel> DAL = new NHibernateDAL<SintegraModel>(Session);
                Result = DAL.SelectListSql<SintegraModel>(Query);
            }
            return Result;
        }
		
        public SintegraModel GetObject(int id)
        {
            SintegraModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SintegraModel> DAL = new NHibernateDAL<SintegraModel>(Session);
                Result = DAL.SelectId<SintegraModel>(id);
            }
            return Result;
        }
		
        public void Insert(SintegraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SintegraModel> DAL = new NHibernateDAL<SintegraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SintegraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SintegraModel> DAL = new NHibernateDAL<SintegraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SintegraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SintegraModel> DAL = new NHibernateDAL<SintegraModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}