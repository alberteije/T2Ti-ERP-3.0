using sped.Models;
using sped.NHibernate;
using ISession = NHibernate.ISession;

namespace sped.Services
{
    public class SpedFiscalService
    {

        public IEnumerable<SpedFiscalModel> GetList()
        {
            IList<SpedFiscalModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedFiscalModel> DAL = new NHibernateDAL<SpedFiscalModel>(Session);
                Result = DAL.Select(new SpedFiscalModel());
            }
            return Result;
        }

        public IEnumerable<SpedFiscalModel> GetListFilter(Filter filterObj)
        {
            IList<SpedFiscalModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SpedFiscalModel where " + filterObj.Where;
                NHibernateDAL<SpedFiscalModel> DAL = new NHibernateDAL<SpedFiscalModel>(Session);
                Result = DAL.SelectListSql<SpedFiscalModel>(Query);
            }
            return Result;
        }
		
        public SpedFiscalModel GetObject(int id)
        {
            SpedFiscalModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedFiscalModel> DAL = new NHibernateDAL<SpedFiscalModel>(Session);
                Result = DAL.SelectId<SpedFiscalModel>(id);
            }
            return Result;
        }
		
        public void Insert(SpedFiscalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedFiscalModel> DAL = new NHibernateDAL<SpedFiscalModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SpedFiscalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedFiscalModel> DAL = new NHibernateDAL<SpedFiscalModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SpedFiscalModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SpedFiscalModel> DAL = new NHibernateDAL<SpedFiscalModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}