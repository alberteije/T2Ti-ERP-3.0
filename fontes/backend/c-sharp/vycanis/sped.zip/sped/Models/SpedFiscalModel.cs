namespace sped.Models
{
	public class SpedFiscalModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataEmissao { get; set; } 

		public System.Nullable<System.DateTime> PeriodoInicial { get; set; } 

		public System.Nullable<System.DateTime> PeriodoFinal { get; set; } 

		public string? PerfilApresentacao { get; set; } 

		public string? FinalidadeArquivo { get; set; } 

		public string? VersaoLayout { get; set; } 

	}
}
