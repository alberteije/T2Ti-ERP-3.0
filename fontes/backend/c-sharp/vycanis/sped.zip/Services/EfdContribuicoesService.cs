using sped.Models;
using sped.NHibernate;
using ISession = NHibernate.ISession;

namespace sped.Services
{
    public class EfdContribuicoesService
    {

        public IEnumerable<EfdContribuicoesModel> GetList()
        {
            IList<EfdContribuicoesModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdContribuicoesModel> DAL = new NHibernateDAL<EfdContribuicoesModel>(Session);
                Result = DAL.Select(new EfdContribuicoesModel());
            }
            return Result;
        }

        public IEnumerable<EfdContribuicoesModel> GetListFilter(Filter filterObj)
        {
            IList<EfdContribuicoesModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EfdContribuicoesModel where " + filterObj.Where;
                NHibernateDAL<EfdContribuicoesModel> DAL = new NHibernateDAL<EfdContribuicoesModel>(Session);
                Result = DAL.SelectListSql<EfdContribuicoesModel>(Query);
            }
            return Result;
        }
		
        public EfdContribuicoesModel GetObject(int id)
        {
            EfdContribuicoesModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdContribuicoesModel> DAL = new NHibernateDAL<EfdContribuicoesModel>(Session);
                Result = DAL.SelectId<EfdContribuicoesModel>(id);
            }
            return Result;
        }
		
        public void Insert(EfdContribuicoesModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdContribuicoesModel> DAL = new NHibernateDAL<EfdContribuicoesModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EfdContribuicoesModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdContribuicoesModel> DAL = new NHibernateDAL<EfdContribuicoesModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EfdContribuicoesModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EfdContribuicoesModel> DAL = new NHibernateDAL<EfdContribuicoesModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}