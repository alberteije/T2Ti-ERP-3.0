namespace loja_virtual.Utils
{

    public static class Constants
    {
        public static int MAX_ROWS = 50;
    }
}
