﻿using NHibernate;
using NHibernate.Cfg;

namespace loja_virtual.NHibernate
{
    public class NHibernateHelper
    {
        private static ISessionFactory? SessionFactory;

        public static ISessionFactory GetSessionFactory()
        {
            try
            {
                if (SessionFactory == null)
                {
                    lock(typeof (NHibernateHelper))
                    {
                        Configuration config = new Configuration();
                        config.Configure();
                        config.AddAssembly("loja_virtual");
                        SessionFactory = config.BuildSessionFactory();
                    }
                }
                return SessionFactory;
            }
            catch
            {
                throw;
            }
        }
    }
}
