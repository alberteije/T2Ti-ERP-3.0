namespace loja_virtual.Models
{
	public class ViewPessoaTransportadoraModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Tipo { get; set; } 

		public string? Email { get; set; } 

		public string? Site { get; set; } 

		public string? CpfCnpj { get; set; } 

		public string? RgIe { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public string? Observacao { get; set; } 

		public int? IdPessoa { get; set; } 

	}
}
