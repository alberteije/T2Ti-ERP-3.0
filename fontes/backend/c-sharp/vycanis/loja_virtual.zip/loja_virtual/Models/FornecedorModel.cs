namespace loja_virtual.Models
{
	public class FornecedorModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> Desde { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public string? Observacao { get; set; } 

		public string? OptanteSimplesNacional { get; set; } 

		public string? PermiteReterPagamento { get; set; } 

		public int? PrazoMedioEntrega { get; set; } 

		public string? ForneceAPrazo { get; set; } 

		public int? NumDiasPrimeiroVencimento { get; set; } 

		public int? NumDiasIntervalo { get; set; } 

		public int? QuantidadeParcelas { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
