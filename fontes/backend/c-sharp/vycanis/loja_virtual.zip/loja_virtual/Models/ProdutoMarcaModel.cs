namespace loja_virtual.Models
{
	public class ProdutoMarcaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

	}
}
