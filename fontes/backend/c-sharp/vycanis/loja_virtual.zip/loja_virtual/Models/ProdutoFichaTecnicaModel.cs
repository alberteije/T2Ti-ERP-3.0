namespace loja_virtual.Models
{
	public class ProdutoFichaTecnicaModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public int? IdProdutoFilho { get; set; } 

		public System.Nullable<System.Decimal> Quantidade { get; set; } 

		public System.Nullable<System.Decimal> ValorCusto { get; set; } 

		public System.Nullable<System.Decimal> PercentualCusto { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
