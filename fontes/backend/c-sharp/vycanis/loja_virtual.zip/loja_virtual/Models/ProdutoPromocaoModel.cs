namespace loja_virtual.Models
{
	public class ProdutoPromocaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeEmPromocao { get; set; } 

		public System.Nullable<System.Decimal> QuantidadeMaximaCliente { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public ProdutoModel? ProdutoModel { get; set; } 

	}
}
