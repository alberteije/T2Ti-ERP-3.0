namespace loja_virtual.Models
{
	public class PessoaContatoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Email { get; set; } 

		public string? Observacao { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
