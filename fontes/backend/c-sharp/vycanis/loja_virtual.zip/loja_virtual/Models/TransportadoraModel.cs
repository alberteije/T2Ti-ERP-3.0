namespace loja_virtual.Models
{
	public class TransportadoraModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public string? Observacao { get; set; } 

		public PessoaModel? PessoaModel { get; set; } 

	}
}
