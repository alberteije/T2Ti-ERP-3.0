namespace loja_virtual.Models
{
	public class FinDocumentoOrigemModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Sigla { get; set; } 

		public string? Descricao { get; set; } 

	}
}
