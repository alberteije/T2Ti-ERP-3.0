namespace loja_virtual.Models
{
	public class NivelFormacaoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

	}
}
