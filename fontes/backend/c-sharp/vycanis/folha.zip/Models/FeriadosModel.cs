namespace folha.Models
{
	public class FeriadosModel
	{	
		public int? Id { get; set; } 

		public string? Ano { get; set; } 

		public string? Nome { get; set; } 

		public string? Abrangencia { get; set; } 

		public string? Uf { get; set; } 

		public int? MunicipioIbge { get; set; } 

		public string? Tipo { get; set; } 

		public System.Nullable<System.DateTime> DataFeriado { get; set; } 

	}
}
