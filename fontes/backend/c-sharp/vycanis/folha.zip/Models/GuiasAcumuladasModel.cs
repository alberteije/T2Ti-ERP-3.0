namespace folha.Models
{
	public class GuiasAcumuladasModel
	{	
		public int? Id { get; set; } 

		public string? GpsTipo { get; set; } 

		public string? GpsCompetencia { get; set; } 

		public System.Nullable<System.Decimal> GpsValorInss { get; set; } 

		public System.Nullable<System.Decimal> GpsValorOutrasEnt { get; set; } 

		public System.Nullable<System.DateTime> GpsDataPagamento { get; set; } 

		public string? IrrfCompetencia { get; set; } 

		public int? IrrfCodigoRecolhimento { get; set; } 

		public System.Nullable<System.Decimal> IrrfValorAcumulado { get; set; } 

		public System.Nullable<System.DateTime> IrrfDataPagamento { get; set; } 

		public string? PisCompetencia { get; set; } 

		public System.Nullable<System.Decimal> PisValorAcumulado { get; set; } 

		public System.Nullable<System.DateTime> PisDataPagamento { get; set; } 

	}
}
