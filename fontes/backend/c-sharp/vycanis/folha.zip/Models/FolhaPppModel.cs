namespace folha.Models
{
	public class FolhaPppModel
	{	
		public int? Id { get; set; } 

		public string? Observacao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<FolhaPppCatModel>? folhaPppCatModelList; 
		public IList<FolhaPppCatModel>? FolhaPppCatModelList 
		{ 
			get 
			{ 
				return folhaPppCatModelList; 
			} 
			set 
			{ 
				folhaPppCatModelList = value; 
				foreach (FolhaPppCatModel folhaPppCatModel in folhaPppCatModelList!) 
				{ 
					folhaPppCatModel.FolhaPppModel = this; 
				} 
			} 
		} 

		private IList<FolhaPppAtividadeModel>? folhaPppAtividadeModelList; 
		public IList<FolhaPppAtividadeModel>? FolhaPppAtividadeModelList 
		{ 
			get 
			{ 
				return folhaPppAtividadeModelList; 
			} 
			set 
			{ 
				folhaPppAtividadeModelList = value; 
				foreach (FolhaPppAtividadeModel folhaPppAtividadeModel in folhaPppAtividadeModelList!) 
				{ 
					folhaPppAtividadeModel.FolhaPppModel = this; 
				} 
			} 
		} 

		private IList<FolhaPppFatorRiscoModel>? folhaPppFatorRiscoModelList; 
		public IList<FolhaPppFatorRiscoModel>? FolhaPppFatorRiscoModelList 
		{ 
			get 
			{ 
				return folhaPppFatorRiscoModelList; 
			} 
			set 
			{ 
				folhaPppFatorRiscoModelList = value; 
				foreach (FolhaPppFatorRiscoModel folhaPppFatorRiscoModel in folhaPppFatorRiscoModelList!) 
				{ 
					folhaPppFatorRiscoModel.FolhaPppModel = this; 
				} 
			} 
		} 

		private IList<FolhaPppExameMedicoModel>? folhaPppExameMedicoModelList; 
		public IList<FolhaPppExameMedicoModel>? FolhaPppExameMedicoModelList 
		{ 
			get 
			{ 
				return folhaPppExameMedicoModelList; 
			} 
			set 
			{ 
				folhaPppExameMedicoModelList = value; 
				foreach (FolhaPppExameMedicoModel folhaPppExameMedicoModel in folhaPppExameMedicoModelList!) 
				{ 
					folhaPppExameMedicoModel.FolhaPppModel = this; 
				} 
			} 
		} 

	}
}
