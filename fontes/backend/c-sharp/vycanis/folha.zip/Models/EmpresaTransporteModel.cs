namespace folha.Models
{
	public class EmpresaTransporteModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Uf { get; set; } 

		public string? ClassificacaoContabilConta { get; set; } 

		private IList<EmpresaTransporteItinerarioModel>? empresaTransporteItinerarioModelList; 
		public IList<EmpresaTransporteItinerarioModel>? EmpresaTransporteItinerarioModelList 
		{ 
			get 
			{ 
				return empresaTransporteItinerarioModelList; 
			} 
			set 
			{ 
				empresaTransporteItinerarioModelList = value; 
				foreach (EmpresaTransporteItinerarioModel empresaTransporteItinerarioModel in empresaTransporteItinerarioModelList!) 
				{ 
					empresaTransporteItinerarioModel.EmpresaTransporteModel = this; 
				} 
			} 
		} 

	}
}
