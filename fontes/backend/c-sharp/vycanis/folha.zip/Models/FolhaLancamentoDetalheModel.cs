namespace folha.Models
{
	public class FolhaLancamentoDetalheModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Origem { get; set; } 

		public System.Nullable<System.Decimal> Provento { get; set; } 

		public System.Nullable<System.Decimal> Desconto { get; set; } 

		public FolhaLancamentoCabecalhoModel? FolhaLancamentoCabecalhoModel { get; set; } 

		public FolhaEventoModel? FolhaEventoModel { get; set; } 

	}
}
