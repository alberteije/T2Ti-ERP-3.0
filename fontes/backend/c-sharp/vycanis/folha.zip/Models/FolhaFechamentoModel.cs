namespace folha.Models
{
	public class FolhaFechamentoModel
	{	
		public int? Id { get; set; } 

		public string? FechamentoAtual { get; set; } 

		public string? ProximoFechamento { get; set; } 

	}
}
