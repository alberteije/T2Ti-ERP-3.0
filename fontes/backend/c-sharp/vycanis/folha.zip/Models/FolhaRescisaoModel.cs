namespace folha.Models
{
	public class FolhaRescisaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataDemissao { get; set; } 

		public System.Nullable<System.DateTime> DataPagamento { get; set; } 

		public string? Motivo { get; set; } 

		public string? MotivoEsocial { get; set; } 

		public System.Nullable<System.DateTime> DataAvisoPrevio { get; set; } 

		public int? DiasAvisoPrevio { get; set; } 

		public string? ComprovouNovoEmprego { get; set; } 

		public string? DispensouEmpregado { get; set; } 

		public System.Nullable<System.Decimal> PensaoAlimenticia { get; set; } 

		public System.Nullable<System.Decimal> PensaoAlimenticiaFgts { get; set; } 

		public System.Nullable<System.Decimal> FgtsValorRescisao { get; set; } 

		public System.Nullable<System.Decimal> FgtsSaldoBanco { get; set; } 

		public System.Nullable<System.Decimal> FgtsComplementoSaldo { get; set; } 

		public string? FgtsCodigoAfastamento { get; set; } 

		public string? FgtsCodigoSaque { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
