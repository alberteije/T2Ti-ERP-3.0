namespace folha.Models
{
	public class FolhaLancamentoCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public string? Tipo { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<FolhaLancamentoDetalheModel>? folhaLancamentoDetalheModelList; 
		public IList<FolhaLancamentoDetalheModel>? FolhaLancamentoDetalheModelList 
		{ 
			get 
			{ 
				return folhaLancamentoDetalheModelList; 
			} 
			set 
			{ 
				folhaLancamentoDetalheModelList = value; 
				foreach (FolhaLancamentoDetalheModel folhaLancamentoDetalheModel in folhaLancamentoDetalheModelList!) 
				{ 
					folhaLancamentoDetalheModel.FolhaLancamentoCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
