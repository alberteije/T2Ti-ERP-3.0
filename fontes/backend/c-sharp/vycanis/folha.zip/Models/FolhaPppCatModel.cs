namespace folha.Models
{
	public class FolhaPppCatModel
	{	
		public int? Id { get; set; } 

		public int? NumeroCat { get; set; } 

		public System.Nullable<System.DateTime> DataAfastamento { get; set; } 

		public System.Nullable<System.DateTime> DataRegistro { get; set; } 

		public FolhaPppModel? FolhaPppModel { get; set; } 

	}
}
