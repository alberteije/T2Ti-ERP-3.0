namespace folha.Models
{
	public class OperadoraPlanoSaudeModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? RegistroAns { get; set; } 

		public string? ClassificacaoContabilConta { get; set; } 

	}
}
