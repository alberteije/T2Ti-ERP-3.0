namespace folha.Models
{
	public class FolhaAfastamentoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public int? DiasAfastado { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public FolhaTipoAfastamentoModel? FolhaTipoAfastamentoModel { get; set; } 

	}
}
