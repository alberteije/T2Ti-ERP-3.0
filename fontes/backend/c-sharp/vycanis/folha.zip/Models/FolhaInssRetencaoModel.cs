namespace folha.Models
{
	public class FolhaInssRetencaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> ValorMensal { get; set; } 

		public System.Nullable<System.Decimal> Valor13 { get; set; } 

		public FolhaInssModel? FolhaInssModel { get; set; } 

		public FolhaInssServicoModel? FolhaInssServicoModel { get; set; } 

	}
}
