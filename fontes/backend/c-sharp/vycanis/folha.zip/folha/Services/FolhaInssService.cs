using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaInssService
    {

        public IEnumerable<FolhaInssModel> GetList()
        {
            IList<FolhaInssModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssModel> DAL = new NHibernateDAL<FolhaInssModel>(Session);
                Result = DAL.Select(new FolhaInssModel());
            }
            return Result;
        }

        public IEnumerable<FolhaInssModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaInssModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaInssModel where " + filterObj.Where;
                NHibernateDAL<FolhaInssModel> DAL = new NHibernateDAL<FolhaInssModel>(Session);
                Result = DAL.SelectListSql<FolhaInssModel>(Query);
            }
            return Result;
        }
		
        public FolhaInssModel GetObject(int id)
        {
            FolhaInssModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssModel> DAL = new NHibernateDAL<FolhaInssModel>(Session);
                Result = DAL.SelectId<FolhaInssModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaInssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssModel> DAL = new NHibernateDAL<FolhaInssModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaInssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssModel> DAL = new NHibernateDAL<FolhaInssModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaInssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssModel> DAL = new NHibernateDAL<FolhaInssModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}