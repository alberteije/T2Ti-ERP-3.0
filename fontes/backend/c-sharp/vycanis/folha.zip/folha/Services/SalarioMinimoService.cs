using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class SalarioMinimoService
    {

        public IEnumerable<SalarioMinimoModel> GetList()
        {
            IList<SalarioMinimoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SalarioMinimoModel> DAL = new NHibernateDAL<SalarioMinimoModel>(Session);
                Result = DAL.Select(new SalarioMinimoModel());
            }
            return Result;
        }

        public IEnumerable<SalarioMinimoModel> GetListFilter(Filter filterObj)
        {
            IList<SalarioMinimoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SalarioMinimoModel where " + filterObj.Where;
                NHibernateDAL<SalarioMinimoModel> DAL = new NHibernateDAL<SalarioMinimoModel>(Session);
                Result = DAL.SelectListSql<SalarioMinimoModel>(Query);
            }
            return Result;
        }
		
        public SalarioMinimoModel GetObject(int id)
        {
            SalarioMinimoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SalarioMinimoModel> DAL = new NHibernateDAL<SalarioMinimoModel>(Session);
                Result = DAL.SelectId<SalarioMinimoModel>(id);
            }
            return Result;
        }
		
        public void Insert(SalarioMinimoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SalarioMinimoModel> DAL = new NHibernateDAL<SalarioMinimoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SalarioMinimoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SalarioMinimoModel> DAL = new NHibernateDAL<SalarioMinimoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SalarioMinimoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SalarioMinimoModel> DAL = new NHibernateDAL<SalarioMinimoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}