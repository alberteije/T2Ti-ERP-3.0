using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaParametroService
    {

        public IEnumerable<FolhaParametroModel> GetList()
        {
            IList<FolhaParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaParametroModel> DAL = new NHibernateDAL<FolhaParametroModel>(Session);
                Result = DAL.Select(new FolhaParametroModel());
            }
            return Result;
        }

        public IEnumerable<FolhaParametroModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaParametroModel where " + filterObj.Where;
                NHibernateDAL<FolhaParametroModel> DAL = new NHibernateDAL<FolhaParametroModel>(Session);
                Result = DAL.SelectListSql<FolhaParametroModel>(Query);
            }
            return Result;
        }
		
        public FolhaParametroModel GetObject(int id)
        {
            FolhaParametroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaParametroModel> DAL = new NHibernateDAL<FolhaParametroModel>(Session);
                Result = DAL.SelectId<FolhaParametroModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaParametroModel> DAL = new NHibernateDAL<FolhaParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaParametroModel> DAL = new NHibernateDAL<FolhaParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaParametroModel> DAL = new NHibernateDAL<FolhaParametroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}