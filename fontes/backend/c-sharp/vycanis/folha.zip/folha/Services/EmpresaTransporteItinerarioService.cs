using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class EmpresaTransporteItinerarioService
    {

        public IEnumerable<EmpresaTransporteItinerarioModel> GetList()
        {
            IList<EmpresaTransporteItinerarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteItinerarioModel> DAL = new NHibernateDAL<EmpresaTransporteItinerarioModel>(Session);
                Result = DAL.Select(new EmpresaTransporteItinerarioModel());
            }
            return Result;
        }

        public IEnumerable<EmpresaTransporteItinerarioModel> GetListFilter(Filter filterObj)
        {
            IList<EmpresaTransporteItinerarioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EmpresaTransporteItinerarioModel where " + filterObj.Where;
                NHibernateDAL<EmpresaTransporteItinerarioModel> DAL = new NHibernateDAL<EmpresaTransporteItinerarioModel>(Session);
                Result = DAL.SelectListSql<EmpresaTransporteItinerarioModel>(Query);
            }
            return Result;
        }
		
        public EmpresaTransporteItinerarioModel GetObject(int id)
        {
            EmpresaTransporteItinerarioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteItinerarioModel> DAL = new NHibernateDAL<EmpresaTransporteItinerarioModel>(Session);
                Result = DAL.SelectId<EmpresaTransporteItinerarioModel>(id);
            }
            return Result;
        }
		
        public void Insert(EmpresaTransporteItinerarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteItinerarioModel> DAL = new NHibernateDAL<EmpresaTransporteItinerarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EmpresaTransporteItinerarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteItinerarioModel> DAL = new NHibernateDAL<EmpresaTransporteItinerarioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EmpresaTransporteItinerarioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteItinerarioModel> DAL = new NHibernateDAL<EmpresaTransporteItinerarioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}