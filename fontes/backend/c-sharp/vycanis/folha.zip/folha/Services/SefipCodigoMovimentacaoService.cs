using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class SefipCodigoMovimentacaoService
    {

        public IEnumerable<SefipCodigoMovimentacaoModel> GetList()
        {
            IList<SefipCodigoMovimentacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoMovimentacaoModel> DAL = new NHibernateDAL<SefipCodigoMovimentacaoModel>(Session);
                Result = DAL.Select(new SefipCodigoMovimentacaoModel());
            }
            return Result;
        }

        public IEnumerable<SefipCodigoMovimentacaoModel> GetListFilter(Filter filterObj)
        {
            IList<SefipCodigoMovimentacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SefipCodigoMovimentacaoModel where " + filterObj.Where;
                NHibernateDAL<SefipCodigoMovimentacaoModel> DAL = new NHibernateDAL<SefipCodigoMovimentacaoModel>(Session);
                Result = DAL.SelectListSql<SefipCodigoMovimentacaoModel>(Query);
            }
            return Result;
        }
		
        public SefipCodigoMovimentacaoModel GetObject(int id)
        {
            SefipCodigoMovimentacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoMovimentacaoModel> DAL = new NHibernateDAL<SefipCodigoMovimentacaoModel>(Session);
                Result = DAL.SelectId<SefipCodigoMovimentacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(SefipCodigoMovimentacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoMovimentacaoModel> DAL = new NHibernateDAL<SefipCodigoMovimentacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SefipCodigoMovimentacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoMovimentacaoModel> DAL = new NHibernateDAL<SefipCodigoMovimentacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SefipCodigoMovimentacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoMovimentacaoModel> DAL = new NHibernateDAL<SefipCodigoMovimentacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}