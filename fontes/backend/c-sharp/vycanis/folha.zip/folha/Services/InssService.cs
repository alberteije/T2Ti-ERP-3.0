using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class InssService
    {

        public IEnumerable<InssModel> GetList()
        {
            IList<InssModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InssModel> DAL = new NHibernateDAL<InssModel>(Session);
                Result = DAL.Select(new InssModel());
            }
            return Result;
        }

        public IEnumerable<InssModel> GetListFilter(Filter filterObj)
        {
            IList<InssModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from InssModel where " + filterObj.Where;
                NHibernateDAL<InssModel> DAL = new NHibernateDAL<InssModel>(Session);
                Result = DAL.SelectListSql<InssModel>(Query);
            }
            return Result;
        }
		
        public InssModel GetObject(int id)
        {
            InssModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InssModel> DAL = new NHibernateDAL<InssModel>(Session);
                Result = DAL.SelectId<InssModel>(id);
            }
            return Result;
        }
		
        public void Insert(InssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InssModel> DAL = new NHibernateDAL<InssModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(InssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InssModel> DAL = new NHibernateDAL<InssModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(InssModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<InssModel> DAL = new NHibernateDAL<InssModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}