using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class SefipCodigoRecolhimentoService
    {

        public IEnumerable<SefipCodigoRecolhimentoModel> GetList()
        {
            IList<SefipCodigoRecolhimentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoRecolhimentoModel> DAL = new NHibernateDAL<SefipCodigoRecolhimentoModel>(Session);
                Result = DAL.Select(new SefipCodigoRecolhimentoModel());
            }
            return Result;
        }

        public IEnumerable<SefipCodigoRecolhimentoModel> GetListFilter(Filter filterObj)
        {
            IList<SefipCodigoRecolhimentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SefipCodigoRecolhimentoModel where " + filterObj.Where;
                NHibernateDAL<SefipCodigoRecolhimentoModel> DAL = new NHibernateDAL<SefipCodigoRecolhimentoModel>(Session);
                Result = DAL.SelectListSql<SefipCodigoRecolhimentoModel>(Query);
            }
            return Result;
        }
		
        public SefipCodigoRecolhimentoModel GetObject(int id)
        {
            SefipCodigoRecolhimentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoRecolhimentoModel> DAL = new NHibernateDAL<SefipCodigoRecolhimentoModel>(Session);
                Result = DAL.SelectId<SefipCodigoRecolhimentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(SefipCodigoRecolhimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoRecolhimentoModel> DAL = new NHibernateDAL<SefipCodigoRecolhimentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SefipCodigoRecolhimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoRecolhimentoModel> DAL = new NHibernateDAL<SefipCodigoRecolhimentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SefipCodigoRecolhimentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCodigoRecolhimentoModel> DAL = new NHibernateDAL<SefipCodigoRecolhimentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}