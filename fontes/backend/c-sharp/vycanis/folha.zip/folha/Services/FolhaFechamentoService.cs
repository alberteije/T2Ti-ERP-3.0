using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaFechamentoService
    {

        public IEnumerable<FolhaFechamentoModel> GetList()
        {
            IList<FolhaFechamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFechamentoModel> DAL = new NHibernateDAL<FolhaFechamentoModel>(Session);
                Result = DAL.Select(new FolhaFechamentoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaFechamentoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaFechamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaFechamentoModel where " + filterObj.Where;
                NHibernateDAL<FolhaFechamentoModel> DAL = new NHibernateDAL<FolhaFechamentoModel>(Session);
                Result = DAL.SelectListSql<FolhaFechamentoModel>(Query);
            }
            return Result;
        }
		
        public FolhaFechamentoModel GetObject(int id)
        {
            FolhaFechamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFechamentoModel> DAL = new NHibernateDAL<FolhaFechamentoModel>(Session);
                Result = DAL.SelectId<FolhaFechamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaFechamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFechamentoModel> DAL = new NHibernateDAL<FolhaFechamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaFechamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFechamentoModel> DAL = new NHibernateDAL<FolhaFechamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaFechamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFechamentoModel> DAL = new NHibernateDAL<FolhaFechamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}