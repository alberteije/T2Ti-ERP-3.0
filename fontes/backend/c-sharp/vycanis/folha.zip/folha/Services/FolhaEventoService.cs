using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaEventoService
    {

        public IEnumerable<FolhaEventoModel> GetList()
        {
            IList<FolhaEventoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaEventoModel> DAL = new NHibernateDAL<FolhaEventoModel>(Session);
                Result = DAL.Select(new FolhaEventoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaEventoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaEventoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaEventoModel where " + filterObj.Where;
                NHibernateDAL<FolhaEventoModel> DAL = new NHibernateDAL<FolhaEventoModel>(Session);
                Result = DAL.SelectListSql<FolhaEventoModel>(Query);
            }
            return Result;
        }
		
        public FolhaEventoModel GetObject(int id)
        {
            FolhaEventoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaEventoModel> DAL = new NHibernateDAL<FolhaEventoModel>(Session);
                Result = DAL.SelectId<FolhaEventoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaEventoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaEventoModel> DAL = new NHibernateDAL<FolhaEventoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaEventoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaEventoModel> DAL = new NHibernateDAL<FolhaEventoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaEventoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaEventoModel> DAL = new NHibernateDAL<FolhaEventoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}