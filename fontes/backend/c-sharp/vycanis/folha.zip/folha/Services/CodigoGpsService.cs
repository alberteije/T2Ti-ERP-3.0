using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class CodigoGpsService
    {

        public IEnumerable<CodigoGpsModel> GetList()
        {
            IList<CodigoGpsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CodigoGpsModel> DAL = new NHibernateDAL<CodigoGpsModel>(Session);
                Result = DAL.Select(new CodigoGpsModel());
            }
            return Result;
        }

        public IEnumerable<CodigoGpsModel> GetListFilter(Filter filterObj)
        {
            IList<CodigoGpsModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CodigoGpsModel where " + filterObj.Where;
                NHibernateDAL<CodigoGpsModel> DAL = new NHibernateDAL<CodigoGpsModel>(Session);
                Result = DAL.SelectListSql<CodigoGpsModel>(Query);
            }
            return Result;
        }
		
        public CodigoGpsModel GetObject(int id)
        {
            CodigoGpsModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CodigoGpsModel> DAL = new NHibernateDAL<CodigoGpsModel>(Session);
                Result = DAL.SelectId<CodigoGpsModel>(id);
            }
            return Result;
        }
		
        public void Insert(CodigoGpsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CodigoGpsModel> DAL = new NHibernateDAL<CodigoGpsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CodigoGpsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CodigoGpsModel> DAL = new NHibernateDAL<CodigoGpsModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CodigoGpsModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CodigoGpsModel> DAL = new NHibernateDAL<CodigoGpsModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}