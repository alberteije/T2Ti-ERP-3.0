using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class IrrfService
    {

        public IEnumerable<IrrfModel> GetList()
        {
            IList<IrrfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<IrrfModel> DAL = new NHibernateDAL<IrrfModel>(Session);
                Result = DAL.Select(new IrrfModel());
            }
            return Result;
        }

        public IEnumerable<IrrfModel> GetListFilter(Filter filterObj)
        {
            IList<IrrfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from IrrfModel where " + filterObj.Where;
                NHibernateDAL<IrrfModel> DAL = new NHibernateDAL<IrrfModel>(Session);
                Result = DAL.SelectListSql<IrrfModel>(Query);
            }
            return Result;
        }
		
        public IrrfModel GetObject(int id)
        {
            IrrfModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<IrrfModel> DAL = new NHibernateDAL<IrrfModel>(Session);
                Result = DAL.SelectId<IrrfModel>(id);
            }
            return Result;
        }
		
        public void Insert(IrrfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<IrrfModel> DAL = new NHibernateDAL<IrrfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(IrrfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<IrrfModel> DAL = new NHibernateDAL<IrrfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(IrrfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<IrrfModel> DAL = new NHibernateDAL<IrrfModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}