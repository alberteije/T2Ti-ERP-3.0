using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class CboService
    {

        public IEnumerable<CboModel> GetList()
        {
            IList<CboModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CboModel> DAL = new NHibernateDAL<CboModel>(Session);
                Result = DAL.Select(new CboModel());
            }
            return Result;
        }

        public IEnumerable<CboModel> GetListFilter(Filter filterObj)
        {
            IList<CboModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CboModel where " + filterObj.Where;
                NHibernateDAL<CboModel> DAL = new NHibernateDAL<CboModel>(Session);
                Result = DAL.SelectListSql<CboModel>(Query);
            }
            return Result;
        }
		
        public CboModel GetObject(int id)
        {
            CboModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CboModel> DAL = new NHibernateDAL<CboModel>(Session);
                Result = DAL.SelectId<CboModel>(id);
            }
            return Result;
        }
		
        public void Insert(CboModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CboModel> DAL = new NHibernateDAL<CboModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CboModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CboModel> DAL = new NHibernateDAL<CboModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CboModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CboModel> DAL = new NHibernateDAL<CboModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}