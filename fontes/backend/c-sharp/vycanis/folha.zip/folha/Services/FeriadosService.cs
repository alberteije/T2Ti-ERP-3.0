using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FeriadosService
    {

        public IEnumerable<FeriadosModel> GetList()
        {
            IList<FeriadosModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriadosModel> DAL = new NHibernateDAL<FeriadosModel>(Session);
                Result = DAL.Select(new FeriadosModel());
            }
            return Result;
        }

        public IEnumerable<FeriadosModel> GetListFilter(Filter filterObj)
        {
            IList<FeriadosModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FeriadosModel where " + filterObj.Where;
                NHibernateDAL<FeriadosModel> DAL = new NHibernateDAL<FeriadosModel>(Session);
                Result = DAL.SelectListSql<FeriadosModel>(Query);
            }
            return Result;
        }
		
        public FeriadosModel GetObject(int id)
        {
            FeriadosModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriadosModel> DAL = new NHibernateDAL<FeriadosModel>(Session);
                Result = DAL.SelectId<FeriadosModel>(id);
            }
            return Result;
        }
		
        public void Insert(FeriadosModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriadosModel> DAL = new NHibernateDAL<FeriadosModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FeriadosModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriadosModel> DAL = new NHibernateDAL<FeriadosModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FeriadosModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriadosModel> DAL = new NHibernateDAL<FeriadosModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}