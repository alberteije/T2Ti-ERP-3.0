using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class EmpresaTransporteService
    {

        public IEnumerable<EmpresaTransporteModel> GetList()
        {
            IList<EmpresaTransporteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteModel> DAL = new NHibernateDAL<EmpresaTransporteModel>(Session);
                Result = DAL.Select(new EmpresaTransporteModel());
            }
            return Result;
        }

        public IEnumerable<EmpresaTransporteModel> GetListFilter(Filter filterObj)
        {
            IList<EmpresaTransporteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EmpresaTransporteModel where " + filterObj.Where;
                NHibernateDAL<EmpresaTransporteModel> DAL = new NHibernateDAL<EmpresaTransporteModel>(Session);
                Result = DAL.SelectListSql<EmpresaTransporteModel>(Query);
            }
            return Result;
        }
		
        public EmpresaTransporteModel GetObject(int id)
        {
            EmpresaTransporteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteModel> DAL = new NHibernateDAL<EmpresaTransporteModel>(Session);
                Result = DAL.SelectId<EmpresaTransporteModel>(id);
            }
            return Result;
        }
		
        public void Insert(EmpresaTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteModel> DAL = new NHibernateDAL<EmpresaTransporteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EmpresaTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteModel> DAL = new NHibernateDAL<EmpresaTransporteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EmpresaTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EmpresaTransporteModel> DAL = new NHibernateDAL<EmpresaTransporteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}