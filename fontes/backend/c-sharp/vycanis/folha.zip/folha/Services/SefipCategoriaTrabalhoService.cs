using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class SefipCategoriaTrabalhoService
    {

        public IEnumerable<SefipCategoriaTrabalhoModel> GetList()
        {
            IList<SefipCategoriaTrabalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCategoriaTrabalhoModel> DAL = new NHibernateDAL<SefipCategoriaTrabalhoModel>(Session);
                Result = DAL.Select(new SefipCategoriaTrabalhoModel());
            }
            return Result;
        }

        public IEnumerable<SefipCategoriaTrabalhoModel> GetListFilter(Filter filterObj)
        {
            IList<SefipCategoriaTrabalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SefipCategoriaTrabalhoModel where " + filterObj.Where;
                NHibernateDAL<SefipCategoriaTrabalhoModel> DAL = new NHibernateDAL<SefipCategoriaTrabalhoModel>(Session);
                Result = DAL.SelectListSql<SefipCategoriaTrabalhoModel>(Query);
            }
            return Result;
        }
		
        public SefipCategoriaTrabalhoModel GetObject(int id)
        {
            SefipCategoriaTrabalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCategoriaTrabalhoModel> DAL = new NHibernateDAL<SefipCategoriaTrabalhoModel>(Session);
                Result = DAL.SelectId<SefipCategoriaTrabalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(SefipCategoriaTrabalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCategoriaTrabalhoModel> DAL = new NHibernateDAL<SefipCategoriaTrabalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SefipCategoriaTrabalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCategoriaTrabalhoModel> DAL = new NHibernateDAL<SefipCategoriaTrabalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SefipCategoriaTrabalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SefipCategoriaTrabalhoModel> DAL = new NHibernateDAL<SefipCategoriaTrabalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}