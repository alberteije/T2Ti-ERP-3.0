using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class OperadoraPlanoSaudeService
    {

        public IEnumerable<OperadoraPlanoSaudeModel> GetList()
        {
            IList<OperadoraPlanoSaudeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OperadoraPlanoSaudeModel> DAL = new NHibernateDAL<OperadoraPlanoSaudeModel>(Session);
                Result = DAL.Select(new OperadoraPlanoSaudeModel());
            }
            return Result;
        }

        public IEnumerable<OperadoraPlanoSaudeModel> GetListFilter(Filter filterObj)
        {
            IList<OperadoraPlanoSaudeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from OperadoraPlanoSaudeModel where " + filterObj.Where;
                NHibernateDAL<OperadoraPlanoSaudeModel> DAL = new NHibernateDAL<OperadoraPlanoSaudeModel>(Session);
                Result = DAL.SelectListSql<OperadoraPlanoSaudeModel>(Query);
            }
            return Result;
        }
		
        public OperadoraPlanoSaudeModel GetObject(int id)
        {
            OperadoraPlanoSaudeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OperadoraPlanoSaudeModel> DAL = new NHibernateDAL<OperadoraPlanoSaudeModel>(Session);
                Result = DAL.SelectId<OperadoraPlanoSaudeModel>(id);
            }
            return Result;
        }
		
        public void Insert(OperadoraPlanoSaudeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OperadoraPlanoSaudeModel> DAL = new NHibernateDAL<OperadoraPlanoSaudeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(OperadoraPlanoSaudeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OperadoraPlanoSaudeModel> DAL = new NHibernateDAL<OperadoraPlanoSaudeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(OperadoraPlanoSaudeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<OperadoraPlanoSaudeModel> DAL = new NHibernateDAL<OperadoraPlanoSaudeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}