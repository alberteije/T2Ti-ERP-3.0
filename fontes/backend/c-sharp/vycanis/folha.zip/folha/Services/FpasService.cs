using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FpasService
    {

        public IEnumerable<FpasModel> GetList()
        {
            IList<FpasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FpasModel> DAL = new NHibernateDAL<FpasModel>(Session);
                Result = DAL.Select(new FpasModel());
            }
            return Result;
        }

        public IEnumerable<FpasModel> GetListFilter(Filter filterObj)
        {
            IList<FpasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FpasModel where " + filterObj.Where;
                NHibernateDAL<FpasModel> DAL = new NHibernateDAL<FpasModel>(Session);
                Result = DAL.SelectListSql<FpasModel>(Query);
            }
            return Result;
        }
		
        public FpasModel GetObject(int id)
        {
            FpasModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FpasModel> DAL = new NHibernateDAL<FpasModel>(Session);
                Result = DAL.SelectId<FpasModel>(id);
            }
            return Result;
        }
		
        public void Insert(FpasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FpasModel> DAL = new NHibernateDAL<FpasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FpasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FpasModel> DAL = new NHibernateDAL<FpasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FpasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FpasModel> DAL = new NHibernateDAL<FpasModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}