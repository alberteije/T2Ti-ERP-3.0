using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class GuiasAcumuladasService
    {

        public IEnumerable<GuiasAcumuladasModel> GetList()
        {
            IList<GuiasAcumuladasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GuiasAcumuladasModel> DAL = new NHibernateDAL<GuiasAcumuladasModel>(Session);
                Result = DAL.Select(new GuiasAcumuladasModel());
            }
            return Result;
        }

        public IEnumerable<GuiasAcumuladasModel> GetListFilter(Filter filterObj)
        {
            IList<GuiasAcumuladasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from GuiasAcumuladasModel where " + filterObj.Where;
                NHibernateDAL<GuiasAcumuladasModel> DAL = new NHibernateDAL<GuiasAcumuladasModel>(Session);
                Result = DAL.SelectListSql<GuiasAcumuladasModel>(Query);
            }
            return Result;
        }
		
        public GuiasAcumuladasModel GetObject(int id)
        {
            GuiasAcumuladasModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GuiasAcumuladasModel> DAL = new NHibernateDAL<GuiasAcumuladasModel>(Session);
                Result = DAL.SelectId<GuiasAcumuladasModel>(id);
            }
            return Result;
        }
		
        public void Insert(GuiasAcumuladasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GuiasAcumuladasModel> DAL = new NHibernateDAL<GuiasAcumuladasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(GuiasAcumuladasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GuiasAcumuladasModel> DAL = new NHibernateDAL<GuiasAcumuladasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(GuiasAcumuladasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GuiasAcumuladasModel> DAL = new NHibernateDAL<GuiasAcumuladasModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}