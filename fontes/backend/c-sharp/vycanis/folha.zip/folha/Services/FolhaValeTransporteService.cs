using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaValeTransporteService
    {

        public IEnumerable<FolhaValeTransporteModel> GetList()
        {
            IList<FolhaValeTransporteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaValeTransporteModel> DAL = new NHibernateDAL<FolhaValeTransporteModel>(Session);
                Result = DAL.Select(new FolhaValeTransporteModel());
            }
            return Result;
        }

        public IEnumerable<FolhaValeTransporteModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaValeTransporteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaValeTransporteModel where " + filterObj.Where;
                NHibernateDAL<FolhaValeTransporteModel> DAL = new NHibernateDAL<FolhaValeTransporteModel>(Session);
                Result = DAL.SelectListSql<FolhaValeTransporteModel>(Query);
            }
            return Result;
        }
		
        public FolhaValeTransporteModel GetObject(int id)
        {
            FolhaValeTransporteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaValeTransporteModel> DAL = new NHibernateDAL<FolhaValeTransporteModel>(Session);
                Result = DAL.SelectId<FolhaValeTransporteModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaValeTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaValeTransporteModel> DAL = new NHibernateDAL<FolhaValeTransporteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaValeTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaValeTransporteModel> DAL = new NHibernateDAL<FolhaValeTransporteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaValeTransporteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaValeTransporteModel> DAL = new NHibernateDAL<FolhaValeTransporteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}