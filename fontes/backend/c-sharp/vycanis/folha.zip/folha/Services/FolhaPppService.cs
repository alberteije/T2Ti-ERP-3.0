using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaPppService
    {

        public IEnumerable<FolhaPppModel> GetList()
        {
            IList<FolhaPppModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPppModel> DAL = new NHibernateDAL<FolhaPppModel>(Session);
                Result = DAL.Select(new FolhaPppModel());
            }
            return Result;
        }

        public IEnumerable<FolhaPppModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaPppModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaPppModel where " + filterObj.Where;
                NHibernateDAL<FolhaPppModel> DAL = new NHibernateDAL<FolhaPppModel>(Session);
                Result = DAL.SelectListSql<FolhaPppModel>(Query);
            }
            return Result;
        }
		
        public FolhaPppModel GetObject(int id)
        {
            FolhaPppModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPppModel> DAL = new NHibernateDAL<FolhaPppModel>(Session);
                Result = DAL.SelectId<FolhaPppModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaPppModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPppModel> DAL = new NHibernateDAL<FolhaPppModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaPppModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPppModel> DAL = new NHibernateDAL<FolhaPppModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaPppModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPppModel> DAL = new NHibernateDAL<FolhaPppModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}