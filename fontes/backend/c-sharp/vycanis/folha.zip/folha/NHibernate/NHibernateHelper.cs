﻿using NHibernate;
using NHibernate.Cfg;

namespace folha.NHibernate
{
    public class NHibernateHelper
    {
        private static ISessionFactory? SessionFactory;

        public static ISessionFactory GetSessionFactory()
        {
            try
            {
                if (SessionFactory == null)
                {
                    lock(typeof (NHibernateHelper))
                    {
                        Configuration config = new Configuration();
                        config.Configure();
                        config.AddAssembly("folha");
                        SessionFactory = config.BuildSessionFactory();
                    }
                }
                return SessionFactory;
            }
            catch
            {
                throw;
            }
        }
    }
}
