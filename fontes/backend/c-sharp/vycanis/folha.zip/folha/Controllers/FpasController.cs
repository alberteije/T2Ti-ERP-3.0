using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("fpas")]
    [Produces("application/json")]
    public class FpasController : Controller
    {
		private readonly FpasService _service;

        public FpasController()
        {
            _service = new FpasService();
        }

        [HttpGet]
        public IActionResult GetListFpas([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FpasModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Fpas]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFpas")]
        public IActionResult GetObjectFpas(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Fpas]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Fpas]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFpas([FromBody]FpasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Fpas]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFpas", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Fpas]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFpas([FromBody]FpasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Fpas]", null));
                }

                _service.Update(objJson);

                return GetObjectFpas(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Fpas]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFpas(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Fpas]", ex));
            }
        }

    }
}