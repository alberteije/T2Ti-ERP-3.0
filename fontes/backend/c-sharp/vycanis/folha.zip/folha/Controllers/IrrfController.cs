using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("irrf")]
    [Produces("application/json")]
    public class IrrfController : Controller
    {
		private readonly IrrfService _service;

        public IrrfController()
        {
            _service = new IrrfService();
        }

        [HttpGet]
        public IActionResult GetListIrrf([FromQuery]string filter)
        {
            try
            {
                IEnumerable<IrrfModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Irrf]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectIrrf")]
        public IActionResult GetObjectIrrf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Irrf]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Irrf]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertIrrf([FromBody]IrrfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Irrf]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectIrrf", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Irrf]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateIrrf([FromBody]IrrfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Irrf]", null));
                }

                _service.Update(objJson);

                return GetObjectIrrf(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Irrf]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteIrrf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Irrf]", ex));
            }
        }

    }
}