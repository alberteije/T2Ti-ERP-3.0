using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("ferias-periodo-aquisitivo")]
    [Produces("application/json")]
    public class FeriasPeriodoAquisitivoController : Controller
    {
		private readonly FeriasPeriodoAquisitivoService _service;

        public FeriasPeriodoAquisitivoController()
        {
            _service = new FeriasPeriodoAquisitivoService();
        }

        [HttpGet]
        public IActionResult GetListFeriasPeriodoAquisitivo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FeriasPeriodoAquisitivoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FeriasPeriodoAquisitivo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFeriasPeriodoAquisitivo")]
        public IActionResult GetObjectFeriasPeriodoAquisitivo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FeriasPeriodoAquisitivo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FeriasPeriodoAquisitivo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFeriasPeriodoAquisitivo([FromBody]FeriasPeriodoAquisitivoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FeriasPeriodoAquisitivo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFeriasPeriodoAquisitivo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FeriasPeriodoAquisitivo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFeriasPeriodoAquisitivo([FromBody]FeriasPeriodoAquisitivoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FeriasPeriodoAquisitivo]", null));
                }

                _service.Update(objJson);

                return GetObjectFeriasPeriodoAquisitivo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FeriasPeriodoAquisitivo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFeriasPeriodoAquisitivo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FeriasPeriodoAquisitivo]", ex));
            }
        }

    }
}