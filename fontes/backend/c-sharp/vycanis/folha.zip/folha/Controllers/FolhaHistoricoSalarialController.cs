using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-historico-salarial")]
    [Produces("application/json")]
    public class FolhaHistoricoSalarialController : Controller
    {
		private readonly FolhaHistoricoSalarialService _service;

        public FolhaHistoricoSalarialController()
        {
            _service = new FolhaHistoricoSalarialService();
        }

        [HttpGet]
        public IActionResult GetListFolhaHistoricoSalarial([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaHistoricoSalarialModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaHistoricoSalarial]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaHistoricoSalarial")]
        public IActionResult GetObjectFolhaHistoricoSalarial(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaHistoricoSalarial]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaHistoricoSalarial]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaHistoricoSalarial([FromBody]FolhaHistoricoSalarialModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaHistoricoSalarial]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaHistoricoSalarial", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaHistoricoSalarial]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaHistoricoSalarial([FromBody]FolhaHistoricoSalarialModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaHistoricoSalarial]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaHistoricoSalarial(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaHistoricoSalarial]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaHistoricoSalarial(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaHistoricoSalarial]", ex));
            }
        }

    }
}