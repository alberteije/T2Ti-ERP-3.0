using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-tipo-afastamento")]
    [Produces("application/json")]
    public class FolhaTipoAfastamentoController : Controller
    {
		private readonly FolhaTipoAfastamentoService _service;

        public FolhaTipoAfastamentoController()
        {
            _service = new FolhaTipoAfastamentoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaTipoAfastamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaTipoAfastamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaTipoAfastamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaTipoAfastamento")]
        public IActionResult GetObjectFolhaTipoAfastamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaTipoAfastamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaTipoAfastamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaTipoAfastamento([FromBody]FolhaTipoAfastamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaTipoAfastamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaTipoAfastamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaTipoAfastamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaTipoAfastamento([FromBody]FolhaTipoAfastamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaTipoAfastamento]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaTipoAfastamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaTipoAfastamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaTipoAfastamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaTipoAfastamento]", ex));
            }
        }

    }
}