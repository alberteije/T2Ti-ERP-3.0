using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("cbo")]
    [Produces("application/json")]
    public class CboController : Controller
    {
		private readonly CboService _service;

        public CboController()
        {
            _service = new CboService();
        }

        [HttpGet]
        public IActionResult GetListCbo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CboModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Cbo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCbo")]
        public IActionResult GetObjectCbo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Cbo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Cbo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCbo([FromBody]CboModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Cbo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCbo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Cbo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCbo([FromBody]CboModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Cbo]", null));
                }

                _service.Update(objJson);

                return GetObjectCbo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Cbo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCbo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Cbo]", ex));
            }
        }

    }
}