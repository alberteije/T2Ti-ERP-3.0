using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-lancamento-cabecalho")]
    [Produces("application/json")]
    public class FolhaLancamentoCabecalhoController : Controller
    {
		private readonly FolhaLancamentoCabecalhoService _service;

        public FolhaLancamentoCabecalhoController()
        {
            _service = new FolhaLancamentoCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaLancamentoCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaLancamentoCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaLancamentoCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaLancamentoCabecalho")]
        public IActionResult GetObjectFolhaLancamentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaLancamentoCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaLancamentoCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaLancamentoCabecalho([FromBody]FolhaLancamentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaLancamentoCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaLancamentoCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaLancamentoCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaLancamentoCabecalho([FromBody]FolhaLancamentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaLancamentoCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaLancamentoCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaLancamentoCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaLancamentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaLancamentoCabecalho]", ex));
            }
        }

    }
}