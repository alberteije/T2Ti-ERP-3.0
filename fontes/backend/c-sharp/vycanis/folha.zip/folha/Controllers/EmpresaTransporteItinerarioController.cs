using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("empresa-transporte-itinerario")]
    [Produces("application/json")]
    public class EmpresaTransporteItinerarioController : Controller
    {
		private readonly EmpresaTransporteItinerarioService _service;

        public EmpresaTransporteItinerarioController()
        {
            _service = new EmpresaTransporteItinerarioService();
        }

        [HttpGet]
        public IActionResult GetListEmpresaTransporteItinerario([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EmpresaTransporteItinerarioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EmpresaTransporteItinerario]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEmpresaTransporteItinerario")]
        public IActionResult GetObjectEmpresaTransporteItinerario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EmpresaTransporteItinerario]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EmpresaTransporteItinerario]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEmpresaTransporteItinerario([FromBody]EmpresaTransporteItinerarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EmpresaTransporteItinerario]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEmpresaTransporteItinerario", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EmpresaTransporteItinerario]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEmpresaTransporteItinerario([FromBody]EmpresaTransporteItinerarioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EmpresaTransporteItinerario]", null));
                }

                _service.Update(objJson);

                return GetObjectEmpresaTransporteItinerario(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EmpresaTransporteItinerario]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmpresaTransporteItinerario(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EmpresaTransporteItinerario]", ex));
            }
        }

    }
}