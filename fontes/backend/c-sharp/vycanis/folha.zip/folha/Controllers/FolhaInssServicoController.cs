using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-inss-servico")]
    [Produces("application/json")]
    public class FolhaInssServicoController : Controller
    {
		private readonly FolhaInssServicoService _service;

        public FolhaInssServicoController()
        {
            _service = new FolhaInssServicoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaInssServico([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaInssServicoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaInssServico]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaInssServico")]
        public IActionResult GetObjectFolhaInssServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaInssServico]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaInssServico]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaInssServico([FromBody]FolhaInssServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaInssServico]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaInssServico", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaInssServico]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaInssServico([FromBody]FolhaInssServicoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaInssServico]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaInssServico(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaInssServico]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaInssServico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaInssServico]", ex));
            }
        }

    }
}