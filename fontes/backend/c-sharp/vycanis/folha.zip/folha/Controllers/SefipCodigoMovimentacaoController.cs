using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("sefip-codigo-movimentacao")]
    [Produces("application/json")]
    public class SefipCodigoMovimentacaoController : Controller
    {
		private readonly SefipCodigoMovimentacaoService _service;

        public SefipCodigoMovimentacaoController()
        {
            _service = new SefipCodigoMovimentacaoService();
        }

        [HttpGet]
        public IActionResult GetListSefipCodigoMovimentacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SefipCodigoMovimentacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList SefipCodigoMovimentacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSefipCodigoMovimentacao")]
        public IActionResult GetObjectSefipCodigoMovimentacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject SefipCodigoMovimentacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject SefipCodigoMovimentacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSefipCodigoMovimentacao([FromBody]SefipCodigoMovimentacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert SefipCodigoMovimentacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSefipCodigoMovimentacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert SefipCodigoMovimentacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSefipCodigoMovimentacao([FromBody]SefipCodigoMovimentacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update SefipCodigoMovimentacao]", null));
                }

                _service.Update(objJson);

                return GetObjectSefipCodigoMovimentacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update SefipCodigoMovimentacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSefipCodigoMovimentacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete SefipCodigoMovimentacao]", ex));
            }
        }

    }
}