using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-ppp")]
    [Produces("application/json")]
    public class FolhaPppController : Controller
    {
		private readonly FolhaPppService _service;

        public FolhaPppController()
        {
            _service = new FolhaPppService();
        }

        [HttpGet]
        public IActionResult GetListFolhaPpp([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaPppModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaPpp]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaPpp")]
        public IActionResult GetObjectFolhaPpp(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaPpp]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaPpp]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaPpp([FromBody]FolhaPppModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaPpp]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaPpp", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaPpp]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaPpp([FromBody]FolhaPppModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaPpp]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaPpp(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaPpp]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaPpp(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaPpp]", ex));
            }
        }

    }
}