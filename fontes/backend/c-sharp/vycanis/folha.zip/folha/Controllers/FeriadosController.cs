using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("feriados")]
    [Produces("application/json")]
    public class FeriadosController : Controller
    {
		private readonly FeriadosService _service;

        public FeriadosController()
        {
            _service = new FeriadosService();
        }

        [HttpGet]
        public IActionResult GetListFeriados([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FeriadosModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Feriados]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFeriados")]
        public IActionResult GetObjectFeriados(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Feriados]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Feriados]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFeriados([FromBody]FeriadosModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Feriados]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFeriados", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Feriados]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFeriados([FromBody]FeriadosModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Feriados]", null));
                }

                _service.Update(objJson);

                return GetObjectFeriados(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Feriados]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFeriados(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Feriados]", ex));
            }
        }

    }
}