using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("sefip-codigo-recolhimento")]
    [Produces("application/json")]
    public class SefipCodigoRecolhimentoController : Controller
    {
		private readonly SefipCodigoRecolhimentoService _service;

        public SefipCodigoRecolhimentoController()
        {
            _service = new SefipCodigoRecolhimentoService();
        }

        [HttpGet]
        public IActionResult GetListSefipCodigoRecolhimento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SefipCodigoRecolhimentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList SefipCodigoRecolhimento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSefipCodigoRecolhimento")]
        public IActionResult GetObjectSefipCodigoRecolhimento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject SefipCodigoRecolhimento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject SefipCodigoRecolhimento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSefipCodigoRecolhimento([FromBody]SefipCodigoRecolhimentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert SefipCodigoRecolhimento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSefipCodigoRecolhimento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert SefipCodigoRecolhimento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSefipCodigoRecolhimento([FromBody]SefipCodigoRecolhimentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update SefipCodigoRecolhimento]", null));
                }

                _service.Update(objJson);

                return GetObjectSefipCodigoRecolhimento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update SefipCodigoRecolhimento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSefipCodigoRecolhimento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete SefipCodigoRecolhimento]", ex));
            }
        }

    }
}