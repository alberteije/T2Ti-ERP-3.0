using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("codigo-gps")]
    [Produces("application/json")]
    public class CodigoGpsController : Controller
    {
		private readonly CodigoGpsService _service;

        public CodigoGpsController()
        {
            _service = new CodigoGpsService();
        }

        [HttpGet]
        public IActionResult GetListCodigoGps([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CodigoGpsModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CodigoGps]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCodigoGps")]
        public IActionResult GetObjectCodigoGps(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CodigoGps]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CodigoGps]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCodigoGps([FromBody]CodigoGpsModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CodigoGps]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCodigoGps", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CodigoGps]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCodigoGps([FromBody]CodigoGpsModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CodigoGps]", null));
                }

                _service.Update(objJson);

                return GetObjectCodigoGps(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CodigoGps]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCodigoGps(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CodigoGps]", ex));
            }
        }

    }
}