using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-fechamento")]
    [Produces("application/json")]
    public class FolhaFechamentoController : Controller
    {
		private readonly FolhaFechamentoService _service;

        public FolhaFechamentoController()
        {
            _service = new FolhaFechamentoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaFechamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaFechamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaFechamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaFechamento")]
        public IActionResult GetObjectFolhaFechamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaFechamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaFechamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaFechamento([FromBody]FolhaFechamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaFechamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaFechamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaFechamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaFechamento([FromBody]FolhaFechamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaFechamento]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaFechamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaFechamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaFechamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaFechamento]", ex));
            }
        }

    }
}