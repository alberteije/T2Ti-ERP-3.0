using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("salario-minimo")]
    [Produces("application/json")]
    public class SalarioMinimoController : Controller
    {
		private readonly SalarioMinimoService _service;

        public SalarioMinimoController()
        {
            _service = new SalarioMinimoService();
        }

        [HttpGet]
        public IActionResult GetListSalarioMinimo([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SalarioMinimoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList SalarioMinimo]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSalarioMinimo")]
        public IActionResult GetObjectSalarioMinimo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject SalarioMinimo]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject SalarioMinimo]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSalarioMinimo([FromBody]SalarioMinimoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert SalarioMinimo]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSalarioMinimo", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert SalarioMinimo]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSalarioMinimo([FromBody]SalarioMinimoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update SalarioMinimo]", null));
                }

                _service.Update(objJson);

                return GetObjectSalarioMinimo(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update SalarioMinimo]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSalarioMinimo(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete SalarioMinimo]", ex));
            }
        }

    }
}