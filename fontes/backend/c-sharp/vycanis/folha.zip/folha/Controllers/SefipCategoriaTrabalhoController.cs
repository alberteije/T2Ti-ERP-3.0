using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("sefip-categoria-trabalho")]
    [Produces("application/json")]
    public class SefipCategoriaTrabalhoController : Controller
    {
		private readonly SefipCategoriaTrabalhoService _service;

        public SefipCategoriaTrabalhoController()
        {
            _service = new SefipCategoriaTrabalhoService();
        }

        [HttpGet]
        public IActionResult GetListSefipCategoriaTrabalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SefipCategoriaTrabalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList SefipCategoriaTrabalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSefipCategoriaTrabalho")]
        public IActionResult GetObjectSefipCategoriaTrabalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject SefipCategoriaTrabalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject SefipCategoriaTrabalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSefipCategoriaTrabalho([FromBody]SefipCategoriaTrabalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert SefipCategoriaTrabalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSefipCategoriaTrabalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert SefipCategoriaTrabalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSefipCategoriaTrabalho([FromBody]SefipCategoriaTrabalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update SefipCategoriaTrabalho]", null));
                }

                _service.Update(objJson);

                return GetObjectSefipCategoriaTrabalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update SefipCategoriaTrabalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSefipCategoriaTrabalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete SefipCategoriaTrabalho]", ex));
            }
        }

    }
}