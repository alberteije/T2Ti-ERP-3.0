using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-vale-transporte")]
    [Produces("application/json")]
    public class FolhaValeTransporteController : Controller
    {
		private readonly FolhaValeTransporteService _service;

        public FolhaValeTransporteController()
        {
            _service = new FolhaValeTransporteService();
        }

        [HttpGet]
        public IActionResult GetListFolhaValeTransporte([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaValeTransporteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaValeTransporte]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaValeTransporte")]
        public IActionResult GetObjectFolhaValeTransporte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaValeTransporte]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaValeTransporte]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaValeTransporte([FromBody]FolhaValeTransporteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaValeTransporte]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaValeTransporte", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaValeTransporte]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaValeTransporte([FromBody]FolhaValeTransporteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaValeTransporte]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaValeTransporte(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaValeTransporte]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaValeTransporte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaValeTransporte]", ex));
            }
        }

    }
}