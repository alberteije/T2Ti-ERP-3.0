using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-afastamento")]
    [Produces("application/json")]
    public class FolhaAfastamentoController : Controller
    {
		private readonly FolhaAfastamentoService _service;

        public FolhaAfastamentoController()
        {
            _service = new FolhaAfastamentoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaAfastamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaAfastamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaAfastamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaAfastamento")]
        public IActionResult GetObjectFolhaAfastamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaAfastamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaAfastamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaAfastamento([FromBody]FolhaAfastamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaAfastamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaAfastamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaAfastamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaAfastamento([FromBody]FolhaAfastamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaAfastamento]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaAfastamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaAfastamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaAfastamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaAfastamento]", ex));
            }
        }

    }
}