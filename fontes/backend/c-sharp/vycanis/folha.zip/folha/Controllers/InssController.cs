using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("inss")]
    [Produces("application/json")]
    public class InssController : Controller
    {
		private readonly InssService _service;

        public InssController()
        {
            _service = new InssService();
        }

        [HttpGet]
        public IActionResult GetListInss([FromQuery]string filter)
        {
            try
            {
                IEnumerable<InssModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Inss]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectInss")]
        public IActionResult GetObjectInss(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Inss]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Inss]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertInss([FromBody]InssModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Inss]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectInss", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Inss]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateInss([FromBody]InssModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Inss]", null));
                }

                _service.Update(objJson);

                return GetObjectInss(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Inss]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteInss(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Inss]", ex));
            }
        }

    }
}