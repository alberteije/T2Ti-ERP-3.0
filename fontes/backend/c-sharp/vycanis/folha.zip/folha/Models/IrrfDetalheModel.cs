namespace folha.Models
{
	public class IrrfDetalheModel
	{	
		public int? Id { get; set; } 

		public int? Faixa { get; set; } 

		public System.Nullable<System.Decimal> De { get; set; } 

		public System.Nullable<System.Decimal> Ate { get; set; } 

		public System.Nullable<System.Decimal> Taxa { get; set; } 

		public System.Nullable<System.Decimal> Desconto { get; set; } 

		public IrrfModel? IrrfModel { get; set; } 

	}
}
