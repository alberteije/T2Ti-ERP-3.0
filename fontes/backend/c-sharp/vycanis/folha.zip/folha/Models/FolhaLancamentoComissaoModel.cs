namespace folha.Models
{
	public class FolhaLancamentoComissaoModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public System.Nullable<System.DateTime> Vencimento { get; set; } 

		public System.Nullable<System.Decimal> BaseCalculo { get; set; } 

		public System.Nullable<System.Decimal> ValorComissao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
