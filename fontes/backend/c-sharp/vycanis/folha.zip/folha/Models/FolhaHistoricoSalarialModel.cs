namespace folha.Models
{
	public class FolhaHistoricoSalarialModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public System.Nullable<System.Decimal> SalarioAtual { get; set; } 

		public System.Nullable<System.Decimal> PercentualAumento { get; set; } 

		public System.Nullable<System.Decimal> SalarioNovo { get; set; } 

		public string? ValidoAPartir { get; set; } 

		public string? Motivo { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
