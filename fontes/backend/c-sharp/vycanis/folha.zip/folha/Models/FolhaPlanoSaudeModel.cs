namespace folha.Models
{
	public class FolhaPlanoSaudeModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public string? Beneficiario { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public OperadoraPlanoSaudeModel? OperadoraPlanoSaudeModel { get; set; } 

	}
}
