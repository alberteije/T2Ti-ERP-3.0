namespace folha.Models
{
	public class FeriasPeriodoAquisitivoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public string? Situacao { get; set; } 

		public System.Nullable<System.DateTime> LimiteParaGozo { get; set; } 

		public string? DescontarFaltas { get; set; } 

		public string? DesconsiderarAfastamento { get; set; } 

		public int? AfastamentoPrevidencia { get; set; } 

		public int? AfastamentoSemRemun { get; set; } 

		public int? AfastamentoComRemun { get; set; } 

		public int? DiasDireito { get; set; } 

		public int? DiasGozados { get; set; } 

		public int? DiasFaltas { get; set; } 

		public int? DiasRestantes { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
