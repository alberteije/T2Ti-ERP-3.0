namespace folha.Models
{
	public class FolhaTipoAfastamentoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		public string? CodigoEsocial { get; set; } 

		public string? Descricao { get; set; } 

	}
}
