namespace folha.Models
{
	public class FolhaFeriasColetivasModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public int? DiasGozo { get; set; } 

		public System.Nullable<System.DateTime> AbonoPecuniarioInicio { get; set; } 

		public System.Nullable<System.DateTime> AbonoPecuniarioFim { get; set; } 

		public int? DiasAbono { get; set; } 

		public System.Nullable<System.DateTime> DataPagamento { get; set; } 

	}
}
