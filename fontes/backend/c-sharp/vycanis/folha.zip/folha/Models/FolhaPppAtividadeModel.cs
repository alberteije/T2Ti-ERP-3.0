namespace folha.Models
{
	public class FolhaPppAtividadeModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public string? Descricao { get; set; } 

		public FolhaPppModel? FolhaPppModel { get; set; } 

	}
}
