namespace folha.Models
{
	public class InssModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		private IList<SalarioFamiliaModel>? salarioFamiliaModelList; 
		public IList<SalarioFamiliaModel>? SalarioFamiliaModelList 
		{ 
			get 
			{ 
				return salarioFamiliaModelList; 
			} 
			set 
			{ 
				salarioFamiliaModelList = value; 
				foreach (SalarioFamiliaModel salarioFamiliaModel in salarioFamiliaModelList!) 
				{ 
					salarioFamiliaModel.InssModel = this; 
				} 
			} 
		} 

		private IList<InssDetalheModel>? inssDetalheModelList; 
		public IList<InssDetalheModel>? InssDetalheModelList 
		{ 
			get 
			{ 
				return inssDetalheModelList; 
			} 
			set 
			{ 
				inssDetalheModelList = value; 
				foreach (InssDetalheModel inssDetalheModel in inssDetalheModelList!) 
				{ 
					inssDetalheModel.InssModel = this; 
				} 
			} 
		} 

	}
}
