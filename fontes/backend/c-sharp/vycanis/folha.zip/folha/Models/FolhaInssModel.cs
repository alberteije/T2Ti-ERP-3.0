namespace folha.Models
{
	public class FolhaInssModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		private IList<FolhaInssRetencaoModel>? folhaInssRetencaoModelList; 
		public IList<FolhaInssRetencaoModel>? FolhaInssRetencaoModelList 
		{ 
			get 
			{ 
				return folhaInssRetencaoModelList; 
			} 
			set 
			{ 
				folhaInssRetencaoModelList = value; 
				foreach (FolhaInssRetencaoModel folhaInssRetencaoModel in folhaInssRetencaoModelList!) 
				{ 
					folhaInssRetencaoModel.FolhaInssModel = this; 
				} 
			} 
		} 

	}
}
