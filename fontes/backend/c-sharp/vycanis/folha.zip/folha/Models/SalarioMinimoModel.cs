namespace folha.Models
{
	public class SalarioMinimoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> Vigencia { get; set; } 

		public System.Nullable<System.Decimal> ValorMensal { get; set; } 

		public System.Nullable<System.Decimal> ValorDiario { get; set; } 

		public System.Nullable<System.Decimal> ValorHora { get; set; } 

		public string? NormaLegal { get; set; } 

		public System.Nullable<System.DateTime> Dou { get; set; } 

	}
}
