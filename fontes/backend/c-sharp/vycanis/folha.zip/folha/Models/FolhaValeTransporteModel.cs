namespace folha.Models
{
	public class FolhaValeTransporteModel
	{	
		public int? Id { get; set; } 

		public int? Quantidade { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public EmpresaTransporteItinerarioModel? EmpresaTransporteItinerarioModel { get; set; } 

	}
}
