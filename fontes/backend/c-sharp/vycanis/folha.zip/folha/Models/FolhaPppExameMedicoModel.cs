namespace folha.Models
{
	public class FolhaPppExameMedicoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataUltimo { get; set; } 

		public string? Tipo { get; set; } 

		public string? Exame { get; set; } 

		public string? Natureza { get; set; } 

		public string? IndicacaoResultados { get; set; } 

		public FolhaPppModel? FolhaPppModel { get; set; } 

	}
}
