namespace folha.Models
{
	public class EmpresaTransporteItinerarioModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.Decimal> Tarifa { get; set; } 

		public string? Trajeto { get; set; } 

		public EmpresaTransporteModel? EmpresaTransporteModel { get; set; } 

	}
}
