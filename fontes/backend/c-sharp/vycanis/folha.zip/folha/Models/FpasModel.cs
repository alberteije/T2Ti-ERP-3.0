namespace folha.Models
{
	public class FpasModel
	{	
		public int? Id { get; set; } 

		public int? Codigo { get; set; } 

		public string? Cnae { get; set; } 

		public System.Nullable<System.Decimal> AliquotaSat { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.Decimal> PercentualInssPatronal { get; set; } 

		public string? CodigoTerceiro { get; set; } 

		public System.Nullable<System.Decimal> PercentualTerceiros { get; set; } 

	}
}
