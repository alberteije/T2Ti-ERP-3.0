namespace folha.Models
{
	public class IrrfModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public System.Nullable<System.Decimal> DescontoPorDependente { get; set; } 

		public System.Nullable<System.Decimal> MinimoParaRetencao { get; set; } 

		private IList<IrrfDetalheModel>? irrfDetalheModelList; 
		public IList<IrrfDetalheModel>? IrrfDetalheModelList 
		{ 
			get 
			{ 
				return irrfDetalheModelList; 
			} 
			set 
			{ 
				irrfDetalheModelList = value; 
				foreach (IrrfDetalheModel irrfDetalheModel in irrfDetalheModelList!) 
				{ 
					irrfDetalheModel.IrrfModel = this; 
				} 
			} 
		} 

	}
}
