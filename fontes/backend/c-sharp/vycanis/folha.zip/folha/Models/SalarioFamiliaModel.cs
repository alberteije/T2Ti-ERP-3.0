namespace folha.Models
{
	public class SalarioFamiliaModel
	{	
		public int? Id { get; set; } 

		public int? Faixa { get; set; } 

		public System.Nullable<System.Decimal> De { get; set; } 

		public System.Nullable<System.Decimal> Ate { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public InssModel? InssModel { get; set; } 

	}
}
