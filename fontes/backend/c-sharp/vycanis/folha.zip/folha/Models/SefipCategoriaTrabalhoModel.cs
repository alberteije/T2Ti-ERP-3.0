namespace folha.Models
{
	public class SefipCategoriaTrabalhoModel
	{	
		public int? Id { get; set; } 

		public int? Codigo { get; set; } 

		public string? Nome { get; set; } 

	}
}
