namespace folha.Models
{
	public class CboModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Codigo1994 { get; set; } 

		public string? Nome { get; set; } 

		public string? Observacao { get; set; } 

	}
}
