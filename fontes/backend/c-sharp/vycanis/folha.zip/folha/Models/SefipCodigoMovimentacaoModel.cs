namespace folha.Models
{
	public class SefipCodigoMovimentacaoModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Aplicacao { get; set; } 

	}
}
