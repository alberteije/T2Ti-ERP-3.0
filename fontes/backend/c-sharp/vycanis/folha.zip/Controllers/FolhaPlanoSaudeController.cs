using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-plano-saude")]
    [Produces("application/json")]
    public class FolhaPlanoSaudeController : Controller
    {
		private readonly FolhaPlanoSaudeService _service;

        public FolhaPlanoSaudeController()
        {
            _service = new FolhaPlanoSaudeService();
        }

        [HttpGet]
        public IActionResult GetListFolhaPlanoSaude([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaPlanoSaudeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaPlanoSaude]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaPlanoSaude")]
        public IActionResult GetObjectFolhaPlanoSaude(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaPlanoSaude]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaPlanoSaude]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaPlanoSaude([FromBody]FolhaPlanoSaudeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaPlanoSaude]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaPlanoSaude", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaPlanoSaude]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaPlanoSaude([FromBody]FolhaPlanoSaudeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaPlanoSaude]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaPlanoSaude(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaPlanoSaude]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaPlanoSaude(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaPlanoSaude]", ex));
            }
        }

    }
}