using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-evento")]
    [Produces("application/json")]
    public class FolhaEventoController : Controller
    {
		private readonly FolhaEventoService _service;

        public FolhaEventoController()
        {
            _service = new FolhaEventoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaEvento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaEventoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaEvento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaEvento")]
        public IActionResult GetObjectFolhaEvento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaEvento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaEvento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaEvento([FromBody]FolhaEventoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaEvento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaEvento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaEvento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaEvento([FromBody]FolhaEventoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaEvento]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaEvento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaEvento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaEvento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaEvento]", ex));
            }
        }

    }
}