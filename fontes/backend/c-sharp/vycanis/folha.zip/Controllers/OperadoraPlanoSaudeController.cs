using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("operadora-plano-saude")]
    [Produces("application/json")]
    public class OperadoraPlanoSaudeController : Controller
    {
		private readonly OperadoraPlanoSaudeService _service;

        public OperadoraPlanoSaudeController()
        {
            _service = new OperadoraPlanoSaudeService();
        }

        [HttpGet]
        public IActionResult GetListOperadoraPlanoSaude([FromQuery]string filter)
        {
            try
            {
                IEnumerable<OperadoraPlanoSaudeModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList OperadoraPlanoSaude]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectOperadoraPlanoSaude")]
        public IActionResult GetObjectOperadoraPlanoSaude(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject OperadoraPlanoSaude]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject OperadoraPlanoSaude]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertOperadoraPlanoSaude([FromBody]OperadoraPlanoSaudeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert OperadoraPlanoSaude]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectOperadoraPlanoSaude", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert OperadoraPlanoSaude]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateOperadoraPlanoSaude([FromBody]OperadoraPlanoSaudeModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update OperadoraPlanoSaude]", null));
                }

                _service.Update(objJson);

                return GetObjectOperadoraPlanoSaude(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update OperadoraPlanoSaude]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOperadoraPlanoSaude(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete OperadoraPlanoSaude]", ex));
            }
        }

    }
}