using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("guias-acumuladas")]
    [Produces("application/json")]
    public class GuiasAcumuladasController : Controller
    {
		private readonly GuiasAcumuladasService _service;

        public GuiasAcumuladasController()
        {
            _service = new GuiasAcumuladasService();
        }

        [HttpGet]
        public IActionResult GetListGuiasAcumuladas([FromQuery]string filter)
        {
            try
            {
                IEnumerable<GuiasAcumuladasModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList GuiasAcumuladas]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectGuiasAcumuladas")]
        public IActionResult GetObjectGuiasAcumuladas(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject GuiasAcumuladas]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject GuiasAcumuladas]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertGuiasAcumuladas([FromBody]GuiasAcumuladasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert GuiasAcumuladas]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectGuiasAcumuladas", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert GuiasAcumuladas]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateGuiasAcumuladas([FromBody]GuiasAcumuladasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update GuiasAcumuladas]", null));
                }

                _service.Update(objJson);

                return GetObjectGuiasAcumuladas(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update GuiasAcumuladas]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteGuiasAcumuladas(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete GuiasAcumuladas]", ex));
            }
        }

    }
}