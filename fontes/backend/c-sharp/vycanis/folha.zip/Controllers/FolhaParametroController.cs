using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-parametro")]
    [Produces("application/json")]
    public class FolhaParametroController : Controller
    {
		private readonly FolhaParametroService _service;

        public FolhaParametroController()
        {
            _service = new FolhaParametroService();
        }

        [HttpGet]
        public IActionResult GetListFolhaParametro([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaParametroModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaParametro]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaParametro")]
        public IActionResult GetObjectFolhaParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaParametro]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaParametro]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaParametro([FromBody]FolhaParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaParametro]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaParametro", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaParametro]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaParametro([FromBody]FolhaParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaParametro]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaParametro(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaParametro]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaParametro]", ex));
            }
        }

    }
}