using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("empresa-transporte")]
    [Produces("application/json")]
    public class EmpresaTransporteController : Controller
    {
		private readonly EmpresaTransporteService _service;

        public EmpresaTransporteController()
        {
            _service = new EmpresaTransporteService();
        }

        [HttpGet]
        public IActionResult GetListEmpresaTransporte([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EmpresaTransporteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EmpresaTransporte]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEmpresaTransporte")]
        public IActionResult GetObjectEmpresaTransporte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EmpresaTransporte]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EmpresaTransporte]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEmpresaTransporte([FromBody]EmpresaTransporteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EmpresaTransporte]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEmpresaTransporte", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EmpresaTransporte]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEmpresaTransporte([FromBody]EmpresaTransporteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EmpresaTransporte]", null));
                }

                _service.Update(objJson);

                return GetObjectEmpresaTransporte(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EmpresaTransporte]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmpresaTransporte(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EmpresaTransporte]", ex));
            }
        }

    }
}