using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-ferias-coletivas")]
    [Produces("application/json")]
    public class FolhaFeriasColetivasController : Controller
    {
		private readonly FolhaFeriasColetivasService _service;

        public FolhaFeriasColetivasController()
        {
            _service = new FolhaFeriasColetivasService();
        }

        [HttpGet]
        public IActionResult GetListFolhaFeriasColetivas([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaFeriasColetivasModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaFeriasColetivas]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaFeriasColetivas")]
        public IActionResult GetObjectFolhaFeriasColetivas(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaFeriasColetivas]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaFeriasColetivas]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaFeriasColetivas([FromBody]FolhaFeriasColetivasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaFeriasColetivas]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaFeriasColetivas", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaFeriasColetivas]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaFeriasColetivas([FromBody]FolhaFeriasColetivasModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaFeriasColetivas]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaFeriasColetivas(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaFeriasColetivas]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaFeriasColetivas(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaFeriasColetivas]", ex));
            }
        }

    }
}