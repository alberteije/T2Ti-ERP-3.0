using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-inss")]
    [Produces("application/json")]
    public class FolhaInssController : Controller
    {
		private readonly FolhaInssService _service;

        public FolhaInssController()
        {
            _service = new FolhaInssService();
        }

        [HttpGet]
        public IActionResult GetListFolhaInss([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaInssModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaInss]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaInss")]
        public IActionResult GetObjectFolhaInss(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaInss]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaInss]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaInss([FromBody]FolhaInssModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaInss]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaInss", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaInss]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaInss([FromBody]FolhaInssModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaInss]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaInss(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaInss]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaInss(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaInss]", ex));
            }
        }

    }
}