using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-rescisao")]
    [Produces("application/json")]
    public class FolhaRescisaoController : Controller
    {
		private readonly FolhaRescisaoService _service;

        public FolhaRescisaoController()
        {
            _service = new FolhaRescisaoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaRescisao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaRescisaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaRescisao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaRescisao")]
        public IActionResult GetObjectFolhaRescisao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaRescisao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaRescisao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaRescisao([FromBody]FolhaRescisaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaRescisao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaRescisao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaRescisao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaRescisao([FromBody]FolhaRescisaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaRescisao]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaRescisao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaRescisao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaRescisao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaRescisao]", ex));
            }
        }

    }
}