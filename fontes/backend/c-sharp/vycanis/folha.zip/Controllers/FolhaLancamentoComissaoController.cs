using Microsoft.AspNetCore.Mvc;
using folha.Models;
using folha.Services;

namespace folha.Controllers
{
    [Route("folha-lancamento-comissao")]
    [Produces("application/json")]
    public class FolhaLancamentoComissaoController : Controller
    {
		private readonly FolhaLancamentoComissaoService _service;

        public FolhaLancamentoComissaoController()
        {
            _service = new FolhaLancamentoComissaoService();
        }

        [HttpGet]
        public IActionResult GetListFolhaLancamentoComissao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FolhaLancamentoComissaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList FolhaLancamentoComissao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFolhaLancamentoComissao")]
        public IActionResult GetObjectFolhaLancamentoComissao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject FolhaLancamentoComissao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject FolhaLancamentoComissao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFolhaLancamentoComissao([FromBody]FolhaLancamentoComissaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert FolhaLancamentoComissao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFolhaLancamentoComissao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert FolhaLancamentoComissao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFolhaLancamentoComissao([FromBody]FolhaLancamentoComissaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update FolhaLancamentoComissao]", null));
                }

                _service.Update(objJson);

                return GetObjectFolhaLancamentoComissao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update FolhaLancamentoComissao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFolhaLancamentoComissao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete FolhaLancamentoComissao]", ex));
            }
        }

    }
}