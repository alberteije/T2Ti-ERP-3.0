using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaLancamentoCabecalhoService
    {

        public IEnumerable<FolhaLancamentoCabecalhoModel> GetList()
        {
            IList<FolhaLancamentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoCabecalhoModel> DAL = new NHibernateDAL<FolhaLancamentoCabecalhoModel>(Session);
                Result = DAL.Select(new FolhaLancamentoCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaLancamentoCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaLancamentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaLancamentoCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<FolhaLancamentoCabecalhoModel> DAL = new NHibernateDAL<FolhaLancamentoCabecalhoModel>(Session);
                Result = DAL.SelectListSql<FolhaLancamentoCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public FolhaLancamentoCabecalhoModel GetObject(int id)
        {
            FolhaLancamentoCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoCabecalhoModel> DAL = new NHibernateDAL<FolhaLancamentoCabecalhoModel>(Session);
                Result = DAL.SelectId<FolhaLancamentoCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaLancamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoCabecalhoModel> DAL = new NHibernateDAL<FolhaLancamentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaLancamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoCabecalhoModel> DAL = new NHibernateDAL<FolhaLancamentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaLancamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoCabecalhoModel> DAL = new NHibernateDAL<FolhaLancamentoCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}