using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaAfastamentoService
    {

        public IEnumerable<FolhaAfastamentoModel> GetList()
        {
            IList<FolhaAfastamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaAfastamentoModel> DAL = new NHibernateDAL<FolhaAfastamentoModel>(Session);
                Result = DAL.Select(new FolhaAfastamentoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaAfastamentoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaAfastamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaAfastamentoModel where " + filterObj.Where;
                NHibernateDAL<FolhaAfastamentoModel> DAL = new NHibernateDAL<FolhaAfastamentoModel>(Session);
                Result = DAL.SelectListSql<FolhaAfastamentoModel>(Query);
            }
            return Result;
        }
		
        public FolhaAfastamentoModel GetObject(int id)
        {
            FolhaAfastamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaAfastamentoModel> DAL = new NHibernateDAL<FolhaAfastamentoModel>(Session);
                Result = DAL.SelectId<FolhaAfastamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaAfastamentoModel> DAL = new NHibernateDAL<FolhaAfastamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaAfastamentoModel> DAL = new NHibernateDAL<FolhaAfastamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaAfastamentoModel> DAL = new NHibernateDAL<FolhaAfastamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}