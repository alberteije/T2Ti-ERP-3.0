using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaPlanoSaudeService
    {

        public IEnumerable<FolhaPlanoSaudeModel> GetList()
        {
            IList<FolhaPlanoSaudeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPlanoSaudeModel> DAL = new NHibernateDAL<FolhaPlanoSaudeModel>(Session);
                Result = DAL.Select(new FolhaPlanoSaudeModel());
            }
            return Result;
        }

        public IEnumerable<FolhaPlanoSaudeModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaPlanoSaudeModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaPlanoSaudeModel where " + filterObj.Where;
                NHibernateDAL<FolhaPlanoSaudeModel> DAL = new NHibernateDAL<FolhaPlanoSaudeModel>(Session);
                Result = DAL.SelectListSql<FolhaPlanoSaudeModel>(Query);
            }
            return Result;
        }
		
        public FolhaPlanoSaudeModel GetObject(int id)
        {
            FolhaPlanoSaudeModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPlanoSaudeModel> DAL = new NHibernateDAL<FolhaPlanoSaudeModel>(Session);
                Result = DAL.SelectId<FolhaPlanoSaudeModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaPlanoSaudeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPlanoSaudeModel> DAL = new NHibernateDAL<FolhaPlanoSaudeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaPlanoSaudeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPlanoSaudeModel> DAL = new NHibernateDAL<FolhaPlanoSaudeModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaPlanoSaudeModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaPlanoSaudeModel> DAL = new NHibernateDAL<FolhaPlanoSaudeModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}