using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaHistoricoSalarialService
    {

        public IEnumerable<FolhaHistoricoSalarialModel> GetList()
        {
            IList<FolhaHistoricoSalarialModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaHistoricoSalarialModel> DAL = new NHibernateDAL<FolhaHistoricoSalarialModel>(Session);
                Result = DAL.Select(new FolhaHistoricoSalarialModel());
            }
            return Result;
        }

        public IEnumerable<FolhaHistoricoSalarialModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaHistoricoSalarialModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaHistoricoSalarialModel where " + filterObj.Where;
                NHibernateDAL<FolhaHistoricoSalarialModel> DAL = new NHibernateDAL<FolhaHistoricoSalarialModel>(Session);
                Result = DAL.SelectListSql<FolhaHistoricoSalarialModel>(Query);
            }
            return Result;
        }
		
        public FolhaHistoricoSalarialModel GetObject(int id)
        {
            FolhaHistoricoSalarialModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaHistoricoSalarialModel> DAL = new NHibernateDAL<FolhaHistoricoSalarialModel>(Session);
                Result = DAL.SelectId<FolhaHistoricoSalarialModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaHistoricoSalarialModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaHistoricoSalarialModel> DAL = new NHibernateDAL<FolhaHistoricoSalarialModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaHistoricoSalarialModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaHistoricoSalarialModel> DAL = new NHibernateDAL<FolhaHistoricoSalarialModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaHistoricoSalarialModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaHistoricoSalarialModel> DAL = new NHibernateDAL<FolhaHistoricoSalarialModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}