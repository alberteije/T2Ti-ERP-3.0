using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FeriasPeriodoAquisitivoService
    {

        public IEnumerable<FeriasPeriodoAquisitivoModel> GetList()
        {
            IList<FeriasPeriodoAquisitivoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriasPeriodoAquisitivoModel> DAL = new NHibernateDAL<FeriasPeriodoAquisitivoModel>(Session);
                Result = DAL.Select(new FeriasPeriodoAquisitivoModel());
            }
            return Result;
        }

        public IEnumerable<FeriasPeriodoAquisitivoModel> GetListFilter(Filter filterObj)
        {
            IList<FeriasPeriodoAquisitivoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FeriasPeriodoAquisitivoModel where " + filterObj.Where;
                NHibernateDAL<FeriasPeriodoAquisitivoModel> DAL = new NHibernateDAL<FeriasPeriodoAquisitivoModel>(Session);
                Result = DAL.SelectListSql<FeriasPeriodoAquisitivoModel>(Query);
            }
            return Result;
        }
		
        public FeriasPeriodoAquisitivoModel GetObject(int id)
        {
            FeriasPeriodoAquisitivoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriasPeriodoAquisitivoModel> DAL = new NHibernateDAL<FeriasPeriodoAquisitivoModel>(Session);
                Result = DAL.SelectId<FeriasPeriodoAquisitivoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FeriasPeriodoAquisitivoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriasPeriodoAquisitivoModel> DAL = new NHibernateDAL<FeriasPeriodoAquisitivoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FeriasPeriodoAquisitivoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriasPeriodoAquisitivoModel> DAL = new NHibernateDAL<FeriasPeriodoAquisitivoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FeriasPeriodoAquisitivoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FeriasPeriodoAquisitivoModel> DAL = new NHibernateDAL<FeriasPeriodoAquisitivoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}