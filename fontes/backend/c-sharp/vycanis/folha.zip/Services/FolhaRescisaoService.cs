using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaRescisaoService
    {

        public IEnumerable<FolhaRescisaoModel> GetList()
        {
            IList<FolhaRescisaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaRescisaoModel> DAL = new NHibernateDAL<FolhaRescisaoModel>(Session);
                Result = DAL.Select(new FolhaRescisaoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaRescisaoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaRescisaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaRescisaoModel where " + filterObj.Where;
                NHibernateDAL<FolhaRescisaoModel> DAL = new NHibernateDAL<FolhaRescisaoModel>(Session);
                Result = DAL.SelectListSql<FolhaRescisaoModel>(Query);
            }
            return Result;
        }
		
        public FolhaRescisaoModel GetObject(int id)
        {
            FolhaRescisaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaRescisaoModel> DAL = new NHibernateDAL<FolhaRescisaoModel>(Session);
                Result = DAL.SelectId<FolhaRescisaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaRescisaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaRescisaoModel> DAL = new NHibernateDAL<FolhaRescisaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaRescisaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaRescisaoModel> DAL = new NHibernateDAL<FolhaRescisaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaRescisaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaRescisaoModel> DAL = new NHibernateDAL<FolhaRescisaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}