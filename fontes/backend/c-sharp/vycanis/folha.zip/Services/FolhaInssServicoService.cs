using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaInssServicoService
    {

        public IEnumerable<FolhaInssServicoModel> GetList()
        {
            IList<FolhaInssServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssServicoModel> DAL = new NHibernateDAL<FolhaInssServicoModel>(Session);
                Result = DAL.Select(new FolhaInssServicoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaInssServicoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaInssServicoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaInssServicoModel where " + filterObj.Where;
                NHibernateDAL<FolhaInssServicoModel> DAL = new NHibernateDAL<FolhaInssServicoModel>(Session);
                Result = DAL.SelectListSql<FolhaInssServicoModel>(Query);
            }
            return Result;
        }
		
        public FolhaInssServicoModel GetObject(int id)
        {
            FolhaInssServicoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssServicoModel> DAL = new NHibernateDAL<FolhaInssServicoModel>(Session);
                Result = DAL.SelectId<FolhaInssServicoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaInssServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssServicoModel> DAL = new NHibernateDAL<FolhaInssServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaInssServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssServicoModel> DAL = new NHibernateDAL<FolhaInssServicoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaInssServicoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaInssServicoModel> DAL = new NHibernateDAL<FolhaInssServicoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}