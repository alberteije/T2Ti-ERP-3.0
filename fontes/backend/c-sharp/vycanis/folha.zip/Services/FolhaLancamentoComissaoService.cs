using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaLancamentoComissaoService
    {

        public IEnumerable<FolhaLancamentoComissaoModel> GetList()
        {
            IList<FolhaLancamentoComissaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoComissaoModel> DAL = new NHibernateDAL<FolhaLancamentoComissaoModel>(Session);
                Result = DAL.Select(new FolhaLancamentoComissaoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaLancamentoComissaoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaLancamentoComissaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaLancamentoComissaoModel where " + filterObj.Where;
                NHibernateDAL<FolhaLancamentoComissaoModel> DAL = new NHibernateDAL<FolhaLancamentoComissaoModel>(Session);
                Result = DAL.SelectListSql<FolhaLancamentoComissaoModel>(Query);
            }
            return Result;
        }
		
        public FolhaLancamentoComissaoModel GetObject(int id)
        {
            FolhaLancamentoComissaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoComissaoModel> DAL = new NHibernateDAL<FolhaLancamentoComissaoModel>(Session);
                Result = DAL.SelectId<FolhaLancamentoComissaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaLancamentoComissaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoComissaoModel> DAL = new NHibernateDAL<FolhaLancamentoComissaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaLancamentoComissaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoComissaoModel> DAL = new NHibernateDAL<FolhaLancamentoComissaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaLancamentoComissaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaLancamentoComissaoModel> DAL = new NHibernateDAL<FolhaLancamentoComissaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}