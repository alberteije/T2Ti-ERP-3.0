using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaTipoAfastamentoService
    {

        public IEnumerable<FolhaTipoAfastamentoModel> GetList()
        {
            IList<FolhaTipoAfastamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaTipoAfastamentoModel> DAL = new NHibernateDAL<FolhaTipoAfastamentoModel>(Session);
                Result = DAL.Select(new FolhaTipoAfastamentoModel());
            }
            return Result;
        }

        public IEnumerable<FolhaTipoAfastamentoModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaTipoAfastamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaTipoAfastamentoModel where " + filterObj.Where;
                NHibernateDAL<FolhaTipoAfastamentoModel> DAL = new NHibernateDAL<FolhaTipoAfastamentoModel>(Session);
                Result = DAL.SelectListSql<FolhaTipoAfastamentoModel>(Query);
            }
            return Result;
        }
		
        public FolhaTipoAfastamentoModel GetObject(int id)
        {
            FolhaTipoAfastamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaTipoAfastamentoModel> DAL = new NHibernateDAL<FolhaTipoAfastamentoModel>(Session);
                Result = DAL.SelectId<FolhaTipoAfastamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaTipoAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaTipoAfastamentoModel> DAL = new NHibernateDAL<FolhaTipoAfastamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaTipoAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaTipoAfastamentoModel> DAL = new NHibernateDAL<FolhaTipoAfastamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaTipoAfastamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaTipoAfastamentoModel> DAL = new NHibernateDAL<FolhaTipoAfastamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}