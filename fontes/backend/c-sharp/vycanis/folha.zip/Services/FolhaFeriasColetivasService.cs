using folha.Models;
using folha.NHibernate;
using ISession = NHibernate.ISession;

namespace folha.Services
{
    public class FolhaFeriasColetivasService
    {

        public IEnumerable<FolhaFeriasColetivasModel> GetList()
        {
            IList<FolhaFeriasColetivasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFeriasColetivasModel> DAL = new NHibernateDAL<FolhaFeriasColetivasModel>(Session);
                Result = DAL.Select(new FolhaFeriasColetivasModel());
            }
            return Result;
        }

        public IEnumerable<FolhaFeriasColetivasModel> GetListFilter(Filter filterObj)
        {
            IList<FolhaFeriasColetivasModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FolhaFeriasColetivasModel where " + filterObj.Where;
                NHibernateDAL<FolhaFeriasColetivasModel> DAL = new NHibernateDAL<FolhaFeriasColetivasModel>(Session);
                Result = DAL.SelectListSql<FolhaFeriasColetivasModel>(Query);
            }
            return Result;
        }
		
        public FolhaFeriasColetivasModel GetObject(int id)
        {
            FolhaFeriasColetivasModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFeriasColetivasModel> DAL = new NHibernateDAL<FolhaFeriasColetivasModel>(Session);
                Result = DAL.SelectId<FolhaFeriasColetivasModel>(id);
            }
            return Result;
        }
		
        public void Insert(FolhaFeriasColetivasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFeriasColetivasModel> DAL = new NHibernateDAL<FolhaFeriasColetivasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FolhaFeriasColetivasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFeriasColetivasModel> DAL = new NHibernateDAL<FolhaFeriasColetivasModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FolhaFeriasColetivasModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FolhaFeriasColetivasModel> DAL = new NHibernateDAL<FolhaFeriasColetivasModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}