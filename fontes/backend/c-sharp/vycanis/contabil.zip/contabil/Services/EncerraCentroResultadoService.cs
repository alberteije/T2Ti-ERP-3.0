using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class EncerraCentroResultadoService
    {

        public IEnumerable<EncerraCentroResultadoModel> GetList()
        {
            IList<EncerraCentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EncerraCentroResultadoModel> DAL = new NHibernateDAL<EncerraCentroResultadoModel>(Session);
                Result = DAL.Select(new EncerraCentroResultadoModel());
            }
            return Result;
        }

        public IEnumerable<EncerraCentroResultadoModel> GetListFilter(Filter filterObj)
        {
            IList<EncerraCentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from EncerraCentroResultadoModel where " + filterObj.Where;
                NHibernateDAL<EncerraCentroResultadoModel> DAL = new NHibernateDAL<EncerraCentroResultadoModel>(Session);
                Result = DAL.SelectListSql<EncerraCentroResultadoModel>(Query);
            }
            return Result;
        }
		
        public EncerraCentroResultadoModel GetObject(int id)
        {
            EncerraCentroResultadoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EncerraCentroResultadoModel> DAL = new NHibernateDAL<EncerraCentroResultadoModel>(Session);
                Result = DAL.SelectId<EncerraCentroResultadoModel>(id);
            }
            return Result;
        }
		
        public void Insert(EncerraCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EncerraCentroResultadoModel> DAL = new NHibernateDAL<EncerraCentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(EncerraCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EncerraCentroResultadoModel> DAL = new NHibernateDAL<EncerraCentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(EncerraCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<EncerraCentroResultadoModel> DAL = new NHibernateDAL<EncerraCentroResultadoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}