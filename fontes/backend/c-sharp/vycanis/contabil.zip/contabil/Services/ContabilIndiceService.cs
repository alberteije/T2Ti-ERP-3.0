using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilIndiceService
    {

        public IEnumerable<ContabilIndiceModel> GetList()
        {
            IList<ContabilIndiceModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilIndiceModel> DAL = new NHibernateDAL<ContabilIndiceModel>(Session);
                Result = DAL.Select(new ContabilIndiceModel());
            }
            return Result;
        }

        public IEnumerable<ContabilIndiceModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilIndiceModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilIndiceModel where " + filterObj.Where;
                NHibernateDAL<ContabilIndiceModel> DAL = new NHibernateDAL<ContabilIndiceModel>(Session);
                Result = DAL.SelectListSql<ContabilIndiceModel>(Query);
            }
            return Result;
        }
		
        public ContabilIndiceModel GetObject(int id)
        {
            ContabilIndiceModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilIndiceModel> DAL = new NHibernateDAL<ContabilIndiceModel>(Session);
                Result = DAL.SelectId<ContabilIndiceModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilIndiceModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilIndiceModel> DAL = new NHibernateDAL<ContabilIndiceModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilIndiceModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilIndiceModel> DAL = new NHibernateDAL<ContabilIndiceModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilIndiceModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilIndiceModel> DAL = new NHibernateDAL<ContabilIndiceModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}