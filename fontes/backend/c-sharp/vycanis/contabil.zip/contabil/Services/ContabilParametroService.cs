using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilParametroService
    {

        public IEnumerable<ContabilParametroModel> GetList()
        {
            IList<ContabilParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilParametroModel> DAL = new NHibernateDAL<ContabilParametroModel>(Session);
                Result = DAL.Select(new ContabilParametroModel());
            }
            return Result;
        }

        public IEnumerable<ContabilParametroModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilParametroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilParametroModel where " + filterObj.Where;
                NHibernateDAL<ContabilParametroModel> DAL = new NHibernateDAL<ContabilParametroModel>(Session);
                Result = DAL.SelectListSql<ContabilParametroModel>(Query);
            }
            return Result;
        }
		
        public ContabilParametroModel GetObject(int id)
        {
            ContabilParametroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilParametroModel> DAL = new NHibernateDAL<ContabilParametroModel>(Session);
                Result = DAL.SelectId<ContabilParametroModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilParametroModel> DAL = new NHibernateDAL<ContabilParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilParametroModel> DAL = new NHibernateDAL<ContabilParametroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilParametroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilParametroModel> DAL = new NHibernateDAL<ContabilParametroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}