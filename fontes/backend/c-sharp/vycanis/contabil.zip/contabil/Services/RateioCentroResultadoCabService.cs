using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class RateioCentroResultadoCabService
    {

        public IEnumerable<RateioCentroResultadoCabModel> GetList()
        {
            IList<RateioCentroResultadoCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RateioCentroResultadoCabModel> DAL = new NHibernateDAL<RateioCentroResultadoCabModel>(Session);
                Result = DAL.Select(new RateioCentroResultadoCabModel());
            }
            return Result;
        }

        public IEnumerable<RateioCentroResultadoCabModel> GetListFilter(Filter filterObj)
        {
            IList<RateioCentroResultadoCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from RateioCentroResultadoCabModel where " + filterObj.Where;
                NHibernateDAL<RateioCentroResultadoCabModel> DAL = new NHibernateDAL<RateioCentroResultadoCabModel>(Session);
                Result = DAL.SelectListSql<RateioCentroResultadoCabModel>(Query);
            }
            return Result;
        }
		
        public RateioCentroResultadoCabModel GetObject(int id)
        {
            RateioCentroResultadoCabModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RateioCentroResultadoCabModel> DAL = new NHibernateDAL<RateioCentroResultadoCabModel>(Session);
                Result = DAL.SelectId<RateioCentroResultadoCabModel>(id);
            }
            return Result;
        }
		
        public void Insert(RateioCentroResultadoCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RateioCentroResultadoCabModel> DAL = new NHibernateDAL<RateioCentroResultadoCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(RateioCentroResultadoCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RateioCentroResultadoCabModel> DAL = new NHibernateDAL<RateioCentroResultadoCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(RateioCentroResultadoCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RateioCentroResultadoCabModel> DAL = new NHibernateDAL<RateioCentroResultadoCabModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}