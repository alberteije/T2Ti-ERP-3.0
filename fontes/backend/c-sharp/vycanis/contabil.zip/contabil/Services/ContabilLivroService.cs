using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilLivroService
    {

        public IEnumerable<ContabilLivroModel> GetList()
        {
            IList<ContabilLivroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLivroModel> DAL = new NHibernateDAL<ContabilLivroModel>(Session);
                Result = DAL.Select(new ContabilLivroModel());
            }
            return Result;
        }

        public IEnumerable<ContabilLivroModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilLivroModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilLivroModel where " + filterObj.Where;
                NHibernateDAL<ContabilLivroModel> DAL = new NHibernateDAL<ContabilLivroModel>(Session);
                Result = DAL.SelectListSql<ContabilLivroModel>(Query);
            }
            return Result;
        }
		
        public ContabilLivroModel GetObject(int id)
        {
            ContabilLivroModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLivroModel> DAL = new NHibernateDAL<ContabilLivroModel>(Session);
                Result = DAL.SelectId<ContabilLivroModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilLivroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLivroModel> DAL = new NHibernateDAL<ContabilLivroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilLivroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLivroModel> DAL = new NHibernateDAL<ContabilLivroModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilLivroModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLivroModel> DAL = new NHibernateDAL<ContabilLivroModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}