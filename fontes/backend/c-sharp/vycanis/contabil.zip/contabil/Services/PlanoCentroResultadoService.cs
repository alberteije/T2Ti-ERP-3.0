using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class PlanoCentroResultadoService
    {

        public IEnumerable<PlanoCentroResultadoModel> GetList()
        {
            IList<PlanoCentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoCentroResultadoModel> DAL = new NHibernateDAL<PlanoCentroResultadoModel>(Session);
                Result = DAL.Select(new PlanoCentroResultadoModel());
            }
            return Result;
        }

        public IEnumerable<PlanoCentroResultadoModel> GetListFilter(Filter filterObj)
        {
            IList<PlanoCentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PlanoCentroResultadoModel where " + filterObj.Where;
                NHibernateDAL<PlanoCentroResultadoModel> DAL = new NHibernateDAL<PlanoCentroResultadoModel>(Session);
                Result = DAL.SelectListSql<PlanoCentroResultadoModel>(Query);
            }
            return Result;
        }
		
        public PlanoCentroResultadoModel GetObject(int id)
        {
            PlanoCentroResultadoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoCentroResultadoModel> DAL = new NHibernateDAL<PlanoCentroResultadoModel>(Session);
                Result = DAL.SelectId<PlanoCentroResultadoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PlanoCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoCentroResultadoModel> DAL = new NHibernateDAL<PlanoCentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PlanoCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoCentroResultadoModel> DAL = new NHibernateDAL<PlanoCentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PlanoCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoCentroResultadoModel> DAL = new NHibernateDAL<PlanoCentroResultadoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}