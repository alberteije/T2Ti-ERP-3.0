using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilContaService
    {

        public IEnumerable<ContabilContaModel> GetList()
        {
            IList<ContabilContaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaModel> DAL = new NHibernateDAL<ContabilContaModel>(Session);
                Result = DAL.Select(new ContabilContaModel());
            }
            return Result;
        }

        public IEnumerable<ContabilContaModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilContaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilContaModel where " + filterObj.Where;
                NHibernateDAL<ContabilContaModel> DAL = new NHibernateDAL<ContabilContaModel>(Session);
                Result = DAL.SelectListSql<ContabilContaModel>(Query);
            }
            return Result;
        }
		
        public ContabilContaModel GetObject(int id)
        {
            ContabilContaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaModel> DAL = new NHibernateDAL<ContabilContaModel>(Session);
                Result = DAL.SelectId<ContabilContaModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilContaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaModel> DAL = new NHibernateDAL<ContabilContaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilContaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaModel> DAL = new NHibernateDAL<ContabilContaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilContaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaModel> DAL = new NHibernateDAL<ContabilContaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}