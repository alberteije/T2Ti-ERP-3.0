using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilFechamentoService
    {

        public IEnumerable<ContabilFechamentoModel> GetList()
        {
            IList<ContabilFechamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilFechamentoModel> DAL = new NHibernateDAL<ContabilFechamentoModel>(Session);
                Result = DAL.Select(new ContabilFechamentoModel());
            }
            return Result;
        }

        public IEnumerable<ContabilFechamentoModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilFechamentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilFechamentoModel where " + filterObj.Where;
                NHibernateDAL<ContabilFechamentoModel> DAL = new NHibernateDAL<ContabilFechamentoModel>(Session);
                Result = DAL.SelectListSql<ContabilFechamentoModel>(Query);
            }
            return Result;
        }
		
        public ContabilFechamentoModel GetObject(int id)
        {
            ContabilFechamentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilFechamentoModel> DAL = new NHibernateDAL<ContabilFechamentoModel>(Session);
                Result = DAL.SelectId<ContabilFechamentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilFechamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilFechamentoModel> DAL = new NHibernateDAL<ContabilFechamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilFechamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilFechamentoModel> DAL = new NHibernateDAL<ContabilFechamentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilFechamentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilFechamentoModel> DAL = new NHibernateDAL<ContabilFechamentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}