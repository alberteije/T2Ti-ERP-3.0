using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilDreCabecalhoService
    {

        public IEnumerable<ContabilDreCabecalhoModel> GetList()
        {
            IList<ContabilDreCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilDreCabecalhoModel> DAL = new NHibernateDAL<ContabilDreCabecalhoModel>(Session);
                Result = DAL.Select(new ContabilDreCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<ContabilDreCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilDreCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilDreCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<ContabilDreCabecalhoModel> DAL = new NHibernateDAL<ContabilDreCabecalhoModel>(Session);
                Result = DAL.SelectListSql<ContabilDreCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public ContabilDreCabecalhoModel GetObject(int id)
        {
            ContabilDreCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilDreCabecalhoModel> DAL = new NHibernateDAL<ContabilDreCabecalhoModel>(Session);
                Result = DAL.SelectId<ContabilDreCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilDreCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilDreCabecalhoModel> DAL = new NHibernateDAL<ContabilDreCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilDreCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilDreCabecalhoModel> DAL = new NHibernateDAL<ContabilDreCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilDreCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilDreCabecalhoModel> DAL = new NHibernateDAL<ContabilDreCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}