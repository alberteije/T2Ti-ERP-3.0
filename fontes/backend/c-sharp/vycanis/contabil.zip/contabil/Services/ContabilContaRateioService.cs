using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilContaRateioService
    {

        public IEnumerable<ContabilContaRateioModel> GetList()
        {
            IList<ContabilContaRateioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaRateioModel> DAL = new NHibernateDAL<ContabilContaRateioModel>(Session);
                Result = DAL.Select(new ContabilContaRateioModel());
            }
            return Result;
        }

        public IEnumerable<ContabilContaRateioModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilContaRateioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilContaRateioModel where " + filterObj.Where;
                NHibernateDAL<ContabilContaRateioModel> DAL = new NHibernateDAL<ContabilContaRateioModel>(Session);
                Result = DAL.SelectListSql<ContabilContaRateioModel>(Query);
            }
            return Result;
        }
		
        public ContabilContaRateioModel GetObject(int id)
        {
            ContabilContaRateioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaRateioModel> DAL = new NHibernateDAL<ContabilContaRateioModel>(Session);
                Result = DAL.SelectId<ContabilContaRateioModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilContaRateioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaRateioModel> DAL = new NHibernateDAL<ContabilContaRateioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilContaRateioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaRateioModel> DAL = new NHibernateDAL<ContabilContaRateioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilContaRateioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilContaRateioModel> DAL = new NHibernateDAL<ContabilContaRateioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}