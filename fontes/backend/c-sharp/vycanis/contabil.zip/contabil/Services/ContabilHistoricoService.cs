using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilHistoricoService
    {

        public IEnumerable<ContabilHistoricoModel> GetList()
        {
            IList<ContabilHistoricoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilHistoricoModel> DAL = new NHibernateDAL<ContabilHistoricoModel>(Session);
                Result = DAL.Select(new ContabilHistoricoModel());
            }
            return Result;
        }

        public IEnumerable<ContabilHistoricoModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilHistoricoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilHistoricoModel where " + filterObj.Where;
                NHibernateDAL<ContabilHistoricoModel> DAL = new NHibernateDAL<ContabilHistoricoModel>(Session);
                Result = DAL.SelectListSql<ContabilHistoricoModel>(Query);
            }
            return Result;
        }
		
        public ContabilHistoricoModel GetObject(int id)
        {
            ContabilHistoricoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilHistoricoModel> DAL = new NHibernateDAL<ContabilHistoricoModel>(Session);
                Result = DAL.SelectId<ContabilHistoricoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilHistoricoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilHistoricoModel> DAL = new NHibernateDAL<ContabilHistoricoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilHistoricoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilHistoricoModel> DAL = new NHibernateDAL<ContabilHistoricoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilHistoricoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilHistoricoModel> DAL = new NHibernateDAL<ContabilHistoricoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}