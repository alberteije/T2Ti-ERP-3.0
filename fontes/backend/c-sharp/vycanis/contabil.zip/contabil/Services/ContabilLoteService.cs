using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilLoteService
    {

        public IEnumerable<ContabilLoteModel> GetList()
        {
            IList<ContabilLoteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLoteModel> DAL = new NHibernateDAL<ContabilLoteModel>(Session);
                Result = DAL.Select(new ContabilLoteModel());
            }
            return Result;
        }

        public IEnumerable<ContabilLoteModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilLoteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilLoteModel where " + filterObj.Where;
                NHibernateDAL<ContabilLoteModel> DAL = new NHibernateDAL<ContabilLoteModel>(Session);
                Result = DAL.SelectListSql<ContabilLoteModel>(Query);
            }
            return Result;
        }
		
        public ContabilLoteModel GetObject(int id)
        {
            ContabilLoteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLoteModel> DAL = new NHibernateDAL<ContabilLoteModel>(Session);
                Result = DAL.SelectId<ContabilLoteModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilLoteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLoteModel> DAL = new NHibernateDAL<ContabilLoteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilLoteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLoteModel> DAL = new NHibernateDAL<ContabilLoteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilLoteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLoteModel> DAL = new NHibernateDAL<ContabilLoteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}