using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class AidfAimdfService
    {

        public IEnumerable<AidfAimdfModel> GetList()
        {
            IList<AidfAimdfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AidfAimdfModel> DAL = new NHibernateDAL<AidfAimdfModel>(Session);
                Result = DAL.Select(new AidfAimdfModel());
            }
            return Result;
        }

        public IEnumerable<AidfAimdfModel> GetListFilter(Filter filterObj)
        {
            IList<AidfAimdfModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from AidfAimdfModel where " + filterObj.Where;
                NHibernateDAL<AidfAimdfModel> DAL = new NHibernateDAL<AidfAimdfModel>(Session);
                Result = DAL.SelectListSql<AidfAimdfModel>(Query);
            }
            return Result;
        }
		
        public AidfAimdfModel GetObject(int id)
        {
            AidfAimdfModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AidfAimdfModel> DAL = new NHibernateDAL<AidfAimdfModel>(Session);
                Result = DAL.SelectId<AidfAimdfModel>(id);
            }
            return Result;
        }
		
        public void Insert(AidfAimdfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AidfAimdfModel> DAL = new NHibernateDAL<AidfAimdfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(AidfAimdfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AidfAimdfModel> DAL = new NHibernateDAL<AidfAimdfModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(AidfAimdfModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AidfAimdfModel> DAL = new NHibernateDAL<AidfAimdfModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}