namespace contabil.Models
{
	public class ContabilLancamentoPadraoModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public string? Historico { get; set; } 

		public int? IdContaDebito { get; set; } 

		public int? IdContaCredito { get; set; } 

	}
}
