namespace contabil.Models
{
	public class PlanoContaModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

		public string? Mascara { get; set; } 

		public int? Niveis { get; set; } 

	}
}
