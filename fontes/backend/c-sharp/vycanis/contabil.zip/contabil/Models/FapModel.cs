namespace contabil.Models
{
	public class FapModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Fap { get; set; } 

		public System.Nullable<System.DateTime> DataInicial { get; set; } 

		public System.Nullable<System.DateTime> DataFinal { get; set; } 

	}
}
