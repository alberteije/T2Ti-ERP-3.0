namespace contabil.Models
{
	public class ContabilFechamentoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public string? CriterioLancamento { get; set; } 

	}
}
