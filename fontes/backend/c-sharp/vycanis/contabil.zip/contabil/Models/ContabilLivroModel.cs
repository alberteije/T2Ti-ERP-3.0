namespace contabil.Models
{
	public class ContabilLivroModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public string? FormaEscrituracao { get; set; } 

		public string? Descricao { get; set; } 

		private IList<ContabilTermoModel>? contabilTermoModelList; 
		public IList<ContabilTermoModel>? ContabilTermoModelList 
		{ 
			get 
			{ 
				return contabilTermoModelList; 
			} 
			set 
			{ 
				contabilTermoModelList = value; 
				foreach (ContabilTermoModel contabilTermoModel in contabilTermoModelList!) 
				{ 
					contabilTermoModel.ContabilLivroModel = this; 
				} 
			} 
		} 

	}
}
