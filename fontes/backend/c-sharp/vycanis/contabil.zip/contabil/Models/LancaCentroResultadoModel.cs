namespace contabil.Models
{
	public class LancaCentroResultadoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public System.Nullable<System.DateTime> DataLancamento { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

		public string? OrigemDeRateio { get; set; } 

		public string? Historico { get; set; } 

		public CentroResultadoModel? CentroResultadoModel { get; set; } 

	}
}
