namespace contabil.Models
{
	public class ContabilLancamentoDetalheModel
	{	
		public int? Id { get; set; } 

		public string? Tipo { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public string? Historico { get; set; } 

		public ContabilLancamentoCabecalhoModel? ContabilLancamentoCabecalhoModel { get; set; } 

		public ContabilHistoricoModel? ContabilHistoricoModel { get; set; } 

		public ContabilContaModel? ContabilContaModel { get; set; } 

	}
}
