namespace contabil.Models
{
	public class EncerraCentroResultadoModel
	{	
		public int? Id { get; set; } 

		public string? Competencia { get; set; } 

		public System.Nullable<System.Decimal> ValorTotal { get; set; } 

		public System.Nullable<System.Decimal> ValorSubRateio { get; set; } 

		public CentroResultadoModel? CentroResultadoModel { get; set; } 

	}
}
