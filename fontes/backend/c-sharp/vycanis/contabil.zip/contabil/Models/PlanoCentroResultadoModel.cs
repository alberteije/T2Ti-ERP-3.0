namespace contabil.Models
{
	public class PlanoCentroResultadoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Mascara { get; set; } 

		public int? Niveis { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

	}
}
