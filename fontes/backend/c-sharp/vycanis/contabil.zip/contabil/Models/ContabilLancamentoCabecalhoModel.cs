namespace contabil.Models
{
	public class ContabilLancamentoCabecalhoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataLancamento { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

		public string? Tipo { get; set; } 

		public string? Liberado { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public ContabilLoteModel? ContabilLoteModel { get; set; } 

		private IList<ContabilLancamentoDetalheModel>? contabilLancamentoDetalheModelList; 
		public IList<ContabilLancamentoDetalheModel>? ContabilLancamentoDetalheModelList 
		{ 
			get 
			{ 
				return contabilLancamentoDetalheModelList; 
			} 
			set 
			{ 
				contabilLancamentoDetalheModelList = value; 
				foreach (ContabilLancamentoDetalheModel contabilLancamentoDetalheModel in contabilLancamentoDetalheModelList!) 
				{ 
					contabilLancamentoDetalheModel.ContabilLancamentoCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
