namespace contabil.Models
{
	public class ContabilContaRateioModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> PorcentoRateio { get; set; } 

		public ContabilContaModel? ContabilContaModel { get; set; } 

		public CentroResultadoModel? CentroResultadoModel { get; set; } 

	}
}
