namespace contabil.Models
{
	public class CentroResultadoModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public string? Classificacao { get; set; } 

		public string? SofreRateiro { get; set; } 

		public PlanoCentroResultadoModel? PlanoCentroResultadoModel { get; set; } 

		private IList<CtResultadoNtFinanceiraModel>? ctResultadoNtFinanceiraModelList; 
		public IList<CtResultadoNtFinanceiraModel>? CtResultadoNtFinanceiraModelList 
		{ 
			get 
			{ 
				return ctResultadoNtFinanceiraModelList; 
			} 
			set 
			{ 
				ctResultadoNtFinanceiraModelList = value; 
				foreach (CtResultadoNtFinanceiraModel ctResultadoNtFinanceiraModel in ctResultadoNtFinanceiraModelList!) 
				{ 
					ctResultadoNtFinanceiraModel.CentroResultadoModel = this; 
				} 
			} 
		} 

	}
}
