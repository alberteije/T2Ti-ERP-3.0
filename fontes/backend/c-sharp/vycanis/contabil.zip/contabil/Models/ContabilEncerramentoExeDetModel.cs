namespace contabil.Models
{
	public class ContabilEncerramentoExeDetModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> SaldoAnterior { get; set; } 

		public System.Nullable<System.Decimal> ValorDebito { get; set; } 

		public System.Nullable<System.Decimal> ValorCredito { get; set; } 

		public System.Nullable<System.Decimal> Saldo { get; set; } 

		public ContabilEncerramentoExeCabModel? ContabilEncerramentoExeCabModel { get; set; } 

		public ContabilContaModel? ContabilContaModel { get; set; } 

	}
}
