namespace contabil.Models
{
	public class PlanoContaRefSpedModel
	{	
		public int? Id { get; set; } 

		public string? CodCtaRef { get; set; } 

		public System.Nullable<System.DateTime> InicioValidade { get; set; } 

		public System.Nullable<System.DateTime> FimValidade { get; set; } 

		public string? Tipo { get; set; } 

		public string? Descricao { get; set; } 

		public string? Orientacoes { get; set; } 

	}
}
