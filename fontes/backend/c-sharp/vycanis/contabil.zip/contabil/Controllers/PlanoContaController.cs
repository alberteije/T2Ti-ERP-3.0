using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("plano-conta")]
    [Produces("application/json")]
    public class PlanoContaController : Controller
    {
		private readonly PlanoContaService _service;

        public PlanoContaController()
        {
            _service = new PlanoContaService();
        }

        [HttpGet]
        public IActionResult GetListPlanoConta([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PlanoContaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PlanoConta]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPlanoConta")]
        public IActionResult GetObjectPlanoConta(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PlanoConta]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PlanoConta]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPlanoConta([FromBody]PlanoContaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PlanoConta]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPlanoConta", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PlanoConta]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePlanoConta([FromBody]PlanoContaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PlanoConta]", null));
                }

                _service.Update(objJson);

                return GetObjectPlanoConta(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PlanoConta]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePlanoConta(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PlanoConta]", ex));
            }
        }

    }
}