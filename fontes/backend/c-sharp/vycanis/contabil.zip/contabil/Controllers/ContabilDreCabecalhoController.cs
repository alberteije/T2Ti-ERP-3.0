using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-dre-cabecalho")]
    [Produces("application/json")]
    public class ContabilDreCabecalhoController : Controller
    {
		private readonly ContabilDreCabecalhoService _service;

        public ContabilDreCabecalhoController()
        {
            _service = new ContabilDreCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListContabilDreCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilDreCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilDreCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilDreCabecalho")]
        public IActionResult GetObjectContabilDreCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilDreCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilDreCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilDreCabecalho([FromBody]ContabilDreCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilDreCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilDreCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilDreCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilDreCabecalho([FromBody]ContabilDreCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilDreCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilDreCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilDreCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilDreCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilDreCabecalho]", ex));
            }
        }

    }
}