using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-lote")]
    [Produces("application/json")]
    public class ContabilLoteController : Controller
    {
		private readonly ContabilLoteService _service;

        public ContabilLoteController()
        {
            _service = new ContabilLoteService();
        }

        [HttpGet]
        public IActionResult GetListContabilLote([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilLoteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilLote]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilLote")]
        public IActionResult GetObjectContabilLote(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilLote]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilLote]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilLote([FromBody]ContabilLoteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilLote]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilLote", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilLote]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilLote([FromBody]ContabilLoteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilLote]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilLote(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilLote]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilLote(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilLote]", ex));
            }
        }

    }
}