using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("centro-resultado")]
    [Produces("application/json")]
    public class CentroResultadoController : Controller
    {
		private readonly CentroResultadoService _service;

        public CentroResultadoController()
        {
            _service = new CentroResultadoService();
        }

        [HttpGet]
        public IActionResult GetListCentroResultado([FromQuery]string filter)
        {
            try
            {
                IEnumerable<CentroResultadoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList CentroResultado]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectCentroResultado")]
        public IActionResult GetObjectCentroResultado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject CentroResultado]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject CentroResultado]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertCentroResultado([FromBody]CentroResultadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert CentroResultado]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectCentroResultado", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert CentroResultado]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateCentroResultado([FromBody]CentroResultadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update CentroResultado]", null));
                }

                _service.Update(objJson);

                return GetObjectCentroResultado(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update CentroResultado]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCentroResultado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete CentroResultado]", ex));
            }
        }

    }
}