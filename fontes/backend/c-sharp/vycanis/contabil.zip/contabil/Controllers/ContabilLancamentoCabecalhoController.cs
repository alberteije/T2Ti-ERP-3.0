using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-lancamento-cabecalho")]
    [Produces("application/json")]
    public class ContabilLancamentoCabecalhoController : Controller
    {
		private readonly ContabilLancamentoCabecalhoService _service;

        public ContabilLancamentoCabecalhoController()
        {
            _service = new ContabilLancamentoCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListContabilLancamentoCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilLancamentoCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilLancamentoCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilLancamentoCabecalho")]
        public IActionResult GetObjectContabilLancamentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilLancamentoCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilLancamentoCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilLancamentoCabecalho([FromBody]ContabilLancamentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilLancamentoCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilLancamentoCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilLancamentoCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilLancamentoCabecalho([FromBody]ContabilLancamentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilLancamentoCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilLancamentoCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilLancamentoCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilLancamentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilLancamentoCabecalho]", ex));
            }
        }

    }
}