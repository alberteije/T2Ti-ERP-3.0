using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("plano-conta-ref-sped")]
    [Produces("application/json")]
    public class PlanoContaRefSpedController : Controller
    {
		private readonly PlanoContaRefSpedService _service;

        public PlanoContaRefSpedController()
        {
            _service = new PlanoContaRefSpedService();
        }

        [HttpGet]
        public IActionResult GetListPlanoContaRefSped([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PlanoContaRefSpedModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PlanoContaRefSped]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPlanoContaRefSped")]
        public IActionResult GetObjectPlanoContaRefSped(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PlanoContaRefSped]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PlanoContaRefSped]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPlanoContaRefSped([FromBody]PlanoContaRefSpedModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PlanoContaRefSped]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPlanoContaRefSped", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PlanoContaRefSped]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePlanoContaRefSped([FromBody]PlanoContaRefSpedModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PlanoContaRefSped]", null));
                }

                _service.Update(objJson);

                return GetObjectPlanoContaRefSped(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PlanoContaRefSped]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePlanoContaRefSped(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PlanoContaRefSped]", ex));
            }
        }

    }
}