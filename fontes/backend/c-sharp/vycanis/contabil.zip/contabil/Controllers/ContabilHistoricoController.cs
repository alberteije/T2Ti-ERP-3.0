using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-historico")]
    [Produces("application/json")]
    public class ContabilHistoricoController : Controller
    {
		private readonly ContabilHistoricoService _service;

        public ContabilHistoricoController()
        {
            _service = new ContabilHistoricoService();
        }

        [HttpGet]
        public IActionResult GetListContabilHistorico([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilHistoricoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilHistorico]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilHistorico")]
        public IActionResult GetObjectContabilHistorico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilHistorico]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilHistorico]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilHistorico([FromBody]ContabilHistoricoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilHistorico]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilHistorico", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilHistorico]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilHistorico([FromBody]ContabilHistoricoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilHistorico]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilHistorico(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilHistorico]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilHistorico(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilHistorico]", ex));
            }
        }

    }
}