using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-conta")]
    [Produces("application/json")]
    public class ContabilContaController : Controller
    {
		private readonly ContabilContaService _service;

        public ContabilContaController()
        {
            _service = new ContabilContaService();
        }

        [HttpGet]
        public IActionResult GetListContabilConta([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilContaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilConta]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilConta")]
        public IActionResult GetObjectContabilConta(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilConta]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilConta]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilConta([FromBody]ContabilContaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilConta]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilConta", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilConta]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilConta([FromBody]ContabilContaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilConta]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilConta(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilConta]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilConta(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilConta]", ex));
            }
        }

    }
}