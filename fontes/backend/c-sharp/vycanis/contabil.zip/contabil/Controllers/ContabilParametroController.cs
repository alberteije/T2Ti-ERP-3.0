using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-parametro")]
    [Produces("application/json")]
    public class ContabilParametroController : Controller
    {
		private readonly ContabilParametroService _service;

        public ContabilParametroController()
        {
            _service = new ContabilParametroService();
        }

        [HttpGet]
        public IActionResult GetListContabilParametro([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilParametroModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilParametro]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilParametro")]
        public IActionResult GetObjectContabilParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilParametro]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilParametro]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilParametro([FromBody]ContabilParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilParametro]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilParametro", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilParametro]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilParametro([FromBody]ContabilParametroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilParametro]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilParametro(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilParametro]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilParametro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilParametro]", ex));
            }
        }

    }
}