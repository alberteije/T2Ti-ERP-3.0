using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("plano-centro-resultado")]
    [Produces("application/json")]
    public class PlanoCentroResultadoController : Controller
    {
		private readonly PlanoCentroResultadoService _service;

        public PlanoCentroResultadoController()
        {
            _service = new PlanoCentroResultadoService();
        }

        [HttpGet]
        public IActionResult GetListPlanoCentroResultado([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PlanoCentroResultadoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PlanoCentroResultado]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPlanoCentroResultado")]
        public IActionResult GetObjectPlanoCentroResultado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PlanoCentroResultado]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PlanoCentroResultado]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPlanoCentroResultado([FromBody]PlanoCentroResultadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PlanoCentroResultado]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPlanoCentroResultado", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PlanoCentroResultado]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePlanoCentroResultado([FromBody]PlanoCentroResultadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PlanoCentroResultado]", null));
                }

                _service.Update(objJson);

                return GetObjectPlanoCentroResultado(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PlanoCentroResultado]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePlanoCentroResultado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PlanoCentroResultado]", ex));
            }
        }

    }
}