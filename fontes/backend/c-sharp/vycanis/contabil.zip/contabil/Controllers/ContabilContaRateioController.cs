using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-conta-rateio")]
    [Produces("application/json")]
    public class ContabilContaRateioController : Controller
    {
		private readonly ContabilContaRateioService _service;

        public ContabilContaRateioController()
        {
            _service = new ContabilContaRateioService();
        }

        [HttpGet]
        public IActionResult GetListContabilContaRateio([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilContaRateioModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilContaRateio]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilContaRateio")]
        public IActionResult GetObjectContabilContaRateio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilContaRateio]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilContaRateio]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilContaRateio([FromBody]ContabilContaRateioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilContaRateio]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilContaRateio", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilContaRateio]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilContaRateio([FromBody]ContabilContaRateioModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilContaRateio]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilContaRateio(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilContaRateio]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilContaRateio(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilContaRateio]", ex));
            }
        }

    }
}