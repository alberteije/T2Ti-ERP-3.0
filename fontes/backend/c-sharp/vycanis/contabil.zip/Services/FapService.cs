using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class FapService
    {

        public IEnumerable<FapModel> GetList()
        {
            IList<FapModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FapModel> DAL = new NHibernateDAL<FapModel>(Session);
                Result = DAL.Select(new FapModel());
            }
            return Result;
        }

        public IEnumerable<FapModel> GetListFilter(Filter filterObj)
        {
            IList<FapModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from FapModel where " + filterObj.Where;
                NHibernateDAL<FapModel> DAL = new NHibernateDAL<FapModel>(Session);
                Result = DAL.SelectListSql<FapModel>(Query);
            }
            return Result;
        }
		
        public FapModel GetObject(int id)
        {
            FapModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FapModel> DAL = new NHibernateDAL<FapModel>(Session);
                Result = DAL.SelectId<FapModel>(id);
            }
            return Result;
        }
		
        public void Insert(FapModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FapModel> DAL = new NHibernateDAL<FapModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(FapModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FapModel> DAL = new NHibernateDAL<FapModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(FapModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<FapModel> DAL = new NHibernateDAL<FapModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}