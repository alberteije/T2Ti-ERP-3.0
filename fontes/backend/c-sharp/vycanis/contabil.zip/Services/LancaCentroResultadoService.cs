using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class LancaCentroResultadoService
    {

        public IEnumerable<LancaCentroResultadoModel> GetList()
        {
            IList<LancaCentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<LancaCentroResultadoModel> DAL = new NHibernateDAL<LancaCentroResultadoModel>(Session);
                Result = DAL.Select(new LancaCentroResultadoModel());
            }
            return Result;
        }

        public IEnumerable<LancaCentroResultadoModel> GetListFilter(Filter filterObj)
        {
            IList<LancaCentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from LancaCentroResultadoModel where " + filterObj.Where;
                NHibernateDAL<LancaCentroResultadoModel> DAL = new NHibernateDAL<LancaCentroResultadoModel>(Session);
                Result = DAL.SelectListSql<LancaCentroResultadoModel>(Query);
            }
            return Result;
        }
		
        public LancaCentroResultadoModel GetObject(int id)
        {
            LancaCentroResultadoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<LancaCentroResultadoModel> DAL = new NHibernateDAL<LancaCentroResultadoModel>(Session);
                Result = DAL.SelectId<LancaCentroResultadoModel>(id);
            }
            return Result;
        }
		
        public void Insert(LancaCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<LancaCentroResultadoModel> DAL = new NHibernateDAL<LancaCentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(LancaCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<LancaCentroResultadoModel> DAL = new NHibernateDAL<LancaCentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(LancaCentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<LancaCentroResultadoModel> DAL = new NHibernateDAL<LancaCentroResultadoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}