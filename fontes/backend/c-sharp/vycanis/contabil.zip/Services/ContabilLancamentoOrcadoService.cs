using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilLancamentoOrcadoService
    {

        public IEnumerable<ContabilLancamentoOrcadoModel> GetList()
        {
            IList<ContabilLancamentoOrcadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoOrcadoModel> DAL = new NHibernateDAL<ContabilLancamentoOrcadoModel>(Session);
                Result = DAL.Select(new ContabilLancamentoOrcadoModel());
            }
            return Result;
        }

        public IEnumerable<ContabilLancamentoOrcadoModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilLancamentoOrcadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilLancamentoOrcadoModel where " + filterObj.Where;
                NHibernateDAL<ContabilLancamentoOrcadoModel> DAL = new NHibernateDAL<ContabilLancamentoOrcadoModel>(Session);
                Result = DAL.SelectListSql<ContabilLancamentoOrcadoModel>(Query);
            }
            return Result;
        }
		
        public ContabilLancamentoOrcadoModel GetObject(int id)
        {
            ContabilLancamentoOrcadoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoOrcadoModel> DAL = new NHibernateDAL<ContabilLancamentoOrcadoModel>(Session);
                Result = DAL.SelectId<ContabilLancamentoOrcadoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilLancamentoOrcadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoOrcadoModel> DAL = new NHibernateDAL<ContabilLancamentoOrcadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilLancamentoOrcadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoOrcadoModel> DAL = new NHibernateDAL<ContabilLancamentoOrcadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilLancamentoOrcadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoOrcadoModel> DAL = new NHibernateDAL<ContabilLancamentoOrcadoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}