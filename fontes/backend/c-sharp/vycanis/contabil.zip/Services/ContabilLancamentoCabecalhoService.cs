using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilLancamentoCabecalhoService
    {

        public IEnumerable<ContabilLancamentoCabecalhoModel> GetList()
        {
            IList<ContabilLancamentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoCabecalhoModel> DAL = new NHibernateDAL<ContabilLancamentoCabecalhoModel>(Session);
                Result = DAL.Select(new ContabilLancamentoCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<ContabilLancamentoCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilLancamentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilLancamentoCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<ContabilLancamentoCabecalhoModel> DAL = new NHibernateDAL<ContabilLancamentoCabecalhoModel>(Session);
                Result = DAL.SelectListSql<ContabilLancamentoCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public ContabilLancamentoCabecalhoModel GetObject(int id)
        {
            ContabilLancamentoCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoCabecalhoModel> DAL = new NHibernateDAL<ContabilLancamentoCabecalhoModel>(Session);
                Result = DAL.SelectId<ContabilLancamentoCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilLancamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoCabecalhoModel> DAL = new NHibernateDAL<ContabilLancamentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilLancamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoCabecalhoModel> DAL = new NHibernateDAL<ContabilLancamentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilLancamentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoCabecalhoModel> DAL = new NHibernateDAL<ContabilLancamentoCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}