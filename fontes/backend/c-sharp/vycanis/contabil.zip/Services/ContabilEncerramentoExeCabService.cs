using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilEncerramentoExeCabService
    {

        public IEnumerable<ContabilEncerramentoExeCabModel> GetList()
        {
            IList<ContabilEncerramentoExeCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilEncerramentoExeCabModel> DAL = new NHibernateDAL<ContabilEncerramentoExeCabModel>(Session);
                Result = DAL.Select(new ContabilEncerramentoExeCabModel());
            }
            return Result;
        }

        public IEnumerable<ContabilEncerramentoExeCabModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilEncerramentoExeCabModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilEncerramentoExeCabModel where " + filterObj.Where;
                NHibernateDAL<ContabilEncerramentoExeCabModel> DAL = new NHibernateDAL<ContabilEncerramentoExeCabModel>(Session);
                Result = DAL.SelectListSql<ContabilEncerramentoExeCabModel>(Query);
            }
            return Result;
        }
		
        public ContabilEncerramentoExeCabModel GetObject(int id)
        {
            ContabilEncerramentoExeCabModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilEncerramentoExeCabModel> DAL = new NHibernateDAL<ContabilEncerramentoExeCabModel>(Session);
                Result = DAL.SelectId<ContabilEncerramentoExeCabModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilEncerramentoExeCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilEncerramentoExeCabModel> DAL = new NHibernateDAL<ContabilEncerramentoExeCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilEncerramentoExeCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilEncerramentoExeCabModel> DAL = new NHibernateDAL<ContabilEncerramentoExeCabModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilEncerramentoExeCabModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilEncerramentoExeCabModel> DAL = new NHibernateDAL<ContabilEncerramentoExeCabModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}