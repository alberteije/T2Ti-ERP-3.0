using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class ContabilLancamentoPadraoService
    {

        public IEnumerable<ContabilLancamentoPadraoModel> GetList()
        {
            IList<ContabilLancamentoPadraoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoPadraoModel> DAL = new NHibernateDAL<ContabilLancamentoPadraoModel>(Session);
                Result = DAL.Select(new ContabilLancamentoPadraoModel());
            }
            return Result;
        }

        public IEnumerable<ContabilLancamentoPadraoModel> GetListFilter(Filter filterObj)
        {
            IList<ContabilLancamentoPadraoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ContabilLancamentoPadraoModel where " + filterObj.Where;
                NHibernateDAL<ContabilLancamentoPadraoModel> DAL = new NHibernateDAL<ContabilLancamentoPadraoModel>(Session);
                Result = DAL.SelectListSql<ContabilLancamentoPadraoModel>(Query);
            }
            return Result;
        }
		
        public ContabilLancamentoPadraoModel GetObject(int id)
        {
            ContabilLancamentoPadraoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoPadraoModel> DAL = new NHibernateDAL<ContabilLancamentoPadraoModel>(Session);
                Result = DAL.SelectId<ContabilLancamentoPadraoModel>(id);
            }
            return Result;
        }
		
        public void Insert(ContabilLancamentoPadraoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoPadraoModel> DAL = new NHibernateDAL<ContabilLancamentoPadraoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ContabilLancamentoPadraoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoPadraoModel> DAL = new NHibernateDAL<ContabilLancamentoPadraoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ContabilLancamentoPadraoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ContabilLancamentoPadraoModel> DAL = new NHibernateDAL<ContabilLancamentoPadraoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}