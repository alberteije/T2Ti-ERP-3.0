using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class PlanoContaService
    {

        public IEnumerable<PlanoContaModel> GetList()
        {
            IList<PlanoContaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaModel> DAL = new NHibernateDAL<PlanoContaModel>(Session);
                Result = DAL.Select(new PlanoContaModel());
            }
            return Result;
        }

        public IEnumerable<PlanoContaModel> GetListFilter(Filter filterObj)
        {
            IList<PlanoContaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PlanoContaModel where " + filterObj.Where;
                NHibernateDAL<PlanoContaModel> DAL = new NHibernateDAL<PlanoContaModel>(Session);
                Result = DAL.SelectListSql<PlanoContaModel>(Query);
            }
            return Result;
        }
		
        public PlanoContaModel GetObject(int id)
        {
            PlanoContaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaModel> DAL = new NHibernateDAL<PlanoContaModel>(Session);
                Result = DAL.SelectId<PlanoContaModel>(id);
            }
            return Result;
        }
		
        public void Insert(PlanoContaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaModel> DAL = new NHibernateDAL<PlanoContaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PlanoContaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaModel> DAL = new NHibernateDAL<PlanoContaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PlanoContaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaModel> DAL = new NHibernateDAL<PlanoContaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}