using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class RegistroCartorioService
    {

        public IEnumerable<RegistroCartorioModel> GetList()
        {
            IList<RegistroCartorioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RegistroCartorioModel> DAL = new NHibernateDAL<RegistroCartorioModel>(Session);
                Result = DAL.Select(new RegistroCartorioModel());
            }
            return Result;
        }

        public IEnumerable<RegistroCartorioModel> GetListFilter(Filter filterObj)
        {
            IList<RegistroCartorioModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from RegistroCartorioModel where " + filterObj.Where;
                NHibernateDAL<RegistroCartorioModel> DAL = new NHibernateDAL<RegistroCartorioModel>(Session);
                Result = DAL.SelectListSql<RegistroCartorioModel>(Query);
            }
            return Result;
        }
		
        public RegistroCartorioModel GetObject(int id)
        {
            RegistroCartorioModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RegistroCartorioModel> DAL = new NHibernateDAL<RegistroCartorioModel>(Session);
                Result = DAL.SelectId<RegistroCartorioModel>(id);
            }
            return Result;
        }
		
        public void Insert(RegistroCartorioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RegistroCartorioModel> DAL = new NHibernateDAL<RegistroCartorioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(RegistroCartorioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RegistroCartorioModel> DAL = new NHibernateDAL<RegistroCartorioModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(RegistroCartorioModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RegistroCartorioModel> DAL = new NHibernateDAL<RegistroCartorioModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}