using contabil.Models;
using contabil.NHibernate;
using ISession = NHibernate.ISession;

namespace contabil.Services
{
    public class PlanoContaRefSpedService
    {

        public IEnumerable<PlanoContaRefSpedModel> GetList()
        {
            IList<PlanoContaRefSpedModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaRefSpedModel> DAL = new NHibernateDAL<PlanoContaRefSpedModel>(Session);
                Result = DAL.Select(new PlanoContaRefSpedModel());
            }
            return Result;
        }

        public IEnumerable<PlanoContaRefSpedModel> GetListFilter(Filter filterObj)
        {
            IList<PlanoContaRefSpedModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PlanoContaRefSpedModel where " + filterObj.Where;
                NHibernateDAL<PlanoContaRefSpedModel> DAL = new NHibernateDAL<PlanoContaRefSpedModel>(Session);
                Result = DAL.SelectListSql<PlanoContaRefSpedModel>(Query);
            }
            return Result;
        }
		
        public PlanoContaRefSpedModel GetObject(int id)
        {
            PlanoContaRefSpedModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaRefSpedModel> DAL = new NHibernateDAL<PlanoContaRefSpedModel>(Session);
                Result = DAL.SelectId<PlanoContaRefSpedModel>(id);
            }
            return Result;
        }
		
        public void Insert(PlanoContaRefSpedModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaRefSpedModel> DAL = new NHibernateDAL<PlanoContaRefSpedModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PlanoContaRefSpedModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaRefSpedModel> DAL = new NHibernateDAL<PlanoContaRefSpedModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PlanoContaRefSpedModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PlanoContaRefSpedModel> DAL = new NHibernateDAL<PlanoContaRefSpedModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}