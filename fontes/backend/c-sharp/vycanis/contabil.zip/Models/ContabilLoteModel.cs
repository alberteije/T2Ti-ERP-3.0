namespace contabil.Models
{
	public class ContabilLoteModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

		public System.Nullable<System.DateTime> DataLiberacao { get; set; } 

		public string? Liberado { get; set; } 

		public string? Programado { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

	}
}
