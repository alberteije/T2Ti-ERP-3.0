namespace contabil.Models
{
	public class ContabilIndiceValorModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataIndice { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public ContabilIndiceModel? ContabilIndiceModel { get; set; } 

	}
}
