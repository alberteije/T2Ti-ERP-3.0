namespace contabil.Models
{
	public class ContabilDreCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public string? Padrao { get; set; } 

		public string? PeriodoInicial { get; set; } 

		public string? PeriodoFinal { get; set; } 

		private IList<ContabilDreDetalheModel>? contabilDreDetalheModelList; 
		public IList<ContabilDreDetalheModel>? ContabilDreDetalheModelList 
		{ 
			get 
			{ 
				return contabilDreDetalheModelList; 
			} 
			set 
			{ 
				contabilDreDetalheModelList = value; 
				foreach (ContabilDreDetalheModel contabilDreDetalheModel in contabilDreDetalheModelList!) 
				{ 
					contabilDreDetalheModel.ContabilDreCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
