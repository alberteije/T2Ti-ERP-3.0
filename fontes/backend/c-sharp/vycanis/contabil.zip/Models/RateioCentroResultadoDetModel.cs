namespace contabil.Models
{
	public class RateioCentroResultadoDetModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> PorcentoRateio { get; set; } 

		public RateioCentroResultadoCabModel? RateioCentroResultadoCabModel { get; set; } 

		public CentroResultadoModel? CentroResultadoModel { get; set; } 

	}
}
