namespace contabil.Models
{
	public class ContabilLancamentoOrcadoModel
	{	
		public int? Id { get; set; } 

		public string? Ano { get; set; } 

		public System.Nullable<System.Decimal> Janeiro { get; set; } 

		public System.Nullable<System.Decimal> Fevereiro { get; set; } 

		public System.Nullable<System.Decimal> Marco { get; set; } 

		public System.Nullable<System.Decimal> Abril { get; set; } 

		public System.Nullable<System.Decimal> Maio { get; set; } 

		public System.Nullable<System.Decimal> Junho { get; set; } 

		public System.Nullable<System.Decimal> Julho { get; set; } 

		public System.Nullable<System.Decimal> Agosto { get; set; } 

		public System.Nullable<System.Decimal> Setembro { get; set; } 

		public System.Nullable<System.Decimal> Outubro { get; set; } 

		public System.Nullable<System.Decimal> Novembro { get; set; } 

		public System.Nullable<System.Decimal> Dezembro { get; set; } 

		public ContabilContaModel? ContabilContaModel { get; set; } 

	}
}
