namespace contabil.Models
{
	public class ContabilIndiceModel
	{	
		public int? Id { get; set; } 

		public string? Indice { get; set; } 

		public string? Periodicidade { get; set; } 

		public System.Nullable<System.DateTime> DiarioAPartirDe { get; set; } 

		public string? MensalMesAno { get; set; } 

		private IList<ContabilIndiceValorModel>? contabilIndiceValorModelList; 
		public IList<ContabilIndiceValorModel>? ContabilIndiceValorModelList 
		{ 
			get 
			{ 
				return contabilIndiceValorModelList; 
			} 
			set 
			{ 
				contabilIndiceValorModelList = value; 
				foreach (ContabilIndiceValorModel contabilIndiceValorModel in contabilIndiceValorModelList!) 
				{ 
					contabilIndiceValorModel.ContabilIndiceModel = this; 
				} 
			} 
		} 

	}
}
