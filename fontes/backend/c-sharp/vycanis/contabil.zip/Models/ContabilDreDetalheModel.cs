namespace contabil.Models
{
	public class ContabilDreDetalheModel
	{	
		public int? Id { get; set; } 

		public string? Classificacao { get; set; } 

		public string? Descricao { get; set; } 

		public string? FormaCalculo { get; set; } 

		public string? Sinal { get; set; } 

		public string? Natureza { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public ContabilDreCabecalhoModel? ContabilDreCabecalhoModel { get; set; } 

	}
}
