namespace contabil.Models
{
	public class ContabilContaModel
	{	
		public int? Id { get; set; } 

		public int? IdContabilConta { get; set; } 

		public string? Classificacao { get; set; } 

		public string? Tipo { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

		public string? Situacao { get; set; } 

		public string? Natureza { get; set; } 

		public string? PatrimonioResultado { get; set; } 

		public string? LivroCaixa { get; set; } 

		public string? Dfc { get; set; } 

		public string? CodigoEfd { get; set; } 

		public string? Ordem { get; set; } 

		public string? CodigoReduzido { get; set; } 

		public PlanoContaModel? PlanoContaModel { get; set; } 

		public PlanoContaRefSpedModel? PlanoContaRefSpedModel { get; set; } 

	}
}
