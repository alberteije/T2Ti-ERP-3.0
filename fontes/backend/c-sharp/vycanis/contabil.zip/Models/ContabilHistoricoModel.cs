namespace contabil.Models
{
	public class ContabilHistoricoModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public string? PedeComplemento { get; set; } 

		public string? Historico { get; set; } 

	}
}
