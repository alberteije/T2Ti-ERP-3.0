namespace contabil.Models
{
	public class AidfAimdfModel
	{	
		public int? Id { get; set; } 

		public int? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataValidade { get; set; } 

		public System.Nullable<System.DateTime> DataAutorizacao { get; set; } 

		public string? NumeroAutorizacao { get; set; } 

		public string? FormularioDisponivel { get; set; } 

	}
}
