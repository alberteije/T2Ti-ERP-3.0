namespace contabil.Models
{
	public class RateioCentroResultadoCabModel
	{	
		public int? Id { get; set; } 

		public string? Descricao { get; set; } 

		public CentroResultadoModel? CentroResultadoModel { get; set; } 

		private IList<RateioCentroResultadoDetModel>? rateioCentroResultadoDetModelList; 
		public IList<RateioCentroResultadoDetModel>? RateioCentroResultadoDetModelList 
		{ 
			get 
			{ 
				return rateioCentroResultadoDetModelList; 
			} 
			set 
			{ 
				rateioCentroResultadoDetModelList = value; 
				foreach (RateioCentroResultadoDetModel rateioCentroResultadoDetModel in rateioCentroResultadoDetModelList!) 
				{ 
					rateioCentroResultadoDetModel.RateioCentroResultadoCabModel = this; 
				} 
			} 
		} 

	}
}
