namespace contabil.Models
{
	public class ContabilEncerramentoExeCabModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataInicio { get; set; } 

		public System.Nullable<System.DateTime> DataFim { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

		public string? Motivo { get; set; } 

		private IList<ContabilEncerramentoExeDetModel>? contabilEncerramentoExeDetModelList; 
		public IList<ContabilEncerramentoExeDetModel>? ContabilEncerramentoExeDetModelList 
		{ 
			get 
			{ 
				return contabilEncerramentoExeDetModelList; 
			} 
			set 
			{ 
				contabilEncerramentoExeDetModelList = value; 
				foreach (ContabilEncerramentoExeDetModel contabilEncerramentoExeDetModel in contabilEncerramentoExeDetModelList!) 
				{ 
					contabilEncerramentoExeDetModel.ContabilEncerramentoExeCabModel = this; 
				} 
			} 
		} 

	}
}
