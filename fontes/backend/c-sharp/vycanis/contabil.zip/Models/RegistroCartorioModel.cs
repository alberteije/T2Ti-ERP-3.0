namespace contabil.Models
{
	public class RegistroCartorioModel
	{	
		public int? Id { get; set; } 

		public string? NomeCartorio { get; set; } 

		public System.Nullable<System.DateTime> DataRegistro { get; set; } 

		public int? Numero { get; set; } 

		public int? Folha { get; set; } 

		public int? Livro { get; set; } 

		public string? Nire { get; set; } 

	}
}
