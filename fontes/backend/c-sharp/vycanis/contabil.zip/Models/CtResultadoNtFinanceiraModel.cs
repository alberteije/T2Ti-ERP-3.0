namespace contabil.Models
{
	public class CtResultadoNtFinanceiraModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.Decimal> PercentualRateio { get; set; } 

		public FinNaturezaFinanceiraModel? FinNaturezaFinanceiraModel { get; set; } 

		public CentroResultadoModel? CentroResultadoModel { get; set; } 

	}
}
