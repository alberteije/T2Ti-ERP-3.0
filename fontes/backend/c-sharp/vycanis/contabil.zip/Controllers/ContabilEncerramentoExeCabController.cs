using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-encerramento-exe-cab")]
    [Produces("application/json")]
    public class ContabilEncerramentoExeCabController : Controller
    {
		private readonly ContabilEncerramentoExeCabService _service;

        public ContabilEncerramentoExeCabController()
        {
            _service = new ContabilEncerramentoExeCabService();
        }

        [HttpGet]
        public IActionResult GetListContabilEncerramentoExeCab([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilEncerramentoExeCabModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilEncerramentoExeCab]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilEncerramentoExeCab")]
        public IActionResult GetObjectContabilEncerramentoExeCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilEncerramentoExeCab]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilEncerramentoExeCab]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilEncerramentoExeCab([FromBody]ContabilEncerramentoExeCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilEncerramentoExeCab]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilEncerramentoExeCab", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilEncerramentoExeCab]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilEncerramentoExeCab([FromBody]ContabilEncerramentoExeCabModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilEncerramentoExeCab]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilEncerramentoExeCab(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilEncerramentoExeCab]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilEncerramentoExeCab(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilEncerramentoExeCab]", ex));
            }
        }

    }
}