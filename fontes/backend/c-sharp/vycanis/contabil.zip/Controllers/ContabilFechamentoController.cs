using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-fechamento")]
    [Produces("application/json")]
    public class ContabilFechamentoController : Controller
    {
		private readonly ContabilFechamentoService _service;

        public ContabilFechamentoController()
        {
            _service = new ContabilFechamentoService();
        }

        [HttpGet]
        public IActionResult GetListContabilFechamento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilFechamentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilFechamento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilFechamento")]
        public IActionResult GetObjectContabilFechamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilFechamento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilFechamento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilFechamento([FromBody]ContabilFechamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilFechamento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilFechamento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilFechamento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilFechamento([FromBody]ContabilFechamentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilFechamento]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilFechamento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilFechamento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilFechamento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilFechamento]", ex));
            }
        }

    }
}