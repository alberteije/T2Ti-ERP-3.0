using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-indice")]
    [Produces("application/json")]
    public class ContabilIndiceController : Controller
    {
		private readonly ContabilIndiceService _service;

        public ContabilIndiceController()
        {
            _service = new ContabilIndiceService();
        }

        [HttpGet]
        public IActionResult GetListContabilIndice([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilIndiceModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilIndice]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilIndice")]
        public IActionResult GetObjectContabilIndice(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilIndice]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilIndice]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilIndice([FromBody]ContabilIndiceModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilIndice]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilIndice", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilIndice]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilIndice([FromBody]ContabilIndiceModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilIndice]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilIndice(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilIndice]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilIndice(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilIndice]", ex));
            }
        }

    }
}