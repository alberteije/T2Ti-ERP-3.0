using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-lancamento-orcado")]
    [Produces("application/json")]
    public class ContabilLancamentoOrcadoController : Controller
    {
		private readonly ContabilLancamentoOrcadoService _service;

        public ContabilLancamentoOrcadoController()
        {
            _service = new ContabilLancamentoOrcadoService();
        }

        [HttpGet]
        public IActionResult GetListContabilLancamentoOrcado([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilLancamentoOrcadoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilLancamentoOrcado]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilLancamentoOrcado")]
        public IActionResult GetObjectContabilLancamentoOrcado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilLancamentoOrcado]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilLancamentoOrcado]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilLancamentoOrcado([FromBody]ContabilLancamentoOrcadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilLancamentoOrcado]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilLancamentoOrcado", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilLancamentoOrcado]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilLancamentoOrcado([FromBody]ContabilLancamentoOrcadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilLancamentoOrcado]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilLancamentoOrcado(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilLancamentoOrcado]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilLancamentoOrcado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilLancamentoOrcado]", ex));
            }
        }

    }
}