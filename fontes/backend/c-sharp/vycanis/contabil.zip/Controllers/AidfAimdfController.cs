using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("aidf-aimdf")]
    [Produces("application/json")]
    public class AidfAimdfController : Controller
    {
		private readonly AidfAimdfService _service;

        public AidfAimdfController()
        {
            _service = new AidfAimdfService();
        }

        [HttpGet]
        public IActionResult GetListAidfAimdf([FromQuery]string filter)
        {
            try
            {
                IEnumerable<AidfAimdfModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList AidfAimdf]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectAidfAimdf")]
        public IActionResult GetObjectAidfAimdf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject AidfAimdf]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject AidfAimdf]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertAidfAimdf([FromBody]AidfAimdfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert AidfAimdf]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectAidfAimdf", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert AidfAimdf]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateAidfAimdf([FromBody]AidfAimdfModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update AidfAimdf]", null));
                }

                _service.Update(objJson);

                return GetObjectAidfAimdf(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update AidfAimdf]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteAidfAimdf(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete AidfAimdf]", ex));
            }
        }

    }
}