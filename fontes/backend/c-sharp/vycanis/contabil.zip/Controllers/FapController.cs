using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("fap")]
    [Produces("application/json")]
    public class FapController : Controller
    {
		private readonly FapService _service;

        public FapController()
        {
            _service = new FapService();
        }

        [HttpGet]
        public IActionResult GetListFap([FromQuery]string filter)
        {
            try
            {
                IEnumerable<FapModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Fap]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectFap")]
        public IActionResult GetObjectFap(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Fap]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Fap]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertFap([FromBody]FapModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Fap]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectFap", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Fap]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateFap([FromBody]FapModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Fap]", null));
                }

                _service.Update(objJson);

                return GetObjectFap(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Fap]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteFap(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Fap]", ex));
            }
        }

    }
}