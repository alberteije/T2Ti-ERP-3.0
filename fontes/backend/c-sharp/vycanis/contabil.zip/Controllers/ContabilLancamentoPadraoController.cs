using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-lancamento-padrao")]
    [Produces("application/json")]
    public class ContabilLancamentoPadraoController : Controller
    {
		private readonly ContabilLancamentoPadraoService _service;

        public ContabilLancamentoPadraoController()
        {
            _service = new ContabilLancamentoPadraoService();
        }

        [HttpGet]
        public IActionResult GetListContabilLancamentoPadrao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilLancamentoPadraoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilLancamentoPadrao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilLancamentoPadrao")]
        public IActionResult GetObjectContabilLancamentoPadrao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilLancamentoPadrao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilLancamentoPadrao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilLancamentoPadrao([FromBody]ContabilLancamentoPadraoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilLancamentoPadrao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilLancamentoPadrao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilLancamentoPadrao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilLancamentoPadrao([FromBody]ContabilLancamentoPadraoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilLancamentoPadrao]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilLancamentoPadrao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilLancamentoPadrao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilLancamentoPadrao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilLancamentoPadrao]", ex));
            }
        }

    }
}