using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("encerra-centro-resultado")]
    [Produces("application/json")]
    public class EncerraCentroResultadoController : Controller
    {
		private readonly EncerraCentroResultadoService _service;

        public EncerraCentroResultadoController()
        {
            _service = new EncerraCentroResultadoService();
        }

        [HttpGet]
        public IActionResult GetListEncerraCentroResultado([FromQuery]string filter)
        {
            try
            {
                IEnumerable<EncerraCentroResultadoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList EncerraCentroResultado]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectEncerraCentroResultado")]
        public IActionResult GetObjectEncerraCentroResultado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject EncerraCentroResultado]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject EncerraCentroResultado]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertEncerraCentroResultado([FromBody]EncerraCentroResultadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert EncerraCentroResultado]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectEncerraCentroResultado", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert EncerraCentroResultado]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateEncerraCentroResultado([FromBody]EncerraCentroResultadoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update EncerraCentroResultado]", null));
                }

                _service.Update(objJson);

                return GetObjectEncerraCentroResultado(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update EncerraCentroResultado]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEncerraCentroResultado(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete EncerraCentroResultado]", ex));
            }
        }

    }
}