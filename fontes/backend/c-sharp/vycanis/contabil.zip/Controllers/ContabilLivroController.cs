using Microsoft.AspNetCore.Mvc;
using contabil.Models;
using contabil.Services;

namespace contabil.Controllers
{
    [Route("contabil-livro")]
    [Produces("application/json")]
    public class ContabilLivroController : Controller
    {
		private readonly ContabilLivroService _service;

        public ContabilLivroController()
        {
            _service = new ContabilLivroService();
        }

        [HttpGet]
        public IActionResult GetListContabilLivro([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ContabilLivroModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ContabilLivro]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectContabilLivro")]
        public IActionResult GetObjectContabilLivro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ContabilLivro]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ContabilLivro]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertContabilLivro([FromBody]ContabilLivroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ContabilLivro]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectContabilLivro", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ContabilLivro]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateContabilLivro([FromBody]ContabilLivroModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ContabilLivro]", null));
                }

                _service.Update(objJson);

                return GetObjectContabilLivro(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ContabilLivro]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteContabilLivro(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ContabilLivro]", ex));
            }
        }

    }
}