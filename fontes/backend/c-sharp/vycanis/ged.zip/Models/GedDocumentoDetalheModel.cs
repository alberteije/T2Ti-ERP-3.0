namespace ged.Models
{
	public class GedDocumentoDetalheModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public string? PalavrasChave { get; set; } 

		public string? PodeExcluir { get; set; } 

		public string? PodeAlterar { get; set; } 

		public string? Assinado { get; set; } 

		public System.Nullable<System.DateTime> DataFimVigencia { get; set; } 

		public System.Nullable<System.DateTime> DataExclusao { get; set; } 

		public GedTipoDocumentoModel? GedTipoDocumentoModel { get; set; } 

		public GedDocumentoCabecalhoModel? GedDocumentoCabecalhoModel { get; set; } 

	}
}
