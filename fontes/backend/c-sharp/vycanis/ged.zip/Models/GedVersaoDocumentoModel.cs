namespace ged.Models
{
	public class GedVersaoDocumentoModel
	{	
		public int? Id { get; set; } 

		public string? Acao { get; set; } 

		public int? Versao { get; set; } 

		public System.Nullable<System.DateTime> DataVersao { get; set; } 

		public string? HoraVersao { get; set; } 

		public string? HashArquivo { get; set; } 

		public string? Caminho { get; set; } 

		public GedDocumentoDetalheModel? GedDocumentoDetalheModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
