namespace ged.Models
{
	public class GedTipoDocumentoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.Decimal> TamanhoMaximo { get; set; } 

	}
}
