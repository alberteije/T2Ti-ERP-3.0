namespace ged.Models
{
	public class GedDocumentoCabecalhoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.DateTime> DataInclusao { get; set; } 

		public string? Descricao { get; set; } 

		private IList<GedDocumentoDetalheModel>? gedDocumentoDetalheModelList; 
		public IList<GedDocumentoDetalheModel>? GedDocumentoDetalheModelList 
		{ 
			get 
			{ 
				return gedDocumentoDetalheModelList; 
			} 
			set 
			{ 
				gedDocumentoDetalheModelList = value; 
				foreach (GedDocumentoDetalheModel gedDocumentoDetalheModel in gedDocumentoDetalheModelList!) 
				{ 
					gedDocumentoDetalheModel.GedDocumentoCabecalhoModel = this; 
				} 
			} 
		} 

	}
}
