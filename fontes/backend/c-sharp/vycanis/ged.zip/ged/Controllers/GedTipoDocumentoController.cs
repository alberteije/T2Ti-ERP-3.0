using Microsoft.AspNetCore.Mvc;
using ged.Models;
using ged.Services;

namespace ged.Controllers
{
    [Route("ged-tipo-documento")]
    [Produces("application/json")]
    public class GedTipoDocumentoController : Controller
    {
		private readonly GedTipoDocumentoService _service;

        public GedTipoDocumentoController()
        {
            _service = new GedTipoDocumentoService();
        }

        [HttpGet]
        public IActionResult GetListGedTipoDocumento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<GedTipoDocumentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList GedTipoDocumento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectGedTipoDocumento")]
        public IActionResult GetObjectGedTipoDocumento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject GedTipoDocumento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject GedTipoDocumento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertGedTipoDocumento([FromBody]GedTipoDocumentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert GedTipoDocumento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectGedTipoDocumento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert GedTipoDocumento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateGedTipoDocumento([FromBody]GedTipoDocumentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update GedTipoDocumento]", null));
                }

                _service.Update(objJson);

                return GetObjectGedTipoDocumento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update GedTipoDocumento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteGedTipoDocumento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete GedTipoDocumento]", ex));
            }
        }

    }
}