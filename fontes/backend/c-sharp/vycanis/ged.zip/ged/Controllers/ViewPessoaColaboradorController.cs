using Microsoft.AspNetCore.Mvc;
using ged.Models;
using ged.Services;

namespace ged.Controllers
{
    [Route("view-pessoa-colaborador")]
    [Produces("application/json")]
    public class ViewPessoaColaboradorController : Controller
    {
		private readonly ViewPessoaColaboradorService _service;

        public ViewPessoaColaboradorController()
        {
            _service = new ViewPessoaColaboradorService();
        }

        [HttpGet]
        public IActionResult GetListViewPessoaColaborador([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ViewPessoaColaboradorModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ViewPessoaColaborador]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectViewPessoaColaborador")]
        public IActionResult GetObjectViewPessoaColaborador(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ViewPessoaColaborador]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ViewPessoaColaborador]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertViewPessoaColaborador([FromBody]ViewPessoaColaboradorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ViewPessoaColaborador]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectViewPessoaColaborador", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ViewPessoaColaborador]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateViewPessoaColaborador([FromBody]ViewPessoaColaboradorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ViewPessoaColaborador]", null));
                }

                _service.Update(objJson);

                return GetObjectViewPessoaColaborador(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ViewPessoaColaborador]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteViewPessoaColaborador(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ViewPessoaColaborador]", ex));
            }
        }

    }
}