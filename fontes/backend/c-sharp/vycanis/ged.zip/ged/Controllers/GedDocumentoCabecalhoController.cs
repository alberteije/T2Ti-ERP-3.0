using Microsoft.AspNetCore.Mvc;
using ged.Models;
using ged.Services;

namespace ged.Controllers
{
    [Route("ged-documento-cabecalho")]
    [Produces("application/json")]
    public class GedDocumentoCabecalhoController : Controller
    {
		private readonly GedDocumentoCabecalhoService _service;

        public GedDocumentoCabecalhoController()
        {
            _service = new GedDocumentoCabecalhoService();
        }

        [HttpGet]
        public IActionResult GetListGedDocumentoCabecalho([FromQuery]string filter)
        {
            try
            {
                IEnumerable<GedDocumentoCabecalhoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList GedDocumentoCabecalho]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectGedDocumentoCabecalho")]
        public IActionResult GetObjectGedDocumentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject GedDocumentoCabecalho]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject GedDocumentoCabecalho]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertGedDocumentoCabecalho([FromBody]GedDocumentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert GedDocumentoCabecalho]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectGedDocumentoCabecalho", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert GedDocumentoCabecalho]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateGedDocumentoCabecalho([FromBody]GedDocumentoCabecalhoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update GedDocumentoCabecalho]", null));
                }

                _service.Update(objJson);

                return GetObjectGedDocumentoCabecalho(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update GedDocumentoCabecalho]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteGedDocumentoCabecalho(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete GedDocumentoCabecalho]", ex));
            }
        }

    }
}