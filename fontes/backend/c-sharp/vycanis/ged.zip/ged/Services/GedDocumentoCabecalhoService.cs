using ged.Models;
using ged.NHibernate;
using ISession = NHibernate.ISession;

namespace ged.Services
{
    public class GedDocumentoCabecalhoService
    {

        public IEnumerable<GedDocumentoCabecalhoModel> GetList()
        {
            IList<GedDocumentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedDocumentoCabecalhoModel> DAL = new NHibernateDAL<GedDocumentoCabecalhoModel>(Session);
                Result = DAL.Select(new GedDocumentoCabecalhoModel());
            }
            return Result;
        }

        public IEnumerable<GedDocumentoCabecalhoModel> GetListFilter(Filter filterObj)
        {
            IList<GedDocumentoCabecalhoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from GedDocumentoCabecalhoModel where " + filterObj.Where;
                NHibernateDAL<GedDocumentoCabecalhoModel> DAL = new NHibernateDAL<GedDocumentoCabecalhoModel>(Session);
                Result = DAL.SelectListSql<GedDocumentoCabecalhoModel>(Query);
            }
            return Result;
        }
		
        public GedDocumentoCabecalhoModel GetObject(int id)
        {
            GedDocumentoCabecalhoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedDocumentoCabecalhoModel> DAL = new NHibernateDAL<GedDocumentoCabecalhoModel>(Session);
                Result = DAL.SelectId<GedDocumentoCabecalhoModel>(id);
            }
            return Result;
        }
		
        public void Insert(GedDocumentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedDocumentoCabecalhoModel> DAL = new NHibernateDAL<GedDocumentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(GedDocumentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedDocumentoCabecalhoModel> DAL = new NHibernateDAL<GedDocumentoCabecalhoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(GedDocumentoCabecalhoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedDocumentoCabecalhoModel> DAL = new NHibernateDAL<GedDocumentoCabecalhoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}