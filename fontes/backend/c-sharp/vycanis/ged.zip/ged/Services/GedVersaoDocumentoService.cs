using ged.Models;
using ged.NHibernate;
using ISession = NHibernate.ISession;

namespace ged.Services
{
    public class GedVersaoDocumentoService
    {

        public IEnumerable<GedVersaoDocumentoModel> GetList()
        {
            IList<GedVersaoDocumentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedVersaoDocumentoModel> DAL = new NHibernateDAL<GedVersaoDocumentoModel>(Session);
                Result = DAL.Select(new GedVersaoDocumentoModel());
            }
            return Result;
        }

        public IEnumerable<GedVersaoDocumentoModel> GetListFilter(Filter filterObj)
        {
            IList<GedVersaoDocumentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from GedVersaoDocumentoModel where " + filterObj.Where;
                NHibernateDAL<GedVersaoDocumentoModel> DAL = new NHibernateDAL<GedVersaoDocumentoModel>(Session);
                Result = DAL.SelectListSql<GedVersaoDocumentoModel>(Query);
            }
            return Result;
        }
		
        public GedVersaoDocumentoModel GetObject(int id)
        {
            GedVersaoDocumentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedVersaoDocumentoModel> DAL = new NHibernateDAL<GedVersaoDocumentoModel>(Session);
                Result = DAL.SelectId<GedVersaoDocumentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(GedVersaoDocumentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedVersaoDocumentoModel> DAL = new NHibernateDAL<GedVersaoDocumentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(GedVersaoDocumentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedVersaoDocumentoModel> DAL = new NHibernateDAL<GedVersaoDocumentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(GedVersaoDocumentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedVersaoDocumentoModel> DAL = new NHibernateDAL<GedVersaoDocumentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}