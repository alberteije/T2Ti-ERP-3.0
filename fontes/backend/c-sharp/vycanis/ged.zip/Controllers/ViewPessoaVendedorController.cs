using Microsoft.AspNetCore.Mvc;
using ged.Models;
using ged.Services;

namespace ged.Controllers
{
    [Route("view-pessoa-vendedor")]
    [Produces("application/json")]
    public class ViewPessoaVendedorController : Controller
    {
		private readonly ViewPessoaVendedorService _service;

        public ViewPessoaVendedorController()
        {
            _service = new ViewPessoaVendedorService();
        }

        [HttpGet]
        public IActionResult GetListViewPessoaVendedor([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ViewPessoaVendedorModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ViewPessoaVendedor]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectViewPessoaVendedor")]
        public IActionResult GetObjectViewPessoaVendedor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ViewPessoaVendedor]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ViewPessoaVendedor]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertViewPessoaVendedor([FromBody]ViewPessoaVendedorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ViewPessoaVendedor]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectViewPessoaVendedor", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ViewPessoaVendedor]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateViewPessoaVendedor([FromBody]ViewPessoaVendedorModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ViewPessoaVendedor]", null));
                }

                _service.Update(objJson);

                return GetObjectViewPessoaVendedor(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ViewPessoaVendedor]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteViewPessoaVendedor(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ViewPessoaVendedor]", ex));
            }
        }

    }
}