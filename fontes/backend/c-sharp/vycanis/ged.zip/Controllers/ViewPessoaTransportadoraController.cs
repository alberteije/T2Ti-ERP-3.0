using Microsoft.AspNetCore.Mvc;
using ged.Models;
using ged.Services;

namespace ged.Controllers
{
    [Route("view-pessoa-transportadora")]
    [Produces("application/json")]
    public class ViewPessoaTransportadoraController : Controller
    {
		private readonly ViewPessoaTransportadoraService _service;

        public ViewPessoaTransportadoraController()
        {
            _service = new ViewPessoaTransportadoraService();
        }

        [HttpGet]
        public IActionResult GetListViewPessoaTransportadora([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ViewPessoaTransportadoraModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ViewPessoaTransportadora]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectViewPessoaTransportadora")]
        public IActionResult GetObjectViewPessoaTransportadora(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ViewPessoaTransportadora]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ViewPessoaTransportadora]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertViewPessoaTransportadora([FromBody]ViewPessoaTransportadoraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ViewPessoaTransportadora]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectViewPessoaTransportadora", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ViewPessoaTransportadora]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateViewPessoaTransportadora([FromBody]ViewPessoaTransportadoraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ViewPessoaTransportadora]", null));
                }

                _service.Update(objJson);

                return GetObjectViewPessoaTransportadora(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ViewPessoaTransportadora]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteViewPessoaTransportadora(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ViewPessoaTransportadora]", ex));
            }
        }

    }
}