using Microsoft.AspNetCore.Mvc;
using ged.Models;
using ged.Services;

namespace ged.Controllers
{
    [Route("ged-versao-documento")]
    [Produces("application/json")]
    public class GedVersaoDocumentoController : Controller
    {
		private readonly GedVersaoDocumentoService _service;

        public GedVersaoDocumentoController()
        {
            _service = new GedVersaoDocumentoService();
        }

        [HttpGet]
        public IActionResult GetListGedVersaoDocumento([FromQuery]string filter)
        {
            try
            {
                IEnumerable<GedVersaoDocumentoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList GedVersaoDocumento]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectGedVersaoDocumento")]
        public IActionResult GetObjectGedVersaoDocumento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject GedVersaoDocumento]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject GedVersaoDocumento]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertGedVersaoDocumento([FromBody]GedVersaoDocumentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert GedVersaoDocumento]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectGedVersaoDocumento", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert GedVersaoDocumento]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateGedVersaoDocumento([FromBody]GedVersaoDocumentoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update GedVersaoDocumento]", null));
                }

                _service.Update(objJson);

                return GetObjectGedVersaoDocumento(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update GedVersaoDocumento]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteGedVersaoDocumento(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete GedVersaoDocumento]", ex));
            }
        }

    }
}