using ged.Models;
using ged.NHibernate;
using ISession = NHibernate.ISession;

namespace ged.Services
{
    public class GedTipoDocumentoService
    {

        public IEnumerable<GedTipoDocumentoModel> GetList()
        {
            IList<GedTipoDocumentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedTipoDocumentoModel> DAL = new NHibernateDAL<GedTipoDocumentoModel>(Session);
                Result = DAL.Select(new GedTipoDocumentoModel());
            }
            return Result;
        }

        public IEnumerable<GedTipoDocumentoModel> GetListFilter(Filter filterObj)
        {
            IList<GedTipoDocumentoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from GedTipoDocumentoModel where " + filterObj.Where;
                NHibernateDAL<GedTipoDocumentoModel> DAL = new NHibernateDAL<GedTipoDocumentoModel>(Session);
                Result = DAL.SelectListSql<GedTipoDocumentoModel>(Query);
            }
            return Result;
        }
		
        public GedTipoDocumentoModel GetObject(int id)
        {
            GedTipoDocumentoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedTipoDocumentoModel> DAL = new NHibernateDAL<GedTipoDocumentoModel>(Session);
                Result = DAL.SelectId<GedTipoDocumentoModel>(id);
            }
            return Result;
        }
		
        public void Insert(GedTipoDocumentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedTipoDocumentoModel> DAL = new NHibernateDAL<GedTipoDocumentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(GedTipoDocumentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedTipoDocumentoModel> DAL = new NHibernateDAL<GedTipoDocumentoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(GedTipoDocumentoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<GedTipoDocumentoModel> DAL = new NHibernateDAL<GedTipoDocumentoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}