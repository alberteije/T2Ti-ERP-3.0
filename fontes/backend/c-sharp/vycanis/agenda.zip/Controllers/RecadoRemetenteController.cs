using Microsoft.AspNetCore.Mvc;
using agenda.Models;
using agenda.Services;

namespace agenda.Controllers
{
    [Route("recado-remetente")]
    [Produces("application/json")]
    public class RecadoRemetenteController : Controller
    {
		private readonly RecadoRemetenteService _service;

        public RecadoRemetenteController()
        {
            _service = new RecadoRemetenteService();
        }

        [HttpGet]
        public IActionResult GetListRecadoRemetente([FromQuery]string filter)
        {
            try
            {
                IEnumerable<RecadoRemetenteModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList RecadoRemetente]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectRecadoRemetente")]
        public IActionResult GetObjectRecadoRemetente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject RecadoRemetente]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject RecadoRemetente]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertRecadoRemetente([FromBody]RecadoRemetenteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert RecadoRemetente]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectRecadoRemetente", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert RecadoRemetente]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateRecadoRemetente([FromBody]RecadoRemetenteModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update RecadoRemetente]", null));
                }

                _service.Update(objJson);

                return GetObjectRecadoRemetente(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update RecadoRemetente]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteRecadoRemetente(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete RecadoRemetente]", ex));
            }
        }

    }
}