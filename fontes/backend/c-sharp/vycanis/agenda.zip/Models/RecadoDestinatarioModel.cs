namespace agenda.Models
{
	public class RecadoDestinatarioModel
	{	
		public int? Id { get; set; } 

		public RecadoRemetenteModel? RecadoRemetenteModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
