namespace agenda.Models
{
	public class AgendaCompromissoConvidadoModel
	{	
		public int? Id { get; set; } 

		public AgendaCompromissoModel? AgendaCompromissoModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

	}
}
