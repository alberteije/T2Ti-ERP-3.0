namespace agenda.Models
{
	public class AgendaCategoriaCompromissoModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Cor { get; set; } 

	}
}
