using agenda.Models;
using agenda.NHibernate;
using ISession = NHibernate.ISession;

namespace agenda.Services
{
    public class AgendaCategoriaCompromissoService
    {

        public IEnumerable<AgendaCategoriaCompromissoModel> GetList()
        {
            IList<AgendaCategoriaCompromissoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCategoriaCompromissoModel> DAL = new NHibernateDAL<AgendaCategoriaCompromissoModel>(Session);
                Result = DAL.Select(new AgendaCategoriaCompromissoModel());
            }
            return Result;
        }

        public IEnumerable<AgendaCategoriaCompromissoModel> GetListFilter(Filter filterObj)
        {
            IList<AgendaCategoriaCompromissoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from AgendaCategoriaCompromissoModel where " + filterObj.Where;
                NHibernateDAL<AgendaCategoriaCompromissoModel> DAL = new NHibernateDAL<AgendaCategoriaCompromissoModel>(Session);
                Result = DAL.SelectListSql<AgendaCategoriaCompromissoModel>(Query);
            }
            return Result;
        }
		
        public AgendaCategoriaCompromissoModel GetObject(int id)
        {
            AgendaCategoriaCompromissoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCategoriaCompromissoModel> DAL = new NHibernateDAL<AgendaCategoriaCompromissoModel>(Session);
                Result = DAL.SelectId<AgendaCategoriaCompromissoModel>(id);
            }
            return Result;
        }
		
        public void Insert(AgendaCategoriaCompromissoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCategoriaCompromissoModel> DAL = new NHibernateDAL<AgendaCategoriaCompromissoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(AgendaCategoriaCompromissoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCategoriaCompromissoModel> DAL = new NHibernateDAL<AgendaCategoriaCompromissoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(AgendaCategoriaCompromissoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCategoriaCompromissoModel> DAL = new NHibernateDAL<AgendaCategoriaCompromissoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}