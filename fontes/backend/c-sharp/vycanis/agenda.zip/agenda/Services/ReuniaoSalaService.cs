using agenda.Models;
using agenda.NHibernate;
using ISession = NHibernate.ISession;

namespace agenda.Services
{
    public class ReuniaoSalaService
    {

        public IEnumerable<ReuniaoSalaModel> GetList()
        {
            IList<ReuniaoSalaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ReuniaoSalaModel> DAL = new NHibernateDAL<ReuniaoSalaModel>(Session);
                Result = DAL.Select(new ReuniaoSalaModel());
            }
            return Result;
        }

        public IEnumerable<ReuniaoSalaModel> GetListFilter(Filter filterObj)
        {
            IList<ReuniaoSalaModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from ReuniaoSalaModel where " + filterObj.Where;
                NHibernateDAL<ReuniaoSalaModel> DAL = new NHibernateDAL<ReuniaoSalaModel>(Session);
                Result = DAL.SelectListSql<ReuniaoSalaModel>(Query);
            }
            return Result;
        }
		
        public ReuniaoSalaModel GetObject(int id)
        {
            ReuniaoSalaModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ReuniaoSalaModel> DAL = new NHibernateDAL<ReuniaoSalaModel>(Session);
                Result = DAL.SelectId<ReuniaoSalaModel>(id);
            }
            return Result;
        }
		
        public void Insert(ReuniaoSalaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ReuniaoSalaModel> DAL = new NHibernateDAL<ReuniaoSalaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(ReuniaoSalaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ReuniaoSalaModel> DAL = new NHibernateDAL<ReuniaoSalaModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(ReuniaoSalaModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<ReuniaoSalaModel> DAL = new NHibernateDAL<ReuniaoSalaModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}