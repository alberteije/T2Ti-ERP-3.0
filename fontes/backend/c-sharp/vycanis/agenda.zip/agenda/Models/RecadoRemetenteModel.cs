namespace agenda.Models
{
	public class RecadoRemetenteModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataEnvio { get; set; } 

		public string? HoraEnvio { get; set; } 

		public string? Assunto { get; set; } 

		public string? Texto { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<RecadoDestinatarioModel>? recadoDestinatarioModelList; 
		public IList<RecadoDestinatarioModel>? RecadoDestinatarioModelList 
		{ 
			get 
			{ 
				return recadoDestinatarioModelList; 
			} 
			set 
			{ 
				recadoDestinatarioModelList = value; 
				foreach (RecadoDestinatarioModel recadoDestinatarioModel in recadoDestinatarioModelList!) 
				{ 
					recadoDestinatarioModel.RecadoRemetenteModel = this; 
				} 
			} 
		} 

	}
}
