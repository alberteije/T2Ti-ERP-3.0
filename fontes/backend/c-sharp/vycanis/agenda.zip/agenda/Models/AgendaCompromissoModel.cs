namespace agenda.Models
{
	public class AgendaCompromissoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataCompromisso { get; set; } 

		public string? Hora { get; set; } 

		public int? Duracao { get; set; } 

		public string? Tipo { get; set; } 

		public string? Onde { get; set; } 

		public string? Descricao { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		public AgendaCategoriaCompromissoModel? AgendaCategoriaCompromissoModel { get; set; } 

		private IList<AgendaNotificacaoModel>? agendaNotificacaoModelList; 
		public IList<AgendaNotificacaoModel>? AgendaNotificacaoModelList 
		{ 
			get 
			{ 
				return agendaNotificacaoModelList; 
			} 
			set 
			{ 
				agendaNotificacaoModelList = value; 
				foreach (AgendaNotificacaoModel agendaNotificacaoModel in agendaNotificacaoModelList!) 
				{ 
					agendaNotificacaoModel.AgendaCompromissoModel = this; 
				} 
			} 
		} 

		private IList<AgendaCompromissoConvidadoModel>? agendaCompromissoConvidadoModelList; 
		public IList<AgendaCompromissoConvidadoModel>? AgendaCompromissoConvidadoModelList 
		{ 
			get 
			{ 
				return agendaCompromissoConvidadoModelList; 
			} 
			set 
			{ 
				agendaCompromissoConvidadoModelList = value; 
				foreach (AgendaCompromissoConvidadoModel agendaCompromissoConvidadoModel in agendaCompromissoConvidadoModelList!) 
				{ 
					agendaCompromissoConvidadoModel.AgendaCompromissoModel = this; 
				} 
			} 
		} 

		private IList<ReuniaoSalaEventoModel>? reuniaoSalaEventoModelList; 
		public IList<ReuniaoSalaEventoModel>? ReuniaoSalaEventoModelList 
		{ 
			get 
			{ 
				return reuniaoSalaEventoModelList; 
			} 
			set 
			{ 
				reuniaoSalaEventoModelList = value; 
				foreach (ReuniaoSalaEventoModel reuniaoSalaEventoModel in reuniaoSalaEventoModelList!) 
				{ 
					reuniaoSalaEventoModel.AgendaCompromissoModel = this; 
				} 
			} 
		} 

	}
}
