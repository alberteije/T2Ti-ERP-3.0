namespace agenda.Models
{
	public class ReuniaoSalaEventoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataReserva { get; set; } 

		public AgendaCompromissoModel? AgendaCompromissoModel { get; set; } 

		public ReuniaoSalaModel? ReuniaoSalaModel { get; set; } 

	}
}
