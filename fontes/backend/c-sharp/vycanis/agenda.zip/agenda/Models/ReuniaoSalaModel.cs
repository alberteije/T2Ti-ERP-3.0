namespace agenda.Models
{
	public class ReuniaoSalaModel
	{	
		public int? Id { get; set; } 

		public string? Predio { get; set; } 

		public string? Nome { get; set; } 

		public string? Andar { get; set; } 

		public string? Numero { get; set; } 

	}
}
