namespace agenda.Models
{
	public class UsuarioTokenModel
	{	
		public int? Id { get; set; } 

		public string? Login { get; set; } 

		public string? Token { get; set; } 

		public System.Nullable<System.DateTime> DataCriacao { get; set; } 

		public string? HoraCriacao { get; set; } 

		public System.Nullable<System.DateTime> DataExpiracao { get; set; } 

		public string? HoraExpiracao { get; set; } 

	}
}
