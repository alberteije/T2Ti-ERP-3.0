namespace agenda.Models
{
	public class AgendaNotificacaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataNotificacao { get; set; } 

		public string? Hora { get; set; } 

		public string? Tipo { get; set; } 

		public AgendaCompromissoModel? AgendaCompromissoModel { get; set; } 

	}
}
