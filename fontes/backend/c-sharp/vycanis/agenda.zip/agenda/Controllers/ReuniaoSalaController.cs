using Microsoft.AspNetCore.Mvc;
using agenda.Models;
using agenda.Services;

namespace agenda.Controllers
{
    [Route("reuniao-sala")]
    [Produces("application/json")]
    public class ReuniaoSalaController : Controller
    {
		private readonly ReuniaoSalaService _service;

        public ReuniaoSalaController()
        {
            _service = new ReuniaoSalaService();
        }

        [HttpGet]
        public IActionResult GetListReuniaoSala([FromQuery]string filter)
        {
            try
            {
                IEnumerable<ReuniaoSalaModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList ReuniaoSala]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectReuniaoSala")]
        public IActionResult GetObjectReuniaoSala(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject ReuniaoSala]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject ReuniaoSala]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertReuniaoSala([FromBody]ReuniaoSalaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert ReuniaoSala]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectReuniaoSala", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert ReuniaoSala]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateReuniaoSala([FromBody]ReuniaoSalaModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update ReuniaoSala]", null));
                }

                _service.Update(objJson);

                return GetObjectReuniaoSala(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update ReuniaoSala]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteReuniaoSala(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete ReuniaoSala]", ex));
            }
        }

    }
}