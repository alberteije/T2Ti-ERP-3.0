using Microsoft.AspNetCore.Mvc;
using agenda.Models;
using agenda.Services;

namespace agenda.Controllers
{
    [Route("agenda-categoria-compromisso")]
    [Produces("application/json")]
    public class AgendaCategoriaCompromissoController : Controller
    {
		private readonly AgendaCategoriaCompromissoService _service;

        public AgendaCategoriaCompromissoController()
        {
            _service = new AgendaCategoriaCompromissoService();
        }

        [HttpGet]
        public IActionResult GetListAgendaCategoriaCompromisso([FromQuery]string filter)
        {
            try
            {
                IEnumerable<AgendaCategoriaCompromissoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList AgendaCategoriaCompromisso]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectAgendaCategoriaCompromisso")]
        public IActionResult GetObjectAgendaCategoriaCompromisso(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject AgendaCategoriaCompromisso]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject AgendaCategoriaCompromisso]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertAgendaCategoriaCompromisso([FromBody]AgendaCategoriaCompromissoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert AgendaCategoriaCompromisso]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectAgendaCategoriaCompromisso", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert AgendaCategoriaCompromisso]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateAgendaCategoriaCompromisso([FromBody]AgendaCategoriaCompromissoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update AgendaCategoriaCompromisso]", null));
                }

                _service.Update(objJson);

                return GetObjectAgendaCategoriaCompromisso(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update AgendaCategoriaCompromisso]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteAgendaCategoriaCompromisso(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete AgendaCategoriaCompromisso]", ex));
            }
        }

    }
}