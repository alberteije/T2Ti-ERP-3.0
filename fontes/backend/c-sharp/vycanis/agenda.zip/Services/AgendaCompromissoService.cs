using agenda.Models;
using agenda.NHibernate;
using ISession = NHibernate.ISession;

namespace agenda.Services
{
    public class AgendaCompromissoService
    {

        public IEnumerable<AgendaCompromissoModel> GetList()
        {
            IList<AgendaCompromissoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCompromissoModel> DAL = new NHibernateDAL<AgendaCompromissoModel>(Session);
                Result = DAL.Select(new AgendaCompromissoModel());
            }
            return Result;
        }

        public IEnumerable<AgendaCompromissoModel> GetListFilter(Filter filterObj)
        {
            IList<AgendaCompromissoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from AgendaCompromissoModel where " + filterObj.Where;
                NHibernateDAL<AgendaCompromissoModel> DAL = new NHibernateDAL<AgendaCompromissoModel>(Session);
                Result = DAL.SelectListSql<AgendaCompromissoModel>(Query);
            }
            return Result;
        }
		
        public AgendaCompromissoModel GetObject(int id)
        {
            AgendaCompromissoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCompromissoModel> DAL = new NHibernateDAL<AgendaCompromissoModel>(Session);
                Result = DAL.SelectId<AgendaCompromissoModel>(id);
            }
            return Result;
        }
		
        public void Insert(AgendaCompromissoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCompromissoModel> DAL = new NHibernateDAL<AgendaCompromissoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(AgendaCompromissoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCompromissoModel> DAL = new NHibernateDAL<AgendaCompromissoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(AgendaCompromissoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<AgendaCompromissoModel> DAL = new NHibernateDAL<AgendaCompromissoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}