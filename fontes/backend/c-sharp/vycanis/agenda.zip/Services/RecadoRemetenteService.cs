using agenda.Models;
using agenda.NHibernate;
using ISession = NHibernate.ISession;

namespace agenda.Services
{
    public class RecadoRemetenteService
    {

        public IEnumerable<RecadoRemetenteModel> GetList()
        {
            IList<RecadoRemetenteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RecadoRemetenteModel> DAL = new NHibernateDAL<RecadoRemetenteModel>(Session);
                Result = DAL.Select(new RecadoRemetenteModel());
            }
            return Result;
        }

        public IEnumerable<RecadoRemetenteModel> GetListFilter(Filter filterObj)
        {
            IList<RecadoRemetenteModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from RecadoRemetenteModel where " + filterObj.Where;
                NHibernateDAL<RecadoRemetenteModel> DAL = new NHibernateDAL<RecadoRemetenteModel>(Session);
                Result = DAL.SelectListSql<RecadoRemetenteModel>(Query);
            }
            return Result;
        }
		
        public RecadoRemetenteModel GetObject(int id)
        {
            RecadoRemetenteModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RecadoRemetenteModel> DAL = new NHibernateDAL<RecadoRemetenteModel>(Session);
                Result = DAL.SelectId<RecadoRemetenteModel>(id);
            }
            return Result;
        }
		
        public void Insert(RecadoRemetenteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RecadoRemetenteModel> DAL = new NHibernateDAL<RecadoRemetenteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(RecadoRemetenteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RecadoRemetenteModel> DAL = new NHibernateDAL<RecadoRemetenteModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(RecadoRemetenteModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<RecadoRemetenteModel> DAL = new NHibernateDAL<RecadoRemetenteModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}