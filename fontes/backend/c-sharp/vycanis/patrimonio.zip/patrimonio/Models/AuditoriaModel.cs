namespace patrimonio.Models
{
	public class AuditoriaModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataRegistro { get; set; } 

		public string? HoraRegistro { get; set; } 

		public string? JanelaController { get; set; } 

		public string? Acao { get; set; } 

		public string? Conteudo { get; set; } 

		public string? TokenJwt { get; set; } 

	}
}
