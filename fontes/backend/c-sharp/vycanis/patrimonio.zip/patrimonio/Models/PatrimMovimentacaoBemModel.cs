namespace patrimonio.Models
{
	public class PatrimMovimentacaoBemModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataMovimentacao { get; set; } 

		public string? Responsavel { get; set; } 

		public PatrimBemModel? PatrimBemModel { get; set; } 

		public PatrimTipoMovimentacaoModel? PatrimTipoMovimentacaoModel { get; set; } 

	}
}
