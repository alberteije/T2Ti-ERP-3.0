namespace patrimonio.Models
{
	public class SeguradoraModel
	{	
		public int? Id { get; set; } 

		public string? Nome { get; set; } 

		public string? Contato { get; set; } 

		public string? Telefone { get; set; } 

	}
}
