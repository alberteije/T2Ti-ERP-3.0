namespace patrimonio.Models
{
	public class PatrimGrupoBemModel
	{	
		public int? Id { get; set; } 

		public string? Codigo { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public string? ContaAtivoImobilizado { get; set; } 

		public string? ContaDepreciacaoAcumulada { get; set; } 

		public string? ContaDespesaDepreciacao { get; set; } 

		public int? CodigoHistorico { get; set; } 

	}
}
