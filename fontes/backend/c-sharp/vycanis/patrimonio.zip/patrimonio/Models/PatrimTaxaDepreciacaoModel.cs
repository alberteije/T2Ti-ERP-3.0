namespace patrimonio.Models
{
	public class PatrimTaxaDepreciacaoModel
	{	
		public int? Id { get; set; } 

		public string? Ncm { get; set; } 

		public string? Bem { get; set; } 

		public System.Nullable<System.Decimal> Vida { get; set; } 

		public System.Nullable<System.Decimal> Taxa { get; set; } 

	}
}
