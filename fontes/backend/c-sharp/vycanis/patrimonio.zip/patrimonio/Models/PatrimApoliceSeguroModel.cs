namespace patrimonio.Models
{
	public class PatrimApoliceSeguroModel
	{	
		public int? Id { get; set; } 

		public string? Numero { get; set; } 

		public System.Nullable<System.DateTime> DataContratacao { get; set; } 

		public System.Nullable<System.DateTime> DataVencimento { get; set; } 

		public System.Nullable<System.Decimal> ValorPremio { get; set; } 

		public System.Nullable<System.Decimal> ValorSegurado { get; set; } 

		public string? Observacao { get; set; } 

		public string? Imagem { get; set; } 

		public PatrimBemModel? PatrimBemModel { get; set; } 

		public SeguradoraModel? SeguradoraModel { get; set; } 

	}
}
