using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class PatrimTaxaDepreciacaoService
    {

        public IEnumerable<PatrimTaxaDepreciacaoModel> GetList()
        {
            IList<PatrimTaxaDepreciacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTaxaDepreciacaoModel> DAL = new NHibernateDAL<PatrimTaxaDepreciacaoModel>(Session);
                Result = DAL.Select(new PatrimTaxaDepreciacaoModel());
            }
            return Result;
        }

        public IEnumerable<PatrimTaxaDepreciacaoModel> GetListFilter(Filter filterObj)
        {
            IList<PatrimTaxaDepreciacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PatrimTaxaDepreciacaoModel where " + filterObj.Where;
                NHibernateDAL<PatrimTaxaDepreciacaoModel> DAL = new NHibernateDAL<PatrimTaxaDepreciacaoModel>(Session);
                Result = DAL.SelectListSql<PatrimTaxaDepreciacaoModel>(Query);
            }
            return Result;
        }
		
        public PatrimTaxaDepreciacaoModel GetObject(int id)
        {
            PatrimTaxaDepreciacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTaxaDepreciacaoModel> DAL = new NHibernateDAL<PatrimTaxaDepreciacaoModel>(Session);
                Result = DAL.SelectId<PatrimTaxaDepreciacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PatrimTaxaDepreciacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTaxaDepreciacaoModel> DAL = new NHibernateDAL<PatrimTaxaDepreciacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PatrimTaxaDepreciacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTaxaDepreciacaoModel> DAL = new NHibernateDAL<PatrimTaxaDepreciacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PatrimTaxaDepreciacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTaxaDepreciacaoModel> DAL = new NHibernateDAL<PatrimTaxaDepreciacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}