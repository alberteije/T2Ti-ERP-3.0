using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class PatrimEstadoConservacaoService
    {

        public IEnumerable<PatrimEstadoConservacaoModel> GetList()
        {
            IList<PatrimEstadoConservacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimEstadoConservacaoModel> DAL = new NHibernateDAL<PatrimEstadoConservacaoModel>(Session);
                Result = DAL.Select(new PatrimEstadoConservacaoModel());
            }
            return Result;
        }

        public IEnumerable<PatrimEstadoConservacaoModel> GetListFilter(Filter filterObj)
        {
            IList<PatrimEstadoConservacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PatrimEstadoConservacaoModel where " + filterObj.Where;
                NHibernateDAL<PatrimEstadoConservacaoModel> DAL = new NHibernateDAL<PatrimEstadoConservacaoModel>(Session);
                Result = DAL.SelectListSql<PatrimEstadoConservacaoModel>(Query);
            }
            return Result;
        }
		
        public PatrimEstadoConservacaoModel GetObject(int id)
        {
            PatrimEstadoConservacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimEstadoConservacaoModel> DAL = new NHibernateDAL<PatrimEstadoConservacaoModel>(Session);
                Result = DAL.SelectId<PatrimEstadoConservacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PatrimEstadoConservacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimEstadoConservacaoModel> DAL = new NHibernateDAL<PatrimEstadoConservacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PatrimEstadoConservacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimEstadoConservacaoModel> DAL = new NHibernateDAL<PatrimEstadoConservacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PatrimEstadoConservacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimEstadoConservacaoModel> DAL = new NHibernateDAL<PatrimEstadoConservacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}