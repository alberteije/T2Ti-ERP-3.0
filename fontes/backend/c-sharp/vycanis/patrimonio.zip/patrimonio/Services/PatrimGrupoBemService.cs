using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class PatrimGrupoBemService
    {

        public IEnumerable<PatrimGrupoBemModel> GetList()
        {
            IList<PatrimGrupoBemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimGrupoBemModel> DAL = new NHibernateDAL<PatrimGrupoBemModel>(Session);
                Result = DAL.Select(new PatrimGrupoBemModel());
            }
            return Result;
        }

        public IEnumerable<PatrimGrupoBemModel> GetListFilter(Filter filterObj)
        {
            IList<PatrimGrupoBemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PatrimGrupoBemModel where " + filterObj.Where;
                NHibernateDAL<PatrimGrupoBemModel> DAL = new NHibernateDAL<PatrimGrupoBemModel>(Session);
                Result = DAL.SelectListSql<PatrimGrupoBemModel>(Query);
            }
            return Result;
        }
		
        public PatrimGrupoBemModel GetObject(int id)
        {
            PatrimGrupoBemModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimGrupoBemModel> DAL = new NHibernateDAL<PatrimGrupoBemModel>(Session);
                Result = DAL.SelectId<PatrimGrupoBemModel>(id);
            }
            return Result;
        }
		
        public void Insert(PatrimGrupoBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimGrupoBemModel> DAL = new NHibernateDAL<PatrimGrupoBemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PatrimGrupoBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimGrupoBemModel> DAL = new NHibernateDAL<PatrimGrupoBemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PatrimGrupoBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimGrupoBemModel> DAL = new NHibernateDAL<PatrimGrupoBemModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}