using Microsoft.AspNetCore.Mvc;
using patrimonio.Models;
using patrimonio.Services;

namespace patrimonio.Controllers
{
    [Route("patrim-bem")]
    [Produces("application/json")]
    public class PatrimBemController : Controller
    {
		private readonly PatrimBemService _service;

        public PatrimBemController()
        {
            _service = new PatrimBemService();
        }

        [HttpGet]
        public IActionResult GetListPatrimBem([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PatrimBemModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PatrimBem]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPatrimBem")]
        public IActionResult GetObjectPatrimBem(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PatrimBem]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PatrimBem]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPatrimBem([FromBody]PatrimBemModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PatrimBem]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPatrimBem", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PatrimBem]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePatrimBem([FromBody]PatrimBemModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PatrimBem]", null));
                }

                _service.Update(objJson);

                return GetObjectPatrimBem(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PatrimBem]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePatrimBem(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PatrimBem]", ex));
            }
        }

    }
}