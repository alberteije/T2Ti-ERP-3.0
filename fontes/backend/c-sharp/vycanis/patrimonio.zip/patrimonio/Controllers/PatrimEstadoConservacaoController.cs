using Microsoft.AspNetCore.Mvc;
using patrimonio.Models;
using patrimonio.Services;

namespace patrimonio.Controllers
{
    [Route("patrim-estado-conservacao")]
    [Produces("application/json")]
    public class PatrimEstadoConservacaoController : Controller
    {
		private readonly PatrimEstadoConservacaoService _service;

        public PatrimEstadoConservacaoController()
        {
            _service = new PatrimEstadoConservacaoService();
        }

        [HttpGet]
        public IActionResult GetListPatrimEstadoConservacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PatrimEstadoConservacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PatrimEstadoConservacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPatrimEstadoConservacao")]
        public IActionResult GetObjectPatrimEstadoConservacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PatrimEstadoConservacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PatrimEstadoConservacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPatrimEstadoConservacao([FromBody]PatrimEstadoConservacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PatrimEstadoConservacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPatrimEstadoConservacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PatrimEstadoConservacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePatrimEstadoConservacao([FromBody]PatrimEstadoConservacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PatrimEstadoConservacao]", null));
                }

                _service.Update(objJson);

                return GetObjectPatrimEstadoConservacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PatrimEstadoConservacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePatrimEstadoConservacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PatrimEstadoConservacao]", ex));
            }
        }

    }
}