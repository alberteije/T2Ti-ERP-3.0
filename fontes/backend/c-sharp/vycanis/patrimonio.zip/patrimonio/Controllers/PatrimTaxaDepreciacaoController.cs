using Microsoft.AspNetCore.Mvc;
using patrimonio.Models;
using patrimonio.Services;

namespace patrimonio.Controllers
{
    [Route("patrim-taxa-depreciacao")]
    [Produces("application/json")]
    public class PatrimTaxaDepreciacaoController : Controller
    {
		private readonly PatrimTaxaDepreciacaoService _service;

        public PatrimTaxaDepreciacaoController()
        {
            _service = new PatrimTaxaDepreciacaoService();
        }

        [HttpGet]
        public IActionResult GetListPatrimTaxaDepreciacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PatrimTaxaDepreciacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PatrimTaxaDepreciacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPatrimTaxaDepreciacao")]
        public IActionResult GetObjectPatrimTaxaDepreciacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PatrimTaxaDepreciacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PatrimTaxaDepreciacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPatrimTaxaDepreciacao([FromBody]PatrimTaxaDepreciacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PatrimTaxaDepreciacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPatrimTaxaDepreciacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PatrimTaxaDepreciacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePatrimTaxaDepreciacao([FromBody]PatrimTaxaDepreciacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PatrimTaxaDepreciacao]", null));
                }

                _service.Update(objJson);

                return GetObjectPatrimTaxaDepreciacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PatrimTaxaDepreciacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePatrimTaxaDepreciacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PatrimTaxaDepreciacao]", ex));
            }
        }

    }
}