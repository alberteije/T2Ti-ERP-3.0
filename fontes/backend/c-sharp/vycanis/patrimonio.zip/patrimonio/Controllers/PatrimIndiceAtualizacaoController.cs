using Microsoft.AspNetCore.Mvc;
using patrimonio.Models;
using patrimonio.Services;

namespace patrimonio.Controllers
{
    [Route("patrim-indice-atualizacao")]
    [Produces("application/json")]
    public class PatrimIndiceAtualizacaoController : Controller
    {
		private readonly PatrimIndiceAtualizacaoService _service;

        public PatrimIndiceAtualizacaoController()
        {
            _service = new PatrimIndiceAtualizacaoService();
        }

        [HttpGet]
        public IActionResult GetListPatrimIndiceAtualizacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PatrimIndiceAtualizacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PatrimIndiceAtualizacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPatrimIndiceAtualizacao")]
        public IActionResult GetObjectPatrimIndiceAtualizacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PatrimIndiceAtualizacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PatrimIndiceAtualizacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPatrimIndiceAtualizacao([FromBody]PatrimIndiceAtualizacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PatrimIndiceAtualizacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPatrimIndiceAtualizacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PatrimIndiceAtualizacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePatrimIndiceAtualizacao([FromBody]PatrimIndiceAtualizacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PatrimIndiceAtualizacao]", null));
                }

                _service.Update(objJson);

                return GetObjectPatrimIndiceAtualizacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PatrimIndiceAtualizacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePatrimIndiceAtualizacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PatrimIndiceAtualizacao]", ex));
            }
        }

    }
}