using Microsoft.AspNetCore.Mvc;
using patrimonio.Models;
using patrimonio.Services;

namespace patrimonio.Controllers
{
    [Route("patrim-tipo-movimentacao")]
    [Produces("application/json")]
    public class PatrimTipoMovimentacaoController : Controller
    {
		private readonly PatrimTipoMovimentacaoService _service;

        public PatrimTipoMovimentacaoController()
        {
            _service = new PatrimTipoMovimentacaoService();
        }

        [HttpGet]
        public IActionResult GetListPatrimTipoMovimentacao([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PatrimTipoMovimentacaoModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PatrimTipoMovimentacao]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPatrimTipoMovimentacao")]
        public IActionResult GetObjectPatrimTipoMovimentacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PatrimTipoMovimentacao]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PatrimTipoMovimentacao]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPatrimTipoMovimentacao([FromBody]PatrimTipoMovimentacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PatrimTipoMovimentacao]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPatrimTipoMovimentacao", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PatrimTipoMovimentacao]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePatrimTipoMovimentacao([FromBody]PatrimTipoMovimentacaoModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PatrimTipoMovimentacao]", null));
                }

                _service.Update(objJson);

                return GetObjectPatrimTipoMovimentacao(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PatrimTipoMovimentacao]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePatrimTipoMovimentacao(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PatrimTipoMovimentacao]", ex));
            }
        }

    }
}