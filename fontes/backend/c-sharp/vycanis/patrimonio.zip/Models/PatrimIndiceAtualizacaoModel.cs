namespace patrimonio.Models
{
	public class PatrimIndiceAtualizacaoModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataIndice { get; set; } 

		public string? Nome { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public System.Nullable<System.Decimal> ValorAlternativo { get; set; } 

	}
}
