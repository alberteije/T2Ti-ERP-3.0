namespace patrimonio.Models
{
	public class CentroResultadoModel
	{	
		public int? Id { get; set; } 

		public int? IdPlanoCentroResultado { get; set; } 

		public string? Classificacao { get; set; } 

		public string? Descricao { get; set; } 

		public string? SofreRateiro { get; set; } 

	}
}
