namespace patrimonio.Models
{
	public class PatrimBemModel
	{	
		public int? Id { get; set; } 

		public string? NumeroNb { get; set; } 

		public string? Nome { get; set; } 

		public string? Descricao { get; set; } 

		public System.Nullable<System.DateTime> DataAquisicao { get; set; } 

		public System.Nullable<System.DateTime> DataAceite { get; set; } 

		public System.Nullable<System.DateTime> DataCadastro { get; set; } 

		public System.Nullable<System.DateTime> DataContabilizado { get; set; } 

		public System.Nullable<System.DateTime> DataVistoria { get; set; } 

		public System.Nullable<System.DateTime> DataMarcacao { get; set; } 

		public System.Nullable<System.DateTime> DataBaixa { get; set; } 

		public System.Nullable<System.DateTime> VencimentoGarantia { get; set; } 

		public string? NumeroNotaFiscal { get; set; } 

		public string? NumeroSerie { get; set; } 

		public string? ChaveNfe { get; set; } 

		public System.Nullable<System.Decimal> ValorOriginal { get; set; } 

		public System.Nullable<System.Decimal> ValorCompra { get; set; } 

		public System.Nullable<System.Decimal> ValorAtualizado { get; set; } 

		public System.Nullable<System.Decimal> ValorBaixa { get; set; } 

		public string? Deprecia { get; set; } 

		public string? MetodoDepreciacao { get; set; } 

		public System.Nullable<System.DateTime> InicioDepreciacao { get; set; } 

		public System.Nullable<System.DateTime> UltimaDepreciacao { get; set; } 

		public string? TipoDepreciacao { get; set; } 

		public System.Nullable<System.Decimal> TaxaAnualDepreciacao { get; set; } 

		public System.Nullable<System.Decimal> TaxaMensalDepreciacao { get; set; } 

		public System.Nullable<System.Decimal> TaxaDepreciacaoAcelerada { get; set; } 

		public System.Nullable<System.Decimal> TaxaDepreciacaoIncentivada { get; set; } 

		public string? Funcao { get; set; } 

		public CentroResultadoModel? CentroResultadoModel { get; set; } 

		public PatrimEstadoConservacaoModel? PatrimEstadoConservacaoModel { get; set; } 

		public SetorModel? SetorModel { get; set; } 

		public ViewPessoaFornecedorModel? ViewPessoaFornecedorModel { get; set; } 

		public PatrimTipoAquisicaoBemModel? PatrimTipoAquisicaoBemModel { get; set; } 

		public PatrimGrupoBemModel? PatrimGrupoBemModel { get; set; } 

		public ViewPessoaColaboradorModel? ViewPessoaColaboradorModel { get; set; } 

		private IList<PatrimDocumentoBemModel>? patrimDocumentoBemModelList; 
		public IList<PatrimDocumentoBemModel>? PatrimDocumentoBemModelList 
		{ 
			get 
			{ 
				return patrimDocumentoBemModelList; 
			} 
			set 
			{ 
				patrimDocumentoBemModelList = value; 
				foreach (PatrimDocumentoBemModel patrimDocumentoBemModel in patrimDocumentoBemModelList!) 
				{ 
					patrimDocumentoBemModel.PatrimBemModel = this; 
				} 
			} 
		} 

		private IList<PatrimDepreciacaoBemModel>? patrimDepreciacaoBemModelList; 
		public IList<PatrimDepreciacaoBemModel>? PatrimDepreciacaoBemModelList 
		{ 
			get 
			{ 
				return patrimDepreciacaoBemModelList; 
			} 
			set 
			{ 
				patrimDepreciacaoBemModelList = value; 
				foreach (PatrimDepreciacaoBemModel patrimDepreciacaoBemModel in patrimDepreciacaoBemModelList!) 
				{ 
					patrimDepreciacaoBemModel.PatrimBemModel = this; 
				} 
			} 
		} 

		private IList<PatrimMovimentacaoBemModel>? patrimMovimentacaoBemModelList; 
		public IList<PatrimMovimentacaoBemModel>? PatrimMovimentacaoBemModelList 
		{ 
			get 
			{ 
				return patrimMovimentacaoBemModelList; 
			} 
			set 
			{ 
				patrimMovimentacaoBemModelList = value; 
				foreach (PatrimMovimentacaoBemModel patrimMovimentacaoBemModel in patrimMovimentacaoBemModelList!) 
				{ 
					patrimMovimentacaoBemModel.PatrimBemModel = this; 
				} 
			} 
		} 

		private IList<PatrimApoliceSeguroModel>? patrimApoliceSeguroModelList; 
		public IList<PatrimApoliceSeguroModel>? PatrimApoliceSeguroModelList 
		{ 
			get 
			{ 
				return patrimApoliceSeguroModelList; 
			} 
			set 
			{ 
				patrimApoliceSeguroModelList = value; 
				foreach (PatrimApoliceSeguroModel patrimApoliceSeguroModel in patrimApoliceSeguroModelList!) 
				{ 
					patrimApoliceSeguroModel.PatrimBemModel = this; 
				} 
			} 
		} 

	}
}
