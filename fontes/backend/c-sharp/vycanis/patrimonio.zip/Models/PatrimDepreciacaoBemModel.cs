namespace patrimonio.Models
{
	public class PatrimDepreciacaoBemModel
	{	
		public int? Id { get; set; } 

		public System.Nullable<System.DateTime> DataDepreciacao { get; set; } 

		public int? Dias { get; set; } 

		public System.Nullable<System.Decimal> Taxa { get; set; } 

		public System.Nullable<System.Decimal> Indice { get; set; } 

		public System.Nullable<System.Decimal> Valor { get; set; } 

		public System.Nullable<System.Decimal> DepreciacaoAcumulada { get; set; } 

		public PatrimBemModel? PatrimBemModel { get; set; } 

	}
}
