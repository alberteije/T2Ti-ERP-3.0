using Microsoft.AspNetCore.Mvc;
using patrimonio.Models;
using patrimonio.Services;

namespace patrimonio.Controllers
{
    [Route("seguradora")]
    [Produces("application/json")]
    public class SeguradoraController : Controller
    {
		private readonly SeguradoraService _service;

        public SeguradoraController()
        {
            _service = new SeguradoraService();
        }

        [HttpGet]
        public IActionResult GetListSeguradora([FromQuery]string filter)
        {
            try
            {
                IEnumerable<SeguradoraModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList Seguradora]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectSeguradora")]
        public IActionResult GetObjectSeguradora(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject Seguradora]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject Seguradora]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertSeguradora([FromBody]SeguradoraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert Seguradora]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectSeguradora", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert Seguradora]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdateSeguradora([FromBody]SeguradoraModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update Seguradora]", null));
                }

                _service.Update(objJson);

                return GetObjectSeguradora(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update Seguradora]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteSeguradora(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete Seguradora]", ex));
            }
        }

    }
}