using Microsoft.AspNetCore.Mvc;
using patrimonio.Models;
using patrimonio.Services;

namespace patrimonio.Controllers
{
    [Route("patrim-grupo-bem")]
    [Produces("application/json")]
    public class PatrimGrupoBemController : Controller
    {
		private readonly PatrimGrupoBemService _service;

        public PatrimGrupoBemController()
        {
            _service = new PatrimGrupoBemService();
        }

        [HttpGet]
        public IActionResult GetListPatrimGrupoBem([FromQuery]string filter)
        {
            try
            {
                IEnumerable<PatrimGrupoBemModel> resultList;
                if (filter == null)
                {
                    resultList = _service.GetList();
                }
                else
                {
                    // defines filter
                    Filter filterObj = new Filter(filter);
                    resultList = _service.GetListFilter(filterObj);
                }
                return Ok(resultList);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetList PatrimGrupoBem]", ex));
            }
        }

        [HttpGet("{id}", Name = "GetObjectPatrimGrupoBem")]
        public IActionResult GetObjectPatrimGrupoBem(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                if (obj == null)
                {
                    return StatusCode(404, new ResultJsonError(404, "Not Found [GetObject PatrimGrupoBem]", null));
                }
                else
                {
                    return Ok(obj);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [GetObject PatrimGrupoBem]", ex));
            }
        }

        [HttpPost]
        public IActionResult InsertPatrimGrupoBem([FromBody]PatrimGrupoBemModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Insert PatrimGrupoBem]", null));
                }
                _service.Insert(objJson);

                return CreatedAtRoute("GetObjectPatrimGrupoBem", new { id = objJson.Id }, objJson);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Insert PatrimGrupoBem]", ex));
            }
        }

        [HttpPut]
        public IActionResult UpdatePatrimGrupoBem([FromBody]PatrimGrupoBemModel objJson)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new ResultJsonError(400, "Invalid Object [Update PatrimGrupoBem]", null));
                }

                _service.Update(objJson);

                return GetObjectPatrimGrupoBem(objJson.Id!.Value);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Update PatrimGrupoBem]", ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePatrimGrupoBem(int id)
        {
            try
            {
                var obj = _service.GetObject(id);

                _service.Delete(obj);

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResultJsonError(500, "Error [Delete PatrimGrupoBem]", ex));
            }
        }

    }
}