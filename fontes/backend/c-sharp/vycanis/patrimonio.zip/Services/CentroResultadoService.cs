using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class CentroResultadoService
    {

        public IEnumerable<CentroResultadoModel> GetList()
        {
            IList<CentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CentroResultadoModel> DAL = new NHibernateDAL<CentroResultadoModel>(Session);
                Result = DAL.Select(new CentroResultadoModel());
            }
            return Result;
        }

        public IEnumerable<CentroResultadoModel> GetListFilter(Filter filterObj)
        {
            IList<CentroResultadoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from CentroResultadoModel where " + filterObj.Where;
                NHibernateDAL<CentroResultadoModel> DAL = new NHibernateDAL<CentroResultadoModel>(Session);
                Result = DAL.SelectListSql<CentroResultadoModel>(Query);
            }
            return Result;
        }
		
        public CentroResultadoModel GetObject(int id)
        {
            CentroResultadoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CentroResultadoModel> DAL = new NHibernateDAL<CentroResultadoModel>(Session);
                Result = DAL.SelectId<CentroResultadoModel>(id);
            }
            return Result;
        }
		
        public void Insert(CentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CentroResultadoModel> DAL = new NHibernateDAL<CentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(CentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CentroResultadoModel> DAL = new NHibernateDAL<CentroResultadoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(CentroResultadoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<CentroResultadoModel> DAL = new NHibernateDAL<CentroResultadoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}