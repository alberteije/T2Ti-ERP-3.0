using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class SeguradoraService
    {

        public IEnumerable<SeguradoraModel> GetList()
        {
            IList<SeguradoraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SeguradoraModel> DAL = new NHibernateDAL<SeguradoraModel>(Session);
                Result = DAL.Select(new SeguradoraModel());
            }
            return Result;
        }

        public IEnumerable<SeguradoraModel> GetListFilter(Filter filterObj)
        {
            IList<SeguradoraModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from SeguradoraModel where " + filterObj.Where;
                NHibernateDAL<SeguradoraModel> DAL = new NHibernateDAL<SeguradoraModel>(Session);
                Result = DAL.SelectListSql<SeguradoraModel>(Query);
            }
            return Result;
        }
		
        public SeguradoraModel GetObject(int id)
        {
            SeguradoraModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SeguradoraModel> DAL = new NHibernateDAL<SeguradoraModel>(Session);
                Result = DAL.SelectId<SeguradoraModel>(id);
            }
            return Result;
        }
		
        public void Insert(SeguradoraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SeguradoraModel> DAL = new NHibernateDAL<SeguradoraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(SeguradoraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SeguradoraModel> DAL = new NHibernateDAL<SeguradoraModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(SeguradoraModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<SeguradoraModel> DAL = new NHibernateDAL<SeguradoraModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}