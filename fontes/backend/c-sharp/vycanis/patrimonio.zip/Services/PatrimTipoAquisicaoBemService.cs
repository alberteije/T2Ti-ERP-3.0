using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class PatrimTipoAquisicaoBemService
    {

        public IEnumerable<PatrimTipoAquisicaoBemModel> GetList()
        {
            IList<PatrimTipoAquisicaoBemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoAquisicaoBemModel> DAL = new NHibernateDAL<PatrimTipoAquisicaoBemModel>(Session);
                Result = DAL.Select(new PatrimTipoAquisicaoBemModel());
            }
            return Result;
        }

        public IEnumerable<PatrimTipoAquisicaoBemModel> GetListFilter(Filter filterObj)
        {
            IList<PatrimTipoAquisicaoBemModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PatrimTipoAquisicaoBemModel where " + filterObj.Where;
                NHibernateDAL<PatrimTipoAquisicaoBemModel> DAL = new NHibernateDAL<PatrimTipoAquisicaoBemModel>(Session);
                Result = DAL.SelectListSql<PatrimTipoAquisicaoBemModel>(Query);
            }
            return Result;
        }
		
        public PatrimTipoAquisicaoBemModel GetObject(int id)
        {
            PatrimTipoAquisicaoBemModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoAquisicaoBemModel> DAL = new NHibernateDAL<PatrimTipoAquisicaoBemModel>(Session);
                Result = DAL.SelectId<PatrimTipoAquisicaoBemModel>(id);
            }
            return Result;
        }
		
        public void Insert(PatrimTipoAquisicaoBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoAquisicaoBemModel> DAL = new NHibernateDAL<PatrimTipoAquisicaoBemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PatrimTipoAquisicaoBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoAquisicaoBemModel> DAL = new NHibernateDAL<PatrimTipoAquisicaoBemModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PatrimTipoAquisicaoBemModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoAquisicaoBemModel> DAL = new NHibernateDAL<PatrimTipoAquisicaoBemModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}