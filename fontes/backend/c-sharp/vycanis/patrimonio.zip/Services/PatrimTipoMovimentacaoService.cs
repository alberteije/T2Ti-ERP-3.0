using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class PatrimTipoMovimentacaoService
    {

        public IEnumerable<PatrimTipoMovimentacaoModel> GetList()
        {
            IList<PatrimTipoMovimentacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoMovimentacaoModel> DAL = new NHibernateDAL<PatrimTipoMovimentacaoModel>(Session);
                Result = DAL.Select(new PatrimTipoMovimentacaoModel());
            }
            return Result;
        }

        public IEnumerable<PatrimTipoMovimentacaoModel> GetListFilter(Filter filterObj)
        {
            IList<PatrimTipoMovimentacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PatrimTipoMovimentacaoModel where " + filterObj.Where;
                NHibernateDAL<PatrimTipoMovimentacaoModel> DAL = new NHibernateDAL<PatrimTipoMovimentacaoModel>(Session);
                Result = DAL.SelectListSql<PatrimTipoMovimentacaoModel>(Query);
            }
            return Result;
        }
		
        public PatrimTipoMovimentacaoModel GetObject(int id)
        {
            PatrimTipoMovimentacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoMovimentacaoModel> DAL = new NHibernateDAL<PatrimTipoMovimentacaoModel>(Session);
                Result = DAL.SelectId<PatrimTipoMovimentacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PatrimTipoMovimentacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoMovimentacaoModel> DAL = new NHibernateDAL<PatrimTipoMovimentacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PatrimTipoMovimentacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoMovimentacaoModel> DAL = new NHibernateDAL<PatrimTipoMovimentacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PatrimTipoMovimentacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimTipoMovimentacaoModel> DAL = new NHibernateDAL<PatrimTipoMovimentacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}