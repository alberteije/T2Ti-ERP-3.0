using patrimonio.Models;
using patrimonio.NHibernate;
using ISession = NHibernate.ISession;

namespace patrimonio.Services
{
    public class PatrimIndiceAtualizacaoService
    {

        public IEnumerable<PatrimIndiceAtualizacaoModel> GetList()
        {
            IList<PatrimIndiceAtualizacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimIndiceAtualizacaoModel> DAL = new NHibernateDAL<PatrimIndiceAtualizacaoModel>(Session);
                Result = DAL.Select(new PatrimIndiceAtualizacaoModel());
            }
            return Result;
        }

        public IEnumerable<PatrimIndiceAtualizacaoModel> GetListFilter(Filter filterObj)
        {
            IList<PatrimIndiceAtualizacaoModel> Result = [];
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                var Query = "from PatrimIndiceAtualizacaoModel where " + filterObj.Where;
                NHibernateDAL<PatrimIndiceAtualizacaoModel> DAL = new NHibernateDAL<PatrimIndiceAtualizacaoModel>(Session);
                Result = DAL.SelectListSql<PatrimIndiceAtualizacaoModel>(Query);
            }
            return Result;
        }
		
        public PatrimIndiceAtualizacaoModel GetObject(int id)
        {
            PatrimIndiceAtualizacaoModel? Result = null;
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimIndiceAtualizacaoModel> DAL = new NHibernateDAL<PatrimIndiceAtualizacaoModel>(Session);
                Result = DAL.SelectId<PatrimIndiceAtualizacaoModel>(id);
            }
            return Result;
        }
		
        public void Insert(PatrimIndiceAtualizacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimIndiceAtualizacaoModel> DAL = new NHibernateDAL<PatrimIndiceAtualizacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Update(PatrimIndiceAtualizacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimIndiceAtualizacaoModel> DAL = new NHibernateDAL<PatrimIndiceAtualizacaoModel>(Session);
                DAL.SaveOrUpdate(obj);
                Session.Flush();
            }
        }

        public void Delete(PatrimIndiceAtualizacaoModel obj)
        {
            using (ISession Session = NHibernateHelper.GetSessionFactory().OpenSession())
            {
                NHibernateDAL<PatrimIndiceAtualizacaoModel> DAL = new NHibernateDAL<PatrimIndiceAtualizacaoModel>(Session);
                DAL.Delete(obj);
                Session.Flush();
            }
        }
		
    }

}