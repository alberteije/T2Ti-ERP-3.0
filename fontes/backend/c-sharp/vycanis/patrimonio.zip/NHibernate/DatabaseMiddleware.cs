﻿namespace patrimonio.NHIbernate
{
    public class DatabaseMiddleware
    {
        private readonly RequestDelegate _next;

        public DatabaseMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Headers.TryGetValue("cnpj", out var cnpj))
            {
                // Configurar o banco de dados dinamicamente
                NHibernateHelper.SetCurrentCnpj(cnpj.ToString());
            }

            await _next(context);
        }
    }

}
