from flask import Flask, request, redirect
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv

# Carrega as variáveis de ambiente do arquivo .env
load_dotenv()

# Importa as configurações do aplicativo Flask
from src.config import config

# Cria a instância do SQLAlchemy para interagir com o banco de dados
db = SQLAlchemy()
   
# Função para criar e configurar o aplicativo Flask
def create_app(config_mode):
    # Cria a instância do aplicativo Flask
    app = Flask(__name__)

    # Configura o aplicativo Flask com base no modo de configuração fornecido
    app.config.from_object(config[config_mode])

    # Inicializa o SQLAlchemy com o aplicativo Flask
    db.init_app(app)

    return app