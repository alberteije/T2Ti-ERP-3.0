import jwt
from src.model.view_pessoa_usuario_model import ViewPessoaUsuarioModel
from sqlalchemy.orm.exc import NoResultFound
from src.util.util import cifrar, md5_string  # Importe os métodos necessários
from src.util.constants import CHAVE
import json

class LoginService:

    @staticmethod
    def gerar_token(usuario: ViewPessoaUsuarioModel):
        payload = {
            'sub': usuario.login
        }
        token = jwt.encode(payload, CHAVE, algorithm='HS256')
        return token

    @staticmethod
    def login(usuario: ViewPessoaUsuarioModel):
        md5_senha = md5_string(usuario.login + usuario.senha)

        # Filtra o usuário no banco de dados
        user = ViewPessoaUsuarioModel.query.filter_by(login=usuario.login, senha=md5_senha).first()

        if user:
            user_json = json.dumps(user.serialize())
            user_cifrado = cifrar(user_json)
            objeto_login = {
                'token': cifrar(LoginService.gerar_token(usuario)),
                'user': user_cifrado
            }
            return objeto_login

        raise NoResultFound('Usuário ou senha inválidos')
