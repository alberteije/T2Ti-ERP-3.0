from flask import Blueprint, request, jsonify
from src.model.transient.filter import Filter
from src.service.usuario_service import UsuarioService

usuario_bp = Blueprint('usuario', __name__)
service = UsuarioService()

@usuario_bp.route('/usuario', methods=['GET'])
@usuario_bp.route('/usuario/', methods=['GET'])
def get_list():
    query_params = request.args
    filter_obj = Filter(query_params)    
    if filter_obj.where:
        result_list = service.get_list_filter(filter_obj)
    else:
        result_list = service.get_list()
    return jsonify([obj.serialize() for obj in result_list])

@usuario_bp.route('/usuario/<int:id>', methods=['GET'])
def get_object(id):
    obj = service.get_object(id)
    return jsonify(obj.serialize())

@usuario_bp.route('/usuario', methods=['POST'])
def insert():
    data = request.json
    result = service.insert(data)
    return jsonify(result.serialize()), 201

@usuario_bp.route('/usuario', methods=['PUT'])
def update():
    data = request.json
    result = service.update(data)
    return jsonify(result.serialize()), 200

@usuario_bp.route('/usuario/<int:id>', methods=['DELETE'])
def delete(id):
    service.delete(id)
    return jsonify({'message': 'Deleted successfully'})

@usuario_bp.route('/usuario/verifica-login/<string:login>', methods=['GET'])
def get_usuario_pelo_login(login):
    obj = service.get_usuario_pelo_login(login)
    return jsonify(obj.serialize())