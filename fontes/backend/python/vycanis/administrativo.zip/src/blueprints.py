from src.controller.login_controller import login_bp
from src.controller.papel_controller import papel_bp
from src.controller.empresa_controller import empresa_bp
from src.controller.auditoria_controller import auditoria_bp
from src.controller.usuario_token_controller import usuario_token_bp
from src.controller.view_controle_acesso_controller import view_controle_acesso_bp
from src.controller.view_pessoa_usuario_controller import view_pessoa_usuario_bp
from src.controller.view_pessoa_colaborador_controller import view_pessoa_colaborador_bp
from src.controller.funcao_controller import funcao_bp
from src.controller.usuario_controller import usuario_bp
from src.controller.cnae_controller import cnae_bp

# Register the blueprints with the Flask application
def register_blueprints(app):
		app.register_blueprint(papel_bp)
		app.register_blueprint(empresa_bp)
		app.register_blueprint(auditoria_bp)
		app.register_blueprint(usuario_token_bp)
		app.register_blueprint(view_controle_acesso_bp)
		app.register_blueprint(view_pessoa_usuario_bp)
		app.register_blueprint(view_pessoa_colaborador_bp)
		app.register_blueprint(funcao_bp)
		app.register_blueprint(usuario_bp)
		app.register_blueprint(cnae_bp)
		app.register_blueprint(login_bp)