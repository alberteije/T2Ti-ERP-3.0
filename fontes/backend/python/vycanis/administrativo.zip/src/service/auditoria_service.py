from src import db
from sqlalchemy import text
from src.model.auditoria_model import AuditoriaModel
from src.model.usuario_token_model import UsuarioTokenModel

class AuditoriaService:
    def get_list(self):
        auditoria_list = AuditoriaModel.query.all()
        return [
            # abaixo vamos combinar o dicionário padrão com o novo elemento e retornamos um dicionário
            {
                **auditoria.serialize(),
                'usuarioTokenModel': self.get_usuario_token(auditoria).serialize() if self.get_usuario_token(auditoria) else None
            }
            for auditoria in auditoria_list
        ]

    def get_list_filter(self, filter_obj):
        return AuditoriaModel.query.filter(text(filter_obj.where)).all()

    def get_object(self, id):
        return AuditoriaModel.query.get_or_404(id)
    
    def insert(self, data):
        obj = AuditoriaModel()
        obj.mapping(data)
        db.session.add(obj)
        db.session.commit()
        return obj

    def update(self, data):
        id = data.get('id')
        obj = AuditoriaModel.query.get_or_404(id)
        obj.mapping(data)
        db.session.commit()
        return obj
    
    def delete(self, id):
        obj = AuditoriaModel.query.get_or_404(id)
        db.session.delete(obj)
        db.session.commit()

    def get_usuario_token(self, auditoria):
        """
        Busca o registro correspondente em UsuarioToken usando o token_jwt.
        """
        return UsuarioTokenModel.query.filter_by(token=auditoria.token_jwt).first()          