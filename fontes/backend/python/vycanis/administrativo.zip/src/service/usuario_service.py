from src import db
from sqlalchemy import text
from src.model.usuario_model import UsuarioModel

class UsuarioService:
    def get_list(self):
        return UsuarioModel.query.all()

    def get_list_filter(self, filter_obj):
        return UsuarioModel.query.filter(text(filter_obj.where)).all()

    def get_object(self, id):
        return UsuarioModel.query.get_or_404(id)
    
    def insert(self, data):
        obj = UsuarioModel()
        obj.mapping(data)
        db.session.add(obj)
        db.session.commit()
        return obj

    def update(self, data):
        id = data.get('id')
        obj = UsuarioModel.query.get_or_404(id)
        obj.mapping(data)
        db.session.commit()
        return obj
    
    def delete(self, id):
        obj = UsuarioModel.query.get_or_404(id)
        db.session.delete(obj)
        db.session.commit()

    def get_usuario_pelo_login(self, login):
        obj = UsuarioModel.query.filter_by(login=login).first_or_404()
        return obj        