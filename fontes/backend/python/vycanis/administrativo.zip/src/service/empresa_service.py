from src import db
from sqlalchemy import text
from src.model.empresa_model import EmpresaModel
from src.model.empresa_contato_model import EmpresaContatoModel
from src.model.empresa_telefone_model import EmpresaTelefoneModel
from src.model.empresa_cnae_model import EmpresaCnaeModel
from src.model.empresa_endereco_model import EmpresaEnderecoModel

class EmpresaService:
    def get_list(self):
        return EmpresaModel.query.all()

    def get_list_filter(self, filter_obj):
        return EmpresaModel.query.filter(text(filter_obj.where)).all()

    def get_object(self, id):
        return EmpresaModel.query.get_or_404(id)
    
    def insert(self, data):
        obj = EmpresaModel()
        obj.mapping(data)
        with db.session.begin_nested():
            db.session.add(obj) 
            self.insert_children(data, obj)
        db.session.commit()  
        return obj

    def update(self, data):
        id = data.get('id')
        obj = EmpresaModel.query.get_or_404(id)
        obj.mapping(data)
        with db.session.begin_nested():
            self.delete_children(obj)
            self.insert_children(data, obj)
        db.session.commit()
        return obj
    
    def delete(self, id):
        obj = EmpresaModel.query.get_or_404(id)
        with db.session.begin_nested():
            self.delete_children(obj)
            db.session.delete(obj)
        db.session.commit()

    def insert_children(self, data, parent):
        # empresaContatoModel
        children_data = data.get('empresaContatoModelList', []) 
        for child_data in children_data:
            child = EmpresaContatoModel()
            child.mapping(child_data)
            parent.empresa_contato_model_list.append(child)
            db.session.add(child)

        # empresaTelefoneModel
        children_data = data.get('empresaTelefoneModelList', []) 
        for child_data in children_data:
            child = EmpresaTelefoneModel()
            child.mapping(child_data)
            parent.empresa_telefone_model_list.append(child)
            db.session.add(child)

        # empresaCnaeModel
        children_data = data.get('empresaCnaeModelList', []) 
        for child_data in children_data:
            child = EmpresaCnaeModel()
            child.mapping(child_data)
            parent.empresa_cnae_model_list.append(child)
            db.session.add(child)

        # empresaEnderecoModel
        children_data = data.get('empresaEnderecoModelList', []) 
        for child_data in children_data:
            child = EmpresaEnderecoModel()
            child.mapping(child_data)
            parent.empresa_endereco_model_list.append(child)
            db.session.add(child)


    def delete_children(self, parent):
        # empresaContatoModel
        for child in parent.empresa_contato_model_list: 
            db.session.delete(child)

        # empresaTelefoneModel
        for child in parent.empresa_telefone_model_list: 
            db.session.delete(child)

        # empresaCnaeModel
        for child in parent.empresa_cnae_model_list: 
            db.session.delete(child)

        # empresaEnderecoModel
        for child in parent.empresa_endereco_model_list: 
            db.session.delete(child)

