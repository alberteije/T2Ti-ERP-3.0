from src import db


class EmpresaTelefoneModel(db.Model):
    __tablename__ = 'empresa_telefone'

    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(1))
    numero = db.Column(db.String(15))
    id_empresa = db.Column(db.Integer, db.ForeignKey('empresa.id'))


    def mapping(self, data):
        self.id = data.get('id')
        self.id_empresa = data.get('idEmpresa')
        self.tipo = data.get('tipo')
        self.numero = data.get('numero')

    def serialize(self):
        return {
            'id': self.id,
            'idEmpresa': self.id_empresa,
            'tipo': self.tipo,
            'numero': self.numero,
        }