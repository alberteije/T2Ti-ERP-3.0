from src import db
from src.model.view_pessoa_colaborador_model import ViewPessoaColaboradorModel
from src.model.papel_model import PapelModel


class UsuarioModel(db.Model):
    __tablename__ = 'usuario'

    id = db.Column(db.Integer, primary_key=True)
    login = db.Column(db.String(50))
    senha = db.Column(db.String(50))
    administrador = db.Column(db.String(1))
    data_cadastro = db.Column(db.DateTime)
    id_colaborador = db.Column(db.Integer, db.ForeignKey('view_pessoa_colaborador.id'))
    id_papel = db.Column(db.Integer, db.ForeignKey('papel.id'))

    view_pessoa_colaborador_model = db.relationship('ViewPessoaColaboradorModel', foreign_keys=[id_colaborador])
    papel_model = db.relationship('PapelModel', foreign_keys=[id_papel])

    def mapping(self, data):
        self.id = data.get('id')
        self.id_papel = data.get('idPapel')
        self.id_colaborador = data.get('idColaborador')
        self.login = data.get('login')
        self.senha = data.get('senha')
        self.administrador = data.get('administrador')
        self.data_cadastro = data.get('dataCadastro')

    def serialize(self):
        return {
            'id': self.id,
            'idPapel': self.id_papel,
            'idColaborador': self.id_colaborador,
            'login': self.login,
            'senha': self.senha,
            'administrador': self.administrador,
            'dataCadastro': self.data_cadastro.isoformat() if self.data_cadastro else None,
            'viewPessoaColaboradorModel': self.view_pessoa_colaborador_model.serialize() if self.view_pessoa_colaborador_model else None,
            'papelModel': self.papel_model.serialize() if self.papel_model else None,
        }