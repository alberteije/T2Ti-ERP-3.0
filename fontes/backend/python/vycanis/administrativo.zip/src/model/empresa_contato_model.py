from src import db


class EmpresaContatoModel(db.Model):
    __tablename__ = 'empresa_contato'

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150))
    email = db.Column(db.String(250))
    observacao = db.Column(db.String(250))
    id_empresa = db.Column(db.Integer, db.ForeignKey('empresa.id'))


    def mapping(self, data):
        self.id = data.get('id')
        self.id_empresa = data.get('idEmpresa')
        self.nome = data.get('nome')
        self.email = data.get('email')
        self.observacao = data.get('observacao')

    def serialize(self):
        return {
            'id': self.id,
            'idEmpresa': self.id_empresa,
            'nome': self.nome,
            'email': self.email,
            'observacao': self.observacao,
        }