from src import db
from src.model.cnae_model import CnaeModel


class EmpresaCnaeModel(db.Model):
    __tablename__ = 'empresa_cnae'

    id = db.Column(db.Integer, primary_key=True)
    principal = db.Column(db.String(1))
    ramo_atividade = db.Column(db.String(50))
    objeto_social = db.Column(db.String(250))
    id_cnae = db.Column(db.Integer, db.ForeignKey('cnae.id'))
    id_empresa = db.Column(db.Integer, db.ForeignKey('empresa.id'))

    cnae_model = db.relationship('CnaeModel', foreign_keys=[id_cnae])

    def mapping(self, data):
        self.id = data.get('id')
        self.id_empresa = data.get('idEmpresa')
        self.id_cnae = data.get('idCnae')
        self.principal = data.get('principal')
        self.ramo_atividade = data.get('ramoAtividade')
        self.objeto_social = data.get('objetoSocial')

    def serialize(self):
        return {
            'id': self.id,
            'idEmpresa': self.id_empresa,
            'idCnae': self.id_cnae,
            'principal': self.principal,
            'ramoAtividade': self.ramo_atividade,
            'objetoSocial': self.objeto_social,
            'cnaeModel': self.cnae_model.serialize() if self.cnae_model else None,
        }