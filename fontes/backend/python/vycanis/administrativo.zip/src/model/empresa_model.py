from src import db
from src.model.empresa_contato_model import EmpresaContatoModel
from src.model.empresa_telefone_model import EmpresaTelefoneModel
from src.model.empresa_cnae_model import EmpresaCnaeModel
from src.model.empresa_endereco_model import EmpresaEnderecoModel


class EmpresaModel(db.Model):
    __tablename__ = 'empresa'

    id = db.Column(db.Integer, primary_key=True)
    razao_social = db.Column(db.String(150))
    nome_fantasia = db.Column(db.String(150))
    cnpj = db.Column(db.String(14))
    inscricao_estadual = db.Column(db.String(45))
    inscricao_municipal = db.Column(db.String(45))
    tipo_regime = db.Column(db.String(1))
    crt = db.Column(db.String(1))
    email = db.Column(db.String(250))
    site = db.Column(db.String(250))
    contato = db.Column(db.String(100))
    data_constituicao = db.Column(db.DateTime)
    tipo = db.Column(db.String(1))
    inscricao_junta_comercial = db.Column(db.String(30))
    data_insc_junta_comercial = db.Column(db.DateTime)
    codigo_ibge_cidade = db.Column(db.Integer)
    codigo_ibge_uf = db.Column(db.Integer)
    cei = db.Column(db.String(12))
    codigo_cnae_principal = db.Column(db.String(7))
    imagem_logotipo = db.Column(db.Text)

    empresa_contato_model_list = db.relationship('EmpresaContatoModel', lazy='dynamic')
    empresa_telefone_model_list = db.relationship('EmpresaTelefoneModel', lazy='dynamic')
    empresa_cnae_model_list = db.relationship('EmpresaCnaeModel', lazy='dynamic')
    empresa_endereco_model_list = db.relationship('EmpresaEnderecoModel', lazy='dynamic')

    def mapping(self, data):
        self.id = data.get('id')
        self.razao_social = data.get('razaoSocial')
        self.nome_fantasia = data.get('nomeFantasia')
        self.cnpj = data.get('cnpj')
        self.inscricao_estadual = data.get('inscricaoEstadual')
        self.inscricao_municipal = data.get('inscricaoMunicipal')
        self.tipo_regime = data.get('tipoRegime')
        self.crt = data.get('crt')
        self.email = data.get('email')
        self.site = data.get('site')
        self.contato = data.get('contato')
        self.data_constituicao = data.get('dataConstituicao')
        self.tipo = data.get('tipo')
        self.inscricao_junta_comercial = data.get('inscricaoJuntaComercial')
        self.data_insc_junta_comercial = data.get('dataInscJuntaComercial')
        self.codigo_ibge_cidade = data.get('codigoIbgeCidade')
        self.codigo_ibge_uf = data.get('codigoIbgeUf')
        self.cei = data.get('cei')
        self.codigo_cnae_principal = data.get('codigoCnaePrincipal')
        self.imagem_logotipo = data.get('imagemLogotipo')

    def serialize(self):
        return {
            'id': self.id,
            'razaoSocial': self.razao_social,
            'nomeFantasia': self.nome_fantasia,
            'cnpj': self.cnpj,
            'inscricaoEstadual': self.inscricao_estadual,
            'inscricaoMunicipal': self.inscricao_municipal,
            'tipoRegime': self.tipo_regime,
            'crt': self.crt,
            'email': self.email,
            'site': self.site,
            'contato': self.contato,
            'dataConstituicao': self.data_constituicao.isoformat() if self.data_constituicao else None,
            'tipo': self.tipo,
            'inscricaoJuntaComercial': self.inscricao_junta_comercial,
            'dataInscJuntaComercial': self.data_insc_junta_comercial.isoformat() if self.data_insc_junta_comercial else None,
            'codigoIbgeCidade': self.codigo_ibge_cidade,
            'codigoIbgeUf': self.codigo_ibge_uf,
            'cei': self.cei,
            'codigoCnaePrincipal': self.codigo_cnae_principal,
            'imagemLogotipo': self.imagem_logotipo,
            'empresaContatoModelList': [empresa_contato_model.serialize() for empresa_contato_model in self.empresa_contato_model_list],
            'empresaTelefoneModelList': [empresa_telefone_model.serialize() for empresa_telefone_model in self.empresa_telefone_model_list],
            'empresaCnaeModelList': [empresa_cnae_model.serialize() for empresa_cnae_model in self.empresa_cnae_model_list],
            'empresaEnderecoModelList': [empresa_endereco_model.serialize() for empresa_endereco_model in self.empresa_endereco_model_list],
        }
