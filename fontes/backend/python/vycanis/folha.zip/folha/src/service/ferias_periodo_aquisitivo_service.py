from src import db
from sqlalchemy import text
from src.model.ferias_periodo_aquisitivo_model import FeriasPeriodoAquisitivoModel

class FeriasPeriodoAquisitivoService:
    def get_list(self):
        return FeriasPeriodoAquisitivoModel.query.all()

    def get_list_filter(self, filter_obj):
        return FeriasPeriodoAquisitivoModel.query.filter(text(filter_obj.where)).all()

    def get_object(self, id):
        return FeriasPeriodoAquisitivoModel.query.get_or_404(id)
    
    def insert(self, data):
        obj = FeriasPeriodoAquisitivoModel()
        obj.mapping(data)
        db.session.add(obj)
        db.session.commit()
        return obj

    def update(self, data):
        id = data.get('id')
        obj = FeriasPeriodoAquisitivoModel.query.get_or_404(id)
        obj.mapping(data)
        db.session.commit()
        return obj
    
    def delete(self, id):
        obj = FeriasPeriodoAquisitivoModel.query.get_or_404(id)
        db.session.delete(obj)
        db.session.commit()