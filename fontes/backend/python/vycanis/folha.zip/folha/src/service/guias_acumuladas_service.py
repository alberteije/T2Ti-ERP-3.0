from src import db
from sqlalchemy import text
from src.model.guias_acumuladas_model import GuiasAcumuladasModel

class GuiasAcumuladasService:
    def get_list(self):
        return GuiasAcumuladasModel.query.all()

    def get_list_filter(self, filter_obj):
        return GuiasAcumuladasModel.query.filter(text(filter_obj.where)).all()

    def get_object(self, id):
        return GuiasAcumuladasModel.query.get_or_404(id)
    
    def insert(self, data):
        obj = GuiasAcumuladasModel()
        obj.mapping(data)
        db.session.add(obj)
        db.session.commit()
        return obj

    def update(self, data):
        id = data.get('id')
        obj = GuiasAcumuladasModel.query.get_or_404(id)
        obj.mapping(data)
        db.session.commit()
        return obj
    
    def delete(self, id):
        obj = GuiasAcumuladasModel.query.get_or_404(id)
        db.session.delete(obj)
        db.session.commit()