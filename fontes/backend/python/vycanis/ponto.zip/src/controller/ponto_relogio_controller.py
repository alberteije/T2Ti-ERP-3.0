from flask import Blueprint, request, jsonify
from src.model.transient.filter import Filter
from src.service.ponto_relogio_service import PontoRelogioService

ponto_relogio_bp = Blueprint('ponto-relogio', __name__)
service = PontoRelogioService()

@ponto_relogio_bp.route('/ponto-relogio', methods=['GET'])
@ponto_relogio_bp.route('/ponto-relogio/', methods=['GET'])
def get_list():
    query_params = request.args
    filter_obj = Filter(query_params)    
    if filter_obj.where:
        result_list = service.get_list_filter(filter_obj)
    else:
        result_list = service.get_list()
    return jsonify([obj.serialize() for obj in result_list])

@ponto_relogio_bp.route('/ponto-relogio/<int:id>', methods=['GET'])
def get_object(id):
    obj = service.get_object(id)
    return jsonify(obj.serialize())

@ponto_relogio_bp.route('/ponto-relogio', methods=['POST'])
def insert():
    data = request.json
    result = service.insert(data)
    return jsonify(result.serialize()), 201

@ponto_relogio_bp.route('/ponto-relogio', methods=['PUT'])
def update():
    data = request.json
    result = service.update(data)
    return jsonify(result.serialize()), 200

@ponto_relogio_bp.route('/ponto-relogio/<int:id>', methods=['DELETE'])
def delete(id):
    service.delete(id)
    return jsonify({'message': 'Deleted successfully'})