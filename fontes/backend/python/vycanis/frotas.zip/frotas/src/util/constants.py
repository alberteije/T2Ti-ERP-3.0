CHAVE = "#Sua-Chave-de-32-caracteres-aqui"
VETOR = "#Seu-Vetor-aqui#"