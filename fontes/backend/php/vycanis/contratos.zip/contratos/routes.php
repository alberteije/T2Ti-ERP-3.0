<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// contrato
$app->get('/contrato[/]', \ContratoController::class . RESULT_LIST);
$app->get('/contrato/{id}', \ContratoController::class . RESULT_OBJECT);
$app->post('/contrato', \ContratoController::class . INSERT);
$app->put('/contrato', \ContratoController::class . UPDATE);
$app->delete('/contrato/{id}', \ContratoController::class . DELETE);
$app->options('/contrato', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// setor
$app->get('/setor[/]', \SetorController::class . RESULT_LIST);
$app->get('/setor/{id}', \SetorController::class . RESULT_OBJECT);
$app->post('/setor', \SetorController::class . INSERT);
$app->put('/setor', \SetorController::class . UPDATE);
$app->delete('/setor/{id}', \SetorController::class . DELETE);
$app->options('/setor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tipo-contrato
$app->get('/tipo-contrato[/]', \TipoContratoController::class . RESULT_LIST);
$app->get('/tipo-contrato/{id}', \TipoContratoController::class . RESULT_OBJECT);
$app->post('/tipo-contrato', \TipoContratoController::class . INSERT);
$app->put('/tipo-contrato', \TipoContratoController::class . UPDATE);
$app->delete('/tipo-contrato/{id}', \TipoContratoController::class . DELETE);
$app->options('/tipo-contrato', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-contrato/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-contrato/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contrato-tipo-servico
$app->get('/contrato-tipo-servico[/]', \ContratoTipoServicoController::class . RESULT_LIST);
$app->get('/contrato-tipo-servico/{id}', \ContratoTipoServicoController::class . RESULT_OBJECT);
$app->post('/contrato-tipo-servico', \ContratoTipoServicoController::class . INSERT);
$app->put('/contrato-tipo-servico', \ContratoTipoServicoController::class . UPDATE);
$app->delete('/contrato-tipo-servico/{id}', \ContratoTipoServicoController::class . DELETE);
$app->options('/contrato-tipo-servico', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato-tipo-servico/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato-tipo-servico/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contrato-solicitacao-servico
$app->get('/contrato-solicitacao-servico[/]', \ContratoSolicitacaoServicoController::class . RESULT_LIST);
$app->get('/contrato-solicitacao-servico/{id}', \ContratoSolicitacaoServicoController::class . RESULT_OBJECT);
$app->post('/contrato-solicitacao-servico', \ContratoSolicitacaoServicoController::class . INSERT);
$app->put('/contrato-solicitacao-servico', \ContratoSolicitacaoServicoController::class . UPDATE);
$app->delete('/contrato-solicitacao-servico/{id}', \ContratoSolicitacaoServicoController::class . DELETE);
$app->options('/contrato-solicitacao-servico', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato-solicitacao-servico/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato-solicitacao-servico/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contrato-template
$app->get('/contrato-template[/]', \ContratoTemplateController::class . RESULT_LIST);
$app->get('/contrato-template/{id}', \ContratoTemplateController::class . RESULT_OBJECT);
$app->post('/contrato-template', \ContratoTemplateController::class . INSERT);
$app->put('/contrato-template', \ContratoTemplateController::class . UPDATE);
$app->delete('/contrato-template/{id}', \ContratoTemplateController::class . DELETE);
$app->options('/contrato-template', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato-template/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contrato-template/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-cliente
$app->get('/view-pessoa-cliente[/]', \ViewPessoaClienteController::class . RESULT_LIST);
$app->get('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . RESULT_OBJECT);
$app->post('/view-pessoa-cliente', \ViewPessoaClienteController::class . INSERT);
$app->put('/view-pessoa-cliente', \ViewPessoaClienteController::class . UPDATE);
$app->delete('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . DELETE);
$app->options('/view-pessoa-cliente', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-fornecedor
$app->get('/view-pessoa-fornecedor[/]', \ViewPessoaFornecedorController::class . RESULT_LIST);
$app->get('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . INSERT);
$app->put('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . UPDATE);
$app->delete('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . DELETE);
$app->options('/view-pessoa-fornecedor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

