<?php
class ContratoTipoServicoService extends ServiceBase
{
  public function getList()
  {
    return ContratoTipoServicoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContratoTipoServicoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContratoTipoServicoModel::find($id);
  }

}