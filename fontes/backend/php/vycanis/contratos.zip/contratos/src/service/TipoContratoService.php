<?php
class TipoContratoService extends ServiceBase
{
  public function getList()
  {
    return TipoContratoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TipoContratoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return TipoContratoModel::find($id);
  }

}