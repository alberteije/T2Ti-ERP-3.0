<?php

include 'ServiceBase.php';

include 'ContratoService.php';
include 'SetorService.php';
include 'TipoContratoService.php';
include 'ContratoTipoServicoService.php';
include 'ContratoSolicitacaoServicoService.php';
include 'ContratoTemplateService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaClienteService.php';
include 'ViewPessoaFornecedorService.php';
include 'ViewPessoaColaboradorService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';