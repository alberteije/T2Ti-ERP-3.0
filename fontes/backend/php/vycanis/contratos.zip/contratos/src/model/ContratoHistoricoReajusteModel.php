<?php
declare(strict_types=1);

class ContratoHistoricoReajusteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contrato_historico_reajuste';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function contratoModel()
	{
		return $this->belongsTo(ContratoModel::class, 'id_contrato', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIndiceAttribute()
	{
		return (double)$this->attributes['indice'];
	}

	public function setIndiceAttribute($indice)
	{
		$this->attributes['indice'] = $indice;
	}

	public function getValorAnteriorAttribute()
	{
		return (double)$this->attributes['valor_anterior'];
	}

	public function setValorAnteriorAttribute($valorAnterior)
	{
		$this->attributes['valor_anterior'] = $valorAnterior;
	}

	public function getValorAtualAttribute()
	{
		return (double)$this->attributes['valor_atual'];
	}

	public function setValorAtualAttribute($valorAtual)
	{
		$this->attributes['valor_atual'] = $valorAtual;
	}

	public function getDataReajusteAttribute()
	{
		return $this->attributes['data_reajuste'];
	}

	public function setDataReajusteAttribute($dataReajuste)
	{
		$this->attributes['data_reajuste'] = $dataReajuste;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIndiceAttribute($object->indice);
				$this->setValorAnteriorAttribute($object->valorAnterior);
				$this->setValorAtualAttribute($object->valorAtual);
				$this->setDataReajusteAttribute($object->dataReajuste);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'indice' => $this->getIndiceAttribute(),
				'valorAnterior' => $this->getValorAnteriorAttribute(),
				'valorAtual' => $this->getValorAtualAttribute(),
				'dataReajuste' => $this->getDataReajusteAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}