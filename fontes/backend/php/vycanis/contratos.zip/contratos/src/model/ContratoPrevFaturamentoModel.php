<?php
declare(strict_types=1);

class ContratoPrevFaturamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contrato_prev_faturamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function contratoModel()
	{
		return $this->belongsTo(ContratoModel::class, 'id_contrato', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataPrevistaAttribute()
	{
		return $this->attributes['data_prevista'];
	}

	public function setDataPrevistaAttribute($dataPrevista)
	{
		$this->attributes['data_prevista'] = $dataPrevista;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataPrevistaAttribute($object->dataPrevista);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataPrevista' => $this->getDataPrevistaAttribute(),
				'valor' => $this->getValorAttribute(),
			];
	}
}