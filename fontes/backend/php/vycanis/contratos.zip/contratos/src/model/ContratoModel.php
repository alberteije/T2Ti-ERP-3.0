<?php
declare(strict_types=1);

class ContratoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contrato';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contratoHistoricoReajusteModelList',
		'contratoPrevFaturamentoModelList',
		'contratoHistFaturamentoModelList',
		'tipoContratoModel',
		'contratoSolicitacaoServicoModel',
	];

	/**
		* Relations
		*/
	public function contratoHistoricoReajusteModelList()
{
	return $this->hasMany(ContratoHistoricoReajusteModel::class, 'id_contrato', 'id');
}

	public function contratoPrevFaturamentoModelList()
{
	return $this->hasMany(ContratoPrevFaturamentoModel::class, 'id_contrato', 'id');
}

	public function contratoHistFaturamentoModelList()
{
	return $this->hasMany(ContratoHistFaturamentoModel::class, 'id_contrato', 'id');
}

	public function tipoContratoModel()
	{
		return $this->belongsTo(TipoContratoModel::class, 'id_tipo_contrato', 'id');
	}

	public function contratoSolicitacaoServicoModel()
	{
		return $this->belongsTo(ContratoSolicitacaoServicoModel::class, 'id_solicitacao_servico', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getDataInicioVigenciaAttribute()
	{
		return $this->attributes['data_inicio_vigencia'];
	}

	public function setDataInicioVigenciaAttribute($dataInicioVigencia)
	{
		$this->attributes['data_inicio_vigencia'] = $dataInicioVigencia;
	}

	public function getDataFimVigenciaAttribute()
	{
		return $this->attributes['data_fim_vigencia'];
	}

	public function setDataFimVigenciaAttribute($dataFimVigencia)
	{
		$this->attributes['data_fim_vigencia'] = $dataFimVigencia;
	}

	public function getDiaFaturamentoAttribute()
	{
		return $this->attributes['dia_faturamento'];
	}

	public function setDiaFaturamentoAttribute($diaFaturamento)
	{
		$this->attributes['dia_faturamento'] = $diaFaturamento;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getQuantidadeParcelasAttribute()
	{
		return $this->attributes['quantidade_parcelas'];
	}

	public function setQuantidadeParcelasAttribute($quantidadeParcelas)
	{
		$this->attributes['quantidade_parcelas'] = $quantidadeParcelas;
	}

	public function getIntervaloEntreParcelasAttribute()
	{
		return $this->attributes['intervalo_entre_parcelas'];
	}

	public function setIntervaloEntreParcelasAttribute($intervaloEntreParcelas)
	{
		$this->attributes['intervalo_entre_parcelas'] = $intervaloEntreParcelas;
	}

	public function getClassificacaoContabilContaAttribute()
	{
		return $this->attributes['classificacao_contabil_conta'];
	}

	public function setClassificacaoContabilContaAttribute($classificacaoContabilConta)
	{
		$this->attributes['classificacao_contabil_conta'] = $classificacaoContabilConta;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setDataInicioVigenciaAttribute($object->dataInicioVigencia);
				$this->setDataFimVigenciaAttribute($object->dataFimVigencia);
				$this->setDiaFaturamentoAttribute($object->diaFaturamento);
				$this->setValorAttribute($object->valor);
				$this->setQuantidadeParcelasAttribute($object->quantidadeParcelas);
				$this->setIntervaloEntreParcelasAttribute($object->intervaloEntreParcelas);
				$this->setClassificacaoContabilContaAttribute($object->classificacaoContabilConta);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$tipoContratoModel = new TipoContratoModel();
				$tipoContratoModel->mapping($object->tipoContratoModel);
				$this->tipoContratoModel()->associate($tipoContratoModel);
				$contratoSolicitacaoServicoModel = new ContratoSolicitacaoServicoModel();
				$contratoSolicitacaoServicoModel->mapping($object->contratoSolicitacaoServicoModel);
				$this->contratoSolicitacaoServicoModel()->associate($contratoSolicitacaoServicoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'dataInicioVigencia' => $this->getDataInicioVigenciaAttribute(),
				'dataFimVigencia' => $this->getDataFimVigenciaAttribute(),
				'diaFaturamento' => $this->getDiaFaturamentoAttribute(),
				'valor' => $this->getValorAttribute(),
				'quantidadeParcelas' => $this->getQuantidadeParcelasAttribute(),
				'intervaloEntreParcelas' => $this->getIntervaloEntreParcelasAttribute(),
				'classificacaoContabilConta' => $this->getClassificacaoContabilContaAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'contratoHistoricoReajusteModelList' => $this->contratoHistoricoReajusteModelList,
				'contratoPrevFaturamentoModelList' => $this->contratoPrevFaturamentoModelList,
				'contratoHistFaturamentoModelList' => $this->contratoHistFaturamentoModelList,
				'tipoContratoModel' => $this->tipoContratoModel,
				'contratoSolicitacaoServicoModel' => $this->contratoSolicitacaoServicoModel,
			];
	}
}