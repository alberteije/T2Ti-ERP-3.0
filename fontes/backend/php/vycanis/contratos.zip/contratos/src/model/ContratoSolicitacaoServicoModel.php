<?php
declare(strict_types=1);

class ContratoSolicitacaoServicoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contrato_solicitacao_servico';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
		'viewPessoaClienteModel',
		'viewPessoaFornecedorModel',
		'setorModel',
		'contratoTipoServicoModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}

	public function viewPessoaFornecedorModel()
	{
		return $this->belongsTo(ViewPessoaFornecedorModel::class, 'id_fornecedor', 'id');
	}

	public function setorModel()
	{
		return $this->belongsTo(SetorModel::class, 'id_setor', 'id');
	}

	public function contratoTipoServicoModel()
	{
		return $this->belongsTo(ContratoTipoServicoModel::class, 'id_contrato_tipo_servico', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataSolicitacaoAttribute()
	{
		return $this->attributes['data_solicitacao'];
	}

	public function setDataSolicitacaoAttribute($dataSolicitacao)
	{
		$this->attributes['data_solicitacao'] = $dataSolicitacao;
	}

	public function getDataDesejadaInicioAttribute()
	{
		return $this->attributes['data_desejada_inicio'];
	}

	public function setDataDesejadaInicioAttribute($dataDesejadaInicio)
	{
		$this->attributes['data_desejada_inicio'] = $dataDesejadaInicio;
	}

	public function getUrgenteAttribute()
	{
		return $this->attributes['urgente'];
	}

	public function setUrgenteAttribute($urgente)
	{
		$this->attributes['urgente'] = $urgente;
	}

	public function getStatusSolicitacaoAttribute()
	{
		return $this->attributes['status_solicitacao'];
	}

	public function setStatusSolicitacaoAttribute($statusSolicitacao)
	{
		$this->attributes['status_solicitacao'] = $statusSolicitacao;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataSolicitacaoAttribute($object->dataSolicitacao);
				$this->setDataDesejadaInicioAttribute($object->dataDesejadaInicio);
				$this->setUrgenteAttribute($object->urgente);
				$this->setStatusSolicitacaoAttribute($object->statusSolicitacao);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
				$viewPessoaFornecedorModel = new ViewPessoaFornecedorModel();
				$viewPessoaFornecedorModel->mapping($object->viewPessoaFornecedorModel);
				$this->viewPessoaFornecedorModel()->associate($viewPessoaFornecedorModel);
				$setorModel = new SetorModel();
				$setorModel->mapping($object->setorModel);
				$this->setorModel()->associate($setorModel);
				$contratoTipoServicoModel = new ContratoTipoServicoModel();
				$contratoTipoServicoModel->mapping($object->contratoTipoServicoModel);
				$this->contratoTipoServicoModel()->associate($contratoTipoServicoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataSolicitacao' => $this->getDataSolicitacaoAttribute(),
				'dataDesejadaInicio' => $this->getDataDesejadaInicioAttribute(),
				'urgente' => $this->getUrgenteAttribute(),
				'statusSolicitacao' => $this->getStatusSolicitacaoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
				'viewPessoaFornecedorModel' => $this->viewPessoaFornecedorModel,
				'setorModel' => $this->setorModel,
				'contratoTipoServicoModel' => $this->contratoTipoServicoModel,
			];
	}
}