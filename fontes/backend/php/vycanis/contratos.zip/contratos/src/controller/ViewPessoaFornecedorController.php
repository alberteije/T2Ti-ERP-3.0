<?php
class ViewPessoaFornecedorController extends ControllerBase
{

		private $viewPessoaFornecedorService = null;

		public function __construct()
		{	 
				$this->viewPessoaFornecedorService = new ViewPessoaFornecedorService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->viewPessoaFornecedorService->getListFilter($filter);
						} else {
								$resultList = $this->viewPessoaFornecedorService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList ViewPessoaFornecedor]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->viewPessoaFornecedorService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject ViewPessoaFornecedor]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject ViewPessoaFornecedor]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert ViewPessoaFornecedor]', null);
						}

						$objModel = new ViewPessoaFornecedorModel();
						$objModel->mapping($objJson);

						$this->viewPessoaFornecedorService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert ViewPessoaFornecedor]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->viewPessoaFornecedorService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update ViewPessoaFornecedor]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->viewPessoaFornecedorService->save($objFromDatabase);
								$objFromDatabase = $this->viewPessoaFornecedorService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update ViewPessoaFornecedor]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->viewPessoaFornecedorService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete ViewPessoaFornecedor]', null);
						} else {
								$this->viewPessoaFornecedorService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete ViewPessoaFornecedor]', $e);
				}
		}
}
