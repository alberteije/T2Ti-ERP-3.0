<?php

include 'ControllerBase.php';
include 'LoginController.php';

include 'ContratoController.php';
include 'SetorController.php';
include 'TipoContratoController.php';
include 'ContratoTipoServicoController.php';
include 'ContratoSolicitacaoServicoController.php';
include 'ContratoTemplateController.php';
include 'ViewControleAcessoController.php';
include 'ViewPessoaUsuarioController.php';
include 'ViewPessoaClienteController.php';
include 'ViewPessoaFornecedorController.php';
include 'ViewPessoaColaboradorController.php';