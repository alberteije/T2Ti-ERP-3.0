<?php
class ContratoSolicitacaoServicoController extends ControllerBase
{

		private $contratoSolicitacaoServicoService = null;

		public function __construct()
		{	 
				$this->contratoSolicitacaoServicoService = new ContratoSolicitacaoServicoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->contratoSolicitacaoServicoService->getListFilter($filter);
						} else {
								$resultList = $this->contratoSolicitacaoServicoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList ContratoSolicitacaoServico]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contratoSolicitacaoServicoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject ContratoSolicitacaoServico]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject ContratoSolicitacaoServico]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert ContratoSolicitacaoServico]', null);
						}

						$objModel = new ContratoSolicitacaoServicoModel();
						$objModel->mapping($objJson);

						$this->contratoSolicitacaoServicoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert ContratoSolicitacaoServico]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->contratoSolicitacaoServicoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update ContratoSolicitacaoServico]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->contratoSolicitacaoServicoService->save($objFromDatabase);
								$objFromDatabase = $this->contratoSolicitacaoServicoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update ContratoSolicitacaoServico]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contratoSolicitacaoServicoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete ContratoSolicitacaoServico]', null);
						} else {
								$this->contratoSolicitacaoServicoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete ContratoSolicitacaoServico]', $e);
				}
		}
}
