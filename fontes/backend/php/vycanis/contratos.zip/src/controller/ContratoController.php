<?php
class ContratoController extends ControllerBase
{

		private $contratoService = null;

		public function __construct()
		{	 
				$this->contratoService = new ContratoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->contratoService->getListFilter($filter);
						} else {
								$resultList = $this->contratoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList Contrato]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contratoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject Contrato]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject Contrato]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert Contrato]', null);
						}

						$objModel = new ContratoModel();
						$objModel->mapping($objJson);

						$this->contratoService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert Contrato]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->contratoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update Contrato]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->contratoService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->contratoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update Contrato]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contratoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete Contrato]', null);
						} else {
								$this->contratoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete Contrato]', $e);
				}
		}
}
