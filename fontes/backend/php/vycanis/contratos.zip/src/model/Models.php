<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'ContratoHistoricoReajusteModel.php';
include 'ContratoPrevFaturamentoModel.php';
include 'ContratoHistFaturamentoModel.php';
include 'ContratoModel.php';
include 'SetorModel.php';
include 'TipoContratoModel.php';
include 'ContratoTipoServicoModel.php';
include 'ContratoSolicitacaoServicoModel.php';
include 'ContratoTemplateModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaClienteModel.php';
include 'ViewPessoaFornecedorModel.php';
include 'ViewPessoaColaboradorModel.php';