<?php
declare(strict_types=1);

class Util 
{

	public static function camelCase($string)
	{
		$stringRetorno = ucwords(strtolower($string), "_");
		$stringRetorno = str_replace("_", "", $stringRetorno);
		$stringRetorno = lcfirst($stringRetorno);
		return $stringRetorno;
	}	

	public static function sortArray(&$array, $field, $order = 'ASC') {
		usort(
			$array,
			function($a, $b) use ($order, $field) {
			if($a->$field == $b->$field) return 0;
				return (($a->$field < $b->$field) ? ($order == 'ASC' ? -1 : 1) : ($order == 'ASC' ? 1 : -1));
			}
		);				
	}

	public static function crypt(string $valor) {
		$cifra_data = openssl_encrypt($valor, CYPHER, MAIN_KEY, OPENSSL_RAW_DATA, MAIN_VECTOR);
		$cifra_data_base64 = base64_encode($cifra_data);	
		return $cifra_data_base64;
	}

	public static function decrypt(string $valor) {
		$decifra_data_base64 = base64_decode($valor);
		$decifra_data = openssl_decrypt($decifra_data_base64, CYPHER, MAIN_KEY, OPENSSL_RAW_DATA, MAIN_VECTOR);
		return $decifra_data;
	}    
}