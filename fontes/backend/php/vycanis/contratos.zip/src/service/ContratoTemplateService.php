<?php
class ContratoTemplateService extends ServiceBase
{
  public function getList()
  {
    return ContratoTemplateModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContratoTemplateModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContratoTemplateModel::find($id);
  }

}