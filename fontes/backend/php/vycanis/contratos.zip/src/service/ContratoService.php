<?php
use Illuminate\Database\Capsule\Manager as DB;
class ContratoService extends ServiceBase
{
	public function getList()
	{
		return ContratoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ContratoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ContratoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// contratoHistoricoReajuste
		$contratoHistoricoReajusteModelListJson = $objJson->contratoHistoricoReajusteModelList;
		if ($contratoHistoricoReajusteModelListJson != null) {
			for ($i = 0; $i < count($contratoHistoricoReajusteModelListJson); $i++) {
				$contratoHistoricoReajuste = new ContratoHistoricoReajusteModel();
				$contratoHistoricoReajuste->mapping($contratoHistoricoReajusteModelListJson[$i]);
				$objModel->contratoHistoricoReajusteModelList()->save($contratoHistoricoReajuste);
			}
		}

		// contratoPrevFaturamento
		$contratoPrevFaturamentoModelListJson = $objJson->contratoPrevFaturamentoModelList;
		if ($contratoPrevFaturamentoModelListJson != null) {
			for ($i = 0; $i < count($contratoPrevFaturamentoModelListJson); $i++) {
				$contratoPrevFaturamento = new ContratoPrevFaturamentoModel();
				$contratoPrevFaturamento->mapping($contratoPrevFaturamentoModelListJson[$i]);
				$objModel->contratoPrevFaturamentoModelList()->save($contratoPrevFaturamento);
			}
		}

		// contratoHistFaturamento
		$contratoHistFaturamentoModelListJson = $objJson->contratoHistFaturamentoModelList;
		if ($contratoHistFaturamentoModelListJson != null) {
			for ($i = 0; $i < count($contratoHistFaturamentoModelListJson); $i++) {
				$contratoHistFaturamento = new ContratoHistFaturamentoModel();
				$contratoHistFaturamento->mapping($contratoHistFaturamentoModelListJson[$i]);
				$objModel->contratoHistFaturamentoModelList()->save($contratoHistFaturamento);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ContratoHistoricoReajusteModel::where('id_contrato', $object->getIdAttribute())->delete();
		ContratoPrevFaturamentoModel::where('id_contrato', $object->getIdAttribute())->delete();
		ContratoHistFaturamentoModel::where('id_contrato', $object->getIdAttribute())->delete();
	}	
 
}