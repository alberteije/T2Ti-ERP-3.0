<?php
class SetorService extends ServiceBase
{
  public function getList()
  {
    return SetorModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SetorModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SetorModel::find($id);
  }

}