<?php
class ContratoSolicitacaoServicoService extends ServiceBase
{
  public function getList()
  {
    return ContratoSolicitacaoServicoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContratoSolicitacaoServicoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContratoSolicitacaoServicoModel::find($id);
  }

}