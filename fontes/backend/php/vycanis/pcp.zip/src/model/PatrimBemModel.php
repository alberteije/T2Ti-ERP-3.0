<?php
declare(strict_types=1);

class PatrimBemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_bem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdCentroResultadoAttribute()
	{
		return $this->attributes['id_centro_resultado'];
	}

	public function setIdCentroResultadoAttribute($idCentroResultado)
	{
		$this->attributes['id_centro_resultado'] = $idCentroResultado;
	}

	public function getIdPatrimTipoAquisicaoBemAttribute()
	{
		return $this->attributes['id_patrim_tipo_aquisicao_bem'];
	}

	public function setIdPatrimTipoAquisicaoBemAttribute($idPatrimTipoAquisicaoBem)
	{
		$this->attributes['id_patrim_tipo_aquisicao_bem'] = $idPatrimTipoAquisicaoBem;
	}

	public function getIdPatrimEstadoConservacaoAttribute()
	{
		return $this->attributes['id_patrim_estado_conservacao'];
	}

	public function setIdPatrimEstadoConservacaoAttribute($idPatrimEstadoConservacao)
	{
		$this->attributes['id_patrim_estado_conservacao'] = $idPatrimEstadoConservacao;
	}

	public function getIdPatrimGrupoBemAttribute()
	{
		return $this->attributes['id_patrim_grupo_bem'];
	}

	public function setIdPatrimGrupoBemAttribute($idPatrimGrupoBem)
	{
		$this->attributes['id_patrim_grupo_bem'] = $idPatrimGrupoBem;
	}

	public function getIdFornecedorAttribute()
	{
		return $this->attributes['id_fornecedor'];
	}

	public function setIdFornecedorAttribute($idFornecedor)
	{
		$this->attributes['id_fornecedor'] = $idFornecedor;
	}

	public function getIdSetorAttribute()
	{
		return $this->attributes['id_setor'];
	}

	public function setIdSetorAttribute($idSetor)
	{
		$this->attributes['id_setor'] = $idSetor;
	}

	public function getNumeroNbAttribute()
	{
		return $this->attributes['numero_nb'];
	}

	public function setNumeroNbAttribute($numeroNb)
	{
		$this->attributes['numero_nb'] = $numeroNb;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getNumeroSerieAttribute()
	{
		return $this->attributes['numero_serie'];
	}

	public function setNumeroSerieAttribute($numeroSerie)
	{
		$this->attributes['numero_serie'] = $numeroSerie;
	}

	public function getDataAquisicaoAttribute()
	{
		return $this->attributes['data_aquisicao'];
	}

	public function setDataAquisicaoAttribute($dataAquisicao)
	{
		$this->attributes['data_aquisicao'] = $dataAquisicao;
	}

	public function getDataAceiteAttribute()
	{
		return $this->attributes['data_aceite'];
	}

	public function setDataAceiteAttribute($dataAceite)
	{
		$this->attributes['data_aceite'] = $dataAceite;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getDataContabilizadoAttribute()
	{
		return $this->attributes['data_contabilizado'];
	}

	public function setDataContabilizadoAttribute($dataContabilizado)
	{
		$this->attributes['data_contabilizado'] = $dataContabilizado;
	}

	public function getDataVistoriaAttribute()
	{
		return $this->attributes['data_vistoria'];
	}

	public function setDataVistoriaAttribute($dataVistoria)
	{
		$this->attributes['data_vistoria'] = $dataVistoria;
	}

	public function getDataMarcacaoAttribute()
	{
		return $this->attributes['data_marcacao'];
	}

	public function setDataMarcacaoAttribute($dataMarcacao)
	{
		$this->attributes['data_marcacao'] = $dataMarcacao;
	}

	public function getDataBaixaAttribute()
	{
		return $this->attributes['data_baixa'];
	}

	public function setDataBaixaAttribute($dataBaixa)
	{
		$this->attributes['data_baixa'] = $dataBaixa;
	}

	public function getVencimentoGarantiaAttribute()
	{
		return $this->attributes['vencimento_garantia'];
	}

	public function setVencimentoGarantiaAttribute($vencimentoGarantia)
	{
		$this->attributes['vencimento_garantia'] = $vencimentoGarantia;
	}

	public function getNumeroNotaFiscalAttribute()
	{
		return $this->attributes['numero_nota_fiscal'];
	}

	public function setNumeroNotaFiscalAttribute($numeroNotaFiscal)
	{
		$this->attributes['numero_nota_fiscal'] = $numeroNotaFiscal;
	}

	public function getChaveNfeAttribute()
	{
		return $this->attributes['chave_nfe'];
	}

	public function setChaveNfeAttribute($chaveNfe)
	{
		$this->attributes['chave_nfe'] = $chaveNfe;
	}

	public function getValorOriginalAttribute()
	{
		return (double)$this->attributes['valor_original'];
	}

	public function setValorOriginalAttribute($valorOriginal)
	{
		$this->attributes['valor_original'] = $valorOriginal;
	}

	public function getValorCompraAttribute()
	{
		return (double)$this->attributes['valor_compra'];
	}

	public function setValorCompraAttribute($valorCompra)
	{
		$this->attributes['valor_compra'] = $valorCompra;
	}

	public function getValorAtualizadoAttribute()
	{
		return (double)$this->attributes['valor_atualizado'];
	}

	public function setValorAtualizadoAttribute($valorAtualizado)
	{
		$this->attributes['valor_atualizado'] = $valorAtualizado;
	}

	public function getValorBaixaAttribute()
	{
		return (double)$this->attributes['valor_baixa'];
	}

	public function setValorBaixaAttribute($valorBaixa)
	{
		$this->attributes['valor_baixa'] = $valorBaixa;
	}

	public function getDepreciaAttribute()
	{
		return $this->attributes['deprecia'];
	}

	public function setDepreciaAttribute($deprecia)
	{
		$this->attributes['deprecia'] = $deprecia;
	}

	public function getMetodoDepreciacaoAttribute()
	{
		return $this->attributes['metodo_depreciacao'];
	}

	public function setMetodoDepreciacaoAttribute($metodoDepreciacao)
	{
		$this->attributes['metodo_depreciacao'] = $metodoDepreciacao;
	}

	public function getInicioDepreciacaoAttribute()
	{
		return $this->attributes['inicio_depreciacao'];
	}

	public function setInicioDepreciacaoAttribute($inicioDepreciacao)
	{
		$this->attributes['inicio_depreciacao'] = $inicioDepreciacao;
	}

	public function getUltimaDepreciacaoAttribute()
	{
		return $this->attributes['ultima_depreciacao'];
	}

	public function setUltimaDepreciacaoAttribute($ultimaDepreciacao)
	{
		$this->attributes['ultima_depreciacao'] = $ultimaDepreciacao;
	}

	public function getTipoDepreciacaoAttribute()
	{
		return $this->attributes['tipo_depreciacao'];
	}

	public function setTipoDepreciacaoAttribute($tipoDepreciacao)
	{
		$this->attributes['tipo_depreciacao'] = $tipoDepreciacao;
	}

	public function getTaxaAnualDepreciacaoAttribute()
	{
		return (double)$this->attributes['taxa_anual_depreciacao'];
	}

	public function setTaxaAnualDepreciacaoAttribute($taxaAnualDepreciacao)
	{
		$this->attributes['taxa_anual_depreciacao'] = $taxaAnualDepreciacao;
	}

	public function getTaxaMensalDepreciacaoAttribute()
	{
		return (double)$this->attributes['taxa_mensal_depreciacao'];
	}

	public function setTaxaMensalDepreciacaoAttribute($taxaMensalDepreciacao)
	{
		$this->attributes['taxa_mensal_depreciacao'] = $taxaMensalDepreciacao;
	}

	public function getTaxaDepreciacaoAceleradaAttribute()
	{
		return (double)$this->attributes['taxa_depreciacao_acelerada'];
	}

	public function setTaxaDepreciacaoAceleradaAttribute($taxaDepreciacaoAcelerada)
	{
		$this->attributes['taxa_depreciacao_acelerada'] = $taxaDepreciacaoAcelerada;
	}

	public function getTaxaDepreciacaoIncentivadaAttribute()
	{
		return (double)$this->attributes['taxa_depreciacao_incentivada'];
	}

	public function setTaxaDepreciacaoIncentivadaAttribute($taxaDepreciacaoIncentivada)
	{
		$this->attributes['taxa_depreciacao_incentivada'] = $taxaDepreciacaoIncentivada;
	}

	public function getFuncaoAttribute()
	{
		return $this->attributes['funcao'];
	}

	public function setFuncaoAttribute($funcao)
	{
		$this->attributes['funcao'] = $funcao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdCentroResultadoAttribute($object->idCentroResultado);
				$this->setIdPatrimTipoAquisicaoBemAttribute($object->idPatrimTipoAquisicaoBem);
				$this->setIdPatrimEstadoConservacaoAttribute($object->idPatrimEstadoConservacao);
				$this->setIdPatrimGrupoBemAttribute($object->idPatrimGrupoBem);
				$this->setIdFornecedorAttribute($object->idFornecedor);
				$this->setIdSetorAttribute($object->idSetor);
				$this->setNumeroNbAttribute($object->numeroNb);
				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setNumeroSerieAttribute($object->numeroSerie);
				$this->setDataAquisicaoAttribute($object->dataAquisicao);
				$this->setDataAceiteAttribute($object->dataAceite);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setDataContabilizadoAttribute($object->dataContabilizado);
				$this->setDataVistoriaAttribute($object->dataVistoria);
				$this->setDataMarcacaoAttribute($object->dataMarcacao);
				$this->setDataBaixaAttribute($object->dataBaixa);
				$this->setVencimentoGarantiaAttribute($object->vencimentoGarantia);
				$this->setNumeroNotaFiscalAttribute($object->numeroNotaFiscal);
				$this->setChaveNfeAttribute($object->chaveNfe);
				$this->setValorOriginalAttribute($object->valorOriginal);
				$this->setValorCompraAttribute($object->valorCompra);
				$this->setValorAtualizadoAttribute($object->valorAtualizado);
				$this->setValorBaixaAttribute($object->valorBaixa);
				$this->setDepreciaAttribute($object->deprecia);
				$this->setMetodoDepreciacaoAttribute($object->metodoDepreciacao);
				$this->setInicioDepreciacaoAttribute($object->inicioDepreciacao);
				$this->setUltimaDepreciacaoAttribute($object->ultimaDepreciacao);
				$this->setTipoDepreciacaoAttribute($object->tipoDepreciacao);
				$this->setTaxaAnualDepreciacaoAttribute($object->taxaAnualDepreciacao);
				$this->setTaxaMensalDepreciacaoAttribute($object->taxaMensalDepreciacao);
				$this->setTaxaDepreciacaoAceleradaAttribute($object->taxaDepreciacaoAcelerada);
				$this->setTaxaDepreciacaoIncentivadaAttribute($object->taxaDepreciacaoIncentivada);
				$this->setFuncaoAttribute($object->funcao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idCentroResultado' => $this->getIdCentroResultadoAttribute(),
				'idPatrimTipoAquisicaoBem' => $this->getIdPatrimTipoAquisicaoBemAttribute(),
				'idPatrimEstadoConservacao' => $this->getIdPatrimEstadoConservacaoAttribute(),
				'idPatrimGrupoBem' => $this->getIdPatrimGrupoBemAttribute(),
				'idFornecedor' => $this->getIdFornecedorAttribute(),
				'idSetor' => $this->getIdSetorAttribute(),
				'numeroNb' => $this->getNumeroNbAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'numeroSerie' => $this->getNumeroSerieAttribute(),
				'dataAquisicao' => $this->getDataAquisicaoAttribute(),
				'dataAceite' => $this->getDataAceiteAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'dataContabilizado' => $this->getDataContabilizadoAttribute(),
				'dataVistoria' => $this->getDataVistoriaAttribute(),
				'dataMarcacao' => $this->getDataMarcacaoAttribute(),
				'dataBaixa' => $this->getDataBaixaAttribute(),
				'vencimentoGarantia' => $this->getVencimentoGarantiaAttribute(),
				'numeroNotaFiscal' => $this->getNumeroNotaFiscalAttribute(),
				'chaveNfe' => $this->getChaveNfeAttribute(),
				'valorOriginal' => $this->getValorOriginalAttribute(),
				'valorCompra' => $this->getValorCompraAttribute(),
				'valorAtualizado' => $this->getValorAtualizadoAttribute(),
				'valorBaixa' => $this->getValorBaixaAttribute(),
				'deprecia' => $this->getDepreciaAttribute(),
				'metodoDepreciacao' => $this->getMetodoDepreciacaoAttribute(),
				'inicioDepreciacao' => $this->getInicioDepreciacaoAttribute(),
				'ultimaDepreciacao' => $this->getUltimaDepreciacaoAttribute(),
				'tipoDepreciacao' => $this->getTipoDepreciacaoAttribute(),
				'taxaAnualDepreciacao' => $this->getTaxaAnualDepreciacaoAttribute(),
				'taxaMensalDepreciacao' => $this->getTaxaMensalDepreciacaoAttribute(),
				'taxaDepreciacaoAcelerada' => $this->getTaxaDepreciacaoAceleradaAttribute(),
				'taxaDepreciacaoIncentivada' => $this->getTaxaDepreciacaoIncentivadaAttribute(),
				'funcao' => $this->getFuncaoAttribute(),
			];
	}
}