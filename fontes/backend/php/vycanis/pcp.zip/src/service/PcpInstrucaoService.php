<?php
class PcpInstrucaoService extends ServiceBase
{
  public function getList()
  {
    return PcpInstrucaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PcpInstrucaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PcpInstrucaoModel::find($id);
  }

}