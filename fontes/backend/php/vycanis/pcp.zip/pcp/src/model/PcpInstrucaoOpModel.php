<?php
declare(strict_types=1);

class PcpInstrucaoOpModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pcp_instrucao_op';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pcpInstrucaoModel',
	];

	/**
		* Relations
		*/
	public function pcpOpCabecalhoModel()
	{
		return $this->belongsTo(PcpOpCabecalhoModel::class, 'id_pcp_op_cabecalho', 'id');
	}

	public function pcpInstrucaoModel()
	{
		return $this->belongsTo(PcpInstrucaoModel::class, 'id_pcp_instrucao', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);


				// link objects - lookups
				$pcpInstrucaoModel = new PcpInstrucaoModel();
				$pcpInstrucaoModel->mapping($object->pcpInstrucaoModel);
				$this->pcpInstrucaoModel()->associate($pcpInstrucaoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'pcpInstrucaoModel' => $this->pcpInstrucaoModel,
			];
	}
}