<?php
declare(strict_types=1);

class PcpOpCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pcp_op_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pcpOpDetalheModelList',
		'pcpInstrucaoOpModelList',
	];

	/**
		* Relations
		*/
	public function pcpOpDetalheModelList()
{
	return $this->hasMany(PcpOpDetalheModel::class, 'id_pcp_op_cabecalho', 'id');
}

	public function pcpInstrucaoOpModelList()
{
	return $this->hasMany(PcpInstrucaoOpModel::class, 'id_pcp_op_cabecalho', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataPrevisaoEntregaAttribute()
	{
		return $this->attributes['data_previsao_entrega'];
	}

	public function setDataPrevisaoEntregaAttribute($dataPrevisaoEntrega)
	{
		$this->attributes['data_previsao_entrega'] = $dataPrevisaoEntrega;
	}

	public function getDataTerminoAttribute()
	{
		return $this->attributes['data_termino'];
	}

	public function setDataTerminoAttribute($dataTermino)
	{
		$this->attributes['data_termino'] = $dataTermino;
	}

	public function getCustoTotalPrevistoAttribute()
	{
		return (double)$this->attributes['custo_total_previsto'];
	}

	public function setCustoTotalPrevistoAttribute($custoTotalPrevisto)
	{
		$this->attributes['custo_total_previsto'] = $custoTotalPrevisto;
	}

	public function getCustoTotalRealizadoAttribute()
	{
		return (double)$this->attributes['custo_total_realizado'];
	}

	public function setCustoTotalRealizadoAttribute($custoTotalRealizado)
	{
		$this->attributes['custo_total_realizado'] = $custoTotalRealizado;
	}

	public function getPorcentoVendaAttribute()
	{
		return (double)$this->attributes['porcento_venda'];
	}

	public function setPorcentoVendaAttribute($porcentoVenda)
	{
		$this->attributes['porcento_venda'] = $porcentoVenda;
	}

	public function getPorcentoEstoqueAttribute()
	{
		return (double)$this->attributes['porcento_estoque'];
	}

	public function setPorcentoEstoqueAttribute($porcentoEstoque)
	{
		$this->attributes['porcento_estoque'] = $porcentoEstoque;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataPrevisaoEntregaAttribute($object->dataPrevisaoEntrega);
				$this->setDataTerminoAttribute($object->dataTermino);
				$this->setCustoTotalPrevistoAttribute($object->custoTotalPrevisto);
				$this->setCustoTotalRealizadoAttribute($object->custoTotalRealizado);
				$this->setPorcentoVendaAttribute($object->porcentoVenda);
				$this->setPorcentoEstoqueAttribute($object->porcentoEstoque);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataPrevisaoEntrega' => $this->getDataPrevisaoEntregaAttribute(),
				'dataTermino' => $this->getDataTerminoAttribute(),
				'custoTotalPrevisto' => $this->getCustoTotalPrevistoAttribute(),
				'custoTotalRealizado' => $this->getCustoTotalRealizadoAttribute(),
				'porcentoVenda' => $this->getPorcentoVendaAttribute(),
				'porcentoEstoque' => $this->getPorcentoEstoqueAttribute(),
				'pcpOpDetalheModelList' => $this->pcpOpDetalheModelList,
				'pcpInstrucaoOpModelList' => $this->pcpInstrucaoOpModelList,
			];
	}
}