<?php
declare(strict_types=1);

class PcpServicoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pcp_servico';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pcpServicoColaboradorModelList',
		'pcpServicoEquipamentoModelList',
		'pcpOpDetalheModel',
	];

	/**
		* Relations
		*/
	public function pcpServicoColaboradorModelList()
{
	return $this->hasMany(PcpServicoColaboradorModel::class, 'id_pcp_servico', 'id');
}

	public function pcpServicoEquipamentoModelList()
{
	return $this->hasMany(PcpServicoEquipamentoModel::class, 'id_pcp_servico', 'id');
}

	public function pcpOpDetalheModel()
	{
		return $this->belongsTo(PcpOpDetalheModel::class, 'id_pcp_op_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getInicioRealizadoAttribute()
	{
		return $this->attributes['inicio_realizado'];
	}

	public function setInicioRealizadoAttribute($inicioRealizado)
	{
		$this->attributes['inicio_realizado'] = $inicioRealizado;
	}

	public function getTerminoRealizadoAttribute()
	{
		return $this->attributes['termino_realizado'];
	}

	public function setTerminoRealizadoAttribute($terminoRealizado)
	{
		$this->attributes['termino_realizado'] = $terminoRealizado;
	}

	public function getHorasRealizadoAttribute()
	{
		return $this->attributes['horas_realizado'];
	}

	public function setHorasRealizadoAttribute($horasRealizado)
	{
		$this->attributes['horas_realizado'] = $horasRealizado;
	}

	public function getMinutosRealizadoAttribute()
	{
		return $this->attributes['minutos_realizado'];
	}

	public function setMinutosRealizadoAttribute($minutosRealizado)
	{
		$this->attributes['minutos_realizado'] = $minutosRealizado;
	}

	public function getSegundosRealizadoAttribute()
	{
		return $this->attributes['segundos_realizado'];
	}

	public function setSegundosRealizadoAttribute($segundosRealizado)
	{
		$this->attributes['segundos_realizado'] = $segundosRealizado;
	}

	public function getCustoRealizadoAttribute()
	{
		return (double)$this->attributes['custo_realizado'];
	}

	public function setCustoRealizadoAttribute($custoRealizado)
	{
		$this->attributes['custo_realizado'] = $custoRealizado;
	}

	public function getInicioPrevistoAttribute()
	{
		return $this->attributes['inicio_previsto'];
	}

	public function setInicioPrevistoAttribute($inicioPrevisto)
	{
		$this->attributes['inicio_previsto'] = $inicioPrevisto;
	}

	public function getTerminoPrevistoAttribute()
	{
		return $this->attributes['termino_previsto'];
	}

	public function setTerminoPrevistoAttribute($terminoPrevisto)
	{
		$this->attributes['termino_previsto'] = $terminoPrevisto;
	}

	public function getHorasPrevistoAttribute()
	{
		return $this->attributes['horas_previsto'];
	}

	public function setHorasPrevistoAttribute($horasPrevisto)
	{
		$this->attributes['horas_previsto'] = $horasPrevisto;
	}

	public function getMinutosPrevistoAttribute()
	{
		return $this->attributes['minutos_previsto'];
	}

	public function setMinutosPrevistoAttribute($minutosPrevisto)
	{
		$this->attributes['minutos_previsto'] = $minutosPrevisto;
	}

	public function getSegundosPrevistoAttribute()
	{
		return $this->attributes['segundos_previsto'];
	}

	public function setSegundosPrevistoAttribute($segundosPrevisto)
	{
		$this->attributes['segundos_previsto'] = $segundosPrevisto;
	}

	public function getCustoPrevistoAttribute()
	{
		return (double)$this->attributes['custo_previsto'];
	}

	public function setCustoPrevistoAttribute($custoPrevisto)
	{
		$this->attributes['custo_previsto'] = $custoPrevisto;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setInicioRealizadoAttribute($object->inicioRealizado);
				$this->setTerminoRealizadoAttribute($object->terminoRealizado);
				$this->setHorasRealizadoAttribute($object->horasRealizado);
				$this->setMinutosRealizadoAttribute($object->minutosRealizado);
				$this->setSegundosRealizadoAttribute($object->segundosRealizado);
				$this->setCustoRealizadoAttribute($object->custoRealizado);
				$this->setInicioPrevistoAttribute($object->inicioPrevisto);
				$this->setTerminoPrevistoAttribute($object->terminoPrevisto);
				$this->setHorasPrevistoAttribute($object->horasPrevisto);
				$this->setMinutosPrevistoAttribute($object->minutosPrevisto);
				$this->setSegundosPrevistoAttribute($object->segundosPrevisto);
				$this->setCustoPrevistoAttribute($object->custoPrevisto);

				// link objects - lookups
				$pcpOpDetalheModel = new PcpOpDetalheModel();
				$pcpOpDetalheModel->mapping($object->pcpOpDetalheModel);
				$this->pcpOpDetalheModel()->associate($pcpOpDetalheModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'inicioRealizado' => $this->getInicioRealizadoAttribute(),
				'terminoRealizado' => $this->getTerminoRealizadoAttribute(),
				'horasRealizado' => $this->getHorasRealizadoAttribute(),
				'minutosRealizado' => $this->getMinutosRealizadoAttribute(),
				'segundosRealizado' => $this->getSegundosRealizadoAttribute(),
				'custoRealizado' => $this->getCustoRealizadoAttribute(),
				'inicioPrevisto' => $this->getInicioPrevistoAttribute(),
				'terminoPrevisto' => $this->getTerminoPrevistoAttribute(),
				'horasPrevisto' => $this->getHorasPrevistoAttribute(),
				'minutosPrevisto' => $this->getMinutosPrevistoAttribute(),
				'segundosPrevisto' => $this->getSegundosPrevistoAttribute(),
				'custoPrevisto' => $this->getCustoPrevistoAttribute(),
				'pcpServicoColaboradorModelList' => $this->pcpServicoColaboradorModelList,
				'pcpServicoEquipamentoModelList' => $this->pcpServicoEquipamentoModelList,
				'pcpOpDetalheModel' => $this->pcpOpDetalheModel,
			];
	}
}