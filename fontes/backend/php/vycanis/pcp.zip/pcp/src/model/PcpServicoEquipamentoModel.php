<?php
declare(strict_types=1);

class PcpServicoEquipamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pcp_servico_equipamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'patrimBemModel',
	];

	/**
		* Relations
		*/
	public function pcpServicoModel()
	{
		return $this->belongsTo(PcpServicoModel::class, 'id_pcp_servico', 'id');
	}

	public function patrimBemModel()
	{
		return $this->belongsTo(PatrimBemModel::class, 'id_patrim_bem', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);


				// link objects - lookups
				$patrimBemModel = new PatrimBemModel();
				$patrimBemModel->mapping($object->patrimBemModel);
				$this->patrimBemModel()->associate($patrimBemModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'patrimBemModel' => $this->patrimBemModel,
			];
	}
}