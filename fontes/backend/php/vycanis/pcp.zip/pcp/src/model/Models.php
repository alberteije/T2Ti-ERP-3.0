<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'PcpOpDetalheModel.php';
include 'PcpServicoColaboradorModel.php';
include 'PcpInstrucaoOpModel.php';
include 'PcpServicoEquipamentoModel.php';
include 'PcpOpCabecalhoModel.php';
include 'PcpServicoModel.php';
include 'ProdutoModel.php';
include 'PatrimBemModel.php';
include 'PcpInstrucaoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';