<?php
class PatrimBemService extends ServiceBase
{
  public function getList()
  {
    return PatrimBemModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PatrimBemModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PatrimBemModel::find($id);
  }

}