<?php
use Illuminate\Database\Capsule\Manager as DB;
class PcpOpCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return PcpOpCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return PcpOpCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return PcpOpCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// pcpOpDetalhe
		$pcpOpDetalheModelListJson = $objJson->pcpOpDetalheModelList;
		if ($pcpOpDetalheModelListJson != null) {
			for ($i = 0; $i < count($pcpOpDetalheModelListJson); $i++) {
				$pcpOpDetalhe = new PcpOpDetalheModel();
				$pcpOpDetalhe->mapping($pcpOpDetalheModelListJson[$i]);
				$objModel->pcpOpDetalheModelList()->save($pcpOpDetalhe);
			}
		}

		// pcpInstrucaoOp
		$pcpInstrucaoOpModelListJson = $objJson->pcpInstrucaoOpModelList;
		if ($pcpInstrucaoOpModelListJson != null) {
			for ($i = 0; $i < count($pcpInstrucaoOpModelListJson); $i++) {
				$pcpInstrucaoOp = new PcpInstrucaoOpModel();
				$pcpInstrucaoOp->mapping($pcpInstrucaoOpModelListJson[$i]);
				$objModel->pcpInstrucaoOpModelList()->save($pcpInstrucaoOp);
			}
		}

	}	

	public function deleteChildren($object)
	{
		PcpOpDetalheModel::where('id_pcp_op_cabecalho', $object->getIdAttribute())->delete();
		PcpInstrucaoOpModel::where('id_pcp_op_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}