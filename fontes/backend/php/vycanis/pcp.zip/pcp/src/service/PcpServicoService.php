<?php
use Illuminate\Database\Capsule\Manager as DB;
class PcpServicoService extends ServiceBase
{
	public function getList()
	{
		return PcpServicoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return PcpServicoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return PcpServicoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// pcpServicoColaborador
		$pcpServicoColaboradorModelListJson = $objJson->pcpServicoColaboradorModelList;
		if ($pcpServicoColaboradorModelListJson != null) {
			for ($i = 0; $i < count($pcpServicoColaboradorModelListJson); $i++) {
				$pcpServicoColaborador = new PcpServicoColaboradorModel();
				$pcpServicoColaborador->mapping($pcpServicoColaboradorModelListJson[$i]);
				$objModel->pcpServicoColaboradorModelList()->save($pcpServicoColaborador);
			}
		}

		// pcpServicoEquipamento
		$pcpServicoEquipamentoModelListJson = $objJson->pcpServicoEquipamentoModelList;
		if ($pcpServicoEquipamentoModelListJson != null) {
			for ($i = 0; $i < count($pcpServicoEquipamentoModelListJson); $i++) {
				$pcpServicoEquipamento = new PcpServicoEquipamentoModel();
				$pcpServicoEquipamento->mapping($pcpServicoEquipamentoModelListJson[$i]);
				$objModel->pcpServicoEquipamentoModelList()->save($pcpServicoEquipamento);
			}
		}

	}	

	public function deleteChildren($object)
	{
		PcpServicoColaboradorModel::where('id_pcp_servico', $object->getIdAttribute())->delete();
		PcpServicoEquipamentoModel::where('id_pcp_servico', $object->getIdAttribute())->delete();
	}	
 
}