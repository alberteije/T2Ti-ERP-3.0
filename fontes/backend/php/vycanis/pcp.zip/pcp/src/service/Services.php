<?php

include 'ServiceBase.php';

include 'PcpOpCabecalhoService.php';
include 'PcpServicoService.php';
include 'ProdutoService.php';
include 'PatrimBemService.php';
include 'PcpInstrucaoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';