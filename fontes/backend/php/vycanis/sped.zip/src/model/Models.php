<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'SpedContabilModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'SpedFiscalModel.php';
include 'SintegraModel.php';
include 'EfdContribuicoesModel.php';
include 'EfdReinfModel.php';