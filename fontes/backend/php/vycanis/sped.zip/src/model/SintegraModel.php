<?php
declare(strict_types=1);

class SintegraModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'sintegra';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataEmissaoAttribute()
	{
		return $this->attributes['data_emissao'];
	}

	public function setDataEmissaoAttribute($dataEmissao)
	{
		$this->attributes['data_emissao'] = $dataEmissao;
	}

	public function getPeriodoInicialAttribute()
	{
		return $this->attributes['periodo_inicial'];
	}

	public function setPeriodoInicialAttribute($periodoInicial)
	{
		$this->attributes['periodo_inicial'] = $periodoInicial;
	}

	public function getPeriodoFinalAttribute()
	{
		return $this->attributes['periodo_final'];
	}

	public function setPeriodoFinalAttribute($periodoFinal)
	{
		$this->attributes['periodo_final'] = $periodoFinal;
	}

	public function getCodigoConvenioAttribute()
	{
		return $this->attributes['codigo_convenio'];
	}

	public function setCodigoConvenioAttribute($codigoConvenio)
	{
		$this->attributes['codigo_convenio'] = $codigoConvenio;
	}

	public function getInventarioAttribute()
	{
		return $this->attributes['inventario'];
	}

	public function setInventarioAttribute($inventario)
	{
		$this->attributes['inventario'] = $inventario;
	}

	public function getFinalidadeArquivoAttribute()
	{
		return $this->attributes['finalidade_arquivo'];
	}

	public function setFinalidadeArquivoAttribute($finalidadeArquivo)
	{
		$this->attributes['finalidade_arquivo'] = $finalidadeArquivo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataEmissaoAttribute($object->dataEmissao);
				$this->setPeriodoInicialAttribute($object->periodoInicial);
				$this->setPeriodoFinalAttribute($object->periodoFinal);
				$this->setCodigoConvenioAttribute($object->codigoConvenio);
				$this->setInventarioAttribute($object->inventario);
				$this->setFinalidadeArquivoAttribute($object->finalidadeArquivo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataEmissao' => $this->getDataEmissaoAttribute(),
				'periodoInicial' => $this->getPeriodoInicialAttribute(),
				'periodoFinal' => $this->getPeriodoFinalAttribute(),
				'codigoConvenio' => $this->getCodigoConvenioAttribute(),
				'inventario' => $this->getInventarioAttribute(),
				'finalidadeArquivo' => $this->getFinalidadeArquivoAttribute(),
			];
	}
}