<?php
class SpedContabilService extends ServiceBase
{
  public function getList()
  {
    return SpedContabilModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SpedContabilModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SpedContabilModel::find($id);
  }

}