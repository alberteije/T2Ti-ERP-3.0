<?php
class SpedFiscalService extends ServiceBase
{
  public function getList()
  {
    return SpedFiscalModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SpedFiscalModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SpedFiscalModel::find($id);
  }

}