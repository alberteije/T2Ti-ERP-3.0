<?php
class SintegraService extends ServiceBase
{
  public function getList()
  {
    return SintegraModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SintegraModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SintegraModel::find($id);
  }

}