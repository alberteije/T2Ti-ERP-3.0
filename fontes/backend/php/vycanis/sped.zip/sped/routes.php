<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// sped-contabil
$app->get('/sped-contabil[/]', \SpedContabilController::class . RESULT_LIST);
$app->get('/sped-contabil/{id}', \SpedContabilController::class . RESULT_OBJECT);
$app->post('/sped-contabil', \SpedContabilController::class . INSERT);
$app->put('/sped-contabil', \SpedContabilController::class . UPDATE);
$app->delete('/sped-contabil/{id}', \SpedContabilController::class . DELETE);
$app->options('/sped-contabil', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sped-contabil/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sped-contabil/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// sped-fiscal
$app->get('/sped-fiscal[/]', \SpedFiscalController::class . RESULT_LIST);
$app->get('/sped-fiscal/{id}', \SpedFiscalController::class . RESULT_OBJECT);
$app->post('/sped-fiscal', \SpedFiscalController::class . INSERT);
$app->put('/sped-fiscal', \SpedFiscalController::class . UPDATE);
$app->delete('/sped-fiscal/{id}', \SpedFiscalController::class . DELETE);
$app->options('/sped-fiscal', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sped-fiscal/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sped-fiscal/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// sintegra
$app->get('/sintegra[/]', \SintegraController::class . RESULT_LIST);
$app->get('/sintegra/{id}', \SintegraController::class . RESULT_OBJECT);
$app->post('/sintegra', \SintegraController::class . INSERT);
$app->put('/sintegra', \SintegraController::class . UPDATE);
$app->delete('/sintegra/{id}', \SintegraController::class . DELETE);
$app->options('/sintegra', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sintegra/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sintegra/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// efd-contribuicoes
$app->get('/efd-contribuicoes[/]', \EfdContribuicoesController::class . RESULT_LIST);
$app->get('/efd-contribuicoes/{id}', \EfdContribuicoesController::class . RESULT_OBJECT);
$app->post('/efd-contribuicoes', \EfdContribuicoesController::class . INSERT);
$app->put('/efd-contribuicoes', \EfdContribuicoesController::class . UPDATE);
$app->delete('/efd-contribuicoes/{id}', \EfdContribuicoesController::class . DELETE);
$app->options('/efd-contribuicoes', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/efd-contribuicoes/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/efd-contribuicoes/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// efd-reinf
$app->get('/efd-reinf[/]', \EfdReinfController::class . RESULT_LIST);
$app->get('/efd-reinf/{id}', \EfdReinfController::class . RESULT_OBJECT);
$app->post('/efd-reinf', \EfdReinfController::class . INSERT);
$app->put('/efd-reinf', \EfdReinfController::class . UPDATE);
$app->delete('/efd-reinf/{id}', \EfdReinfController::class . DELETE);
$app->options('/efd-reinf', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/efd-reinf/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/efd-reinf/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

