<?php
class EfdReinfService extends ServiceBase
{
  public function getList()
  {
    return EfdReinfModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EfdReinfModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EfdReinfModel::find($id);
  }

}