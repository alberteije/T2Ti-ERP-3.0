<?php
class EfdContribuicoesService extends ServiceBase
{
  public function getList()
  {
    return EfdContribuicoesModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EfdContribuicoesModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EfdContribuicoesModel::find($id);
  }

}