<?php
declare(strict_types=1);

class ProdutoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'produto';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'produtoMarcaModel',
		'tributIcmsCustomCabModel',
		'tributGrupoTributarioModel',
		'produtoUnidadeModel',
		'produtoSubgrupoModel',
	];

	/**
		* Relations
		*/
	public function produtoMarcaModel()
	{
		return $this->belongsTo(ProdutoMarcaModel::class, 'id_produto_marca', 'id');
	}

	public function tributIcmsCustomCabModel()
	{
		return $this->belongsTo(TributIcmsCustomCabModel::class, 'id_tribut_icms_custom_cab', 'id');
	}

	public function tributGrupoTributarioModel()
	{
		return $this->belongsTo(TributGrupoTributarioModel::class, 'id_tribut_grupo_tributario', 'id');
	}

	public function produtoUnidadeModel()
	{
		return $this->belongsTo(ProdutoUnidadeModel::class, 'id_produto_unidade', 'id');
	}

	public function produtoSubgrupoModel()
	{
		return $this->belongsTo(ProdutoSubgrupoModel::class, 'id_produto_subgrupo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getGtinAttribute()
	{
		return $this->attributes['gtin'];
	}

	public function setGtinAttribute($gtin)
	{
		$this->attributes['gtin'] = $gtin;
	}

	public function getCodigoInternoAttribute()
	{
		return $this->attributes['codigo_interno'];
	}

	public function setCodigoInternoAttribute($codigoInterno)
	{
		$this->attributes['codigo_interno'] = $codigoInterno;
	}

	public function getValorCompraAttribute()
	{
		return (double)$this->attributes['valor_compra'];
	}

	public function setValorCompraAttribute($valorCompra)
	{
		$this->attributes['valor_compra'] = $valorCompra;
	}

	public function getValorVendaAttribute()
	{
		return (double)$this->attributes['valor_venda'];
	}

	public function setValorVendaAttribute($valorVenda)
	{
		$this->attributes['valor_venda'] = $valorVenda;
	}

	public function getCodigoNcmAttribute()
	{
		return $this->attributes['codigo_ncm'];
	}

	public function setCodigoNcmAttribute($codigoNcm)
	{
		$this->attributes['codigo_ncm'] = $codigoNcm;
	}

	public function getEstoqueMinimoAttribute()
	{
		return (double)$this->attributes['estoque_minimo'];
	}

	public function setEstoqueMinimoAttribute($estoqueMinimo)
	{
		$this->attributes['estoque_minimo'] = $estoqueMinimo;
	}

	public function getEstoqueMaximoAttribute()
	{
		return (double)$this->attributes['estoque_maximo'];
	}

	public function setEstoqueMaximoAttribute($estoqueMaximo)
	{
		$this->attributes['estoque_maximo'] = $estoqueMaximo;
	}

	public function getQuantidadeEstoqueAttribute()
	{
		return (double)$this->attributes['quantidade_estoque'];
	}

	public function setQuantidadeEstoqueAttribute($quantidadeEstoque)
	{
		$this->attributes['quantidade_estoque'] = $quantidadeEstoque;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setGtinAttribute($object->gtin);
				$this->setCodigoInternoAttribute($object->codigoInterno);
				$this->setValorCompraAttribute($object->valorCompra);
				$this->setValorVendaAttribute($object->valorVenda);
				$this->setCodigoNcmAttribute($object->codigoNcm);
				$this->setEstoqueMinimoAttribute($object->estoqueMinimo);
				$this->setEstoqueMaximoAttribute($object->estoqueMaximo);
				$this->setQuantidadeEstoqueAttribute($object->quantidadeEstoque);
				$this->setDataCadastroAttribute($object->dataCadastro);

				// link objects - lookups
				$produtoMarcaModel = new ProdutoMarcaModel();
				$produtoMarcaModel->mapping($object->produtoMarcaModel);
				$this->produtoMarcaModel()->associate($produtoMarcaModel);
				$tributIcmsCustomCabModel = new TributIcmsCustomCabModel();
				$tributIcmsCustomCabModel->mapping($object->tributIcmsCustomCabModel);
				$this->tributIcmsCustomCabModel()->associate($tributIcmsCustomCabModel);
				$tributGrupoTributarioModel = new TributGrupoTributarioModel();
				$tributGrupoTributarioModel->mapping($object->tributGrupoTributarioModel);
				$this->tributGrupoTributarioModel()->associate($tributGrupoTributarioModel);
				$produtoUnidadeModel = new ProdutoUnidadeModel();
				$produtoUnidadeModel->mapping($object->produtoUnidadeModel);
				$this->produtoUnidadeModel()->associate($produtoUnidadeModel);
				$produtoSubgrupoModel = new ProdutoSubgrupoModel();
				$produtoSubgrupoModel->mapping($object->produtoSubgrupoModel);
				$this->produtoSubgrupoModel()->associate($produtoSubgrupoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'gtin' => $this->getGtinAttribute(),
				'codigoInterno' => $this->getCodigoInternoAttribute(),
				'valorCompra' => $this->getValorCompraAttribute(),
				'valorVenda' => $this->getValorVendaAttribute(),
				'codigoNcm' => $this->getCodigoNcmAttribute(),
				'estoqueMinimo' => $this->getEstoqueMinimoAttribute(),
				'estoqueMaximo' => $this->getEstoqueMaximoAttribute(),
				'quantidadeEstoque' => $this->getQuantidadeEstoqueAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'produtoMarcaModel' => $this->produtoMarcaModel,
				'tributIcmsCustomCabModel' => $this->tributIcmsCustomCabModel,
				'tributGrupoTributarioModel' => $this->tributGrupoTributarioModel,
				'produtoUnidadeModel' => $this->produtoUnidadeModel,
				'produtoSubgrupoModel' => $this->produtoSubgrupoModel,
			];
	}
}