<?php
declare(strict_types=1);

class CompraPedidoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'compra_pedido';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'compraPedidoDetalheModelList',
		'compraTipoPedidoModel',
		'viewPessoaColaboradorModel',
		'viewPessoaFornecedorModel',
	];

	/**
		* Relations
		*/
	public function compraPedidoDetalheModelList()
{
	return $this->hasMany(CompraPedidoDetalheModel::class, 'id_compra_pedido', 'id');
}

	public function compraTipoPedidoModel()
	{
		return $this->belongsTo(CompraTipoPedidoModel::class, 'id_compra_tipo_pedido', 'id');
	}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function viewPessoaFornecedorModel()
	{
		return $this->belongsTo(ViewPessoaFornecedorModel::class, 'id_fornecedor', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoCotacaoAttribute()
	{
		return $this->attributes['codigo_cotacao'];
	}

	public function setCodigoCotacaoAttribute($codigoCotacao)
	{
		$this->attributes['codigo_cotacao'] = $codigoCotacao;
	}

	public function getDataPedidoAttribute()
	{
		return $this->attributes['data_pedido'];
	}

	public function setDataPedidoAttribute($dataPedido)
	{
		$this->attributes['data_pedido'] = $dataPedido;
	}

	public function getDataPrevistaEntregaAttribute()
	{
		return $this->attributes['data_prevista_entrega'];
	}

	public function setDataPrevistaEntregaAttribute($dataPrevistaEntrega)
	{
		$this->attributes['data_prevista_entrega'] = $dataPrevistaEntrega;
	}

	public function getDataPrevisaoPagamentoAttribute()
	{
		return $this->attributes['data_previsao_pagamento'];
	}

	public function setDataPrevisaoPagamentoAttribute($dataPrevisaoPagamento)
	{
		$this->attributes['data_previsao_pagamento'] = $dataPrevisaoPagamento;
	}

	public function getLocalEntregaAttribute()
	{
		return $this->attributes['local_entrega'];
	}

	public function setLocalEntregaAttribute($localEntrega)
	{
		$this->attributes['local_entrega'] = $localEntrega;
	}

	public function getLocalCobrancaAttribute()
	{
		return $this->attributes['local_cobranca'];
	}

	public function setLocalCobrancaAttribute($localCobranca)
	{
		$this->attributes['local_cobranca'] = $localCobranca;
	}

	public function getContatoAttribute()
	{
		return $this->attributes['contato'];
	}

	public function setContatoAttribute($contato)
	{
		$this->attributes['contato'] = $contato;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getTipoFreteAttribute()
	{
		return $this->attributes['tipo_frete'];
	}

	public function setTipoFreteAttribute($tipoFrete)
	{
		$this->attributes['tipo_frete'] = $tipoFrete;
	}

	public function getFormaPagamentoAttribute()
	{
		return $this->attributes['forma_pagamento'];
	}

	public function setFormaPagamentoAttribute($formaPagamento)
	{
		$this->attributes['forma_pagamento'] = $formaPagamento;
	}

	public function getBaseCalculoIcmsAttribute()
	{
		return (double)$this->attributes['base_calculo_icms'];
	}

	public function setBaseCalculoIcmsAttribute($baseCalculoIcms)
	{
		$this->attributes['base_calculo_icms'] = $baseCalculoIcms;
	}

	public function getValorIcmsAttribute()
	{
		return (double)$this->attributes['valor_icms'];
	}

	public function setValorIcmsAttribute($valorIcms)
	{
		$this->attributes['valor_icms'] = $valorIcms;
	}

	public function getBaseCalculoIcmsStAttribute()
	{
		return (double)$this->attributes['base_calculo_icms_st'];
	}

	public function setBaseCalculoIcmsStAttribute($baseCalculoIcmsSt)
	{
		$this->attributes['base_calculo_icms_st'] = $baseCalculoIcmsSt;
	}

	public function getValorIcmsStAttribute()
	{
		return (double)$this->attributes['valor_icms_st'];
	}

	public function setValorIcmsStAttribute($valorIcmsSt)
	{
		$this->attributes['valor_icms_st'] = $valorIcmsSt;
	}

	public function getValorTotalProdutosAttribute()
	{
		return (double)$this->attributes['valor_total_produtos'];
	}

	public function setValorTotalProdutosAttribute($valorTotalProdutos)
	{
		$this->attributes['valor_total_produtos'] = $valorTotalProdutos;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	public function getValorSeguroAttribute()
	{
		return (double)$this->attributes['valor_seguro'];
	}

	public function setValorSeguroAttribute($valorSeguro)
	{
		$this->attributes['valor_seguro'] = $valorSeguro;
	}

	public function getValorOutrasDespesasAttribute()
	{
		return (double)$this->attributes['valor_outras_despesas'];
	}

	public function setValorOutrasDespesasAttribute($valorOutrasDespesas)
	{
		$this->attributes['valor_outras_despesas'] = $valorOutrasDespesas;
	}

	public function getValorIpiAttribute()
	{
		return (double)$this->attributes['valor_ipi'];
	}

	public function setValorIpiAttribute($valorIpi)
	{
		$this->attributes['valor_ipi'] = $valorIpi;
	}

	public function getValorTotalNfAttribute()
	{
		return (double)$this->attributes['valor_total_nf'];
	}

	public function setValorTotalNfAttribute($valorTotalNf)
	{
		$this->attributes['valor_total_nf'] = $valorTotalNf;
	}

	public function getQuantidadeParcelasAttribute()
	{
		return $this->attributes['quantidade_parcelas'];
	}

	public function setQuantidadeParcelasAttribute($quantidadeParcelas)
	{
		$this->attributes['quantidade_parcelas'] = $quantidadeParcelas;
	}

	public function getDiaPrimeiroVencimentoAttribute()
	{
		return $this->attributes['dia_primeiro_vencimento'];
	}

	public function setDiaPrimeiroVencimentoAttribute($diaPrimeiroVencimento)
	{
		$this->attributes['dia_primeiro_vencimento'] = $diaPrimeiroVencimento;
	}

	public function getIntervaloEntreParcelasAttribute()
	{
		return $this->attributes['intervalo_entre_parcelas'];
	}

	public function setIntervaloEntreParcelasAttribute($intervaloEntreParcelas)
	{
		$this->attributes['intervalo_entre_parcelas'] = $intervaloEntreParcelas;
	}

	public function getDiaFixoParcelaAttribute()
	{
		return $this->attributes['dia_fixo_parcela'];
	}

	public function setDiaFixoParcelaAttribute($diaFixoParcela)
	{
		$this->attributes['dia_fixo_parcela'] = $diaFixoParcela;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoCotacaoAttribute($object->codigoCotacao);
				$this->setDataPedidoAttribute($object->dataPedido);
				$this->setDataPrevistaEntregaAttribute($object->dataPrevistaEntrega);
				$this->setDataPrevisaoPagamentoAttribute($object->dataPrevisaoPagamento);
				$this->setLocalEntregaAttribute($object->localEntrega);
				$this->setLocalCobrancaAttribute($object->localCobranca);
				$this->setContatoAttribute($object->contato);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setTipoFreteAttribute($object->tipoFrete);
				$this->setFormaPagamentoAttribute($object->formaPagamento);
				$this->setBaseCalculoIcmsAttribute($object->baseCalculoIcms);
				$this->setValorIcmsAttribute($object->valorIcms);
				$this->setBaseCalculoIcmsStAttribute($object->baseCalculoIcmsSt);
				$this->setValorIcmsStAttribute($object->valorIcmsSt);
				$this->setValorTotalProdutosAttribute($object->valorTotalProdutos);
				$this->setValorFreteAttribute($object->valorFrete);
				$this->setValorSeguroAttribute($object->valorSeguro);
				$this->setValorOutrasDespesasAttribute($object->valorOutrasDespesas);
				$this->setValorIpiAttribute($object->valorIpi);
				$this->setValorTotalNfAttribute($object->valorTotalNf);
				$this->setQuantidadeParcelasAttribute($object->quantidadeParcelas);
				$this->setDiaPrimeiroVencimentoAttribute($object->diaPrimeiroVencimento);
				$this->setIntervaloEntreParcelasAttribute($object->intervaloEntreParcelas);
				$this->setDiaFixoParcelaAttribute($object->diaFixoParcela);

				// link objects - lookups
				$compraTipoPedidoModel = new CompraTipoPedidoModel();
				$compraTipoPedidoModel->mapping($object->compraTipoPedidoModel);
				$this->compraTipoPedidoModel()->associate($compraTipoPedidoModel);
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$viewPessoaFornecedorModel = new ViewPessoaFornecedorModel();
				$viewPessoaFornecedorModel->mapping($object->viewPessoaFornecedorModel);
				$this->viewPessoaFornecedorModel()->associate($viewPessoaFornecedorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoCotacao' => $this->getCodigoCotacaoAttribute(),
				'dataPedido' => $this->getDataPedidoAttribute(),
				'dataPrevistaEntrega' => $this->getDataPrevistaEntregaAttribute(),
				'dataPrevisaoPagamento' => $this->getDataPrevisaoPagamentoAttribute(),
				'localEntrega' => $this->getLocalEntregaAttribute(),
				'localCobranca' => $this->getLocalCobrancaAttribute(),
				'contato' => $this->getContatoAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'tipoFrete' => $this->getTipoFreteAttribute(),
				'formaPagamento' => $this->getFormaPagamentoAttribute(),
				'baseCalculoIcms' => $this->getBaseCalculoIcmsAttribute(),
				'valorIcms' => $this->getValorIcmsAttribute(),
				'baseCalculoIcmsSt' => $this->getBaseCalculoIcmsStAttribute(),
				'valorIcmsSt' => $this->getValorIcmsStAttribute(),
				'valorTotalProdutos' => $this->getValorTotalProdutosAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
				'valorSeguro' => $this->getValorSeguroAttribute(),
				'valorOutrasDespesas' => $this->getValorOutrasDespesasAttribute(),
				'valorIpi' => $this->getValorIpiAttribute(),
				'valorTotalNf' => $this->getValorTotalNfAttribute(),
				'quantidadeParcelas' => $this->getQuantidadeParcelasAttribute(),
				'diaPrimeiroVencimento' => $this->getDiaPrimeiroVencimentoAttribute(),
				'intervaloEntreParcelas' => $this->getIntervaloEntreParcelasAttribute(),
				'diaFixoParcela' => $this->getDiaFixoParcelaAttribute(),
				'compraPedidoDetalheModelList' => $this->compraPedidoDetalheModelList,
				'compraTipoPedidoModel' => $this->compraTipoPedidoModel,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'viewPessoaFornecedorModel' => $this->viewPessoaFornecedorModel,
			];
	}
}