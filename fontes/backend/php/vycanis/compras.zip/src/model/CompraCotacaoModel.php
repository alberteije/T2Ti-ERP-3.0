<?php
declare(strict_types=1);

class CompraCotacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'compra_cotacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'compraFornecedorCotacaoModelList',
		'compraRequisicaoModel',
		'compraCotacaoDetalheModelList',
	];

	/**
		* Relations
		*/
	public function compraFornecedorCotacaoModelList()
{
	return $this->hasMany(CompraFornecedorCotacaoModel::class, 'id_compra_cotacao', 'id');
}

	public function compraRequisicaoModel()
	{
		return $this->belongsTo(CompraRequisicaoModel::class, 'id_compra_requisicao', 'id');
	}

	public function compraCotacaoDetalheModelList()
{
	return $this->hasMany(CompraCotacaoDetalheModel::class, 'id_compra_cotacao', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataCotacaoAttribute()
	{
		return $this->attributes['data_cotacao'];
	}

	public function setDataCotacaoAttribute($dataCotacao)
	{
		$this->attributes['data_cotacao'] = $dataCotacao;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataCotacaoAttribute($object->dataCotacao);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
				$compraRequisicaoModel = new CompraRequisicaoModel();
				$compraRequisicaoModel->mapping($object->compraRequisicaoModel);
				$this->compraRequisicaoModel()->associate($compraRequisicaoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataCotacao' => $this->getDataCotacaoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'compraFornecedorCotacaoModelList' => $this->compraFornecedorCotacaoModelList,
				'compraRequisicaoModel' => $this->compraRequisicaoModel,
				'compraCotacaoDetalheModelList' => $this->compraCotacaoDetalheModelList,
			];
	}
}