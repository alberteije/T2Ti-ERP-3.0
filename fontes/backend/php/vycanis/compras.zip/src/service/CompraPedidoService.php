<?php
use Illuminate\Database\Capsule\Manager as DB;
class CompraPedidoService extends ServiceBase
{
	public function getList()
	{
		return CompraPedidoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return CompraPedidoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return CompraPedidoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// compraPedidoDetalhe
		$compraPedidoDetalheModelListJson = $objJson->compraPedidoDetalheModelList;
		if ($compraPedidoDetalheModelListJson != null) {
			for ($i = 0; $i < count($compraPedidoDetalheModelListJson); $i++) {
				$compraPedidoDetalhe = new CompraPedidoDetalheModel();
				$compraPedidoDetalhe->mapping($compraPedidoDetalheModelListJson[$i]);
				$objModel->compraPedidoDetalheModelList()->save($compraPedidoDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		CompraPedidoDetalheModel::where('id_compra_pedido', $object->getIdAttribute())->delete();
	}	
 
}