<?php
class ProdutoMarcaService extends ServiceBase
{
  public function getList()
  {
    return ProdutoMarcaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ProdutoMarcaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ProdutoMarcaModel::find($id);
  }

}