<?php
use Illuminate\Database\Capsule\Manager as DB;
class CompraCotacaoService extends ServiceBase
{
	public function getList()
	{
		return CompraCotacaoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return CompraCotacaoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return CompraCotacaoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// compraFornecedorCotacao
		$compraFornecedorCotacaoModelListJson = $objJson->compraFornecedorCotacaoModelList;
		if ($compraFornecedorCotacaoModelListJson != null) {
			for ($i = 0; $i < count($compraFornecedorCotacaoModelListJson); $i++) {
				$compraFornecedorCotacao = new CompraFornecedorCotacaoModel();
				$compraFornecedorCotacao->mapping($compraFornecedorCotacaoModelListJson[$i]);
				$objModel->compraFornecedorCotacaoModelList()->save($compraFornecedorCotacao);
			}
		}

		// compraCotacaoDetalhe
		$compraCotacaoDetalheModelListJson = $objJson->compraCotacaoDetalheModelList;
		if ($compraCotacaoDetalheModelListJson != null) {
			for ($i = 0; $i < count($compraCotacaoDetalheModelListJson); $i++) {
				$compraCotacaoDetalhe = new CompraCotacaoDetalheModel();
				$compraCotacaoDetalhe->mapping($compraCotacaoDetalheModelListJson[$i]);
				$objModel->compraCotacaoDetalheModelList()->save($compraCotacaoDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		CompraFornecedorCotacaoModel::where('id_compra_cotacao', $object->getIdAttribute())->delete();
		CompraCotacaoDetalheModel::where('id_compra_cotacao', $object->getIdAttribute())->delete();
	}	
 
}