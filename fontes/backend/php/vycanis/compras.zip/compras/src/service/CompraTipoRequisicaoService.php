<?php
class CompraTipoRequisicaoService extends ServiceBase
{
  public function getList()
  {
    return CompraTipoRequisicaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CompraTipoRequisicaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CompraTipoRequisicaoModel::find($id);
  }

}