<?php
class ProdutoGrupoService extends ServiceBase
{
  public function getList()
  {
    return ProdutoGrupoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ProdutoGrupoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ProdutoGrupoModel::find($id);
  }

}