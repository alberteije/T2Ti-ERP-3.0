<?php

include 'ServiceBase.php';

include 'CompraRequisicaoService.php';
include 'CompraCotacaoService.php';
include 'CompraPedidoService.php';
include 'ProdutoGrupoService.php';
include 'ProdutoSubgrupoService.php';
include 'ProdutoMarcaService.php';
include 'ProdutoUnidadeService.php';
include 'TributIcmsCustomCabService.php';
include 'TributGrupoTributarioService.php';
include 'ProdutoService.php';
include 'CompraTipoRequisicaoService.php';
include 'CompraTipoPedidoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaFornecedorService.php';
include 'ViewPessoaColaboradorService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';