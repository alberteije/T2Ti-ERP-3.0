<?php
use Illuminate\Database\Capsule\Manager as DB;
class CompraRequisicaoService extends ServiceBase
{
	public function getList()
	{
		return CompraRequisicaoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return CompraRequisicaoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return CompraRequisicaoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// compraRequisicaoDetalhe
		$compraRequisicaoDetalheModelListJson = $objJson->compraRequisicaoDetalheModelList;
		if ($compraRequisicaoDetalheModelListJson != null) {
			for ($i = 0; $i < count($compraRequisicaoDetalheModelListJson); $i++) {
				$compraRequisicaoDetalhe = new CompraRequisicaoDetalheModel();
				$compraRequisicaoDetalhe->mapping($compraRequisicaoDetalheModelListJson[$i]);
				$objModel->compraRequisicaoDetalheModelList()->save($compraRequisicaoDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		CompraRequisicaoDetalheModel::where('id_compra_requisicao', $object->getIdAttribute())->delete();
	}	
 
}