<?php
class CompraTipoPedidoService extends ServiceBase
{
  public function getList()
  {
    return CompraTipoPedidoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CompraTipoPedidoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CompraTipoPedidoModel::find($id);
  }

}