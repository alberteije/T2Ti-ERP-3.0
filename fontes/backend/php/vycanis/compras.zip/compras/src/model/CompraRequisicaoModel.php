<?php
declare(strict_types=1);

class CompraRequisicaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'compra_requisicao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'compraRequisicaoDetalheModelList',
		'viewPessoaColaboradorModel',
		'compraTipoRequisicaoModel',
	];

	/**
		* Relations
		*/
	public function compraRequisicaoDetalheModelList()
{
	return $this->hasMany(CompraRequisicaoDetalheModel::class, 'id_compra_requisicao', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function compraTipoRequisicaoModel()
	{
		return $this->belongsTo(CompraTipoRequisicaoModel::class, 'id_compra_tipo_requisicao', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getDataRequisicaoAttribute()
	{
		return $this->attributes['data_requisicao'];
	}

	public function setDataRequisicaoAttribute($dataRequisicao)
	{
		$this->attributes['data_requisicao'] = $dataRequisicao;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setDataRequisicaoAttribute($object->dataRequisicao);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$compraTipoRequisicaoModel = new CompraTipoRequisicaoModel();
				$compraTipoRequisicaoModel->mapping($object->compraTipoRequisicaoModel);
				$this->compraTipoRequisicaoModel()->associate($compraTipoRequisicaoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'dataRequisicao' => $this->getDataRequisicaoAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'compraRequisicaoDetalheModelList' => $this->compraRequisicaoDetalheModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'compraTipoRequisicaoModel' => $this->compraTipoRequisicaoModel,
			];
	}
}