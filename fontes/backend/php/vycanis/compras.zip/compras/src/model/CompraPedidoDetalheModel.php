<?php
declare(strict_types=1);

class CompraPedidoDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'compra_pedido_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'produtoModel',
	];

	/**
		* Relations
		*/
	public function compraPedidoModel()
	{
		return $this->belongsTo(CompraPedidoModel::class, 'id_compra_pedido', 'id');
	}

	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return (double)$this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getValorUnitarioAttribute()
	{
		return (double)$this->attributes['valor_unitario'];
	}

	public function setValorUnitarioAttribute($valorUnitario)
	{
		$this->attributes['valor_unitario'] = $valorUnitario;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getCstAttribute()
	{
		return $this->attributes['cst'];
	}

	public function setCstAttribute($cst)
	{
		$this->attributes['cst'] = $cst;
	}

	public function getCsosnAttribute()
	{
		return $this->attributes['csosn'];
	}

	public function setCsosnAttribute($csosn)
	{
		$this->attributes['csosn'] = $csosn;
	}

	public function getCfopAttribute()
	{
		return $this->attributes['cfop'];
	}

	public function setCfopAttribute($cfop)
	{
		$this->attributes['cfop'] = $cfop;
	}

	public function getBaseCalculoIcmsAttribute()
	{
		return (double)$this->attributes['base_calculo_icms'];
	}

	public function setBaseCalculoIcmsAttribute($baseCalculoIcms)
	{
		$this->attributes['base_calculo_icms'] = $baseCalculoIcms;
	}

	public function getValorIcmsAttribute()
	{
		return (double)$this->attributes['valor_icms'];
	}

	public function setValorIcmsAttribute($valorIcms)
	{
		$this->attributes['valor_icms'] = $valorIcms;
	}

	public function getValorIpiAttribute()
	{
		return (double)$this->attributes['valor_ipi'];
	}

	public function setValorIpiAttribute($valorIpi)
	{
		$this->attributes['valor_ipi'] = $valorIpi;
	}

	public function getAliquotaIcmsAttribute()
	{
		return (double)$this->attributes['aliquota_icms'];
	}

	public function setAliquotaIcmsAttribute($aliquotaIcms)
	{
		$this->attributes['aliquota_icms'] = $aliquotaIcms;
	}

	public function getAliquotaIpiAttribute()
	{
		return (double)$this->attributes['aliquota_ipi'];
	}

	public function setAliquotaIpiAttribute($aliquotaIpi)
	{
		$this->attributes['aliquota_ipi'] = $aliquotaIpi;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);
				$this->setValorUnitarioAttribute($object->valorUnitario);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setCstAttribute($object->cst);
				$this->setCsosnAttribute($object->csosn);
				$this->setCfopAttribute($object->cfop);
				$this->setBaseCalculoIcmsAttribute($object->baseCalculoIcms);
				$this->setValorIcmsAttribute($object->valorIcms);
				$this->setValorIpiAttribute($object->valorIpi);
				$this->setAliquotaIcmsAttribute($object->aliquotaIcms);
				$this->setAliquotaIpiAttribute($object->aliquotaIpi);

				// link objects - lookups
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'valorUnitario' => $this->getValorUnitarioAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'cst' => $this->getCstAttribute(),
				'csosn' => $this->getCsosnAttribute(),
				'cfop' => $this->getCfopAttribute(),
				'baseCalculoIcms' => $this->getBaseCalculoIcmsAttribute(),
				'valorIcms' => $this->getValorIcmsAttribute(),
				'valorIpi' => $this->getValorIpiAttribute(),
				'aliquotaIcms' => $this->getAliquotaIcmsAttribute(),
				'aliquotaIpi' => $this->getAliquotaIpiAttribute(),
				'produtoModel' => $this->produtoModel,
			];
	}
}