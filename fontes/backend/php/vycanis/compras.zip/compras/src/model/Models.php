<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'CompraRequisicaoDetalheModel.php';
include 'CompraFornecedorCotacaoModel.php';
include 'CompraCotacaoDetalheModel.php';
include 'CompraPedidoDetalheModel.php';
include 'CompraRequisicaoModel.php';
include 'CompraCotacaoModel.php';
include 'CompraPedidoModel.php';
include 'ProdutoGrupoModel.php';
include 'ProdutoSubgrupoModel.php';
include 'ProdutoMarcaModel.php';
include 'ProdutoUnidadeModel.php';
include 'TributIcmsCustomCabModel.php';
include 'TributGrupoTributarioModel.php';
include 'ProdutoModel.php';
include 'CompraTipoRequisicaoModel.php';
include 'CompraTipoPedidoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaFornecedorModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';