<?php
declare(strict_types=1);

class CompraFornecedorCotacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'compra_fornecedor_cotacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaFornecedorModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaFornecedorModel()
	{
		return $this->belongsTo(ViewPessoaFornecedorModel::class, 'id_fornecedor', 'id');
	}

	public function compraCotacaoModel()
	{
		return $this->belongsTo(CompraCotacaoModel::class, 'id_compra_cotacao', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getPrazoEntregaAttribute()
	{
		return $this->attributes['prazo_entrega'];
	}

	public function setPrazoEntregaAttribute($prazoEntrega)
	{
		$this->attributes['prazo_entrega'] = $prazoEntrega;
	}

	public function getVendaCondicoesPagamentoAttribute()
	{
		return $this->attributes['venda_condicoes_pagamento'];
	}

	public function setVendaCondicoesPagamentoAttribute($vendaCondicoesPagamento)
	{
		$this->attributes['venda_condicoes_pagamento'] = $vendaCondicoesPagamento;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setPrazoEntregaAttribute($object->prazoEntrega);
				$this->setVendaCondicoesPagamentoAttribute($object->vendaCondicoesPagamento);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorTotalAttribute($object->valorTotal);

				// link objects - lookups
				$viewPessoaFornecedorModel = new ViewPessoaFornecedorModel();
				$viewPessoaFornecedorModel->mapping($object->viewPessoaFornecedorModel);
				$this->viewPessoaFornecedorModel()->associate($viewPessoaFornecedorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'prazoEntrega' => $this->getPrazoEntregaAttribute(),
				'vendaCondicoesPagamento' => $this->getVendaCondicoesPagamentoAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'viewPessoaFornecedorModel' => $this->viewPessoaFornecedorModel,
			];
	}
}