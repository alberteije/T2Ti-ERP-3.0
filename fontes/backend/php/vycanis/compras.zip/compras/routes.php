<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// compra-requisicao
$app->get('/compra-requisicao[/]', \CompraRequisicaoController::class . RESULT_LIST);
$app->get('/compra-requisicao/{id}', \CompraRequisicaoController::class . RESULT_OBJECT);
$app->post('/compra-requisicao', \CompraRequisicaoController::class . INSERT);
$app->put('/compra-requisicao', \CompraRequisicaoController::class . UPDATE);
$app->delete('/compra-requisicao/{id}', \CompraRequisicaoController::class . DELETE);
$app->options('/compra-requisicao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-requisicao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-requisicao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// compra-cotacao
$app->get('/compra-cotacao[/]', \CompraCotacaoController::class . RESULT_LIST);
$app->get('/compra-cotacao/{id}', \CompraCotacaoController::class . RESULT_OBJECT);
$app->post('/compra-cotacao', \CompraCotacaoController::class . INSERT);
$app->put('/compra-cotacao', \CompraCotacaoController::class . UPDATE);
$app->delete('/compra-cotacao/{id}', \CompraCotacaoController::class . DELETE);
$app->options('/compra-cotacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-cotacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-cotacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// compra-pedido
$app->get('/compra-pedido[/]', \CompraPedidoController::class . RESULT_LIST);
$app->get('/compra-pedido/{id}', \CompraPedidoController::class . RESULT_OBJECT);
$app->post('/compra-pedido', \CompraPedidoController::class . INSERT);
$app->put('/compra-pedido', \CompraPedidoController::class . UPDATE);
$app->delete('/compra-pedido/{id}', \CompraPedidoController::class . DELETE);
$app->options('/compra-pedido', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-pedido/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-pedido/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-grupo
$app->get('/produto-grupo[/]', \ProdutoGrupoController::class . RESULT_LIST);
$app->get('/produto-grupo/{id}', \ProdutoGrupoController::class . RESULT_OBJECT);
$app->post('/produto-grupo', \ProdutoGrupoController::class . INSERT);
$app->put('/produto-grupo', \ProdutoGrupoController::class . UPDATE);
$app->delete('/produto-grupo/{id}', \ProdutoGrupoController::class . DELETE);
$app->options('/produto-grupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-subgrupo
$app->get('/produto-subgrupo[/]', \ProdutoSubgrupoController::class . RESULT_LIST);
$app->get('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . RESULT_OBJECT);
$app->post('/produto-subgrupo', \ProdutoSubgrupoController::class . INSERT);
$app->put('/produto-subgrupo', \ProdutoSubgrupoController::class . UPDATE);
$app->delete('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . DELETE);
$app->options('/produto-subgrupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-marca
$app->get('/produto-marca[/]', \ProdutoMarcaController::class . RESULT_LIST);
$app->get('/produto-marca/{id}', \ProdutoMarcaController::class . RESULT_OBJECT);
$app->post('/produto-marca', \ProdutoMarcaController::class . INSERT);
$app->put('/produto-marca', \ProdutoMarcaController::class . UPDATE);
$app->delete('/produto-marca/{id}', \ProdutoMarcaController::class . DELETE);
$app->options('/produto-marca', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-unidade
$app->get('/produto-unidade[/]', \ProdutoUnidadeController::class . RESULT_LIST);
$app->get('/produto-unidade/{id}', \ProdutoUnidadeController::class . RESULT_OBJECT);
$app->post('/produto-unidade', \ProdutoUnidadeController::class . INSERT);
$app->put('/produto-unidade', \ProdutoUnidadeController::class . UPDATE);
$app->delete('/produto-unidade/{id}', \ProdutoUnidadeController::class . DELETE);
$app->options('/produto-unidade', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-icms-custom-cab
$app->get('/tribut-icms-custom-cab[/]', \TributIcmsCustomCabController::class . RESULT_LIST);
$app->get('/tribut-icms-custom-cab/{id}', \TributIcmsCustomCabController::class . RESULT_OBJECT);
$app->post('/tribut-icms-custom-cab', \TributIcmsCustomCabController::class . INSERT);
$app->put('/tribut-icms-custom-cab', \TributIcmsCustomCabController::class . UPDATE);
$app->delete('/tribut-icms-custom-cab/{id}', \TributIcmsCustomCabController::class . DELETE);
$app->options('/tribut-icms-custom-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-icms-custom-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-icms-custom-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-grupo-tributario
$app->get('/tribut-grupo-tributario[/]', \TributGrupoTributarioController::class . RESULT_LIST);
$app->get('/tribut-grupo-tributario/{id}', \TributGrupoTributarioController::class . RESULT_OBJECT);
$app->post('/tribut-grupo-tributario', \TributGrupoTributarioController::class . INSERT);
$app->put('/tribut-grupo-tributario', \TributGrupoTributarioController::class . UPDATE);
$app->delete('/tribut-grupo-tributario/{id}', \TributGrupoTributarioController::class . DELETE);
$app->options('/tribut-grupo-tributario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-grupo-tributario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-grupo-tributario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto
$app->get('/produto[/]', \ProdutoController::class . RESULT_LIST);
$app->get('/produto/{id}', \ProdutoController::class . RESULT_OBJECT);
$app->post('/produto', \ProdutoController::class . INSERT);
$app->put('/produto', \ProdutoController::class . UPDATE);
$app->delete('/produto/{id}', \ProdutoController::class . DELETE);
$app->options('/produto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// compra-tipo-requisicao
$app->get('/compra-tipo-requisicao[/]', \CompraTipoRequisicaoController::class . RESULT_LIST);
$app->get('/compra-tipo-requisicao/{id}', \CompraTipoRequisicaoController::class . RESULT_OBJECT);
$app->post('/compra-tipo-requisicao', \CompraTipoRequisicaoController::class . INSERT);
$app->put('/compra-tipo-requisicao', \CompraTipoRequisicaoController::class . UPDATE);
$app->delete('/compra-tipo-requisicao/{id}', \CompraTipoRequisicaoController::class . DELETE);
$app->options('/compra-tipo-requisicao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-tipo-requisicao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-tipo-requisicao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// compra-tipo-pedido
$app->get('/compra-tipo-pedido[/]', \CompraTipoPedidoController::class . RESULT_LIST);
$app->get('/compra-tipo-pedido/{id}', \CompraTipoPedidoController::class . RESULT_OBJECT);
$app->post('/compra-tipo-pedido', \CompraTipoPedidoController::class . INSERT);
$app->put('/compra-tipo-pedido', \CompraTipoPedidoController::class . UPDATE);
$app->delete('/compra-tipo-pedido/{id}', \CompraTipoPedidoController::class . DELETE);
$app->options('/compra-tipo-pedido', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-tipo-pedido/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/compra-tipo-pedido/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-fornecedor
$app->get('/view-pessoa-fornecedor[/]', \ViewPessoaFornecedorController::class . RESULT_LIST);
$app->get('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . INSERT);
$app->put('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . UPDATE);
$app->delete('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . DELETE);
$app->options('/view-pessoa-fornecedor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

