<?php
class PontoParametroController extends ControllerBase
{

		private $pontoParametroService = null;

		public function __construct()
		{	 
				$this->pontoParametroService = new PontoParametroService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->pontoParametroService->getListFilter($filter);
						} else {
								$resultList = $this->pontoParametroService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList PontoParametro]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->pontoParametroService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject PontoParametro]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject PontoParametro]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert PontoParametro]', null);
						}

						$objModel = new PontoParametroModel();
						$objModel->mapping($objJson);

						$this->pontoParametroService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert PontoParametro]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->pontoParametroService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update PontoParametro]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->pontoParametroService->save($objFromDatabase);
								$objFromDatabase = $this->pontoParametroService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update PontoParametro]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->pontoParametroService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete PontoParametro]', null);
						} else {
								$this->pontoParametroService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete PontoParametro]', $e);
				}
		}
}
