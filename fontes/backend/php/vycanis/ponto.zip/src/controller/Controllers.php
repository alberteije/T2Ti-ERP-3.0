<?php

include 'ControllerBase.php';
include 'LoginController.php';

include 'PontoEscalaController.php';
include 'PontoBancoHorasController.php';
include 'PontoAbonoController.php';
include 'PontoParametroController.php';
include 'PontoHorarioController.php';
include 'PontoRelogioController.php';
include 'PontoMarcacaoController.php';
include 'PontoClassificacaoJornadaController.php';
include 'PontoHorarioAutorizadoController.php';
include 'PontoFechamentoJornadaController.php';
include 'ViewControleAcessoController.php';
include 'ViewPessoaUsuarioController.php';
include 'ViewPessoaColaboradorController.php';