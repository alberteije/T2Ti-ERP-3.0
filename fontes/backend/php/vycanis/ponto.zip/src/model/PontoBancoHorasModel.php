<?php
declare(strict_types=1);

class PontoBancoHorasModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_banco_horas';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pontoBancoHorasUtilizacaoModelList',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function pontoBancoHorasUtilizacaoModelList()
{
	return $this->hasMany(PontoBancoHorasUtilizacaoModel::class, 'id_ponto_banco_horas', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataTrabalhoAttribute()
	{
		return $this->attributes['data_trabalho'];
	}

	public function setDataTrabalhoAttribute($dataTrabalho)
	{
		$this->attributes['data_trabalho'] = $dataTrabalho;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataTrabalhoAttribute($object->dataTrabalho);
				$this->setQuantidadeAttribute($object->quantidade);
				$this->setSituacaoAttribute($object->situacao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataTrabalho' => $this->getDataTrabalhoAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'pontoBancoHorasUtilizacaoModelList' => $this->pontoBancoHorasUtilizacaoModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}