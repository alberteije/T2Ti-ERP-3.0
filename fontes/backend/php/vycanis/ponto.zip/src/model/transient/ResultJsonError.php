<?php

/// transient class that stores the error object that will be returned to the client
class ResultJsonError implements \JsonSerializable
{
	private $status;
	private $message;
	private $error;
	private $trace;

	public function __construct(int $codigo, string $mensagem, ?Exception $erro)
	{
		$this->status = $codigo;
		$this->message = $mensagem;

		switch ($this->status) {
			case 400:
				$this->error = 'Bad Request';
				break;
			case 404:
				$this->error = 'Not Found';
				break;
			case 500:
				$this->error = 'Internal Server Error';
				break;
			default:
				$this->error = 'Not Mapped Error';
				break;
		}

		if ($erro != null) {
			$this->message = $this->message . " - Error: " . $erro->getMessage();
			$this->trace = $erro->getTraceAsString();
		}
	}

    /**
     * {@inheritdoc}
     */
    public function jsonSerialize()
    {
			return [
				'status' => $this->status,
				'message' => $this->message,
				'error' => $this->error,
				'trace' => $this->trace
			];
    }


}