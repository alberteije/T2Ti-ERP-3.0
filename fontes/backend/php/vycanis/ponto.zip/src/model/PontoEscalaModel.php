<?php
declare(strict_types=1);

class PontoEscalaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_escala';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pontoTurmaModelList',
	];

	/**
		* Relations
		*/
	public function pontoTurmaModelList()
{
	return $this->hasMany(PontoTurmaModel::class, 'id_ponto_escala', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescontoHoraDiaAttribute()
	{
		return $this->attributes['desconto_hora_dia'];
	}

	public function setDescontoHoraDiaAttribute($descontoHoraDia)
	{
		$this->attributes['desconto_hora_dia'] = $descontoHoraDia;
	}

	public function getDescontoDsrAttribute()
	{
		return $this->attributes['desconto_dsr'];
	}

	public function setDescontoDsrAttribute($descontoDsr)
	{
		$this->attributes['desconto_dsr'] = $descontoDsr;
	}

	public function getCodigoHorarioDomingoAttribute()
	{
		return $this->attributes['codigo_horario_domingo'];
	}

	public function setCodigoHorarioDomingoAttribute($codigoHorarioDomingo)
	{
		$this->attributes['codigo_horario_domingo'] = $codigoHorarioDomingo;
	}

	public function getCodigoHorarioSegundaAttribute()
	{
		return $this->attributes['codigo_horario_segunda'];
	}

	public function setCodigoHorarioSegundaAttribute($codigoHorarioSegunda)
	{
		$this->attributes['codigo_horario_segunda'] = $codigoHorarioSegunda;
	}

	public function getCodigoHorarioTercaAttribute()
	{
		return $this->attributes['codigo_horario_terca'];
	}

	public function setCodigoHorarioTercaAttribute($codigoHorarioTerca)
	{
		$this->attributes['codigo_horario_terca'] = $codigoHorarioTerca;
	}

	public function getCodigoHorarioQuartaAttribute()
	{
		return $this->attributes['codigo_horario_quarta'];
	}

	public function setCodigoHorarioQuartaAttribute($codigoHorarioQuarta)
	{
		$this->attributes['codigo_horario_quarta'] = $codigoHorarioQuarta;
	}

	public function getCodigoHorarioQuintaAttribute()
	{
		return $this->attributes['codigo_horario_quinta'];
	}

	public function setCodigoHorarioQuintaAttribute($codigoHorarioQuinta)
	{
		$this->attributes['codigo_horario_quinta'] = $codigoHorarioQuinta;
	}

	public function getCodigoHorarioSextaAttribute()
	{
		return $this->attributes['codigo_horario_sexta'];
	}

	public function setCodigoHorarioSextaAttribute($codigoHorarioSexta)
	{
		$this->attributes['codigo_horario_sexta'] = $codigoHorarioSexta;
	}

	public function getCodigoHorarioSabadoAttribute()
	{
		return $this->attributes['codigo_horario_sabado'];
	}

	public function setCodigoHorarioSabadoAttribute($codigoHorarioSabado)
	{
		$this->attributes['codigo_horario_sabado'] = $codigoHorarioSabado;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDescontoHoraDiaAttribute($object->descontoHoraDia);
				$this->setDescontoDsrAttribute($object->descontoDsr);
				$this->setCodigoHorarioDomingoAttribute($object->codigoHorarioDomingo);
				$this->setCodigoHorarioSegundaAttribute($object->codigoHorarioSegunda);
				$this->setCodigoHorarioTercaAttribute($object->codigoHorarioTerca);
				$this->setCodigoHorarioQuartaAttribute($object->codigoHorarioQuarta);
				$this->setCodigoHorarioQuintaAttribute($object->codigoHorarioQuinta);
				$this->setCodigoHorarioSextaAttribute($object->codigoHorarioSexta);
				$this->setCodigoHorarioSabadoAttribute($object->codigoHorarioSabado);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descontoHoraDia' => $this->getDescontoHoraDiaAttribute(),
				'descontoDsr' => $this->getDescontoDsrAttribute(),
				'codigoHorarioDomingo' => $this->getCodigoHorarioDomingoAttribute(),
				'codigoHorarioSegunda' => $this->getCodigoHorarioSegundaAttribute(),
				'codigoHorarioTerca' => $this->getCodigoHorarioTercaAttribute(),
				'codigoHorarioQuarta' => $this->getCodigoHorarioQuartaAttribute(),
				'codigoHorarioQuinta' => $this->getCodigoHorarioQuintaAttribute(),
				'codigoHorarioSexta' => $this->getCodigoHorarioSextaAttribute(),
				'codigoHorarioSabado' => $this->getCodigoHorarioSabadoAttribute(),
				'pontoTurmaModelList' => $this->pontoTurmaModelList,
			];
	}
}