<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'PontoTurmaModel.php';
include 'PontoAbonoUtilizacaoModel.php';
include 'PontoBancoHorasUtilizacaoModel.php';
include 'PontoEscalaModel.php';
include 'PontoBancoHorasModel.php';
include 'PontoAbonoModel.php';
include 'PontoParametroModel.php';
include 'PontoHorarioModel.php';
include 'PontoRelogioModel.php';
include 'PontoMarcacaoModel.php';
include 'PontoClassificacaoJornadaModel.php';
include 'PontoHorarioAutorizadoModel.php';
include 'PontoFechamentoJornadaModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';