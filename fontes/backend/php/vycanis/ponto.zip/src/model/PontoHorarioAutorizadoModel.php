<?php
declare(strict_types=1);

class PontoHorarioAutorizadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_horario_autorizado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataHorarioAttribute()
	{
		return $this->attributes['data_horario'];
	}

	public function setDataHorarioAttribute($dataHorario)
	{
		$this->attributes['data_horario'] = $dataHorario;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getCargaHorariaAttribute()
	{
		return $this->attributes['carga_horaria'];
	}

	public function setCargaHorariaAttribute($cargaHoraria)
	{
		$this->attributes['carga_horaria'] = $cargaHoraria;
	}

	public function getEntrada01Attribute()
	{
		return $this->attributes['entrada01'];
	}

	public function setEntrada01Attribute($entrada01)
	{
		$this->attributes['entrada01'] = $entrada01;
	}

	public function getSaida01Attribute()
	{
		return $this->attributes['saida01'];
	}

	public function setSaida01Attribute($saida01)
	{
		$this->attributes['saida01'] = $saida01;
	}

	public function getEntrada02Attribute()
	{
		return $this->attributes['entrada02'];
	}

	public function setEntrada02Attribute($entrada02)
	{
		$this->attributes['entrada02'] = $entrada02;
	}

	public function getSaida02Attribute()
	{
		return $this->attributes['saida02'];
	}

	public function setSaida02Attribute($saida02)
	{
		$this->attributes['saida02'] = $saida02;
	}

	public function getEntrada03Attribute()
	{
		return $this->attributes['entrada03'];
	}

	public function setEntrada03Attribute($entrada03)
	{
		$this->attributes['entrada03'] = $entrada03;
	}

	public function getSaida03Attribute()
	{
		return $this->attributes['saida03'];
	}

	public function setSaida03Attribute($saida03)
	{
		$this->attributes['saida03'] = $saida03;
	}

	public function getEntrada04Attribute()
	{
		return $this->attributes['entrada04'];
	}

	public function setEntrada04Attribute($entrada04)
	{
		$this->attributes['entrada04'] = $entrada04;
	}

	public function getSaida04Attribute()
	{
		return $this->attributes['saida04'];
	}

	public function setSaida04Attribute($saida04)
	{
		$this->attributes['saida04'] = $saida04;
	}

	public function getEntrada05Attribute()
	{
		return $this->attributes['entrada05'];
	}

	public function setEntrada05Attribute($entrada05)
	{
		$this->attributes['entrada05'] = $entrada05;
	}

	public function getSaida05Attribute()
	{
		return $this->attributes['saida05'];
	}

	public function setSaida05Attribute($saida05)
	{
		$this->attributes['saida05'] = $saida05;
	}

	public function getHoraFechamentoDiaAttribute()
	{
		return $this->attributes['hora_fechamento_dia'];
	}

	public function setHoraFechamentoDiaAttribute($horaFechamentoDia)
	{
		$this->attributes['hora_fechamento_dia'] = $horaFechamentoDia;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataHorarioAttribute($object->dataHorario);
				$this->setTipoAttribute($object->tipo);
				$this->setCargaHorariaAttribute($object->cargaHoraria);
				$this->setEntrada01Attribute($object->entrada01);
				$this->setSaida01Attribute($object->saida01);
				$this->setEntrada02Attribute($object->entrada02);
				$this->setSaida02Attribute($object->saida02);
				$this->setEntrada03Attribute($object->entrada03);
				$this->setSaida03Attribute($object->saida03);
				$this->setEntrada04Attribute($object->entrada04);
				$this->setSaida04Attribute($object->saida04);
				$this->setEntrada05Attribute($object->entrada05);
				$this->setSaida05Attribute($object->saida05);
				$this->setHoraFechamentoDiaAttribute($object->horaFechamentoDia);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataHorario' => $this->getDataHorarioAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'cargaHoraria' => $this->getCargaHorariaAttribute(),
				'entrada01' => $this->getEntrada01Attribute(),
				'saida01' => $this->getSaida01Attribute(),
				'entrada02' => $this->getEntrada02Attribute(),
				'saida02' => $this->getSaida02Attribute(),
				'entrada03' => $this->getEntrada03Attribute(),
				'saida03' => $this->getSaida03Attribute(),
				'entrada04' => $this->getEntrada04Attribute(),
				'saida04' => $this->getSaida04Attribute(),
				'entrada05' => $this->getEntrada05Attribute(),
				'saida05' => $this->getSaida05Attribute(),
				'horaFechamentoDia' => $this->getHoraFechamentoDiaAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}