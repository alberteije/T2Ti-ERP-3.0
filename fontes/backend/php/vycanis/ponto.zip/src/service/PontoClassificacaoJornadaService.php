<?php
class PontoClassificacaoJornadaService extends ServiceBase
{
  public function getList()
  {
    return PontoClassificacaoJornadaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PontoClassificacaoJornadaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PontoClassificacaoJornadaModel::find($id);
  }

}