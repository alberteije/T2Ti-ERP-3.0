<?php
class PontoHorarioAutorizadoService extends ServiceBase
{
  public function getList()
  {
    return PontoHorarioAutorizadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PontoHorarioAutorizadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PontoHorarioAutorizadoModel::find($id);
  }

}