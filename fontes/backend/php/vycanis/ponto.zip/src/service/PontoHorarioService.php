<?php
class PontoHorarioService extends ServiceBase
{
  public function getList()
  {
    return PontoHorarioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PontoHorarioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PontoHorarioModel::find($id);
  }

}