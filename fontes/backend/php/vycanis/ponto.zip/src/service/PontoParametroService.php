<?php
class PontoParametroService extends ServiceBase
{
  public function getList()
  {
    return PontoParametroModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PontoParametroModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PontoParametroModel::find($id);
  }

}