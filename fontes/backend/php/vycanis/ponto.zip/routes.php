<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// ponto-escala
$app->get('/ponto-escala[/]', \PontoEscalaController::class . RESULT_LIST);
$app->get('/ponto-escala/{id}', \PontoEscalaController::class . RESULT_OBJECT);
$app->post('/ponto-escala', \PontoEscalaController::class . INSERT);
$app->put('/ponto-escala', \PontoEscalaController::class . UPDATE);
$app->delete('/ponto-escala/{id}', \PontoEscalaController::class . DELETE);
$app->options('/ponto-escala', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-escala/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-escala/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-banco-horas
$app->get('/ponto-banco-horas[/]', \PontoBancoHorasController::class . RESULT_LIST);
$app->get('/ponto-banco-horas/{id}', \PontoBancoHorasController::class . RESULT_OBJECT);
$app->post('/ponto-banco-horas', \PontoBancoHorasController::class . INSERT);
$app->put('/ponto-banco-horas', \PontoBancoHorasController::class . UPDATE);
$app->delete('/ponto-banco-horas/{id}', \PontoBancoHorasController::class . DELETE);
$app->options('/ponto-banco-horas', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-banco-horas/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-banco-horas/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-abono
$app->get('/ponto-abono[/]', \PontoAbonoController::class . RESULT_LIST);
$app->get('/ponto-abono/{id}', \PontoAbonoController::class . RESULT_OBJECT);
$app->post('/ponto-abono', \PontoAbonoController::class . INSERT);
$app->put('/ponto-abono', \PontoAbonoController::class . UPDATE);
$app->delete('/ponto-abono/{id}', \PontoAbonoController::class . DELETE);
$app->options('/ponto-abono', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-abono/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-abono/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-parametro
$app->get('/ponto-parametro[/]', \PontoParametroController::class . RESULT_LIST);
$app->get('/ponto-parametro/{id}', \PontoParametroController::class . RESULT_OBJECT);
$app->post('/ponto-parametro', \PontoParametroController::class . INSERT);
$app->put('/ponto-parametro', \PontoParametroController::class . UPDATE);
$app->delete('/ponto-parametro/{id}', \PontoParametroController::class . DELETE);
$app->options('/ponto-parametro', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-parametro/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-parametro/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-horario
$app->get('/ponto-horario[/]', \PontoHorarioController::class . RESULT_LIST);
$app->get('/ponto-horario/{id}', \PontoHorarioController::class . RESULT_OBJECT);
$app->post('/ponto-horario', \PontoHorarioController::class . INSERT);
$app->put('/ponto-horario', \PontoHorarioController::class . UPDATE);
$app->delete('/ponto-horario/{id}', \PontoHorarioController::class . DELETE);
$app->options('/ponto-horario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-horario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-horario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-relogio
$app->get('/ponto-relogio[/]', \PontoRelogioController::class . RESULT_LIST);
$app->get('/ponto-relogio/{id}', \PontoRelogioController::class . RESULT_OBJECT);
$app->post('/ponto-relogio', \PontoRelogioController::class . INSERT);
$app->put('/ponto-relogio', \PontoRelogioController::class . UPDATE);
$app->delete('/ponto-relogio/{id}', \PontoRelogioController::class . DELETE);
$app->options('/ponto-relogio', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-relogio/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-relogio/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-marcacao
$app->get('/ponto-marcacao[/]', \PontoMarcacaoController::class . RESULT_LIST);
$app->get('/ponto-marcacao/{id}', \PontoMarcacaoController::class . RESULT_OBJECT);
$app->post('/ponto-marcacao', \PontoMarcacaoController::class . INSERT);
$app->put('/ponto-marcacao', \PontoMarcacaoController::class . UPDATE);
$app->delete('/ponto-marcacao/{id}', \PontoMarcacaoController::class . DELETE);
$app->options('/ponto-marcacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-marcacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-marcacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-classificacao-jornada
$app->get('/ponto-classificacao-jornada[/]', \PontoClassificacaoJornadaController::class . RESULT_LIST);
$app->get('/ponto-classificacao-jornada/{id}', \PontoClassificacaoJornadaController::class . RESULT_OBJECT);
$app->post('/ponto-classificacao-jornada', \PontoClassificacaoJornadaController::class . INSERT);
$app->put('/ponto-classificacao-jornada', \PontoClassificacaoJornadaController::class . UPDATE);
$app->delete('/ponto-classificacao-jornada/{id}', \PontoClassificacaoJornadaController::class . DELETE);
$app->options('/ponto-classificacao-jornada', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-classificacao-jornada/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-classificacao-jornada/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-horario-autorizado
$app->get('/ponto-horario-autorizado[/]', \PontoHorarioAutorizadoController::class . RESULT_LIST);
$app->get('/ponto-horario-autorizado/{id}', \PontoHorarioAutorizadoController::class . RESULT_OBJECT);
$app->post('/ponto-horario-autorizado', \PontoHorarioAutorizadoController::class . INSERT);
$app->put('/ponto-horario-autorizado', \PontoHorarioAutorizadoController::class . UPDATE);
$app->delete('/ponto-horario-autorizado/{id}', \PontoHorarioAutorizadoController::class . DELETE);
$app->options('/ponto-horario-autorizado', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-horario-autorizado/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-horario-autorizado/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ponto-fechamento-jornada
$app->get('/ponto-fechamento-jornada[/]', \PontoFechamentoJornadaController::class . RESULT_LIST);
$app->get('/ponto-fechamento-jornada/{id}', \PontoFechamentoJornadaController::class . RESULT_OBJECT);
$app->post('/ponto-fechamento-jornada', \PontoFechamentoJornadaController::class . INSERT);
$app->put('/ponto-fechamento-jornada', \PontoFechamentoJornadaController::class . UPDATE);
$app->delete('/ponto-fechamento-jornada/{id}', \PontoFechamentoJornadaController::class . DELETE);
$app->options('/ponto-fechamento-jornada', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-fechamento-jornada/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ponto-fechamento-jornada/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

