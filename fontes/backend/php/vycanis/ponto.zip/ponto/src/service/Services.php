<?php

include 'ServiceBase.php';

include 'PontoEscalaService.php';
include 'PontoBancoHorasService.php';
include 'PontoAbonoService.php';
include 'PontoParametroService.php';
include 'PontoHorarioService.php';
include 'PontoRelogioService.php';
include 'PontoMarcacaoService.php';
include 'PontoClassificacaoJornadaService.php';
include 'PontoHorarioAutorizadoService.php';
include 'PontoFechamentoJornadaService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';