<?php
use Illuminate\Database\Capsule\Manager as DB;
class PontoEscalaService extends ServiceBase
{
	public function getList()
	{
		return PontoEscalaModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return PontoEscalaModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return PontoEscalaModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// pontoTurma
		$pontoTurmaModelListJson = $objJson->pontoTurmaModelList;
		if ($pontoTurmaModelListJson != null) {
			for ($i = 0; $i < count($pontoTurmaModelListJson); $i++) {
				$pontoTurma = new PontoTurmaModel();
				$pontoTurma->mapping($pontoTurmaModelListJson[$i]);
				$objModel->pontoTurmaModelList()->save($pontoTurma);
			}
		}

	}	

	public function deleteChildren($object)
	{
		PontoTurmaModel::where('id_ponto_escala', $object->getIdAttribute())->delete();
	}	
 
}