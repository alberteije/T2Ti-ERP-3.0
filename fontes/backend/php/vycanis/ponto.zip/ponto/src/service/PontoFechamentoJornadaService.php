<?php
class PontoFechamentoJornadaService extends ServiceBase
{
  public function getList()
  {
    return PontoFechamentoJornadaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PontoFechamentoJornadaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PontoFechamentoJornadaModel::find($id);
  }

}