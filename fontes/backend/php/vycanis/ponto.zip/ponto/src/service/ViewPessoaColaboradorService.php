<?php
class ViewPessoaColaboradorService extends ServiceBase
{
  public function getList()
  {
    return ViewPessoaColaboradorModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewPessoaColaboradorModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewPessoaColaboradorModel::find($id);
  }

}