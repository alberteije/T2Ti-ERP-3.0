<?php
class PontoMarcacaoService extends ServiceBase
{
  public function getList()
  {
    return PontoMarcacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PontoMarcacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PontoMarcacaoModel::find($id);
  }

}