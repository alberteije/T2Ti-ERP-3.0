<?php
class PontoRelogioService extends ServiceBase
{
  public function getList()
  {
    return PontoRelogioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PontoRelogioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PontoRelogioModel::find($id);
  }

}