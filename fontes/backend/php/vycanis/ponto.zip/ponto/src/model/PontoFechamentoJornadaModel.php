<?php
declare(strict_types=1);

class PontoFechamentoJornadaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_fechamento_jornada';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
		'pontoClassificacaoJornadaModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function pontoClassificacaoJornadaModel()
	{
		return $this->belongsTo(PontoClassificacaoJornadaModel::class, 'id_ponto_classificacao_jornada', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataFechamentoAttribute()
	{
		return $this->attributes['data_fechamento'];
	}

	public function setDataFechamentoAttribute($dataFechamento)
	{
		$this->attributes['data_fechamento'] = $dataFechamento;
	}

	public function getDiaSemanaAttribute()
	{
		return $this->attributes['dia_semana'];
	}

	public function setDiaSemanaAttribute($diaSemana)
	{
		$this->attributes['dia_semana'] = $diaSemana;
	}

	public function getCodigoHorarioAttribute()
	{
		return $this->attributes['codigo_horario'];
	}

	public function setCodigoHorarioAttribute($codigoHorario)
	{
		$this->attributes['codigo_horario'] = $codigoHorario;
	}

	public function getCargaHorariaEsperadaAttribute()
	{
		return $this->attributes['carga_horaria_esperada'];
	}

	public function setCargaHorariaEsperadaAttribute($cargaHorariaEsperada)
	{
		$this->attributes['carga_horaria_esperada'] = $cargaHorariaEsperada;
	}

	public function getCargaHorariaDiurnaAttribute()
	{
		return $this->attributes['carga_horaria_diurna'];
	}

	public function setCargaHorariaDiurnaAttribute($cargaHorariaDiurna)
	{
		$this->attributes['carga_horaria_diurna'] = $cargaHorariaDiurna;
	}

	public function getCargaHorariaNoturnaAttribute()
	{
		return $this->attributes['carga_horaria_noturna'];
	}

	public function setCargaHorariaNoturnaAttribute($cargaHorariaNoturna)
	{
		$this->attributes['carga_horaria_noturna'] = $cargaHorariaNoturna;
	}

	public function getCargaHorariaTotalAttribute()
	{
		return $this->attributes['carga_horaria_total'];
	}

	public function setCargaHorariaTotalAttribute($cargaHorariaTotal)
	{
		$this->attributes['carga_horaria_total'] = $cargaHorariaTotal;
	}

	public function getEntrada01Attribute()
	{
		return $this->attributes['entrada01'];
	}

	public function setEntrada01Attribute($entrada01)
	{
		$this->attributes['entrada01'] = $entrada01;
	}

	public function getSaida01Attribute()
	{
		return $this->attributes['saida01'];
	}

	public function setSaida01Attribute($saida01)
	{
		$this->attributes['saida01'] = $saida01;
	}

	public function getEntrada02Attribute()
	{
		return $this->attributes['entrada02'];
	}

	public function setEntrada02Attribute($entrada02)
	{
		$this->attributes['entrada02'] = $entrada02;
	}

	public function getSaida02Attribute()
	{
		return $this->attributes['saida02'];
	}

	public function setSaida02Attribute($saida02)
	{
		$this->attributes['saida02'] = $saida02;
	}

	public function getEntrada03Attribute()
	{
		return $this->attributes['entrada03'];
	}

	public function setEntrada03Attribute($entrada03)
	{
		$this->attributes['entrada03'] = $entrada03;
	}

	public function getSaida03Attribute()
	{
		return $this->attributes['saida03'];
	}

	public function setSaida03Attribute($saida03)
	{
		$this->attributes['saida03'] = $saida03;
	}

	public function getEntrada04Attribute()
	{
		return $this->attributes['entrada04'];
	}

	public function setEntrada04Attribute($entrada04)
	{
		$this->attributes['entrada04'] = $entrada04;
	}

	public function getSaida04Attribute()
	{
		return $this->attributes['saida04'];
	}

	public function setSaida04Attribute($saida04)
	{
		$this->attributes['saida04'] = $saida04;
	}

	public function getEntrada05Attribute()
	{
		return $this->attributes['entrada05'];
	}

	public function setEntrada05Attribute($entrada05)
	{
		$this->attributes['entrada05'] = $entrada05;
	}

	public function getSaida05Attribute()
	{
		return $this->attributes['saida05'];
	}

	public function setSaida05Attribute($saida05)
	{
		$this->attributes['saida05'] = $saida05;
	}

	public function getHoraInicioJornadaAttribute()
	{
		return $this->attributes['hora_inicio_jornada'];
	}

	public function setHoraInicioJornadaAttribute($horaInicioJornada)
	{
		$this->attributes['hora_inicio_jornada'] = $horaInicioJornada;
	}

	public function getHoraFimJornadaAttribute()
	{
		return $this->attributes['hora_fim_jornada'];
	}

	public function setHoraFimJornadaAttribute($horaFimJornada)
	{
		$this->attributes['hora_fim_jornada'] = $horaFimJornada;
	}

	public function getHoraExtra01Attribute()
	{
		return $this->attributes['hora_extra01'];
	}

	public function setHoraExtra01Attribute($horaExtra01)
	{
		$this->attributes['hora_extra01'] = $horaExtra01;
	}

	public function getPercentualHoraExtra01Attribute()
	{
		return (double)$this->attributes['percentual_hora_extra01'];
	}

	public function setPercentualHoraExtra01Attribute($percentualHoraExtra01)
	{
		$this->attributes['percentual_hora_extra01'] = $percentualHoraExtra01;
	}

	public function getModalidadeHoraExtra01Attribute()
	{
		return $this->attributes['modalidade_hora_extra01'];
	}

	public function setModalidadeHoraExtra01Attribute($modalidadeHoraExtra01)
	{
		$this->attributes['modalidade_hora_extra01'] = $modalidadeHoraExtra01;
	}

	public function getHoraExtra02Attribute()
	{
		return $this->attributes['hora_extra02'];
	}

	public function setHoraExtra02Attribute($horaExtra02)
	{
		$this->attributes['hora_extra02'] = $horaExtra02;
	}

	public function getPercentualHoraExtra02Attribute()
	{
		return (double)$this->attributes['percentual_hora_extra02'];
	}

	public function setPercentualHoraExtra02Attribute($percentualHoraExtra02)
	{
		$this->attributes['percentual_hora_extra02'] = $percentualHoraExtra02;
	}

	public function getModalidadeHoraExtra02Attribute()
	{
		return $this->attributes['modalidade_hora_extra02'];
	}

	public function setModalidadeHoraExtra02Attribute($modalidadeHoraExtra02)
	{
		$this->attributes['modalidade_hora_extra02'] = $modalidadeHoraExtra02;
	}

	public function getHoraExtra03Attribute()
	{
		return $this->attributes['hora_extra03'];
	}

	public function setHoraExtra03Attribute($horaExtra03)
	{
		$this->attributes['hora_extra03'] = $horaExtra03;
	}

	public function getPercentualHoraExtra03Attribute()
	{
		return (double)$this->attributes['percentual_hora_extra03'];
	}

	public function setPercentualHoraExtra03Attribute($percentualHoraExtra03)
	{
		$this->attributes['percentual_hora_extra03'] = $percentualHoraExtra03;
	}

	public function getModalidadeHoraExtra03Attribute()
	{
		return $this->attributes['modalidade_hora_extra03'];
	}

	public function setModalidadeHoraExtra03Attribute($modalidadeHoraExtra03)
	{
		$this->attributes['modalidade_hora_extra03'] = $modalidadeHoraExtra03;
	}

	public function getHoraExtra04Attribute()
	{
		return $this->attributes['hora_extra04'];
	}

	public function setHoraExtra04Attribute($horaExtra04)
	{
		$this->attributes['hora_extra04'] = $horaExtra04;
	}

	public function getPercentualHoraExtra04Attribute()
	{
		return (double)$this->attributes['percentual_hora_extra04'];
	}

	public function setPercentualHoraExtra04Attribute($percentualHoraExtra04)
	{
		$this->attributes['percentual_hora_extra04'] = $percentualHoraExtra04;
	}

	public function getModalidadeHoraExtra04Attribute()
	{
		return $this->attributes['modalidade_hora_extra04'];
	}

	public function setModalidadeHoraExtra04Attribute($modalidadeHoraExtra04)
	{
		$this->attributes['modalidade_hora_extra04'] = $modalidadeHoraExtra04;
	}

	public function getFaltaAtrasoAttribute()
	{
		return $this->attributes['falta_atraso'];
	}

	public function setFaltaAtrasoAttribute($faltaAtraso)
	{
		$this->attributes['falta_atraso'] = $faltaAtraso;
	}

	public function getCompensarAttribute()
	{
		return $this->attributes['compensar'];
	}

	public function setCompensarAttribute($compensar)
	{
		$this->attributes['compensar'] = $compensar;
	}

	public function getBancoHorasAttribute()
	{
		return $this->attributes['banco_horas'];
	}

	public function setBancoHorasAttribute($bancoHoras)
	{
		$this->attributes['banco_horas'] = $bancoHoras;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataFechamentoAttribute($object->dataFechamento);
				$this->setDiaSemanaAttribute($object->diaSemana);
				$this->setCodigoHorarioAttribute($object->codigoHorario);
				$this->setCargaHorariaEsperadaAttribute($object->cargaHorariaEsperada);
				$this->setCargaHorariaDiurnaAttribute($object->cargaHorariaDiurna);
				$this->setCargaHorariaNoturnaAttribute($object->cargaHorariaNoturna);
				$this->setCargaHorariaTotalAttribute($object->cargaHorariaTotal);
				$this->setEntrada01Attribute($object->entrada01);
				$this->setSaida01Attribute($object->saida01);
				$this->setEntrada02Attribute($object->entrada02);
				$this->setSaida02Attribute($object->saida02);
				$this->setEntrada03Attribute($object->entrada03);
				$this->setSaida03Attribute($object->saida03);
				$this->setEntrada04Attribute($object->entrada04);
				$this->setSaida04Attribute($object->saida04);
				$this->setEntrada05Attribute($object->entrada05);
				$this->setSaida05Attribute($object->saida05);
				$this->setHoraInicioJornadaAttribute($object->horaInicioJornada);
				$this->setHoraFimJornadaAttribute($object->horaFimJornada);
				$this->setHoraExtra01Attribute($object->horaExtra01);
				$this->setPercentualHoraExtra01Attribute($object->percentualHoraExtra01);
				$this->setModalidadeHoraExtra01Attribute($object->modalidadeHoraExtra01);
				$this->setHoraExtra02Attribute($object->horaExtra02);
				$this->setPercentualHoraExtra02Attribute($object->percentualHoraExtra02);
				$this->setModalidadeHoraExtra02Attribute($object->modalidadeHoraExtra02);
				$this->setHoraExtra03Attribute($object->horaExtra03);
				$this->setPercentualHoraExtra03Attribute($object->percentualHoraExtra03);
				$this->setModalidadeHoraExtra03Attribute($object->modalidadeHoraExtra03);
				$this->setHoraExtra04Attribute($object->horaExtra04);
				$this->setPercentualHoraExtra04Attribute($object->percentualHoraExtra04);
				$this->setModalidadeHoraExtra04Attribute($object->modalidadeHoraExtra04);
				$this->setFaltaAtrasoAttribute($object->faltaAtraso);
				$this->setCompensarAttribute($object->compensar);
				$this->setBancoHorasAttribute($object->bancoHoras);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$pontoClassificacaoJornadaModel = new PontoClassificacaoJornadaModel();
				$pontoClassificacaoJornadaModel->mapping($object->pontoClassificacaoJornadaModel);
				$this->pontoClassificacaoJornadaModel()->associate($pontoClassificacaoJornadaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataFechamento' => $this->getDataFechamentoAttribute(),
				'diaSemana' => $this->getDiaSemanaAttribute(),
				'codigoHorario' => $this->getCodigoHorarioAttribute(),
				'cargaHorariaEsperada' => $this->getCargaHorariaEsperadaAttribute(),
				'cargaHorariaDiurna' => $this->getCargaHorariaDiurnaAttribute(),
				'cargaHorariaNoturna' => $this->getCargaHorariaNoturnaAttribute(),
				'cargaHorariaTotal' => $this->getCargaHorariaTotalAttribute(),
				'entrada01' => $this->getEntrada01Attribute(),
				'saida01' => $this->getSaida01Attribute(),
				'entrada02' => $this->getEntrada02Attribute(),
				'saida02' => $this->getSaida02Attribute(),
				'entrada03' => $this->getEntrada03Attribute(),
				'saida03' => $this->getSaida03Attribute(),
				'entrada04' => $this->getEntrada04Attribute(),
				'saida04' => $this->getSaida04Attribute(),
				'entrada05' => $this->getEntrada05Attribute(),
				'saida05' => $this->getSaida05Attribute(),
				'horaInicioJornada' => $this->getHoraInicioJornadaAttribute(),
				'horaFimJornada' => $this->getHoraFimJornadaAttribute(),
				'horaExtra01' => $this->getHoraExtra01Attribute(),
				'percentualHoraExtra01' => $this->getPercentualHoraExtra01Attribute(),
				'modalidadeHoraExtra01' => $this->getModalidadeHoraExtra01Attribute(),
				'horaExtra02' => $this->getHoraExtra02Attribute(),
				'percentualHoraExtra02' => $this->getPercentualHoraExtra02Attribute(),
				'modalidadeHoraExtra02' => $this->getModalidadeHoraExtra02Attribute(),
				'horaExtra03' => $this->getHoraExtra03Attribute(),
				'percentualHoraExtra03' => $this->getPercentualHoraExtra03Attribute(),
				'modalidadeHoraExtra03' => $this->getModalidadeHoraExtra03Attribute(),
				'horaExtra04' => $this->getHoraExtra04Attribute(),
				'percentualHoraExtra04' => $this->getPercentualHoraExtra04Attribute(),
				'modalidadeHoraExtra04' => $this->getModalidadeHoraExtra04Attribute(),
				'faltaAtraso' => $this->getFaltaAtrasoAttribute(),
				'compensar' => $this->getCompensarAttribute(),
				'bancoHoras' => $this->getBancoHorasAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'pontoClassificacaoJornadaModel' => $this->pontoClassificacaoJornadaModel,
			];
	}
}