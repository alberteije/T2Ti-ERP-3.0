<?php
declare(strict_types=1);

class PontoAbonoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_abono';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pontoAbonoUtilizacaoModelList',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function pontoAbonoUtilizacaoModelList()
{
	return $this->hasMany(PontoAbonoUtilizacaoModel::class, 'id_ponto_abono', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getUtilizadoAttribute()
	{
		return $this->attributes['utilizado'];
	}

	public function setUtilizadoAttribute($utilizado)
	{
		$this->attributes['utilizado'] = $utilizado;
	}

	public function getSaldoAttribute()
	{
		return $this->attributes['saldo'];
	}

	public function setSaldoAttribute($saldo)
	{
		$this->attributes['saldo'] = $saldo;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getInicioUtilizacaoAttribute()
	{
		return $this->attributes['inicio_utilizacao'];
	}

	public function setInicioUtilizacaoAttribute($inicioUtilizacao)
	{
		$this->attributes['inicio_utilizacao'] = $inicioUtilizacao;
	}

	public function getDataValidadeAttribute()
	{
		return $this->attributes['data_validade'];
	}

	public function setDataValidadeAttribute($dataValidade)
	{
		$this->attributes['data_validade'] = $dataValidade;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);
				$this->setUtilizadoAttribute($object->utilizado);
				$this->setSaldoAttribute($object->saldo);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setInicioUtilizacaoAttribute($object->inicioUtilizacao);
				$this->setDataValidadeAttribute($object->dataValidade);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'utilizado' => $this->getUtilizadoAttribute(),
				'saldo' => $this->getSaldoAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'inicioUtilizacao' => $this->getInicioUtilizacaoAttribute(),
				'dataValidade' => $this->getDataValidadeAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'pontoAbonoUtilizacaoModelList' => $this->pontoAbonoUtilizacaoModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}