<?php
declare(strict_types=1);

class PontoRelogioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_relogio';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getLocalizacaoAttribute()
	{
		return $this->attributes['localizacao'];
	}

	public function setLocalizacaoAttribute($localizacao)
	{
		$this->attributes['localizacao'] = $localizacao;
	}

	public function getMarcaAttribute()
	{
		return $this->attributes['marca'];
	}

	public function setMarcaAttribute($marca)
	{
		$this->attributes['marca'] = $marca;
	}

	public function getFabricanteAttribute()
	{
		return $this->attributes['fabricante'];
	}

	public function setFabricanteAttribute($fabricante)
	{
		$this->attributes['fabricante'] = $fabricante;
	}

	public function getNumeroSerieAttribute()
	{
		return $this->attributes['numero_serie'];
	}

	public function setNumeroSerieAttribute($numeroSerie)
	{
		$this->attributes['numero_serie'] = $numeroSerie;
	}

	public function getUtilizacaoAttribute()
	{
		return $this->attributes['utilizacao'];
	}

	public function setUtilizacaoAttribute($utilizacao)
	{
		$this->attributes['utilizacao'] = $utilizacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setLocalizacaoAttribute($object->localizacao);
				$this->setMarcaAttribute($object->marca);
				$this->setFabricanteAttribute($object->fabricante);
				$this->setNumeroSerieAttribute($object->numeroSerie);
				$this->setUtilizacaoAttribute($object->utilizacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'localizacao' => $this->getLocalizacaoAttribute(),
				'marca' => $this->getMarcaAttribute(),
				'fabricante' => $this->getFabricanteAttribute(),
				'numeroSerie' => $this->getNumeroSerieAttribute(),
				'utilizacao' => $this->getUtilizacaoAttribute(),
			];
	}
}