<?php
declare(strict_types=1);

class PontoParametroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_parametro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getMesAnoAttribute()
	{
		return $this->attributes['mes_ano'];
	}

	public function setMesAnoAttribute($mesAno)
	{
		$this->attributes['mes_ano'] = $mesAno;
	}

	public function getDiaInicialApuracaoAttribute()
	{
		return $this->attributes['dia_inicial_apuracao'];
	}

	public function setDiaInicialApuracaoAttribute($diaInicialApuracao)
	{
		$this->attributes['dia_inicial_apuracao'] = $diaInicialApuracao;
	}

	public function getHoraNoturnaInicioAttribute()
	{
		return $this->attributes['hora_noturna_inicio'];
	}

	public function setHoraNoturnaInicioAttribute($horaNoturnaInicio)
	{
		$this->attributes['hora_noturna_inicio'] = $horaNoturnaInicio;
	}

	public function getHoraNoturnaFimAttribute()
	{
		return $this->attributes['hora_noturna_fim'];
	}

	public function setHoraNoturnaFimAttribute($horaNoturnaFim)
	{
		$this->attributes['hora_noturna_fim'] = $horaNoturnaFim;
	}

	public function getPeriodoMinimoInterjornadaAttribute()
	{
		return $this->attributes['periodo_minimo_interjornada'];
	}

	public function setPeriodoMinimoInterjornadaAttribute($periodoMinimoInterjornada)
	{
		$this->attributes['periodo_minimo_interjornada'] = $periodoMinimoInterjornada;
	}

	public function getPercentualHeDiurnaAttribute()
	{
		return (double)$this->attributes['percentual_he_diurna'];
	}

	public function setPercentualHeDiurnaAttribute($percentualHeDiurna)
	{
		$this->attributes['percentual_he_diurna'] = $percentualHeDiurna;
	}

	public function getPercentualHeNoturnaAttribute()
	{
		return (double)$this->attributes['percentual_he_noturna'];
	}

	public function setPercentualHeNoturnaAttribute($percentualHeNoturna)
	{
		$this->attributes['percentual_he_noturna'] = $percentualHeNoturna;
	}

	public function getDuracaoHoraNoturnaAttribute()
	{
		return $this->attributes['duracao_hora_noturna'];
	}

	public function setDuracaoHoraNoturnaAttribute($duracaoHoraNoturna)
	{
		$this->attributes['duracao_hora_noturna'] = $duracaoHoraNoturna;
	}

	public function getTratamentoHoraMaisAttribute()
	{
		return $this->attributes['tratamento_hora_mais'];
	}

	public function setTratamentoHoraMaisAttribute($tratamentoHoraMais)
	{
		$this->attributes['tratamento_hora_mais'] = $tratamentoHoraMais;
	}

	public function getTratamentoHoraMenosAttribute()
	{
		return $this->attributes['tratamento_hora_menos'];
	}

	public function setTratamentoHoraMenosAttribute($tratamentoHoraMenos)
	{
		$this->attributes['tratamento_hora_menos'] = $tratamentoHoraMenos;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setMesAnoAttribute($object->mesAno);
				$this->setDiaInicialApuracaoAttribute($object->diaInicialApuracao);
				$this->setHoraNoturnaInicioAttribute($object->horaNoturnaInicio);
				$this->setHoraNoturnaFimAttribute($object->horaNoturnaFim);
				$this->setPeriodoMinimoInterjornadaAttribute($object->periodoMinimoInterjornada);
				$this->setPercentualHeDiurnaAttribute($object->percentualHeDiurna);
				$this->setPercentualHeNoturnaAttribute($object->percentualHeNoturna);
				$this->setDuracaoHoraNoturnaAttribute($object->duracaoHoraNoturna);
				$this->setTratamentoHoraMaisAttribute($object->tratamentoHoraMais);
				$this->setTratamentoHoraMenosAttribute($object->tratamentoHoraMenos);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'mesAno' => $this->getMesAnoAttribute(),
				'diaInicialApuracao' => $this->getDiaInicialApuracaoAttribute(),
				'horaNoturnaInicio' => $this->getHoraNoturnaInicioAttribute(),
				'horaNoturnaFim' => $this->getHoraNoturnaFimAttribute(),
				'periodoMinimoInterjornada' => $this->getPeriodoMinimoInterjornadaAttribute(),
				'percentualHeDiurna' => $this->getPercentualHeDiurnaAttribute(),
				'percentualHeNoturna' => $this->getPercentualHeNoturnaAttribute(),
				'duracaoHoraNoturna' => $this->getDuracaoHoraNoturnaAttribute(),
				'tratamentoHoraMais' => $this->getTratamentoHoraMaisAttribute(),
				'tratamentoHoraMenos' => $this->getTratamentoHoraMenosAttribute(),
			];
	}
}