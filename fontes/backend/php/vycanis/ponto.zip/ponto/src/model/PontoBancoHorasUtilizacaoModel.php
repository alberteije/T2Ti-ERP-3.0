<?php
declare(strict_types=1);

class PontoBancoHorasUtilizacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_banco_horas_utilizacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function pontoBancoHorasModel()
	{
		return $this->belongsTo(PontoBancoHorasModel::class, 'id_ponto_banco_horas', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataUtilizacaoAttribute()
	{
		return $this->attributes['data_utilizacao'];
	}

	public function setDataUtilizacaoAttribute($dataUtilizacao)
	{
		$this->attributes['data_utilizacao'] = $dataUtilizacao;
	}

	public function getQuantidadeUtilizadaAttribute()
	{
		return $this->attributes['quantidade_utilizada'];
	}

	public function setQuantidadeUtilizadaAttribute($quantidadeUtilizada)
	{
		$this->attributes['quantidade_utilizada'] = $quantidadeUtilizada;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataUtilizacaoAttribute($object->dataUtilizacao);
				$this->setQuantidadeUtilizadaAttribute($object->quantidadeUtilizada);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataUtilizacao' => $this->getDataUtilizacaoAttribute(),
				'quantidadeUtilizada' => $this->getQuantidadeUtilizadaAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}