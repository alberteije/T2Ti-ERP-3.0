<?php
declare(strict_types=1);

class PontoAbonoUtilizacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_abono_utilizacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function pontoAbonoModel()
	{
		return $this->belongsTo(PontoAbonoModel::class, 'id_ponto_abono', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataUtilizacaoAttribute()
	{
		return $this->attributes['data_utilizacao'];
	}

	public function setDataUtilizacaoAttribute($dataUtilizacao)
	{
		$this->attributes['data_utilizacao'] = $dataUtilizacao;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataUtilizacaoAttribute($object->dataUtilizacao);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataUtilizacao' => $this->getDataUtilizacaoAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}