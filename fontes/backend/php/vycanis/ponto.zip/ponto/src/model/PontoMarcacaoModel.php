<?php
declare(strict_types=1);

class PontoMarcacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ponto_marcacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
		'pontoRelogioModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function pontoRelogioModel()
	{
		return $this->belongsTo(PontoRelogioModel::class, 'id_ponto_relogio', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNsrAttribute()
	{
		return $this->attributes['nsr'];
	}

	public function setNsrAttribute($nsr)
	{
		$this->attributes['nsr'] = $nsr;
	}

	public function getDataMarcacaoAttribute()
	{
		return $this->attributes['data_marcacao'];
	}

	public function setDataMarcacaoAttribute($dataMarcacao)
	{
		$this->attributes['data_marcacao'] = $dataMarcacao;
	}

	public function getHoraMarcacaoAttribute()
	{
		return $this->attributes['hora_marcacao'];
	}

	public function setHoraMarcacaoAttribute($horaMarcacao)
	{
		$this->attributes['hora_marcacao'] = $horaMarcacao;
	}

	public function getTipoMarcacaoAttribute()
	{
		return $this->attributes['tipo_marcacao'];
	}

	public function setTipoMarcacaoAttribute($tipoMarcacao)
	{
		$this->attributes['tipo_marcacao'] = $tipoMarcacao;
	}

	public function getTipoRegistroAttribute()
	{
		return $this->attributes['tipo_registro'];
	}

	public function setTipoRegistroAttribute($tipoRegistro)
	{
		$this->attributes['tipo_registro'] = $tipoRegistro;
	}

	public function getParEntradaSaidaAttribute()
	{
		return $this->attributes['par_entrada_saida'];
	}

	public function setParEntradaSaidaAttribute($parEntradaSaida)
	{
		$this->attributes['par_entrada_saida'] = $parEntradaSaida;
	}

	public function getJustificativaAttribute()
	{
		return $this->attributes['justificativa'];
	}

	public function setJustificativaAttribute($justificativa)
	{
		$this->attributes['justificativa'] = $justificativa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNsrAttribute($object->nsr);
				$this->setDataMarcacaoAttribute($object->dataMarcacao);
				$this->setHoraMarcacaoAttribute($object->horaMarcacao);
				$this->setTipoMarcacaoAttribute($object->tipoMarcacao);
				$this->setTipoRegistroAttribute($object->tipoRegistro);
				$this->setParEntradaSaidaAttribute($object->parEntradaSaida);
				$this->setJustificativaAttribute($object->justificativa);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$pontoRelogioModel = new PontoRelogioModel();
				$pontoRelogioModel->mapping($object->pontoRelogioModel);
				$this->pontoRelogioModel()->associate($pontoRelogioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nsr' => $this->getNsrAttribute(),
				'dataMarcacao' => $this->getDataMarcacaoAttribute(),
				'horaMarcacao' => $this->getHoraMarcacaoAttribute(),
				'tipoMarcacao' => $this->getTipoMarcacaoAttribute(),
				'tipoRegistro' => $this->getTipoRegistroAttribute(),
				'parEntradaSaida' => $this->getParEntradaSaidaAttribute(),
				'justificativa' => $this->getJustificativaAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'pontoRelogioModel' => $this->pontoRelogioModel,
			];
	}
}