<?php
class PontoMarcacaoController extends ControllerBase
{

		private $pontoMarcacaoService = null;

		public function __construct()
		{	 
				$this->pontoMarcacaoService = new PontoMarcacaoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->pontoMarcacaoService->getListFilter($filter);
						} else {
								$resultList = $this->pontoMarcacaoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList PontoMarcacao]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->pontoMarcacaoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject PontoMarcacao]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject PontoMarcacao]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert PontoMarcacao]', null);
						}

						$objModel = new PontoMarcacaoModel();
						$objModel->mapping($objJson);

						$this->pontoMarcacaoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert PontoMarcacao]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->pontoMarcacaoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update PontoMarcacao]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->pontoMarcacaoService->save($objFromDatabase);
								$objFromDatabase = $this->pontoMarcacaoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update PontoMarcacao]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->pontoMarcacaoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete PontoMarcacao]', null);
						} else {
								$this->pontoMarcacaoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete PontoMarcacao]', $e);
				}
		}

	public function insertBatch($request, $response, $args)
	{
		try {
			$data = json_decode($request->getBody(), true);

			if (!isset($data)) {
				return parent::handleError($response, 400, 'Invalid Data [insertBatch PontoMarcacao]', null);
			}

			if (!isset($data['marcacoes'])) {
				return parent::handleError($response, 400, 'Invalid Data Structure [insertBatch PontoMarcacao]', null);
			}

			$marcacoesData = $data['marcacoes'];

			// Prepara os dados no formato do banco usando o Model
			$dadosParaInserir = array_map(function ($lancamentoData) {
				return PontoMarcacaoModel::toDatabaseFormat((object)$lancamentoData);
			}, $marcacoesData);

			// Insere os novos registros
			$result = $this->pontoMarcacaoService->saveBatch($dadosParaInserir);

			$response->getBody()->write(json_encode([
				'success' => true,
				'count' => count($dadosParaInserir),
			]));

			return $response
				->withStatus(201)
				->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [insertBatch PontoMarcacao]', $e);
		}
	}

}
