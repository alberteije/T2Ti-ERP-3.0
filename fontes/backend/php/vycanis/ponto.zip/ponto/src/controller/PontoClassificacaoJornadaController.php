<?php
class PontoClassificacaoJornadaController extends ControllerBase
{

		private $pontoClassificacaoJornadaService = null;

		public function __construct()
		{	 
				$this->pontoClassificacaoJornadaService = new PontoClassificacaoJornadaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->pontoClassificacaoJornadaService->getListFilter($filter);
						} else {
								$resultList = $this->pontoClassificacaoJornadaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList PontoClassificacaoJornada]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->pontoClassificacaoJornadaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject PontoClassificacaoJornada]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject PontoClassificacaoJornada]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert PontoClassificacaoJornada]', null);
						}

						$objModel = new PontoClassificacaoJornadaModel();
						$objModel->mapping($objJson);

						$this->pontoClassificacaoJornadaService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert PontoClassificacaoJornada]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->pontoClassificacaoJornadaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update PontoClassificacaoJornada]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->pontoClassificacaoJornadaService->save($objFromDatabase);
								$objFromDatabase = $this->pontoClassificacaoJornadaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update PontoClassificacaoJornada]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->pontoClassificacaoJornadaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete PontoClassificacaoJornada]', null);
						} else {
								$this->pontoClassificacaoJornadaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete PontoClassificacaoJornada]', $e);
				}
		}
}
