<?php
use Illuminate\Database\Capsule\Manager as DB;
class OsStatusService extends ServiceBase
{
	public function getList()
	{
		return OsStatusModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return OsStatusModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return OsStatusModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// osAbertura
		$osAberturaModelListJson = $objJson->osAberturaModelList;
		if ($osAberturaModelListJson != null) {
			for ($i = 0; $i < count($osAberturaModelListJson); $i++) {
				$osAbertura = new OsAberturaModel();
				$osAbertura->mapping($osAberturaModelListJson[$i]);
				$objModel->osAberturaModelList()->save($osAbertura);
			}
		}

	}	

	public function deleteChildren($object)
	{
		OsAberturaModel::where('id_os_status', $object->getIdAttribute())->delete();
	}	
 
}