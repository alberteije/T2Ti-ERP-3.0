<?php
class NfseListaServicoService extends ServiceBase
{
  public function getList()
  {
    return NfseListaServicoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfseListaServicoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfseListaServicoModel::find($id);
  }

}