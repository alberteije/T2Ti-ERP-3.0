<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'OsAberturaModel.php';
include 'NfseDetalheModel.php';
include 'NfseIntermediarioModel.php';
include 'OsStatusModel.php';
include 'NfseCabecalhoModel.php';
include 'NfseListaServicoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaClienteModel.php';
include 'ViewPessoaColaboradorModel.php';