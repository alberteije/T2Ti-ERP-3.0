<?php
declare(strict_types=1);

class NfseCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfse_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfseDetalheModelList',
		'nfseIntermediarioModelList',
		'viewPessoaClienteModel',
		'osAberturaModel',
	];

	/**
		* Relations
		*/
	public function nfseDetalheModelList()
{
	return $this->hasMany(NfseDetalheModel::class, 'id_nfse_cabecalho', 'id');
}

	public function nfseIntermediarioModelList()
{
	return $this->hasMany(NfseIntermediarioModel::class, 'id_nfse_cabecalho', 'id');
}

	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}

	public function osAberturaModel()
	{
		return $this->belongsTo(OsAberturaModel::class, 'id_os_abertura', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getCodigoVerificacaoAttribute()
	{
		return $this->attributes['codigo_verificacao'];
	}

	public function setCodigoVerificacaoAttribute($codigoVerificacao)
	{
		$this->attributes['codigo_verificacao'] = $codigoVerificacao;
	}

	public function getDataHoraEmissaoAttribute()
	{
		return $this->attributes['data_hora_emissao'];
	}

	public function setDataHoraEmissaoAttribute($dataHoraEmissao)
	{
		$this->attributes['data_hora_emissao'] = $dataHoraEmissao;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getNumeroSubstituidaAttribute()
	{
		return $this->attributes['numero_substituida'];
	}

	public function setNumeroSubstituidaAttribute($numeroSubstituida)
	{
		$this->attributes['numero_substituida'] = $numeroSubstituida;
	}

	public function getNaturezaOperacaoAttribute()
	{
		return $this->attributes['natureza_operacao'];
	}

	public function setNaturezaOperacaoAttribute($naturezaOperacao)
	{
		$this->attributes['natureza_operacao'] = $naturezaOperacao;
	}

	public function getRegimeEspecialTributacaoAttribute()
	{
		return $this->attributes['regime_especial_tributacao'];
	}

	public function setRegimeEspecialTributacaoAttribute($regimeEspecialTributacao)
	{
		$this->attributes['regime_especial_tributacao'] = $regimeEspecialTributacao;
	}

	public function getOptanteSimplesNacionalAttribute()
	{
		return $this->attributes['optante_simples_nacional'];
	}

	public function setOptanteSimplesNacionalAttribute($optanteSimplesNacional)
	{
		$this->attributes['optante_simples_nacional'] = $optanteSimplesNacional;
	}

	public function getIncentivadorCulturalAttribute()
	{
		return $this->attributes['incentivador_cultural'];
	}

	public function setIncentivadorCulturalAttribute($incentivadorCultural)
	{
		$this->attributes['incentivador_cultural'] = $incentivadorCultural;
	}

	public function getNumeroRpsAttribute()
	{
		return $this->attributes['numero_rps'];
	}

	public function setNumeroRpsAttribute($numeroRps)
	{
		$this->attributes['numero_rps'] = $numeroRps;
	}

	public function getSerieRpsAttribute()
	{
		return $this->attributes['serie_rps'];
	}

	public function setSerieRpsAttribute($serieRps)
	{
		$this->attributes['serie_rps'] = $serieRps;
	}

	public function getTipoRpsAttribute()
	{
		return $this->attributes['tipo_rps'];
	}

	public function setTipoRpsAttribute($tipoRps)
	{
		$this->attributes['tipo_rps'] = $tipoRps;
	}

	public function getDataEmissaoRpsAttribute()
	{
		return $this->attributes['data_emissao_rps'];
	}

	public function setDataEmissaoRpsAttribute($dataEmissaoRps)
	{
		$this->attributes['data_emissao_rps'] = $dataEmissaoRps;
	}

	public function getOutrasInformacoesAttribute()
	{
		return $this->attributes['outras_informacoes'];
	}

	public function setOutrasInformacoesAttribute($outrasInformacoes)
	{
		$this->attributes['outras_informacoes'] = $outrasInformacoes;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setCodigoVerificacaoAttribute($object->codigoVerificacao);
				$this->setDataHoraEmissaoAttribute($object->dataHoraEmissao);
				$this->setCompetenciaAttribute($object->competencia);
				$this->setNumeroSubstituidaAttribute($object->numeroSubstituida);
				$this->setNaturezaOperacaoAttribute($object->naturezaOperacao);
				$this->setRegimeEspecialTributacaoAttribute($object->regimeEspecialTributacao);
				$this->setOptanteSimplesNacionalAttribute($object->optanteSimplesNacional);
				$this->setIncentivadorCulturalAttribute($object->incentivadorCultural);
				$this->setNumeroRpsAttribute($object->numeroRps);
				$this->setSerieRpsAttribute($object->serieRps);
				$this->setTipoRpsAttribute($object->tipoRps);
				$this->setDataEmissaoRpsAttribute($object->dataEmissaoRps);
				$this->setOutrasInformacoesAttribute($object->outrasInformacoes);

				// link objects - lookups
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
				$osAberturaModel = new OsAberturaModel();
				$osAberturaModel->mapping($object->osAberturaModel);
				$this->osAberturaModel()->associate($osAberturaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'codigoVerificacao' => $this->getCodigoVerificacaoAttribute(),
				'dataHoraEmissao' => $this->getDataHoraEmissaoAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'numeroSubstituida' => $this->getNumeroSubstituidaAttribute(),
				'naturezaOperacao' => $this->getNaturezaOperacaoAttribute(),
				'regimeEspecialTributacao' => $this->getRegimeEspecialTributacaoAttribute(),
				'optanteSimplesNacional' => $this->getOptanteSimplesNacionalAttribute(),
				'incentivadorCultural' => $this->getIncentivadorCulturalAttribute(),
				'numeroRps' => $this->getNumeroRpsAttribute(),
				'serieRps' => $this->getSerieRpsAttribute(),
				'tipoRps' => $this->getTipoRpsAttribute(),
				'dataEmissaoRps' => $this->getDataEmissaoRpsAttribute(),
				'outrasInformacoes' => $this->getOutrasInformacoesAttribute(),
				'nfseDetalheModelList' => $this->nfseDetalheModelList,
				'nfseIntermediarioModelList' => $this->nfseIntermediarioModelList,
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
				'osAberturaModel' => $this->osAberturaModel,
			];
	}
}