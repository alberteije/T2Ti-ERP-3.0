<?php
declare(strict_types=1);

class NfseDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfse_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfseListaServicoModel',
	];

	/**
		* Relations
		*/
	public function nfseCabecalhoModel()
	{
		return $this->belongsTo(NfseCabecalhoModel::class, 'id_nfse_cabecalho', 'id');
	}

	public function nfseListaServicoModel()
	{
		return $this->belongsTo(NfseListaServicoModel::class, 'id_nfse_lista_servico', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoCnaeAttribute()
	{
		return $this->attributes['codigo_cnae'];
	}

	public function setCodigoCnaeAttribute($codigoCnae)
	{
		$this->attributes['codigo_cnae'] = $codigoCnae;
	}

	public function getCodigoTributacaoMunicipioAttribute()
	{
		return $this->attributes['codigo_tributacao_municipio'];
	}

	public function setCodigoTributacaoMunicipioAttribute($codigoTributacaoMunicipio)
	{
		$this->attributes['codigo_tributacao_municipio'] = $codigoTributacaoMunicipio;
	}

	public function getValorServicosAttribute()
	{
		return (double)$this->attributes['valor_servicos'];
	}

	public function setValorServicosAttribute($valorServicos)
	{
		$this->attributes['valor_servicos'] = $valorServicos;
	}

	public function getValorDeducoesAttribute()
	{
		return (double)$this->attributes['valor_deducoes'];
	}

	public function setValorDeducoesAttribute($valorDeducoes)
	{
		$this->attributes['valor_deducoes'] = $valorDeducoes;
	}

	public function getValorPisAttribute()
	{
		return (double)$this->attributes['valor_pis'];
	}

	public function setValorPisAttribute($valorPis)
	{
		$this->attributes['valor_pis'] = $valorPis;
	}

	public function getValorCofinsAttribute()
	{
		return (double)$this->attributes['valor_cofins'];
	}

	public function setValorCofinsAttribute($valorCofins)
	{
		$this->attributes['valor_cofins'] = $valorCofins;
	}

	public function getValorInssAttribute()
	{
		return (double)$this->attributes['valor_inss'];
	}

	public function setValorInssAttribute($valorInss)
	{
		$this->attributes['valor_inss'] = $valorInss;
	}

	public function getValorIrAttribute()
	{
		return (double)$this->attributes['valor_ir'];
	}

	public function setValorIrAttribute($valorIr)
	{
		$this->attributes['valor_ir'] = $valorIr;
	}

	public function getValorCsllAttribute()
	{
		return (double)$this->attributes['valor_csll'];
	}

	public function setValorCsllAttribute($valorCsll)
	{
		$this->attributes['valor_csll'] = $valorCsll;
	}

	public function getValorBaseCalculoAttribute()
	{
		return (double)$this->attributes['valor_base_calculo'];
	}

	public function setValorBaseCalculoAttribute($valorBaseCalculo)
	{
		$this->attributes['valor_base_calculo'] = $valorBaseCalculo;
	}

	public function getAliquotaAttribute()
	{
		return (double)$this->attributes['aliquota'];
	}

	public function setAliquotaAttribute($aliquota)
	{
		$this->attributes['aliquota'] = $aliquota;
	}

	public function getValorIssAttribute()
	{
		return (double)$this->attributes['valor_iss'];
	}

	public function setValorIssAttribute($valorIss)
	{
		$this->attributes['valor_iss'] = $valorIss;
	}

	public function getValorLiquidoAttribute()
	{
		return (double)$this->attributes['valor_liquido'];
	}

	public function setValorLiquidoAttribute($valorLiquido)
	{
		$this->attributes['valor_liquido'] = $valorLiquido;
	}

	public function getOutrasRetencoesAttribute()
	{
		return (double)$this->attributes['outras_retencoes'];
	}

	public function setOutrasRetencoesAttribute($outrasRetencoes)
	{
		$this->attributes['outras_retencoes'] = $outrasRetencoes;
	}

	public function getValorCreditoAttribute()
	{
		return (double)$this->attributes['valor_credito'];
	}

	public function setValorCreditoAttribute($valorCredito)
	{
		$this->attributes['valor_credito'] = $valorCredito;
	}

	public function getIssRetidoAttribute()
	{
		return $this->attributes['iss_retido'];
	}

	public function setIssRetidoAttribute($issRetido)
	{
		$this->attributes['iss_retido'] = $issRetido;
	}

	public function getValorIssRetidoAttribute()
	{
		return (double)$this->attributes['valor_iss_retido'];
	}

	public function setValorIssRetidoAttribute($valorIssRetido)
	{
		$this->attributes['valor_iss_retido'] = $valorIssRetido;
	}

	public function getValorDescontoCondicionadoAttribute()
	{
		return (double)$this->attributes['valor_desconto_condicionado'];
	}

	public function setValorDescontoCondicionadoAttribute($valorDescontoCondicionado)
	{
		$this->attributes['valor_desconto_condicionado'] = $valorDescontoCondicionado;
	}

	public function getValorDescontoIncondicionadoAttribute()
	{
		return (double)$this->attributes['valor_desconto_incondicionado'];
	}

	public function setValorDescontoIncondicionadoAttribute($valorDescontoIncondicionado)
	{
		$this->attributes['valor_desconto_incondicionado'] = $valorDescontoIncondicionado;
	}

	public function getMunicipioPrestacaoAttribute()
	{
		return $this->attributes['municipio_prestacao'];
	}

	public function setMunicipioPrestacaoAttribute($municipioPrestacao)
	{
		$this->attributes['municipio_prestacao'] = $municipioPrestacao;
	}

	public function getDiscriminacaoAttribute()
	{
		return $this->attributes['discriminacao'];
	}

	public function setDiscriminacaoAttribute($discriminacao)
	{
		$this->attributes['discriminacao'] = $discriminacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoCnaeAttribute($object->codigoCnae);
				$this->setCodigoTributacaoMunicipioAttribute($object->codigoTributacaoMunicipio);
				$this->setValorServicosAttribute($object->valorServicos);
				$this->setValorDeducoesAttribute($object->valorDeducoes);
				$this->setValorPisAttribute($object->valorPis);
				$this->setValorCofinsAttribute($object->valorCofins);
				$this->setValorInssAttribute($object->valorInss);
				$this->setValorIrAttribute($object->valorIr);
				$this->setValorCsllAttribute($object->valorCsll);
				$this->setValorBaseCalculoAttribute($object->valorBaseCalculo);
				$this->setAliquotaAttribute($object->aliquota);
				$this->setValorIssAttribute($object->valorIss);
				$this->setValorLiquidoAttribute($object->valorLiquido);
				$this->setOutrasRetencoesAttribute($object->outrasRetencoes);
				$this->setValorCreditoAttribute($object->valorCredito);
				$this->setIssRetidoAttribute($object->issRetido);
				$this->setValorIssRetidoAttribute($object->valorIssRetido);
				$this->setValorDescontoCondicionadoAttribute($object->valorDescontoCondicionado);
				$this->setValorDescontoIncondicionadoAttribute($object->valorDescontoIncondicionado);
				$this->setMunicipioPrestacaoAttribute($object->municipioPrestacao);
				$this->setDiscriminacaoAttribute($object->discriminacao);

				// link objects - lookups
				$nfseListaServicoModel = new NfseListaServicoModel();
				$nfseListaServicoModel->mapping($object->nfseListaServicoModel);
				$this->nfseListaServicoModel()->associate($nfseListaServicoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoCnae' => $this->getCodigoCnaeAttribute(),
				'codigoTributacaoMunicipio' => $this->getCodigoTributacaoMunicipioAttribute(),
				'valorServicos' => $this->getValorServicosAttribute(),
				'valorDeducoes' => $this->getValorDeducoesAttribute(),
				'valorPis' => $this->getValorPisAttribute(),
				'valorCofins' => $this->getValorCofinsAttribute(),
				'valorInss' => $this->getValorInssAttribute(),
				'valorIr' => $this->getValorIrAttribute(),
				'valorCsll' => $this->getValorCsllAttribute(),
				'valorBaseCalculo' => $this->getValorBaseCalculoAttribute(),
				'aliquota' => $this->getAliquotaAttribute(),
				'valorIss' => $this->getValorIssAttribute(),
				'valorLiquido' => $this->getValorLiquidoAttribute(),
				'outrasRetencoes' => $this->getOutrasRetencoesAttribute(),
				'valorCredito' => $this->getValorCreditoAttribute(),
				'issRetido' => $this->getIssRetidoAttribute(),
				'valorIssRetido' => $this->getValorIssRetidoAttribute(),
				'valorDescontoCondicionado' => $this->getValorDescontoCondicionadoAttribute(),
				'valorDescontoIncondicionado' => $this->getValorDescontoIncondicionadoAttribute(),
				'municipioPrestacao' => $this->getMunicipioPrestacaoAttribute(),
				'discriminacao' => $this->getDiscriminacaoAttribute(),
				'nfseListaServicoModel' => $this->nfseListaServicoModel,
			];
	}
}