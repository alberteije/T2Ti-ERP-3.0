<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// os-status
$app->get('/os-status[/]', \OsStatusController::class . RESULT_LIST);
$app->get('/os-status/{id}', \OsStatusController::class . RESULT_OBJECT);
$app->post('/os-status', \OsStatusController::class . INSERT);
$app->put('/os-status', \OsStatusController::class . UPDATE);
$app->delete('/os-status/{id}', \OsStatusController::class . DELETE);
$app->options('/os-status', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/os-status/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/os-status/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// nfse-cabecalho
$app->get('/nfse-cabecalho[/]', \NfseCabecalhoController::class . RESULT_LIST);
$app->get('/nfse-cabecalho/{id}', \NfseCabecalhoController::class . RESULT_OBJECT);
$app->post('/nfse-cabecalho', \NfseCabecalhoController::class . INSERT);
$app->put('/nfse-cabecalho', \NfseCabecalhoController::class . UPDATE);
$app->delete('/nfse-cabecalho/{id}', \NfseCabecalhoController::class . DELETE);
$app->options('/nfse-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nfse-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nfse-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->post('/nfse-cabecalho/transmite-nfse[/]', \NfseCabecalhoController::class . ':transmitirNfse');

// nfse-lista-servico
$app->get('/nfse-lista-servico[/]', \NfseListaServicoController::class . RESULT_LIST);
$app->get('/nfse-lista-servico/{id}', \NfseListaServicoController::class . RESULT_OBJECT);
$app->post('/nfse-lista-servico', \NfseListaServicoController::class . INSERT);
$app->put('/nfse-lista-servico', \NfseListaServicoController::class . UPDATE);
$app->delete('/nfse-lista-servico/{id}', \NfseListaServicoController::class . DELETE);
$app->options('/nfse-lista-servico', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nfse-lista-servico/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nfse-lista-servico/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-cliente
$app->get('/view-pessoa-cliente[/]', \ViewPessoaClienteController::class . RESULT_LIST);
$app->get('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . RESULT_OBJECT);
$app->post('/view-pessoa-cliente', \ViewPessoaClienteController::class . INSERT);
$app->put('/view-pessoa-cliente', \ViewPessoaClienteController::class . UPDATE);
$app->delete('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . DELETE);
$app->options('/view-pessoa-cliente', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

