<?php
use Slim\Psr7\Stream;
class NfseCabecalhoController extends ControllerBase
{

		private $nfseCabecalhoService = null;

		public function __construct()
		{	 
				$this->nfseCabecalhoService = new NfseCabecalhoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->nfseCabecalhoService->getListFilter($filter);
						} else {
								$resultList = $this->nfseCabecalhoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList NfseCabecalho]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->nfseCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject NfseCabecalho]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject NfseCabecalho]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert NfseCabecalho]', null);
						}

						$objModel = new NfseCabecalhoModel();
						$objModel->mapping($objJson);

						$this->nfseCabecalhoService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert NfseCabecalho]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->nfseCabecalhoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update NfseCabecalho]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->nfseCabecalhoService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->nfseCabecalhoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update NfseCabecalho]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->nfseCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete NfseCabecalho]', null);
						} else {
								$this->nfseCabecalhoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete NfseCabecalho]', $e);
				}
		}
		
	public function transmitirNfse($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			$objFromDatabase = $this->nfseCabecalhoService->getObject($objJson->id);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [update NfseCabecalho]', null);
			}

			$retorno = $this->nfseCabecalhoService->transmitirNfse($objFromDatabase);
			// $retorno = "";

			if (!str_contains($retorno, "ERRO")) {
				// $fh = fopen($retorno, 'rb');
				$fh = fopen("C:\\T2Ti\\NFSe\\202008\\NFSe\\3120081079311800017856000000000000027-nfse.pdf", 'rb');
				$stream = new Stream($fh);
				return parent::resultFile($response, $stream, 'application/pdf');
			} else {
				return parent::handleError($response, 418, $retorno, null);
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Erro no Servidor [Transmitir NFS-e]', $e);
		}
	}
		
}
