<?php
declare(strict_types=1);

class NfseIntermediarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfse_intermediario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfseCabecalhoModel()
	{
		return $this->belongsTo(NfseCabecalhoModel::class, 'id_nfse_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getInscricaoMunicipalAttribute()
	{
		return $this->attributes['inscricao_municipal'];
	}

	public function setInscricaoMunicipalAttribute($inscricaoMunicipal)
	{
		$this->attributes['inscricao_municipal'] = $inscricaoMunicipal;
	}

	public function getRazaoAttribute()
	{
		return $this->attributes['razao'];
	}

	public function setRazaoAttribute($razao)
	{
		$this->attributes['razao'] = $razao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjAttribute($object->cnpj);
				$this->setInscricaoMunicipalAttribute($object->inscricaoMunicipal);
				$this->setRazaoAttribute($object->razao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'inscricaoMunicipal' => $this->getInscricaoMunicipalAttribute(),
				'razao' => $this->getRazaoAttribute(),
			];
	}
}