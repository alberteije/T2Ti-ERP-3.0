<?php
use Illuminate\Database\Capsule\Manager as DB;
class NfseCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return NfseCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return NfseCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return NfseCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// nfseDetalhe
		$nfseDetalheModelListJson = $objJson->nfseDetalheModelList;
		if ($nfseDetalheModelListJson != null) {
			for ($i = 0; $i < count($nfseDetalheModelListJson); $i++) {
				$nfseDetalhe = new NfseDetalheModel();
				$nfseDetalhe->mapping($nfseDetalheModelListJson[$i]);
				$objModel->nfseDetalheModelList()->save($nfseDetalhe);
			}
		}

		// nfseIntermediario
		$nfseIntermediarioModelListJson = $objJson->nfseIntermediarioModelList;
		if ($nfseIntermediarioModelListJson != null) {
			for ($i = 0; $i < count($nfseIntermediarioModelListJson); $i++) {
				$nfseIntermediario = new NfseIntermediarioModel();
				$nfseIntermediario->mapping($nfseIntermediarioModelListJson[$i]);
				$objModel->nfseIntermediarioModelList()->save($nfseIntermediario);
			}
		}

	}	

	public function deleteChildren($object)
	{
		NfseDetalheModel::where('id_nfse_cabecalho', $object->getIdAttribute())->delete();
		NfseIntermediarioModel::where('id_nfse_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}