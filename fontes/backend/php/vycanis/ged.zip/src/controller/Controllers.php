<?php

include 'ControllerBase.php';
include 'LoginController.php';

include 'GedDocumentoCabecalhoController.php';
include 'GedTipoDocumentoController.php';
include 'GedVersaoDocumentoController.php';