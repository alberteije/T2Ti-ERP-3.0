<?php
declare(strict_types=1);

class Util 
{

	public static function camelCase($string)
	{
		$stringRetorno = ucwords(strtolower($string), "_");
		$stringRetorno = str_replace("_", "", $stringRetorno);
		$stringRetorno = lcfirst($stringRetorno);
		return $stringRetorno;
	}	

	public static function sortArray(&$array, $field, $order = 'ASC') {
		usort(
			$array,
			function($a, $b) use ($order, $field) {
			if($a->$field == $b->$field) return 0;
				return (($a->$field < $b->$field) ? ($order == 'ASC' ? -1 : 1) : ($order == 'ASC' ? 1 : -1));
			}
		);				
	}

}