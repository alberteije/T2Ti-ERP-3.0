<?php

include 'ServiceBase.php';

include 'GedDocumentoCabecalhoService.php';
include 'GedTipoDocumentoService.php';
include 'GedVersaoDocumentoService.php';