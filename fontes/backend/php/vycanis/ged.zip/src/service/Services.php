<?php

include 'ServiceBase.php';

include 'GedDocumentoCabecalhoService.php';
include 'GedTipoDocumentoService.php';
include 'GedVersaoDocumentoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';
include 'ViewPessoaVendedorService.php';
include 'ViewPessoaTransportadoraService.php';