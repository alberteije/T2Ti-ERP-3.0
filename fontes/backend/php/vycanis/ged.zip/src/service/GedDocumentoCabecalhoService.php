<?php
use Illuminate\Database\Capsule\Manager as DB;
class GedDocumentoCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return GedDocumentoCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return GedDocumentoCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return GedDocumentoCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// gedDocumentoDetalhe
		$gedDocumentoDetalheModelListJson = $objJson->gedDocumentoDetalheModelList;
		if ($gedDocumentoDetalheModelListJson != null) {
			for ($i = 0; $i < count($gedDocumentoDetalheModelListJson); $i++) {
				$gedDocumentoDetalhe = new GedDocumentoDetalheModel();
				$gedDocumentoDetalhe->mapping($gedDocumentoDetalheModelListJson[$i]);
				$objModel->gedDocumentoDetalheModelList()->save($gedDocumentoDetalhe);

				// gedVersaoDocumento
				$gedVersaoDocumentoModelListJson = $gedDocumentoDetalheModelListJson[$i]->gedVersaoDocumentoModelList;
				if ($gedVersaoDocumentoModelListJson != null) {
					for ($j = 0; $j < count($gedVersaoDocumentoModelListJson); $j++) {
						$gedVersaoDocumento = new GedVersaoDocumentoModel();
						$gedVersaoDocumento->mapping($gedVersaoDocumentoModelListJson[$j]);
						$gedVersaoDocumento->setCaminhoAttribute("caminho do arquivo"); // TODO: salve o arquivo no disco e grave o caminho aqui
						$gedDocumentoDetalhe->gedVersaoDocumentoModelList()->save($gedVersaoDocumento);
					}
				}
			}
		}

	}

	public function deleteChildren($object)
	{
		$detalhes = GedDocumentoDetalheModel::where('id_ged_documento_cabecalho', $object->getIdAttribute())->get();
		foreach ($detalhes as $detalhe) {
			$idDetalhe = $detalhe->id;
			GedVersaoDocumentoModel::where('id_ged_documento_detalhe', $idDetalhe)->delete();
			$detalhe->delete();
		}
	}

}