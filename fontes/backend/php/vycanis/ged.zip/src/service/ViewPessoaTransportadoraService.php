<?php
class ViewPessoaTransportadoraService extends ServiceBase
{
  public function getList()
  {
    return ViewPessoaTransportadoraModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewPessoaTransportadoraModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewPessoaTransportadoraModel::find($id);
  }

}