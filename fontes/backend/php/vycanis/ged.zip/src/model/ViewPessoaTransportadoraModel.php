<?php
declare(strict_types=1);

class ViewPessoaTransportadoraModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'view_pessoa_transportadora';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getSiteAttribute()
	{
		return $this->attributes['site'];
	}

	public function setSiteAttribute($site)
	{
		$this->attributes['site'] = $site;
	}

	public function getCpfCnpjAttribute()
	{
		return $this->attributes['cpf_cnpj'];
	}

	public function setCpfCnpjAttribute($cpfCnpj)
	{
		$this->attributes['cpf_cnpj'] = $cpfCnpj;
	}

	public function getRgIeAttribute()
	{
		return $this->attributes['rg_ie'];
	}

	public function setRgIeAttribute($rgIe)
	{
		$this->attributes['rg_ie'] = $rgIe;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	public function getIdPessoaAttribute()
	{
		return $this->attributes['id_pessoa'];
	}

	public function setIdPessoaAttribute($idPessoa)
	{
		$this->attributes['id_pessoa'] = $idPessoa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setTipoAttribute($object->tipo);
				$this->setEmailAttribute($object->email);
				$this->setSiteAttribute($object->site);
				$this->setCpfCnpjAttribute($object->cpfCnpj);
				$this->setRgIeAttribute($object->rgIe);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setObservacaoAttribute($object->observacao);
				$this->setIdPessoaAttribute($object->idPessoa);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'email' => $this->getEmailAttribute(),
				'site' => $this->getSiteAttribute(),
				'cpfCnpj' => $this->getCpfCnpjAttribute(),
				'rgIe' => $this->getRgIeAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'idPessoa' => $this->getIdPessoaAttribute(),
			];
	}
}