<?php
declare(strict_types=1);

class GedVersaoDocumentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ged_versao_documento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'gedDocumentoDetalheModel',
	];

	/**
		* Relations
		*/
	public function gedDocumentoDetalheModel()
	{
		return $this->belongsTo(GedDocumentoDetalheModel::class, 'id_ged_documento_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdColaboradorAttribute()
	{
		return $this->attributes['id_colaborador'];
	}

	public function setIdColaboradorAttribute($idColaborador)
	{
		$this->attributes['id_colaborador'] = $idColaborador;
	}

	public function getVersaoAttribute()
	{
		return $this->attributes['versao'];
	}

	public function setVersaoAttribute($versao)
	{
		$this->attributes['versao'] = $versao;
	}

	public function getDataVersaoAttribute()
	{
		return $this->attributes['data_versao'];
	}

	public function setDataVersaoAttribute($dataVersao)
	{
		$this->attributes['data_versao'] = $dataVersao;
	}

	public function getHoraVersaoAttribute()
	{
		return $this->attributes['hora_versao'];
	}

	public function setHoraVersaoAttribute($horaVersao)
	{
		$this->attributes['hora_versao'] = $horaVersao;
	}

	public function getHashArquivoAttribute()
	{
		return $this->attributes['hash_arquivo'];
	}

	public function setHashArquivoAttribute($hashArquivo)
	{
		$this->attributes['hash_arquivo'] = $hashArquivo;
	}

	public function getCaminhoAttribute()
	{
		return $this->attributes['caminho'];
	}

	public function setCaminhoAttribute($caminho)
	{
		$this->attributes['caminho'] = $caminho;
	}

	public function getAcaoAttribute()
	{
		return $this->attributes['acao'];
	}

	public function setAcaoAttribute($acao)
	{
		$this->attributes['acao'] = $acao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdColaboradorAttribute($object->idColaborador);
				$this->setVersaoAttribute($object->versao);
				$this->setDataVersaoAttribute($object->dataVersao);
				$this->setHoraVersaoAttribute($object->horaVersao);
				$this->setHashArquivoAttribute($object->hashArquivo);
				$this->setCaminhoAttribute($object->caminho);
				$this->setAcaoAttribute($object->acao);

				// link objects - lookups
				$gedDocumentoDetalheModel = new GedDocumentoDetalheModel();
				$gedDocumentoDetalheModel->mapping($object->gedDocumentoDetalheModel);
				$this->gedDocumentoDetalheModel()->associate($gedDocumentoDetalheModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idColaborador' => $this->getIdColaboradorAttribute(),
				'versao' => $this->getVersaoAttribute(),
				'dataVersao' => $this->getDataVersaoAttribute(),
				'horaVersao' => $this->getHoraVersaoAttribute(),
				'hashArquivo' => $this->getHashArquivoAttribute(),
				'caminho' => $this->getCaminhoAttribute(),
				'acao' => $this->getAcaoAttribute(),
				'gedDocumentoDetalheModel' => $this->gedDocumentoDetalheModel,
			];
	}
}