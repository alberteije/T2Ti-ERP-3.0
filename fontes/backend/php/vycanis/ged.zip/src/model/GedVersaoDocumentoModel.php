<?php
declare(strict_types=1);

class GedVersaoDocumentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ged_versao_documento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'gedDocumentoDetalheModel',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function gedDocumentoDetalheModel()
	{
		return $this->belongsTo(GedDocumentoDetalheModel::class, 'id_ged_documento_detalhe', 'id');
	}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getAcaoAttribute()
	{
		return $this->attributes['acao'];
	}

	public function setAcaoAttribute($acao)
	{
		$this->attributes['acao'] = $acao;
	}

	public function getVersaoAttribute()
	{
		return $this->attributes['versao'];
	}

	public function setVersaoAttribute($versao)
	{
		$this->attributes['versao'] = $versao;
	}

	public function getDataVersaoAttribute()
	{
		return $this->attributes['data_versao'];
	}

	public function setDataVersaoAttribute($dataVersao)
	{
		$this->attributes['data_versao'] = $dataVersao;
	}

	public function getHoraVersaoAttribute()
	{
		return $this->attributes['hora_versao'];
	}

	public function setHoraVersaoAttribute($horaVersao)
	{
		$this->attributes['hora_versao'] = $horaVersao;
	}

	public function getHashArquivoAttribute()
	{
		return $this->attributes['hash_arquivo'];
	}

	public function setHashArquivoAttribute($hashArquivo)
	{
		$this->attributes['hash_arquivo'] = $hashArquivo;
	}

	public function getCaminhoAttribute()
	{
		return $this->attributes['caminho'];
	}

	public function setCaminhoAttribute($caminho)
	{
		$this->attributes['caminho'] = $caminho;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setAcaoAttribute($object->acao);
				$this->setVersaoAttribute($object->versao);
				$this->setDataVersaoAttribute($object->dataVersao);
				$this->setHoraVersaoAttribute($object->horaVersao);
				$this->setHashArquivoAttribute($object->hashArquivo);
				$this->setCaminhoAttribute($object->caminho);

				// link objects - lookups
				$gedDocumentoDetalheModel = new GedDocumentoDetalheModel();
				$gedDocumentoDetalheModel->mapping($object->gedDocumentoDetalheModel);
				$this->gedDocumentoDetalheModel()->associate($gedDocumentoDetalheModel);
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'acao' => $this->getAcaoAttribute(),
				'versao' => $this->getVersaoAttribute(),
				'dataVersao' => $this->getDataVersaoAttribute(),
				'horaVersao' => $this->getHoraVersaoAttribute(),
				'hashArquivo' => $this->getHashArquivoAttribute(),
				'caminho' => $this->getCaminhoAttribute(),
				'gedDocumentoDetalheModel' => $this->gedDocumentoDetalheModel,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}