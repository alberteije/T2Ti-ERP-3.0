<?php
declare(strict_types=1);

class GedDocumentoDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ged_documento_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'gedTipoDocumentoModel',
	];

	/**
		* Relations
		*/
	public function gedDocumentoCabecalhoModel()
	{
		return $this->belongsTo(GedDocumentoCabecalhoModel::class, 'id_ged_documento_cabecalho', 'id');
	}

	public function gedTipoDocumentoModel()
	{
		return $this->belongsTo(GedTipoDocumentoModel::class, 'id_ged_tipo_documento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getPalavrasChaveAttribute()
	{
		return $this->attributes['palavras_chave'];
	}

	public function setPalavrasChaveAttribute($palavrasChave)
	{
		$this->attributes['palavras_chave'] = $palavrasChave;
	}

	public function getPodeExcluirAttribute()
	{
		return $this->attributes['pode_excluir'];
	}

	public function setPodeExcluirAttribute($podeExcluir)
	{
		$this->attributes['pode_excluir'] = $podeExcluir;
	}

	public function getPodeAlterarAttribute()
	{
		return $this->attributes['pode_alterar'];
	}

	public function setPodeAlterarAttribute($podeAlterar)
	{
		$this->attributes['pode_alterar'] = $podeAlterar;
	}

	public function getAssinadoAttribute()
	{
		return $this->attributes['assinado'];
	}

	public function setAssinadoAttribute($assinado)
	{
		$this->attributes['assinado'] = $assinado;
	}

	public function getDataFimVigenciaAttribute()
	{
		return $this->attributes['data_fim_vigencia'];
	}

	public function setDataFimVigenciaAttribute($dataFimVigencia)
	{
		$this->attributes['data_fim_vigencia'] = $dataFimVigencia;
	}

	public function getDataExclusaoAttribute()
	{
		return $this->attributes['data_exclusao'];
	}

	public function setDataExclusaoAttribute($dataExclusao)
	{
		$this->attributes['data_exclusao'] = $dataExclusao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setPalavrasChaveAttribute($object->palavrasChave);
				$this->setPodeExcluirAttribute($object->podeExcluir);
				$this->setPodeAlterarAttribute($object->podeAlterar);
				$this->setAssinadoAttribute($object->assinado);
				$this->setDataFimVigenciaAttribute($object->dataFimVigencia);
				$this->setDataExclusaoAttribute($object->dataExclusao);

				// link objects - lookups
				$gedTipoDocumentoModel = new GedTipoDocumentoModel();
				$gedTipoDocumentoModel->mapping($object->gedTipoDocumentoModel);
				$this->gedTipoDocumentoModel()->associate($gedTipoDocumentoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'palavrasChave' => $this->getPalavrasChaveAttribute(),
				'podeExcluir' => $this->getPodeExcluirAttribute(),
				'podeAlterar' => $this->getPodeAlterarAttribute(),
				'assinado' => $this->getAssinadoAttribute(),
				'dataFimVigencia' => $this->getDataFimVigenciaAttribute(),
				'dataExclusao' => $this->getDataExclusaoAttribute(),
				'gedTipoDocumentoModel' => $this->gedTipoDocumentoModel,
			];
	}
}