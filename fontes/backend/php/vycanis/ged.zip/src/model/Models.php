<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'GedDocumentoDetalheModel.php';
include 'GedDocumentoCabecalhoModel.php';
include 'GedTipoDocumentoModel.php';
include 'GedVersaoDocumentoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'ViewPessoaVendedorModel.php';
include 'ViewPessoaTransportadoraModel.php';