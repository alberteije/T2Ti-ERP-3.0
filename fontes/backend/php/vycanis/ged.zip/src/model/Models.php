<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'GedDocumentoDetalheModel.php';
include 'GedDocumentoCabecalhoModel.php';
include 'GedTipoDocumentoModel.php';
include 'GedVersaoDocumentoModel.php';