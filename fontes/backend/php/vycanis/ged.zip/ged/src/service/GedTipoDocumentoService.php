<?php
class GedTipoDocumentoService extends ServiceBase
{
  public function getList()
  {
    return GedTipoDocumentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return GedTipoDocumentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return GedTipoDocumentoModel::find($id);
  }

}