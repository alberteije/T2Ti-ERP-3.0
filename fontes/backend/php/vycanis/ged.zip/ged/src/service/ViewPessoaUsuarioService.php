<?php
class ViewPessoaUsuarioService extends ServiceBase
{
  public function getList()
  {
    return ViewPessoaUsuarioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewPessoaUsuarioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewPessoaUsuarioModel::find($id);
  }

  public function doLogin($filter)
	{
		$result = ViewPessoaUsuarioModel::whereRaw($filter->where)->get();
		if (count($result) > 0) {
			return $result[0];
		} else {
			return null;
		}
	}	
}