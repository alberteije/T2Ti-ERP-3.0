<?php
class ViewPessoaVendedorService extends ServiceBase
{
  public function getList()
  {
    return ViewPessoaVendedorModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewPessoaVendedorModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewPessoaVendedorModel::find($id);
  }

}