<?php
class GedVersaoDocumentoService extends ServiceBase
{
  public function getList()
  {
    return GedVersaoDocumentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return GedVersaoDocumentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return GedVersaoDocumentoModel::find($id);
  }

}