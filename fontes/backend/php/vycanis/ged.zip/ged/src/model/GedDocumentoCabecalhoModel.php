<?php
declare(strict_types=1);

class GedDocumentoCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ged_documento_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'gedDocumentoDetalheModelList',
	];

	/**
		* Relations
		*/
	public function gedDocumentoDetalheModelList()
{
	return $this->hasMany(GedDocumentoDetalheModel::class, 'id_ged_documento_cabecalho', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDataInclusaoAttribute()
	{
		return $this->attributes['data_inclusao'];
	}

	public function setDataInclusaoAttribute($dataInclusao)
	{
		$this->attributes['data_inclusao'] = $dataInclusao;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDataInclusaoAttribute($object->dataInclusao);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'dataInclusao' => $this->getDataInclusaoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'gedDocumentoDetalheModelList' => $this->gedDocumentoDetalheModelList,
			];
	}
}