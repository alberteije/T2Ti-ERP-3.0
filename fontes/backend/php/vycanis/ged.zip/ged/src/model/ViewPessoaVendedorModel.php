<?php
declare(strict_types=1);

class ViewPessoaVendedorModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'view_pessoa_vendedor';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getSiteAttribute()
	{
		return $this->attributes['site'];
	}

	public function setSiteAttribute($site)
	{
		$this->attributes['site'] = $site;
	}

	public function getCpfCnpjAttribute()
	{
		return $this->attributes['cpf_cnpj'];
	}

	public function setCpfCnpjAttribute($cpfCnpj)
	{
		$this->attributes['cpf_cnpj'] = $cpfCnpj;
	}

	public function getRgIeAttribute()
	{
		return $this->attributes['rg_ie'];
	}

	public function setRgIeAttribute($rgIe)
	{
		$this->attributes['rg_ie'] = $rgIe;
	}

	public function getMatriculaAttribute()
	{
		return $this->attributes['matricula'];
	}

	public function setMatriculaAttribute($matricula)
	{
		$this->attributes['matricula'] = $matricula;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getDataAdmissaoAttribute()
	{
		return $this->attributes['data_admissao'];
	}

	public function setDataAdmissaoAttribute($dataAdmissao)
	{
		$this->attributes['data_admissao'] = $dataAdmissao;
	}

	public function getDataDemissaoAttribute()
	{
		return $this->attributes['data_demissao'];
	}

	public function setDataDemissaoAttribute($dataDemissao)
	{
		$this->attributes['data_demissao'] = $dataDemissao;
	}

	public function getCtpsNumeroAttribute()
	{
		return $this->attributes['ctps_numero'];
	}

	public function setCtpsNumeroAttribute($ctpsNumero)
	{
		$this->attributes['ctps_numero'] = $ctpsNumero;
	}

	public function getCtpsSerieAttribute()
	{
		return $this->attributes['ctps_serie'];
	}

	public function setCtpsSerieAttribute($ctpsSerie)
	{
		$this->attributes['ctps_serie'] = $ctpsSerie;
	}

	public function getCtpsDataExpedicaoAttribute()
	{
		return $this->attributes['ctps_data_expedicao'];
	}

	public function setCtpsDataExpedicaoAttribute($ctpsDataExpedicao)
	{
		$this->attributes['ctps_data_expedicao'] = $ctpsDataExpedicao;
	}

	public function getCtpsUfAttribute()
	{
		return $this->attributes['ctps_uf'];
	}

	public function setCtpsUfAttribute($ctpsUf)
	{
		$this->attributes['ctps_uf'] = $ctpsUf;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getComplementoAttribute()
	{
		return $this->attributes['complemento'];
	}

	public function setComplementoAttribute($complemento)
	{
		$this->attributes['complemento'] = $complemento;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getCidadeAttribute()
	{
		return $this->attributes['cidade'];
	}

	public function setCidadeAttribute($cidade)
	{
		$this->attributes['cidade'] = $cidade;
	}

	public function getCepAttribute()
	{
		return $this->attributes['cep'];
	}

	public function setCepAttribute($cep)
	{
		$this->attributes['cep'] = $cep;
	}

	public function getMunicipioIbgeAttribute()
	{
		return $this->attributes['municipio_ibge'];
	}

	public function setMunicipioIbgeAttribute($municipioIbge)
	{
		$this->attributes['municipio_ibge'] = $municipioIbge;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getIdPessoaAttribute()
	{
		return $this->attributes['id_pessoa'];
	}

	public function setIdPessoaAttribute($idPessoa)
	{
		$this->attributes['id_pessoa'] = $idPessoa;
	}

	public function getIdCargoAttribute()
	{
		return $this->attributes['id_cargo'];
	}

	public function setIdCargoAttribute($idCargo)
	{
		$this->attributes['id_cargo'] = $idCargo;
	}

	public function getIdSetorAttribute()
	{
		return $this->attributes['id_setor'];
	}

	public function setIdSetorAttribute($idSetor)
	{
		$this->attributes['id_setor'] = $idSetor;
	}

	public function getComissaoAttribute()
	{
		return (double)$this->attributes['comissao'];
	}

	public function setComissaoAttribute($comissao)
	{
		$this->attributes['comissao'] = $comissao;
	}

	public function getMetaVendaAttribute()
	{
		return (double)$this->attributes['meta_venda'];
	}

	public function setMetaVendaAttribute($metaVenda)
	{
		$this->attributes['meta_venda'] = $metaVenda;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setTipoAttribute($object->tipo);
				$this->setEmailAttribute($object->email);
				$this->setSiteAttribute($object->site);
				$this->setCpfCnpjAttribute($object->cpfCnpj);
				$this->setRgIeAttribute($object->rgIe);
				$this->setMatriculaAttribute($object->matricula);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setDataAdmissaoAttribute($object->dataAdmissao);
				$this->setDataDemissaoAttribute($object->dataDemissao);
				$this->setCtpsNumeroAttribute($object->ctpsNumero);
				$this->setCtpsSerieAttribute($object->ctpsSerie);
				$this->setCtpsDataExpedicaoAttribute($object->ctpsDataExpedicao);
				$this->setCtpsUfAttribute($object->ctpsUf);
				$this->setObservacaoAttribute($object->observacao);
				$this->setLogradouroAttribute($object->logradouro);
				$this->setNumeroAttribute($object->numero);
				$this->setComplementoAttribute($object->complemento);
				$this->setBairroAttribute($object->bairro);
				$this->setCidadeAttribute($object->cidade);
				$this->setCepAttribute($object->cep);
				$this->setMunicipioIbgeAttribute($object->municipioIbge);
				$this->setUfAttribute($object->uf);
				$this->setIdPessoaAttribute($object->idPessoa);
				$this->setIdCargoAttribute($object->idCargo);
				$this->setIdSetorAttribute($object->idSetor);
				$this->setComissaoAttribute($object->comissao);
				$this->setMetaVendaAttribute($object->metaVenda);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'email' => $this->getEmailAttribute(),
				'site' => $this->getSiteAttribute(),
				'cpfCnpj' => $this->getCpfCnpjAttribute(),
				'rgIe' => $this->getRgIeAttribute(),
				'matricula' => $this->getMatriculaAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'dataAdmissao' => $this->getDataAdmissaoAttribute(),
				'dataDemissao' => $this->getDataDemissaoAttribute(),
				'ctpsNumero' => $this->getCtpsNumeroAttribute(),
				'ctpsSerie' => $this->getCtpsSerieAttribute(),
				'ctpsDataExpedicao' => $this->getCtpsDataExpedicaoAttribute(),
				'ctpsUf' => $this->getCtpsUfAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'complemento' => $this->getComplementoAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'cidade' => $this->getCidadeAttribute(),
				'cep' => $this->getCepAttribute(),
				'municipioIbge' => $this->getMunicipioIbgeAttribute(),
				'uf' => $this->getUfAttribute(),
				'idPessoa' => $this->getIdPessoaAttribute(),
				'idCargo' => $this->getIdCargoAttribute(),
				'idSetor' => $this->getIdSetorAttribute(),
				'comissao' => $this->getComissaoAttribute(),
				'metaVenda' => $this->getMetaVendaAttribute(),
			];
	}
}