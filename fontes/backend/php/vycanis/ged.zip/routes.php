<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// ged-documento-cabecalho
$app->get('/ged-documento-cabecalho[/]', \GedDocumentoCabecalhoController::class . RESULT_LIST);
$app->get('/ged-documento-cabecalho/{id}', \GedDocumentoCabecalhoController::class . RESULT_OBJECT);
$app->post('/ged-documento-cabecalho', \GedDocumentoCabecalhoController::class . INSERT);
$app->put('/ged-documento-cabecalho', \GedDocumentoCabecalhoController::class . UPDATE);
$app->delete('/ged-documento-cabecalho/{id}', \GedDocumentoCabecalhoController::class . DELETE);
$app->options('/ged-documento-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ged-documento-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ged-documento-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ged-tipo-documento
$app->get('/ged-tipo-documento[/]', \GedTipoDocumentoController::class . RESULT_LIST);
$app->get('/ged-tipo-documento/{id}', \GedTipoDocumentoController::class . RESULT_OBJECT);
$app->post('/ged-tipo-documento', \GedTipoDocumentoController::class . INSERT);
$app->put('/ged-tipo-documento', \GedTipoDocumentoController::class . UPDATE);
$app->delete('/ged-tipo-documento/{id}', \GedTipoDocumentoController::class . DELETE);
$app->options('/ged-tipo-documento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ged-tipo-documento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ged-tipo-documento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ged-versao-documento
$app->get('/ged-versao-documento[/]', \GedVersaoDocumentoController::class . RESULT_LIST);
$app->get('/ged-versao-documento/{id}', \GedVersaoDocumentoController::class . RESULT_OBJECT);
$app->post('/ged-versao-documento', \GedVersaoDocumentoController::class . INSERT);
$app->put('/ged-versao-documento', \GedVersaoDocumentoController::class . UPDATE);
$app->delete('/ged-versao-documento/{id}', \GedVersaoDocumentoController::class . DELETE);
$app->options('/ged-versao-documento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ged-versao-documento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ged-versao-documento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

