<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// cte-cabecalho
$app->get('/cte-cabecalho[/]', \CteCabecalhoController::class . RESULT_LIST);
$app->get('/cte-cabecalho/{id}', \CteCabecalhoController::class . RESULT_OBJECT);
$app->post('/cte-cabecalho', \CteCabecalhoController::class . INSERT);
$app->put('/cte-cabecalho', \CteCabecalhoController::class . UPDATE);
$app->delete('/cte-cabecalho/{id}', \CteCabecalhoController::class . DELETE);
$app->options('/cte-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-informacao-nf-transporte
$app->get('/cte-informacao-nf-transporte[/]', \CteInformacaoNfTransporteController::class . RESULT_LIST);
$app->get('/cte-informacao-nf-transporte/{id}', \CteInformacaoNfTransporteController::class . RESULT_OBJECT);
$app->post('/cte-informacao-nf-transporte', \CteInformacaoNfTransporteController::class . INSERT);
$app->put('/cte-informacao-nf-transporte', \CteInformacaoNfTransporteController::class . UPDATE);
$app->delete('/cte-informacao-nf-transporte/{id}', \CteInformacaoNfTransporteController::class . DELETE);
$app->options('/cte-informacao-nf-transporte', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-informacao-nf-transporte/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-informacao-nf-transporte/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-inf-nf-transporte-lacre
$app->get('/cte-inf-nf-transporte-lacre[/]', \CteInfNfTransporteLacreController::class . RESULT_LIST);
$app->get('/cte-inf-nf-transporte-lacre/{id}', \CteInfNfTransporteLacreController::class . RESULT_OBJECT);
$app->post('/cte-inf-nf-transporte-lacre', \CteInfNfTransporteLacreController::class . INSERT);
$app->put('/cte-inf-nf-transporte-lacre', \CteInfNfTransporteLacreController::class . UPDATE);
$app->delete('/cte-inf-nf-transporte-lacre/{id}', \CteInfNfTransporteLacreController::class . DELETE);
$app->options('/cte-inf-nf-transporte-lacre', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-inf-nf-transporte-lacre/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-inf-nf-transporte-lacre/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-informacao-nf-carga
$app->get('/cte-informacao-nf-carga[/]', \CteInformacaoNfCargaController::class . RESULT_LIST);
$app->get('/cte-informacao-nf-carga/{id}', \CteInformacaoNfCargaController::class . RESULT_OBJECT);
$app->post('/cte-informacao-nf-carga', \CteInformacaoNfCargaController::class . INSERT);
$app->put('/cte-informacao-nf-carga', \CteInformacaoNfCargaController::class . UPDATE);
$app->delete('/cte-informacao-nf-carga/{id}', \CteInformacaoNfCargaController::class . DELETE);
$app->options('/cte-informacao-nf-carga', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-informacao-nf-carga/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-informacao-nf-carga/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-inf-nf-carga-lacre
$app->get('/cte-inf-nf-carga-lacre[/]', \CteInfNfCargaLacreController::class . RESULT_LIST);
$app->get('/cte-inf-nf-carga-lacre/{id}', \CteInfNfCargaLacreController::class . RESULT_OBJECT);
$app->post('/cte-inf-nf-carga-lacre', \CteInfNfCargaLacreController::class . INSERT);
$app->put('/cte-inf-nf-carga-lacre', \CteInfNfCargaLacreController::class . UPDATE);
$app->delete('/cte-inf-nf-carga-lacre/{id}', \CteInfNfCargaLacreController::class . DELETE);
$app->options('/cte-inf-nf-carga-lacre', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-inf-nf-carga-lacre/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-inf-nf-carga-lacre/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-documento-anterior-id
$app->get('/cte-documento-anterior-id[/]', \CteDocumentoAnteriorIdController::class . RESULT_LIST);
$app->get('/cte-documento-anterior-id/{id}', \CteDocumentoAnteriorIdController::class . RESULT_OBJECT);
$app->post('/cte-documento-anterior-id', \CteDocumentoAnteriorIdController::class . INSERT);
$app->put('/cte-documento-anterior-id', \CteDocumentoAnteriorIdController::class . UPDATE);
$app->delete('/cte-documento-anterior-id/{id}', \CteDocumentoAnteriorIdController::class . DELETE);
$app->options('/cte-documento-anterior-id', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-documento-anterior-id/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-documento-anterior-id/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-rodoviario-occ
$app->get('/cte-rodoviario-occ[/]', \CteRodoviarioOccController::class . RESULT_LIST);
$app->get('/cte-rodoviario-occ/{id}', \CteRodoviarioOccController::class . RESULT_OBJECT);
$app->post('/cte-rodoviario-occ', \CteRodoviarioOccController::class . INSERT);
$app->put('/cte-rodoviario-occ', \CteRodoviarioOccController::class . UPDATE);
$app->delete('/cte-rodoviario-occ/{id}', \CteRodoviarioOccController::class . DELETE);
$app->options('/cte-rodoviario-occ', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-occ/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-occ/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-rodoviario-pedagio
$app->get('/cte-rodoviario-pedagio[/]', \CteRodoviarioPedagioController::class . RESULT_LIST);
$app->get('/cte-rodoviario-pedagio/{id}', \CteRodoviarioPedagioController::class . RESULT_OBJECT);
$app->post('/cte-rodoviario-pedagio', \CteRodoviarioPedagioController::class . INSERT);
$app->put('/cte-rodoviario-pedagio', \CteRodoviarioPedagioController::class . UPDATE);
$app->delete('/cte-rodoviario-pedagio/{id}', \CteRodoviarioPedagioController::class . DELETE);
$app->options('/cte-rodoviario-pedagio', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-pedagio/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-pedagio/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-rodoviario-veiculo
$app->get('/cte-rodoviario-veiculo[/]', \CteRodoviarioVeiculoController::class . RESULT_LIST);
$app->get('/cte-rodoviario-veiculo/{id}', \CteRodoviarioVeiculoController::class . RESULT_OBJECT);
$app->post('/cte-rodoviario-veiculo', \CteRodoviarioVeiculoController::class . INSERT);
$app->put('/cte-rodoviario-veiculo', \CteRodoviarioVeiculoController::class . UPDATE);
$app->delete('/cte-rodoviario-veiculo/{id}', \CteRodoviarioVeiculoController::class . DELETE);
$app->options('/cte-rodoviario-veiculo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-veiculo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-veiculo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-rodoviario-lacre
$app->get('/cte-rodoviario-lacre[/]', \CteRodoviarioLacreController::class . RESULT_LIST);
$app->get('/cte-rodoviario-lacre/{id}', \CteRodoviarioLacreController::class . RESULT_OBJECT);
$app->post('/cte-rodoviario-lacre', \CteRodoviarioLacreController::class . INSERT);
$app->put('/cte-rodoviario-lacre', \CteRodoviarioLacreController::class . UPDATE);
$app->delete('/cte-rodoviario-lacre/{id}', \CteRodoviarioLacreController::class . DELETE);
$app->options('/cte-rodoviario-lacre', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-lacre/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-lacre/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-rodoviario-motorista
$app->get('/cte-rodoviario-motorista[/]', \CteRodoviarioMotoristaController::class . RESULT_LIST);
$app->get('/cte-rodoviario-motorista/{id}', \CteRodoviarioMotoristaController::class . RESULT_OBJECT);
$app->post('/cte-rodoviario-motorista', \CteRodoviarioMotoristaController::class . INSERT);
$app->put('/cte-rodoviario-motorista', \CteRodoviarioMotoristaController::class . UPDATE);
$app->delete('/cte-rodoviario-motorista/{id}', \CteRodoviarioMotoristaController::class . DELETE);
$app->options('/cte-rodoviario-motorista', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-motorista/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-rodoviario-motorista/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-aquaviario-balsa
$app->get('/cte-aquaviario-balsa[/]', \CteAquaviarioBalsaController::class . RESULT_LIST);
$app->get('/cte-aquaviario-balsa/{id}', \CteAquaviarioBalsaController::class . RESULT_OBJECT);
$app->post('/cte-aquaviario-balsa', \CteAquaviarioBalsaController::class . INSERT);
$app->put('/cte-aquaviario-balsa', \CteAquaviarioBalsaController::class . UPDATE);
$app->delete('/cte-aquaviario-balsa/{id}', \CteAquaviarioBalsaController::class . DELETE);
$app->options('/cte-aquaviario-balsa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-aquaviario-balsa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-aquaviario-balsa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-ferroviario-ferrovia
$app->get('/cte-ferroviario-ferrovia[/]', \CteFerroviarioFerroviaController::class . RESULT_LIST);
$app->get('/cte-ferroviario-ferrovia/{id}', \CteFerroviarioFerroviaController::class . RESULT_OBJECT);
$app->post('/cte-ferroviario-ferrovia', \CteFerroviarioFerroviaController::class . INSERT);
$app->put('/cte-ferroviario-ferrovia', \CteFerroviarioFerroviaController::class . UPDATE);
$app->delete('/cte-ferroviario-ferrovia/{id}', \CteFerroviarioFerroviaController::class . DELETE);
$app->options('/cte-ferroviario-ferrovia', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-ferroviario-ferrovia/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-ferroviario-ferrovia/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cte-ferroviario-vagao
$app->get('/cte-ferroviario-vagao[/]', \CteFerroviarioVagaoController::class . RESULT_LIST);
$app->get('/cte-ferroviario-vagao/{id}', \CteFerroviarioVagaoController::class . RESULT_OBJECT);
$app->post('/cte-ferroviario-vagao', \CteFerroviarioVagaoController::class . INSERT);
$app->put('/cte-ferroviario-vagao', \CteFerroviarioVagaoController::class . UPDATE);
$app->delete('/cte-ferroviario-vagao/{id}', \CteFerroviarioVagaoController::class . DELETE);
$app->options('/cte-ferroviario-vagao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-ferroviario-vagao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cte-ferroviario-vagao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

