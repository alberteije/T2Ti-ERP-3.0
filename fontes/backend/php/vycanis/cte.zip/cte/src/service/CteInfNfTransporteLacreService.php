<?php
class CteInfNfTransporteLacreService extends ServiceBase
{
  public function getList()
  {
    return CteInfNfTransporteLacreModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteInfNfTransporteLacreModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteInfNfTransporteLacreModel::find($id);
  }

}