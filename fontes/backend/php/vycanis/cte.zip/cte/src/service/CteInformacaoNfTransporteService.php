<?php
class CteInformacaoNfTransporteService extends ServiceBase
{
  public function getList()
  {
    return CteInformacaoNfTransporteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteInformacaoNfTransporteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteInformacaoNfTransporteModel::find($id);
  }

}