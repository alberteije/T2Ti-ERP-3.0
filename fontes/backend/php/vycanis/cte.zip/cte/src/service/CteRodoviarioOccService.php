<?php
class CteRodoviarioOccService extends ServiceBase
{
  public function getList()
  {
    return CteRodoviarioOccModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteRodoviarioOccModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteRodoviarioOccModel::find($id);
  }

}