<?php
class CteInformacaoNfCargaService extends ServiceBase
{
  public function getList()
  {
    return CteInformacaoNfCargaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteInformacaoNfCargaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteInformacaoNfCargaModel::find($id);
  }

}