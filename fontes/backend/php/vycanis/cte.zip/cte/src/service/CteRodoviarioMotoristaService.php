<?php
class CteRodoviarioMotoristaService extends ServiceBase
{
  public function getList()
  {
    return CteRodoviarioMotoristaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteRodoviarioMotoristaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteRodoviarioMotoristaModel::find($id);
  }

}