<?php
class CteAquaviarioBalsaService extends ServiceBase
{
  public function getList()
  {
    return CteAquaviarioBalsaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteAquaviarioBalsaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteAquaviarioBalsaModel::find($id);
  }

}