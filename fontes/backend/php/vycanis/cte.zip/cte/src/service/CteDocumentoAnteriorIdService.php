<?php
class CteDocumentoAnteriorIdService extends ServiceBase
{
  public function getList()
  {
    return CteDocumentoAnteriorIdModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteDocumentoAnteriorIdModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteDocumentoAnteriorIdModel::find($id);
  }

}