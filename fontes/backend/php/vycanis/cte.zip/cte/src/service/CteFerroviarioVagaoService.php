<?php
class CteFerroviarioVagaoService extends ServiceBase
{
  public function getList()
  {
    return CteFerroviarioVagaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteFerroviarioVagaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteFerroviarioVagaoModel::find($id);
  }

}