<?php
declare(strict_types=1);

class CteVeiculoNovoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_veiculo_novo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getChassiAttribute()
	{
		return $this->attributes['chassi'];
	}

	public function setChassiAttribute($chassi)
	{
		$this->attributes['chassi'] = $chassi;
	}

	public function getCorAttribute()
	{
		return $this->attributes['cor'];
	}

	public function setCorAttribute($cor)
	{
		$this->attributes['cor'] = $cor;
	}

	public function getDescricaoCorAttribute()
	{
		return $this->attributes['descricao_cor'];
	}

	public function setDescricaoCorAttribute($descricaoCor)
	{
		$this->attributes['descricao_cor'] = $descricaoCor;
	}

	public function getCodigoMarcaModeloAttribute()
	{
		return $this->attributes['codigo_marca_modelo'];
	}

	public function setCodigoMarcaModeloAttribute($codigoMarcaModelo)
	{
		$this->attributes['codigo_marca_modelo'] = $codigoMarcaModelo;
	}

	public function getValorUnitarioAttribute()
	{
		return (double)$this->attributes['valor_unitario'];
	}

	public function setValorUnitarioAttribute($valorUnitario)
	{
		$this->attributes['valor_unitario'] = $valorUnitario;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setChassiAttribute($object->chassi);
				$this->setCorAttribute($object->cor);
				$this->setDescricaoCorAttribute($object->descricaoCor);
				$this->setCodigoMarcaModeloAttribute($object->codigoMarcaModelo);
				$this->setValorUnitarioAttribute($object->valorUnitario);
				$this->setValorFreteAttribute($object->valorFrete);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'chassi' => $this->getChassiAttribute(),
				'cor' => $this->getCorAttribute(),
				'descricaoCor' => $this->getDescricaoCorAttribute(),
				'codigoMarcaModelo' => $this->getCodigoMarcaModeloAttribute(),
				'valorUnitario' => $this->getValorUnitarioAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
			];
	}
}