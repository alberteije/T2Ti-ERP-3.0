<?php
declare(strict_types=1);

class CteSeguroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_seguro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getResponsavelAttribute()
	{
		return $this->attributes['responsavel'];
	}

	public function setResponsavelAttribute($responsavel)
	{
		$this->attributes['responsavel'] = $responsavel;
	}

	public function getSeguradoraAttribute()
	{
		return $this->attributes['seguradora'];
	}

	public function setSeguradoraAttribute($seguradora)
	{
		$this->attributes['seguradora'] = $seguradora;
	}

	public function getApoliceAttribute()
	{
		return $this->attributes['apolice'];
	}

	public function setApoliceAttribute($apolice)
	{
		$this->attributes['apolice'] = $apolice;
	}

	public function getAverbacaoAttribute()
	{
		return $this->attributes['averbacao'];
	}

	public function setAverbacaoAttribute($averbacao)
	{
		$this->attributes['averbacao'] = $averbacao;
	}

	public function getValorCargaAttribute()
	{
		return (double)$this->attributes['valor_carga'];
	}

	public function setValorCargaAttribute($valorCarga)
	{
		$this->attributes['valor_carga'] = $valorCarga;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setResponsavelAttribute($object->responsavel);
				$this->setSeguradoraAttribute($object->seguradora);
				$this->setApoliceAttribute($object->apolice);
				$this->setAverbacaoAttribute($object->averbacao);
				$this->setValorCargaAttribute($object->valorCarga);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'responsavel' => $this->getResponsavelAttribute(),
				'seguradora' => $this->getSeguradoraAttribute(),
				'apolice' => $this->getApoliceAttribute(),
				'averbacao' => $this->getAverbacaoAttribute(),
				'valorCarga' => $this->getValorCargaAttribute(),
			];
	}
}