<?php
declare(strict_types=1);

class CteFerroviarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_ferroviario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoTrafegoAttribute()
	{
		return $this->attributes['tipo_trafego'];
	}

	public function setTipoTrafegoAttribute($tipoTrafego)
	{
		$this->attributes['tipo_trafego'] = $tipoTrafego;
	}

	public function getResponsavelFaturamentoAttribute()
	{
		return $this->attributes['responsavel_faturamento'];
	}

	public function setResponsavelFaturamentoAttribute($responsavelFaturamento)
	{
		$this->attributes['responsavel_faturamento'] = $responsavelFaturamento;
	}

	public function getFerroviaEmitenteCteAttribute()
	{
		return $this->attributes['ferrovia_emitente_cte'];
	}

	public function setFerroviaEmitenteCteAttribute($ferroviaEmitenteCte)
	{
		$this->attributes['ferrovia_emitente_cte'] = $ferroviaEmitenteCte;
	}

	public function getFluxoAttribute()
	{
		return $this->attributes['fluxo'];
	}

	public function setFluxoAttribute($fluxo)
	{
		$this->attributes['fluxo'] = $fluxo;
	}

	public function getIdTremAttribute()
	{
		return $this->attributes['id_trem'];
	}

	public function setIdTremAttribute($idTrem)
	{
		$this->attributes['id_trem'] = $idTrem;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoTrafegoAttribute($object->tipoTrafego);
				$this->setResponsavelFaturamentoAttribute($object->responsavelFaturamento);
				$this->setFerroviaEmitenteCteAttribute($object->ferroviaEmitenteCte);
				$this->setFluxoAttribute($object->fluxo);
				$this->setIdTremAttribute($object->idTrem);
				$this->setValorFreteAttribute($object->valorFrete);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipoTrafego' => $this->getTipoTrafegoAttribute(),
				'responsavelFaturamento' => $this->getResponsavelFaturamentoAttribute(),
				'ferroviaEmitenteCte' => $this->getFerroviaEmitenteCteAttribute(),
				'fluxo' => $this->getFluxoAttribute(),
				'idTrem' => $this->getIdTremAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
			];
	}
}