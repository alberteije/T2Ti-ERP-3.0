<?php
declare(strict_types=1);

class CteDutoviarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_dutoviario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorTarifaAttribute()
	{
		return (double)$this->attributes['valor_tarifa'];
	}

	public function setValorTarifaAttribute($valorTarifa)
	{
		$this->attributes['valor_tarifa'] = $valorTarifa;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorTarifaAttribute($object->valorTarifa);
				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valorTarifa' => $this->getValorTarifaAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
			];
	}
}