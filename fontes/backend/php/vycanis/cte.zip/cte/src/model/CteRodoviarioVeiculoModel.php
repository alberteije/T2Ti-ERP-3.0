<?php
declare(strict_types=1);

class CteRodoviarioVeiculoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_rodoviario_veiculo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function cteRodoviarioModel()
	{
		return $this->belongsTo(CteRodoviarioModel::class, 'id_cte_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoInternoAttribute()
	{
		return $this->attributes['codigo_interno'];
	}

	public function setCodigoInternoAttribute($codigoInterno)
	{
		$this->attributes['codigo_interno'] = $codigoInterno;
	}

	public function getRenavamAttribute()
	{
		return $this->attributes['renavam'];
	}

	public function setRenavamAttribute($renavam)
	{
		$this->attributes['renavam'] = $renavam;
	}

	public function getPlacaAttribute()
	{
		return $this->attributes['placa'];
	}

	public function setPlacaAttribute($placa)
	{
		$this->attributes['placa'] = $placa;
	}

	public function getTaraAttribute()
	{
		return $this->attributes['tara'];
	}

	public function setTaraAttribute($tara)
	{
		$this->attributes['tara'] = $tara;
	}

	public function getCapacidadeKgAttribute()
	{
		return $this->attributes['capacidade_kg'];
	}

	public function setCapacidadeKgAttribute($capacidadeKg)
	{
		$this->attributes['capacidade_kg'] = $capacidadeKg;
	}

	public function getCapacidadeM3Attribute()
	{
		return $this->attributes['capacidade_m3'];
	}

	public function setCapacidadeM3Attribute($capacidadeM3)
	{
		$this->attributes['capacidade_m3'] = $capacidadeM3;
	}

	public function getTipoPropriedadeAttribute()
	{
		return $this->attributes['tipo_propriedade'];
	}

	public function setTipoPropriedadeAttribute($tipoPropriedade)
	{
		$this->attributes['tipo_propriedade'] = $tipoPropriedade;
	}

	public function getTipoVeiculoAttribute()
	{
		return $this->attributes['tipo_veiculo'];
	}

	public function setTipoVeiculoAttribute($tipoVeiculo)
	{
		$this->attributes['tipo_veiculo'] = $tipoVeiculo;
	}

	public function getTipoRodadoAttribute()
	{
		return $this->attributes['tipo_rodado'];
	}

	public function setTipoRodadoAttribute($tipoRodado)
	{
		$this->attributes['tipo_rodado'] = $tipoRodado;
	}

	public function getTipoCarroceriaAttribute()
	{
		return $this->attributes['tipo_carroceria'];
	}

	public function setTipoCarroceriaAttribute($tipoCarroceria)
	{
		$this->attributes['tipo_carroceria'] = $tipoCarroceria;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getProprietarioCpfAttribute()
	{
		return $this->attributes['proprietario_cpf'];
	}

	public function setProprietarioCpfAttribute($proprietarioCpf)
	{
		$this->attributes['proprietario_cpf'] = $proprietarioCpf;
	}

	public function getProprietarioCnpjAttribute()
	{
		return $this->attributes['proprietario_cnpj'];
	}

	public function setProprietarioCnpjAttribute($proprietarioCnpj)
	{
		$this->attributes['proprietario_cnpj'] = $proprietarioCnpj;
	}

	public function getProprietarioRntrcAttribute()
	{
		return $this->attributes['proprietario_rntrc'];
	}

	public function setProprietarioRntrcAttribute($proprietarioRntrc)
	{
		$this->attributes['proprietario_rntrc'] = $proprietarioRntrc;
	}

	public function getProprietarioNomeAttribute()
	{
		return $this->attributes['proprietario_nome'];
	}

	public function setProprietarioNomeAttribute($proprietarioNome)
	{
		$this->attributes['proprietario_nome'] = $proprietarioNome;
	}

	public function getProprietarioIeAttribute()
	{
		return $this->attributes['proprietario_ie'];
	}

	public function setProprietarioIeAttribute($proprietarioIe)
	{
		$this->attributes['proprietario_ie'] = $proprietarioIe;
	}

	public function getProprietarioUfAttribute()
	{
		return $this->attributes['proprietario_uf'];
	}

	public function setProprietarioUfAttribute($proprietarioUf)
	{
		$this->attributes['proprietario_uf'] = $proprietarioUf;
	}

	public function getProprietarioTipoAttribute()
	{
		return $this->attributes['proprietario_tipo'];
	}

	public function setProprietarioTipoAttribute($proprietarioTipo)
	{
		$this->attributes['proprietario_tipo'] = $proprietarioTipo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoInternoAttribute($object->codigoInterno);
				$this->setRenavamAttribute($object->renavam);
				$this->setPlacaAttribute($object->placa);
				$this->setTaraAttribute($object->tara);
				$this->setCapacidadeKgAttribute($object->capacidadeKg);
				$this->setCapacidadeM3Attribute($object->capacidadeM3);
				$this->setTipoPropriedadeAttribute($object->tipoPropriedade);
				$this->setTipoVeiculoAttribute($object->tipoVeiculo);
				$this->setTipoRodadoAttribute($object->tipoRodado);
				$this->setTipoCarroceriaAttribute($object->tipoCarroceria);
				$this->setUfAttribute($object->uf);
				$this->setProprietarioCpfAttribute($object->proprietarioCpf);
				$this->setProprietarioCnpjAttribute($object->proprietarioCnpj);
				$this->setProprietarioRntrcAttribute($object->proprietarioRntrc);
				$this->setProprietarioNomeAttribute($object->proprietarioNome);
				$this->setProprietarioIeAttribute($object->proprietarioIe);
				$this->setProprietarioUfAttribute($object->proprietarioUf);
				$this->setProprietarioTipoAttribute($object->proprietarioTipo);

				// link objects - lookups
				$cteRodoviarioModel = new CteRodoviarioModel();
				$cteRodoviarioModel->mapping($object->cteRodoviarioModel);
				$this->cteRodoviarioModel()->associate($cteRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoInterno' => $this->getCodigoInternoAttribute(),
				'renavam' => $this->getRenavamAttribute(),
				'placa' => $this->getPlacaAttribute(),
				'tara' => $this->getTaraAttribute(),
				'capacidadeKg' => $this->getCapacidadeKgAttribute(),
				'capacidadeM3' => $this->getCapacidadeM3Attribute(),
				'tipoPropriedade' => $this->getTipoPropriedadeAttribute(),
				'tipoVeiculo' => $this->getTipoVeiculoAttribute(),
				'tipoRodado' => $this->getTipoRodadoAttribute(),
				'tipoCarroceria' => $this->getTipoCarroceriaAttribute(),
				'uf' => $this->getUfAttribute(),
				'proprietarioCpf' => $this->getProprietarioCpfAttribute(),
				'proprietarioCnpj' => $this->getProprietarioCnpjAttribute(),
				'proprietarioRntrc' => $this->getProprietarioRntrcAttribute(),
				'proprietarioNome' => $this->getProprietarioNomeAttribute(),
				'proprietarioIe' => $this->getProprietarioIeAttribute(),
				'proprietarioUf' => $this->getProprietarioUfAttribute(),
				'proprietarioTipo' => $this->getProprietarioTipoAttribute(),
				'cteRodoviarioModel' => $this->cteRodoviarioModel,
			];
	}
}