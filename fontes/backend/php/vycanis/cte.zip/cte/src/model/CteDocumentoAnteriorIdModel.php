<?php
declare(strict_types=1);

class CteDocumentoAnteriorIdModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_documento_anterior_id';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getSubserieAttribute()
	{
		return $this->attributes['subserie'];
	}

	public function setSubserieAttribute($subserie)
	{
		$this->attributes['subserie'] = $subserie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataEmissaoAttribute()
	{
		return $this->attributes['data_emissao'];
	}

	public function setDataEmissaoAttribute($dataEmissao)
	{
		$this->attributes['data_emissao'] = $dataEmissao;
	}

	public function getChaveCteAttribute()
	{
		return $this->attributes['chave_cte'];
	}

	public function setChaveCteAttribute($chaveCte)
	{
		$this->attributes['chave_cte'] = $chaveCte;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoAttribute($object->tipo);
				$this->setSerieAttribute($object->serie);
				$this->setSubserieAttribute($object->subserie);
				$this->setNumeroAttribute($object->numero);
				$this->setDataEmissaoAttribute($object->dataEmissao);
				$this->setChaveCteAttribute($object->chaveCte);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'serie' => $this->getSerieAttribute(),
				'subserie' => $this->getSubserieAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataEmissao' => $this->getDataEmissaoAttribute(),
				'chaveCte' => $this->getChaveCteAttribute(),
			];
	}
}