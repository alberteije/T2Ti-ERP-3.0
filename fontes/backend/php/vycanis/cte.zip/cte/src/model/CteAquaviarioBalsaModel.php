<?php
declare(strict_types=1);

class CteAquaviarioBalsaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_aquaviario_balsa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteAquaviarioModel',
	];

	/**
		* Relations
		*/
	public function cteAquaviarioModel()
	{
		return $this->belongsTo(CteAquaviarioModel::class, 'id_cte_aquaviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdBalsaAttribute()
	{
		return $this->attributes['id_balsa'];
	}

	public function setIdBalsaAttribute($idBalsa)
	{
		$this->attributes['id_balsa'] = $idBalsa;
	}

	public function getNumeroViagemAttribute()
	{
		return $this->attributes['numero_viagem'];
	}

	public function setNumeroViagemAttribute($numeroViagem)
	{
		$this->attributes['numero_viagem'] = $numeroViagem;
	}

	public function getDirecaoAttribute()
	{
		return $this->attributes['direcao'];
	}

	public function setDirecaoAttribute($direcao)
	{
		$this->attributes['direcao'] = $direcao;
	}

	public function getPortoEmbarqueAttribute()
	{
		return $this->attributes['porto_embarque'];
	}

	public function setPortoEmbarqueAttribute($portoEmbarque)
	{
		$this->attributes['porto_embarque'] = $portoEmbarque;
	}

	public function getPortoTransbordoAttribute()
	{
		return $this->attributes['porto_transbordo'];
	}

	public function setPortoTransbordoAttribute($portoTransbordo)
	{
		$this->attributes['porto_transbordo'] = $portoTransbordo;
	}

	public function getPortoDestinoAttribute()
	{
		return $this->attributes['porto_destino'];
	}

	public function setPortoDestinoAttribute($portoDestino)
	{
		$this->attributes['porto_destino'] = $portoDestino;
	}

	public function getTipoNavegacaoAttribute()
	{
		return $this->attributes['tipo_navegacao'];
	}

	public function setTipoNavegacaoAttribute($tipoNavegacao)
	{
		$this->attributes['tipo_navegacao'] = $tipoNavegacao;
	}

	public function getIrinAttribute()
	{
		return $this->attributes['irin'];
	}

	public function setIrinAttribute($irin)
	{
		$this->attributes['irin'] = $irin;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdBalsaAttribute($object->idBalsa);
				$this->setNumeroViagemAttribute($object->numeroViagem);
				$this->setDirecaoAttribute($object->direcao);
				$this->setPortoEmbarqueAttribute($object->portoEmbarque);
				$this->setPortoTransbordoAttribute($object->portoTransbordo);
				$this->setPortoDestinoAttribute($object->portoDestino);
				$this->setTipoNavegacaoAttribute($object->tipoNavegacao);
				$this->setIrinAttribute($object->irin);

				// link objects - lookups
				$cteAquaviarioModel = new CteAquaviarioModel();
				$cteAquaviarioModel->mapping($object->cteAquaviarioModel);
				$this->cteAquaviarioModel()->associate($cteAquaviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idBalsa' => $this->getIdBalsaAttribute(),
				'numeroViagem' => $this->getNumeroViagemAttribute(),
				'direcao' => $this->getDirecaoAttribute(),
				'portoEmbarque' => $this->getPortoEmbarqueAttribute(),
				'portoTransbordo' => $this->getPortoTransbordoAttribute(),
				'portoDestino' => $this->getPortoDestinoAttribute(),
				'tipoNavegacao' => $this->getTipoNavegacaoAttribute(),
				'irin' => $this->getIrinAttribute(),
				'cteAquaviarioModel' => $this->cteAquaviarioModel,
			];
	}
}