<?php
declare(strict_types=1);

class CteInfNfCargaLacreModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_inf_nf_carga_lacre';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteInformacaoNfCargaModel',
	];

	/**
		* Relations
		*/
	public function cteInformacaoNfCargaModel()
	{
		return $this->belongsTo(CteInformacaoNfCargaModel::class, 'id_cte_informacao_nf_carga', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getQuantidadeRateadaAttribute()
	{
		return (double)$this->attributes['quantidade_rateada'];
	}

	public function setQuantidadeRateadaAttribute($quantidadeRateada)
	{
		$this->attributes['quantidade_rateada'] = $quantidadeRateada;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setQuantidadeRateadaAttribute($object->quantidadeRateada);

				// link objects - lookups
				$cteInformacaoNfCargaModel = new CteInformacaoNfCargaModel();
				$cteInformacaoNfCargaModel->mapping($object->cteInformacaoNfCargaModel);
				$this->cteInformacaoNfCargaModel()->associate($cteInformacaoNfCargaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'quantidadeRateada' => $this->getQuantidadeRateadaAttribute(),
				'cteInformacaoNfCargaModel' => $this->cteInformacaoNfCargaModel,
			];
	}
}