<?php
declare(strict_types=1);

class CteCargaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_carga';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoUnidadeMedidaAttribute()
	{
		return $this->attributes['codigo_unidade_medida'];
	}

	public function setCodigoUnidadeMedidaAttribute($codigoUnidadeMedida)
	{
		$this->attributes['codigo_unidade_medida'] = $codigoUnidadeMedida;
	}

	public function getTipoMedidaAttribute()
	{
		return $this->attributes['tipo_medida'];
	}

	public function setTipoMedidaAttribute($tipoMedida)
	{
		$this->attributes['tipo_medida'] = $tipoMedida;
	}

	public function getQuantidadeAttribute()
	{
		return (double)$this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoUnidadeMedidaAttribute($object->codigoUnidadeMedida);
				$this->setTipoMedidaAttribute($object->tipoMedida);
				$this->setQuantidadeAttribute($object->quantidade);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoUnidadeMedida' => $this->getCodigoUnidadeMedidaAttribute(),
				'tipoMedida' => $this->getTipoMedidaAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
			];
	}
}