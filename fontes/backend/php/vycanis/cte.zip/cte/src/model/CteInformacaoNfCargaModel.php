<?php
declare(strict_types=1);

class CteInformacaoNfCargaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_informacao_nf_carga';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteInformacaoNfOutrosModel',
	];

	/**
		* Relations
		*/
	public function cteInformacaoNfOutrosModel()
	{
		return $this->belongsTo(CteInformacaoNfOutrosModel::class, 'id_cte_informacao_nf', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoUnidadeCargaAttribute()
	{
		return $this->attributes['tipo_unidade_carga'];
	}

	public function setTipoUnidadeCargaAttribute($tipoUnidadeCarga)
	{
		$this->attributes['tipo_unidade_carga'] = $tipoUnidadeCarga;
	}

	public function getIdUnidadeCargaAttribute()
	{
		return $this->attributes['id_unidade_carga'];
	}

	public function setIdUnidadeCargaAttribute($idUnidadeCarga)
	{
		$this->attributes['id_unidade_carga'] = $idUnidadeCarga;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoUnidadeCargaAttribute($object->tipoUnidadeCarga);
				$this->setIdUnidadeCargaAttribute($object->idUnidadeCarga);

				// link objects - lookups
				$cteInformacaoNfOutrosModel = new CteInformacaoNfOutrosModel();
				$cteInformacaoNfOutrosModel->mapping($object->cteInformacaoNfOutrosModel);
				$this->cteInformacaoNfOutrosModel()->associate($cteInformacaoNfOutrosModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipoUnidadeCarga' => $this->getTipoUnidadeCargaAttribute(),
				'idUnidadeCarga' => $this->getIdUnidadeCargaAttribute(),
				'cteInformacaoNfOutrosModel' => $this->cteInformacaoNfOutrosModel,
			];
	}
}