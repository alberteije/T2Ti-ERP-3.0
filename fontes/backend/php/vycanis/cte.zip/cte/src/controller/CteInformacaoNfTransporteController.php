<?php
class CteInformacaoNfTransporteController extends ControllerBase
{

		private $cteInformacaoNfTransporteService = null;

		public function __construct()
		{	 
				$this->cteInformacaoNfTransporteService = new CteInformacaoNfTransporteService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteInformacaoNfTransporteService->getListFilter($filter);
						} else {
								$resultList = $this->cteInformacaoNfTransporteService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteInformacaoNfTransporte]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteInformacaoNfTransporteService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteInformacaoNfTransporte]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteInformacaoNfTransporte]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteInformacaoNfTransporte]', null);
						}

						$objModel = new CteInformacaoNfTransporteModel();
						$objModel->mapping($objJson);

						$this->cteInformacaoNfTransporteService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteInformacaoNfTransporte]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteInformacaoNfTransporteService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteInformacaoNfTransporte]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteInformacaoNfTransporteService->save($objFromDatabase);
								$objFromDatabase = $this->cteInformacaoNfTransporteService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteInformacaoNfTransporte]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteInformacaoNfTransporteService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteInformacaoNfTransporte]', null);
						} else {
								$this->cteInformacaoNfTransporteService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteInformacaoNfTransporte]', $e);
				}
		}
}
