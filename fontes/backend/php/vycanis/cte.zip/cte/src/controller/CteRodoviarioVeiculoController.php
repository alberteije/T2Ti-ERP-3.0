<?php
class CteRodoviarioVeiculoController extends ControllerBase
{

		private $cteRodoviarioVeiculoService = null;

		public function __construct()
		{	 
				$this->cteRodoviarioVeiculoService = new CteRodoviarioVeiculoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteRodoviarioVeiculoService->getListFilter($filter);
						} else {
								$resultList = $this->cteRodoviarioVeiculoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteRodoviarioVeiculo]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteRodoviarioVeiculoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteRodoviarioVeiculo]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteRodoviarioVeiculo]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteRodoviarioVeiculo]', null);
						}

						$objModel = new CteRodoviarioVeiculoModel();
						$objModel->mapping($objJson);

						$this->cteRodoviarioVeiculoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteRodoviarioVeiculo]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteRodoviarioVeiculoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteRodoviarioVeiculo]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteRodoviarioVeiculoService->save($objFromDatabase);
								$objFromDatabase = $this->cteRodoviarioVeiculoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteRodoviarioVeiculo]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteRodoviarioVeiculoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteRodoviarioVeiculo]', null);
						} else {
								$this->cteRodoviarioVeiculoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteRodoviarioVeiculo]', $e);
				}
		}
}
