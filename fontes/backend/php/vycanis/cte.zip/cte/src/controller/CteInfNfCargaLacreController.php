<?php
class CteInfNfCargaLacreController extends ControllerBase
{

		private $cteInfNfCargaLacreService = null;

		public function __construct()
		{	 
				$this->cteInfNfCargaLacreService = new CteInfNfCargaLacreService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteInfNfCargaLacreService->getListFilter($filter);
						} else {
								$resultList = $this->cteInfNfCargaLacreService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteInfNfCargaLacre]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteInfNfCargaLacreService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteInfNfCargaLacre]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteInfNfCargaLacre]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteInfNfCargaLacre]', null);
						}

						$objModel = new CteInfNfCargaLacreModel();
						$objModel->mapping($objJson);

						$this->cteInfNfCargaLacreService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteInfNfCargaLacre]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteInfNfCargaLacreService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteInfNfCargaLacre]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteInfNfCargaLacreService->save($objFromDatabase);
								$objFromDatabase = $this->cteInfNfCargaLacreService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteInfNfCargaLacre]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteInfNfCargaLacreService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteInfNfCargaLacre]', null);
						} else {
								$this->cteInfNfCargaLacreService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteInfNfCargaLacre]', $e);
				}
		}
}
