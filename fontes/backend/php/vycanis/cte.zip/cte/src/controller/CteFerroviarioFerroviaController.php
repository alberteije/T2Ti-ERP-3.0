<?php
class CteFerroviarioFerroviaController extends ControllerBase
{

		private $cteFerroviarioFerroviaService = null;

		public function __construct()
		{	 
				$this->cteFerroviarioFerroviaService = new CteFerroviarioFerroviaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteFerroviarioFerroviaService->getListFilter($filter);
						} else {
								$resultList = $this->cteFerroviarioFerroviaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteFerroviarioFerrovia]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteFerroviarioFerroviaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteFerroviarioFerrovia]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteFerroviarioFerrovia]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteFerroviarioFerrovia]', null);
						}

						$objModel = new CteFerroviarioFerroviaModel();
						$objModel->mapping($objJson);

						$this->cteFerroviarioFerroviaService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteFerroviarioFerrovia]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteFerroviarioFerroviaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteFerroviarioFerrovia]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteFerroviarioFerroviaService->save($objFromDatabase);
								$objFromDatabase = $this->cteFerroviarioFerroviaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteFerroviarioFerrovia]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteFerroviarioFerroviaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteFerroviarioFerrovia]', null);
						} else {
								$this->cteFerroviarioFerroviaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteFerroviarioFerrovia]', $e);
				}
		}
}
