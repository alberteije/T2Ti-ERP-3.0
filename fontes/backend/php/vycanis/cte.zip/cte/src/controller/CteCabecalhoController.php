<?php
use Slim\Psr7\Stream;
class CteCabecalhoController extends ControllerBase
{

		private $cteCabecalhoService = null;

		public function __construct()
		{	 
				$this->cteCabecalhoService = new CteCabecalhoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteCabecalhoService->getListFilter($filter);
						} else {
								$resultList = $this->cteCabecalhoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteCabecalho]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteCabecalho]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteCabecalho]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteCabecalho]', null);
						}

						$objModel = new CteCabecalhoModel();
						$objModel->mapping($objJson);

						$this->cteCabecalhoService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteCabecalho]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteCabecalhoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteCabecalho]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteCabecalhoService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->cteCabecalhoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteCabecalho]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteCabecalho]', null);
						} else {
								$this->cteCabecalhoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteCabecalho]', $e);
				}
		}

	public function transmitirCte($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			$objFromDatabase = $this->cteCabecalhoService->getObject($objJson->id);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [Transmitir Cte]', null);
			}

			$retorno = $this->cteCabecalhoService->transmitirCte($objFromDatabase);
			// $retorno = "";

			if (!str_contains($retorno, "ERRO")) {
				// $fh = fopen($retorno, 'rb');
				$fh = fopen("C:\\T2Ti\\cte\\exemplo.pdf", 'rb');
				$stream = new Stream($fh);
				return parent::resultFile($response, $stream, 'application/pdf');
			} else {
				return parent::handleError($response, 418, $retorno, null);
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Erro no Servidor [Transmitir CT-e]', $e);
		}
	}

}
