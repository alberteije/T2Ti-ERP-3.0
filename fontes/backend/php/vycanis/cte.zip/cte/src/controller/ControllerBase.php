<?php

class ControllerBase
{
    public function handleError($response, $code, $message, $exception)
    {
        $jsonErro = new ResultJsonError($code, $message, $exception);
        $retorno = json_encode($jsonErro);
        $response->getBody()->write($retorno);
        return $response
            ->withStatus($code)
            ->withHeader('Content-Type', 'application/json');
    }

    public function browserOptionsResponse($request, $response, $args)
    {
        return $response;
    }

    public function resultFile($response, $stream, $tipoArquivo) {
        return $response
        ->withHeader('Content-Type', $tipoArquivo)
        ->withHeader('Content-Description', 'File Transfer')
        ->withHeader('Content-Transfer-Encoding', 'binary')
        //->withHeader('Content-Disposition', 'attachment; filename="' . basename($file) . '"') - to force download
        ->withHeader('Expires', '0')
        ->withHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0')
        ->withHeader('Pragma', 'public')
        ->withBody($stream);     
    }
}