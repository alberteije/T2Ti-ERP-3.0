<?php
class CteDocumentoAnteriorIdController extends ControllerBase
{

		private $cteDocumentoAnteriorIdService = null;

		public function __construct()
		{	 
				$this->cteDocumentoAnteriorIdService = new CteDocumentoAnteriorIdService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteDocumentoAnteriorIdService->getListFilter($filter);
						} else {
								$resultList = $this->cteDocumentoAnteriorIdService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteDocumentoAnteriorId]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteDocumentoAnteriorIdService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteDocumentoAnteriorId]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteDocumentoAnteriorId]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteDocumentoAnteriorId]', null);
						}

						$objModel = new CteDocumentoAnteriorIdModel();
						$objModel->mapping($objJson);

						$this->cteDocumentoAnteriorIdService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteDocumentoAnteriorId]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteDocumentoAnteriorIdService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteDocumentoAnteriorId]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteDocumentoAnteriorIdService->save($objFromDatabase);
								$objFromDatabase = $this->cteDocumentoAnteriorIdService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteDocumentoAnteriorId]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteDocumentoAnteriorIdService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteDocumentoAnteriorId]', null);
						} else {
								$this->cteDocumentoAnteriorIdService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteDocumentoAnteriorId]', $e);
				}
		}
}
