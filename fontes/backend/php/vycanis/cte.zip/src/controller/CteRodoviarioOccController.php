<?php
class CteRodoviarioOccController extends ControllerBase
{

		private $cteRodoviarioOccService = null;

		public function __construct()
		{	 
				$this->cteRodoviarioOccService = new CteRodoviarioOccService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteRodoviarioOccService->getListFilter($filter);
						} else {
								$resultList = $this->cteRodoviarioOccService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteRodoviarioOcc]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteRodoviarioOccService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteRodoviarioOcc]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteRodoviarioOcc]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteRodoviarioOcc]', null);
						}

						$objModel = new CteRodoviarioOccModel();
						$objModel->mapping($objJson);

						$this->cteRodoviarioOccService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteRodoviarioOcc]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteRodoviarioOccService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteRodoviarioOcc]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteRodoviarioOccService->save($objFromDatabase);
								$objFromDatabase = $this->cteRodoviarioOccService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteRodoviarioOcc]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteRodoviarioOccService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteRodoviarioOcc]', null);
						} else {
								$this->cteRodoviarioOccService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteRodoviarioOcc]', $e);
				}
		}
}
