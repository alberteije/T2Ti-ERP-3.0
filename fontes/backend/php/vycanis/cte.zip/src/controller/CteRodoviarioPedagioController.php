<?php
class CteRodoviarioPedagioController extends ControllerBase
{

		private $cteRodoviarioPedagioService = null;

		public function __construct()
		{	 
				$this->cteRodoviarioPedagioService = new CteRodoviarioPedagioService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->cteRodoviarioPedagioService->getListFilter($filter);
						} else {
								$resultList = $this->cteRodoviarioPedagioService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList CteRodoviarioPedagio]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteRodoviarioPedagioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject CteRodoviarioPedagio]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject CteRodoviarioPedagio]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert CteRodoviarioPedagio]', null);
						}

						$objModel = new CteRodoviarioPedagioModel();
						$objModel->mapping($objJson);

						$this->cteRodoviarioPedagioService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert CteRodoviarioPedagio]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->cteRodoviarioPedagioService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update CteRodoviarioPedagio]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->cteRodoviarioPedagioService->save($objFromDatabase);
								$objFromDatabase = $this->cteRodoviarioPedagioService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update CteRodoviarioPedagio]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->cteRodoviarioPedagioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete CteRodoviarioPedagio]', null);
						} else {
								$this->cteRodoviarioPedagioService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete CteRodoviarioPedagio]', $e);
				}
		}
}
