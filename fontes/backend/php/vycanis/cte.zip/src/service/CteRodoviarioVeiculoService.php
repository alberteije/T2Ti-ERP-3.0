<?php
class CteRodoviarioVeiculoService extends ServiceBase
{
  public function getList()
  {
    return CteRodoviarioVeiculoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteRodoviarioVeiculoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteRodoviarioVeiculoModel::find($id);
  }

}