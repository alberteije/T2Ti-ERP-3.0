<?php
class CteRodoviarioLacreService extends ServiceBase
{
  public function getList()
  {
    return CteRodoviarioLacreModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteRodoviarioLacreModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteRodoviarioLacreModel::find($id);
  }

}