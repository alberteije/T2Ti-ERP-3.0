<?php
class CteInfNfCargaLacreService extends ServiceBase
{
  public function getList()
  {
    return CteInfNfCargaLacreModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteInfNfCargaLacreModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteInfNfCargaLacreModel::find($id);
  }

}