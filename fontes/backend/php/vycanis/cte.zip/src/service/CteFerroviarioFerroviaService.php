<?php
class CteFerroviarioFerroviaService extends ServiceBase
{
  public function getList()
  {
    return CteFerroviarioFerroviaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteFerroviarioFerroviaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteFerroviarioFerroviaModel::find($id);
  }

}