<?php
class CteRodoviarioPedagioService extends ServiceBase
{
  public function getList()
  {
    return CteRodoviarioPedagioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CteRodoviarioPedagioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CteRodoviarioPedagioModel::find($id);
  }

}