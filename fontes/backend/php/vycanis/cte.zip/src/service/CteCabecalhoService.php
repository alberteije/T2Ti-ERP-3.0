<?php
use Illuminate\Database\Capsule\Manager as DB;
class CteCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return CteCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return CteCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return CteCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// cteEmitente
		$cteEmitenteModelListJson = $objJson->cteEmitenteModelList;
		if ($cteEmitenteModelListJson != null) {
			for ($i = 0; $i < count($cteEmitenteModelListJson); $i++) {
				$cteEmitente = new CteEmitenteModel();
				$cteEmitente->mapping($cteEmitenteModelListJson[$i]);
				$objModel->cteEmitenteModelList()->save($cteEmitente);
			}
		}

		// cteLocalColeta
		$cteLocalColetaModelListJson = $objJson->cteLocalColetaModelList;
		if ($cteLocalColetaModelListJson != null) {
			for ($i = 0; $i < count($cteLocalColetaModelListJson); $i++) {
				$cteLocalColeta = new CteLocalColetaModel();
				$cteLocalColeta->mapping($cteLocalColetaModelListJson[$i]);
				$objModel->cteLocalColetaModelList()->save($cteLocalColeta);
			}
		}

		// cteTomador
		$cteTomadorModelListJson = $objJson->cteTomadorModelList;
		if ($cteTomadorModelListJson != null) {
			for ($i = 0; $i < count($cteTomadorModelListJson); $i++) {
				$cteTomador = new CteTomadorModel();
				$cteTomador->mapping($cteTomadorModelListJson[$i]);
				$objModel->cteTomadorModelList()->save($cteTomador);
			}
		}

		// ctePassagem
		$ctePassagemModelListJson = $objJson->ctePassagemModelList;
		if ($ctePassagemModelListJson != null) {
			for ($i = 0; $i < count($ctePassagemModelListJson); $i++) {
				$ctePassagem = new CtePassagemModel();
				$ctePassagem->mapping($ctePassagemModelListJson[$i]);
				$objModel->ctePassagemModelList()->save($ctePassagem);
			}
		}

		// cteRemetente
		$cteRemetenteModelListJson = $objJson->cteRemetenteModelList;
		if ($cteRemetenteModelListJson != null) {
			for ($i = 0; $i < count($cteRemetenteModelListJson); $i++) {
				$cteRemetente = new CteRemetenteModel();
				$cteRemetente->mapping($cteRemetenteModelListJson[$i]);
				$objModel->cteRemetenteModelList()->save($cteRemetente);
			}
		}

		// cteExpedidor
		$cteExpedidorModelListJson = $objJson->cteExpedidorModelList;
		if ($cteExpedidorModelListJson != null) {
			for ($i = 0; $i < count($cteExpedidorModelListJson); $i++) {
				$cteExpedidor = new CteExpedidorModel();
				$cteExpedidor->mapping($cteExpedidorModelListJson[$i]);
				$objModel->cteExpedidorModelList()->save($cteExpedidor);
			}
		}

		// cteRecebedor
		$cteRecebedorModelListJson = $objJson->cteRecebedorModelList;
		if ($cteRecebedorModelListJson != null) {
			for ($i = 0; $i < count($cteRecebedorModelListJson); $i++) {
				$cteRecebedor = new CteRecebedorModel();
				$cteRecebedor->mapping($cteRecebedorModelListJson[$i]);
				$objModel->cteRecebedorModelList()->save($cteRecebedor);
			}
		}

		// cteDestinatario
		$cteDestinatarioModelListJson = $objJson->cteDestinatarioModelList;
		if ($cteDestinatarioModelListJson != null) {
			for ($i = 0; $i < count($cteDestinatarioModelListJson); $i++) {
				$cteDestinatario = new CteDestinatarioModel();
				$cteDestinatario->mapping($cteDestinatarioModelListJson[$i]);
				$objModel->cteDestinatarioModelList()->save($cteDestinatario);
			}
		}

		// cteLocalEntrega
		$cteLocalEntregaModelListJson = $objJson->cteLocalEntregaModelList;
		if ($cteLocalEntregaModelListJson != null) {
			for ($i = 0; $i < count($cteLocalEntregaModelListJson); $i++) {
				$cteLocalEntrega = new CteLocalEntregaModel();
				$cteLocalEntrega->mapping($cteLocalEntregaModelListJson[$i]);
				$objModel->cteLocalEntregaModelList()->save($cteLocalEntrega);
			}
		}

		// cteComponente
		$cteComponenteModelListJson = $objJson->cteComponenteModelList;
		if ($cteComponenteModelListJson != null) {
			for ($i = 0; $i < count($cteComponenteModelListJson); $i++) {
				$cteComponente = new CteComponenteModel();
				$cteComponente->mapping($cteComponenteModelListJson[$i]);
				$objModel->cteComponenteModelList()->save($cteComponente);
			}
		}

		// cteCarga
		$cteCargaModelListJson = $objJson->cteCargaModelList;
		if ($cteCargaModelListJson != null) {
			for ($i = 0; $i < count($cteCargaModelListJson); $i++) {
				$cteCarga = new CteCargaModel();
				$cteCarga->mapping($cteCargaModelListJson[$i]);
				$objModel->cteCargaModelList()->save($cteCarga);
			}
		}

		// cteInformacaoNfOutros
		$cteInformacaoNfOutrosModelListJson = $objJson->cteInformacaoNfOutrosModelList;
		if ($cteInformacaoNfOutrosModelListJson != null) {
			for ($i = 0; $i < count($cteInformacaoNfOutrosModelListJson); $i++) {
				$cteInformacaoNfOutros = new CteInformacaoNfOutrosModel();
				$cteInformacaoNfOutros->mapping($cteInformacaoNfOutrosModelListJson[$i]);
				$objModel->cteInformacaoNfOutrosModelList()->save($cteInformacaoNfOutros);
			}
		}

		// cteSeguro
		$cteSeguroModelListJson = $objJson->cteSeguroModelList;
		if ($cteSeguroModelListJson != null) {
			for ($i = 0; $i < count($cteSeguroModelListJson); $i++) {
				$cteSeguro = new CteSeguroModel();
				$cteSeguro->mapping($cteSeguroModelListJson[$i]);
				$objModel->cteSeguroModelList()->save($cteSeguro);
			}
		}

		// ctePerigoso
		$ctePerigosoModelListJson = $objJson->ctePerigosoModelList;
		if ($ctePerigosoModelListJson != null) {
			for ($i = 0; $i < count($ctePerigosoModelListJson); $i++) {
				$ctePerigoso = new CtePerigosoModel();
				$ctePerigoso->mapping($ctePerigosoModelListJson[$i]);
				$objModel->ctePerigosoModelList()->save($ctePerigoso);
			}
		}

		// cteVeiculoNovo
		$cteVeiculoNovoModelListJson = $objJson->cteVeiculoNovoModelList;
		if ($cteVeiculoNovoModelListJson != null) {
			for ($i = 0; $i < count($cteVeiculoNovoModelListJson); $i++) {
				$cteVeiculoNovo = new CteVeiculoNovoModel();
				$cteVeiculoNovo->mapping($cteVeiculoNovoModelListJson[$i]);
				$objModel->cteVeiculoNovoModelList()->save($cteVeiculoNovo);
			}
		}

		// cteFatura
		$cteFaturaModelListJson = $objJson->cteFaturaModelList;
		if ($cteFaturaModelListJson != null) {
			for ($i = 0; $i < count($cteFaturaModelListJson); $i++) {
				$cteFatura = new CteFaturaModel();
				$cteFatura->mapping($cteFaturaModelListJson[$i]);
				$objModel->cteFaturaModelList()->save($cteFatura);
			}
		}

		// cteDuplicata
		$cteDuplicataModelListJson = $objJson->cteDuplicataModelList;
		if ($cteDuplicataModelListJson != null) {
			for ($i = 0; $i < count($cteDuplicataModelListJson); $i++) {
				$cteDuplicata = new CteDuplicataModel();
				$cteDuplicata->mapping($cteDuplicataModelListJson[$i]);
				$objModel->cteDuplicataModelList()->save($cteDuplicata);
			}
		}

		// cteRodoviario
		$cteRodoviarioModelListJson = $objJson->cteRodoviarioModelList;
		if ($cteRodoviarioModelListJson != null) {
			for ($i = 0; $i < count($cteRodoviarioModelListJson); $i++) {
				$cteRodoviario = new CteRodoviarioModel();
				$cteRodoviario->mapping($cteRodoviarioModelListJson[$i]);
				$objModel->cteRodoviarioModelList()->save($cteRodoviario);
			}
		}

		// cteAereo
		$cteAereoModelListJson = $objJson->cteAereoModelList;
		if ($cteAereoModelListJson != null) {
			for ($i = 0; $i < count($cteAereoModelListJson); $i++) {
				$cteAereo = new CteAereoModel();
				$cteAereo->mapping($cteAereoModelListJson[$i]);
				$objModel->cteAereoModelList()->save($cteAereo);
			}
		}

		// cteAquaviario
		$cteAquaviarioModelListJson = $objJson->cteAquaviarioModelList;
		if ($cteAquaviarioModelListJson != null) {
			for ($i = 0; $i < count($cteAquaviarioModelListJson); $i++) {
				$cteAquaviario = new CteAquaviarioModel();
				$cteAquaviario->mapping($cteAquaviarioModelListJson[$i]);
				$objModel->cteAquaviarioModelList()->save($cteAquaviario);
			}
		}

		// cteFerroviario
		$cteFerroviarioModelListJson = $objJson->cteFerroviarioModelList;
		if ($cteFerroviarioModelListJson != null) {
			for ($i = 0; $i < count($cteFerroviarioModelListJson); $i++) {
				$cteFerroviario = new CteFerroviarioModel();
				$cteFerroviario->mapping($cteFerroviarioModelListJson[$i]);
				$objModel->cteFerroviarioModelList()->save($cteFerroviario);
			}
		}

		// cteDutoviario
		$cteDutoviarioModelListJson = $objJson->cteDutoviarioModelList;
		if ($cteDutoviarioModelListJson != null) {
			for ($i = 0; $i < count($cteDutoviarioModelListJson); $i++) {
				$cteDutoviario = new CteDutoviarioModel();
				$cteDutoviario->mapping($cteDutoviarioModelListJson[$i]);
				$objModel->cteDutoviarioModelList()->save($cteDutoviario);
			}
		}

		// cteMultimodal
		$cteMultimodalModelListJson = $objJson->cteMultimodalModelList;
		if ($cteMultimodalModelListJson != null) {
			for ($i = 0; $i < count($cteMultimodalModelListJson); $i++) {
				$cteMultimodal = new CteMultimodalModel();
				$cteMultimodal->mapping($cteMultimodalModelListJson[$i]);
				$objModel->cteMultimodalModelList()->save($cteMultimodal);
			}
		}

	}	

	public function deleteChildren($object)
	{
		CteEmitenteModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteLocalColetaModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteTomadorModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CtePassagemModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteRemetenteModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteExpedidorModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteRecebedorModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteDestinatarioModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteLocalEntregaModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteComponenteModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteCargaModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteInformacaoNfOutrosModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteSeguroModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CtePerigosoModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteVeiculoNovoModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteFaturaModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteDuplicataModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteRodoviarioModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteAereoModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteAquaviarioModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteFerroviarioModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteDutoviarioModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
		CteMultimodalModel::where('id_cte_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}