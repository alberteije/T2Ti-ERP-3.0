<?php
declare(strict_types=1);

class CteInformacaoNfOutrosModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_informacao_nf_outros';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroRomaneioAttribute()
	{
		return $this->attributes['numero_romaneio'];
	}

	public function setNumeroRomaneioAttribute($numeroRomaneio)
	{
		$this->attributes['numero_romaneio'] = $numeroRomaneio;
	}

	public function getNumeroPedidoAttribute()
	{
		return $this->attributes['numero_pedido'];
	}

	public function setNumeroPedidoAttribute($numeroPedido)
	{
		$this->attributes['numero_pedido'] = $numeroPedido;
	}

	public function getChaveAcessoNfeAttribute()
	{
		return $this->attributes['chave_acesso_nfe'];
	}

	public function setChaveAcessoNfeAttribute($chaveAcessoNfe)
	{
		$this->attributes['chave_acesso_nfe'] = $chaveAcessoNfe;
	}

	public function getCodigoModeloAttribute()
	{
		return $this->attributes['codigo_modelo'];
	}

	public function setCodigoModeloAttribute($codigoModelo)
	{
		$this->attributes['codigo_modelo'] = $codigoModelo;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataEmissaoAttribute()
	{
		return $this->attributes['data_emissao'];
	}

	public function setDataEmissaoAttribute($dataEmissao)
	{
		$this->attributes['data_emissao'] = $dataEmissao;
	}

	public function getUfEmitenteAttribute()
	{
		return $this->attributes['uf_emitente'];
	}

	public function setUfEmitenteAttribute($ufEmitente)
	{
		$this->attributes['uf_emitente'] = $ufEmitente;
	}

	public function getBaseCalculoIcmsAttribute()
	{
		return (double)$this->attributes['base_calculo_icms'];
	}

	public function setBaseCalculoIcmsAttribute($baseCalculoIcms)
	{
		$this->attributes['base_calculo_icms'] = $baseCalculoIcms;
	}

	public function getValorIcmsAttribute()
	{
		return (double)$this->attributes['valor_icms'];
	}

	public function setValorIcmsAttribute($valorIcms)
	{
		$this->attributes['valor_icms'] = $valorIcms;
	}

	public function getBaseCalculoIcmsStAttribute()
	{
		return (double)$this->attributes['base_calculo_icms_st'];
	}

	public function setBaseCalculoIcmsStAttribute($baseCalculoIcmsSt)
	{
		$this->attributes['base_calculo_icms_st'] = $baseCalculoIcmsSt;
	}

	public function getValorIcmsStAttribute()
	{
		return (double)$this->attributes['valor_icms_st'];
	}

	public function setValorIcmsStAttribute($valorIcmsSt)
	{
		$this->attributes['valor_icms_st'] = $valorIcmsSt;
	}

	public function getValorTotalProdutosAttribute()
	{
		return (double)$this->attributes['valor_total_produtos'];
	}

	public function setValorTotalProdutosAttribute($valorTotalProdutos)
	{
		$this->attributes['valor_total_produtos'] = $valorTotalProdutos;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getCfopPredominanteAttribute()
	{
		return $this->attributes['cfop_predominante'];
	}

	public function setCfopPredominanteAttribute($cfopPredominante)
	{
		$this->attributes['cfop_predominante'] = $cfopPredominante;
	}

	public function getPesoTotalKgAttribute()
	{
		return (double)$this->attributes['peso_total_kg'];
	}

	public function setPesoTotalKgAttribute($pesoTotalKg)
	{
		$this->attributes['peso_total_kg'] = $pesoTotalKg;
	}

	public function getPinSuframaAttribute()
	{
		return $this->attributes['pin_suframa'];
	}

	public function setPinSuframaAttribute($pinSuframa)
	{
		$this->attributes['pin_suframa'] = $pinSuframa;
	}

	public function getDataPrevistaEntregaAttribute()
	{
		return $this->attributes['data_prevista_entrega'];
	}

	public function setDataPrevistaEntregaAttribute($dataPrevistaEntrega)
	{
		$this->attributes['data_prevista_entrega'] = $dataPrevistaEntrega;
	}

	public function getOutroTipoDocOrigAttribute()
	{
		return $this->attributes['outro_tipo_doc_orig'];
	}

	public function setOutroTipoDocOrigAttribute($outroTipoDocOrig)
	{
		$this->attributes['outro_tipo_doc_orig'] = $outroTipoDocOrig;
	}

	public function getOutroDescricaoAttribute()
	{
		return $this->attributes['outro_descricao'];
	}

	public function setOutroDescricaoAttribute($outroDescricao)
	{
		$this->attributes['outro_descricao'] = $outroDescricao;
	}

	public function getOutroValorDocumentoAttribute()
	{
		return (double)$this->attributes['outro_valor_documento'];
	}

	public function setOutroValorDocumentoAttribute($outroValorDocumento)
	{
		$this->attributes['outro_valor_documento'] = $outroValorDocumento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroRomaneioAttribute($object->numeroRomaneio);
				$this->setNumeroPedidoAttribute($object->numeroPedido);
				$this->setChaveAcessoNfeAttribute($object->chaveAcessoNfe);
				$this->setCodigoModeloAttribute($object->codigoModelo);
				$this->setSerieAttribute($object->serie);
				$this->setNumeroAttribute($object->numero);
				$this->setDataEmissaoAttribute($object->dataEmissao);
				$this->setUfEmitenteAttribute($object->ufEmitente);
				$this->setBaseCalculoIcmsAttribute($object->baseCalculoIcms);
				$this->setValorIcmsAttribute($object->valorIcms);
				$this->setBaseCalculoIcmsStAttribute($object->baseCalculoIcmsSt);
				$this->setValorIcmsStAttribute($object->valorIcmsSt);
				$this->setValorTotalProdutosAttribute($object->valorTotalProdutos);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setCfopPredominanteAttribute($object->cfopPredominante);
				$this->setPesoTotalKgAttribute($object->pesoTotalKg);
				$this->setPinSuframaAttribute($object->pinSuframa);
				$this->setDataPrevistaEntregaAttribute($object->dataPrevistaEntrega);
				$this->setOutroTipoDocOrigAttribute($object->outroTipoDocOrig);
				$this->setOutroDescricaoAttribute($object->outroDescricao);
				$this->setOutroValorDocumentoAttribute($object->outroValorDocumento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroRomaneio' => $this->getNumeroRomaneioAttribute(),
				'numeroPedido' => $this->getNumeroPedidoAttribute(),
				'chaveAcessoNfe' => $this->getChaveAcessoNfeAttribute(),
				'codigoModelo' => $this->getCodigoModeloAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataEmissao' => $this->getDataEmissaoAttribute(),
				'ufEmitente' => $this->getUfEmitenteAttribute(),
				'baseCalculoIcms' => $this->getBaseCalculoIcmsAttribute(),
				'valorIcms' => $this->getValorIcmsAttribute(),
				'baseCalculoIcmsSt' => $this->getBaseCalculoIcmsStAttribute(),
				'valorIcmsSt' => $this->getValorIcmsStAttribute(),
				'valorTotalProdutos' => $this->getValorTotalProdutosAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'cfopPredominante' => $this->getCfopPredominanteAttribute(),
				'pesoTotalKg' => $this->getPesoTotalKgAttribute(),
				'pinSuframa' => $this->getPinSuframaAttribute(),
				'dataPrevistaEntrega' => $this->getDataPrevistaEntregaAttribute(),
				'outroTipoDocOrig' => $this->getOutroTipoDocOrigAttribute(),
				'outroDescricao' => $this->getOutroDescricaoAttribute(),
				'outroValorDocumento' => $this->getOutroValorDocumentoAttribute(),
			];
	}
}