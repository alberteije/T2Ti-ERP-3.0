<?php
declare(strict_types=1);

class CteRodoviarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_rodoviario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getRntrcAttribute()
	{
		return $this->attributes['rntrc'];
	}

	public function setRntrcAttribute($rntrc)
	{
		$this->attributes['rntrc'] = $rntrc;
	}

	public function getDataPrevistaEntregaAttribute()
	{
		return $this->attributes['data_prevista_entrega'];
	}

	public function setDataPrevistaEntregaAttribute($dataPrevistaEntrega)
	{
		$this->attributes['data_prevista_entrega'] = $dataPrevistaEntrega;
	}

	public function getIndicadorLotacaoAttribute()
	{
		return $this->attributes['indicador_lotacao'];
	}

	public function setIndicadorLotacaoAttribute($indicadorLotacao)
	{
		$this->attributes['indicador_lotacao'] = $indicadorLotacao;
	}

	public function getCiotAttribute()
	{
		return $this->attributes['ciot'];
	}

	public function setCiotAttribute($ciot)
	{
		$this->attributes['ciot'] = $ciot;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setRntrcAttribute($object->rntrc);
				$this->setDataPrevistaEntregaAttribute($object->dataPrevistaEntrega);
				$this->setIndicadorLotacaoAttribute($object->indicadorLotacao);
				$this->setCiotAttribute($object->ciot);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'rntrc' => $this->getRntrcAttribute(),
				'dataPrevistaEntrega' => $this->getDataPrevistaEntregaAttribute(),
				'indicadorLotacao' => $this->getIndicadorLotacaoAttribute(),
				'ciot' => $this->getCiotAttribute(),
			];
	}
}