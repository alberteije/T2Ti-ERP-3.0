<?php
declare(strict_types=1);

class CteRodoviarioLacreModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_rodoviario_lacre';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function cteRodoviarioModel()
	{
		return $this->belongsTo(CteRodoviarioModel::class, 'id_cte_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);

				// link objects - lookups
				$cteRodoviarioModel = new CteRodoviarioModel();
				$cteRodoviarioModel->mapping($object->cteRodoviarioModel);
				$this->cteRodoviarioModel()->associate($cteRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'cteRodoviarioModel' => $this->cteRodoviarioModel,
			];
	}
}