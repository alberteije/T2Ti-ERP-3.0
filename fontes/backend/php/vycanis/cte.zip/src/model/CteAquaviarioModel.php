<?php
declare(strict_types=1);

class CteAquaviarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_aquaviario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorPrestacaoAttribute()
	{
		return (double)$this->attributes['valor_prestacao'];
	}

	public function setValorPrestacaoAttribute($valorPrestacao)
	{
		$this->attributes['valor_prestacao'] = $valorPrestacao;
	}

	public function getAfrmmAttribute()
	{
		return (double)$this->attributes['afrmm'];
	}

	public function setAfrmmAttribute($afrmm)
	{
		$this->attributes['afrmm'] = $afrmm;
	}

	public function getNumeroBookingAttribute()
	{
		return $this->attributes['numero_booking'];
	}

	public function setNumeroBookingAttribute($numeroBooking)
	{
		$this->attributes['numero_booking'] = $numeroBooking;
	}

	public function getNumeroControleAttribute()
	{
		return $this->attributes['numero_controle'];
	}

	public function setNumeroControleAttribute($numeroControle)
	{
		$this->attributes['numero_controle'] = $numeroControle;
	}

	public function getIdNavioAttribute()
	{
		return $this->attributes['id_navio'];
	}

	public function setIdNavioAttribute($idNavio)
	{
		$this->attributes['id_navio'] = $idNavio;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorPrestacaoAttribute($object->valorPrestacao);
				$this->setAfrmmAttribute($object->afrmm);
				$this->setNumeroBookingAttribute($object->numeroBooking);
				$this->setNumeroControleAttribute($object->numeroControle);
				$this->setIdNavioAttribute($object->idNavio);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valorPrestacao' => $this->getValorPrestacaoAttribute(),
				'afrmm' => $this->getAfrmmAttribute(),
				'numeroBooking' => $this->getNumeroBookingAttribute(),
				'numeroControle' => $this->getNumeroControleAttribute(),
				'idNavio' => $this->getIdNavioAttribute(),
			];
	}
}