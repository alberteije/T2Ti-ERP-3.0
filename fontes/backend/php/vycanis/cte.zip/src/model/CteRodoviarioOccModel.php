<?php
declare(strict_types=1);

class CteRodoviarioOccModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_rodoviario_occ';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function cteRodoviarioModel()
	{
		return $this->belongsTo(CteRodoviarioModel::class, 'id_cte_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataEmissaoAttribute()
	{
		return $this->attributes['data_emissao'];
	}

	public function setDataEmissaoAttribute($dataEmissao)
	{
		$this->attributes['data_emissao'] = $dataEmissao;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getCodigoInternoAttribute()
	{
		return $this->attributes['codigo_interno'];
	}

	public function setCodigoInternoAttribute($codigoInterno)
	{
		$this->attributes['codigo_interno'] = $codigoInterno;
	}

	public function getIeAttribute()
	{
		return $this->attributes['ie'];
	}

	public function setIeAttribute($ie)
	{
		$this->attributes['ie'] = $ie;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getTelefoneAttribute()
	{
		return $this->attributes['telefone'];
	}

	public function setTelefoneAttribute($telefone)
	{
		$this->attributes['telefone'] = $telefone;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setSerieAttribute($object->serie);
				$this->setNumeroAttribute($object->numero);
				$this->setDataEmissaoAttribute($object->dataEmissao);
				$this->setCnpjAttribute($object->cnpj);
				$this->setCodigoInternoAttribute($object->codigoInterno);
				$this->setIeAttribute($object->ie);
				$this->setUfAttribute($object->uf);
				$this->setTelefoneAttribute($object->telefone);

				// link objects - lookups
				$cteRodoviarioModel = new CteRodoviarioModel();
				$cteRodoviarioModel->mapping($object->cteRodoviarioModel);
				$this->cteRodoviarioModel()->associate($cteRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataEmissao' => $this->getDataEmissaoAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'codigoInterno' => $this->getCodigoInternoAttribute(),
				'ie' => $this->getIeAttribute(),
				'uf' => $this->getUfAttribute(),
				'telefone' => $this->getTelefoneAttribute(),
				'cteRodoviarioModel' => $this->cteRodoviarioModel,
			];
	}
}