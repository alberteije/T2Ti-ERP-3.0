<?php
declare(strict_types=1);

class CtePassagemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_passagem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getSiglaPassagemAttribute()
	{
		return $this->attributes['sigla_passagem'];
	}

	public function setSiglaPassagemAttribute($siglaPassagem)
	{
		$this->attributes['sigla_passagem'] = $siglaPassagem;
	}

	public function getSiglaDestinoAttribute()
	{
		return $this->attributes['sigla_destino'];
	}

	public function setSiglaDestinoAttribute($siglaDestino)
	{
		$this->attributes['sigla_destino'] = $siglaDestino;
	}

	public function getRotaAttribute()
	{
		return $this->attributes['rota'];
	}

	public function setRotaAttribute($rota)
	{
		$this->attributes['rota'] = $rota;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setSiglaPassagemAttribute($object->siglaPassagem);
				$this->setSiglaDestinoAttribute($object->siglaDestino);
				$this->setRotaAttribute($object->rota);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'siglaPassagem' => $this->getSiglaPassagemAttribute(),
				'siglaDestino' => $this->getSiglaDestinoAttribute(),
				'rota' => $this->getRotaAttribute(),
			];
	}
}