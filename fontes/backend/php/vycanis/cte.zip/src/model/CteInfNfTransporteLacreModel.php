<?php
declare(strict_types=1);

class CteInfNfTransporteLacreModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_inf_nf_transporte_lacre';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteInformacaoNfTransporteModel',
	];

	/**
		* Relations
		*/
	public function cteInformacaoNfTransporteModel()
	{
		return $this->belongsTo(CteInformacaoNfTransporteModel::class, 'id_cte_informacao_nf_transporte', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);

				// link objects - lookups
				$cteInformacaoNfTransporteModel = new CteInformacaoNfTransporteModel();
				$cteInformacaoNfTransporteModel->mapping($object->cteInformacaoNfTransporteModel);
				$this->cteInformacaoNfTransporteModel()->associate($cteInformacaoNfTransporteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'cteInformacaoNfTransporteModel' => $this->cteInformacaoNfTransporteModel,
			];
	}
}