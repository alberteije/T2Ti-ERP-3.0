<?php
declare(strict_types=1);

class CtePerigosoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_perigoso';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroOnuAttribute()
	{
		return $this->attributes['numero_onu'];
	}

	public function setNumeroOnuAttribute($numeroOnu)
	{
		$this->attributes['numero_onu'] = $numeroOnu;
	}

	public function getNomeApropriadoAttribute()
	{
		return $this->attributes['nome_apropriado'];
	}

	public function setNomeApropriadoAttribute($nomeApropriado)
	{
		$this->attributes['nome_apropriado'] = $nomeApropriado;
	}

	public function getClasseRiscoAttribute()
	{
		return $this->attributes['classe_risco'];
	}

	public function setClasseRiscoAttribute($classeRisco)
	{
		$this->attributes['classe_risco'] = $classeRisco;
	}

	public function getGrupoEmbalagemAttribute()
	{
		return $this->attributes['grupo_embalagem'];
	}

	public function setGrupoEmbalagemAttribute($grupoEmbalagem)
	{
		$this->attributes['grupo_embalagem'] = $grupoEmbalagem;
	}

	public function getQuantidadeTotalProdutoAttribute()
	{
		return $this->attributes['quantidade_total_produto'];
	}

	public function setQuantidadeTotalProdutoAttribute($quantidadeTotalProduto)
	{
		$this->attributes['quantidade_total_produto'] = $quantidadeTotalProduto;
	}

	public function getQuantidadeTipoVolumeAttribute()
	{
		return $this->attributes['quantidade_tipo_volume'];
	}

	public function setQuantidadeTipoVolumeAttribute($quantidadeTipoVolume)
	{
		$this->attributes['quantidade_tipo_volume'] = $quantidadeTipoVolume;
	}

	public function getPontoFulgorAttribute()
	{
		return $this->attributes['ponto_fulgor'];
	}

	public function setPontoFulgorAttribute($pontoFulgor)
	{
		$this->attributes['ponto_fulgor'] = $pontoFulgor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroOnuAttribute($object->numeroOnu);
				$this->setNomeApropriadoAttribute($object->nomeApropriado);
				$this->setClasseRiscoAttribute($object->classeRisco);
				$this->setGrupoEmbalagemAttribute($object->grupoEmbalagem);
				$this->setQuantidadeTotalProdutoAttribute($object->quantidadeTotalProduto);
				$this->setQuantidadeTipoVolumeAttribute($object->quantidadeTipoVolume);
				$this->setPontoFulgorAttribute($object->pontoFulgor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroOnu' => $this->getNumeroOnuAttribute(),
				'nomeApropriado' => $this->getNomeApropriadoAttribute(),
				'classeRisco' => $this->getClasseRiscoAttribute(),
				'grupoEmbalagem' => $this->getGrupoEmbalagemAttribute(),
				'quantidadeTotalProduto' => $this->getQuantidadeTotalProdutoAttribute(),
				'quantidadeTipoVolume' => $this->getQuantidadeTipoVolumeAttribute(),
				'pontoFulgor' => $this->getPontoFulgorAttribute(),
			];
	}
}