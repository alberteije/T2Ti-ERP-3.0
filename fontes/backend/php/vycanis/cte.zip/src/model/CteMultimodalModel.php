<?php
declare(strict_types=1);

class CteMultimodalModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_multimodal';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCotmAttribute()
	{
		return $this->attributes['cotm'];
	}

	public function setCotmAttribute($cotm)
	{
		$this->attributes['cotm'] = $cotm;
	}

	public function getIndicadorNegociavelAttribute()
	{
		return $this->attributes['indicador_negociavel'];
	}

	public function setIndicadorNegociavelAttribute($indicadorNegociavel)
	{
		$this->attributes['indicador_negociavel'] = $indicadorNegociavel;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCotmAttribute($object->cotm);
				$this->setIndicadorNegociavelAttribute($object->indicadorNegociavel);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cotm' => $this->getCotmAttribute(),
				'indicadorNegociavel' => $this->getIndicadorNegociavelAttribute(),
			];
	}
}