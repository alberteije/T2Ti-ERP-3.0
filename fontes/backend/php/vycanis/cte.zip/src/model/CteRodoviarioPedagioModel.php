<?php
declare(strict_types=1);

class CteRodoviarioPedagioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_rodoviario_pedagio';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function cteRodoviarioModel()
	{
		return $this->belongsTo(CteRodoviarioModel::class, 'id_cte_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjFornecedorAttribute()
	{
		return $this->attributes['cnpj_fornecedor'];
	}

	public function setCnpjFornecedorAttribute($cnpjFornecedor)
	{
		$this->attributes['cnpj_fornecedor'] = $cnpjFornecedor;
	}

	public function getComprovanteCompraAttribute()
	{
		return $this->attributes['comprovante_compra'];
	}

	public function setComprovanteCompraAttribute($comprovanteCompra)
	{
		$this->attributes['comprovante_compra'] = $comprovanteCompra;
	}

	public function getCnpjResponsavelAttribute()
	{
		return $this->attributes['cnpj_responsavel'];
	}

	public function setCnpjResponsavelAttribute($cnpjResponsavel)
	{
		$this->attributes['cnpj_responsavel'] = $cnpjResponsavel;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjFornecedorAttribute($object->cnpjFornecedor);
				$this->setComprovanteCompraAttribute($object->comprovanteCompra);
				$this->setCnpjResponsavelAttribute($object->cnpjResponsavel);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
				$cteRodoviarioModel = new CteRodoviarioModel();
				$cteRodoviarioModel->mapping($object->cteRodoviarioModel);
				$this->cteRodoviarioModel()->associate($cteRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpjFornecedor' => $this->getCnpjFornecedorAttribute(),
				'comprovanteCompra' => $this->getComprovanteCompraAttribute(),
				'cnpjResponsavel' => $this->getCnpjResponsavelAttribute(),
				'valor' => $this->getValorAttribute(),
				'cteRodoviarioModel' => $this->cteRodoviarioModel,
			];
	}
}