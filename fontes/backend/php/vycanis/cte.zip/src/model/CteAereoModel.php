<?php
declare(strict_types=1);

class CteAereoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_aereo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroMinutaAttribute()
	{
		return $this->attributes['numero_minuta'];
	}

	public function setNumeroMinutaAttribute($numeroMinuta)
	{
		$this->attributes['numero_minuta'] = $numeroMinuta;
	}

	public function getNumeroConhecimentoAttribute()
	{
		return $this->attributes['numero_conhecimento'];
	}

	public function setNumeroConhecimentoAttribute($numeroConhecimento)
	{
		$this->attributes['numero_conhecimento'] = $numeroConhecimento;
	}

	public function getDataPrevistaEntregaAttribute()
	{
		return $this->attributes['data_prevista_entrega'];
	}

	public function setDataPrevistaEntregaAttribute($dataPrevistaEntrega)
	{
		$this->attributes['data_prevista_entrega'] = $dataPrevistaEntrega;
	}

	public function getIdEmissorAttribute()
	{
		return $this->attributes['id_emissor'];
	}

	public function setIdEmissorAttribute($idEmissor)
	{
		$this->attributes['id_emissor'] = $idEmissor;
	}

	public function getIdInternaTomadorAttribute()
	{
		return $this->attributes['id_interna_tomador'];
	}

	public function setIdInternaTomadorAttribute($idInternaTomador)
	{
		$this->attributes['id_interna_tomador'] = $idInternaTomador;
	}

	public function getTarifaClasseAttribute()
	{
		return $this->attributes['tarifa_classe'];
	}

	public function setTarifaClasseAttribute($tarifaClasse)
	{
		$this->attributes['tarifa_classe'] = $tarifaClasse;
	}

	public function getTarifaCodigoAttribute()
	{
		return $this->attributes['tarifa_codigo'];
	}

	public function setTarifaCodigoAttribute($tarifaCodigo)
	{
		$this->attributes['tarifa_codigo'] = $tarifaCodigo;
	}

	public function getTarifaValorAttribute()
	{
		return (double)$this->attributes['tarifa_valor'];
	}

	public function setTarifaValorAttribute($tarifaValor)
	{
		$this->attributes['tarifa_valor'] = $tarifaValor;
	}

	public function getCargaDimensaoAttribute()
	{
		return $this->attributes['carga_dimensao'];
	}

	public function setCargaDimensaoAttribute($cargaDimensao)
	{
		$this->attributes['carga_dimensao'] = $cargaDimensao;
	}

	public function getCargaInformacaoManuseioAttribute()
	{
		return $this->attributes['carga_informacao_manuseio'];
	}

	public function setCargaInformacaoManuseioAttribute($cargaInformacaoManuseio)
	{
		$this->attributes['carga_informacao_manuseio'] = $cargaInformacaoManuseio;
	}

	public function getCargaEspecialAttribute()
	{
		return $this->attributes['carga_especial'];
	}

	public function setCargaEspecialAttribute($cargaEspecial)
	{
		$this->attributes['carga_especial'] = $cargaEspecial;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroMinutaAttribute($object->numeroMinuta);
				$this->setNumeroConhecimentoAttribute($object->numeroConhecimento);
				$this->setDataPrevistaEntregaAttribute($object->dataPrevistaEntrega);
				$this->setIdEmissorAttribute($object->idEmissor);
				$this->setIdInternaTomadorAttribute($object->idInternaTomador);
				$this->setTarifaClasseAttribute($object->tarifaClasse);
				$this->setTarifaCodigoAttribute($object->tarifaCodigo);
				$this->setTarifaValorAttribute($object->tarifaValor);
				$this->setCargaDimensaoAttribute($object->cargaDimensao);
				$this->setCargaInformacaoManuseioAttribute($object->cargaInformacaoManuseio);
				$this->setCargaEspecialAttribute($object->cargaEspecial);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroMinuta' => $this->getNumeroMinutaAttribute(),
				'numeroConhecimento' => $this->getNumeroConhecimentoAttribute(),
				'dataPrevistaEntrega' => $this->getDataPrevistaEntregaAttribute(),
				'idEmissor' => $this->getIdEmissorAttribute(),
				'idInternaTomador' => $this->getIdInternaTomadorAttribute(),
				'tarifaClasse' => $this->getTarifaClasseAttribute(),
				'tarifaCodigo' => $this->getTarifaCodigoAttribute(),
				'tarifaValor' => $this->getTarifaValorAttribute(),
				'cargaDimensao' => $this->getCargaDimensaoAttribute(),
				'cargaInformacaoManuseio' => $this->getCargaInformacaoManuseioAttribute(),
				'cargaEspecial' => $this->getCargaEspecialAttribute(),
			];
	}
}