<?php
declare(strict_types=1);

class CteFerroviarioVagaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_ferroviario_vagao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteFerroviarioModel',
	];

	/**
		* Relations
		*/
	public function cteFerroviarioModel()
	{
		return $this->belongsTo(CteFerroviarioModel::class, 'id_cte_ferroviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroVagaoAttribute()
	{
		return $this->attributes['numero_vagao'];
	}

	public function setNumeroVagaoAttribute($numeroVagao)
	{
		$this->attributes['numero_vagao'] = $numeroVagao;
	}

	public function getCapacidadeAttribute()
	{
		return (double)$this->attributes['capacidade'];
	}

	public function setCapacidadeAttribute($capacidade)
	{
		$this->attributes['capacidade'] = $capacidade;
	}

	public function getTipoVagaoAttribute()
	{
		return $this->attributes['tipo_vagao'];
	}

	public function setTipoVagaoAttribute($tipoVagao)
	{
		$this->attributes['tipo_vagao'] = $tipoVagao;
	}

	public function getPesoRealAttribute()
	{
		return (double)$this->attributes['peso_real'];
	}

	public function setPesoRealAttribute($pesoReal)
	{
		$this->attributes['peso_real'] = $pesoReal;
	}

	public function getPesoBcAttribute()
	{
		return (double)$this->attributes['peso_bc'];
	}

	public function setPesoBcAttribute($pesoBc)
	{
		$this->attributes['peso_bc'] = $pesoBc;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroVagaoAttribute($object->numeroVagao);
				$this->setCapacidadeAttribute($object->capacidade);
				$this->setTipoVagaoAttribute($object->tipoVagao);
				$this->setPesoRealAttribute($object->pesoReal);
				$this->setPesoBcAttribute($object->pesoBc);

				// link objects - lookups
				$cteFerroviarioModel = new CteFerroviarioModel();
				$cteFerroviarioModel->mapping($object->cteFerroviarioModel);
				$this->cteFerroviarioModel()->associate($cteFerroviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroVagao' => $this->getNumeroVagaoAttribute(),
				'capacidade' => $this->getCapacidadeAttribute(),
				'tipoVagao' => $this->getTipoVagaoAttribute(),
				'pesoReal' => $this->getPesoRealAttribute(),
				'pesoBc' => $this->getPesoBcAttribute(),
				'cteFerroviarioModel' => $this->cteFerroviarioModel,
			];
	}
}