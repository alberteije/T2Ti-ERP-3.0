<?php
declare(strict_types=1);

class CteDestinatarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_destinatario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function cteCabecalhoModel()
	{
		return $this->belongsTo(CteCabecalhoModel::class, 'id_cte_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getIeAttribute()
	{
		return $this->attributes['ie'];
	}

	public function setIeAttribute($ie)
	{
		$this->attributes['ie'] = $ie;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getFantasiaAttribute()
	{
		return $this->attributes['fantasia'];
	}

	public function setFantasiaAttribute($fantasia)
	{
		$this->attributes['fantasia'] = $fantasia;
	}

	public function getTelefoneAttribute()
	{
		return $this->attributes['telefone'];
	}

	public function setTelefoneAttribute($telefone)
	{
		$this->attributes['telefone'] = $telefone;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getComplementoAttribute()
	{
		return $this->attributes['complemento'];
	}

	public function setComplementoAttribute($complemento)
	{
		$this->attributes['complemento'] = $complemento;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getCodigoMunicipioAttribute()
	{
		return $this->attributes['codigo_municipio'];
	}

	public function setCodigoMunicipioAttribute($codigoMunicipio)
	{
		$this->attributes['codigo_municipio'] = $codigoMunicipio;
	}

	public function getNomeMunicipioAttribute()
	{
		return $this->attributes['nome_municipio'];
	}

	public function setNomeMunicipioAttribute($nomeMunicipio)
	{
		$this->attributes['nome_municipio'] = $nomeMunicipio;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getCepAttribute()
	{
		return $this->attributes['cep'];
	}

	public function setCepAttribute($cep)
	{
		$this->attributes['cep'] = $cep;
	}

	public function getCodigoPaisAttribute()
	{
		return $this->attributes['codigo_pais'];
	}

	public function setCodigoPaisAttribute($codigoPais)
	{
		$this->attributes['codigo_pais'] = $codigoPais;
	}

	public function getNomePaisAttribute()
	{
		return $this->attributes['nome_pais'];
	}

	public function setNomePaisAttribute($nomePais)
	{
		$this->attributes['nome_pais'] = $nomePais;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjAttribute($object->cnpj);
				$this->setCpfAttribute($object->cpf);
				$this->setIeAttribute($object->ie);
				$this->setNomeAttribute($object->nome);
				$this->setFantasiaAttribute($object->fantasia);
				$this->setTelefoneAttribute($object->telefone);
				$this->setLogradouroAttribute($object->logradouro);
				$this->setNumeroAttribute($object->numero);
				$this->setComplementoAttribute($object->complemento);
				$this->setBairroAttribute($object->bairro);
				$this->setCodigoMunicipioAttribute($object->codigoMunicipio);
				$this->setNomeMunicipioAttribute($object->nomeMunicipio);
				$this->setUfAttribute($object->uf);
				$this->setCepAttribute($object->cep);
				$this->setCodigoPaisAttribute($object->codigoPais);
				$this->setNomePaisAttribute($object->nomePais);
				$this->setEmailAttribute($object->email);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'ie' => $this->getIeAttribute(),
				'nome' => $this->getNomeAttribute(),
				'fantasia' => $this->getFantasiaAttribute(),
				'telefone' => $this->getTelefoneAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'complemento' => $this->getComplementoAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'codigoMunicipio' => $this->getCodigoMunicipioAttribute(),
				'nomeMunicipio' => $this->getNomeMunicipioAttribute(),
				'uf' => $this->getUfAttribute(),
				'cep' => $this->getCepAttribute(),
				'codigoPais' => $this->getCodigoPaisAttribute(),
				'nomePais' => $this->getNomePaisAttribute(),
				'email' => $this->getEmailAttribute(),
			];
	}
}