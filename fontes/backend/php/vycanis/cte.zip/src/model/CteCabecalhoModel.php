<?php
declare(strict_types=1);

class CteCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteEmitenteModelList',
		'cteLocalColetaModelList',
		'cteTomadorModelList',
		'ctePassagemModelList',
		'cteRemetenteModelList',
		'cteExpedidorModelList',
		'cteRecebedorModelList',
		'cteDestinatarioModelList',
		'cteLocalEntregaModelList',
		'cteComponenteModelList',
		'cteCargaModelList',
		'cteInformacaoNfOutrosModelList',
		'cteSeguroModelList',
		'ctePerigosoModelList',
		'cteVeiculoNovoModelList',
		'cteFaturaModelList',
		'cteDuplicataModelList',
		'cteRodoviarioModelList',
		'cteAereoModelList',
		'cteAquaviarioModelList',
		'cteFerroviarioModelList',
		'cteDutoviarioModelList',
		'cteMultimodalModelList',
	];

	/**
		* Relations
		*/
	public function cteEmitenteModelList()
{
	return $this->hasMany(CteEmitenteModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteLocalColetaModelList()
{
	return $this->hasMany(CteLocalColetaModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteTomadorModelList()
{
	return $this->hasMany(CteTomadorModel::class, 'id_cte_cabecalho', 'id');
}

	public function ctePassagemModelList()
{
	return $this->hasMany(CtePassagemModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteRemetenteModelList()
{
	return $this->hasMany(CteRemetenteModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteExpedidorModelList()
{
	return $this->hasMany(CteExpedidorModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteRecebedorModelList()
{
	return $this->hasMany(CteRecebedorModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteDestinatarioModelList()
{
	return $this->hasMany(CteDestinatarioModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteLocalEntregaModelList()
{
	return $this->hasMany(CteLocalEntregaModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteComponenteModelList()
{
	return $this->hasMany(CteComponenteModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteCargaModelList()
{
	return $this->hasMany(CteCargaModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteInformacaoNfOutrosModelList()
{
	return $this->hasMany(CteInformacaoNfOutrosModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteSeguroModelList()
{
	return $this->hasMany(CteSeguroModel::class, 'id_cte_cabecalho', 'id');
}

	public function ctePerigosoModelList()
{
	return $this->hasMany(CtePerigosoModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteVeiculoNovoModelList()
{
	return $this->hasMany(CteVeiculoNovoModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteFaturaModelList()
{
	return $this->hasMany(CteFaturaModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteDuplicataModelList()
{
	return $this->hasMany(CteDuplicataModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteRodoviarioModelList()
{
	return $this->hasMany(CteRodoviarioModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteAereoModelList()
{
	return $this->hasMany(CteAereoModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteAquaviarioModelList()
{
	return $this->hasMany(CteAquaviarioModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteFerroviarioModelList()
{
	return $this->hasMany(CteFerroviarioModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteDutoviarioModelList()
{
	return $this->hasMany(CteDutoviarioModel::class, 'id_cte_cabecalho', 'id');
}

	public function cteMultimodalModelList()
{
	return $this->hasMany(CteMultimodalModel::class, 'id_cte_cabecalho', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNaturezaOperacaoAttribute()
	{
		return $this->attributes['natureza_operacao'];
	}

	public function setNaturezaOperacaoAttribute($naturezaOperacao)
	{
		$this->attributes['natureza_operacao'] = $naturezaOperacao;
	}

	public function getChaveAcessoAttribute()
	{
		return $this->attributes['chave_acesso'];
	}

	public function setChaveAcessoAttribute($chaveAcesso)
	{
		$this->attributes['chave_acesso'] = $chaveAcesso;
	}

	public function getDigitoChaveAcessoAttribute()
	{
		return $this->attributes['digito_chave_acesso'];
	}

	public function setDigitoChaveAcessoAttribute($digitoChaveAcesso)
	{
		$this->attributes['digito_chave_acesso'] = $digitoChaveAcesso;
	}

	public function getCodigoNumericoAttribute()
	{
		return $this->attributes['codigo_numerico'];
	}

	public function setCodigoNumericoAttribute($codigoNumerico)
	{
		$this->attributes['codigo_numerico'] = $codigoNumerico;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataHoraEmissaoAttribute()
	{
		return $this->attributes['data_hora_emissao'];
	}

	public function setDataHoraEmissaoAttribute($dataHoraEmissao)
	{
		$this->attributes['data_hora_emissao'] = $dataHoraEmissao;
	}

	public function getUfEmitenteAttribute()
	{
		return $this->attributes['uf_emitente'];
	}

	public function setUfEmitenteAttribute($ufEmitente)
	{
		$this->attributes['uf_emitente'] = $ufEmitente;
	}

	public function getCfopAttribute()
	{
		return $this->attributes['cfop'];
	}

	public function setCfopAttribute($cfop)
	{
		$this->attributes['cfop'] = $cfop;
	}

	public function getFormaPagamentoAttribute()
	{
		return $this->attributes['forma_pagamento'];
	}

	public function setFormaPagamentoAttribute($formaPagamento)
	{
		$this->attributes['forma_pagamento'] = $formaPagamento;
	}

	public function getModeloAttribute()
	{
		return $this->attributes['modelo'];
	}

	public function setModeloAttribute($modelo)
	{
		$this->attributes['modelo'] = $modelo;
	}

	public function getFormatoImpressaoDacteAttribute()
	{
		return $this->attributes['formato_impressao_dacte'];
	}

	public function setFormatoImpressaoDacteAttribute($formatoImpressaoDacte)
	{
		$this->attributes['formato_impressao_dacte'] = $formatoImpressaoDacte;
	}

	public function getTipoEmissaoAttribute()
	{
		return $this->attributes['tipo_emissao'];
	}

	public function setTipoEmissaoAttribute($tipoEmissao)
	{
		$this->attributes['tipo_emissao'] = $tipoEmissao;
	}

	public function getAmbienteAttribute()
	{
		return $this->attributes['ambiente'];
	}

	public function setAmbienteAttribute($ambiente)
	{
		$this->attributes['ambiente'] = $ambiente;
	}

	public function getTipoCteAttribute()
	{
		return $this->attributes['tipo_cte'];
	}

	public function setTipoCteAttribute($tipoCte)
	{
		$this->attributes['tipo_cte'] = $tipoCte;
	}

	public function getProcessoEmissaoAttribute()
	{
		return $this->attributes['processo_emissao'];
	}

	public function setProcessoEmissaoAttribute($processoEmissao)
	{
		$this->attributes['processo_emissao'] = $processoEmissao;
	}

	public function getVersaoProcessoEmissaoAttribute()
	{
		return $this->attributes['versao_processo_emissao'];
	}

	public function setVersaoProcessoEmissaoAttribute($versaoProcessoEmissao)
	{
		$this->attributes['versao_processo_emissao'] = $versaoProcessoEmissao;
	}

	public function getChaveReferenciadoAttribute()
	{
		return $this->attributes['chave_referenciado'];
	}

	public function setChaveReferenciadoAttribute($chaveReferenciado)
	{
		$this->attributes['chave_referenciado'] = $chaveReferenciado;
	}

	public function getCodigoMunicipioEnvioAttribute()
	{
		return $this->attributes['codigo_municipio_envio'];
	}

	public function setCodigoMunicipioEnvioAttribute($codigoMunicipioEnvio)
	{
		$this->attributes['codigo_municipio_envio'] = $codigoMunicipioEnvio;
	}

	public function getNomeMunicipioEnvioAttribute()
	{
		return $this->attributes['nome_municipio_envio'];
	}

	public function setNomeMunicipioEnvioAttribute($nomeMunicipioEnvio)
	{
		$this->attributes['nome_municipio_envio'] = $nomeMunicipioEnvio;
	}

	public function getUfEnvioAttribute()
	{
		return $this->attributes['uf_envio'];
	}

	public function setUfEnvioAttribute($ufEnvio)
	{
		$this->attributes['uf_envio'] = $ufEnvio;
	}

	public function getModalAttribute()
	{
		return $this->attributes['modal'];
	}

	public function setModalAttribute($modal)
	{
		$this->attributes['modal'] = $modal;
	}

	public function getTipoServicoAttribute()
	{
		return $this->attributes['tipo_servico'];
	}

	public function setTipoServicoAttribute($tipoServico)
	{
		$this->attributes['tipo_servico'] = $tipoServico;
	}

	public function getCodigoMunicipioIniPrestacaoAttribute()
	{
		return $this->attributes['codigo_municipio_ini_prestacao'];
	}

	public function setCodigoMunicipioIniPrestacaoAttribute($codigoMunicipioIniPrestacao)
	{
		$this->attributes['codigo_municipio_ini_prestacao'] = $codigoMunicipioIniPrestacao;
	}

	public function getNomeMunicipioIniPrestacaoAttribute()
	{
		return $this->attributes['nome_municipio_ini_prestacao'];
	}

	public function setNomeMunicipioIniPrestacaoAttribute($nomeMunicipioIniPrestacao)
	{
		$this->attributes['nome_municipio_ini_prestacao'] = $nomeMunicipioIniPrestacao;
	}

	public function getUfIniPrestacaoAttribute()
	{
		return $this->attributes['uf_ini_prestacao'];
	}

	public function setUfIniPrestacaoAttribute($ufIniPrestacao)
	{
		$this->attributes['uf_ini_prestacao'] = $ufIniPrestacao;
	}

	public function getCodigoMunicipioFimPrestacaoAttribute()
	{
		return $this->attributes['codigo_municipio_fim_prestacao'];
	}

	public function setCodigoMunicipioFimPrestacaoAttribute($codigoMunicipioFimPrestacao)
	{
		$this->attributes['codigo_municipio_fim_prestacao'] = $codigoMunicipioFimPrestacao;
	}

	public function getNomeMunicipioFimPrestacaoAttribute()
	{
		return $this->attributes['nome_municipio_fim_prestacao'];
	}

	public function setNomeMunicipioFimPrestacaoAttribute($nomeMunicipioFimPrestacao)
	{
		$this->attributes['nome_municipio_fim_prestacao'] = $nomeMunicipioFimPrestacao;
	}

	public function getUfFimPrestacaoAttribute()
	{
		return $this->attributes['uf_fim_prestacao'];
	}

	public function setUfFimPrestacaoAttribute($ufFimPrestacao)
	{
		$this->attributes['uf_fim_prestacao'] = $ufFimPrestacao;
	}

	public function getRetiraAttribute()
	{
		return $this->attributes['retira'];
	}

	public function setRetiraAttribute($retira)
	{
		$this->attributes['retira'] = $retira;
	}

	public function getRetiraDetalheAttribute()
	{
		return $this->attributes['retira_detalhe'];
	}

	public function setRetiraDetalheAttribute($retiraDetalhe)
	{
		$this->attributes['retira_detalhe'] = $retiraDetalhe;
	}

	public function getTomadorAttribute()
	{
		return $this->attributes['tomador'];
	}

	public function setTomadorAttribute($tomador)
	{
		$this->attributes['tomador'] = $tomador;
	}

	public function getDataEntradaContingenciaAttribute()
	{
		return $this->attributes['data_entrada_contingencia'];
	}

	public function setDataEntradaContingenciaAttribute($dataEntradaContingencia)
	{
		$this->attributes['data_entrada_contingencia'] = $dataEntradaContingencia;
	}

	public function getJustificativaContingenciaAttribute()
	{
		return $this->attributes['justificativa_contingencia'];
	}

	public function setJustificativaContingenciaAttribute($justificativaContingencia)
	{
		$this->attributes['justificativa_contingencia'] = $justificativaContingencia;
	}

	public function getCaracAdicionalTransporteAttribute()
	{
		return $this->attributes['carac_adicional_transporte'];
	}

	public function setCaracAdicionalTransporteAttribute($caracAdicionalTransporte)
	{
		$this->attributes['carac_adicional_transporte'] = $caracAdicionalTransporte;
	}

	public function getCaracAdicionalServicoAttribute()
	{
		return $this->attributes['carac_adicional_servico'];
	}

	public function setCaracAdicionalServicoAttribute($caracAdicionalServico)
	{
		$this->attributes['carac_adicional_servico'] = $caracAdicionalServico;
	}

	public function getFuncionarioEmissorAttribute()
	{
		return $this->attributes['funcionario_emissor'];
	}

	public function setFuncionarioEmissorAttribute($funcionarioEmissor)
	{
		$this->attributes['funcionario_emissor'] = $funcionarioEmissor;
	}

	public function getFluxoOrigemAttribute()
	{
		return $this->attributes['fluxo_origem'];
	}

	public function setFluxoOrigemAttribute($fluxoOrigem)
	{
		$this->attributes['fluxo_origem'] = $fluxoOrigem;
	}

	public function getEntregaTipoPeriodoAttribute()
	{
		return $this->attributes['entrega_tipo_periodo'];
	}

	public function setEntregaTipoPeriodoAttribute($entregaTipoPeriodo)
	{
		$this->attributes['entrega_tipo_periodo'] = $entregaTipoPeriodo;
	}

	public function getEntregaDataProgramadaAttribute()
	{
		return $this->attributes['entrega_data_programada'];
	}

	public function setEntregaDataProgramadaAttribute($entregaDataProgramada)
	{
		$this->attributes['entrega_data_programada'] = $entregaDataProgramada;
	}

	public function getEntregaDataInicialAttribute()
	{
		return $this->attributes['entrega_data_inicial'];
	}

	public function setEntregaDataInicialAttribute($entregaDataInicial)
	{
		$this->attributes['entrega_data_inicial'] = $entregaDataInicial;
	}

	public function getEntregaDataFinalAttribute()
	{
		return $this->attributes['entrega_data_final'];
	}

	public function setEntregaDataFinalAttribute($entregaDataFinal)
	{
		$this->attributes['entrega_data_final'] = $entregaDataFinal;
	}

	public function getEntregaTipoHoraAttribute()
	{
		return $this->attributes['entrega_tipo_hora'];
	}

	public function setEntregaTipoHoraAttribute($entregaTipoHora)
	{
		$this->attributes['entrega_tipo_hora'] = $entregaTipoHora;
	}

	public function getEntregaHoraProgramadaAttribute()
	{
		return $this->attributes['entrega_hora_programada'];
	}

	public function setEntregaHoraProgramadaAttribute($entregaHoraProgramada)
	{
		$this->attributes['entrega_hora_programada'] = $entregaHoraProgramada;
	}

	public function getEntregaHoraInicialAttribute()
	{
		return $this->attributes['entrega_hora_inicial'];
	}

	public function setEntregaHoraInicialAttribute($entregaHoraInicial)
	{
		$this->attributes['entrega_hora_inicial'] = $entregaHoraInicial;
	}

	public function getEntregaHoraFinalAttribute()
	{
		return $this->attributes['entrega_hora_final'];
	}

	public function setEntregaHoraFinalAttribute($entregaHoraFinal)
	{
		$this->attributes['entrega_hora_final'] = $entregaHoraFinal;
	}

	public function getMunicipioOrigemCalculoAttribute()
	{
		return $this->attributes['municipio_origem_calculo'];
	}

	public function setMunicipioOrigemCalculoAttribute($municipioOrigemCalculo)
	{
		$this->attributes['municipio_origem_calculo'] = $municipioOrigemCalculo;
	}

	public function getMunicipioDestinoCalculoAttribute()
	{
		return $this->attributes['municipio_destino_calculo'];
	}

	public function setMunicipioDestinoCalculoAttribute($municipioDestinoCalculo)
	{
		$this->attributes['municipio_destino_calculo'] = $municipioDestinoCalculo;
	}

	public function getObservacoesGeraisAttribute()
	{
		return $this->attributes['observacoes_gerais'];
	}

	public function setObservacoesGeraisAttribute($observacoesGerais)
	{
		$this->attributes['observacoes_gerais'] = $observacoesGerais;
	}

	public function getValorTotalServicoAttribute()
	{
		return (double)$this->attributes['valor_total_servico'];
	}

	public function setValorTotalServicoAttribute($valorTotalServico)
	{
		$this->attributes['valor_total_servico'] = $valorTotalServico;
	}

	public function getValorReceberAttribute()
	{
		return (double)$this->attributes['valor_receber'];
	}

	public function setValorReceberAttribute($valorReceber)
	{
		$this->attributes['valor_receber'] = $valorReceber;
	}

	public function getCstAttribute()
	{
		return $this->attributes['cst'];
	}

	public function setCstAttribute($cst)
	{
		$this->attributes['cst'] = $cst;
	}

	public function getBaseCalculoIcmsAttribute()
	{
		return (double)$this->attributes['base_calculo_icms'];
	}

	public function setBaseCalculoIcmsAttribute($baseCalculoIcms)
	{
		$this->attributes['base_calculo_icms'] = $baseCalculoIcms;
	}

	public function getAliquotaIcmsAttribute()
	{
		return (double)$this->attributes['aliquota_icms'];
	}

	public function setAliquotaIcmsAttribute($aliquotaIcms)
	{
		$this->attributes['aliquota_icms'] = $aliquotaIcms;
	}

	public function getValorIcmsAttribute()
	{
		return (double)$this->attributes['valor_icms'];
	}

	public function setValorIcmsAttribute($valorIcms)
	{
		$this->attributes['valor_icms'] = $valorIcms;
	}

	public function getPercentualReducaoBcIcmsAttribute()
	{
		return (double)$this->attributes['percentual_reducao_bc_icms'];
	}

	public function setPercentualReducaoBcIcmsAttribute($percentualReducaoBcIcms)
	{
		$this->attributes['percentual_reducao_bc_icms'] = $percentualReducaoBcIcms;
	}

	public function getValorBcIcmsStRetidoAttribute()
	{
		return (double)$this->attributes['valor_bc_icms_st_retido'];
	}

	public function setValorBcIcmsStRetidoAttribute($valorBcIcmsStRetido)
	{
		$this->attributes['valor_bc_icms_st_retido'] = $valorBcIcmsStRetido;
	}

	public function getValorIcmsStRetidoAttribute()
	{
		return (double)$this->attributes['valor_icms_st_retido'];
	}

	public function setValorIcmsStRetidoAttribute($valorIcmsStRetido)
	{
		$this->attributes['valor_icms_st_retido'] = $valorIcmsStRetido;
	}

	public function getAliquotaIcmsStRetidoAttribute()
	{
		return (double)$this->attributes['aliquota_icms_st_retido'];
	}

	public function setAliquotaIcmsStRetidoAttribute($aliquotaIcmsStRetido)
	{
		$this->attributes['aliquota_icms_st_retido'] = $aliquotaIcmsStRetido;
	}

	public function getValorCreditoPresumidoIcmsAttribute()
	{
		return (double)$this->attributes['valor_credito_presumido_icms'];
	}

	public function setValorCreditoPresumidoIcmsAttribute($valorCreditoPresumidoIcms)
	{
		$this->attributes['valor_credito_presumido_icms'] = $valorCreditoPresumidoIcms;
	}

	public function getPercentualBcIcmsOutraUfAttribute()
	{
		return (double)$this->attributes['percentual_bc_icms_outra_uf'];
	}

	public function setPercentualBcIcmsOutraUfAttribute($percentualBcIcmsOutraUf)
	{
		$this->attributes['percentual_bc_icms_outra_uf'] = $percentualBcIcmsOutraUf;
	}

	public function getValorBcIcmsOutraUfAttribute()
	{
		return (double)$this->attributes['valor_bc_icms_outra_uf'];
	}

	public function setValorBcIcmsOutraUfAttribute($valorBcIcmsOutraUf)
	{
		$this->attributes['valor_bc_icms_outra_uf'] = $valorBcIcmsOutraUf;
	}

	public function getAliquotaIcmsOutraUfAttribute()
	{
		return (double)$this->attributes['aliquota_icms_outra_uf'];
	}

	public function setAliquotaIcmsOutraUfAttribute($aliquotaIcmsOutraUf)
	{
		$this->attributes['aliquota_icms_outra_uf'] = $aliquotaIcmsOutraUf;
	}

	public function getValorIcmsOutraUfAttribute()
	{
		return (double)$this->attributes['valor_icms_outra_uf'];
	}

	public function setValorIcmsOutraUfAttribute($valorIcmsOutraUf)
	{
		$this->attributes['valor_icms_outra_uf'] = $valorIcmsOutraUf;
	}

	public function getSimplesNacionalIndicadorAttribute()
	{
		return $this->attributes['simples_nacional_indicador'];
	}

	public function setSimplesNacionalIndicadorAttribute($simplesNacionalIndicador)
	{
		$this->attributes['simples_nacional_indicador'] = $simplesNacionalIndicador;
	}

	public function getSimplesNacionalTotalAttribute()
	{
		return (double)$this->attributes['simples_nacional_total'];
	}

	public function setSimplesNacionalTotalAttribute($simplesNacionalTotal)
	{
		$this->attributes['simples_nacional_total'] = $simplesNacionalTotal;
	}

	public function getInformacoesAddFiscoAttribute()
	{
		return $this->attributes['informacoes_add_fisco'];
	}

	public function setInformacoesAddFiscoAttribute($informacoesAddFisco)
	{
		$this->attributes['informacoes_add_fisco'] = $informacoesAddFisco;
	}

	public function getValorTotalCargaAttribute()
	{
		return (double)$this->attributes['valor_total_carga'];
	}

	public function setValorTotalCargaAttribute($valorTotalCarga)
	{
		$this->attributes['valor_total_carga'] = $valorTotalCarga;
	}

	public function getProdutoPredominanteAttribute()
	{
		return $this->attributes['produto_predominante'];
	}

	public function setProdutoPredominanteAttribute($produtoPredominante)
	{
		$this->attributes['produto_predominante'] = $produtoPredominante;
	}

	public function getCargaOutrasCaracteristicasAttribute()
	{
		return $this->attributes['carga_outras_caracteristicas'];
	}

	public function setCargaOutrasCaracteristicasAttribute($cargaOutrasCaracteristicas)
	{
		$this->attributes['carga_outras_caracteristicas'] = $cargaOutrasCaracteristicas;
	}

	public function getModalVersaoLayoutAttribute()
	{
		return $this->attributes['modal_versao_layout'];
	}

	public function setModalVersaoLayoutAttribute($modalVersaoLayout)
	{
		$this->attributes['modal_versao_layout'] = $modalVersaoLayout;
	}

	public function getChaveCteSubstituidoAttribute()
	{
		return $this->attributes['chave_cte_substituido'];
	}

	public function setChaveCteSubstituidoAttribute($chaveCteSubstituido)
	{
		$this->attributes['chave_cte_substituido'] = $chaveCteSubstituido;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNaturezaOperacaoAttribute($object->naturezaOperacao);
				$this->setChaveAcessoAttribute($object->chaveAcesso);
				$this->setDigitoChaveAcessoAttribute($object->digitoChaveAcesso);
				$this->setCodigoNumericoAttribute($object->codigoNumerico);
				$this->setSerieAttribute($object->serie);
				$this->setNumeroAttribute($object->numero);
				$this->setDataHoraEmissaoAttribute($object->dataHoraEmissao);
				$this->setUfEmitenteAttribute($object->ufEmitente);
				$this->setCfopAttribute($object->cfop);
				$this->setFormaPagamentoAttribute($object->formaPagamento);
				$this->setModeloAttribute($object->modelo);
				$this->setFormatoImpressaoDacteAttribute($object->formatoImpressaoDacte);
				$this->setTipoEmissaoAttribute($object->tipoEmissao);
				$this->setAmbienteAttribute($object->ambiente);
				$this->setTipoCteAttribute($object->tipoCte);
				$this->setProcessoEmissaoAttribute($object->processoEmissao);
				$this->setVersaoProcessoEmissaoAttribute($object->versaoProcessoEmissao);
				$this->setChaveReferenciadoAttribute($object->chaveReferenciado);
				$this->setCodigoMunicipioEnvioAttribute($object->codigoMunicipioEnvio);
				$this->setNomeMunicipioEnvioAttribute($object->nomeMunicipioEnvio);
				$this->setUfEnvioAttribute($object->ufEnvio);
				$this->setModalAttribute($object->modal);
				$this->setTipoServicoAttribute($object->tipoServico);
				$this->setCodigoMunicipioIniPrestacaoAttribute($object->codigoMunicipioIniPrestacao);
				$this->setNomeMunicipioIniPrestacaoAttribute($object->nomeMunicipioIniPrestacao);
				$this->setUfIniPrestacaoAttribute($object->ufIniPrestacao);
				$this->setCodigoMunicipioFimPrestacaoAttribute($object->codigoMunicipioFimPrestacao);
				$this->setNomeMunicipioFimPrestacaoAttribute($object->nomeMunicipioFimPrestacao);
				$this->setUfFimPrestacaoAttribute($object->ufFimPrestacao);
				$this->setRetiraAttribute($object->retira);
				$this->setRetiraDetalheAttribute($object->retiraDetalhe);
				$this->setTomadorAttribute($object->tomador);
				$this->setDataEntradaContingenciaAttribute($object->dataEntradaContingencia);
				$this->setJustificativaContingenciaAttribute($object->justificativaContingencia);
				$this->setCaracAdicionalTransporteAttribute($object->caracAdicionalTransporte);
				$this->setCaracAdicionalServicoAttribute($object->caracAdicionalServico);
				$this->setFuncionarioEmissorAttribute($object->funcionarioEmissor);
				$this->setFluxoOrigemAttribute($object->fluxoOrigem);
				$this->setEntregaTipoPeriodoAttribute($object->entregaTipoPeriodo);
				$this->setEntregaDataProgramadaAttribute($object->entregaDataProgramada);
				$this->setEntregaDataInicialAttribute($object->entregaDataInicial);
				$this->setEntregaDataFinalAttribute($object->entregaDataFinal);
				$this->setEntregaTipoHoraAttribute($object->entregaTipoHora);
				$this->setEntregaHoraProgramadaAttribute($object->entregaHoraProgramada);
				$this->setEntregaHoraInicialAttribute($object->entregaHoraInicial);
				$this->setEntregaHoraFinalAttribute($object->entregaHoraFinal);
				$this->setMunicipioOrigemCalculoAttribute($object->municipioOrigemCalculo);
				$this->setMunicipioDestinoCalculoAttribute($object->municipioDestinoCalculo);
				$this->setObservacoesGeraisAttribute($object->observacoesGerais);
				$this->setValorTotalServicoAttribute($object->valorTotalServico);
				$this->setValorReceberAttribute($object->valorReceber);
				$this->setCstAttribute($object->cst);
				$this->setBaseCalculoIcmsAttribute($object->baseCalculoIcms);
				$this->setAliquotaIcmsAttribute($object->aliquotaIcms);
				$this->setValorIcmsAttribute($object->valorIcms);
				$this->setPercentualReducaoBcIcmsAttribute($object->percentualReducaoBcIcms);
				$this->setValorBcIcmsStRetidoAttribute($object->valorBcIcmsStRetido);
				$this->setValorIcmsStRetidoAttribute($object->valorIcmsStRetido);
				$this->setAliquotaIcmsStRetidoAttribute($object->aliquotaIcmsStRetido);
				$this->setValorCreditoPresumidoIcmsAttribute($object->valorCreditoPresumidoIcms);
				$this->setPercentualBcIcmsOutraUfAttribute($object->percentualBcIcmsOutraUf);
				$this->setValorBcIcmsOutraUfAttribute($object->valorBcIcmsOutraUf);
				$this->setAliquotaIcmsOutraUfAttribute($object->aliquotaIcmsOutraUf);
				$this->setValorIcmsOutraUfAttribute($object->valorIcmsOutraUf);
				$this->setSimplesNacionalIndicadorAttribute($object->simplesNacionalIndicador);
				$this->setSimplesNacionalTotalAttribute($object->simplesNacionalTotal);
				$this->setInformacoesAddFiscoAttribute($object->informacoesAddFisco);
				$this->setValorTotalCargaAttribute($object->valorTotalCarga);
				$this->setProdutoPredominanteAttribute($object->produtoPredominante);
				$this->setCargaOutrasCaracteristicasAttribute($object->cargaOutrasCaracteristicas);
				$this->setModalVersaoLayoutAttribute($object->modalVersaoLayout);
				$this->setChaveCteSubstituidoAttribute($object->chaveCteSubstituido);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'naturezaOperacao' => $this->getNaturezaOperacaoAttribute(),
				'chaveAcesso' => $this->getChaveAcessoAttribute(),
				'digitoChaveAcesso' => $this->getDigitoChaveAcessoAttribute(),
				'codigoNumerico' => $this->getCodigoNumericoAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataHoraEmissao' => $this->getDataHoraEmissaoAttribute(),
				'ufEmitente' => $this->getUfEmitenteAttribute(),
				'cfop' => $this->getCfopAttribute(),
				'formaPagamento' => $this->getFormaPagamentoAttribute(),
				'modelo' => $this->getModeloAttribute(),
				'formatoImpressaoDacte' => $this->getFormatoImpressaoDacteAttribute(),
				'tipoEmissao' => $this->getTipoEmissaoAttribute(),
				'ambiente' => $this->getAmbienteAttribute(),
				'tipoCte' => $this->getTipoCteAttribute(),
				'processoEmissao' => $this->getProcessoEmissaoAttribute(),
				'versaoProcessoEmissao' => $this->getVersaoProcessoEmissaoAttribute(),
				'chaveReferenciado' => $this->getChaveReferenciadoAttribute(),
				'codigoMunicipioEnvio' => $this->getCodigoMunicipioEnvioAttribute(),
				'nomeMunicipioEnvio' => $this->getNomeMunicipioEnvioAttribute(),
				'ufEnvio' => $this->getUfEnvioAttribute(),
				'modal' => $this->getModalAttribute(),
				'tipoServico' => $this->getTipoServicoAttribute(),
				'codigoMunicipioIniPrestacao' => $this->getCodigoMunicipioIniPrestacaoAttribute(),
				'nomeMunicipioIniPrestacao' => $this->getNomeMunicipioIniPrestacaoAttribute(),
				'ufIniPrestacao' => $this->getUfIniPrestacaoAttribute(),
				'codigoMunicipioFimPrestacao' => $this->getCodigoMunicipioFimPrestacaoAttribute(),
				'nomeMunicipioFimPrestacao' => $this->getNomeMunicipioFimPrestacaoAttribute(),
				'ufFimPrestacao' => $this->getUfFimPrestacaoAttribute(),
				'retira' => $this->getRetiraAttribute(),
				'retiraDetalhe' => $this->getRetiraDetalheAttribute(),
				'tomador' => $this->getTomadorAttribute(),
				'dataEntradaContingencia' => $this->getDataEntradaContingenciaAttribute(),
				'justificativaContingencia' => $this->getJustificativaContingenciaAttribute(),
				'caracAdicionalTransporte' => $this->getCaracAdicionalTransporteAttribute(),
				'caracAdicionalServico' => $this->getCaracAdicionalServicoAttribute(),
				'funcionarioEmissor' => $this->getFuncionarioEmissorAttribute(),
				'fluxoOrigem' => $this->getFluxoOrigemAttribute(),
				'entregaTipoPeriodo' => $this->getEntregaTipoPeriodoAttribute(),
				'entregaDataProgramada' => $this->getEntregaDataProgramadaAttribute(),
				'entregaDataInicial' => $this->getEntregaDataInicialAttribute(),
				'entregaDataFinal' => $this->getEntregaDataFinalAttribute(),
				'entregaTipoHora' => $this->getEntregaTipoHoraAttribute(),
				'entregaHoraProgramada' => $this->getEntregaHoraProgramadaAttribute(),
				'entregaHoraInicial' => $this->getEntregaHoraInicialAttribute(),
				'entregaHoraFinal' => $this->getEntregaHoraFinalAttribute(),
				'municipioOrigemCalculo' => $this->getMunicipioOrigemCalculoAttribute(),
				'municipioDestinoCalculo' => $this->getMunicipioDestinoCalculoAttribute(),
				'observacoesGerais' => $this->getObservacoesGeraisAttribute(),
				'valorTotalServico' => $this->getValorTotalServicoAttribute(),
				'valorReceber' => $this->getValorReceberAttribute(),
				'cst' => $this->getCstAttribute(),
				'baseCalculoIcms' => $this->getBaseCalculoIcmsAttribute(),
				'aliquotaIcms' => $this->getAliquotaIcmsAttribute(),
				'valorIcms' => $this->getValorIcmsAttribute(),
				'percentualReducaoBcIcms' => $this->getPercentualReducaoBcIcmsAttribute(),
				'valorBcIcmsStRetido' => $this->getValorBcIcmsStRetidoAttribute(),
				'valorIcmsStRetido' => $this->getValorIcmsStRetidoAttribute(),
				'aliquotaIcmsStRetido' => $this->getAliquotaIcmsStRetidoAttribute(),
				'valorCreditoPresumidoIcms' => $this->getValorCreditoPresumidoIcmsAttribute(),
				'percentualBcIcmsOutraUf' => $this->getPercentualBcIcmsOutraUfAttribute(),
				'valorBcIcmsOutraUf' => $this->getValorBcIcmsOutraUfAttribute(),
				'aliquotaIcmsOutraUf' => $this->getAliquotaIcmsOutraUfAttribute(),
				'valorIcmsOutraUf' => $this->getValorIcmsOutraUfAttribute(),
				'simplesNacionalIndicador' => $this->getSimplesNacionalIndicadorAttribute(),
				'simplesNacionalTotal' => $this->getSimplesNacionalTotalAttribute(),
				'informacoesAddFisco' => $this->getInformacoesAddFiscoAttribute(),
				'valorTotalCarga' => $this->getValorTotalCargaAttribute(),
				'produtoPredominante' => $this->getProdutoPredominanteAttribute(),
				'cargaOutrasCaracteristicas' => $this->getCargaOutrasCaracteristicasAttribute(),
				'modalVersaoLayout' => $this->getModalVersaoLayoutAttribute(),
				'chaveCteSubstituido' => $this->getChaveCteSubstituidoAttribute(),
				'cteEmitenteModelList' => $this->cteEmitenteModelList,
				'cteLocalColetaModelList' => $this->cteLocalColetaModelList,
				'cteTomadorModelList' => $this->cteTomadorModelList,
				'ctePassagemModelList' => $this->ctePassagemModelList,
				'cteRemetenteModelList' => $this->cteRemetenteModelList,
				'cteExpedidorModelList' => $this->cteExpedidorModelList,
				'cteRecebedorModelList' => $this->cteRecebedorModelList,
				'cteDestinatarioModelList' => $this->cteDestinatarioModelList,
				'cteLocalEntregaModelList' => $this->cteLocalEntregaModelList,
				'cteComponenteModelList' => $this->cteComponenteModelList,
				'cteCargaModelList' => $this->cteCargaModelList,
				'cteInformacaoNfOutrosModelList' => $this->cteInformacaoNfOutrosModelList,
				'cteSeguroModelList' => $this->cteSeguroModelList,
				'ctePerigosoModelList' => $this->ctePerigosoModelList,
				'cteVeiculoNovoModelList' => $this->cteVeiculoNovoModelList,
				'cteFaturaModelList' => $this->cteFaturaModelList,
				'cteDuplicataModelList' => $this->cteDuplicataModelList,
				'cteRodoviarioModelList' => $this->cteRodoviarioModelList,
				'cteAereoModelList' => $this->cteAereoModelList,
				'cteAquaviarioModelList' => $this->cteAquaviarioModelList,
				'cteFerroviarioModelList' => $this->cteFerroviarioModelList,
				'cteDutoviarioModelList' => $this->cteDutoviarioModelList,
				'cteMultimodalModelList' => $this->cteMultimodalModelList,
			];
	}
}