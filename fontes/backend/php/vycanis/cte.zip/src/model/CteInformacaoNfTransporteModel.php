<?php
declare(strict_types=1);

class CteInformacaoNfTransporteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cte_informacao_nf_transporte';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cteInformacaoNfOutrosModel',
	];

	/**
		* Relations
		*/
	public function cteInformacaoNfOutrosModel()
	{
		return $this->belongsTo(CteInformacaoNfOutrosModel::class, 'id_cte_informacao_nf', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoUnidadeTransporteAttribute()
	{
		return $this->attributes['tipo_unidade_transporte'];
	}

	public function setTipoUnidadeTransporteAttribute($tipoUnidadeTransporte)
	{
		$this->attributes['tipo_unidade_transporte'] = $tipoUnidadeTransporte;
	}

	public function getIdUnidadeTransporteAttribute()
	{
		return $this->attributes['id_unidade_transporte'];
	}

	public function setIdUnidadeTransporteAttribute($idUnidadeTransporte)
	{
		$this->attributes['id_unidade_transporte'] = $idUnidadeTransporte;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoUnidadeTransporteAttribute($object->tipoUnidadeTransporte);
				$this->setIdUnidadeTransporteAttribute($object->idUnidadeTransporte);

				// link objects - lookups
				$cteInformacaoNfOutrosModel = new CteInformacaoNfOutrosModel();
				$cteInformacaoNfOutrosModel->mapping($object->cteInformacaoNfOutrosModel);
				$this->cteInformacaoNfOutrosModel()->associate($cteInformacaoNfOutrosModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipoUnidadeTransporte' => $this->getTipoUnidadeTransporteAttribute(),
				'idUnidadeTransporte' => $this->getIdUnidadeTransporteAttribute(),
				'cteInformacaoNfOutrosModel' => $this->cteInformacaoNfOutrosModel,
			];
	}
}