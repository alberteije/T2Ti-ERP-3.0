<?php
require './vendor/autoload.php';
use Illuminate\Database\Capsule\Manager as Capsule;

$capsule = new Capsule;

$capsule->addConnection([
	'driver'		=> 'mysql',
	'host'			=> 'localhost',
	'database'	=> 'fenix',
	'username'	=> 'root',
	'password'	=> 'root',
	'charset'	 	=> 'utf8',
	'collation' => 'utf8_unicode_ci',
	'prefix'		=> '',
]);

$capsule->setAsGlobal();
$capsule->bootEloquent();

abstract class EloquentModel extends \Illuminate\Database\Eloquent\Model {
	/**
		* Indicates if the model should be timestamped.
		* To disallow Eloquent to create created_at and updated_at fields in the database
		*
		* @var bool
	*/
	public $timestamps = false;
}