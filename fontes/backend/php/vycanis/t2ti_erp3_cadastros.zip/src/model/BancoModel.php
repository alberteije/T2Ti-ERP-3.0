<?php
declare(strict_types=1);

class BancoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'banco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['ID'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['ID'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['CODIGO'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['CODIGO'] = $codigo;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['NOME'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['NOME'] = $nome;
	}

	public function getUrlAttribute()
	{
		return $this->attributes['URL'];
	}

	public function setUrlAttribute($url)
	{
		$this->attributes['URL'] = $url;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setNomeAttribute($object->nome);
				$this->setUrlAttribute($object->url);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'url' => $this->getUrlAttribute(),
			];
	}
}