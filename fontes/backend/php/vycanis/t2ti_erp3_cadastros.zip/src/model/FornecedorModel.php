<?php
declare(strict_types=1);

class FornecedorModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fornecedor';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function pessoaModel()
	{
		return $this->belongsTo(PessoaModel::class, 'id_pessoa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDesdeAttribute()
	{
		return $this->attributes['desde'];
	}

	public function setDesdeAttribute($desde)
	{
		$this->attributes['desde'] = $desde;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDesdeAttribute($object->desde);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'desde' => $this->getDesdeAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}