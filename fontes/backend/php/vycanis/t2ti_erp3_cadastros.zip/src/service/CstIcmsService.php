<?php
class CstIcmsService extends ServiceBase
{
  public function getList()
  {
    return CstIcmsModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CstIcmsModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CstIcmsModel::find($id);
  }

}