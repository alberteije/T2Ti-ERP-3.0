<?php
class VendedorService extends ServiceBase
{
  public function getList()
  {
    return VendedorModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return VendedorModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return VendedorModel::find($id);
  }

}