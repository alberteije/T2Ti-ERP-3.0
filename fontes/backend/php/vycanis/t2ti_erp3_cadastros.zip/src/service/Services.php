<?php

include 'ServiceBase.php';

include 'PessoaService.php';
include 'ColaboradorService.php';
include 'EstadoCivilService.php';
include 'CargoService.php';
include 'SetorService.php';
include 'ColaboradorSituacaoService.php';
include 'TipoAdmissaoService.php';
include 'ColaboradorTipoService.php';
include 'VendedorService.php';
include 'ProdutoGrupoService.php';
include 'ProdutoSubgrupoService.php';
include 'ProdutoMarcaService.php';
include 'ProdutoUnidadeService.php';
include 'ProdutoService.php';
include 'BancoService.php';
include 'BancoAgenciaService.php';
include 'BancoContaCaixaService.php';
include 'CepService.php';
include 'UfService.php';
include 'MunicipioService.php';
include 'NcmService.php';
include 'CfopService.php';
include 'CstIcmsService.php';
include 'CstIpiService.php';
include 'CstCofinsService.php';
include 'CstPisService.php';
include 'CsosnService.php';
include 'CnaeService.php';
include 'PaisService.php';
include 'NivelFormacaoService.php';
include 'TabelaPrecoService.php';