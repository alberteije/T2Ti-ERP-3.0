<?php
class MunicipioService extends ServiceBase
{
  public function getList()
  {
    return MunicipioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return MunicipioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return MunicipioModel::find($id);
  }

}