<?php
use Illuminate\Database\Capsule\Manager as DB;
class PessoaService extends ServiceBase
{
	public function getList()
	{
		return PessoaModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return PessoaModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return PessoaModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// pessoaJuridica
		if (isset($objJson->pessoaJuridicaModel)) {
			$pessoaJuridicaModel = new PessoaJuridicaModel();
			$pessoaJuridicaModel->mapping($objJson->pessoaJuridicaModel);
			$objModel->pessoaJuridicaModel()->save($pessoaJuridicaModel);
		}

		// fornecedor
		if (isset($objJson->fornecedorModel)) {
			$fornecedorModel = new FornecedorModel();
			$fornecedorModel->mapping($objJson->fornecedorModel);
			$objModel->fornecedorModel()->save($fornecedorModel);
		}

		// cliente
		if (isset($objJson->clienteModel)) {
			$clienteModel = new ClienteModel();
			$clienteModel->mapping($objJson->clienteModel);
			$objModel->clienteModel()->save($clienteModel);
		}

		// contador
		if (isset($objJson->contadorModel)) {
			$contadorModel = new ContadorModel();
			$contadorModel->mapping($objJson->contadorModel);
			$objModel->contadorModel()->save($contadorModel);
		}

		// pessoaFisica
		if (isset($objJson->pessoaFisicaModel)) {
			$pessoaFisicaModel = new PessoaFisicaModel();
			$pessoaFisicaModel->mapping($objJson->pessoaFisicaModel);
			$objModel->pessoaFisicaModel()->save($pessoaFisicaModel);
		}

		// transportadora
		if (isset($objJson->transportadoraModel)) {
			$transportadoraModel = new TransportadoraModel();
			$transportadoraModel->mapping($objJson->transportadoraModel);
			$objModel->transportadoraModel()->save($transportadoraModel);
		}

		// pessoaContato
		$pessoaContatoModelListJson = $objJson->pessoaContatoModelList;
		if ($pessoaContatoModelListJson != null) {
			for ($i = 0; $i < count($pessoaContatoModelListJson); $i++) {
				$pessoaContato = new PessoaContatoModel();
				$pessoaContato->mapping($pessoaContatoModelListJson[$i]);
				$objModel->pessoaContatoModelList()->save($pessoaContato);
			}
		}

		// pessoaTelefone
		$pessoaTelefoneModelListJson = $objJson->pessoaTelefoneModelList;
		if ($pessoaTelefoneModelListJson != null) {
			for ($i = 0; $i < count($pessoaTelefoneModelListJson); $i++) {
				$pessoaTelefone = new PessoaTelefoneModel();
				$pessoaTelefone->mapping($pessoaTelefoneModelListJson[$i]);
				$objModel->pessoaTelefoneModelList()->save($pessoaTelefone);
			}
		}

		// pessoaEndereco
		$pessoaEnderecoModelListJson = $objJson->pessoaEnderecoModelList;
		if ($pessoaEnderecoModelListJson != null) {
			for ($i = 0; $i < count($pessoaEnderecoModelListJson); $i++) {
				$pessoaEndereco = new PessoaEnderecoModel();
				$pessoaEndereco->mapping($pessoaEnderecoModelListJson[$i]);
				$objModel->pessoaEnderecoModelList()->save($pessoaEndereco);
			}
		}

	}	

	public function deleteChildren($object)
	{
		PessoaJuridicaModel::where('id_pessoa', $object->getIdAttribute())->delete();
		FornecedorModel::where('id_pessoa', $object->getIdAttribute())->delete();
		ClienteModel::where('id_pessoa', $object->getIdAttribute())->delete();
		ContadorModel::where('id_pessoa', $object->getIdAttribute())->delete();
		PessoaFisicaModel::where('id_pessoa', $object->getIdAttribute())->delete();
		TransportadoraModel::where('id_pessoa', $object->getIdAttribute())->delete();
		PessoaContatoModel::where('id_pessoa', $object->getIdAttribute())->delete();
		PessoaTelefoneModel::where('id_pessoa', $object->getIdAttribute())->delete();
		PessoaEnderecoModel::where('id_pessoa', $object->getIdAttribute())->delete();
	}	
 
}