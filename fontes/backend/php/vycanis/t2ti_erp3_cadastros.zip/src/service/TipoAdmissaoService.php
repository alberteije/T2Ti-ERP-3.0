<?php
class TipoAdmissaoService extends ServiceBase
{
  public function getList()
  {
    return TipoAdmissaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TipoAdmissaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return TipoAdmissaoModel::find($id);
  }

}