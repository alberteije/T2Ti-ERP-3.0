<?php
class CfopService extends ServiceBase
{
  public function getList()
  {
    return CfopModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CfopModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CfopModel::find($id);
  }

}