<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// pessoa
$app->get('/pessoa[/]', \PessoaController::class . RESULT_LIST);
$app->get('/pessoa/{id}', \PessoaController::class . RESULT_OBJECT);
$app->post('/pessoa', \PessoaController::class . INSERT);
$app->put('/pessoa', \PessoaController::class . UPDATE);
$app->delete('/pessoa/{id}', \PessoaController::class . DELETE);
$app->options('/pessoa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pessoa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pessoa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// colaborador
$app->get('/colaborador[/]', \ColaboradorController::class . RESULT_LIST);
$app->get('/colaborador/{id}', \ColaboradorController::class . RESULT_OBJECT);
$app->post('/colaborador', \ColaboradorController::class . INSERT);
$app->put('/colaborador', \ColaboradorController::class . UPDATE);
$app->delete('/colaborador/{id}', \ColaboradorController::class . DELETE);
$app->options('/colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estado-civil
$app->get('/estado-civil[/]', \EstadoCivilController::class . RESULT_LIST);
$app->get('/estado-civil/{id}', \EstadoCivilController::class . RESULT_OBJECT);
$app->post('/estado-civil', \EstadoCivilController::class . INSERT);
$app->put('/estado-civil', \EstadoCivilController::class . UPDATE);
$app->delete('/estado-civil/{id}', \EstadoCivilController::class . DELETE);
$app->options('/estado-civil', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estado-civil/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estado-civil/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cargo
$app->get('/cargo[/]', \CargoController::class . RESULT_LIST);
$app->get('/cargo/{id}', \CargoController::class . RESULT_OBJECT);
$app->post('/cargo', \CargoController::class . INSERT);
$app->put('/cargo', \CargoController::class . UPDATE);
$app->delete('/cargo/{id}', \CargoController::class . DELETE);
$app->options('/cargo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cargo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cargo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// setor
$app->get('/setor[/]', \SetorController::class . RESULT_LIST);
$app->get('/setor/{id}', \SetorController::class . RESULT_OBJECT);
$app->post('/setor', \SetorController::class . INSERT);
$app->put('/setor', \SetorController::class . UPDATE);
$app->delete('/setor/{id}', \SetorController::class . DELETE);
$app->options('/setor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// colaborador-situacao
$app->get('/colaborador-situacao[/]', \ColaboradorSituacaoController::class . RESULT_LIST);
$app->get('/colaborador-situacao/{id}', \ColaboradorSituacaoController::class . RESULT_OBJECT);
$app->post('/colaborador-situacao', \ColaboradorSituacaoController::class . INSERT);
$app->put('/colaborador-situacao', \ColaboradorSituacaoController::class . UPDATE);
$app->delete('/colaborador-situacao/{id}', \ColaboradorSituacaoController::class . DELETE);
$app->options('/colaborador-situacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-situacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-situacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tipo-admissao
$app->get('/tipo-admissao[/]', \TipoAdmissaoController::class . RESULT_LIST);
$app->get('/tipo-admissao/{id}', \TipoAdmissaoController::class . RESULT_OBJECT);
$app->post('/tipo-admissao', \TipoAdmissaoController::class . INSERT);
$app->put('/tipo-admissao', \TipoAdmissaoController::class . UPDATE);
$app->delete('/tipo-admissao/{id}', \TipoAdmissaoController::class . DELETE);
$app->options('/tipo-admissao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-admissao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-admissao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// colaborador-tipo
$app->get('/colaborador-tipo[/]', \ColaboradorTipoController::class . RESULT_LIST);
$app->get('/colaborador-tipo/{id}', \ColaboradorTipoController::class . RESULT_OBJECT);
$app->post('/colaborador-tipo', \ColaboradorTipoController::class . INSERT);
$app->put('/colaborador-tipo', \ColaboradorTipoController::class . UPDATE);
$app->delete('/colaborador-tipo/{id}', \ColaboradorTipoController::class . DELETE);
$app->options('/colaborador-tipo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-tipo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-tipo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// vendedor
$app->get('/vendedor[/]', \VendedorController::class . RESULT_LIST);
$app->get('/vendedor/{id}', \VendedorController::class . RESULT_OBJECT);
$app->post('/vendedor', \VendedorController::class . INSERT);
$app->put('/vendedor', \VendedorController::class . UPDATE);
$app->delete('/vendedor/{id}', \VendedorController::class . DELETE);
$app->options('/vendedor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/vendedor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/vendedor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-grupo
$app->get('/produto-grupo[/]', \ProdutoGrupoController::class . RESULT_LIST);
$app->get('/produto-grupo/{id}', \ProdutoGrupoController::class . RESULT_OBJECT);
$app->post('/produto-grupo', \ProdutoGrupoController::class . INSERT);
$app->put('/produto-grupo', \ProdutoGrupoController::class . UPDATE);
$app->delete('/produto-grupo/{id}', \ProdutoGrupoController::class . DELETE);
$app->options('/produto-grupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-subgrupo
$app->get('/produto-subgrupo[/]', \ProdutoSubgrupoController::class . RESULT_LIST);
$app->get('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . RESULT_OBJECT);
$app->post('/produto-subgrupo', \ProdutoSubgrupoController::class . INSERT);
$app->put('/produto-subgrupo', \ProdutoSubgrupoController::class . UPDATE);
$app->delete('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . DELETE);
$app->options('/produto-subgrupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-marca
$app->get('/produto-marca[/]', \ProdutoMarcaController::class . RESULT_LIST);
$app->get('/produto-marca/{id}', \ProdutoMarcaController::class . RESULT_OBJECT);
$app->post('/produto-marca', \ProdutoMarcaController::class . INSERT);
$app->put('/produto-marca', \ProdutoMarcaController::class . UPDATE);
$app->delete('/produto-marca/{id}', \ProdutoMarcaController::class . DELETE);
$app->options('/produto-marca', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-unidade
$app->get('/produto-unidade[/]', \ProdutoUnidadeController::class . RESULT_LIST);
$app->get('/produto-unidade/{id}', \ProdutoUnidadeController::class . RESULT_OBJECT);
$app->post('/produto-unidade', \ProdutoUnidadeController::class . INSERT);
$app->put('/produto-unidade', \ProdutoUnidadeController::class . UPDATE);
$app->delete('/produto-unidade/{id}', \ProdutoUnidadeController::class . DELETE);
$app->options('/produto-unidade', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto
$app->get('/produto[/]', \ProdutoController::class . RESULT_LIST);
$app->get('/produto/{id}', \ProdutoController::class . RESULT_OBJECT);
$app->post('/produto', \ProdutoController::class . INSERT);
$app->put('/produto', \ProdutoController::class . UPDATE);
$app->delete('/produto/{id}', \ProdutoController::class . DELETE);
$app->options('/produto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco
$app->get('/banco[/]', \BancoController::class . RESULT_LIST);
$app->get('/banco/{id}', \BancoController::class . RESULT_OBJECT);
$app->post('/banco', \BancoController::class . INSERT);
$app->put('/banco', \BancoController::class . UPDATE);
$app->delete('/banco/{id}', \BancoController::class . DELETE);
$app->options('/banco', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco-agencia
$app->get('/banco-agencia[/]', \BancoAgenciaController::class . RESULT_LIST);
$app->get('/banco-agencia/{id}', \BancoAgenciaController::class . RESULT_OBJECT);
$app->post('/banco-agencia', \BancoAgenciaController::class . INSERT);
$app->put('/banco-agencia', \BancoAgenciaController::class . UPDATE);
$app->delete('/banco-agencia/{id}', \BancoAgenciaController::class . DELETE);
$app->options('/banco-agencia', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-agencia/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-agencia/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco-conta-caixa
$app->get('/banco-conta-caixa[/]', \BancoContaCaixaController::class . RESULT_LIST);
$app->get('/banco-conta-caixa/{id}', \BancoContaCaixaController::class . RESULT_OBJECT);
$app->post('/banco-conta-caixa', \BancoContaCaixaController::class . INSERT);
$app->put('/banco-conta-caixa', \BancoContaCaixaController::class . UPDATE);
$app->delete('/banco-conta-caixa/{id}', \BancoContaCaixaController::class . DELETE);
$app->options('/banco-conta-caixa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-conta-caixa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-conta-caixa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cep
$app->get('/cep[/]', \CepController::class . RESULT_LIST);
$app->get('/cep/{id}', \CepController::class . RESULT_OBJECT);
$app->post('/cep', \CepController::class . INSERT);
$app->put('/cep', \CepController::class . UPDATE);
$app->delete('/cep/{id}', \CepController::class . DELETE);
$app->options('/cep', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cep/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cep/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// uf
$app->get('/uf[/]', \UfController::class . RESULT_LIST);
$app->get('/uf/{id}', \UfController::class . RESULT_OBJECT);
$app->post('/uf', \UfController::class . INSERT);
$app->put('/uf', \UfController::class . UPDATE);
$app->delete('/uf/{id}', \UfController::class . DELETE);
$app->options('/uf', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/uf/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/uf/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// municipio
$app->get('/municipio[/]', \MunicipioController::class . RESULT_LIST);
$app->get('/municipio/{id}', \MunicipioController::class . RESULT_OBJECT);
$app->post('/municipio', \MunicipioController::class . INSERT);
$app->put('/municipio', \MunicipioController::class . UPDATE);
$app->delete('/municipio/{id}', \MunicipioController::class . DELETE);
$app->options('/municipio', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/municipio/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/municipio/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ncm
$app->get('/ncm[/]', \NcmController::class . RESULT_LIST);
$app->get('/ncm/{id}', \NcmController::class . RESULT_OBJECT);
$app->post('/ncm', \NcmController::class . INSERT);
$app->put('/ncm', \NcmController::class . UPDATE);
$app->delete('/ncm/{id}', \NcmController::class . DELETE);
$app->options('/ncm', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ncm/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ncm/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cfop
$app->get('/cfop[/]', \CfopController::class . RESULT_LIST);
$app->get('/cfop/{id}', \CfopController::class . RESULT_OBJECT);
$app->post('/cfop', \CfopController::class . INSERT);
$app->put('/cfop', \CfopController::class . UPDATE);
$app->delete('/cfop/{id}', \CfopController::class . DELETE);
$app->options('/cfop', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cfop/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cfop/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-icms
$app->get('/cst-icms[/]', \CstIcmsController::class . RESULT_LIST);
$app->get('/cst-icms/{id}', \CstIcmsController::class . RESULT_OBJECT);
$app->post('/cst-icms', \CstIcmsController::class . INSERT);
$app->put('/cst-icms', \CstIcmsController::class . UPDATE);
$app->delete('/cst-icms/{id}', \CstIcmsController::class . DELETE);
$app->options('/cst-icms', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-icms/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-icms/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-ipi
$app->get('/cst-ipi[/]', \CstIpiController::class . RESULT_LIST);
$app->get('/cst-ipi/{id}', \CstIpiController::class . RESULT_OBJECT);
$app->post('/cst-ipi', \CstIpiController::class . INSERT);
$app->put('/cst-ipi', \CstIpiController::class . UPDATE);
$app->delete('/cst-ipi/{id}', \CstIpiController::class . DELETE);
$app->options('/cst-ipi', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-ipi/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-ipi/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-cofins
$app->get('/cst-cofins[/]', \CstCofinsController::class . RESULT_LIST);
$app->get('/cst-cofins/{id}', \CstCofinsController::class . RESULT_OBJECT);
$app->post('/cst-cofins', \CstCofinsController::class . INSERT);
$app->put('/cst-cofins', \CstCofinsController::class . UPDATE);
$app->delete('/cst-cofins/{id}', \CstCofinsController::class . DELETE);
$app->options('/cst-cofins', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-cofins/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-cofins/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-pis
$app->get('/cst-pis[/]', \CstPisController::class . RESULT_LIST);
$app->get('/cst-pis/{id}', \CstPisController::class . RESULT_OBJECT);
$app->post('/cst-pis', \CstPisController::class . INSERT);
$app->put('/cst-pis', \CstPisController::class . UPDATE);
$app->delete('/cst-pis/{id}', \CstPisController::class . DELETE);
$app->options('/cst-pis', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-pis/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-pis/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// csosn
$app->get('/csosn[/]', \CsosnController::class . RESULT_LIST);
$app->get('/csosn/{id}', \CsosnController::class . RESULT_OBJECT);
$app->post('/csosn', \CsosnController::class . INSERT);
$app->put('/csosn', \CsosnController::class . UPDATE);
$app->delete('/csosn/{id}', \CsosnController::class . DELETE);
$app->options('/csosn', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/csosn/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/csosn/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cnae
$app->get('/cnae[/]', \CnaeController::class . RESULT_LIST);
$app->get('/cnae/{id}', \CnaeController::class . RESULT_OBJECT);
$app->post('/cnae', \CnaeController::class . INSERT);
$app->put('/cnae', \CnaeController::class . UPDATE);
$app->delete('/cnae/{id}', \CnaeController::class . DELETE);
$app->options('/cnae', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cnae/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cnae/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// pais
$app->get('/pais[/]', \PaisController::class . RESULT_LIST);
$app->get('/pais/{id}', \PaisController::class . RESULT_OBJECT);
$app->post('/pais', \PaisController::class . INSERT);
$app->put('/pais', \PaisController::class . UPDATE);
$app->delete('/pais/{id}', \PaisController::class . DELETE);
$app->options('/pais', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pais/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pais/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// nivel-formacao
$app->get('/nivel-formacao[/]', \NivelFormacaoController::class . RESULT_LIST);
$app->get('/nivel-formacao/{id}', \NivelFormacaoController::class . RESULT_OBJECT);
$app->post('/nivel-formacao', \NivelFormacaoController::class . INSERT);
$app->put('/nivel-formacao', \NivelFormacaoController::class . UPDATE);
$app->delete('/nivel-formacao/{id}', \NivelFormacaoController::class . DELETE);
$app->options('/nivel-formacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nivel-formacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nivel-formacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tabela-preco
$app->get('/tabela-preco[/]', \TabelaPrecoController::class . RESULT_LIST);
$app->get('/tabela-preco/{id}', \TabelaPrecoController::class . RESULT_OBJECT);
$app->post('/tabela-preco', \TabelaPrecoController::class . INSERT);
$app->put('/tabela-preco', \TabelaPrecoController::class . UPDATE);
$app->delete('/tabela-preco/{id}', \TabelaPrecoController::class . DELETE);
$app->options('/tabela-preco', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tabela-preco/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tabela-preco/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

