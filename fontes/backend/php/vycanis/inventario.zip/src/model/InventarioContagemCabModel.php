<?php
declare(strict_types=1);

class InventarioContagemCabModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'inventario_contagem_cab';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'inventarioContagemDetModelList',
	];

	/**
		* Relations
		*/
	public function inventarioContagemDetModelList()
{
	return $this->hasMany(InventarioContagemDetModel::class, 'id_inventario_contagem_cab', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataContagemAttribute()
	{
		return $this->attributes['data_contagem'];
	}

	public function setDataContagemAttribute($dataContagem)
	{
		$this->attributes['data_contagem'] = $dataContagem;
	}

	public function getEstoqueAtualizadoAttribute()
	{
		return $this->attributes['estoque_atualizado'];
	}

	public function setEstoqueAtualizadoAttribute($estoqueAtualizado)
	{
		$this->attributes['estoque_atualizado'] = $estoqueAtualizado;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataContagemAttribute($object->dataContagem);
				$this->setEstoqueAtualizadoAttribute($object->estoqueAtualizado);
				$this->setTipoAttribute($object->tipo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataContagem' => $this->getDataContagemAttribute(),
				'estoqueAtualizado' => $this->getEstoqueAtualizadoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'inventarioContagemDetModelList' => $this->inventarioContagemDetModelList,
			];
	}
}