<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'InventarioContagemDetModel.php';
include 'InventarioAjusteDetModel.php';
include 'InventarioContagemCabModel.php';
include 'InventarioAjusteCabModel.php';
include 'ProdutoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';