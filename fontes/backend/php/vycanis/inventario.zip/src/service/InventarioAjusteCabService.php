<?php
use Illuminate\Database\Capsule\Manager as DB;
class InventarioAjusteCabService extends ServiceBase
{
	public function getList()
	{
		return InventarioAjusteCabModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return InventarioAjusteCabModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return InventarioAjusteCabModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// inventarioAjusteDet
		$inventarioAjusteDetModelListJson = $objJson->inventarioAjusteDetModelList;
		if ($inventarioAjusteDetModelListJson != null) {
			for ($i = 0; $i < count($inventarioAjusteDetModelListJson); $i++) {
				$inventarioAjusteDet = new InventarioAjusteDetModel();
				$inventarioAjusteDet->mapping($inventarioAjusteDetModelListJson[$i]);
				$objModel->inventarioAjusteDetModelList()->save($inventarioAjusteDet);
			}
		}

	}	

	public function deleteChildren($object)
	{
		InventarioAjusteDetModel::where('id_inventario_ajuste_cab', $object->getIdAttribute())->delete();
	}	
 
}