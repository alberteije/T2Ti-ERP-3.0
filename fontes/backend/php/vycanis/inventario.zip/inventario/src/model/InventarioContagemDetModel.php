<?php
declare(strict_types=1);

class InventarioContagemDetModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'inventario_contagem_det';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'produtoModel',
	];

	/**
		* Relations
		*/
	public function inventarioContagemCabModel()
	{
		return $this->belongsTo(InventarioContagemCabModel::class, 'id_inventario_contagem_cab', 'id');
	}

	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getContagem01Attribute()
	{
		return (double)$this->attributes['contagem01'];
	}

	public function setContagem01Attribute($contagem01)
	{
		$this->attributes['contagem01'] = $contagem01;
	}

	public function getContagem02Attribute()
	{
		return (double)$this->attributes['contagem02'];
	}

	public function setContagem02Attribute($contagem02)
	{
		$this->attributes['contagem02'] = $contagem02;
	}

	public function getContagem03Attribute()
	{
		return (double)$this->attributes['contagem03'];
	}

	public function setContagem03Attribute($contagem03)
	{
		$this->attributes['contagem03'] = $contagem03;
	}

	public function getFechadoContagemAttribute()
	{
		return $this->attributes['fechado_contagem'];
	}

	public function setFechadoContagemAttribute($fechadoContagem)
	{
		$this->attributes['fechado_contagem'] = $fechadoContagem;
	}

	public function getQuantidadeSistemaAttribute()
	{
		return (double)$this->attributes['quantidade_sistema'];
	}

	public function setQuantidadeSistemaAttribute($quantidadeSistema)
	{
		$this->attributes['quantidade_sistema'] = $quantidadeSistema;
	}

	public function getAcuracidadeAttribute()
	{
		return (double)$this->attributes['acuracidade'];
	}

	public function setAcuracidadeAttribute($acuracidade)
	{
		$this->attributes['acuracidade'] = $acuracidade;
	}

	public function getDivergenciaAttribute()
	{
		return (double)$this->attributes['divergencia'];
	}

	public function setDivergenciaAttribute($divergencia)
	{
		$this->attributes['divergencia'] = $divergencia;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setContagem01Attribute($object->contagem01);
				$this->setContagem02Attribute($object->contagem02);
				$this->setContagem03Attribute($object->contagem03);
				$this->setFechadoContagemAttribute($object->fechadoContagem);
				$this->setQuantidadeSistemaAttribute($object->quantidadeSistema);
				$this->setAcuracidadeAttribute($object->acuracidade);
				$this->setDivergenciaAttribute($object->divergencia);

				// link objects - lookups
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'contagem01' => $this->getContagem01Attribute(),
				'contagem02' => $this->getContagem02Attribute(),
				'contagem03' => $this->getContagem03Attribute(),
				'fechadoContagem' => $this->getFechadoContagemAttribute(),
				'quantidadeSistema' => $this->getQuantidadeSistemaAttribute(),
				'acuracidade' => $this->getAcuracidadeAttribute(),
				'divergencia' => $this->getDivergenciaAttribute(),
				'produtoModel' => $this->produtoModel,
			];
	}
}