<?php
declare(strict_types=1);

class InventarioAjusteCabModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'inventario_ajuste_cab';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
		'inventarioAjusteDetModelList',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_view_pessoa_colaborador', 'id');
	}

	public function inventarioAjusteDetModelList()
{
	return $this->hasMany(InventarioAjusteDetModel::class, 'id_inventario_ajuste_cab', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataAjusteAttribute()
	{
		return $this->attributes['data_ajuste'];
	}

	public function setDataAjusteAttribute($dataAjuste)
	{
		$this->attributes['data_ajuste'] = $dataAjuste;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getTaxaAttribute()
	{
		return (double)$this->attributes['taxa'];
	}

	public function setTaxaAttribute($taxa)
	{
		$this->attributes['taxa'] = $taxa;
	}

	public function getJustificativaAttribute()
	{
		return $this->attributes['justificativa'];
	}

	public function setJustificativaAttribute($justificativa)
	{
		$this->attributes['justificativa'] = $justificativa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataAjusteAttribute($object->dataAjuste);
				$this->setTipoAttribute($object->tipo);
				$this->setTaxaAttribute($object->taxa);
				$this->setJustificativaAttribute($object->justificativa);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataAjuste' => $this->getDataAjusteAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'taxa' => $this->getTaxaAttribute(),
				'justificativa' => $this->getJustificativaAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'inventarioAjusteDetModelList' => $this->inventarioAjusteDetModelList,
			];
	}
}