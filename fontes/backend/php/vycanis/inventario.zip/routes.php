<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// inventario-contagem-cab
$app->get('/inventario-contagem-cab[/]', \InventarioContagemCabController::class . RESULT_LIST);
$app->get('/inventario-contagem-cab/{id}', \InventarioContagemCabController::class . RESULT_OBJECT);
$app->post('/inventario-contagem-cab', \InventarioContagemCabController::class . INSERT);
$app->put('/inventario-contagem-cab', \InventarioContagemCabController::class . UPDATE);
$app->delete('/inventario-contagem-cab/{id}', \InventarioContagemCabController::class . DELETE);
$app->options('/inventario-contagem-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/inventario-contagem-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/inventario-contagem-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// inventario-ajuste-cab
$app->get('/inventario-ajuste-cab[/]', \InventarioAjusteCabController::class . RESULT_LIST);
$app->get('/inventario-ajuste-cab/{id}', \InventarioAjusteCabController::class . RESULT_OBJECT);
$app->post('/inventario-ajuste-cab', \InventarioAjusteCabController::class . INSERT);
$app->put('/inventario-ajuste-cab', \InventarioAjusteCabController::class . UPDATE);
$app->delete('/inventario-ajuste-cab/{id}', \InventarioAjusteCabController::class . DELETE);
$app->options('/inventario-ajuste-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/inventario-ajuste-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/inventario-ajuste-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto
$app->get('/produto[/]', \ProdutoController::class . RESULT_LIST);
$app->get('/produto/{id}', \ProdutoController::class . RESULT_OBJECT);
$app->post('/produto', \ProdutoController::class . INSERT);
$app->put('/produto', \ProdutoController::class . UPDATE);
$app->delete('/produto/{id}', \ProdutoController::class . DELETE);
$app->options('/produto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

