<?php
use Illuminate\Database\Capsule\Manager as DB;
class ProjetoPrincipalService extends ServiceBase
{
	public function getList()
	{
		return ProjetoPrincipalModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ProjetoPrincipalModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ProjetoPrincipalModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// projetoCronograma
		$projetoCronogramaModelListJson = $objJson->projetoCronogramaModelList;
		if ($projetoCronogramaModelListJson != null) {
			for ($i = 0; $i < count($projetoCronogramaModelListJson); $i++) {
				$projetoCronograma = new ProjetoCronogramaModel();
				$projetoCronograma->mapping($projetoCronogramaModelListJson[$i]);
				$objModel->projetoCronogramaModelList()->save($projetoCronograma);
			}
		}

		// projetoRisco
		$projetoRiscoModelListJson = $objJson->projetoRiscoModelList;
		if ($projetoRiscoModelListJson != null) {
			for ($i = 0; $i < count($projetoRiscoModelListJson); $i++) {
				$projetoRisco = new ProjetoRiscoModel();
				$projetoRisco->mapping($projetoRiscoModelListJson[$i]);
				$objModel->projetoRiscoModelList()->save($projetoRisco);
			}
		}

		// projetoCusto
		$projetoCustoModelListJson = $objJson->projetoCustoModelList;
		if ($projetoCustoModelListJson != null) {
			for ($i = 0; $i < count($projetoCustoModelListJson); $i++) {
				$projetoCusto = new ProjetoCustoModel();
				$projetoCusto->mapping($projetoCustoModelListJson[$i]);
				$objModel->projetoCustoModelList()->save($projetoCusto);
			}
		}

		// projetoStakeholders
		$projetoStakeholdersModelListJson = $objJson->projetoStakeholdersModelList;
		if ($projetoStakeholdersModelListJson != null) {
			for ($i = 0; $i < count($projetoStakeholdersModelListJson); $i++) {
				$projetoStakeholders = new ProjetoStakeholdersModel();
				$projetoStakeholders->mapping($projetoStakeholdersModelListJson[$i]);
				$objModel->projetoStakeholdersModelList()->save($projetoStakeholders);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ProjetoCronogramaModel::where('id_projeto_principal', $object->getIdAttribute())->delete();
		ProjetoRiscoModel::where('id_projeto_principal', $object->getIdAttribute())->delete();
		ProjetoCustoModel::where('id_projeto_principal', $object->getIdAttribute())->delete();
		ProjetoStakeholdersModel::where('id_projeto_principal', $object->getIdAttribute())->delete();
	}	
 
}