<?php
declare(strict_types=1);

class ProjetoRiscoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'projeto_risco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function projetoPrincipalModel()
	{
		return $this->belongsTo(ProjetoPrincipalModel::class, 'id_projeto_principal', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getProbabilidadeAttribute()
	{
		return $this->attributes['probabilidade'];
	}

	public function setProbabilidadeAttribute($probabilidade)
	{
		$this->attributes['probabilidade'] = $probabilidade;
	}

	public function getImpactoAttribute()
	{
		return $this->attributes['impacto'];
	}

	public function setImpactoAttribute($impacto)
	{
		$this->attributes['impacto'] = $impacto;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setProbabilidadeAttribute($object->probabilidade);
				$this->setImpactoAttribute($object->impacto);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'probabilidade' => $this->getProbabilidadeAttribute(),
				'impacto' => $this->getImpactoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
			];
	}
}