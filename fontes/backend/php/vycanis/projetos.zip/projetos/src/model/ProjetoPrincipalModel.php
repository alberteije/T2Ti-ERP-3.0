<?php
declare(strict_types=1);

class ProjetoPrincipalModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'projeto_principal';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'projetoCronogramaModelList',
		'projetoRiscoModelList',
		'projetoCustoModelList',
		'projetoStakeholdersModelList',
	];

	/**
		* Relations
		*/
	public function projetoCronogramaModelList()
{
	return $this->hasMany(ProjetoCronogramaModel::class, 'id_projeto_principal', 'id');
}

	public function projetoRiscoModelList()
{
	return $this->hasMany(ProjetoRiscoModel::class, 'id_projeto_principal', 'id');
}

	public function projetoCustoModelList()
{
	return $this->hasMany(ProjetoCustoModel::class, 'id_projeto_principal', 'id');
}

	public function projetoStakeholdersModelList()
{
	return $this->hasMany(ProjetoStakeholdersModel::class, 'id_projeto_principal', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataPrevisaoFimAttribute()
	{
		return $this->attributes['data_previsao_fim'];
	}

	public function setDataPrevisaoFimAttribute($dataPrevisaoFim)
	{
		$this->attributes['data_previsao_fim'] = $dataPrevisaoFim;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getValorOrcamentoAttribute()
	{
		return (double)$this->attributes['valor_orcamento'];
	}

	public function setValorOrcamentoAttribute($valorOrcamento)
	{
		$this->attributes['valor_orcamento'] = $valorOrcamento;
	}

	public function getLinkQuadroKanbanAttribute()
	{
		return $this->attributes['link_quadro_kanban'];
	}

	public function setLinkQuadroKanbanAttribute($linkQuadroKanban)
	{
		$this->attributes['link_quadro_kanban'] = $linkQuadroKanban;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataPrevisaoFimAttribute($object->dataPrevisaoFim);
				$this->setDataFimAttribute($object->dataFim);
				$this->setValorOrcamentoAttribute($object->valorOrcamento);
				$this->setLinkQuadroKanbanAttribute($object->linkQuadroKanban);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataPrevisaoFim' => $this->getDataPrevisaoFimAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'valorOrcamento' => $this->getValorOrcamentoAttribute(),
				'linkQuadroKanban' => $this->getLinkQuadroKanbanAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'projetoCronogramaModelList' => $this->projetoCronogramaModelList,
				'projetoRiscoModelList' => $this->projetoRiscoModelList,
				'projetoCustoModelList' => $this->projetoCustoModelList,
				'projetoStakeholdersModelList' => $this->projetoStakeholdersModelList,
			];
	}
}