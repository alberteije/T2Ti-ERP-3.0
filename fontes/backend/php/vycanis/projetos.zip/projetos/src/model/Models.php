<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'ProjetoCronogramaModel.php';
include 'ProjetoStakeholdersModel.php';
include 'ProjetoRiscoModel.php';
include 'ProjetoCustoModel.php';
include 'ProjetoPrincipalModel.php';
include 'FinNaturezaFinanceiraModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';