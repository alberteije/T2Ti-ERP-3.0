<?php
declare(strict_types=1);

class ProjetoCronogramaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'projeto_cronograma';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function projetoPrincipalModel()
	{
		return $this->belongsTo(ProjetoPrincipalModel::class, 'id_projeto_principal', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTarefaAttribute()
	{
		return $this->attributes['tarefa'];
	}

	public function setTarefaAttribute($tarefa)
	{
		$this->attributes['tarefa'] = $tarefa;
	}

	public function getDataTarefaAttribute()
	{
		return $this->attributes['data_tarefa'];
	}

	public function setDataTarefaAttribute($dataTarefa)
	{
		$this->attributes['data_tarefa'] = $dataTarefa;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTarefaAttribute($object->tarefa);
				$this->setDataTarefaAttribute($object->dataTarefa);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tarefa' => $this->getTarefaAttribute(),
				'dataTarefa' => $this->getDataTarefaAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
			];
	}
}