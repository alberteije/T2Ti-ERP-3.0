<?php
declare(strict_types=1);

class ProjetoCustoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'projeto_custo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'finNaturezaFinanceiraModel',
	];

	/**
		* Relations
		*/
	public function projetoPrincipalModel()
	{
		return $this->belongsTo(ProjetoPrincipalModel::class, 'id_projeto_principal', 'id');
	}

	public function finNaturezaFinanceiraModel()
	{
		return $this->belongsTo(FinNaturezaFinanceiraModel::class, 'id_fin_natureza_financeira', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getValorMensalAttribute()
	{
		return (double)$this->attributes['valor_mensal'];
	}

	public function setValorMensalAttribute($valorMensal)
	{
		$this->attributes['valor_mensal'] = $valorMensal;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getJustificativaAttribute()
	{
		return $this->attributes['justificativa'];
	}

	public function setJustificativaAttribute($justificativa)
	{
		$this->attributes['justificativa'] = $justificativa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setValorMensalAttribute($object->valorMensal);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setJustificativaAttribute($object->justificativa);

				// link objects - lookups
				$finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel();
				$finNaturezaFinanceiraModel->mapping($object->finNaturezaFinanceiraModel);
				$this->finNaturezaFinanceiraModel()->associate($finNaturezaFinanceiraModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'valorMensal' => $this->getValorMensalAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'justificativa' => $this->getJustificativaAttribute(),
				'finNaturezaFinanceiraModel' => $this->finNaturezaFinanceiraModel,
			];
	}
}