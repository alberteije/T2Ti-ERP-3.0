<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// projeto-principal
$app->get('/projeto-principal[/]', \ProjetoPrincipalController::class . RESULT_LIST);
$app->get('/projeto-principal/{id}', \ProjetoPrincipalController::class . RESULT_OBJECT);
$app->post('/projeto-principal', \ProjetoPrincipalController::class . INSERT);
$app->put('/projeto-principal', \ProjetoPrincipalController::class . UPDATE);
$app->delete('/projeto-principal/{id}', \ProjetoPrincipalController::class . DELETE);
$app->options('/projeto-principal', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/projeto-principal/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/projeto-principal/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-natureza-financeira
$app->get('/fin-natureza-financeira[/]', \FinNaturezaFinanceiraController::class . RESULT_LIST);
$app->get('/fin-natureza-financeira/{id}', \FinNaturezaFinanceiraController::class . RESULT_OBJECT);
$app->post('/fin-natureza-financeira', \FinNaturezaFinanceiraController::class . INSERT);
$app->put('/fin-natureza-financeira', \FinNaturezaFinanceiraController::class . UPDATE);
$app->delete('/fin-natureza-financeira/{id}', \FinNaturezaFinanceiraController::class . DELETE);
$app->options('/fin-natureza-financeira', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-natureza-financeira/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-natureza-financeira/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

