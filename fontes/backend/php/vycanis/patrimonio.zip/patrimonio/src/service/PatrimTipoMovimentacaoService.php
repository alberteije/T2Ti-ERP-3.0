<?php
class PatrimTipoMovimentacaoService extends ServiceBase
{
  public function getList()
  {
    return PatrimTipoMovimentacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PatrimTipoMovimentacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PatrimTipoMovimentacaoModel::find($id);
  }

}