<?php
class SeguradoraService extends ServiceBase
{
  public function getList()
  {
    return SeguradoraModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SeguradoraModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SeguradoraModel::find($id);
  }

}