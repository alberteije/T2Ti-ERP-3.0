<?php
declare(strict_types=1);

class PatrimIndiceAtualizacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_indice_atualizacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataIndiceAttribute()
	{
		return $this->attributes['data_indice'];
	}

	public function setDataIndiceAttribute($dataIndice)
	{
		$this->attributes['data_indice'] = $dataIndice;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getValorAlternativoAttribute()
	{
		return (double)$this->attributes['valor_alternativo'];
	}

	public function setValorAlternativoAttribute($valorAlternativo)
	{
		$this->attributes['valor_alternativo'] = $valorAlternativo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataIndiceAttribute($object->dataIndice);
				$this->setNomeAttribute($object->nome);
				$this->setValorAttribute($object->valor);
				$this->setValorAlternativoAttribute($object->valorAlternativo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataIndice' => $this->getDataIndiceAttribute(),
				'nome' => $this->getNomeAttribute(),
				'valor' => $this->getValorAttribute(),
				'valorAlternativo' => $this->getValorAlternativoAttribute(),
			];
	}
}