<?php
declare(strict_types=1);

class PatrimBemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_bem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'patrimDocumentoBemModelList',
		'patrimDepreciacaoBemModelList',
		'patrimMovimentacaoBemModelList',
		'patrimApoliceSeguroModelList',
		'centroResultadoModel',
		'patrimEstadoConservacaoModel',
		'setorModel',
		'viewPessoaFornecedorModel',
		'patrimTipoAquisicaoBemModel',
		'patrimGrupoBemModel',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function patrimDocumentoBemModelList()
{
	return $this->hasMany(PatrimDocumentoBemModel::class, 'id_patrim_bem', 'id');
}

	public function patrimDepreciacaoBemModelList()
{
	return $this->hasMany(PatrimDepreciacaoBemModel::class, 'id_patrim_bem', 'id');
}

	public function patrimMovimentacaoBemModelList()
{
	return $this->hasMany(PatrimMovimentacaoBemModel::class, 'id_patrim_bem', 'id');
}

	public function patrimApoliceSeguroModelList()
{
	return $this->hasMany(PatrimApoliceSeguroModel::class, 'id_patrim_bem', 'id');
}

	public function centroResultadoModel()
	{
		return $this->belongsTo(CentroResultadoModel::class, 'id_centro_resultado', 'id');
	}

	public function patrimEstadoConservacaoModel()
	{
		return $this->belongsTo(PatrimEstadoConservacaoModel::class, 'id_patrim_estado_conservacao', 'id');
	}

	public function setorModel()
	{
		return $this->belongsTo(SetorModel::class, 'id_setor', 'id');
	}

	public function viewPessoaFornecedorModel()
	{
		return $this->belongsTo(ViewPessoaFornecedorModel::class, 'id_fornecedor', 'id');
	}

	public function patrimTipoAquisicaoBemModel()
	{
		return $this->belongsTo(PatrimTipoAquisicaoBemModel::class, 'id_patrim_tipo_aquisicao_bem', 'id');
	}

	public function patrimGrupoBemModel()
	{
		return $this->belongsTo(PatrimGrupoBemModel::class, 'id_patrim_grupo_bem', 'id');
	}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroNbAttribute()
	{
		return $this->attributes['numero_nb'];
	}

	public function setNumeroNbAttribute($numeroNb)
	{
		$this->attributes['numero_nb'] = $numeroNb;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getDataAquisicaoAttribute()
	{
		return $this->attributes['data_aquisicao'];
	}

	public function setDataAquisicaoAttribute($dataAquisicao)
	{
		$this->attributes['data_aquisicao'] = $dataAquisicao;
	}

	public function getDataAceiteAttribute()
	{
		return $this->attributes['data_aceite'];
	}

	public function setDataAceiteAttribute($dataAceite)
	{
		$this->attributes['data_aceite'] = $dataAceite;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getDataContabilizadoAttribute()
	{
		return $this->attributes['data_contabilizado'];
	}

	public function setDataContabilizadoAttribute($dataContabilizado)
	{
		$this->attributes['data_contabilizado'] = $dataContabilizado;
	}

	public function getDataVistoriaAttribute()
	{
		return $this->attributes['data_vistoria'];
	}

	public function setDataVistoriaAttribute($dataVistoria)
	{
		$this->attributes['data_vistoria'] = $dataVistoria;
	}

	public function getDataMarcacaoAttribute()
	{
		return $this->attributes['data_marcacao'];
	}

	public function setDataMarcacaoAttribute($dataMarcacao)
	{
		$this->attributes['data_marcacao'] = $dataMarcacao;
	}

	public function getDataBaixaAttribute()
	{
		return $this->attributes['data_baixa'];
	}

	public function setDataBaixaAttribute($dataBaixa)
	{
		$this->attributes['data_baixa'] = $dataBaixa;
	}

	public function getVencimentoGarantiaAttribute()
	{
		return $this->attributes['vencimento_garantia'];
	}

	public function setVencimentoGarantiaAttribute($vencimentoGarantia)
	{
		$this->attributes['vencimento_garantia'] = $vencimentoGarantia;
	}

	public function getNumeroNotaFiscalAttribute()
	{
		return $this->attributes['numero_nota_fiscal'];
	}

	public function setNumeroNotaFiscalAttribute($numeroNotaFiscal)
	{
		$this->attributes['numero_nota_fiscal'] = $numeroNotaFiscal;
	}

	public function getNumeroSerieAttribute()
	{
		return $this->attributes['numero_serie'];
	}

	public function setNumeroSerieAttribute($numeroSerie)
	{
		$this->attributes['numero_serie'] = $numeroSerie;
	}

	public function getChaveNfeAttribute()
	{
		return $this->attributes['chave_nfe'];
	}

	public function setChaveNfeAttribute($chaveNfe)
	{
		$this->attributes['chave_nfe'] = $chaveNfe;
	}

	public function getValorOriginalAttribute()
	{
		return (double)$this->attributes['valor_original'];
	}

	public function setValorOriginalAttribute($valorOriginal)
	{
		$this->attributes['valor_original'] = $valorOriginal;
	}

	public function getValorCompraAttribute()
	{
		return (double)$this->attributes['valor_compra'];
	}

	public function setValorCompraAttribute($valorCompra)
	{
		$this->attributes['valor_compra'] = $valorCompra;
	}

	public function getValorAtualizadoAttribute()
	{
		return (double)$this->attributes['valor_atualizado'];
	}

	public function setValorAtualizadoAttribute($valorAtualizado)
	{
		$this->attributes['valor_atualizado'] = $valorAtualizado;
	}

	public function getValorBaixaAttribute()
	{
		return (double)$this->attributes['valor_baixa'];
	}

	public function setValorBaixaAttribute($valorBaixa)
	{
		$this->attributes['valor_baixa'] = $valorBaixa;
	}

	public function getDepreciaAttribute()
	{
		return $this->attributes['deprecia'];
	}

	public function setDepreciaAttribute($deprecia)
	{
		$this->attributes['deprecia'] = $deprecia;
	}

	public function getMetodoDepreciacaoAttribute()
	{
		return $this->attributes['metodo_depreciacao'];
	}

	public function setMetodoDepreciacaoAttribute($metodoDepreciacao)
	{
		$this->attributes['metodo_depreciacao'] = $metodoDepreciacao;
	}

	public function getInicioDepreciacaoAttribute()
	{
		return $this->attributes['inicio_depreciacao'];
	}

	public function setInicioDepreciacaoAttribute($inicioDepreciacao)
	{
		$this->attributes['inicio_depreciacao'] = $inicioDepreciacao;
	}

	public function getUltimaDepreciacaoAttribute()
	{
		return $this->attributes['ultima_depreciacao'];
	}

	public function setUltimaDepreciacaoAttribute($ultimaDepreciacao)
	{
		$this->attributes['ultima_depreciacao'] = $ultimaDepreciacao;
	}

	public function getTipoDepreciacaoAttribute()
	{
		return $this->attributes['tipo_depreciacao'];
	}

	public function setTipoDepreciacaoAttribute($tipoDepreciacao)
	{
		$this->attributes['tipo_depreciacao'] = $tipoDepreciacao;
	}

	public function getTaxaAnualDepreciacaoAttribute()
	{
		return (double)$this->attributes['taxa_anual_depreciacao'];
	}

	public function setTaxaAnualDepreciacaoAttribute($taxaAnualDepreciacao)
	{
		$this->attributes['taxa_anual_depreciacao'] = $taxaAnualDepreciacao;
	}

	public function getTaxaMensalDepreciacaoAttribute()
	{
		return (double)$this->attributes['taxa_mensal_depreciacao'];
	}

	public function setTaxaMensalDepreciacaoAttribute($taxaMensalDepreciacao)
	{
		$this->attributes['taxa_mensal_depreciacao'] = $taxaMensalDepreciacao;
	}

	public function getTaxaDepreciacaoAceleradaAttribute()
	{
		return (double)$this->attributes['taxa_depreciacao_acelerada'];
	}

	public function setTaxaDepreciacaoAceleradaAttribute($taxaDepreciacaoAcelerada)
	{
		$this->attributes['taxa_depreciacao_acelerada'] = $taxaDepreciacaoAcelerada;
	}

	public function getTaxaDepreciacaoIncentivadaAttribute()
	{
		return (double)$this->attributes['taxa_depreciacao_incentivada'];
	}

	public function setTaxaDepreciacaoIncentivadaAttribute($taxaDepreciacaoIncentivada)
	{
		$this->attributes['taxa_depreciacao_incentivada'] = $taxaDepreciacaoIncentivada;
	}

	public function getFuncaoAttribute()
	{
		return $this->attributes['funcao'];
	}

	public function setFuncaoAttribute($funcao)
	{
		$this->attributes['funcao'] = $funcao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroNbAttribute($object->numeroNb);
				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setDataAquisicaoAttribute($object->dataAquisicao);
				$this->setDataAceiteAttribute($object->dataAceite);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setDataContabilizadoAttribute($object->dataContabilizado);
				$this->setDataVistoriaAttribute($object->dataVistoria);
				$this->setDataMarcacaoAttribute($object->dataMarcacao);
				$this->setDataBaixaAttribute($object->dataBaixa);
				$this->setVencimentoGarantiaAttribute($object->vencimentoGarantia);
				$this->setNumeroNotaFiscalAttribute($object->numeroNotaFiscal);
				$this->setNumeroSerieAttribute($object->numeroSerie);
				$this->setChaveNfeAttribute($object->chaveNfe);
				$this->setValorOriginalAttribute($object->valorOriginal);
				$this->setValorCompraAttribute($object->valorCompra);
				$this->setValorAtualizadoAttribute($object->valorAtualizado);
				$this->setValorBaixaAttribute($object->valorBaixa);
				$this->setDepreciaAttribute($object->deprecia);
				$this->setMetodoDepreciacaoAttribute($object->metodoDepreciacao);
				$this->setInicioDepreciacaoAttribute($object->inicioDepreciacao);
				$this->setUltimaDepreciacaoAttribute($object->ultimaDepreciacao);
				$this->setTipoDepreciacaoAttribute($object->tipoDepreciacao);
				$this->setTaxaAnualDepreciacaoAttribute($object->taxaAnualDepreciacao);
				$this->setTaxaMensalDepreciacaoAttribute($object->taxaMensalDepreciacao);
				$this->setTaxaDepreciacaoAceleradaAttribute($object->taxaDepreciacaoAcelerada);
				$this->setTaxaDepreciacaoIncentivadaAttribute($object->taxaDepreciacaoIncentivada);
				$this->setFuncaoAttribute($object->funcao);

				// link objects - lookups
				$centroResultadoModel = new CentroResultadoModel();
				$centroResultadoModel->mapping($object->centroResultadoModel);
				$this->centroResultadoModel()->associate($centroResultadoModel);
				$patrimEstadoConservacaoModel = new PatrimEstadoConservacaoModel();
				$patrimEstadoConservacaoModel->mapping($object->patrimEstadoConservacaoModel);
				$this->patrimEstadoConservacaoModel()->associate($patrimEstadoConservacaoModel);
				$setorModel = new SetorModel();
				$setorModel->mapping($object->setorModel);
				$this->setorModel()->associate($setorModel);
				$viewPessoaFornecedorModel = new ViewPessoaFornecedorModel();
				$viewPessoaFornecedorModel->mapping($object->viewPessoaFornecedorModel);
				$this->viewPessoaFornecedorModel()->associate($viewPessoaFornecedorModel);
				$patrimTipoAquisicaoBemModel = new PatrimTipoAquisicaoBemModel();
				$patrimTipoAquisicaoBemModel->mapping($object->patrimTipoAquisicaoBemModel);
				$this->patrimTipoAquisicaoBemModel()->associate($patrimTipoAquisicaoBemModel);
				$patrimGrupoBemModel = new PatrimGrupoBemModel();
				$patrimGrupoBemModel->mapping($object->patrimGrupoBemModel);
				$this->patrimGrupoBemModel()->associate($patrimGrupoBemModel);
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroNb' => $this->getNumeroNbAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'dataAquisicao' => $this->getDataAquisicaoAttribute(),
				'dataAceite' => $this->getDataAceiteAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'dataContabilizado' => $this->getDataContabilizadoAttribute(),
				'dataVistoria' => $this->getDataVistoriaAttribute(),
				'dataMarcacao' => $this->getDataMarcacaoAttribute(),
				'dataBaixa' => $this->getDataBaixaAttribute(),
				'vencimentoGarantia' => $this->getVencimentoGarantiaAttribute(),
				'numeroNotaFiscal' => $this->getNumeroNotaFiscalAttribute(),
				'numeroSerie' => $this->getNumeroSerieAttribute(),
				'chaveNfe' => $this->getChaveNfeAttribute(),
				'valorOriginal' => $this->getValorOriginalAttribute(),
				'valorCompra' => $this->getValorCompraAttribute(),
				'valorAtualizado' => $this->getValorAtualizadoAttribute(),
				'valorBaixa' => $this->getValorBaixaAttribute(),
				'deprecia' => $this->getDepreciaAttribute(),
				'metodoDepreciacao' => $this->getMetodoDepreciacaoAttribute(),
				'inicioDepreciacao' => $this->getInicioDepreciacaoAttribute(),
				'ultimaDepreciacao' => $this->getUltimaDepreciacaoAttribute(),
				'tipoDepreciacao' => $this->getTipoDepreciacaoAttribute(),
				'taxaAnualDepreciacao' => $this->getTaxaAnualDepreciacaoAttribute(),
				'taxaMensalDepreciacao' => $this->getTaxaMensalDepreciacaoAttribute(),
				'taxaDepreciacaoAcelerada' => $this->getTaxaDepreciacaoAceleradaAttribute(),
				'taxaDepreciacaoIncentivada' => $this->getTaxaDepreciacaoIncentivadaAttribute(),
				'funcao' => $this->getFuncaoAttribute(),
				'patrimDocumentoBemModelList' => $this->patrimDocumentoBemModelList,
				'patrimDepreciacaoBemModelList' => $this->patrimDepreciacaoBemModelList,
				'patrimMovimentacaoBemModelList' => $this->patrimMovimentacaoBemModelList,
				'patrimApoliceSeguroModelList' => $this->patrimApoliceSeguroModelList,
				'centroResultadoModel' => $this->centroResultadoModel,
				'patrimEstadoConservacaoModel' => $this->patrimEstadoConservacaoModel,
				'setorModel' => $this->setorModel,
				'viewPessoaFornecedorModel' => $this->viewPessoaFornecedorModel,
				'patrimTipoAquisicaoBemModel' => $this->patrimTipoAquisicaoBemModel,
				'patrimGrupoBemModel' => $this->patrimGrupoBemModel,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}