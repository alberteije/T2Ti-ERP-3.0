<?php
declare(strict_types=1);

class PatrimDepreciacaoBemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_depreciacao_bem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function patrimBemModel()
	{
		return $this->belongsTo(PatrimBemModel::class, 'id_patrim_bem', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataDepreciacaoAttribute()
	{
		return $this->attributes['data_depreciacao'];
	}

	public function setDataDepreciacaoAttribute($dataDepreciacao)
	{
		$this->attributes['data_depreciacao'] = $dataDepreciacao;
	}

	public function getDiasAttribute()
	{
		return $this->attributes['dias'];
	}

	public function setDiasAttribute($dias)
	{
		$this->attributes['dias'] = $dias;
	}

	public function getTaxaAttribute()
	{
		return (double)$this->attributes['taxa'];
	}

	public function setTaxaAttribute($taxa)
	{
		$this->attributes['taxa'] = $taxa;
	}

	public function getIndiceAttribute()
	{
		return (double)$this->attributes['indice'];
	}

	public function setIndiceAttribute($indice)
	{
		$this->attributes['indice'] = $indice;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getDepreciacaoAcumuladaAttribute()
	{
		return (double)$this->attributes['depreciacao_acumulada'];
	}

	public function setDepreciacaoAcumuladaAttribute($depreciacaoAcumulada)
	{
		$this->attributes['depreciacao_acumulada'] = $depreciacaoAcumulada;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataDepreciacaoAttribute($object->dataDepreciacao);
				$this->setDiasAttribute($object->dias);
				$this->setTaxaAttribute($object->taxa);
				$this->setIndiceAttribute($object->indice);
				$this->setValorAttribute($object->valor);
				$this->setDepreciacaoAcumuladaAttribute($object->depreciacaoAcumulada);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataDepreciacao' => $this->getDataDepreciacaoAttribute(),
				'dias' => $this->getDiasAttribute(),
				'taxa' => $this->getTaxaAttribute(),
				'indice' => $this->getIndiceAttribute(),
				'valor' => $this->getValorAttribute(),
				'depreciacaoAcumulada' => $this->getDepreciacaoAcumuladaAttribute(),
			];
	}
}