<?php
declare(strict_types=1);

class PatrimGrupoBemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_grupo_bem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getContaAtivoImobilizadoAttribute()
	{
		return $this->attributes['conta_ativo_imobilizado'];
	}

	public function setContaAtivoImobilizadoAttribute($contaAtivoImobilizado)
	{
		$this->attributes['conta_ativo_imobilizado'] = $contaAtivoImobilizado;
	}

	public function getContaDepreciacaoAcumuladaAttribute()
	{
		return $this->attributes['conta_depreciacao_acumulada'];
	}

	public function setContaDepreciacaoAcumuladaAttribute($contaDepreciacaoAcumulada)
	{
		$this->attributes['conta_depreciacao_acumulada'] = $contaDepreciacaoAcumulada;
	}

	public function getContaDespesaDepreciacaoAttribute()
	{
		return $this->attributes['conta_despesa_depreciacao'];
	}

	public function setContaDespesaDepreciacaoAttribute($contaDespesaDepreciacao)
	{
		$this->attributes['conta_despesa_depreciacao'] = $contaDespesaDepreciacao;
	}

	public function getCodigoHistoricoAttribute()
	{
		return $this->attributes['codigo_historico'];
	}

	public function setCodigoHistoricoAttribute($codigoHistorico)
	{
		$this->attributes['codigo_historico'] = $codigoHistorico;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setContaAtivoImobilizadoAttribute($object->contaAtivoImobilizado);
				$this->setContaDepreciacaoAcumuladaAttribute($object->contaDepreciacaoAcumulada);
				$this->setContaDespesaDepreciacaoAttribute($object->contaDespesaDepreciacao);
				$this->setCodigoHistoricoAttribute($object->codigoHistorico);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'contaAtivoImobilizado' => $this->getContaAtivoImobilizadoAttribute(),
				'contaDepreciacaoAcumulada' => $this->getContaDepreciacaoAcumuladaAttribute(),
				'contaDespesaDepreciacao' => $this->getContaDespesaDepreciacaoAttribute(),
				'codigoHistorico' => $this->getCodigoHistoricoAttribute(),
			];
	}
}