<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// patrim-bem
$app->get('/patrim-bem[/]', \PatrimBemController::class . RESULT_LIST);
$app->get('/patrim-bem/{id}', \PatrimBemController::class . RESULT_OBJECT);
$app->post('/patrim-bem', \PatrimBemController::class . INSERT);
$app->put('/patrim-bem', \PatrimBemController::class . UPDATE);
$app->delete('/patrim-bem/{id}', \PatrimBemController::class . DELETE);
$app->options('/patrim-bem', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-bem/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-bem/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// setor
$app->get('/setor[/]', \SetorController::class . RESULT_LIST);
$app->get('/setor/{id}', \SetorController::class . RESULT_OBJECT);
$app->post('/setor', \SetorController::class . INSERT);
$app->put('/setor', \SetorController::class . UPDATE);
$app->delete('/setor/{id}', \SetorController::class . DELETE);
$app->options('/setor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// centro-resultado
$app->get('/centro-resultado[/]', \CentroResultadoController::class . RESULT_LIST);
$app->get('/centro-resultado/{id}', \CentroResultadoController::class . RESULT_OBJECT);
$app->post('/centro-resultado', \CentroResultadoController::class . INSERT);
$app->put('/centro-resultado', \CentroResultadoController::class . UPDATE);
$app->delete('/centro-resultado/{id}', \CentroResultadoController::class . DELETE);
$app->options('/centro-resultado', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/centro-resultado/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/centro-resultado/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// patrim-indice-atualizacao
$app->get('/patrim-indice-atualizacao[/]', \PatrimIndiceAtualizacaoController::class . RESULT_LIST);
$app->get('/patrim-indice-atualizacao/{id}', \PatrimIndiceAtualizacaoController::class . RESULT_OBJECT);
$app->post('/patrim-indice-atualizacao', \PatrimIndiceAtualizacaoController::class . INSERT);
$app->put('/patrim-indice-atualizacao', \PatrimIndiceAtualizacaoController::class . UPDATE);
$app->delete('/patrim-indice-atualizacao/{id}', \PatrimIndiceAtualizacaoController::class . DELETE);
$app->options('/patrim-indice-atualizacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-indice-atualizacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-indice-atualizacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// patrim-taxa-depreciacao
$app->get('/patrim-taxa-depreciacao[/]', \PatrimTaxaDepreciacaoController::class . RESULT_LIST);
$app->get('/patrim-taxa-depreciacao/{id}', \PatrimTaxaDepreciacaoController::class . RESULT_OBJECT);
$app->post('/patrim-taxa-depreciacao', \PatrimTaxaDepreciacaoController::class . INSERT);
$app->put('/patrim-taxa-depreciacao', \PatrimTaxaDepreciacaoController::class . UPDATE);
$app->delete('/patrim-taxa-depreciacao/{id}', \PatrimTaxaDepreciacaoController::class . DELETE);
$app->options('/patrim-taxa-depreciacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-taxa-depreciacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-taxa-depreciacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// patrim-grupo-bem
$app->get('/patrim-grupo-bem[/]', \PatrimGrupoBemController::class . RESULT_LIST);
$app->get('/patrim-grupo-bem/{id}', \PatrimGrupoBemController::class . RESULT_OBJECT);
$app->post('/patrim-grupo-bem', \PatrimGrupoBemController::class . INSERT);
$app->put('/patrim-grupo-bem', \PatrimGrupoBemController::class . UPDATE);
$app->delete('/patrim-grupo-bem/{id}', \PatrimGrupoBemController::class . DELETE);
$app->options('/patrim-grupo-bem', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-grupo-bem/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-grupo-bem/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// patrim-tipo-aquisicao-bem
$app->get('/patrim-tipo-aquisicao-bem[/]', \PatrimTipoAquisicaoBemController::class . RESULT_LIST);
$app->get('/patrim-tipo-aquisicao-bem/{id}', \PatrimTipoAquisicaoBemController::class . RESULT_OBJECT);
$app->post('/patrim-tipo-aquisicao-bem', \PatrimTipoAquisicaoBemController::class . INSERT);
$app->put('/patrim-tipo-aquisicao-bem', \PatrimTipoAquisicaoBemController::class . UPDATE);
$app->delete('/patrim-tipo-aquisicao-bem/{id}', \PatrimTipoAquisicaoBemController::class . DELETE);
$app->options('/patrim-tipo-aquisicao-bem', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-tipo-aquisicao-bem/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-tipo-aquisicao-bem/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// patrim-estado-conservacao
$app->get('/patrim-estado-conservacao[/]', \PatrimEstadoConservacaoController::class . RESULT_LIST);
$app->get('/patrim-estado-conservacao/{id}', \PatrimEstadoConservacaoController::class . RESULT_OBJECT);
$app->post('/patrim-estado-conservacao', \PatrimEstadoConservacaoController::class . INSERT);
$app->put('/patrim-estado-conservacao', \PatrimEstadoConservacaoController::class . UPDATE);
$app->delete('/patrim-estado-conservacao/{id}', \PatrimEstadoConservacaoController::class . DELETE);
$app->options('/patrim-estado-conservacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-estado-conservacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-estado-conservacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// seguradora
$app->get('/seguradora[/]', \SeguradoraController::class . RESULT_LIST);
$app->get('/seguradora/{id}', \SeguradoraController::class . RESULT_OBJECT);
$app->post('/seguradora', \SeguradoraController::class . INSERT);
$app->put('/seguradora', \SeguradoraController::class . UPDATE);
$app->delete('/seguradora/{id}', \SeguradoraController::class . DELETE);
$app->options('/seguradora', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/seguradora/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/seguradora/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// patrim-tipo-movimentacao
$app->get('/patrim-tipo-movimentacao[/]', \PatrimTipoMovimentacaoController::class . RESULT_LIST);
$app->get('/patrim-tipo-movimentacao/{id}', \PatrimTipoMovimentacaoController::class . RESULT_OBJECT);
$app->post('/patrim-tipo-movimentacao', \PatrimTipoMovimentacaoController::class . INSERT);
$app->put('/patrim-tipo-movimentacao', \PatrimTipoMovimentacaoController::class . UPDATE);
$app->delete('/patrim-tipo-movimentacao/{id}', \PatrimTipoMovimentacaoController::class . DELETE);
$app->options('/patrim-tipo-movimentacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-tipo-movimentacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/patrim-tipo-movimentacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-fornecedor
$app->get('/view-pessoa-fornecedor[/]', \ViewPessoaFornecedorController::class . RESULT_LIST);
$app->get('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . INSERT);
$app->put('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . UPDATE);
$app->delete('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . DELETE);
$app->options('/view-pessoa-fornecedor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

