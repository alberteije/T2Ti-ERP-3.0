<?php
use Illuminate\Database\Capsule\Manager as DB;
class PatrimBemService extends ServiceBase
{
	public function getList()
	{
		return PatrimBemModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return PatrimBemModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return PatrimBemModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// patrimDocumentoBem
		$patrimDocumentoBemModelListJson = $objJson->patrimDocumentoBemModelList;
		if ($patrimDocumentoBemModelListJson != null) {
			for ($i = 0; $i < count($patrimDocumentoBemModelListJson); $i++) {
				$patrimDocumentoBem = new PatrimDocumentoBemModel();
				$patrimDocumentoBem->mapping($patrimDocumentoBemModelListJson[$i]);
				$objModel->patrimDocumentoBemModelList()->save($patrimDocumentoBem);
			}
		}

		// patrimDepreciacaoBem
		$patrimDepreciacaoBemModelListJson = $objJson->patrimDepreciacaoBemModelList;
		if ($patrimDepreciacaoBemModelListJson != null) {
			for ($i = 0; $i < count($patrimDepreciacaoBemModelListJson); $i++) {
				$patrimDepreciacaoBem = new PatrimDepreciacaoBemModel();
				$patrimDepreciacaoBem->mapping($patrimDepreciacaoBemModelListJson[$i]);
				$objModel->patrimDepreciacaoBemModelList()->save($patrimDepreciacaoBem);
			}
		}

		// patrimMovimentacaoBem
		$patrimMovimentacaoBemModelListJson = $objJson->patrimMovimentacaoBemModelList;
		if ($patrimMovimentacaoBemModelListJson != null) {
			for ($i = 0; $i < count($patrimMovimentacaoBemModelListJson); $i++) {
				$patrimMovimentacaoBem = new PatrimMovimentacaoBemModel();
				$patrimMovimentacaoBem->mapping($patrimMovimentacaoBemModelListJson[$i]);
				$objModel->patrimMovimentacaoBemModelList()->save($patrimMovimentacaoBem);
			}
		}

		// patrimApoliceSeguro
		$patrimApoliceSeguroModelListJson = $objJson->patrimApoliceSeguroModelList;
		if ($patrimApoliceSeguroModelListJson != null) {
			for ($i = 0; $i < count($patrimApoliceSeguroModelListJson); $i++) {
				$patrimApoliceSeguro = new PatrimApoliceSeguroModel();
				$patrimApoliceSeguro->mapping($patrimApoliceSeguroModelListJson[$i]);
				$objModel->patrimApoliceSeguroModelList()->save($patrimApoliceSeguro);
			}
		}

	}	

	public function deleteChildren($object)
	{
		PatrimDocumentoBemModel::where('id_patrim_bem', $object->getIdAttribute())->delete();
		PatrimDepreciacaoBemModel::where('id_patrim_bem', $object->getIdAttribute())->delete();
		PatrimMovimentacaoBemModel::where('id_patrim_bem', $object->getIdAttribute())->delete();
		PatrimApoliceSeguroModel::where('id_patrim_bem', $object->getIdAttribute())->delete();
	}	
 
}