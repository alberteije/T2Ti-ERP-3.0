<?php
class PatrimEstadoConservacaoService extends ServiceBase
{
  public function getList()
  {
    return PatrimEstadoConservacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PatrimEstadoConservacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PatrimEstadoConservacaoModel::find($id);
  }

}