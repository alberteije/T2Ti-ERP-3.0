<?php
class PatrimTipoAquisicaoBemService extends ServiceBase
{
  public function getList()
  {
    return PatrimTipoAquisicaoBemModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PatrimTipoAquisicaoBemModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PatrimTipoAquisicaoBemModel::find($id);
  }

}