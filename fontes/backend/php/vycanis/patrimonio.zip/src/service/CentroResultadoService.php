<?php
class CentroResultadoService extends ServiceBase
{
  public function getList()
  {
    return CentroResultadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CentroResultadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CentroResultadoModel::find($id);
  }

}