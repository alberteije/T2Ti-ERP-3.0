<?php

include 'ServiceBase.php';

include 'PatrimBemService.php';
include 'SetorService.php';
include 'CentroResultadoService.php';
include 'PatrimIndiceAtualizacaoService.php';
include 'PatrimTaxaDepreciacaoService.php';
include 'PatrimGrupoBemService.php';
include 'PatrimTipoAquisicaoBemService.php';
include 'PatrimEstadoConservacaoService.php';
include 'SeguradoraService.php';
include 'PatrimTipoMovimentacaoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaFornecedorService.php';
include 'ViewPessoaColaboradorService.php';