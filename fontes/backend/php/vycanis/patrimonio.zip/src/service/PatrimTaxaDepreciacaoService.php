<?php
class PatrimTaxaDepreciacaoService extends ServiceBase
{
  public function getList()
  {
    return PatrimTaxaDepreciacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PatrimTaxaDepreciacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PatrimTaxaDepreciacaoModel::find($id);
  }

}