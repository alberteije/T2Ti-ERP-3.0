<?php
class PatrimGrupoBemService extends ServiceBase
{
  public function getList()
  {
    return PatrimGrupoBemModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PatrimGrupoBemModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PatrimGrupoBemModel::find($id);
  }

}