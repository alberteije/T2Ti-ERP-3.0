<?php
class PatrimIndiceAtualizacaoService extends ServiceBase
{
  public function getList()
  {
    return PatrimIndiceAtualizacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PatrimIndiceAtualizacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PatrimIndiceAtualizacaoModel::find($id);
  }

}