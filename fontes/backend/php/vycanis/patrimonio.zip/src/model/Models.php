<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'PatrimDocumentoBemModel.php';
include 'PatrimDepreciacaoBemModel.php';
include 'PatrimMovimentacaoBemModel.php';
include 'PatrimApoliceSeguroModel.php';
include 'PatrimBemModel.php';
include 'SetorModel.php';
include 'CentroResultadoModel.php';
include 'PatrimIndiceAtualizacaoModel.php';
include 'PatrimTaxaDepreciacaoModel.php';
include 'PatrimGrupoBemModel.php';
include 'PatrimTipoAquisicaoBemModel.php';
include 'PatrimEstadoConservacaoModel.php';
include 'SeguradoraModel.php';
include 'PatrimTipoMovimentacaoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaFornecedorModel.php';
include 'ViewPessoaColaboradorModel.php';