<?php
declare(strict_types=1);

class PatrimMovimentacaoBemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_movimentacao_bem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'patrimTipoMovimentacaoModel',
	];

	/**
		* Relations
		*/
	public function patrimBemModel()
	{
		return $this->belongsTo(PatrimBemModel::class, 'id_patrim_bem', 'id');
	}

	public function patrimTipoMovimentacaoModel()
	{
		return $this->belongsTo(PatrimTipoMovimentacaoModel::class, 'id_patrim_tipo_movimentacao', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataMovimentacaoAttribute()
	{
		return $this->attributes['data_movimentacao'];
	}

	public function setDataMovimentacaoAttribute($dataMovimentacao)
	{
		$this->attributes['data_movimentacao'] = $dataMovimentacao;
	}

	public function getResponsavelAttribute()
	{
		return $this->attributes['responsavel'];
	}

	public function setResponsavelAttribute($responsavel)
	{
		$this->attributes['responsavel'] = $responsavel;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataMovimentacaoAttribute($object->dataMovimentacao);
				$this->setResponsavelAttribute($object->responsavel);

				// link objects - lookups
				$patrimTipoMovimentacaoModel = new PatrimTipoMovimentacaoModel();
				$patrimTipoMovimentacaoModel->mapping($object->patrimTipoMovimentacaoModel);
				$this->patrimTipoMovimentacaoModel()->associate($patrimTipoMovimentacaoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataMovimentacao' => $this->getDataMovimentacaoAttribute(),
				'responsavel' => $this->getResponsavelAttribute(),
				'patrimTipoMovimentacaoModel' => $this->patrimTipoMovimentacaoModel,
			];
	}
}