<?php
declare(strict_types=1);

class PatrimApoliceSeguroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_apolice_seguro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'seguradoraModel',
	];

	/**
		* Relations
		*/
	public function patrimBemModel()
	{
		return $this->belongsTo(PatrimBemModel::class, 'id_patrim_bem', 'id');
	}

	public function seguradoraModel()
	{
		return $this->belongsTo(SeguradoraModel::class, 'id_seguradora', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataContratacaoAttribute()
	{
		return $this->attributes['data_contratacao'];
	}

	public function setDataContratacaoAttribute($dataContratacao)
	{
		$this->attributes['data_contratacao'] = $dataContratacao;
	}

	public function getDataVencimentoAttribute()
	{
		return $this->attributes['data_vencimento'];
	}

	public function setDataVencimentoAttribute($dataVencimento)
	{
		$this->attributes['data_vencimento'] = $dataVencimento;
	}

	public function getValorPremioAttribute()
	{
		return (double)$this->attributes['valor_premio'];
	}

	public function setValorPremioAttribute($valorPremio)
	{
		$this->attributes['valor_premio'] = $valorPremio;
	}

	public function getValorSeguradoAttribute()
	{
		return (double)$this->attributes['valor_segurado'];
	}

	public function setValorSeguradoAttribute($valorSegurado)
	{
		$this->attributes['valor_segurado'] = $valorSegurado;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	public function getImagemAttribute()
	{
		return $this->attributes['imagem'];
	}

	public function setImagemAttribute($imagem)
	{
		$this->attributes['imagem'] = $imagem;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setDataContratacaoAttribute($object->dataContratacao);
				$this->setDataVencimentoAttribute($object->dataVencimento);
				$this->setValorPremioAttribute($object->valorPremio);
				$this->setValorSeguradoAttribute($object->valorSegurado);
				$this->setObservacaoAttribute($object->observacao);
				$this->setImagemAttribute($object->imagem);

				// link objects - lookups
				$seguradoraModel = new SeguradoraModel();
				$seguradoraModel->mapping($object->seguradoraModel);
				$this->seguradoraModel()->associate($seguradoraModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataContratacao' => $this->getDataContratacaoAttribute(),
				'dataVencimento' => $this->getDataVencimentoAttribute(),
				'valorPremio' => $this->getValorPremioAttribute(),
				'valorSegurado' => $this->getValorSeguradoAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'imagem' => $this->getImagemAttribute(),
				'seguradoraModel' => $this->seguradoraModel,
			];
	}
}