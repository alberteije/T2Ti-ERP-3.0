<?php
declare(strict_types=1);

class PatrimTaxaDepreciacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'patrim_taxa_depreciacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNcmAttribute()
	{
		return $this->attributes['ncm'];
	}

	public function setNcmAttribute($ncm)
	{
		$this->attributes['ncm'] = $ncm;
	}

	public function getBemAttribute()
	{
		return $this->attributes['bem'];
	}

	public function setBemAttribute($bem)
	{
		$this->attributes['bem'] = $bem;
	}

	public function getVidaAttribute()
	{
		return (double)$this->attributes['vida'];
	}

	public function setVidaAttribute($vida)
	{
		$this->attributes['vida'] = $vida;
	}

	public function getTaxaAttribute()
	{
		return (double)$this->attributes['taxa'];
	}

	public function setTaxaAttribute($taxa)
	{
		$this->attributes['taxa'] = $taxa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNcmAttribute($object->ncm);
				$this->setBemAttribute($object->bem);
				$this->setVidaAttribute($object->vida);
				$this->setTaxaAttribute($object->taxa);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ncm' => $this->getNcmAttribute(),
				'bem' => $this->getBemAttribute(),
				'vida' => $this->getVidaAttribute(),
				'taxa' => $this->getTaxaAttribute(),
			];
	}
}