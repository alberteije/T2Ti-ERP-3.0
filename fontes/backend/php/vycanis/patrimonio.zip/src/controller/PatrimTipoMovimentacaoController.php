<?php
class PatrimTipoMovimentacaoController extends ControllerBase
{

		private $patrimTipoMovimentacaoService = null;

		public function __construct()
		{	 
				$this->patrimTipoMovimentacaoService = new PatrimTipoMovimentacaoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->patrimTipoMovimentacaoService->getListFilter($filter);
						} else {
								$resultList = $this->patrimTipoMovimentacaoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList PatrimTipoMovimentacao]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->patrimTipoMovimentacaoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject PatrimTipoMovimentacao]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject PatrimTipoMovimentacao]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert PatrimTipoMovimentacao]', null);
						}

						$objModel = new PatrimTipoMovimentacaoModel();
						$objModel->mapping($objJson);

						$this->patrimTipoMovimentacaoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert PatrimTipoMovimentacao]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->patrimTipoMovimentacaoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update PatrimTipoMovimentacao]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->patrimTipoMovimentacaoService->save($objFromDatabase);
								$objFromDatabase = $this->patrimTipoMovimentacaoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update PatrimTipoMovimentacao]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->patrimTipoMovimentacaoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete PatrimTipoMovimentacao]', null);
						} else {
								$this->patrimTipoMovimentacaoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete PatrimTipoMovimentacao]', $e);
				}
		}
}
