<?php

include 'ControllerBase.php';
include 'LoginController.php';

include 'PatrimBemController.php';
include 'SetorController.php';
include 'CentroResultadoController.php';
include 'PatrimIndiceAtualizacaoController.php';
include 'PatrimTaxaDepreciacaoController.php';
include 'PatrimGrupoBemController.php';
include 'PatrimTipoAquisicaoBemController.php';
include 'PatrimEstadoConservacaoController.php';
include 'SeguradoraController.php';
include 'PatrimTipoMovimentacaoController.php';
include 'ViewControleAcessoController.php';
include 'ViewPessoaUsuarioController.php';
include 'ViewPessoaFornecedorController.php';
include 'ViewPessoaColaboradorController.php';