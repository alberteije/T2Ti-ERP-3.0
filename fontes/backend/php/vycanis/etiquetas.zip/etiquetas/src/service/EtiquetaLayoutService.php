<?php
use Illuminate\Database\Capsule\Manager as DB;
class EtiquetaLayoutService extends ServiceBase
{
	public function getList()
	{
		return EtiquetaLayoutModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return EtiquetaLayoutModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return EtiquetaLayoutModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// etiquetaTemplate
		$etiquetaTemplateModelListJson = $objJson->etiquetaTemplateModelList;
		if ($etiquetaTemplateModelListJson != null) {
			for ($i = 0; $i < count($etiquetaTemplateModelListJson); $i++) {
				$etiquetaTemplate = new EtiquetaTemplateModel();
				$etiquetaTemplate->mapping($etiquetaTemplateModelListJson[$i]);
				$objModel->etiquetaTemplateModelList()->save($etiquetaTemplate);
			}
		}

	}	

	public function deleteChildren($object)
	{
		EtiquetaTemplateModel::where('id_etiqueta_layout', $object->getIdAttribute())->delete();
	}	
 
}