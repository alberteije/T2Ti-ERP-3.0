<?php
declare(strict_types=1);

class EtiquetaTemplateModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'etiqueta_template';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function etiquetaLayoutModel()
	{
		return $this->belongsTo(EtiquetaLayoutModel::class, 'id_etiqueta_layout', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTabelaAttribute()
	{
		return $this->attributes['tabela'];
	}

	public function setTabelaAttribute($tabela)
	{
		$this->attributes['tabela'] = $tabela;
	}

	public function getCampoAttribute()
	{
		return $this->attributes['campo'];
	}

	public function setCampoAttribute($campo)
	{
		$this->attributes['campo'] = $campo;
	}

	public function getFormatoAttribute()
	{
		return $this->attributes['formato'];
	}

	public function setFormatoAttribute($formato)
	{
		$this->attributes['formato'] = $formato;
	}

	public function getQuantidadeRepeticoesAttribute()
	{
		return $this->attributes['quantidade_repeticoes'];
	}

	public function setQuantidadeRepeticoesAttribute($quantidadeRepeticoes)
	{
		$this->attributes['quantidade_repeticoes'] = $quantidadeRepeticoes;
	}

	public function getFiltroAttribute()
	{
		return $this->attributes['filtro'];
	}

	public function setFiltroAttribute($filtro)
	{
		$this->attributes['filtro'] = $filtro;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTabelaAttribute($object->tabela);
				$this->setCampoAttribute($object->campo);
				$this->setFormatoAttribute($object->formato);
				$this->setQuantidadeRepeticoesAttribute($object->quantidadeRepeticoes);
				$this->setFiltroAttribute($object->filtro);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tabela' => $this->getTabelaAttribute(),
				'campo' => $this->getCampoAttribute(),
				'formato' => $this->getFormatoAttribute(),
				'quantidadeRepeticoes' => $this->getQuantidadeRepeticoesAttribute(),
				'filtro' => $this->getFiltroAttribute(),
			];
	}
}