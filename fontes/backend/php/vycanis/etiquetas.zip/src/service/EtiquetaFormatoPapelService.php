<?php
class EtiquetaFormatoPapelService extends ServiceBase
{
  public function getList()
  {
    return EtiquetaFormatoPapelModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EtiquetaFormatoPapelModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EtiquetaFormatoPapelModel::find($id);
  }

}