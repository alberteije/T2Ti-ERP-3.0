<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'EtiquetaTemplateModel.php';
include 'EtiquetaLayoutModel.php';
include 'EtiquetaFormatoPapelModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';