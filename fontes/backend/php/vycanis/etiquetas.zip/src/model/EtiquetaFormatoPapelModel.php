<?php
declare(strict_types=1);

class EtiquetaFormatoPapelModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'etiqueta_formato_papel';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getAlturaAttribute()
	{
		return $this->attributes['altura'];
	}

	public function setAlturaAttribute($altura)
	{
		$this->attributes['altura'] = $altura;
	}

	public function getLarguraAttribute()
	{
		return $this->attributes['largura'];
	}

	public function setLarguraAttribute($largura)
	{
		$this->attributes['largura'] = $largura;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setAlturaAttribute($object->altura);
				$this->setLarguraAttribute($object->largura);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'altura' => $this->getAlturaAttribute(),
				'largura' => $this->getLarguraAttribute(),
			];
	}
}