<?php
declare(strict_types=1);

class EtiquetaLayoutModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'etiqueta_layout';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'etiquetaTemplateModelList',
		'etiquetaFormatoPapelModel',
	];

	/**
		* Relations
		*/
	public function etiquetaTemplateModelList()
{
	return $this->hasMany(EtiquetaTemplateModel::class, 'id_etiqueta_layout', 'id');
}

	public function etiquetaFormatoPapelModel()
	{
		return $this->belongsTo(EtiquetaFormatoPapelModel::class, 'id_formato_papel', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoFabricanteAttribute()
	{
		return $this->attributes['codigo_fabricante'];
	}

	public function setCodigoFabricanteAttribute($codigoFabricante)
	{
		$this->attributes['codigo_fabricante'] = $codigoFabricante;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getQuantidadeHorizontalAttribute()
	{
		return $this->attributes['quantidade_horizontal'];
	}

	public function setQuantidadeHorizontalAttribute($quantidadeHorizontal)
	{
		$this->attributes['quantidade_horizontal'] = $quantidadeHorizontal;
	}

	public function getQuantidadeVerticalAttribute()
	{
		return $this->attributes['quantidade_vertical'];
	}

	public function setQuantidadeVerticalAttribute($quantidadeVertical)
	{
		$this->attributes['quantidade_vertical'] = $quantidadeVertical;
	}

	public function getMargemSuperiorAttribute()
	{
		return $this->attributes['margem_superior'];
	}

	public function setMargemSuperiorAttribute($margemSuperior)
	{
		$this->attributes['margem_superior'] = $margemSuperior;
	}

	public function getMargemInferiorAttribute()
	{
		return $this->attributes['margem_inferior'];
	}

	public function setMargemInferiorAttribute($margemInferior)
	{
		$this->attributes['margem_inferior'] = $margemInferior;
	}

	public function getMargemEsquerdaAttribute()
	{
		return $this->attributes['margem_esquerda'];
	}

	public function setMargemEsquerdaAttribute($margemEsquerda)
	{
		$this->attributes['margem_esquerda'] = $margemEsquerda;
	}

	public function getMargemDireitaAttribute()
	{
		return $this->attributes['margem_direita'];
	}

	public function setMargemDireitaAttribute($margemDireita)
	{
		$this->attributes['margem_direita'] = $margemDireita;
	}

	public function getEspacamentoHorizontalAttribute()
	{
		return $this->attributes['espacamento_horizontal'];
	}

	public function setEspacamentoHorizontalAttribute($espacamentoHorizontal)
	{
		$this->attributes['espacamento_horizontal'] = $espacamentoHorizontal;
	}

	public function getEspacamentoVerticalAttribute()
	{
		return $this->attributes['espacamento_vertical'];
	}

	public function setEspacamentoVerticalAttribute($espacamentoVertical)
	{
		$this->attributes['espacamento_vertical'] = $espacamentoVertical;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoFabricanteAttribute($object->codigoFabricante);
				$this->setQuantidadeAttribute($object->quantidade);
				$this->setQuantidadeHorizontalAttribute($object->quantidadeHorizontal);
				$this->setQuantidadeVerticalAttribute($object->quantidadeVertical);
				$this->setMargemSuperiorAttribute($object->margemSuperior);
				$this->setMargemInferiorAttribute($object->margemInferior);
				$this->setMargemEsquerdaAttribute($object->margemEsquerda);
				$this->setMargemDireitaAttribute($object->margemDireita);
				$this->setEspacamentoHorizontalAttribute($object->espacamentoHorizontal);
				$this->setEspacamentoVerticalAttribute($object->espacamentoVertical);

				// link objects - lookups
				$etiquetaFormatoPapelModel = new EtiquetaFormatoPapelModel();
				$etiquetaFormatoPapelModel->mapping($object->etiquetaFormatoPapelModel);
				$this->etiquetaFormatoPapelModel()->associate($etiquetaFormatoPapelModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoFabricante' => $this->getCodigoFabricanteAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'quantidadeHorizontal' => $this->getQuantidadeHorizontalAttribute(),
				'quantidadeVertical' => $this->getQuantidadeVerticalAttribute(),
				'margemSuperior' => $this->getMargemSuperiorAttribute(),
				'margemInferior' => $this->getMargemInferiorAttribute(),
				'margemEsquerda' => $this->getMargemEsquerdaAttribute(),
				'margemDireita' => $this->getMargemDireitaAttribute(),
				'espacamentoHorizontal' => $this->getEspacamentoHorizontalAttribute(),
				'espacamentoVertical' => $this->getEspacamentoVerticalAttribute(),
				'etiquetaTemplateModelList' => $this->etiquetaTemplateModelList,
				'etiquetaFormatoPapelModel' => $this->etiquetaFormatoPapelModel,
			];
	}
}