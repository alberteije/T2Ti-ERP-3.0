<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// etiqueta-layout
$app->get('/etiqueta-layout[/]', \EtiquetaLayoutController::class . RESULT_LIST);
$app->get('/etiqueta-layout/{id}', \EtiquetaLayoutController::class . RESULT_OBJECT);
$app->post('/etiqueta-layout', \EtiquetaLayoutController::class . INSERT);
$app->put('/etiqueta-layout', \EtiquetaLayoutController::class . UPDATE);
$app->delete('/etiqueta-layout/{id}', \EtiquetaLayoutController::class . DELETE);
$app->options('/etiqueta-layout', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/etiqueta-layout/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/etiqueta-layout/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// etiqueta-formato-papel
$app->get('/etiqueta-formato-papel[/]', \EtiquetaFormatoPapelController::class . RESULT_LIST);
$app->get('/etiqueta-formato-papel/{id}', \EtiquetaFormatoPapelController::class . RESULT_OBJECT);
$app->post('/etiqueta-formato-papel', \EtiquetaFormatoPapelController::class . INSERT);
$app->put('/etiqueta-formato-papel', \EtiquetaFormatoPapelController::class . UPDATE);
$app->delete('/etiqueta-formato-papel/{id}', \EtiquetaFormatoPapelController::class . DELETE);
$app->options('/etiqueta-formato-papel', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/etiqueta-formato-papel/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/etiqueta-formato-papel/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

