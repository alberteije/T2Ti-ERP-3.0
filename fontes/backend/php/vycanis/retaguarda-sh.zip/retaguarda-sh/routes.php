<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// empresa
$app->get('/empresa[/]', \EmpresaController::class . RESULT_LIST);
$app->get('/empresa/{id}', \EmpresaController::class . RESULT_OBJECT);
$app->get('/empresa/cnpj/{cnpj}', \EmpresaController::class . ':getEmpresaPorCnpj');
$app->post('/empresa', \EmpresaController::class . INSERT);
$app->post('/empresa/registra-empresa-erp', \EmpresaController::class . ':registrarEmpresaErp');
$app->put('/empresa', \EmpresaController::class . UPDATE);
$app->delete('/empresa/{id}', \EmpresaController::class . DELETE);
$app->options('/empresa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/empresa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/empresa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// pdv-tipo-plano
$app->get('/pdv-tipo-plano[/]', \PdvTipoPlanoController::class . RESULT_LIST);
$app->get('/pdv-tipo-plano/{id}', \PdvTipoPlanoController::class . RESULT_OBJECT);
$app->post('/pdv-tipo-plano', \PdvTipoPlanoController::class . INSERT);
$app->put('/pdv-tipo-plano', \PdvTipoPlanoController::class . UPDATE);
$app->delete('/pdv-tipo-plano/{id}', \PdvTipoPlanoController::class . DELETE);
$app->options('/pdv-tipo-plano', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pdv-tipo-plano/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pdv-tipo-plano/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// erp-tipo-plano
$app->get('/erp-tipo-plano[/]', \ErpTipoPlanoController::class . RESULT_LIST);
$app->get('/erp-tipo-plano/{id}', \ErpTipoPlanoController::class . RESULT_OBJECT);
$app->post('/erp-tipo-plano', \ErpTipoPlanoController::class . INSERT);
$app->put('/erp-tipo-plano', \ErpTipoPlanoController::class . UPDATE);
$app->delete('/erp-tipo-plano/{id}', \ErpTipoPlanoController::class . DELETE);
$app->options('/erp-tipo-plano', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/erp-tipo-plano/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/erp-tipo-plano/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);