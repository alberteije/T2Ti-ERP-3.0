<?php
declare(strict_types=1);

class PdvPlanoPagamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pdv_plano_pagamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function pdvTipoPlanoModel()
	{
		return $this->belongsTo(PdvTipoPlanoModel::class, 'id_pdv_tipo_plano', 'id');
	}

	public function empresaModel()
	{
		return $this->belongsTo(EmpresaModel::class, 'id_empresa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataSolicitacaoAttribute()
	{
		return $this->attributes['data_solicitacao'];
	}

	public function setDataSolicitacaoAttribute($dataSolicitacao)
	{
		$this->attributes['data_solicitacao'] = $dataSolicitacao;
	}

	public function getDataPagamentoAttribute()
	{
		return $this->attributes['data_pagamento'];
	}

	public function setDataPagamentoAttribute($dataPagamento)
	{
		$this->attributes['data_pagamento'] = $dataPagamento;
	}

	public function getPlanoAttribute()
	{
		return $this->attributes['plano'];
	}

	public function setPlanoAttribute($plano)
	{
		$this->attributes['plano'] = $plano;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getStatusPagamentoAttribute()
	{
		return $this->attributes['status_pagamento'];
	}

	public function setStatusPagamentoAttribute($statusPagamento)
	{
		$this->attributes['status_pagamento'] = $statusPagamento;
	}

	public function getCodigoTransacaoAttribute()
	{
		return $this->attributes['codigo_transacao'];
	}

	public function setCodigoTransacaoAttribute($codigoTransacao)
	{
		$this->attributes['codigo_transacao'] = $codigoTransacao;
	}

	public function getMetodoPagamentoAttribute()
	{
		return $this->attributes['metodo_pagamento'];
	}

	public function setMetodoPagamentoAttribute($metodoPagamento)
	{
		$this->attributes['metodo_pagamento'] = $metodoPagamento;
	}

	public function getCodigoTipoPagamentoAttribute()
	{
		return $this->attributes['codigo_tipo_pagamento'];
	}

	public function setCodigoTipoPagamentoAttribute($codigoTipoPagamento)
	{
		$this->attributes['codigo_tipo_pagamento'] = $codigoTipoPagamento;
	}

	public function getDataPlanoExpiraAttribute()
	{
		return $this->attributes['data_plano_expira'];
	}

	public function setDataPlanoExpiraAttribute($dataPlanoExpira)
	{
		$this->attributes['data_plano_expira'] = $dataPlanoExpira;
	}

	public function getEmailPagamentoAttribute()
	{
		return $this->attributes['email_pagamento'];
	}

	public function setEmailPagamentoAttribute($emailPagamento)
	{
		$this->attributes['email_pagamento'] = $emailPagamento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataSolicitacaoAttribute($object->dataSolicitacao);
				$this->setDataPagamentoAttribute($object->dataPagamento);
				$this->setPlanoAttribute($object->plano);
				$this->setValorAttribute($object->valor);
				$this->setStatusPagamentoAttribute($object->statusPagamento);
				$this->setCodigoTransacaoAttribute($object->codigoTransacao);
				$this->setMetodoPagamentoAttribute($object->metodoPagamento);
				$this->setCodigoTipoPagamentoAttribute($object->codigoTipoPagamento);
				$this->setDataPlanoExpiraAttribute($object->dataPlanoExpira);
				$this->setEmailPagamentoAttribute($object->emailPagamento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataSolicitacao' => $this->getDataSolicitacaoAttribute(),
				'dataPagamento' => $this->getDataPagamentoAttribute(),
				'plano' => $this->getPlanoAttribute(),
				'valor' => $this->getValorAttribute(),
				'statusPagamento' => $this->getStatusPagamentoAttribute(),
				'codigoTransacao' => $this->getCodigoTransacaoAttribute(),
				'metodoPagamento' => $this->getMetodoPagamentoAttribute(),
				'codigoTipoPagamento' => $this->getCodigoTipoPagamentoAttribute(),
				'dataPlanoExpira' => $this->getDataPlanoExpiraAttribute(),
				'emailPagamento' => $this->getEmailPagamentoAttribute(),
			];
	}
}