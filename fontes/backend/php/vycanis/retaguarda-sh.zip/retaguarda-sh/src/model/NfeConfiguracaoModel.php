<?php
declare(strict_types=1);

class NfeConfiguracaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_configuracao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function empresaModel()
	{
		return $this->belongsTo(EmpresaModel::class, 'id_empresa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCertificadoDigitalSerieAttribute()
	{
		return $this->attributes['certificado_digital_serie'];
	}

	public function setCertificadoDigitalSerieAttribute($certificadoDigitalSerie)
	{
		$this->attributes['certificado_digital_serie'] = $certificadoDigitalSerie;
	}

	public function getCertificadoDigitalCaminhoAttribute()
	{
		return $this->attributes['certificado_digital_caminho'];
	}

	public function setCertificadoDigitalCaminhoAttribute($certificadoDigitalCaminho)
	{
		$this->attributes['certificado_digital_caminho'] = $certificadoDigitalCaminho;
	}

	public function getCertificadoDigitalSenhaAttribute()
	{
		return $this->attributes['certificado_digital_senha'];
	}

	public function setCertificadoDigitalSenhaAttribute($certificadoDigitalSenha)
	{
		$this->attributes['certificado_digital_senha'] = $certificadoDigitalSenha;
	}

	public function getTipoEmissaoAttribute()
	{
		return $this->attributes['tipo_emissao'];
	}

	public function setTipoEmissaoAttribute($tipoEmissao)
	{
		$this->attributes['tipo_emissao'] = $tipoEmissao;
	}

	public function getFormatoImpressaoDanfeAttribute()
	{
		return $this->attributes['formato_impressao_danfe'];
	}

	public function setFormatoImpressaoDanfeAttribute($formatoImpressaoDanfe)
	{
		$this->attributes['formato_impressao_danfe'] = $formatoImpressaoDanfe;
	}

	public function getProcessoEmissaoAttribute()
	{
		return $this->attributes['processo_emissao'];
	}

	public function setProcessoEmissaoAttribute($processoEmissao)
	{
		$this->attributes['processo_emissao'] = $processoEmissao;
	}

	public function getVersaoProcessoEmissaoAttribute()
	{
		return $this->attributes['versao_processo_emissao'];
	}

	public function setVersaoProcessoEmissaoAttribute($versaoProcessoEmissao)
	{
		$this->attributes['versao_processo_emissao'] = $versaoProcessoEmissao;
	}

	public function getCaminhoLogomarcaAttribute()
	{
		return $this->attributes['caminho_logomarca'];
	}

	public function setCaminhoLogomarcaAttribute($caminhoLogomarca)
	{
		$this->attributes['caminho_logomarca'] = $caminhoLogomarca;
	}

	public function getSalvarXmlAttribute()
	{
		return $this->attributes['salvar_xml'];
	}

	public function setSalvarXmlAttribute($salvarXml)
	{
		$this->attributes['salvar_xml'] = $salvarXml;
	}

	public function getCaminhoSalvarXmlAttribute()
	{
		return $this->attributes['caminho_salvar_xml'];
	}

	public function setCaminhoSalvarXmlAttribute($caminhoSalvarXml)
	{
		$this->attributes['caminho_salvar_xml'] = $caminhoSalvarXml;
	}

	public function getCaminhoSchemasAttribute()
	{
		return $this->attributes['caminho_schemas'];
	}

	public function setCaminhoSchemasAttribute($caminhoSchemas)
	{
		$this->attributes['caminho_schemas'] = $caminhoSchemas;
	}

	public function getCaminhoArquivoDanfeAttribute()
	{
		return $this->attributes['caminho_arquivo_danfe'];
	}

	public function setCaminhoArquivoDanfeAttribute($caminhoArquivoDanfe)
	{
		$this->attributes['caminho_arquivo_danfe'] = $caminhoArquivoDanfe;
	}

	public function getCaminhoSalvarPdfAttribute()
	{
		return $this->attributes['caminho_salvar_pdf'];
	}

	public function setCaminhoSalvarPdfAttribute($caminhoSalvarPdf)
	{
		$this->attributes['caminho_salvar_pdf'] = $caminhoSalvarPdf;
	}

	public function getWebserviceUfAttribute()
	{
		return $this->attributes['webservice_uf'];
	}

	public function setWebserviceUfAttribute($webserviceUf)
	{
		$this->attributes['webservice_uf'] = $webserviceUf;
	}

	public function getWebserviceAmbienteAttribute()
	{
		return $this->attributes['webservice_ambiente'];
	}

	public function setWebserviceAmbienteAttribute($webserviceAmbiente)
	{
		$this->attributes['webservice_ambiente'] = $webserviceAmbiente;
	}

	public function getWebserviceProxyHostAttribute()
	{
		return $this->attributes['webservice_proxy_host'];
	}

	public function setWebserviceProxyHostAttribute($webserviceProxyHost)
	{
		$this->attributes['webservice_proxy_host'] = $webserviceProxyHost;
	}

	public function getWebserviceProxyPortaAttribute()
	{
		return $this->attributes['webservice_proxy_porta'];
	}

	public function setWebserviceProxyPortaAttribute($webserviceProxyPorta)
	{
		$this->attributes['webservice_proxy_porta'] = $webserviceProxyPorta;
	}

	public function getWebserviceProxyUsuarioAttribute()
	{
		return $this->attributes['webservice_proxy_usuario'];
	}

	public function setWebserviceProxyUsuarioAttribute($webserviceProxyUsuario)
	{
		$this->attributes['webservice_proxy_usuario'] = $webserviceProxyUsuario;
	}

	public function getWebserviceProxySenhaAttribute()
	{
		return $this->attributes['webservice_proxy_senha'];
	}

	public function setWebserviceProxySenhaAttribute($webserviceProxySenha)
	{
		$this->attributes['webservice_proxy_senha'] = $webserviceProxySenha;
	}

	public function getWebserviceVisualizarAttribute()
	{
		return $this->attributes['webservice_visualizar'];
	}

	public function setWebserviceVisualizarAttribute($webserviceVisualizar)
	{
		$this->attributes['webservice_visualizar'] = $webserviceVisualizar;
	}

	public function getEmailServidorSmtpAttribute()
	{
		return $this->attributes['email_servidor_smtp'];
	}

	public function setEmailServidorSmtpAttribute($emailServidorSmtp)
	{
		$this->attributes['email_servidor_smtp'] = $emailServidorSmtp;
	}

	public function getEmailPortaAttribute()
	{
		return $this->attributes['email_porta'];
	}

	public function setEmailPortaAttribute($emailPorta)
	{
		$this->attributes['email_porta'] = $emailPorta;
	}

	public function getEmailUsuarioAttribute()
	{
		return $this->attributes['email_usuario'];
	}

	public function setEmailUsuarioAttribute($emailUsuario)
	{
		$this->attributes['email_usuario'] = $emailUsuario;
	}

	public function getEmailSenhaAttribute()
	{
		return $this->attributes['email_senha'];
	}

	public function setEmailSenhaAttribute($emailSenha)
	{
		$this->attributes['email_senha'] = $emailSenha;
	}

	public function getEmailAssuntoAttribute()
	{
		return $this->attributes['email_assunto'];
	}

	public function setEmailAssuntoAttribute($emailAssunto)
	{
		$this->attributes['email_assunto'] = $emailAssunto;
	}

	public function getEmailAutenticaSslAttribute()
	{
		return $this->attributes['email_autentica_ssl'];
	}

	public function setEmailAutenticaSslAttribute($emailAutenticaSsl)
	{
		$this->attributes['email_autentica_ssl'] = $emailAutenticaSsl;
	}

	public function getEmailTextoAttribute()
	{
		return $this->attributes['email_texto'];
	}

	public function setEmailTextoAttribute($emailTexto)
	{
		$this->attributes['email_texto'] = $emailTexto;
	}

	public function getNfceIdCscAttribute()
	{
		return $this->attributes['nfce_id_csc'];
	}

	public function setNfceIdCscAttribute($nfceIdCsc)
	{
		$this->attributes['nfce_id_csc'] = $nfceIdCsc;
	}

	public function getNfceCscAttribute()
	{
		return $this->attributes['nfce_csc'];
	}

	public function setNfceCscAttribute($nfceCsc)
	{
		$this->attributes['nfce_csc'] = $nfceCsc;
	}

	public function getNfceModeloImpressaoAttribute()
	{
		return $this->attributes['nfce_modelo_impressao'];
	}

	public function setNfceModeloImpressaoAttribute($nfceModeloImpressao)
	{
		$this->attributes['nfce_modelo_impressao'] = $nfceModeloImpressao;
	}

	public function getNfceImprimirItensUmaLinhaAttribute()
	{
		return $this->attributes['nfce_imprimir_itens_uma_linha'];
	}

	public function setNfceImprimirItensUmaLinhaAttribute($nfceImprimirItensUmaLinha)
	{
		$this->attributes['nfce_imprimir_itens_uma_linha'] = $nfceImprimirItensUmaLinha;
	}

	public function getNfceImprimirDescontoPorItemAttribute()
	{
		return $this->attributes['nfce_imprimir_desconto_por_item'];
	}

	public function setNfceImprimirDescontoPorItemAttribute($nfceImprimirDescontoPorItem)
	{
		$this->attributes['nfce_imprimir_desconto_por_item'] = $nfceImprimirDescontoPorItem;
	}

	public function getNfceImprimirQrcodeLateralAttribute()
	{
		return $this->attributes['nfce_imprimir_qrcode_lateral'];
	}

	public function setNfceImprimirQrcodeLateralAttribute($nfceImprimirQrcodeLateral)
	{
		$this->attributes['nfce_imprimir_qrcode_lateral'] = $nfceImprimirQrcodeLateral;
	}

	public function getNfceImprimirGtinAttribute()
	{
		return $this->attributes['nfce_imprimir_gtin'];
	}

	public function setNfceImprimirGtinAttribute($nfceImprimirGtin)
	{
		$this->attributes['nfce_imprimir_gtin'] = $nfceImprimirGtin;
	}

	public function getNfceImprimirNomeFantasiaAttribute()
	{
		return $this->attributes['nfce_imprimir_nome_fantasia'];
	}

	public function setNfceImprimirNomeFantasiaAttribute($nfceImprimirNomeFantasia)
	{
		$this->attributes['nfce_imprimir_nome_fantasia'] = $nfceImprimirNomeFantasia;
	}

	public function getNfceImpressaoTributosAttribute()
	{
		return $this->attributes['nfce_impressao_tributos'];
	}

	public function setNfceImpressaoTributosAttribute($nfceImpressaoTributos)
	{
		$this->attributes['nfce_impressao_tributos'] = $nfceImpressaoTributos;
	}

	public function getNfceMargemSuperiorAttribute()
	{
		return (double)$this->attributes['nfce_margem_superior'];
	}

	public function setNfceMargemSuperiorAttribute($nfceMargemSuperior)
	{
		$this->attributes['nfce_margem_superior'] = $nfceMargemSuperior;
	}

	public function getNfceMargemInferiorAttribute()
	{
		return (double)$this->attributes['nfce_margem_inferior'];
	}

	public function setNfceMargemInferiorAttribute($nfceMargemInferior)
	{
		$this->attributes['nfce_margem_inferior'] = $nfceMargemInferior;
	}

	public function getNfceMargemDireitaAttribute()
	{
		return (double)$this->attributes['nfce_margem_direita'];
	}

	public function setNfceMargemDireitaAttribute($nfceMargemDireita)
	{
		$this->attributes['nfce_margem_direita'] = $nfceMargemDireita;
	}

	public function getNfceMargemEsquerdaAttribute()
	{
		return (double)$this->attributes['nfce_margem_esquerda'];
	}

	public function setNfceMargemEsquerdaAttribute($nfceMargemEsquerda)
	{
		$this->attributes['nfce_margem_esquerda'] = $nfceMargemEsquerda;
	}

	public function getNfceResolucaoImpressaoAttribute()
	{
		return $this->attributes['nfce_resolucao_impressao'];
	}

	public function setNfceResolucaoImpressaoAttribute($nfceResolucaoImpressao)
	{
		$this->attributes['nfce_resolucao_impressao'] = $nfceResolucaoImpressao;
	}

	public function getNfceTamanhoFonteItemAttribute()
	{
		return $this->attributes['nfce_tamanho_fonte_item'];
	}

	public function setNfceTamanhoFonteItemAttribute($nfceTamanhoFonteItem)
	{
		$this->attributes['nfce_tamanho_fonte_item'] = $nfceTamanhoFonteItem;
	}

	public function getRespTecCnpjAttribute()
	{
		return $this->attributes['resp_tec_cnpj'];
	}

	public function setRespTecCnpjAttribute($respTecCnpj)
	{
		$this->attributes['resp_tec_cnpj'] = $respTecCnpj;
	}

	public function getRespTecContatoAttribute()
	{
		return $this->attributes['resp_tec_contato'];
	}

	public function setRespTecContatoAttribute($respTecContato)
	{
		$this->attributes['resp_tec_contato'] = $respTecContato;
	}

	public function getRespTecEmailAttribute()
	{
		return $this->attributes['resp_tec_email'];
	}

	public function setRespTecEmailAttribute($respTecEmail)
	{
		$this->attributes['resp_tec_email'] = $respTecEmail;
	}

	public function getRespTecFoneAttribute()
	{
		return $this->attributes['resp_tec_fone'];
	}

	public function setRespTecFoneAttribute($respTecFone)
	{
		$this->attributes['resp_tec_fone'] = $respTecFone;
	}

	public function getRespTecIdCsrtAttribute()
	{
		return $this->attributes['resp_tec_id_csrt'];
	}

	public function setRespTecIdCsrtAttribute($respTecIdCsrt)
	{
		$this->attributes['resp_tec_id_csrt'] = $respTecIdCsrt;
	}

	public function getRespTecHashCsrtAttribute()
	{
		return $this->attributes['resp_tec_hash_csrt'];
	}

	public function setRespTecHashCsrtAttribute($respTecHashCsrt)
	{
		$this->attributes['resp_tec_hash_csrt'] = $respTecHashCsrt;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCertificadoDigitalSerieAttribute($object->certificadoDigitalSerie);
				$this->setCertificadoDigitalCaminhoAttribute($object->certificadoDigitalCaminho);
				$this->setCertificadoDigitalSenhaAttribute($object->certificadoDigitalSenha);
				$this->setTipoEmissaoAttribute($object->tipoEmissao);
				$this->setFormatoImpressaoDanfeAttribute($object->formatoImpressaoDanfe);
				$this->setProcessoEmissaoAttribute($object->processoEmissao);
				$this->setVersaoProcessoEmissaoAttribute($object->versaoProcessoEmissao);
				$this->setCaminhoLogomarcaAttribute($object->caminhoLogomarca);
				$this->setSalvarXmlAttribute($object->salvarXml);
				$this->setCaminhoSalvarXmlAttribute($object->caminhoSalvarXml);
				$this->setCaminhoSchemasAttribute($object->caminhoSchemas);
				$this->setCaminhoArquivoDanfeAttribute($object->caminhoArquivoDanfe);
				$this->setCaminhoSalvarPdfAttribute($object->caminhoSalvarPdf);
				$this->setWebserviceUfAttribute($object->webserviceUf);
				$this->setWebserviceAmbienteAttribute($object->webserviceAmbiente);
				$this->setWebserviceProxyHostAttribute($object->webserviceProxyHost);
				$this->setWebserviceProxyPortaAttribute($object->webserviceProxyPorta);
				$this->setWebserviceProxyUsuarioAttribute($object->webserviceProxyUsuario);
				$this->setWebserviceProxySenhaAttribute($object->webserviceProxySenha);
				$this->setWebserviceVisualizarAttribute($object->webserviceVisualizar);
				$this->setEmailServidorSmtpAttribute($object->emailServidorSmtp);
				$this->setEmailPortaAttribute($object->emailPorta);
				$this->setEmailUsuarioAttribute($object->emailUsuario);
				$this->setEmailSenhaAttribute($object->emailSenha);
				$this->setEmailAssuntoAttribute($object->emailAssunto);
				$this->setEmailAutenticaSslAttribute($object->emailAutenticaSsl);
				$this->setEmailTextoAttribute($object->emailTexto);
				$this->setNfceIdCscAttribute($object->nfceIdCsc);
				$this->setNfceCscAttribute($object->nfceCsc);
				$this->setNfceModeloImpressaoAttribute($object->nfceModeloImpressao);
				$this->setNfceImprimirItensUmaLinhaAttribute($object->nfceImprimirItensUmaLinha);
				$this->setNfceImprimirDescontoPorItemAttribute($object->nfceImprimirDescontoPorItem);
				$this->setNfceImprimirQrcodeLateralAttribute($object->nfceImprimirQrcodeLateral);
				$this->setNfceImprimirGtinAttribute($object->nfceImprimirGtin);
				$this->setNfceImprimirNomeFantasiaAttribute($object->nfceImprimirNomeFantasia);
				$this->setNfceImpressaoTributosAttribute($object->nfceImpressaoTributos);
				$this->setNfceMargemSuperiorAttribute($object->nfceMargemSuperior);
				$this->setNfceMargemInferiorAttribute($object->nfceMargemInferior);
				$this->setNfceMargemDireitaAttribute($object->nfceMargemDireita);
				$this->setNfceMargemEsquerdaAttribute($object->nfceMargemEsquerda);
				$this->setNfceResolucaoImpressaoAttribute($object->nfceResolucaoImpressao);
				$this->setNfceTamanhoFonteItemAttribute($object->nfceTamanhoFonteItem);
				$this->setRespTecCnpjAttribute($object->respTecCnpj);
				$this->setRespTecContatoAttribute($object->respTecContato);
				$this->setRespTecEmailAttribute($object->respTecEmail);
				$this->setRespTecFoneAttribute($object->respTecFone);
				$this->setRespTecIdCsrtAttribute($object->respTecIdCsrt);
				$this->setRespTecHashCsrtAttribute($object->respTecHashCsrt);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'certificadoDigitalSerie' => $this->getCertificadoDigitalSerieAttribute(),
				'certificadoDigitalCaminho' => $this->getCertificadoDigitalCaminhoAttribute(),
				'certificadoDigitalSenha' => $this->getCertificadoDigitalSenhaAttribute(),
				'tipoEmissao' => $this->getTipoEmissaoAttribute(),
				'formatoImpressaoDanfe' => $this->getFormatoImpressaoDanfeAttribute(),
				'processoEmissao' => $this->getProcessoEmissaoAttribute(),
				'versaoProcessoEmissao' => $this->getVersaoProcessoEmissaoAttribute(),
				'caminhoLogomarca' => $this->getCaminhoLogomarcaAttribute(),
				'salvarXml' => $this->getSalvarXmlAttribute(),
				'caminhoSalvarXml' => $this->getCaminhoSalvarXmlAttribute(),
				'caminhoSchemas' => $this->getCaminhoSchemasAttribute(),
				'caminhoArquivoDanfe' => $this->getCaminhoArquivoDanfeAttribute(),
				'caminhoSalvarPdf' => $this->getCaminhoSalvarPdfAttribute(),
				'webserviceUf' => $this->getWebserviceUfAttribute(),
				'webserviceAmbiente' => $this->getWebserviceAmbienteAttribute(),
				'webserviceProxyHost' => $this->getWebserviceProxyHostAttribute(),
				'webserviceProxyPorta' => $this->getWebserviceProxyPortaAttribute(),
				'webserviceProxyUsuario' => $this->getWebserviceProxyUsuarioAttribute(),
				'webserviceProxySenha' => $this->getWebserviceProxySenhaAttribute(),
				'webserviceVisualizar' => $this->getWebserviceVisualizarAttribute(),
				'emailServidorSmtp' => $this->getEmailServidorSmtpAttribute(),
				'emailPorta' => $this->getEmailPortaAttribute(),
				'emailUsuario' => $this->getEmailUsuarioAttribute(),
				'emailSenha' => $this->getEmailSenhaAttribute(),
				'emailAssunto' => $this->getEmailAssuntoAttribute(),
				'emailAutenticaSsl' => $this->getEmailAutenticaSslAttribute(),
				'emailTexto' => $this->getEmailTextoAttribute(),
				'nfceIdCsc' => $this->getNfceIdCscAttribute(),
				'nfceCsc' => $this->getNfceCscAttribute(),
				'nfceModeloImpressao' => $this->getNfceModeloImpressaoAttribute(),
				'nfceImprimirItensUmaLinha' => $this->getNfceImprimirItensUmaLinhaAttribute(),
				'nfceImprimirDescontoPorItem' => $this->getNfceImprimirDescontoPorItemAttribute(),
				'nfceImprimirQrcodeLateral' => $this->getNfceImprimirQrcodeLateralAttribute(),
				'nfceImprimirGtin' => $this->getNfceImprimirGtinAttribute(),
				'nfceImprimirNomeFantasia' => $this->getNfceImprimirNomeFantasiaAttribute(),
				'nfceImpressaoTributos' => $this->getNfceImpressaoTributosAttribute(),
				'nfceMargemSuperior' => $this->getNfceMargemSuperiorAttribute(),
				'nfceMargemInferior' => $this->getNfceMargemInferiorAttribute(),
				'nfceMargemDireita' => $this->getNfceMargemDireitaAttribute(),
				'nfceMargemEsquerda' => $this->getNfceMargemEsquerdaAttribute(),
				'nfceResolucaoImpressao' => $this->getNfceResolucaoImpressaoAttribute(),
				'nfceTamanhoFonteItem' => $this->getNfceTamanhoFonteItemAttribute(),
				'respTecCnpj' => $this->getRespTecCnpjAttribute(),
				'respTecContato' => $this->getRespTecContatoAttribute(),
				'respTecEmail' => $this->getRespTecEmailAttribute(),
				'respTecFone' => $this->getRespTecFoneAttribute(),
				'respTecIdCsrt' => $this->getRespTecIdCsrtAttribute(),
				'respTecHashCsrt' => $this->getRespTecHashCsrtAttribute(),
			];
	}
}