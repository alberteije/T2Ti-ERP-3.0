<?php
class ErpTipoPlanoService extends ServiceBase
{
  public function getList()
  {
    return ErpTipoPlanoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ErpTipoPlanoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ErpTipoPlanoModel::find($id);
  }

}