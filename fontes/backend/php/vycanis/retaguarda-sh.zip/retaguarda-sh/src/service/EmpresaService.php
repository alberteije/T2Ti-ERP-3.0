<?php
use Illuminate\Database\Capsule\Manager as DB;
class EmpresaService extends ServiceBase
{
	public function getList()
	{
		return EmpresaModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return EmpresaModel::whereRaw($filter->where)->get();
	}

	public function getObjectFilter($filter)
	{
		$retorno = EmpresaModel::whereRaw($filter)->get();
		if ($retorno->count() > 0) {
			return $retorno[0];
		} else {
			return null;
		}		
	}

	public function getObject(int $id)
	{
		return EmpresaModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// nfeConfiguracao
		$nfeConfiguracaoModelListJson = $objJson->nfeConfiguracaoModelList;
		if ($nfeConfiguracaoModelListJson != null) {
			for ($i = 0; $i < count($nfeConfiguracaoModelListJson); $i++) {
				$nfeConfiguracao = new NfeConfiguracaoModel();
				$nfeConfiguracao->mapping($nfeConfiguracaoModelListJson[$i]);
				$objModel->nfeConfiguracaoModelList()->save($nfeConfiguracao);
			}
		}

		// pdvPlanoPagamento
		$pdvPlanoPagamentoModelListJson = $objJson->pdvPlanoPagamentoModelList;
		if ($pdvPlanoPagamentoModelListJson != null) {
			for ($i = 0; $i < count($pdvPlanoPagamentoModelListJson); $i++) {
				$pdvPlanoPagamento = new PdvPlanoPagamentoModel();
				$pdvPlanoPagamento->mapping($pdvPlanoPagamentoModelListJson[$i]);
				$objModel->pdvPlanoPagamentoModelList()->save($pdvPlanoPagamento);
			}
		}

		// acbrMonitorPorta
		$acbrMonitorPortaModelListJson = $objJson->acbrMonitorPortaModelList;
		if ($acbrMonitorPortaModelListJson != null) {
			for ($i = 0; $i < count($acbrMonitorPortaModelListJson); $i++) {
				$acbrMonitorPorta = new AcbrMonitorPortaModel();
				$acbrMonitorPorta->mapping($acbrMonitorPortaModelListJson[$i]);
				$objModel->acbrMonitorPortaModelList()->save($acbrMonitorPorta);
			}
		}

		// empresaPlano
		$empresaPlanoModelListJson = $objJson->empresaPlanoModelList;
		if ($empresaPlanoModelListJson != null) {
			for ($i = 0; $i < count($empresaPlanoModelListJson); $i++) {
				$empresaPlano = new EmpresaPlanoModel();
				$empresaPlano->mapping($empresaPlanoModelListJson[$i]);
				$objModel->empresaPlanoModelList()->save($empresaPlano);
			}
		}

	}	

	public function deleteChildren($object)
	{
		NfeConfiguracaoModel::where('id_empresa', $object->getIdAttribute())->delete();
		PdvPlanoPagamentoModel::where('id_empresa', $object->getIdAttribute())->delete();
		AcbrMonitorPortaModel::where('id_empresa', $object->getIdAttribute())->delete();
		EmpresaPlanoModel::where('id_empresa', $object->getIdAttribute())->delete();
	}	
 
	public function registrarEmpresaErp($objeto)
	{
		$filter = 'CNPJ = "' . $objeto->cnpj . '"';
		$objBanco = $this->getObjectFilter($filter);

		if ($objBanco == null) {
			$objBanco = new EmpresaModel();
			$objBanco->mapping($objeto);
			$objBanco->logotipo = '';
			$objBanco->registrado = 'S';
			// self::enviarEmailConfirmacao($objeto);
			$objBanco->save();
			$result = $this->getObjectFilter($filter);
			$this->gerarBancoDeDados($objeto->cnpj);
			return $result;
		} else {
			return $objBanco; // TODO: verifique o plano de pagamento, da forma que está aqui basta a empresa está cadastrada para ter acesso ao sistema
		}
	}

	public static function gerarBancoDeDados($cnpj)
	{
		try {
			// cria o banco de dados
			DB::statement("CREATE DATABASE /*!32312 IF NOT EXISTS*/`" . $cnpj . "` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;");
			DB::statement("USE `" . $cnpj . "`;");

			// Ler o conteúdo do arquivo de script SQL
			$script = file_get_contents('dump-t2ti-erp3.sql');

			// Executar cada consulta SQL do script
			foreach (explode(';', $script) as $query) {
				if (!empty(trim($query))) {
					DB::statement($query);
				}
			}
		} catch (Exception $e) {
			echo $e;
		}			
	}	


}