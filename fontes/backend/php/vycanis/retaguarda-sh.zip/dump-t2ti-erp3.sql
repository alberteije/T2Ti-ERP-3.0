create table if not exists pessoa (
  id int not null auto_increment,
  nome varchar(150) null,
  tipo char(1) null,
  site varchar(250) null,
  email varchar(250) null,
  eh_cliente char(1) null,
  eh_fornecedor char(1) null,
  eh_transportadora char(1) null,
  eh_colaborador char(1) null,
  eh_contador char(1) null,
  primary key (id))
engine = innodb;
create table if not exists nivel_formacao (
  id int not null auto_increment,
  nome varchar(100) null,
  descricao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists estado_civil (
  id int not null auto_increment,
  nome varchar(50) null,
  descricao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists pessoa_fisica (
  id int not null auto_increment,
  id_pessoa int not null,
  id_nivel_formacao int not null,
  id_estado_civil int not null,
  cpf varchar(11) null,
  rg varchar(20) null,
  orgao_rg varchar(20) null,
  data_emissao_rg date null,
  data_nascimento date null,
  sexo char(1) null,
  raca char(1) null,
  nacionalidade varchar(100) null,
  naturalidade varchar(100) null,
  nome_pai varchar(200) null,
  nome_mae varchar(200) null,
  primary key (id),
  index fk_pessoa_fisica_pessoa1_idx (id_pessoa asc),
  index fk_pessoa_fisica_nivel_formacao1_idx (id_nivel_formacao asc),
  index fk_pessoa_fisica_estado_civil1_idx (id_estado_civil asc),
  constraint fk_pessoa_fisica_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action,
  constraint fk_pessoa_fisica_nivel_formacao1
    foreign key (id_nivel_formacao)
    references nivel_formacao (id)
    on delete no action
    on update no action,
  constraint fk_pessoa_fisica_estado_civil1
    foreign key (id_estado_civil)
    references estado_civil (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists pessoa_juridica (
  id int not null auto_increment,
  id_pessoa int not null,
  cnpj varchar(14) null,
  nome_fantasia varchar(100) null,
  inscricao_estadual varchar(45) null,
  inscricao_municipal varchar(45) null,
  data_constituicao date null,
  tipo_regime char(1) null,
  crt char(1) null,
  primary key (id),
  index fk_pessoa_juridica_pessoa1_idx (id_pessoa asc),
  constraint fk_pessoa_juridica_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists tabela_preco (
  id int unsigned not null auto_increment,
  nome varchar(100) null,
  principal char(1) null,
  coeficiente decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists cliente (
  id int not null auto_increment,
  id_pessoa int not null,
  id_tabela_preco int unsigned null,
  desde date null,
  data_cadastro date null,
  taxa_desconto decimal(18,6) null,
  limite_credito decimal(18,6) null,
  observacao varchar(250) null,
  primary key (id),
  index fk_cliente_pessoa_idx (id_pessoa asc),
  index fk_cliente_tabela_preco1_idx (id_tabela_preco asc),
  constraint fk_cliente_pessoa
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action,
  constraint fk_cliente_tabela_preco1
    foreign key (id_tabela_preco)
    references tabela_preco (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists fornecedor (
  id int not null auto_increment,
  id_pessoa int not null,
  desde date null,
  data_cadastro date null,
  observacao varchar(250) null,
  primary key (id),
  index fk_fornecedor_pessoa1_idx (id_pessoa asc),
  constraint fk_fornecedor_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists transportadora (
  id int not null auto_increment,
  id_pessoa int not null,
  data_cadastro date null,
  observacao varchar(250) null,
  primary key (id),
  index fk_transportadora_pessoa1_idx (id_pessoa asc),
  constraint fk_transportadora_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists contador (
  id int not null auto_increment,
  id_pessoa int not null,
  crc_inscricao varchar(15) null,
  crc_uf char(2) null,
  primary key (id),
  index fk_contador_pessoa1_idx (id_pessoa asc),
  constraint fk_contador_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists cargo (
  id int not null auto_increment,
  nome varchar(100) null,
  descricao varchar(250) null,
  salario decimal(18,6) null,
  cbo_1994 varchar(10) null,
  cbo_2002 varchar(10) null,
  primary key (id))
engine = innodb;
create table if not exists setor (
  id int not null auto_increment,
  nome varchar(100) null,
  descricao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists colaborador_situacao (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists tipo_admissao (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists colaborador_tipo (
  id int(11) unsigned not null auto_increment,
  nome varchar(20) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists sindicato (
  id int(11) unsigned not null auto_increment,
  nome varchar(100) null,
  codigo_banco int(11) unsigned null,
  codigo_agencia int(11) unsigned null,
  conta_banco varchar(20) null,
  codigo_cedente varchar(30) null,
  logradouro varchar(100) null,
  numero varchar(10) null,
  bairro varchar(100) null,
  municipio_ibge int(11) unsigned null,
  uf char(2) null,
  fone1 varchar(14) null,
  fone2 varchar(14) null,
  email varchar(100) null,
  tipo_sindicato char(1) null,
  data_base date null,
  piso_salarial decimal(18,6) null,
  cnpj varchar(14) null,
  classificacao_contabil_conta varchar(30) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists colaborador (
  id int not null auto_increment,
  id_pessoa int not null,
  id_cargo int null,
  id_setor int null,
  id_colaborador_situacao int(11) unsigned null,
  id_tipo_admissao int(11) unsigned null,
  id_colaborador_tipo int(11) unsigned null,
  id_sindicato int(11) unsigned null,
  matricula varchar(10) null,
  data_cadastro date null,
  data_admissao date null,
  data_demissao date null,
  ctps_numero varchar(10) null,
  ctps_serie varchar(10) null,
  ctps_data_expedicao date null,
  ctps_uf char(2) null,
  observacao varchar(250) null,
  primary key (id),
  index fk_colaborador_pessoa1_idx (id_pessoa asc),
  index fk_colaborador_cargo1_idx (id_cargo asc),
  index fk_colaborador_setor1_idx (id_setor asc),
  index fk_colaborador_colaborador_situacao1_idx (id_colaborador_situacao asc),
  index fk_colaborador_tipo_admissao1_idx (id_tipo_admissao asc),
  index fk_colaborador_colaborador_tipo1_idx (id_colaborador_tipo asc),
  index fk_colaborador_sindicato1_idx (id_sindicato asc),
  constraint fk_colaborador_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action,
  constraint fk_colaborador_cargo1
    foreign key (id_cargo)
    references cargo (id)
    on delete no action
    on update no action,
  constraint fk_colaborador_setor1
    foreign key (id_setor)
    references setor (id)
    on delete no action
    on update no action,
  constraint fk_colaborador_colaborador_situacao1
    foreign key (id_colaborador_situacao)
    references colaborador_situacao (id)
    on delete no action
    on update no action,
  constraint fk_colaborador_tipo_admissao1
    foreign key (id_tipo_admissao)
    references tipo_admissao (id)
    on delete no action
    on update no action,
  constraint fk_colaborador_colaborador_tipo1
    foreign key (id_colaborador_tipo)
    references colaborador_tipo (id)
    on delete no action
    on update no action,
  constraint fk_colaborador_sindicato1
    foreign key (id_sindicato)
    references sindicato (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists comissao_perfil (
  id int unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists vendedor (
  id int not null auto_increment,
  id_colaborador int not null,
  id_comissao_perfil int unsigned null,
  comissao decimal(18,6) null,
  meta_venda decimal(18,6) null,
  primary key (id),
  index fk_vendedor_colaborador1_idx (id_colaborador asc),
  index fk_vendedor_comissao_perfil1_idx (id_comissao_perfil asc),
  constraint fk_vendedor_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action,
  constraint fk_vendedor_comissao_perfil1
    foreign key (id_comissao_perfil)
    references comissao_perfil (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists pessoa_endereco (
  id int not null auto_increment,
  id_pessoa int not null,
  logradouro varchar(100) null,
  numero varchar(10) null,
  bairro varchar(100) null,
  municipio_ibge int null,
  uf char(2) null,
  cep varchar(8) null,
  cidade varchar(100) null,
  complemento varchar(100) null,
  principal char(1) null,
  entrega char(1) null,
  cobranca char(1) null,
  correspondencia char(1) null,
  primary key (id),
  index fk_pessoa_endereco_pessoa1_idx (id_pessoa asc),
  constraint fk_pessoa_endereco_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists pessoa_contato (
  id int not null auto_increment,
  id_pessoa int not null,
  nome varchar(150) null,
  email varchar(250) null,
  observacao varchar(250) null,
  primary key (id),
  index fk_pessoa_contato_pessoa1_idx (id_pessoa asc),
  constraint fk_pessoa_contato_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists pessoa_telefone (
  id int not null auto_increment,
  id_pessoa int not null,
  tipo char(1) null,
  numero varchar(15) null,
  primary key (id),
  index fk_pessoa_telefone_pessoa1_idx (id_pessoa asc),
  constraint fk_pessoa_telefone_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists papel (
  id int not null auto_increment,
  nome varchar(100) null,
  descricao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists usuario (
  id int not null auto_increment,
  id_colaborador int not null,
  id_papel int not null,
  login varchar(50) null,
  senha varchar(50) null,
  administrador char(1) null,
  data_cadastro date null,
  primary key (id),
  index fk_usuario_colaborador1_idx (id_colaborador asc),
  index fk_usuario_papel1_idx (id_papel asc),
  constraint fk_usuario_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action,
  constraint fk_usuario_papel1
    foreign key (id_papel)
    references papel (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists funcao (
  id int not null auto_increment,
  nome varchar(100) null,
  descricao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists papel_funcao (
  id int not null auto_increment,
  id_papel int not null,
  id_funcao int not null,
  habilitado char(1) null,
  pode_inserir char(1) null,
  pode_alterar char(1) null,
  pode_excluir char(1) null,
  primary key (id),
  index fk_papel_funcao_papel1_idx (id_papel asc),
  index fk_papel_funcao_funcao1_idx (id_funcao asc),
  constraint fk_papel_funcao_papel1
    foreign key (id_papel)
    references papel (id)
    on delete no action
    on update no action,
  constraint fk_papel_funcao_funcao1
    foreign key (id_funcao)
    references funcao (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists empresa (
  id int not null auto_increment,
  razao_social varchar(150) null,
  nome_fantasia varchar(150) null,
  cnpj varchar(14) null,
  inscricao_estadual varchar(45) null,
  inscricao_municipal varchar(45) null,
  tipo_regime char(1) null,
  crt char(1) null,
  email varchar(250) null,
  site varchar(250) null,
  contato varchar(100) null,
  data_constituicao date null,
  tipo char(1) null,
  inscricao_junta_comercial varchar(30) null,
  data_insc_junta_comercial date null,
  codigo_ibge_cidade int null default null,
  codigo_ibge_uf int null default null,
  cei varchar(12) null default null,
  codigo_cnae_principal varchar(7) null default null,
  imagem_logotipo text null,
  primary key (id))
engine = innodb;
create table if not exists produto_grupo (
  id int not null auto_increment,
  nome varchar(100) null,
  descricao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists produto_subgrupo (
  id int not null auto_increment,
  id_produto_grupo int not null,
  nome varchar(100) null,
  descricao varchar(250) null,
  primary key (id),
  index fk_produto_subgrupo_produto_grupo1_idx (id_produto_grupo asc),
  constraint fk_produto_subgrupo_produto_grupo1
    foreign key (id_produto_grupo)
    references produto_grupo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists produto_marca (
  id int not null auto_increment,
  nome varchar(100) null,
  descricao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists produto_unidade (
  id int not null auto_increment,
  sigla varchar(10) null,
  descricao varchar(250) null,
  pode_fracionar char(1) null,
  primary key (id))
engine = innodb;
create table if not exists tribut_icms_custom_cab (
  id int unsigned not null auto_increment,
  descricao varchar(100) null,
  origem_mercadoria char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists tribut_grupo_tributario (
  id int not null auto_increment,
  descricao varchar(100) null,
  origem_mercadoria char(1) null,
  observacao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists produto (
  id int not null auto_increment,
  id_produto_subgrupo int not null,
  id_produto_marca int not null,
  id_produto_unidade int not null,
  id_tribut_icms_custom_cab int unsigned null,
  id_tribut_grupo_tributario int null,
  nome varchar(100) null,
  descricao varchar(250) null,
  gtin varchar(14) null,
  codigo_interno varchar(50) null,
  valor_compra decimal(18,6) null,
  valor_venda decimal(18,6) null,
  codigo_ncm varchar(8) null,
  estoque_minimo decimal(18,6) null,
  estoque_maximo decimal(18,6) null,
  quantidade_estoque decimal(18,6) null,
  data_cadastro date null,
  primary key (id),
  index fk_produto_produto_subgrupo1_idx (id_produto_subgrupo asc),
  index fk_produto_produto_marca1_idx (id_produto_marca asc),
  index fk_produto_produto_unidade1_idx (id_produto_unidade asc),
  index fk_produto_tribut_icms_custom_cab1_idx (id_tribut_icms_custom_cab asc),
  index fk_produto_tribut_grupo_tributario1_idx (id_tribut_grupo_tributario asc),
  constraint fk_produto_produto_subgrupo1
    foreign key (id_produto_subgrupo)
    references produto_subgrupo (id)
    on delete no action
    on update no action,
  constraint fk_produto_produto_marca1
    foreign key (id_produto_marca)
    references produto_marca (id)
    on delete no action
    on update no action,
  constraint fk_produto_produto_unidade1
    foreign key (id_produto_unidade)
    references produto_unidade (id)
    on delete no action
    on update no action,
  constraint fk_produto_tribut_icms_custom_cab1
    foreign key (id_tribut_icms_custom_cab)
    references tribut_icms_custom_cab (id)
    on delete no action
    on update no action,
  constraint fk_produto_tribut_grupo_tributario1
    foreign key (id_tribut_grupo_tributario)
    references tribut_grupo_tributario (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists banco (
  id int not null auto_increment,
  codigo varchar(10) null,
  nome varchar(100) null,
  url varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists banco_agencia (
  id int not null auto_increment,
  id_banco int not null,
  numero varchar(20) null,
  digito char(1) null,
  nome varchar(100) null,
  telefone varchar(15) null,
  contato varchar(100) null,
  observacao varchar(250) null,
  gerente varchar(100) null,
  primary key (id),
  index fk_banco_agencia_banco1_idx (id_banco asc),
  constraint fk_banco_agencia_banco1
    foreign key (id_banco)
    references banco (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists banco_conta_caixa (
  id int not null auto_increment,
  id_banco_agencia int null,
  numero varchar(20) null,
  digito char(1) null,
  nome varchar(100) null,
  tipo char(1) null,
  descricao varchar(250) null,
  primary key (id),
  index fk_banco_conta_caixa_banco_agencia1_idx (id_banco_agencia asc),
  constraint fk_banco_conta_caixa_banco_agencia1
    foreign key (id_banco_agencia)
    references banco_agencia (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists cep (
  id int not null auto_increment,
  numero varchar(8) null,
  logradouro varchar(100) null,
  complemento varchar(100) null,
  bairro varchar(100) null,
  municipio varchar(100) null,
  uf char(2) null,
  codigo_ibge_municipio int null,
  primary key (id))
engine = innodb;
create table if not exists uf (
  id int not null auto_increment,
  sigla char(2) null,
  nome varchar(100) null,
  codigo_ibge int null,
  primary key (id))
engine = innodb;
create table if not exists municipio (
  id int not null auto_increment,
  id_uf int not null,
  nome varchar(100) null,
  codigo_ibge int null,
  codigo_receita_federal int null,
  codigo_estadual int null,
  primary key (id),
  index fk_municipio_uf1_idx (id_uf asc),
  constraint fk_municipio_uf1
    foreign key (id_uf)
    references uf (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists ncm (
  id int not null auto_increment,
  codigo varchar(8) null,
  descricao varchar(1000) null,
  observacao varchar(1000) null,
  primary key (id))
engine = innodb;
create table if not exists cfop (
  id int not null auto_increment,
  codigo int null,
  descricao varchar(1000) null,
  aplicacao varchar(1000) null,
  primary key (id))
engine = innodb;
create table if not exists cst_icms (
  id int not null auto_increment,
  codigo char(2) null,
  descricao varchar(250) null,
  observacao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists cst_ipi (
  id int not null auto_increment,
  codigo char(2) null,
  descricao varchar(250) null,
  observacao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists cst_cofins (
  id int not null auto_increment,
  codigo char(2) null,
  descricao varchar(250) null,
  observacao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists cst_pis (
  id int not null auto_increment,
  codigo char(2) null,
  descricao varchar(250) null,
  observacao varchar(250) null,
  primary key (id))
engine = innodb;
create table if not exists csosn (
  id int not null auto_increment,
  codigo char(3) null,
  descricao varchar(250) null,
  observacao varchar(1000) null,
  primary key (id))
engine = innodb;
create table if not exists empresa_endereco (
  id int not null auto_increment,
  id_empresa int not null,
  logradouro varchar(100) null,
  numero varchar(10) null,
  bairro varchar(100) null,
  cidade varchar(100) null,
  uf char(2) null,
  cep varchar(8) null,
  municipio_ibge int null,
  complemento varchar(100) null,
  principal char(1) null,
  entrega char(1) null,
  cobranca char(1) null,
  correspondencia char(1) null,
  primary key (id),
  index fk_empresa_endereco_empresa1_idx (id_empresa asc),
  constraint fk_empresa_endereco_empresa1
    foreign key (id_empresa)
    references empresa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists empresa_contato (
  id int not null auto_increment,
  id_empresa int not null,
  nome varchar(150) null,
  email varchar(250) null,
  observacao varchar(250) null,
  primary key (id),
  index fk_empresa_contato_empresa1_idx (id_empresa asc),
  constraint fk_empresa_contato_empresa1
    foreign key (id_empresa)
    references empresa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists empresa_telefone (
  id int not null auto_increment,
  id_empresa int not null,
  tipo char(1) null,
  numero varchar(15) null,
  primary key (id),
  index fk_empresa_telefone_empresa1_idx (id_empresa asc),
  constraint fk_empresa_telefone_empresa1
    foreign key (id_empresa)
    references empresa (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists cnae (
  id int not null auto_increment,
  codigo varchar(7) null,
  denominacao varchar(1000) null,
  primary key (id))
engine = innodb;
create table if not exists talonario_cheque (
  id int unsigned not null auto_increment,
  id_banco_conta_caixa int not null,
  talao varchar(10) null,
  numero int unsigned null,
  status_talao char(1) null,
  primary key (id),
  index fk_talonario_cheque_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_talonario_cheque_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists cheque (
  id int unsigned not null auto_increment,
  id_talonario_cheque int unsigned not null,
  numero int unsigned null,
  status_cheque char(1) null,
  data_status date null,
  primary key (id),
  index fk_talonario_cheque (id_talonario_cheque asc),
  constraint fk_cheque_talonario_cheque1
    foreign key (id_talonario_cheque)
    references talonario_cheque (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_fechamento_caixa_banco (
  id int unsigned not null auto_increment,
  id_banco_conta_caixa int not null,
  data_fechamento date null,
  mes_ano varchar(7) null,
  mes char(2) null,
  ano char(4) null,
  saldo_anterior decimal(18,6) null,
  recebimentos decimal(18,6) null,
  pagamentos decimal(18,6) null,
  saldo_conta decimal(18,6) null,
  cheque_nao_compensado decimal(18,6) null,
  saldo_disponivel decimal(18,6) null,
  primary key (id),
  index fk_fin_fechamento_caixa_banco_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_fin_fechamento_caixa_banco_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_extrato_conta_banco (
  id int unsigned not null auto_increment,
  id_banco_conta_caixa int not null,
  mes_ano varchar(7) null,
  mes char(2) null,
  ano char(4) null,
  data_movimento date null,
  data_balancete date null,
  historico varchar(250) null,
  documento varchar(50) null,
  valor decimal(18,6) null,
  conciliado char(1) null,
  observacao text null,
  primary key (id),
  index fk_fin_extrato_conta_banco_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_fin_extrato_conta_banco_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_documento_origem (
  id int unsigned not null auto_increment,
  codigo char(3) null,
  sigla char(10) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fin_natureza_financeira (
  id int unsigned not null auto_increment,
  codigo char(4) null,
  descricao varchar(100) null,
  tipo char(1) null,
  aplicacao varchar(250) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fin_lancamento_pagar (
  id int unsigned not null auto_increment,
  id_fin_documento_origem int unsigned not null,
  id_fin_natureza_financeira int unsigned not null,
  id_fornecedor int not null,
  id_banco_conta_caixa int not null,
  quantidade_parcela int unsigned null,
  valor_a_pagar decimal(18,6) null,
  data_lancamento date null,
  numero_documento varchar(50) null,
  imagem_documento text null,
  primeiro_vencimento date null,
  intervalo_entre_parcelas int unsigned null,
  dia_fixo char(2) null,
  primary key (id),
  index fk_doc_orig_lcto_pagar (id_fin_documento_origem asc),
  index fk_fin_lancamento_pagar_fin_natureza_financeira1_idx (id_fin_natureza_financeira asc),
  index fk_fin_lancamento_pagar_fornecedor1_idx (id_fornecedor asc),
  index fk_fin_lancamento_pagar_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_fin_lancamento_pagar_fin_documento_origem1
    foreign key (id_fin_documento_origem)
    references fin_documento_origem (id)
    on delete no action
    on update no action,
  constraint fk_fin_lancamento_pagar_fin_natureza_financeira1
    foreign key (id_fin_natureza_financeira)
    references fin_natureza_financeira (id)
    on delete no action
    on update no action,
  constraint fk_fin_lancamento_pagar_fornecedor1
    foreign key (id_fornecedor)
    references fornecedor (id)
    on delete no action
    on update no action,
  constraint fk_fin_lancamento_pagar_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_status_parcela (
  id int unsigned not null auto_increment,
  situacao char(2) not null,
  descricao varchar(30) null,
  procedimento text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fin_tipo_pagamento (
  id int unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(30) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fin_cheque_emitido (
  id int unsigned not null auto_increment,
  id_cheque int unsigned not null,
  data_emissao date null,
  bom_para date null,
  data_compensacao date null,
  valor decimal(18,6) null,
  nominal_a varchar(100) null,
  primary key (id),
  index fk_cheque_emitido (id_cheque asc),
  constraint fk_fin_cheque_emitido_cheque1
    foreign key (id_cheque)
    references cheque (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_parcela_pagar (
  id int unsigned not null auto_increment,
  id_fin_lancamento_pagar int unsigned not null,
  id_fin_status_parcela int unsigned not null,
  id_fin_tipo_pagamento int unsigned null,
  id_fin_cheque_emitido int unsigned null,
  numero_parcela int unsigned null,
  data_emissao date null,
  data_vencimento date null,
  data_pagamento date null,
  desconto_ate date null,
  valor decimal(18,6) null,
  taxa_juro decimal(18,6) null,
  taxa_multa decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_juro decimal(18,6) null,
  valor_multa decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_pago decimal(18,6) null,
  historico text null,
  primary key (id),
  index fk_status_parcela_pagar (id_fin_status_parcela asc),
  index fk_lancamento_parcela (id_fin_lancamento_pagar asc),
  index fk_fin_parcela_pagar_fin_tipo_pagamento1_idx (id_fin_tipo_pagamento asc),
  index fk_fin_parcela_pagar_fin_cheque_emitido1_idx (id_fin_cheque_emitido asc),
  constraint fk_fin_parcela_pagar_fin_status_parcela1
    foreign key (id_fin_status_parcela)
    references fin_status_parcela (id)
    on delete no action
    on update no action,
  constraint fk_fin_parcela_pagar_fin_lancamento_pagar1
    foreign key (id_fin_lancamento_pagar)
    references fin_lancamento_pagar (id)
    on delete no action
    on update no action,
  constraint fk_fin_parcela_pagar_fin_tipo_pagamento1
    foreign key (id_fin_tipo_pagamento)
    references fin_tipo_pagamento (id)
    on delete no action
    on update no action,
  constraint fk_fin_parcela_pagar_fin_cheque_emitido1
    foreign key (id_fin_cheque_emitido)
    references fin_cheque_emitido (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_tipo_recebimento (
  id int unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(100) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fin_lancamento_receber (
  id int unsigned not null auto_increment,
  id_fin_documento_origem int unsigned not null,
  id_fin_natureza_financeira int unsigned not null,
  id_cliente int not null,
  id_banco_conta_caixa int not null,
  quantidade_parcela int unsigned null,
  valor_a_receber decimal(18,6) null,
  data_lancamento date null,
  numero_documento varchar(50) null,
  primeiro_vencimento date null,
  taxa_comissao decimal(18,6) null,
  valor_comissao decimal(18,6) null,
  intervalo_entre_parcelas int null,
  dia_fixo char(2) null,
  primary key (id),
  index fk_doc_ori_lanc_receber (id_fin_documento_origem asc),
  index fk_fin_lancamento_receber_fin_natureza_financeira1_idx (id_fin_natureza_financeira asc),
  index fk_fin_lancamento_receber_cliente1_idx (id_cliente asc),
  index fk_fin_lancamento_receber_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_fin_lancamento_receber_in_documento_origem1
    foreign key (id_fin_documento_origem)
    references fin_documento_origem (id)
    on delete no action
    on update no action,
  constraint fk_fin_lancamento_receber_fin_natureza_financeira1
    foreign key (id_fin_natureza_financeira)
    references fin_natureza_financeira (id)
    on delete no action
    on update no action,
  constraint fk_fin_lancamento_receber_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action,
  constraint fk_fin_lancamento_receber_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_cheque_recebido (
  id int unsigned not null auto_increment,
  id_pessoa int null,
  cpf varchar(11) null,
  cnpj varchar(14) null,
  nome varchar(100) null,
  codigo_banco varchar(10) null,
  codigo_agencia varchar(10) null,
  conta varchar(20) null,
  numero int unsigned null,
  data_emissao date null,
  bom_para date null,
  data_compensacao date null,
  valor decimal(18,6) null,
  custodia_data date null,
  custodia_tarifa decimal(18,6) null,
  custodia_comissao decimal(18,6) null,
  desconto_data date null,
  desconto_tarifa decimal(18,6) null,
  desconto_comissao decimal(18,6) null,
  valor_recebido decimal(18,6) null,
  primary key (id),
  index fk_fin_cheque_recebido_pessoa1_idx (id_pessoa asc),
  constraint fk_fin_cheque_recebido_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_parcela_receber (
  id int unsigned not null auto_increment,
  id_fin_lancamento_receber int unsigned not null,
  id_fin_status_parcela int unsigned not null,
  id_fin_tipo_recebimento int unsigned null,
  id_fin_cheque_recebido int unsigned null,
  numero_parcela int unsigned null,
  data_emissao date null,
  data_vencimento date null,
  data_recebimento date null,
  desconto_ate date null,
  valor decimal(18,6) null,
  taxa_juro decimal(18,6) null,
  taxa_multa decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_juro decimal(18,6) null,
  valor_multa decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  emitiu_boleto char(1) null,
  boleto_nosso_numero varchar(50) null,
  valor_recebido decimal(18,6) null,
  historico text null,
  primary key (id),
  index fk_lancamento_parcela_receber (id_fin_lancamento_receber asc),
  index fk_status_parcela_receber (id_fin_status_parcela asc),
  index fk_fin_parcela_receber_fin_tipo_recebimento1_idx (id_fin_tipo_recebimento asc),
  index fk_fin_parcela_receber_fin_cheque_recebido1_idx (id_fin_cheque_recebido asc),
  constraint fk_fin_parcela_receber_fin_lancamento_receber1
    foreign key (id_fin_lancamento_receber)
    references fin_lancamento_receber (id)
    on delete no action
    on update no action,
  constraint fk_fin_parcela_receber_fin_status_parcela1
    foreign key (id_fin_status_parcela)
    references fin_status_parcela (id)
    on delete no action
    on update no action,
  constraint fk_fin_parcela_receber_fin_tipo_recebimento1
    foreign key (id_fin_tipo_recebimento)
    references fin_tipo_recebimento (id)
    on delete no action
    on update no action,
  constraint fk_fin_parcela_receber_fin_cheque_recebido1
    foreign key (id_fin_cheque_recebido)
    references fin_cheque_recebido (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fin_configuracao_boleto (
  id int unsigned not null auto_increment,
  id_banco_conta_caixa int not null,
  instrucao01 varchar(100) null,
  instrucao02 varchar(100) null,
  caminho_arquivo_remessa varchar(250) null,
  caminho_arquivo_retorno varchar(250) null,
  caminho_arquivo_logotipo varchar(250) null,
  caminho_arquivo_pdf varchar(250) null,
  mensagem varchar(250) null,
  local_pagamento varchar(100) null,
  layout_remessa char(3) null,
  aceite char(1) null,
  especie char(1) null,
  carteira char(3) null,
  codigo_convenio varchar(20) null,
  codigo_cedente varchar(20) null,
  taxa_multa decimal(18,6) null,
  taxa_juro decimal(18,6) null,
  dias_protesto int unsigned null,
  nosso_numero_anterior varchar(50) null,
  primary key (id),
  index fk_fin_configuracao_boleto_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_fin_configuracao_boleto_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tribut_operacao_fiscal (
  id int unsigned not null auto_increment,
  descricao varchar(100) null,
  descricao_na_nf varchar(100) null,
  cfop int unsigned null,
  observacao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists tribut_configura_of_gt (
  id int unsigned not null auto_increment,
  id_tribut_grupo_tributario int not null,
  id_tribut_operacao_fiscal int unsigned not null,
  primary key (id),
  index fk_op_fiscal_configura (id_tribut_operacao_fiscal asc),
  index fk_grupo_trib_configura (id_tribut_grupo_tributario asc),
  constraint fk_tribut_configura_of_gt_tribut_operacao_fiscal1
    foreign key (id_tribut_operacao_fiscal)
    references tribut_operacao_fiscal (id)
    on delete no action
    on update no action,
  constraint fk_tribut_configura_of_gt_tribut_grupo_tributario
    foreign key (id_tribut_grupo_tributario)
    references tribut_grupo_tributario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tribut_icms_uf (
  id int unsigned not null auto_increment,
  id_tribut_configura_of_gt int unsigned not null,
  uf_destino char(2) null,
  cfop int unsigned null,
  csosn char(3) null,
  cst char(2) null,
  modalidade_bc char(1) null,
  aliquota decimal(18,6) null,
  valor_pauta decimal(18,6) null,
  valor_preco_maximo decimal(18,6) null,
  mva decimal(18,6) null,
  porcento_bc decimal(18,6) null,
  modalidade_bc_st char(1) null,
  aliquota_interna_st decimal(18,6) null,
  aliquota_interestadual_st decimal(18,6) null,
  porcento_bc_st decimal(18,6) null,
  aliquota_icms_st decimal(18,6) null,
  valor_pauta_st decimal(18,6) null,
  valor_preco_maximo_st decimal(18,6) null,
  primary key (id),
  index fk_config_of_gt_icms (id_tribut_configura_of_gt asc),
  constraint fk_tribut_icms_uf_tribut_configura_of_gt1
    foreign key (id_tribut_configura_of_gt)
    references tribut_configura_of_gt (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tribut_pis (
  id int unsigned not null auto_increment,
  id_tribut_configura_of_gt int unsigned not null,
  cst_pis char(2) null,
  efd_tabela_435 char(2) null,
  modalidade_base_calculo char(1) null,
  porcento_base_calculo decimal(18,6) null,
  aliquota_porcento decimal(18,6) null,
  aliquota_unidade decimal(18,6) null,
  valor_preco_maximo decimal(18,6) null,
  valor_pauta_fiscal decimal(18,6) null,
  primary key (id),
  index fk_config_of_gt_pis (id_tribut_configura_of_gt asc),
  constraint fk_tribut_pis_tribut_configura_of_gt1
    foreign key (id_tribut_configura_of_gt)
    references tribut_configura_of_gt (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tribut_cofins (
  id int unsigned not null auto_increment,
  id_tribut_configura_of_gt int unsigned not null,
  cst_cofins char(2) null,
  efd_tabela_435 char(2) null,
  modalidade_base_calculo char(1) null,
  porcento_base_calculo decimal(18,6) null,
  aliquota_porcento decimal(18,6) null,
  aliquota_unidade decimal(18,6) null,
  valor_preco_maximo decimal(18,6) null,
  valor_pauta_fiscal decimal(18,6) null,
  primary key (id),
  index fk_config_of_gt_cofins (id_tribut_configura_of_gt asc),
  constraint fk_tribut_cofins_tribut_configura_of_gt1
    foreign key (id_tribut_configura_of_gt)
    references tribut_configura_of_gt (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tribut_ipi (
  id int unsigned not null auto_increment,
  id_tribut_configura_of_gt int unsigned not null,
  cst_ipi char(2) null,
  modalidade_base_calculo char(1) null,
  porcento_base_calculo decimal(18,6) null,
  aliquota_porcento decimal(18,6) null,
  aliquota_unidade decimal(18,6) null,
  valor_preco_maximo decimal(18,6) null,
  valor_pauta_fiscal decimal(18,6) null,
  primary key (id),
  index fk_config_of_gt_ipi (id_tribut_configura_of_gt asc),
  constraint fk_tribut_ipi_tribut_configura_of_gt1
    foreign key (id_tribut_configura_of_gt)
    references tribut_configura_of_gt (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tribut_iss (
  id int unsigned not null auto_increment,
  id_tribut_operacao_fiscal int unsigned not null,
  modalidade_base_calculo char(1) null,
  porcento_base_calculo decimal(18,6) null,
  aliquota_porcento decimal(18,6) null,
  aliquota_unidade decimal(18,6) null,
  valor_preco_maximo decimal(18,6) null,
  valor_pauta_fiscal decimal(18,6) null,
  item_lista_servico int unsigned null,
  codigo_tributacao char(1) null,
  primary key (id),
  index fk_tribut_op_fiscal_iss (id_tribut_operacao_fiscal asc),
  constraint fk_tribut_iss_tribut_operacao_fiscal1
    foreign key (id_tribut_operacao_fiscal)
    references tribut_operacao_fiscal (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists compra_tipo_requisicao (
  id int unsigned not null auto_increment,
  codigo char(2) null,
  nome varchar(30) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists compra_requisicao (
  id int unsigned not null auto_increment,
  id_compra_tipo_requisicao int unsigned not null,
  id_colaborador int not null,
  descricao varchar(100) null,
  data_requisicao date null,
  observacao text null,
  primary key (id),
  index fk_tipo_req_compra (id_compra_tipo_requisicao asc),
  index fk_compra_requisicao_colaborador1_idx (id_colaborador asc),
  constraint fk_compra_requisicao_compra_tipo_requisicao1
    foreign key (id_compra_tipo_requisicao)
    references compra_tipo_requisicao (id)
    on delete no action
    on update no action,
  constraint fk_compra_requisicao_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists compra_requisicao_detalhe (
  id int unsigned not null auto_increment,
  id_compra_requisicao int unsigned not null,
  id_produto int not null,
  quantidade decimal(18,6) null,
  primary key (id),
  index fk_requisicao_compra_detalhe (id_compra_requisicao asc),
  index fk_compra_requisicao_detalhe_produto1_idx (id_produto asc),
  constraint fk_compra_requisicao_detalhe_compra_requisicao1
    foreign key (id_compra_requisicao)
    references compra_requisicao (id)
    on delete no action
    on update no action,
  constraint fk_compra_requisicao_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists compra_cotacao (
  id int unsigned not null auto_increment,
  id_compra_requisicao int unsigned not null,
  data_cotacao date null,
  descricao varchar(100) null,
  primary key (id),
  index fk_compra_cotacao_compra_requisicao1_idx (id_compra_requisicao asc),
  constraint fk_compra_cotacao_compra_requisicao1
    foreign key (id_compra_requisicao)
    references compra_requisicao (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists compra_fornecedor_cotacao (
  id int unsigned not null auto_increment,
  id_compra_cotacao int unsigned not null,
  id_fornecedor int not null,
  codigo varchar(32) null,
  prazo_entrega varchar(50) null,
  venda_condicoes_pagamento varchar(50) null,
  valor_subtotal decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  primary key (id),
  index fk_cotacao_fornecedor (id_compra_cotacao asc),
  index fk_compra_fornecedor_cotacao_fornecedor1_idx (id_fornecedor asc),
  constraint fk_compra_fornecedor_cotacao_compra_cotacao1
    foreign key (id_compra_cotacao)
    references compra_cotacao (id)
    on delete no action
    on update no action,
  constraint fk_compra_fornecedor_cotacao_fornecedor1
    foreign key (id_fornecedor)
    references fornecedor (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists compra_cotacao_detalhe (
  id int unsigned not null auto_increment,
  id_compra_fornecedor_cotacao int unsigned not null,
  id_produto int not null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_subtotal decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  primary key (id),
  index fk_fornecedor_cotacao_detalhe (id_compra_fornecedor_cotacao asc),
  index fk_compra_cotacao_detalhe_produto1_idx (id_produto asc),
  constraint fk_compra_cotacao_detalhe_compra_fornecedor_cotacao1
    foreign key (id_compra_fornecedor_cotacao)
    references compra_fornecedor_cotacao (id)
    on delete no action
    on update no action,
  constraint fk_compra_cotacao_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists compra_tipo_pedido (
  id int unsigned not null auto_increment,
  codigo char(2) null,
  nome varchar(30) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists compra_pedido (
  id int unsigned not null auto_increment,
  id_compra_tipo_pedido int unsigned not null,
  id_fornecedor int not null,
  id_colaborador int not null,
  data_pedido date null,
  data_prevista_entrega date null,
  data_previsao_pagamento date null,
  local_entrega varchar(100) null,
  local_cobranca varchar(100) null,
  contato varchar(50) null,
  valor_subtotal decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  tipo_frete char(1) null,
  forma_pagamento char(1) null,
  base_calculo_icms decimal(18,6) null,
  valor_icms decimal(18,6) null,
  base_calculo_icms_st decimal(18,6) null,
  valor_icms_st decimal(18,6) null,
  valor_total_produtos decimal(18,6) null,
  valor_frete decimal(18,6) null,
  valor_seguro decimal(18,6) null,
  valor_outras_despesas decimal(18,6) null,
  valor_ipi decimal(18,6) null,
  valor_total_nf decimal(18,6) null,
  quantidade_parcelas int unsigned null,
  dia_primeiro_vencimento char(2) null,
  intervalo_entre_parcelas int unsigned null,
  dia_fixo_parcela char(2) null,
  codigo_cotacao varchar(32) null,
  primary key (id),
  index fk_tipo_pedido_compra (id_compra_tipo_pedido asc),
  index fk_compra_pedido_fornecedor1_idx (id_fornecedor asc),
  index fk_compra_pedido_colaborador1_idx (id_colaborador asc),
  constraint fk_compra_pedido_compra_tipo_pedido1
    foreign key (id_compra_tipo_pedido)
    references compra_tipo_pedido (id)
    on delete no action
    on update no action,
  constraint fk_compra_pedido_fornecedor1
    foreign key (id_fornecedor)
    references fornecedor (id)
    on delete no action
    on update no action,
  constraint fk_compra_pedido_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists compra_pedido_detalhe (
  id int unsigned not null auto_increment,
  id_compra_pedido int unsigned not null,
  id_produto int not null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_subtotal decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  cst char(2) null,
  csosn char(3) null,
  cfop int null,
  base_calculo_icms decimal(18,6) null,
  valor_icms decimal(18,6) null,
  valor_ipi decimal(18,6) null,
  aliquota_icms decimal(18,6) null,
  aliquota_ipi decimal(18,6) null,
  primary key (id),
  index fk_pedido_compra_detalhe (id_compra_pedido asc),
  index fk_compra_pedido_detalhe_produto1_idx (id_produto asc),
  constraint fk_compra_pedido_detalhe_compra_pedido
    foreign key (id_compra_pedido)
    references compra_pedido (id)
    on delete no action
    on update no action,
  constraint fk_compra_pedido_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists venda_condicoes_pagamento (
  id int unsigned not null auto_increment,
  nome varchar(50) null,
  descricao text null,
  faturamento_minimo decimal(18,6) null,
  faturamento_maximo decimal(18,6) null,
  indice_correcao decimal(18,6) null,
  dias_tolerancia int unsigned null,
  valor_tolerancia decimal(18,6) null,
  prazo_medio int unsigned null,
  vista_prazo char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists venda_orcamento_cabecalho (
  id int unsigned not null auto_increment,
  id_venda_condicoes_pagamento int unsigned not null,
  id_vendedor int not null,
  id_cliente int not null,
  id_transportadora int null,
  codigo varchar(20) null,
  data_cadastro date null,
  data_entrega date null,
  validade date null,
  tipo_frete char(1) null,
  valor_subtotal decimal(18,6) null,
  valor_frete decimal(18,6) null,
  taxa_comissao decimal(18,6) null,
  valor_comissao decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  observacao text null,
  primary key (id),
  index fk_cond_pgto_orc_ped_venda (id_venda_condicoes_pagamento asc),
  index fk_venda_orcamento_cabecalho_vendedor1_idx (id_vendedor asc),
  index fk_venda_orcamento_cabecalho_cliente1_idx (id_cliente asc),
  index fk_venda_orcamento_cabecalho_transportadora1_idx (id_transportadora asc),
  constraint fk_venda_orcamento_cabecalho_venda_condicoes_pagamento1
    foreign key (id_venda_condicoes_pagamento)
    references venda_condicoes_pagamento (id)
    on delete no action
    on update no action,
  constraint fk_venda_orcamento_cabecalho_vendedor1
    foreign key (id_vendedor)
    references vendedor (id)
    on delete no action
    on update no action,
  constraint fk_venda_orcamento_cabecalho_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action,
  constraint fk_venda_orcamento_cabecalho_transportadora1
    foreign key (id_transportadora)
    references transportadora (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nota_fiscal_modelo (
  id int unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(100) null,
  modelo varchar(10) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists nota_fiscal_tipo (
  id int unsigned not null auto_increment,
  id_nota_fiscal_modelo int unsigned not null,
  nome varchar(50) null,
  descricao text null,
  serie char(3) null,
  serie_scan char(3) null,
  ultimo_numero int unsigned null,
  primary key (id),
  index fk_nf_tipo_modelo (id_nota_fiscal_modelo asc),
  constraint fk_nota_fiscal_tipo_nota_fiscal_modelo1
    foreign key (id_nota_fiscal_modelo)
    references nota_fiscal_modelo (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists venda_orcamento_detalhe (
  id int unsigned not null auto_increment,
  id_venda_orcamento_cabecalho int unsigned not null,
  id_produto int not null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_subtotal decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  primary key (id),
  index fk_venda_orcamento_cab_det (id_venda_orcamento_cabecalho asc),
  index fk_venda_orcamento_detalhe_produto1_idx (id_produto asc),
  constraint fk_venda_orcamento_detalhe_venda_orcamento_cabecalho1
    foreign key (id_venda_orcamento_cabecalho)
    references venda_orcamento_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_venda_orcamento_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists venda_cabecalho (
  id int unsigned not null auto_increment,
  id_venda_orcamento_cabecalho int unsigned null,
  id_venda_condicoes_pagamento int unsigned not null,
  id_nota_fiscal_tipo int unsigned not null,
  id_cliente int not null,
  id_transportadora int null,
  id_vendedor int not null,
  data_venda date null,
  data_saida date null,
  hora_saida varchar(8) null,
  numero_fatura int unsigned null,
  local_entrega varchar(100) null,
  local_cobranca varchar(100) null,
  valor_subtotal decimal(18,6) null,
  taxa_comissao decimal(18,6) null,
  valor_comissao decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  tipo_frete char(1) null,
  forma_pagamento char(1) null,
  valor_frete decimal(18,6) null,
  valor_seguro decimal(18,6) null,
  observacao text null,
  situacao char(1) null,
  dia_fixo_parcela char(2) null,
  primary key (id),
  index fk_orcamento_venda (id_venda_orcamento_cabecalho asc),
  index fk_venda_cab_condicoes (id_venda_condicoes_pagamento asc),
  index fk_tipo_nf_venda_cab (id_nota_fiscal_tipo asc),
  index fk_venda_cabecalho_cliente1_idx (id_cliente asc),
  index fk_venda_cabecalho_transportadora1_idx (id_transportadora asc),
  index fk_venda_cabecalho_vendedor1_idx (id_vendedor asc),
  constraint fk_venda_cabecalho_venda_orcamento_cabecalho1
    foreign key (id_venda_orcamento_cabecalho)
    references venda_orcamento_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_venda_cabecalho_venda_condicoes_pagamento1
    foreign key (id_venda_condicoes_pagamento)
    references venda_condicoes_pagamento (id)
    on delete no action
    on update no action,
  constraint fk_venda_cabecalho_nota_fiscal_tipo1
    foreign key (id_nota_fiscal_tipo)
    references nota_fiscal_tipo (id)
    on delete no action
    on update no action,
  constraint fk_venda_cabecalho_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action,
  constraint fk_venda_cabecalho_transportadora1
    foreign key (id_transportadora)
    references transportadora (id)
    on delete no action
    on update no action,
  constraint fk_venda_cabecalho_vendedor1
    foreign key (id_vendedor)
    references vendedor (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists venda_detalhe (
  id int unsigned not null auto_increment,
  id_venda_cabecalho int unsigned not null,
  id_produto int not null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_subtotal decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  primary key (id),
  index fk_venda_cab_det (id_venda_cabecalho asc),
  index fk_venda_detalhe_produto1_idx (id_produto asc),
  constraint fk_venda_detalhe_id_venda_cabecalho
    foreign key (id_venda_cabecalho)
    references venda_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_venda_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists venda_condicoes_parcelas (
  id int unsigned not null auto_increment,
  id_venda_condicoes_pagamento int unsigned not null,
  parcela int unsigned null,
  dias int unsigned null,
  taxa decimal(18,6) null,
  primary key (id),
  index fk_condicoes_parcelas (id_venda_condicoes_pagamento asc),
  constraint fk_venda_condicoes_parcelas_id_venda_condicoes_pagamento
    foreign key (id_venda_condicoes_pagamento)
    references venda_condicoes_pagamento (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists venda_frete (
  id int unsigned not null auto_increment,
  id_venda_cabecalho int unsigned not null,
  id_transportadora int not null,
  conhecimento int unsigned null,
  responsavel char(1) null,
  placa varchar(7) null,
  uf_placa char(2) null,
  selo_fiscal int null,
  quantidade_volume decimal(18,6) null,
  marca_volume varchar(50) null,
  especie_volume varchar(20) null,
  peso_bruto decimal(18,6) null,
  peso_liquido decimal(18,6) null,
  primary key (id),
  index fk_venda_cabecalho_frete (id_venda_cabecalho asc),
  index fk_venda_frete_transportadora1_idx (id_transportadora asc),
  constraint fk_venda_cabecalho_frete_id_venda_cabecalho
    foreign key (id_venda_cabecalho)
    references venda_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_venda_frete_transportadora1
    foreign key (id_transportadora)
    references transportadora (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists venda_comissao (
  id int unsigned not null auto_increment,
  id_venda_cabecalho int unsigned not null,
  id_vendedor int not null,
  valor_venda decimal(18,6) null,
  tipo_contabil char(1) null,
  valor_comissao decimal(18,6) zerofill null,
  situacao char(1) null,
  data_lancamento date null,
  primary key (id),
  index fk_venda_comissao (id_venda_cabecalho asc),
  index fk_venda_comissao_vendedor1_idx (id_vendedor asc),
  constraint fk_venda_cabecalho_id_venda_cabecalho_comissao
    foreign key (id_venda_cabecalho)
    references venda_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_venda_comissao_vendedor1
    foreign key (id_vendedor)
    references vendedor (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists requisicao_interna_cabecalho (
  id int unsigned not null auto_increment,
  id_colaborador int not null,
  data_requisicao date null,
  situacao char(1) null,
  primary key (id),
  index fk_requisicao_interna_cabecalho_colaborador1_idx (id_colaborador asc),
  constraint fk_requisicao_interna_cabecalho_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists requisicao_interna_detalhe (
  id int unsigned not null auto_increment,
  id_requisicao_interna_cabecalho int unsigned not null,
  id_produto int not null,
  quantidade decimal(18,6) not null,
  primary key (id),
  index fk_req_interna_cab_det (id_requisicao_interna_cabecalho asc),
  index fk_requisicao_interna_detalhe_produto1_idx (id_produto asc),
  constraint fk_requisicao_interna_detalhe_id_requisicao_interna_cabecalho
    foreign key (id_requisicao_interna_cabecalho)
    references requisicao_interna_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_requisicao_interna_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb;  
create table if not exists estoque_reajuste_cabecalho (
  id int unsigned not null auto_increment,
  id_colaborador int not null,
  data_reajuste date null,
  taxa decimal(18,6) null,
  tipo_reajuste char(1) null,
  justificativa varchar(100) null,
  primary key (id),
  index fk_estoque_reajuste_cabecalho_colaborador1_idx (id_colaborador asc),
  constraint fk_estoque_reajuste_cabecalho_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists estoque_reajuste_detalhe (
  id int unsigned not null auto_increment,
  id_estoque_reajuste_cabecalho int unsigned not null,
  id_produto int not null,
  valor_original decimal(18,6) null,
  valor_reajuste decimal(18,6) null,
  primary key (id),
  index fk_estoque_reajuste_cab_det (id_estoque_reajuste_cabecalho asc),
  index fk_estoque_reajuste_detalhe_produto1_idx (id_produto asc),
  constraint fk_estoque_reajuste_detalhe_id_estoque_reajuste_cabecalho
    foreign key (id_estoque_reajuste_cabecalho)
    references estoque_reajuste_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_estoque_reajuste_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb;  
create table if not exists estoque_cor (
  id int unsigned not null auto_increment,
  codigo char(4) null,
  nome varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists estoque_tamanho (
  id int unsigned not null auto_increment,
  codigo char(4) null,
  nome varchar(50) null,
  altura decimal(18,6) null,
  comprimento decimal(18,6) null,
  largura decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists estoque_sabor (
  id int unsigned not null auto_increment,
  codigo char(4) null,
  nome varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists estoque_marca (
  id int unsigned not null auto_increment,
  codigo char(4) null,
  nome varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists estoque_grade (
  id int unsigned not null auto_increment,
  id_estoque_marca int unsigned null,
  id_estoque_sabor int unsigned null,
  id_estoque_tamanho int unsigned null,
  id_estoque_cor int unsigned null,
  id_produto int not null,
  codigo varchar(50) null,
  quantidade decimal(18,6) null,
  primary key (id),
  index fk_estoque_cor_grade (id_estoque_cor asc),
  index fk_estoque_tamanho_grade (id_estoque_tamanho asc),
  index fk_estoque_sabor_grade (id_estoque_sabor asc),
  index fk_estoque_marca_grade (id_estoque_marca asc),
  index fk_estoque_grade_produto1_idx (id_produto asc),
  constraint fk_estoque_grade_estoque_cor
    foreign key (id_estoque_cor)
    references estoque_cor (id)
    on delete no action
    on update no action,
  constraint fk_estoque_grade_estoque_tamanho
    foreign key (id_estoque_tamanho)
    references estoque_tamanho (id)
    on delete no action
    on update no action,
  constraint fk_estoque_grade_estoque_sabor
    foreign key (id_estoque_sabor)
    references estoque_sabor (id)
    on delete no action
    on update no action,
  constraint fk_estoque_grade_estoque_marca
    foreign key (id_estoque_marca)
    references estoque_marca (id)
    on delete no action
    on update no action,
  constraint fk_estoque_grade_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tribut_icms_custom_det (
  id int unsigned not null auto_increment,
  id_tribut_icms_custom_cab int unsigned not null,
  uf_destino char(2) null,
  cfop int unsigned null,
  csosn char(3) null,
  cst char(2) null,
  modalidade_bc char(1) null,
  aliquota decimal(18,6) null,
  valor_pauta decimal(18,6) null,
  valor_preco_maximo decimal(18,6) null,
  mva decimal(18,6) null,
  porcento_bc decimal(18,6) null,
  modalidade_bc_st char(1) null,
  aliquota_interna_st decimal(18,6) null,
  aliquota_interestadual_st decimal(18,6) null,
  porcento_bc_st decimal(18,6) null,
  aliquota_icms_st decimal(18,6) null,
  valor_pauta_st decimal(18,6) null,
  valor_preco_maximo_st decimal(18,6) null,
  primary key (id),
  index fk_icms_custom_cab_det (id_tribut_icms_custom_cab asc),
  constraint fk_tribut_icms_custom_det_tribut_icms_custom_cab
    foreign key (id_tribut_icms_custom_cab)
    references tribut_icms_custom_cab (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists dia_parcela (
  id int not null auto_increment,
  dia char(2) null,
  primary key (id))
engine = innodb;
create table if not exists nfce_operador (
  id int unsigned not null auto_increment,
  id_colaborador int not null,
  login varchar(20) null,
  senha varchar(20) null,
  nivel_autorizacao char(1) null,
  primary key (id),
  index fk_nfce_operador_colaborador1_idx (id_colaborador asc),
  constraint fk_nfce_operador_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfce_caixa (
  id int unsigned not null auto_increment,
  nome varchar(50) null,
  data_cadastro date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists nfce_movimento (
  id int unsigned not null auto_increment,
  id_nfce_caixa int unsigned not null,
  id_nfce_operador int unsigned null,
  id_gerente_supervisor int unsigned null,
  data_abertura date null,
  hora_abertura varchar(8) null,
  data_fechamento date null,
  hora_fechamento varchar(8) null,
  total_suprimento decimal(18,6) null,
  total_sangria decimal(18,6) null,
  total_nao_fiscal decimal(18,6) null,
  total_venda decimal(18,6) null,
  total_desconto decimal(18,6) null,
  total_acrescimo decimal(18,6) null,
  total_final decimal(18,6) null,
  total_recebido decimal(18,6) null,
  total_troco decimal(18,6) null,
  total_cancelado decimal(18,6) null,
  status_movimento char(1) null,
  primary key (id),
  index fk_nfce_operador_mov (id_nfce_operador asc),
  index fk_nfce_caixa_mov (id_nfce_caixa asc),
  constraint fk_nfce_movimento_nfce_operador
    foreign key (id_nfce_operador)
    references nfce_operador (id)
    on delete no action
    on update no action,
  constraint fk_nfce_movimento_nfce_caixa
    foreign key (id_nfce_caixa)
    references nfce_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_cabecalho (
  id int unsigned not null auto_increment,
  id_vendedor int null,
  uf_emitente int null,
  codigo_numerico varchar(8) null,
  natureza_operacao varchar(60) null,
  codigo_modelo char(2) null,
  serie char(3) null,
  numero varchar(9) null,
  data_hora_emissao timestamp null,
  data_hora_entrada_saida timestamp null,
  tipo_operacao char(1) null,
  local_destino char(1) null,
  codigo_municipio int null,
  formato_impressao_danfe char(1) null,
  tipo_emissao char(1) null,
  chave_acesso varchar(44) null,
  digito_chave_acesso char(1) null,
  ambiente char(1) null,
  finalidade_emissao char(1) null,
  consumidor_operacao char(1) null,
  consumidor_presenca char(1) null,
  processo_emissao char(1) null,
  versao_processo_emissao varchar(20) null,
  data_entrada_contingencia timestamp null,
  justificativa_contingencia varchar(255) null,
  base_calculo_icms decimal(18,6) null,
  valor_icms decimal(18,6) null,
  valor_icms_desonerado decimal(18,6) null,
  total_icms_fcp_uf_destino decimal(18,6) null,
  total_icms_interestadual_uf_destino decimal(18,6) null,
  total_icms_interestadual_uf_remetente decimal(18,6) null,
  valor_total_fcp decimal(18,6) null,
  base_calculo_icms_st decimal(18,6) null,
  valor_icms_st decimal(18,6) null,
  valor_total_fcp_st decimal(18,6) null,
  valor_total_fcp_st_retido decimal(18,6) null,
  valor_total_produtos decimal(18,6) null,
  valor_frete decimal(18,6) null,
  valor_seguro decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_imposto_importacao decimal(18,6) null,
  valor_ipi decimal(18,6) null,
  valor_ipi_devolvido decimal(18,6) null,
  valor_pis decimal(18,6) null,
  valor_cofins decimal(18,6) null,
  valor_despesas_acessorias decimal(18,6) null,
  valor_total decimal(18,6) null,
  valor_total_tributos decimal(18,6) null,
  valor_servicos decimal(18,6) null,
  base_calculo_issqn decimal(18,6) null,
  valor_issqn decimal(18,6) null,
  valor_pis_issqn decimal(18,6) null,
  valor_cofins_issqn decimal(18,6) null,
  data_prestacao_servico date null,
  valor_deducao_issqn decimal(18,6) null,
  outras_retencoes_issqn decimal(18,6) null,
  desconto_incondicionado_issqn decimal(18,6) null,
  desconto_condicionado_issqn decimal(18,6) null,
  total_retencao_issqn decimal(18,6) null,
  regime_especial_tributacao char(1) null,
  valor_retido_pis decimal(18,6) null,
  valor_retido_cofins decimal(18,6) null,
  valor_retido_csll decimal(18,6) null,
  base_calculo_irrf decimal(18,6) null,
  valor_retido_irrf decimal(18,6) null,
  base_calculo_previdencia decimal(18,6) null,
  valor_retido_previdencia decimal(18,6) null,
  informacoes_add_fisco text null,
  informacoes_add_contribuinte text null,
  comex_uf_embarque char(2) null,
  comex_local_embarque varchar(60) null,
  comex_local_despacho varchar(60) null,
  compra_nota_empenho varchar(22) null,
  compra_pedido varchar(60) null,
  compra_contrato varchar(60) null,
  qrcode text null,
  url_chave varchar(85) null,
  status_nota char(1) null,
  id_fornecedor int null,
  id_nfce_movimento int unsigned null,
  id_venda_cabecalho int unsigned null,
  id_tribut_operacao_fiscal int unsigned null,
  id_cliente int null,
  primary key (id),
  index fk_nfe_cabecalho_vendedor1_idx (id_vendedor asc),
  index fk_nfe_cabecalho_fornecedor1_idx (id_fornecedor asc),
  index fk_nfe_cabecalho_nfce_movimento1_idx (id_nfce_movimento asc),
  index fk_nfe_cabecalho_venda_cabecalho1_idx (id_venda_cabecalho asc),
  index fk_nfe_cabecalho_tribut_operacao_fiscal1_idx (id_tribut_operacao_fiscal asc),
  index fk_nfe_cabecalho_cliente1_idx (id_cliente asc),
  constraint fk_nfe_cabecalho_vendedor1
    foreign key (id_vendedor)
    references vendedor (id)
    on delete no action
    on update no action,
  constraint fk_nfe_cabecalho_fornecedor1
    foreign key (id_fornecedor)
    references fornecedor (id)
    on delete no action
    on update no action,
  constraint fk_nfe_cabecalho_nfce_movimento1
    foreign key (id_nfce_movimento)
    references nfce_movimento (id)
    on delete no action
    on update no action,
  constraint fk_nfe_cabecalho_venda_cabecalho1
    foreign key (id_venda_cabecalho)
    references venda_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_nfe_cabecalho_tribut_operacao_fiscal1
    foreign key (id_tribut_operacao_fiscal)
    references tribut_operacao_fiscal (id)
    on delete no action
    on update no action,
  constraint fk_nfe_cabecalho_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  id_produto int null,
  numero_item int unsigned null,
  codigo_produto varchar(60) null,
  gtin varchar(14) null,
  nome_produto varchar(120) null,
  ncm varchar(8) null,
  nve varchar(6) null,
  cest varchar(7) null,
  indicador_escala_relevante char(1) null,
  cnpj_fabricante varchar(14) null,
  codigo_beneficio_fiscal varchar(10) null,
  ex_tipi int unsigned null,
  cfop int unsigned null,
  unidade_comercial varchar(6) null,
  quantidade_comercial decimal(18,6) null,
  numero_pedido_compra varchar(15) null,
  item_pedido_compra int unsigned null,
  numero_fci varchar(36) null,
  numero_recopi varchar(20) null,
  valor_unitario_comercial decimal(18,6) null,
  valor_bruto_produto decimal(18,6) null,
  gtin_unidade_tributavel varchar(14) null,
  unidade_tributavel varchar(6) null,
  quantidade_tributavel decimal(18,6) null,
  valor_unitario_tributavel decimal(18,6) null,
  valor_frete decimal(18,6) null,
  valor_seguro decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_outras_despesas decimal(18,6) null,
  entra_total char(1) null,
  valor_total_tributos decimal(18,6) null,
  percentual_devolvido decimal(18,6) null,
  valor_ipi_devolvido decimal(18,6) null,
  informacoes_adicionais text null,
  valor_subtotal decimal(18,6) null,
  valor_total decimal(18,6) null,
  primary key (id),
  index fk_nfe_cab_det (id_nfe_cabecalho asc),
  index fk_nfe_detalhe_produto1 (id_produto asc),
  constraint fk_nfe_detalhe_nfe_cabecalho
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_nfe_detalhe_produto
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb;  
create table if not exists nfe_referenciada (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  chave_acesso varchar(44) null,
  primary key (id),
  index fk_nfe_referenciada_nfe_cabecalho (id_nfe_cabecalho asc),
  constraint fk_nfe_referenciada_nfe_cabecalho
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_emitente (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  logradouro varchar(60) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null default 1058 ,
  nome_pais varchar(60) null default 'brasil' ,
  telefone varchar(14) null,
  inscricao_estadual varchar(14) null,
  inscricao_estadual_st varchar(14) null,
  inscricao_municipal varchar(15) null,
  cnae varchar(7) null,
  crt char(1) null,
  primary key (id),
  index fk_nfe_emitente_nfe_cabecalho (id_nfe_cabecalho asc),
  constraint fk_nfe_emitente_nfe_cabecalho
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb;  
create table if not exists nfe_destinatario (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  estrangeiro_identificacao varchar(20) null,
  nome varchar(60) null,
  logradouro varchar(60) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  telefone varchar(14) null,
  indicador_ie char(1) null,
  inscricao_estadual varchar(14) null,
  suframa int unsigned null,
  inscricao_municipal varchar(15) null,
  email varchar(60) null,
  primary key (id),
  index fk_nfe_destinatario_nfe_cabecalho (id_nfe_cabecalho asc),
  constraint fk_nfe_destinatario_nfe_cabecalho
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_local_retirada (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  nome_expedidor varchar(60) null,
  logradouro varchar(60) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  telefone varchar(14) null,
  email varchar(60) null,
  inscricao_estadual varchar(14) null,
  primary key (id),
  index fk_nfe_local_retirada_nfe_cabecalho (id_nfe_cabecalho asc),
  constraint fk_nfe_local_retirada_nfe_cabecalho
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_det_especifico_medicamento (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  codigo_anvisa varchar(13) null,
  motivo_isencao varchar(250) null,
  preco_maximo_consumidor decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_especifico_medicamento_nfe_detalhe (id_nfe_detalhe asc),
  constraint fk_nfe_det_especifico_medicamento_nfe_detalhe
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb;
create table if not exists nfe_det_especifico_veiculo (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  tipo_operacao char(1) null,
  chassi varchar(17) null,
  cor varchar(4) null,
  descricao_cor varchar(40) null,
  potencia_motor varchar(4) null,
  cilindradas varchar(4) null,
  peso_liquido varchar(9) null,
  peso_bruto varchar(9) null,
  numero_serie varchar(9) null,
  tipo_combustivel char(2) null,
  numero_motor varchar(21) null,
  capacidade_maxima_tracao varchar(9) null,
  distancia_eixos varchar(4) null,
  ano_modelo char(4) null,
  ano_fabricacao char(4) null,
  tipo_pintura char(1) null,
  tipo_veiculo char(2) null,
  especie_veiculo char(1) null,
  condicao_vin char(1) null,
  condicao_veiculo char(1) null,
  codigo_marca_modelo varchar(6) null,
  codigo_cor_denatran char(2) null,
  lotacao_maxima int unsigned null,
  restricao char(1) null,
  primary key (id),
  index fk_nfe_det_especifico_veiculo_nfe_detalhe (id_nfe_detalhe asc),
  constraint fk_nfe_det_especifico_veiculo_nfe_detalhe
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb;
create table if not exists nfe_det_especifico_armamento (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  tipo_arma char(1) null,
  numero_serie_arma varchar(15) null,
  numero_serie_cano varchar(15) null,
  descricao varchar(250) null,
  primary key (id),
  index fk_nfe_det_especifico_armamento_nfe_detalhe (id_nfe_detalhe asc),
  constraint fk_nfe_det_especifico_armamento_nfe_detalhe
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb;
create table if not exists nfe_det_especifico_combustivel (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  codigo_anp int unsigned null,
  descricao_anp varchar(95) null,
  percentual_glp decimal(18,6) null,
  percentual_gas_nacional decimal(18,6) null,
  percentual_gas_importado decimal(18,6) null,
  valor_partida decimal(18,6) null,
  codif varchar(21) null,
  quantidade_temp_ambiente decimal(18,6) null,
  uf_consumo char(2) null,
  cide_base_calculo decimal(18,6) null,
  cide_aliquota decimal(18,6) null,
  cide_valor decimal(18,6) null,
  encerrante_bico int null,
  encerrante_bomba int null,
  encerrante_tanque int null,
  encerrante_valor_inicio decimal(18,6) null,
  encerrante_valor_fim decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_especifico_combustivel_nfe_detalhe (id_nfe_detalhe asc),
  constraint fk_nfe_det_especifico_combustivel_nfe_detalhe
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb;
create table if not exists nfe_transporte (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  id_transportadora int null,
  modalidade_frete char(1) null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  nome varchar(60) null,
  inscricao_estadual varchar(14) null,
  endereco varchar(60) null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  valor_servico decimal(18,6) null,
  valor_bc_retencao_icms decimal(18,6) null,
  aliquota_retencao_icms decimal(18,6) null,
  valor_icms_retido decimal(18,6) null,
  cfop int unsigned null,
  municipio int unsigned null,
  placa_veiculo varchar(7) null,
  uf_veiculo char(2) null,
  rntc_veiculo varchar(20) null,
  primary key (id),
  index fk_nfe_transporte_nfe_cabecalho (id_nfe_cabecalho asc),
  index fk_nfe_transporte_transportadora1 (id_transportadora asc),
  constraint fk_nfe_transporte_nfe_cabecalho
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_nfe_transporte_transportadora1
    foreign key (id_transportadora)
    references transportadora (id)
    on delete no action
    on update no action) 
 engine = innodb;
create table if not exists nfe_fatura (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  numero varchar(60) null,
  valor_original decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_liquido decimal(18,6) null,
  primary key (id),
  index fk_nfe_cab_fatura (id_nfe_cabecalho asc),
  constraint fk_nfe_cab_fatura
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action
) engine = innodb;
create table if not exists nfe_duplicata (
  id int unsigned not null auto_increment,
  id_nfe_fatura int unsigned not null,
  numero varchar(60) null,
  data_vencimento date null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_nfe_duplicata_nfe_fatura1_idx (id_nfe_fatura asc),
  constraint fk_nfe_duplicata_nfe_fatura1
    foreign key (id_nfe_fatura)
    references nfe_fatura (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_declaracao_importacao (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  numero_documento varchar(12) null,
  data_registro date null,
  local_desembaraco varchar(60) null,
  uf_desembaraco char(2) null,
  data_desembaraco date null,
  via_transporte char(1) null,
  valor_afrmm decimal(18,6) null,
  forma_intermediacao char(1) null,
  cnpj varchar(14) null,
  uf_terceiro char(2) null,
  codigo_exportador varchar(60) null,
  primary key (id),
  index fk_nfe_det_dec_importacao (id_nfe_detalhe asc),
  constraint fk_1771ae4ce2764f9499ebbda61d415790
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_importacao_detalhe (
  id int unsigned not null auto_increment,
  id_nfe_declaracao_importacao int unsigned not null,
  numero_adicao int unsigned null,
  numero_sequencial int unsigned null,
  codigo_fabricante_estrangeiro varchar(60) null,
  valor_desconto decimal(18,6) null,
  drawback int unsigned null,
  primary key (id),
  index fk_nfe_importacao_detalhe (id_nfe_declaracao_importacao asc),
  constraint fk_788f333adcb04371aecf18a42abf93b6
    foreign key (id_nfe_declaracao_importacao)
    references nfe_declaracao_importacao (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_cana (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  safra varchar(9) null,
  mes_ano_referencia varchar(7) null,
  primary key (id),
  index fk_nfe_cab_cana (id_nfe_cabecalho asc),
  constraint fk_d05c4271b5e547ebbd5b3885fea3e899
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_cana_fornecimento_diario (
  id int unsigned not null auto_increment,
  id_nfe_cana int unsigned not null,
  dia char(2) null,
  quantidade decimal(18,6) null,
  quantidade_total_mes decimal(18,6) null,
  quantidade_total_anterior decimal(18,6) null,
  quantidade_total_geral decimal(18,6) null,
  primary key (id),
  index fk_nfe_cana_fornecimento (id_nfe_cana asc),
  constraint fk_71a66239c5384b83ad23efc8f3fa0ab4
    foreign key (id_nfe_cana)
    references nfe_cana (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_cana_deducoes_safra (
  id int unsigned not null auto_increment,
  id_nfe_cana int unsigned not null,
  decricao varchar(60) null,
  valor_deducao decimal(18,6) null,
  valor_fornecimento decimal(18,6) null,
  valor_total_deducao decimal(18,6) null,
  valor_liquido_fornecimento decimal(18,6) null,
  primary key (id),
  index fk_nfe_cana_deducoes (id_nfe_cana asc),
  constraint fk_3c5ff51c922a47c7b352e32615ca2327
    foreign key (id_nfe_cana)
    references nfe_cana (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_cupom_fiscal_referenciado (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  modelo_documento_fiscal char(2) null,
  numero_ordem_ecf int unsigned null,
  coo int unsigned null,
  data_emissao_cupom date null,
  numero_caixa int unsigned null,
  numero_serie_ecf varchar(21) null,
  primary key (id),
  index fk_nfe_cf_referenciado (id_nfe_cabecalho asc),
  constraint fk_0b096a6dc97b4de5b93d254b25c37cc5
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_numero (
  id int unsigned not null auto_increment,
  serie char(3) null,
  numero int unsigned null,
  primary key (id)) 
 engine = innodb; 
create table if not exists nfe_prod_rural_referenciada (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  codigo_uf int unsigned null,
  ano_mes varchar(4) null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  inscricao_estadual varchar(14) null,
  modelo char(2) null,
  serie char(3) null,
  numero_nf int unsigned null,
  primary key (id),
  index fk_nfe_rural_referenciado (id_nfe_cabecalho asc),
  constraint fk_7c9760bef8ed418daed91f65acb76f67
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_nf_referenciada (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  codigo_uf int unsigned null,
  ano_mes varchar(4) null,
  cnpj varchar(14) null,
  modelo char(2) null default '01' ,
  serie char(3) null,
  numero_nf int unsigned null,
  primary key (id),
  index fk_nfe_nf_referenciada (id_nfe_cabecalho asc),
  constraint fk_172ba84474674e30bb11f98e00d75e8f
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_icms (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  origem_mercadoria char(1) null,
  cst_icms char(2) null,
  csosn char(3) null,
  modalidade_bc_icms char(1) null,
  percentual_reducao_bc_icms decimal(18,6) null,
  valor_bc_icms decimal(18,6) null,
  aliquota_icms decimal(18,6) null,
  valor_icms_operacao decimal(18,6) null,
  percentual_diferimento decimal(18,6) null,
  valor_icms_diferido decimal(18,6) null,
  valor_icms decimal(18,6) null,
  base_calculo_fcp decimal(18,6) null,
  percentual_fcp decimal(18,6) null,
  valor_fcp decimal(18,6) null,
  modalidade_bc_icms_st char(1) null,
  percentual_mva_icms_st decimal(18,6) null,
  percentual_reducao_bc_icms_st decimal(18,6) null,
  valor_base_calculo_icms_st decimal(18,6) null,
  aliquota_icms_st decimal(18,6) null,
  valor_icms_st decimal(18,6) null,
  base_calculo_fcp_st decimal(18,6) null,
  percentual_fcp_st decimal(18,6) null,
  valor_fcp_st decimal(18,6) null,
  uf_st char(2) null,
  percentual_bc_operacao_propria decimal(18,6) null,
  valor_bc_icms_st_retido decimal(18,6) null,
  aliquota_suportada_consumidor decimal(18,6) null,
  valor_icms_substituto decimal(18,6) null,
  valor_icms_st_retido decimal(18,6) null,
  base_calculo_fcp_st_retido decimal(18,6) null,
  percentual_fcp_st_retido decimal(18,6) null,
  valor_fcp_st_retido decimal(18,6) null,
  motivo_desoneracao_icms char(2) null,
  valor_icms_desonerado decimal(18,6) null,
  aliquota_credito_icms_sn decimal(18,6) null,
  valor_credito_icms_sn decimal(18,6) null,
  valor_bc_icms_st_destino decimal(18,6) null,
  valor_icms_st_destino decimal(18,6) null,
  percentual_reducao_bc_efetivo decimal(18,6) null,
  valor_bc_efetivo decimal(18,6) null,
  aliquota_icms_efetivo decimal(18,6) null,
  valor_icms_efetivo decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_icms (id_nfe_detalhe asc),
  constraint fk_2eca610c69b943e7b65df30edc701a59
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_ipi (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  cnpj_produtor varchar(14) null,
  codigo_selo_ipi varchar(60) null,
  quantidade_selo_ipi int unsigned null,
  enquadramento_legal_ipi char(3) null,
  cst_ipi char(2) null,
  valor_base_calculo_ipi decimal(18,6) null,
  quantidade_unidade_tributavel decimal(18,6) null,
  valor_unidade_tributavel decimal(18,6) null,
  aliquota_ipi decimal(18,6) null,
  valor_ipi decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_ipi (id_nfe_detalhe asc),
  constraint fk_848512e868184ff885b2fd9773a5aaa8
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_ii (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  valor_bc_ii decimal(18,6) null,
  valor_despesas_aduaneiras decimal(18,6) null,
  valor_imposto_importacao decimal(18,6) null,
  valor_iof decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_ii (id_nfe_detalhe asc),
  constraint fk_dd990476fee74709bd8da6d372781ae1
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_pis (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  cst_pis char(2) null,
  valor_base_calculo_pis decimal(18,6) null,
  aliquota_pis_percentual decimal(18,6) null,
  valor_pis decimal(18,6) null,
  quantidade_vendida decimal(18,6) null,
  aliquota_pis_reais decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_pis (id_nfe_detalhe asc),
  constraint fk_a901b4cbeecc4e0d8163e9c48092fbb3
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_cofins (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  cst_cofins char(2) null,
  base_calculo_cofins decimal(18,6) null,
  aliquota_cofins_percentual decimal(18,6) null,
  quantidade_vendida decimal(18,6) null,
  aliquota_cofins_reais decimal(18,6) null,
  valor_cofins decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_cofins (id_nfe_detalhe asc),
  constraint fk_45f41988b66741838517dd1800d74792
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_issqn (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  base_calculo_issqn decimal(18,6) null,
  aliquota_issqn decimal(18,6) null,
  valor_issqn decimal(18,6) null,
  municipio_issqn int unsigned null,
  item_lista_servicos int unsigned null,
  valor_deducao decimal(18,6) null,
  valor_outras_retencoes decimal(18,6) null,
  valor_desconto_incondicionado decimal(18,6) null,
  valor_desconto_condicionado decimal(18,6) null,
  valor_retencao_iss decimal(18,6) null,
  indicador_exigibilidade_iss char(1) null,
  codigo_servico varchar(20) null,
  municipio_incidencia int unsigned null,
  pais_sevico_prestado int unsigned null,
  numero_processo varchar(30) null,
  indicador_incentivo_fiscal char(1) null,
  primary key (id),
  index fk_nfe_det_issqn (id_nfe_detalhe asc),
  constraint fk_d3eade394ba1402d9ae5f55a6327da3b
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_transporte_reboque (
  id int unsigned not null auto_increment,
  id_nfe_transporte int unsigned not null,
  placa varchar(8) null,
  uf char(2) null,
  rntc varchar(20) null,
  vagao varchar(20) null,
  balsa varchar(20) null,
  primary key (id),
  index fk_nfe_transp_reboque (id_nfe_transporte asc),
  constraint fk_33120fea84fa45b19f95183d64ac0f6f
    foreign key (id_nfe_transporte)
    references nfe_transporte (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_transporte_volume (
  id int unsigned not null,
  id_nfe_transporte int unsigned not null,
  quantidade int unsigned null,
  especie varchar(60) null,
  marca varchar(60) null,
  numeracao varchar(60) null,
  peso_liquido decimal(18,6) null,
  peso_bruto decimal(18,6) null,
  primary key (id),
  index fk_transp_volume (id_nfe_transporte asc),
  constraint fk_683237c698794c55bbd38cd3f1af00ef
    foreign key (id_nfe_transporte)
    references nfe_transporte (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_transporte_volume_lacre (
  id int unsigned not null auto_increment,
  id_nfe_transporte_volume int unsigned not null,
  numero varchar(60) null,
  primary key (id),
  index fk_nfe_transp_vol_lacre (id_nfe_transporte_volume asc),
  constraint fk_c379b5127c7141d48d327a543923dc1e
    foreign key (id_nfe_transporte_volume)
    references nfe_transporte_volume (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_processo_referenciado (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  identificador varchar(60) null,
  origem char(1) null,
  primary key (id),
  index nfe_cab_proc_ref (id_nfe_cabecalho asc),
  constraint fk_9c752faab71f425aacb6a3e8972e6ff4
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_cte_referenciado (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  chave_acesso varchar(44) null,
  primary key (id),
  index fk_nfe_cte_referenciado (id_nfe_cabecalho asc),
  constraint fk_43cdcd03ab6a4120bb27cbdb6c26b4a7
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_configuracao (
  id int unsigned not null auto_increment,
  certificado_digital_serie varchar(100) null,
  certificado_digital_caminho text null,
  certificado_digital_senha varchar(100) null,
  tipo_emissao int unsigned null,
  formato_impressao_danfe int unsigned null,
  processo_emissao int unsigned null,
  versao_processo_emissao varchar(20) null,
  caminho_logomarca text null,
  salvar_xml char(1) null,
  caminho_salvar_xml text null,
  caminho_schemas text null,
  caminho_arquivo_danfe text null,
  caminho_salvar_pdf text null,
  webservice_uf char(2) null,
  webservice_ambiente int unsigned null,
  webservice_proxy_host varchar(100) null,
  webservice_proxy_porta int unsigned null,
  webservice_proxy_usuario varchar(100) null,
  webservice_proxy_senha varchar(100) null,
  webservice_visualizar char(1) null,
  email_servidor_smtp varchar(100) null,
  email_porta int unsigned null,
  email_usuario varchar(100) null,
  email_senha varchar(100) null,
  email_assunto varchar(100) null,
  email_autentica_ssl char(1) null,
  email_texto text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists nfe_acesso_xml (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  primary key (id),
  index fk_acesso_xml (id_nfe_cabecalho asc),
  constraint fk_b466efd38c2d4efdb9aa9dceaaf57fa8
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_exportacao (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  drawback int unsigned null,
  numero_registro int unsigned null,
  chave_acesso varchar(44) null,
  quantidade decimal(18,6) null,
  primary key (id),
  index fk_nfe_exportacao (id_nfe_detalhe asc),
  constraint fk_29ddd06fddd4425594ee1e32334eb138
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_informacao_pagamento (
  id int unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  indicador_pagamento char(1) null,
  meio_pagamento char(2) null,
  valor decimal(18,6) null,
  tipo_integracao char(1) null,
  cnpj_operadora_cartao varchar(14) null,
  bandeira char(2) null,
  numero_autorizacao varchar(20) null,
  troco decimal(18,6) null,
  primary key (id),
  index fk_nfe_forma_pagamento (id_nfe_cabecalho asc),
  constraint fk_bfb74debfac64f448fdaf52bfec321ed
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_numero_inutilizado (
  id int unsigned not null auto_increment,
  serie char(3) null,
  numero int unsigned null,
  data_inutilizacao date null,
  observacao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists nfe_item_rastreado (
  id int not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  numero_lote varchar(20) null,
  quantidade_itens decimal(18,6) null,
  data_fabricacao date null,
  data_validade date null,
  codigo_agregacao varchar(20) null,
  primary key (id),
  index fk_nfe_item_rastreado_nfe_detalhe1_idx (id_nfe_detalhe asc),
  constraint fk_nfe_item_rastreado_nfe_detalhe1
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists nfe_detalhe_imposto_pis_st (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  valor_base_calculo_pis_st decimal(18,6) null,
  aliquota_pis_st_percentual decimal(18,6) null,
  quantidade_vendida_pis_st decimal(18,6) null,
  aliquota_pis_st_reais decimal(18,6) null,
  valor_pis_st decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_pis (id_nfe_detalhe asc),
  constraint fk_a901b4cbeecc4e0d8163e9c48092fbb30
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_icms_ufdest (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  valor_bc_icms_uf_destino decimal(18,6) null,
  valor_bc_fcp_uf_destino decimal(18,6) null,
  percentual_fcp_uf_destino decimal(18,6) null,
  aliquota_interna_uf_destino decimal(18,6) null,
  aliquota_interesdatual_uf_envolvidas decimal(18,6) null,
  percentual_provisorio_partilha_icms decimal(18,6) null,
  valor_icms_fcp_uf_destino decimal(18,6) null,
  valor_interestadual_uf_destino decimal(18,6) null,
  valor_interestadual_uf_remetente decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_icms (id_nfe_detalhe asc),
  constraint fk_2eca610c69b943e7b65df30edc701a590
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_detalhe_imposto_cofins_st (
  id int unsigned not null auto_increment,
  id_nfe_detalhe int unsigned not null,
  base_calculo_cofins_st decimal(18,6) null,
  aliquota_cofins_st_percentual decimal(18,6) null,
  quantidade_vendida_cofins_st decimal(18,6) null,
  aliquota_cofins_st_reais decimal(18,6) null,
  valor_cofins_st decimal(18,6) null,
  primary key (id),
  index fk_nfe_det_cofins (id_nfe_detalhe asc),
  constraint fk_45f41988b66741838517dd1800d747920
    foreign key (id_nfe_detalhe)
    references nfe_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfe_responsavel_tecnico (
  id int not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  contato varchar(60) null,
  email varchar(60) null,
  telefone varchar(14) null,
  identificador_csrt char(2) null,
  hash_csrt varchar(28) null,
  primary key (id),
  index fk_nfe_responsavel_tecnico_nfe_cabecalho1_idx (id_nfe_cabecalho asc),
  constraint fk_nfe_responsavel_tecnico_nfe_cabecalho1
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists cbo (
  id int not null auto_increment,
  codigo varchar(10) null,
  codigo_1994 varchar(10) null,
  nome varchar(250) null,
  observacao text null,
  primary key (id))
engine = innodb;
create table if not exists pais (
  id int not null auto_increment,
  codigo int null,
  nome_en varchar(100) null,
  nome_ptbr varchar(100) null,
  sigla2 char(2) null,
  sigla3 char(3) null,
  codigo_bacen int null,
  primary key (id))
engine = innodb;
create table if not exists tabela_preco_produto (
  id int unsigned not null auto_increment,
  id_tabela_preco int unsigned not null,
  id_produto int not null,
  preco decimal(18,6) null,
  primary key (id),
  index fk_tabela_preco (id_tabela_preco asc),
  index fk_tabela_preco_produto_produto1_idx (id_produto asc),
  constraint fk_1c28a5670398406b92434403c0e93099
    foreign key (id_tabela_preco)
    references tabela_preco (id)
    on delete no action
    on update no action,
  constraint fk_tabela_preco_produto_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ged_tipo_documento (
  id int unsigned not null auto_increment,
  nome varchar(100) null,
  tamanho_maximo decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ged_documento_cabecalho (
  id int unsigned not null auto_increment,
  nome varchar(100) null,
  descricao text null,
  data_inclusao date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ged_documento_detalhe (
  id int unsigned not null auto_increment,
  id_ged_documento_cabecalho int unsigned not null,
  id_ged_tipo_documento int unsigned not null,
  nome varchar(100) null,
  descricao text null,
  palavras_chave varchar(250) null,
  pode_excluir char(1) null,
  pode_alterar char(1) null,
  assinado char(1) null,
  data_fim_vigencia date null,
  data_exclusao date null,
  primary key (id),
  index fk_ged_tipo_documento (id_ged_tipo_documento asc),
  index fk_ged_documento_cab_det (id_ged_documento_cabecalho asc),
  constraint fk_57544f3181ac4880ab10168655128e85
    foreign key (id_ged_tipo_documento)
    references ged_tipo_documento (id)
    on delete no action
    on update no action,
  constraint fk_cf2c5e46a149422fb16ca9731c76f40b
    foreign key (id_ged_documento_cabecalho)
    references ged_documento_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ged_versao_documento (
  id int unsigned not null auto_increment,
  id_ged_documento_detalhe int unsigned not null,
  id_colaborador int not null,
  versao int unsigned null,
  data_versao date null,
  hora_versao varchar(8) null,
  hash_arquivo varchar(250) null,
  caminho varchar(250) null,
  acao char(1) null,
  primary key (id),
  index fk_ged_doc_versao_doc (id_ged_documento_detalhe asc),
  index fk_ged_versao_documento_colaborador1_idx (id_colaborador asc),
  constraint fk_b1b3e93f737d40439164ad1418b05011
    foreign key (id_ged_documento_detalhe)
    references ged_documento_detalhe (id)
    on delete no action
    on update no action,
  constraint fk_ged_versao_documento_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists os_status (
  id int unsigned not null auto_increment,
  codigo char(2) null,
  nome varchar(100) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists os_abertura (
  id int unsigned not null auto_increment,
  id_os_status int unsigned not null,
  id_cliente int not null,
  id_colaborador int not null,
  numero varchar(20) null,
  data_inicio date null,
  hora_inicio varchar(8) null,
  data_previsao date null,
  hora_previsao varchar(8) null,
  data_fim date null,
  hora_fim varchar(8) null,
  nome_contato varchar(50) null,
  fone_contato varchar(15) null,
  observacao_cliente text null,
  observacao_abertura text null,
  primary key (id),
  index fk_os_status_abertura (id_os_status asc),
  index fk_os_abertura_cliente1_idx (id_cliente asc),
  index fk_os_abertura_colaborador1_idx (id_colaborador asc),
  constraint fk_6bcae8d38ef545fd8a4538b20dff9fb0
    foreign key (id_os_status)
    references os_status (id)
    on delete no action
    on update no action,
  constraint fk_os_abertura_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action,
  constraint fk_os_abertura_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists os_equipamento (
  id int unsigned not null auto_increment,
  nome varchar(100) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists os_abertura_equipamento (
  id int unsigned not null,
  id_os_equipamento int unsigned not null,
  id_os_abertura int unsigned not null,
  numero_serie varchar(50) null,
  tipo_cobertura char(1) null,
  primary key (id),
  index fk_os_abert_equip (id_os_abertura asc),
  index fk_os_equip_abert (id_os_equipamento asc),
  constraint fk_810b527cfc0041789f830dce34f553a7
    foreign key (id_os_abertura)
    references os_abertura (id)
    on delete no action
    on update no action,
  constraint fk_22ca1568f45b42e9b8404c2fda5d9d90
    foreign key (id_os_equipamento)
    references os_equipamento (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists os_produto_servico (
  id int unsigned not null auto_increment,
  id_os_abertura int unsigned not null,
  id_produto int null,
  tipo char(1) null,
  complemento text null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_subtotal decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_total decimal(18,6) null,
  primary key (id),
  index fk_os_abert_prod_serv (id_os_abertura asc),
  index fk_os_produto_servico_produto1_idx (id_produto asc),
  constraint fk_1076f74ad81046a7bc95bc173a02f8e1
    foreign key (id_os_abertura)
    references os_abertura (id)
    on delete no action
    on update no action,
  constraint fk_os_produto_servico_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists os_evolucao (
  id int unsigned not null auto_increment,
  id_os_abertura int unsigned not null,
  data_registro date null,
  hora_registro varchar(8) null,
  observacao text null,
  enviar_email char(1) null,
  primary key (id),
  index os_evolucao_fkindex1 (id_os_abertura asc),
  constraint fk_6eff3578c97b4e128768f5d4247d08a9
    foreign key (id_os_abertura)
    references os_abertura (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists comissao_objetivo (
  id int unsigned not null auto_increment,
  id_comissao_perfil int unsigned not null,
  id_produto int not null,
  codigo char(3) null,
  nome varchar(100) null,
  descricao text null,
  forma_pagamento char(1) null,
  taxa_pagamento decimal(18,6) null,
  valor_pagamento decimal(18,6) null,
  valor_meta decimal(18,6) null,
  quantidade decimal(18,6) null,
  primary key (id),
  index fk_comissao_perfil_objetivo (id_comissao_perfil asc),
  index fk_comissao_objetivo_produto1_idx (id_produto asc),
  constraint fk_351ef9cb7f6d4edea2c3e35b9ef1f796
    foreign key (id_comissao_perfil)
    references comissao_perfil (id)
    on delete no action
    on update no action,
  constraint fk_comissao_objetivo_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists vendedor_rota (
  id int not null auto_increment,
  id_vendedor int not null,
  id_cliente int not null,
  posicao int null,
  primary key (id),
  index fk_vendedor_rota_vendedor1_idx (id_vendedor asc),
  index fk_vendedor_rota_cliente1_idx (id_cliente asc),
  constraint fk_vendedor_rota_vendedor1
    foreign key (id_vendedor)
    references vendedor (id)
    on delete no action
    on update no action,
  constraint fk_vendedor_rota_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists vendedor_meta (
  id int not null auto_increment,
  id_vendedor int not null,
  id_cliente int not null,
  periodo_meta char(1) null,
  meta_orcada decimal(18,6) null,
  meta_realizada decimal(18,6) null,
  data_inicio date null,
  data_fim date null,
  primary key (id),
  index fk_vendedor_meta_vendedor1_idx (id_vendedor asc),
  index fk_vendedor_meta_cliente1_idx (id_cliente asc),
  constraint fk_vendedor_meta_vendedor1
    foreign key (id_vendedor)
    references vendedor (id)
    on delete no action
    on update no action,
  constraint fk_vendedor_meta_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists nfce_sangria (
  id int unsigned not null auto_increment,
  id_nfce_movimento int unsigned not null,
  data_sangria date null,
  valor decimal(18,6) null,
  observacao text null,
  primary key (id),
  index fk_nfce_mov_sangria (id_nfce_movimento asc),
  constraint fk_2777ac82dfa34f0e9ee31f4ae5c53cf3
    foreign key (id_nfce_movimento)
    references nfce_movimento (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfce_tipo_pagamento (
  id int unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(20) null,
  permite_troco char(1) null,
  gera_parcelas char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists nfce_fechamento (
  id int unsigned not null auto_increment,
  id_nfce_movimento int unsigned not null,
  id_nfce_tipo_pagamento int unsigned not null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_nfce_mov_fecha (id_nfce_movimento asc),
  index fk_nfce_fechamento_nfce_tipo_pagamento1_idx (id_nfce_tipo_pagamento asc),
  constraint fk_7ee389ff4dbb42fe8ec650da93b8778e
    foreign key (id_nfce_movimento)
    references nfce_movimento (id)
    on delete no action
    on update no action,
  constraint fk_nfce_fechamento_nfce_tipo_pagamento1
    foreign key (id_nfce_tipo_pagamento)
    references nfce_tipo_pagamento (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists nfce_suprimento (
  id int unsigned not null auto_increment,
  id_nfce_movimento int unsigned not null,
  data_suprimento date null,
  valor decimal(18,6) null,
  observacao text null,
  primary key (id),
  index fk_nfce_mov_suprimento (id_nfce_movimento asc),
  constraint fk_2b61d0b458a249f5a893b0c551865c45
    foreign key (id_nfce_movimento)
    references nfce_movimento (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists nfse_lista_servico (
  id int unsigned not null auto_increment,
  codigo char(5) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists nfse_cabecalho (
  id int unsigned not null auto_increment,
  id_cliente int not null,
  id_os_abertura int unsigned null,
  numero varchar(15) null,
  codigo_verificacao varchar(9) null,
  data_hora_emissao timestamp null,
  competencia varchar(6) null,
  numero_substituida varchar(15) null,
  natureza_operacao char(1) null,
  regime_especial_tributacao char(1) null,
  optante_simples_nacional char(1) null,
  incentivador_cultural char(1) null,
  numero_rps varchar(15) null,
  serie_rps varchar(5) null,
  tipo_rps char(1) null,
  data_emissao_rps date null,
  outras_informacoes text null,
  primary key (id),
  index fk_nfse_cabecalho_os_abertura1_idx (id_os_abertura asc),
  index fk_nfse_cabecalho_cliente1_idx (id_cliente asc),
  constraint fk_nfse_cabecalho_os_abertura1
    foreign key (id_os_abertura)
    references os_abertura (id)
    on delete no action
    on update no action,
  constraint fk_nfse_cabecalho_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists nfse_detalhe (
  id int unsigned not null auto_increment,
  id_nfse_lista_servico int unsigned not null,
  id_nfse_cabecalho int unsigned not null,
  valor_servicos decimal(18,6) null,
  valor_deducoes decimal(18,6) null,
  valor_pis decimal(18,6) null,
  valor_cofins decimal(18,6) null,
  valor_inss decimal(18,6) null,
  valor_ir decimal(18,6) null,
  valor_csll decimal(18,6) null,
  codigo_cnae varchar(7) null,
  codigo_tributacao_municipio varchar(20) null,
  valor_base_calculo decimal(18,6) null,
  aliquota decimal(18,6) null,
  valor_iss decimal(18,6) null,
  valor_liquido decimal(18,6) null,
  outras_retencoes decimal(18,6) null,
  valor_credito decimal(18,6) null,
  iss_retido char(1) null,
  valor_iss_retido decimal(18,6) null,
  valor_desconto_condicionado decimal(18,6) null,
  valor_desconto_incondicionado decimal(18,6) null,
  discriminacao text null,
  municipio_prestacao int unsigned null,
  primary key (id),
  index fk_nfse_cab_det (id_nfse_cabecalho asc),
  index fk_lista_ser_det (id_nfse_lista_servico asc),
  constraint fk_a4d96b77686243de9d906ce7c219395a
    foreign key (id_nfse_cabecalho)
    references nfse_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_250949fca04f43dab79fe473f538aa92
    foreign key (id_nfse_lista_servico)
    references nfse_lista_servico (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists nfse_intermediario (
  id int unsigned not null auto_increment,
  id_nfse_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  razao varchar(150) null,
  inscricao_municipal varchar(15) null,
  primary key (id),
  index fk_nfse_intermediario (id_nfse_cabecalho asc),
  constraint fk_239e588f852e4b348b1585253428f291
    foreign key (id_nfse_cabecalho)
    references nfse_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_cabecalho (
  id int unsigned not null auto_increment,
  uf_emitente int unsigned null,
  codigo_numerico varchar(8) null,
  cfop int unsigned null,
  natureza_operacao varchar(60) null,
  forma_pagamento char(1) null,
  modelo char(2) null,
  serie char(3) null,
  numero varchar(9) null,
  data_hora_emissao timestamp null,
  formato_impressao_dacte char(1) null,
  tipo_emissao char(1) null,
  chave_acesso varchar(44) null,
  digito_chave_acesso char(1) null,
  ambiente char(1) null,
  tipo_cte char(1) null,
  processo_emissao char(1) null,
  versao_processo_emissao varchar(20) null,
  chave_referenciado varchar(44) null,
  codigo_municipio_envio int unsigned null,
  nome_municipio_envio varchar(60) null,
  uf_envio char(2) null,
  modal char(2) null,
  tipo_servico char(1) null,
  codigo_municipio_ini_prestacao int unsigned null,
  nome_municipio_ini_prestacao varchar(60) null,
  uf_ini_prestacao char(2) null,
  codigo_municipio_fim_prestacao int unsigned null,
  nome_municipio_fim_prestacao varchar(60) null,
  uf_fim_prestacao char(2) null,
  retira char(1) null,
  retira_detalhe varchar(160) null,
  tomador char(1) null,
  data_entrada_contingencia timestamp null,
  justificativa_contingencia varchar(255) null,
  carac_adicional_transporte varchar(15) null,
  carac_adicional_servico varchar(30) null,
  funcionario_emissor varchar(20) null,
  fluxo_origem varchar(15) null,
  entrega_tipo_periodo char(1) null,
  entrega_data_programada date null,
  entrega_data_inicial date null,
  entrega_data_final date null,
  entrega_tipo_hora char(1) null,
  entrega_hora_programada varchar(8) null,
  entrega_hora_inicial varchar(8) null,
  entrega_hora_final varchar(8) null,
  municipio_origem_calculo varchar(40) null,
  municipio_destino_calculo varchar(40) null,
  observacoes_gerais text null,
  valor_total_servico decimal(18,6) null,
  valor_receber decimal(18,6) null,
  cst char(2) null,
  base_calculo_icms decimal(18,6) null,
  aliquota_icms decimal(18,6) null,
  valor_icms decimal(18,6) null,
  percentual_reducao_bc_icms decimal(18,6) null,
  valor_bc_icms_st_retido decimal(18,6) null,
  valor_icms_st_retido decimal(18,6) null,
  aliquota_icms_st_retido decimal(18,6) null,
  valor_credito_presumido_icms decimal(18,6) null,
  percentual_bc_icms_outra_uf decimal(18,6) null,
  valor_bc_icms_outra_uf decimal(18,6) null,
  aliquota_icms_outra_uf decimal(18,6) null,
  valor_icms_outra_uf decimal(18,6) null,
  simples_nacional_indicador char(1) null,
  simples_nacional_total decimal(18,6) null,
  informacoes_add_fisco text null,
  valor_total_carga decimal(18,6) null,
  produto_predominante varchar(60) null,
  carga_outras_caracteristicas varchar(30) null,
  modal_versao_layout int unsigned null,
  chave_cte_substituido varchar(44) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists cte_emitente (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  ie varchar(14) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  logradouro varchar(60) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  telefone varchar(14) null,
  primary key (id),
  index fk_cte_cab_emitente (id_cte_cabecalho asc),
  constraint fk_8e0ea66cea894c1f8cf4778365c7ae3b
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_local_coleta (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  nome varchar(60) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  primary key (id),
  index fk_cte_cab_coleta (id_cte_cabecalho asc),
  constraint fk_bb10e3a135724882ade2b20451a6c58a
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_tomador (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  ie varchar(14) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  telefone varchar(14) null,
  logradouro varchar(255) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_tomador (id_cte_cabecalho asc),
  constraint fk_fb54edc5f9184617a82870539984bb46
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_passagem (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  sigla_passagem varchar(15) null,
  sigla_destino varchar(15) null,
  rota varchar(10) null,
  primary key (id),
  index fk_cte_cab_passagem (id_cte_cabecalho asc),
  constraint fk_08191dfbe0614102a06534c8e0503cda
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_remetente (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  ie varchar(20) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  telefone varchar(14) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_remetente (id_cte_cabecalho asc),
  constraint fk_44c5ae01875b414ab141210de88d5716
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_expedidor (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  ie varchar(20) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  telefone varchar(14) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_expedidor (id_cte_cabecalho asc),
  constraint fk_b49f680d20f54d89945bed7a99c5ebff
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_recebedor (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  ie varchar(20) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  telefone varchar(14) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_recebedor (id_cte_cabecalho asc),
  constraint fk_73407675aeac4ef480e53ef4401cf4d3
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_destinatario (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  ie varchar(20) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  telefone varchar(14) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_destinatario (id_cte_cabecalho asc),
  constraint fk_be7e7fc1411540c2ab9ea9b2b1b52d98
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_local_entrega (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  nome varchar(60) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  primary key (id),
  index fk_cte_cab_entrega (id_cte_cabecalho asc),
  constraint fk_754026b8770a45e5b53c385e92689a57
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_componente (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  nome varchar(15) null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_componente (id_cte_cabecalho asc),
  constraint fk_6a4b28da086847b1b13535b9ab1d1598
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_carga (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  codigo_unidade_medida char(2) null,
  tipo_medida varchar(20) null,
  quantidade decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_carga (id_cte_cabecalho asc),
  constraint fk_9b8a42cbe13a475f81fe5e7c48ed6e2f
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_informacao_nf_outros (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  numero_romaneio varchar(20) null,
  numero_pedido varchar(20) null,
  chave_acesso_nfe varchar(44) null,
  codigo_modelo char(2) null,
  serie char(3) null,
  numero varchar(20) null,
  data_emissao date null,
  uf_emitente int unsigned null,
  base_calculo_icms decimal(18,6) null,
  valor_icms decimal(18,6) null,
  base_calculo_icms_st decimal(18,6) null,
  valor_icms_st decimal(18,6) null,
  valor_total_produtos decimal(18,6) null,
  valor_total decimal(18,6) null,
  cfop_predominante int unsigned null,
  peso_total_kg decimal(18,6) null,
  pin_suframa int unsigned null,
  data_prevista_entrega date null,
  outro_tipo_doc_orig char(2) null,
  outro_descricao varchar(100) null,
  outro_valor_documento decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_informacao_nf (id_cte_cabecalho asc),
  constraint fk_9e6856b975694d16be2471bf8f64dc1e
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists cte_informacao_nf_transporte (
  id int unsigned not null auto_increment,
  id_cte_informacao_nf int unsigned not null,
  tipo_unidade_transporte char(1) null,
  id_unidade_transporte varchar(20) null,
  primary key (id),
  index fk_cte_inf_nf_transp (id_cte_informacao_nf asc),
  constraint fk_a8cc2c9b51124914aa89d8e0d2b6e646
    foreign key (id_cte_informacao_nf)
    references cte_informacao_nf_outros (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_inf_nf_transporte_lacre (
  id int unsigned not null,
  id_cte_informacao_nf_transporte int unsigned not null,
  numero varchar(20) null,
  primary key (id),
  index fk_cte_inf_nf_trans_lacre (id_cte_informacao_nf_transporte asc),
  constraint fk_95a360969355464ea5db22b8f81e9908
    foreign key (id_cte_informacao_nf_transporte)
    references cte_informacao_nf_transporte (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_informacao_nf_carga (
  id int unsigned not null auto_increment,
  id_cte_informacao_nf int unsigned not null,
  tipo_unidade_carga char(1) null,
  id_unidade_carga varchar(20) null,
  primary key (id),
  index fk_cte_inf_nf_carga (id_cte_informacao_nf asc),
  constraint fk_5db05f41b79749a1b003d7b4df8bf69c
    foreign key (id_cte_informacao_nf)
    references cte_informacao_nf_outros (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_inf_nf_carga_lacre (
  id int unsigned not null auto_increment,
  id_cte_informacao_nf_carga int unsigned not null,
  numero varchar(20) null,
  quantidade_rateada decimal(18,6) null,
  primary key (id),
  index fk_cte_inf_carga_lacre (id_cte_informacao_nf_carga asc),
  constraint fk_54ed8f7f282e4133b2ef771071f016ac
    foreign key (id_cte_informacao_nf_carga)
    references cte_informacao_nf_carga (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_documento_anterior (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  ie varchar(20) null,
  uf char(2) null,
  nome varchar(60) null,
  primary key (id),
  index fk_cte_cab_doc_anterior (id_cte_cabecalho asc),
  constraint fk_a53759a7d8444d7fa5efb72eacb5ed21
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_documento_anterior_id (
  id int unsigned not null auto_increment,
  id_cte_documento_anterior int unsigned not null,
  tipo char(2) null,
  serie char(3) null,
  subserie char(2) null,
  numero varchar(20) null,
  data_emissao date null,
  chave_cte varchar(44) null,
  primary key (id),
  index fk_cte_doc_anterior_id (id_cte_documento_anterior asc),
  constraint fk_9a75406f0c01483f8130100ddc289e23
    foreign key (id_cte_documento_anterior)
    references cte_documento_anterior (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_seguro (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  responsavel char(1) null,
  seguradora varchar(30) null,
  apolice varchar(20) null,
  averbacao varchar(20) null,
  valor_carga decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_seguro (id_cte_cabecalho asc),
  constraint fk_c775f390c7824417a7415f64688574c5
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_perigoso (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  numero_onu varchar(4) null,
  nome_apropriado varchar(150) null,
  classe_risco varchar(40) null,
  grupo_embalagem varchar(6) null,
  quantidade_total_produto varchar(20) null,
  quantidade_tipo_volume varchar(60) null,
  ponto_fulgor varchar(6) null,
  primary key (id),
  index fk_cte_cab_perigo (id_cte_cabecalho asc),
  constraint fk_b945a2926a0e4df983f2a595019696d1
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_veiculo_novo (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  chassi varchar(17) null,
  cor varchar(4) null,
  descricao_cor varchar(40) null,
  codigo_marca_modelo varchar(6) null,
  valor_unitario decimal(18,6) null,
  valor_frete decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_veiculo_novo (id_cte_cabecalho asc),
  constraint fk_7276ae5be77e49f1b481fa55d8680c6d
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists cte_fatura (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  numero varchar(60) null,
  valor_original decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_liquido decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_fatura (id_cte_cabecalho asc),
  constraint fk_6438723e81db4412abec40020aae5df6
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists cte_duplicata (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  numero varchar(60) null,
  data_vencimento date null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_duplicata (id_cte_cabecalho asc),
  constraint fk_59427324f43f494cb7072c3544786351
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists cte_rodoviario (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  rntrc varchar(8) null,
  data_prevista_entrega date null,
  indicador_lotacao char(1) null,
  ciot int unsigned null,
  primary key (id),
  index fk_cte_cab_rodoviario (id_cte_cabecalho asc),
  constraint fk_f52500440cc74629afffd28b8fda5ea1
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_rodoviario_occ (
  id int unsigned not null auto_increment,
  id_cte_rodoviario int unsigned not null,
  serie char(3) null,
  numero int unsigned null,
  data_emissao date null,
  cnpj varchar(14) null,
  codigo_interno varchar(10) null,
  ie varchar(14) null,
  uf char(2) null,
  telefone varchar(14) null,
  primary key (id),
  index fk_cte_rod_occ (id_cte_rodoviario asc),
  constraint fk_dd4f9e16bfdd4934a6a0afad56955e2a
    foreign key (id_cte_rodoviario)
    references cte_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_rodoviario_pedagio (
  id int unsigned not null auto_increment,
  id_cte_rodoviario int unsigned not null,
  cnpj_fornecedor varchar(14) null,
  comprovante_compra varchar(20) null,
  cnpj_responsavel varchar(14) null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_cte_rod_pedagio (id_cte_rodoviario asc),
  constraint fk_1dd174077e794dc1b8ec40d707a49a50
    foreign key (id_cte_rodoviario)
    references cte_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_rodoviario_veiculo (
  id int unsigned not null auto_increment,
  id_cte_rodoviario int unsigned not null,
  codigo_interno varchar(10) null,
  renavam varchar(11) null,
  placa varchar(7) null,
  tara int unsigned null,
  capacidade_kg int unsigned null,
  capacidade_m3 int unsigned null,
  tipo_propriedade char(1) null,
  tipo_veiculo char(1) null,
  tipo_rodado char(2) null,
  tipo_carroceria char(2) null,
  uf char(2) null,
  proprietario_cpf varchar(11) null,
  proprietario_cnpj varchar(14) null,
  proprietario_rntrc varchar(8) null,
  proprietario_nome varchar(60) null,
  proprietario_ie varchar(14) null,
  proprietario_uf char(2) null,
  proprietario_tipo char(1) null,
  primary key (id),
  index fk_cte_rod_veiculo (id_cte_rodoviario asc),
  constraint fk_8f53c9c02dbd48339a6f65464db09c72
    foreign key (id_cte_rodoviario)
    references cte_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_rodoviario_lacre (
  id int unsigned not null auto_increment,
  id_cte_rodoviario int unsigned not null,
  numero varchar(20) null,
  primary key (id),
  index fk_cte_rod_lacre (id_cte_rodoviario asc),
  constraint fk_004ee9fa69414146834d227a24bad2a6
    foreign key (id_cte_rodoviario)
    references cte_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_rodoviario_motorista (
  id int unsigned not null auto_increment,
  id_cte_rodoviario int unsigned not null,
  nome varchar(60) null,
  cpf varchar(11) null,
  primary key (id),
  index fk_cte_rod_motorista (id_cte_rodoviario asc),
  constraint fk_c8eba555faa44b1ebbd66544e2bc65b6
    foreign key (id_cte_rodoviario)
    references cte_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_aereo (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  numero_minuta int unsigned null,
  numero_conhecimento int unsigned null,
  data_prevista_entrega date null,
  id_emissor varchar(20) null,
  id_interna_tomador varchar(14) null,
  tarifa_classe char(1) null,
  tarifa_codigo varchar(4) null,
  tarifa_valor decimal(18,6) null,
  carga_dimensao varchar(14) null,
  carga_informacao_manuseio char(1) null,
  carga_especial char(3) null,
  primary key (id),
  index fk_cte_cab_aereo (id_cte_cabecalho asc),
  constraint fk_582ed5632b8f4348977794fa1657e73d
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_aquaviario (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  valor_prestacao decimal(18,6) null,
  afrmm decimal(18,6) null,
  numero_booking varchar(10) null,
  numero_controle varchar(10) null,
  id_navio varchar(60) null,
  primary key (id),
  index fk_cte_cab_aquaviario (id_cte_cabecalho asc),
  constraint fk_edb7a03701b141c0935c32998709a4ca
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_aquaviario_balsa (
  id int unsigned not null auto_increment,
  id_cte_aquaviario int unsigned not null,
  id_balsa varchar(60) null,
  numero_viagem int unsigned null,
  direcao char(1) null,
  porto_embarque varchar(60) null,
  porto_transbordo varchar(60) null,
  porto_destino varchar(60) null,
  tipo_navegacao char(1) null,
  irin varchar(10) null,
  primary key (id),
  index fk_cte_aqua_balsa (id_cte_aquaviario asc),
  constraint fk_c55a2fc7979f4114a228699effdff750
    foreign key (id_cte_aquaviario)
    references cte_aquaviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_ferroviario (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  tipo_trafego char(1) null,
  responsavel_faturamento char(1) null,
  ferrovia_emitente_cte char(1) null,
  fluxo varchar(10) null,
  id_trem varchar(7) null,
  valor_frete decimal(18,6) null,
  primary key (id),
  index fk_cte_cab_ferroviario (id_cte_cabecalho asc),
  constraint fk_9633509ad7f9476bb37e8210a6404789
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_ferroviario_ferrovia (
  id int unsigned not null auto_increment,
  id_cte_ferroviario int unsigned not null,
  cnpj varchar(14) null,
  codigo_interno varchar(10) null,
  ie varchar(20) null,
  nome varchar(60) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  primary key (id),
  index fk_cte_ferro_via (id_cte_ferroviario asc),
  constraint fk_ab21b268a4c748c0ab5787a4561fc4f2
    foreign key (id_cte_ferroviario)
    references cte_ferroviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_ferroviario_vagao (
  id int unsigned not null,
  id_cte_ferroviario int unsigned not null,
  numero_vagao int unsigned null,
  capacidade decimal(18,6) null,
  tipo_vagao char(3) null,
  peso_real decimal(18,6) null,
  peso_bc decimal(18,6) null,
  primary key (id),
  index fk_cte_ferro_vagao (id_cte_ferroviario asc),
  constraint fk_3913f060202c40f786965c45bd7ed67a
    foreign key (id_cte_ferroviario)
    references cte_ferroviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_dutoviario (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  valor_tarifa decimal(18,6) null,
  data_inicio date null,
  data_fim date null,
  primary key (id),
  index fk_cte_cab_duto (id_cte_cabecalho asc),
  constraint fk_9fee0e93ddb54b3fada68301e12f3cd9
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists cte_multimodal (
  id int unsigned not null auto_increment,
  id_cte_cabecalho int unsigned not null,
  cotm varchar(20) null,
  indicador_negociavel char(1) null,
  primary key (id),
  index fk_cte_cab_multi (id_cte_cabecalho asc),
  constraint fk_d4d31624133a4e999505eff8aa9ee66c
    foreign key (id_cte_cabecalho)
    references cte_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists operadora_cartao (
  id int(11) unsigned not null auto_increment,
  id_banco_conta_caixa int not null,
  bandeira varchar(30) null,
  nome varchar(50) null,
  taxa_adm decimal(18,6) null,
  taxa_adm_debito decimal(18,6) null,
  valor_aluguel_pos_pin decimal(18,6) null,
  vencimento_aluguel int(11) unsigned null,
  fone1 varchar(14) null,
  fone2 varchar(14) null,
  classificacao_contabil_conta varchar(30) null,
  primary key (id),
  index fk_operadora_cartao_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_operadora_cartao_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tipo_relacionamento (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists colaborador_relacionamento (
  id int(11) unsigned not null auto_increment,
  id_tipo_relacionamento int(11) unsigned not null,
  id_colaborador int not null,
  nome varchar(100) null,
  data_nascimento date null,
  cpf varchar(11) null,
  registro_matricula varchar(50) null,
  registro_cartorio varchar(50) null,
  registro_cartorio_numero varchar(50) null,
  registro_numero_livro varchar(10) null,
  registro_numero_folha varchar(10) null,
  data_entrega_documento date null,
  salario_familia char(1) null,
  salario_familia_idade_limite int(11) unsigned null,
  salario_familia_data_fim date null,
  imposto_renda_idade_limite int(11) unsigned null,
  imposto_renda_data_fim int(11) unsigned null,
  primary key (id),
  index fk_tipo_rel_colaborador (id_tipo_relacionamento asc),
  index fk_colaborador_relacionamento_colaborador1_idx (id_colaborador asc),
  constraint fk_195aeaa025cf41cbb13f5aaa18580ac8
    foreign key (id_tipo_relacionamento)
    references tipo_relacionamento (id)
    on delete no action
    on update no action,
  constraint fk_colaborador_relacionamento_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fornecedor_produto (
  id int(11) unsigned not null auto_increment,
  id_produto int not null,
  id_fornecedor int not null,
  codigo_fornecedor_produto varchar(20) null,
  data_ultima_compra date null,
  preco_ultima_compra decimal(18,6) null,
  lote_minimo_compra decimal(18,6) null,
  menor_embalagem_compra decimal(18,6) null,
  custo_ultima_compra decimal(18,6) null,
  primary key (id),
  index fk_fornecedor_produto_produto1_idx (id_produto asc),
  index fk_fornecedor_produto_fornecedor1_idx (id_fornecedor asc),
  constraint fk_fornecedor_produto_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action,
  constraint fk_fornecedor_produto_fornecedor1
    foreign key (id_fornecedor)
    references fornecedor (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists aidf_aimdf (
  id int(11) unsigned not null auto_increment,
  numero int(11) unsigned null,
  data_validade date null,
  data_autorizacao date null,
  numero_autorizacao varchar(20) null,
  formulario_disponivel char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists produto_promocao (
  id int(11) unsigned not null auto_increment,
  id_produto int not null,
  data_inicio date null,
  data_fim date null,
  quantidade_em_promocao decimal(18,6) null,
  quantidade_maxima_cliente decimal(18,6) null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_produto_promocao_produto1_idx (id_produto asc),
  constraint fk_produto_promocao_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists produto_ficha_tecnica (
  id int(11) unsigned not null auto_increment,
  id_produto int not null,
  descricao varchar(100) null,
  id_produto_filho int(11) unsigned null,
  quantidade decimal(18,6) null,
  sequencia_producao int(11) unsigned null,
  primary key (id),
  index fk_produto_ficha_tecnica_produto1_idx (id_produto asc),
  constraint fk_produto_ficha_tecnica_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tipo_item_sped (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists produto_codigo_adicional (
  id int(11) unsigned not null auto_increment,
  id_produto int not null,
  codigo varchar(14) null,
  primary key (id),
  index fk_produto_codigo_adicional_produto1_idx (id_produto asc),
  constraint fk_produto_codigo_adicional_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists almoxarifado (
  id int(11) unsigned not null auto_increment,
  nome varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists operadora_plano_saude (
  id int(11) unsigned not null auto_increment,
  registro_ans varchar(20) null,
  nome varchar(100) null,
  classificacao_contabil_conta varchar(30) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists irrf (
  id int(11) unsigned not null auto_increment,
  competencia varchar(7) null,
  desconto_por_dependente decimal(18,6) null,
  minimo_para_retencao decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists irrf_detalhe (
  id int(11) unsigned not null auto_increment,
  id_irrf int(11) unsigned not null,
  faixa int(11) unsigned null,
  de decimal(18,6) null,
  ate decimal(18,6) null,
  taxa decimal(18,6) null,
  desconto decimal(18,6) null,
  primary key (id),
  index fk_irrf_detalhe (id_irrf asc),
  constraint fk_5c43c7898dd440e6bedc2ef8f4646e21
    foreign key (id_irrf)
    references irrf (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists inss (
  id int(11) unsigned not null auto_increment,
  competencia varchar(7) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists inss_detalhe (
  id int(11) unsigned not null auto_increment,
  id_inss int(11) unsigned not null,
  faixa int(11) unsigned null,
  de decimal(18,6) null,
  ate decimal(18,6) null,
  taxa decimal(18,6) null,
  primary key (id),
  index fk_inss_detalhe (id_inss asc),
  constraint fk_460758bf536f4b1db83cd7d676cca7fd
    foreign key (id_inss)
    references inss (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists salario_familia (
  id int(11) unsigned not null auto_increment,
  id_inss int(11) unsigned not null,
  faixa int(11) unsigned null,
  de decimal(18,6) null,
  ate decimal(18,6) null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_inss_salario_familia (id_inss asc),
  constraint fk_460a3e57743b45d3bc2f89c6779eb22a
    foreign key (id_inss)
    references inss (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists salario_minimo (
  id int(11) unsigned not null auto_increment,
  vigencia date null,
  valor_mensal decimal(18,6) null,
  valor_diario decimal(18,6) null,
  valor_hora decimal(18,6) null,
  norma_legal varchar(100) null,
  dou date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contrib_sind_patronal_cab (
  id int(11) unsigned not null auto_increment,
  id_sindicato int(11) unsigned not null,
  vigencia_ano char(4) null,
  primary key (id),
  index fk_sind_patro_contr (id_sindicato asc),
  constraint fk_3b251eb4f2604a838c67bfcf190aec38
    foreign key (id_sindicato)
    references sindicato (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contrib_sind_patronal_det (
  id int(11) unsigned not null auto_increment,
  id_contrib_sind_patronal_cab int(11) unsigned not null,
  de decimal(18,6) null,
  ate decimal(18,6) null,
  percentual decimal(18,6) null,
  valor_adicionar decimal(18,6) null,
  primary key (id),
  index fk_contr_sind_patronal (id_contrib_sind_patronal_cab asc),
  constraint fk_107bd546819b41b2b009646739bd5837
    foreign key (id_contrib_sind_patronal_cab)
    references contrib_sind_patronal_cab (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists empresa_transporte (
  id int(11) unsigned not null auto_increment,
  uf char(2) null,
  nome varchar(100) null,
  classificacao_contabil_conta varchar(30) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists empresa_transporte_itinerario (
  id int(11) unsigned not null auto_increment,
  id_empresa_transporte int(11) unsigned not null,
  nome varchar(100) null,
  tarifa decimal(18,6) null,
  trajeto text null,
  primary key (id),
  index fk_emp_trans_itiner (id_empresa_transporte asc),
  constraint fk_8fe3d483e7d94361b2e8464f7d802a73
    foreign key (id_empresa_transporte)
    references empresa_transporte (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists pdv_caixa (
  id int(11) unsigned not null auto_increment,
  nome varchar(30) null,
  data_cadastro date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_impressora (
  id int(11) unsigned not null auto_increment,
  numero int(11) unsigned null,
  codigo varchar(10) null,
  serie varchar(25) null,
  identificacao varchar(250) null,
  mc char(2) null,
  md char(2) null,
  vr char(2) null,
  tipo varchar(7) null,
  marca varchar(30) null,
  modelo varchar(30) null,
  modelo_acbr varchar(30) null,
  modelo_documento_fiscal char(2) null,
  versao varchar(30) null,
  le char(1) null,
  lef char(1) null,
  mfd char(1) null,
  lacre_na_mfd char(1) null,
  data_instalacao_sb date null,
  hora_instalacao_sb varchar(8) null,
  docto varchar(60) null,
  ecf_impressora varchar(3) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_tipo_pagamento (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  descricao varchar(20) null,
  tef char(1) null,
  imprime_vinculado char(1) null,
  permite_troco char(1) null,
  tef_tipo_gp char(1) null,
  gera_parcelas char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_movimento (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_ecf_impressora int(11) unsigned null,
  id_pdv_operador int(11) unsigned null,
  id_pdv_caixa int(11) unsigned null,
  id_gerente_supervisor int(11) unsigned not null,
  data_abertura date null,
  hora_abertura varchar(8) null,
  data_fechamento date null,
  hora_fechamento varchar(8) null,
  total_suprimento decimal(18,6) null,
  total_sangria decimal(18,6) null,
  total_nao_fiscal decimal(18,6) null,
  total_venda decimal(18,6) null,
  total_desconto decimal(18,6) null,
  total_acrescimo decimal(18,6) null,
  total_final decimal(18,6) null,
  total_recebido decimal(18,6) null,
  total_troco decimal(18,6) null,
  total_cancelado decimal(18,6) null,
  status_movimento char(1) not null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_venda_cabecalho (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_cliente int(11) unsigned null,
  id_pdv_funcionario int(11) unsigned null,
  id_pdv_movimento int(11) unsigned null,
  id_ecf_dav int(11) unsigned null,
  id_ecf_pre_venda_cabecalho int(11) unsigned null,
  serie_ecf varchar(20) null,
  cfop int(11) unsigned null,
  coo int(11) unsigned null,
  ccf int(11) unsigned null,
  data_venda date null,
  hora_venda varchar(8) null,
  valor_venda decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  desconto decimal(18,6) null,
  taxa_acrescimo decimal(18,6) null,
  acrescimo decimal(18,6) null,
  valor_final decimal(18,6) null,
  valor_recebido decimal(18,6) null,
  troco decimal(18,6) null,
  valor_cancelado decimal(18,6) null,
  total_produtos decimal(18,6) null,
  total_documento decimal(18,6) null,
  base_icms decimal(18,6) null,
  icms decimal(18,6) null,
  icms_outras decimal(18,6) null,
  issqn decimal(18,6) null,
  pis decimal(18,6) null,
  cofins decimal(18,6) null,
  acrescimo_itens decimal(18,6) null,
  desconto_itens decimal(18,6) null,
  status_venda char(1) null,
  nome_cliente varchar(100) null,
  cpf_cnpj_cliente varchar(14) null,
  cupom_cancelado char(1) null,
  hash_registro varchar(32) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_venda_detalhe (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_produto int(11) unsigned null,
  id_pdv_venda_cabecalho int(11) unsigned null,
  cfop int(11) unsigned null,
  gtin varchar(14) null,
  ccf int(11) unsigned null,
  coo int(11) unsigned null,
  serie_ecf varchar(20) null,
  item int(11) unsigned null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_total decimal(18,6) null,
  total_item decimal(18,6) null,
  base_icms decimal(18,6) null,
  taxa_icms decimal(18,6) null,
  icms decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  desconto decimal(18,6) null,
  taxa_issqn decimal(18,6) null,
  issqn decimal(18,6) null,
  taxa_pis decimal(18,6) null,
  pis decimal(18,6) null,
  taxa_cofins decimal(18,6) null,
  cofins decimal(18,6) null,
  taxa_acrescimo decimal(18,6) null,
  acrescimo decimal(18,6) null,
  acrescimo_rateio decimal(18,6) null,
  desconto_rateio decimal(18,6) null,
  totalizador_parcial varchar(10) null,
  cst char(3) null,
  cancelado char(1) null,
  movimenta_estoque char(1) null,
  ecf_icms_st varchar(4) null,
  hash_registro varchar(32) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_total_tipo_pagamento (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_venda_cabecalho int(11) unsigned null,
  id_pdv_tipo_pagamento int(11) unsigned null,
  serie_ecf varchar(20) null,
  coo int(11) unsigned null,
  ccf int(11) unsigned null,
  gnf int(11) unsigned null,
  valor decimal(18,6) null,
  nsu varchar(30) null,
  estorno char(1) null,
  rede varchar(10) null,
  cartao_dc char(1) null,
  data_venda date null,
  hash_registro varchar(32) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_configuracao (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_ecf_impressora int(11) unsigned null,
  id_pdv_caixa int(11) unsigned null,
  mensagem_cupom varchar(250) null,
  porta_ecf char(10) null,
  ip_servidor varchar(15) null,
  ip_sitef varchar(15) null,
  tipo_tef char(2) null,
  titulo_tela_caixa varchar(100) null,
  caminho_imagens_produtos varchar(250) null,
  caminho_imagens_marketing varchar(250) null,
  cor_janelas_internas varchar(20) null,
  marketing_ativo char(1) null,
  cfop_ecf int(11) unsigned null,
  timeout_ecf int(11) unsigned null,
  intervalo_ecf int(11) unsigned null,
  descricao_suprimento varchar(20) null,
  descricao_sangria varchar(20) null,
  tef_tipo_gp int(11) unsigned null,
  tef_tempo_espera int(11) unsigned null,
  tef_espera_sts int(11) unsigned null,
  tef_numero_vias int(11) unsigned null,
  decimais_quantidade int(11) unsigned null,
  decimais_valor int(11) unsigned null,
  bits_por_segundo int(11) unsigned null,
  qtde_maxima_cartoes int(11) unsigned null,
  pesquisa_parte char(1) null,
  configuracao_balanca varchar(100) null,
  parametros_diversos varchar(250) null,
  ultima_exclusao int(11) unsigned null,
  laudo varchar(10) null,
  indice_gerencial varchar(100) null,
  data_atualizacao_estoque date null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_documentos_emitidos (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_movimento int(11) unsigned null,
  data_emissao date null,
  hora_emissao varchar(8) null,
  tipo char(2) null,
  coo int(11) unsigned null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_fechamento (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_movimento int(11) unsigned null,
  tipo_pagamento varchar(20) null,
  valor decimal(18,6) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists ecf_recebimento_nao_fiscal (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_movimento int(11) unsigned null,
  data_recebimento date null,
  descricao varchar(50) null,
  valor decimal(18,6) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pdv_suprimento (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_movimento int(11) unsigned null,
  data_suprimento date null,
  valor decimal(18,6) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_r02 (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_operador int(11) unsigned not null,
  id_ecf_impressora int(11) unsigned not null,
  id_pdv_caixa int(11) unsigned null,
  serie_ecf varchar(20) null,
  crz int(11) unsigned null,
  coo int(11) null,
  cro int(11) unsigned null,
  data_movimento date null,
  data_emissao date null,
  hora_emissao varchar(8) null,
  venda_bruta decimal(18,6) null,
  grande_total decimal(18,6) null,
  hash_registro varchar(32) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_r03 (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_ecf_r02 int(11) unsigned null,
  serie_ecf varchar(20) null,
  totalizador_parcial varchar(10) null,
  valor_acumulado decimal(18,6) null,
  crz int(11) unsigned null,
  hash_registro varchar(32) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_r06 (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_operador int(11) unsigned not null,
  id_ecf_impressora int(11) unsigned not null,
  id_pdv_caixa int(11) unsigned null,
  serie_ecf varchar(20) null,
  coo int(11) unsigned null,
  gnf int(11) unsigned null,
  grg int(11) unsigned null,
  cdc int(11) unsigned null,
  denominacao char(2) null,
  data_emissao date null,
  hora_emissao varchar(8) null,
  hash_registro varchar(32) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_r07 (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(8) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_ecf_r06 int(11) unsigned null,
  ccf int(11) unsigned null,
  meio_pagamento varchar(20) null,
  valor_pagamento decimal(18,6) null,
  estorno char(1) null,
  valor_estorno decimal(18,6) null,
  hash_registro varchar(32) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists sefip_codigo_recolhimento (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao text null,
  aplicacao text null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists sefip_categoria_trabalho (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  nome text null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists sefip_codigo_movimentacao (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  descricao text null,
  aplicacao text null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists fpas (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  cnae varchar(14) null,
  aliquota_sat decimal null,
  descricao varchar(250) null,
  percentual_inss_patronal decimal(18,6) null,
  codigo_terceiro char(4) null,
  percentual_terceiros decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists codigo_gps (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao varchar(250) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists fap (
  id int(11) unsigned not null auto_increment,
  fap decimal(18,6) null,
  data_inicial date null,
  data_final date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists tipo_receita_dacon (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao varchar(50) null,
  observacao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_435 (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(100) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists cod_apuracao_receita_dacon (
  id int(11) unsigned not null auto_increment,
  id_codigo_apuracao_efd int(11) unsigned not null,
  id_tipo_receita_dacon int(11) unsigned not null,
  primary key (id),
  index fk_tipo_rec_dacon (id_tipo_receita_dacon asc),
  index fk_cod_apura_dacon (id_codigo_apuracao_efd asc),
  constraint fk_871bbbad37b745239ff57ddc7049997c
    foreign key (id_tipo_receita_dacon)
    references tipo_receita_dacon (id)
    on delete no action
    on update no action,
  constraint fk_a797b44b92e24edfa83152ee511664f6
    foreign key (id_codigo_apuracao_efd)
    references efd_tabela_435 (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tipo_receita_dipi (
  id int(11) unsigned not null auto_increment,
  descricao varchar(100) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists orcamento_fluxo_caixa_periodo (
  id int(11) unsigned not null auto_increment,
  id_banco_conta_caixa int not null,
  periodo char(2) null,
  nome varchar(30) null,
  primary key (id),
  index fk_orcamento_fluxo_caixa_periodo_banco_conta_caixa1_idx (id_banco_conta_caixa asc),
  constraint fk_orcamento_fluxo_caixa_periodo_banco_conta_caixa1
    foreign key (id_banco_conta_caixa)
    references banco_conta_caixa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists orcamento_fluxo_caixa (
  id int(11) unsigned not null auto_increment,
  id_orc_fluxo_caixa_periodo int(11) unsigned not null,
  nome varchar(30) null,
  descricao text null,
  data_inicial date null,
  numero_periodos int(11) unsigned null,
  data_base date null,
  primary key (id),
  index fk_fluxo_cx_periodo (id_orc_fluxo_caixa_periodo asc),
  constraint fk_dae02892954d49c195ad159e01e5b882
    foreign key (id_orc_fluxo_caixa_periodo)
    references orcamento_fluxo_caixa_periodo (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists orcamento_fluxo_caixa_detalhe (
  id int(11) unsigned not null auto_increment,
  id_orcamento_fluxo_caixa int(11) unsigned not null,
  id_fin_natureza_financeira int unsigned not null,
  periodo varchar(10) null,
  valor_orcado decimal(18,6) null,
  valor_realizado decimal(18,6) null,
  taxa_variacao decimal(18,6) null,
  valor_variacao decimal(18,6) null,
  primary key (id),
  index fk_fluxo_caixa_detalhe (id_orcamento_fluxo_caixa asc),
  index fk_orcamento_fluxo_caixa_detalhe_fin_natureza_financeira1_idx (id_fin_natureza_financeira asc),
  constraint fk_7da41a8e71ff4158a2f6284efd0c66c0
    foreign key (id_orcamento_fluxo_caixa)
    references orcamento_fluxo_caixa (id)
    on delete no action
    on update no action,
  constraint fk_orcamento_fluxo_caixa_detalhe_fin_natureza_financeira1
    foreign key (id_fin_natureza_financeira)
    references fin_natureza_financeira (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists registro_cartorio (
  id int(11) unsigned not null auto_increment,
  nome_cartorio varchar(100) null,
  data_registro date null,
  numero int(11) unsigned null,
  folha int(11) unsigned null,
  livro int(11) unsigned null,
  nire varchar(11) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_parametro (
  id int(11) unsigned not null auto_increment,
  mascara varchar(30) null,
  niveis int(11) unsigned zerofill null,
  informar_conta_por char(1) null,
  compartilha_plano_conta char(1) null,
  compartilha_historicos char(1) null,
  altera_lancamento_outro char(1) null,
  historico_obrigatorio char(1) null,
  permite_lancamento_zerado char(1) null,
  gera_informativo_sped char(1) null,
  sped_forma_escrit_diario char(3) null,
  sped_nome_livro_diario varchar(100) null,
  assinatura_direita text null,
  assinatura_esquerda text null,
  conta_ativo varchar(30) null,
  conta_passivo varchar(30) null,
  conta_patrimonio_liquido varchar(30) null,
  conta_depreciacao_acumulada varchar(30) null,
  conta_capital_social varchar(30) null,
  conta_resultado_exercicio varchar(30) null,
  conta_prejuizo_acumulado varchar(30) null,
  conta_lucro_acumulado varchar(30) null,
  conta_titulo_pagar varchar(30) null,
  conta_titulo_receber varchar(30) null,
  conta_juros_passivo varchar(30) null,
  conta_juros_ativo varchar(30) null,
  conta_desconto_obtido varchar(30) null,
  conta_desconto_concedido varchar(30) null,
  conta_cmv varchar(30) null,
  conta_venda varchar(30) null,
  conta_venda_servico varchar(30) null,
  conta_estoque varchar(30) null,
  conta_apura_resultado varchar(30) null,
  conta_juros_apropriar varchar(30) null,
  id_hist_padrao_resultado int(11) unsigned zerofill null,
  id_hist_padrao_lucro int(11) unsigned zerofill null,
  id_hist_padrao_prejuizo int(11) unsigned zerofill null,
  primary key (id)) 
 engine = innodb; 
create table if not exists plano_conta_ref_sped (
  id int(11) unsigned not null auto_increment,
  cod_cta_ref varchar(30) null,
  descricao text null,
  orientacoes text null,
  inicio_validade date null,
  fim_validade date null,
  tipo char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists plano_conta (
  id int(11) unsigned not null auto_increment,
  nome varchar(100) null,
  data_inclusao date null,
  mascara varchar(50) null,
  niveis int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_conta (
  id int(11) unsigned not null auto_increment,
  id_plano_conta int(11) unsigned not null,
  id_contabil_conta int(11) unsigned null,
  id_plano_conta_ref_sped int(11) unsigned not null,
  classificacao varchar(30) null,
  tipo char(1) null,
  descricao varchar(100) null,
  data_inclusao date null,
  situacao char(1) null,
  natureza char(1) null,
  patrimonio_resultado char(1) null,
  livro_caixa char(1) null,
  dfc char(1) null,
  ordem varchar(20) null,
  codigo_reduzido varchar(10) null,
  codigo_efd char(2) null,
  primary key (id),
  index fk_conta_sped_conta (id_plano_conta_ref_sped asc),
  index fk_contabil_conta_conta (id_contabil_conta asc),
  index fk_plano_conta_conta (id_plano_conta asc),
  constraint fk_b91bdb7e3c8947f2b87fef076c65c6f9
    foreign key (id_plano_conta_ref_sped)
    references plano_conta_ref_sped (id)
    on delete no action
    on update no action,
  constraint fk_1a1b29a397fa4561bcc198667b3c27b1
    foreign key (id_contabil_conta)
    references contabil_conta (id)
    on delete no action
    on update no action,
  constraint fk_115d906caff4472ab6754f4ff01593d7
    foreign key (id_plano_conta)
    references plano_conta (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_historico (
  id int(11) unsigned not null auto_increment,
  descricao varchar(100) null,
  historico varchar(250) null,
  pede_complemento char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_lancamento_padrao (
  id int(11) unsigned not null auto_increment,
  descricao varchar(100) null,
  historico varchar(250) null,
  id_conta_debito int(11) unsigned null,
  id_conta_credito int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_lote (
  id int(11) unsigned not null auto_increment,
  descricao varchar(100) null,
  liberado char(1) null,
  data_inclusao date null,
  data_liberacao date null,
  programado char(1) null,
  valor decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_lancamento_cabecalho (
  id int(11) unsigned not null auto_increment,
  id_contabil_lote int(11) unsigned null,
  data_lancamento date null,
  data_inclusao date null,
  tipo char(4) null,
  liberado char(1) null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_lote_lanc_cab (id_contabil_lote asc),
  constraint fk_792712e2e225495da777e44de2565be7
    foreign key (id_contabil_lote)
    references contabil_lote (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_lancamento_detalhe (
  id int(11) unsigned not null auto_increment,
  id_contabil_conta int(11) unsigned not null,
  id_contabil_historico int(11) unsigned null,
  id_contabil_lancamento_cab int(11) unsigned not null,
  historico varchar(250) null,
  valor decimal(18,6) null,
  tipo char(1) null,
  primary key (id),
  index fk_contabil_lancamento (id_contabil_lancamento_cab asc),
  index fk_hist_lancamento (id_contabil_historico asc),
  index fk_conta_lancamento (id_contabil_conta asc),
  constraint fk_91277fe70bbc47d5af997477da2cde13
    foreign key (id_contabil_lancamento_cab)
    references contabil_lancamento_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_105193a2fc4d4b16a6ad6c6c337d8ff7
    foreign key (id_contabil_historico)
    references contabil_historico (id)
    on delete no action
    on update no action,
  constraint fk_e1cb81973d7d44a682f6c882ba9faa40
    foreign key (id_contabil_conta)
    references contabil_conta (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_lancamento_orcado (
  id int(11) unsigned not null auto_increment,
  id_contabil_conta int(11) unsigned not null,
  ano char(4) null,
  janeiro decimal(18,6) null,
  fevereiro decimal(18,6) null,
  marco decimal(18,6) null,
  abril decimal(18,6) null,
  maio decimal(18,6) null,
  junho decimal(18,6) null,
  julho decimal(18,6) null,
  agosto decimal(18,6) null,
  setembro decimal(18,6) null,
  outubro decimal(18,6) null,
  novembro decimal(18,6) null,
  dezembro decimal(18,6) null,
  primary key (id),
  index fk_conta_lanc_orcado (id_contabil_conta asc),
  constraint fk_9821838a951448e9838517a587d1a2c1
    foreign key (id_contabil_conta)
    references contabil_conta (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_dre_cabecalho (
  id int(11) unsigned not null auto_increment,
  descricao varchar(100) null,
  padrao char(1) null,
  periodo_inicial varchar(7) null,
  periodo_final varchar(7) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_dre_detalhe (
  id int(11) unsigned not null auto_increment,
  id_contabil_dre_cabecalho int(11) unsigned not null,
  classificacao varchar(30) null,
  descricao varchar(100) null,
  forma_calculo char(1) null,
  sinal char(1) null,
  natureza char(1) null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_dre_cab_det (id_contabil_dre_cabecalho asc),
  constraint fk_6ddcbe08695e44c58412eba846c11bdb
    foreign key (id_contabil_dre_cabecalho)
    references contabil_dre_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_livro (
  id int(11) unsigned not null auto_increment,
  descricao varchar(50) null,
  competencia varchar(7) null,
  forma_escrituracao char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_termo (
  id int(11) unsigned not null auto_increment,
  id_contabil_livro int(11) unsigned not null,
  abertura_encerramento char(1) null,
  numero int(11) unsigned null,
  pagina_inicial int(11) unsigned null,
  pagina_final int(11) unsigned null,
  registrado varchar(100) null,
  numero_registro varchar(50) null,
  data_despacho date null,
  data_abertura date null,
  data_encerramento date null,
  escrituracao_inicio date null,
  escrituracao_fim date null,
  texto text null,
  primary key (id),
  index fk_contabil_livro_termo (id_contabil_livro asc),
  constraint fk_90b322a02da84ef09d6a4d8467f07f59
    foreign key (id_contabil_livro)
    references contabil_livro (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_encerramento_exe_cab (
  id int(11) unsigned not null auto_increment,
  data_inicio date null,
  data_fim date null,
  data_inclusao date null,
  motivo varchar(100) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_encerramento_exe_det (
  id int(11) unsigned not null auto_increment,
  id_contabil_conta int(11) unsigned not null,
  id_contabil_encerramento_exe int(11) unsigned not null,
  saldo_anterior decimal(18,6) null,
  valor_debito decimal(18,6) null,
  valor_credito decimal(18,6) null,
  saldo decimal(18,6) null,
  primary key (id),
  index fk_enc_exe_cab_det (id_contabil_encerramento_exe asc),
  index fk_contabil_conta_enc_det (id_contabil_conta asc),
  constraint fk_e3f23d1accdc467fa8f29e0a03fd6c63
    foreign key (id_contabil_encerramento_exe)
    references contabil_encerramento_exe_cab (id)
    on delete no action
    on update no action,
  constraint fk_74fd9080f3c34c60a10dd7a2f34ebe60
    foreign key (id_contabil_conta)
    references contabil_conta (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists plano_centro_resultado (
  id int(11) unsigned not null auto_increment,
  nome varchar(100) null,
  mascara varchar(50) null,
  niveis int(11) unsigned null,
  data_inclusao date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists centro_resultado (
  id int(11) unsigned not null auto_increment,
  id_plano_centro_resultado int(11) unsigned not null,
  classificacao varchar(30) null,
  descricao varchar(100) null,
  sofre_rateiro char(1) null,
  primary key (id),
  index fk_plano_centro (id_plano_centro_resultado asc),
  constraint fk_a188d698814541829a82afd03c7bcd15
    foreign key (id_plano_centro_resultado)
    references plano_centro_resultado (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists lanca_centro_resultado (
  id int(11) unsigned not null auto_increment,
  id_centro_resultado int(11) unsigned not null,
  valor decimal(18,6) null,
  historico varchar(250) null,
  data_lancamento date null,
  data_inclusao date null,
  origem_de_rateio char(1) null,
  primary key (id),
  index fk_centro_lanca (id_centro_resultado asc),
  constraint fk_f9581400b5484933b0ae9da6ee5fb941
    foreign key (id_centro_resultado)
    references centro_resultado (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists rateio_centro_resultado_cab (
  id int(11) unsigned not null auto_increment,
  id_centro_resultado int(11) unsigned not null,
  descricao varchar(100) null,
  primary key (id),
  index fk_centro_rateio_cab (id_centro_resultado asc),
  constraint fk_5030a2eaffe14f338380ae8b4d236121
    foreign key (id_centro_resultado)
    references centro_resultado (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists rateio_centro_resultado_det (
  id int(11) unsigned not null auto_increment,
  id_centro_resultado_destino int(11) unsigned not null,
  id_rateio_centro_resul_cab int(11) unsigned not null,
  porcento_rateio decimal(18,6) null,
  primary key (id),
  index fk_rateio_cab_det (id_rateio_centro_resul_cab asc),
  index fk_centro_rateio (id_centro_resultado_destino asc),
  constraint fk_b3ec49d9b1d347bbb51bff23f144819c
    foreign key (id_rateio_centro_resul_cab)
    references rateio_centro_resultado_cab (id)
    on delete no action
    on update no action,
  constraint fk_9ac87dd89bfc4d4cb4b96b39b2a16c49
    foreign key (id_centro_resultado_destino)
    references centro_resultado (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists encerra_centro_resultado (
  id int(11) unsigned not null auto_increment,
  id_centro_resultado int(11) unsigned not null,
  competencia varchar(7) null,
  valor_total decimal(18,6) null,
  valor_sub_rateio decimal(18,6) null,
  primary key (id),
  index fk_centro_encerra (id_centro_resultado asc),
  constraint fk_ca4c3c762109472ea9798ca8a104070c
    foreign key (id_centro_resultado)
    references centro_resultado (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_lancamento_comissao (
  id int(11) unsigned not null auto_increment,
  id_vendedor int not null,
  competencia varchar(7) null,
  vencimento date null,
  base_calculo decimal(18,6) null,
  valor_comissao decimal(18,6) null,
  primary key (id),
  index fk_folha_lancamento_comissao_vendedor1_idx (id_vendedor asc),
  constraint fk_folha_lancamento_comissao_vendedor1
    foreign key (id_vendedor)
    references vendedor (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_conta_rateio (
  id int(11) unsigned not null auto_increment,
  id_centro_resultado int(11) unsigned not null,
  id_contabil_conta int(11) unsigned not null,
  porcento_rateio decimal(18,6) null,
  primary key (id),
  index fk_contabil_conta_rateio (id_contabil_conta asc),
  index fk_centro_resultado_rateio (id_centro_resultado asc),
  constraint fk_846c56844dca4ef28210d5e1a11e71fe
    foreign key (id_contabil_conta)
    references contabil_conta (id)
    on delete no action
    on update no action,
  constraint fk_21b68c003bfb469caaa0ad350248a949
    foreign key (id_centro_resultado)
    references centro_resultado (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists log_importacao (
  id int(11) unsigned not null auto_increment,
  data_importacao date null,
  hora_importacao varchar(8) null,
  erro text null,
  registro text null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists log_exportacao (
  id int(11) unsigned not null auto_increment,
  data_exportacao date null,
  hora_exportacao varchar(8) null,
  erro text null,
  registro text null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists integracao_pdv (
  id int(11) unsigned not null auto_increment,
  identifica varchar(50) null,
  data_integracao date null,
  hora_integracao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists efd_tabela_436 (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao varchar(250) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_437 (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(250) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_4316 (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao text null,
  observacao text null,
  inicio_vigencia date null,
  fim_vigencia date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_4315 (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao text null,
  observacao text null,
  inicio_vigencia date null,
  fim_vigencia date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_4314 (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao text null,
  observacao text null,
  inicio_vigencia date null,
  fim_vigencia date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_4313 (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao text null,
  observacao text null,
  inicio_vigencia date null,
  fim_vigencia date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_439 (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao text null,
  observacao text null,
  inicio_vigencia date null,
  fim_vigencia date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists efd_tabela_4310 (
  id int(11) unsigned not null auto_increment,
  codigo int(11) unsigned null,
  descricao text null,
  observacao text null,
  inicio_vigencia date null,
  fim_vigencia date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists empresa_cnae (
  id int(11) unsigned not null auto_increment,
  id_empresa int not null,
  id_cnae int not null,
  principal char(1) null,
  ramo_atividade varchar(50) null,
  objeto_social text null,
  primary key (id),
  index fk_empresa_cnae_empresa1_idx (id_empresa asc),
  index fk_empresa_cnae_cnae1_idx (id_cnae asc),
  constraint fk_empresa_cnae_empresa1
    foreign key (id_empresa)
    references empresa (id)
    on delete no action
    on update no action,
  constraint fk_empresa_cnae_cnae1
    foreign key (id_cnae)
    references cnae (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists inventario_contagem_cab (
  id int(11) unsigned not null auto_increment,
  data_contagem date null,
  estoque_atualizado char(1) null,
  tipo char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists inventario_contagem_det (
  id int(11) unsigned not null auto_increment,
  id_inventario_contagem_cab int(11) unsigned not null,
  id_produto int not null,
  contagem01 decimal(18,6) null,
  contagem02 decimal(18,6) null,
  contagem03 decimal(18,6) null,
  fechado_contagem char(2) null,
  quantidade_sistema decimal(18,6) null,
  acuracidade decimal(18,6) null,
  divergencia decimal(18,6) null,
  primary key (id),
  index fk_contagem_cab_det (id_inventario_contagem_cab asc),
  index fk_inventario_contagem_det_produto1_idx (id_produto asc),
  constraint fk_0ff2b94b9a4b47d1a53625332faf4cfa
    foreign key (id_inventario_contagem_cab)
    references inventario_contagem_cab (id)
    on delete no action
    on update no action,
  constraint fk_inventario_contagem_det_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists orcamento_periodo (
  id int(11) unsigned not null auto_increment,
  periodo char(2) null,
  nome varchar(30) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists orcamento_empresarial (
  id int(11) unsigned not null auto_increment,
  id_orcamento_periodo int(11) unsigned not null,
  nome varchar(30) null,
  descricao text null,
  data_inicial date null,
  numero_periodos int(11) unsigned null,
  data_base date null,
  primary key (id),
  index fk_orcamento_periodo_orc (id_orcamento_periodo asc),
  constraint fk_34b87ee9090849479a62962274b9e2e6
    foreign key (id_orcamento_periodo)
    references orcamento_periodo (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists orcamento_detalhe (
  id int(11) unsigned not null auto_increment,
  id_orcamento_empresarial int(11) unsigned not null,
  id_fin_natureza_financeira int unsigned not null,
  periodo varchar(10) null,
  valor_orcado decimal(18,6) null,
  valor_realizado decimal(18,6) null,
  taxa_variacao decimal(18,6) null,
  valor_variacao decimal(18,6) null,
  primary key (id),
  index fk_orc_empresarial_cab_det (id_orcamento_empresarial asc),
  index fk_orcamento_detalhe_fin_natureza_financeira1_idx (id_fin_natureza_financeira asc),
  constraint fk_579ed741cdcd4302923c704283061efb
    foreign key (id_orcamento_empresarial)
    references orcamento_empresarial (id)
    on delete no action
    on update no action,
  constraint fk_orcamento_detalhe_fin_natureza_financeira1
    foreign key (id_fin_natureza_financeira)
    references fin_natureza_financeira (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists patrim_indice_atualizacao (
  id int(11) unsigned not null auto_increment,
  data_indice date null,
  nome varchar(10) null,
  valor decimal(18,6) null,
  valor_alternativo decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists patrim_taxa_depreciacao (
  id int(11) unsigned not null auto_increment,
  ncm varchar(8) null,
  bem varchar(250) null,
  vida decimal(18,6) null,
  taxa decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists patrim_grupo_bem (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(50) null,
  descricao text null,
  conta_ativo_imobilizado varchar(30) null,
  conta_depreciacao_acumulada varchar(30) null,
  conta_despesa_depreciacao varchar(30) null,
  codigo_historico int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
create table if not exists patrim_tipo_aquisicao_bem (
  id int(11) unsigned not null auto_increment,
  tipo char(2) null,
  nome varchar(50) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists patrim_estado_conservacao (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  nome varchar(50) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists patrim_bem (
  id int(11) unsigned not null auto_increment,
  id_centro_resultado int(11) unsigned not null,
  id_patrim_tipo_aquisicao_bem int(11) unsigned not null,
  id_patrim_estado_conservacao int(11) unsigned not null,
  id_patrim_grupo_bem int(11) unsigned not null,
  id_fornecedor int not null,
  id_colaborador int not null,
  id_setor int not null,
  numero_nb varchar(20) null,
  nome varchar(100) null,
  descricao text null,
  numero_serie varchar(50) null,
  data_aquisicao date null,
  data_aceite date null,
  data_cadastro date null,
  data_contabilizado date null,
  data_vistoria date null,
  data_marcacao date null,
  data_baixa date null,
  vencimento_garantia date null,
  numero_nota_fiscal varchar(50) null,
  chave_nfe varchar(44) null,
  valor_original decimal(18,6) null,
  valor_compra decimal(18,6) null,
  valor_atualizado decimal(18,6) null,
  valor_baixa decimal(18,6) null,
  deprecia char(1) null,
  metodo_depreciacao char(1) null,
  inicio_depreciacao date null,
  ultima_depreciacao date null,
  tipo_depreciacao char(1) null,
  taxa_anual_depreciacao decimal(18,6) null,
  taxa_mensal_depreciacao decimal(18,6) null,
  taxa_depreciacao_acelerada decimal(18,6) null,
  taxa_depreciacao_incentivada decimal(18,6) null,
  funcao text null,
  primary key (id),
  index fk_patrim_grupo_bem (id_patrim_grupo_bem asc),
  index fk_tipo_aquisicao_bem (id_patrim_tipo_aquisicao_bem asc),
  index fk_estado_conservacao_bem (id_patrim_estado_conservacao asc),
  index fk_centro_res_bem (id_centro_resultado asc),
  index fk_patrim_bem_fornecedor1_idx (id_fornecedor asc),
  index fk_patrim_bem_colaborador1_idx (id_colaborador asc),
  index fk_patrim_bem_setor1_idx (id_setor asc),
  constraint fk_6763d73fcad345f5b326f15f787593c8
    foreign key (id_patrim_grupo_bem)
    references patrim_grupo_bem (id)
    on delete no action
    on update no action,
  constraint fk_308bf88115ec4edba8d9031c5760dd18
    foreign key (id_patrim_tipo_aquisicao_bem)
    references patrim_tipo_aquisicao_bem (id)
    on delete no action
    on update no action,
  constraint fk_5e078f04adf748eea4826e2b657f63c7
    foreign key (id_patrim_estado_conservacao)
    references patrim_estado_conservacao (id)
    on delete no action
    on update no action,
  constraint fk_791e60132f02480ab5b65dd83dbe5125
    foreign key (id_centro_resultado)
    references centro_resultado (id)
    on delete no action
    on update no action,
  constraint fk_patrim_bem_fornecedor1
    foreign key (id_fornecedor)
    references fornecedor (id)
    on delete no action
    on update no action,
  constraint fk_patrim_bem_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action,
  constraint fk_patrim_bem_setor1
    foreign key (id_setor)
    references setor (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists seguradora (
  id int(11) unsigned not null auto_increment,
  nome varchar(50) null,
  contato varchar(50) null,
  telefone varchar(14) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists patrim_documento_bem (
  id int(11) unsigned not null auto_increment,
  id_patrim_bem int(11) unsigned not null,
  nome varchar(50) null,
  descricao text null,
  imagem text null,
  primary key (id),
  index fk_patrim_documento_bem (id_patrim_bem asc),
  constraint fk_7a0c1480e2444328b2cb2ab8a169b89f
    foreign key (id_patrim_bem)
    references patrim_bem (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists patrim_depreciacao_bem (
  id int(11) unsigned not null auto_increment,
  id_patrim_bem int(11) unsigned not null,
  data_depreciacao date null,
  dias int(11) unsigned null,
  taxa decimal(18,6) null,
  indice decimal(18,6) null,
  valor decimal(18,6) null,
  depreciacao_acumulada decimal(18,6) null,
  primary key (id),
  index fk_patrim_bem_depreciacao (id_patrim_bem asc),
  constraint fk_3702f0f7cf2141c8aaaba7d9a723936e
    foreign key (id_patrim_bem)
    references patrim_bem (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists patrim_tipo_movimentacao (
  id int(11) unsigned not null auto_increment,
  tipo char(2) null,
  nome varchar(50) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists patrim_movimentacao_bem (
  id int(11) unsigned not null auto_increment,
  id_patrim_bem int(11) unsigned not null,
  id_patrim_tipo_movimentacao int(11) unsigned not null,
  data_movimentacao date null,
  responsavel varchar(50) null,
  primary key (id),
  index fk_tipo_mov_bem_mov_bem (id_patrim_tipo_movimentacao asc),
  index fk_patrim_bem_movimentacao (id_patrim_bem asc),
  constraint fk_59673d0699da4bf395dc3a4ab382d4d1
    foreign key (id_patrim_tipo_movimentacao)
    references patrim_tipo_movimentacao (id)
    on delete no action
    on update no action,
  constraint fk_ad129e44f68b4ea39952207a4e51d786
    foreign key (id_patrim_bem)
    references patrim_bem (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists patrim_apolice_seguro (
  id int(11) unsigned not null auto_increment,
  id_patrim_bem int(11) unsigned not null,
  id_seguradora int(11) unsigned not null,
  numero varchar(20) null,
  data_contratacao date null,
  data_vencimento date null,
  valor_premio decimal(18,6) null,
  valor_segurado decimal(18,6) null,
  observacao text null,
  imagem text null,
  primary key (id),
  index fk_segurada_apolice (id_seguradora asc),
  index fk_patrim_apolice_bem (id_patrim_bem asc),
  constraint fk_51ff0562515b417c894cc79ddbfcdfe3
    foreign key (id_seguradora)
    references seguradora (id)
    on delete no action
    on update no action,
  constraint fk_1072f0b38a3c48369f4d77ccaedc3279
    foreign key (id_patrim_bem)
    references patrim_bem (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fiscal_municipal_regime (
  id int(11) unsigned not null auto_increment,
  uf char(2) null,
  codigo varchar(20) null,
  nome varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fiscal_estadual_regime (
  id int(11) unsigned not null auto_increment,
  uf char(2) null,
  codigo varchar(20) null,
  nome varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fiscal_estadual_porte (
  id int(11) unsigned not null auto_increment,
  uf char(2) null,
  codigo varchar(20) null,
  nome varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fiscal_parametro (
  id int(11) unsigned not null auto_increment,
  id_fiscal_estadual_porte int(11) unsigned null,
  id_fiscal_estadual_regime int(11) unsigned null,
  id_fiscal_municipal_regime int(11) unsigned null,
  vigencia varchar(7) null,
  descricao_vigencia varchar(100) null,
  criterio_lancamento char(1) null,
  apuracao char(1) null,
  microempree_individual char(1) null,
  calc_pis_cofins_efd char(2) null,
  simples_codigo_acesso varchar(50) null,
  simples_tabela char(1) null,
  simples_atividade char(2) null,
  perfil_sped char(1) null,
  apuracao_consolidada char(1) null,
  substituicao_tributaria char(1) null,
  forma_calculo_iss char(2) null,
  primary key (id),
  index fk_regime_mun_par (id_fiscal_municipal_regime asc),
  index fk_regime_est_par (id_fiscal_estadual_regime asc),
  index fk_porte_est_par (id_fiscal_estadual_porte asc),
  constraint fk_982964890ee6403b9eafd990246b28d1
    foreign key (id_fiscal_municipal_regime)
    references fiscal_municipal_regime (id)
    on delete no action
    on update no action,
  constraint fk_3a84100727d643c3a35656427e03924f
    foreign key (id_fiscal_estadual_regime)
    references fiscal_estadual_regime (id)
    on delete no action
    on update no action,
  constraint fk_d9548e2c5e6b4c6c88c12cd968da496c
    foreign key (id_fiscal_estadual_porte)
    references fiscal_estadual_porte (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fiscal_livro (
  id int(11) unsigned not null auto_increment,
  descricao varchar(50) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fiscal_termo (
  id int(11) unsigned not null auto_increment,
  id_fiscal_livro int(11) unsigned not null,
  abertura_encerramento char(1) null,
  numero int(11) unsigned null,
  pagina_inicial int(11) unsigned null,
  pagina_final int(11) unsigned null,
  registrado varchar(100) null,
  numero_registro varchar(50) null,
  data_despacho date null,
  data_abertura date null,
  data_encerramento date null,
  escrituracao_inicio date null,
  escrituracao_fim date null,
  texto text null,
  primary key (id),
  index fk_fiscal_livro_termo (id_fiscal_livro asc),
  constraint fk_a4f4c5768f6f4ff99bd1de2e881a7252
    foreign key (id_fiscal_livro)
    references fiscal_livro (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fiscal_inscricoes_substitutas (
  id int(11) unsigned not null auto_increment,
  id_fiscal_parametros int(11) unsigned not null,
  uf char(2) null,
  inscricao_estadual varchar(30) null,
  pmpf char(1) null,
  primary key (id),
  index fk_par_insc_substituta (id_fiscal_parametros asc),
  constraint fk_8b1f8bd02a384b9b91efe8d9fba98567
    foreign key (id_fiscal_parametros)
    references fiscal_parametro (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists simples_nacional_cabecalho (
  id int(11) unsigned not null auto_increment,
  vigencia_inicial date null,
  vigencia_final date null,
  anexo varchar(10) null,
  tabela varchar(10) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists simples_nacional_detalhe (
  id int(11) unsigned not null auto_increment,
  id_simples_nacional_cabecalho int(11) unsigned not null,
  faixa int(11) unsigned null,
  valor_inicial decimal(18,6) null,
  valor_final decimal(18,6) null,
  aliquota decimal(18,6) null,
  irpj decimal(18,6) null,
  csll decimal(18,6) null,
  cofins decimal(18,6) null,
  pis_pasep decimal(18,6) null,
  cpp decimal(18,6) null,
  icms decimal(18,6) null,
  ipi decimal(18,6) null,
  iss decimal(18,6) null,
  primary key (id),
  index fk_simples_nacional_cab_det (id_simples_nacional_cabecalho asc),
  constraint fk_6638a7a10ba34d46a720be1bbc8966a0
    foreign key (id_simples_nacional_cabecalho)
    references simples_nacional_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fiscal_nota_fiscal_entrada (
  id int(11) unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  competencia varchar(7) null,
  cfop_entrada int(11) unsigned null,
  valor_rateio_frete decimal(18,6) null,
  valor_custo_medio decimal(18,6) null,
  valor_icms_antecipado decimal(18,6) null,
  valor_bc_icms_antecipado decimal(18,6) null,
  valor_bc_icms_creditado decimal(18,6) null,
  valor_bc_pis_creditado decimal(18,6) null,
  valor_bc_cofins_creditado decimal(18,6) null,
  valor_bc_ipi_creditado decimal(18,6) null,
  cst_credito_icms char(3) null,
  cst_credito_pis char(2) null,
  cst_credito_cofins char(2) null,
  cst_credito_ipi char(2) null,
  valor_icms_creditado decimal(18,6) null,
  valor_pis_creditado decimal(18,6) null,
  valor_cofins_creditado decimal(18,6) null,
  valor_ipi_creditado decimal(18,6) null,
  qtde_parcela_credito_pis int(11) unsigned null,
  qtde_parcela_credito_cofins int(11) unsigned null,
  qtde_parcela_credito_icms int(11) unsigned null,
  qtde_parcela_credito_ipi int(11) unsigned null,
  aliquota_credito_icms decimal(18,6) null,
  aliquota_credito_pis decimal(18,6) null,
  aliquota_credito_cofins decimal(18,6) null,
  aliquota_credito_ipi decimal(18,6) null,
  primary key (id),
  index fk_fiscal_nota_fiscal_entrada_nfe_cabecalho1_idx (id_nfe_cabecalho asc),
  constraint fk_fiscal_nota_fiscal_entrada_nfe_cabecalho1
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_parametro (
  id int(11) unsigned not null auto_increment,
  competencia varchar(7) null,
  contribui_pis char(1) null,
  aliquota_pis decimal(18,6) null,
  discriminar_dsr char(1) null,
  dia_pagamento char(2) null,
  calculo_proporcionalidade char(1) null,
  descontar_faltas_13 char(1) null,
  pagar_adicionais_13 char(1) null,
  pagar_estagiarios_13 char(1) null,
  mes_adiantamento_13 char(2) null,
  percentual_adiantam_13 decimal(18,6) null,
  ferias_descontar_faltas char(1) null,
  ferias_pagar_adicionais char(1) null,
  ferias_adiantar_13 char(1) null,
  ferias_pagar_estagiarios char(1) null,
  ferias_calc_justa_causa char(1) null,
  ferias_movimento_mensal char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists guias_acumuladas (
  id int(11) unsigned not null auto_increment,
  gps_tipo char(1) null,
  gps_competencia varchar(7) null,
  gps_valor_inss decimal(18,6) null,
  gps_valor_outras_ent decimal(18,6) null,
  gps_data_pagamento date null,
  irrf_competencia varchar(7) null,
  irrf_codigo_recolhimento int(11) unsigned null,
  irrf_valor_acumulado decimal(18,6) null,
  irrf_data_pagamento date null,
  pis_competencia varchar(7) null,
  pis_valor_acumulado decimal(18,6) null,
  pis_data_pagamento date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists folha_fechamento (
  id int(11) unsigned not null auto_increment,
  fechamento_atual varchar(7) null,
  proximo_fechamento varchar(7) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ferias_periodo_aquisitivo (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  data_inicio date null,
  data_fim date null,
  situacao char(1) null,
  limite_para_gozo date null,
  descontar_faltas char(1) null,
  desconsiderar_afastamento char(1) null,
  afastamento_previdencia int(11) unsigned null,
  afastamento_sem_remun int(11) unsigned null,
  afastamento_com_remun int(11) unsigned null,
  dias_direito int(11) unsigned null,
  dias_gozados int(11) unsigned null,
  dias_faltas int(11) unsigned null,
  dias_restantes int(11) unsigned null,
  primary key (id),
  index fk_ferias_periodo_aquisitivo_colaborador1_idx (id_colaborador asc),
  constraint fk_ferias_periodo_aquisitivo_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_tipo_afastamento (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  descricao text null,
  codigo_esocial char(2) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists folha_afastamento (
  id int(11) unsigned not null auto_increment,
  id_folha_tipo_afastamento int(11) unsigned not null,
  id_colaborador int not null,
  data_inicio date null,
  data_fim date null,
  dias_afastado int(11) unsigned null,
  primary key (id),
  index fk_folha_tipo_afastamento (id_folha_tipo_afastamento asc),
  index fk_folha_afastamento_colaborador1_idx (id_colaborador asc),
  constraint fk_26d6c2dce017477381d187f4ca4db521
    foreign key (id_folha_tipo_afastamento)
    references folha_tipo_afastamento (id)
    on delete no action
    on update no action,
  constraint fk_folha_afastamento_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_plano_saude (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  id_operadora_plano_saude int(11) unsigned not null,
  data_inicio date null,
  beneficiario char(1) null,
  primary key (id),
  index fk_folha_plano_saude_colaborador1_idx (id_colaborador asc),
  index fk_folha_plano_saude_operadora_plano_saude1_idx (id_operadora_plano_saude asc),
  constraint fk_folha_plano_saude_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action,
  constraint fk_folha_plano_saude_operadora_plano_saude1
    foreign key (id_operadora_plano_saude)
    references operadora_plano_saude (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_evento (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  descricao text null,
  tipo char(1) null,
  unidade char(1) null,
  base_calculo char(2) null,
  taxa decimal(18,6) null,
  rubrica_esocial char(4) null,
  cod_incidencia_previdencia char(2) null,
  cod_incidencia_irrf char(2) null,
  cod_incidencia_fgts char(2) null,
  cod_incidencia_sindicato char(2) null,
  repercute_dsr char(1) null,
  repercute_13 char(1) null,
  repercute_ferias char(1) null,
  repercute_aviso char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists folha_rescisao (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  data_demissao date null,
  data_pagamento date null,
  motivo varchar(100) null,
  motivo_esocial char(2) null,
  data_aviso_previo date null,
  dias_aviso_previo int(11) unsigned null,
  comprovou_novo_emprego char(1) null,
  dispensou_empregado char(1) null,
  pensao_alimenticia decimal(18,6) null,
  pensao_alimenticia_fgts decimal(18,6) null,
  fgts_valor_rescisao decimal(18,6) null,
  fgts_saldo_banco decimal(18,6) null,
  fgts_complemento_saldo decimal(18,6) null,
  fgts_codigo_afastamento varchar(10) null,
  fgts_codigo_saque varchar(10) null,
  primary key (id),
  index fk_folha_rescisao_colaborador1_idx (id_colaborador asc),
  constraint fk_folha_rescisao_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_lancamento_cabecalho (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  competencia varchar(7) null,
  tipo char(1) null,
  primary key (id),
  index fk_folha_lancamento_cabecalho_colaborador1_idx (id_colaborador asc),
  constraint fk_folha_lancamento_cabecalho_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_lancamento_detalhe (
  id int(11) unsigned not null auto_increment,
  id_folha_evento int(11) unsigned not null,
  id_folha_lancamento_cabecalho int(11) unsigned not null,
  origem decimal(18,6) null,
  provento decimal(18,6) null,
  desconto decimal(18,6) null,
  primary key (id),
  index fk_folha_lancamento_cab_det (id_folha_lancamento_cabecalho asc),
  index fk_folha_evento_lancamento (id_folha_evento asc),
  constraint fk_69a27780ad584027a36169821375b7e3
    foreign key (id_folha_lancamento_cabecalho)
    references folha_lancamento_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_a20d00a982d24c0a831925fb9531aa16
    foreign key (id_folha_evento)
    references folha_evento (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_ferias_coletivas (
  id int(11) unsigned not null auto_increment,
  data_inicio date null,
  data_fim date null,
  dias_gozo int(11) unsigned null,
  abono_pecuniario_inicio date null,
  abono_pecuniario_fim date null,
  dias_abono int(11) unsigned null,
  data_pagamento date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists folha_vale_transporte (
  id int(11) unsigned not null auto_increment,
  id_empresa_transp_itin int(11) unsigned not null,
  id_colaborador int not null,
  quantidade int(11) unsigned null,
  primary key (id),
  index fk_emp_tra_itin_val_tra (id_empresa_transp_itin asc),
  index fk_folha_vale_transporte_colaborador1_idx (id_colaborador asc),
  constraint fk_dfefe399d3534963a41e26a38db31853
    foreign key (id_empresa_transp_itin)
    references empresa_transporte_itinerario (id)
    on delete no action
    on update no action,
  constraint fk_folha_vale_transporte_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_inss (
  id int(11) unsigned not null auto_increment,
  competencia varchar(7) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists folha_inss_servico (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists folha_inss_retencao (
  id int(11) unsigned not null auto_increment,
  id_folha_inss int(11) unsigned not null,
  id_folha_inss_servico int(11) unsigned not null,
  valor_mensal decimal(18,6) null,
  valor_13 decimal(18,6) null,
  primary key (id),
  index fk_folha_inss_serv_retencao (id_folha_inss_servico asc),
  index fk_folha_inss_retencao (id_folha_inss asc),
  constraint fk_2d85fcf030df40f98182dca007e88a1d
    foreign key (id_folha_inss_servico)
    references folha_inss_servico (id)
    on delete no action
    on update no action,
  constraint fk_5265f7ed93104991a56cc0541e246dce
    foreign key (id_folha_inss)
    references folha_inss (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_ppp (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  observacao text null,
  primary key (id),
  index fk_folha_ppp_colaborador1_idx (id_colaborador asc),
  constraint fk_folha_ppp_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_ppp_cat (
  id int(11) unsigned not null auto_increment,
  id_folha_ppp int(11) unsigned not null,
  numero_cat int(11) unsigned null,
  data_afastamento date null,
  data_registro date null,
  primary key (id),
  index fk_folha_ppp_cat (id_folha_ppp asc),
  constraint fk_8c91d20046d54c33a1eb74f1c11ac8b5
    foreign key (id_folha_ppp)
    references folha_ppp (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_ppp_atividade (
  id int(11) unsigned not null auto_increment,
  id_folha_ppp int(11) unsigned not null,
  data_inicio date null,
  data_fim date null,
  descricao text null,
  primary key (id),
  index fk_folha_ppp_atividade (id_folha_ppp asc),
  constraint fk_f750f228a23b4262a967e271b442caf0
    foreign key (id_folha_ppp)
    references folha_ppp (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_ppp_fator_risco (
  id int(11) unsigned not null auto_increment,
  id_folha_ppp int(11) unsigned not null,
  data_inicio date null,
  data_fim date null,
  tipo char(1) null,
  fator_risco varchar(40) null,
  intensidade varchar(15) null,
  tecnica_utilizada varchar(40) null,
  epc_eficaz char(1) null,
  epi_eficaz char(1) null,
  ca_epi int(11) unsigned null,
  atendimento_nr06_1 char(1) null,
  atendimento_nr06_2 char(1) null,
  atendimento_nr06_3 char(1) null,
  atendimento_nr06_4 char(1) null,
  atendimento_nr06_5 char(1) null,
  primary key (id),
  index fk_folha_ppp_fator_risco (id_folha_ppp asc),
  constraint fk_0ffe40c714194ffd92981d1468daa9f2
    foreign key (id_folha_ppp)
    references folha_ppp (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_ppp_exame_medico (
  id int(11) unsigned not null auto_increment,
  id_folha_ppp int(11) unsigned not null,
  data_ultimo date null,
  tipo char(1) null,
  natureza varchar(50) null,
  exame char(1) null,
  indicacao_resultados varchar(50) null,
  primary key (id),
  index fk_folha_ppp_exame_medido (id_folha_ppp asc),
  constraint fk_1521efa174474a6cac0c853b15624864
    foreign key (id_folha_ppp)
    references folha_ppp (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists folha_historico_salarial (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  competencia varchar(7) null,
  salario_atual decimal(18,6) null,
  percentual_aumento decimal(18,6) null,
  salario_novo decimal(18,6) null,
  valido_a_partir varchar(7) null,
  motivo varchar(100) null,
  primary key (id),
  index fk_folha_historico_salarial_colaborador1_idx (id_colaborador asc),
  constraint fk_folha_historico_salarial_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists tipo_contrato (
  id int(11) unsigned not null auto_increment,
  nome varchar(50) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contrato_tipo_servico (
  id int(11) unsigned not null auto_increment,
  nome varchar(50) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contrato_solicitacao_servico (
  id int(11) unsigned not null auto_increment,
  id_contrato_tipo_servico int(11) unsigned not null,
  id_setor int not null,
  id_colaborador int not null,
  id_cliente int null,
  id_fornecedor int null,
  data_solicitacao date null,
  data_desejada_inicio date null,
  urgente char(1) null,
  status_solicitacao char(1) null,
  descricao varchar(100) null,
  primary key (id),
  index fk_contrato_tipo_servico_sol (id_contrato_tipo_servico asc),
  index fk_contrato_solicitacao_servico_setor1_idx (id_setor asc),
  index fk_contrato_solicitacao_servico_colaborador1_idx (id_colaborador asc),
  index fk_contrato_solicitacao_servico_cliente1_idx (id_cliente asc),
  index fk_contrato_solicitacao_servico_fornecedor1_idx (id_fornecedor asc),
  constraint fk_1155005805694d229d5279eced1cb6f4
    foreign key (id_contrato_tipo_servico)
    references contrato_tipo_servico (id)
    on delete no action
    on update no action,
  constraint fk_contrato_solicitacao_servico_setor1
    foreign key (id_setor)
    references setor (id)
    on delete no action
    on update no action,
  constraint fk_contrato_solicitacao_servico_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action,
  constraint fk_contrato_solicitacao_servico_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action,
  constraint fk_contrato_solicitacao_servico_fornecedor1
    foreign key (id_fornecedor)
    references fornecedor (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contrato (
  id int(11) unsigned not null,
  id_solicitacao_servico int(11) unsigned not null,
  id_tipo_contrato int(11) unsigned not null,
  numero varchar(50) null,
  nome varchar(100) null,
  descricao text null,
  data_cadastro date null,
  data_inicio_vigencia date null,
  data_fim_vigencia date null,
  dia_faturamento char(2) null,
  valor decimal(18,6) null,
  quantidade_parcelas int(11) unsigned null,
  intervalo_entre_parcelas int(11) null,
  observacao text null,
  classificacao_contabil_conta varchar(30) null,
  primary key (id),
  index fk_tipo_contrato_contrato (id_tipo_contrato asc),
  index fk_sol_servico_contrato (id_solicitacao_servico asc),
  constraint fk_361e6865aaca4aae835d69951506b97c
    foreign key (id_tipo_contrato)
    references tipo_contrato (id)
    on delete no action
    on update no action,
  constraint fk_26ad03399a7f44d5a937974af985c5c6
    foreign key (id_solicitacao_servico)
    references contrato_solicitacao_servico (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contrato_historico_reajuste (
  id int(11) unsigned not null auto_increment,
  id_contrato int(11) unsigned not null,
  indice decimal(18,6) null,
  valor_anterior decimal(18,6) null,
  valor_atual decimal(18,6) null,
  data_reajuste date null,
  observacao text null,
  primary key (id),
  index fk_contrato_historico_reajuste (id_contrato asc),
  constraint fk_5930b5f38d8448f3ade0546a1d58ef8a
    foreign key (id_contrato)
    references contrato (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contrato_prev_faturamento (
  id int(11) unsigned not null auto_increment,
  id_contrato int(11) unsigned not null,
  data_prevista date null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_contrato_prev_faturamento (id_contrato asc),
  constraint fk_081245602f8f419e911b8193c17ac936
    foreign key (id_contrato)
    references contrato (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contrato_hist_faturamento (
  id int(11) unsigned not null auto_increment,
  id_contrato int(11) unsigned not null,
  data_fatura date null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_contrato_hist_faturamento (id_contrato asc),
  constraint fk_04a46b13cdc142a8a029987fd4c07cc3
    foreign key (id_contrato)
    references contrato (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists feriados (
  id int(11) unsigned not null auto_increment,
  ano char(4) null,
  nome varchar(50) null,
  abrangencia char(1) null,
  uf char(2) null,
  municipio_ibge int(11) unsigned null,
  tipo char(1) null,
  data_feriado date null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ponto_parametro (
  id int(11) unsigned not null auto_increment,
  mes_ano varchar(7) null,
  dia_inicial_apuracao int(11) unsigned null,
  hora_noturna_inicio varchar(8) null,
  hora_noturna_fim varchar(8) null,
  periodo_minimo_interjornada varchar(8) null,
  percentual_he_diurna decimal(18,6) null,
  percentual_he_noturna decimal(18,6) null,
  duracao_hora_noturna varchar(8) null,
  tratamento_hora_mais char(1) null,
  tratamento_hora_menos char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ponto_horario (
  id int(11) unsigned not null auto_increment,
  tipo char(1) null,
  codigo char(4) null,
  nome varchar(50) null,
  tipo_trabalho char(1) null,
  carga_horaria varchar(8) null,
  entrada01 varchar(8) null,
  saida01 varchar(8) null,
  entrada02 varchar(8) null,
  saida02 varchar(8) null,
  entrada03 varchar(8) null,
  saida03 varchar(8) null,
  entrada04 varchar(8) null,
  saida04 varchar(8) null,
  entrada05 varchar(8) null,
  saida05 varchar(8) null,
  hora_inicio_jornada varchar(8) null,
  hora_fim_jornada varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ponto_escala (
  id int(11) unsigned not null auto_increment,
  nome varchar(50) null,
  desconto_hora_dia varchar(8) null,
  desconto_dsr varchar(8) null,
  codigo_horario_domingo char(4) null,
  codigo_horario_segunda char(4) null,
  codigo_horario_terca char(4) null,
  codigo_horario_quarta char(4) null,
  codigo_horario_quinta char(4) null,
  codigo_horario_sexta char(4) null,
  codigo_horario_sabado char(4) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ponto_relogio (
  id int(11) unsigned not null auto_increment,
  localizacao varchar(50) null,
  marca varchar(30) null,
  fabricante varchar(30) null,
  numero_serie varchar(50) null,
  utilizacao char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ponto_turma (
  id int(11) unsigned not null auto_increment,
  id_ponto_escala int(11) unsigned not null,
  codigo char(5) null,
  nome varchar(50) null,
  primary key (id),
  index fk_ponto_escala_turma (id_ponto_escala asc),
  constraint fk_24dad7dc09654edf8059e958a0821aa1
    foreign key (id_ponto_escala)
    references ponto_escala (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ponto_marcacao (
  id int(11) unsigned not null auto_increment,
  id_ponto_relogio int(11) unsigned null,
  id_colaborador int not null,
  nsr int(11) unsigned null,
  data_marcacao date null,
  hora_marcacao varchar(8) null,
  tipo_marcacao char(1) null,
  tipo_registro char(1) null,
  par_entrada_saida char(2) null,
  justificativa varchar(100) null,
  primary key (id),
  index fk_ponto_relogio_marcacao (id_ponto_relogio asc),
  index fk_ponto_marcacao_colaborador1_idx (id_colaborador asc),
  constraint fk_41e0724dfd6049ceb95c119cdb59790c
    foreign key (id_ponto_relogio)
    references ponto_relogio (id)
    on delete no action
    on update no action,
  constraint fk_ponto_marcacao_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ponto_banco_horas (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  data_trabalho date null,
  quantidade varchar(8) null,
  situacao char(1) null,
  primary key (id),
  index fk_ponto_banco_horas_colaborador1_idx (id_colaborador asc),
  constraint fk_ponto_banco_horas_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ponto_classificacao_jornada (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(50) null,
  descricao text null,
  padrao char(1) null,
  descontar_horas char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ponto_horario_autorizado (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  data_horario date null,
  tipo char(1) null,
  carga_horaria varchar(8) null,
  entrada01 varchar(8) null,
  saida01 varchar(8) null,
  entrada02 varchar(8) null,
  saida02 varchar(8) null,
  entrada03 varchar(8) null,
  saida03 varchar(8) null,
  entrada04 varchar(8) null,
  saida04 varchar(8) null,
  entrada05 varchar(8) null,
  saida05 varchar(8) null,
  hora_fechamento_dia varchar(8) null,
  primary key (id),
  index fk_ponto_horario_autorizado_colaborador1_idx (id_colaborador asc),
  constraint fk_ponto_horario_autorizado_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ponto_abono (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  quantidade int(11) unsigned null,
  utilizado int(11) unsigned null,
  saldo int(11) unsigned null,
  data_cadastro date null,
  inicio_utilizacao date null,
  observacao text null,
  primary key (id),
  index fk_ponto_abono_colaborador1_idx (id_colaborador asc),
  constraint fk_ponto_abono_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ponto_abono_utilizacao (
  id int(11) unsigned not null auto_increment,
  id_ponto_abono int(11) unsigned not null,
  data_utilizacao date null,
  observacao text null,
  primary key (id),
  index fk_ponto_abono_utilizacao (id_ponto_abono asc),
  constraint fk_5e373e197d304782bbbc5c35c10cb2d9
    foreign key (id_ponto_abono)
    references ponto_abono (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists dav_cabecalho (
  id int(11) unsigned not null auto_increment,
  id_pessoa int not null,
  numero_dav varchar(10) null,
  numero_ecf varchar(4) null,
  ccf int(11) unsigned null,
  coo int(11) unsigned null,
  nome_destinatario varchar(100) null,
  cpf_cnpj_destinatario varchar(14) null,
  data_emissao date null,
  hora_emissao varchar(8) null,
  situacao char(1) null,
  taxa_acrescimo decimal(18,6) null,
  acrescimo decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  desconto decimal(18,6) null,
  subtotal decimal(18,6) null,
  valor decimal(18,6) null,
  impresso char(1) null,
  hash_registro varchar(32) null,
  primary key (id),
  index fk_dav_cabecalho_pessoa1_idx (id_pessoa asc),
  constraint fk_dav_cabecalho_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists dav_detalhe (
  id int(11) unsigned not null auto_increment,
  id_dav_cabecalho int(11) unsigned not null,
  id_produto int not null,
  numero_dav varchar(10) null,
  data_emissao date null,
  item int(11) unsigned null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_total decimal(18,6) null,
  cancelado char(1) null,
  mescla_produto char(1) null,
  gtin_produto varchar(14) null,
  nome_produto varchar(100) null,
  unidade_produto varchar(10) null,
  totalizador_parcial varchar(10) null,
  servico_formula text null,
  hash_registro varchar(32) null,
  primary key (id),
  index fk_dav_cab_det (id_dav_cabecalho asc),
  index fk_dav_detalhe_produto1_idx (id_produto asc),
  constraint fk_01af191ea00c44b195befca329907da1
    foreign key (id_dav_cabecalho)
    references dav_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_dav_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists pre_venda_cabecalho (
  id int(11) unsigned zerofill not null auto_increment,
  id_pessoa int not null,
  data_emissao date null,
  hora_emissao varchar(8) null,
  situacao char(1) null,
  ccf int(11) unsigned null,
  valor decimal(18,6) null,
  nome_destinatario varchar(100) null,
  cpf_cnpj_destinatario varchar(14) null,
  subtotal decimal(18,6) null,
  desconto decimal(18,6) null,
  acrescimo decimal(18,6) null,
  taxa_acrescimo decimal(18,6) null,
  taxa_desconto decimal(18,6) null,
  primary key (id),
  index fk_pre_venda_cabecalho_pessoa1_idx (id_pessoa asc),
  constraint fk_pre_venda_cabecalho_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists pre_venda_detalhe (
  id int(11) unsigned not null auto_increment,
  id_pre_venda_cabecalho int(11) unsigned zerofill not null,
  id_produto int not null,
  item int(11) null,
  quantidade decimal(18,6) null,
  valor_unitario decimal(18,6) null,
  valor_total decimal(18,6) null,
  cancelado char(1) null,
  gtin_produto varchar(14) null,
  nome_produto varchar(100) null,
  unidade_produto varchar(10) null,
  ecf_icms_st varchar(4) null,
  primary key (id),
  index fk_pre_venda_cab_det (id_pre_venda_cabecalho asc),
  index fk_pre_venda_detalhe_produto1_idx (id_produto asc),
  constraint fk_b35253d23ee9435c89116faa488c3baf
    foreign key (id_pre_venda_cabecalho)
    references pre_venda_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_pre_venda_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists contabil_fechamento (
  id int(11) unsigned not null auto_increment,
  data_inicio date null,
  data_fim date null,
  criterio_lancamento char(1) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_indice (
  id int(11) unsigned not null auto_increment,
  indice varchar(50) null,
  periodicidade char(1) not null,
  diario_a_partir_de date null,
  mensal_mes_ano varchar(7) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contabil_indice_valor (
  id int(11) unsigned not null auto_increment,
  id_contabil_indice int(11) unsigned not null,
  data_indice date null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_contabil_indice_valor (id_contabil_indice asc),
  constraint fk_7b3e8135bfc84495ad5362286eaac690
    foreign key (id_contabil_indice)
    references contabil_indice (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists quadro_societario (
  id int(11) unsigned not null auto_increment,
  data_registro date null,
  capital_social decimal(18,6) null,
  valor_quota decimal(18,6) null,
  quantidade_cotas int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
create table if not exists contrato_template (
  id int unsigned not null auto_increment,
  nome varchar(100) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ponto_banco_horas_utilizacao (
  id int(11) unsigned not null auto_increment,
  id_ponto_banco_horas int(11) unsigned not null,
  data_utilizacao date null,
  quantidade_utilizada varchar(8) null,
  observacao text null,
  primary key (id),
  index fk_banco_hora_utilizacao (id_ponto_banco_horas asc),
  constraint fk_95e38be788894039a9ef9b3f06c021c1
    foreign key (id_ponto_banco_horas)
    references ponto_banco_horas (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ponto_fechamento_jornada (
  id int(11) unsigned not null auto_increment,
  id_ponto_classificacao_jornada int(11) unsigned not null,
  id_colaborador int not null,
  data_fechamento date null,
  dia_semana varchar(7) null,
  codigo_horario char(4) null,
  carga_horaria_esperada varchar(8) null,
  carga_horaria_diurna varchar(8) null,
  carga_horaria_noturna varchar(8) null,
  carga_horaria_total varchar(8) null,
  entrada01 varchar(8) null,
  saida01 varchar(8) null,
  entrada02 varchar(8) null,
  saida02 varchar(8) null,
  entrada03 varchar(8) null,
  saida03 varchar(8) null,
  entrada04 varchar(8) null,
  saida04 varchar(8) null,
  entrada05 varchar(8) null,
  saida05 varchar(8) null,
  hora_inicio_jornada varchar(8) null,
  hora_fim_jornada varchar(8) null,
  hora_extra01 varchar(8) null,
  percentual_hora_extra01 decimal(18,6) null,
  modalidade_hora_extra01 char(1) null,
  hora_extra02 varchar(8) null,
  percentual_hora_extra02 decimal(18,6) null,
  modalidade_hora_extra02 char(1) null,
  hora_extra03 varchar(8) null,
  percentual_hora_extra03 decimal(18,6) null,
  modalidade_hora_extra03 char(1) null,
  hora_extra04 varchar(8) null,
  percentual_hora_extra04 decimal(18,6) null,
  modalidade_hora_extra04 char(1) null,
  falta_atraso varchar(8) null,
  compensar char(1) null,
  banco_horas varchar(8) null,
  observacao varchar(250) null,
  primary key (id),
  index fk_ponto_classificacao_jornada (id_ponto_classificacao_jornada asc),
  index fk_ponto_fechamento_jornada_colaborador1_idx (id_colaborador asc),
  constraint fk_46d9407683bd47cf81a8cfb7358e7852
    foreign key (id_ponto_classificacao_jornada)
    references ponto_classificacao_jornada (id)
    on delete no action
    on update no action,
  constraint fk_ponto_fechamento_jornada_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists adm_modulo (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  nome varchar(100) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ct_resultado_nt_financeira (
  id int(11) unsigned not null auto_increment,
  id_centro_resultado int(11) unsigned not null,
  id_fin_natureza_financeira int unsigned not null,
  percentual_rateio decimal(18,6) null,
  primary key (id),
  index fk_cr_nf (id_centro_resultado asc),
  index fk_ct_resultado_nt_financeira_fin_natureza_financeira1_idx (id_fin_natureza_financeira asc),
  constraint fk_858fce59ebde45c6ba90be4ee82f5897
    foreign key (id_centro_resultado)
    references centro_resultado (id)
    on delete no action
    on update no action,
  constraint fk_ct_resultado_nt_financeira_fin_natureza_financeira1
    foreign key (id_fin_natureza_financeira)
    references fin_natureza_financeira (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ecf_aliquotas (
  id int(11) unsigned not null auto_increment,
  totalizador_parcial varchar(10) null,
  ecf_icms_st varchar(4) null,
  paf_p_st char(1) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists auditoria (
  id int(11) unsigned not null auto_increment,
  data_registro date null,
  hora_registro varchar(8) null,
  janela_controller varchar(50) null,
  acao varchar(50) null,
  conteudo text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists produto_alteracao_item (
  id int(11) unsigned not null auto_increment,
  id_produto int not null,
  codigo varchar(14) null,
  nome varchar(100) null,
  data_inicial date null,
  data_final date null,
  primary key (id),
  index fk_produto_alteracao_item_produto1_idx (id_produto asc),
  constraint fk_produto_alteracao_item_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists fiscal_apuracao_icms (
  id int(11) unsigned not null auto_increment,
  competencia varchar(7) null,
  valor_total_debito decimal(18,6) null,
  valor_ajuste_debito decimal(18,6) null,
  valor_total_ajuste_debito decimal(18,6) null,
  valor_estorno_credito decimal(18,6) null,
  valor_total_credito decimal(18,6) null,
  valor_ajuste_credito decimal(18,6) null,
  valor_total_ajuste_credito decimal(18,6) null,
  valor_estorno_debito decimal(18,6) null,
  valor_saldo_credor_anterior decimal(18,6) null,
  valor_saldo_apurado decimal(18,6) null,
  valor_total_deducao decimal(18,6) null,
  valor_icms_recolher decimal(18,6) null,
  valor_saldo_credor_transp decimal(18,6) null,
  valor_debito_especial decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists fiscal_nota_fiscal_saida (
  id int(11) unsigned not null auto_increment,
  id_nfe_cabecalho int unsigned not null,
  competencia varchar(7) null,
  primary key (id),
  index fk_fiscal_nota_fiscal_saida_nfe_cabecalho1_idx (id_nfe_cabecalho asc),
  constraint fk_fiscal_nota_fiscal_saida_nfe_cabecalho1
    foreign key (id_nfe_cabecalho)
    references nfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists ecf_sintegra_60m (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(8) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  data_emissao date null,
  numero_serie_ecf varchar(20) null,
  numero_equipamento int(11) unsigned null,
  modelo_documento_fiscal char(2) null,
  coo_inicial int(11) unsigned null,
  coo_final int(11) unsigned null,
  crz int(11) unsigned null,
  cro int(11) unsigned null,
  valor_venda_bruta decimal(18,6) null,
  valor_grande_total decimal(18,6) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_sintegra_60a (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(8) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_ecf_sintegra_60m int(11) unsigned null,
  situacao_tributaria varchar(4) null,
  valor decimal(18,6) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(32) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists adm_parametro (
  id int(11) unsigned not null auto_increment,
  fin_parcela_aberto int(11) unsigned null,
  fin_parcela_quitado int(11) unsigned null,
  fin_parcela_quitado_parcial int(11) unsigned null,
  fin_tipo_recebimento_edi int(11) unsigned null,
  compra_fin_doc_origem int(11) unsigned null,
  compra_conta_caixa int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
create table if not exists ecf_e3 (
  id int(11) unsigned not null auto_increment,
  serie_ecf varchar(20) null,
  mf_adicional char(1) null,
  tipo_ecf varchar(7) null,
  marca_ecf varchar(20) null,
  modelo_ecf varchar(20) null,
  data_estoque date null,
  hora_estoque varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pessoa_alteracao (
  id int(11) unsigned not null auto_increment,
  id_pessoa int not null,
  data_alteracao date null,
  objeto_antigo text null,
  objeto_novo text null,
  primary key (id),
  index fk_pessoa_alteracao_pessoa1_idx (id_pessoa asc),
  constraint fk_pessoa_alteracao_pessoa1
    foreign key (id_pessoa)
    references pessoa (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists dav_detalhe_alteracao (
  id int(11) unsigned not null auto_increment,
  id_dav_detalhe int(11) unsigned not null,
  data_alteracao date null,
  hora_alteracao varchar(8) null,
  tipo_alteracao char(1) null,
  objeto text null,
  primary key (id),
  index dav_detalhe_alteracao_fkindex1 (id_dav_detalhe asc),
  constraint fk_38eb7611f5364209befdee739d12e364
    foreign key (id_dav_detalhe)
    references dav_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists pdv_sangria (
  id int(11) unsigned not null auto_increment,
  nome_caixa varchar(30) null,
  id_gerado_caixa int(11) unsigned null,
  id_empresa int(11) unsigned null,
  id_pdv_movimento int(11) unsigned null,
  data_sangria date null,
  valor decimal(18,6) null,
  data_sincronizacao date null,
  hora_sincronizacao varchar(8) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists malote_digital_documento (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  nome varchar(100) null,
  nome_arquivo int(11) unsigned null,
  formato char(3) null,
  tamanho int(11) unsigned null,
  assinado char(1) null,
  data_envio date null,
  assunto varchar(100) null,
  primary key (id),
  index fk_malote_digital_documento_colaborador1_idx (id_colaborador asc),
  constraint fk_malote_digital_documento_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists malote_digital_destinatario (
  id int(11) unsigned not null auto_increment,
  id_malote_digital_documento int(11) unsigned not null,
  id_colaborador int not null,
  primary key (id),
  index fk_malote_digital_dest (id_malote_digital_documento asc),
  index fk_malote_digital_destinatario_colaborador1_idx (id_colaborador asc),
  constraint fk_f02d780c73d742a1b054410048c997d8
    foreign key (id_malote_digital_documento)
    references malote_digital_documento (id)
    on delete no action
    on update no action,
  constraint fk_malote_digital_destinatario_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists malote_digital_acesso (
  id int(11) unsigned not null auto_increment,
  id_malote_digital_destinatario int(11) unsigned not null,
  data_acesso date null,
  hora_acesso varchar(8) null,
  primary key (id),
  index fk_malote_dig_dest_acesso (id_malote_digital_destinatario asc),
  constraint fk_040820c89ab647e28a77b292404c61d4
    foreign key (id_malote_digital_destinatario)
    references malote_digital_destinatario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists etiqueta_formato_papel (
  id int(11) unsigned not null auto_increment,
  nome varchar(50) null,
  altura int(11) unsigned null,
  largura int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
create table if not exists etiqueta_layout (
  id int(11) unsigned not null auto_increment,
  id_formato_papel int(11) unsigned not null,
  codigo_fabricante varchar(50) null,
  quantidade int(11) unsigned null,
  quantidade_horizontal int(11) unsigned null,
  quantidade_vertical int(11) unsigned null,
  margem_superior int(11) unsigned null,
  margem_inferior int(11) unsigned null,
  margem_esquerda int(11) unsigned null,
  margem_direita int(11) unsigned null,
  espacamento_horizontal int(11) unsigned null,
  espacamento_vertical int(11) unsigned null,
  primary key (id),
  index fk_papel_etiqueta (id_formato_papel asc),
  constraint fk_870db90a13724e58b205c25bb2c7365f
    foreign key (id_formato_papel)
    references etiqueta_formato_papel (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists etiqueta_template (
  id int(11) unsigned not null auto_increment,
  id_etiqueta_layout int(11) unsigned not null,
  tabela varchar(50) null,
  campo varchar(50) null,
  formato int(11) unsigned null,
  quantidade_repeticoes int(11) unsigned null,
  filtro varchar(100) null,
  primary key (id),
  index fk_etiqueta_template (id_etiqueta_layout asc),
  constraint fk_433b10d13f6e494bad5edbf791dfa501
    foreign key (id_etiqueta_layout)
    references etiqueta_layout (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists agenda_categoria_compromisso (
  id int(11) unsigned not null auto_increment,
  nome varchar(100) null,
  cor varchar(50) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists agenda_compromisso (
  id int(11) unsigned not null auto_increment,
  id_agenda_categoria_compromisso int(11) unsigned not null,
  id_colaborador int not null,
  data_compromisso date null,
  hora varchar(8) null,
  duracao int(11) unsigned null,
  onde varchar(100) null,
  descricao varchar(100) null,
  tipo char(1) null,
  primary key (id),
  index fk_categoria_compromisso (id_agenda_categoria_compromisso asc),
  index fk_agenda_compromisso_colaborador1_idx (id_colaborador asc),
  constraint fk_fc82468133d04247bfdf526a153cd722
    foreign key (id_agenda_categoria_compromisso)
    references agenda_categoria_compromisso (id)
    on delete no action
    on update no action,
  constraint fk_agenda_compromisso_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists agenda_notificacao (
  id int(11) unsigned not null auto_increment,
  id_agenda_compromisso int(11) unsigned not null,
  data_notificacao date null,
  hora varchar(8) null,
  tipo int(11) unsigned null,
  primary key (id),
  index fk_compromisso_notificacao (id_agenda_compromisso asc),
  constraint fk_399131fd404b48bfaf89c823dd44767f
    foreign key (id_agenda_compromisso)
    references agenda_compromisso (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists agenda_compromisso_convidado (
  id int(11) unsigned not null auto_increment,
  id_agenda_compromisso int(11) unsigned not null,
  id_colaborador int not null,
  primary key (id),
  index fk_compromisso_convidado (id_agenda_compromisso asc),
  index fk_agenda_compromisso_convidado_colaborador1_idx (id_colaborador asc),
  constraint fk_4e85396e52a346e086bae662be304e59
    foreign key (id_agenda_compromisso)
    references agenda_compromisso (id)
    on delete no action
    on update no action,
  constraint fk_agenda_compromisso_convidado_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists reuniao_sala (
  id int(11) unsigned not null auto_increment,
  predio varchar(100) null,
  andar varchar(10) null,
  numero varchar(10) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists reuniao_sala_evento (
  id int(11) unsigned not null auto_increment,
  id_agenda_compromisso int(11) unsigned not null,
  id_reuniao_sala int(11) unsigned not null,
  data_reserva date null,
  primary key (id),
  index fk_sala_evento (id_reuniao_sala asc),
  index fk_compromisso_sala (id_agenda_compromisso asc),
  constraint fk_166e3aab2db544fcbcde62d0e052ad18
    foreign key (id_reuniao_sala)
    references reuniao_sala (id)
    on delete no action
    on update no action,
  constraint fk_c71e2edc9c694a00abbd5127b0e9fba0
    foreign key (id_agenda_compromisso)
    references agenda_compromisso (id)
    on delete no action
    on update no action) 
 engine = innodb; 
create table if not exists recado_remetente (
  id int(11) unsigned not null auto_increment,
  id_colaborador int not null,
  data_envio date null,
  hora_envio varchar(8) null,
  assunto varchar(100) null,
  texto text null,
  primary key (id),
  index fk_recado_remetente_colaborador1_idx (id_colaborador asc),
  constraint fk_recado_remetente_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists recado_destinatario (
  id int(11) unsigned not null auto_increment,
  id_recado_remetente int(11) unsigned not null,
  id_colaborador int not null,
  primary key (id),
  index fk_recado_rem_dest (id_recado_remetente asc),
  index fk_recado_destinatario_colaborador1_idx (id_colaborador asc),
  constraint fk_0e54bf3467ce451eb4a0778d89f84d5f
    foreign key (id_recado_remetente)
    references recado_remetente (id)
    on delete no action
    on update no action,
  constraint fk_recado_destinatario_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists esocial_natureza_juridica (
  id int(11) unsigned not null auto_increment,
  grupo int(11) unsigned null,
  codigo varchar(5) null,
  descricao varchar(100) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists esocial_classificacao_tribut (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  descricao varchar(100) null,
  primary key (id)) 
 engine = innodb; 
create table if not exists esocial_rubrica (
  id int(11) unsigned not null auto_increment,
  codigo char(4) null,
  nome varchar(100) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists esocial_tipo_afastamento (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists esocial_motivo_desligamento (
  id int(11) unsigned not null auto_increment,
  codigo char(2) null,
  descricao text null,
  primary key (id)) 
 engine = innodb; 
create table if not exists pcp_op_cabecalho (
  id int(11) unsigned not null auto_increment,
  inicio date null,
  previsao_entrega date null,
  termino date null,
  custo_total_previsto decimal(18,6) null,
  custo_total_realizado decimal(18,6) null,
  porcento_venda decimal(18,6) null,
  porcento_estoque decimal(18,6) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists pcp_op_detalhe (
  id int(11) unsigned not null auto_increment,
  id_pcp_op_cabecalho int(11) unsigned not null,
  id_produto int not null,
  quantidade_produzir decimal(18,6) null,
  quantidade_produzida decimal(18,6) null,
  quantidade_entregue decimal(18,6) null,
  custo_previsto decimal(18,6) null,
  custo_realizado decimal(18,6) null,
  primary key (id),
  index fk_pcp_op_cab_det (id_pcp_op_cabecalho asc),
  index fk_pcp_op_detalhe_produto1_idx (id_produto asc),
  constraint fk_38bb45ea9d0e47dda72f3fa45738d406
    foreign key (id_pcp_op_cabecalho)
    references pcp_op_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_pcp_op_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists pcp_servico (
  id int(11) unsigned not null auto_increment,
  id_pcp_op_detalhe int(11) unsigned not null,
  inicio_realizado date null,
  termino_realizado date null,
  horas_realizado int(11) unsigned null,
  minutos_realizado int(11) unsigned null,
  segundos_realizado int(11) unsigned null,
  custo_realizado decimal(18,6) null,
  inicio_previsto date null,
  termino_previsto date null,
  horas_previsto int(11) unsigned null,
  minutos_previsto int(11) unsigned null,
  segundos_previsto int(11) unsigned null,
  custo_previsto decimal(18,6) null,
  primary key (id),
  index fk_pcp_servico_realizado (id_pcp_op_detalhe asc),
  constraint fk_8826f024b03d4d578619410c8743c47b
    foreign key (id_pcp_op_detalhe)
    references pcp_op_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists pcp_servico_colaborador (
  id int(11) unsigned not null auto_increment,
  id_pcp_servico int(11) unsigned not null,
  id_colaborador int not null,
  primary key (id),
  index fk_pcp_servico_colaborador (id_pcp_servico asc),
  index fk_pcp_servico_colaborador_colaborador1_idx (id_colaborador asc),
  constraint fk_664764e534884030bfb115e4d34a5446
    foreign key (id_pcp_servico)
    references pcp_servico (id)
    on delete no action
    on update no action,
  constraint fk_pcp_servico_colaborador_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists pcp_instrucao (
  id int(11) unsigned not null auto_increment,
  codigo char(3) null,
  descricao varchar(100) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists pcp_instrucao_op (
  id int(11) unsigned not null auto_increment,
  id_pcp_instrucao int(11) unsigned not null,
  id_pcp_op_cabecalho int(11) unsigned not null,
  primary key (id),
  index fk_pcp_op_instrucao (id_pcp_op_cabecalho asc),
  index fk_pcp_instrucao_op (id_pcp_instrucao asc),
  constraint fk_7c1e7e45beb54de3ad45217b1c481440
    foreign key (id_pcp_op_cabecalho)
    references pcp_op_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_1711bd286b33449f8c2fe6cdbfcef130
    foreign key (id_pcp_instrucao)
    references pcp_instrucao (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists pcp_servico_equipamento (
  id int(11) unsigned not null auto_increment,
  id_patrim_bem int(11) unsigned not null,
  id_pcp_servico int(11) unsigned not null,
  primary key (id),
  index fk_pcp_serv_equip (id_pcp_servico asc),
  index fk_pcp_equip_serv (id_patrim_bem asc),
  constraint fk_6d48a2c92a214a7ab1a54882369d9e49
    foreign key (id_pcp_servico)
    references pcp_servico (id)
    on delete no action
    on update no action,
  constraint fk_34e8fab188f54369a7e00edfd616f5eb
    foreign key (id_patrim_bem)
    references patrim_bem (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists wms_agendamento (
  id int(11) unsigned not null auto_increment,
  data_operacao date null,
  hora_operacao varchar(8) null,
  local_operacao varchar(100) null,
  quantidade_volume int(11) unsigned null,
  peso_total_volume decimal(18,6) null,
  quantidade_pessoa int(11) unsigned null,
  quantidade_hora int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists wms_parametro (
  id int(11) unsigned not null auto_increment,
  hora_por_volume int(11) unsigned null,
  pessoa_por_volume int(11) unsigned null,
  hora_por_peso int(11) unsigned null,
  pessoa_por_peso int(11) unsigned null,
  item_diferente_caixa char(1) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists wms_recebimento_cabecalho (
  id int(11) unsigned not null auto_increment,
  id_wms_agendamento int(11) unsigned not null,
  data_recebimento date null,
  hora_inicio varchar(8) null,
  hora_fim varchar(8) null,
  volume_recebido int(11) unsigned null,
  peso_recebido decimal(18,6) null,
  inconsistencia char(1) null,
  observacao text null,
  primary key (id),
  index fk_wms_agenda_recebe (id_wms_agendamento asc),
  constraint fk_8b28efa0d32c4aacb55c219a5f910e4b
    foreign key (id_wms_agendamento)
    references wms_agendamento (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists wms_recebimento_detalhe (
  id int(11) unsigned not null auto_increment,
  id_wms_recebimento_cabecalho int(11) unsigned not null,
  id_produto int not null,
  quantidade_volume int(11) unsigned null,
  quantidade_item_por_volume int(11) unsigned null,
  quantidade_recebida int(11) unsigned null,
  destino char(1) null,
  primary key (id),
  index fk_wms_rec_cab_det (id_wms_recebimento_cabecalho asc),
  index fk_wms_recebimento_detalhe_produto1_idx (id_produto asc),
  constraint fk_25a6ac1d7a1e4f97aac7246cc689d258
    foreign key (id_wms_recebimento_cabecalho)
    references wms_recebimento_cabecalho (id)
    on delete no action
    on update no action,
  constraint fk_wms_recebimento_detalhe_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists wms_rua (
  id int(11) unsigned not null auto_increment,
  codigo varchar(10) null,
  nome varchar(100) null,
  quantidade_estante int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists wms_estante (
  id int(11) unsigned not null auto_increment,
  id_wms_rua int(11) unsigned not null,
  codigo varchar(10) null,
  quantidade_caixa int(11) unsigned null,
  primary key (id),
  index fk_wms_rua_estante (id_wms_rua asc),
  constraint fk_54ed3a4a06854eada483fb2085c30584
    foreign key (id_wms_rua)
    references wms_rua (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists wms_caixa (
  id int(11) unsigned not null auto_increment,
  id_wms_estante int(11) unsigned not null,
  codigo varchar(10) null,
  altura int(11) unsigned null,
  largura int(11) unsigned null,
  profundidade int(11) unsigned null,
  primary key (id),
  index fk_wms_estante_caixa (id_wms_estante asc),
  constraint fk_1716794bb0d84c32b29a8322e86a49f3
    foreign key (id_wms_estante)
    references wms_estante (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists wms_armazenamento (
  id int(11) unsigned not null auto_increment,
  id_wms_caixa int(11) unsigned not null,
  id_wms_recebimento_detalhe int(11) unsigned not null,
  quantidade int(11) unsigned null,
  primary key (id),
  index fk_caixa_armazena (id_wms_caixa asc),
  index fk_rece_armazena (id_wms_recebimento_detalhe asc),
  constraint fk_734ff4e6a808433aab1584f96c5547ea
    foreign key (id_wms_caixa)
    references wms_caixa (id)
    on delete no action
    on update no action,
  constraint fk_7be115cd47dc43bcb71a9767fbcc9e9d
    foreign key (id_wms_recebimento_detalhe)
    references wms_recebimento_detalhe (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists wms_ordem_separacao_cab (
  id int(11) unsigned not null auto_increment,
  origem char(1) null,
  data_solicitacao date null,
  data_limite date null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists wms_ordem_separacao_det (
  id int(11) unsigned not null auto_increment,
  id_wms_ordem_separacao_cab int(11) unsigned not null,
  id_produto int not null,
  quantidade int(11) unsigned null,
  primary key (id),
  index fk_wms_os_cab_det (id_wms_ordem_separacao_cab asc),
  index fk_wms_ordem_separacao_det_produto1_idx (id_produto asc),
  constraint fk_9a2509d6849e46368bd3a38f16b050b0
    foreign key (id_wms_ordem_separacao_cab)
    references wms_ordem_separacao_cab (id)
    on delete no action
    on update no action,
  constraint fk_wms_ordem_separacao_det_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists wms_expedicao (
  id int(11) unsigned not null auto_increment,
  id_wms_ordem_separacao_det int(11) unsigned not null,
  id_wms_armazenamento int(11) unsigned not null,
  quantidade int(11) unsigned null,
  data_saida date null,
  primary key (id),
  index fk_wms_armaz_exped (id_wms_armazenamento asc),
  index fk_wms_os_det_exped (id_wms_ordem_separacao_det asc),
  constraint fk_2ade2a797150491583a19d60624ae78a
    foreign key (id_wms_armazenamento)
    references wms_armazenamento (id)
    on delete no action
    on update no action,
  constraint fk_466260291fd941a499bc3883e02c29a1
    foreign key (id_wms_ordem_separacao_det)
    references wms_ordem_separacao_det (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists ibpt (
  id int(10) unsigned not null auto_increment,
  ncm varchar(8) null,
  ex char(2) null,
  tipo char(1) null,
  descricao text null,
  nacional_federal decimal(18,6) null,
  importados_federal decimal(18,6) null,
  estadual decimal(18,6) null,
  municipal decimal(18,6) null,
  vigencia_inicio date null,
  vigencia_fim date null,
  chave varchar(6) null,
  versao varchar(6) null,
  fonte varchar(34) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists mdfe_cabecalho (
  id int(11) unsigned not null auto_increment,
  uf int(11) unsigned null,
  tipo_ambiente int(11) unsigned null,
  tipo_emitente int(11) unsigned null,
  tipo_transportadora int(11) unsigned null,
  modelo char(2) null,
  serie varchar(3) null,
  numero_mdfe varchar(9) null,
  codigo_numerico varchar(8) null,
  chave_acesso varchar(44) null,
  digito_verificador int null,
  modal int(11) unsigned null,
  data_hora_emissao timestamp null,
  tipo_emissao int(11) unsigned null,
  processo_emissao int(11) unsigned null,
  versao_processo_emissao varchar(20) null,
  uf_inicio char(2) null,
  uf_fim char(2) null,
  data_hora_previsao_viagem timestamp null,
  quantidade_total_cte int(11) unsigned null,
  quantidade_total_nfe int(11) unsigned null,
  quantidade_total_mdfe int(11) unsigned null,
  codigo_unidade_medida char(2) null,
  peso_bruto_carga decimal(18,6) null,
  valor_carga decimal(18,6) null,
  numero_protocolo varchar(15) null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists mdfe_lacre (
  id int(11) unsigned not null auto_increment,
  id_mdfe_cabecalho int(11) unsigned not null,
  numero_lacre varchar(20) null,
  primary key (id),
  index fk_mdfe_lacre (id_mdfe_cabecalho asc),
  constraint fk_11dfa71dcdd94355b6079ef9fb3034f1
    foreign key (id_mdfe_cabecalho)
    references mdfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_municipio_descarrega (
  id int(11) unsigned not null auto_increment,
  id_mdfe_cabecalho int(11) unsigned not null,
  nome_municipio varchar(60) null,
  codigo_municipio varchar(7) null,
  primary key (id),
  index fk_mdfe_municipio_descarregamento (id_mdfe_cabecalho asc),
  constraint fk_cc00c9563de944e1aa5117d2000ee6c1
    foreign key (id_mdfe_cabecalho)
    references mdfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_informacao_cte (
  id int(11) unsigned not null auto_increment,
  id_mdfe_municipio_descarrega int(11) unsigned not null,
  chave_cte varchar(44) null,
  segundo_codigo_barra varchar(36) null,
  indicador_reentrega int(11) unsigned null,
  primary key (id),
  index fk_mdfe_informacao_cte (id_mdfe_municipio_descarrega asc),
  constraint fk_433cd8d0d22e4e1cbd4a4b4ec39a50e3
    foreign key (id_mdfe_municipio_descarrega)
    references mdfe_municipio_descarrega (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_informacao_nfe (
  id int(11) unsigned not null auto_increment,
  id_mdfe_municipio_descarrega int(11) unsigned not null,
  chave_nfe varchar(44) null,
  segundo_codigo_barra varchar(36) null,
  indicador_reentrega int(11) unsigned null,
  primary key (id),
  index fk_mdfe_informacao_nfe (id_mdfe_municipio_descarrega asc),
  constraint fk_d3b14fcd37de4878849300fcd857a050
    foreign key (id_mdfe_municipio_descarrega)
    references mdfe_municipio_descarrega (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_emitente (
  id int(11) unsigned not null auto_increment,
  id_mdfe_cabecalho int(11) unsigned not null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  cnpj varchar(14) null,
  ie int(11) unsigned null,
  logradouro varchar(60) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio varchar(7) null,
  nome_municipio varchar(60) null,
  cep varchar(8) null,
  uf char(2) null,
  telefone varchar(12) null,
  email varchar(60) null,
  primary key (id),
  index fk_mdfe_cab_emit (id_mdfe_cabecalho asc),
  constraint fk_bc2f739273cf4aefa3514c51f4407448
    foreign key (id_mdfe_cabecalho)
    references mdfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_percurso (
  id int(11) unsigned not null auto_increment,
  id_mdfe_cabecalho int(11) unsigned not null,
  uf_percurso char(2) null,
  data_inicio_viagem date null,
  primary key (id),
  index fk_mdfe_percurso (id_mdfe_cabecalho asc),
  constraint fk_453dd9e0098440c38b6145d63ec9ed04
    foreign key (id_mdfe_cabecalho)
    references mdfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_municipio_carregamento (
  id int(11) unsigned not null auto_increment,
  id_mdfe_cabecalho int(11) unsigned not null,
  nome_municipio varchar(60) null,
  codigo_municipio varchar(7) null,
  primary key (id),
  index fk_mdfe_municipio_carregamento (id_mdfe_cabecalho asc),
  constraint fk_33283b7abb2c46e39c4658cde9d5a014
    foreign key (id_mdfe_cabecalho)
    references mdfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_rodoviario (
  id int(11) unsigned not null auto_increment,
  id_mdfe_cabecalho int(11) unsigned not null,
  rntrc varchar(8) null,
  codigo_agendamento varchar(16) null,
  primary key (id),
  index fk_mdfe_cab_rodo (id_mdfe_cabecalho asc),
  constraint fk_d84e9ff2a5ea4c9db2120ece0aa9e7e5
    foreign key (id_mdfe_cabecalho)
    references mdfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_rodoviario_motorista (
  id int(11) unsigned not null auto_increment,
  id_mdfe_rodoviario int(11) unsigned not null,
  nome varchar(60) null,
  cpf varchar(11) null,
  primary key (id),
  index fk_mdfe_rodoviario_motorista (id_mdfe_rodoviario asc),
  constraint fk_935170e7782941999f7310bac5597794
    foreign key (id_mdfe_rodoviario)
    references mdfe_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_rodoviario_veiculo (
  id int(11) unsigned not null auto_increment,
  id_mdfe_rodoviario int(11) unsigned not null,
  codigo_interno varchar(10) null,
  placa varchar(7) null,
  renavam varchar(11) null,
  tara int(11) unsigned zerofill null,
  capacidade_kg int(11) unsigned null,
  capacidade_m3 int(11) unsigned null,
  tipo_rodado char(2) null,
  tipo_carroceria char(2) null,
  uf_licenciamento char(2) null,
  proprietario_cpf varchar(11) null,
  proprietario_cnpj varchar(14) null,
  proprietario_rntrc varchar(8) null,
  proprietario_nome varchar(60) null,
  proprietario_ie varchar(2) null,
  proprietario_tipo int(11) unsigned null,
  primary key (id),
  index fk_mdfe_rodoviario_veiculo (id_mdfe_rodoviario asc),
  constraint fk_b32e660b84f3483394954a51c0513400
    foreign key (id_mdfe_rodoviario)
    references mdfe_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_informacao_seguro (
  id int(11) unsigned not null auto_increment,
  id_mdfe_cabecalho int(11) unsigned not null,
  responsavel int(11) unsigned null,
  cnpj_cpf varchar(14) null,
  seguradora varchar(11) null,
  cnpj_seguradora varchar(14) null,
  apolice varchar(20) null,
  averbacao varchar(40) null,
  primary key (id),
  index fk_mdfe_informacao_seguro (id_mdfe_cabecalho asc),
  constraint fk_a88ca6d6c1614cd1b1dea51628ec6cba
    foreign key (id_mdfe_cabecalho)
    references mdfe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_rodoviario_pedagio (
  id int(11) unsigned not null auto_increment,
  id_mdfe_rodoviario int(11) unsigned not null,
  cnpj_fornecedor varchar(14) null,
  cnpj_responsavel varchar(14) null,
  cpf_responsavel varchar(11) null,
  numero_comprovante varchar(20) null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_mdfe_rodoviario_pedagio (id_mdfe_rodoviario asc),
  constraint fk_dffaaed97a4c4738a240cee1d14b9113
    foreign key (id_mdfe_rodoviario)
    references mdfe_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists mdfe_rodoviario_ciot (
  id int(11) unsigned not null auto_increment,
  id_mdfe_rodoviario int(11) unsigned not null,
  ciot varchar(12) null,
  cpf varchar(11) null,
  cnpj varchar(14) null,
  primary key (id),
  index fk_mdfe_rod_ciot (id_mdfe_rodoviario asc),
  constraint fk_072b68bd2b5c4b82bcfe5e424c22d7ba
    foreign key (id_mdfe_rodoviario)
    references mdfe_rodoviario (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists frota_veiculo_tipo (
  id int not null auto_increment,
  codigo char(2) null,
  nome varchar(100) null,
  primary key (id))
engine = innodb;
create table if not exists frota_combustivel_tipo (
  id int not null auto_increment,
  codigo char(2) null,
  nome varchar(100) null,
  primary key (id))
engine = innodb;
create table if not exists frota_veiculo (
  id int not null auto_increment,
  id_frota_veiculo_tipo int not null,
  id_frota_combustivel_tipo int not null,
  renavam varchar(11) null,
  ipva_mes_vencimento char(2) null,
  dpvat_mes_vencimento char(2) null,
  placa varchar(7) null,
  marca varchar(100) null,
  modelo varchar(100) null,
  modelo_ano char(4) null,
  codigo_fipe varchar(7) null,
  primary key (id),
  index fk_frota_veiculo_frota_veiculo_tipo1_idx (id_frota_veiculo_tipo asc),
  index fk_frota_veiculo_frota_combustivel_tipo1_idx (id_frota_combustivel_tipo asc),
  constraint fk_frota_veiculo_frota_veiculo_tipo1
    foreign key (id_frota_veiculo_tipo)
    references frota_veiculo_tipo (id)
    on delete no action
    on update no action,
  constraint fk_frota_veiculo_frota_combustivel_tipo1
    foreign key (id_frota_combustivel_tipo)
    references frota_combustivel_tipo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_ipva_controle (
  id int not null auto_increment,
  id_frota_veiculo int not null,
  parcela char(2) null,
  data_vencimento date null,
  data_pagamento date null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_frota_ipva_controle_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_ipva_controle_frota_veiculo1
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_dpvat_controle (
  id int not null auto_increment,
  id_frota_veiculo int not null,
  parcela char(2) null,
  data_vencimento date null,
  data_pagamento date null,
  valor decimal(18,6) null,
  primary key (id),
  index fk_frota_ipva_controle_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_ipva_controle_frota_veiculo10
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_motorista (
  id int not null auto_increment,
  id_pessoa_fisica int not null,
  numero_cnh varchar(11) null,
  cnh_categoria char(2) null,
  primary key (id),
  index fk_frota_motorista_pessoa_fisica1_idx (id_pessoa_fisica asc),
  constraint fk_frota_motorista_pessoa_fisica1
    foreign key (id_pessoa_fisica)
    references pessoa_fisica (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_veiculo_sinistro (
  id int not null auto_increment,
  id_frota_veiculo int not null,
  data_sinistro date null,
  observacao text null,
  primary key (id),
  index fk_frota_sinistro_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_sinistro_frota_veiculo1
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_veiculo_movimentacao (
  id int not null auto_increment,
  id_frota_motorista int not null,
  id_frota_veiculo int not null,
  data_saida date null,
  hora_saida varchar(8) null,
  data_entrada date null,
  hora_entrada varchar(8) null,
  observacao text null,
  primary key (id),
  index fk_frota_veiculo_movimentacao_frota_motorista1_idx (id_frota_motorista asc),
  index fk_frota_veiculo_movimentacao_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_veiculo_movimentacao_frota_motorista1
    foreign key (id_frota_motorista)
    references frota_motorista (id)
    on delete no action
    on update no action,
  constraint fk_frota_veiculo_movimentacao_frota_veiculo1
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_veiculo_pneu (
  id int not null auto_increment,
  data_troca date null,
  valor_troca decimal(18,6) null,
  posicao_pneu varchar(100) null,
  marca_pneu varchar(100) null,
  id_frota_veiculo int not null,
  primary key (id),
  index fk_frota_veiculo_pneu_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_veiculo_pneu_frota_veiculo1
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_veiculo_manutencao (
  id int not null auto_increment,
  id_frota_veiculo int not null,
  tipo char(1) null,
  data_manutencao date null,
  valor_manutencao decimal(18,6) null,
  observacao text null,
  primary key (id),
  index fk_frota_veiculo_manutencao_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_veiculo_manutencao_frota_veiculo1
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_multa_controle (
  id int not null auto_increment,
  id_frota_veiculo int not null,
  data_multa date null,
  pontos int null,
  valor decimal(18,6) null,
  observacao text null,
  primary key (id),
  index fk_frota_multa_controle_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_multa_controle_frota_veiculo1
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists frota_combustivel_controle (
  id int not null auto_increment,
  id_frota_veiculo int not null,
  data_abastecimento date null,
  hora_abastecimento varchar(8) null,
  valor_abastecimento decimal(18,6) null,
  primary key (id),
  index fk_frota_combustivel_controle_frota_veiculo1_idx (id_frota_veiculo asc),
  constraint fk_frota_combustivel_controle_frota_veiculo1
    foreign key (id_frota_veiculo)
    references frota_veiculo (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists gondola_rua (
  id int(11) unsigned not null auto_increment,
  codigo varchar(10) null,
  nome varchar(100) null,
  quantidade_estante int(11) unsigned null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists gondola_estante (
  id int(11) unsigned not null auto_increment,
  id_gondola_rua int(11) unsigned not null,
  codigo varchar(10) null,
  quantidade_caixa int(11) unsigned null,
  primary key (id),
  index fk_wms_rua_estante (id_gondola_rua asc),
  constraint fk_54ed3a4a06854eada483fb2085c305840
    foreign key (id_gondola_rua)
    references gondola_rua (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists gondola_caixa (
  id int(11) unsigned not null auto_increment,
  id_gondola_estante int(11) unsigned not null,
  codigo varchar(10) null,
  altura int(11) unsigned null,
  largura int(11) unsigned null,
  profundidade int(11) unsigned null,
  primary key (id),
  index fk_wms_estante_caixa (id_gondola_estante asc),
  constraint fk_1716794bb0d84c32b29a8322e86a49f30
    foreign key (id_gondola_estante)
    references gondola_estante (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists gondola_armazenamento (
  id int(11) unsigned not null auto_increment,
  id_gondola_caixa int(11) unsigned not null,
  id_produto int not null,
  quantidade int(11) unsigned null,
  primary key (id),
  index fk_caixa_armazena (id_gondola_caixa asc),
  index fk_gondola_armazenamento_produto1_idx (id_produto asc),
  constraint fk_734ff4e6a808433aab1584f96c5547ea0
    foreign key (id_gondola_caixa)
    references gondola_caixa (id)
    on delete no action
    on update no action,
  constraint fk_gondola_armazenamento_produto1
    foreign key (id_produto)
    references produto (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists projeto_principal (
  id int not null auto_increment,
  nome varchar(100) null,
  data_inicio date null,
  data_previsao_fim date null,
  data_fim date null,
  link_quadro_trello varchar(100) null,
  valor_orcamento decimal(18,6) null,
  observacao text null,
  primary key (id))
engine = innodb;
create table if not exists projeto_cronograma (
  id int not null auto_increment,
  id_projeto_principal int not null,
  tarefa varchar(100) null,
  data_tarefa date null,
  descricao text null,
  primary key (id),
  index fk_projeto_cronograma_projeto_dados1_idx (id_projeto_principal asc),
  constraint fk_projeto_cronograma_projeto_dados1
    foreign key (id_projeto_principal)
    references projeto_principal (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists projeto_stakeholders (
  id int not null auto_increment,
  id_projeto_dados int not null,
  id_colaborador int not null,
  primary key (id),
  index fk_projeto_stakeholders_projeto_dados1_idx (id_projeto_dados asc),
  index fk_projeto_stakeholders_colaborador1_idx (id_colaborador asc),
  constraint fk_projeto_stakeholders_projeto_dados1
    foreign key (id_projeto_dados)
    references projeto_principal (id)
    on delete no action
    on update no action,
  constraint fk_projeto_stakeholders_colaborador1
    foreign key (id_colaborador)
    references colaborador (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists projeto_risco (
  id int not null auto_increment,
  id_projeto_principal int not null,
  nome varchar(100) null,
  descricao text null,
  probabilidade int null,
  impacto int null,
  primary key (id),
  index fk_projeto_risco_projeto_principal1_idx (id_projeto_principal asc),
  constraint fk_projeto_risco_projeto_principal1
    foreign key (id_projeto_principal)
    references projeto_principal (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists projeto_custo (
  id int not null auto_increment,
  id_projeto_principal int not null,
  id_fin_natureza_financeira int unsigned not null,
  nome varchar(100) null,
  justificativa text null,
  valor_mensal decimal(18,6) null,
  valor_total decimal(18,6) null,
  primary key (id),
  index fk_projeto_custo_projeto_principal1_idx (id_projeto_principal asc),
  index fk_projeto_custo_fin_natureza_financeira1_idx (id_fin_natureza_financeira asc),
  constraint fk_projeto_custo_projeto_principal1
    foreign key (id_projeto_principal)
    references projeto_principal (id)
    on delete no action
    on update no action,
  constraint fk_projeto_custo_fin_natureza_financeira1
    foreign key (id_fin_natureza_financeira)
    references fin_natureza_financeira (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists bpe_cabecalho (
  id int unsigned not null auto_increment,
  uf_emitente int unsigned null,
  ambiente char(1) null,
  modelo char(2) null,
  serie char(3) null,
  numero varchar(9) null,
  codigo_numerico varchar(8) null,
  chave_acesso varchar(44) null,
  digito_chave_acesso char(1) null,
  modal char(2) null,
  data_hora_emissao timestamp null,
  tipo_emissao char(1) null,
  versao_processo_emissao varchar(20) null,
  tipo_bpe char(1) null,
  consumidor_presenca char(1) null,
  uf_inicio_viagem char(2) null,
  codigo_municipio_inicio_viagem int unsigned null,
  uf_fim_viagem char(2) null,
  codigo_municipio_fim_viagem int unsigned null,
  valor_bilhete decimal(18,6) null,
  valor_desconto decimal(18,6) null,
  valor_pago decimal(18,6) null,
  valor_troco decimal(18,6) null,
  tipo_desconto char(2) null,
  desconto_descricao varchar(100) null,
  desconto_concedido_outros varchar(20) null,
  forma_pagamento char(2) null,
  forma_pagamento_outros varchar(100) null,
  forma_pagamento_documento varchar(20) null,
  cst char(2) null,
  base_calculo_icms decimal(18,6) null,
  aliquota_icms decimal(18,6) null,
  valor_icms decimal(18,6) null,
  percentual_reducao_bc_icms decimal(18,6) null,
  informacoes_add_fisco text null,
  primary key (id)) 
 engine = innodb; 
 create table if not exists bpe_emitente (
  id int unsigned not null auto_increment,
  id_bpe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  ie varchar(14) null,
  iest varchar(14) null,
  im varchar(15) null,
  cnae varchar(7) null,
  crt int null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  logradouro varchar(60) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  telefone varchar(14) null,
  primary key (id),
  index fk_cte_cab_emitente (id_bpe_cabecalho asc),
  constraint fk_8e0ea66cea894c1f8cf4778365c7ae3b0
    foreign key (id_bpe_cabecalho)
    references bpe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists bpe_passageiro (
  id int unsigned not null auto_increment,
  id_bpe_cabecalho int unsigned not null,
  nome varchar(60) null,
  cpf varchar(11) null,
  tipo_documento_identificacao char(1) null,
  numero_documento varchar(20) null,
  documento_outros_descricao varchar(100) null,
  data_nascimento date null,
  telefone varchar(12) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_tomador (id_bpe_cabecalho asc),
  constraint fk_fb54edc5f9184617a82870539984bb460
    foreign key (id_bpe_cabecalho)
    references bpe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists bpe_comprador (
  id int unsigned not null auto_increment,
  id_bpe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  cpf varchar(11) null,
  ie varchar(20) null,
  nome varchar(60) null,
  fantasia varchar(60) null,
  telefone varchar(14) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_remetente (id_bpe_cabecalho asc),
  constraint fk_44c5ae01875b414ab141210de88d57160
    foreign key (id_bpe_cabecalho)
    references bpe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists bpe_viagem (
  id int unsigned not null auto_increment,
  id_bpe_cabecalho int unsigned not null,
  codigo_percurso varchar(20) null,
  descricao_percurso varchar(100) null,
  tipo_viagem char(2) null,
  tipo_servico char(1) null,
  tipo_acomodacao char(1) null,
  tipo_trecho char(1) null,
  data_hora_viagem timestamp null,
  data_hora_conexao timestamp null,
  prefixo_linha varchar(20) null,
  poltrona char(3) null,
  plataforma varchar(10) null,
  primary key (id),
  index fk_cte_cab_expedidor (id_bpe_cabecalho asc),
  constraint fk_b49f680d20f54d89945bed7a99c5ebff0
    foreign key (id_bpe_cabecalho)
    references bpe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists bpe_agencia (
  id int unsigned not null auto_increment,
  id_bpe_cabecalho int unsigned not null,
  cnpj varchar(14) null,
  nome varchar(60) null,
  telefone varchar(14) null,
  logradouro varchar(250) null,
  numero varchar(60) null,
  complemento varchar(60) null,
  bairro varchar(60) null,
  codigo_municipio int unsigned null,
  nome_municipio varchar(60) null,
  uf char(2) null,
  cep varchar(8) null,
  codigo_pais int null,
  nome_pais varchar(60) null,
  email varchar(60) null,
  primary key (id),
  index fk_cte_cab_destinatario (id_bpe_cabecalho asc),
  constraint fk_be7e7fc1411540c2ab9ea9b2b1b52d980
    foreign key (id_bpe_cabecalho)
    references bpe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists bpe_passagem (
  id int unsigned not null auto_increment,
  id_bpe_cabecalho int unsigned not null,
  codigo_localidade_origem varchar(7) null,
  descricao_localidade_origem varchar(60) null,
  codigo_localidade_destino varchar(7) null,
  descricao_localidade_destino varchar(60) null,
  data_hora_embarque timestamp null,
  data_hora_validade timestamp null,
  primary key (id),
  index fk_cte_cab_carga (id_bpe_cabecalho asc),
  constraint fk_9b8a42cbe13a475f81fe5e7c48ed6e2f0
    foreign key (id_bpe_cabecalho)
    references bpe_cabecalho (id)
    on delete no action
    on update no action) 
 engine = innodb; 
 create table if not exists crm_sac_cabecalho (
  id int not null auto_increment,
  data_abertura date null,
  hora_abertura varchar(8) null,
  numero_protocolo varchar(100) null,
  nivel_reclamacao char(1) null,
  id_cliente int not null,
  primary key (id),
  index fk_crm_sac_cabecalho_cliente1_idx (id_cliente asc),
  constraint fk_crm_sac_cabecalho_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists crm_sac_detalhe (
  id int not null auto_increment,
  id_crm_sac_cabecalho int not null,
  data_registro date null,
  hora_registro varchar(8) null,
  historico text null,
  primary key (id),
  index fk_crm_sac_detalhe_crm_sac_cabecalho1_idx (id_crm_sac_cabecalho asc),
  constraint fk_crm_sac_detalhe_crm_sac_cabecalho1
    foreign key (id_crm_sac_cabecalho)
    references crm_sac_cabecalho (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists crm_buscas_cliente (
  id int not null auto_increment,
  data_busca date null,
  hora_busca varchar(8) null,
  detalhes text null,
  id_cliente int not null,
  primary key (id),
  index fk_crm_buscas_cliente_cliente1_idx (id_cliente asc),
  constraint fk_crm_buscas_cliente_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action)
engine = innodb;
create table if not exists crm_carteira_cliente_perfil (
  id int not null auto_increment,
  codigo char(2) null,
  nome varchar(100) null,
  primary key (id))
engine = innodb;
create table if not exists crm_carteira_cliente (
  id int not null auto_increment,
  id_crm_carteira_cliente_perfil int not null,
  id_cliente int not null,
  primary key (id),
  index fk_crm_carteira_cliente_crm_carteira_cliente_perfil1_idx (id_crm_carteira_cliente_perfil asc),
  index fk_crm_carteira_cliente_cliente1_idx (id_cliente asc),
  constraint fk_crm_carteira_cliente_crm_carteira_cliente_perfil1
    foreign key (id_crm_carteira_cliente_perfil)
    references crm_carteira_cliente_perfil (id)
    on delete no action
    on update no action,
  constraint fk_crm_carteira_cliente_cliente1
    foreign key (id_cliente)
    references cliente (id)
    on delete no action
    on update no action)
engine = innodb;


/*
  ESTADO_CIVIL
  ------------
*/
insert into estado_civil (id, nome, descricao) values (1, 'SOLTEIRO', 'SOLTEIRO');
insert into estado_civil (id, nome, descricao) values (2, 'CASADO', 'CASADO');
insert into estado_civil (id, nome, descricao) values (3, 'VIUVO', 'VIUVO');
insert into estado_civil (id, nome, descricao) values (4, 'SEPARADO JUDICIALMENTE', 'SEPARADO JUDICIALMENTE');
insert into estado_civil (id, nome, descricao) values (5, 'DIVORCIADO', 'DIVORCIADO');

/*
  NIVEL_FORMACAO
  --------------
*/
insert into nivel_formacao (id, nome, descricao) values('1','Analfabeto','Grau de instrução 1');
insert into nivel_formacao (id, nome, descricao) values('2','Até 5º Ano Incompleto','Grau de instrução 2');
insert into nivel_formacao (id, nome, descricao) values('3','5º Ano Completo','Grau de instrução 3');
insert into nivel_formacao (id, nome, descricao) values('4','6º ao 9º Ano do Fundamental','Grau de instrução 4');
insert into nivel_formacao (id, nome, descricao) values('5','Fundamental Completo','Grau de instrução 5');
insert into nivel_formacao (id, nome, descricao) values('6','Médio Incompleto','Grau de instrução 6');
insert into nivel_formacao (id, nome, descricao) values('7','Médio Completo','Grau de instrução 7');
insert into nivel_formacao (id, nome, descricao) values('8','Superior Incompleto','Grau de instrução 8');
insert into nivel_formacao (id, nome, descricao) values('9','Superior Completo','Grau de instrução 9');
insert into nivel_formacao (id, nome, descricao) values('10','Mestrado','Grau de instrução 10');
insert into nivel_formacao (id, nome, descricao) values('11','Doutorado','Grau de instrução 11');
insert into nivel_formacao (id, nome, descricao) values('12','Pós-Doutorado','');

/*
  PESSOA
*/
insert into pessoa (id, nome, tipo, email, site, eh_cliente, eh_fornecedor, eh_colaborador, eh_transportadora) values('1','TESTE PESSOA FISICA','F','pf@gmail.com',NULL,'S','S','S','S');
insert into pessoa (id, nome, tipo, email, site, eh_cliente, eh_fornecedor, eh_colaborador, eh_transportadora) values('2','TESTE PESSOA JURIDICA','J','pj@gmail.com',NULL,'S','S','S','S');
insert into pessoa (id, nome, tipo, email, site, eh_cliente, eh_fornecedor, eh_colaborador, eh_transportadora) values('3','OUTRA PESSOA FISICA','F','pf2@gmail.com',NULL,'S','S','S','S');

/*
  PESSOA_FISICA
  -------------
*/
insert into pessoa_fisica (id, id_pessoa, id_estado_civil, id_nivel_formacao, cpf, rg, orgao_rg, data_emissao_rg, data_nascimento, sexo) values('1', '1','1','1','11111111111','123456','SSP-SP','1980-01-01','1970-01-01','M');

/*
  PESSOA_JURIDICA
  ---------------
*/
insert into pessoa_juridica (id, id_pessoa, cnpj, nome_fantasia, inscricao_municipal, inscricao_estadual, data_constituicao, tipo_regime, crt) values('1','2','00000000000191','PESSOA JURIDICA.COM','ISENTO','ISENTO','1980-01-01','3','1');

/*
  PESSOA_ENDERECO
  -------
*/
insert into pessoa_endereco (id, id_pessoa, logradouro, numero, complemento, bairro, cidade, cep, municipio_ibge, uf, principal, entrega, cobranca, correspondencia) values('1','1','LOGRADOURO PESSOA FISICA','2','COMPLEMENTO','BAIRRO','CIDADE','71000000','5300108','DF','S',NULL,NULL,NULL);
insert into pessoa_endereco (id, id_pessoa, logradouro, numero, complemento, bairro, cidade, cep, municipio_ibge, uf, principal, entrega, cobranca, correspondencia) values('2','2','LOGRADOURO PESSOA JURIDICA','3','COMPLEMENTO','BAIRRO','CIDADE','72000000','5300108','DF','S',NULL,NULL,NULL);

/*
  PESSOA_TELEFONE
  -------
*/
insert into pessoa_telefone (id, id_pessoa, tipo, numero) values('1','1','0','06120203030');
insert into pessoa_telefone (id, id_pessoa, tipo, numero) values('2','2','0','08865985487');

/*
  CLIENTE
  -------
*/
insert into cliente (id, id_pessoa) values (1, 1);

/*
  FORNECEDOR
  ----------
*/
insert into fornecedor (id, id_pessoa) values (1, 1);

/*
  EMPRESA
  -------
*/
insert into empresa (id, razao_social, nome_fantasia, cnpj, inscricao_estadual, inscricao_municipal, inscricao_junta_comercial, data_insc_junta_comercial, tipo, email, codigo_ibge_cidade, codigo_ibge_uf) values (1, 'EMPRESA MATRIZ PARA TESTES', 'EMPRESA PARA TESTES', '00000000000191', NULL, NULL, NULL, '2009-11-19', NULL, 'testes@empresateste.com', '5300108', '53');


/*
  EMPRESA_ENDERECO
  -------
*/
insert into empresa_endereco (id, id_empresa, logradouro, numero, complemento, bairro, cidade, cep, municipio_ibge, uf, principal, entrega, cobranca, correspondencia) values('1','1','LOGRADOURO EMPRESA','1','COMPLEMENTO','BAIRRO','CIDADE','70000000','5300108','DF','S',NULL,NULL,NULL);

/*
  EMPRESA_TELEFONE
  -------
*/
insert into empresa_telefone (id, id_empresa, tipo, numero) values('1','1','0','06120203030');
insert into empresa_telefone (id, id_empresa, tipo, numero) values('2','1','1','08865985487');

/*
  CARGO
*/
insert into cargo (id, nome, descricao, salario, cbo_1994, cbo_2002) values (1, 'ADMINISTRADOR', NULL, 5000, NULL, '252105');

/*
  SETOR
  -----
*/
insert into setor (id, nome, descricao) values (1, 'ADMINISTRACAO', NULL);

/*
  PAPEL
  -----
*/
insert into papel (id, nome, descricao) values (1, 'ADMINISTRADOR', 'TEM ACESSO IRRESTRITO AO SISTEMA');
insert into papel (id, nome, descricao) values (2, 'COMUM', 'TESTE USUARIO COMUM');

/*
  COLABORADOR
*/
insert into colaborador (id, id_pessoa, id_cargo, id_setor) values (1, 1, 1, 1);
insert into colaborador (id, id_pessoa, id_cargo, id_setor) values (2, 3, 1, 1);


/*
  USUARIO
  -------
*/
insert into usuario (id, id_colaborador, id_papel, login, senha, data_cadastro, administrador) values (1, 1, 1, '1', '6512bd43d9caa6e02c990b0a82652dca', '2012-01-01', 'S');
insert into usuario (id, id_colaborador, id_papel, login, senha, data_cadastro, administrador) values (2, 2, 2, '2', 'b6d767d2f8ed5d21a44b0e5886680cb9', '2013-08-06', 'N');

/*
  CONTADOR
  --------
*/
insert into contador (id, id_pessoa, crc_inscricao) values (1, 1, '666999');


/*
  BANCO
  -----
*/
insert into banco (id, codigo, nome, url) values (1, '001', 'BANCO DO BRASIL', NULL);
insert into banco (id, codigo, nome, url) values (2, '246', 'BANCO ABC BRASIL S.A. ', 'http://www.abcbrasil.com.br/ ');
insert into banco (id, codigo, nome, url) values (3, '356', 'BANCO ABN AMRO REAL S.A. ', 'http://www.abnamro.com.br/ ');
insert into banco (id, codigo, nome, url) values (4, '25', 'BANCO ALFA S.A. ', 'http://www.bancoalfa.com.br/ ');
insert into banco (id, codigo, nome, url) values (5, '641', 'BANCO ALVORADA S.A. ', 'Não possui site ');
insert into banco (id, codigo, nome, url) values (6, NULL, 'BANCO AMERICAN EXPRESS S.A. ', 'http://www.aexp.com/ ');
insert into banco (id, codigo, nome, url) values (7, '29', 'BANCO BANERJ S.A. ', 'http://www.banerJÁcom.br/ ');
insert into banco (id, codigo, nome, url) values (8, '38', 'BANCO BANESTADO S.A. ', 'http://www.banestado.com.br/ ');
insert into banco (id, codigo, nome, url) values (9, '740', 'BANCO BARCLAYS S.A. ', 'http://www.barclays.com/ ');
insert into banco (id, codigo, nome, url) values (10, '107', 'BANCO BBM S.A. ', 'http://www.bbmbank.com.br/ ');


/*
  AGENCIA_BANCO
  -------------
*/
insert into banco_agencia (id, id_banco, numero, nome) values (1, 1, 2903, 'AGENCIA IMPERADOR');

/*
  CONTA_CAIXA
  -----------
*/
insert into banco_conta_caixa (id, id_banco_agencia, numero, nome, descricao, tipo) values (1, 1, '255645', 'CC MOVIMETACAO BB', 'CONTA CORRENTE DE MOVIMENTACAO NO BB', 'C');
insert into banco_conta_caixa (id, id_banco_agencia, numero, nome, descricao, tipo) values (2, NULL, 'CXINT', 'CAIXA INTERNO', 'CONTA INTERNA PARA MOVIMENTACAO DO CAIXA DA EMPRESA', 'X');

/*
  CFOP
  ----
*/
insert into cfop (id, codigo, descricao, aplicacao) values('1','1000','ENTRADAS OU AQUISIÇÕES DE SERVIÇOS DO ESTADO','Classificam-se, neste grupo, as operações ou prestações em que o estabelecimento remetente esteja localizado na mesma unidade da Federação do destinatário');
insert into cfop (id, codigo, descricao, aplicacao) values('2','1100','COMPRAS PARA INDUSTRIALIZAÇÃO, COMERCIALIZAÇÃO OU PRESTAÇÃO DE SERVIÇOS','');
insert into cfop (id, codigo, descricao, aplicacao) values('3','1101','Compra para industrialização','Classificam-se neste código as compras de mercadorias a serem utilizadas em processo de industrialização. Também serão classificadas neste código as entradas de mercadorias em estabelecimento industrial de cooperativa recebidas de seus cooperados ou de estabelecimento de outra cooperativa.');
insert into cfop (id, codigo, descricao, aplicacao) values('4','1102','Compra para comercialização','Classificam-se neste código as compras de mercadorias a serem comercializadas. Também serão classificadas neste código as entradas de mercadorias em estabelecimento comercial de cooperativa recebidas de seus cooperados ou de estabelecimento de outra cooperativa.');
insert into cfop (id, codigo, descricao, aplicacao) values('5','1111','Compra para industrialização de mercadoria recebida anteriormente em consignação industrial','Classificam-se neste código as compras efetivas de mercadorias a serem utilizadas em processo de industrialização, recebidas anteriormente a título de consignação industrial.');
insert into cfop (id, codigo, descricao, aplicacao) values('6','1113','Compra para comercialização, de mercadoria recebida anteriormente em consignação mercantil','Classificam-se neste código as compras efetivas de mercadorias recebidas anteriormente a título de consignação mercantil.');
insert into cfop (id, codigo, descricao, aplicacao) values('7','1116','Compra para industrialização originada de encomenda para recebimento futuro','Classificam-se neste código as compras de mercadorias a serem utilizadas em processo de industrialização, quando da entrada real da mercadoria, cuja aquisição tenha sido classificada no código 1.922 - Lançamento efetuado a título de simples faturamento decorrente de compra para recebimento futuro.');
insert into cfop (id, codigo, descricao, aplicacao) values('8','1117','Compra para comercialização originada de encomenda para recebimento futuro','Classificam-se neste código as compras de mercadorias a serem comercializadas, quando da entrada real da mercadoria, cuja aquisição tenha sido classificada no código 1.922 - Lançamento efetuado a título de simples faturamento decorrente de compra para recebimento futuro.');
insert into cfop (id, codigo, descricao, aplicacao) values('9','1118','Compra de mercadoria para comercialização pelo adquirente originário, entregue pelo vendedor remetente ao destinatário, em venda à ordem','Classificam-se neste código as compras de mercadorias já comercializadas, que, sem transitar pelo estabelecimento do adquirente originário, sejam entregues pelo vendedor remetente diretamente ao destinatário, em operação de venda à ordem, cuja venda seja classificada, pelo adquirente originário, no código 5.120 - Venda de mercadoria adquirida ou recebida de terceiros entregue ao destinatário pelo vendedor remetente, em venda à ordem.');
insert into cfop (id, codigo, descricao, aplicacao) values('10','1120','Compra para industrialização, em venda à ordem, já recebida do vendedor remetente','Classificam-se neste código as compras de mercadorias a serem utilizadas em processo de industrialização, em vendas à ordem, já recebidas do vendedor remetente, por ordem do adquirente originário.');

/*
  CST_ICMS
  ----------
*/
insert into cst_icms (id, codigo, descricao) values (1, '00', 'Tributada Integralmente');
insert into cst_icms (id, codigo, descricao) values (2, '10', 'Tributada e com Cobrança do ICMS  por Substituicao Tributária');
insert into cst_icms (id, codigo, descricao) values (3, '20', 'Com redução de Base de Calculo');
insert into cst_icms (id, codigo, descricao) values (4, '30', 'Isenta ou Não Tributada e com cobrança do ICMS por Substituição tributária');
insert into cst_icms (id, codigo, descricao) values (5, '40', 'Isenta');
insert into cst_icms (id, codigo, descricao) values (6, '41', 'Não Tributada');
insert into cst_icms (id, codigo, descricao) values (7, '50', 'Suspensão');
insert into cst_icms (id, codigo, descricao) values (8, '51', 'Direrimento');
insert into cst_icms (id, codigo, descricao) values (9, '60', 'ICMS cobrado anteriormente por substituição tributária');
insert into cst_icms (id, codigo, descricao) values (10, '70', 'Com redução de base de cálculo e cobrança do ICMS por substituicão tributária');
insert into cst_icms (id, codigo, descricao) values (11, '90', 'Outras');

/*
  CSOSN
  -------
*/
insert into csosn (id, codigo, descricao, observacao) values('1','101','Tributada pelo Simples Nacional com permissão de crédito','Classificam-se neste código as operações que permitem a indicação da alíquota do ICMS devido no Simples Nacional e o valor do crédito correspondente.');
insert into csosn (id, codigo, descricao, observacao) values('2','102','Tributada pelo Simples Nacional sem permissão de crédito','Classificam-se neste código as operações que não permitem a indicação da alíquota do ICMS devido pelo Simples Nacional e do valor do crédito, e não estejam abrangidas nas hipóteses dos códigos 103, 203, 300, 400, 500 e 900.');
insert into csosn (id, codigo, descricao, observacao) values('3','103','Isenção do ICMS no Simples Nacional para faixa de receita bruta','Classificam-se neste código as operações praticadas por optantes pelo Simples Nacional contemplados com isenção concedida para faixa de receita bruta nos termos da Lei Complementar nº 123, de 2006.');
insert into csosn (id, codigo, descricao, observacao) values('4','201','Tributada pelo Simples Nacional com permissão de crédito e com cobrança do ICMS por substituição tributária','Classificam-se neste código as operações que permitem a indicação da alíquota do ICMS devido pelo Simples Nacional e do valor do crédito, e com cobrança do ICMS por substituição tributária.');
insert into csosn (id, codigo, descricao, observacao) values('5','202','Tributada pelo Simples Nacional sem permissão de crédito e com cobrança do ICMS por substituição tributária','Classificam-se neste código as operações que não permitem a indicação da alíquota do ICMS devido pelo Simples Nacional e do valor do crédito, e não estejam abrangidas nas hipóteses dos códigos 103, 203, 300, 400, 500 e 900, e com cobrança do ICMS por substituição tributária.');
insert into csosn (id, codigo, descricao, observacao) values('6','203','Isenção do ICMS no Simples Nacional para faixa de receita bruta e com cobrança do ICMS por substituição tributária','Classificam-se neste código as operações praticadas por optantes pelo Simples Nacional contemplados com isenção para faixa de receita bruta nos termos da Lei Complementar nº 123, de 2006, e com cobrança do ICMS por substituição tributária.');
insert into csosn (id, codigo, descricao, observacao) values('7','300','Imune','Classificam-se neste código as operações praticadas por optantes pelo Simples Nacional contempladas com imunidade do ICMS.');
insert into csosn (id, codigo, descricao, observacao) values('8','400','Não tributada pelo Simples Nacional','Classificam-se neste código as operações praticadas por optantes pelo Simples Nacional não sujeitas à tributação pelo ICMS dentro do Simples Nacional.');
insert into csosn (id, codigo, descricao, observacao) values('9','500','ICMS cobrado anteriormente por substituição tributária (substituído) ou por antecipação','Classificam-se neste código as operações sujeitas exclusivamente ao regime de substituição tributária na condição de substituído tributário ou no caso de antecipações.');
insert into csosn (id, codigo, descricao, observacao) values('10','900','Outros','Classificam-se neste código as demais operações que não se enquadrem nos códigos 101, 102, 103, 201, 202, 203, 300, 400 e 500.');

/*
  CST_COFINS
  ----------
*/
insert into cst_cofins (id, descricao, codigo) values (1, 'Operacao Tributavel com Aliquota Basica', '01');
insert into cst_cofins (id, descricao, codigo) values (2, 'Operacao Tributavel com Aliquota Diferenciada', '02');
insert into cst_cofins (id, descricao, codigo) values (3, 'Operacao Tributavel com Aliquota por Unidade de Medida de Produto', '03');
insert into cst_cofins (id, descricao, codigo) values (4, 'Operacao Tributavel Monofasica - Revenda a Aliquota Zero', '04');
insert into cst_cofins (id, descricao, codigo) values (5, 'Operacao Tributavel por Substituicao Tributaria', '05');
insert into cst_cofins (id, descricao, codigo) values (6, 'Operacao Tributavel a Aliquota Zero', '06');
insert into cst_cofins (id, descricao, codigo) values (7, 'Operacao Isenta da Contribuicao', '07');
insert into cst_cofins (id, descricao, codigo) values (8, 'Operacao sem Incidencia da Contribuicao', '08');
insert into cst_cofins (id, descricao, codigo) values (9, 'Operacao com Suspensao da Contribuicao', '09');
insert into cst_cofins (id, descricao, codigo) values (10, 'Outras Operacões de Saida', '49');
insert into cst_cofins (id, descricao, codigo) values (11, 'Operacao com Direito a Credito - Vinculada Exclusivamente a Receita Tributada no Mercado Interno', '50');
insert into cst_cofins (id, descricao, codigo) values (12, 'Operacao com Direito a Credito – Vinculada Exclusivamente a Receita Nao Tributada no Mercado Interno', '51');
insert into cst_cofins (id, descricao, codigo) values (13, 'Operacao com Direito a Credito - Vinculada Exclusivamente a Receita de Exportacao', '52');
insert into cst_cofins (id, descricao, codigo) values (14, 'Operacao com Direito a Credito - Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno', '53');
insert into cst_cofins (id, descricao, codigo) values (15, 'Operacao com Direito a Credito - Vinculada a Receitas Tributadas no Mercado Interno e de Exportacao', '54');
insert into cst_cofins (id, descricao, codigo) values (16, 'Operacao com Direito a Credito - Vinculada a Receitas Nao-Tributadas no Mercado Interno e de Exportacao', '55');
insert into cst_cofins (id, descricao, codigo) values (17, 'Operacao com Direito a Credito - Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno, e de Exportacao', '56');
insert into cst_cofins (id, descricao, codigo) values (18, 'Credito Presumido - Operacao de Aquisicao Vinculada Exclusivamente a Receita Tributada no Mercado Interno', '60');
insert into cst_cofins (id, descricao, codigo) values (19, 'Credito Presumido - Operacao de Aquisicao Vinculada Exclusivamente a Receita Nao-Tributada no Mercado Interno', '61');
insert into cst_cofins (id, descricao, codigo) values (20, 'Credito Presumido - Operacao de Aquisicao Vinculada Exclusivamente a Receita de Exportacao', '62');
insert into cst_cofins (id, descricao, codigo) values (21, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno', '63');
insert into cst_cofins (id, descricao, codigo) values (22, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Tributadas no Mercado Interno e de Exportacao', '64');
insert into cst_cofins (id, descricao, codigo) values (23, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Nao-Tributadas no Mercado Interno e de Exportacao', '65');
insert into cst_cofins (id, descricao, codigo) values (24, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno, e de Exportacao', '66');
insert into cst_cofins (id, descricao, codigo) values (25, 'Credito Presumido - Outras Operacões', '67');
insert into cst_cofins (id, descricao, codigo) values (26, 'Operacao de Aquisicao sem Direito a Credito', '70');
insert into cst_cofins (id, descricao, codigo) values (27, 'Operacao de Aquisicao com Isencao', '71');
insert into cst_cofins (id, descricao, codigo) values (28, 'Operacao de Aquisicao com Suspensao', '72');
insert into cst_cofins (id, descricao, codigo) values (29, 'Operacao de Aquisicao a Aliquota Zero', '73');
insert into cst_cofins (id, descricao, codigo) values (30, 'Operacao de Aquisicao sem Incidencia da Contribuicao', '74');
insert into cst_cofins (id, descricao, codigo) values (31, 'Operacao de Aquisicao por Substituicao Tributaria', '75');
insert into cst_cofins (id, descricao, codigo) values (32, 'Outras Operacões de Entrada', '98');
insert into cst_cofins (id, descricao, codigo) values (33, 'Outras Operacões', '99');

/*
  CST_IPI
  -------
*/
insert into cst_ipi (id, descricao, codigo) values (2, 'Entrada com Recuperação de Crédito', '00');
insert into cst_ipi (id, descricao, codigo) values (3, 'Entrada Tributável com Aliquota Zero', '01');
insert into cst_ipi (id, descricao, codigo) values (4, 'Entrada Isenta', '02');
insert into cst_ipi (id, descricao, codigo) values (5, 'Entrada Não-Tributada', '03');
insert into cst_ipi (id, descricao, codigo) values (6, 'Entrada Imune', '04');
insert into cst_ipi (id, descricao, codigo) values (7, 'Entrada com Suspensão', '05');
insert into cst_ipi (id, descricao, codigo) values (8, 'Outras Entradas', '49');
insert into cst_ipi (id, descricao, codigo) values (9, 'Saída Tributada', '50');
insert into cst_ipi (id, descricao, codigo) values (10, 'Saída Tributável com aliquota Zero', '51');
insert into cst_ipi (id, descricao, codigo) values (11, 'Saida Isenta', '52');
insert into cst_ipi (id, descricao, codigo) values (12, 'Saida Não-Tributada', '53');
insert into cst_ipi (id, descricao, codigo) values (13, 'Saida Imune', '54');
insert into cst_ipi (id, descricao, codigo) values (14, 'Saida com Suspensão', '55');
insert into cst_ipi (id, descricao, codigo) values (15, 'Outras Saídas', '99');

/*
  CST_PIS
  -------
*/
insert into cst_pis (id, descricao, codigo) values (2, 'Operacao Tributavel com Aliquota Basica', '01');
insert into cst_pis (id, descricao, codigo) values (3, 'Operacao Tributavel com Aliquota Diferenciada', '02');
insert into cst_pis (id, descricao, codigo) values (4, 'Operacao Tributavel com Aliquota por Unidade de Medida de Produto', '03');
insert into cst_pis (id, descricao, codigo) values (5, 'Operacao Tributavel Monofasica - Revenda a Aliquota Zero', '04');
insert into cst_pis (id, descricao, codigo) values (6, 'Operacao Tributavel por Substituicao Tributaria', '05');
insert into cst_pis (id, descricao, codigo) values (7, 'Operacao Tributavel a Aliquota Zero', '06');
insert into cst_pis (id, descricao, codigo) values (8, 'Operacao Isenta da Contribuicao', '07');
insert into cst_pis (id, descricao, codigo) values (9, 'Operacao sem Incidencia da Contribuicao', '08');
insert into cst_pis (id, descricao, codigo) values (10, 'Operacao com Suspensao da Contribuicao', '09');
insert into cst_pis (id, descricao, codigo) values (11, 'Outras Operacões de Saida', '49');
insert into cst_pis (id, descricao, codigo) values (12, 'Operacao com Direito a Credito - Vinculada Exclusivamente a Receita Tributada no Mercado Interno', '50');
insert into cst_pis (id, descricao, codigo) values (13, 'Operacao com Direito a Credito – Vinculada Exclusivamente a Receita Nao Tributada no Mercado Interno', '51');
insert into cst_pis (id, descricao, codigo) values (14, 'Operacao com Direito a Credito - Vinculada Exclusivamente a Receita de Exportacao', '52');
insert into cst_pis (id, descricao, codigo) values (15, 'Operacao com Direito a Credito - Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno', '53');
insert into cst_pis (id, descricao, codigo) values (16, 'Operacao com Direito a Credito - Vinculada a Receitas Tributadas no Mercado Interno e de Exportacao', '54');
insert into cst_pis (id, descricao, codigo) values (17, 'Operacao com Direito a Credito - Vinculada a Receitas Nao-Tributadas no Mercado Interno e de Exportacao', '55');
insert into cst_pis (id, descricao, codigo) values (18, 'Operacao com Direito a Credito - Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno, e de Exportacao', '56');
insert into cst_pis (id, descricao, codigo) values (19, 'Credito Presumido - Operacao de Aquisicao Vinculada Exclusivamente a Receita Tributada no Mercado Interno', '60');
insert into cst_pis (id, descricao, codigo) values (20, 'Credito Presumido - Operacao de Aquisicao Vinculada Exclusivamente a Receita Nao-Tributada no Mercado Interno', '61');
insert into cst_pis (id, descricao, codigo) values (21, 'Credito Presumido - Operacao de Aquisicao Vinculada Exclusivamente a Receita de Exportacao', '62');
insert into cst_pis (id, descricao, codigo) values (22, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno', '63');
insert into cst_pis (id, descricao, codigo) values (23, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Tributadas no Mercado Interno e de Exportacao', '64');
insert into cst_pis (id, descricao, codigo) values (24, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Nao-Tributadas no Mercado Interno e de Exportacao', '65');
insert into cst_pis (id, descricao, codigo) values (25, 'Credito Presumido - Operacao de Aquisicao Vinculada a Receitas Tributadas e Nao-Tributadas no Mercado Interno, e de Exportacao', '66');
insert into cst_pis (id, descricao, codigo) values (26, 'Credito Presumido - Outras Operacões', '67');
insert into cst_pis (id, descricao, codigo) values (27, 'Operacao de Aquisicao sem Direito a Credito', '70');
insert into cst_pis (id, descricao, codigo) values (28, 'Operacao de Aquisicao com Isencao', '71');
insert into cst_pis (id, descricao, codigo) values (29, 'Operacao de Aquisicao com Suspensao', '72');
insert into cst_pis (id, descricao, codigo) values (30, 'Operacao de Aquisicao a Aliquota Zero', '73');
insert into cst_pis (id, descricao, codigo) values (31, 'Operacao de Aquisicao sem Incidencia da Contribuicao', '74');
insert into cst_pis (id, descricao, codigo) values (32, 'Operacao de Aquisicao por Substituicao Tributaria', '75');
insert into cst_pis (id, descricao, codigo) values (33, 'Outras Operacões de Entrada', '98');
insert into cst_pis (id, descricao, codigo) values (34, 'Outras Operacões', '99');

/*
  UF
  --
*/
insert into uf (id, sigla, nome, codigo_ibge) values (1, 'AC', 'ACRE', 12);
insert into uf (id, sigla, nome, codigo_ibge) values (2, 'AL', 'ALAGOAS', 27);
insert into uf (id, sigla, nome, codigo_ibge) values (3, 'AP', 'AMAPÁ', 16);
insert into uf (id, sigla, nome, codigo_ibge) values (4, 'AM', 'AMAZONAS', 13);
insert into uf (id, sigla, nome, codigo_ibge) values (5, 'BA', 'BAHIA', 29);
insert into uf (id, sigla, nome, codigo_ibge) values (6, 'CE', 'CEARÁ', 23);
insert into uf (id, sigla, nome, codigo_ibge) values (7, 'DF', 'DISTRITO FEDERAL', 53);
insert into uf (id, sigla, nome, codigo_ibge) values (8, 'ES', 'ESPÍRITO SANTO', 32);
insert into uf (id, sigla, nome, codigo_ibge) values (9, 'GO', 'GOIÁS', 52);
insert into uf (id, sigla, nome, codigo_ibge) values (10, 'MA', 'MARANHÃO', 21);
insert into uf (id, sigla, nome, codigo_ibge) values (11, 'MT', 'MATO GROSSO', 51);
insert into uf (id, sigla, nome, codigo_ibge) values (12, 'MS', 'MATO GROSSO DO SUL', 50);
insert into uf (id, sigla, nome, codigo_ibge) values (13, 'MG', 'MINAS GERAIS', 31);
insert into uf (id, sigla, nome, codigo_ibge) values (14, 'PA', 'PARÁ', 15);
insert into uf (id, sigla, nome, codigo_ibge) values (15, 'PB', 'PARAÍBA', 25);
insert into uf (id, sigla, nome, codigo_ibge) values (16, 'PR', 'PARANÁ', 41);
insert into uf (id, sigla, nome, codigo_ibge) values (17, 'PE', 'PERNAMBUCO', 26);
insert into uf (id, sigla, nome, codigo_ibge) values (18, 'PI', 'PIAUÍ', 22);
insert into uf (id, sigla, nome, codigo_ibge) values (19, 'RJ', 'RIO DE JANEIRO', 33);
insert into uf (id, sigla, nome, codigo_ibge) values (20, 'RN', 'RIO GRANDE DO NORTE', 24);
insert into uf (id, sigla, nome, codigo_ibge) values (21, 'RS', 'RIO GRANDE DO SUL', 43);
insert into uf (id, sigla, nome, codigo_ibge) values (22, 'RO', 'RONDÔNIA', 11);
insert into uf (id, sigla, nome, codigo_ibge) values (23, 'RR', 'RORAIMA', 14);
insert into uf (id, sigla, nome, codigo_ibge) values (24, 'SC', 'SANTA CATARINA', 42);
insert into uf (id, sigla, nome, codigo_ibge) values (25, 'SP', 'SÃO PAULO', 35);
insert into uf (id, sigla, nome, codigo_ibge) values (26, 'SE', 'SERGIPE', 28);
insert into uf (id, sigla, nome, codigo_ibge) values (27, 'TO', 'TOCANTINS', 17);

/*
  MUNICIPIO
*/
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (2, 1, 'ACRELÂNDIA', 1200013, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (3, 1, 'ASSIS BRASIL', 1200054, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (4, 1, 'BRASILÉIA', 1200104, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (5, 1, 'BUJARI', 1200138, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (6, 1, 'CAPIXABA', 1200179, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (7, 1, 'CRUZEIRO DO SUL', 1200203, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (8, 1, 'EPITACIOLÂNDIA', 1200252, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (9, 1, 'FEIJÓ', 1200302, NULL, NULL);
insert into municipio (id, id_uf, nome, codigo_ibge, codigo_receita_federal, codigo_estadual) values (10, 1, 'JORDÃO', 1200328, NULL, NULL);

/*
  NCM
  ---
*/
insert into ncm (id, codigo, descricao) values (1, '82121020', ' APARELHOS DE BARBEAR');
insert into ncm (id, codigo, descricao) values (2, '85269100', ' APARELHOS DE RADIONAVEGAÇÃO');
insert into ncm (id, codigo, descricao) values (3, '90278014', ' APARELHOS MEDIDORES DE PH');
insert into ncm (id, codigo, descricao) values (4, '84138100', ' BOMBAS DE USO AGRÍCOLAS  (EXEMPLO: BOMBAS CENTRÍFUGAS PARA ALIMENTAÇÃO DE ÁGUA DE CALDEIRA COM CAPACIDADE MÁXIMA IGUAL OU SUPERIOR');
insert into ncm (id, codigo, descricao) values (5, '84148019', ' COMPRESSORES DE AR,  (DE PALHETAS, ISENTOS DE ÓLEO COM PALHETAS CONSITUÍDAS Á BASE DE CARVÃO, AUTO AJUSTÁVEIS AO DESGASTE.');
insert into ncm (id, codigo, descricao) values (6, '30021024', ' CONCENTRADO DE FATOR VIII');
insert into ncm (id, codigo, descricao) values (7, '29362811', ' D- OU DL-ALFA-TOCOFEROL');
insert into ncm (id, codigo, descricao) values (8, '29331111', ' DIPIRONA');
insert into ncm (id, codigo, descricao) values (9, '85122011', ' FARÓIS, APARELHOS DE ILUMINAÇÃO');
insert into ncm (id, codigo, descricao) values (10, '40129010', ' FLAPS');

/*
  CNAE
  ----
*/
insert into cnae (id, denominacao, codigo) values (1, 'COMERCIO DE COSMETICOS', '4072500');
insert into cnae (id, denominacao, codigo) values (2, 'Cultivo de arroz', '111301');
insert into cnae (id, denominacao, codigo) values (3, 'Cultivo de milho', '111302');
insert into cnae (id, denominacao, codigo) values (4, 'Cultivo de trigo', '111303');
insert into cnae (id, denominacao, codigo) values (5, 'Cultivo de outros cereais não especificados anteriormente', '111399');
insert into cnae (id, denominacao, codigo) values (6, 'Cultivo de algodão herbáceo', '112101');
insert into cnae (id, denominacao, codigo) values (7, 'Cultivo de juta', '112102');
insert into cnae (id, denominacao, codigo) values (8, 'Cultivo de outras fibras de lavoura temporária não especificadas anteriormente', '112199');
insert into cnae (id, denominacao, codigo) values (9, 'Cultivo de canadeaçúcar', '113000');
insert into cnae (id, denominacao, codigo) values (10, 'Cultivo de fumo', '114800');

/*
  PRODUTO_UNIDADE
  ---------------
*/
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (1, 'UN', 'UNIDADE', 'S');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (2, 'UN', 'UNIDADE', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (3, 'KG', 'KILO', 'S');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (4, 'CX', 'CAIXA', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (5, 'VD', 'VIDRO', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (6, 'MT', 'METRO', 'S');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (7, 'M2', 'METRO QUADRADO', 'S');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (8, 'M3', 'METRO CUBICO', 'S');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (9, 'LT', 'LITRO', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (10, 'PÇ', 'PEÇA', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (11, 'JG', 'JOGO', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (12, 'GR', 'GRAMA', 'S');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (13, 'KT', 'KIT', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (14, 'RL', 'ROLO', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (15, 'PT', 'POTE', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (16, 'FL', 'FOLHA', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (17, 'FR', 'FRASCO', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (18, 'SC', 'SACO', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (19, 'CM', 'CENTIMETRO', 'S');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (20, 'LA', 'LATA', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (21, 'DB', 'BALDE', 'N');
insert into produto_unidade (id, sigla, descricao, pode_fracionar) values (22, 'PA', 'PAR', 'N');

insert into produto_marca (id, nome, descricao) values('1','MARCA 01','MARCA 01');
insert into produto_marca (id, nome, descricao) values('2','MARCA 02','MARCA 02');

insert into produto_grupo (id, nome, descricao) values('1','GRUPO 01','GRUPO 01');
insert into produto_grupo (id, nome, descricao) values('2','GRUPO 02','GRUPO 02');

insert into produto_subgrupo (id, id_produto_grupo, nome, descricao) values('1','1','SUBGRUPO 01 DO GRUPO 01','SUBGRUPO 01 DO GRUPO 01');
insert into produto_subgrupo (id, id_produto_grupo, nome, descricao) values('2','1','SUBGRUPO 02 DO GRUPO 01','SUBGRUPO 02 DO GRUPO 01');
insert into produto_subgrupo (id, id_produto_grupo, nome, descricao) values('3','2','SUBGRUPO 01 DO GRUPO 02','SUBGRUPO 01 DO GRUPO 02');
insert into produto_subgrupo (id, id_produto_grupo, nome, descricao) values('4','2','SUBGRUPO 02 DO GRUPO 02','SUBGRUPO 02 DO GRUPO 02');

insert into produto (id, id_produto_subgrupo, id_produto_marca, id_produto_unidade, nome, descricao, gtin, codigo_interno, valor_compra, valor_venda, codigo_ncm, estoque_minimo, estoque_maximo, quantidade_estoque, data_cadastro) values('1','1','1','1','PRODUTO 1','teste produto 1','123456',NULL,'1234.560000','2.300000',NULL,'3.000000','4.000000','325.325000',NULL);
insert into produto (id, id_produto_subgrupo, id_produto_marca, id_produto_unidade, nome, descricao, gtin, codigo_interno, valor_compra, valor_venda, codigo_ncm, estoque_minimo, estoque_maximo, quantidade_estoque, data_cadastro) values('2','2','2','2','PRODUTO 2',NULL,NULL,NULL,'2.300000','3.400000',NULL,NULL,NULL,NULL,NULL);
insert into produto (id, id_produto_subgrupo, id_produto_marca, id_produto_unidade, nome, descricao, gtin, codigo_interno, valor_compra, valor_venda, codigo_ncm, estoque_minimo, estoque_maximo, quantidade_estoque, data_cadastro) values('3','3','1','3','PRODUTO 3',NULL,NULL,NULL,'3.450000',NULL,NULL,NULL,NULL,NULL,NULL);
insert into produto (id, id_produto_subgrupo, id_produto_marca, id_produto_unidade, nome, descricao, gtin, codigo_interno, valor_compra, valor_venda, codigo_ncm, estoque_minimo, estoque_maximo, quantidade_estoque, data_cadastro) values('4','4','2','4','PRODUTO 4',NULL,NULL,NULL,'1.220000','6.380000',NULL,NULL,NULL,NULL,NULL);

/*
  CBO
*/
insert into cbo (id, codigo, nome) values (2, '010105', 'OFICIAL GENERAL DA AERONÁUTICA');
insert into cbo (id, codigo, nome) values (3, '010110', 'OFICIAL GENERAL DO EXÉRCITO');
insert into cbo (id, codigo, nome) values (4, '010115', 'OFICIAL GENERAL DA MARINHA');
insert into cbo (id, codigo, nome) values (5, '010205', 'OFICIAL DA AERONÁUTICA');
insert into cbo (id, codigo, nome) values (6, '010210', 'OFICIAL DO EXÉRCITO');
insert into cbo (id, codigo, nome) values (7, '010215', 'OFICIAL DA MARINHA');
insert into cbo (id, codigo, nome) values (8, '010305', 'PRAÇA DA AERONÁUTICA');
insert into cbo (id, codigo, nome) values (9, '010315', 'PRAÇA DA MARINHA');
insert into cbo (id, codigo, nome) values (10, '010310', 'PRAÇA DO EXÉRCITO');

/*
  FIN_DOCUMENTO_ORIGEM
  ----------------
*/
insert into fin_documento_origem (id, descricao, codigo, sigla) values (1, 'Nota Fiscal  1/1A  ', '01', 'Nf1');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (2, 'Nota Fiscal Avulsa  ', '1B', 'NfA');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (3, 'Nota Fiscal de Venda a Consumidor  2  ', '02', 'NFVC');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (4, 'Cupom Fiscal   - ECF IF', '2D', 'CF');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (5, 'Cupom Fiscal   - ECF PDV', '2C', 'CFPD');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (6, 'Cupom Fiscal   - ECF MR', '2B', 'CFMR');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (7, 'Cupom Fiscal Bilhete de Passagem  ', '2E', 'CFBP');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (8, 'Nota Fiscal de Produtor ', '04', 'NFP');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (9, 'Nota Fiscal/Conta de Energia Elétrica', '06', 'NFCE');
insert into fin_documento_origem (id, descricao, codigo, sigla) values (10, 'Nota Fiscal de Serviço de Transporte ', '07', 'NFST');


/*
	FINANCEIRO
*/
insert into fin_status_parcela (id, situacao, descricao, procedimento) values('1','01','Aberto',NULL);
insert into fin_status_parcela (id, situacao, descricao, procedimento) values('2','02','Quitado',NULL);
insert into fin_status_parcela (id, situacao, descricao, procedimento) values('3','03','Quitado Parcial',NULL);
insert into fin_status_parcela (id, situacao, descricao, procedimento) values('4','04','Vencido',NULL);
insert into fin_status_parcela (id, situacao, descricao, procedimento) values('5','05','Renegociado',NULL);

insert into fin_tipo_pagamento (id, codigo, descricao) values('1','01','Dinheiro');
insert into fin_tipo_pagamento (id, codigo, descricao) values('2','02','Cheque');
insert into fin_tipo_pagamento (id, codigo, descricao) values('3','03','Cartao');

insert into fin_tipo_recebimento (id, codigo, descricao) values('1','01','Dinheiro');
insert into fin_tipo_recebimento (id, codigo, descricao) values('2','02','Cheque');
insert into fin_tipo_recebimento (id, codigo, descricao) values('3','03','Cartao');


/*
	Dados de teste para tributação
*/

insert into tribut_operacao_fiscal (id, descricao, descricao_na_nf, cfop, observacao) values('1','VENDA A NAO CONTRIBUINTE','VENDA',NULL,'1. Venda a  não contribuinte. Ex. Consumidor final, Construtora ou empresas que comprem os PRODUTOs para uso próprio.');
insert into tribut_operacao_fiscal (id, descricao, descricao_na_nf, cfop, observacao) values('2','VENDA PARA LOJISTAS - REVENDEDOR','VENDA',NULL,'2. Venda para Lojistas (Revendedor)');
insert into tribut_operacao_fiscal (id, descricao, descricao_na_nf, cfop, observacao) values('3','VENDA PARA CONSUMIDOR FORA DO ESTADO','VENDA',NULL,'3. Venda Consumidor fora do Estado');
insert into tribut_operacao_fiscal (id, descricao, descricao_na_nf, cfop, observacao) values('4','VENDA A CONTRIBUINTE USUARIO FINAL','VENDA',NULL,'4. Venda a Contribuinte Usuário final (ex. construtora, empresa que comprem para consumo)');
insert into tribut_operacao_fiscal (id, descricao, descricao_na_nf, cfop, observacao) values('5','VENDA LOJISTA FORA DO ESTADO','VENDA',NULL,'5. Venda Lojista fora do Estado');
insert into tribut_operacao_fiscal (id, descricao, descricao_na_nf, cfop, observacao) values('6','SERVICO DENTRO DO ESTADO','PRESTACAO DE SERVICO','5933','NFE DE SERVICOS PARA DENTRO DO ESTADO');
insert into tribut_operacao_fiscal (id, descricao, descricao_na_nf, cfop, observacao) values('7','SERVICO FORA DO ESTADO','PRESTACAO DE SERVICO','6933','NFE DE SERVICOS PARA FORA DO ESTADO');

insert into tribut_grupo_tributario (id, descricao, origem_mercadoria, observacao) values('1','PRODUTO FABRICACAO PROPRIA SUJEITO AO ICMS ST','0','1. Produtos de fabricação própria (sujeitos ao ICMS ST)');
insert into tribut_grupo_tributario (id, descricao, origem_mercadoria, observacao) values('2','PRODUTO PARA REVENDA SUJEITO AO ICMS ST','0','2. Produtos de Revenda (sujeitos ao Regime do ICMS ST)');
insert into tribut_grupo_tributario (id, descricao, origem_mercadoria, observacao) values('3','PRODUTO PARA REVENDA NAO SUJEITO AO ICMS ST','0','3. Produtos de Revenda Não sujeitos ao ICMS ST');
insert into tribut_grupo_tributario (id, descricao, origem_mercadoria, observacao) values('4','SERVICO','0','SERVICO');

insert into tribut_configura_of_gt (id, id_tribut_grupo_tributario, id_tribut_operacao_fiscal) values('2','1','2');
insert into tribut_configura_of_gt (id, id_tribut_grupo_tributario, id_tribut_operacao_fiscal) values('3','1','5');

insert into tribut_cofins (id, id_tribut_configura_of_gt, cst_cofins, efd_tabela_435, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal) values('1','2','01','01','0','100.000000','3.000000',NULL,NULL,NULL);
insert into tribut_cofins (id, id_tribut_configura_of_gt, cst_cofins, efd_tabela_435, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal) values('2','3','01','01','0','100.000000','3.000000','0.000000','0.000000','0.000000');

insert into tribut_icms_uf (id, id_tribut_configura_of_gt, uf_destino, cfop, csosn, cst, modalidade_bc, aliquota, valor_pauta, valor_preco_maximo, mva, porcento_bc, modalidade_bc_st, aliquota_interna_st, aliquota_interestadual_st, porcento_bc_st, aliquota_icms_st, valor_pauta_st, valor_preco_maximo_st) values('1','2','DF','5101',NULL,'00','3','17.000000','0.000000','0.000000','0.000000','100.000000',NULL,'0.000000','0.000000','0.000000','0.000000','0.000000','0.000000');
insert into tribut_icms_uf (id, id_tribut_configura_of_gt, uf_destino, cfop, csosn, cst, modalidade_bc, aliquota, valor_pauta, valor_preco_maximo, mva, porcento_bc, modalidade_bc_st, aliquota_interna_st, aliquota_interestadual_st, porcento_bc_st, aliquota_icms_st, valor_pauta_st, valor_preco_maximo_st) values('2','3','SP','6401',NULL,'10','3','12.000000','0.000000','0.000000','40.000000','100.000000','4','18.000000','12.000000','100.000000','12.000000','0.000000','0.000000');
insert into tribut_icms_uf (id, id_tribut_configura_of_gt, uf_destino, cfop, csosn, cst, modalidade_bc, aliquota, valor_pauta, valor_preco_maximo, mva, porcento_bc, modalidade_bc_st, aliquota_interna_st, aliquota_interestadual_st, porcento_bc_st, aliquota_icms_st, valor_pauta_st, valor_preco_maximo_st) values('3','3','MG','6401',NULL,'10','3','12.000000','0.000000','0.000000','40.000000','100.000000','4','18.000000','12.000000','100.000000','12.000000','0.000000','0.000000');

insert into tribut_ipi (id, id_tribut_configura_of_gt, cst_ipi, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal) values('1','2','51','0',NULL,NULL,NULL,NULL,NULL);
insert into tribut_ipi (id, id_tribut_configura_of_gt, cst_ipi, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal) values('2','3','51','0','0.000000','0.000000','0.000000','0.000000','0.000000');

insert into tribut_pis (id, id_tribut_configura_of_gt, cst_pis, efd_tabela_435, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal) values('1','2','01','01','0','100.000000','0.650000',NULL,NULL,NULL);
insert into tribut_pis (id, id_tribut_configura_of_gt, cst_pis, efd_tabela_435, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal) values('2','3','01','01','0','100.000000','0.650000','0.000000','0.000000','0.000000');

insert into tribut_icms_custom_cab (id, descricao) values('1','ICMS CUSTOMIZADO 15%');

insert into tribut_icms_custom_det (id, id_tribut_icms_custom_cab, uf_destino, cfop, csosn, cst, modalidade_bc, aliquota, valor_pauta, valor_preco_maximo, mva, porcento_bc, modalidade_bc_st, aliquota_interna_st, aliquota_interestadual_st, porcento_bc_st, aliquota_icms_st, valor_pauta_st, valor_preco_maximo_st) values('1','1','CE','6102',NULL,'00','3','15.000000','0.000000','0.000000','0.000000','100.000000',NULL,'0.000000','0.000000','0.000000','0.000000','0.000000','0.000000');
insert into tribut_icms_custom_det (id, id_tribut_icms_custom_cab, uf_destino, cfop, csosn, cst, modalidade_bc, aliquota, valor_pauta, valor_preco_maximo, mva, porcento_bc, modalidade_bc_st, aliquota_interna_st, aliquota_interestadual_st, porcento_bc_st, aliquota_icms_st, valor_pauta_st, valor_preco_maximo_st) values('2','1','BA','6102',NULL,'00','3','15.000000','0.000000','0.000000','0.000000','100.000000',NULL,'0.000000','0.000000','0.000000','0.000000','0.000000','0.000000');

insert into tribut_iss (id, id_tribut_operacao_fiscal, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal, item_lista_servico, codigo_tributacao) values('1','6','0','100.000000','3.000000','0.000000','0.000000','0.000000','803','N');
insert into tribut_iss (id, id_tribut_operacao_fiscal, modalidade_base_calculo, porcento_base_calculo, aliquota_porcento, aliquota_unidade, valor_preco_maximo, valor_pauta_fiscal, item_lista_servico, codigo_tributacao) values('2','7','0','100.000000','5.000000','0.000000','0.000000','0.000000','802','N');


/*
  NOTA_FISCAL_MODELO
  -------
*/
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('1','01','Nota Fiscal','1/1A');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('2','1B','Nota Fiscal Avulsa','-');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('3','02','Nota Fiscal de Venda a Consumidor','2');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('4','2D','Cupom Fiscal','-');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('5','2E','Cupom Fiscal Bilhete de Passagem','-');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('6','04','Nota Fiscal de Produtor','4');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('7','06','Nota Fiscal/Conta de Energia Elétrica','6');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('8','07','Nota Fiscal de Serviço de Transporte','7');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('9','08','Conhecimento de Transporte Rodoviário de Cargas','8');
insert into nota_fiscal_modelo (id, codigo, descricao, modelo) values('10','8B','Conhecimento de Transporte de Cargas Avulso','-');


/*
	COMPRAS
*/
insert into compra_tipo_requisicao (id, codigo, nome, descricao) values('1','01','INTERNA',NULL);
insert into compra_tipo_requisicao (id, codigo, nome, descricao) values('2','02','EXTERNA',NULL);

insert into compra_tipo_pedido (id, codigo, nome, descricao) values('1','01','NORMAL',NULL);
insert into compra_tipo_pedido (id, codigo, nome, descricao) values('2','02','PLANEJADO',NULL);
insert into compra_tipo_pedido (id, codigo, nome, descricao) values('3','03','ABERTO',NULL);

/*
	NFS-e
*/
insert into nfse_lista_servico (codigo, descricao) values ('1.01', 'Análise e desenvolvimento de sistemas.');
insert into nfse_lista_servico (codigo, descricao) values ('1.02', 'Programação.');
insert into nfse_lista_servico (codigo, descricao) values ('1.03', 'Processamento de dados e congêneres.');
insert into nfse_lista_servico (codigo, descricao) values ('1.04', 'Elaboração de programas de computadores, inclusive de jogos eletrônicos.');
insert into nfse_lista_servico (codigo, descricao) values ('1.05', 'Licenciamento ou cessão de direito de uso de programas de computação.');
insert into nfse_lista_servico (codigo, descricao) values ('1.06', 'Assessoria e consultoria em informática.');
insert into nfse_lista_servico (codigo, descricao) values ('1.07', 'Suporte técnico em informática, inclusive instalação, configuração e manutenção de programas de computação e bancos de dados.');
insert into nfse_lista_servico (codigo, descricao) values ('1.08', 'Planejamento, confecção, manutenção e atualização de páginas eletrônicas.');

/*
  IBPT
  -------
*/
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('1','0','','0','PRODUTO NAO ESPECIFICADO NA LISTA DE NCM','7.850000','9.850000','0.000000','0.000000','2021-02-01','2021-04-30','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('2','1012100','','0','Cavalos reprodutores,de raca pura','4.200000','6.200000','18.000000','0.000000','2021-02-02','2021-05-01','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('3','1012900','','0','Cavalos vivos,exceto reprodutores de raca pura','4.200000','6.880000','18.000000','0.000000','2021-02-03','2021-05-02','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('4','1013000','','0','Asininos','4.200000','7.530000','18.000000','0.000000','2021-02-04','2021-05-03','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('5','1019000','','0','Outros asininos e muares,vivos','4.200000','7.530000','18.000000','0.000000','2021-02-05','2021-05-04','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('6','1022110','','0','Bovinos reprodutores,de raca pura,prenhe ou com cria ao pe','4.200000','6.200000','18.000000','0.000000','2021-02-06','2021-05-05','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('7','1022190','','0','Outros bovinos reprodutores,de raca pura','4.200000','6.200000','18.000000','0.000000','2021-02-07','2021-05-06','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('8','1022911','','0','Outros bovinos para reprodução, prenhe ou com cria ao pe','4.200000','6.880000','18.000000','0.000000','2021-02-08','2021-05-07','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('9','1022919','','0','Outros bovinos domésticos para reprodução','4.200000','6.880000','18.000000','0.000000','2021-02-09','2021-05-08','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');
insert into ibpt (id, ncm, ex, tipo, descricao, nacional_federal, importados_federal, estadual, municipal, vigencia_inicio, vigencia_fim, chave, versao, fonte) values('10','1022990','','0','Outros bovinos domésticos','4.200000','6.880000','18.000000','0.000000','2021-02-10','2021-05-09','8F6CA7','21.1.A','IBPT/empresometro.com.br\r');