<?php

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Psr7\Response;

use Firebase\JWT\BeforeValidException;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\JWT;
use Firebase\JWT\SignatureInvalidException;

class LoginController extends ControllerBase
{

    private static $key = MAIN_KEY;
    private static $alg = array('HS256');

    // method called by Slim before processing requests for routes that MiddleWare has added
    public function __invoke(Request $request, RequestHandler $handler): Response
    {
        $token = null;
        $header = $request->getHeader("authorization");
        if (count($header) == 1) {
            $token = substr($header[0], 7); // fetches the token in the request header
        }

        if (isset($token)) {
            if ($this->checkToken($token)) {
                return $handler->handle($request); //if the token is valid process the request
            }
        }
        
        // if the token is invalid, it returns an http 401.
        $response = new Response();
        return parent::handleError($response, 401, 'Unauthorized', null);
    }

    // perform user authentication => 
    public function login($request, $response, $args) {
        try {
            // get the request object
            $user = json_decode($request->getBody());
            
            // validate the object
            if (!isset($user)) {
                return parent::handleError($response, 400, 'Invalid object [Login]', null);
            }
            
            $login = $user->login;
            $senha = $user->senha;

            $filter = new Filter(null);
            $filter->where = " t.login = '$login' AND t.senha = '$senha' ";
            
            // TODO: adapt the authentication according to your need
            // $return = UserService::login($filter);

            if (empty($return)) {
                // if the user data is INCORRECT it returns an http 401.
                return parent::handleError($response, 401, 'Invalid username and/or password', null);
            } else {
                // if the user data is correct, it generates the token and returns it in the request header.
                $token = $this->generateToken($login);

				$response->getBody()->write('{"token": "' . $token . '"}');

                return $response
                    ->withHeader('Content-Type', 'application/json')
					->withStatus(200);
			}
        } catch (Exception $e) {
            return parent::handleError($response, 500, 'Server Error [Login]', $e);
        }
    }

    private function generateToken(string $subject): string
    {
        $token = array(
            "sub" => $subject
        );

        return JWT::encode($token, self::$key);
    }

    private function checkToken(string $token): bool
    {
        if ($token != null) {
            try {
                JWT::decode($token, self::$key, self::$alg);

                return true;
            } catch (UnexpectedValueException | SignatureInvalidException | BeforeValidException | ExpiredException $e) {
                return false;
            }
        }
        return false;
    }
    
}