<?php
declare(strict_types=1);

class EmpresaPlanoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'empresa_plano';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'erpTipoPlanoModel',
	];

	/**
		* Relations
		*/
	public function erpTipoPlanoModel()
	{
		return $this->belongsTo(ErpTipoPlanoModel::class, 'id_erp_tipo_plano', 'id');
	}

	public function empresaModel()
	{
		return $this->belongsTo(EmpresaModel::class, 'id_empresa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getValorPagoAttribute()
	{
		return (double)$this->attributes['valor_pago'];
	}

	public function setValorPagoAttribute($valorPago)
	{
		$this->attributes['valor_pago'] = $valorPago;
	}

	public function getIdPagamentoPlataformaAttribute()
	{
		return $this->attributes['id_pagamento_plataforma'];
	}

	public function setIdPagamentoPlataformaAttribute($idPagamentoPlataforma)
	{
		$this->attributes['id_pagamento_plataforma'] = $idPagamentoPlataforma;
	}

	public function getStatusPagamentoPlataformaAttribute()
	{
		return $this->attributes['status_pagamento_plataforma'];
	}

	public function setStatusPagamentoPlataformaAttribute($statusPagamentoPlataforma)
	{
		$this->attributes['status_pagamento_plataforma'] = $statusPagamentoPlataforma;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);
				$this->setValorPagoAttribute($object->valorPago);
				$this->setIdPagamentoPlataformaAttribute($object->idPagamentoPlataforma);
				$this->setStatusPagamentoPlataformaAttribute($object->statusPagamentoPlataforma);

				// link objects - lookups
				$erpTipoPlanoModel = new ErpTipoPlanoModel();
				$erpTipoPlanoModel->mapping($object->erpTipoPlanoModel);
				$this->erpTipoPlanoModel()->associate($erpTipoPlanoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'valorPago' => $this->getValorPagoAttribute(),
				'idPagamentoPlataforma' => $this->getIdPagamentoPlataformaAttribute(),
				'statusPagamentoPlataforma' => $this->getStatusPagamentoPlataformaAttribute(),
				'erpTipoPlanoModel' => $this->erpTipoPlanoModel,
			];
	}
}