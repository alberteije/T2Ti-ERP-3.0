<?php
declare(strict_types=1);

class EmpresaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'empresa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeConfiguracaoModelList',
		'pdvPlanoPagamentoModelList',
		'acbrMonitorPortaModelList',
		'empresaPlanoModelList',
		'admModuloModelList',
	];

	/**
		* Relations
		*/
	public function nfeConfiguracaoModelList()
{
	return $this->hasMany(NfeConfiguracaoModel::class, 'id_empresa', 'id');
}

	public function pdvPlanoPagamentoModelList()
{
	return $this->hasMany(PdvPlanoPagamentoModel::class, 'id_empresa', 'id');
}

	public function acbrMonitorPortaModelList()
{
	return $this->hasMany(AcbrMonitorPortaModel::class, 'id_empresa', 'id');
}

	public function empresaPlanoModelList()
{
	return $this->hasMany(EmpresaPlanoModel::class, 'id_empresa', 'id');
}

	public function admModuloModelList()
{
	return $this->hasMany(AdmModuloModel::class, 'id_empresa', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getRazaoSocialAttribute()
	{
		return $this->attributes['razao_social'];
	}

	public function setRazaoSocialAttribute($razaoSocial)
	{
		$this->attributes['razao_social'] = $razaoSocial;
	}

	public function getNomeFantasiaAttribute()
	{
		return $this->attributes['nome_fantasia'];
	}

	public function setNomeFantasiaAttribute($nomeFantasia)
	{
		$this->attributes['nome_fantasia'] = $nomeFantasia;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	public function getInscricaoMunicipalAttribute()
	{
		return $this->attributes['inscricao_municipal'];
	}

	public function setInscricaoMunicipalAttribute($inscricaoMunicipal)
	{
		$this->attributes['inscricao_municipal'] = $inscricaoMunicipal;
	}

	public function getTipoRegimeAttribute()
	{
		return $this->attributes['tipo_regime'];
	}

	public function setTipoRegimeAttribute($tipoRegime)
	{
		$this->attributes['tipo_regime'] = $tipoRegime;
	}

	public function getCrtAttribute()
	{
		return $this->attributes['crt'];
	}

	public function setCrtAttribute($crt)
	{
		$this->attributes['crt'] = $crt;
	}

	public function getDataConstituicaoAttribute()
	{
		return $this->attributes['data_constituicao'];
	}

	public function setDataConstituicaoAttribute($dataConstituicao)
	{
		$this->attributes['data_constituicao'] = $dataConstituicao;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getComplementoAttribute()
	{
		return $this->attributes['complemento'];
	}

	public function setComplementoAttribute($complemento)
	{
		$this->attributes['complemento'] = $complemento;
	}

	public function getCepAttribute()
	{
		return $this->attributes['cep'];
	}

	public function setCepAttribute($cep)
	{
		$this->attributes['cep'] = $cep;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getCidadeAttribute()
	{
		return $this->attributes['cidade'];
	}

	public function setCidadeAttribute($cidade)
	{
		$this->attributes['cidade'] = $cidade;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getFoneAttribute()
	{
		return $this->attributes['fone'];
	}

	public function setFoneAttribute($fone)
	{
		$this->attributes['fone'] = $fone;
	}

	public function getContatoAttribute()
	{
		return $this->attributes['contato'];
	}

	public function setContatoAttribute($contato)
	{
		$this->attributes['contato'] = $contato;
	}

	public function getCodigoIbgeCidadeAttribute()
	{
		return $this->attributes['codigo_ibge_cidade'];
	}

	public function setCodigoIbgeCidadeAttribute($codigoIbgeCidade)
	{
		$this->attributes['codigo_ibge_cidade'] = $codigoIbgeCidade;
	}

	public function getCodigoIbgeUfAttribute()
	{
		return $this->attributes['codigo_ibge_uf'];
	}

	public function setCodigoIbgeUfAttribute($codigoIbgeUf)
	{
		$this->attributes['codigo_ibge_uf'] = $codigoIbgeUf;
	}

	public function getLogotipoAttribute()
	{
		return $this->attributes['logotipo'];
	}

	public function setLogotipoAttribute($logotipo)
	{
		$this->attributes['logotipo'] = $logotipo;
	}

	public function getRegistradoAttribute()
	{
		return $this->attributes['registrado'];
	}

	public function setRegistradoAttribute($registrado)
	{
		$this->attributes['registrado'] = $registrado;
	}

	public function getNaturezaJuridicaAttribute()
	{
		return $this->attributes['natureza_juridica'];
	}

	public function setNaturezaJuridicaAttribute($naturezaJuridica)
	{
		$this->attributes['natureza_juridica'] = $naturezaJuridica;
	}

	public function getSimeiAttribute()
	{
		return $this->attributes['simei'];
	}

	public function setSimeiAttribute($simei)
	{
		$this->attributes['simei'] = $simei;
	}

	public function getEmailPagamentoAttribute()
	{
		return $this->attributes['email_pagamento'];
	}

	public function setEmailPagamentoAttribute($emailPagamento)
	{
		$this->attributes['email_pagamento'] = $emailPagamento;
	}

	public function getDataRegistroAttribute()
	{
		return $this->attributes['data_registro'];
	}

	public function setDataRegistroAttribute($dataRegistro)
	{
		$this->attributes['data_registro'] = $dataRegistro;
	}

	public function getHoraRegistroAttribute()
	{
		return $this->attributes['hora_registro'];
	}

	public function setHoraRegistroAttribute($horaRegistro)
	{
		$this->attributes['hora_registro'] = $horaRegistro;
	}

	public function getIdPlataformaPagamentoAttribute()
	{
		return $this->attributes['id_plataforma_pagamento'];
	}

	public function setIdPlataformaPagamentoAttribute($idPlataformaPagamento)
	{
		$this->attributes['id_plataforma_pagamento'] = $idPlataformaPagamento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setRazaoSocialAttribute($object->razaoSocial);
				$this->setNomeFantasiaAttribute($object->nomeFantasia);
				$this->setCnpjAttribute($object->cnpj);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);
				$this->setInscricaoMunicipalAttribute($object->inscricaoMunicipal);
				$this->setTipoRegimeAttribute($object->tipoRegime);
				$this->setCrtAttribute($object->crt);
				$this->setDataConstituicaoAttribute($object->dataConstituicao);
				$this->setTipoAttribute($object->tipo);
				$this->setEmailAttribute($object->email);
				$this->setLogradouroAttribute($object->logradouro);
				$this->setNumeroAttribute($object->numero);
				$this->setComplementoAttribute($object->complemento);
				$this->setCepAttribute($object->cep);
				$this->setBairroAttribute($object->bairro);
				$this->setCidadeAttribute($object->cidade);
				$this->setUfAttribute($object->uf);
				$this->setFoneAttribute($object->fone);
				$this->setContatoAttribute($object->contato);
				$this->setCodigoIbgeCidadeAttribute($object->codigoIbgeCidade);
				$this->setCodigoIbgeUfAttribute($object->codigoIbgeUf);
				$this->setLogotipoAttribute($object->logotipo);
				$this->setRegistradoAttribute($object->registrado);
				$this->setNaturezaJuridicaAttribute($object->naturezaJuridica);
				$this->setSimeiAttribute($object->simei);
				$this->setEmailPagamentoAttribute($object->emailPagamento);
				$this->setDataRegistroAttribute($object->dataRegistro);
				$this->setHoraRegistroAttribute($object->horaRegistro);
				$this->setIdPlataformaPagamentoAttribute($object->idPlataformaPagamento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'razaoSocial' => $this->getRazaoSocialAttribute(),
				'nomeFantasia' => $this->getNomeFantasiaAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
				'inscricaoMunicipal' => $this->getInscricaoMunicipalAttribute(),
				'tipoRegime' => $this->getTipoRegimeAttribute(),
				'crt' => $this->getCrtAttribute(),
				'dataConstituicao' => $this->getDataConstituicaoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'email' => $this->getEmailAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'complemento' => $this->getComplementoAttribute(),
				'cep' => $this->getCepAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'cidade' => $this->getCidadeAttribute(),
				'uf' => $this->getUfAttribute(),
				'fone' => $this->getFoneAttribute(),
				'contato' => $this->getContatoAttribute(),
				'codigoIbgeCidade' => $this->getCodigoIbgeCidadeAttribute(),
				'codigoIbgeUf' => $this->getCodigoIbgeUfAttribute(),
				'logotipo' => $this->getLogotipoAttribute(),
				'registrado' => $this->getRegistradoAttribute(),
				'naturezaJuridica' => $this->getNaturezaJuridicaAttribute(),
				'simei' => $this->getSimeiAttribute(),
				'emailPagamento' => $this->getEmailPagamentoAttribute(),
				'dataRegistro' => $this->getDataRegistroAttribute(),
				'horaRegistro' => $this->getHoraRegistroAttribute(),
				'idPlataformaPagamento' => $this->getIdPlataformaPagamentoAttribute(),
				'nfeConfiguracaoModelList' => $this->nfeConfiguracaoModelList,
				'pdvPlanoPagamentoModelList' => $this->pdvPlanoPagamentoModelList,
				'acbrMonitorPortaModelList' => $this->acbrMonitorPortaModelList,
				'empresaPlanoModelList' => $this->empresaPlanoModelList,
				'admModuloModelList' => $this->admModuloModelList,
			];
	}
}