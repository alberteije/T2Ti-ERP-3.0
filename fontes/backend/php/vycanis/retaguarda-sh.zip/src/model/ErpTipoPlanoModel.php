<?php
declare(strict_types=1);

class ErpTipoPlanoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'erp_tipo_plano';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getFrequenciaAttribute()
	{
		return $this->attributes['frequencia'];
	}

	public function setFrequenciaAttribute($frequencia)
	{
		$this->attributes['frequencia'] = $frequencia;
	}

	public function getAcessoTotalAttribute()
	{
		return $this->attributes['acesso_total'];
	}

	public function setAcessoTotalAttribute($acessoTotal)
	{
		$this->attributes['acesso_total'] = $acessoTotal;
	}

	public function getAtivoAttribute()
	{
		return $this->attributes['ativo'];
	}

	public function setAtivoAttribute($ativo)
	{
		$this->attributes['ativo'] = $ativo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setValorAttribute($object->valor);
				$this->setFrequenciaAttribute($object->frequencia);
				$this->setAcessoTotalAttribute($object->acessoTotal);
				$this->setAtivoAttribute($object->ativo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'valor' => $this->getValorAttribute(),
				'frequencia' => $this->getFrequenciaAttribute(),
				'acessoTotal' => $this->getAcessoTotalAttribute() === 1 ? true : false,
				'ativo' => $this->getAtivoAttribute() === 1 ? true : false,
			];
	}
}