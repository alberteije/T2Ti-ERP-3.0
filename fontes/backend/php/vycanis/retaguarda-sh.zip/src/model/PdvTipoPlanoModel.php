<?php
declare(strict_types=1);

class PdvTipoPlanoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pdv_tipo_plano';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pdvPlanoPagamentoModelList',
	];

	/**
		* Relations
		*/
	public function pdvPlanoPagamentoModelList()
{
	return $this->hasMany(PdvPlanoPagamentoModel::class, 'id_pdv_tipo_plano', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getModuloAttribute()
	{
		return $this->attributes['modulo'];
	}

	public function setModuloAttribute($modulo)
	{
		$this->attributes['modulo'] = $modulo;
	}

	public function getPlanoAttribute()
	{
		return $this->attributes['plano'];
	}

	public function setPlanoAttribute($plano)
	{
		$this->attributes['plano'] = $plano;
	}

	public function getModuloFiscalAttribute()
	{
		return $this->attributes['modulo_fiscal'];
	}

	public function setModuloFiscalAttribute($moduloFiscal)
	{
		$this->attributes['modulo_fiscal'] = $moduloFiscal;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setModuloAttribute($object->modulo);
				$this->setPlanoAttribute($object->plano);
				$this->setModuloFiscalAttribute($object->moduloFiscal);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'modulo' => $this->getModuloAttribute(),
				'plano' => $this->getPlanoAttribute(),
				'moduloFiscal' => $this->getModuloFiscalAttribute(),
				'valor' => $this->getValorAttribute(),
				'pdvPlanoPagamentoModelList' => $this->pdvPlanoPagamentoModelList,
			];
	}
}