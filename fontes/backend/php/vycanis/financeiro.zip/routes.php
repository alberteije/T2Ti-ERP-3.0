<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// talonario-cheque
$app->get('/talonario-cheque[/]', \TalonarioChequeController::class . RESULT_LIST);
$app->get('/talonario-cheque/{id}', \TalonarioChequeController::class . RESULT_OBJECT);
$app->post('/talonario-cheque', \TalonarioChequeController::class . INSERT);
$app->put('/talonario-cheque', \TalonarioChequeController::class . UPDATE);
$app->delete('/talonario-cheque/{id}', \TalonarioChequeController::class . DELETE);
$app->options('/talonario-cheque', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/talonario-cheque/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/talonario-cheque/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-lancamento-pagar
$app->get('/fin-lancamento-pagar[/]', \FinLancamentoPagarController::class . RESULT_LIST);
$app->get('/fin-lancamento-pagar/{id}', \FinLancamentoPagarController::class . RESULT_OBJECT);
$app->post('/fin-lancamento-pagar', \FinLancamentoPagarController::class . INSERT);
$app->put('/fin-lancamento-pagar', \FinLancamentoPagarController::class . UPDATE);
$app->delete('/fin-lancamento-pagar/{id}', \FinLancamentoPagarController::class . DELETE);
$app->options('/fin-lancamento-pagar', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-lancamento-pagar/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-lancamento-pagar/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-lancamento-receber
$app->get('/fin-lancamento-receber[/]', \FinLancamentoReceberController::class . RESULT_LIST);
$app->get('/fin-lancamento-receber/{id}', \FinLancamentoReceberController::class . RESULT_OBJECT);
$app->post('/fin-lancamento-receber', \FinLancamentoReceberController::class . INSERT);
$app->put('/fin-lancamento-receber', \FinLancamentoReceberController::class . UPDATE);
$app->delete('/fin-lancamento-receber/{id}', \FinLancamentoReceberController::class . DELETE);
$app->options('/fin-lancamento-receber', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-lancamento-receber/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-lancamento-receber/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco
$app->get('/banco[/]', \BancoController::class . RESULT_LIST);
$app->get('/banco/{id}', \BancoController::class . RESULT_OBJECT);
$app->post('/banco', \BancoController::class . INSERT);
$app->put('/banco', \BancoController::class . UPDATE);
$app->delete('/banco/{id}', \BancoController::class . DELETE);
$app->options('/banco', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco-agencia
$app->get('/banco-agencia[/]', \BancoAgenciaController::class . RESULT_LIST);
$app->get('/banco-agencia/{id}', \BancoAgenciaController::class . RESULT_OBJECT);
$app->post('/banco-agencia', \BancoAgenciaController::class . INSERT);
$app->put('/banco-agencia', \BancoAgenciaController::class . UPDATE);
$app->delete('/banco-agencia/{id}', \BancoAgenciaController::class . DELETE);
$app->options('/banco-agencia', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-agencia/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-agencia/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco-conta-caixa
$app->get('/banco-conta-caixa[/]', \BancoContaCaixaController::class . RESULT_LIST);
$app->get('/banco-conta-caixa/{id}', \BancoContaCaixaController::class . RESULT_OBJECT);
$app->post('/banco-conta-caixa', \BancoContaCaixaController::class . INSERT);
$app->put('/banco-conta-caixa', \BancoContaCaixaController::class . UPDATE);
$app->delete('/banco-conta-caixa/{id}', \BancoContaCaixaController::class . DELETE);
$app->options('/banco-conta-caixa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-conta-caixa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-conta-caixa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-fechamento-caixa-banco
$app->get('/fin-fechamento-caixa-banco[/]', \FinFechamentoCaixaBancoController::class . RESULT_LIST);
$app->get('/fin-fechamento-caixa-banco/{id}', \FinFechamentoCaixaBancoController::class . RESULT_OBJECT);
$app->post('/fin-fechamento-caixa-banco', \FinFechamentoCaixaBancoController::class . INSERT);
$app->put('/fin-fechamento-caixa-banco', \FinFechamentoCaixaBancoController::class . UPDATE);
$app->delete('/fin-fechamento-caixa-banco/{id}', \FinFechamentoCaixaBancoController::class . DELETE);
$app->options('/fin-fechamento-caixa-banco', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-fechamento-caixa-banco/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-fechamento-caixa-banco/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-extrato-conta-banco
$app->get('/fin-extrato-conta-banco[/]', \FinExtratoContaBancoController::class . RESULT_LIST);
$app->get('/fin-extrato-conta-banco/{id}', \FinExtratoContaBancoController::class . RESULT_OBJECT);
$app->post('/fin-extrato-conta-banco', \FinExtratoContaBancoController::class . INSERT);
$app->put('/fin-extrato-conta-banco', \FinExtratoContaBancoController::class . UPDATE);
$app->delete('/fin-extrato-conta-banco/{id}', \FinExtratoContaBancoController::class . DELETE);
$app->options('/fin-extrato-conta-banco', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-extrato-conta-banco/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-extrato-conta-banco/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-documento-origem
$app->get('/fin-documento-origem[/]', \FinDocumentoOrigemController::class . RESULT_LIST);
$app->get('/fin-documento-origem/{id}', \FinDocumentoOrigemController::class . RESULT_OBJECT);
$app->post('/fin-documento-origem', \FinDocumentoOrigemController::class . INSERT);
$app->put('/fin-documento-origem', \FinDocumentoOrigemController::class . UPDATE);
$app->delete('/fin-documento-origem/{id}', \FinDocumentoOrigemController::class . DELETE);
$app->options('/fin-documento-origem', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-documento-origem/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-documento-origem/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-natureza-financeira
$app->get('/fin-natureza-financeira[/]', \FinNaturezaFinanceiraController::class . RESULT_LIST);
$app->get('/fin-natureza-financeira/{id}', \FinNaturezaFinanceiraController::class . RESULT_OBJECT);
$app->post('/fin-natureza-financeira', \FinNaturezaFinanceiraController::class . INSERT);
$app->put('/fin-natureza-financeira', \FinNaturezaFinanceiraController::class . UPDATE);
$app->delete('/fin-natureza-financeira/{id}', \FinNaturezaFinanceiraController::class . DELETE);
$app->options('/fin-natureza-financeira', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-natureza-financeira/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-natureza-financeira/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-status-parcela
$app->get('/fin-status-parcela[/]', \FinStatusParcelaController::class . RESULT_LIST);
$app->get('/fin-status-parcela/{id}', \FinStatusParcelaController::class . RESULT_OBJECT);
$app->post('/fin-status-parcela', \FinStatusParcelaController::class . INSERT);
$app->put('/fin-status-parcela', \FinStatusParcelaController::class . UPDATE);
$app->delete('/fin-status-parcela/{id}', \FinStatusParcelaController::class . DELETE);
$app->options('/fin-status-parcela', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-status-parcela/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-status-parcela/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-tipo-pagamento
$app->get('/fin-tipo-pagamento[/]', \FinTipoPagamentoController::class . RESULT_LIST);
$app->get('/fin-tipo-pagamento/{id}', \FinTipoPagamentoController::class . RESULT_OBJECT);
$app->post('/fin-tipo-pagamento', \FinTipoPagamentoController::class . INSERT);
$app->put('/fin-tipo-pagamento', \FinTipoPagamentoController::class . UPDATE);
$app->delete('/fin-tipo-pagamento/{id}', \FinTipoPagamentoController::class . DELETE);
$app->options('/fin-tipo-pagamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-tipo-pagamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-tipo-pagamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-cheque-emitido
$app->get('/fin-cheque-emitido[/]', \FinChequeEmitidoController::class . RESULT_LIST);
$app->get('/fin-cheque-emitido/{id}', \FinChequeEmitidoController::class . RESULT_OBJECT);
$app->post('/fin-cheque-emitido', \FinChequeEmitidoController::class . INSERT);
$app->put('/fin-cheque-emitido', \FinChequeEmitidoController::class . UPDATE);
$app->delete('/fin-cheque-emitido/{id}', \FinChequeEmitidoController::class . DELETE);
$app->options('/fin-cheque-emitido', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-cheque-emitido/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-cheque-emitido/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-tipo-recebimento
$app->get('/fin-tipo-recebimento[/]', \FinTipoRecebimentoController::class . RESULT_LIST);
$app->get('/fin-tipo-recebimento/{id}', \FinTipoRecebimentoController::class . RESULT_OBJECT);
$app->post('/fin-tipo-recebimento', \FinTipoRecebimentoController::class . INSERT);
$app->put('/fin-tipo-recebimento', \FinTipoRecebimentoController::class . UPDATE);
$app->delete('/fin-tipo-recebimento/{id}', \FinTipoRecebimentoController::class . DELETE);
$app->options('/fin-tipo-recebimento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-tipo-recebimento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-tipo-recebimento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-cheque-recebido
$app->get('/fin-cheque-recebido[/]', \FinChequeRecebidoController::class . RESULT_LIST);
$app->get('/fin-cheque-recebido/{id}', \FinChequeRecebidoController::class . RESULT_OBJECT);
$app->post('/fin-cheque-recebido', \FinChequeRecebidoController::class . INSERT);
$app->put('/fin-cheque-recebido', \FinChequeRecebidoController::class . UPDATE);
$app->delete('/fin-cheque-recebido/{id}', \FinChequeRecebidoController::class . DELETE);
$app->options('/fin-cheque-recebido', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-cheque-recebido/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-cheque-recebido/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-configuracao-boleto
$app->get('/fin-configuracao-boleto[/]', \FinConfiguracaoBoletoController::class . RESULT_LIST);
$app->get('/fin-configuracao-boleto/{id}', \FinConfiguracaoBoletoController::class . RESULT_OBJECT);
$app->post('/fin-configuracao-boleto', \FinConfiguracaoBoletoController::class . INSERT);
$app->put('/fin-configuracao-boleto', \FinConfiguracaoBoletoController::class . UPDATE);
$app->delete('/fin-configuracao-boleto/{id}', \FinConfiguracaoBoletoController::class . DELETE);
$app->options('/fin-configuracao-boleto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-configuracao-boleto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-configuracao-boleto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-cliente
$app->get('/view-pessoa-cliente[/]', \ViewPessoaClienteController::class . RESULT_LIST);
$app->get('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . RESULT_OBJECT);
$app->post('/view-pessoa-cliente', \ViewPessoaClienteController::class . INSERT);
$app->put('/view-pessoa-cliente', \ViewPessoaClienteController::class . UPDATE);
$app->delete('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . DELETE);
$app->options('/view-pessoa-cliente', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-fornecedor
$app->get('/view-pessoa-fornecedor[/]', \ViewPessoaFornecedorController::class . RESULT_LIST);
$app->get('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . INSERT);
$app->put('/view-pessoa-fornecedor', \ViewPessoaFornecedorController::class . UPDATE);
$app->delete('/view-pessoa-fornecedor/{id}', \ViewPessoaFornecedorController::class . DELETE);
$app->options('/view-pessoa-fornecedor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-fornecedor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

