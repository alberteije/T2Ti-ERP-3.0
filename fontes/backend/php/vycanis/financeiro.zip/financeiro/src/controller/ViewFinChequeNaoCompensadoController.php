<?php
class ViewFinChequeNaoCompensadoController extends ControllerBase
{

		private $viewFinChequeNaoCompensadoService = null;

		public function __construct()
		{	 
				$this->viewFinChequeNaoCompensadoService = new ViewFinChequeNaoCompensadoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->viewFinChequeNaoCompensadoService->getListFilter($filter);
						} else {
								$resultList = $this->viewFinChequeNaoCompensadoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList ViewFinChequeNaoCompensado]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->viewFinChequeNaoCompensadoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject ViewFinChequeNaoCompensado]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject ViewFinChequeNaoCompensado]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert ViewFinChequeNaoCompensado]', null);
						}

						$objModel = new ViewFinChequeNaoCompensadoModel();
						$objModel->mapping($objJson);

						$this->viewFinChequeNaoCompensadoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert ViewFinChequeNaoCompensado]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->viewFinChequeNaoCompensadoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update ViewFinChequeNaoCompensado]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->viewFinChequeNaoCompensadoService->save($objFromDatabase);
								$objFromDatabase = $this->viewFinChequeNaoCompensadoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update ViewFinChequeNaoCompensado]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->viewFinChequeNaoCompensadoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete ViewFinChequeNaoCompensado]', null);
						} else {
								$this->viewFinChequeNaoCompensadoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete ViewFinChequeNaoCompensado]', $e);
				}
		}
}
