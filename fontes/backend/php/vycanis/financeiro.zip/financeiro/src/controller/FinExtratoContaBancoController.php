<?php
class FinExtratoContaBancoController extends ControllerBase
{

	private $finExtratoContaBancoService = null;

	public function __construct()
	{
		$this->finExtratoContaBancoService = new FinExtratoContaBancoService();
	}

	public function getList($request, $response, $args)
	{
		try {
			if (count($request->getQueryParams()) > 0) {
				$filter = new Filter(parent::handleFilter($request));
				$resultList = $this->finExtratoContaBancoService->getListFilter($filter);
			} else {
				$resultList = $this->finExtratoContaBancoService->getList();
			}
			$return = json_encode($resultList);
			$response->getBody()->write($return);
			return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [getList FinExtratoContaBanco]', $e);
		}
	}

	public function getObject($request, $response, $args)
	{
		try {
			$objFromDatabase = $this->finExtratoContaBancoService->getObject($args['id']);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 404, 'Not Found [getObject FinExtratoContaBanco]', null);
			} else {
				$return = json_encode($objFromDatabase);
				$response->getBody()->write($return);
				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [getObject FinExtratoContaBanco]', $e);
		}
	}

	public function insert($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			if (!isset($objJson)) {
				return parent::handleError($response, 400, 'Invalid Object [insert FinExtratoContaBanco]', null);
			}

			$objModel = new FinExtratoContaBancoModel();
			$objModel->mapping($objJson);

			$this->finExtratoContaBancoService->save($objModel);

			$return = json_encode($objModel);
			$response->getBody()->write($return);

			return $response
				->withStatus(201)
				->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [insert FinExtratoContaBanco]', $e);
		}
	}

	public function insertBatch($request, $response, $args)
	{
		try {
			$data = json_decode($request->getBody(), true);

			if (!isset($data)) {
				return parent::handleError($response, 400, 'Invalid Data [insertBatch FinExtratoContaBanco]', null);
			}

			if (!isset($data['lancamentos']) || !isset($data['mesAno'])) {
				return parent::handleError($response, 400, 'Invalid Data Structure [insertBatch FinExtratoContaBanco]', null);
			}

			$lancamentosData = $data['lancamentos'];
			$mesAno = $data['mesAno'];
			list($mes, $ano) = explode('/', $mesAno);

			// Primeiro deleta os registros do mês/ano
			$this->finExtratoContaBancoService->deleteByMonthYear($mes, $ano);

			// Prepara os dados no formato do banco usando o Model
			$dadosParaInserir = array_map(function ($lancamentoData) {
				return FinExtratoContaBancoModel::toDatabaseFormat((object)$lancamentoData);
			}, $lancamentosData);

			// Insere os novos registros
			$result = $this->finExtratoContaBancoService->saveBatch($dadosParaInserir);

			$response->getBody()->write(json_encode([
				'success' => true,
				'count' => count($dadosParaInserir),
				'mesAno' => $mesAno
			]));

			return $response
				->withStatus(201)
				->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [insertBatch FinExtratoContaBanco]', $e);
		}
	}

	public function update($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			$objFromDatabase = $this->finExtratoContaBancoService->getObject($objJson->id);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [update FinExtratoContaBanco]', null);
			} else {
				$objFromDatabase->mapping($objJson);

				$this->finExtratoContaBancoService->save($objFromDatabase);
				$objFromDatabase = $this->finExtratoContaBancoService->getObject($objJson->id);

				$return = json_encode($objFromDatabase);
				$response->getBody()->write($return);
				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [update FinExtratoContaBanco]', $e);
		}
	}

	public function delete($request, $response, $args)
	{
		try {
			$objFromDatabase = $this->finExtratoContaBancoService->getObject($args['id']);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [delete FinExtratoContaBanco]', null);
			} else {
				$this->finExtratoContaBancoService->delete($objFromDatabase);

				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [delete FinExtratoContaBanco]', $e);
		}
	}

	public function reconcileTransactions($request, $response, $args)
	{
		try {
			$data = json_decode($request->getBody(), true);

			if (!isset($data['mesAno'])) {
				return parent::handleError($response, 400, 'Mês e ano são obrigatórios', null);
			}

			$result = $this->finExtratoContaBancoService->reconcileTransactions($data['mesAno']);

			$response->getBody()->write(json_encode([
				'success' => $result,
				'message' => 'Conciliação realizada com sucesso'
			]));

			return $response
				->withStatus(200)
				->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Erro na conciliação', $e);
		}
	}
}
