<?php
class ViewFinMovimentoCaixaBancoController extends ControllerBase
{

		private $viewFinMovimentoCaixaBancoService = null;

		public function __construct()
		{	 
				$this->viewFinMovimentoCaixaBancoService = new ViewFinMovimentoCaixaBancoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->viewFinMovimentoCaixaBancoService->getListFilter($filter);
						} else {
								$resultList = $this->viewFinMovimentoCaixaBancoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList ViewFinMovimentoCaixaBanco]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->viewFinMovimentoCaixaBancoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject ViewFinMovimentoCaixaBanco]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject ViewFinMovimentoCaixaBanco]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert ViewFinMovimentoCaixaBanco]', null);
						}

						$objModel = new ViewFinMovimentoCaixaBancoModel();
						$objModel->mapping($objJson);

						$this->viewFinMovimentoCaixaBancoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert ViewFinMovimentoCaixaBanco]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->viewFinMovimentoCaixaBancoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update ViewFinMovimentoCaixaBanco]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->viewFinMovimentoCaixaBancoService->save($objFromDatabase);
								$objFromDatabase = $this->viewFinMovimentoCaixaBancoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update ViewFinMovimentoCaixaBanco]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->viewFinMovimentoCaixaBancoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete ViewFinMovimentoCaixaBanco]', null);
						} else {
								$this->viewFinMovimentoCaixaBancoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete ViewFinMovimentoCaixaBanco]', $e);
				}
		}
}
