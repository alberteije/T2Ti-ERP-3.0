<?php

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Psr7\Response;

use Firebase\JWT\BeforeValidException;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\JWT;
use Firebase\JWT\SignatureInvalidException;

class LoginController extends ControllerBase
{

	private static $key = MAIN_KEY;
	private static $alg = array('HS256');
	private $tokenExpirationTime = "";

	// method called by Slim before processing requests for routes that MiddleWare has added
	public function __invoke(Request $request, RequestHandler $handler): Response
	{
		$token = null;
		$header = $request->getHeader("authorization");
		if (count($header) == 1) {
			$token = substr($header[0], 7); // fetches the token in the request header
		}

		// Auditoria
		$metodo = $request->getMethod();
		$filtro = "";
		if ($metodo === 'GET') {
			if (count($request->getQueryParams()) > 0) {
				$filtro = $request->getQueryParams()['filter'];
			}
		}
		$corpo = (string)$request->getBody();

		$objetoAuditoria = new AuditoriaModel();
		$objetoAuditoria->dataRegistro = date('Y-m-d');
		$objetoAuditoria->horaRegistro = date('H:i:s');
		$objetoAuditoria->janelaController = $request->getUri()->getPath();
		$objetoAuditoria->acao = $metodo;
		$objetoAuditoria->conteudo = $corpo !== "" ? $corpo : $filtro;
		$objetoAuditoria->tokenJwt = $token;
		$auditoriaService = new AuditoriaService();
		$auditoriaService->save($objetoAuditoria);

		if (isset($token)) {
			if ($this->checkToken($token)) {
				return $handler->handle($request); //if the token is valid process the request
			}
		}

		// if the token is invalid, it returns an http 401.
		$response = new Response();
		return parent::handleError($response, 401, 'Unauthorized', null);
	}

	// perform user authentication => rota '/otica/login'
	public function login($request, $response, $args)
	{
		try {
			// get the request object
			$user = json_decode(Util::decrypt($request->getBody()));

			// validate the object
			if (!isset($user)) {
				return parent::handleError($response, 400, 'Invalid object [Login]', null);
			}

			$login = $user->login;
			$senha = $user->senha;
			$md5Senha = md5($login . $senha);

			$filter = new Filter(null);
			$filter->where = " login = '$login' AND senha = '$md5Senha' ";

			$viewPessoaUsuarioService = new ViewPessoaUsuarioService();
			$return = $viewPessoaUsuarioService->doLogin($filter);

			if (empty($return) || $return === null) {
				// if the user data is INCORRECT it returns an http 401.
				return parent::handleError($response, 401, 'Invalid username and/or password', null);
			} else {
				// if the user data is correct, it generates the token and returns it in the request header.
				$return = Util::crypt(json_encode($return));

				$token = $this->generateToken($login);

				// Auditoria
				$usuarioToken =  new UsuarioTokenModel();
				$usuarioToken->login = $login;
				$usuarioToken->Token = $token;
				$usuarioToken->DataCriacao = date('Y-m-d');
				$usuarioToken->HoraCriacao = date('H:i:s');
				$usuarioToken->DataExpiracao = date('Y-m-d', $this->tokenExpirationTime);
				$usuarioToken->HoraExpiracao = date('H:i:s', $this->tokenExpirationTime);
				$usuarioTokenService = new UsuarioTokenService();
				$usuarioTokenService->save($usuarioToken);

				$token = Util::crypt($token);
				$result = "{\"user\": \"$return\", \"token\": \"$token\"}";
				$response->getBody()->write($result);

				return $response
					->withHeader('Content-Type', 'application/json')
					->withStatus(200);
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Server Error [Login]', $e);
		}
	}

	private function generateToken(string $subject): string
	{
		// Define o tempo de expiração em segundos (1 dia a partir de agora)
		$this->tokenExpirationTime = time() + 86400; // 86400 segundos = 1 dia

		$token = array(
			"sub" => $subject,
			"exp" => $this->tokenExpirationTime,
			"iss" => "T2Ti" // Define o issuer como 'T2Ti'
		);

		$result = JWT::encode($token, self::$key);
		return $result;
	}


	private function checkToken(string $token): bool
	{
		if ($token != null) {
			try {
				JWT::decode($token, self::$key, self::$alg);

				return true;
			} catch (UnexpectedValueException | SignatureInvalidException | BeforeValidException | ExpiredException $e) {
				return false;
			}
		}
		return false;
	}
}
