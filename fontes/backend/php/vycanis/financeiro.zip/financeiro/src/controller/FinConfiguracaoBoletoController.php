<?php
class FinConfiguracaoBoletoController extends ControllerBase
{

		private $finConfiguracaoBoletoService = null;

		public function __construct()
		{	 
				$this->finConfiguracaoBoletoService = new FinConfiguracaoBoletoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->finConfiguracaoBoletoService->getListFilter($filter);
						} else {
								$resultList = $this->finConfiguracaoBoletoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList FinConfiguracaoBoleto]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->finConfiguracaoBoletoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject FinConfiguracaoBoleto]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject FinConfiguracaoBoleto]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert FinConfiguracaoBoleto]', null);
						}

						$objModel = new FinConfiguracaoBoletoModel();
						$objModel->mapping($objJson);

						$this->finConfiguracaoBoletoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert FinConfiguracaoBoleto]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->finConfiguracaoBoletoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update FinConfiguracaoBoleto]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->finConfiguracaoBoletoService->save($objFromDatabase);
								$objFromDatabase = $this->finConfiguracaoBoletoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update FinConfiguracaoBoleto]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->finConfiguracaoBoletoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete FinConfiguracaoBoleto]', null);
						} else {
								$this->finConfiguracaoBoletoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete FinConfiguracaoBoleto]', $e);
				}
		}
}
