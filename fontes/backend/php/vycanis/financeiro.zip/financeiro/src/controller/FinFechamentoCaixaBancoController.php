<?php
class FinFechamentoCaixaBancoController extends ControllerBase
{

		private $finFechamentoCaixaBancoService = null;

		public function __construct()
		{	 
				$this->finFechamentoCaixaBancoService = new FinFechamentoCaixaBancoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->finFechamentoCaixaBancoService->getListFilter($filter);
						} else {
								$resultList = $this->finFechamentoCaixaBancoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList FinFechamentoCaixaBanco]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->finFechamentoCaixaBancoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject FinFechamentoCaixaBanco]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject FinFechamentoCaixaBanco]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert FinFechamentoCaixaBanco]', null);
						}

						$objModel = new FinFechamentoCaixaBancoModel();
						$objModel->mapping($objJson);

						$this->finFechamentoCaixaBancoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert FinFechamentoCaixaBanco]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->finFechamentoCaixaBancoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update FinFechamentoCaixaBanco]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->finFechamentoCaixaBancoService->save($objFromDatabase);
								$objFromDatabase = $this->finFechamentoCaixaBancoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update FinFechamentoCaixaBanco]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->finFechamentoCaixaBancoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete FinFechamentoCaixaBanco]', null);
						} else {
								$this->finFechamentoCaixaBancoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete FinFechamentoCaixaBanco]', $e);
				}
		}
}
