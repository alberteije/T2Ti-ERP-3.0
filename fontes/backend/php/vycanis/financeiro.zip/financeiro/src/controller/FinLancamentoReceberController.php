<?php

use Slim\Psr7\Stream;

class FinLancamentoReceberController extends ControllerBase
{

	private $finLancamentoReceberService = null;

	public function __construct()
	{
		$this->finLancamentoReceberService = new FinLancamentoReceberService();
	}

	public function getList($request, $response, $args)
	{
		try {
			if (count($request->getQueryParams()) > 0) {
				$filter = new Filter(parent::handleFilter($request));
				$resultList = $this->finLancamentoReceberService->getListFilter($filter);
			} else {
				$resultList = $this->finLancamentoReceberService->getList();
			}
			$return = json_encode($resultList);
			$response->getBody()->write($return);
			return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [getList FinLancamentoReceber]', $e);
		}
	}

	public function getObject($request, $response, $args)
	{
		try {
			$objFromDatabase = $this->finLancamentoReceberService->getObject($args['id']);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 404, 'Not Found [getObject FinLancamentoReceber]', null);
			} else {
				$return = json_encode($objFromDatabase);
				$response->getBody()->write($return);
				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [getObject FinLancamentoReceber]', $e);
		}
	}

	public function insert($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			if (!isset($objJson)) {
				return parent::handleError($response, 400, 'Invalid Object [insert FinLancamentoReceber]', null);
			}

			$objModel = new FinLancamentoReceberModel();
			$objModel->mapping($objJson);

			$this->finLancamentoReceberService->insert($objJson, $objModel);

			$return = json_encode($objModel);
			$response->getBody()->write($return);

			return $response
				->withStatus(201)
				->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [insert FinLancamentoReceber]', $e);
		}
	}

	public function update($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			$objFromDatabase = $this->finLancamentoReceberService->getObject($objJson->id);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [update FinLancamentoReceber]', null);
			} else {
				$objFromDatabase->mapping($objJson);

				$this->finLancamentoReceberService->update($objJson, $objFromDatabase);
				$objFromDatabase = $this->finLancamentoReceberService->getObject($objJson->id);

				$return = json_encode($objFromDatabase);
				$response->getBody()->write($return);
				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [update FinLancamentoReceber]', $e);
		}
	}

	public function delete($request, $response, $args)
	{
		try {
			$objFromDatabase = $this->finLancamentoReceberService->getObject($args['id']);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [delete FinLancamentoReceber]', null);
			} else {
				$this->finLancamentoReceberService->delete($objFromDatabase);

				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [delete FinLancamentoReceber]', $e);
		}
	}

	public function gerarPdfBoleto($request, $response, $args)
	{
		try {
			$idParcela = $args['id'];

			$this->finLancamentoReceberService->gerarPdfBoleto($idParcela);

			$fh = fopen("C:\\T2Ti\\Boletos\\PDF\\boleto.pdf", 'rb');
			$stream = new Stream($fh);
			return parent::resultFile($response, $stream, 'application/pdf');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Erro no Servidor [Atualizar AcbrMonitor]', $e);
		}
	}

}
