<?php
class FinTipoRecebimentoService extends ServiceBase
{
  public function getList()
  {
    return FinTipoRecebimentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinTipoRecebimentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinTipoRecebimentoModel::find($id);
  }

}