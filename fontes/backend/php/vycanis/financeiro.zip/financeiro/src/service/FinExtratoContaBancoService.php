<?php
class FinExtratoContaBancoService extends ServiceBase
{
	public function getList()
	{
		return FinExtratoContaBancoModel::select()->get();
	}

	public function getListFilter($filter)
	{
		return FinExtratoContaBancoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FinExtratoContaBancoModel::find($id);
	}

	public function deleteByMonthYear($mes, $ano)
	{
		return FinExtratoContaBancoModel::where('mes', $mes)
			->where('ano', $ano)
			->delete();
	}

	public function saveBatch(array $dadosParaInserir)
	{
		if (!empty($dadosParaInserir)) {
			return FinExtratoContaBancoModel::insert($dadosParaInserir);
		}
		return false;
	}

	public function reconcileTransactions(string $mesAno)
	{
		// Concilia recebimentos (valores positivos)
		$this->reconcileReceivables($mesAno);

		// Concilia pagamentos (valores negativos)
		$this->reconcilePayables($mesAno);

		return true;
	}

	private function reconcileReceivables(string $mesAno)
	{
		// Busca lançamentos positivos não conciliados no extrato
		$recebimentosExtrato = FinExtratoContaBancoModel::where('mes_ano', $mesAno)
			->where('conciliado', 'N')
			->where('valor', '>', 0)
			->get();

		foreach ($recebimentosExtrato as $extrato) {
			// Busca parcela a receber com mesmo valor e data
			$parcela = FinParcelaReceberModel::where('valor_recebido', abs($extrato->valor))
				->whereDate('data_recebimento', $extrato->data_movimento)
				->first();

			if ($parcela) {
				$extrato->conciliado = 'S';
				$extrato->save();
			}
		}
	}

	private function reconcilePayables(string $mesAno)
	{
		// Busca lançamentos negativos não conciliados no extrato
		$pagamentosExtrato = FinExtratoContaBancoModel::where('mes_ano', $mesAno)
			->where('conciliado', 'N')
			->where('valor', '<', 0)
			->get();

		foreach ($pagamentosExtrato as $extrato) {
			// Busca parcela a pagar com mesmo valor e data
			$parcela = FinParcelaPagarModel::where('valor_pago', abs($extrato->valor))
				->whereDate('data_pagamento', $extrato->data_movimento)
				->first();

			if ($parcela) {
				$extrato->conciliado = 'S';
				$extrato->save();
			}
		}
	}
}
