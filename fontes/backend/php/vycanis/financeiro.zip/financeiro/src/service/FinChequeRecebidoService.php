<?php
class FinChequeRecebidoService extends ServiceBase
{
  public function getList()
  {
    return FinChequeRecebidoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinChequeRecebidoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinChequeRecebidoModel::find($id);
  }

}