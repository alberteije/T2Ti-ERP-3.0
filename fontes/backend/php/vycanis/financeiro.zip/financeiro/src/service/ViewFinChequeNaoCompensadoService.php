<?php
class ViewFinChequeNaoCompensadoService extends ServiceBase
{
  public function getList()
  {
    return ViewFinChequeNaoCompensadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewFinChequeNaoCompensadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewFinChequeNaoCompensadoModel::find($id);
  }

}