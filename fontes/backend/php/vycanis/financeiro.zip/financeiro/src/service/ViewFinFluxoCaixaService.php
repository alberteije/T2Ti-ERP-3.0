<?php
class ViewFinFluxoCaixaService extends ServiceBase
{
	public function getList()
	{
		return ViewFinFluxoCaixaModel::select()->get();
	}

	public function getListFilter($filter)
	{
		return ViewFinFluxoCaixaModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ViewFinFluxoCaixaModel::find($id);
	}
}
