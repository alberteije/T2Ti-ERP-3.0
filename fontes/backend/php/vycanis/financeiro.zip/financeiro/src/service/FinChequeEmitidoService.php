<?php
class FinChequeEmitidoService extends ServiceBase
{
  public function getList()
  {
    return FinChequeEmitidoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinChequeEmitidoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinChequeEmitidoModel::find($id);
  }

}