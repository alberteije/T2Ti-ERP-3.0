<?php
class FinFechamentoCaixaBancoService extends ServiceBase
{
  public function getList()
  {
    return FinFechamentoCaixaBancoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinFechamentoCaixaBancoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinFechamentoCaixaBancoModel::find($id);
  }

}