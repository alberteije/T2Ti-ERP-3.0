<?php
class ViewFinMovimentoCaixaBancoService extends ServiceBase
{
	public function getList()
	{
		return ViewFinMovimentoCaixaBancoModel::select()->get();
	}

	public function getListFilter($filter)
	{
		return ViewFinMovimentoCaixaBancoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ViewFinMovimentoCaixaBancoModel::find($id);
	}
}
