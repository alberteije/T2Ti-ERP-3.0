<?php

use Illuminate\Database\Capsule\Manager as DB;

class FinLancamentoReceberService extends ServiceBase
{
	public function getList()
	{
		return FinLancamentoReceberModel::select()->get();
	}

	public function getListFilter($filter)
	{
		return FinLancamentoReceberModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FinLancamentoReceberModel::find($id);
	}

	public function insert($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});
	}

	public function insertChildren($objJson, $objModel)
	{
		// finParcelaReceber
		$finParcelaReceberModelListJson = $objJson->finParcelaReceberModelList;
		if ($finParcelaReceberModelListJson != null) {
			for ($i = 0; $i < count($finParcelaReceberModelListJson); $i++) {
				$finParcelaReceber = new FinParcelaReceberModel();
				$finParcelaReceber->mapping($finParcelaReceberModelListJson[$i]);
				$objModel->finParcelaReceberModelList()->save($finParcelaReceber);
			}
		}
	}

	public function deleteChildren($object)
	{
		FinParcelaReceberModel::where('id_fin_lancamento_receber', $object->getIdAttribute())->delete();
	}

	public function gerarPdfBoleto($idParcela)
	{
		// carrega mustache
		$m = new Mustache_Engine(
			array(
				'loader' => new Mustache_Loader_FilesystemLoader('C:\\T2Ti\\Boletos\\ini'),
			)
		);
		// carrega dados do boleto
		$rendered = $m->render('/boleto.ini', new BoletoIniMustache($idParcela));
		file_put_contents("C:\\T2Ti\\Boletos\\ini\\$idParcela.ini", $rendered);

		// cria o arquivo de entrada no acbrmonitor para limpar a lista de boletos
		file_put_contents("C:\\ACBrMonitor\\10793118000178\\ENT.txt", "BOLETO.LimparLista");

		sleep(1);

		// cria o arquivo de entrada no acbrmonitor para imprimir o boleto
		file_put_contents("C:\\ACBrMonitor\\10793118000178\\ENT.txt", 'BOLETO.IncluirTitulos("C:\\T2Ti\\Boletos\\ini\\' . $idParcela . '.ini", "I")');
	}
}
