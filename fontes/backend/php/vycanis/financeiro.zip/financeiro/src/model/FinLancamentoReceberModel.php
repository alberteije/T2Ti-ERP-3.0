<?php
declare(strict_types=1);

class FinLancamentoReceberModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_lancamento_receber';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'finParcelaReceberModelList',
		'finDocumentoOrigemModel',
		'bancoContaCaixaModel',
		'finNaturezaFinanceiraModel',
		'viewPessoaClienteModel',
	];

	/**
		* Relations
		*/
	public function finParcelaReceberModelList()
{
	return $this->hasMany(FinParcelaReceberModel::class, 'id_fin_lancamento_receber', 'id');
}

	public function finDocumentoOrigemModel()
	{
		return $this->belongsTo(FinDocumentoOrigemModel::class, 'id_fin_documento_origem', 'id');
	}

	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}

	public function finNaturezaFinanceiraModel()
	{
		return $this->belongsTo(FinNaturezaFinanceiraModel::class, 'id_fin_natureza_financeira', 'id');
	}

	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeParcelaAttribute()
	{
		return $this->attributes['quantidade_parcela'];
	}

	public function setQuantidadeParcelaAttribute($quantidadeParcela)
	{
		$this->attributes['quantidade_parcela'] = $quantidadeParcela;
	}

	public function getValorAReceberAttribute()
	{
		return (double)$this->attributes['valor_a_receber'];
	}

	public function setValorAReceberAttribute($valorAReceber)
	{
		$this->attributes['valor_a_receber'] = $valorAReceber;
	}

	public function getDataLancamentoAttribute()
	{
		return $this->attributes['data_lancamento'];
	}

	public function setDataLancamentoAttribute($dataLancamento)
	{
		$this->attributes['data_lancamento'] = $dataLancamento;
	}

	public function getNumeroDocumentoAttribute()
	{
		return $this->attributes['numero_documento'];
	}

	public function setNumeroDocumentoAttribute($numeroDocumento)
	{
		$this->attributes['numero_documento'] = $numeroDocumento;
	}

	public function getPrimeiroVencimentoAttribute()
	{
		return $this->attributes['primeiro_vencimento'];
	}

	public function setPrimeiroVencimentoAttribute($primeiroVencimento)
	{
		$this->attributes['primeiro_vencimento'] = $primeiroVencimento;
	}

	public function getTaxaComissaoAttribute()
	{
		return (double)$this->attributes['taxa_comissao'];
	}

	public function setTaxaComissaoAttribute($taxaComissao)
	{
		$this->attributes['taxa_comissao'] = $taxaComissao;
	}

	public function getValorComissaoAttribute()
	{
		return (double)$this->attributes['valor_comissao'];
	}

	public function setValorComissaoAttribute($valorComissao)
	{
		$this->attributes['valor_comissao'] = $valorComissao;
	}

	public function getIntervaloEntreParcelasAttribute()
	{
		return $this->attributes['intervalo_entre_parcelas'];
	}

	public function setIntervaloEntreParcelasAttribute($intervaloEntreParcelas)
	{
		$this->attributes['intervalo_entre_parcelas'] = $intervaloEntreParcelas;
	}

	public function getDiaFixoAttribute()
	{
		return $this->attributes['dia_fixo'];
	}

	public function setDiaFixoAttribute($diaFixo)
	{
		$this->attributes['dia_fixo'] = $diaFixo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeParcelaAttribute($object->quantidadeParcela);
				$this->setValorAReceberAttribute($object->valorAReceber);
				$this->setDataLancamentoAttribute($object->dataLancamento);
				$this->setNumeroDocumentoAttribute($object->numeroDocumento);
				$this->setPrimeiroVencimentoAttribute($object->primeiroVencimento);
				$this->setTaxaComissaoAttribute($object->taxaComissao);
				$this->setValorComissaoAttribute($object->valorComissao);
				$this->setIntervaloEntreParcelasAttribute($object->intervaloEntreParcelas);
				$this->setDiaFixoAttribute($object->diaFixo);

				// link objects - lookups
				$finDocumentoOrigemModel = new FinDocumentoOrigemModel();
				$finDocumentoOrigemModel->mapping($object->finDocumentoOrigemModel);
				$this->finDocumentoOrigemModel()->associate($finDocumentoOrigemModel);
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
				$finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel();
				$finNaturezaFinanceiraModel->mapping($object->finNaturezaFinanceiraModel);
				$this->finNaturezaFinanceiraModel()->associate($finNaturezaFinanceiraModel);
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidadeParcela' => $this->getQuantidadeParcelaAttribute(),
				'valorAReceber' => $this->getValorAReceberAttribute(),
				'dataLancamento' => $this->getDataLancamentoAttribute(),
				'numeroDocumento' => $this->getNumeroDocumentoAttribute(),
				'primeiroVencimento' => $this->getPrimeiroVencimentoAttribute(),
				'taxaComissao' => $this->getTaxaComissaoAttribute(),
				'valorComissao' => $this->getValorComissaoAttribute(),
				'intervaloEntreParcelas' => $this->getIntervaloEntreParcelasAttribute(),
				'diaFixo' => $this->getDiaFixoAttribute(),
				'finParcelaReceberModelList' => $this->finParcelaReceberModelList,
				'finDocumentoOrigemModel' => $this->finDocumentoOrigemModel,
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
				'finNaturezaFinanceiraModel' => $this->finNaturezaFinanceiraModel,
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
			];
	}
}