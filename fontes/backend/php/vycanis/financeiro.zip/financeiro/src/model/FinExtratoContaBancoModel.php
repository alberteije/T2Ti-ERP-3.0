<?php
declare(strict_types=1);

class FinExtratoContaBancoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_extrato_conta_banco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'bancoContaCaixaModel',
	];

	/**
		* Relations
		*/
	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getMesAnoAttribute()
	{
		return $this->attributes['mes_ano'];
	}

	public function setMesAnoAttribute($mesAno)
	{
		$this->attributes['mes_ano'] = $mesAno;
	}

	public function getMesAttribute()
	{
		return $this->attributes['mes'];
	}

	public function setMesAttribute($mes)
	{
		$this->attributes['mes'] = $mes;
	}

	public function getAnoAttribute()
	{
		return $this->attributes['ano'];
	}

	public function setAnoAttribute($ano)
	{
		$this->attributes['ano'] = $ano;
	}

	public function getDataMovimentoAttribute()
	{
		return $this->attributes['data_movimento'];
	}

	public function setDataMovimentoAttribute($dataMovimento)
	{
		$this->attributes['data_movimento'] = $dataMovimento;
	}

	public function getDataBalanceteAttribute()
	{
		return $this->attributes['data_balancete'];
	}

	public function setDataBalanceteAttribute($dataBalancete)
	{
		$this->attributes['data_balancete'] = $dataBalancete;
	}

	public function getHistoricoAttribute()
	{
		return $this->attributes['historico'];
	}

	public function setHistoricoAttribute($historico)
	{
		$this->attributes['historico'] = $historico;
	}

	public function getDocumentoAttribute()
	{
		return $this->attributes['documento'];
	}

	public function setDocumentoAttribute($documento)
	{
		$this->attributes['documento'] = $documento;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getConciliadoAttribute()
	{
		return $this->attributes['conciliado'];
	}

	public function setConciliadoAttribute($conciliado)
	{
		$this->attributes['conciliado'] = $conciliado;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setMesAnoAttribute($object->mesAno);
				$this->setMesAttribute($object->mes);
				$this->setAnoAttribute($object->ano);
				$this->setDataMovimentoAttribute($object->dataMovimento);
				$this->setDataBalanceteAttribute($object->dataBalancete);
				$this->setHistoricoAttribute($object->historico);
				$this->setDocumentoAttribute($object->documento);
				$this->setValorAttribute($object->valor);
				$this->setConciliadoAttribute($object->conciliado);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'mesAno' => $this->getMesAnoAttribute(),
				'mes' => $this->getMesAttribute(),
				'ano' => $this->getAnoAttribute(),
				'dataMovimento' => $this->getDataMovimentoAttribute(),
				'dataBalancete' => $this->getDataBalanceteAttribute(),
				'historico' => $this->getHistoricoAttribute(),
				'documento' => $this->getDocumentoAttribute(),
				'valor' => $this->getValorAttribute(),
				'conciliado' => $this->getConciliadoAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
			];
	}
}