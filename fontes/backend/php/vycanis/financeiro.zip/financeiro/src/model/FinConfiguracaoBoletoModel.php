<?php
declare(strict_types=1);

class FinConfiguracaoBoletoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_configuracao_boleto';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'bancoContaCaixaModel',
	];

	/**
		* Relations
		*/
	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getInstrucao01Attribute()
	{
		return $this->attributes['instrucao01'];
	}

	public function setInstrucao01Attribute($instrucao01)
	{
		$this->attributes['instrucao01'] = $instrucao01;
	}

	public function getInstrucao02Attribute()
	{
		return $this->attributes['instrucao02'];
	}

	public function setInstrucao02Attribute($instrucao02)
	{
		$this->attributes['instrucao02'] = $instrucao02;
	}

	public function getCaminhoArquivoRemessaAttribute()
	{
		return $this->attributes['caminho_arquivo_remessa'];
	}

	public function setCaminhoArquivoRemessaAttribute($caminhoArquivoRemessa)
	{
		$this->attributes['caminho_arquivo_remessa'] = $caminhoArquivoRemessa;
	}

	public function getCaminhoArquivoRetornoAttribute()
	{
		return $this->attributes['caminho_arquivo_retorno'];
	}

	public function setCaminhoArquivoRetornoAttribute($caminhoArquivoRetorno)
	{
		$this->attributes['caminho_arquivo_retorno'] = $caminhoArquivoRetorno;
	}

	public function getCaminhoArquivoLogotipoAttribute()
	{
		return $this->attributes['caminho_arquivo_logotipo'];
	}

	public function setCaminhoArquivoLogotipoAttribute($caminhoArquivoLogotipo)
	{
		$this->attributes['caminho_arquivo_logotipo'] = $caminhoArquivoLogotipo;
	}

	public function getCaminhoArquivoPdfAttribute()
	{
		return $this->attributes['caminho_arquivo_pdf'];
	}

	public function setCaminhoArquivoPdfAttribute($caminhoArquivoPdf)
	{
		$this->attributes['caminho_arquivo_pdf'] = $caminhoArquivoPdf;
	}

	public function getMensagemAttribute()
	{
		return $this->attributes['mensagem'];
	}

	public function setMensagemAttribute($mensagem)
	{
		$this->attributes['mensagem'] = $mensagem;
	}

	public function getLocalPagamentoAttribute()
	{
		return $this->attributes['local_pagamento'];
	}

	public function setLocalPagamentoAttribute($localPagamento)
	{
		$this->attributes['local_pagamento'] = $localPagamento;
	}

	public function getLayoutRemessaAttribute()
	{
		return $this->attributes['layout_remessa'];
	}

	public function setLayoutRemessaAttribute($layoutRemessa)
	{
		$this->attributes['layout_remessa'] = $layoutRemessa;
	}

	public function getAceiteAttribute()
	{
		return $this->attributes['aceite'];
	}

	public function setAceiteAttribute($aceite)
	{
		$this->attributes['aceite'] = $aceite;
	}

	public function getEspecieAttribute()
	{
		return $this->attributes['especie'];
	}

	public function setEspecieAttribute($especie)
	{
		$this->attributes['especie'] = $especie;
	}

	public function getCarteiraAttribute()
	{
		return $this->attributes['carteira'];
	}

	public function setCarteiraAttribute($carteira)
	{
		$this->attributes['carteira'] = $carteira;
	}

	public function getCodigoConvenioAttribute()
	{
		return $this->attributes['codigo_convenio'];
	}

	public function setCodigoConvenioAttribute($codigoConvenio)
	{
		$this->attributes['codigo_convenio'] = $codigoConvenio;
	}

	public function getCodigoCedenteAttribute()
	{
		return $this->attributes['codigo_cedente'];
	}

	public function setCodigoCedenteAttribute($codigoCedente)
	{
		$this->attributes['codigo_cedente'] = $codigoCedente;
	}

	public function getTaxaMultaAttribute()
	{
		return (double)$this->attributes['taxa_multa'];
	}

	public function setTaxaMultaAttribute($taxaMulta)
	{
		$this->attributes['taxa_multa'] = $taxaMulta;
	}

	public function getTaxaJuroAttribute()
	{
		return (double)$this->attributes['taxa_juro'];
	}

	public function setTaxaJuroAttribute($taxaJuro)
	{
		$this->attributes['taxa_juro'] = $taxaJuro;
	}

	public function getDiasProtestoAttribute()
	{
		return $this->attributes['dias_protesto'];
	}

	public function setDiasProtestoAttribute($diasProtesto)
	{
		$this->attributes['dias_protesto'] = $diasProtesto;
	}

	public function getNossoNumeroAnteriorAttribute()
	{
		return $this->attributes['nosso_numero_anterior'];
	}

	public function setNossoNumeroAnteriorAttribute($nossoNumeroAnterior)
	{
		$this->attributes['nosso_numero_anterior'] = $nossoNumeroAnterior;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setInstrucao01Attribute($object->instrucao01);
				$this->setInstrucao02Attribute($object->instrucao02);
				$this->setCaminhoArquivoRemessaAttribute($object->caminhoArquivoRemessa);
				$this->setCaminhoArquivoRetornoAttribute($object->caminhoArquivoRetorno);
				$this->setCaminhoArquivoLogotipoAttribute($object->caminhoArquivoLogotipo);
				$this->setCaminhoArquivoPdfAttribute($object->caminhoArquivoPdf);
				$this->setMensagemAttribute($object->mensagem);
				$this->setLocalPagamentoAttribute($object->localPagamento);
				$this->setLayoutRemessaAttribute($object->layoutRemessa);
				$this->setAceiteAttribute($object->aceite);
				$this->setEspecieAttribute($object->especie);
				$this->setCarteiraAttribute($object->carteira);
				$this->setCodigoConvenioAttribute($object->codigoConvenio);
				$this->setCodigoCedenteAttribute($object->codigoCedente);
				$this->setTaxaMultaAttribute($object->taxaMulta);
				$this->setTaxaJuroAttribute($object->taxaJuro);
				$this->setDiasProtestoAttribute($object->diasProtesto);
				$this->setNossoNumeroAnteriorAttribute($object->nossoNumeroAnterior);

				// link objects - lookups
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'instrucao01' => $this->getInstrucao01Attribute(),
				'instrucao02' => $this->getInstrucao02Attribute(),
				'caminhoArquivoRemessa' => $this->getCaminhoArquivoRemessaAttribute(),
				'caminhoArquivoRetorno' => $this->getCaminhoArquivoRetornoAttribute(),
				'caminhoArquivoLogotipo' => $this->getCaminhoArquivoLogotipoAttribute(),
				'caminhoArquivoPdf' => $this->getCaminhoArquivoPdfAttribute(),
				'mensagem' => $this->getMensagemAttribute(),
				'localPagamento' => $this->getLocalPagamentoAttribute(),
				'layoutRemessa' => $this->getLayoutRemessaAttribute(),
				'aceite' => $this->getAceiteAttribute(),
				'especie' => $this->getEspecieAttribute(),
				'carteira' => $this->getCarteiraAttribute(),
				'codigoConvenio' => $this->getCodigoConvenioAttribute(),
				'codigoCedente' => $this->getCodigoCedenteAttribute(),
				'taxaMulta' => $this->getTaxaMultaAttribute(),
				'taxaJuro' => $this->getTaxaJuroAttribute(),
				'diasProtesto' => $this->getDiasProtestoAttribute(),
				'nossoNumeroAnterior' => $this->getNossoNumeroAnteriorAttribute(),
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
			];
	}
}