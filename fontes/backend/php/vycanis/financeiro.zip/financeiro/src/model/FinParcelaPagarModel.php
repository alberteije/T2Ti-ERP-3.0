<?php
declare(strict_types=1);

class FinParcelaPagarModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_parcela_pagar';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'finStatusParcelaModel',
		'finTipoPagamentoModel',
	];

	/**
		* Relations
		*/
	public function finLancamentoPagarModel()
	{
		return $this->belongsTo(FinLancamentoPagarModel::class, 'id_fin_lancamento_pagar', 'id');
	}

	public function finStatusParcelaModel()
	{
		return $this->belongsTo(FinStatusParcelaModel::class, 'id_fin_status_parcela', 'id');
	}

	public function finTipoPagamentoModel()
	{
		return $this->belongsTo(FinTipoPagamentoModel::class, 'id_fin_tipo_pagamento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroParcelaAttribute()
	{
		return $this->attributes['numero_parcela'];
	}

	public function setNumeroParcelaAttribute($numeroParcela)
	{
		$this->attributes['numero_parcela'] = $numeroParcela;
	}

	public function getDataEmissaoAttribute()
	{
		return $this->attributes['data_emissao'];
	}

	public function setDataEmissaoAttribute($dataEmissao)
	{
		$this->attributes['data_emissao'] = $dataEmissao;
	}

	public function getDataVencimentoAttribute()
	{
		return $this->attributes['data_vencimento'];
	}

	public function setDataVencimentoAttribute($dataVencimento)
	{
		$this->attributes['data_vencimento'] = $dataVencimento;
	}

	public function getDataPagamentoAttribute()
	{
		return $this->attributes['data_pagamento'];
	}

	public function setDataPagamentoAttribute($dataPagamento)
	{
		$this->attributes['data_pagamento'] = $dataPagamento;
	}

	public function getDescontoAteAttribute()
	{
		return $this->attributes['desconto_ate'];
	}

	public function setDescontoAteAttribute($descontoAte)
	{
		$this->attributes['desconto_ate'] = $descontoAte;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getTaxaJuroAttribute()
	{
		return (double)$this->attributes['taxa_juro'];
	}

	public function setTaxaJuroAttribute($taxaJuro)
	{
		$this->attributes['taxa_juro'] = $taxaJuro;
	}

	public function getTaxaMultaAttribute()
	{
		return (double)$this->attributes['taxa_multa'];
	}

	public function setTaxaMultaAttribute($taxaMulta)
	{
		$this->attributes['taxa_multa'] = $taxaMulta;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorJuroAttribute()
	{
		return (double)$this->attributes['valor_juro'];
	}

	public function setValorJuroAttribute($valorJuro)
	{
		$this->attributes['valor_juro'] = $valorJuro;
	}

	public function getValorMultaAttribute()
	{
		return (double)$this->attributes['valor_multa'];
	}

	public function setValorMultaAttribute($valorMulta)
	{
		$this->attributes['valor_multa'] = $valorMulta;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorPagoAttribute()
	{
		return (double)$this->attributes['valor_pago'];
	}

	public function setValorPagoAttribute($valorPago)
	{
		$this->attributes['valor_pago'] = $valorPago;
	}

	public function getHistoricoAttribute()
	{
		return $this->attributes['historico'];
	}

	public function setHistoricoAttribute($historico)
	{
		$this->attributes['historico'] = $historico;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroParcelaAttribute($object->numeroParcela);
				$this->setDataEmissaoAttribute($object->dataEmissao);
				$this->setDataVencimentoAttribute($object->dataVencimento);
				$this->setDataPagamentoAttribute($object->dataPagamento);
				$this->setDescontoAteAttribute($object->descontoAte);
				$this->setValorAttribute($object->valor);
				$this->setTaxaJuroAttribute($object->taxaJuro);
				$this->setTaxaMultaAttribute($object->taxaMulta);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorJuroAttribute($object->valorJuro);
				$this->setValorMultaAttribute($object->valorMulta);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorPagoAttribute($object->valorPago);
				$this->setHistoricoAttribute($object->historico);

				// link objects - lookups
				$finStatusParcelaModel = new FinStatusParcelaModel();
				$finStatusParcelaModel->mapping($object->finStatusParcelaModel);
				$this->finStatusParcelaModel()->associate($finStatusParcelaModel);
				$finTipoPagamentoModel = new FinTipoPagamentoModel();
				$finTipoPagamentoModel->mapping($object->finTipoPagamentoModel);
				$this->finTipoPagamentoModel()->associate($finTipoPagamentoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroParcela' => $this->getNumeroParcelaAttribute(),
				'dataEmissao' => $this->getDataEmissaoAttribute(),
				'dataVencimento' => $this->getDataVencimentoAttribute(),
				'dataPagamento' => $this->getDataPagamentoAttribute(),
				'descontoAte' => $this->getDescontoAteAttribute(),
				'valor' => $this->getValorAttribute(),
				'taxaJuro' => $this->getTaxaJuroAttribute(),
				'taxaMulta' => $this->getTaxaMultaAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorJuro' => $this->getValorJuroAttribute(),
				'valorMulta' => $this->getValorMultaAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorPago' => $this->getValorPagoAttribute(),
				'historico' => $this->getHistoricoAttribute(),
				'finStatusParcelaModel' => $this->finStatusParcelaModel,
				'finTipoPagamentoModel' => $this->finTipoPagamentoModel,
			];
	}
}