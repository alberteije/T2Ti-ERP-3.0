<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'ChequeModel.php';
include 'FinParcelaPagarModel.php';
include 'FinParcelaReceberModel.php';
include 'TalonarioChequeModel.php';
include 'FinLancamentoPagarModel.php';
include 'FinLancamentoReceberModel.php';
include 'BancoModel.php';
include 'BancoAgenciaModel.php';
include 'BancoContaCaixaModel.php';
include 'FinFechamentoCaixaBancoModel.php';
include 'FinExtratoContaBancoModel.php';
include 'FinDocumentoOrigemModel.php';
include 'FinNaturezaFinanceiraModel.php';
include 'FinStatusParcelaModel.php';
include 'FinTipoPagamentoModel.php';
include 'FinChequeEmitidoModel.php';
include 'FinTipoRecebimentoModel.php';
include 'FinChequeRecebidoModel.php';
include 'FinConfiguracaoBoletoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaClienteModel.php';
include 'ViewPessoaFornecedorModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';