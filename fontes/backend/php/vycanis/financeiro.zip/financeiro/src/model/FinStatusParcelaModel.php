<?php
declare(strict_types=1);

class FinStatusParcelaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_status_parcela';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getProcedimentoAttribute()
	{
		return $this->attributes['procedimento'];
	}

	public function setProcedimentoAttribute($procedimento)
	{
		$this->attributes['procedimento'] = $procedimento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setSituacaoAttribute($object->situacao);
				$this->setDescricaoAttribute($object->descricao);
				$this->setProcedimentoAttribute($object->procedimento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'procedimento' => $this->getProcedimentoAttribute(),
			];
	}
}