<?php
declare(strict_types=1);

class TalonarioChequeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'talonario_cheque';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'chequeModelList',
		'bancoContaCaixaModel',
	];

	/**
		* Relations
		*/
	public function chequeModelList()
{
	return $this->hasMany(ChequeModel::class, 'id_talonario_cheque', 'id');
}

	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTalaoAttribute()
	{
		return $this->attributes['talao'];
	}

	public function setTalaoAttribute($talao)
	{
		$this->attributes['talao'] = $talao;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getStatusTalaoAttribute()
	{
		return $this->attributes['status_talao'];
	}

	public function setStatusTalaoAttribute($statusTalao)
	{
		$this->attributes['status_talao'] = $statusTalao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTalaoAttribute($object->talao);
				$this->setNumeroAttribute($object->numero);
				$this->setStatusTalaoAttribute($object->statusTalao);

				// link objects - lookups
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'talao' => $this->getTalaoAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'statusTalao' => $this->getStatusTalaoAttribute(),
				'chequeModelList' => $this->chequeModelList,
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
			];
	}
}