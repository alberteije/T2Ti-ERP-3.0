<?php
declare(strict_types=1);

class ChequeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cheque';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function talonarioChequeModel()
	{
		return $this->belongsTo(TalonarioChequeModel::class, 'id_talonario_cheque', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getStatusChequeAttribute()
	{
		return $this->attributes['status_cheque'];
	}

	public function setStatusChequeAttribute($statusCheque)
	{
		$this->attributes['status_cheque'] = $statusCheque;
	}

	public function getDataStatusAttribute()
	{
		return $this->attributes['data_status'];
	}

	public function setDataStatusAttribute($dataStatus)
	{
		$this->attributes['data_status'] = $dataStatus;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setStatusChequeAttribute($object->statusCheque);
				$this->setDataStatusAttribute($object->dataStatus);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'statusCheque' => $this->getStatusChequeAttribute(),
				'dataStatus' => $this->getDataStatusAttribute(),
			];
	}
}