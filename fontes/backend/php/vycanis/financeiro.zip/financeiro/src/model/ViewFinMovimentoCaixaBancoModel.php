<?php
declare(strict_types=1);

class ViewFinMovimentoCaixaBancoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'view_fin_movimento_caixa_banco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdBancoContaCaixaAttribute()
	{
		return $this->attributes['id_banco_conta_caixa'];
	}

	public function setIdBancoContaCaixaAttribute($id)
	{
		$this->attributes['id_banco_conta_caixa'] = $id;
	}


	public function getNomeContaCaixaAttribute()
	{
		return $this->attributes['nome_conta_caixa'];
	}

	public function setNomeContaCaixaAttribute($nomeContaCaixa)
	{
		$this->attributes['nome_conta_caixa'] = $nomeContaCaixa;
	}

	public function getNomePessoaAttribute()
	{
		return $this->attributes['nome_pessoa'];
	}

	public function setNomePessoaAttribute($nomePessoa)
	{
		$this->attributes['nome_pessoa'] = $nomePessoa;
	}

	public function getDataLancamentoAttribute()
	{
		return $this->attributes['data_lancamento'];
	}

	public function setDataLancamentoAttribute($dataLancamento)
	{
		$this->attributes['data_lancamento'] = $dataLancamento;
	}

	public function getDataPagoRecebidoAttribute()
	{
		return $this->attributes['data_pago_recebido'];
	}

	public function setDataPagoRecebidoAttribute($dataPagoRecebido)
	{
		$this->attributes['data_pago_recebido'] = $dataPagoRecebido;
	}

	public function getMesAnoAttribute()
	{
		return $this->attributes['mes_ano'];
	}

	public function setMesAnoAttribute($mesAno)
	{
		$this->attributes['mes_ano'] = $mesAno;
	}

	public function getHistoricoAttribute()
	{
		return $this->attributes['historico'];
	}

	public function setHistoricoAttribute($historico)
	{
		$this->attributes['historico'] = $historico;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getDescricaoDocumentoOrigemAttribute()
	{
		return $this->attributes['descricao_documento_origem'];
	}

	public function setDescricaoDocumentoOrigemAttribute($descricaoDocumentoOrigem)
	{
		$this->attributes['descricao_documento_origem'] = $descricaoDocumentoOrigem;
	}

	public function getOperacaoAttribute()
	{
		return $this->attributes['operacao'];
	}

	public function setOperacaoAttribute($operacao)
	{
		$this->attributes['operacao'] = $operacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeContaCaixaAttribute($object->nomeContaCaixa);
				$this->setNomePessoaAttribute($object->nomePessoa);
				$this->setDataLancamentoAttribute($object->dataLancamento);
				$this->setDataPagoRecebidoAttribute($object->dataPagoRecebido);
				$this->setMesAnoAttribute($object->mesAno);
				$this->setHistoricoAttribute($object->historico);
				$this->setValorAttribute($object->valor);
				$this->setDescricaoDocumentoOrigemAttribute($object->descricaoDocumentoOrigem);
				$this->setOperacaoAttribute($object->operacao);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize(): mixed
	{
			return [
				'id' => $this->getIdAttribute(),
				'idBancoContaCaixa' => $this->getIdBancoContaCaixaAttribute(),
				'nomeContaCaixa' => $this->getNomeContaCaixaAttribute(),
				'nomePessoa' => $this->getNomePessoaAttribute(),
				'dataLancamento' => $this->getDataLancamentoAttribute(),
				'dataPagoRecebido' => $this->getDataPagoRecebidoAttribute(),
				'mesAno' => $this->getMesAnoAttribute(),
				'historico' => $this->getHistoricoAttribute(),
				'valor' => $this->getValorAttribute(),
				'descricaoDocumentoOrigem' => $this->getDescricaoDocumentoOrigemAttribute(),
				'operacao' => $this->getOperacaoAttribute(),
			];
	}
}