<?php
declare(strict_types=1);

class ViewFinChequeNaoCompensadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'view_fin_cheque_nao_compensado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeContaCaixaAttribute()
	{
		return $this->attributes['nome_conta_caixa'];
	}

	public function getIdBancoContaCaixaAttribute()
	{
		return $this->attributes['id_banco_conta_caixa'];
	}

	public function setIdBancoContaCaixaAttribute($id)
	{
		$this->attributes['id_banco_conta_caixa'] = $id;
	}

	public function setNomeContaCaixaAttribute($nomeContaCaixa)
	{
		$this->attributes['nome_conta_caixa'] = $nomeContaCaixa;
	}

	public function getTalaoAttribute()
	{
		return $this->attributes['talao'];
	}

	public function setTalaoAttribute($talao)
	{
		$this->attributes['talao'] = $talao;
	}

	public function getNumeroTalaoAttribute()
	{
		return $this->attributes['numero_talao'];
	}

	public function setNumeroTalaoAttribute($numeroTalao)
	{
		$this->attributes['numero_talao'] = $numeroTalao;
	}

	public function getNumeroChequeAttribute()
	{
		return $this->attributes['numero_cheque'];
	}

	public function setNumeroChequeAttribute($numeroCheque)
	{
		$this->attributes['numero_cheque'] = $numeroCheque;
	}

	public function getStatusChequeAttribute()
	{
		return $this->attributes['status_cheque'];
	}

	public function setStatusChequeAttribute($statusCheque)
	{
		$this->attributes['status_cheque'] = $statusCheque;
	}

	public function getDataStatusAttribute()
	{
		return $this->attributes['data_status'];
	}

	public function setDataStatusAttribute($dataStatus)
	{
		$this->attributes['data_status'] = $dataStatus;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeContaCaixaAttribute($object->nomeContaCaixa);
				$this->setTalaoAttribute($object->talao);
				$this->setNumeroTalaoAttribute($object->numeroTalao);
				$this->setNumeroChequeAttribute($object->numeroCheque);
				$this->setStatusChequeAttribute($object->statusCheque);
				$this->setDataStatusAttribute($object->dataStatus);
				$this->setValorAttribute($object->valor);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idBancoContaCaixa' => $this->getIdBancoContaCaixaAttribute(),
				'nomeContaCaixa' => $this->getNomeContaCaixaAttribute(),
				'talao' => $this->getTalaoAttribute(),
				'numeroTalao' => $this->getNumeroTalaoAttribute(),
				'numeroCheque' => $this->getNumeroChequeAttribute(),
				'statusCheque' => $this->getStatusChequeAttribute(),
				'dataStatus' => $this->getDataStatusAttribute(),
				'valor' => $this->getValorAttribute(),
			];
	}
}