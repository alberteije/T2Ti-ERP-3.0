<?php
declare(strict_types=1);

class ViewFinFluxoCaixaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'view_fin_fluxo_caixa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'bancoContaCaixaModel',
	];

	/**
		* Relations
		*/
	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeContaCaixaAttribute()
	{
		return $this->attributes['nome_conta_caixa'];
	}

	public function setNomeContaCaixaAttribute($nomeContaCaixa)
	{
		$this->attributes['nome_conta_caixa'] = $nomeContaCaixa;
	}

	public function getNomePessoaAttribute()
	{
		return $this->attributes['nome_pessoa'];
	}

	public function setNomePessoaAttribute($nomePessoa)
	{
		$this->attributes['nome_pessoa'] = $nomePessoa;
	}

	public function getDataLancamentoAttribute()
	{
		return $this->attributes['data_lancamento'];
	}

	public function setDataLancamentoAttribute($dataLancamento)
	{
		$this->attributes['data_lancamento'] = $dataLancamento;
	}

	public function getDataVencimentoAttribute()
	{
		return $this->attributes['data_vencimento'];
	}

	public function setDataVencimentoAttribute($dataVencimento)
	{
		$this->attributes['data_vencimento'] = $dataVencimento;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getCodigoSituacaoAttribute()
	{
		return $this->attributes['codigo_situacao'];
	}

	public function setCodigoSituacaoAttribute($codigoSituacao)
	{
		$this->attributes['codigo_situacao'] = $codigoSituacao;
	}

	public function getDescricaoSituacaoAttribute()
	{
		return $this->attributes['descricao_situacao'];
	}

	public function setDescricaoSituacaoAttribute($descricaoSituacao)
	{
		$this->attributes['descricao_situacao'] = $descricaoSituacao;
	}

	public function getOperacaoAttribute()
	{
		return $this->attributes['operacao'];
	}

	public function setOperacaoAttribute($operacao)
	{
		$this->attributes['operacao'] = $operacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeContaCaixaAttribute($object->nomeContaCaixa);
				$this->setNomePessoaAttribute($object->nomePessoa);
				$this->setDataLancamentoAttribute($object->dataLancamento);
				$this->setDataVencimentoAttribute($object->dataVencimento);
				$this->setValorAttribute($object->valor);
				$this->setCodigoSituacaoAttribute($object->codigoSituacao);
				$this->setDescricaoSituacaoAttribute($object->descricaoSituacao);
				$this->setOperacaoAttribute($object->operacao);

				// link objects - lookups
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nomeContaCaixa' => $this->getNomeContaCaixaAttribute(),
				'nomePessoa' => $this->getNomePessoaAttribute(),
				'dataLancamento' => $this->getDataLancamentoAttribute(),
				'dataVencimento' => $this->getDataVencimentoAttribute(),
				'valor' => $this->getValorAttribute(),
				'codigoSituacao' => $this->getCodigoSituacaoAttribute(),
				'descricaoSituacao' => $this->getDescricaoSituacaoAttribute(),
				'operacao' => $this->getOperacaoAttribute(),
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
			];
	}
}