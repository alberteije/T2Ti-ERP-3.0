<?php
declare(strict_types=1);

class ViewFinLancamentoReceberModel extends EloquentModel implements \JsonSerializable
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'view_fin_lancamento_receber';

    /**
     * Eager Loading - Relationships that should always be loaded by default
     *
     * @var array
     */
    protected $with = [
    ];

    /**
     * Gets e Sets
     */
    public function getIdAttribute()
    {
        return $this->attributes['id'];
    }

    public function setIdAttribute($id)
    {
        $this->attributes['id'] = $id;
    }

    public function getIdFinLancamentoReceberAttribute()
    {
        return $this->attributes['id_fin_lancamento_receber'];
    }

    public function setIdFinLancamentoReceberAttribute($id)
    {
        $this->attributes['id_fin_lancamento_receber'] = $id;
    }

    public function getQuantidadeParcelaAttribute()
    {
        return $this->attributes['quantidade_parcela'];
    }

    public function setQuantidadeParcelaAttribute($quantidade)
    {
        $this->attributes['quantidade_parcela'] = $quantidade;
    }

    public function getValorLancamentoAttribute()
    {
        return (double)$this->attributes['valor_lancamento'];
    }

    public function setValorLancamentoAttribute($valor)
    {
        $this->attributes['valor_lancamento'] = $valor;
    }

    public function getDataLancamentoAttribute()
    {
        return $this->attributes['data_lancamento'];
    }

    public function setDataLancamentoAttribute($data)
    {
        $this->attributes['data_lancamento'] = $data;
    }

    public function getNumeroDocumentoAttribute()
    {
        return $this->attributes['numero_documento'];
    }

    public function setNumeroDocumentoAttribute($numero)
    {
        $this->attributes['numero_documento'] = $numero;
    }

    public function getIdFinParcelaReceberAttribute()
    {
        return $this->attributes['id_fin_parcela_receber'];
    }

    public function setIdFinParcelaReceberAttribute($id)
    {
        $this->attributes['id_fin_parcela_receber'] = $id;
    }

    public function getNumeroParcelaAttribute()
    {
        return $this->attributes['numero_parcela'];
    }

    public function setNumeroParcelaAttribute($numero)
    {
        $this->attributes['numero_parcela'] = $numero;
    }

    public function getDataVencimentoAttribute()
    {
        return $this->attributes['data_vencimento'];
    }

    public function setDataVencimentoAttribute($data)
    {
        $this->attributes['data_vencimento'] = $data;
    }

    public function getDataRecebimentoAttribute()
    {
        return $this->attributes['data_recebimento'];
    }

    public function setDataRecebimentoAttribute($data)
    {
        $this->attributes['data_recebimento'] = $data;
    }

    public function getValorParcelaAttribute()
    {
        return (double)$this->attributes['valor_parcela'];
    }

    public function setValorParcelaAttribute($valor)
    {
        $this->attributes['valor_parcela'] = $valor;
    }

    public function getTaxaJuroAttribute()
    {
        return (double)$this->attributes['taxa_juro'];
    }

    public function setTaxaJuroAttribute($taxa)
    {
        $this->attributes['taxa_juro'] = $taxa;
    }

    public function getValorJuroAttribute()
    {
        return (double)$this->attributes['valor_juro'];
    }

    public function setValorJuroAttribute($valor)
    {
        $this->attributes['valor_juro'] = $valor;
    }

    public function getTaxaMultaAttribute()
    {
        return (double)$this->attributes['taxa_multa'];
    }

    public function setTaxaMultaAttribute($taxa)
    {
        $this->attributes['taxa_multa'] = $taxa;
    }

    public function getValorMultaAttribute()
    {
        return (double)$this->attributes['valor_multa'];
    }

    public function setValorMultaAttribute($valor)
    {
        $this->attributes['valor_multa'] = $valor;
    }

    public function getTaxaDescontoAttribute()
    {
        return (double)$this->attributes['taxa_desconto'];
    }

    public function setTaxaDescontoAttribute($taxa)
    {
        $this->attributes['taxa_desconto'] = $taxa;
    }

    public function getValorDescontoAttribute()
    {
        return (double)$this->attributes['valor_desconto'];
    }

    public function setValorDescontoAttribute($valor)
    {
        $this->attributes['valor_desconto'] = $valor;
    }

    public function getSiglaDocumentoAttribute()
    {
        return $this->attributes['sigla_documento'];
    }

    public function setSiglaDocumentoAttribute($sigla)
    {
        $this->attributes['sigla_documento'] = $sigla;
    }

    public function getNomeClienteAttribute()
    {
        return $this->attributes['nome_cliente'];
    }

    public function setNomeClienteAttribute($nome)
    {
        $this->attributes['nome_cliente'] = $nome;
    }

    public function getIdFinStatusParcelaAttribute()
    {
        return $this->attributes['id_fin_status_parcela'];
    }

    public function setIdFinStatusParcelaAttribute($id)
    {
        $this->attributes['id_fin_status_parcela'] = $id;
    }

    public function getSituacaoParcelaAttribute()
    {
        return $this->attributes['situacao_parcela'];
    }

    public function setSituacaoParcelaAttribute($situacao)
    {
        $this->attributes['situacao_parcela'] = $situacao;
    }

    public function getDescricaoSituacaoParcelaAttribute()
    {
        return $this->attributes['descricao_situacao_parcela'];
    }

    public function setDescricaoSituacaoParcelaAttribute($descricao)
    {
        $this->attributes['descricao_situacao_parcela'] = $descricao;
    }

    public function getIdBancoContaCaixaAttribute()
    {
        return $this->attributes['id_banco_conta_caixa'];
    }

    public function setIdBancoContaCaixaAttribute($id)
    {
        $this->attributes['id_banco_conta_caixa'] = $id;
    }

    public function getNomeContaCaixaAttribute()
    {
        return $this->attributes['nome_conta_caixa'];
    }

    public function setNomeContaCaixaAttribute($nome)
    {
        $this->attributes['nome_conta_caixa'] = $nome;
    }

    /**
     * Mapping
     */
    public function mapping($object)
    {
        if (isset($object)) {
            isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);
            
            $this->setIdFinLancamentoReceberAttribute($object->idFinLancamentoReceber);
            $this->setQuantidadeParcelaAttribute($object->quantidadeParcela);
            $this->setValorLancamentoAttribute($object->valorLancamento);
            $this->setDataLancamentoAttribute($object->dataLancamento);
            $this->setNumeroDocumentoAttribute($object->numeroDocumento);
            $this->setIdFinParcelaReceberAttribute($object->idFinParcelaReceber);
            $this->setNumeroParcelaAttribute($object->numeroParcela);
            $this->setDataVencimentoAttribute($object->dataVencimento);
            $this->setDataRecebimentoAttribute($object->dataRecebimento);
            $this->setValorParcelaAttribute($object->valorParcela);
            $this->setTaxaJuroAttribute($object->taxaJuro);
            $this->setValorJuroAttribute($object->valorJuro);
            $this->setTaxaMultaAttribute($object->taxaMulta);
            $this->setValorMultaAttribute($object->valorMulta);
            $this->setTaxaDescontoAttribute($object->taxaDesconto);
            $this->setValorDescontoAttribute($object->valorDesconto);
            $this->setSiglaDocumentoAttribute($object->siglaDocumento);
            $this->setNomeClienteAttribute($object->nomeCliente);
            $this->setIdFinStatusParcelaAttribute($object->idFinStatusParcela);
            $this->setSituacaoParcelaAttribute($object->situacaoParcela);
            $this->setDescricaoSituacaoParcelaAttribute($object->descricaoSituacaoParcela);
            $this->setIdBancoContaCaixaAttribute($object->idBancoContaCaixa);
            $this->setNomeContaCaixaAttribute($object->nomeContaCaixa);
        }
    }

    /**
     * Serialization
     * {@inheritdoc}
     */
    public function jsonSerialize()
    {
        return [
            'id' => $this->getIdAttribute(),
            'idFinLancamentoReceber' => $this->getIdFinLancamentoReceberAttribute(),
            'quantidadeParcela' => $this->getQuantidadeParcelaAttribute(),
            'valorLancamento' => $this->getValorLancamentoAttribute(),
            'dataLancamento' => $this->getDataLancamentoAttribute(),
            'numeroDocumento' => $this->getNumeroDocumentoAttribute(),
            'idFinParcelaReceber' => $this->getIdFinParcelaReceberAttribute(),
            'numeroParcela' => $this->getNumeroParcelaAttribute(),
            'dataVencimento' => $this->getDataVencimentoAttribute(),
            'dataRecebimento' => $this->getDataRecebimentoAttribute(),
            'valorParcela' => $this->getValorParcelaAttribute(),
            'taxaJuro' => $this->getTaxaJuroAttribute(),
            'valorJuro' => $this->getValorJuroAttribute(),
            'taxaMulta' => $this->getTaxaMultaAttribute(),
            'valorMulta' => $this->getValorMultaAttribute(),
            'taxaDesconto' => $this->getTaxaDescontoAttribute(),
            'valorDesconto' => $this->getValorDescontoAttribute(),
            'siglaDocumento' => $this->getSiglaDocumentoAttribute(),
            'nomeCliente' => $this->getNomeClienteAttribute(),
            'idFinStatusParcela' => $this->getIdFinStatusParcelaAttribute(),
            'situacaoParcela' => $this->getSituacaoParcelaAttribute(),
            'descricaoSituacaoParcela' => $this->getDescricaoSituacaoParcelaAttribute(),
            'idBancoContaCaixa' => $this->getIdBancoContaCaixaAttribute(),
            'nomeContaCaixa' => $this->getNomeContaCaixaAttribute()
        ];
    }
}