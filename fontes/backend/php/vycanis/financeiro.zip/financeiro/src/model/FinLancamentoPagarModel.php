<?php
declare(strict_types=1);

class FinLancamentoPagarModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_lancamento_pagar';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'finParcelaPagarModelList',
		'finDocumentoOrigemModel',
		'bancoContaCaixaModel',
		'finNaturezaFinanceiraModel',
		'viewPessoaFornecedorModel',
	];

	/**
		* Relations
		*/
	public function finParcelaPagarModelList()
{
	return $this->hasMany(FinParcelaPagarModel::class, 'id_fin_lancamento_pagar', 'id');
}

	public function finDocumentoOrigemModel()
	{
		return $this->belongsTo(FinDocumentoOrigemModel::class, 'id_fin_documento_origem', 'id');
	}

	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}

	public function finNaturezaFinanceiraModel()
	{
		return $this->belongsTo(FinNaturezaFinanceiraModel::class, 'id_fin_natureza_financeira', 'id');
	}

	public function viewPessoaFornecedorModel()
	{
		return $this->belongsTo(ViewPessoaFornecedorModel::class, 'id_fornecedor', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeParcelaAttribute()
	{
		return $this->attributes['quantidade_parcela'];
	}

	public function setQuantidadeParcelaAttribute($quantidadeParcela)
	{
		$this->attributes['quantidade_parcela'] = $quantidadeParcela;
	}

	public function getValorAPagarAttribute()
	{
		return (double)$this->attributes['valor_a_pagar'];
	}

	public function setValorAPagarAttribute($valorAPagar)
	{
		$this->attributes['valor_a_pagar'] = $valorAPagar;
	}

	public function getDataLancamentoAttribute()
	{
		return $this->attributes['data_lancamento'];
	}

	public function setDataLancamentoAttribute($dataLancamento)
	{
		$this->attributes['data_lancamento'] = $dataLancamento;
	}

	public function getNumeroDocumentoAttribute()
	{
		return $this->attributes['numero_documento'];
	}

	public function setNumeroDocumentoAttribute($numeroDocumento)
	{
		$this->attributes['numero_documento'] = $numeroDocumento;
	}

	public function getPrimeiroVencimentoAttribute()
	{
		return $this->attributes['primeiro_vencimento'];
	}

	public function setPrimeiroVencimentoAttribute($primeiroVencimento)
	{
		$this->attributes['primeiro_vencimento'] = $primeiroVencimento;
	}

	public function getIntervaloEntreParcelasAttribute()
	{
		return $this->attributes['intervalo_entre_parcelas'];
	}

	public function setIntervaloEntreParcelasAttribute($intervaloEntreParcelas)
	{
		$this->attributes['intervalo_entre_parcelas'] = $intervaloEntreParcelas;
	}

	public function getDiaFixoAttribute()
	{
		return $this->attributes['dia_fixo'];
	}

	public function setDiaFixoAttribute($diaFixo)
	{
		$this->attributes['dia_fixo'] = $diaFixo;
	}

	public function getImagemDocumentoAttribute()
	{
		return $this->attributes['imagem_documento'];
	}

	public function setImagemDocumentoAttribute($imagemDocumento)
	{
		$this->attributes['imagem_documento'] = $imagemDocumento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeParcelaAttribute($object->quantidadeParcela);
				$this->setValorAPagarAttribute($object->valorAPagar);
				$this->setDataLancamentoAttribute($object->dataLancamento);
				$this->setNumeroDocumentoAttribute($object->numeroDocumento);
				$this->setPrimeiroVencimentoAttribute($object->primeiroVencimento);
				$this->setIntervaloEntreParcelasAttribute($object->intervaloEntreParcelas);
				$this->setDiaFixoAttribute($object->diaFixo);
				$this->setImagemDocumentoAttribute($object->imagemDocumento);

				// link objects - lookups
				$finDocumentoOrigemModel = new FinDocumentoOrigemModel();
				$finDocumentoOrigemModel->mapping($object->finDocumentoOrigemModel);
				$this->finDocumentoOrigemModel()->associate($finDocumentoOrigemModel);
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
				$finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel();
				$finNaturezaFinanceiraModel->mapping($object->finNaturezaFinanceiraModel);
				$this->finNaturezaFinanceiraModel()->associate($finNaturezaFinanceiraModel);
				$viewPessoaFornecedorModel = new ViewPessoaFornecedorModel();
				$viewPessoaFornecedorModel->mapping($object->viewPessoaFornecedorModel);
				$this->viewPessoaFornecedorModel()->associate($viewPessoaFornecedorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidadeParcela' => $this->getQuantidadeParcelaAttribute(),
				'valorAPagar' => $this->getValorAPagarAttribute(),
				'dataLancamento' => $this->getDataLancamentoAttribute(),
				'numeroDocumento' => $this->getNumeroDocumentoAttribute(),
				'primeiroVencimento' => $this->getPrimeiroVencimentoAttribute(),
				'intervaloEntreParcelas' => $this->getIntervaloEntreParcelasAttribute(),
				'diaFixo' => $this->getDiaFixoAttribute(),
				'imagemDocumento' => $this->getImagemDocumentoAttribute(),
				'finParcelaPagarModelList' => $this->finParcelaPagarModelList,
				'finDocumentoOrigemModel' => $this->finDocumentoOrigemModel,
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
				'finNaturezaFinanceiraModel' => $this->finNaturezaFinanceiraModel,
				'viewPessoaFornecedorModel' => $this->viewPessoaFornecedorModel,
			];
	}
}