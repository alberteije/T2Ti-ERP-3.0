<?php

class BoletoIniMustache
{
	public $numeroDocumento;
	public $nossoNumero;
	public $carteira;
	public $localPagamento;
	public $dataVencimento;
	public $dataDocumento;
	public $dataProcessamento;
	public $aceite;
	public $dataDesconto;
	public $valorDocumento;
	public $percentualMulta;
	public $instrucao01;
	public $instrucao02;
	public $nomeSacado;
	public $cpfCnpjSacado;

	public function __construct($idParcela)
	{
		$filtro = 'id_fin_parcela_receber = "' . $idParcela . '"';
		$lancamento = ViewFinLancamentoReceberModel::whereRaw($filtro)->first();
		$configuracaoBoleto = FinConfiguracaoBoletoModel::find(1);

		$this->numeroDocumento = $lancamento->numeroDocumento;
		$this->nossoNumero = $lancamento->numeroDocumento;
		$this->carteira = $configuracaoBoleto->carteira;
		$this->localPagamento = $configuracaoBoleto->localPagamento;
		$this->dataVencimento = $lancamento->dataVencimento;
		$this->dataDocumento = $lancamento->dataLancamento;
		$this->dataProcessamento = $lancamento->dataLancamento;
		$this->aceite = $configuracaoBoleto->aceite;
		$this->dataDesconto = $lancamento->dataVencimento; // Mesmo que vencimento ou ajustar
		$this->valorDocumento = $lancamento->valorParcela;
		$this->percentualMulta = $lancamento->taxaMulta;
		$this->instrucao01 = $configuracaoBoleto->instrucao01;
		$this->instrucao02 = $configuracaoBoleto->instrucao02;
		$this->nomeSacado = $lancamento->nomeCliente;
		$this->cpfCnpjSacado = '';
	}
}
