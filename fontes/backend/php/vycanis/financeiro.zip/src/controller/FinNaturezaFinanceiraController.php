<?php
class FinNaturezaFinanceiraController extends ControllerBase
{

		private $finNaturezaFinanceiraService = null;

		public function __construct()
		{	 
				$this->finNaturezaFinanceiraService = new FinNaturezaFinanceiraService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->finNaturezaFinanceiraService->getListFilter($filter);
						} else {
								$resultList = $this->finNaturezaFinanceiraService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList FinNaturezaFinanceira]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->finNaturezaFinanceiraService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject FinNaturezaFinanceira]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject FinNaturezaFinanceira]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert FinNaturezaFinanceira]', null);
						}

						$objModel = new FinNaturezaFinanceiraModel();
						$objModel->mapping($objJson);

						$this->finNaturezaFinanceiraService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert FinNaturezaFinanceira]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->finNaturezaFinanceiraService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update FinNaturezaFinanceira]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->finNaturezaFinanceiraService->save($objFromDatabase);
								$objFromDatabase = $this->finNaturezaFinanceiraService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update FinNaturezaFinanceira]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->finNaturezaFinanceiraService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete FinNaturezaFinanceira]', null);
						} else {
								$this->finNaturezaFinanceiraService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete FinNaturezaFinanceira]', $e);
				}
		}
}
