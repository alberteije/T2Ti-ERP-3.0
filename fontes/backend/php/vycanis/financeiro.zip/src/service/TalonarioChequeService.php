<?php
use Illuminate\Database\Capsule\Manager as DB;
class TalonarioChequeService extends ServiceBase
{
	public function getList()
	{
		return TalonarioChequeModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return TalonarioChequeModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return TalonarioChequeModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// cheque
		$chequeModelListJson = $objJson->chequeModelList;
		if ($chequeModelListJson != null) {
			for ($i = 0; $i < count($chequeModelListJson); $i++) {
				$cheque = new ChequeModel();
				$cheque->mapping($chequeModelListJson[$i]);
				$objModel->chequeModelList()->save($cheque);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ChequeModel::where('id_talonario_cheque', $object->getIdAttribute())->delete();
	}	
 
}