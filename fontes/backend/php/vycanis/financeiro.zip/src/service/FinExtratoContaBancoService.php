<?php
class FinExtratoContaBancoService extends ServiceBase
{
  public function getList()
  {
    return FinExtratoContaBancoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinExtratoContaBancoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinExtratoContaBancoModel::find($id);
  }

}