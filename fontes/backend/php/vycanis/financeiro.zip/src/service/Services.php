<?php

include 'ServiceBase.php';

include 'TalonarioChequeService.php';
include 'FinLancamentoPagarService.php';
include 'FinLancamentoReceberService.php';
include 'BancoService.php';
include 'BancoAgenciaService.php';
include 'BancoContaCaixaService.php';
include 'FinFechamentoCaixaBancoService.php';
include 'FinExtratoContaBancoService.php';
include 'FinDocumentoOrigemService.php';
include 'FinNaturezaFinanceiraService.php';
include 'FinStatusParcelaService.php';
include 'FinTipoPagamentoService.php';
include 'FinChequeEmitidoService.php';
include 'FinTipoRecebimentoService.php';
include 'FinChequeRecebidoService.php';
include 'FinConfiguracaoBoletoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaClienteService.php';
include 'ViewPessoaFornecedorService.php';