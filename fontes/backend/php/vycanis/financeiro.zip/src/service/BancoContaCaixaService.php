<?php
class BancoContaCaixaService extends ServiceBase
{
  public function getList()
  {
    return BancoContaCaixaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return BancoContaCaixaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return BancoContaCaixaModel::find($id);
  }

}