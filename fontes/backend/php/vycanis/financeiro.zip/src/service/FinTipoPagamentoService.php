<?php
class FinTipoPagamentoService extends ServiceBase
{
  public function getList()
  {
    return FinTipoPagamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinTipoPagamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinTipoPagamentoModel::find($id);
  }

}