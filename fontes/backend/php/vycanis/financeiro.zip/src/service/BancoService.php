<?php
class BancoService extends ServiceBase
{
  public function getList()
  {
    return BancoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return BancoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return BancoModel::find($id);
  }

}