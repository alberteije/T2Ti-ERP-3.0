<?php
use Illuminate\Database\Capsule\Manager as DB;
class FinLancamentoReceberService extends ServiceBase
{
	public function getList()
	{
		return FinLancamentoReceberModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FinLancamentoReceberModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FinLancamentoReceberModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// finParcelaReceber
		$finParcelaReceberModelListJson = $objJson->finParcelaReceberModelList;
		if ($finParcelaReceberModelListJson != null) {
			for ($i = 0; $i < count($finParcelaReceberModelListJson); $i++) {
				$finParcelaReceber = new FinParcelaReceberModel();
				$finParcelaReceber->mapping($finParcelaReceberModelListJson[$i]);
				$objModel->finParcelaReceberModelList()->save($finParcelaReceber);
			}
		}

	}	

	public function deleteChildren($object)
	{
		FinParcelaReceberModel::where('id_fin_lancamento_receber', $object->getIdAttribute())->delete();
	}	
 
}