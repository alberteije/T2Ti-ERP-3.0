<?php
class FinConfiguracaoBoletoService extends ServiceBase
{
  public function getList()
  {
    return FinConfiguracaoBoletoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinConfiguracaoBoletoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinConfiguracaoBoletoModel::find($id);
  }

}