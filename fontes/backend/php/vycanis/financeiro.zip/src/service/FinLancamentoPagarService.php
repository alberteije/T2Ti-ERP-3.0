<?php
use Illuminate\Database\Capsule\Manager as DB;
class FinLancamentoPagarService extends ServiceBase
{
	public function getList()
	{
		return FinLancamentoPagarModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FinLancamentoPagarModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FinLancamentoPagarModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// finParcelaPagar
		$finParcelaPagarModelListJson = $objJson->finParcelaPagarModelList;
		if ($finParcelaPagarModelListJson != null) {
			for ($i = 0; $i < count($finParcelaPagarModelListJson); $i++) {
				$finParcelaPagar = new FinParcelaPagarModel();
				$finParcelaPagar->mapping($finParcelaPagarModelListJson[$i]);
				$objModel->finParcelaPagarModelList()->save($finParcelaPagar);
			}
		}

	}	

	public function deleteChildren($object)
	{
		FinParcelaPagarModel::where('id_fin_lancamento_pagar', $object->getIdAttribute())->delete();
	}	
 
}