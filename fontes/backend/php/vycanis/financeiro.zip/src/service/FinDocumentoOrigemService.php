<?php
class FinDocumentoOrigemService extends ServiceBase
{
  public function getList()
  {
    return FinDocumentoOrigemModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinDocumentoOrigemModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinDocumentoOrigemModel::find($id);
  }

}