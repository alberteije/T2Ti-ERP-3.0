<?php
class FinStatusParcelaService extends ServiceBase
{
  public function getList()
  {
    return FinStatusParcelaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinStatusParcelaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinStatusParcelaModel::find($id);
  }

}