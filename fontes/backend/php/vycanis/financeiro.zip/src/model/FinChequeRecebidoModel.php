<?php
declare(strict_types=1);

class FinChequeRecebidoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_cheque_recebido';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaClienteModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getCodigoBancoAttribute()
	{
		return $this->attributes['codigo_banco'];
	}

	public function setCodigoBancoAttribute($codigoBanco)
	{
		$this->attributes['codigo_banco'] = $codigoBanco;
	}

	public function getCodigoAgenciaAttribute()
	{
		return $this->attributes['codigo_agencia'];
	}

	public function setCodigoAgenciaAttribute($codigoAgencia)
	{
		$this->attributes['codigo_agencia'] = $codigoAgencia;
	}

	public function getContaAttribute()
	{
		return $this->attributes['conta'];
	}

	public function setContaAttribute($conta)
	{
		$this->attributes['conta'] = $conta;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataEmissaoAttribute()
	{
		return $this->attributes['data_emissao'];
	}

	public function setDataEmissaoAttribute($dataEmissao)
	{
		$this->attributes['data_emissao'] = $dataEmissao;
	}

	public function getBomParaAttribute()
	{
		return $this->attributes['bom_para'];
	}

	public function setBomParaAttribute($bomPara)
	{
		$this->attributes['bom_para'] = $bomPara;
	}

	public function getDataCompensacaoAttribute()
	{
		return $this->attributes['data_compensacao'];
	}

	public function setDataCompensacaoAttribute($dataCompensacao)
	{
		$this->attributes['data_compensacao'] = $dataCompensacao;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getCustodiaDataAttribute()
	{
		return $this->attributes['custodia_data'];
	}

	public function setCustodiaDataAttribute($custodiaData)
	{
		$this->attributes['custodia_data'] = $custodiaData;
	}

	public function getCustodiaTarifaAttribute()
	{
		return (double)$this->attributes['custodia_tarifa'];
	}

	public function setCustodiaTarifaAttribute($custodiaTarifa)
	{
		$this->attributes['custodia_tarifa'] = $custodiaTarifa;
	}

	public function getCustodiaComissaoAttribute()
	{
		return (double)$this->attributes['custodia_comissao'];
	}

	public function setCustodiaComissaoAttribute($custodiaComissao)
	{
		$this->attributes['custodia_comissao'] = $custodiaComissao;
	}

	public function getDescontoDataAttribute()
	{
		return $this->attributes['desconto_data'];
	}

	public function setDescontoDataAttribute($descontoData)
	{
		$this->attributes['desconto_data'] = $descontoData;
	}

	public function getDescontoTarifaAttribute()
	{
		return (double)$this->attributes['desconto_tarifa'];
	}

	public function setDescontoTarifaAttribute($descontoTarifa)
	{
		$this->attributes['desconto_tarifa'] = $descontoTarifa;
	}

	public function getDescontoComissaoAttribute()
	{
		return (double)$this->attributes['desconto_comissao'];
	}

	public function setDescontoComissaoAttribute($descontoComissao)
	{
		$this->attributes['desconto_comissao'] = $descontoComissao;
	}

	public function getValorRecebidoAttribute()
	{
		return (double)$this->attributes['valor_recebido'];
	}

	public function setValorRecebidoAttribute($valorRecebido)
	{
		$this->attributes['valor_recebido'] = $valorRecebido;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCpfAttribute($object->cpf);
				$this->setCnpjAttribute($object->cnpj);
				$this->setNomeAttribute($object->nome);
				$this->setCodigoBancoAttribute($object->codigoBanco);
				$this->setCodigoAgenciaAttribute($object->codigoAgencia);
				$this->setContaAttribute($object->conta);
				$this->setNumeroAttribute($object->numero);
				$this->setDataEmissaoAttribute($object->dataEmissao);
				$this->setBomParaAttribute($object->bomPara);
				$this->setDataCompensacaoAttribute($object->dataCompensacao);
				$this->setValorAttribute($object->valor);
				$this->setCustodiaDataAttribute($object->custodiaData);
				$this->setCustodiaTarifaAttribute($object->custodiaTarifa);
				$this->setCustodiaComissaoAttribute($object->custodiaComissao);
				$this->setDescontoDataAttribute($object->descontoData);
				$this->setDescontoTarifaAttribute($object->descontoTarifa);
				$this->setDescontoComissaoAttribute($object->descontoComissao);
				$this->setValorRecebidoAttribute($object->valorRecebido);

				// link objects - lookups
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'nome' => $this->getNomeAttribute(),
				'codigoBanco' => $this->getCodigoBancoAttribute(),
				'codigoAgencia' => $this->getCodigoAgenciaAttribute(),
				'conta' => $this->getContaAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataEmissao' => $this->getDataEmissaoAttribute(),
				'bomPara' => $this->getBomParaAttribute(),
				'dataCompensacao' => $this->getDataCompensacaoAttribute(),
				'valor' => $this->getValorAttribute(),
				'custodiaData' => $this->getCustodiaDataAttribute(),
				'custodiaTarifa' => $this->getCustodiaTarifaAttribute(),
				'custodiaComissao' => $this->getCustodiaComissaoAttribute(),
				'descontoData' => $this->getDescontoDataAttribute(),
				'descontoTarifa' => $this->getDescontoTarifaAttribute(),
				'descontoComissao' => $this->getDescontoComissaoAttribute(),
				'valorRecebido' => $this->getValorRecebidoAttribute(),
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
			];
	}
}