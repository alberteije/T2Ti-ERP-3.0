<?php
declare(strict_types=1);

class FinNaturezaFinanceiraModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_natureza_financeira';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getAplicacaoAttribute()
	{
		return $this->attributes['aplicacao'];
	}

	public function setAplicacaoAttribute($aplicacao)
	{
		$this->attributes['aplicacao'] = $aplicacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setTipoAttribute($object->tipo);
				$this->setDescricaoAttribute($object->descricao);
				$this->setAplicacaoAttribute($object->aplicacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'aplicacao' => $this->getAplicacaoAttribute(),
			];
	}
}