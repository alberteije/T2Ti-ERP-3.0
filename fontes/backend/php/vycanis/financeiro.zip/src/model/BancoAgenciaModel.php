<?php
declare(strict_types=1);

class BancoAgenciaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'banco_agencia';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'bancoModel',
	];

	/**
		* Relations
		*/
	public function bancoModel()
	{
		return $this->belongsTo(BancoModel::class, 'id_banco', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDigitoAttribute()
	{
		return $this->attributes['digito'];
	}

	public function setDigitoAttribute($digito)
	{
		$this->attributes['digito'] = $digito;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getTelefoneAttribute()
	{
		return $this->attributes['telefone'];
	}

	public function setTelefoneAttribute($telefone)
	{
		$this->attributes['telefone'] = $telefone;
	}

	public function getContatoAttribute()
	{
		return $this->attributes['contato'];
	}

	public function setContatoAttribute($contato)
	{
		$this->attributes['contato'] = $contato;
	}

	public function getGerenteAttribute()
	{
		return $this->attributes['gerente'];
	}

	public function setGerenteAttribute($gerente)
	{
		$this->attributes['gerente'] = $gerente;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setDigitoAttribute($object->digito);
				$this->setNomeAttribute($object->nome);
				$this->setTelefoneAttribute($object->telefone);
				$this->setContatoAttribute($object->contato);
				$this->setGerenteAttribute($object->gerente);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$bancoModel = new BancoModel();
				$bancoModel->mapping($object->bancoModel);
				$this->bancoModel()->associate($bancoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'digito' => $this->getDigitoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'telefone' => $this->getTelefoneAttribute(),
				'contato' => $this->getContatoAttribute(),
				'gerente' => $this->getGerenteAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'bancoModel' => $this->bancoModel,
			];
	}
}