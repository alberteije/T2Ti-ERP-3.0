<?php
declare(strict_types=1);

class FinChequeEmitidoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_cheque_emitido';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'chequeModel',
	];

	/**
		* Relations
		*/
	public function chequeModel()
	{
		return $this->belongsTo(ChequeModel::class, 'id_cheque', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataEmissaoAttribute()
	{
		return $this->attributes['data_emissao'];
	}

	public function setDataEmissaoAttribute($dataEmissao)
	{
		$this->attributes['data_emissao'] = $dataEmissao;
	}

	public function getBomParaAttribute()
	{
		return $this->attributes['bom_para'];
	}

	public function setBomParaAttribute($bomPara)
	{
		$this->attributes['bom_para'] = $bomPara;
	}

	public function getDataCompensacaoAttribute()
	{
		return $this->attributes['data_compensacao'];
	}

	public function setDataCompensacaoAttribute($dataCompensacao)
	{
		$this->attributes['data_compensacao'] = $dataCompensacao;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getNominalAAttribute()
	{
		return $this->attributes['nominal_a'];
	}

	public function setNominalAAttribute($nominalA)
	{
		$this->attributes['nominal_a'] = $nominalA;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataEmissaoAttribute($object->dataEmissao);
				$this->setBomParaAttribute($object->bomPara);
				$this->setDataCompensacaoAttribute($object->dataCompensacao);
				$this->setValorAttribute($object->valor);
				$this->setNominalAAttribute($object->nominalA);

				// link objects - lookups
				$chequeModel = new ChequeModel();
				$chequeModel->mapping($object->chequeModel);
				$this->chequeModel()->associate($chequeModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataEmissao' => $this->getDataEmissaoAttribute(),
				'bomPara' => $this->getBomParaAttribute(),
				'dataCompensacao' => $this->getDataCompensacaoAttribute(),
				'valor' => $this->getValorAttribute(),
				'nominalA' => $this->getNominalAAttribute(),
				'chequeModel' => $this->chequeModel,
			];
	}
}