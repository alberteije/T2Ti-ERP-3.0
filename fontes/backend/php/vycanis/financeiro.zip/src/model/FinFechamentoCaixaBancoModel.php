<?php
declare(strict_types=1);

class FinFechamentoCaixaBancoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fin_fechamento_caixa_banco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'bancoContaCaixaModel',
	];

	/**
		* Relations
		*/
	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataFechamentoAttribute()
	{
		return $this->attributes['data_fechamento'];
	}

	public function setDataFechamentoAttribute($dataFechamento)
	{
		$this->attributes['data_fechamento'] = $dataFechamento;
	}

	public function getMesAnoAttribute()
	{
		return $this->attributes['mes_ano'];
	}

	public function setMesAnoAttribute($mesAno)
	{
		$this->attributes['mes_ano'] = $mesAno;
	}

	public function getMesAttribute()
	{
		return $this->attributes['mes'];
	}

	public function setMesAttribute($mes)
	{
		$this->attributes['mes'] = $mes;
	}

	public function getAnoAttribute()
	{
		return $this->attributes['ano'];
	}

	public function setAnoAttribute($ano)
	{
		$this->attributes['ano'] = $ano;
	}

	public function getSaldoAnteriorAttribute()
	{
		return (double)$this->attributes['saldo_anterior'];
	}

	public function setSaldoAnteriorAttribute($saldoAnterior)
	{
		$this->attributes['saldo_anterior'] = $saldoAnterior;
	}

	public function getRecebimentosAttribute()
	{
		return (double)$this->attributes['recebimentos'];
	}

	public function setRecebimentosAttribute($recebimentos)
	{
		$this->attributes['recebimentos'] = $recebimentos;
	}

	public function getPagamentosAttribute()
	{
		return (double)$this->attributes['pagamentos'];
	}

	public function setPagamentosAttribute($pagamentos)
	{
		$this->attributes['pagamentos'] = $pagamentos;
	}

	public function getSaldoContaAttribute()
	{
		return (double)$this->attributes['saldo_conta'];
	}

	public function setSaldoContaAttribute($saldoConta)
	{
		$this->attributes['saldo_conta'] = $saldoConta;
	}

	public function getChequeNaoCompensadoAttribute()
	{
		return (double)$this->attributes['cheque_nao_compensado'];
	}

	public function setChequeNaoCompensadoAttribute($chequeNaoCompensado)
	{
		$this->attributes['cheque_nao_compensado'] = $chequeNaoCompensado;
	}

	public function getSaldoDisponivelAttribute()
	{
		return (double)$this->attributes['saldo_disponivel'];
	}

	public function setSaldoDisponivelAttribute($saldoDisponivel)
	{
		$this->attributes['saldo_disponivel'] = $saldoDisponivel;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataFechamentoAttribute($object->dataFechamento);
				$this->setMesAnoAttribute($object->mesAno);
				$this->setMesAttribute($object->mes);
				$this->setAnoAttribute($object->ano);
				$this->setSaldoAnteriorAttribute($object->saldoAnterior);
				$this->setRecebimentosAttribute($object->recebimentos);
				$this->setPagamentosAttribute($object->pagamentos);
				$this->setSaldoContaAttribute($object->saldoConta);
				$this->setChequeNaoCompensadoAttribute($object->chequeNaoCompensado);
				$this->setSaldoDisponivelAttribute($object->saldoDisponivel);

				// link objects - lookups
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataFechamento' => $this->getDataFechamentoAttribute(),
				'mesAno' => $this->getMesAnoAttribute(),
				'mes' => $this->getMesAttribute(),
				'ano' => $this->getAnoAttribute(),
				'saldoAnterior' => $this->getSaldoAnteriorAttribute(),
				'recebimentos' => $this->getRecebimentosAttribute(),
				'pagamentos' => $this->getPagamentosAttribute(),
				'saldoConta' => $this->getSaldoContaAttribute(),
				'chequeNaoCompensado' => $this->getChequeNaoCompensadoAttribute(),
				'saldoDisponivel' => $this->getSaldoDisponivelAttribute(),
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
			];
	}
}