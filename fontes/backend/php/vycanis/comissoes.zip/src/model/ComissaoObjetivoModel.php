<?php
declare(strict_types=1);

class ComissaoObjetivoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'comissao_objetivo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'comissaoPerfilModel',
	];

	/**
		* Relations
		*/
	public function comissaoPerfilModel()
	{
		return $this->belongsTo(ComissaoPerfilModel::class, 'id_comissao_perfil', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getTaxaPagamentoAttribute()
	{
		return (double)$this->attributes['taxa_pagamento'];
	}

	public function setTaxaPagamentoAttribute($taxaPagamento)
	{
		$this->attributes['taxa_pagamento'] = $taxaPagamento;
	}

	public function getValorPagamentoAttribute()
	{
		return (double)$this->attributes['valor_pagamento'];
	}

	public function setValorPagamentoAttribute($valorPagamento)
	{
		$this->attributes['valor_pagamento'] = $valorPagamento;
	}

	public function getValorMetaAttribute()
	{
		return (double)$this->attributes['valor_meta'];
	}

	public function setValorMetaAttribute($valorMeta)
	{
		$this->attributes['valor_meta'] = $valorMeta;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setTaxaPagamentoAttribute($object->taxaPagamento);
				$this->setValorPagamentoAttribute($object->valorPagamento);
				$this->setValorMetaAttribute($object->valorMeta);
				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);

				// link objects - lookups
				$comissaoPerfilModel = new ComissaoPerfilModel();
				$comissaoPerfilModel->mapping($object->comissaoPerfilModel);
				$this->comissaoPerfilModel()->associate($comissaoPerfilModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'taxaPagamento' => $this->getTaxaPagamentoAttribute(),
				'valorPagamento' => $this->getValorPagamentoAttribute(),
				'valorMeta' => $this->getValorMetaAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'comissaoPerfilModel' => $this->comissaoPerfilModel,
			];
	}
}