<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'ComissaoPerfilModel.php';
include 'ComissaoObjetivoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';