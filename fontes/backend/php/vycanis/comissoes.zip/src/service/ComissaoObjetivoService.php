<?php
class ComissaoObjetivoService extends ServiceBase
{
  public function getList()
  {
    return ComissaoObjetivoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ComissaoObjetivoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ComissaoObjetivoModel::find($id);
  }

}