<?php
class ComissaoPerfilService extends ServiceBase
{
  public function getList()
  {
    return ComissaoPerfilModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ComissaoPerfilModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ComissaoPerfilModel::find($id);
  }

}