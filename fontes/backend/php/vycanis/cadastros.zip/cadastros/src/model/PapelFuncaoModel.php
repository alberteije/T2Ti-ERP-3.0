<?php
declare(strict_types=1);

class PapelFuncaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'papel_funcao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function papelModel()
	{
		return $this->belongsTo(PapelModel::class, 'id_papel', 'id');
	}

	public function funcaoModel()
	{
		return $this->belongsTo(FuncaoModel::class, 'id_funcao', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getHabilitadoAttribute()
	{
		return $this->attributes['habilitado'];
	}

	public function setHabilitadoAttribute($habilitado)
	{
		$this->attributes['habilitado'] = $habilitado;
	}

	public function getPodeInserirAttribute()
	{
		return $this->attributes['pode_inserir'];
	}

	public function setPodeInserirAttribute($podeInserir)
	{
		$this->attributes['pode_inserir'] = $podeInserir;
	}

	public function getPodeAlterarAttribute()
	{
		return $this->attributes['pode_alterar'];
	}

	public function setPodeAlterarAttribute($podeAlterar)
	{
		$this->attributes['pode_alterar'] = $podeAlterar;
	}

	public function getPodeExcluirAttribute()
	{
		return $this->attributes['pode_excluir'];
	}

	public function setPodeExcluirAttribute($podeExcluir)
	{
		$this->attributes['pode_excluir'] = $podeExcluir;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setHabilitadoAttribute($object->habilitado);
				$this->setPodeInserirAttribute($object->podeInserir);
				$this->setPodeAlterarAttribute($object->podeAlterar);
				$this->setPodeExcluirAttribute($object->podeExcluir);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'habilitado' => $this->getHabilitadoAttribute(),
				'podeInserir' => $this->getPodeInserirAttribute(),
				'podeAlterar' => $this->getPodeAlterarAttribute(),
				'podeExcluir' => $this->getPodeExcluirAttribute(),
			];
	}
}