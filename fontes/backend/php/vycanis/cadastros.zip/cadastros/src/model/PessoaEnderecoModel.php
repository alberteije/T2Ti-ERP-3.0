<?php
declare(strict_types=1);

class PessoaEnderecoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pessoa_endereco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function pessoaModel()
	{
		return $this->belongsTo(PessoaModel::class, 'id_pessoa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getComplementoAttribute()
	{
		return $this->attributes['complemento'];
	}

	public function setComplementoAttribute($complemento)
	{
		$this->attributes['complemento'] = $complemento;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getCidadeAttribute()
	{
		return $this->attributes['cidade'];
	}

	public function setCidadeAttribute($cidade)
	{
		$this->attributes['cidade'] = $cidade;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getCepAttribute()
	{
		return $this->attributes['cep'];
	}

	public function setCepAttribute($cep)
	{
		$this->attributes['cep'] = $cep;
	}

	public function getMunicipioIbgeAttribute()
	{
		return $this->attributes['municipio_ibge'];
	}

	public function setMunicipioIbgeAttribute($municipioIbge)
	{
		$this->attributes['municipio_ibge'] = $municipioIbge;
	}

	public function getPrincipalAttribute()
	{
		return $this->attributes['principal'];
	}

	public function setPrincipalAttribute($principal)
	{
		$this->attributes['principal'] = $principal;
	}

	public function getEntregaAttribute()
	{
		return $this->attributes['entrega'];
	}

	public function setEntregaAttribute($entrega)
	{
		$this->attributes['entrega'] = $entrega;
	}

	public function getCobrancaAttribute()
	{
		return $this->attributes['cobranca'];
	}

	public function setCobrancaAttribute($cobranca)
	{
		$this->attributes['cobranca'] = $cobranca;
	}

	public function getCorrespondenciaAttribute()
	{
		return $this->attributes['correspondencia'];
	}

	public function setCorrespondenciaAttribute($correspondencia)
	{
		$this->attributes['correspondencia'] = $correspondencia;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setLogradouroAttribute($object->logradouro);
				$this->setNumeroAttribute($object->numero);
				$this->setComplementoAttribute($object->complemento);
				$this->setBairroAttribute($object->bairro);
				$this->setCidadeAttribute($object->cidade);
				$this->setUfAttribute($object->uf);
				$this->setCepAttribute($object->cep);
				$this->setMunicipioIbgeAttribute($object->municipioIbge);
				$this->setPrincipalAttribute($object->principal);
				$this->setEntregaAttribute($object->entrega);
				$this->setCobrancaAttribute($object->cobranca);
				$this->setCorrespondenciaAttribute($object->correspondencia);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'complemento' => $this->getComplementoAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'cidade' => $this->getCidadeAttribute(),
				'uf' => $this->getUfAttribute(),
				'cep' => $this->getCepAttribute(),
				'municipioIbge' => $this->getMunicipioIbgeAttribute(),
				'principal' => $this->getPrincipalAttribute(),
				'entrega' => $this->getEntregaAttribute(),
				'cobranca' => $this->getCobrancaAttribute(),
				'correspondencia' => $this->getCorrespondenciaAttribute(),
			];
	}
}