<?php
declare(strict_types=1);

class CepModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cep';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getComplementoAttribute()
	{
		return $this->attributes['complemento'];
	}

	public function setComplementoAttribute($complemento)
	{
		$this->attributes['complemento'] = $complemento;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getMunicipioAttribute()
	{
		return $this->attributes['municipio'];
	}

	public function setMunicipioAttribute($municipio)
	{
		$this->attributes['municipio'] = $municipio;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getCodigoIbgeMunicipioAttribute()
	{
		return $this->attributes['codigo_ibge_municipio'];
	}

	public function setCodigoIbgeMunicipioAttribute($codigoIbgeMunicipio)
	{
		$this->attributes['codigo_ibge_municipio'] = $codigoIbgeMunicipio;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setLogradouroAttribute($object->logradouro);
				$this->setComplementoAttribute($object->complemento);
				$this->setBairroAttribute($object->bairro);
				$this->setMunicipioAttribute($object->municipio);
				$this->setUfAttribute($object->uf);
				$this->setCodigoIbgeMunicipioAttribute($object->codigoIbgeMunicipio);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'complemento' => $this->getComplementoAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'municipio' => $this->getMunicipioAttribute(),
				'uf' => $this->getUfAttribute(),
				'codigoIbgeMunicipio' => $this->getCodigoIbgeMunicipioAttribute(),
			];
	}
}