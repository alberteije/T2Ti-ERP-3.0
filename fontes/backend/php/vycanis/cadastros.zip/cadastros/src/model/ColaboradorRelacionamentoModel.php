<?php
declare(strict_types=1);

class ColaboradorRelacionamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'colaborador_relacionamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'tipoRelacionamentoModel',
	];

	/**
		* Relations
		*/
	public function colaboradorModel()
	{
		return $this->belongsTo(ColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function tipoRelacionamentoModel()
	{
		return $this->belongsTo(TipoRelacionamentoModel::class, 'id_tipo_relacionamento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDataNascimentoAttribute()
	{
		return $this->attributes['data_nascimento'];
	}

	public function setDataNascimentoAttribute($dataNascimento)
	{
		$this->attributes['data_nascimento'] = $dataNascimento;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getRegistroMatriculaAttribute()
	{
		return $this->attributes['registro_matricula'];
	}

	public function setRegistroMatriculaAttribute($registroMatricula)
	{
		$this->attributes['registro_matricula'] = $registroMatricula;
	}

	public function getRegistroCartorioAttribute()
	{
		return $this->attributes['registro_cartorio'];
	}

	public function setRegistroCartorioAttribute($registroCartorio)
	{
		$this->attributes['registro_cartorio'] = $registroCartorio;
	}

	public function getRegistroCartorioNumeroAttribute()
	{
		return $this->attributes['registro_cartorio_numero'];
	}

	public function setRegistroCartorioNumeroAttribute($registroCartorioNumero)
	{
		$this->attributes['registro_cartorio_numero'] = $registroCartorioNumero;
	}

	public function getRegistroNumeroLivroAttribute()
	{
		return $this->attributes['registro_numero_livro'];
	}

	public function setRegistroNumeroLivroAttribute($registroNumeroLivro)
	{
		$this->attributes['registro_numero_livro'] = $registroNumeroLivro;
	}

	public function getRegistroNumeroFolhaAttribute()
	{
		return $this->attributes['registro_numero_folha'];
	}

	public function setRegistroNumeroFolhaAttribute($registroNumeroFolha)
	{
		$this->attributes['registro_numero_folha'] = $registroNumeroFolha;
	}

	public function getDataEntregaDocumentoAttribute()
	{
		return $this->attributes['data_entrega_documento'];
	}

	public function setDataEntregaDocumentoAttribute($dataEntregaDocumento)
	{
		$this->attributes['data_entrega_documento'] = $dataEntregaDocumento;
	}

	public function getSalarioFamiliaAttribute()
	{
		return $this->attributes['salario_familia'];
	}

	public function setSalarioFamiliaAttribute($salarioFamilia)
	{
		$this->attributes['salario_familia'] = $salarioFamilia;
	}

	public function getSalarioFamiliaIdadeLimiteAttribute()
	{
		return $this->attributes['salario_familia_idade_limite'];
	}

	public function setSalarioFamiliaIdadeLimiteAttribute($salarioFamiliaIdadeLimite)
	{
		$this->attributes['salario_familia_idade_limite'] = $salarioFamiliaIdadeLimite;
	}

	public function getSalarioFamiliaDataFimAttribute()
	{
		return $this->attributes['salario_familia_data_fim'];
	}

	public function setSalarioFamiliaDataFimAttribute($salarioFamiliaDataFim)
	{
		$this->attributes['salario_familia_data_fim'] = $salarioFamiliaDataFim;
	}

	public function getImpostoRendaIdadeLimiteAttribute()
	{
		return $this->attributes['imposto_renda_idade_limite'];
	}

	public function setImpostoRendaIdadeLimiteAttribute($impostoRendaIdadeLimite)
	{
		$this->attributes['imposto_renda_idade_limite'] = $impostoRendaIdadeLimite;
	}

	public function getImpostoRendaDataFimAttribute()
	{
		return $this->attributes['imposto_renda_data_fim'];
	}

	public function setImpostoRendaDataFimAttribute($impostoRendaDataFim)
	{
		$this->attributes['imposto_renda_data_fim'] = $impostoRendaDataFim;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDataNascimentoAttribute($object->dataNascimento);
				$this->setCpfAttribute($object->cpf);
				$this->setRegistroMatriculaAttribute($object->registroMatricula);
				$this->setRegistroCartorioAttribute($object->registroCartorio);
				$this->setRegistroCartorioNumeroAttribute($object->registroCartorioNumero);
				$this->setRegistroNumeroLivroAttribute($object->registroNumeroLivro);
				$this->setRegistroNumeroFolhaAttribute($object->registroNumeroFolha);
				$this->setDataEntregaDocumentoAttribute($object->dataEntregaDocumento);
				$this->setSalarioFamiliaAttribute($object->salarioFamilia);
				$this->setSalarioFamiliaIdadeLimiteAttribute($object->salarioFamiliaIdadeLimite);
				$this->setSalarioFamiliaDataFimAttribute($object->salarioFamiliaDataFim);
				$this->setImpostoRendaIdadeLimiteAttribute($object->impostoRendaIdadeLimite);
				$this->setImpostoRendaDataFimAttribute($object->impostoRendaDataFim);

				// link objects - lookups
				$tipoRelacionamentoModel = new TipoRelacionamentoModel();
				$tipoRelacionamentoModel->mapping($object->tipoRelacionamentoModel);
				$this->tipoRelacionamentoModel()->associate($tipoRelacionamentoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'dataNascimento' => $this->getDataNascimentoAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'registroMatricula' => $this->getRegistroMatriculaAttribute(),
				'registroCartorio' => $this->getRegistroCartorioAttribute(),
				'registroCartorioNumero' => $this->getRegistroCartorioNumeroAttribute(),
				'registroNumeroLivro' => $this->getRegistroNumeroLivroAttribute(),
				'registroNumeroFolha' => $this->getRegistroNumeroFolhaAttribute(),
				'dataEntregaDocumento' => $this->getDataEntregaDocumentoAttribute(),
				'salarioFamilia' => $this->getSalarioFamiliaAttribute(),
				'salarioFamiliaIdadeLimite' => $this->getSalarioFamiliaIdadeLimiteAttribute(),
				'salarioFamiliaDataFim' => $this->getSalarioFamiliaDataFimAttribute(),
				'impostoRendaIdadeLimite' => $this->getImpostoRendaIdadeLimiteAttribute(),
				'impostoRendaDataFim' => $this->getImpostoRendaDataFimAttribute(),
				'tipoRelacionamentoModel' => $this->tipoRelacionamentoModel,
			];
	}
}