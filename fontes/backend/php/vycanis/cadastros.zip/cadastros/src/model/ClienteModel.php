<?php
declare(strict_types=1);

class ClienteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cliente';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'tabelaPrecoModel',
	];

	/**
		* Relations
		*/
	public function pessoaModel()
	{
		return $this->belongsTo(PessoaModel::class, 'id_pessoa', 'id');
	}

	public function tabelaPrecoModel()
	{
		return $this->belongsTo(TabelaPrecoModel::class, 'id_tabela_preco', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDesdeAttribute()
	{
		return $this->attributes['desde'];
	}

	public function setDesdeAttribute($desde)
	{
		$this->attributes['desde'] = $desde;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getLimiteCreditoAttribute()
	{
		return (double)$this->attributes['limite_credito'];
	}

	public function setLimiteCreditoAttribute($limiteCredito)
	{
		$this->attributes['limite_credito'] = $limiteCredito;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDesdeAttribute($object->desde);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setLimiteCreditoAttribute($object->limiteCredito);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$tabelaPrecoModel = new TabelaPrecoModel();
				$tabelaPrecoModel->mapping($object->tabelaPrecoModel);
				$this->tabelaPrecoModel()->associate($tabelaPrecoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'desde' => $this->getDesdeAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'limiteCredito' => $this->getLimiteCreditoAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'tabelaPrecoModel' => $this->tabelaPrecoModel,
			];
	}
}