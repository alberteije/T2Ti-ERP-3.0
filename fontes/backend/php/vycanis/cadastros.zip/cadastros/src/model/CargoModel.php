<?php
declare(strict_types=1);

class CargoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'cargo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getSalarioAttribute()
	{
		return (double)$this->attributes['salario'];
	}

	public function setSalarioAttribute($salario)
	{
		$this->attributes['salario'] = $salario;
	}

	public function getCbo1994Attribute()
	{
		return $this->attributes['cbo_1994'];
	}

	public function setCbo1994Attribute($cbo1994)
	{
		$this->attributes['cbo_1994'] = $cbo1994;
	}

	public function getCbo2002Attribute()
	{
		return $this->attributes['cbo_2002'];
	}

	public function setCbo2002Attribute($cbo2002)
	{
		$this->attributes['cbo_2002'] = $cbo2002;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setSalarioAttribute($object->salario);
				$this->setCbo1994Attribute($object->cbo1994);
				$this->setCbo2002Attribute($object->cbo2002);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'salario' => $this->getSalarioAttribute(),
				'cbo1994' => $this->getCbo1994Attribute(),
				'cbo2002' => $this->getCbo2002Attribute(),
			];
	}
}