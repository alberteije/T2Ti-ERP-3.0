<?php
declare(strict_types=1);

class ContadorModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contador';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function pessoaModel()
	{
		return $this->belongsTo(PessoaModel::class, 'id_pessoa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCrcInscricaoAttribute()
	{
		return $this->attributes['crc_inscricao'];
	}

	public function setCrcInscricaoAttribute($crcInscricao)
	{
		$this->attributes['crc_inscricao'] = $crcInscricao;
	}

	public function getCrcUfAttribute()
	{
		return $this->attributes['crc_uf'];
	}

	public function setCrcUfAttribute($crcUf)
	{
		$this->attributes['crc_uf'] = $crcUf;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCrcInscricaoAttribute($object->crcInscricao);
				$this->setCrcUfAttribute($object->crcUf);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'crcInscricao' => $this->getCrcInscricaoAttribute(),
				'crcUf' => $this->getCrcUfAttribute(),
			];
	}
}