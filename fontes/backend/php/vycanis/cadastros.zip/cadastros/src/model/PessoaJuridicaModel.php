<?php
declare(strict_types=1);

class PessoaJuridicaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pessoa_juridica';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function pessoaModel()
	{
		return $this->belongsTo(PessoaModel::class, 'id_pessoa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getNomeFantasiaAttribute()
	{
		return $this->attributes['nome_fantasia'];
	}

	public function setNomeFantasiaAttribute($nomeFantasia)
	{
		$this->attributes['nome_fantasia'] = $nomeFantasia;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	public function getInscricaoMunicipalAttribute()
	{
		return $this->attributes['inscricao_municipal'];
	}

	public function setInscricaoMunicipalAttribute($inscricaoMunicipal)
	{
		$this->attributes['inscricao_municipal'] = $inscricaoMunicipal;
	}

	public function getDataConstituicaoAttribute()
	{
		return $this->attributes['data_constituicao'];
	}

	public function setDataConstituicaoAttribute($dataConstituicao)
	{
		$this->attributes['data_constituicao'] = $dataConstituicao;
	}

	public function getTipoRegimeAttribute()
	{
		return $this->attributes['tipo_regime'];
	}

	public function setTipoRegimeAttribute($tipoRegime)
	{
		$this->attributes['tipo_regime'] = $tipoRegime;
	}

	public function getCrtAttribute()
	{
		return $this->attributes['crt'];
	}

	public function setCrtAttribute($crt)
	{
		$this->attributes['crt'] = $crt;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjAttribute($object->cnpj);
				$this->setNomeFantasiaAttribute($object->nomeFantasia);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);
				$this->setInscricaoMunicipalAttribute($object->inscricaoMunicipal);
				$this->setDataConstituicaoAttribute($object->dataConstituicao);
				$this->setTipoRegimeAttribute($object->tipoRegime);
				$this->setCrtAttribute($object->crt);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'nomeFantasia' => $this->getNomeFantasiaAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
				'inscricaoMunicipal' => $this->getInscricaoMunicipalAttribute(),
				'dataConstituicao' => $this->getDataConstituicaoAttribute(),
				'tipoRegime' => $this->getTipoRegimeAttribute(),
				'crt' => $this->getCrtAttribute(),
			];
	}
}