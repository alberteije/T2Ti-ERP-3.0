<?php
declare(strict_types=1);

class UsuarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'usuario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function papelModel()
	{
		return $this->belongsTo(PapelModel::class, 'id_papel', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getLoginAttribute()
	{
		return $this->attributes['login'];
	}

	public function setLoginAttribute($login)
	{
		$this->attributes['login'] = $login;
	}

	public function getSenhaAttribute()
	{
		return $this->attributes['senha'];
	}

	public function setSenhaAttribute($senha)
	{
		$this->attributes['senha'] = $senha;
	}

	public function getAdministradorAttribute()
	{
		return $this->attributes['administrador'];
	}

	public function setAdministradorAttribute($administrador)
	{
		$this->attributes['administrador'] = $administrador;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setLoginAttribute($object->login);
				$this->setSenhaAttribute($object->senha);
				$this->setAdministradorAttribute($object->administrador);
				$this->setDataCadastroAttribute($object->dataCadastro);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'login' => $this->getLoginAttribute(),
				'senha' => $this->getSenhaAttribute(),
				'administrador' => $this->getAdministradorAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
			];
	}
}