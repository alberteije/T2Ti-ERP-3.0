<?php
class CstPisService extends ServiceBase
{
  public function getList()
  {
    return CstPisModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CstPisModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CstPisModel::find($id);
  }

}