<?php

declare(strict_types=1);

class ServiceBase
{

    public function save($object)
    {
        $object->save();
    }

    public function delete($object)
    {
        $object->delete();
    }

}