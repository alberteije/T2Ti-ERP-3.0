<?php
class TipoRelacionamentoService extends ServiceBase
{
  public function getList()
  {
    return TipoRelacionamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TipoRelacionamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return TipoRelacionamentoModel::find($id);
  }

}