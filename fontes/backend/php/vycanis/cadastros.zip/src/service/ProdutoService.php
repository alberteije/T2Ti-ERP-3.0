<?php
class ProdutoService extends ServiceBase
{
  public function getList()
  {
    return ProdutoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ProdutoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ProdutoModel::find($id);
  }

}