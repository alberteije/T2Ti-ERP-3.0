<?php
class EstadoCivilService extends ServiceBase
{
  public function getList()
  {
    return EstadoCivilModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EstadoCivilModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EstadoCivilModel::find($id);
  }

}