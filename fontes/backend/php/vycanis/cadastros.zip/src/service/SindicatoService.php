<?php
class SindicatoService extends ServiceBase
{
  public function getList()
  {
    return SindicatoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SindicatoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SindicatoModel::find($id);
  }

}