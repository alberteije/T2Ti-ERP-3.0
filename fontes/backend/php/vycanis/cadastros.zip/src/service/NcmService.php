<?php
class NcmService extends ServiceBase
{
  public function getList()
  {
    return NcmModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NcmModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NcmModel::find($id);
  }

}