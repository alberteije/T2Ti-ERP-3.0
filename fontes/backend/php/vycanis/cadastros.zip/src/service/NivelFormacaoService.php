<?php
class NivelFormacaoService extends ServiceBase
{
  public function getList()
  {
    return NivelFormacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NivelFormacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NivelFormacaoModel::find($id);
  }

}