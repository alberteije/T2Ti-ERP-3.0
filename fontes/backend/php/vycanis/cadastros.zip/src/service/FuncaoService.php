<?php
use Illuminate\Database\Capsule\Manager as DB;
class FuncaoService extends ServiceBase
{
	public function getList()
	{
		return FuncaoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FuncaoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FuncaoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// papelFuncao
		$papelFuncaoModelListJson = $objJson->papelFuncaoModelList;
		if ($papelFuncaoModelListJson != null) {
			for ($i = 0; $i < count($papelFuncaoModelListJson); $i++) {
				$papelFuncao = new PapelFuncaoModel();
				$papelFuncao->mapping($papelFuncaoModelListJson[$i]);
				$objModel->papelFuncaoModelList()->save($papelFuncao);
			}
		}

	}	

	public function deleteChildren($object)
	{
		PapelFuncaoModel::where('id_funcao', $object->getIdAttribute())->delete();
	}	
 
}