<?php
use Illuminate\Database\Capsule\Manager as DB;
class PapelService extends ServiceBase
{
	public function getList()
	{
		return PapelModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return PapelModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return PapelModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// papelFuncao
		$papelFuncaoModelListJson = $objJson->papelFuncaoModelList;
		if ($papelFuncaoModelListJson != null) {
			for ($i = 0; $i < count($papelFuncaoModelListJson); $i++) {
				$papelFuncao = new PapelFuncaoModel();
				$papelFuncao->mapping($papelFuncaoModelListJson[$i]);
				$objModel->papelFuncaoModelList()->save($papelFuncao);
			}
		}

		// usuario
		$usuarioModelListJson = $objJson->usuarioModelList;
		if ($usuarioModelListJson != null) {
			for ($i = 0; $i < count($usuarioModelListJson); $i++) {
				$usuario = new UsuarioModel();
				$usuario->mapping($usuarioModelListJson[$i]);
				$objModel->usuarioModelList()->save($usuario);
			}
		}

	}	

	public function deleteChildren($object)
	{
		PapelFuncaoModel::where('id_papel', $object->getIdAttribute())->delete();
		UsuarioModel::where('id_papel', $object->getIdAttribute())->delete();
	}	
 
}