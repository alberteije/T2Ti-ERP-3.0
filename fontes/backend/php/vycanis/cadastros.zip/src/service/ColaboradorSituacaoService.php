<?php
class ColaboradorSituacaoService extends ServiceBase
{
  public function getList()
  {
    return ColaboradorSituacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ColaboradorSituacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ColaboradorSituacaoModel::find($id);
  }

}