<?php
class PaisService extends ServiceBase
{
  public function getList()
  {
    return PaisModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PaisModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PaisModel::find($id);
  }

}