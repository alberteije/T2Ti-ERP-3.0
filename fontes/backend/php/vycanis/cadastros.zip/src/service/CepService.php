<?php
class CepService extends ServiceBase
{
  public function getList()
  {
    return CepModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CepModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CepModel::find($id);
  }

}