<?php
class TributGrupoTributarioService extends ServiceBase
{
  public function getList()
  {
    return TributGrupoTributarioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TributGrupoTributarioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return TributGrupoTributarioModel::find($id);
  }

}