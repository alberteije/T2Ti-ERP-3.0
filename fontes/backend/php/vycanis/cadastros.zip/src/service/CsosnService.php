<?php
class CsosnService extends ServiceBase
{
  public function getList()
  {
    return CsosnModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CsosnModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CsosnModel::find($id);
  }

}