<?php
class CstCofinsService extends ServiceBase
{
  public function getList()
  {
    return CstCofinsModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CstCofinsModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CstCofinsModel::find($id);
  }

}