<?php
class TributIcmsCustomCabService extends ServiceBase
{
  public function getList()
  {
    return TributIcmsCustomCabModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TributIcmsCustomCabModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return TributIcmsCustomCabModel::find($id);
  }

}