<?php
class TributGrupoTributarioController extends ControllerBase
{

		private $tributGrupoTributarioService = null;

		public function __construct()
		{	 
				$this->tributGrupoTributarioService = new TributGrupoTributarioService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->tributGrupoTributarioService->getListFilter($filter);
						} else {
								$resultList = $this->tributGrupoTributarioService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList TributGrupoTributario]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->tributGrupoTributarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject TributGrupoTributario]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject TributGrupoTributario]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert TributGrupoTributario]', null);
						}

						$objModel = new TributGrupoTributarioModel();
						$objModel->mapping($objJson);

						$this->tributGrupoTributarioService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert TributGrupoTributario]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->tributGrupoTributarioService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update TributGrupoTributario]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->tributGrupoTributarioService->save($objFromDatabase);
								$objFromDatabase = $this->tributGrupoTributarioService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update TributGrupoTributario]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->tributGrupoTributarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete TributGrupoTributario]', null);
						} else {
								$this->tributGrupoTributarioService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete TributGrupoTributario]', $e);
				}
		}
}
