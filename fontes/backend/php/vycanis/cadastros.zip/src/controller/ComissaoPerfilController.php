<?php
class ComissaoPerfilController extends ControllerBase
{

		private $comissaoPerfilService = null;

		public function __construct()
		{	 
				$this->comissaoPerfilService = new ComissaoPerfilService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->comissaoPerfilService->getListFilter($filter);
						} else {
								$resultList = $this->comissaoPerfilService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList ComissaoPerfil]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->comissaoPerfilService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject ComissaoPerfil]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject ComissaoPerfil]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert ComissaoPerfil]', null);
						}

						$objModel = new ComissaoPerfilModel();
						$objModel->mapping($objJson);

						$this->comissaoPerfilService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert ComissaoPerfil]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->comissaoPerfilService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update ComissaoPerfil]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->comissaoPerfilService->save($objFromDatabase);
								$objFromDatabase = $this->comissaoPerfilService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update ComissaoPerfil]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->comissaoPerfilService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete ComissaoPerfil]', null);
						} else {
								$this->comissaoPerfilService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete ComissaoPerfil]', $e);
				}
		}
}
