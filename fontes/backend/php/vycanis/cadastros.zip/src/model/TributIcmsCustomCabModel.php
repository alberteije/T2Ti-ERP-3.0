<?php
declare(strict_types=1);

class TributIcmsCustomCabModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'tribut_icms_custom_cab';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getOrigemMercadoriaAttribute()
	{
		return $this->attributes['origem_mercadoria'];
	}

	public function setOrigemMercadoriaAttribute($origemMercadoria)
	{
		$this->attributes['origem_mercadoria'] = $origemMercadoria;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setOrigemMercadoriaAttribute($object->origemMercadoria);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'origemMercadoria' => $this->getOrigemMercadoriaAttribute(),
			];
	}
}