<?php
declare(strict_types=1);

class TabelaPrecoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'tabela_preco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getPrincipalAttribute()
	{
		return $this->attributes['principal'];
	}

	public function setPrincipalAttribute($principal)
	{
		$this->attributes['principal'] = $principal;
	}

	public function getCoeficienteAttribute()
	{
		return (double)$this->attributes['coeficiente'];
	}

	public function setCoeficienteAttribute($coeficiente)
	{
		$this->attributes['coeficiente'] = $coeficiente;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setPrincipalAttribute($object->principal);
				$this->setCoeficienteAttribute($object->coeficiente);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'principal' => $this->getPrincipalAttribute(),
				'coeficiente' => $this->getCoeficienteAttribute(),
			];
	}
}