<?php
declare(strict_types=1);

class PessoaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pessoa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pessoaJuridicaModel',
		'fornecedorModel',
		'clienteModel',
		'pessoaFisicaModel',
		'transportadoraModel',
		'contadorModel',
		'pessoaContatoModelList',
		'pessoaTelefoneModelList',
		'pessoaEnderecoModelList',
	];

	/**
		* Relations
		*/
	public function pessoaJuridicaModel()
	{
		return $this->hasOne(PessoaJuridicaModel::class, 'id_pessoa', 'id');
	}

	public function fornecedorModel()
	{
		return $this->hasOne(FornecedorModel::class, 'id_pessoa', 'id');
	}

	public function clienteModel()
	{
		return $this->hasOne(ClienteModel::class, 'id_pessoa', 'id');
	}

	public function pessoaFisicaModel()
	{
		return $this->hasOne(PessoaFisicaModel::class, 'id_pessoa', 'id');
	}

	public function transportadoraModel()
	{
		return $this->hasOne(TransportadoraModel::class, 'id_pessoa', 'id');
	}

	public function contadorModel()
	{
		return $this->hasOne(ContadorModel::class, 'id_pessoa', 'id');
	}

	public function pessoaContatoModelList()
{
	return $this->hasMany(PessoaContatoModel::class, 'id_pessoa', 'id');
}

	public function pessoaTelefoneModelList()
{
	return $this->hasMany(PessoaTelefoneModel::class, 'id_pessoa', 'id');
}

	public function pessoaEnderecoModelList()
{
	return $this->hasMany(PessoaEnderecoModel::class, 'id_pessoa', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getSiteAttribute()
	{
		return $this->attributes['site'];
	}

	public function setSiteAttribute($site)
	{
		$this->attributes['site'] = $site;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getEhClienteAttribute()
	{
		return $this->attributes['eh_cliente'];
	}

	public function setEhClienteAttribute($ehCliente)
	{
		$this->attributes['eh_cliente'] = $ehCliente;
	}

	public function getEhFornecedorAttribute()
	{
		return $this->attributes['eh_fornecedor'];
	}

	public function setEhFornecedorAttribute($ehFornecedor)
	{
		$this->attributes['eh_fornecedor'] = $ehFornecedor;
	}

	public function getEhTransportadoraAttribute()
	{
		return $this->attributes['eh_transportadora'];
	}

	public function setEhTransportadoraAttribute($ehTransportadora)
	{
		$this->attributes['eh_transportadora'] = $ehTransportadora;
	}

	public function getEhColaboradorAttribute()
	{
		return $this->attributes['eh_colaborador'];
	}

	public function setEhColaboradorAttribute($ehColaborador)
	{
		$this->attributes['eh_colaborador'] = $ehColaborador;
	}

	public function getEhContadorAttribute()
	{
		return $this->attributes['eh_contador'];
	}

	public function setEhContadorAttribute($ehContador)
	{
		$this->attributes['eh_contador'] = $ehContador;
	}

	



	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}
	
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setTipoAttribute($object->tipo);
				$this->setSiteAttribute($object->site);
				$this->setEmailAttribute($object->email);
				$this->setEhClienteAttribute($object->ehCliente);
				$this->setEhFornecedorAttribute($object->ehFornecedor);
				$this->setEhTransportadoraAttribute($object->ehTransportadora);
				$this->setEhColaboradorAttribute($object->ehColaborador);
				$this->setEhContadorAttribute($object->ehContador);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'site' => $this->getSiteAttribute(),
				'email' => $this->getEmailAttribute(),
				'ehCliente' => $this->getEhClienteAttribute(),
				'ehFornecedor' => $this->getEhFornecedorAttribute(),
				'ehTransportadora' => $this->getEhTransportadoraAttribute(),
				'ehColaborador' => $this->getEhColaboradorAttribute(),
				'ehContador' => $this->getEhContadorAttribute(),
				
				'numero' => $this->getNumeroAttribute(),
				
				
				'pessoaJuridicaModel' => $this->pessoaJuridicaModel,
				'fornecedorModel' => $this->fornecedorModel,
				'clienteModel' => $this->clienteModel,
				'pessoaFisicaModel' => $this->pessoaFisicaModel,
				'transportadoraModel' => $this->transportadoraModel,
				'contadorModel' => $this->contadorModel,
				'pessoaContatoModelList' => $this->pessoaContatoModelList,
				'pessoaTelefoneModelList' => $this->pessoaTelefoneModelList,
				'pessoaEnderecoModelList' => $this->pessoaEnderecoModelList,
			];
	}
}