<?php

declare(strict_types=1);

class VendedorModel extends EloquentModel implements \JsonSerializable
{
	/**
	 * The table associated with the model.
	 *
	 * @var string
	 */
	protected $table = 'vendedor';

	/**
	 * Eager Loading - Relationships that should always be loaded by default
	 *
	 * @var array
	 */
	protected $with = [
		'comissaoPerfilModel',
		'colaboradorModel',
	];

	/**
	 * Relations
	 */
	public function colaboradorModel()
	{
		return $this->belongsTo(ColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function comissaoPerfilModel()
	{
		return $this->belongsTo(ComissaoPerfilModel::class, 'id_comissao_perfil', 'id');
	}



	/**
	 * Gets e Sets
	 */
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getComissaoAttribute()
	{
		return (float)$this->attributes['comissao'];
	}

	public function setComissaoAttribute($comissao)
	{
		$this->attributes['comissao'] = $comissao;
	}

	public function getMetaVendaAttribute()
	{
		return (float)$this->attributes['meta_venda'];
	}

	public function setMetaVendaAttribute($metaVenda)
	{
		$this->attributes['meta_venda'] = $metaVenda;
	}



	/**
	 * Mapping
	 */
	public function mapping($object)
	{
		if (isset($object)) {
			isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

			$this->setComissaoAttribute($object->comissao);
			$this->setMetaVendaAttribute($object->metaVenda);

			// link objects - lookups
			$comissaoPerfilModel = new ComissaoPerfilModel();
			$comissaoPerfilModel->mapping($object->comissaoPerfilModel);
			$this->comissaoPerfilModel()->associate($comissaoPerfilModel);

			$colaboradorModel = new ColaboradorModel();
			$colaboradorModel->mapping($object->colaboradorModel);
			$this->colaboradorModel()->associate($colaboradorModel);
		}
	}


	/**
	 * Serialization
	 * {@inheritdoc}
	 */
	public function jsonSerialize()
	{
		return [
			'id' => $this->getIdAttribute(),
			'comissao' => $this->getComissaoAttribute(),
			'metaVenda' => $this->getMetaVendaAttribute(),
			'comissaoPerfilModel' => $this->comissaoPerfilModel,
			'colaboradorModel' => $this->colaboradorModel,
		];
	}
}
