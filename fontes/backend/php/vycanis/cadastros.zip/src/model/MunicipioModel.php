<?php
declare(strict_types=1);

class MunicipioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'municipio';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'ufModel',
	];

	/**
		* Relations
		*/
	public function ufModel()
	{
		return $this->belongsTo(UfModel::class, 'id_uf', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getCodigoIbgeAttribute()
	{
		return $this->attributes['codigo_ibge'];
	}

	public function setCodigoIbgeAttribute($codigoIbge)
	{
		$this->attributes['codigo_ibge'] = $codigoIbge;
	}

	public function getCodigoReceitaFederalAttribute()
	{
		return $this->attributes['codigo_receita_federal'];
	}

	public function setCodigoReceitaFederalAttribute($codigoReceitaFederal)
	{
		$this->attributes['codigo_receita_federal'] = $codigoReceitaFederal;
	}

	public function getCodigoEstadualAttribute()
	{
		return $this->attributes['codigo_estadual'];
	}

	public function setCodigoEstadualAttribute($codigoEstadual)
	{
		$this->attributes['codigo_estadual'] = $codigoEstadual;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setCodigoIbgeAttribute($object->codigoIbge);
				$this->setCodigoReceitaFederalAttribute($object->codigoReceitaFederal);
				$this->setCodigoEstadualAttribute($object->codigoEstadual);

				// link objects - lookups
				$ufModel = new UfModel();
				$ufModel->mapping($object->ufModel);
				$this->ufModel()->associate($ufModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'codigoIbge' => $this->getCodigoIbgeAttribute(),
				'codigoReceitaFederal' => $this->getCodigoReceitaFederalAttribute(),
				'codigoEstadual' => $this->getCodigoEstadualAttribute(),
				'ufModel' => $this->ufModel,
			];
	}
}