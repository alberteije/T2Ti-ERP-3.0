<?php
declare(strict_types=1);

class PessoaFisicaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pessoa_fisica';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'estadoCivilModel',
		'nivelFormacaoModel',
	];

	/**
		* Relations
		*/
	public function pessoaModel()
	{
		return $this->belongsTo(PessoaModel::class, 'id_pessoa', 'id');
	}

	public function estadoCivilModel()
	{
		return $this->belongsTo(EstadoCivilModel::class, 'id_estado_civil', 'id');
	}

	public function nivelFormacaoModel()
	{
		return $this->belongsTo(NivelFormacaoModel::class, 'id_nivel_formacao', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getRgAttribute()
	{
		return $this->attributes['rg'];
	}

	public function setRgAttribute($rg)
	{
		$this->attributes['rg'] = $rg;
	}

	public function getOrgaoRgAttribute()
	{
		return $this->attributes['orgao_rg'];
	}

	public function setOrgaoRgAttribute($orgaoRg)
	{
		$this->attributes['orgao_rg'] = $orgaoRg;
	}

	public function getDataEmissaoRgAttribute()
	{
		return $this->attributes['data_emissao_rg'];
	}

	public function setDataEmissaoRgAttribute($dataEmissaoRg)
	{
		$this->attributes['data_emissao_rg'] = $dataEmissaoRg;
	}

	public function getDataNascimentoAttribute()
	{
		return $this->attributes['data_nascimento'];
	}

	public function setDataNascimentoAttribute($dataNascimento)
	{
		$this->attributes['data_nascimento'] = $dataNascimento;
	}

	public function getSexoAttribute()
	{
		return $this->attributes['sexo'];
	}

	public function setSexoAttribute($sexo)
	{
		$this->attributes['sexo'] = $sexo;
	}

	public function getRacaAttribute()
	{
		return $this->attributes['raca'];
	}

	public function setRacaAttribute($raca)
	{
		$this->attributes['raca'] = $raca;
	}

	public function getNacionalidadeAttribute()
	{
		return $this->attributes['nacionalidade'];
	}

	public function setNacionalidadeAttribute($nacionalidade)
	{
		$this->attributes['nacionalidade'] = $nacionalidade;
	}

	public function getNaturalidadeAttribute()
	{
		return $this->attributes['naturalidade'];
	}

	public function setNaturalidadeAttribute($naturalidade)
	{
		$this->attributes['naturalidade'] = $naturalidade;
	}

	public function getNomePaiAttribute()
	{
		return $this->attributes['nome_pai'];
	}

	public function setNomePaiAttribute($nomePai)
	{
		$this->attributes['nome_pai'] = $nomePai;
	}

	public function getNomeMaeAttribute()
	{
		return $this->attributes['nome_mae'];
	}

	public function setNomeMaeAttribute($nomeMae)
	{
		$this->attributes['nome_mae'] = $nomeMae;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCpfAttribute($object->cpf);
				$this->setRgAttribute($object->rg);
				$this->setOrgaoRgAttribute($object->orgaoRg);
				$this->setDataEmissaoRgAttribute($object->dataEmissaoRg);
				$this->setDataNascimentoAttribute($object->dataNascimento);
				$this->setSexoAttribute($object->sexo);
				$this->setRacaAttribute($object->raca);
				$this->setNacionalidadeAttribute($object->nacionalidade);
				$this->setNaturalidadeAttribute($object->naturalidade);
				$this->setNomePaiAttribute($object->nomePai);
				$this->setNomeMaeAttribute($object->nomeMae);

				// link objects - lookups
				$estadoCivilModel = new EstadoCivilModel();
				$estadoCivilModel->mapping($object->estadoCivilModel);
				$this->estadoCivilModel()->associate($estadoCivilModel);
				$nivelFormacaoModel = new NivelFormacaoModel();
				$nivelFormacaoModel->mapping($object->nivelFormacaoModel);
				$this->nivelFormacaoModel()->associate($nivelFormacaoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'rg' => $this->getRgAttribute(),
				'orgaoRg' => $this->getOrgaoRgAttribute(),
				'dataEmissaoRg' => $this->getDataEmissaoRgAttribute(),
				'dataNascimento' => $this->getDataNascimentoAttribute(),
				'sexo' => $this->getSexoAttribute(),
				'raca' => $this->getRacaAttribute(),
				'nacionalidade' => $this->getNacionalidadeAttribute(),
				'naturalidade' => $this->getNaturalidadeAttribute(),
				'nomePai' => $this->getNomePaiAttribute(),
				'nomeMae' => $this->getNomeMaeAttribute(),
				'estadoCivilModel' => $this->estadoCivilModel,
				'nivelFormacaoModel' => $this->nivelFormacaoModel,
			];
	}
}