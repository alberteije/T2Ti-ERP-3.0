<?php
declare(strict_types=1);

class ColaboradorModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'colaborador';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'pessoaModel',
		'colaboradorSituacaoModel',
		'colaboradorTipoModel',
		'setorModel',
		'cargoModel',
		'tipoAdmissaoModel',
		'colaboradorRelacionamentoModelList',
		'sindicatoModel',
	];

	/**
		* Relations
		*/
	public function pessoaModel()
	{
		return $this->belongsTo(PessoaModel::class, 'id_pessoa', 'id');
	}

	public function colaboradorSituacaoModel()
	{
		return $this->belongsTo(ColaboradorSituacaoModel::class, 'id_colaborador_situacao', 'id');
	}

	public function colaboradorTipoModel()
	{
		return $this->belongsTo(ColaboradorTipoModel::class, 'id_colaborador_tipo', 'id');
	}

	public function setorModel()
	{
		return $this->belongsTo(SetorModel::class, 'id_setor', 'id');
	}

	public function cargoModel()
	{
		return $this->belongsTo(CargoModel::class, 'id_cargo', 'id');
	}

	public function tipoAdmissaoModel()
	{
		return $this->belongsTo(TipoAdmissaoModel::class, 'id_tipo_admissao', 'id');
	}

	public function colaboradorRelacionamentoModelList()
{
	return $this->hasMany(ColaboradorRelacionamentoModel::class, 'id_colaborador', 'id');
}

	public function sindicatoModel()
	{
		return $this->belongsTo(SindicatoModel::class, 'id_sindicato', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getMatriculaAttribute()
	{
		return $this->attributes['matricula'];
	}

	public function setMatriculaAttribute($matricula)
	{
		$this->attributes['matricula'] = $matricula;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getDataAdmissaoAttribute()
	{
		return $this->attributes['data_admissao'];
	}

	public function setDataAdmissaoAttribute($dataAdmissao)
	{
		$this->attributes['data_admissao'] = $dataAdmissao;
	}

	public function getDataDemissaoAttribute()
	{
		return $this->attributes['data_demissao'];
	}

	public function setDataDemissaoAttribute($dataDemissao)
	{
		$this->attributes['data_demissao'] = $dataDemissao;
	}

	public function getCtpsNumeroAttribute()
	{
		return $this->attributes['ctps_numero'];
	}

	public function setCtpsNumeroAttribute($ctpsNumero)
	{
		$this->attributes['ctps_numero'] = $ctpsNumero;
	}

	public function getCtpsSerieAttribute()
	{
		return $this->attributes['ctps_serie'];
	}

	public function setCtpsSerieAttribute($ctpsSerie)
	{
		$this->attributes['ctps_serie'] = $ctpsSerie;
	}

	public function getCtpsDataExpedicaoAttribute()
	{
		return $this->attributes['ctps_data_expedicao'];
	}

	public function setCtpsDataExpedicaoAttribute($ctpsDataExpedicao)
	{
		$this->attributes['ctps_data_expedicao'] = $ctpsDataExpedicao;
	}

	public function getCtpsUfAttribute()
	{
		return $this->attributes['ctps_uf'];
	}

	public function setCtpsUfAttribute($ctpsUf)
	{
		$this->attributes['ctps_uf'] = $ctpsUf;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setMatriculaAttribute($object->matricula);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setDataAdmissaoAttribute($object->dataAdmissao);
				$this->setDataDemissaoAttribute($object->dataDemissao);
				$this->setCtpsNumeroAttribute($object->ctpsNumero);
				$this->setCtpsSerieAttribute($object->ctpsSerie);
				$this->setCtpsDataExpedicaoAttribute($object->ctpsDataExpedicao);
				$this->setCtpsUfAttribute($object->ctpsUf);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$pessoaModel = new PessoaModel();
				$pessoaModel->mapping($object->pessoaModel);
				$this->pessoaModel()->associate($pessoaModel);
				$colaboradorSituacaoModel = new ColaboradorSituacaoModel();
				$colaboradorSituacaoModel->mapping($object->colaboradorSituacaoModel);
				$this->colaboradorSituacaoModel()->associate($colaboradorSituacaoModel);
				$colaboradorTipoModel = new ColaboradorTipoModel();
				$colaboradorTipoModel->mapping($object->colaboradorTipoModel);
				$this->colaboradorTipoModel()->associate($colaboradorTipoModel);
				$setorModel = new SetorModel();
				$setorModel->mapping($object->setorModel);
				$this->setorModel()->associate($setorModel);
				$cargoModel = new CargoModel();
				$cargoModel->mapping($object->cargoModel);
				$this->cargoModel()->associate($cargoModel);
				$tipoAdmissaoModel = new TipoAdmissaoModel();
				$tipoAdmissaoModel->mapping($object->tipoAdmissaoModel);
				$this->tipoAdmissaoModel()->associate($tipoAdmissaoModel);
				$sindicatoModel = new SindicatoModel();
				$sindicatoModel->mapping($object->sindicatoModel);
				$this->sindicatoModel()->associate($sindicatoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'matricula' => $this->getMatriculaAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'dataAdmissao' => $this->getDataAdmissaoAttribute(),
				'dataDemissao' => $this->getDataDemissaoAttribute(),
				'ctpsNumero' => $this->getCtpsNumeroAttribute(),
				'ctpsSerie' => $this->getCtpsSerieAttribute(),
				'ctpsDataExpedicao' => $this->getCtpsDataExpedicaoAttribute(),
				'ctpsUf' => $this->getCtpsUfAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'pessoaModel' => $this->pessoaModel,
				'colaboradorSituacaoModel' => $this->colaboradorSituacaoModel,
				'colaboradorTipoModel' => $this->colaboradorTipoModel,
				'setorModel' => $this->setorModel,
				'cargoModel' => $this->cargoModel,
				'tipoAdmissaoModel' => $this->tipoAdmissaoModel,
				'colaboradorRelacionamentoModelList' => $this->colaboradorRelacionamentoModelList,
				'sindicatoModel' => $this->sindicatoModel,
			];
	}
}