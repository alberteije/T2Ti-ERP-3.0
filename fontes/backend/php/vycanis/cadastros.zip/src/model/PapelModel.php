<?php
declare(strict_types=1);

class PapelModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'papel';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'papelFuncaoModelList',
		'usuarioModelList',
	];

	/**
		* Relations
		*/
	public function papelFuncaoModelList()
{
	return $this->hasMany(PapelFuncaoModel::class, 'id_papel', 'id');
}

	public function usuarioModelList()
{
	return $this->hasMany(UsuarioModel::class, 'id_papel', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaAttribute()
	{
		return $this->attributes['descrica'];
	}

	public function setDescricaAttribute($descrica)
	{
		$this->attributes['descrica'] = $descrica;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDescricaAttribute($object->descrica);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descrica' => $this->getDescricaAttribute(),
				'papelFuncaoModelList' => $this->papelFuncaoModelList,
				'usuarioModelList' => $this->usuarioModelList,
			];
	}
}