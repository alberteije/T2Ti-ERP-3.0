<?php
declare(strict_types=1);

class SindicatoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'sindicato';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getCodigoBancoAttribute()
	{
		return $this->attributes['codigo_banco'];
	}

	public function setCodigoBancoAttribute($codigoBanco)
	{
		$this->attributes['codigo_banco'] = $codigoBanco;
	}

	public function getCodigoAgenciaAttribute()
	{
		return $this->attributes['codigo_agencia'];
	}

	public function setCodigoAgenciaAttribute($codigoAgencia)
	{
		$this->attributes['codigo_agencia'] = $codigoAgencia;
	}

	public function getContaBancoAttribute()
	{
		return $this->attributes['conta_banco'];
	}

	public function setContaBancoAttribute($contaBanco)
	{
		$this->attributes['conta_banco'] = $contaBanco;
	}

	public function getCodigoCedenteAttribute()
	{
		return $this->attributes['codigo_cedente'];
	}

	public function setCodigoCedenteAttribute($codigoCedente)
	{
		$this->attributes['codigo_cedente'] = $codigoCedente;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getMunicipioIbgeAttribute()
	{
		return $this->attributes['municipio_ibge'];
	}

	public function setMunicipioIbgeAttribute($municipioIbge)
	{
		$this->attributes['municipio_ibge'] = $municipioIbge;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getFone1Attribute()
	{
		return $this->attributes['fone1'];
	}

	public function setFone1Attribute($fone1)
	{
		$this->attributes['fone1'] = $fone1;
	}

	public function getFone2Attribute()
	{
		return $this->attributes['fone2'];
	}

	public function setFone2Attribute($fone2)
	{
		$this->attributes['fone2'] = $fone2;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getTipoSindicatoAttribute()
	{
		return $this->attributes['tipo_sindicato'];
	}

	public function setTipoSindicatoAttribute($tipoSindicato)
	{
		$this->attributes['tipo_sindicato'] = $tipoSindicato;
	}

	public function getDataBaseAttribute()
	{
		return $this->attributes['data_base'];
	}

	public function setDataBaseAttribute($dataBase)
	{
		$this->attributes['data_base'] = $dataBase;
	}

	public function getPisoSalarialAttribute()
	{
		return (double)$this->attributes['piso_salarial'];
	}

	public function setPisoSalarialAttribute($pisoSalarial)
	{
		$this->attributes['piso_salarial'] = $pisoSalarial;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getClassificacaoContabilContaAttribute()
	{
		return $this->attributes['classificacao_contabil_conta'];
	}

	public function setClassificacaoContabilContaAttribute($classificacaoContabilConta)
	{
		$this->attributes['classificacao_contabil_conta'] = $classificacaoContabilConta;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setCodigoBancoAttribute($object->codigoBanco);
				$this->setCodigoAgenciaAttribute($object->codigoAgencia);
				$this->setContaBancoAttribute($object->contaBanco);
				$this->setCodigoCedenteAttribute($object->codigoCedente);
				$this->setLogradouroAttribute($object->logradouro);
				$this->setNumeroAttribute($object->numero);
				$this->setBairroAttribute($object->bairro);
				$this->setMunicipioIbgeAttribute($object->municipioIbge);
				$this->setUfAttribute($object->uf);
				$this->setFone1Attribute($object->fone1);
				$this->setFone2Attribute($object->fone2);
				$this->setEmailAttribute($object->email);
				$this->setTipoSindicatoAttribute($object->tipoSindicato);
				$this->setDataBaseAttribute($object->dataBase);
				$this->setPisoSalarialAttribute($object->pisoSalarial);
				$this->setCnpjAttribute($object->cnpj);
				$this->setClassificacaoContabilContaAttribute($object->classificacaoContabilConta);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'codigoBanco' => $this->getCodigoBancoAttribute(),
				'codigoAgencia' => $this->getCodigoAgenciaAttribute(),
				'contaBanco' => $this->getContaBancoAttribute(),
				'codigoCedente' => $this->getCodigoCedenteAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'municipioIbge' => $this->getMunicipioIbgeAttribute(),
				'uf' => $this->getUfAttribute(),
				'fone1' => $this->getFone1Attribute(),
				'fone2' => $this->getFone2Attribute(),
				'email' => $this->getEmailAttribute(),
				'tipoSindicato' => $this->getTipoSindicatoAttribute(),
				'dataBase' => $this->getDataBaseAttribute(),
				'pisoSalarial' => $this->getPisoSalarialAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'classificacaoContabilConta' => $this->getClassificacaoContabilContaAttribute(),
			];
	}
}