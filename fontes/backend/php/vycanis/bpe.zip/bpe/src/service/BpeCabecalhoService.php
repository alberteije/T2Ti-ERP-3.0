<?php
use Illuminate\Database\Capsule\Manager as DB;
class BpeCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return BpeCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return BpeCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return BpeCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// bpeEmitente
		$bpeEmitenteModelListJson = $objJson->bpeEmitenteModelList;
		if ($bpeEmitenteModelListJson != null) {
			for ($i = 0; $i < count($bpeEmitenteModelListJson); $i++) {
				$bpeEmitente = new BpeEmitenteModel();
				$bpeEmitente->mapping($bpeEmitenteModelListJson[$i]);
				$objModel->bpeEmitenteModelList()->save($bpeEmitente);
			}
		}

		// bpePassageiro
		$bpePassageiroModelListJson = $objJson->bpePassageiroModelList;
		if ($bpePassageiroModelListJson != null) {
			for ($i = 0; $i < count($bpePassageiroModelListJson); $i++) {
				$bpePassageiro = new BpePassageiroModel();
				$bpePassageiro->mapping($bpePassageiroModelListJson[$i]);
				$objModel->bpePassageiroModelList()->save($bpePassageiro);
			}
		}

		// bpeComprador
		$bpeCompradorModelListJson = $objJson->bpeCompradorModelList;
		if ($bpeCompradorModelListJson != null) {
			for ($i = 0; $i < count($bpeCompradorModelListJson); $i++) {
				$bpeComprador = new BpeCompradorModel();
				$bpeComprador->mapping($bpeCompradorModelListJson[$i]);
				$objModel->bpeCompradorModelList()->save($bpeComprador);
			}
		}

		// bpeViagem
		$bpeViagemModelListJson = $objJson->bpeViagemModelList;
		if ($bpeViagemModelListJson != null) {
			for ($i = 0; $i < count($bpeViagemModelListJson); $i++) {
				$bpeViagem = new BpeViagemModel();
				$bpeViagem->mapping($bpeViagemModelListJson[$i]);
				$objModel->bpeViagemModelList()->save($bpeViagem);
			}
		}

		// bpeAgencia
		$bpeAgenciaModelListJson = $objJson->bpeAgenciaModelList;
		if ($bpeAgenciaModelListJson != null) {
			for ($i = 0; $i < count($bpeAgenciaModelListJson); $i++) {
				$bpeAgencia = new BpeAgenciaModel();
				$bpeAgencia->mapping($bpeAgenciaModelListJson[$i]);
				$objModel->bpeAgenciaModelList()->save($bpeAgencia);
			}
		}

		// bpePassagem
		$bpePassagemModelListJson = $objJson->bpePassagemModelList;
		if ($bpePassagemModelListJson != null) {
			for ($i = 0; $i < count($bpePassagemModelListJson); $i++) {
				$bpePassagem = new BpePassagemModel();
				$bpePassagem->mapping($bpePassagemModelListJson[$i]);
				$objModel->bpePassagemModelList()->save($bpePassagem);
			}
		}

	}	

	public function deleteChildren($object)
	{
		BpeEmitenteModel::where('id_bpe_cabecalho', $object->getIdAttribute())->delete();
		BpePassageiroModel::where('id_bpe_cabecalho', $object->getIdAttribute())->delete();
		BpeCompradorModel::where('id_bpe_cabecalho', $object->getIdAttribute())->delete();
		BpeViagemModel::where('id_bpe_cabecalho', $object->getIdAttribute())->delete();
		BpeAgenciaModel::where('id_bpe_cabecalho', $object->getIdAttribute())->delete();
		BpePassagemModel::where('id_bpe_cabecalho', $object->getIdAttribute())->delete();
	}	

	public function TransmitirBpe(BpeCabecalhoModel $pBpeCabecalho)
	{
		// TODO: Chame a API da T2Ti ou use o ACBRMonitor como já ensinado na NF-e
		$retorno = "";
		return $retorno;
	}

}