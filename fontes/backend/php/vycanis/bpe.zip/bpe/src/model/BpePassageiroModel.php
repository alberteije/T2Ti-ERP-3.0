<?php
declare(strict_types=1);

class BpePassageiroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'bpe_passageiro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function bpeCabecalhoModel()
	{
		return $this->belongsTo(BpeCabecalhoModel::class, 'id_bpe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getTipoDocumentoIdentificacaoAttribute()
	{
		return $this->attributes['tipo_documento_identificacao'];
	}

	public function setTipoDocumentoIdentificacaoAttribute($tipoDocumentoIdentificacao)
	{
		$this->attributes['tipo_documento_identificacao'] = $tipoDocumentoIdentificacao;
	}

	public function getNumeroDocumentoAttribute()
	{
		return $this->attributes['numero_documento'];
	}

	public function setNumeroDocumentoAttribute($numeroDocumento)
	{
		$this->attributes['numero_documento'] = $numeroDocumento;
	}

	public function getDocumentoOutrosDescricaoAttribute()
	{
		return $this->attributes['documento_outros_descricao'];
	}

	public function setDocumentoOutrosDescricaoAttribute($documentoOutrosDescricao)
	{
		$this->attributes['documento_outros_descricao'] = $documentoOutrosDescricao;
	}

	public function getDataNascimentoAttribute()
	{
		return $this->attributes['data_nascimento'];
	}

	public function setDataNascimentoAttribute($dataNascimento)
	{
		$this->attributes['data_nascimento'] = $dataNascimento;
	}

	public function getTelefoneAttribute()
	{
		return $this->attributes['telefone'];
	}

	public function setTelefoneAttribute($telefone)
	{
		$this->attributes['telefone'] = $telefone;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setCpfAttribute($object->cpf);
				$this->setTipoDocumentoIdentificacaoAttribute($object->tipoDocumentoIdentificacao);
				$this->setNumeroDocumentoAttribute($object->numeroDocumento);
				$this->setDocumentoOutrosDescricaoAttribute($object->documentoOutrosDescricao);
				$this->setDataNascimentoAttribute($object->dataNascimento);
				$this->setTelefoneAttribute($object->telefone);
				$this->setEmailAttribute($object->email);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'tipoDocumentoIdentificacao' => $this->getTipoDocumentoIdentificacaoAttribute(),
				'numeroDocumento' => $this->getNumeroDocumentoAttribute(),
				'documentoOutrosDescricao' => $this->getDocumentoOutrosDescricaoAttribute(),
				'dataNascimento' => $this->getDataNascimentoAttribute(),
				'telefone' => $this->getTelefoneAttribute(),
				'email' => $this->getEmailAttribute(),
			];
	}
}