<?php
declare(strict_types=1);

class BpeCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'bpe_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'bpeEmitenteModelList',
		'bpePassageiroModelList',
		'bpeCompradorModelList',
		'bpeViagemModelList',
		'bpeAgenciaModelList',
		'bpePassagemModelList',
	];

	/**
		* Relations
		*/
	public function bpeEmitenteModelList()
{
	return $this->hasMany(BpeEmitenteModel::class, 'id_bpe_cabecalho', 'id');
}

	public function bpePassageiroModelList()
{
	return $this->hasMany(BpePassageiroModel::class, 'id_bpe_cabecalho', 'id');
}

	public function bpeCompradorModelList()
{
	return $this->hasMany(BpeCompradorModel::class, 'id_bpe_cabecalho', 'id');
}

	public function bpeViagemModelList()
{
	return $this->hasMany(BpeViagemModel::class, 'id_bpe_cabecalho', 'id');
}

	public function bpeAgenciaModelList()
{
	return $this->hasMany(BpeAgenciaModel::class, 'id_bpe_cabecalho', 'id');
}

	public function bpePassagemModelList()
{
	return $this->hasMany(BpePassagemModel::class, 'id_bpe_cabecalho', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getUfEmitenteAttribute()
	{
		return $this->attributes['uf_emitente'];
	}

	public function setUfEmitenteAttribute($ufEmitente)
	{
		$this->attributes['uf_emitente'] = $ufEmitente;
	}

	public function getAmbienteAttribute()
	{
		return $this->attributes['ambiente'];
	}

	public function setAmbienteAttribute($ambiente)
	{
		$this->attributes['ambiente'] = $ambiente;
	}

	public function getModeloAttribute()
	{
		return $this->attributes['modelo'];
	}

	public function setModeloAttribute($modelo)
	{
		$this->attributes['modelo'] = $modelo;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getCodigoNumericoAttribute()
	{
		return $this->attributes['codigo_numerico'];
	}

	public function setCodigoNumericoAttribute($codigoNumerico)
	{
		$this->attributes['codigo_numerico'] = $codigoNumerico;
	}

	public function getChaveAcessoAttribute()
	{
		return $this->attributes['chave_acesso'];
	}

	public function setChaveAcessoAttribute($chaveAcesso)
	{
		$this->attributes['chave_acesso'] = $chaveAcesso;
	}

	public function getDigitoChaveAcessoAttribute()
	{
		return $this->attributes['digito_chave_acesso'];
	}

	public function setDigitoChaveAcessoAttribute($digitoChaveAcesso)
	{
		$this->attributes['digito_chave_acesso'] = $digitoChaveAcesso;
	}

	public function getModalAttribute()
	{
		return $this->attributes['modal'];
	}

	public function setModalAttribute($modal)
	{
		$this->attributes['modal'] = $modal;
	}

	public function getDataHoraEmissaoAttribute()
	{
		return $this->attributes['data_hora_emissao'];
	}

	public function setDataHoraEmissaoAttribute($dataHoraEmissao)
	{
		$this->attributes['data_hora_emissao'] = $dataHoraEmissao;
	}

	public function getTipoEmissaoAttribute()
	{
		return $this->attributes['tipo_emissao'];
	}

	public function setTipoEmissaoAttribute($tipoEmissao)
	{
		$this->attributes['tipo_emissao'] = $tipoEmissao;
	}

	public function getVersaoProcessoEmissaoAttribute()
	{
		return $this->attributes['versao_processo_emissao'];
	}

	public function setVersaoProcessoEmissaoAttribute($versaoProcessoEmissao)
	{
		$this->attributes['versao_processo_emissao'] = $versaoProcessoEmissao;
	}

	public function getTipoBpeAttribute()
	{
		return $this->attributes['tipo_bpe'];
	}

	public function setTipoBpeAttribute($tipoBpe)
	{
		$this->attributes['tipo_bpe'] = $tipoBpe;
	}

	public function getConsumidorPresencaAttribute()
	{
		return $this->attributes['consumidor_presenca'];
	}

	public function setConsumidorPresencaAttribute($consumidorPresenca)
	{
		$this->attributes['consumidor_presenca'] = $consumidorPresenca;
	}

	public function getUfInicioViagemAttribute()
	{
		return $this->attributes['uf_inicio_viagem'];
	}

	public function setUfInicioViagemAttribute($ufInicioViagem)
	{
		$this->attributes['uf_inicio_viagem'] = $ufInicioViagem;
	}

	public function getCodigoMunicipioInicioViagemAttribute()
	{
		return $this->attributes['codigo_municipio_inicio_viagem'];
	}

	public function setCodigoMunicipioInicioViagemAttribute($codigoMunicipioInicioViagem)
	{
		$this->attributes['codigo_municipio_inicio_viagem'] = $codigoMunicipioInicioViagem;
	}

	public function getUfFimViagemAttribute()
	{
		return $this->attributes['uf_fim_viagem'];
	}

	public function setUfFimViagemAttribute($ufFimViagem)
	{
		$this->attributes['uf_fim_viagem'] = $ufFimViagem;
	}

	public function getCodigoMunicipioFimViagemAttribute()
	{
		return $this->attributes['codigo_municipio_fim_viagem'];
	}

	public function setCodigoMunicipioFimViagemAttribute($codigoMunicipioFimViagem)
	{
		$this->attributes['codigo_municipio_fim_viagem'] = $codigoMunicipioFimViagem;
	}

	public function getValorBilheteAttribute()
	{
		return (double)$this->attributes['valor_bilhete'];
	}

	public function setValorBilheteAttribute($valorBilhete)
	{
		$this->attributes['valor_bilhete'] = $valorBilhete;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorPagoAttribute()
	{
		return (double)$this->attributes['valor_pago'];
	}

	public function setValorPagoAttribute($valorPago)
	{
		$this->attributes['valor_pago'] = $valorPago;
	}

	public function getValorTrocoAttribute()
	{
		return (double)$this->attributes['valor_troco'];
	}

	public function setValorTrocoAttribute($valorTroco)
	{
		$this->attributes['valor_troco'] = $valorTroco;
	}

	public function getTipoDescontoAttribute()
	{
		return $this->attributes['tipo_desconto'];
	}

	public function setTipoDescontoAttribute($tipoDesconto)
	{
		$this->attributes['tipo_desconto'] = $tipoDesconto;
	}

	public function getDescontoDescricaoAttribute()
	{
		return $this->attributes['desconto_descricao'];
	}

	public function setDescontoDescricaoAttribute($descontoDescricao)
	{
		$this->attributes['desconto_descricao'] = $descontoDescricao;
	}

	public function getDescontoConcedidoOutrosAttribute()
	{
		return $this->attributes['desconto_concedido_outros'];
	}

	public function setDescontoConcedidoOutrosAttribute($descontoConcedidoOutros)
	{
		$this->attributes['desconto_concedido_outros'] = $descontoConcedidoOutros;
	}

	public function getFormaPagamentoAttribute()
	{
		return $this->attributes['forma_pagamento'];
	}

	public function setFormaPagamentoAttribute($formaPagamento)
	{
		$this->attributes['forma_pagamento'] = $formaPagamento;
	}

	public function getFormaPagamentoOutrosAttribute()
	{
		return $this->attributes['forma_pagamento_outros'];
	}

	public function setFormaPagamentoOutrosAttribute($formaPagamentoOutros)
	{
		$this->attributes['forma_pagamento_outros'] = $formaPagamentoOutros;
	}

	public function getFormaPagamentoDocumentoAttribute()
	{
		return $this->attributes['forma_pagamento_documento'];
	}

	public function setFormaPagamentoDocumentoAttribute($formaPagamentoDocumento)
	{
		$this->attributes['forma_pagamento_documento'] = $formaPagamentoDocumento;
	}

	public function getCstAttribute()
	{
		return $this->attributes['cst'];
	}

	public function setCstAttribute($cst)
	{
		$this->attributes['cst'] = $cst;
	}

	public function getBaseCalculoIcmsAttribute()
	{
		return (double)$this->attributes['base_calculo_icms'];
	}

	public function setBaseCalculoIcmsAttribute($baseCalculoIcms)
	{
		$this->attributes['base_calculo_icms'] = $baseCalculoIcms;
	}

	public function getAliquotaIcmsAttribute()
	{
		return (double)$this->attributes['aliquota_icms'];
	}

	public function setAliquotaIcmsAttribute($aliquotaIcms)
	{
		$this->attributes['aliquota_icms'] = $aliquotaIcms;
	}

	public function getValorIcmsAttribute()
	{
		return (double)$this->attributes['valor_icms'];
	}

	public function setValorIcmsAttribute($valorIcms)
	{
		$this->attributes['valor_icms'] = $valorIcms;
	}

	public function getPercentualReducaoBcIcmsAttribute()
	{
		return (double)$this->attributes['percentual_reducao_bc_icms'];
	}

	public function setPercentualReducaoBcIcmsAttribute($percentualReducaoBcIcms)
	{
		$this->attributes['percentual_reducao_bc_icms'] = $percentualReducaoBcIcms;
	}

	public function getInformacoesAddFiscoAttribute()
	{
		return $this->attributes['informacoes_add_fisco'];
	}

	public function setInformacoesAddFiscoAttribute($informacoesAddFisco)
	{
		$this->attributes['informacoes_add_fisco'] = $informacoesAddFisco;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setUfEmitenteAttribute($object->ufEmitente);
				$this->setAmbienteAttribute($object->ambiente);
				$this->setModeloAttribute($object->modelo);
				$this->setSerieAttribute($object->serie);
				$this->setNumeroAttribute($object->numero);
				$this->setCodigoNumericoAttribute($object->codigoNumerico);
				$this->setChaveAcessoAttribute($object->chaveAcesso);
				$this->setDigitoChaveAcessoAttribute($object->digitoChaveAcesso);
				$this->setModalAttribute($object->modal);
				$this->setDataHoraEmissaoAttribute($object->dataHoraEmissao);
				$this->setTipoEmissaoAttribute($object->tipoEmissao);
				$this->setVersaoProcessoEmissaoAttribute($object->versaoProcessoEmissao);
				$this->setTipoBpeAttribute($object->tipoBpe);
				$this->setConsumidorPresencaAttribute($object->consumidorPresenca);
				$this->setUfInicioViagemAttribute($object->ufInicioViagem);
				$this->setCodigoMunicipioInicioViagemAttribute($object->codigoMunicipioInicioViagem);
				$this->setUfFimViagemAttribute($object->ufFimViagem);
				$this->setCodigoMunicipioFimViagemAttribute($object->codigoMunicipioFimViagem);
				$this->setValorBilheteAttribute($object->valorBilhete);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorPagoAttribute($object->valorPago);
				$this->setValorTrocoAttribute($object->valorTroco);
				$this->setTipoDescontoAttribute($object->tipoDesconto);
				$this->setDescontoDescricaoAttribute($object->descontoDescricao);
				$this->setDescontoConcedidoOutrosAttribute($object->descontoConcedidoOutros);
				$this->setFormaPagamentoAttribute($object->formaPagamento);
				$this->setFormaPagamentoOutrosAttribute($object->formaPagamentoOutros);
				$this->setFormaPagamentoDocumentoAttribute($object->formaPagamentoDocumento);
				$this->setCstAttribute($object->cst);
				$this->setBaseCalculoIcmsAttribute($object->baseCalculoIcms);
				$this->setAliquotaIcmsAttribute($object->aliquotaIcms);
				$this->setValorIcmsAttribute($object->valorIcms);
				$this->setPercentualReducaoBcIcmsAttribute($object->percentualReducaoBcIcms);
				$this->setInformacoesAddFiscoAttribute($object->informacoesAddFisco);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ufEmitente' => $this->getUfEmitenteAttribute(),
				'ambiente' => $this->getAmbienteAttribute(),
				'modelo' => $this->getModeloAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'codigoNumerico' => $this->getCodigoNumericoAttribute(),
				'chaveAcesso' => $this->getChaveAcessoAttribute(),
				'digitoChaveAcesso' => $this->getDigitoChaveAcessoAttribute(),
				'modal' => $this->getModalAttribute(),
				'dataHoraEmissao' => $this->getDataHoraEmissaoAttribute(),
				'tipoEmissao' => $this->getTipoEmissaoAttribute(),
				'versaoProcessoEmissao' => $this->getVersaoProcessoEmissaoAttribute(),
				'tipoBpe' => $this->getTipoBpeAttribute(),
				'consumidorPresenca' => $this->getConsumidorPresencaAttribute(),
				'ufInicioViagem' => $this->getUfInicioViagemAttribute(),
				'codigoMunicipioInicioViagem' => $this->getCodigoMunicipioInicioViagemAttribute(),
				'ufFimViagem' => $this->getUfFimViagemAttribute(),
				'codigoMunicipioFimViagem' => $this->getCodigoMunicipioFimViagemAttribute(),
				'valorBilhete' => $this->getValorBilheteAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorPago' => $this->getValorPagoAttribute(),
				'valorTroco' => $this->getValorTrocoAttribute(),
				'tipoDesconto' => $this->getTipoDescontoAttribute(),
				'descontoDescricao' => $this->getDescontoDescricaoAttribute(),
				'descontoConcedidoOutros' => $this->getDescontoConcedidoOutrosAttribute(),
				'formaPagamento' => $this->getFormaPagamentoAttribute(),
				'formaPagamentoOutros' => $this->getFormaPagamentoOutrosAttribute(),
				'formaPagamentoDocumento' => $this->getFormaPagamentoDocumentoAttribute(),
				'cst' => $this->getCstAttribute(),
				'baseCalculoIcms' => $this->getBaseCalculoIcmsAttribute(),
				'aliquotaIcms' => $this->getAliquotaIcmsAttribute(),
				'valorIcms' => $this->getValorIcmsAttribute(),
				'percentualReducaoBcIcms' => $this->getPercentualReducaoBcIcmsAttribute(),
				'informacoesAddFisco' => $this->getInformacoesAddFiscoAttribute(),
				'bpeEmitenteModelList' => $this->bpeEmitenteModelList,
				'bpePassageiroModelList' => $this->bpePassageiroModelList,
				'bpeCompradorModelList' => $this->bpeCompradorModelList,
				'bpeViagemModelList' => $this->bpeViagemModelList,
				'bpeAgenciaModelList' => $this->bpeAgenciaModelList,
				'bpePassagemModelList' => $this->bpePassagemModelList,
			];
	}
}