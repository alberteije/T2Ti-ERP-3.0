<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'BpeEmitenteModel.php';
include 'BpePassageiroModel.php';
include 'BpeCompradorModel.php';
include 'BpeViagemModel.php';
include 'BpeAgenciaModel.php';
include 'BpePassagemModel.php';
include 'BpeCabecalhoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';