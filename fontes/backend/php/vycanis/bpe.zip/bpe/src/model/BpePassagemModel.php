<?php
declare(strict_types=1);

class BpePassagemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'bpe_passagem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function bpeCabecalhoModel()
	{
		return $this->belongsTo(BpeCabecalhoModel::class, 'id_bpe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoLocalidadeOrigemAttribute()
	{
		return $this->attributes['codigo_localidade_origem'];
	}

	public function setCodigoLocalidadeOrigemAttribute($codigoLocalidadeOrigem)
	{
		$this->attributes['codigo_localidade_origem'] = $codigoLocalidadeOrigem;
	}

	public function getDescricaoLocalidadeOrigemAttribute()
	{
		return $this->attributes['descricao_localidade_origem'];
	}

	public function setDescricaoLocalidadeOrigemAttribute($descricaoLocalidadeOrigem)
	{
		$this->attributes['descricao_localidade_origem'] = $descricaoLocalidadeOrigem;
	}

	public function getCodigoLocalidadeDestinoAttribute()
	{
		return $this->attributes['codigo_localidade_destino'];
	}

	public function setCodigoLocalidadeDestinoAttribute($codigoLocalidadeDestino)
	{
		$this->attributes['codigo_localidade_destino'] = $codigoLocalidadeDestino;
	}

	public function getDescricaoLocalidadeDestinoAttribute()
	{
		return $this->attributes['descricao_localidade_destino'];
	}

	public function setDescricaoLocalidadeDestinoAttribute($descricaoLocalidadeDestino)
	{
		$this->attributes['descricao_localidade_destino'] = $descricaoLocalidadeDestino;
	}

	public function getDataHoraEmbarqueAttribute()
	{
		return $this->attributes['data_hora_embarque'];
	}

	public function setDataHoraEmbarqueAttribute($dataHoraEmbarque)
	{
		$this->attributes['data_hora_embarque'] = $dataHoraEmbarque;
	}

	public function getDataHoraValidadeAttribute()
	{
		return $this->attributes['data_hora_validade'];
	}

	public function setDataHoraValidadeAttribute($dataHoraValidade)
	{
		$this->attributes['data_hora_validade'] = $dataHoraValidade;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoLocalidadeOrigemAttribute($object->codigoLocalidadeOrigem);
				$this->setDescricaoLocalidadeOrigemAttribute($object->descricaoLocalidadeOrigem);
				$this->setCodigoLocalidadeDestinoAttribute($object->codigoLocalidadeDestino);
				$this->setDescricaoLocalidadeDestinoAttribute($object->descricaoLocalidadeDestino);
				$this->setDataHoraEmbarqueAttribute($object->dataHoraEmbarque);
				$this->setDataHoraValidadeAttribute($object->dataHoraValidade);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoLocalidadeOrigem' => $this->getCodigoLocalidadeOrigemAttribute(),
				'descricaoLocalidadeOrigem' => $this->getDescricaoLocalidadeOrigemAttribute(),
				'codigoLocalidadeDestino' => $this->getCodigoLocalidadeDestinoAttribute(),
				'descricaoLocalidadeDestino' => $this->getDescricaoLocalidadeDestinoAttribute(),
				'dataHoraEmbarque' => $this->getDataHoraEmbarqueAttribute(),
				'dataHoraValidade' => $this->getDataHoraValidadeAttribute(),
			];
	}
}