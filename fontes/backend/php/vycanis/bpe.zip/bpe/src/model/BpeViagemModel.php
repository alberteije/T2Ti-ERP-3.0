<?php
declare(strict_types=1);

class BpeViagemModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'bpe_viagem';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function bpeCabecalhoModel()
	{
		return $this->belongsTo(BpeCabecalhoModel::class, 'id_bpe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoPercursoAttribute()
	{
		return $this->attributes['codigo_percurso'];
	}

	public function setCodigoPercursoAttribute($codigoPercurso)
	{
		$this->attributes['codigo_percurso'] = $codigoPercurso;
	}

	public function getDescricaoPercursoAttribute()
	{
		return $this->attributes['descricao_percurso'];
	}

	public function setDescricaoPercursoAttribute($descricaoPercurso)
	{
		$this->attributes['descricao_percurso'] = $descricaoPercurso;
	}

	public function getTipoViagemAttribute()
	{
		return $this->attributes['tipo_viagem'];
	}

	public function setTipoViagemAttribute($tipoViagem)
	{
		$this->attributes['tipo_viagem'] = $tipoViagem;
	}

	public function getTipoServicoAttribute()
	{
		return $this->attributes['tipo_servico'];
	}

	public function setTipoServicoAttribute($tipoServico)
	{
		$this->attributes['tipo_servico'] = $tipoServico;
	}

	public function getTipoAcomodacaoAttribute()
	{
		return $this->attributes['tipo_acomodacao'];
	}

	public function setTipoAcomodacaoAttribute($tipoAcomodacao)
	{
		$this->attributes['tipo_acomodacao'] = $tipoAcomodacao;
	}

	public function getTipoTrechoAttribute()
	{
		return $this->attributes['tipo_trecho'];
	}

	public function setTipoTrechoAttribute($tipoTrecho)
	{
		$this->attributes['tipo_trecho'] = $tipoTrecho;
	}

	public function getDataHoraViagemAttribute()
	{
		return $this->attributes['data_hora_viagem'];
	}

	public function setDataHoraViagemAttribute($dataHoraViagem)
	{
		$this->attributes['data_hora_viagem'] = $dataHoraViagem;
	}

	public function getDataHoraConexaoAttribute()
	{
		return $this->attributes['data_hora_conexao'];
	}

	public function setDataHoraConexaoAttribute($dataHoraConexao)
	{
		$this->attributes['data_hora_conexao'] = $dataHoraConexao;
	}

	public function getPrefixoLinhaAttribute()
	{
		return $this->attributes['prefixo_linha'];
	}

	public function setPrefixoLinhaAttribute($prefixoLinha)
	{
		$this->attributes['prefixo_linha'] = $prefixoLinha;
	}

	public function getPoltronaAttribute()
	{
		return $this->attributes['poltrona'];
	}

	public function setPoltronaAttribute($poltrona)
	{
		$this->attributes['poltrona'] = $poltrona;
	}

	public function getPlataformaAttribute()
	{
		return $this->attributes['plataforma'];
	}

	public function setPlataformaAttribute($plataforma)
	{
		$this->attributes['plataforma'] = $plataforma;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoPercursoAttribute($object->codigoPercurso);
				$this->setDescricaoPercursoAttribute($object->descricaoPercurso);
				$this->setTipoViagemAttribute($object->tipoViagem);
				$this->setTipoServicoAttribute($object->tipoServico);
				$this->setTipoAcomodacaoAttribute($object->tipoAcomodacao);
				$this->setTipoTrechoAttribute($object->tipoTrecho);
				$this->setDataHoraViagemAttribute($object->dataHoraViagem);
				$this->setDataHoraConexaoAttribute($object->dataHoraConexao);
				$this->setPrefixoLinhaAttribute($object->prefixoLinha);
				$this->setPoltronaAttribute($object->poltrona);
				$this->setPlataformaAttribute($object->plataforma);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoPercurso' => $this->getCodigoPercursoAttribute(),
				'descricaoPercurso' => $this->getDescricaoPercursoAttribute(),
				'tipoViagem' => $this->getTipoViagemAttribute(),
				'tipoServico' => $this->getTipoServicoAttribute(),
				'tipoAcomodacao' => $this->getTipoAcomodacaoAttribute(),
				'tipoTrecho' => $this->getTipoTrechoAttribute(),
				'dataHoraViagem' => $this->getDataHoraViagemAttribute(),
				'dataHoraConexao' => $this->getDataHoraConexaoAttribute(),
				'prefixoLinha' => $this->getPrefixoLinhaAttribute(),
				'poltrona' => $this->getPoltronaAttribute(),
				'plataforma' => $this->getPlataformaAttribute(),
			];
	}
}