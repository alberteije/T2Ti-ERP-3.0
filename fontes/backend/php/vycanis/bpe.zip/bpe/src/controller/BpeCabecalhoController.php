<?php
use Slim\Psr7\Stream;
class BpeCabecalhoController extends ControllerBase
{

		private $bpeCabecalhoService = null;

		public function __construct()
		{	 
				$this->bpeCabecalhoService = new BpeCabecalhoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->bpeCabecalhoService->getListFilter($filter);
						} else {
								$resultList = $this->bpeCabecalhoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList BpeCabecalho]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->bpeCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject BpeCabecalho]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject BpeCabecalho]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert BpeCabecalho]', null);
						}

						$objModel = new BpeCabecalhoModel();
						$objModel->mapping($objJson);

						$this->bpeCabecalhoService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert BpeCabecalho]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->bpeCabecalhoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update BpeCabecalho]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->bpeCabecalhoService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->bpeCabecalhoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update BpeCabecalho]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->bpeCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete BpeCabecalho]', null);
						} else {
								$this->bpeCabecalhoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete BpeCabecalho]', $e);
				}
		}

	public function transmitirBpe($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			$objFromDatabase = $this->bpeCabecalhoService->getObject($objJson->id);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [transmitirBpe]', null);
			}

			$retorno = $this->bpeCabecalhoService->transmitirBpe($objFromDatabase);
			// $retorno = "";

			if (!str_contains($retorno, "ERRO")) {
				// $fh = fopen($retorno, 'rb');
				$fh = fopen("C:\\T2Ti\\Bpe\\DaBPe.pdf", 'rb');
				$stream = new Stream($fh);
				return parent::resultFile($response, $stream, 'application/pdf');
			} else {
				return parent::handleError($response, 418, $retorno, null);
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Erro no Servidor [Transmitir NFS-e]', $e);
		}
	}

}
