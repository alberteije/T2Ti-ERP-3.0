<?php
class EstoqueGradeService extends ServiceBase
{
  public function getList()
  {
    return EstoqueGradeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EstoqueGradeModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EstoqueGradeModel::find($id);
  }

}