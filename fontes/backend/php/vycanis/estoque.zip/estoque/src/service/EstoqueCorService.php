<?php
class EstoqueCorService extends ServiceBase
{
  public function getList()
  {
    return EstoqueCorModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EstoqueCorModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EstoqueCorModel::find($id);
  }

}