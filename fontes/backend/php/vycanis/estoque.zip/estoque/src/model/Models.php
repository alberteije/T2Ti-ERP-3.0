<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'RequisicaoInternaDetalheModel.php';
include 'EstoqueReajusteDetalheModel.php';
include 'RequisicaoInternaCabecalhoModel.php';
include 'EstoqueReajusteCabecalhoModel.php';
include 'ProdutoGrupoModel.php';
include 'ProdutoSubgrupoModel.php';
include 'ProdutoMarcaModel.php';
include 'ProdutoUnidadeModel.php';
include 'ProdutoModel.php';
include 'EstoqueCorModel.php';
include 'EstoqueTamanhoModel.php';
include 'EstoqueSaborModel.php';
include 'EstoqueMarcaModel.php';
include 'EstoqueGradeModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';