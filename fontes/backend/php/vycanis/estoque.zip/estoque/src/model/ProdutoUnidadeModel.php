<?php
declare(strict_types=1);

class ProdutoUnidadeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'produto_unidade';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getSiglaAttribute()
	{
		return $this->attributes['sigla'];
	}

	public function setSiglaAttribute($sigla)
	{
		$this->attributes['sigla'] = $sigla;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getPodeFracionarAttribute()
	{
		return $this->attributes['pode_fracionar'];
	}

	public function setPodeFracionarAttribute($podeFracionar)
	{
		$this->attributes['pode_fracionar'] = $podeFracionar;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setSiglaAttribute($object->sigla);
				$this->setDescricaoAttribute($object->descricao);
				$this->setPodeFracionarAttribute($object->podeFracionar);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'sigla' => $this->getSiglaAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'podeFracionar' => $this->getPodeFracionarAttribute(),
			];
	}
}