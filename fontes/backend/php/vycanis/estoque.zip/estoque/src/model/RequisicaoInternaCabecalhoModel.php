<?php
declare(strict_types=1);

class RequisicaoInternaCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'requisicao_interna_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'requisicaoInternaDetalheModelList',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function requisicaoInternaDetalheModelList()
{
	return $this->hasMany(RequisicaoInternaDetalheModel::class, 'id_requisicao_interna_cabecalho', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataRequisicaoAttribute()
	{
		return $this->attributes['data_requisicao'];
	}

	public function setDataRequisicaoAttribute($dataRequisicao)
	{
		$this->attributes['data_requisicao'] = $dataRequisicao;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataRequisicaoAttribute($object->dataRequisicao);
				$this->setSituacaoAttribute($object->situacao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataRequisicao' => $this->getDataRequisicaoAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'requisicaoInternaDetalheModelList' => $this->requisicaoInternaDetalheModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}