<?php
declare(strict_types=1);

class EstoqueReajusteCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'estoque_reajuste_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'estoqueReajusteDetalheModelList',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function estoqueReajusteDetalheModelList()
{
	return $this->hasMany(EstoqueReajusteDetalheModel::class, 'id_estoque_reajuste_cabecalho', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataReajusteAttribute()
	{
		return $this->attributes['data_reajuste'];
	}

	public function setDataReajusteAttribute($dataReajuste)
	{
		$this->attributes['data_reajuste'] = $dataReajuste;
	}

	public function getTaxaAttribute()
	{
		return (double)$this->attributes['taxa'];
	}

	public function setTaxaAttribute($taxa)
	{
		$this->attributes['taxa'] = $taxa;
	}

	public function getTipoReajusteAttribute()
	{
		return $this->attributes['tipo_reajuste'];
	}

	public function setTipoReajusteAttribute($tipoReajuste)
	{
		$this->attributes['tipo_reajuste'] = $tipoReajuste;
	}

	public function getJustificativaAttribute()
	{
		return $this->attributes['justificativa'];
	}

	public function setJustificativaAttribute($justificativa)
	{
		$this->attributes['justificativa'] = $justificativa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataReajusteAttribute($object->dataReajuste);
				$this->setTaxaAttribute($object->taxa);
				$this->setTipoReajusteAttribute($object->tipoReajuste);
				$this->setJustificativaAttribute($object->justificativa);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataReajuste' => $this->getDataReajusteAttribute(),
				'taxa' => $this->getTaxaAttribute(),
				'tipoReajuste' => $this->getTipoReajusteAttribute(),
				'justificativa' => $this->getJustificativaAttribute(),
				'estoqueReajusteDetalheModelList' => $this->estoqueReajusteDetalheModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}