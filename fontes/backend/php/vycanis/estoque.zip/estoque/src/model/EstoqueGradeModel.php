<?php
declare(strict_types=1);

class EstoqueGradeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'estoque_grade';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'produtoModel',
		'estoqueCorModel',
		'estoqueTamanhoModel',
		'estoqueSaborModel',
		'estoqueMarcaModel',
	];

	/**
		* Relations
		*/
	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}

	public function estoqueCorModel()
	{
		return $this->belongsTo(EstoqueCorModel::class, 'id_estoque_cor', 'id');
	}

	public function estoqueTamanhoModel()
	{
		return $this->belongsTo(EstoqueTamanhoModel::class, 'id_estoque_tamanho', 'id');
	}

	public function estoqueSaborModel()
	{
		return $this->belongsTo(EstoqueSaborModel::class, 'id_estoque_sabor', 'id');
	}

	public function estoqueMarcaModel()
	{
		return $this->belongsTo(EstoqueMarcaModel::class, 'id_estoque_marca', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getQuantidadeAttribute()
	{
		return (double)$this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setQuantidadeAttribute($object->quantidade);

				// link objects - lookups
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
				$estoqueCorModel = new EstoqueCorModel();
				$estoqueCorModel->mapping($object->estoqueCorModel);
				$this->estoqueCorModel()->associate($estoqueCorModel);
				$estoqueTamanhoModel = new EstoqueTamanhoModel();
				$estoqueTamanhoModel->mapping($object->estoqueTamanhoModel);
				$this->estoqueTamanhoModel()->associate($estoqueTamanhoModel);
				$estoqueSaborModel = new EstoqueSaborModel();
				$estoqueSaborModel->mapping($object->estoqueSaborModel);
				$this->estoqueSaborModel()->associate($estoqueSaborModel);
				$estoqueMarcaModel = new EstoqueMarcaModel();
				$estoqueMarcaModel->mapping($object->estoqueMarcaModel);
				$this->estoqueMarcaModel()->associate($estoqueMarcaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'produtoModel' => $this->produtoModel,
				'estoqueCorModel' => $this->estoqueCorModel,
				'estoqueTamanhoModel' => $this->estoqueTamanhoModel,
				'estoqueSaborModel' => $this->estoqueSaborModel,
				'estoqueMarcaModel' => $this->estoqueMarcaModel,
			];
	}
}