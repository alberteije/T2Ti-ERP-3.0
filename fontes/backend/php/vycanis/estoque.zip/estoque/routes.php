<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// requisicao-interna-cabecalho
$app->get('/requisicao-interna-cabecalho[/]', \RequisicaoInternaCabecalhoController::class . RESULT_LIST);
$app->get('/requisicao-interna-cabecalho/{id}', \RequisicaoInternaCabecalhoController::class . RESULT_OBJECT);
$app->post('/requisicao-interna-cabecalho', \RequisicaoInternaCabecalhoController::class . INSERT);
$app->put('/requisicao-interna-cabecalho', \RequisicaoInternaCabecalhoController::class . UPDATE);
$app->delete('/requisicao-interna-cabecalho/{id}', \RequisicaoInternaCabecalhoController::class . DELETE);
$app->options('/requisicao-interna-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/requisicao-interna-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/requisicao-interna-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estoque-reajuste-cabecalho
$app->get('/estoque-reajuste-cabecalho[/]', \EstoqueReajusteCabecalhoController::class . RESULT_LIST);
$app->get('/estoque-reajuste-cabecalho/{id}', \EstoqueReajusteCabecalhoController::class . RESULT_OBJECT);
$app->post('/estoque-reajuste-cabecalho', \EstoqueReajusteCabecalhoController::class . INSERT);
$app->put('/estoque-reajuste-cabecalho', \EstoqueReajusteCabecalhoController::class . UPDATE);
$app->delete('/estoque-reajuste-cabecalho/{id}', \EstoqueReajusteCabecalhoController::class . DELETE);
$app->options('/estoque-reajuste-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-reajuste-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-reajuste-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-grupo
$app->get('/produto-grupo[/]', \ProdutoGrupoController::class . RESULT_LIST);
$app->get('/produto-grupo/{id}', \ProdutoGrupoController::class . RESULT_OBJECT);
$app->post('/produto-grupo', \ProdutoGrupoController::class . INSERT);
$app->put('/produto-grupo', \ProdutoGrupoController::class . UPDATE);
$app->delete('/produto-grupo/{id}', \ProdutoGrupoController::class . DELETE);
$app->options('/produto-grupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-subgrupo
$app->get('/produto-subgrupo[/]', \ProdutoSubgrupoController::class . RESULT_LIST);
$app->get('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . RESULT_OBJECT);
$app->post('/produto-subgrupo', \ProdutoSubgrupoController::class . INSERT);
$app->put('/produto-subgrupo', \ProdutoSubgrupoController::class . UPDATE);
$app->delete('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . DELETE);
$app->options('/produto-subgrupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-marca
$app->get('/produto-marca[/]', \ProdutoMarcaController::class . RESULT_LIST);
$app->get('/produto-marca/{id}', \ProdutoMarcaController::class . RESULT_OBJECT);
$app->post('/produto-marca', \ProdutoMarcaController::class . INSERT);
$app->put('/produto-marca', \ProdutoMarcaController::class . UPDATE);
$app->delete('/produto-marca/{id}', \ProdutoMarcaController::class . DELETE);
$app->options('/produto-marca', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-unidade
$app->get('/produto-unidade[/]', \ProdutoUnidadeController::class . RESULT_LIST);
$app->get('/produto-unidade/{id}', \ProdutoUnidadeController::class . RESULT_OBJECT);
$app->post('/produto-unidade', \ProdutoUnidadeController::class . INSERT);
$app->put('/produto-unidade', \ProdutoUnidadeController::class . UPDATE);
$app->delete('/produto-unidade/{id}', \ProdutoUnidadeController::class . DELETE);
$app->options('/produto-unidade', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto
$app->get('/produto[/]', \ProdutoController::class . RESULT_LIST);
$app->get('/produto/{id}', \ProdutoController::class . RESULT_OBJECT);
$app->post('/produto', \ProdutoController::class . INSERT);
$app->put('/produto', \ProdutoController::class . UPDATE);
$app->delete('/produto/{id}', \ProdutoController::class . DELETE);
$app->options('/produto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estoque-cor
$app->get('/estoque-cor[/]', \EstoqueCorController::class . RESULT_LIST);
$app->get('/estoque-cor/{id}', \EstoqueCorController::class . RESULT_OBJECT);
$app->post('/estoque-cor', \EstoqueCorController::class . INSERT);
$app->put('/estoque-cor', \EstoqueCorController::class . UPDATE);
$app->delete('/estoque-cor/{id}', \EstoqueCorController::class . DELETE);
$app->options('/estoque-cor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-cor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-cor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estoque-tamanho
$app->get('/estoque-tamanho[/]', \EstoqueTamanhoController::class . RESULT_LIST);
$app->get('/estoque-tamanho/{id}', \EstoqueTamanhoController::class . RESULT_OBJECT);
$app->post('/estoque-tamanho', \EstoqueTamanhoController::class . INSERT);
$app->put('/estoque-tamanho', \EstoqueTamanhoController::class . UPDATE);
$app->delete('/estoque-tamanho/{id}', \EstoqueTamanhoController::class . DELETE);
$app->options('/estoque-tamanho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-tamanho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-tamanho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estoque-sabor
$app->get('/estoque-sabor[/]', \EstoqueSaborController::class . RESULT_LIST);
$app->get('/estoque-sabor/{id}', \EstoqueSaborController::class . RESULT_OBJECT);
$app->post('/estoque-sabor', \EstoqueSaborController::class . INSERT);
$app->put('/estoque-sabor', \EstoqueSaborController::class . UPDATE);
$app->delete('/estoque-sabor/{id}', \EstoqueSaborController::class . DELETE);
$app->options('/estoque-sabor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-sabor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-sabor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estoque-marca
$app->get('/estoque-marca[/]', \EstoqueMarcaController::class . RESULT_LIST);
$app->get('/estoque-marca/{id}', \EstoqueMarcaController::class . RESULT_OBJECT);
$app->post('/estoque-marca', \EstoqueMarcaController::class . INSERT);
$app->put('/estoque-marca', \EstoqueMarcaController::class . UPDATE);
$app->delete('/estoque-marca/{id}', \EstoqueMarcaController::class . DELETE);
$app->options('/estoque-marca', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-marca/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-marca/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estoque-grade
$app->get('/estoque-grade[/]', \EstoqueGradeController::class . RESULT_LIST);
$app->get('/estoque-grade/{id}', \EstoqueGradeController::class . RESULT_OBJECT);
$app->post('/estoque-grade', \EstoqueGradeController::class . INSERT);
$app->put('/estoque-grade', \EstoqueGradeController::class . UPDATE);
$app->delete('/estoque-grade/{id}', \EstoqueGradeController::class . DELETE);
$app->options('/estoque-grade', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-grade/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estoque-grade/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

