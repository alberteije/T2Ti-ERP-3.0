<?php
class EstoqueMarcaService extends ServiceBase
{
  public function getList()
  {
    return EstoqueMarcaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EstoqueMarcaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EstoqueMarcaModel::find($id);
  }

}