<?php
class EstoqueTamanhoService extends ServiceBase
{
  public function getList()
  {
    return EstoqueTamanhoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EstoqueTamanhoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EstoqueTamanhoModel::find($id);
  }

}