<?php
class EstoqueSaborService extends ServiceBase
{
  public function getList()
  {
    return EstoqueSaborModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EstoqueSaborModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EstoqueSaborModel::find($id);
  }

}