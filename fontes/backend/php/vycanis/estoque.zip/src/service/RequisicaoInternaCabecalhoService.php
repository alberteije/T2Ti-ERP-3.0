<?php
use Illuminate\Database\Capsule\Manager as DB;
class RequisicaoInternaCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return RequisicaoInternaCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return RequisicaoInternaCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return RequisicaoInternaCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// requisicaoInternaDetalhe
		$requisicaoInternaDetalheModelListJson = $objJson->requisicaoInternaDetalheModelList;
		if ($requisicaoInternaDetalheModelListJson != null) {
			for ($i = 0; $i < count($requisicaoInternaDetalheModelListJson); $i++) {
				$requisicaoInternaDetalhe = new RequisicaoInternaDetalheModel();
				$requisicaoInternaDetalhe->mapping($requisicaoInternaDetalheModelListJson[$i]);
				$objModel->requisicaoInternaDetalheModelList()->save($requisicaoInternaDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		RequisicaoInternaDetalheModel::where('id_requisicao_interna_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}