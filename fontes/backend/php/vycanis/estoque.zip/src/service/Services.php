<?php

include 'ServiceBase.php';

include 'RequisicaoInternaCabecalhoService.php';
include 'EstoqueReajusteCabecalhoService.php';
include 'ProdutoGrupoService.php';
include 'ProdutoSubgrupoService.php';
include 'ProdutoMarcaService.php';
include 'ProdutoUnidadeService.php';
include 'ProdutoService.php';
include 'EstoqueCorService.php';
include 'EstoqueTamanhoService.php';
include 'EstoqueSaborService.php';
include 'EstoqueMarcaService.php';
include 'EstoqueGradeService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';