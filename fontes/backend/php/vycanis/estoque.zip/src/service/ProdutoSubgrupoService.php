<?php
class ProdutoSubgrupoService extends ServiceBase
{
  public function getList()
  {
    return ProdutoSubgrupoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ProdutoSubgrupoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ProdutoSubgrupoModel::find($id);
  }

}