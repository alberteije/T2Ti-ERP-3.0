<?php
use Illuminate\Database\Capsule\Manager as DB;
class EstoqueReajusteCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return EstoqueReajusteCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return EstoqueReajusteCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return EstoqueReajusteCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// estoqueReajusteDetalhe
		$estoqueReajusteDetalheModelListJson = $objJson->estoqueReajusteDetalheModelList;
		if ($estoqueReajusteDetalheModelListJson != null) {
			for ($i = 0; $i < count($estoqueReajusteDetalheModelListJson); $i++) {
				$estoqueReajusteDetalhe = new EstoqueReajusteDetalheModel();
				$estoqueReajusteDetalhe->mapping($estoqueReajusteDetalheModelListJson[$i]);
				$objModel->estoqueReajusteDetalheModelList()->save($estoqueReajusteDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		EstoqueReajusteDetalheModel::where('id_estoque_reajuste_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}