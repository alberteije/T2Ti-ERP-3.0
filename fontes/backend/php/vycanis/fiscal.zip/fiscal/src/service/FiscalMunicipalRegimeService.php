<?php
class FiscalMunicipalRegimeService extends ServiceBase
{
  public function getList()
  {
    return FiscalMunicipalRegimeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FiscalMunicipalRegimeModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FiscalMunicipalRegimeModel::find($id);
  }

}