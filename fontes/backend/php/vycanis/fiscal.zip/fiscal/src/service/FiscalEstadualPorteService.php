<?php
class FiscalEstadualPorteService extends ServiceBase
{
  public function getList()
  {
    return FiscalEstadualPorteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FiscalEstadualPorteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FiscalEstadualPorteModel::find($id);
  }

}