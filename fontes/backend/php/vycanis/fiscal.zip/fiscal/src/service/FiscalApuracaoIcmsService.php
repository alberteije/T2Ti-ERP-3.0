<?php
class FiscalApuracaoIcmsService extends ServiceBase
{
  public function getList()
  {
    return FiscalApuracaoIcmsModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FiscalApuracaoIcmsModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FiscalApuracaoIcmsModel::find($id);
  }

}