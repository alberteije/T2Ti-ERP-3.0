<?php
use Illuminate\Database\Capsule\Manager as DB;
class FiscalLivroService extends ServiceBase
{
	public function getList()
	{
		return FiscalLivroModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FiscalLivroModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FiscalLivroModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// fiscalTermo
		$fiscalTermoModelListJson = $objJson->fiscalTermoModelList;
		if ($fiscalTermoModelListJson != null) {
			for ($i = 0; $i < count($fiscalTermoModelListJson); $i++) {
				$fiscalTermo = new FiscalTermoModel();
				$fiscalTermo->mapping($fiscalTermoModelListJson[$i]);
				$objModel->fiscalTermoModelList()->save($fiscalTermo);
			}
		}

	}	

	public function deleteChildren($object)
	{
		FiscalTermoModel::where('id_fiscal_livro', $object->getIdAttribute())->delete();
	}	
 
}