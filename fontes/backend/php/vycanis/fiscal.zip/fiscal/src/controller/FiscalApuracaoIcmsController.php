<?php
class FiscalApuracaoIcmsController extends ControllerBase
{

		private $fiscalApuracaoIcmsService = null;

		public function __construct()
		{	 
				$this->fiscalApuracaoIcmsService = new FiscalApuracaoIcmsService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->fiscalApuracaoIcmsService->getListFilter($filter);
						} else {
								$resultList = $this->fiscalApuracaoIcmsService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList FiscalApuracaoIcms]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->fiscalApuracaoIcmsService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject FiscalApuracaoIcms]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject FiscalApuracaoIcms]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert FiscalApuracaoIcms]', null);
						}

						$objModel = new FiscalApuracaoIcmsModel();
						$objModel->mapping($objJson);

						$this->fiscalApuracaoIcmsService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert FiscalApuracaoIcms]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->fiscalApuracaoIcmsService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update FiscalApuracaoIcms]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->fiscalApuracaoIcmsService->save($objFromDatabase);
								$objFromDatabase = $this->fiscalApuracaoIcmsService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update FiscalApuracaoIcms]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->fiscalApuracaoIcmsService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete FiscalApuracaoIcms]', null);
						} else {
								$this->fiscalApuracaoIcmsService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete FiscalApuracaoIcms]', $e);
				}
		}
}
