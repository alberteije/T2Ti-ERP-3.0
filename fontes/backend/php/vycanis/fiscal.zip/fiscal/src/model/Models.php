<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'FiscalTermoModel.php';
include 'FiscalInscricoesSubstitutasModel.php';
include 'SimplesNacionalDetalheModel.php';
include 'FiscalParametroModel.php';
include 'FiscalLivroModel.php';
include 'SimplesNacionalCabecalhoModel.php';
include 'NfeCabecalhoModel.php';
include 'FiscalMunicipalRegimeModel.php';
include 'FiscalEstadualRegimeModel.php';
include 'FiscalEstadualPorteModel.php';
include 'FiscalNotaFiscalEntradaModel.php';
include 'FiscalApuracaoIcmsModel.php';
include 'FiscalNotaFiscalSaidaModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';