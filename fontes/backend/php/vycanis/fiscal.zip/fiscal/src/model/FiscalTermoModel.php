<?php
declare(strict_types=1);

class FiscalTermoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fiscal_termo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function fiscalLivroModel()
	{
		return $this->belongsTo(FiscalLivroModel::class, 'id_fiscal_livro', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getAberturaEncerramentoAttribute()
	{
		return $this->attributes['abertura_encerramento'];
	}

	public function setAberturaEncerramentoAttribute($aberturaEncerramento)
	{
		$this->attributes['abertura_encerramento'] = $aberturaEncerramento;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getPaginaInicialAttribute()
	{
		return $this->attributes['pagina_inicial'];
	}

	public function setPaginaInicialAttribute($paginaInicial)
	{
		$this->attributes['pagina_inicial'] = $paginaInicial;
	}

	public function getPaginaFinalAttribute()
	{
		return $this->attributes['pagina_final'];
	}

	public function setPaginaFinalAttribute($paginaFinal)
	{
		$this->attributes['pagina_final'] = $paginaFinal;
	}

	public function getNumeroRegistroAttribute()
	{
		return $this->attributes['numero_registro'];
	}

	public function setNumeroRegistroAttribute($numeroRegistro)
	{
		$this->attributes['numero_registro'] = $numeroRegistro;
	}

	public function getRegistradoAttribute()
	{
		return $this->attributes['registrado'];
	}

	public function setRegistradoAttribute($registrado)
	{
		$this->attributes['registrado'] = $registrado;
	}

	public function getDataDespachoAttribute()
	{
		return $this->attributes['data_despacho'];
	}

	public function setDataDespachoAttribute($dataDespacho)
	{
		$this->attributes['data_despacho'] = $dataDespacho;
	}

	public function getDataAberturaAttribute()
	{
		return $this->attributes['data_abertura'];
	}

	public function setDataAberturaAttribute($dataAbertura)
	{
		$this->attributes['data_abertura'] = $dataAbertura;
	}

	public function getDataEncerramentoAttribute()
	{
		return $this->attributes['data_encerramento'];
	}

	public function setDataEncerramentoAttribute($dataEncerramento)
	{
		$this->attributes['data_encerramento'] = $dataEncerramento;
	}

	public function getEscrituracaoInicioAttribute()
	{
		return $this->attributes['escrituracao_inicio'];
	}

	public function setEscrituracaoInicioAttribute($escrituracaoInicio)
	{
		$this->attributes['escrituracao_inicio'] = $escrituracaoInicio;
	}

	public function getEscrituracaoFimAttribute()
	{
		return $this->attributes['escrituracao_fim'];
	}

	public function setEscrituracaoFimAttribute($escrituracaoFim)
	{
		$this->attributes['escrituracao_fim'] = $escrituracaoFim;
	}

	public function getTextoAttribute()
	{
		return $this->attributes['texto'];
	}

	public function setTextoAttribute($texto)
	{
		$this->attributes['texto'] = $texto;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setAberturaEncerramentoAttribute($object->aberturaEncerramento);
				$this->setNumeroAttribute($object->numero);
				$this->setPaginaInicialAttribute($object->paginaInicial);
				$this->setPaginaFinalAttribute($object->paginaFinal);
				$this->setNumeroRegistroAttribute($object->numeroRegistro);
				$this->setRegistradoAttribute($object->registrado);
				$this->setDataDespachoAttribute($object->dataDespacho);
				$this->setDataAberturaAttribute($object->dataAbertura);
				$this->setDataEncerramentoAttribute($object->dataEncerramento);
				$this->setEscrituracaoInicioAttribute($object->escrituracaoInicio);
				$this->setEscrituracaoFimAttribute($object->escrituracaoFim);
				$this->setTextoAttribute($object->texto);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'aberturaEncerramento' => $this->getAberturaEncerramentoAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'paginaInicial' => $this->getPaginaInicialAttribute(),
				'paginaFinal' => $this->getPaginaFinalAttribute(),
				'numeroRegistro' => $this->getNumeroRegistroAttribute(),
				'registrado' => $this->getRegistradoAttribute(),
				'dataDespacho' => $this->getDataDespachoAttribute(),
				'dataAbertura' => $this->getDataAberturaAttribute(),
				'dataEncerramento' => $this->getDataEncerramentoAttribute(),
				'escrituracaoInicio' => $this->getEscrituracaoInicioAttribute(),
				'escrituracaoFim' => $this->getEscrituracaoFimAttribute(),
				'texto' => $this->getTextoAttribute(),
			];
	}
}