<?php
declare(strict_types=1);

class SimplesNacionalDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'simples_nacional_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function simplesNacionalCabecalhoModel()
	{
		return $this->belongsTo(SimplesNacionalCabecalhoModel::class, 'id_simples_nacional_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getFaixaAttribute()
	{
		return $this->attributes['faixa'];
	}

	public function setFaixaAttribute($faixa)
	{
		$this->attributes['faixa'] = $faixa;
	}

	public function getValorInicialAttribute()
	{
		return (double)$this->attributes['valor_inicial'];
	}

	public function setValorInicialAttribute($valorInicial)
	{
		$this->attributes['valor_inicial'] = $valorInicial;
	}

	public function getValorFinalAttribute()
	{
		return (double)$this->attributes['valor_final'];
	}

	public function setValorFinalAttribute($valorFinal)
	{
		$this->attributes['valor_final'] = $valorFinal;
	}

	public function getAliquotaAttribute()
	{
		return (double)$this->attributes['aliquota'];
	}

	public function setAliquotaAttribute($aliquota)
	{
		$this->attributes['aliquota'] = $aliquota;
	}

	public function getIrpjAttribute()
	{
		return (double)$this->attributes['irpj'];
	}

	public function setIrpjAttribute($irpj)
	{
		$this->attributes['irpj'] = $irpj;
	}

	public function getCsllAttribute()
	{
		return (double)$this->attributes['csll'];
	}

	public function setCsllAttribute($csll)
	{
		$this->attributes['csll'] = $csll;
	}

	public function getCofinsAttribute()
	{
		return (double)$this->attributes['cofins'];
	}

	public function setCofinsAttribute($cofins)
	{
		$this->attributes['cofins'] = $cofins;
	}

	public function getPisPasepAttribute()
	{
		return (double)$this->attributes['pis_pasep'];
	}

	public function setPisPasepAttribute($pisPasep)
	{
		$this->attributes['pis_pasep'] = $pisPasep;
	}

	public function getCppAttribute()
	{
		return (double)$this->attributes['cpp'];
	}

	public function setCppAttribute($cpp)
	{
		$this->attributes['cpp'] = $cpp;
	}

	public function getIcmsAttribute()
	{
		return (double)$this->attributes['icms'];
	}

	public function setIcmsAttribute($icms)
	{
		$this->attributes['icms'] = $icms;
	}

	public function getIpiAttribute()
	{
		return (double)$this->attributes['ipi'];
	}

	public function setIpiAttribute($ipi)
	{
		$this->attributes['ipi'] = $ipi;
	}

	public function getIssAttribute()
	{
		return (double)$this->attributes['iss'];
	}

	public function setIssAttribute($iss)
	{
		$this->attributes['iss'] = $iss;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setFaixaAttribute($object->faixa);
				$this->setValorInicialAttribute($object->valorInicial);
				$this->setValorFinalAttribute($object->valorFinal);
				$this->setAliquotaAttribute($object->aliquota);
				$this->setIrpjAttribute($object->irpj);
				$this->setCsllAttribute($object->csll);
				$this->setCofinsAttribute($object->cofins);
				$this->setPisPasepAttribute($object->pisPasep);
				$this->setCppAttribute($object->cpp);
				$this->setIcmsAttribute($object->icms);
				$this->setIpiAttribute($object->ipi);
				$this->setIssAttribute($object->iss);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'faixa' => $this->getFaixaAttribute(),
				'valorInicial' => $this->getValorInicialAttribute(),
				'valorFinal' => $this->getValorFinalAttribute(),
				'aliquota' => $this->getAliquotaAttribute(),
				'irpj' => $this->getIrpjAttribute(),
				'csll' => $this->getCsllAttribute(),
				'cofins' => $this->getCofinsAttribute(),
				'pisPasep' => $this->getPisPasepAttribute(),
				'cpp' => $this->getCppAttribute(),
				'icms' => $this->getIcmsAttribute(),
				'ipi' => $this->getIpiAttribute(),
				'iss' => $this->getIssAttribute(),
			];
	}
}