<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// fiscal-parametro
$app->get('/fiscal-parametro[/]', \FiscalParametroController::class . RESULT_LIST);
$app->get('/fiscal-parametro/{id}', \FiscalParametroController::class . RESULT_OBJECT);
$app->post('/fiscal-parametro', \FiscalParametroController::class . INSERT);
$app->put('/fiscal-parametro', \FiscalParametroController::class . UPDATE);
$app->delete('/fiscal-parametro/{id}', \FiscalParametroController::class . DELETE);
$app->options('/fiscal-parametro', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-parametro/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-parametro/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fiscal-livro
$app->get('/fiscal-livro[/]', \FiscalLivroController::class . RESULT_LIST);
$app->get('/fiscal-livro/{id}', \FiscalLivroController::class . RESULT_OBJECT);
$app->post('/fiscal-livro', \FiscalLivroController::class . INSERT);
$app->put('/fiscal-livro', \FiscalLivroController::class . UPDATE);
$app->delete('/fiscal-livro/{id}', \FiscalLivroController::class . DELETE);
$app->options('/fiscal-livro', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-livro/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-livro/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// simples-nacional-cabecalho
$app->get('/simples-nacional-cabecalho[/]', \SimplesNacionalCabecalhoController::class . RESULT_LIST);
$app->get('/simples-nacional-cabecalho/{id}', \SimplesNacionalCabecalhoController::class . RESULT_OBJECT);
$app->post('/simples-nacional-cabecalho', \SimplesNacionalCabecalhoController::class . INSERT);
$app->put('/simples-nacional-cabecalho', \SimplesNacionalCabecalhoController::class . UPDATE);
$app->delete('/simples-nacional-cabecalho/{id}', \SimplesNacionalCabecalhoController::class . DELETE);
$app->options('/simples-nacional-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/simples-nacional-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/simples-nacional-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// nfe-cabecalho
$app->get('/nfe-cabecalho[/]', \NfeCabecalhoController::class . RESULT_LIST);
$app->get('/nfe-cabecalho/{id}', \NfeCabecalhoController::class . RESULT_OBJECT);
$app->post('/nfe-cabecalho', \NfeCabecalhoController::class . INSERT);
$app->put('/nfe-cabecalho', \NfeCabecalhoController::class . UPDATE);
$app->delete('/nfe-cabecalho/{id}', \NfeCabecalhoController::class . DELETE);
$app->options('/nfe-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nfe-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nfe-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fiscal-municipal-regime
$app->get('/fiscal-municipal-regime[/]', \FiscalMunicipalRegimeController::class . RESULT_LIST);
$app->get('/fiscal-municipal-regime/{id}', \FiscalMunicipalRegimeController::class . RESULT_OBJECT);
$app->post('/fiscal-municipal-regime', \FiscalMunicipalRegimeController::class . INSERT);
$app->put('/fiscal-municipal-regime', \FiscalMunicipalRegimeController::class . UPDATE);
$app->delete('/fiscal-municipal-regime/{id}', \FiscalMunicipalRegimeController::class . DELETE);
$app->options('/fiscal-municipal-regime', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-municipal-regime/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-municipal-regime/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fiscal-estadual-regime
$app->get('/fiscal-estadual-regime[/]', \FiscalEstadualRegimeController::class . RESULT_LIST);
$app->get('/fiscal-estadual-regime/{id}', \FiscalEstadualRegimeController::class . RESULT_OBJECT);
$app->post('/fiscal-estadual-regime', \FiscalEstadualRegimeController::class . INSERT);
$app->put('/fiscal-estadual-regime', \FiscalEstadualRegimeController::class . UPDATE);
$app->delete('/fiscal-estadual-regime/{id}', \FiscalEstadualRegimeController::class . DELETE);
$app->options('/fiscal-estadual-regime', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-estadual-regime/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-estadual-regime/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fiscal-estadual-porte
$app->get('/fiscal-estadual-porte[/]', \FiscalEstadualPorteController::class . RESULT_LIST);
$app->get('/fiscal-estadual-porte/{id}', \FiscalEstadualPorteController::class . RESULT_OBJECT);
$app->post('/fiscal-estadual-porte', \FiscalEstadualPorteController::class . INSERT);
$app->put('/fiscal-estadual-porte', \FiscalEstadualPorteController::class . UPDATE);
$app->delete('/fiscal-estadual-porte/{id}', \FiscalEstadualPorteController::class . DELETE);
$app->options('/fiscal-estadual-porte', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-estadual-porte/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-estadual-porte/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fiscal-nota-fiscal-entrada
$app->get('/fiscal-nota-fiscal-entrada[/]', \FiscalNotaFiscalEntradaController::class . RESULT_LIST);
$app->get('/fiscal-nota-fiscal-entrada/{id}', \FiscalNotaFiscalEntradaController::class . RESULT_OBJECT);
$app->post('/fiscal-nota-fiscal-entrada', \FiscalNotaFiscalEntradaController::class . INSERT);
$app->put('/fiscal-nota-fiscal-entrada', \FiscalNotaFiscalEntradaController::class . UPDATE);
$app->delete('/fiscal-nota-fiscal-entrada/{id}', \FiscalNotaFiscalEntradaController::class . DELETE);
$app->options('/fiscal-nota-fiscal-entrada', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-nota-fiscal-entrada/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-nota-fiscal-entrada/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fiscal-apuracao-icms
$app->get('/fiscal-apuracao-icms[/]', \FiscalApuracaoIcmsController::class . RESULT_LIST);
$app->get('/fiscal-apuracao-icms/{id}', \FiscalApuracaoIcmsController::class . RESULT_OBJECT);
$app->post('/fiscal-apuracao-icms', \FiscalApuracaoIcmsController::class . INSERT);
$app->put('/fiscal-apuracao-icms', \FiscalApuracaoIcmsController::class . UPDATE);
$app->delete('/fiscal-apuracao-icms/{id}', \FiscalApuracaoIcmsController::class . DELETE);
$app->options('/fiscal-apuracao-icms', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-apuracao-icms/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-apuracao-icms/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fiscal-nota-fiscal-saida
$app->get('/fiscal-nota-fiscal-saida[/]', \FiscalNotaFiscalSaidaController::class . RESULT_LIST);
$app->get('/fiscal-nota-fiscal-saida/{id}', \FiscalNotaFiscalSaidaController::class . RESULT_OBJECT);
$app->post('/fiscal-nota-fiscal-saida', \FiscalNotaFiscalSaidaController::class . INSERT);
$app->put('/fiscal-nota-fiscal-saida', \FiscalNotaFiscalSaidaController::class . UPDATE);
$app->delete('/fiscal-nota-fiscal-saida/{id}', \FiscalNotaFiscalSaidaController::class . DELETE);
$app->options('/fiscal-nota-fiscal-saida', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-nota-fiscal-saida/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fiscal-nota-fiscal-saida/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

