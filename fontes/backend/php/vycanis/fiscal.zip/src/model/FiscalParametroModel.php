<?php
declare(strict_types=1);

class FiscalParametroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fiscal_parametro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'fiscalInscricoesSubstitutasModelList',
		'fiscalEstadualRegimeModel',
		'fiscalEstadualPorteModel',
		'fiscalMunicipalRegimeModel',
	];

	/**
		* Relations
		*/
	public function fiscalInscricoesSubstitutasModelList()
{
	return $this->hasMany(FiscalInscricoesSubstitutasModel::class, 'id_fiscal_parametros', 'id');
}

	public function fiscalEstadualRegimeModel()
	{
		return $this->belongsTo(FiscalEstadualRegimeModel::class, 'id_fiscal_estadual_regime', 'id');
	}

	public function fiscalEstadualPorteModel()
	{
		return $this->belongsTo(FiscalEstadualPorteModel::class, 'id_fiscal_estadual_porte', 'id');
	}

	public function fiscalMunicipalRegimeModel()
	{
		return $this->belongsTo(FiscalMunicipalRegimeModel::class, 'id_fiscal_municipal_regime', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getVigenciaAttribute()
	{
		return $this->attributes['vigencia'];
	}

	public function setVigenciaAttribute($vigencia)
	{
		$this->attributes['vigencia'] = $vigencia;
	}

	public function getDescricaoVigenciaAttribute()
	{
		return $this->attributes['descricao_vigencia'];
	}

	public function setDescricaoVigenciaAttribute($descricaoVigencia)
	{
		$this->attributes['descricao_vigencia'] = $descricaoVigencia;
	}

	public function getCriterioLancamentoAttribute()
	{
		return $this->attributes['criterio_lancamento'];
	}

	public function setCriterioLancamentoAttribute($criterioLancamento)
	{
		$this->attributes['criterio_lancamento'] = $criterioLancamento;
	}

	public function getApuracaoAttribute()
	{
		return $this->attributes['apuracao'];
	}

	public function setApuracaoAttribute($apuracao)
	{
		$this->attributes['apuracao'] = $apuracao;
	}

	public function getMicroempreeIndividualAttribute()
	{
		return $this->attributes['microempree_individual'];
	}

	public function setMicroempreeIndividualAttribute($microempreeIndividual)
	{
		$this->attributes['microempree_individual'] = $microempreeIndividual;
	}

	public function getCalcPisCofinsEfdAttribute()
	{
		return $this->attributes['calc_pis_cofins_efd'];
	}

	public function setCalcPisCofinsEfdAttribute($calcPisCofinsEfd)
	{
		$this->attributes['calc_pis_cofins_efd'] = $calcPisCofinsEfd;
	}

	public function getSimplesCodigoAcessoAttribute()
	{
		return $this->attributes['simples_codigo_acesso'];
	}

	public function setSimplesCodigoAcessoAttribute($simplesCodigoAcesso)
	{
		$this->attributes['simples_codigo_acesso'] = $simplesCodigoAcesso;
	}

	public function getSimplesTabelaAttribute()
	{
		return $this->attributes['simples_tabela'];
	}

	public function setSimplesTabelaAttribute($simplesTabela)
	{
		$this->attributes['simples_tabela'] = $simplesTabela;
	}

	public function getSimplesAtividadeAttribute()
	{
		return $this->attributes['simples_atividade'];
	}

	public function setSimplesAtividadeAttribute($simplesAtividade)
	{
		$this->attributes['simples_atividade'] = $simplesAtividade;
	}

	public function getPerfilSpedAttribute()
	{
		return $this->attributes['perfil_sped'];
	}

	public function setPerfilSpedAttribute($perfilSped)
	{
		$this->attributes['perfil_sped'] = $perfilSped;
	}

	public function getApuracaoConsolidadaAttribute()
	{
		return $this->attributes['apuracao_consolidada'];
	}

	public function setApuracaoConsolidadaAttribute($apuracaoConsolidada)
	{
		$this->attributes['apuracao_consolidada'] = $apuracaoConsolidada;
	}

	public function getSubstituicaoTributariaAttribute()
	{
		return $this->attributes['substituicao_tributaria'];
	}

	public function setSubstituicaoTributariaAttribute($substituicaoTributaria)
	{
		$this->attributes['substituicao_tributaria'] = $substituicaoTributaria;
	}

	public function getFormaCalculoIssAttribute()
	{
		return $this->attributes['forma_calculo_iss'];
	}

	public function setFormaCalculoIssAttribute($formaCalculoIss)
	{
		$this->attributes['forma_calculo_iss'] = $formaCalculoIss;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setVigenciaAttribute($object->vigencia);
				$this->setDescricaoVigenciaAttribute($object->descricaoVigencia);
				$this->setCriterioLancamentoAttribute($object->criterioLancamento);
				$this->setApuracaoAttribute($object->apuracao);
				$this->setMicroempreeIndividualAttribute($object->microempreeIndividual);
				$this->setCalcPisCofinsEfdAttribute($object->calcPisCofinsEfd);
				$this->setSimplesCodigoAcessoAttribute($object->simplesCodigoAcesso);
				$this->setSimplesTabelaAttribute($object->simplesTabela);
				$this->setSimplesAtividadeAttribute($object->simplesAtividade);
				$this->setPerfilSpedAttribute($object->perfilSped);
				$this->setApuracaoConsolidadaAttribute($object->apuracaoConsolidada);
				$this->setSubstituicaoTributariaAttribute($object->substituicaoTributaria);
				$this->setFormaCalculoIssAttribute($object->formaCalculoIss);

				// link objects - lookups
				$fiscalEstadualRegimeModel = new FiscalEstadualRegimeModel();
				$fiscalEstadualRegimeModel->mapping($object->fiscalEstadualRegimeModel);
				$this->fiscalEstadualRegimeModel()->associate($fiscalEstadualRegimeModel);
				$fiscalEstadualPorteModel = new FiscalEstadualPorteModel();
				$fiscalEstadualPorteModel->mapping($object->fiscalEstadualPorteModel);
				$this->fiscalEstadualPorteModel()->associate($fiscalEstadualPorteModel);
				$fiscalMunicipalRegimeModel = new FiscalMunicipalRegimeModel();
				$fiscalMunicipalRegimeModel->mapping($object->fiscalMunicipalRegimeModel);
				$this->fiscalMunicipalRegimeModel()->associate($fiscalMunicipalRegimeModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'vigencia' => $this->getVigenciaAttribute(),
				'descricaoVigencia' => $this->getDescricaoVigenciaAttribute(),
				'criterioLancamento' => $this->getCriterioLancamentoAttribute(),
				'apuracao' => $this->getApuracaoAttribute(),
				'microempreeIndividual' => $this->getMicroempreeIndividualAttribute(),
				'calcPisCofinsEfd' => $this->getCalcPisCofinsEfdAttribute(),
				'simplesCodigoAcesso' => $this->getSimplesCodigoAcessoAttribute(),
				'simplesTabela' => $this->getSimplesTabelaAttribute(),
				'simplesAtividade' => $this->getSimplesAtividadeAttribute(),
				'perfilSped' => $this->getPerfilSpedAttribute(),
				'apuracaoConsolidada' => $this->getApuracaoConsolidadaAttribute(),
				'substituicaoTributaria' => $this->getSubstituicaoTributariaAttribute(),
				'formaCalculoIss' => $this->getFormaCalculoIssAttribute(),
				'fiscalInscricoesSubstitutasModelList' => $this->fiscalInscricoesSubstitutasModelList,
				'fiscalEstadualRegimeModel' => $this->fiscalEstadualRegimeModel,
				'fiscalEstadualPorteModel' => $this->fiscalEstadualPorteModel,
				'fiscalMunicipalRegimeModel' => $this->fiscalMunicipalRegimeModel,
			];
	}
}