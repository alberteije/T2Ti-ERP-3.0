<?php
declare(strict_types=1);

class FiscalNotaFiscalSaidaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fiscal_nota_fiscal_saida';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeCabecalhoModel',
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);

				// link objects - lookups
				$nfeCabecalhoModel = new NfeCabecalhoModel();
				$nfeCabecalhoModel->mapping($object->nfeCabecalhoModel);
				$this->nfeCabecalhoModel()->associate($nfeCabecalhoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'nfeCabecalhoModel' => $this->nfeCabecalhoModel,
			];
	}
}