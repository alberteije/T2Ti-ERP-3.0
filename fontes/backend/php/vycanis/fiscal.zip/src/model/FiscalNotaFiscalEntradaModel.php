<?php
declare(strict_types=1);

class FiscalNotaFiscalEntradaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fiscal_nota_fiscal_entrada';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeCabecalhoModel',
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getCfopEntradaAttribute()
	{
		return $this->attributes['cfop_entrada'];
	}

	public function setCfopEntradaAttribute($cfopEntrada)
	{
		$this->attributes['cfop_entrada'] = $cfopEntrada;
	}

	public function getValorRateioFreteAttribute()
	{
		return (double)$this->attributes['valor_rateio_frete'];
	}

	public function setValorRateioFreteAttribute($valorRateioFrete)
	{
		$this->attributes['valor_rateio_frete'] = $valorRateioFrete;
	}

	public function getValorCustoMedioAttribute()
	{
		return (double)$this->attributes['valor_custo_medio'];
	}

	public function setValorCustoMedioAttribute($valorCustoMedio)
	{
		$this->attributes['valor_custo_medio'] = $valorCustoMedio;
	}

	public function getValorIcmsAntecipadoAttribute()
	{
		return (double)$this->attributes['valor_icms_antecipado'];
	}

	public function setValorIcmsAntecipadoAttribute($valorIcmsAntecipado)
	{
		$this->attributes['valor_icms_antecipado'] = $valorIcmsAntecipado;
	}

	public function getValorBcIcmsAntecipadoAttribute()
	{
		return (double)$this->attributes['valor_bc_icms_antecipado'];
	}

	public function setValorBcIcmsAntecipadoAttribute($valorBcIcmsAntecipado)
	{
		$this->attributes['valor_bc_icms_antecipado'] = $valorBcIcmsAntecipado;
	}

	public function getValorBcIcmsCreditadoAttribute()
	{
		return (double)$this->attributes['valor_bc_icms_creditado'];
	}

	public function setValorBcIcmsCreditadoAttribute($valorBcIcmsCreditado)
	{
		$this->attributes['valor_bc_icms_creditado'] = $valorBcIcmsCreditado;
	}

	public function getValorBcPisCreditadoAttribute()
	{
		return (double)$this->attributes['valor_bc_pis_creditado'];
	}

	public function setValorBcPisCreditadoAttribute($valorBcPisCreditado)
	{
		$this->attributes['valor_bc_pis_creditado'] = $valorBcPisCreditado;
	}

	public function getValorBcCofinsCreditadoAttribute()
	{
		return (double)$this->attributes['valor_bc_cofins_creditado'];
	}

	public function setValorBcCofinsCreditadoAttribute($valorBcCofinsCreditado)
	{
		$this->attributes['valor_bc_cofins_creditado'] = $valorBcCofinsCreditado;
	}

	public function getValorBcIpiCreditadoAttribute()
	{
		return (double)$this->attributes['valor_bc_ipi_creditado'];
	}

	public function setValorBcIpiCreditadoAttribute($valorBcIpiCreditado)
	{
		$this->attributes['valor_bc_ipi_creditado'] = $valorBcIpiCreditado;
	}

	public function getCstCreditoIcmsAttribute()
	{
		return $this->attributes['cst_credito_icms'];
	}

	public function setCstCreditoIcmsAttribute($cstCreditoIcms)
	{
		$this->attributes['cst_credito_icms'] = $cstCreditoIcms;
	}

	public function getCstCreditoPisAttribute()
	{
		return $this->attributes['cst_credito_pis'];
	}

	public function setCstCreditoPisAttribute($cstCreditoPis)
	{
		$this->attributes['cst_credito_pis'] = $cstCreditoPis;
	}

	public function getCstCreditoCofinsAttribute()
	{
		return $this->attributes['cst_credito_cofins'];
	}

	public function setCstCreditoCofinsAttribute($cstCreditoCofins)
	{
		$this->attributes['cst_credito_cofins'] = $cstCreditoCofins;
	}

	public function getCstCreditoIpiAttribute()
	{
		return $this->attributes['cst_credito_ipi'];
	}

	public function setCstCreditoIpiAttribute($cstCreditoIpi)
	{
		$this->attributes['cst_credito_ipi'] = $cstCreditoIpi;
	}

	public function getValorIcmsCreditadoAttribute()
	{
		return (double)$this->attributes['valor_icms_creditado'];
	}

	public function setValorIcmsCreditadoAttribute($valorIcmsCreditado)
	{
		$this->attributes['valor_icms_creditado'] = $valorIcmsCreditado;
	}

	public function getValorPisCreditadoAttribute()
	{
		return (double)$this->attributes['valor_pis_creditado'];
	}

	public function setValorPisCreditadoAttribute($valorPisCreditado)
	{
		$this->attributes['valor_pis_creditado'] = $valorPisCreditado;
	}

	public function getValorCofinsCreditadoAttribute()
	{
		return (double)$this->attributes['valor_cofins_creditado'];
	}

	public function setValorCofinsCreditadoAttribute($valorCofinsCreditado)
	{
		$this->attributes['valor_cofins_creditado'] = $valorCofinsCreditado;
	}

	public function getValorIpiCreditadoAttribute()
	{
		return (double)$this->attributes['valor_ipi_creditado'];
	}

	public function setValorIpiCreditadoAttribute($valorIpiCreditado)
	{
		$this->attributes['valor_ipi_creditado'] = $valorIpiCreditado;
	}

	public function getQtdeParcelaCreditoPisAttribute()
	{
		return $this->attributes['qtde_parcela_credito_pis'];
	}

	public function setQtdeParcelaCreditoPisAttribute($qtdeParcelaCreditoPis)
	{
		$this->attributes['qtde_parcela_credito_pis'] = $qtdeParcelaCreditoPis;
	}

	public function getQtdeParcelaCreditoCofinsAttribute()
	{
		return $this->attributes['qtde_parcela_credito_cofins'];
	}

	public function setQtdeParcelaCreditoCofinsAttribute($qtdeParcelaCreditoCofins)
	{
		$this->attributes['qtde_parcela_credito_cofins'] = $qtdeParcelaCreditoCofins;
	}

	public function getQtdeParcelaCreditoIcmsAttribute()
	{
		return $this->attributes['qtde_parcela_credito_icms'];
	}

	public function setQtdeParcelaCreditoIcmsAttribute($qtdeParcelaCreditoIcms)
	{
		$this->attributes['qtde_parcela_credito_icms'] = $qtdeParcelaCreditoIcms;
	}

	public function getQtdeParcelaCreditoIpiAttribute()
	{
		return $this->attributes['qtde_parcela_credito_ipi'];
	}

	public function setQtdeParcelaCreditoIpiAttribute($qtdeParcelaCreditoIpi)
	{
		$this->attributes['qtde_parcela_credito_ipi'] = $qtdeParcelaCreditoIpi;
	}

	public function getAliquotaCreditoIcmsAttribute()
	{
		return (double)$this->attributes['aliquota_credito_icms'];
	}

	public function setAliquotaCreditoIcmsAttribute($aliquotaCreditoIcms)
	{
		$this->attributes['aliquota_credito_icms'] = $aliquotaCreditoIcms;
	}

	public function getAliquotaCreditoPisAttribute()
	{
		return (double)$this->attributes['aliquota_credito_pis'];
	}

	public function setAliquotaCreditoPisAttribute($aliquotaCreditoPis)
	{
		$this->attributes['aliquota_credito_pis'] = $aliquotaCreditoPis;
	}

	public function getAliquotaCreditoCofinsAttribute()
	{
		return (double)$this->attributes['aliquota_credito_cofins'];
	}

	public function setAliquotaCreditoCofinsAttribute($aliquotaCreditoCofins)
	{
		$this->attributes['aliquota_credito_cofins'] = $aliquotaCreditoCofins;
	}

	public function getAliquotaCreditoIpiAttribute()
	{
		return (double)$this->attributes['aliquota_credito_ipi'];
	}

	public function setAliquotaCreditoIpiAttribute($aliquotaCreditoIpi)
	{
		$this->attributes['aliquota_credito_ipi'] = $aliquotaCreditoIpi;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setCfopEntradaAttribute($object->cfopEntrada);
				$this->setValorRateioFreteAttribute($object->valorRateioFrete);
				$this->setValorCustoMedioAttribute($object->valorCustoMedio);
				$this->setValorIcmsAntecipadoAttribute($object->valorIcmsAntecipado);
				$this->setValorBcIcmsAntecipadoAttribute($object->valorBcIcmsAntecipado);
				$this->setValorBcIcmsCreditadoAttribute($object->valorBcIcmsCreditado);
				$this->setValorBcPisCreditadoAttribute($object->valorBcPisCreditado);
				$this->setValorBcCofinsCreditadoAttribute($object->valorBcCofinsCreditado);
				$this->setValorBcIpiCreditadoAttribute($object->valorBcIpiCreditado);
				$this->setCstCreditoIcmsAttribute($object->cstCreditoIcms);
				$this->setCstCreditoPisAttribute($object->cstCreditoPis);
				$this->setCstCreditoCofinsAttribute($object->cstCreditoCofins);
				$this->setCstCreditoIpiAttribute($object->cstCreditoIpi);
				$this->setValorIcmsCreditadoAttribute($object->valorIcmsCreditado);
				$this->setValorPisCreditadoAttribute($object->valorPisCreditado);
				$this->setValorCofinsCreditadoAttribute($object->valorCofinsCreditado);
				$this->setValorIpiCreditadoAttribute($object->valorIpiCreditado);
				$this->setQtdeParcelaCreditoPisAttribute($object->qtdeParcelaCreditoPis);
				$this->setQtdeParcelaCreditoCofinsAttribute($object->qtdeParcelaCreditoCofins);
				$this->setQtdeParcelaCreditoIcmsAttribute($object->qtdeParcelaCreditoIcms);
				$this->setQtdeParcelaCreditoIpiAttribute($object->qtdeParcelaCreditoIpi);
				$this->setAliquotaCreditoIcmsAttribute($object->aliquotaCreditoIcms);
				$this->setAliquotaCreditoPisAttribute($object->aliquotaCreditoPis);
				$this->setAliquotaCreditoCofinsAttribute($object->aliquotaCreditoCofins);
				$this->setAliquotaCreditoIpiAttribute($object->aliquotaCreditoIpi);

				// link objects - lookups
				$nfeCabecalhoModel = new NfeCabecalhoModel();
				$nfeCabecalhoModel->mapping($object->nfeCabecalhoModel);
				$this->nfeCabecalhoModel()->associate($nfeCabecalhoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'cfopEntrada' => $this->getCfopEntradaAttribute(),
				'valorRateioFrete' => $this->getValorRateioFreteAttribute(),
				'valorCustoMedio' => $this->getValorCustoMedioAttribute(),
				'valorIcmsAntecipado' => $this->getValorIcmsAntecipadoAttribute(),
				'valorBcIcmsAntecipado' => $this->getValorBcIcmsAntecipadoAttribute(),
				'valorBcIcmsCreditado' => $this->getValorBcIcmsCreditadoAttribute(),
				'valorBcPisCreditado' => $this->getValorBcPisCreditadoAttribute(),
				'valorBcCofinsCreditado' => $this->getValorBcCofinsCreditadoAttribute(),
				'valorBcIpiCreditado' => $this->getValorBcIpiCreditadoAttribute(),
				'cstCreditoIcms' => $this->getCstCreditoIcmsAttribute(),
				'cstCreditoPis' => $this->getCstCreditoPisAttribute(),
				'cstCreditoCofins' => $this->getCstCreditoCofinsAttribute(),
				'cstCreditoIpi' => $this->getCstCreditoIpiAttribute(),
				'valorIcmsCreditado' => $this->getValorIcmsCreditadoAttribute(),
				'valorPisCreditado' => $this->getValorPisCreditadoAttribute(),
				'valorCofinsCreditado' => $this->getValorCofinsCreditadoAttribute(),
				'valorIpiCreditado' => $this->getValorIpiCreditadoAttribute(),
				'qtdeParcelaCreditoPis' => $this->getQtdeParcelaCreditoPisAttribute(),
				'qtdeParcelaCreditoCofins' => $this->getQtdeParcelaCreditoCofinsAttribute(),
				'qtdeParcelaCreditoIcms' => $this->getQtdeParcelaCreditoIcmsAttribute(),
				'qtdeParcelaCreditoIpi' => $this->getQtdeParcelaCreditoIpiAttribute(),
				'aliquotaCreditoIcms' => $this->getAliquotaCreditoIcmsAttribute(),
				'aliquotaCreditoPis' => $this->getAliquotaCreditoPisAttribute(),
				'aliquotaCreditoCofins' => $this->getAliquotaCreditoCofinsAttribute(),
				'aliquotaCreditoIpi' => $this->getAliquotaCreditoIpiAttribute(),
				'nfeCabecalhoModel' => $this->nfeCabecalhoModel,
			];
	}
}