<?php
declare(strict_types=1);

class FiscalInscricoesSubstitutasModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fiscal_inscricoes_substitutas';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function fiscalParametroModel()
	{
		return $this->belongsTo(FiscalParametroModel::class, 'id_fiscal_parametros', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	public function getPmpfAttribute()
	{
		return $this->attributes['pmpf'];
	}

	public function setPmpfAttribute($pmpf)
	{
		$this->attributes['pmpf'] = $pmpf;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setUfAttribute($object->uf);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);
				$this->setPmpfAttribute($object->pmpf);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'uf' => $this->getUfAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
				'pmpf' => $this->getPmpfAttribute(),
			];
	}
}