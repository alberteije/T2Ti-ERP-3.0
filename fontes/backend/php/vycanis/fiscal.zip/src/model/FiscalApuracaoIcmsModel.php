<?php
declare(strict_types=1);

class FiscalApuracaoIcmsModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fiscal_apuracao_icms';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getValorTotalDebitoAttribute()
	{
		return (double)$this->attributes['valor_total_debito'];
	}

	public function setValorTotalDebitoAttribute($valorTotalDebito)
	{
		$this->attributes['valor_total_debito'] = $valorTotalDebito;
	}

	public function getValorAjusteDebitoAttribute()
	{
		return (double)$this->attributes['valor_ajuste_debito'];
	}

	public function setValorAjusteDebitoAttribute($valorAjusteDebito)
	{
		$this->attributes['valor_ajuste_debito'] = $valorAjusteDebito;
	}

	public function getValorTotalAjusteDebitoAttribute()
	{
		return (double)$this->attributes['valor_total_ajuste_debito'];
	}

	public function setValorTotalAjusteDebitoAttribute($valorTotalAjusteDebito)
	{
		$this->attributes['valor_total_ajuste_debito'] = $valorTotalAjusteDebito;
	}

	public function getValorEstornoCreditoAttribute()
	{
		return (double)$this->attributes['valor_estorno_credito'];
	}

	public function setValorEstornoCreditoAttribute($valorEstornoCredito)
	{
		$this->attributes['valor_estorno_credito'] = $valorEstornoCredito;
	}

	public function getValorTotalCreditoAttribute()
	{
		return (double)$this->attributes['valor_total_credito'];
	}

	public function setValorTotalCreditoAttribute($valorTotalCredito)
	{
		$this->attributes['valor_total_credito'] = $valorTotalCredito;
	}

	public function getValorAjusteCreditoAttribute()
	{
		return (double)$this->attributes['valor_ajuste_credito'];
	}

	public function setValorAjusteCreditoAttribute($valorAjusteCredito)
	{
		$this->attributes['valor_ajuste_credito'] = $valorAjusteCredito;
	}

	public function getValorTotalAjusteCreditoAttribute()
	{
		return (double)$this->attributes['valor_total_ajuste_credito'];
	}

	public function setValorTotalAjusteCreditoAttribute($valorTotalAjusteCredito)
	{
		$this->attributes['valor_total_ajuste_credito'] = $valorTotalAjusteCredito;
	}

	public function getValorEstornoDebitoAttribute()
	{
		return (double)$this->attributes['valor_estorno_debito'];
	}

	public function setValorEstornoDebitoAttribute($valorEstornoDebito)
	{
		$this->attributes['valor_estorno_debito'] = $valorEstornoDebito;
	}

	public function getValorSaldoCredorAnteriorAttribute()
	{
		return (double)$this->attributes['valor_saldo_credor_anterior'];
	}

	public function setValorSaldoCredorAnteriorAttribute($valorSaldoCredorAnterior)
	{
		$this->attributes['valor_saldo_credor_anterior'] = $valorSaldoCredorAnterior;
	}

	public function getValorSaldoApuradoAttribute()
	{
		return (double)$this->attributes['valor_saldo_apurado'];
	}

	public function setValorSaldoApuradoAttribute($valorSaldoApurado)
	{
		$this->attributes['valor_saldo_apurado'] = $valorSaldoApurado;
	}

	public function getValorTotalDeducaoAttribute()
	{
		return (double)$this->attributes['valor_total_deducao'];
	}

	public function setValorTotalDeducaoAttribute($valorTotalDeducao)
	{
		$this->attributes['valor_total_deducao'] = $valorTotalDeducao;
	}

	public function getValorIcmsRecolherAttribute()
	{
		return (double)$this->attributes['valor_icms_recolher'];
	}

	public function setValorIcmsRecolherAttribute($valorIcmsRecolher)
	{
		$this->attributes['valor_icms_recolher'] = $valorIcmsRecolher;
	}

	public function getValorSaldoCredorTranspAttribute()
	{
		return (double)$this->attributes['valor_saldo_credor_transp'];
	}

	public function setValorSaldoCredorTranspAttribute($valorSaldoCredorTransp)
	{
		$this->attributes['valor_saldo_credor_transp'] = $valorSaldoCredorTransp;
	}

	public function getValorDebitoEspecialAttribute()
	{
		return (double)$this->attributes['valor_debito_especial'];
	}

	public function setValorDebitoEspecialAttribute($valorDebitoEspecial)
	{
		$this->attributes['valor_debito_especial'] = $valorDebitoEspecial;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setValorTotalDebitoAttribute($object->valorTotalDebito);
				$this->setValorAjusteDebitoAttribute($object->valorAjusteDebito);
				$this->setValorTotalAjusteDebitoAttribute($object->valorTotalAjusteDebito);
				$this->setValorEstornoCreditoAttribute($object->valorEstornoCredito);
				$this->setValorTotalCreditoAttribute($object->valorTotalCredito);
				$this->setValorAjusteCreditoAttribute($object->valorAjusteCredito);
				$this->setValorTotalAjusteCreditoAttribute($object->valorTotalAjusteCredito);
				$this->setValorEstornoDebitoAttribute($object->valorEstornoDebito);
				$this->setValorSaldoCredorAnteriorAttribute($object->valorSaldoCredorAnterior);
				$this->setValorSaldoApuradoAttribute($object->valorSaldoApurado);
				$this->setValorTotalDeducaoAttribute($object->valorTotalDeducao);
				$this->setValorIcmsRecolherAttribute($object->valorIcmsRecolher);
				$this->setValorSaldoCredorTranspAttribute($object->valorSaldoCredorTransp);
				$this->setValorDebitoEspecialAttribute($object->valorDebitoEspecial);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'valorTotalDebito' => $this->getValorTotalDebitoAttribute(),
				'valorAjusteDebito' => $this->getValorAjusteDebitoAttribute(),
				'valorTotalAjusteDebito' => $this->getValorTotalAjusteDebitoAttribute(),
				'valorEstornoCredito' => $this->getValorEstornoCreditoAttribute(),
				'valorTotalCredito' => $this->getValorTotalCreditoAttribute(),
				'valorAjusteCredito' => $this->getValorAjusteCreditoAttribute(),
				'valorTotalAjusteCredito' => $this->getValorTotalAjusteCreditoAttribute(),
				'valorEstornoDebito' => $this->getValorEstornoDebitoAttribute(),
				'valorSaldoCredorAnterior' => $this->getValorSaldoCredorAnteriorAttribute(),
				'valorSaldoApurado' => $this->getValorSaldoApuradoAttribute(),
				'valorTotalDeducao' => $this->getValorTotalDeducaoAttribute(),
				'valorIcmsRecolher' => $this->getValorIcmsRecolherAttribute(),
				'valorSaldoCredorTransp' => $this->getValorSaldoCredorTranspAttribute(),
				'valorDebitoEspecial' => $this->getValorDebitoEspecialAttribute(),
			];
	}
}