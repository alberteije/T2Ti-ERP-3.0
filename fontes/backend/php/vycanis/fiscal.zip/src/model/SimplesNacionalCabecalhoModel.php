<?php
declare(strict_types=1);

class SimplesNacionalCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'simples_nacional_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'simplesNacionalDetalheModelList',
	];

	/**
		* Relations
		*/
	public function simplesNacionalDetalheModelList()
{
	return $this->hasMany(SimplesNacionalDetalheModel::class, 'id_simples_nacional_cabecalho', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getVigenciaInicialAttribute()
	{
		return $this->attributes['vigencia_inicial'];
	}

	public function setVigenciaInicialAttribute($vigenciaInicial)
	{
		$this->attributes['vigencia_inicial'] = $vigenciaInicial;
	}

	public function getVigenciaFinalAttribute()
	{
		return $this->attributes['vigencia_final'];
	}

	public function setVigenciaFinalAttribute($vigenciaFinal)
	{
		$this->attributes['vigencia_final'] = $vigenciaFinal;
	}

	public function getAnexoAttribute()
	{
		return $this->attributes['anexo'];
	}

	public function setAnexoAttribute($anexo)
	{
		$this->attributes['anexo'] = $anexo;
	}

	public function getTabelaAttribute()
	{
		return $this->attributes['tabela'];
	}

	public function setTabelaAttribute($tabela)
	{
		$this->attributes['tabela'] = $tabela;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setVigenciaInicialAttribute($object->vigenciaInicial);
				$this->setVigenciaFinalAttribute($object->vigenciaFinal);
				$this->setAnexoAttribute($object->anexo);
				$this->setTabelaAttribute($object->tabela);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'vigenciaInicial' => $this->getVigenciaInicialAttribute(),
				'vigenciaFinal' => $this->getVigenciaFinalAttribute(),
				'anexo' => $this->getAnexoAttribute(),
				'tabela' => $this->getTabelaAttribute(),
				'simplesNacionalDetalheModelList' => $this->simplesNacionalDetalheModelList,
			];
	}
}