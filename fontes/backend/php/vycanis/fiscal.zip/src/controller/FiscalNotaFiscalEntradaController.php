<?php
class FiscalNotaFiscalEntradaController extends ControllerBase
{

		private $fiscalNotaFiscalEntradaService = null;

		public function __construct()
		{	 
				$this->fiscalNotaFiscalEntradaService = new FiscalNotaFiscalEntradaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->fiscalNotaFiscalEntradaService->getListFilter($filter);
						} else {
								$resultList = $this->fiscalNotaFiscalEntradaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList FiscalNotaFiscalEntrada]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->fiscalNotaFiscalEntradaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject FiscalNotaFiscalEntrada]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject FiscalNotaFiscalEntrada]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert FiscalNotaFiscalEntrada]', null);
						}

						$objModel = new FiscalNotaFiscalEntradaModel();
						$objModel->mapping($objJson);

						$this->fiscalNotaFiscalEntradaService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert FiscalNotaFiscalEntrada]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->fiscalNotaFiscalEntradaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update FiscalNotaFiscalEntrada]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->fiscalNotaFiscalEntradaService->save($objFromDatabase);
								$objFromDatabase = $this->fiscalNotaFiscalEntradaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update FiscalNotaFiscalEntrada]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->fiscalNotaFiscalEntradaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete FiscalNotaFiscalEntrada]', null);
						} else {
								$this->fiscalNotaFiscalEntradaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete FiscalNotaFiscalEntrada]', $e);
				}
		}
}
