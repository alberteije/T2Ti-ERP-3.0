<?php
class FiscalEstadualRegimeService extends ServiceBase
{
  public function getList()
  {
    return FiscalEstadualRegimeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FiscalEstadualRegimeModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FiscalEstadualRegimeModel::find($id);
  }

}