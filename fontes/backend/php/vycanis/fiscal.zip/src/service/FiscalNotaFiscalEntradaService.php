<?php
class FiscalNotaFiscalEntradaService extends ServiceBase
{
  public function getList()
  {
    return FiscalNotaFiscalEntradaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FiscalNotaFiscalEntradaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FiscalNotaFiscalEntradaModel::find($id);
  }

}