<?php
class NfeCabecalhoService extends ServiceBase
{
  public function getList()
  {
    return NfeCabecalhoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeCabecalhoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeCabecalhoModel::find($id);
  }

}