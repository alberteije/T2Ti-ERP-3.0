<?php
class FiscalNotaFiscalSaidaService extends ServiceBase
{
  public function getList()
  {
    return FiscalNotaFiscalSaidaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FiscalNotaFiscalSaidaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FiscalNotaFiscalSaidaModel::find($id);
  }

}