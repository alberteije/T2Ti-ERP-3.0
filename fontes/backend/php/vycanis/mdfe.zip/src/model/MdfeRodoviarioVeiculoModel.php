<?php
declare(strict_types=1);

class MdfeRodoviarioVeiculoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_rodoviario_veiculo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'mdfeRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function mdfeRodoviarioModel()
	{
		return $this->belongsTo(MdfeRodoviarioModel::class, 'id_mdfe_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoInternoAttribute()
	{
		return $this->attributes['codigo_interno'];
	}

	public function setCodigoInternoAttribute($codigoInterno)
	{
		$this->attributes['codigo_interno'] = $codigoInterno;
	}

	public function getPlacaAttribute()
	{
		return $this->attributes['placa'];
	}

	public function setPlacaAttribute($placa)
	{
		$this->attributes['placa'] = $placa;
	}

	public function getRenavamAttribute()
	{
		return $this->attributes['renavam'];
	}

	public function setRenavamAttribute($renavam)
	{
		$this->attributes['renavam'] = $renavam;
	}

	public function getTaraAttribute()
	{
		return $this->attributes['tara'];
	}

	public function setTaraAttribute($tara)
	{
		$this->attributes['tara'] = $tara;
	}

	public function getCapacidadeKgAttribute()
	{
		return $this->attributes['capacidade_kg'];
	}

	public function setCapacidadeKgAttribute($capacidadeKg)
	{
		$this->attributes['capacidade_kg'] = $capacidadeKg;
	}

	public function getCapacidadeM3Attribute()
	{
		return $this->attributes['capacidade_m3'];
	}

	public function setCapacidadeM3Attribute($capacidadeM3)
	{
		$this->attributes['capacidade_m3'] = $capacidadeM3;
	}

	public function getTipoRodadoAttribute()
	{
		return $this->attributes['tipo_rodado'];
	}

	public function setTipoRodadoAttribute($tipoRodado)
	{
		$this->attributes['tipo_rodado'] = $tipoRodado;
	}

	public function getTipoCarroceriaAttribute()
	{
		return $this->attributes['tipo_carroceria'];
	}

	public function setTipoCarroceriaAttribute($tipoCarroceria)
	{
		$this->attributes['tipo_carroceria'] = $tipoCarroceria;
	}

	public function getUfLicenciamentoAttribute()
	{
		return $this->attributes['uf_licenciamento'];
	}

	public function setUfLicenciamentoAttribute($ufLicenciamento)
	{
		$this->attributes['uf_licenciamento'] = $ufLicenciamento;
	}

	public function getProprietarioCpfAttribute()
	{
		return $this->attributes['proprietario_cpf'];
	}

	public function setProprietarioCpfAttribute($proprietarioCpf)
	{
		$this->attributes['proprietario_cpf'] = $proprietarioCpf;
	}

	public function getProprietarioCnpjAttribute()
	{
		return $this->attributes['proprietario_cnpj'];
	}

	public function setProprietarioCnpjAttribute($proprietarioCnpj)
	{
		$this->attributes['proprietario_cnpj'] = $proprietarioCnpj;
	}

	public function getProprietarioRntrcAttribute()
	{
		return $this->attributes['proprietario_rntrc'];
	}

	public function setProprietarioRntrcAttribute($proprietarioRntrc)
	{
		$this->attributes['proprietario_rntrc'] = $proprietarioRntrc;
	}

	public function getProprietarioNomeAttribute()
	{
		return $this->attributes['proprietario_nome'];
	}

	public function setProprietarioNomeAttribute($proprietarioNome)
	{
		$this->attributes['proprietario_nome'] = $proprietarioNome;
	}

	public function getProprietarioIeAttribute()
	{
		return $this->attributes['proprietario_ie'];
	}

	public function setProprietarioIeAttribute($proprietarioIe)
	{
		$this->attributes['proprietario_ie'] = $proprietarioIe;
	}

	public function getProprietarioTipoAttribute()
	{
		return $this->attributes['proprietario_tipo'];
	}

	public function setProprietarioTipoAttribute($proprietarioTipo)
	{
		$this->attributes['proprietario_tipo'] = $proprietarioTipo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoInternoAttribute($object->codigoInterno);
				$this->setPlacaAttribute($object->placa);
				$this->setRenavamAttribute($object->renavam);
				$this->setTaraAttribute($object->tara);
				$this->setCapacidadeKgAttribute($object->capacidadeKg);
				$this->setCapacidadeM3Attribute($object->capacidadeM3);
				$this->setTipoRodadoAttribute($object->tipoRodado);
				$this->setTipoCarroceriaAttribute($object->tipoCarroceria);
				$this->setUfLicenciamentoAttribute($object->ufLicenciamento);
				$this->setProprietarioCpfAttribute($object->proprietarioCpf);
				$this->setProprietarioCnpjAttribute($object->proprietarioCnpj);
				$this->setProprietarioRntrcAttribute($object->proprietarioRntrc);
				$this->setProprietarioNomeAttribute($object->proprietarioNome);
				$this->setProprietarioIeAttribute($object->proprietarioIe);
				$this->setProprietarioTipoAttribute($object->proprietarioTipo);

				// link objects - lookups
				$mdfeRodoviarioModel = new MdfeRodoviarioModel();
				$mdfeRodoviarioModel->mapping($object->mdfeRodoviarioModel);
				$this->mdfeRodoviarioModel()->associate($mdfeRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoInterno' => $this->getCodigoInternoAttribute(),
				'placa' => $this->getPlacaAttribute(),
				'renavam' => $this->getRenavamAttribute(),
				'tara' => $this->getTaraAttribute(),
				'capacidadeKg' => $this->getCapacidadeKgAttribute(),
				'capacidadeM3' => $this->getCapacidadeM3Attribute(),
				'tipoRodado' => $this->getTipoRodadoAttribute(),
				'tipoCarroceria' => $this->getTipoCarroceriaAttribute(),
				'ufLicenciamento' => $this->getUfLicenciamentoAttribute(),
				'proprietarioCpf' => $this->getProprietarioCpfAttribute(),
				'proprietarioCnpj' => $this->getProprietarioCnpjAttribute(),
				'proprietarioRntrc' => $this->getProprietarioRntrcAttribute(),
				'proprietarioNome' => $this->getProprietarioNomeAttribute(),
				'proprietarioIe' => $this->getProprietarioIeAttribute(),
				'proprietarioTipo' => $this->getProprietarioTipoAttribute(),
				'mdfeRodoviarioModel' => $this->mdfeRodoviarioModel,
			];
	}
}