<?php
class MdfeRodoviarioPedagioService extends ServiceBase
{
  public function getList()
  {
    return MdfeRodoviarioPedagioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return MdfeRodoviarioPedagioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return MdfeRodoviarioPedagioModel::find($id);
  }

}