<?php
class MdfeInformacaoCteService extends ServiceBase
{
  public function getList()
  {
    return MdfeInformacaoCteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return MdfeInformacaoCteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return MdfeInformacaoCteModel::find($id);
  }

}