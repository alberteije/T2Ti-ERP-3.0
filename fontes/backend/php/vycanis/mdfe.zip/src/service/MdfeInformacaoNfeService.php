<?php
class MdfeInformacaoNfeService extends ServiceBase
{
  public function getList()
  {
    return MdfeInformacaoNfeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return MdfeInformacaoNfeModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return MdfeInformacaoNfeModel::find($id);
  }

}