<?php
use Illuminate\Database\Capsule\Manager as DB;
class MdfeCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return MdfeCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return MdfeCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return MdfeCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// mdfeLacre
		$mdfeLacreModelListJson = $objJson->mdfeLacreModelList;
		if ($mdfeLacreModelListJson != null) {
			for ($i = 0; $i < count($mdfeLacreModelListJson); $i++) {
				$mdfeLacre = new MdfeLacreModel();
				$mdfeLacre->mapping($mdfeLacreModelListJson[$i]);
				$objModel->mdfeLacreModelList()->save($mdfeLacre);
			}
		}

		// mdfeMunicipioDescarrega
		$mdfeMunicipioDescarregaModelListJson = $objJson->mdfeMunicipioDescarregaModelList;
		if ($mdfeMunicipioDescarregaModelListJson != null) {
			for ($i = 0; $i < count($mdfeMunicipioDescarregaModelListJson); $i++) {
				$mdfeMunicipioDescarrega = new MdfeMunicipioDescarregaModel();
				$mdfeMunicipioDescarrega->mapping($mdfeMunicipioDescarregaModelListJson[$i]);
				$objModel->mdfeMunicipioDescarregaModelList()->save($mdfeMunicipioDescarrega);
			}
		}

		// mdfeEmitente
		$mdfeEmitenteModelListJson = $objJson->mdfeEmitenteModelList;
		if ($mdfeEmitenteModelListJson != null) {
			for ($i = 0; $i < count($mdfeEmitenteModelListJson); $i++) {
				$mdfeEmitente = new MdfeEmitenteModel();
				$mdfeEmitente->mapping($mdfeEmitenteModelListJson[$i]);
				$objModel->mdfeEmitenteModelList()->save($mdfeEmitente);
			}
		}

		// mdfePercurso
		$mdfePercursoModelListJson = $objJson->mdfePercursoModelList;
		if ($mdfePercursoModelListJson != null) {
			for ($i = 0; $i < count($mdfePercursoModelListJson); $i++) {
				$mdfePercurso = new MdfePercursoModel();
				$mdfePercurso->mapping($mdfePercursoModelListJson[$i]);
				$objModel->mdfePercursoModelList()->save($mdfePercurso);
			}
		}

		// mdfeMunicipioCarregamento
		$mdfeMunicipioCarregamentoModelListJson = $objJson->mdfeMunicipioCarregamentoModelList;
		if ($mdfeMunicipioCarregamentoModelListJson != null) {
			for ($i = 0; $i < count($mdfeMunicipioCarregamentoModelListJson); $i++) {
				$mdfeMunicipioCarregamento = new MdfeMunicipioCarregamentoModel();
				$mdfeMunicipioCarregamento->mapping($mdfeMunicipioCarregamentoModelListJson[$i]);
				$objModel->mdfeMunicipioCarregamentoModelList()->save($mdfeMunicipioCarregamento);
			}
		}

		// mdfeRodoviario
		$mdfeRodoviarioModelListJson = $objJson->mdfeRodoviarioModelList;
		if ($mdfeRodoviarioModelListJson != null) {
			for ($i = 0; $i < count($mdfeRodoviarioModelListJson); $i++) {
				$mdfeRodoviario = new MdfeRodoviarioModel();
				$mdfeRodoviario->mapping($mdfeRodoviarioModelListJson[$i]);
				$objModel->mdfeRodoviarioModelList()->save($mdfeRodoviario);
			}
		}

		// mdfeInformacaoSeguro
		$mdfeInformacaoSeguroModelListJson = $objJson->mdfeInformacaoSeguroModelList;
		if ($mdfeInformacaoSeguroModelListJson != null) {
			for ($i = 0; $i < count($mdfeInformacaoSeguroModelListJson); $i++) {
				$mdfeInformacaoSeguro = new MdfeInformacaoSeguroModel();
				$mdfeInformacaoSeguro->mapping($mdfeInformacaoSeguroModelListJson[$i]);
				$objModel->mdfeInformacaoSeguroModelList()->save($mdfeInformacaoSeguro);
			}
		}

	}	

	public function deleteChildren($object)
	{
		MdfeLacreModel::where('id_mdfe_cabecalho', $object->getIdAttribute())->delete();
		MdfeMunicipioDescarregaModel::where('id_mdfe_cabecalho', $object->getIdAttribute())->delete();
		MdfeEmitenteModel::where('id_mdfe_cabecalho', $object->getIdAttribute())->delete();
		MdfePercursoModel::where('id_mdfe_cabecalho', $object->getIdAttribute())->delete();
		MdfeMunicipioCarregamentoModel::where('id_mdfe_cabecalho', $object->getIdAttribute())->delete();
		MdfeRodoviarioModel::where('id_mdfe_cabecalho', $object->getIdAttribute())->delete();
		MdfeInformacaoSeguroModel::where('id_mdfe_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}