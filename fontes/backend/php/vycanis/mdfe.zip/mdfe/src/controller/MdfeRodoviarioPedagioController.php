<?php
class MdfeRodoviarioPedagioController extends ControllerBase
{

		private $mdfeRodoviarioPedagioService = null;

		public function __construct()
		{	 
				$this->mdfeRodoviarioPedagioService = new MdfeRodoviarioPedagioService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->mdfeRodoviarioPedagioService->getListFilter($filter);
						} else {
								$resultList = $this->mdfeRodoviarioPedagioService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList MdfeRodoviarioPedagio]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioPedagioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject MdfeRodoviarioPedagio]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject MdfeRodoviarioPedagio]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert MdfeRodoviarioPedagio]', null);
						}

						$objModel = new MdfeRodoviarioPedagioModel();
						$objModel->mapping($objJson);

						$this->mdfeRodoviarioPedagioService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert MdfeRodoviarioPedagio]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->mdfeRodoviarioPedagioService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update MdfeRodoviarioPedagio]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->mdfeRodoviarioPedagioService->save($objFromDatabase);
								$objFromDatabase = $this->mdfeRodoviarioPedagioService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update MdfeRodoviarioPedagio]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioPedagioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete MdfeRodoviarioPedagio]', null);
						} else {
								$this->mdfeRodoviarioPedagioService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete MdfeRodoviarioPedagio]', $e);
				}
		}
}
