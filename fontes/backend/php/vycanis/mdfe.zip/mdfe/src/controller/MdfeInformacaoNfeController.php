<?php
class MdfeInformacaoNfeController extends ControllerBase
{

		private $mdfeInformacaoNfeService = null;

		public function __construct()
		{	 
				$this->mdfeInformacaoNfeService = new MdfeInformacaoNfeService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->mdfeInformacaoNfeService->getListFilter($filter);
						} else {
								$resultList = $this->mdfeInformacaoNfeService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList MdfeInformacaoNfe]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeInformacaoNfeService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject MdfeInformacaoNfe]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject MdfeInformacaoNfe]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert MdfeInformacaoNfe]', null);
						}

						$objModel = new MdfeInformacaoNfeModel();
						$objModel->mapping($objJson);

						$this->mdfeInformacaoNfeService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert MdfeInformacaoNfe]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->mdfeInformacaoNfeService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update MdfeInformacaoNfe]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->mdfeInformacaoNfeService->save($objFromDatabase);
								$objFromDatabase = $this->mdfeInformacaoNfeService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update MdfeInformacaoNfe]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeInformacaoNfeService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete MdfeInformacaoNfe]', null);
						} else {
								$this->mdfeInformacaoNfeService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete MdfeInformacaoNfe]', $e);
				}
		}
}
