<?php
class MdfeRodoviarioVeiculoController extends ControllerBase
{

		private $mdfeRodoviarioVeiculoService = null;

		public function __construct()
		{	 
				$this->mdfeRodoviarioVeiculoService = new MdfeRodoviarioVeiculoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->mdfeRodoviarioVeiculoService->getListFilter($filter);
						} else {
								$resultList = $this->mdfeRodoviarioVeiculoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList MdfeRodoviarioVeiculo]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioVeiculoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject MdfeRodoviarioVeiculo]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject MdfeRodoviarioVeiculo]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert MdfeRodoviarioVeiculo]', null);
						}

						$objModel = new MdfeRodoviarioVeiculoModel();
						$objModel->mapping($objJson);

						$this->mdfeRodoviarioVeiculoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert MdfeRodoviarioVeiculo]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->mdfeRodoviarioVeiculoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update MdfeRodoviarioVeiculo]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->mdfeRodoviarioVeiculoService->save($objFromDatabase);
								$objFromDatabase = $this->mdfeRodoviarioVeiculoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update MdfeRodoviarioVeiculo]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioVeiculoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete MdfeRodoviarioVeiculo]', null);
						} else {
								$this->mdfeRodoviarioVeiculoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete MdfeRodoviarioVeiculo]', $e);
				}
		}
}
