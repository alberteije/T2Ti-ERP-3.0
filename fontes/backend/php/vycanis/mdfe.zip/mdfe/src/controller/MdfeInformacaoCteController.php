<?php
class MdfeInformacaoCteController extends ControllerBase
{

		private $mdfeInformacaoCteService = null;

		public function __construct()
		{	 
				$this->mdfeInformacaoCteService = new MdfeInformacaoCteService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->mdfeInformacaoCteService->getListFilter($filter);
						} else {
								$resultList = $this->mdfeInformacaoCteService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList MdfeInformacaoCte]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeInformacaoCteService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject MdfeInformacaoCte]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject MdfeInformacaoCte]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert MdfeInformacaoCte]', null);
						}

						$objModel = new MdfeInformacaoCteModel();
						$objModel->mapping($objJson);

						$this->mdfeInformacaoCteService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert MdfeInformacaoCte]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->mdfeInformacaoCteService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update MdfeInformacaoCte]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->mdfeInformacaoCteService->save($objFromDatabase);
								$objFromDatabase = $this->mdfeInformacaoCteService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update MdfeInformacaoCte]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeInformacaoCteService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete MdfeInformacaoCte]', null);
						} else {
								$this->mdfeInformacaoCteService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete MdfeInformacaoCte]', $e);
				}
		}
}
