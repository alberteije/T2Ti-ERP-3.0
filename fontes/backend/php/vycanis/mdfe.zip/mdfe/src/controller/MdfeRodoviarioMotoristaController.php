<?php
class MdfeRodoviarioMotoristaController extends ControllerBase
{

		private $mdfeRodoviarioMotoristaService = null;

		public function __construct()
		{	 
				$this->mdfeRodoviarioMotoristaService = new MdfeRodoviarioMotoristaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->mdfeRodoviarioMotoristaService->getListFilter($filter);
						} else {
								$resultList = $this->mdfeRodoviarioMotoristaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList MdfeRodoviarioMotorista]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioMotoristaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject MdfeRodoviarioMotorista]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject MdfeRodoviarioMotorista]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert MdfeRodoviarioMotorista]', null);
						}

						$objModel = new MdfeRodoviarioMotoristaModel();
						$objModel->mapping($objJson);

						$this->mdfeRodoviarioMotoristaService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert MdfeRodoviarioMotorista]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->mdfeRodoviarioMotoristaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update MdfeRodoviarioMotorista]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->mdfeRodoviarioMotoristaService->save($objFromDatabase);
								$objFromDatabase = $this->mdfeRodoviarioMotoristaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update MdfeRodoviarioMotorista]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioMotoristaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete MdfeRodoviarioMotorista]', null);
						} else {
								$this->mdfeRodoviarioMotoristaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete MdfeRodoviarioMotorista]', $e);
				}
		}
}
