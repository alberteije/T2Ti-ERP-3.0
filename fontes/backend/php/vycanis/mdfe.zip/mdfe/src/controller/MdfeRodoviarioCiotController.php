<?php
class MdfeRodoviarioCiotController extends ControllerBase
{

		private $mdfeRodoviarioCiotService = null;

		public function __construct()
		{	 
				$this->mdfeRodoviarioCiotService = new MdfeRodoviarioCiotService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->mdfeRodoviarioCiotService->getListFilter($filter);
						} else {
								$resultList = $this->mdfeRodoviarioCiotService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList MdfeRodoviarioCiot]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioCiotService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject MdfeRodoviarioCiot]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject MdfeRodoviarioCiot]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert MdfeRodoviarioCiot]', null);
						}

						$objModel = new MdfeRodoviarioCiotModel();
						$objModel->mapping($objJson);

						$this->mdfeRodoviarioCiotService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert MdfeRodoviarioCiot]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->mdfeRodoviarioCiotService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update MdfeRodoviarioCiot]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->mdfeRodoviarioCiotService->save($objFromDatabase);
								$objFromDatabase = $this->mdfeRodoviarioCiotService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update MdfeRodoviarioCiot]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->mdfeRodoviarioCiotService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete MdfeRodoviarioCiot]', null);
						} else {
								$this->mdfeRodoviarioCiotService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete MdfeRodoviarioCiot]', $e);
				}
		}
}
