<?php
declare(strict_types=1);

class MdfeRodoviarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_rodoviario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function mdfeCabecalhoModel()
	{
		return $this->belongsTo(MdfeCabecalhoModel::class, 'id_mdfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getRntrcAttribute()
	{
		return $this->attributes['rntrc'];
	}

	public function setRntrcAttribute($rntrc)
	{
		$this->attributes['rntrc'] = $rntrc;
	}

	public function getCodigoAgendamentoAttribute()
	{
		return $this->attributes['codigo_agendamento'];
	}

	public function setCodigoAgendamentoAttribute($codigoAgendamento)
	{
		$this->attributes['codigo_agendamento'] = $codigoAgendamento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setRntrcAttribute($object->rntrc);
				$this->setCodigoAgendamentoAttribute($object->codigoAgendamento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'rntrc' => $this->getRntrcAttribute(),
				'codigoAgendamento' => $this->getCodigoAgendamentoAttribute(),
			];
	}
}