<?php
declare(strict_types=1);

class UsuarioTokenModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'usuario_token';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getLoginAttribute()
	{
		return $this->attributes['login'];
	}

	public function setLoginAttribute($login)
	{
		$this->attributes['login'] = $login;
	}

	public function getTokenAttribute()
	{
		return $this->attributes['token'];
	}

	public function setTokenAttribute($token)
	{
		$this->attributes['token'] = $token;
	}

	public function getDataCriacaoAttribute()
	{
		return $this->attributes['data_criacao'];
	}

	public function setDataCriacaoAttribute($dataCriacao)
	{
		$this->attributes['data_criacao'] = $dataCriacao;
	}

	public function getHoraCriacaoAttribute()
	{
		return $this->attributes['hora_criacao'];
	}

	public function setHoraCriacaoAttribute($horaCriacao)
	{
		$this->attributes['hora_criacao'] = $horaCriacao;
	}

	public function getDataExpiracaoAttribute()
	{
		return $this->attributes['data_expiracao'];
	}

	public function setDataExpiracaoAttribute($dataExpiracao)
	{
		$this->attributes['data_expiracao'] = $dataExpiracao;
	}

	public function getHoraExpiracaoAttribute()
	{
		return $this->attributes['hora_expiracao'];
	}

	public function setHoraExpiracaoAttribute($horaExpiracao)
	{
		$this->attributes['hora_expiracao'] = $horaExpiracao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setLoginAttribute($object->login);
				$this->setTokenAttribute($object->token);
				$this->setDataCriacaoAttribute($object->dataCriacao);
				$this->setHoraCriacaoAttribute($object->horaCriacao);
				$this->setDataExpiracaoAttribute($object->dataExpiracao);
				$this->setHoraExpiracaoAttribute($object->horaExpiracao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'login' => $this->getLoginAttribute(),
				'token' => $this->getTokenAttribute(),
				'dataCriacao' => $this->getDataCriacaoAttribute(),
				'horaCriacao' => $this->getHoraCriacaoAttribute(),
				'dataExpiracao' => $this->getDataExpiracaoAttribute(),
				'horaExpiracao' => $this->getHoraExpiracaoAttribute(),
			];
	}
}