<?php
declare(strict_types=1);

class MdfeRodoviarioMotoristaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_rodoviario_motorista';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'mdfeRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function mdfeRodoviarioModel()
	{
		return $this->belongsTo(MdfeRodoviarioModel::class, 'id_mdfe_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setCpfAttribute($object->cpf);

				// link objects - lookups
				$mdfeRodoviarioModel = new MdfeRodoviarioModel();
				$mdfeRodoviarioModel->mapping($object->mdfeRodoviarioModel);
				$this->mdfeRodoviarioModel()->associate($mdfeRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'mdfeRodoviarioModel' => $this->mdfeRodoviarioModel,
			];
	}
}