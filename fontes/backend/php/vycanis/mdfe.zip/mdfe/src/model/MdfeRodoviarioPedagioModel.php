<?php
declare(strict_types=1);

class MdfeRodoviarioPedagioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_rodoviario_pedagio';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'mdfeRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function mdfeRodoviarioModel()
	{
		return $this->belongsTo(MdfeRodoviarioModel::class, 'id_mdfe_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjFornecedorAttribute()
	{
		return $this->attributes['cnpj_fornecedor'];
	}

	public function setCnpjFornecedorAttribute($cnpjFornecedor)
	{
		$this->attributes['cnpj_fornecedor'] = $cnpjFornecedor;
	}

	public function getCnpjResponsavelAttribute()
	{
		return $this->attributes['cnpj_responsavel'];
	}

	public function setCnpjResponsavelAttribute($cnpjResponsavel)
	{
		$this->attributes['cnpj_responsavel'] = $cnpjResponsavel;
	}

	public function getCpfResponsavelAttribute()
	{
		return $this->attributes['cpf_responsavel'];
	}

	public function setCpfResponsavelAttribute($cpfResponsavel)
	{
		$this->attributes['cpf_responsavel'] = $cpfResponsavel;
	}

	public function getNumeroComprovanteAttribute()
	{
		return $this->attributes['numero_comprovante'];
	}

	public function setNumeroComprovanteAttribute($numeroComprovante)
	{
		$this->attributes['numero_comprovante'] = $numeroComprovante;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjFornecedorAttribute($object->cnpjFornecedor);
				$this->setCnpjResponsavelAttribute($object->cnpjResponsavel);
				$this->setCpfResponsavelAttribute($object->cpfResponsavel);
				$this->setNumeroComprovanteAttribute($object->numeroComprovante);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
				$mdfeRodoviarioModel = new MdfeRodoviarioModel();
				$mdfeRodoviarioModel->mapping($object->mdfeRodoviarioModel);
				$this->mdfeRodoviarioModel()->associate($mdfeRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpjFornecedor' => $this->getCnpjFornecedorAttribute(),
				'cnpjResponsavel' => $this->getCnpjResponsavelAttribute(),
				'cpfResponsavel' => $this->getCpfResponsavelAttribute(),
				'numeroComprovante' => $this->getNumeroComprovanteAttribute(),
				'valor' => $this->getValorAttribute(),
				'mdfeRodoviarioModel' => $this->mdfeRodoviarioModel,
			];
	}
}