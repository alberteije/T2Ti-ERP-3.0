<?php
declare(strict_types=1);

class MdfePercursoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_percurso';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function mdfeCabecalhoModel()
	{
		return $this->belongsTo(MdfeCabecalhoModel::class, 'id_mdfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getUfPercursoAttribute()
	{
		return $this->attributes['uf_percurso'];
	}

	public function setUfPercursoAttribute($ufPercurso)
	{
		$this->attributes['uf_percurso'] = $ufPercurso;
	}

	public function getDataInicioViagemAttribute()
	{
		return $this->attributes['data_inicio_viagem'];
	}

	public function setDataInicioViagemAttribute($dataInicioViagem)
	{
		$this->attributes['data_inicio_viagem'] = $dataInicioViagem;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setUfPercursoAttribute($object->ufPercurso);
				$this->setDataInicioViagemAttribute($object->dataInicioViagem);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ufPercurso' => $this->getUfPercursoAttribute(),
				'dataInicioViagem' => $this->getDataInicioViagemAttribute(),
			];
	}
}