<?php
declare(strict_types=1);

class MdfeInformacaoNfeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_informacao_nfe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'mdfeMunicipioDescarregaModel',
	];

	/**
		* Relations
		*/
	public function mdfeMunicipioDescarregaModel()
	{
		return $this->belongsTo(MdfeMunicipioDescarregaModel::class, 'id_mdfe_municipio_descarrega', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getChaveNfeAttribute()
	{
		return $this->attributes['chave_nfe'];
	}

	public function setChaveNfeAttribute($chaveNfe)
	{
		$this->attributes['chave_nfe'] = $chaveNfe;
	}

	public function getSegundoCodigoBarraAttribute()
	{
		return $this->attributes['segundo_codigo_barra'];
	}

	public function setSegundoCodigoBarraAttribute($segundoCodigoBarra)
	{
		$this->attributes['segundo_codigo_barra'] = $segundoCodigoBarra;
	}

	public function getIndicadorReentregaAttribute()
	{
		return $this->attributes['indicador_reentrega'];
	}

	public function setIndicadorReentregaAttribute($indicadorReentrega)
	{
		$this->attributes['indicador_reentrega'] = $indicadorReentrega;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setChaveNfeAttribute($object->chaveNfe);
				$this->setSegundoCodigoBarraAttribute($object->segundoCodigoBarra);
				$this->setIndicadorReentregaAttribute($object->indicadorReentrega);

				// link objects - lookups
				$mdfeMunicipioDescarregaModel = new MdfeMunicipioDescarregaModel();
				$mdfeMunicipioDescarregaModel->mapping($object->mdfeMunicipioDescarregaModel);
				$this->mdfeMunicipioDescarregaModel()->associate($mdfeMunicipioDescarregaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'chaveNfe' => $this->getChaveNfeAttribute(),
				'segundoCodigoBarra' => $this->getSegundoCodigoBarraAttribute(),
				'indicadorReentrega' => $this->getIndicadorReentregaAttribute(),
				'mdfeMunicipioDescarregaModel' => $this->mdfeMunicipioDescarregaModel,
			];
	}
}