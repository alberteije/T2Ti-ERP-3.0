<?php
declare(strict_types=1);

class MdfeLacreModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_lacre';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function mdfeCabecalhoModel()
	{
		return $this->belongsTo(MdfeCabecalhoModel::class, 'id_mdfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroLacreAttribute()
	{
		return $this->attributes['numero_lacre'];
	}

	public function setNumeroLacreAttribute($numeroLacre)
	{
		$this->attributes['numero_lacre'] = $numeroLacre;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroLacreAttribute($object->numeroLacre);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroLacre' => $this->getNumeroLacreAttribute(),
			];
	}
}