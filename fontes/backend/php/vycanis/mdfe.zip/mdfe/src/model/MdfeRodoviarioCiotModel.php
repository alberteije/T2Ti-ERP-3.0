<?php
declare(strict_types=1);

class MdfeRodoviarioCiotModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_rodoviario_ciot';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'mdfeRodoviarioModel',
	];

	/**
		* Relations
		*/
	public function mdfeRodoviarioModel()
	{
		return $this->belongsTo(MdfeRodoviarioModel::class, 'id_mdfe_rodoviario', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCiotAttribute()
	{
		return $this->attributes['ciot'];
	}

	public function setCiotAttribute($ciot)
	{
		$this->attributes['ciot'] = $ciot;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCiotAttribute($object->ciot);
				$this->setCpfAttribute($object->cpf);
				$this->setCnpjAttribute($object->cnpj);

				// link objects - lookups
				$mdfeRodoviarioModel = new MdfeRodoviarioModel();
				$mdfeRodoviarioModel->mapping($object->mdfeRodoviarioModel);
				$this->mdfeRodoviarioModel()->associate($mdfeRodoviarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ciot' => $this->getCiotAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'mdfeRodoviarioModel' => $this->mdfeRodoviarioModel,
			];
	}
}