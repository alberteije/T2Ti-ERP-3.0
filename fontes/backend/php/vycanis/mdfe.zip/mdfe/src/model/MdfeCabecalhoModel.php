<?php
declare(strict_types=1);

class MdfeCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'mdfeLacreModelList',
		'mdfeMunicipioDescarregaModelList',
		'mdfeEmitenteModelList',
		'mdfePercursoModelList',
		'mdfeMunicipioCarregamentoModelList',
		'mdfeRodoviarioModelList',
		'mdfeInformacaoSeguroModelList',
	];

	/**
		* Relations
		*/
	public function mdfeLacreModelList()
{
	return $this->hasMany(MdfeLacreModel::class, 'id_mdfe_cabecalho', 'id');
}

	public function mdfeMunicipioDescarregaModelList()
{
	return $this->hasMany(MdfeMunicipioDescarregaModel::class, 'id_mdfe_cabecalho', 'id');
}

	public function mdfeEmitenteModelList()
{
	return $this->hasMany(MdfeEmitenteModel::class, 'id_mdfe_cabecalho', 'id');
}

	public function mdfePercursoModelList()
{
	return $this->hasMany(MdfePercursoModel::class, 'id_mdfe_cabecalho', 'id');
}

	public function mdfeMunicipioCarregamentoModelList()
{
	return $this->hasMany(MdfeMunicipioCarregamentoModel::class, 'id_mdfe_cabecalho', 'id');
}

	public function mdfeRodoviarioModelList()
{
	return $this->hasMany(MdfeRodoviarioModel::class, 'id_mdfe_cabecalho', 'id');
}

	public function mdfeInformacaoSeguroModelList()
{
	return $this->hasMany(MdfeInformacaoSeguroModel::class, 'id_mdfe_cabecalho', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getTipoAmbienteAttribute()
	{
		return $this->attributes['tipo_ambiente'];
	}

	public function setTipoAmbienteAttribute($tipoAmbiente)
	{
		$this->attributes['tipo_ambiente'] = $tipoAmbiente;
	}

	public function getTipoEmitenteAttribute()
	{
		return $this->attributes['tipo_emitente'];
	}

	public function setTipoEmitenteAttribute($tipoEmitente)
	{
		$this->attributes['tipo_emitente'] = $tipoEmitente;
	}

	public function getTipoTransportadoraAttribute()
	{
		return $this->attributes['tipo_transportadora'];
	}

	public function setTipoTransportadoraAttribute($tipoTransportadora)
	{
		$this->attributes['tipo_transportadora'] = $tipoTransportadora;
	}

	public function getModeloAttribute()
	{
		return $this->attributes['modelo'];
	}

	public function setModeloAttribute($modelo)
	{
		$this->attributes['modelo'] = $modelo;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroMdfeAttribute()
	{
		return $this->attributes['numero_mdfe'];
	}

	public function setNumeroMdfeAttribute($numeroMdfe)
	{
		$this->attributes['numero_mdfe'] = $numeroMdfe;
	}

	public function getCodigoNumericoAttribute()
	{
		return $this->attributes['codigo_numerico'];
	}

	public function setCodigoNumericoAttribute($codigoNumerico)
	{
		$this->attributes['codigo_numerico'] = $codigoNumerico;
	}

	public function getChaveAcessoAttribute()
	{
		return $this->attributes['chave_acesso'];
	}

	public function setChaveAcessoAttribute($chaveAcesso)
	{
		$this->attributes['chave_acesso'] = $chaveAcesso;
	}

	public function getDigitoVerificadorAttribute()
	{
		return $this->attributes['digito_verificador'];
	}

	public function setDigitoVerificadorAttribute($digitoVerificador)
	{
		$this->attributes['digito_verificador'] = $digitoVerificador;
	}

	public function getModalAttribute()
	{
		return $this->attributes['modal'];
	}

	public function setModalAttribute($modal)
	{
		$this->attributes['modal'] = $modal;
	}

	public function getDataHoraEmissaoAttribute()
	{
		return $this->attributes['data_hora_emissao'];
	}

	public function setDataHoraEmissaoAttribute($dataHoraEmissao)
	{
		$this->attributes['data_hora_emissao'] = $dataHoraEmissao;
	}

	public function getTipoEmissaoAttribute()
	{
		return $this->attributes['tipo_emissao'];
	}

	public function setTipoEmissaoAttribute($tipoEmissao)
	{
		$this->attributes['tipo_emissao'] = $tipoEmissao;
	}

	public function getProcessoEmissaoAttribute()
	{
		return $this->attributes['processo_emissao'];
	}

	public function setProcessoEmissaoAttribute($processoEmissao)
	{
		$this->attributes['processo_emissao'] = $processoEmissao;
	}

	public function getVersaoProcessoEmissaoAttribute()
	{
		return $this->attributes['versao_processo_emissao'];
	}

	public function setVersaoProcessoEmissaoAttribute($versaoProcessoEmissao)
	{
		$this->attributes['versao_processo_emissao'] = $versaoProcessoEmissao;
	}

	public function getUfInicioAttribute()
	{
		return $this->attributes['uf_inicio'];
	}

	public function setUfInicioAttribute($ufInicio)
	{
		$this->attributes['uf_inicio'] = $ufInicio;
	}

	public function getUfFimAttribute()
	{
		return $this->attributes['uf_fim'];
	}

	public function setUfFimAttribute($ufFim)
	{
		$this->attributes['uf_fim'] = $ufFim;
	}

	public function getDataHoraPrevisaoViagemAttribute()
	{
		return $this->attributes['data_hora_previsao_viagem'];
	}

	public function setDataHoraPrevisaoViagemAttribute($dataHoraPrevisaoViagem)
	{
		$this->attributes['data_hora_previsao_viagem'] = $dataHoraPrevisaoViagem;
	}

	public function getQuantidadeTotalCteAttribute()
	{
		return $this->attributes['quantidade_total_cte'];
	}

	public function setQuantidadeTotalCteAttribute($quantidadeTotalCte)
	{
		$this->attributes['quantidade_total_cte'] = $quantidadeTotalCte;
	}

	public function getQuantidadeTotalNfeAttribute()
	{
		return $this->attributes['quantidade_total_nfe'];
	}

	public function setQuantidadeTotalNfeAttribute($quantidadeTotalNfe)
	{
		$this->attributes['quantidade_total_nfe'] = $quantidadeTotalNfe;
	}

	public function getQuantidadeTotalMdfeAttribute()
	{
		return $this->attributes['quantidade_total_mdfe'];
	}

	public function setQuantidadeTotalMdfeAttribute($quantidadeTotalMdfe)
	{
		$this->attributes['quantidade_total_mdfe'] = $quantidadeTotalMdfe;
	}

	public function getCodigoUnidadeMedidaAttribute()
	{
		return $this->attributes['codigo_unidade_medida'];
	}

	public function setCodigoUnidadeMedidaAttribute($codigoUnidadeMedida)
	{
		$this->attributes['codigo_unidade_medida'] = $codigoUnidadeMedida;
	}

	public function getPesoBrutoCargaAttribute()
	{
		return (double)$this->attributes['peso_bruto_carga'];
	}

	public function setPesoBrutoCargaAttribute($pesoBrutoCarga)
	{
		$this->attributes['peso_bruto_carga'] = $pesoBrutoCarga;
	}

	public function getValorCargaAttribute()
	{
		return (double)$this->attributes['valor_carga'];
	}

	public function setValorCargaAttribute($valorCarga)
	{
		$this->attributes['valor_carga'] = $valorCarga;
	}

	public function getNumeroProtocoloAttribute()
	{
		return $this->attributes['numero_protocolo'];
	}

	public function setNumeroProtocoloAttribute($numeroProtocolo)
	{
		$this->attributes['numero_protocolo'] = $numeroProtocolo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setUfAttribute($object->uf);
				$this->setTipoAmbienteAttribute($object->tipoAmbiente);
				$this->setTipoEmitenteAttribute($object->tipoEmitente);
				$this->setTipoTransportadoraAttribute($object->tipoTransportadora);
				$this->setModeloAttribute($object->modelo);
				$this->setSerieAttribute($object->serie);
				$this->setNumeroMdfeAttribute($object->numeroMdfe);
				$this->setCodigoNumericoAttribute($object->codigoNumerico);
				$this->setChaveAcessoAttribute($object->chaveAcesso);
				$this->setDigitoVerificadorAttribute($object->digitoVerificador);
				$this->setModalAttribute($object->modal);
				$this->setDataHoraEmissaoAttribute($object->dataHoraEmissao);
				$this->setTipoEmissaoAttribute($object->tipoEmissao);
				$this->setProcessoEmissaoAttribute($object->processoEmissao);
				$this->setVersaoProcessoEmissaoAttribute($object->versaoProcessoEmissao);
				$this->setUfInicioAttribute($object->ufInicio);
				$this->setUfFimAttribute($object->ufFim);
				$this->setDataHoraPrevisaoViagemAttribute($object->dataHoraPrevisaoViagem);
				$this->setQuantidadeTotalCteAttribute($object->quantidadeTotalCte);
				$this->setQuantidadeTotalNfeAttribute($object->quantidadeTotalNfe);
				$this->setQuantidadeTotalMdfeAttribute($object->quantidadeTotalMdfe);
				$this->setCodigoUnidadeMedidaAttribute($object->codigoUnidadeMedida);
				$this->setPesoBrutoCargaAttribute($object->pesoBrutoCarga);
				$this->setValorCargaAttribute($object->valorCarga);
				$this->setNumeroProtocoloAttribute($object->numeroProtocolo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'uf' => $this->getUfAttribute(),
				'tipoAmbiente' => $this->getTipoAmbienteAttribute(),
				'tipoEmitente' => $this->getTipoEmitenteAttribute(),
				'tipoTransportadora' => $this->getTipoTransportadoraAttribute(),
				'modelo' => $this->getModeloAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numeroMdfe' => $this->getNumeroMdfeAttribute(),
				'codigoNumerico' => $this->getCodigoNumericoAttribute(),
				'chaveAcesso' => $this->getChaveAcessoAttribute(),
				'digitoVerificador' => $this->getDigitoVerificadorAttribute(),
				'modal' => $this->getModalAttribute(),
				'dataHoraEmissao' => $this->getDataHoraEmissaoAttribute(),
				'tipoEmissao' => $this->getTipoEmissaoAttribute(),
				'processoEmissao' => $this->getProcessoEmissaoAttribute(),
				'versaoProcessoEmissao' => $this->getVersaoProcessoEmissaoAttribute(),
				'ufInicio' => $this->getUfInicioAttribute(),
				'ufFim' => $this->getUfFimAttribute(),
				'dataHoraPrevisaoViagem' => $this->getDataHoraPrevisaoViagemAttribute(),
				'quantidadeTotalCte' => $this->getQuantidadeTotalCteAttribute(),
				'quantidadeTotalNfe' => $this->getQuantidadeTotalNfeAttribute(),
				'quantidadeTotalMdfe' => $this->getQuantidadeTotalMdfeAttribute(),
				'codigoUnidadeMedida' => $this->getCodigoUnidadeMedidaAttribute(),
				'pesoBrutoCarga' => $this->getPesoBrutoCargaAttribute(),
				'valorCarga' => $this->getValorCargaAttribute(),
				'numeroProtocolo' => $this->getNumeroProtocoloAttribute(),
				'mdfeLacreModelList' => $this->mdfeLacreModelList,
				'mdfeMunicipioDescarregaModelList' => $this->mdfeMunicipioDescarregaModelList,
				'mdfeEmitenteModelList' => $this->mdfeEmitenteModelList,
				'mdfePercursoModelList' => $this->mdfePercursoModelList,
				'mdfeMunicipioCarregamentoModelList' => $this->mdfeMunicipioCarregamentoModelList,
				'mdfeRodoviarioModelList' => $this->mdfeRodoviarioModelList,
				'mdfeInformacaoSeguroModelList' => $this->mdfeInformacaoSeguroModelList,
			];
	}
}