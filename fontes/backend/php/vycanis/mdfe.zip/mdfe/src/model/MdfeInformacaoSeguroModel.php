<?php
declare(strict_types=1);

class MdfeInformacaoSeguroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_informacao_seguro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function mdfeCabecalhoModel()
	{
		return $this->belongsTo(MdfeCabecalhoModel::class, 'id_mdfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getResponsavelAttribute()
	{
		return $this->attributes['responsavel'];
	}

	public function setResponsavelAttribute($responsavel)
	{
		$this->attributes['responsavel'] = $responsavel;
	}

	public function getCnpjCpfAttribute()
	{
		return $this->attributes['cnpj_cpf'];
	}

	public function setCnpjCpfAttribute($cnpjCpf)
	{
		$this->attributes['cnpj_cpf'] = $cnpjCpf;
	}

	public function getSeguradoraAttribute()
	{
		return $this->attributes['seguradora'];
	}

	public function setSeguradoraAttribute($seguradora)
	{
		$this->attributes['seguradora'] = $seguradora;
	}

	public function getCnpjSeguradoraAttribute()
	{
		return $this->attributes['cnpj_seguradora'];
	}

	public function setCnpjSeguradoraAttribute($cnpjSeguradora)
	{
		$this->attributes['cnpj_seguradora'] = $cnpjSeguradora;
	}

	public function getApoliceAttribute()
	{
		return $this->attributes['apolice'];
	}

	public function setApoliceAttribute($apolice)
	{
		$this->attributes['apolice'] = $apolice;
	}

	public function getAverbacaoAttribute()
	{
		return $this->attributes['averbacao'];
	}

	public function setAverbacaoAttribute($averbacao)
	{
		$this->attributes['averbacao'] = $averbacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setResponsavelAttribute($object->responsavel);
				$this->setCnpjCpfAttribute($object->cnpjCpf);
				$this->setSeguradoraAttribute($object->seguradora);
				$this->setCnpjSeguradoraAttribute($object->cnpjSeguradora);
				$this->setApoliceAttribute($object->apolice);
				$this->setAverbacaoAttribute($object->averbacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'responsavel' => $this->getResponsavelAttribute(),
				'cnpjCpf' => $this->getCnpjCpfAttribute(),
				'seguradora' => $this->getSeguradoraAttribute(),
				'cnpjSeguradora' => $this->getCnpjSeguradoraAttribute(),
				'apolice' => $this->getApoliceAttribute(),
				'averbacao' => $this->getAverbacaoAttribute(),
			];
	}
}