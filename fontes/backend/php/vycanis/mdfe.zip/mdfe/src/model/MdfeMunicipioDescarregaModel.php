<?php
declare(strict_types=1);

class MdfeMunicipioDescarregaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'mdfe_municipio_descarrega';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function mdfeCabecalhoModel()
	{
		return $this->belongsTo(MdfeCabecalhoModel::class, 'id_mdfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoMunicipioAttribute()
	{
		return $this->attributes['codigo_municipio'];
	}

	public function setCodigoMunicipioAttribute($codigoMunicipio)
	{
		$this->attributes['codigo_municipio'] = $codigoMunicipio;
	}

	public function getNomeMunicipioAttribute()
	{
		return $this->attributes['nome_municipio'];
	}

	public function setNomeMunicipioAttribute($nomeMunicipio)
	{
		$this->attributes['nome_municipio'] = $nomeMunicipio;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoMunicipioAttribute($object->codigoMunicipio);
				$this->setNomeMunicipioAttribute($object->nomeMunicipio);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoMunicipio' => $this->getCodigoMunicipioAttribute(),
				'nomeMunicipio' => $this->getNomeMunicipioAttribute(),
			];
	}
}