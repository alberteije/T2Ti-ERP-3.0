<?php
class MdfeRodoviarioCiotService extends ServiceBase
{
  public function getList()
  {
    return MdfeRodoviarioCiotModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return MdfeRodoviarioCiotModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return MdfeRodoviarioCiotModel::find($id);
  }

}