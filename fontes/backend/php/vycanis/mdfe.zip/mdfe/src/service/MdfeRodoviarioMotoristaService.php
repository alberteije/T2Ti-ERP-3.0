<?php
class MdfeRodoviarioMotoristaService extends ServiceBase
{
  public function getList()
  {
    return MdfeRodoviarioMotoristaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return MdfeRodoviarioMotoristaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return MdfeRodoviarioMotoristaModel::find($id);
  }

}