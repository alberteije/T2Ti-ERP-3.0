<?php
class MdfeRodoviarioVeiculoService extends ServiceBase
{
  public function getList()
  {
    return MdfeRodoviarioVeiculoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return MdfeRodoviarioVeiculoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return MdfeRodoviarioVeiculoModel::find($id);
  }

}