<?php
use Illuminate\Database\Capsule\Manager as DB;
class VendaCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return VendaCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return VendaCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return VendaCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// vendaComissao
		if (isset($objJson->vendaComissaoModel)) {
			$vendaComissaoModel = new VendaComissaoModel();
			$vendaComissaoModel->mapping($objJson->vendaComissaoModel);
			$objModel->vendaComissaoModel()->save($vendaComissaoModel);
		}

		// vendaDetalhe
		$vendaDetalheModelListJson = $objJson->vendaDetalheModelList;
		if ($vendaDetalheModelListJson != null) {
			for ($i = 0; $i < count($vendaDetalheModelListJson); $i++) {
				$vendaDetalhe = new VendaDetalheModel();
				$vendaDetalhe->mapping($vendaDetalheModelListJson[$i]);
				$objModel->vendaDetalheModelList()->save($vendaDetalhe);
			}
		}

		// vendaFrete
		$vendaFreteModelListJson = $objJson->vendaFreteModelList;
		if ($vendaFreteModelListJson != null) {
			for ($i = 0; $i < count($vendaFreteModelListJson); $i++) {
				$vendaFrete = new VendaFreteModel();
				$vendaFrete->mapping($vendaFreteModelListJson[$i]);
				$objModel->vendaFreteModelList()->save($vendaFrete);
			}
		}

	}	

	public function deleteChildren($object)
	{
		VendaComissaoModel::where('id_venda_cabecalho', $object->getIdAttribute())->delete();
		VendaDetalheModel::where('id_venda_cabecalho', $object->getIdAttribute())->delete();
		VendaFreteModel::where('id_venda_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}