<?php
class NotaFiscalModeloService extends ServiceBase
{
  public function getList()
  {
    return NotaFiscalModeloModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NotaFiscalModeloModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NotaFiscalModeloModel::find($id);
  }

}