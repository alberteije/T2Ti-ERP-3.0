<?php
class NotaFiscalTipoService extends ServiceBase
{
  public function getList()
  {
    return NotaFiscalTipoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NotaFiscalTipoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NotaFiscalTipoModel::find($id);
  }

}