<?php
declare(strict_types=1);

class VendaComissaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_comissao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaVendedorModel',
	];

	/**
		* Relations
		*/
	public function vendaCabecalhoModel()
	{
		return $this->belongsTo(VendaCabecalhoModel::class, 'id_venda_cabecalho', 'id');
	}

	public function viewPessoaVendedorModel()
	{
		return $this->belongsTo(ViewPessoaVendedorModel::class, 'id_vendedor', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorVendaAttribute()
	{
		return (double)$this->attributes['valor_venda'];
	}

	public function setValorVendaAttribute($valorVenda)
	{
		$this->attributes['valor_venda'] = $valorVenda;
	}

	public function getTipoContabilAttribute()
	{
		return $this->attributes['tipo_contabil'];
	}

	public function setTipoContabilAttribute($tipoContabil)
	{
		$this->attributes['tipo_contabil'] = $tipoContabil;
	}

	public function getValorComissaoAttribute()
	{
		return (double)$this->attributes['valor_comissao'];
	}

	public function setValorComissaoAttribute($valorComissao)
	{
		$this->attributes['valor_comissao'] = $valorComissao;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	public function getDataLancamentoAttribute()
	{
		return $this->attributes['data_lancamento'];
	}

	public function setDataLancamentoAttribute($dataLancamento)
	{
		$this->attributes['data_lancamento'] = $dataLancamento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorVendaAttribute($object->valorVenda);
				$this->setTipoContabilAttribute($object->tipoContabil);
				$this->setValorComissaoAttribute($object->valorComissao);
				$this->setSituacaoAttribute($object->situacao);
				$this->setDataLancamentoAttribute($object->dataLancamento);

				// link objects - lookups
				$viewPessoaVendedorModel = new ViewPessoaVendedorModel();
				$viewPessoaVendedorModel->mapping($object->viewPessoaVendedorModel);
				$this->viewPessoaVendedorModel()->associate($viewPessoaVendedorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valorVenda' => $this->getValorVendaAttribute(),
				'tipoContabil' => $this->getTipoContabilAttribute(),
				'valorComissao' => $this->getValorComissaoAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'dataLancamento' => $this->getDataLancamentoAttribute(),
				'viewPessoaVendedorModel' => $this->viewPessoaVendedorModel,
			];
	}
}