<?php
declare(strict_types=1);

class VendaOrcamentoCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_orcamento_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'vendaOrcamentoDetalheModelList',
		'vendaCondicoesPagamentoModel',
		'viewPessoaVendedorModel',
		'viewPessoaTransportadoraModel',
		'viewPessoaClienteModel',
	];

	/**
		* Relations
		*/
	public function vendaOrcamentoDetalheModelList()
{
	return $this->hasMany(VendaOrcamentoDetalheModel::class, 'id_venda_orcamento_cabecalho', 'id');
}

	public function vendaCondicoesPagamentoModel()
	{
		return $this->belongsTo(VendaCondicoesPagamentoModel::class, 'id_venda_condicoes_pagamento', 'id');
	}

	public function viewPessoaVendedorModel()
	{
		return $this->belongsTo(ViewPessoaVendedorModel::class, 'id_vendedor', 'id');
	}

	public function viewPessoaTransportadoraModel()
	{
		return $this->belongsTo(ViewPessoaTransportadoraModel::class, 'id_transportadora', 'id');
	}

	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoFreteAttribute()
	{
		return $this->attributes['tipo_frete'];
	}

	public function setTipoFreteAttribute($tipoFrete)
	{
		$this->attributes['tipo_frete'] = $tipoFrete;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getDataEntregaAttribute()
	{
		return $this->attributes['data_entrega'];
	}

	public function setDataEntregaAttribute($dataEntrega)
	{
		$this->attributes['data_entrega'] = $dataEntrega;
	}

	public function getDataValidadeAttribute()
	{
		return $this->attributes['data_validade'];
	}

	public function setDataValidadeAttribute($dataValidade)
	{
		$this->attributes['data_validade'] = $dataValidade;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	public function getTaxaComissaoAttribute()
	{
		return (double)$this->attributes['taxa_comissao'];
	}

	public function setTaxaComissaoAttribute($taxaComissao)
	{
		$this->attributes['taxa_comissao'] = $taxaComissao;
	}

	public function getValorComissaoAttribute()
	{
		return (double)$this->attributes['valor_comissao'];
	}

	public function setValorComissaoAttribute($valorComissao)
	{
		$this->attributes['valor_comissao'] = $valorComissao;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoFreteAttribute($object->tipoFrete);
				$this->setCodigoAttribute($object->codigo);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setDataEntregaAttribute($object->dataEntrega);
				$this->setDataValidadeAttribute($object->dataValidade);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setValorFreteAttribute($object->valorFrete);
				$this->setTaxaComissaoAttribute($object->taxaComissao);
				$this->setValorComissaoAttribute($object->valorComissao);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$vendaCondicoesPagamentoModel = new VendaCondicoesPagamentoModel();
				$vendaCondicoesPagamentoModel->mapping($object->vendaCondicoesPagamentoModel);
				$this->vendaCondicoesPagamentoModel()->associate($vendaCondicoesPagamentoModel);
				$viewPessoaVendedorModel = new ViewPessoaVendedorModel();
				$viewPessoaVendedorModel->mapping($object->viewPessoaVendedorModel);
				$this->viewPessoaVendedorModel()->associate($viewPessoaVendedorModel);
				$viewPessoaTransportadoraModel = new ViewPessoaTransportadoraModel();
				$viewPessoaTransportadoraModel->mapping($object->viewPessoaTransportadoraModel);
				$this->viewPessoaTransportadoraModel()->associate($viewPessoaTransportadoraModel);
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipoFrete' => $this->getTipoFreteAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'dataEntrega' => $this->getDataEntregaAttribute(),
				'dataValidade' => $this->getDataValidadeAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
				'taxaComissao' => $this->getTaxaComissaoAttribute(),
				'valorComissao' => $this->getValorComissaoAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'vendaOrcamentoDetalheModelList' => $this->vendaOrcamentoDetalheModelList,
				'vendaCondicoesPagamentoModel' => $this->vendaCondicoesPagamentoModel,
				'viewPessoaVendedorModel' => $this->viewPessoaVendedorModel,
				'viewPessoaTransportadoraModel' => $this->viewPessoaTransportadoraModel,
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
			];
	}
}