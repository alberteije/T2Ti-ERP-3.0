<?php
declare(strict_types=1);

class VendaCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'vendaComissaoModel',
		'vendaDetalheModelList',
		'vendaFreteModelList',
		'vendaCondicoesPagamentoModel',
		'viewPessoaVendedorModel',
		'viewPessoaTransportadoraModel',
		'viewPessoaClienteModel',
		'vendaOrcamentoCabecalhoModel',
		'notaFiscalTipoModel',
	];

	/**
		* Relations
		*/
	public function vendaComissaoModel()
	{
		return $this->hasOne(VendaComissaoModel::class, 'id_venda_cabecalho', 'id');
	}

	public function vendaDetalheModelList()
{
	return $this->hasMany(VendaDetalheModel::class, 'id_venda_cabecalho', 'id');
}

	public function vendaFreteModelList()
{
	return $this->hasMany(VendaFreteModel::class, 'id_venda_cabecalho', 'id');
}

	public function vendaCondicoesPagamentoModel()
	{
		return $this->belongsTo(VendaCondicoesPagamentoModel::class, 'id_venda_condicoes_pagamento', 'id');
	}

	public function viewPessoaVendedorModel()
	{
		return $this->belongsTo(ViewPessoaVendedorModel::class, 'id_vendedor', 'id');
	}

	public function viewPessoaTransportadoraModel()
	{
		return $this->belongsTo(ViewPessoaTransportadoraModel::class, 'id_transportadora', 'id');
	}

	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}

	public function vendaOrcamentoCabecalhoModel()
	{
		return $this->belongsTo(VendaOrcamentoCabecalhoModel::class, 'id_venda_orcamento_cabecalho', 'id');
	}

	public function notaFiscalTipoModel()
	{
		return $this->belongsTo(NotaFiscalTipoModel::class, 'id_nota_fiscal_tipo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getLocalEntregaAttribute()
	{
		return $this->attributes['local_entrega'];
	}

	public function setLocalEntregaAttribute($localEntrega)
	{
		$this->attributes['local_entrega'] = $localEntrega;
	}

	public function getLocalCobrancaAttribute()
	{
		return $this->attributes['local_cobranca'];
	}

	public function setLocalCobrancaAttribute($localCobranca)
	{
		$this->attributes['local_cobranca'] = $localCobranca;
	}

	public function getTipoFreteAttribute()
	{
		return $this->attributes['tipo_frete'];
	}

	public function setTipoFreteAttribute($tipoFrete)
	{
		$this->attributes['tipo_frete'] = $tipoFrete;
	}

	public function getFormaPagamentoAttribute()
	{
		return $this->attributes['forma_pagamento'];
	}

	public function setFormaPagamentoAttribute($formaPagamento)
	{
		$this->attributes['forma_pagamento'] = $formaPagamento;
	}

	public function getDataVendaAttribute()
	{
		return $this->attributes['data_venda'];
	}

	public function setDataVendaAttribute($dataVenda)
	{
		$this->attributes['data_venda'] = $dataVenda;
	}

	public function getDataSaidaAttribute()
	{
		return $this->attributes['data_saida'];
	}

	public function setDataSaidaAttribute($dataSaida)
	{
		$this->attributes['data_saida'] = $dataSaida;
	}

	public function getHoraSaidaAttribute()
	{
		return $this->attributes['hora_saida'];
	}

	public function setHoraSaidaAttribute($horaSaida)
	{
		$this->attributes['hora_saida'] = $horaSaida;
	}

	public function getNumeroFaturaAttribute()
	{
		return $this->attributes['numero_fatura'];
	}

	public function setNumeroFaturaAttribute($numeroFatura)
	{
		$this->attributes['numero_fatura'] = $numeroFatura;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	public function getValorSeguroAttribute()
	{
		return (double)$this->attributes['valor_seguro'];
	}

	public function setValorSeguroAttribute($valorSeguro)
	{
		$this->attributes['valor_seguro'] = $valorSeguro;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getTaxaComissaoAttribute()
	{
		return (double)$this->attributes['taxa_comissao'];
	}

	public function setTaxaComissaoAttribute($taxaComissao)
	{
		$this->attributes['taxa_comissao'] = $taxaComissao;
	}

	public function getValorComissaoAttribute()
	{
		return (double)$this->attributes['valor_comissao'];
	}

	public function setValorComissaoAttribute($valorComissao)
	{
		$this->attributes['valor_comissao'] = $valorComissao;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	public function getDiaFixoParcelaAttribute()
	{
		return $this->attributes['dia_fixo_parcela'];
	}

	public function setDiaFixoParcelaAttribute($diaFixoParcela)
	{
		$this->attributes['dia_fixo_parcela'] = $diaFixoParcela;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setLocalEntregaAttribute($object->localEntrega);
				$this->setLocalCobrancaAttribute($object->localCobranca);
				$this->setTipoFreteAttribute($object->tipoFrete);
				$this->setFormaPagamentoAttribute($object->formaPagamento);
				$this->setDataVendaAttribute($object->dataVenda);
				$this->setDataSaidaAttribute($object->dataSaida);
				$this->setHoraSaidaAttribute($object->horaSaida);
				$this->setNumeroFaturaAttribute($object->numeroFatura);
				$this->setValorFreteAttribute($object->valorFrete);
				$this->setValorSeguroAttribute($object->valorSeguro);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setTaxaComissaoAttribute($object->taxaComissao);
				$this->setValorComissaoAttribute($object->valorComissao);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setSituacaoAttribute($object->situacao);
				$this->setDiaFixoParcelaAttribute($object->diaFixoParcela);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$vendaCondicoesPagamentoModel = new VendaCondicoesPagamentoModel();
				$vendaCondicoesPagamentoModel->mapping($object->vendaCondicoesPagamentoModel);
				$this->vendaCondicoesPagamentoModel()->associate($vendaCondicoesPagamentoModel);
				$viewPessoaVendedorModel = new ViewPessoaVendedorModel();
				$viewPessoaVendedorModel->mapping($object->viewPessoaVendedorModel);
				$this->viewPessoaVendedorModel()->associate($viewPessoaVendedorModel);
				$viewPessoaTransportadoraModel = new ViewPessoaTransportadoraModel();
				$viewPessoaTransportadoraModel->mapping($object->viewPessoaTransportadoraModel);
				$this->viewPessoaTransportadoraModel()->associate($viewPessoaTransportadoraModel);
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
				$vendaOrcamentoCabecalhoModel = new VendaOrcamentoCabecalhoModel();
				$vendaOrcamentoCabecalhoModel->mapping($object->vendaOrcamentoCabecalhoModel);
				$this->vendaOrcamentoCabecalhoModel()->associate($vendaOrcamentoCabecalhoModel);
				$notaFiscalTipoModel = new NotaFiscalTipoModel();
				$notaFiscalTipoModel->mapping($object->notaFiscalTipoModel);
				$this->notaFiscalTipoModel()->associate($notaFiscalTipoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'localEntrega' => $this->getLocalEntregaAttribute(),
				'localCobranca' => $this->getLocalCobrancaAttribute(),
				'tipoFrete' => $this->getTipoFreteAttribute(),
				'formaPagamento' => $this->getFormaPagamentoAttribute(),
				'dataVenda' => $this->getDataVendaAttribute(),
				'dataSaida' => $this->getDataSaidaAttribute(),
				'horaSaida' => $this->getHoraSaidaAttribute(),
				'numeroFatura' => $this->getNumeroFaturaAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
				'valorSeguro' => $this->getValorSeguroAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'taxaComissao' => $this->getTaxaComissaoAttribute(),
				'valorComissao' => $this->getValorComissaoAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'diaFixoParcela' => $this->getDiaFixoParcelaAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'vendaComissaoModel' => $this->vendaComissaoModel,
				'vendaDetalheModelList' => $this->vendaDetalheModelList,
				'vendaFreteModelList' => $this->vendaFreteModelList,
				'vendaCondicoesPagamentoModel' => $this->vendaCondicoesPagamentoModel,
				'viewPessoaVendedorModel' => $this->viewPessoaVendedorModel,
				'viewPessoaTransportadoraModel' => $this->viewPessoaTransportadoraModel,
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
				'vendaOrcamentoCabecalhoModel' => $this->vendaOrcamentoCabecalhoModel,
				'notaFiscalTipoModel' => $this->notaFiscalTipoModel,
			];
	}
}