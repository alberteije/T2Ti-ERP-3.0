<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'ProdutoModel.php';
include 'VendaOrcamentoDetalheModel.php';
include 'VendaDetalheModel.php';
include 'VendaCondicoesParcelasModel.php';
include 'VendaFreteModel.php';
include 'VendaComissaoModel.php';
include 'ProdutoGrupoModel.php';
include 'ProdutoSubgrupoModel.php';
include 'ProdutoMarcaModel.php';
include 'ProdutoUnidadeModel.php';
include 'VendaCondicoesPagamentoModel.php';
include 'VendaOrcamentoCabecalhoModel.php';
include 'VendaCabecalhoModel.php';
include 'NotaFiscalModeloModel.php';
include 'NotaFiscalTipoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaClienteModel.php';
include 'ViewPessoaVendedorModel.php';
include 'ViewPessoaTransportadoraModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';