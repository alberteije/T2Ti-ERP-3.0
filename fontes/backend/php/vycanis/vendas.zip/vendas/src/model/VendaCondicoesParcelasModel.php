<?php
declare(strict_types=1);

class VendaCondicoesParcelasModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_condicoes_parcelas';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function vendaCondicoesPagamentoModel()
	{
		return $this->belongsTo(VendaCondicoesPagamentoModel::class, 'id_venda_condicoes_pagamento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getParcelaAttribute()
	{
		return $this->attributes['parcela'];
	}

	public function setParcelaAttribute($parcela)
	{
		$this->attributes['parcela'] = $parcela;
	}

	public function getDiasAttribute()
	{
		return $this->attributes['dias'];
	}

	public function setDiasAttribute($dias)
	{
		$this->attributes['dias'] = $dias;
	}

	public function getTaxaAttribute()
	{
		return (double)$this->attributes['taxa'];
	}

	public function setTaxaAttribute($taxa)
	{
		$this->attributes['taxa'] = $taxa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setParcelaAttribute($object->parcela);
				$this->setDiasAttribute($object->dias);
				$this->setTaxaAttribute($object->taxa);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'parcela' => $this->getParcelaAttribute(),
				'dias' => $this->getDiasAttribute(),
				'taxa' => $this->getTaxaAttribute(),
			];
	}
}