<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// produto-grupo
$app->get('/produto-grupo[/]', \ProdutoGrupoController::class . RESULT_LIST);
$app->get('/produto-grupo/{id}', \ProdutoGrupoController::class . RESULT_OBJECT);
$app->post('/produto-grupo', \ProdutoGrupoController::class . INSERT);
$app->put('/produto-grupo', \ProdutoGrupoController::class . UPDATE);
$app->delete('/produto-grupo/{id}', \ProdutoGrupoController::class . DELETE);
$app->options('/produto-grupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-subgrupo
$app->get('/produto-subgrupo[/]', \ProdutoSubgrupoController::class . RESULT_LIST);
$app->get('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . RESULT_OBJECT);
$app->post('/produto-subgrupo', \ProdutoSubgrupoController::class . INSERT);
$app->put('/produto-subgrupo', \ProdutoSubgrupoController::class . UPDATE);
$app->delete('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . DELETE);
$app->options('/produto-subgrupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-marca
$app->get('/produto-marca[/]', \ProdutoMarcaController::class . RESULT_LIST);
$app->get('/produto-marca/{id}', \ProdutoMarcaController::class . RESULT_OBJECT);
$app->post('/produto-marca', \ProdutoMarcaController::class . INSERT);
$app->put('/produto-marca', \ProdutoMarcaController::class . UPDATE);
$app->delete('/produto-marca/{id}', \ProdutoMarcaController::class . DELETE);
$app->options('/produto-marca', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-unidade
$app->get('/produto-unidade[/]', \ProdutoUnidadeController::class . RESULT_LIST);
$app->get('/produto-unidade/{id}', \ProdutoUnidadeController::class . RESULT_OBJECT);
$app->post('/produto-unidade', \ProdutoUnidadeController::class . INSERT);
$app->put('/produto-unidade', \ProdutoUnidadeController::class . UPDATE);
$app->delete('/produto-unidade/{id}', \ProdutoUnidadeController::class . DELETE);
$app->options('/produto-unidade', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// venda-condicoes-pagamento
$app->get('/venda-condicoes-pagamento[/]', \VendaCondicoesPagamentoController::class . RESULT_LIST);
$app->get('/venda-condicoes-pagamento/{id}', \VendaCondicoesPagamentoController::class . RESULT_OBJECT);
$app->post('/venda-condicoes-pagamento', \VendaCondicoesPagamentoController::class . INSERT);
$app->put('/venda-condicoes-pagamento', \VendaCondicoesPagamentoController::class . UPDATE);
$app->delete('/venda-condicoes-pagamento/{id}', \VendaCondicoesPagamentoController::class . DELETE);
$app->options('/venda-condicoes-pagamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/venda-condicoes-pagamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/venda-condicoes-pagamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// venda-orcamento-cabecalho
$app->get('/venda-orcamento-cabecalho[/]', \VendaOrcamentoCabecalhoController::class . RESULT_LIST);
$app->get('/venda-orcamento-cabecalho/{id}', \VendaOrcamentoCabecalhoController::class . RESULT_OBJECT);
$app->post('/venda-orcamento-cabecalho', \VendaOrcamentoCabecalhoController::class . INSERT);
$app->put('/venda-orcamento-cabecalho', \VendaOrcamentoCabecalhoController::class . UPDATE);
$app->delete('/venda-orcamento-cabecalho/{id}', \VendaOrcamentoCabecalhoController::class . DELETE);
$app->options('/venda-orcamento-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/venda-orcamento-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/venda-orcamento-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// venda-cabecalho
$app->get('/venda-cabecalho[/]', \VendaCabecalhoController::class . RESULT_LIST);
$app->get('/venda-cabecalho/{id}', \VendaCabecalhoController::class . RESULT_OBJECT);
$app->post('/venda-cabecalho', \VendaCabecalhoController::class . INSERT);
$app->put('/venda-cabecalho', \VendaCabecalhoController::class . UPDATE);
$app->delete('/venda-cabecalho/{id}', \VendaCabecalhoController::class . DELETE);
$app->options('/venda-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/venda-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/venda-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// nota-fiscal-modelo
$app->get('/nota-fiscal-modelo[/]', \NotaFiscalModeloController::class . RESULT_LIST);
$app->get('/nota-fiscal-modelo/{id}', \NotaFiscalModeloController::class . RESULT_OBJECT);
$app->post('/nota-fiscal-modelo', \NotaFiscalModeloController::class . INSERT);
$app->put('/nota-fiscal-modelo', \NotaFiscalModeloController::class . UPDATE);
$app->delete('/nota-fiscal-modelo/{id}', \NotaFiscalModeloController::class . DELETE);
$app->options('/nota-fiscal-modelo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nota-fiscal-modelo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nota-fiscal-modelo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// nota-fiscal-tipo
$app->get('/nota-fiscal-tipo[/]', \NotaFiscalTipoController::class . RESULT_LIST);
$app->get('/nota-fiscal-tipo/{id}', \NotaFiscalTipoController::class . RESULT_OBJECT);
$app->post('/nota-fiscal-tipo', \NotaFiscalTipoController::class . INSERT);
$app->put('/nota-fiscal-tipo', \NotaFiscalTipoController::class . UPDATE);
$app->delete('/nota-fiscal-tipo/{id}', \NotaFiscalTipoController::class . DELETE);
$app->options('/nota-fiscal-tipo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nota-fiscal-tipo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nota-fiscal-tipo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-cliente
$app->get('/view-pessoa-cliente[/]', \ViewPessoaClienteController::class . RESULT_LIST);
$app->get('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . RESULT_OBJECT);
$app->post('/view-pessoa-cliente', \ViewPessoaClienteController::class . INSERT);
$app->put('/view-pessoa-cliente', \ViewPessoaClienteController::class . UPDATE);
$app->delete('/view-pessoa-cliente/{id}', \ViewPessoaClienteController::class . DELETE);
$app->options('/view-pessoa-cliente', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-cliente/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-vendedor
$app->get('/view-pessoa-vendedor[/]', \ViewPessoaVendedorController::class . RESULT_LIST);
$app->get('/view-pessoa-vendedor/{id}', \ViewPessoaVendedorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-vendedor', \ViewPessoaVendedorController::class . INSERT);
$app->put('/view-pessoa-vendedor', \ViewPessoaVendedorController::class . UPDATE);
$app->delete('/view-pessoa-vendedor/{id}', \ViewPessoaVendedorController::class . DELETE);
$app->options('/view-pessoa-vendedor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-vendedor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-vendedor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-transportadora
$app->get('/view-pessoa-transportadora[/]', \ViewPessoaTransportadoraController::class . RESULT_LIST);
$app->get('/view-pessoa-transportadora/{id}', \ViewPessoaTransportadoraController::class . RESULT_OBJECT);
$app->post('/view-pessoa-transportadora', \ViewPessoaTransportadoraController::class . INSERT);
$app->put('/view-pessoa-transportadora', \ViewPessoaTransportadoraController::class . UPDATE);
$app->delete('/view-pessoa-transportadora/{id}', \ViewPessoaTransportadoraController::class . DELETE);
$app->options('/view-pessoa-transportadora', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-transportadora/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-transportadora/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

