<?php
use Illuminate\Database\Capsule\Manager as DB;
class ProdutoGrupoService extends ServiceBase
{
	public function getList()
	{
		return ProdutoGrupoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ProdutoGrupoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ProdutoGrupoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// produtoSubgrupo
		$produtoSubgrupoModelListJson = $objJson->produtoSubgrupoModelList;
		if ($produtoSubgrupoModelListJson != null) {
			for ($i = 0; $i < count($produtoSubgrupoModelListJson); $i++) {
				$produtoSubgrupo = new ProdutoSubgrupoModel();
				$produtoSubgrupo->mapping($produtoSubgrupoModelListJson[$i]);
				$objModel->produtoSubgrupoModelList()->save($produtoSubgrupo);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ProdutoSubgrupoModel::where('id_produto_grupo', $object->getIdAttribute())->delete();
	}	
 
}