<?php
use Illuminate\Database\Capsule\Manager as DB;
class VendaCondicoesPagamentoService extends ServiceBase
{
	public function getList()
	{
		return VendaCondicoesPagamentoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return VendaCondicoesPagamentoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return VendaCondicoesPagamentoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// vendaCondicoesParcelas
		$vendaCondicoesParcelasModelListJson = $objJson->vendaCondicoesParcelasModelList;
		if ($vendaCondicoesParcelasModelListJson != null) {
			for ($i = 0; $i < count($vendaCondicoesParcelasModelListJson); $i++) {
				$vendaCondicoesParcelas = new VendaCondicoesParcelasModel();
				$vendaCondicoesParcelas->mapping($vendaCondicoesParcelasModelListJson[$i]);
				$objModel->vendaCondicoesParcelasModelList()->save($vendaCondicoesParcelas);
			}
		}

	}	

	public function deleteChildren($object)
	{
		VendaCondicoesParcelasModel::where('id_venda_condicoes_pagamento', $object->getIdAttribute())->delete();
	}	
 
}