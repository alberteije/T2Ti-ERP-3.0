<?php
use Illuminate\Database\Capsule\Manager as DB;
class VendaOrcamentoCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return VendaOrcamentoCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return VendaOrcamentoCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return VendaOrcamentoCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// vendaOrcamentoDetalhe
		$vendaOrcamentoDetalheModelListJson = $objJson->vendaOrcamentoDetalheModelList;
		if ($vendaOrcamentoDetalheModelListJson != null) {
			for ($i = 0; $i < count($vendaOrcamentoDetalheModelListJson); $i++) {
				$vendaOrcamentoDetalhe = new VendaOrcamentoDetalheModel();
				$vendaOrcamentoDetalhe->mapping($vendaOrcamentoDetalheModelListJson[$i]);
				$objModel->vendaOrcamentoDetalheModelList()->save($vendaOrcamentoDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		VendaOrcamentoDetalheModel::where('id_venda_orcamento_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}