<?php
class VendaOrcamentoCabecalhoController extends ControllerBase
{

		private $vendaOrcamentoCabecalhoService = null;

		public function __construct()
		{	 
				$this->vendaOrcamentoCabecalhoService = new VendaOrcamentoCabecalhoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->vendaOrcamentoCabecalhoService->getListFilter($filter);
						} else {
								$resultList = $this->vendaOrcamentoCabecalhoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList VendaOrcamentoCabecalho]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->vendaOrcamentoCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject VendaOrcamentoCabecalho]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject VendaOrcamentoCabecalho]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert VendaOrcamentoCabecalho]', null);
						}

						$objModel = new VendaOrcamentoCabecalhoModel();
						$objModel->mapping($objJson);

						$this->vendaOrcamentoCabecalhoService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert VendaOrcamentoCabecalho]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->vendaOrcamentoCabecalhoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update VendaOrcamentoCabecalho]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->vendaOrcamentoCabecalhoService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->vendaOrcamentoCabecalhoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update VendaOrcamentoCabecalho]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->vendaOrcamentoCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete VendaOrcamentoCabecalho]', null);
						} else {
								$this->vendaOrcamentoCabecalhoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete VendaOrcamentoCabecalho]', $e);
				}
		}
}
