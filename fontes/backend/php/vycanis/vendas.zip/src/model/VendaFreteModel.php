<?php
declare(strict_types=1);

class VendaFreteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_frete';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaTransportadoraModel',
	];

	/**
		* Relations
		*/
	public function vendaCabecalhoModel()
	{
		return $this->belongsTo(VendaCabecalhoModel::class, 'id_venda_cabecalho', 'id');
	}

	public function viewPessoaTransportadoraModel()
	{
		return $this->belongsTo(ViewPessoaTransportadoraModel::class, 'id_transportadora', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getResponsavelAttribute()
	{
		return $this->attributes['responsavel'];
	}

	public function setResponsavelAttribute($responsavel)
	{
		$this->attributes['responsavel'] = $responsavel;
	}

	public function getConhecimentoAttribute()
	{
		return $this->attributes['conhecimento'];
	}

	public function setConhecimentoAttribute($conhecimento)
	{
		$this->attributes['conhecimento'] = $conhecimento;
	}

	public function getPlacaAttribute()
	{
		return $this->attributes['placa'];
	}

	public function setPlacaAttribute($placa)
	{
		$this->attributes['placa'] = $placa;
	}

	public function getUfPlacaAttribute()
	{
		return $this->attributes['uf_placa'];
	}

	public function setUfPlacaAttribute($ufPlaca)
	{
		$this->attributes['uf_placa'] = $ufPlaca;
	}

	public function getSeloFiscalAttribute()
	{
		return $this->attributes['selo_fiscal'];
	}

	public function setSeloFiscalAttribute($seloFiscal)
	{
		$this->attributes['selo_fiscal'] = $seloFiscal;
	}

	public function getQuantidadeVolumeAttribute()
	{
		return (double)$this->attributes['quantidade_volume'];
	}

	public function setQuantidadeVolumeAttribute($quantidadeVolume)
	{
		$this->attributes['quantidade_volume'] = $quantidadeVolume;
	}

	public function getMarcaVolumeAttribute()
	{
		return $this->attributes['marca_volume'];
	}

	public function setMarcaVolumeAttribute($marcaVolume)
	{
		$this->attributes['marca_volume'] = $marcaVolume;
	}

	public function getEspecieVolumeAttribute()
	{
		return $this->attributes['especie_volume'];
	}

	public function setEspecieVolumeAttribute($especieVolume)
	{
		$this->attributes['especie_volume'] = $especieVolume;
	}

	public function getPesoBrutoAttribute()
	{
		return (double)$this->attributes['peso_bruto'];
	}

	public function setPesoBrutoAttribute($pesoBruto)
	{
		$this->attributes['peso_bruto'] = $pesoBruto;
	}

	public function getPesoLiquidoAttribute()
	{
		return (double)$this->attributes['peso_liquido'];
	}

	public function setPesoLiquidoAttribute($pesoLiquido)
	{
		$this->attributes['peso_liquido'] = $pesoLiquido;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setResponsavelAttribute($object->responsavel);
				$this->setConhecimentoAttribute($object->conhecimento);
				$this->setPlacaAttribute($object->placa);
				$this->setUfPlacaAttribute($object->ufPlaca);
				$this->setSeloFiscalAttribute($object->seloFiscal);
				$this->setQuantidadeVolumeAttribute($object->quantidadeVolume);
				$this->setMarcaVolumeAttribute($object->marcaVolume);
				$this->setEspecieVolumeAttribute($object->especieVolume);
				$this->setPesoBrutoAttribute($object->pesoBruto);
				$this->setPesoLiquidoAttribute($object->pesoLiquido);

				// link objects - lookups
				$viewPessoaTransportadoraModel = new ViewPessoaTransportadoraModel();
				$viewPessoaTransportadoraModel->mapping($object->viewPessoaTransportadoraModel);
				$this->viewPessoaTransportadoraModel()->associate($viewPessoaTransportadoraModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'responsavel' => $this->getResponsavelAttribute(),
				'conhecimento' => $this->getConhecimentoAttribute(),
				'placa' => $this->getPlacaAttribute(),
				'ufPlaca' => $this->getUfPlacaAttribute(),
				'seloFiscal' => $this->getSeloFiscalAttribute(),
				'quantidadeVolume' => $this->getQuantidadeVolumeAttribute(),
				'marcaVolume' => $this->getMarcaVolumeAttribute(),
				'especieVolume' => $this->getEspecieVolumeAttribute(),
				'pesoBruto' => $this->getPesoBrutoAttribute(),
				'pesoLiquido' => $this->getPesoLiquidoAttribute(),
				'viewPessoaTransportadoraModel' => $this->viewPessoaTransportadoraModel,
			];
	}
}