<?php
declare(strict_types=1);

class NotaFiscalTipoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nota_fiscal_tipo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'notaFiscalModeloModel',
	];

	/**
		* Relations
		*/
	public function notaFiscalModeloModel()
	{
		return $this->belongsTo(NotaFiscalModeloModel::class, 'id_nota_fiscal_modelo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getSerieScanAttribute()
	{
		return $this->attributes['serie_scan'];
	}

	public function setSerieScanAttribute($serieScan)
	{
		$this->attributes['serie_scan'] = $serieScan;
	}

	public function getUltimoNumeroAttribute()
	{
		return $this->attributes['ultimo_numero'];
	}

	public function setUltimoNumeroAttribute($ultimoNumero)
	{
		$this->attributes['ultimo_numero'] = $ultimoNumero;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setSerieAttribute($object->serie);
				$this->setSerieScanAttribute($object->serieScan);
				$this->setUltimoNumeroAttribute($object->ultimoNumero);

				// link objects - lookups
				$notaFiscalModeloModel = new NotaFiscalModeloModel();
				$notaFiscalModeloModel->mapping($object->notaFiscalModeloModel);
				$this->notaFiscalModeloModel()->associate($notaFiscalModeloModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'serie' => $this->getSerieAttribute(),
				'serieScan' => $this->getSerieScanAttribute(),
				'ultimoNumero' => $this->getUltimoNumeroAttribute(),
				'notaFiscalModeloModel' => $this->notaFiscalModeloModel,
			];
	}
}