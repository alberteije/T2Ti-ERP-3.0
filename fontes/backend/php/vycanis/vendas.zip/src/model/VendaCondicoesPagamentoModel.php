<?php
declare(strict_types=1);

class VendaCondicoesPagamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_condicoes_pagamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'vendaCondicoesParcelasModelList',
	];

	/**
		* Relations
		*/
	public function vendaCondicoesParcelasModelList()
{
	return $this->hasMany(VendaCondicoesParcelasModel::class, 'id_venda_condicoes_pagamento', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getFaturamentoMinimoAttribute()
	{
		return (double)$this->attributes['faturamento_minimo'];
	}

	public function setFaturamentoMinimoAttribute($faturamentoMinimo)
	{
		$this->attributes['faturamento_minimo'] = $faturamentoMinimo;
	}

	public function getFaturamentoMaximoAttribute()
	{
		return (double)$this->attributes['faturamento_maximo'];
	}

	public function setFaturamentoMaximoAttribute($faturamentoMaximo)
	{
		$this->attributes['faturamento_maximo'] = $faturamentoMaximo;
	}

	public function getIndiceCorrecaoAttribute()
	{
		return (double)$this->attributes['indice_correcao'];
	}

	public function setIndiceCorrecaoAttribute($indiceCorrecao)
	{
		$this->attributes['indice_correcao'] = $indiceCorrecao;
	}

	public function getDiasToleranciaAttribute()
	{
		return $this->attributes['dias_tolerancia'];
	}

	public function setDiasToleranciaAttribute($diasTolerancia)
	{
		$this->attributes['dias_tolerancia'] = $diasTolerancia;
	}

	public function getValorToleranciaAttribute()
	{
		return (double)$this->attributes['valor_tolerancia'];
	}

	public function setValorToleranciaAttribute($valorTolerancia)
	{
		$this->attributes['valor_tolerancia'] = $valorTolerancia;
	}

	public function getPrazoMedioAttribute()
	{
		return $this->attributes['prazo_medio'];
	}

	public function setPrazoMedioAttribute($prazoMedio)
	{
		$this->attributes['prazo_medio'] = $prazoMedio;
	}

	public function getVistaPrazoAttribute()
	{
		return $this->attributes['vista_prazo'];
	}

	public function setVistaPrazoAttribute($vistaPrazo)
	{
		$this->attributes['vista_prazo'] = $vistaPrazo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setFaturamentoMinimoAttribute($object->faturamentoMinimo);
				$this->setFaturamentoMaximoAttribute($object->faturamentoMaximo);
				$this->setIndiceCorrecaoAttribute($object->indiceCorrecao);
				$this->setDiasToleranciaAttribute($object->diasTolerancia);
				$this->setValorToleranciaAttribute($object->valorTolerancia);
				$this->setPrazoMedioAttribute($object->prazoMedio);
				$this->setVistaPrazoAttribute($object->vistaPrazo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'faturamentoMinimo' => $this->getFaturamentoMinimoAttribute(),
				'faturamentoMaximo' => $this->getFaturamentoMaximoAttribute(),
				'indiceCorrecao' => $this->getIndiceCorrecaoAttribute(),
				'diasTolerancia' => $this->getDiasToleranciaAttribute(),
				'valorTolerancia' => $this->getValorToleranciaAttribute(),
				'prazoMedio' => $this->getPrazoMedioAttribute(),
				'vistaPrazo' => $this->getVistaPrazoAttribute(),
				'vendaCondicoesParcelasModelList' => $this->vendaCondicoesParcelasModelList,
			];
	}
}