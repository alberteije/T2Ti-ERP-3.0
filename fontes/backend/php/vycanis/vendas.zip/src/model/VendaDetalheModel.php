<?php
declare(strict_types=1);

class VendaDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'produtoModel',
	];

	/**
		* Relations
		*/
	public function vendaCabecalhoModel()
	{
		return $this->belongsTo(VendaCabecalhoModel::class, 'id_venda_cabecalho', 'id');
	}

	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return (double)$this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getValorUnitarioAttribute()
	{
		return (double)$this->attributes['valor_unitario'];
	}

	public function setValorUnitarioAttribute($valorUnitario)
	{
		$this->attributes['valor_unitario'] = $valorUnitario;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);
				$this->setValorUnitarioAttribute($object->valorUnitario);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorTotalAttribute($object->valorTotal);

				// link objects - lookups
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'valorUnitario' => $this->getValorUnitarioAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'produtoModel' => $this->produtoModel,
			];
	}
}