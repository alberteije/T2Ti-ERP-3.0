<?php
declare(strict_types=1);

class TributIcmsUfModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'tribut_icms_uf';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function tributConfiguraOfGtModel()
	{
		return $this->belongsTo(TributConfiguraOfGtModel::class, 'id_tribut_configura_of_gt', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getUfDestinoAttribute()
	{
		return $this->attributes['uf_destino'];
	}

	public function setUfDestinoAttribute($ufDestino)
	{
		$this->attributes['uf_destino'] = $ufDestino;
	}

	public function getCfopAttribute()
	{
		return $this->attributes['cfop'];
	}

	public function setCfopAttribute($cfop)
	{
		$this->attributes['cfop'] = $cfop;
	}

	public function getCsosnAttribute()
	{
		return $this->attributes['csosn'];
	}

	public function setCsosnAttribute($csosn)
	{
		$this->attributes['csosn'] = $csosn;
	}

	public function getCstAttribute()
	{
		return $this->attributes['cst'];
	}

	public function setCstAttribute($cst)
	{
		$this->attributes['cst'] = $cst;
	}

	public function getModalidadeBcAttribute()
	{
		return $this->attributes['modalidade_bc'];
	}

	public function setModalidadeBcAttribute($modalidadeBc)
	{
		$this->attributes['modalidade_bc'] = $modalidadeBc;
	}

	public function getAliquotaAttribute()
	{
		return (double)$this->attributes['aliquota'];
	}

	public function setAliquotaAttribute($aliquota)
	{
		$this->attributes['aliquota'] = $aliquota;
	}

	public function getValorPautaAttribute()
	{
		return (double)$this->attributes['valor_pauta'];
	}

	public function setValorPautaAttribute($valorPauta)
	{
		$this->attributes['valor_pauta'] = $valorPauta;
	}

	public function getValorPrecoMaximoAttribute()
	{
		return (double)$this->attributes['valor_preco_maximo'];
	}

	public function setValorPrecoMaximoAttribute($valorPrecoMaximo)
	{
		$this->attributes['valor_preco_maximo'] = $valorPrecoMaximo;
	}

	public function getMvaAttribute()
	{
		return (double)$this->attributes['mva'];
	}

	public function setMvaAttribute($mva)
	{
		$this->attributes['mva'] = $mva;
	}

	public function getPorcentoBcAttribute()
	{
		return (double)$this->attributes['porcento_bc'];
	}

	public function setPorcentoBcAttribute($porcentoBc)
	{
		$this->attributes['porcento_bc'] = $porcentoBc;
	}

	public function getModalidadeBcStAttribute()
	{
		return $this->attributes['modalidade_bc_st'];
	}

	public function setModalidadeBcStAttribute($modalidadeBcSt)
	{
		$this->attributes['modalidade_bc_st'] = $modalidadeBcSt;
	}

	public function getAliquotaInternaStAttribute()
	{
		return (double)$this->attributes['aliquota_interna_st'];
	}

	public function setAliquotaInternaStAttribute($aliquotaInternaSt)
	{
		$this->attributes['aliquota_interna_st'] = $aliquotaInternaSt;
	}

	public function getAliquotaInterestadualStAttribute()
	{
		return (double)$this->attributes['aliquota_interestadual_st'];
	}

	public function setAliquotaInterestadualStAttribute($aliquotaInterestadualSt)
	{
		$this->attributes['aliquota_interestadual_st'] = $aliquotaInterestadualSt;
	}

	public function getPorcentoBcStAttribute()
	{
		return (double)$this->attributes['porcento_bc_st'];
	}

	public function setPorcentoBcStAttribute($porcentoBcSt)
	{
		$this->attributes['porcento_bc_st'] = $porcentoBcSt;
	}

	public function getAliquotaIcmsStAttribute()
	{
		return (double)$this->attributes['aliquota_icms_st'];
	}

	public function setAliquotaIcmsStAttribute($aliquotaIcmsSt)
	{
		$this->attributes['aliquota_icms_st'] = $aliquotaIcmsSt;
	}

	public function getValorPautaStAttribute()
	{
		return (double)$this->attributes['valor_pauta_st'];
	}

	public function setValorPautaStAttribute($valorPautaSt)
	{
		$this->attributes['valor_pauta_st'] = $valorPautaSt;
	}

	public function getValorPrecoMaximoStAttribute()
	{
		return (double)$this->attributes['valor_preco_maximo_st'];
	}

	public function setValorPrecoMaximoStAttribute($valorPrecoMaximoSt)
	{
		$this->attributes['valor_preco_maximo_st'] = $valorPrecoMaximoSt;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setUfDestinoAttribute($object->ufDestino);
				$this->setCfopAttribute($object->cfop);
				$this->setCsosnAttribute($object->csosn);
				$this->setCstAttribute($object->cst);
				$this->setModalidadeBcAttribute($object->modalidadeBc);
				$this->setAliquotaAttribute($object->aliquota);
				$this->setValorPautaAttribute($object->valorPauta);
				$this->setValorPrecoMaximoAttribute($object->valorPrecoMaximo);
				$this->setMvaAttribute($object->mva);
				$this->setPorcentoBcAttribute($object->porcentoBc);
				$this->setModalidadeBcStAttribute($object->modalidadeBcSt);
				$this->setAliquotaInternaStAttribute($object->aliquotaInternaSt);
				$this->setAliquotaInterestadualStAttribute($object->aliquotaInterestadualSt);
				$this->setPorcentoBcStAttribute($object->porcentoBcSt);
				$this->setAliquotaIcmsStAttribute($object->aliquotaIcmsSt);
				$this->setValorPautaStAttribute($object->valorPautaSt);
				$this->setValorPrecoMaximoStAttribute($object->valorPrecoMaximoSt);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ufDestino' => $this->getUfDestinoAttribute(),
				'cfop' => $this->getCfopAttribute(),
				'csosn' => $this->getCsosnAttribute(),
				'cst' => $this->getCstAttribute(),
				'modalidadeBc' => $this->getModalidadeBcAttribute(),
				'aliquota' => $this->getAliquotaAttribute(),
				'valorPauta' => $this->getValorPautaAttribute(),
				'valorPrecoMaximo' => $this->getValorPrecoMaximoAttribute(),
				'mva' => $this->getMvaAttribute(),
				'porcentoBc' => $this->getPorcentoBcAttribute(),
				'modalidadeBcSt' => $this->getModalidadeBcStAttribute(),
				'aliquotaInternaSt' => $this->getAliquotaInternaStAttribute(),
				'aliquotaInterestadualSt' => $this->getAliquotaInterestadualStAttribute(),
				'porcentoBcSt' => $this->getPorcentoBcStAttribute(),
				'aliquotaIcmsSt' => $this->getAliquotaIcmsStAttribute(),
				'valorPautaSt' => $this->getValorPautaStAttribute(),
				'valorPrecoMaximoSt' => $this->getValorPrecoMaximoStAttribute(),
			];
	}
}