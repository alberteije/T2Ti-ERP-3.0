<?php
declare(strict_types=1);

class TributConfiguraOfGtModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'tribut_configura_of_gt';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'tributPisModel',
		'tributCofinsModel',
		'tributIpiModel',
		'tributOperacaoFiscalModel',
		'tributGrupoTributarioModel',
		'tributIcmsUfModelList',
	];

	/**
		* Relations
		*/
	public function tributPisModel()
	{
		return $this->hasOne(TributPisModel::class, 'id_tribut_configura_of_gt', 'id');
	}

	public function tributCofinsModel()
	{
		return $this->hasOne(TributCofinsModel::class, 'id_tribut_configura_of_gt', 'id');
	}

	public function tributIpiModel()
	{
		return $this->hasOne(TributIpiModel::class, 'id_tribut_configura_of_gt', 'id');
	}

	public function tributOperacaoFiscalModel()
	{
		return $this->belongsTo(TributOperacaoFiscalModel::class, 'id_tribut_operacao_fiscal', 'id');
	}

	public function tributGrupoTributarioModel()
	{
		return $this->belongsTo(TributGrupoTributarioModel::class, 'id_tribut_grupo_tributario', 'id');
	}

	public function tributIcmsUfModelList()
{
	return $this->hasMany(TributIcmsUfModel::class, 'id_tribut_configura_of_gt', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);


				// link objects - lookups
				$tributOperacaoFiscalModel = new TributOperacaoFiscalModel();
				$tributOperacaoFiscalModel->mapping($object->tributOperacaoFiscalModel);
				$this->tributOperacaoFiscalModel()->associate($tributOperacaoFiscalModel);
				$tributGrupoTributarioModel = new TributGrupoTributarioModel();
				$tributGrupoTributarioModel->mapping($object->tributGrupoTributarioModel);
				$this->tributGrupoTributarioModel()->associate($tributGrupoTributarioModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tributPisModel' => $this->tributPisModel,
				'tributCofinsModel' => $this->tributCofinsModel,
				'tributIpiModel' => $this->tributIpiModel,
				'tributOperacaoFiscalModel' => $this->tributOperacaoFiscalModel,
				'tributGrupoTributarioModel' => $this->tributGrupoTributarioModel,
				'tributIcmsUfModelList' => $this->tributIcmsUfModelList,
			];
	}
}