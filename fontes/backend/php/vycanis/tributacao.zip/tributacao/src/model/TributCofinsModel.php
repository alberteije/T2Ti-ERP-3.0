<?php
declare(strict_types=1);

class TributCofinsModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'tribut_cofins';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function tributConfiguraOfGtModel()
	{
		return $this->belongsTo(TributConfiguraOfGtModel::class, 'id_tribut_configura_of_gt', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCstCofinsAttribute()
	{
		return $this->attributes['cst_cofins'];
	}

	public function setCstCofinsAttribute($cstCofins)
	{
		$this->attributes['cst_cofins'] = $cstCofins;
	}

	public function getEfdTabela435Attribute()
	{
		return $this->attributes['efd_tabela_435'];
	}

	public function setEfdTabela435Attribute($efdTabela435)
	{
		$this->attributes['efd_tabela_435'] = $efdTabela435;
	}

	public function getModalidadeBaseCalculoAttribute()
	{
		return $this->attributes['modalidade_base_calculo'];
	}

	public function setModalidadeBaseCalculoAttribute($modalidadeBaseCalculo)
	{
		$this->attributes['modalidade_base_calculo'] = $modalidadeBaseCalculo;
	}

	public function getPorcentoBaseCalculoAttribute()
	{
		return (double)$this->attributes['porcento_base_calculo'];
	}

	public function setPorcentoBaseCalculoAttribute($porcentoBaseCalculo)
	{
		$this->attributes['porcento_base_calculo'] = $porcentoBaseCalculo;
	}

	public function getAliquotaPorcentoAttribute()
	{
		return (double)$this->attributes['aliquota_porcento'];
	}

	public function setAliquotaPorcentoAttribute($aliquotaPorcento)
	{
		$this->attributes['aliquota_porcento'] = $aliquotaPorcento;
	}

	public function getAliquotaUnidadeAttribute()
	{
		return (double)$this->attributes['aliquota_unidade'];
	}

	public function setAliquotaUnidadeAttribute($aliquotaUnidade)
	{
		$this->attributes['aliquota_unidade'] = $aliquotaUnidade;
	}

	public function getValorPrecoMaximoAttribute()
	{
		return (double)$this->attributes['valor_preco_maximo'];
	}

	public function setValorPrecoMaximoAttribute($valorPrecoMaximo)
	{
		$this->attributes['valor_preco_maximo'] = $valorPrecoMaximo;
	}

	public function getValorPautaFiscalAttribute()
	{
		return (double)$this->attributes['valor_pauta_fiscal'];
	}

	public function setValorPautaFiscalAttribute($valorPautaFiscal)
	{
		$this->attributes['valor_pauta_fiscal'] = $valorPautaFiscal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCstCofinsAttribute($object->cstCofins);
				$this->setEfdTabela435Attribute($object->efdTabela435);
				$this->setModalidadeBaseCalculoAttribute($object->modalidadeBaseCalculo);
				$this->setPorcentoBaseCalculoAttribute($object->porcentoBaseCalculo);
				$this->setAliquotaPorcentoAttribute($object->aliquotaPorcento);
				$this->setAliquotaUnidadeAttribute($object->aliquotaUnidade);
				$this->setValorPrecoMaximoAttribute($object->valorPrecoMaximo);
				$this->setValorPautaFiscalAttribute($object->valorPautaFiscal);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cstCofins' => $this->getCstCofinsAttribute(),
				'efdTabela435' => $this->getEfdTabela435Attribute(),
				'modalidadeBaseCalculo' => $this->getModalidadeBaseCalculoAttribute(),
				'porcentoBaseCalculo' => $this->getPorcentoBaseCalculoAttribute(),
				'aliquotaPorcento' => $this->getAliquotaPorcentoAttribute(),
				'aliquotaUnidade' => $this->getAliquotaUnidadeAttribute(),
				'valorPrecoMaximo' => $this->getValorPrecoMaximoAttribute(),
				'valorPautaFiscal' => $this->getValorPautaFiscalAttribute(),
			];
	}
}