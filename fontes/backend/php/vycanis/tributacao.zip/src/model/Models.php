<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'TributIcmsUfModel.php';
include 'TributPisModel.php';
include 'TributCofinsModel.php';
include 'TributIpiModel.php';
include 'TributIcmsCustomDetModel.php';
include 'TributIcmsCustomCabModel.php';
include 'TributConfiguraOfGtModel.php';
include 'TributGrupoTributarioModel.php';
include 'TributOperacaoFiscalModel.php';
include 'TributIssModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';