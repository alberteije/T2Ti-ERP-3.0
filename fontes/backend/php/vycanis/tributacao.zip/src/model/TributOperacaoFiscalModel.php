<?php
declare(strict_types=1);

class TributOperacaoFiscalModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'tribut_operacao_fiscal';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getDescricaoNaNfAttribute()
	{
		return $this->attributes['descricao_na_nf'];
	}

	public function setDescricaoNaNfAttribute($descricaoNaNf)
	{
		$this->attributes['descricao_na_nf'] = $descricaoNaNf;
	}

	public function getCfopAttribute()
	{
		return $this->attributes['cfop'];
	}

	public function setCfopAttribute($cfop)
	{
		$this->attributes['cfop'] = $cfop;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setDescricaoNaNfAttribute($object->descricaoNaNf);
				$this->setCfopAttribute($object->cfop);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'descricaoNaNf' => $this->getDescricaoNaNfAttribute(),
				'cfop' => $this->getCfopAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}