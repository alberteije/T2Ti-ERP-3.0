<?php
declare(strict_types=1);

class ViewPessoaUsuarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'view_pessoa_usuario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdPessoaAttribute()
	{
		return $this->attributes['id_pessoa'];
	}

	public function setIdPessoaAttribute($idPessoa)
	{
		$this->attributes['id_pessoa'] = $idPessoa;
	}

	public function getPessoaNomeAttribute()
	{
		return $this->attributes['pessoa_nome'];
	}

	public function setPessoaNomeAttribute($pessoaNome)
	{
		$this->attributes['pessoa_nome'] = $pessoaNome;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getIdColaboradorAttribute()
	{
		return $this->attributes['id_colaborador'];
	}

	public function setIdColaboradorAttribute($idColaborador)
	{
		$this->attributes['id_colaborador'] = $idColaborador;
	}

	public function getIdUsuarioAttribute()
	{
		return $this->attributes['id_usuario'];
	}

	public function setIdUsuarioAttribute($idUsuario)
	{
		$this->attributes['id_usuario'] = $idUsuario;
	}

	public function getLoginAttribute()
	{
		return $this->attributes['login'];
	}

	public function setLoginAttribute($login)
	{
		$this->attributes['login'] = $login;
	}

	public function getSenhaAttribute()
	{
		return $this->attributes['senha'];
	}

	public function setSenhaAttribute($senha)
	{
		$this->attributes['senha'] = $senha;
	}

	public function getDataCadastroAttribute()
	{
		return $this->attributes['data_cadastro'];
	}

	public function setDataCadastroAttribute($dataCadastro)
	{
		$this->attributes['data_cadastro'] = $dataCadastro;
	}

	public function getAdministradorAttribute()
	{
		return $this->attributes['administrador'];
	}

	public function setAdministradorAttribute($administrador)
	{
		$this->attributes['administrador'] = $administrador;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdAttribute($object->id);
				$this->setIdPessoaAttribute($object->idPessoa);
				$this->setPessoaNomeAttribute($object->pessoaNome);
				$this->setTipoAttribute($object->tipo);
				$this->setEmailAttribute($object->email);
				$this->setIdColaboradorAttribute($object->idColaborador);
				$this->setIdUsuarioAttribute($object->idUsuario);
				$this->setLoginAttribute($object->login);
				$this->setSenhaAttribute($object->senha);
				$this->setDataCadastroAttribute($object->dataCadastro);
				$this->setAdministradorAttribute($object->administrador);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idPessoa' => $this->getIdPessoaAttribute(),
				'pessoaNome' => $this->getPessoaNomeAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'email' => $this->getEmailAttribute(),
				'idColaborador' => $this->getIdColaboradorAttribute(),
				'idUsuario' => $this->getIdUsuarioAttribute(),
				'login' => $this->getLoginAttribute(),
				'senha' => $this->getSenhaAttribute(),
				'dataCadastro' => $this->getDataCadastroAttribute(),
				'administrador' => $this->getAdministradorAttribute(),
			];
	}
}