<?php
class TributIcmsCustomCabController extends ControllerBase
{

		private $tributIcmsCustomCabService = null;

		public function __construct()
		{	 
				$this->tributIcmsCustomCabService = new TributIcmsCustomCabService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->tributIcmsCustomCabService->getListFilter($filter);
						} else {
								$resultList = $this->tributIcmsCustomCabService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList TributIcmsCustomCab]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->tributIcmsCustomCabService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject TributIcmsCustomCab]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject TributIcmsCustomCab]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert TributIcmsCustomCab]', null);
						}

						$objModel = new TributIcmsCustomCabModel();
						$objModel->mapping($objJson);

						$this->tributIcmsCustomCabService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert TributIcmsCustomCab]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->tributIcmsCustomCabService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update TributIcmsCustomCab]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->tributIcmsCustomCabService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->tributIcmsCustomCabService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update TributIcmsCustomCab]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->tributIcmsCustomCabService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete TributIcmsCustomCab]', null);
						} else {
								$this->tributIcmsCustomCabService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete TributIcmsCustomCab]', $e);
				}
		}
}
