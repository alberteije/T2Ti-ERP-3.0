<?php
use Illuminate\Database\Capsule\Manager as DB;
class TributIcmsCustomCabService extends ServiceBase
{
	public function getList()
	{
		return TributIcmsCustomCabModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return TributIcmsCustomCabModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return TributIcmsCustomCabModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// tributIcmsCustomDet
		$tributIcmsCustomDetModelListJson = $objJson->tributIcmsCustomDetModelList;
		if ($tributIcmsCustomDetModelListJson != null) {
			for ($i = 0; $i < count($tributIcmsCustomDetModelListJson); $i++) {
				$tributIcmsCustomDet = new TributIcmsCustomDetModel();
				$tributIcmsCustomDet->mapping($tributIcmsCustomDetModelListJson[$i]);
				$objModel->tributIcmsCustomDetModelList()->save($tributIcmsCustomDet);
			}
		}

	}	

	public function deleteChildren($object)
	{
		TributIcmsCustomDetModel::where('id_tribut_icms_custom_cab', $object->getIdAttribute())->delete();
	}	
 
}