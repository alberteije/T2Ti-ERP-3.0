<?php
use Illuminate\Database\Capsule\Manager as DB;
class TributConfiguraOfGtService extends ServiceBase
{
	public function getList()
	{
		return TributConfiguraOfGtModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return TributConfiguraOfGtModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return TributConfiguraOfGtModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// tributPis
		if (isset($objJson->tributPisModel)) {
			$tributPisModel = new TributPisModel();
			$tributPisModel->mapping($objJson->tributPisModel);
			$objModel->tributPisModel()->save($tributPisModel);
		}

		// tributCofins
		if (isset($objJson->tributCofinsModel)) {
			$tributCofinsModel = new TributCofinsModel();
			$tributCofinsModel->mapping($objJson->tributCofinsModel);
			$objModel->tributCofinsModel()->save($tributCofinsModel);
		}

		// tributIpi
		if (isset($objJson->tributIpiModel)) {
			$tributIpiModel = new TributIpiModel();
			$tributIpiModel->mapping($objJson->tributIpiModel);
			$objModel->tributIpiModel()->save($tributIpiModel);
		}

		// tributIcmsUf
		$tributIcmsUfModelListJson = $objJson->tributIcmsUfModelList;
		if ($tributIcmsUfModelListJson != null) {
			for ($i = 0; $i < count($tributIcmsUfModelListJson); $i++) {
				$tributIcmsUf = new TributIcmsUfModel();
				$tributIcmsUf->mapping($tributIcmsUfModelListJson[$i]);
				$objModel->tributIcmsUfModelList()->save($tributIcmsUf);
			}
		}

	}	

	public function deleteChildren($object)
	{
		TributPisModel::where('id_tribut_configura_of_gt', $object->getIdAttribute())->delete();
		TributCofinsModel::where('id_tribut_configura_of_gt', $object->getIdAttribute())->delete();
		TributIpiModel::where('id_tribut_configura_of_gt', $object->getIdAttribute())->delete();
		TributIcmsUfModel::where('id_tribut_configura_of_gt', $object->getIdAttribute())->delete();
	}	
 
}