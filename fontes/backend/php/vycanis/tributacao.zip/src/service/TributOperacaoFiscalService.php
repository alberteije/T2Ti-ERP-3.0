<?php
class TributOperacaoFiscalService extends ServiceBase
{
  public function getList()
  {
    return TributOperacaoFiscalModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TributOperacaoFiscalModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return TributOperacaoFiscalModel::find($id);
  }

}