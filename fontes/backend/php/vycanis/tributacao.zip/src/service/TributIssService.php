<?php
class TributIssService extends ServiceBase
{
  public function getList()
  {
    return TributIssModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TributIssModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return TributIssModel::find($id);
  }

}