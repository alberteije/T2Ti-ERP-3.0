<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// tribut-icms-custom-cab
$app->get('/tribut-icms-custom-cab[/]', \TributIcmsCustomCabController::class . RESULT_LIST);
$app->get('/tribut-icms-custom-cab/{id}', \TributIcmsCustomCabController::class . RESULT_OBJECT);
$app->post('/tribut-icms-custom-cab', \TributIcmsCustomCabController::class . INSERT);
$app->put('/tribut-icms-custom-cab', \TributIcmsCustomCabController::class . UPDATE);
$app->delete('/tribut-icms-custom-cab/{id}', \TributIcmsCustomCabController::class . DELETE);
$app->options('/tribut-icms-custom-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-icms-custom-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-icms-custom-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-configura-of-gt
$app->get('/tribut-configura-of-gt[/]', \TributConfiguraOfGtController::class . RESULT_LIST);
$app->get('/tribut-configura-of-gt/{id}', \TributConfiguraOfGtController::class . RESULT_OBJECT);
$app->post('/tribut-configura-of-gt', \TributConfiguraOfGtController::class . INSERT);
$app->put('/tribut-configura-of-gt', \TributConfiguraOfGtController::class . UPDATE);
$app->delete('/tribut-configura-of-gt/{id}', \TributConfiguraOfGtController::class . DELETE);
$app->options('/tribut-configura-of-gt', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-configura-of-gt/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-configura-of-gt/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// papel
$app->get('/papel[/]', \PapelController::class . RESULT_LIST);
$app->get('/papel/{id}', \PapelController::class . RESULT_OBJECT);
$app->post('/papel', \PapelController::class . INSERT);
$app->put('/papel', \PapelController::class . UPDATE);
$app->delete('/papel/{id}', \PapelController::class . DELETE);
$app->options('/papel', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/papel/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/papel/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// funcao
$app->get('/funcao[/]', \FuncaoController::class . RESULT_LIST);
$app->get('/funcao/{id}', \FuncaoController::class . RESULT_OBJECT);
$app->post('/funcao', \FuncaoController::class . INSERT);
$app->put('/funcao', \FuncaoController::class . UPDATE);
$app->delete('/funcao/{id}', \FuncaoController::class . DELETE);
$app->options('/funcao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/funcao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/funcao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// colaborador
$app->get('/colaborador[/]', \ColaboradorController::class . RESULT_LIST);
$app->get('/colaborador/{id}', \ColaboradorController::class . RESULT_OBJECT);
$app->post('/colaborador', \ColaboradorController::class . INSERT);
$app->put('/colaborador', \ColaboradorController::class . UPDATE);
$app->delete('/colaborador/{id}', \ColaboradorController::class . DELETE);
$app->options('/colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-grupo-tributario
$app->get('/tribut-grupo-tributario[/]', \TributGrupoTributarioController::class . RESULT_LIST);
$app->get('/tribut-grupo-tributario/{id}', \TributGrupoTributarioController::class . RESULT_OBJECT);
$app->post('/tribut-grupo-tributario', \TributGrupoTributarioController::class . INSERT);
$app->put('/tribut-grupo-tributario', \TributGrupoTributarioController::class . UPDATE);
$app->delete('/tribut-grupo-tributario/{id}', \TributGrupoTributarioController::class . DELETE);
$app->options('/tribut-grupo-tributario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-grupo-tributario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-grupo-tributario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-operacao-fiscal
$app->get('/tribut-operacao-fiscal[/]', \TributOperacaoFiscalController::class . RESULT_LIST);
$app->get('/tribut-operacao-fiscal/{id}', \TributOperacaoFiscalController::class . RESULT_OBJECT);
$app->post('/tribut-operacao-fiscal', \TributOperacaoFiscalController::class . INSERT);
$app->put('/tribut-operacao-fiscal', \TributOperacaoFiscalController::class . UPDATE);
$app->delete('/tribut-operacao-fiscal/{id}', \TributOperacaoFiscalController::class . DELETE);
$app->options('/tribut-operacao-fiscal', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-operacao-fiscal/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-operacao-fiscal/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-iss
$app->get('/tribut-iss[/]', \TributIssController::class . RESULT_LIST);
$app->get('/tribut-iss/{id}', \TributIssController::class . RESULT_OBJECT);
$app->post('/tribut-iss', \TributIssController::class . INSERT);
$app->put('/tribut-iss', \TributIssController::class . UPDATE);
$app->delete('/tribut-iss/{id}', \TributIssController::class . DELETE);
$app->options('/tribut-iss', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-iss/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-iss/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// pessoa
$app->get('/pessoa[/]', \PessoaController::class . RESULT_LIST);
$app->get('/pessoa/{id}', \PessoaController::class . RESULT_OBJECT);
$app->post('/pessoa', \PessoaController::class . INSERT);
$app->put('/pessoa', \PessoaController::class . UPDATE);
$app->delete('/pessoa/{id}', \PessoaController::class . DELETE);
$app->options('/pessoa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pessoa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pessoa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

