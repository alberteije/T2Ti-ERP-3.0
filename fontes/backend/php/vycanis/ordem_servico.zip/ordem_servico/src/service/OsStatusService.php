<?php
class OsStatusService extends ServiceBase
{
  public function getList()
  {
    return OsStatusModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return OsStatusModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return OsStatusModel::find($id);
  }

}