<?php
class ViewPessoaClienteService extends ServiceBase
{
  public function getList()
  {
    return ViewPessoaClienteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewPessoaClienteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewPessoaClienteModel::find($id);
  }

}