<?php
declare(strict_types=1);

class OsAberturaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'os_abertura';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'osAberturaEquipamentoModelList',
		'osProdutoServicoModelList',
		'osEvolucaoModelList',
		'viewPessoaClienteModel',
		'viewPessoaColaboradorModel',
		'osStatusModel',
	];

	/**
		* Relations
		*/
	public function osAberturaEquipamentoModelList()
{
	return $this->hasMany(OsAberturaEquipamentoModel::class, 'id_os_abertura', 'id');
}

	public function osProdutoServicoModelList()
{
	return $this->hasMany(OsProdutoServicoModel::class, 'id_os_abertura', 'id');
}

	public function osEvolucaoModelList()
{
	return $this->hasMany(OsEvolucaoModel::class, 'id_os_abertura', 'id');
}

	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function osStatusModel()
	{
		return $this->belongsTo(OsStatusModel::class, 'id_os_status', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getHoraInicioAttribute()
	{
		return $this->attributes['hora_inicio'];
	}

	public function setHoraInicioAttribute($horaInicio)
	{
		$this->attributes['hora_inicio'] = $horaInicio;
	}

	public function getDataPrevisaoAttribute()
	{
		return $this->attributes['data_previsao'];
	}

	public function setDataPrevisaoAttribute($dataPrevisao)
	{
		$this->attributes['data_previsao'] = $dataPrevisao;
	}

	public function getHoraPrevisaoAttribute()
	{
		return $this->attributes['hora_previsao'];
	}

	public function setHoraPrevisaoAttribute($horaPrevisao)
	{
		$this->attributes['hora_previsao'] = $horaPrevisao;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getHoraFimAttribute()
	{
		return $this->attributes['hora_fim'];
	}

	public function setHoraFimAttribute($horaFim)
	{
		$this->attributes['hora_fim'] = $horaFim;
	}

	public function getNomeContatoAttribute()
	{
		return $this->attributes['nome_contato'];
	}

	public function setNomeContatoAttribute($nomeContato)
	{
		$this->attributes['nome_contato'] = $nomeContato;
	}

	public function getFoneContatoAttribute()
	{
		return $this->attributes['fone_contato'];
	}

	public function setFoneContatoAttribute($foneContato)
	{
		$this->attributes['fone_contato'] = $foneContato;
	}

	public function getObservacaoClienteAttribute()
	{
		return $this->attributes['observacao_cliente'];
	}

	public function setObservacaoClienteAttribute($observacaoCliente)
	{
		$this->attributes['observacao_cliente'] = $observacaoCliente;
	}

	public function getObservacaoAberturaAttribute()
	{
		return $this->attributes['observacao_abertura'];
	}

	public function setObservacaoAberturaAttribute($observacaoAbertura)
	{
		$this->attributes['observacao_abertura'] = $observacaoAbertura;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setDataInicioAttribute($object->dataInicio);
				$this->setHoraInicioAttribute($object->horaInicio);
				$this->setDataPrevisaoAttribute($object->dataPrevisao);
				$this->setHoraPrevisaoAttribute($object->horaPrevisao);
				$this->setDataFimAttribute($object->dataFim);
				$this->setHoraFimAttribute($object->horaFim);
				$this->setNomeContatoAttribute($object->nomeContato);
				$this->setFoneContatoAttribute($object->foneContato);
				$this->setObservacaoClienteAttribute($object->observacaoCliente);
				$this->setObservacaoAberturaAttribute($object->observacaoAbertura);

				// link objects - lookups
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$osStatusModel = new OsStatusModel();
				$osStatusModel->mapping($object->osStatusModel);
				$this->osStatusModel()->associate($osStatusModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'horaInicio' => $this->getHoraInicioAttribute(),
				'dataPrevisao' => $this->getDataPrevisaoAttribute(),
				'horaPrevisao' => $this->getHoraPrevisaoAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'horaFim' => $this->getHoraFimAttribute(),
				'nomeContato' => $this->getNomeContatoAttribute(),
				'foneContato' => $this->getFoneContatoAttribute(),
				'observacaoCliente' => $this->getObservacaoClienteAttribute(),
				'observacaoAbertura' => $this->getObservacaoAberturaAttribute(),
				'osAberturaEquipamentoModelList' => $this->osAberturaEquipamentoModelList,
				'osProdutoServicoModelList' => $this->osProdutoServicoModelList,
				'osEvolucaoModelList' => $this->osEvolucaoModelList,
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'osStatusModel' => $this->osStatusModel,
			];
	}
}