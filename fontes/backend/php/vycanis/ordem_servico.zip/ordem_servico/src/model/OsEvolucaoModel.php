<?php
declare(strict_types=1);

class OsEvolucaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'os_evolucao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function osAberturaModel()
	{
		return $this->belongsTo(OsAberturaModel::class, 'id_os_abertura', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataRegistroAttribute()
	{
		return $this->attributes['data_registro'];
	}

	public function setDataRegistroAttribute($dataRegistro)
	{
		$this->attributes['data_registro'] = $dataRegistro;
	}

	public function getHoraRegistroAttribute()
	{
		return $this->attributes['hora_registro'];
	}

	public function setHoraRegistroAttribute($horaRegistro)
	{
		$this->attributes['hora_registro'] = $horaRegistro;
	}

	public function getEnviarEmailAttribute()
	{
		return $this->attributes['enviar_email'];
	}

	public function setEnviarEmailAttribute($enviarEmail)
	{
		$this->attributes['enviar_email'] = $enviarEmail;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataRegistroAttribute($object->dataRegistro);
				$this->setHoraRegistroAttribute($object->horaRegistro);
				$this->setEnviarEmailAttribute($object->enviarEmail);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataRegistro' => $this->getDataRegistroAttribute(),
				'horaRegistro' => $this->getHoraRegistroAttribute(),
				'enviarEmail' => $this->getEnviarEmailAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}