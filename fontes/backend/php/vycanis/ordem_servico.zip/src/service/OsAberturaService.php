<?php
use Illuminate\Database\Capsule\Manager as DB;
class OsAberturaService extends ServiceBase
{
	public function getList()
	{
		return OsAberturaModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return OsAberturaModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return OsAberturaModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// osAberturaEquipamento
		$osAberturaEquipamentoModelListJson = $objJson->osAberturaEquipamentoModelList;
		if ($osAberturaEquipamentoModelListJson != null) {
			for ($i = 0; $i < count($osAberturaEquipamentoModelListJson); $i++) {
				$osAberturaEquipamento = new OsAberturaEquipamentoModel();
				$osAberturaEquipamento->mapping($osAberturaEquipamentoModelListJson[$i]);
				$objModel->osAberturaEquipamentoModelList()->save($osAberturaEquipamento);
			}
		}

		// osProdutoServico
		$osProdutoServicoModelListJson = $objJson->osProdutoServicoModelList;
		if ($osProdutoServicoModelListJson != null) {
			for ($i = 0; $i < count($osProdutoServicoModelListJson); $i++) {
				$osProdutoServico = new OsProdutoServicoModel();
				$osProdutoServico->mapping($osProdutoServicoModelListJson[$i]);
				$objModel->osProdutoServicoModelList()->save($osProdutoServico);
			}
		}

		// osEvolucao
		$osEvolucaoModelListJson = $objJson->osEvolucaoModelList;
		if ($osEvolucaoModelListJson != null) {
			for ($i = 0; $i < count($osEvolucaoModelListJson); $i++) {
				$osEvolucao = new OsEvolucaoModel();
				$osEvolucao->mapping($osEvolucaoModelListJson[$i]);
				$objModel->osEvolucaoModelList()->save($osEvolucao);
			}
		}

	}	

	public function deleteChildren($object)
	{
		OsAberturaEquipamentoModel::where('id_os_abertura', $object->getIdAttribute())->delete();
		OsProdutoServicoModel::where('id_os_abertura', $object->getIdAttribute())->delete();
		OsEvolucaoModel::where('id_os_abertura', $object->getIdAttribute())->delete();
	}	
 
}