<?php
class OsEquipamentoService extends ServiceBase
{
  public function getList()
  {
    return OsEquipamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return OsEquipamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return OsEquipamentoModel::find($id);
  }

}