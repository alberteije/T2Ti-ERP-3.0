<?php

include 'ServiceBase.php';

include 'ProdutoGrupoService.php';
include 'ProdutoSubgrupoService.php';
include 'ProdutoMarcaService.php';
include 'ProdutoUnidadeService.php';
include 'OsAberturaService.php';
include 'OsStatusService.php';
include 'OsEquipamentoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaClienteService.php';
include 'ViewPessoaColaboradorService.php';