<?php
declare(strict_types=1);

class OsAberturaEquipamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'os_abertura_equipamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'osEquipamentoModel',
	];

	/**
		* Relations
		*/
	public function osAberturaModel()
	{
		return $this->belongsTo(OsAberturaModel::class, 'id_os_abertura', 'id');
	}

	public function osEquipamentoModel()
	{
		return $this->belongsTo(OsEquipamentoModel::class, 'id_os_equipamento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoCoberturaAttribute()
	{
		return $this->attributes['tipo_cobertura'];
	}

	public function setTipoCoberturaAttribute($tipoCobertura)
	{
		$this->attributes['tipo_cobertura'] = $tipoCobertura;
	}

	public function getNumeroSerieAttribute()
	{
		return $this->attributes['numero_serie'];
	}

	public function setNumeroSerieAttribute($numeroSerie)
	{
		$this->attributes['numero_serie'] = $numeroSerie;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoCoberturaAttribute($object->tipoCobertura);
				$this->setNumeroSerieAttribute($object->numeroSerie);

				// link objects - lookups
				$osEquipamentoModel = new OsEquipamentoModel();
				$osEquipamentoModel->mapping($object->osEquipamentoModel);
				$this->osEquipamentoModel()->associate($osEquipamentoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipoCobertura' => $this->getTipoCoberturaAttribute(),
				'numeroSerie' => $this->getNumeroSerieAttribute(),
				'osEquipamentoModel' => $this->osEquipamentoModel,
			];
	}
}