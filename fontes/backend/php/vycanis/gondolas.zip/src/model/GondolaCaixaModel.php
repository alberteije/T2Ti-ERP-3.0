<?php
declare(strict_types=1);

class GondolaCaixaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'gondola_caixa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'gondolaArmazenamentoModelList',
		'gondolaEstanteModel',
	];

	/**
		* Relations
		*/
	public function gondolaArmazenamentoModelList()
{
	return $this->hasMany(GondolaArmazenamentoModel::class, 'id_gondola_caixa', 'id');
}

	public function gondolaEstanteModel()
	{
		return $this->belongsTo(GondolaEstanteModel::class, 'id_gondola_estante', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getAlturaAttribute()
	{
		return $this->attributes['altura'];
	}

	public function setAlturaAttribute($altura)
	{
		$this->attributes['altura'] = $altura;
	}

	public function getLarguraAttribute()
	{
		return $this->attributes['largura'];
	}

	public function setLarguraAttribute($largura)
	{
		$this->attributes['largura'] = $largura;
	}

	public function getProfundidadeAttribute()
	{
		return $this->attributes['profundidade'];
	}

	public function setProfundidadeAttribute($profundidade)
	{
		$this->attributes['profundidade'] = $profundidade;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setAlturaAttribute($object->altura);
				$this->setLarguraAttribute($object->largura);
				$this->setProfundidadeAttribute($object->profundidade);

				// link objects - lookups
				$gondolaEstanteModel = new GondolaEstanteModel();
				$gondolaEstanteModel->mapping($object->gondolaEstanteModel);
				$this->gondolaEstanteModel()->associate($gondolaEstanteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'altura' => $this->getAlturaAttribute(),
				'largura' => $this->getLarguraAttribute(),
				'profundidade' => $this->getProfundidadeAttribute(),
				'gondolaArmazenamentoModelList' => $this->gondolaArmazenamentoModelList,
				'gondolaEstanteModel' => $this->gondolaEstanteModel,
			];
	}
}