<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'GondolaArmazenamentoModel.php';
include 'GondolaCaixaModel.php';
include 'ProdutoModel.php';
include 'GondolaRuaModel.php';
include 'GondolaEstanteModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';