<?php
class GondolaRuaService extends ServiceBase
{
  public function getList()
  {
    return GondolaRuaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return GondolaRuaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return GondolaRuaModel::find($id);
  }

}