<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// gondola-caixa
$app->get('/gondola-caixa[/]', \GondolaCaixaController::class . RESULT_LIST);
$app->get('/gondola-caixa/{id}', \GondolaCaixaController::class . RESULT_OBJECT);
$app->post('/gondola-caixa', \GondolaCaixaController::class . INSERT);
$app->put('/gondola-caixa', \GondolaCaixaController::class . UPDATE);
$app->delete('/gondola-caixa/{id}', \GondolaCaixaController::class . DELETE);
$app->options('/gondola-caixa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/gondola-caixa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/gondola-caixa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto
$app->get('/produto[/]', \ProdutoController::class . RESULT_LIST);
$app->get('/produto/{id}', \ProdutoController::class . RESULT_OBJECT);
$app->post('/produto', \ProdutoController::class . INSERT);
$app->put('/produto', \ProdutoController::class . UPDATE);
$app->delete('/produto/{id}', \ProdutoController::class . DELETE);
$app->options('/produto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// gondola-rua
$app->get('/gondola-rua[/]', \GondolaRuaController::class . RESULT_LIST);
$app->get('/gondola-rua/{id}', \GondolaRuaController::class . RESULT_OBJECT);
$app->post('/gondola-rua', \GondolaRuaController::class . INSERT);
$app->put('/gondola-rua', \GondolaRuaController::class . UPDATE);
$app->delete('/gondola-rua/{id}', \GondolaRuaController::class . DELETE);
$app->options('/gondola-rua', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/gondola-rua/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/gondola-rua/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// gondola-estante
$app->get('/gondola-estante[/]', \GondolaEstanteController::class . RESULT_LIST);
$app->get('/gondola-estante/{id}', \GondolaEstanteController::class . RESULT_OBJECT);
$app->post('/gondola-estante', \GondolaEstanteController::class . INSERT);
$app->put('/gondola-estante', \GondolaEstanteController::class . UPDATE);
$app->delete('/gondola-estante/{id}', \GondolaEstanteController::class . DELETE);
$app->options('/gondola-estante', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/gondola-estante/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/gondola-estante/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

