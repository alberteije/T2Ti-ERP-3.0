<?php
declare(strict_types=1);

class GondolaEstanteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'gondola_estante';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'gondolaRuaModel',
	];

	/**
		* Relations
		*/
	public function gondolaRuaModel()
	{
		return $this->belongsTo(GondolaRuaModel::class, 'id_gondola_rua', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getQuantidadeCaixaAttribute()
	{
		return $this->attributes['quantidade_caixa'];
	}

	public function setQuantidadeCaixaAttribute($quantidadeCaixa)
	{
		$this->attributes['quantidade_caixa'] = $quantidadeCaixa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setQuantidadeCaixaAttribute($object->quantidadeCaixa);

				// link objects - lookups
				$gondolaRuaModel = new GondolaRuaModel();
				$gondolaRuaModel->mapping($object->gondolaRuaModel);
				$this->gondolaRuaModel()->associate($gondolaRuaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'quantidadeCaixa' => $this->getQuantidadeCaixaAttribute(),
				'gondolaRuaModel' => $this->gondolaRuaModel,
			];
	}
}