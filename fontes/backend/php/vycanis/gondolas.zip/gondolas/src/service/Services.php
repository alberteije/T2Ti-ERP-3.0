<?php

include 'ServiceBase.php';

include 'GondolaCaixaService.php';
include 'ProdutoService.php';
include 'GondolaRuaService.php';
include 'GondolaEstanteService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';