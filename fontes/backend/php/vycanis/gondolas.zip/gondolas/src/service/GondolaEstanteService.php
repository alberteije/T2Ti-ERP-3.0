<?php
class GondolaEstanteService extends ServiceBase
{
  public function getList()
  {
    return GondolaEstanteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return GondolaEstanteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return GondolaEstanteModel::find($id);
  }

}