<?php
class ErpTipoPlanoController extends ControllerBase
{

		private $erpTipoPlanoService = null;

		public function __construct()
		{	 
				$this->erpTipoPlanoService = new ErpTipoPlanoService();
		}

		public function consultarLista($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filtro = new Filtro($request->getQueryParams()['filter']);
								$resultList = $this->erpTipoPlanoService->consultarListaFiltroValor($filtro);
						} else {
								$resultList = $this->erpTipoPlanoService->consultarLista();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
					} catch (Exception $e) {
            return parent::tratarErro($response, 500, 'Erro no Servidor [Consultar Lista PdvTipoPlano]', $e);
        }
		}

		
}
