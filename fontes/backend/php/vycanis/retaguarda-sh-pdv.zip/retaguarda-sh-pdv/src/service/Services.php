<?php

include 'ServiceBase.php';

// Planos
include 'planos/PdvTipoPlanoService.php';
include 'planos/PdvPlanoPagamentoService.php';
include 'planos/ErpTipoPlanoService.php';

// Cadastros
include 'cadastros/EmpresaService.php';
include 'cadastros/AcbrMonitorPortaService.php';

// NF-e
include 'nfe/NfeConfiguracaoService.php';

// ACBr
include 'acbr/AcbrMonitorService.php';

// Sincroniza
include 'sincroniza/SincronizaService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';