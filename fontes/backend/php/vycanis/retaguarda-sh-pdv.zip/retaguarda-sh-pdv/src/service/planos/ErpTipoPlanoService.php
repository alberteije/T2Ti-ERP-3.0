<?php
class ErpTipoPlanoService extends ServiceBase
{
  public function consultarLista()
  {
    return ErpTipoPlanoModel::select()->get();
  } 

  public function consultarListaFiltroValor($filtro)
  {
  	return ErpTipoPlanoModel::whereRaw($filtro->where)->get();
  }


}