<?php
class EmpresaController extends ControllerBase
{

		private $empresaService = null;

		public function __construct()
		{	 
				$this->empresaService = new EmpresaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->empresaService->getListFilter($filter);
						} else {
								$resultList = $this->empresaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList Empresa]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->empresaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject Empresa]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject Empresa]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert Empresa]', null);
						}

						$objModel = new EmpresaModel();
						$objModel->mapping($objJson);

						$this->empresaService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert Empresa]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->empresaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update Empresa]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->empresaService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->empresaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update Empresa]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->empresaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete Empresa]', null);
						} else {
								$this->empresaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete Empresa]', $e);
				}
		}
}
