<?php
class UsuarioController extends ControllerBase
{

		private $usuarioService = null;

		public function __construct()
		{	 
				$this->usuarioService = new UsuarioService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->usuarioService->getListFilter($filter);
						} else {
								$resultList = $this->usuarioService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList Usuario]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->usuarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject Usuario]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject Usuario]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert Usuario]', null);
						}

						$objModel = new UsuarioModel();
						$objModel->mapping($objJson);

						$this->usuarioService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert Usuario]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->usuarioService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update Usuario]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->usuarioService->save($objFromDatabase);
								$objFromDatabase = $this->usuarioService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update Usuario]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->usuarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete Usuario]', null);
						} else {
								$this->usuarioService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete Usuario]', $e);
				}
		}

		public function getUsuarioPorLogin($request, $response, $args)
		{
			try {
				$filter = 'login = "' . $args['login'] . '"';
				$objFromDatabase = $this->usuarioService->getObjectFilter($filter);
		
				if ($objFromDatabase == null) {
					return parent::handleError($response, 404, 'Not Found [getObject Usuario]', null);
				} else {
					$return = json_encode($objFromDatabase);
					$response->getBody()->write($return);
					return $response
						->withStatus(200)
						->withHeader('Content-Type', 'application/json');
				}
			} catch (Exception $e) {
				return parent::handleError($response, 500, 'Error [getObject Usuario]', $e);
			}
		}		
}
