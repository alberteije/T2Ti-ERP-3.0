<?php

declare(strict_types=1);

// Constants used on routes
define("RESULT_LIST", ':getList');
define("RESULT_OBJECT", ':getObject');
define("INSERT", ':insert');
define("UPDATE", ':update');
define("DELETE", ':delete');
define("BROWSER_OPTION_RESPONSE", ':browserOptionsResponse');

// Security constants
define("CYPHER", 'aes-256-ctr'); 
define("MAIN_KEY", '#Sua-Chave-de-32-caracteres-aqui'); 
define("MAIN_VECTOR", '#Seu-Vetor-aqui#'); 