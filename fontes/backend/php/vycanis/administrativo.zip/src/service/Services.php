<?php

include 'ServiceBase.php';

include 'PapelService.php';
include 'EmpresaService.php';
include 'AuditoriaService.php';
include 'UsuarioTokenService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';
include 'FuncaoService.php';
include 'UsuarioService.php';
include 'CnaeService.php';