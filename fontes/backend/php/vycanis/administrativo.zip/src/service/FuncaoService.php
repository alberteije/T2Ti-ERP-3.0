<?php
class FuncaoService extends ServiceBase
{
  public function getList()
  {
    return FuncaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FuncaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FuncaoModel::find($id);
  }

}