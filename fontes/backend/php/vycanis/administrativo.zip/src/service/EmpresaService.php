<?php
use Illuminate\Database\Capsule\Manager as DB;
class EmpresaService extends ServiceBase
{
	public function getList()
	{
		return EmpresaModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return EmpresaModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return EmpresaModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// empresaEndereco
		$empresaEnderecoModelListJson = $objJson->empresaEnderecoModelList;
		if ($empresaEnderecoModelListJson != null) {
			for ($i = 0; $i < count($empresaEnderecoModelListJson); $i++) {
				$empresaEndereco = new EmpresaEnderecoModel();
				$empresaEndereco->mapping($empresaEnderecoModelListJson[$i]);
				$objModel->empresaEnderecoModelList()->save($empresaEndereco);
			}
		}

		// empresaContato
		$empresaContatoModelListJson = $objJson->empresaContatoModelList;
		if ($empresaContatoModelListJson != null) {
			for ($i = 0; $i < count($empresaContatoModelListJson); $i++) {
				$empresaContato = new EmpresaContatoModel();
				$empresaContato->mapping($empresaContatoModelListJson[$i]);
				$objModel->empresaContatoModelList()->save($empresaContato);
			}
		}

		// empresaTelefone
		$empresaTelefoneModelListJson = $objJson->empresaTelefoneModelList;
		if ($empresaTelefoneModelListJson != null) {
			for ($i = 0; $i < count($empresaTelefoneModelListJson); $i++) {
				$empresaTelefone = new EmpresaTelefoneModel();
				$empresaTelefone->mapping($empresaTelefoneModelListJson[$i]);
				$objModel->empresaTelefoneModelList()->save($empresaTelefone);
			}
		}

		// empresaCnae
		$empresaCnaeModelListJson = $objJson->empresaCnaeModelList;
		if ($empresaCnaeModelListJson != null) {
			for ($i = 0; $i < count($empresaCnaeModelListJson); $i++) {
				$empresaCnae = new EmpresaCnaeModel();
				$empresaCnae->mapping($empresaCnaeModelListJson[$i]);
				$objModel->empresaCnaeModelList()->save($empresaCnae);
			}
		}

	}	

	public function deleteChildren($object)
	{
		EmpresaEnderecoModel::where('id_empresa', $object->getIdAttribute())->delete();
		EmpresaContatoModel::where('id_empresa', $object->getIdAttribute())->delete();
		EmpresaTelefoneModel::where('id_empresa', $object->getIdAttribute())->delete();
		EmpresaCnaeModel::where('id_empresa', $object->getIdAttribute())->delete();
	}	
 
}