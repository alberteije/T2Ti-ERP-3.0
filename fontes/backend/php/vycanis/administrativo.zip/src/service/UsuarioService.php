<?php
class UsuarioService extends ServiceBase
{
  public function getList()
  {
    return UsuarioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return UsuarioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return UsuarioModel::find($id);
  }

  public function getObjectFilter($filter)
	{
		$retorno = UsuarioModel::whereRaw($filter)->get();
		if ($retorno->count() > 0) {
			return $retorno[0];
		} else {
			return null;
		}		
	}
}