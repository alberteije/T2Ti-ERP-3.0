<?php
declare(strict_types=1);

class AuditoriaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'auditoria';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'usuarioTokenModel',
	];

	/**
		* Relations
		*/
	public function usuarioTokenModel()
	{
			return $this->belongsTo(UsuarioTokenModel::class, 'token_jwt', 'token');
	}
		

	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataRegistroAttribute()
	{
		return $this->attributes['data_registro'];
	}

	public function setDataRegistroAttribute($dataRegistro)
	{
		$this->attributes['data_registro'] = $dataRegistro;
	}

	public function getHoraRegistroAttribute()
	{
		return $this->attributes['hora_registro'];
	}

	public function setHoraRegistroAttribute($horaRegistro)
	{
		$this->attributes['hora_registro'] = $horaRegistro;
	}

	public function getJanelaControllerAttribute()
	{
		return $this->attributes['janela_controller'];
	}

	public function setJanelaControllerAttribute($janelaController)
	{
		$this->attributes['janela_controller'] = $janelaController;
	}

	public function getAcaoAttribute()
	{
		return $this->attributes['acao'];
	}

	public function setAcaoAttribute($acao)
	{
		$this->attributes['acao'] = $acao;
	}

	public function getConteudoAttribute()
	{
		return $this->attributes['conteudo'];
	}

	public function setConteudoAttribute($conteudo)
	{
		$this->attributes['conteudo'] = $conteudo;
	}

	public function getTokenJwtAttribute()
	{
		return $this->attributes['token_jwt'];
	}

	public function setTokenJwtAttribute($tokenJwt)
	{
		$this->attributes['token_jwt'] = $tokenJwt;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataRegistroAttribute($object->dataRegistro);
				$this->setHoraRegistroAttribute($object->horaRegistro);
				$this->setJanelaControllerAttribute($object->janelaController);
				$this->setAcaoAttribute($object->acao);
				$this->setConteudoAttribute($object->conteudo);
				$this->setTokenJwtAttribute($object->tokenJwt);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataRegistro' => $this->getDataRegistroAttribute(),
				'horaRegistro' => $this->getHoraRegistroAttribute(),
				'janelaController' => $this->getJanelaControllerAttribute(),
				'acao' => $this->getAcaoAttribute(),
				'conteudo' => $this->getConteudoAttribute(),
				'tokenJwt' => $this->getTokenJwtAttribute(),
				'usuarioTokenModel' => $this->usuarioTokenModel,
			];
	}
}