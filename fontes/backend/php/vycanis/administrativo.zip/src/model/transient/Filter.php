<?php

/// transient class that controls the filter
/// take as a basis the following scheme to create the filter conditions (filter conditions)
/// https://github.com/nestjsx/crud/wiki/Requests
class Filter implements \JsonSerializable
{
	public $field;
	public $value;
	public $initialDate;
	public $finalDate;
	public $where;
	
	public function __construct($filter)
	{
		if (isset($filter)) {
			$partsOfFilter = explode('&', $filter);
			
			for ($i=0; $i < count($partsOfFilter); $i++) { 

				$conditions = explode('||', $partsOfFilter[$i]);

				if ($i > 0)
				{
					$this->where = $this->where . " AND ";
				}

				// $cont (LIKE %val%, contains)
				if ($conditions[1] == '$cont') {
					$this->field = $conditions[0];
					$this->value = $conditions[2];
					$this->where = $this->where . " $this->field like '%" . $this->value . "%'";
				}

				// $eq (=, equal)
				if ($conditions[1] == '$eq') {
					$this->field = $conditions[0];
					$this->value = $conditions[2];
					$this->where = $this->where . " $this->field = '" . $this->value . "'";
				}
				
				// $between (BETWEEN, between, accepts two values)
				if ($conditions[1] == '$between') {
					$datas = explode(',', $conditions[2]);
					$this->field = $conditions[0];
					$this->initialDate = $datas[0];
					$this->finalDate = $datas[1];
					$this->where = $this->where . " $this->field between '" . $this->initialDate . "' and '" . $this->finalDate . "'";
				}
		
			}			
		}
	}


	/**
	 * {@inheritdoc}
	 */
	public function jsonSerialize(): mixed
	{
		return [
			'field' => $this->field,
			'value' => $this->value,
			'initialDate' => $this->initialDate,
			'finalDate' => $this->finalDate,
			'where' => $this->where,
		];
	}
}