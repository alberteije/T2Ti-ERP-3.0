<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'PapelFuncaoModel.php';
include 'EmpresaEnderecoModel.php';
include 'EmpresaContatoModel.php';
include 'EmpresaTelefoneModel.php';
include 'EmpresaCnaeModel.php';
include 'PapelModel.php';
include 'EmpresaModel.php';
include 'AuditoriaModel.php';
include 'UsuarioTokenModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'FuncaoModel.php';
include 'UsuarioModel.php';
include 'CnaeModel.php';