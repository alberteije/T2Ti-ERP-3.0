<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// papel
$app->get('/papel[/]', \PapelController::class . RESULT_LIST);
$app->get('/papel/{id}', \PapelController::class . RESULT_OBJECT);
$app->post('/papel', \PapelController::class . INSERT);
$app->put('/papel', \PapelController::class . UPDATE);
$app->delete('/papel/{id}', \PapelController::class . DELETE);
$app->options('/papel', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/papel/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/papel/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// empresa
$app->get('/empresa[/]', \EmpresaController::class . RESULT_LIST);
$app->get('/empresa/{id}', \EmpresaController::class . RESULT_OBJECT);
$app->post('/empresa', \EmpresaController::class . INSERT);
$app->put('/empresa', \EmpresaController::class . UPDATE);
$app->delete('/empresa/{id}', \EmpresaController::class . DELETE);
$app->options('/empresa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/empresa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/empresa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// auditoria
$app->get('/auditoria[/]', \AuditoriaController::class . RESULT_LIST);
$app->get('/auditoria/{id}', \AuditoriaController::class . RESULT_OBJECT);
$app->post('/auditoria', \AuditoriaController::class . INSERT);
$app->put('/auditoria', \AuditoriaController::class . UPDATE);
$app->delete('/auditoria/{id}', \AuditoriaController::class . DELETE);
$app->options('/auditoria', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/auditoria/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/auditoria/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// usuario-token
$app->get('/usuario-token[/]', \UsuarioTokenController::class . RESULT_LIST);
$app->get('/usuario-token/{id}', \UsuarioTokenController::class . RESULT_OBJECT);
$app->post('/usuario-token', \UsuarioTokenController::class . INSERT);
$app->put('/usuario-token', \UsuarioTokenController::class . UPDATE);
$app->delete('/usuario-token/{id}', \UsuarioTokenController::class . DELETE);
$app->options('/usuario-token', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/usuario-token/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/usuario-token/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// funcao
$app->get('/funcao[/]', \FuncaoController::class . RESULT_LIST);
$app->get('/funcao/{id}', \FuncaoController::class . RESULT_OBJECT);
$app->post('/funcao', \FuncaoController::class . INSERT);
$app->put('/funcao', \FuncaoController::class . UPDATE);
$app->delete('/funcao/{id}', \FuncaoController::class . DELETE);
$app->options('/funcao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/funcao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/funcao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// usuario
$app->get('/usuario[/]', \UsuarioController::class . RESULT_LIST);
$app->get('/usuario/{id}', \UsuarioController::class . RESULT_OBJECT);
$app->post('/usuario', \UsuarioController::class . INSERT);
$app->put('/usuario', \UsuarioController::class . UPDATE);
$app->delete('/usuario/{id}', \UsuarioController::class . DELETE);
$app->options('/usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->get('/usuario/verifica-login/{login}', \UsuarioController::class . ':getUsuarioPorLogin');
$app->options('/usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cnae
$app->get('/cnae[/]', \CnaeController::class . RESULT_LIST);
$app->get('/cnae/{id}', \CnaeController::class . RESULT_OBJECT);
$app->post('/cnae', \CnaeController::class . INSERT);
$app->put('/cnae', \CnaeController::class . UPDATE);
$app->delete('/cnae/{id}', \CnaeController::class . DELETE);
$app->options('/cnae', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cnae/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cnae/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

