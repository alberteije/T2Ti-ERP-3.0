<?php
declare(strict_types=1);

class IrrfModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'irrf';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'irrfDetalheModelList',
	];

	/**
		* Relations
		*/
	public function irrfDetalheModelList()
{
	return $this->hasMany(IrrfDetalheModel::class, 'id_irrf', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getDescontoPorDependenteAttribute()
	{
		return (double)$this->attributes['desconto_por_dependente'];
	}

	public function setDescontoPorDependenteAttribute($descontoPorDependente)
	{
		$this->attributes['desconto_por_dependente'] = $descontoPorDependente;
	}

	public function getMinimoParaRetencaoAttribute()
	{
		return (double)$this->attributes['minimo_para_retencao'];
	}

	public function setMinimoParaRetencaoAttribute($minimoParaRetencao)
	{
		$this->attributes['minimo_para_retencao'] = $minimoParaRetencao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setDescontoPorDependenteAttribute($object->descontoPorDependente);
				$this->setMinimoParaRetencaoAttribute($object->minimoParaRetencao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'descontoPorDependente' => $this->getDescontoPorDependenteAttribute(),
				'minimoParaRetencao' => $this->getMinimoParaRetencaoAttribute(),
				'irrfDetalheModelList' => $this->irrfDetalheModelList,
			];
	}
}