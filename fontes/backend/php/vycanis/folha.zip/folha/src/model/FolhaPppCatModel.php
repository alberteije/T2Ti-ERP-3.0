<?php
declare(strict_types=1);

class FolhaPppCatModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_ppp_cat';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function folhaPppModel()
	{
		return $this->belongsTo(FolhaPppModel::class, 'id_folha_ppp', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroCatAttribute()
	{
		return $this->attributes['numero_cat'];
	}

	public function setNumeroCatAttribute($numeroCat)
	{
		$this->attributes['numero_cat'] = $numeroCat;
	}

	public function getDataAfastamentoAttribute()
	{
		return $this->attributes['data_afastamento'];
	}

	public function setDataAfastamentoAttribute($dataAfastamento)
	{
		$this->attributes['data_afastamento'] = $dataAfastamento;
	}

	public function getDataRegistroAttribute()
	{
		return $this->attributes['data_registro'];
	}

	public function setDataRegistroAttribute($dataRegistro)
	{
		$this->attributes['data_registro'] = $dataRegistro;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroCatAttribute($object->numeroCat);
				$this->setDataAfastamentoAttribute($object->dataAfastamento);
				$this->setDataRegistroAttribute($object->dataRegistro);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroCat' => $this->getNumeroCatAttribute(),
				'dataAfastamento' => $this->getDataAfastamentoAttribute(),
				'dataRegistro' => $this->getDataRegistroAttribute(),
			];
	}
}