<?php
declare(strict_types=1);

class FolhaPppAtividadeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_ppp_atividade';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function folhaPppModel()
	{
		return $this->belongsTo(FolhaPppModel::class, 'id_folha_ppp', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
			];
	}
}