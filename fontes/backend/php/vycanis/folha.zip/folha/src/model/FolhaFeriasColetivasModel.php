<?php
declare(strict_types=1);

class FolhaFeriasColetivasModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_ferias_coletivas';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getDiasGozoAttribute()
	{
		return $this->attributes['dias_gozo'];
	}

	public function setDiasGozoAttribute($diasGozo)
	{
		$this->attributes['dias_gozo'] = $diasGozo;
	}

	public function getAbonoPecuniarioInicioAttribute()
	{
		return $this->attributes['abono_pecuniario_inicio'];
	}

	public function setAbonoPecuniarioInicioAttribute($abonoPecuniarioInicio)
	{
		$this->attributes['abono_pecuniario_inicio'] = $abonoPecuniarioInicio;
	}

	public function getAbonoPecuniarioFimAttribute()
	{
		return $this->attributes['abono_pecuniario_fim'];
	}

	public function setAbonoPecuniarioFimAttribute($abonoPecuniarioFim)
	{
		$this->attributes['abono_pecuniario_fim'] = $abonoPecuniarioFim;
	}

	public function getDiasAbonoAttribute()
	{
		return $this->attributes['dias_abono'];
	}

	public function setDiasAbonoAttribute($diasAbono)
	{
		$this->attributes['dias_abono'] = $diasAbono;
	}

	public function getDataPagamentoAttribute()
	{
		return $this->attributes['data_pagamento'];
	}

	public function setDataPagamentoAttribute($dataPagamento)
	{
		$this->attributes['data_pagamento'] = $dataPagamento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);
				$this->setDiasGozoAttribute($object->diasGozo);
				$this->setAbonoPecuniarioInicioAttribute($object->abonoPecuniarioInicio);
				$this->setAbonoPecuniarioFimAttribute($object->abonoPecuniarioFim);
				$this->setDiasAbonoAttribute($object->diasAbono);
				$this->setDataPagamentoAttribute($object->dataPagamento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'diasGozo' => $this->getDiasGozoAttribute(),
				'abonoPecuniarioInicio' => $this->getAbonoPecuniarioInicioAttribute(),
				'abonoPecuniarioFim' => $this->getAbonoPecuniarioFimAttribute(),
				'diasAbono' => $this->getDiasAbonoAttribute(),
				'dataPagamento' => $this->getDataPagamentoAttribute(),
			];
	}
}