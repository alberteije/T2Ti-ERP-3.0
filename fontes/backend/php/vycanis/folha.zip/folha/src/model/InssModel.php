<?php
declare(strict_types=1);

class InssModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'inss';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'salarioFamiliaModelList',
		'inssDetalheModelList',
	];

	/**
		* Relations
		*/
	public function salarioFamiliaModelList()
{
	return $this->hasMany(SalarioFamiliaModel::class, 'id_inss', 'id');
}

	public function inssDetalheModelList()
{
	return $this->hasMany(InssDetalheModel::class, 'id_inss', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'salarioFamiliaModelList' => $this->salarioFamiliaModelList,
				'inssDetalheModelList' => $this->inssDetalheModelList,
			];
	}
}