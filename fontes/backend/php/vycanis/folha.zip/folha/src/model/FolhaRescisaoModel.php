<?php
declare(strict_types=1);

class FolhaRescisaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_rescisao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataDemissaoAttribute()
	{
		return $this->attributes['data_demissao'];
	}

	public function setDataDemissaoAttribute($dataDemissao)
	{
		$this->attributes['data_demissao'] = $dataDemissao;
	}

	public function getDataPagamentoAttribute()
	{
		return $this->attributes['data_pagamento'];
	}

	public function setDataPagamentoAttribute($dataPagamento)
	{
		$this->attributes['data_pagamento'] = $dataPagamento;
	}

	public function getMotivoAttribute()
	{
		return $this->attributes['motivo'];
	}

	public function setMotivoAttribute($motivo)
	{
		$this->attributes['motivo'] = $motivo;
	}

	public function getMotivoEsocialAttribute()
	{
		return $this->attributes['motivo_esocial'];
	}

	public function setMotivoEsocialAttribute($motivoEsocial)
	{
		$this->attributes['motivo_esocial'] = $motivoEsocial;
	}

	public function getDataAvisoPrevioAttribute()
	{
		return $this->attributes['data_aviso_previo'];
	}

	public function setDataAvisoPrevioAttribute($dataAvisoPrevio)
	{
		$this->attributes['data_aviso_previo'] = $dataAvisoPrevio;
	}

	public function getDiasAvisoPrevioAttribute()
	{
		return $this->attributes['dias_aviso_previo'];
	}

	public function setDiasAvisoPrevioAttribute($diasAvisoPrevio)
	{
		$this->attributes['dias_aviso_previo'] = $diasAvisoPrevio;
	}

	public function getComprovouNovoEmpregoAttribute()
	{
		return $this->attributes['comprovou_novo_emprego'];
	}

	public function setComprovouNovoEmpregoAttribute($comprovouNovoEmprego)
	{
		$this->attributes['comprovou_novo_emprego'] = $comprovouNovoEmprego;
	}

	public function getDispensouEmpregadoAttribute()
	{
		return $this->attributes['dispensou_empregado'];
	}

	public function setDispensouEmpregadoAttribute($dispensouEmpregado)
	{
		$this->attributes['dispensou_empregado'] = $dispensouEmpregado;
	}

	public function getPensaoAlimenticiaAttribute()
	{
		return (double)$this->attributes['pensao_alimenticia'];
	}

	public function setPensaoAlimenticiaAttribute($pensaoAlimenticia)
	{
		$this->attributes['pensao_alimenticia'] = $pensaoAlimenticia;
	}

	public function getPensaoAlimenticiaFgtsAttribute()
	{
		return (double)$this->attributes['pensao_alimenticia_fgts'];
	}

	public function setPensaoAlimenticiaFgtsAttribute($pensaoAlimenticiaFgts)
	{
		$this->attributes['pensao_alimenticia_fgts'] = $pensaoAlimenticiaFgts;
	}

	public function getFgtsValorRescisaoAttribute()
	{
		return (double)$this->attributes['fgts_valor_rescisao'];
	}

	public function setFgtsValorRescisaoAttribute($fgtsValorRescisao)
	{
		$this->attributes['fgts_valor_rescisao'] = $fgtsValorRescisao;
	}

	public function getFgtsSaldoBancoAttribute()
	{
		return (double)$this->attributes['fgts_saldo_banco'];
	}

	public function setFgtsSaldoBancoAttribute($fgtsSaldoBanco)
	{
		$this->attributes['fgts_saldo_banco'] = $fgtsSaldoBanco;
	}

	public function getFgtsComplementoSaldoAttribute()
	{
		return (double)$this->attributes['fgts_complemento_saldo'];
	}

	public function setFgtsComplementoSaldoAttribute($fgtsComplementoSaldo)
	{
		$this->attributes['fgts_complemento_saldo'] = $fgtsComplementoSaldo;
	}

	public function getFgtsCodigoAfastamentoAttribute()
	{
		return $this->attributes['fgts_codigo_afastamento'];
	}

	public function setFgtsCodigoAfastamentoAttribute($fgtsCodigoAfastamento)
	{
		$this->attributes['fgts_codigo_afastamento'] = $fgtsCodigoAfastamento;
	}

	public function getFgtsCodigoSaqueAttribute()
	{
		return $this->attributes['fgts_codigo_saque'];
	}

	public function setFgtsCodigoSaqueAttribute($fgtsCodigoSaque)
	{
		$this->attributes['fgts_codigo_saque'] = $fgtsCodigoSaque;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataDemissaoAttribute($object->dataDemissao);
				$this->setDataPagamentoAttribute($object->dataPagamento);
				$this->setMotivoAttribute($object->motivo);
				$this->setMotivoEsocialAttribute($object->motivoEsocial);
				$this->setDataAvisoPrevioAttribute($object->dataAvisoPrevio);
				$this->setDiasAvisoPrevioAttribute($object->diasAvisoPrevio);
				$this->setComprovouNovoEmpregoAttribute($object->comprovouNovoEmprego);
				$this->setDispensouEmpregadoAttribute($object->dispensouEmpregado);
				$this->setPensaoAlimenticiaAttribute($object->pensaoAlimenticia);
				$this->setPensaoAlimenticiaFgtsAttribute($object->pensaoAlimenticiaFgts);
				$this->setFgtsValorRescisaoAttribute($object->fgtsValorRescisao);
				$this->setFgtsSaldoBancoAttribute($object->fgtsSaldoBanco);
				$this->setFgtsComplementoSaldoAttribute($object->fgtsComplementoSaldo);
				$this->setFgtsCodigoAfastamentoAttribute($object->fgtsCodigoAfastamento);
				$this->setFgtsCodigoSaqueAttribute($object->fgtsCodigoSaque);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataDemissao' => $this->getDataDemissaoAttribute(),
				'dataPagamento' => $this->getDataPagamentoAttribute(),
				'motivo' => $this->getMotivoAttribute(),
				'motivoEsocial' => $this->getMotivoEsocialAttribute(),
				'dataAvisoPrevio' => $this->getDataAvisoPrevioAttribute(),
				'diasAvisoPrevio' => $this->getDiasAvisoPrevioAttribute(),
				'comprovouNovoEmprego' => $this->getComprovouNovoEmpregoAttribute(),
				'dispensouEmpregado' => $this->getDispensouEmpregadoAttribute(),
				'pensaoAlimenticia' => $this->getPensaoAlimenticiaAttribute(),
				'pensaoAlimenticiaFgts' => $this->getPensaoAlimenticiaFgtsAttribute(),
				'fgtsValorRescisao' => $this->getFgtsValorRescisaoAttribute(),
				'fgtsSaldoBanco' => $this->getFgtsSaldoBancoAttribute(),
				'fgtsComplementoSaldo' => $this->getFgtsComplementoSaldoAttribute(),
				'fgtsCodigoAfastamento' => $this->getFgtsCodigoAfastamentoAttribute(),
				'fgtsCodigoSaque' => $this->getFgtsCodigoSaqueAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}