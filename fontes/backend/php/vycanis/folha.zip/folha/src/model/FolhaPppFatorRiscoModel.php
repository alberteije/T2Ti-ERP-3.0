<?php
declare(strict_types=1);

class FolhaPppFatorRiscoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_ppp_fator_risco';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function folhaPppModel()
	{
		return $this->belongsTo(FolhaPppModel::class, 'id_folha_ppp', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getFatorRiscoAttribute()
	{
		return $this->attributes['fator_risco'];
	}

	public function setFatorRiscoAttribute($fatorRisco)
	{
		$this->attributes['fator_risco'] = $fatorRisco;
	}

	public function getIntensidadeAttribute()
	{
		return $this->attributes['intensidade'];
	}

	public function setIntensidadeAttribute($intensidade)
	{
		$this->attributes['intensidade'] = $intensidade;
	}

	public function getTecnicaUtilizadaAttribute()
	{
		return $this->attributes['tecnica_utilizada'];
	}

	public function setTecnicaUtilizadaAttribute($tecnicaUtilizada)
	{
		$this->attributes['tecnica_utilizada'] = $tecnicaUtilizada;
	}

	public function getEpcEficazAttribute()
	{
		return $this->attributes['epc_eficaz'];
	}

	public function setEpcEficazAttribute($epcEficaz)
	{
		$this->attributes['epc_eficaz'] = $epcEficaz;
	}

	public function getEpiEficazAttribute()
	{
		return $this->attributes['epi_eficaz'];
	}

	public function setEpiEficazAttribute($epiEficaz)
	{
		$this->attributes['epi_eficaz'] = $epiEficaz;
	}

	public function getCaEpiAttribute()
	{
		return $this->attributes['ca_epi'];
	}

	public function setCaEpiAttribute($caEpi)
	{
		$this->attributes['ca_epi'] = $caEpi;
	}

	public function getAtendimentoNr061Attribute()
	{
		return $this->attributes['atendimento_nr06_1'];
	}

	public function setAtendimentoNr061Attribute($atendimentoNr061)
	{
		$this->attributes['atendimento_nr06_1'] = $atendimentoNr061;
	}

	public function getAtendimentoNr062Attribute()
	{
		return $this->attributes['atendimento_nr06_2'];
	}

	public function setAtendimentoNr062Attribute($atendimentoNr062)
	{
		$this->attributes['atendimento_nr06_2'] = $atendimentoNr062;
	}

	public function getAtendimentoNr063Attribute()
	{
		return $this->attributes['atendimento_nr06_3'];
	}

	public function setAtendimentoNr063Attribute($atendimentoNr063)
	{
		$this->attributes['atendimento_nr06_3'] = $atendimentoNr063;
	}

	public function getAtendimentoNr064Attribute()
	{
		return $this->attributes['atendimento_nr06_4'];
	}

	public function setAtendimentoNr064Attribute($atendimentoNr064)
	{
		$this->attributes['atendimento_nr06_4'] = $atendimentoNr064;
	}

	public function getAtendimentoNr065Attribute()
	{
		return $this->attributes['atendimento_nr06_5'];
	}

	public function setAtendimentoNr065Attribute($atendimentoNr065)
	{
		$this->attributes['atendimento_nr06_5'] = $atendimentoNr065;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);
				$this->setTipoAttribute($object->tipo);
				$this->setFatorRiscoAttribute($object->fatorRisco);
				$this->setIntensidadeAttribute($object->intensidade);
				$this->setTecnicaUtilizadaAttribute($object->tecnicaUtilizada);
				$this->setEpcEficazAttribute($object->epcEficaz);
				$this->setEpiEficazAttribute($object->epiEficaz);
				$this->setCaEpiAttribute($object->caEpi);
				$this->setAtendimentoNr061Attribute($object->atendimentoNr061);
				$this->setAtendimentoNr062Attribute($object->atendimentoNr062);
				$this->setAtendimentoNr063Attribute($object->atendimentoNr063);
				$this->setAtendimentoNr064Attribute($object->atendimentoNr064);
				$this->setAtendimentoNr065Attribute($object->atendimentoNr065);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'fatorRisco' => $this->getFatorRiscoAttribute(),
				'intensidade' => $this->getIntensidadeAttribute(),
				'tecnicaUtilizada' => $this->getTecnicaUtilizadaAttribute(),
				'epcEficaz' => $this->getEpcEficazAttribute(),
				'epiEficaz' => $this->getEpiEficazAttribute(),
				'caEpi' => $this->getCaEpiAttribute(),
				'atendimentoNr061' => $this->getAtendimentoNr061Attribute(),
				'atendimentoNr062' => $this->getAtendimentoNr062Attribute(),
				'atendimentoNr063' => $this->getAtendimentoNr063Attribute(),
				'atendimentoNr064' => $this->getAtendimentoNr064Attribute(),
				'atendimentoNr065' => $this->getAtendimentoNr065Attribute(),
			];
	}
}