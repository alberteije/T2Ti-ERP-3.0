<?php
declare(strict_types=1);

class FolhaEventoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_evento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getBaseCalculoAttribute()
	{
		return $this->attributes['base_calculo'];
	}

	public function setBaseCalculoAttribute($baseCalculo)
	{
		$this->attributes['base_calculo'] = $baseCalculo;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getUnidadeAttribute()
	{
		return $this->attributes['unidade'];
	}

	public function setUnidadeAttribute($unidade)
	{
		$this->attributes['unidade'] = $unidade;
	}

	public function getTaxaAttribute()
	{
		return (double)$this->attributes['taxa'];
	}

	public function setTaxaAttribute($taxa)
	{
		$this->attributes['taxa'] = $taxa;
	}

	public function getRubricaEsocialAttribute()
	{
		return $this->attributes['rubrica_esocial'];
	}

	public function setRubricaEsocialAttribute($rubricaEsocial)
	{
		$this->attributes['rubrica_esocial'] = $rubricaEsocial;
	}

	public function getCodIncidenciaPrevidenciaAttribute()
	{
		return $this->attributes['cod_incidencia_previdencia'];
	}

	public function setCodIncidenciaPrevidenciaAttribute($codIncidenciaPrevidencia)
	{
		$this->attributes['cod_incidencia_previdencia'] = $codIncidenciaPrevidencia;
	}

	public function getCodIncidenciaIrrfAttribute()
	{
		return $this->attributes['cod_incidencia_irrf'];
	}

	public function setCodIncidenciaIrrfAttribute($codIncidenciaIrrf)
	{
		$this->attributes['cod_incidencia_irrf'] = $codIncidenciaIrrf;
	}

	public function getCodIncidenciaFgtsAttribute()
	{
		return $this->attributes['cod_incidencia_fgts'];
	}

	public function setCodIncidenciaFgtsAttribute($codIncidenciaFgts)
	{
		$this->attributes['cod_incidencia_fgts'] = $codIncidenciaFgts;
	}

	public function getCodIncidenciaSindicatoAttribute()
	{
		return $this->attributes['cod_incidencia_sindicato'];
	}

	public function setCodIncidenciaSindicatoAttribute($codIncidenciaSindicato)
	{
		$this->attributes['cod_incidencia_sindicato'] = $codIncidenciaSindicato;
	}

	public function getRepercuteDsrAttribute()
	{
		return $this->attributes['repercute_dsr'];
	}

	public function setRepercuteDsrAttribute($repercuteDsr)
	{
		$this->attributes['repercute_dsr'] = $repercuteDsr;
	}

	public function getRepercute13Attribute()
	{
		return $this->attributes['repercute_13'];
	}

	public function setRepercute13Attribute($repercute13)
	{
		$this->attributes['repercute_13'] = $repercute13;
	}

	public function getRepercuteFeriasAttribute()
	{
		return $this->attributes['repercute_ferias'];
	}

	public function setRepercuteFeriasAttribute($repercuteFerias)
	{
		$this->attributes['repercute_ferias'] = $repercuteFerias;
	}

	public function getRepercuteAvisoAttribute()
	{
		return $this->attributes['repercute_aviso'];
	}

	public function setRepercuteAvisoAttribute($repercuteAviso)
	{
		$this->attributes['repercute_aviso'] = $repercuteAviso;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setNomeAttribute($object->nome);
				$this->setDescricaoAttribute($object->descricao);
				$this->setBaseCalculoAttribute($object->baseCalculo);
				$this->setTipoAttribute($object->tipo);
				$this->setUnidadeAttribute($object->unidade);
				$this->setTaxaAttribute($object->taxa);
				$this->setRubricaEsocialAttribute($object->rubricaEsocial);
				$this->setCodIncidenciaPrevidenciaAttribute($object->codIncidenciaPrevidencia);
				$this->setCodIncidenciaIrrfAttribute($object->codIncidenciaIrrf);
				$this->setCodIncidenciaFgtsAttribute($object->codIncidenciaFgts);
				$this->setCodIncidenciaSindicatoAttribute($object->codIncidenciaSindicato);
				$this->setRepercuteDsrAttribute($object->repercuteDsr);
				$this->setRepercute13Attribute($object->repercute13);
				$this->setRepercuteFeriasAttribute($object->repercuteFerias);
				$this->setRepercuteAvisoAttribute($object->repercuteAviso);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'baseCalculo' => $this->getBaseCalculoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'unidade' => $this->getUnidadeAttribute(),
				'taxa' => $this->getTaxaAttribute(),
				'rubricaEsocial' => $this->getRubricaEsocialAttribute(),
				'codIncidenciaPrevidencia' => $this->getCodIncidenciaPrevidenciaAttribute(),
				'codIncidenciaIrrf' => $this->getCodIncidenciaIrrfAttribute(),
				'codIncidenciaFgts' => $this->getCodIncidenciaFgtsAttribute(),
				'codIncidenciaSindicato' => $this->getCodIncidenciaSindicatoAttribute(),
				'repercuteDsr' => $this->getRepercuteDsrAttribute(),
				'repercute13' => $this->getRepercute13Attribute(),
				'repercuteFerias' => $this->getRepercuteFeriasAttribute(),
				'repercuteAviso' => $this->getRepercuteAvisoAttribute(),
			];
	}
}