<?php
declare(strict_types=1);

class FpasModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fpas';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getCnaeAttribute()
	{
		return $this->attributes['cnae'];
	}

	public function setCnaeAttribute($cnae)
	{
		$this->attributes['cnae'] = $cnae;
	}

	public function getAliquotaSatAttribute()
	{
		return (double)$this->attributes['aliquota_sat'];
	}

	public function setAliquotaSatAttribute($aliquotaSat)
	{
		$this->attributes['aliquota_sat'] = $aliquotaSat;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getPercentualInssPatronalAttribute()
	{
		return (double)$this->attributes['percentual_inss_patronal'];
	}

	public function setPercentualInssPatronalAttribute($percentualInssPatronal)
	{
		$this->attributes['percentual_inss_patronal'] = $percentualInssPatronal;
	}

	public function getCodigoTerceiroAttribute()
	{
		return $this->attributes['codigo_terceiro'];
	}

	public function setCodigoTerceiroAttribute($codigoTerceiro)
	{
		$this->attributes['codigo_terceiro'] = $codigoTerceiro;
	}

	public function getPercentualTerceirosAttribute()
	{
		return (double)$this->attributes['percentual_terceiros'];
	}

	public function setPercentualTerceirosAttribute($percentualTerceiros)
	{
		$this->attributes['percentual_terceiros'] = $percentualTerceiros;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setCnaeAttribute($object->cnae);
				$this->setAliquotaSatAttribute($object->aliquotaSat);
				$this->setDescricaoAttribute($object->descricao);
				$this->setPercentualInssPatronalAttribute($object->percentualInssPatronal);
				$this->setCodigoTerceiroAttribute($object->codigoTerceiro);
				$this->setPercentualTerceirosAttribute($object->percentualTerceiros);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'cnae' => $this->getCnaeAttribute(),
				'aliquotaSat' => $this->getAliquotaSatAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'percentualInssPatronal' => $this->getPercentualInssPatronalAttribute(),
				'codigoTerceiro' => $this->getCodigoTerceiroAttribute(),
				'percentualTerceiros' => $this->getPercentualTerceirosAttribute(),
			];
	}
}