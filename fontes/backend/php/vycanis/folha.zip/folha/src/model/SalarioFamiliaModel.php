<?php
declare(strict_types=1);

class SalarioFamiliaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'salario_familia';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function inssModel()
	{
		return $this->belongsTo(InssModel::class, 'id_inss', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getFaixaAttribute()
	{
		return $this->attributes['faixa'];
	}

	public function setFaixaAttribute($faixa)
	{
		$this->attributes['faixa'] = $faixa;
	}

	public function getDeAttribute()
	{
		return (double)$this->attributes['de'];
	}

	public function setDeAttribute($de)
	{
		$this->attributes['de'] = $de;
	}

	public function getAteAttribute()
	{
		return (double)$this->attributes['ate'];
	}

	public function setAteAttribute($ate)
	{
		$this->attributes['ate'] = $ate;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setFaixaAttribute($object->faixa);
				$this->setDeAttribute($object->de);
				$this->setAteAttribute($object->ate);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'faixa' => $this->getFaixaAttribute(),
				'de' => $this->getDeAttribute(),
				'ate' => $this->getAteAttribute(),
				'valor' => $this->getValorAttribute(),
			];
	}
}