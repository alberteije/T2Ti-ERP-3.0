<?php
declare(strict_types=1);

class EmpresaTransporteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'empresa_transporte';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'empresaTransporteItinerarioModelList',
	];

	/**
		* Relations
		*/
	public function empresaTransporteItinerarioModelList()
{
	return $this->hasMany(EmpresaTransporteItinerarioModel::class, 'id_empresa_transporte', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getClassificacaoContabilContaAttribute()
	{
		return $this->attributes['classificacao_contabil_conta'];
	}

	public function setClassificacaoContabilContaAttribute($classificacaoContabilConta)
	{
		$this->attributes['classificacao_contabil_conta'] = $classificacaoContabilConta;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setUfAttribute($object->uf);
				$this->setClassificacaoContabilContaAttribute($object->classificacaoContabilConta);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'uf' => $this->getUfAttribute(),
				'classificacaoContabilConta' => $this->getClassificacaoContabilContaAttribute(),
				'empresaTransporteItinerarioModelList' => $this->empresaTransporteItinerarioModelList,
			];
	}
}