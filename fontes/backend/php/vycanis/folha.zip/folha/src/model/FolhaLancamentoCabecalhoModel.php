<?php
declare(strict_types=1);

class FolhaLancamentoCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_lancamento_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'folhaLancamentoDetalheModelList',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function folhaLancamentoDetalheModelList()
{
	return $this->hasMany(FolhaLancamentoDetalheModel::class, 'id_folha_lancamento_cabecalho', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setTipoAttribute($object->tipo);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'folhaLancamentoDetalheModelList' => $this->folhaLancamentoDetalheModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}