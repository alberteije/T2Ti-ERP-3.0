<?php
declare(strict_types=1);

class FolhaPppModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_ppp';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'folhaPppCatModelList',
		'folhaPppAtividadeModelList',
		'folhaPppFatorRiscoModelList',
		'folhaPppExameMedicoModelList',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function folhaPppCatModelList()
{
	return $this->hasMany(FolhaPppCatModel::class, 'id_folha_ppp', 'id');
}

	public function folhaPppAtividadeModelList()
{
	return $this->hasMany(FolhaPppAtividadeModel::class, 'id_folha_ppp', 'id');
}

	public function folhaPppFatorRiscoModelList()
{
	return $this->hasMany(FolhaPppFatorRiscoModel::class, 'id_folha_ppp', 'id');
}

	public function folhaPppExameMedicoModelList()
{
	return $this->hasMany(FolhaPppExameMedicoModel::class, 'id_folha_ppp', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'folhaPppCatModelList' => $this->folhaPppCatModelList,
				'folhaPppAtividadeModelList' => $this->folhaPppAtividadeModelList,
				'folhaPppFatorRiscoModelList' => $this->folhaPppFatorRiscoModelList,
				'folhaPppExameMedicoModelList' => $this->folhaPppExameMedicoModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}