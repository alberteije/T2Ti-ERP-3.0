<?php
declare(strict_types=1);

class SalarioMinimoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'salario_minimo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getVigenciaAttribute()
	{
		return $this->attributes['vigencia'];
	}

	public function setVigenciaAttribute($vigencia)
	{
		$this->attributes['vigencia'] = $vigencia;
	}

	public function getValorMensalAttribute()
	{
		return (double)$this->attributes['valor_mensal'];
	}

	public function setValorMensalAttribute($valorMensal)
	{
		$this->attributes['valor_mensal'] = $valorMensal;
	}

	public function getValorDiarioAttribute()
	{
		return (double)$this->attributes['valor_diario'];
	}

	public function setValorDiarioAttribute($valorDiario)
	{
		$this->attributes['valor_diario'] = $valorDiario;
	}

	public function getValorHoraAttribute()
	{
		return (double)$this->attributes['valor_hora'];
	}

	public function setValorHoraAttribute($valorHora)
	{
		$this->attributes['valor_hora'] = $valorHora;
	}

	public function getNormaLegalAttribute()
	{
		return $this->attributes['norma_legal'];
	}

	public function setNormaLegalAttribute($normaLegal)
	{
		$this->attributes['norma_legal'] = $normaLegal;
	}

	public function getDouAttribute()
	{
		return $this->attributes['dou'];
	}

	public function setDouAttribute($dou)
	{
		$this->attributes['dou'] = $dou;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setVigenciaAttribute($object->vigencia);
				$this->setValorMensalAttribute($object->valorMensal);
				$this->setValorDiarioAttribute($object->valorDiario);
				$this->setValorHoraAttribute($object->valorHora);
				$this->setNormaLegalAttribute($object->normaLegal);
				$this->setDouAttribute($object->dou);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'vigencia' => $this->getVigenciaAttribute(),
				'valorMensal' => $this->getValorMensalAttribute(),
				'valorDiario' => $this->getValorDiarioAttribute(),
				'valorHora' => $this->getValorHoraAttribute(),
				'normaLegal' => $this->getNormaLegalAttribute(),
				'dou' => $this->getDouAttribute(),
			];
	}
}