<?php
declare(strict_types=1);

class FolhaLancamentoComissaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_lancamento_comissao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getVencimentoAttribute()
	{
		return $this->attributes['vencimento'];
	}

	public function setVencimentoAttribute($vencimento)
	{
		$this->attributes['vencimento'] = $vencimento;
	}

	public function getBaseCalculoAttribute()
	{
		return (double)$this->attributes['base_calculo'];
	}

	public function setBaseCalculoAttribute($baseCalculo)
	{
		$this->attributes['base_calculo'] = $baseCalculo;
	}

	public function getValorComissaoAttribute()
	{
		return (double)$this->attributes['valor_comissao'];
	}

	public function setValorComissaoAttribute($valorComissao)
	{
		$this->attributes['valor_comissao'] = $valorComissao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setVencimentoAttribute($object->vencimento);
				$this->setBaseCalculoAttribute($object->baseCalculo);
				$this->setValorComissaoAttribute($object->valorComissao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'vencimento' => $this->getVencimentoAttribute(),
				'baseCalculo' => $this->getBaseCalculoAttribute(),
				'valorComissao' => $this->getValorComissaoAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}