<?php
declare(strict_types=1);

class FolhaAfastamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_afastamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
		'folhaTipoAfastamentoModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function folhaTipoAfastamentoModel()
	{
		return $this->belongsTo(FolhaTipoAfastamentoModel::class, 'id_folha_tipo_afastamento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getDiasAfastadoAttribute()
	{
		return $this->attributes['dias_afastado'];
	}

	public function setDiasAfastadoAttribute($diasAfastado)
	{
		$this->attributes['dias_afastado'] = $diasAfastado;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);
				$this->setDiasAfastadoAttribute($object->diasAfastado);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$folhaTipoAfastamentoModel = new FolhaTipoAfastamentoModel();
				$folhaTipoAfastamentoModel->mapping($object->folhaTipoAfastamentoModel);
				$this->folhaTipoAfastamentoModel()->associate($folhaTipoAfastamentoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'diasAfastado' => $this->getDiasAfastadoAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'folhaTipoAfastamentoModel' => $this->folhaTipoAfastamentoModel,
			];
	}
}