<?php
declare(strict_types=1);

class FeriadosModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'feriados';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getAnoAttribute()
	{
		return $this->attributes['ano'];
	}

	public function setAnoAttribute($ano)
	{
		$this->attributes['ano'] = $ano;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getAbrangenciaAttribute()
	{
		return $this->attributes['abrangencia'];
	}

	public function setAbrangenciaAttribute($abrangencia)
	{
		$this->attributes['abrangencia'] = $abrangencia;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getMunicipioIbgeAttribute()
	{
		return $this->attributes['municipio_ibge'];
	}

	public function setMunicipioIbgeAttribute($municipioIbge)
	{
		$this->attributes['municipio_ibge'] = $municipioIbge;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getDataFeriadoAttribute()
	{
		return $this->attributes['data_feriado'];
	}

	public function setDataFeriadoAttribute($dataFeriado)
	{
		$this->attributes['data_feriado'] = $dataFeriado;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setAnoAttribute($object->ano);
				$this->setNomeAttribute($object->nome);
				$this->setAbrangenciaAttribute($object->abrangencia);
				$this->setUfAttribute($object->uf);
				$this->setMunicipioIbgeAttribute($object->municipioIbge);
				$this->setTipoAttribute($object->tipo);
				$this->setDataFeriadoAttribute($object->dataFeriado);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ano' => $this->getAnoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'abrangencia' => $this->getAbrangenciaAttribute(),
				'uf' => $this->getUfAttribute(),
				'municipioIbge' => $this->getMunicipioIbgeAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'dataFeriado' => $this->getDataFeriadoAttribute(),
			];
	}
}