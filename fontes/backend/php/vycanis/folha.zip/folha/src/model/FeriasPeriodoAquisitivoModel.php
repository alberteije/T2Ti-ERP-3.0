<?php
declare(strict_types=1);

class FeriasPeriodoAquisitivoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ferias_periodo_aquisitivo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	public function getLimiteParaGozoAttribute()
	{
		return $this->attributes['limite_para_gozo'];
	}

	public function setLimiteParaGozoAttribute($limiteParaGozo)
	{
		$this->attributes['limite_para_gozo'] = $limiteParaGozo;
	}

	public function getDescontarFaltasAttribute()
	{
		return $this->attributes['descontar_faltas'];
	}

	public function setDescontarFaltasAttribute($descontarFaltas)
	{
		$this->attributes['descontar_faltas'] = $descontarFaltas;
	}

	public function getDesconsiderarAfastamentoAttribute()
	{
		return $this->attributes['desconsiderar_afastamento'];
	}

	public function setDesconsiderarAfastamentoAttribute($desconsiderarAfastamento)
	{
		$this->attributes['desconsiderar_afastamento'] = $desconsiderarAfastamento;
	}

	public function getAfastamentoPrevidenciaAttribute()
	{
		return $this->attributes['afastamento_previdencia'];
	}

	public function setAfastamentoPrevidenciaAttribute($afastamentoPrevidencia)
	{
		$this->attributes['afastamento_previdencia'] = $afastamentoPrevidencia;
	}

	public function getAfastamentoSemRemunAttribute()
	{
		return $this->attributes['afastamento_sem_remun'];
	}

	public function setAfastamentoSemRemunAttribute($afastamentoSemRemun)
	{
		$this->attributes['afastamento_sem_remun'] = $afastamentoSemRemun;
	}

	public function getAfastamentoComRemunAttribute()
	{
		return $this->attributes['afastamento_com_remun'];
	}

	public function setAfastamentoComRemunAttribute($afastamentoComRemun)
	{
		$this->attributes['afastamento_com_remun'] = $afastamentoComRemun;
	}

	public function getDiasDireitoAttribute()
	{
		return $this->attributes['dias_direito'];
	}

	public function setDiasDireitoAttribute($diasDireito)
	{
		$this->attributes['dias_direito'] = $diasDireito;
	}

	public function getDiasGozadosAttribute()
	{
		return $this->attributes['dias_gozados'];
	}

	public function setDiasGozadosAttribute($diasGozados)
	{
		$this->attributes['dias_gozados'] = $diasGozados;
	}

	public function getDiasFaltasAttribute()
	{
		return $this->attributes['dias_faltas'];
	}

	public function setDiasFaltasAttribute($diasFaltas)
	{
		$this->attributes['dias_faltas'] = $diasFaltas;
	}

	public function getDiasRestantesAttribute()
	{
		return $this->attributes['dias_restantes'];
	}

	public function setDiasRestantesAttribute($diasRestantes)
	{
		$this->attributes['dias_restantes'] = $diasRestantes;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);
				$this->setSituacaoAttribute($object->situacao);
				$this->setLimiteParaGozoAttribute($object->limiteParaGozo);
				$this->setDescontarFaltasAttribute($object->descontarFaltas);
				$this->setDesconsiderarAfastamentoAttribute($object->desconsiderarAfastamento);
				$this->setAfastamentoPrevidenciaAttribute($object->afastamentoPrevidencia);
				$this->setAfastamentoSemRemunAttribute($object->afastamentoSemRemun);
				$this->setAfastamentoComRemunAttribute($object->afastamentoComRemun);
				$this->setDiasDireitoAttribute($object->diasDireito);
				$this->setDiasGozadosAttribute($object->diasGozados);
				$this->setDiasFaltasAttribute($object->diasFaltas);
				$this->setDiasRestantesAttribute($object->diasRestantes);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'limiteParaGozo' => $this->getLimiteParaGozoAttribute(),
				'descontarFaltas' => $this->getDescontarFaltasAttribute(),
				'desconsiderarAfastamento' => $this->getDesconsiderarAfastamentoAttribute(),
				'afastamentoPrevidencia' => $this->getAfastamentoPrevidenciaAttribute(),
				'afastamentoSemRemun' => $this->getAfastamentoSemRemunAttribute(),
				'afastamentoComRemun' => $this->getAfastamentoComRemunAttribute(),
				'diasDireito' => $this->getDiasDireitoAttribute(),
				'diasGozados' => $this->getDiasGozadosAttribute(),
				'diasFaltas' => $this->getDiasFaltasAttribute(),
				'diasRestantes' => $this->getDiasRestantesAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}