<?php
declare(strict_types=1);

class FolhaPppExameMedicoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_ppp_exame_medico';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function folhaPppModel()
	{
		return $this->belongsTo(FolhaPppModel::class, 'id_folha_ppp', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataUltimoAttribute()
	{
		return $this->attributes['data_ultimo'];
	}

	public function setDataUltimoAttribute($dataUltimo)
	{
		$this->attributes['data_ultimo'] = $dataUltimo;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getExameAttribute()
	{
		return $this->attributes['exame'];
	}

	public function setExameAttribute($exame)
	{
		$this->attributes['exame'] = $exame;
	}

	public function getNaturezaAttribute()
	{
		return $this->attributes['natureza'];
	}

	public function setNaturezaAttribute($natureza)
	{
		$this->attributes['natureza'] = $natureza;
	}

	public function getIndicacaoResultadosAttribute()
	{
		return $this->attributes['indicacao_resultados'];
	}

	public function setIndicacaoResultadosAttribute($indicacaoResultados)
	{
		$this->attributes['indicacao_resultados'] = $indicacaoResultados;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataUltimoAttribute($object->dataUltimo);
				$this->setTipoAttribute($object->tipo);
				$this->setExameAttribute($object->exame);
				$this->setNaturezaAttribute($object->natureza);
				$this->setIndicacaoResultadosAttribute($object->indicacaoResultados);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataUltimo' => $this->getDataUltimoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'exame' => $this->getExameAttribute(),
				'natureza' => $this->getNaturezaAttribute(),
				'indicacaoResultados' => $this->getIndicacaoResultadosAttribute(),
			];
	}
}