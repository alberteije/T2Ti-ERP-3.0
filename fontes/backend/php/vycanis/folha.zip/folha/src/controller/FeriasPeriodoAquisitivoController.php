<?php
class FeriasPeriodoAquisitivoController extends ControllerBase
{

		private $feriasPeriodoAquisitivoService = null;

		public function __construct()
		{	 
				$this->feriasPeriodoAquisitivoService = new FeriasPeriodoAquisitivoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->feriasPeriodoAquisitivoService->getListFilter($filter);
						} else {
								$resultList = $this->feriasPeriodoAquisitivoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList FeriasPeriodoAquisitivo]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->feriasPeriodoAquisitivoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject FeriasPeriodoAquisitivo]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject FeriasPeriodoAquisitivo]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert FeriasPeriodoAquisitivo]', null);
						}

						$objModel = new FeriasPeriodoAquisitivoModel();
						$objModel->mapping($objJson);

						$this->feriasPeriodoAquisitivoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert FeriasPeriodoAquisitivo]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->feriasPeriodoAquisitivoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update FeriasPeriodoAquisitivo]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->feriasPeriodoAquisitivoService->save($objFromDatabase);
								$objFromDatabase = $this->feriasPeriodoAquisitivoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update FeriasPeriodoAquisitivo]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->feriasPeriodoAquisitivoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete FeriasPeriodoAquisitivo]', null);
						} else {
								$this->feriasPeriodoAquisitivoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete FeriasPeriodoAquisitivo]', $e);
				}
		}
}
