<?php
class SefipCodigoRecolhimentoController extends ControllerBase
{

		private $sefipCodigoRecolhimentoService = null;

		public function __construct()
		{	 
				$this->sefipCodigoRecolhimentoService = new SefipCodigoRecolhimentoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->sefipCodigoRecolhimentoService->getListFilter($filter);
						} else {
								$resultList = $this->sefipCodigoRecolhimentoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList SefipCodigoRecolhimento]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->sefipCodigoRecolhimentoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject SefipCodigoRecolhimento]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject SefipCodigoRecolhimento]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert SefipCodigoRecolhimento]', null);
						}

						$objModel = new SefipCodigoRecolhimentoModel();
						$objModel->mapping($objJson);

						$this->sefipCodigoRecolhimentoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert SefipCodigoRecolhimento]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->sefipCodigoRecolhimentoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update SefipCodigoRecolhimento]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->sefipCodigoRecolhimentoService->save($objFromDatabase);
								$objFromDatabase = $this->sefipCodigoRecolhimentoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update SefipCodigoRecolhimento]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->sefipCodigoRecolhimentoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete SefipCodigoRecolhimento]', null);
						} else {
								$this->sefipCodigoRecolhimentoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete SefipCodigoRecolhimento]', $e);
				}
		}
}
