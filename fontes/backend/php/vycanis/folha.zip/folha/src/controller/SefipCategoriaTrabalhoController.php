<?php
class SefipCategoriaTrabalhoController extends ControllerBase
{

		private $sefipCategoriaTrabalhoService = null;

		public function __construct()
		{	 
				$this->sefipCategoriaTrabalhoService = new SefipCategoriaTrabalhoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->sefipCategoriaTrabalhoService->getListFilter($filter);
						} else {
								$resultList = $this->sefipCategoriaTrabalhoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList SefipCategoriaTrabalho]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->sefipCategoriaTrabalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject SefipCategoriaTrabalho]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject SefipCategoriaTrabalho]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert SefipCategoriaTrabalho]', null);
						}

						$objModel = new SefipCategoriaTrabalhoModel();
						$objModel->mapping($objJson);

						$this->sefipCategoriaTrabalhoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert SefipCategoriaTrabalho]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->sefipCategoriaTrabalhoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update SefipCategoriaTrabalho]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->sefipCategoriaTrabalhoService->save($objFromDatabase);
								$objFromDatabase = $this->sefipCategoriaTrabalhoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update SefipCategoriaTrabalho]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->sefipCategoriaTrabalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete SefipCategoriaTrabalho]', null);
						} else {
								$this->sefipCategoriaTrabalhoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete SefipCategoriaTrabalho]', $e);
				}
		}
}
