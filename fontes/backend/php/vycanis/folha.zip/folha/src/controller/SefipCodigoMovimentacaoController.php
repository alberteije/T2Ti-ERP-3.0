<?php
class SefipCodigoMovimentacaoController extends ControllerBase
{

		private $sefipCodigoMovimentacaoService = null;

		public function __construct()
		{	 
				$this->sefipCodigoMovimentacaoService = new SefipCodigoMovimentacaoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->sefipCodigoMovimentacaoService->getListFilter($filter);
						} else {
								$resultList = $this->sefipCodigoMovimentacaoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList SefipCodigoMovimentacao]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->sefipCodigoMovimentacaoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject SefipCodigoMovimentacao]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject SefipCodigoMovimentacao]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert SefipCodigoMovimentacao]', null);
						}

						$objModel = new SefipCodigoMovimentacaoModel();
						$objModel->mapping($objJson);

						$this->sefipCodigoMovimentacaoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert SefipCodigoMovimentacao]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->sefipCodigoMovimentacaoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update SefipCodigoMovimentacao]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->sefipCodigoMovimentacaoService->save($objFromDatabase);
								$objFromDatabase = $this->sefipCodigoMovimentacaoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update SefipCodigoMovimentacao]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->sefipCodigoMovimentacaoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete SefipCodigoMovimentacao]', null);
						} else {
								$this->sefipCodigoMovimentacaoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete SefipCodigoMovimentacao]', $e);
				}
		}
}
