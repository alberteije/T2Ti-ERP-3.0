<?php
class EmpresaTransporteItinerarioController extends ControllerBase
{

		private $empresaTransporteItinerarioService = null;

		public function __construct()
		{	 
				$this->empresaTransporteItinerarioService = new EmpresaTransporteItinerarioService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->empresaTransporteItinerarioService->getListFilter($filter);
						} else {
								$resultList = $this->empresaTransporteItinerarioService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList EmpresaTransporteItinerario]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->empresaTransporteItinerarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject EmpresaTransporteItinerario]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject EmpresaTransporteItinerario]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert EmpresaTransporteItinerario]', null);
						}

						$objModel = new EmpresaTransporteItinerarioModel();
						$objModel->mapping($objJson);

						$this->empresaTransporteItinerarioService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert EmpresaTransporteItinerario]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->empresaTransporteItinerarioService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update EmpresaTransporteItinerario]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->empresaTransporteItinerarioService->save($objFromDatabase);
								$objFromDatabase = $this->empresaTransporteItinerarioService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update EmpresaTransporteItinerario]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->empresaTransporteItinerarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete EmpresaTransporteItinerario]', null);
						} else {
								$this->empresaTransporteItinerarioService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete EmpresaTransporteItinerario]', $e);
				}
		}
}
