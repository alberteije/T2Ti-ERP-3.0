<?php
class FolhaHistoricoSalarialService extends ServiceBase
{
  public function getList()
  {
    return FolhaHistoricoSalarialModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaHistoricoSalarialModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaHistoricoSalarialModel::find($id);
  }

}