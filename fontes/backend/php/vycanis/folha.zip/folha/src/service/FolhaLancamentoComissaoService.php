<?php
class FolhaLancamentoComissaoService extends ServiceBase
{
  public function getList()
  {
    return FolhaLancamentoComissaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaLancamentoComissaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaLancamentoComissaoModel::find($id);
  }

}