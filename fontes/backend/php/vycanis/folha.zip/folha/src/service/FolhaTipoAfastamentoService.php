<?php
class FolhaTipoAfastamentoService extends ServiceBase
{
  public function getList()
  {
    return FolhaTipoAfastamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaTipoAfastamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaTipoAfastamentoModel::find($id);
  }

}