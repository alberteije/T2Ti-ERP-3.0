<?php
use Illuminate\Database\Capsule\Manager as DB;
class IrrfService extends ServiceBase
{
	public function getList()
	{
		return IrrfModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return IrrfModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return IrrfModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// irrfDetalhe
		$irrfDetalheModelListJson = $objJson->irrfDetalheModelList;
		if ($irrfDetalheModelListJson != null) {
			for ($i = 0; $i < count($irrfDetalheModelListJson); $i++) {
				$irrfDetalhe = new IrrfDetalheModel();
				$irrfDetalhe->mapping($irrfDetalheModelListJson[$i]);
				$objModel->irrfDetalheModelList()->save($irrfDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		IrrfDetalheModel::where('id_irrf', $object->getIdAttribute())->delete();
	}	
 
}