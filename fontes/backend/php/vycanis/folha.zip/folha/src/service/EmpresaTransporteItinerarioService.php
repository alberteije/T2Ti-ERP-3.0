<?php
class EmpresaTransporteItinerarioService extends ServiceBase
{
  public function getList()
  {
    return EmpresaTransporteItinerarioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EmpresaTransporteItinerarioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EmpresaTransporteItinerarioModel::find($id);
  }

}