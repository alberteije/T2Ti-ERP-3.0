<?php
class FolhaPlanoSaudeService extends ServiceBase
{
  public function getList()
  {
    return FolhaPlanoSaudeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaPlanoSaudeModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaPlanoSaudeModel::find($id);
  }

}