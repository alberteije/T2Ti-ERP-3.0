<?php
class GuiasAcumuladasService extends ServiceBase
{
  public function getList()
  {
    return GuiasAcumuladasModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return GuiasAcumuladasModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return GuiasAcumuladasModel::find($id);
  }

}