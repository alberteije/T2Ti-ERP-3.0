<?php
class FeriasPeriodoAquisitivoService extends ServiceBase
{
  public function getList()
  {
    return FeriasPeriodoAquisitivoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FeriasPeriodoAquisitivoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FeriasPeriodoAquisitivoModel::find($id);
  }

}