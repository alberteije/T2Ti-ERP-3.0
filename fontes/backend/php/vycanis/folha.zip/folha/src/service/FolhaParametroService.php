<?php
class FolhaParametroService extends ServiceBase
{
  public function getList()
  {
    return FolhaParametroModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaParametroModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaParametroModel::find($id);
  }

}