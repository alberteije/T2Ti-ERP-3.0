<?php
class SefipCodigoRecolhimentoService extends ServiceBase
{
  public function getList()
  {
    return SefipCodigoRecolhimentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SefipCodigoRecolhimentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SefipCodigoRecolhimentoModel::find($id);
  }

}