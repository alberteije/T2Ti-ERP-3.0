<?php
class SefipCodigoMovimentacaoService extends ServiceBase
{
  public function getList()
  {
    return SefipCodigoMovimentacaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SefipCodigoMovimentacaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SefipCodigoMovimentacaoModel::find($id);
  }

}