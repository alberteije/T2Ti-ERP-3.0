<?php
class CboService extends ServiceBase
{
  public function getList()
  {
    return CboModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CboModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CboModel::find($id);
  }

}