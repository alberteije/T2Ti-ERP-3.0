<?php
class FolhaRescisaoService extends ServiceBase
{
  public function getList()
  {
    return FolhaRescisaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaRescisaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaRescisaoModel::find($id);
  }

}