<?php
class SalarioMinimoService extends ServiceBase
{
  public function getList()
  {
    return SalarioMinimoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SalarioMinimoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SalarioMinimoModel::find($id);
  }

}