<?php
class FolhaValeTransporteService extends ServiceBase
{
  public function getList()
  {
    return FolhaValeTransporteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaValeTransporteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaValeTransporteModel::find($id);
  }

}