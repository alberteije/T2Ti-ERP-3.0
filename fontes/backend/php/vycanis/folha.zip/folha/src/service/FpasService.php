<?php
class FpasService extends ServiceBase
{
  public function getList()
  {
    return FpasModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FpasModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FpasModel::find($id);
  }

}