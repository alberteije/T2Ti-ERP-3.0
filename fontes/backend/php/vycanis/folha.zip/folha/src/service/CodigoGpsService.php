<?php
class CodigoGpsService extends ServiceBase
{
  public function getList()
  {
    return CodigoGpsModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CodigoGpsModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return CodigoGpsModel::find($id);
  }

}