<?php
use Illuminate\Database\Capsule\Manager as DB;
class InssService extends ServiceBase
{
	public function getList()
	{
		return InssModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return InssModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return InssModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// salarioFamilia
		$salarioFamiliaModelListJson = $objJson->salarioFamiliaModelList;
		if ($salarioFamiliaModelListJson != null) {
			for ($i = 0; $i < count($salarioFamiliaModelListJson); $i++) {
				$salarioFamilia = new SalarioFamiliaModel();
				$salarioFamilia->mapping($salarioFamiliaModelListJson[$i]);
				$objModel->salarioFamiliaModelList()->save($salarioFamilia);
			}
		}

		// inssDetalhe
		$inssDetalheModelListJson = $objJson->inssDetalheModelList;
		if ($inssDetalheModelListJson != null) {
			for ($i = 0; $i < count($inssDetalheModelListJson); $i++) {
				$inssDetalhe = new InssDetalheModel();
				$inssDetalhe->mapping($inssDetalheModelListJson[$i]);
				$objModel->inssDetalheModelList()->save($inssDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		SalarioFamiliaModel::where('id_inss', $object->getIdAttribute())->delete();
		InssDetalheModel::where('id_inss', $object->getIdAttribute())->delete();
	}	
 
}