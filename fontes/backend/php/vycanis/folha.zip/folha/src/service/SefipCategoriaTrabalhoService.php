<?php
class SefipCategoriaTrabalhoService extends ServiceBase
{
  public function getList()
  {
    return SefipCategoriaTrabalhoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return SefipCategoriaTrabalhoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return SefipCategoriaTrabalhoModel::find($id);
  }

}