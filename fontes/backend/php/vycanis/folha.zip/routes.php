<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// empresa-transporte
$app->get('/empresa-transporte[/]', \EmpresaTransporteController::class . RESULT_LIST);
$app->get('/empresa-transporte/{id}', \EmpresaTransporteController::class . RESULT_OBJECT);
$app->post('/empresa-transporte', \EmpresaTransporteController::class . INSERT);
$app->put('/empresa-transporte', \EmpresaTransporteController::class . UPDATE);
$app->delete('/empresa-transporte/{id}', \EmpresaTransporteController::class . DELETE);
$app->options('/empresa-transporte', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/empresa-transporte/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/empresa-transporte/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-lancamento-cabecalho
$app->get('/folha-lancamento-cabecalho[/]', \FolhaLancamentoCabecalhoController::class . RESULT_LIST);
$app->get('/folha-lancamento-cabecalho/{id}', \FolhaLancamentoCabecalhoController::class . RESULT_OBJECT);
$app->post('/folha-lancamento-cabecalho', \FolhaLancamentoCabecalhoController::class . INSERT);
$app->put('/folha-lancamento-cabecalho', \FolhaLancamentoCabecalhoController::class . UPDATE);
$app->delete('/folha-lancamento-cabecalho/{id}', \FolhaLancamentoCabecalhoController::class . DELETE);
$app->options('/folha-lancamento-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-lancamento-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-lancamento-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-inss
$app->get('/folha-inss[/]', \FolhaInssController::class . RESULT_LIST);
$app->get('/folha-inss/{id}', \FolhaInssController::class . RESULT_OBJECT);
$app->post('/folha-inss', \FolhaInssController::class . INSERT);
$app->put('/folha-inss', \FolhaInssController::class . UPDATE);
$app->delete('/folha-inss/{id}', \FolhaInssController::class . DELETE);
$app->options('/folha-inss', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-inss/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-inss/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-ppp
$app->get('/folha-ppp[/]', \FolhaPppController::class . RESULT_LIST);
$app->get('/folha-ppp/{id}', \FolhaPppController::class . RESULT_OBJECT);
$app->post('/folha-ppp', \FolhaPppController::class . INSERT);
$app->put('/folha-ppp', \FolhaPppController::class . UPDATE);
$app->delete('/folha-ppp/{id}', \FolhaPppController::class . DELETE);
$app->options('/folha-ppp', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-ppp/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-ppp/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// operadora-plano-saude
$app->get('/operadora-plano-saude[/]', \OperadoraPlanoSaudeController::class . RESULT_LIST);
$app->get('/operadora-plano-saude/{id}', \OperadoraPlanoSaudeController::class . RESULT_OBJECT);
$app->post('/operadora-plano-saude', \OperadoraPlanoSaudeController::class . INSERT);
$app->put('/operadora-plano-saude', \OperadoraPlanoSaudeController::class . UPDATE);
$app->delete('/operadora-plano-saude/{id}', \OperadoraPlanoSaudeController::class . DELETE);
$app->options('/operadora-plano-saude', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/operadora-plano-saude/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/operadora-plano-saude/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-lancamento-comissao
$app->get('/folha-lancamento-comissao[/]', \FolhaLancamentoComissaoController::class . RESULT_LIST);
$app->get('/folha-lancamento-comissao/{id}', \FolhaLancamentoComissaoController::class . RESULT_OBJECT);
$app->post('/folha-lancamento-comissao', \FolhaLancamentoComissaoController::class . INSERT);
$app->put('/folha-lancamento-comissao', \FolhaLancamentoComissaoController::class . UPDATE);
$app->delete('/folha-lancamento-comissao/{id}', \FolhaLancamentoComissaoController::class . DELETE);
$app->options('/folha-lancamento-comissao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-lancamento-comissao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-lancamento-comissao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-parametro
$app->get('/folha-parametro[/]', \FolhaParametroController::class . RESULT_LIST);
$app->get('/folha-parametro/{id}', \FolhaParametroController::class . RESULT_OBJECT);
$app->post('/folha-parametro', \FolhaParametroController::class . INSERT);
$app->put('/folha-parametro', \FolhaParametroController::class . UPDATE);
$app->delete('/folha-parametro/{id}', \FolhaParametroController::class . DELETE);
$app->options('/folha-parametro', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-parametro/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-parametro/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// guias-acumuladas
$app->get('/guias-acumuladas[/]', \GuiasAcumuladasController::class . RESULT_LIST);
$app->get('/guias-acumuladas/{id}', \GuiasAcumuladasController::class . RESULT_OBJECT);
$app->post('/guias-acumuladas', \GuiasAcumuladasController::class . INSERT);
$app->put('/guias-acumuladas', \GuiasAcumuladasController::class . UPDATE);
$app->delete('/guias-acumuladas/{id}', \GuiasAcumuladasController::class . DELETE);
$app->options('/guias-acumuladas', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/guias-acumuladas/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/guias-acumuladas/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-fechamento
$app->get('/folha-fechamento[/]', \FolhaFechamentoController::class . RESULT_LIST);
$app->get('/folha-fechamento/{id}', \FolhaFechamentoController::class . RESULT_OBJECT);
$app->post('/folha-fechamento', \FolhaFechamentoController::class . INSERT);
$app->put('/folha-fechamento', \FolhaFechamentoController::class . UPDATE);
$app->delete('/folha-fechamento/{id}', \FolhaFechamentoController::class . DELETE);
$app->options('/folha-fechamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-fechamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-fechamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ferias-periodo-aquisitivo
$app->get('/ferias-periodo-aquisitivo[/]', \FeriasPeriodoAquisitivoController::class . RESULT_LIST);
$app->get('/ferias-periodo-aquisitivo/{id}', \FeriasPeriodoAquisitivoController::class . RESULT_OBJECT);
$app->post('/ferias-periodo-aquisitivo', \FeriasPeriodoAquisitivoController::class . INSERT);
$app->put('/ferias-periodo-aquisitivo', \FeriasPeriodoAquisitivoController::class . UPDATE);
$app->delete('/ferias-periodo-aquisitivo/{id}', \FeriasPeriodoAquisitivoController::class . DELETE);
$app->options('/ferias-periodo-aquisitivo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ferias-periodo-aquisitivo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ferias-periodo-aquisitivo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-tipo-afastamento
$app->get('/folha-tipo-afastamento[/]', \FolhaTipoAfastamentoController::class . RESULT_LIST);
$app->get('/folha-tipo-afastamento/{id}', \FolhaTipoAfastamentoController::class . RESULT_OBJECT);
$app->post('/folha-tipo-afastamento', \FolhaTipoAfastamentoController::class . INSERT);
$app->put('/folha-tipo-afastamento', \FolhaTipoAfastamentoController::class . UPDATE);
$app->delete('/folha-tipo-afastamento/{id}', \FolhaTipoAfastamentoController::class . DELETE);
$app->options('/folha-tipo-afastamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-tipo-afastamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-tipo-afastamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-afastamento
$app->get('/folha-afastamento[/]', \FolhaAfastamentoController::class . RESULT_LIST);
$app->get('/folha-afastamento/{id}', \FolhaAfastamentoController::class . RESULT_OBJECT);
$app->post('/folha-afastamento', \FolhaAfastamentoController::class . INSERT);
$app->put('/folha-afastamento', \FolhaAfastamentoController::class . UPDATE);
$app->delete('/folha-afastamento/{id}', \FolhaAfastamentoController::class . DELETE);
$app->options('/folha-afastamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-afastamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-afastamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-plano-saude
$app->get('/folha-plano-saude[/]', \FolhaPlanoSaudeController::class . RESULT_LIST);
$app->get('/folha-plano-saude/{id}', \FolhaPlanoSaudeController::class . RESULT_OBJECT);
$app->post('/folha-plano-saude', \FolhaPlanoSaudeController::class . INSERT);
$app->put('/folha-plano-saude', \FolhaPlanoSaudeController::class . UPDATE);
$app->delete('/folha-plano-saude/{id}', \FolhaPlanoSaudeController::class . DELETE);
$app->options('/folha-plano-saude', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-plano-saude/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-plano-saude/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-evento
$app->get('/folha-evento[/]', \FolhaEventoController::class . RESULT_LIST);
$app->get('/folha-evento/{id}', \FolhaEventoController::class . RESULT_OBJECT);
$app->post('/folha-evento', \FolhaEventoController::class . INSERT);
$app->put('/folha-evento', \FolhaEventoController::class . UPDATE);
$app->delete('/folha-evento/{id}', \FolhaEventoController::class . DELETE);
$app->options('/folha-evento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-evento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-evento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-rescisao
$app->get('/folha-rescisao[/]', \FolhaRescisaoController::class . RESULT_LIST);
$app->get('/folha-rescisao/{id}', \FolhaRescisaoController::class . RESULT_OBJECT);
$app->post('/folha-rescisao', \FolhaRescisaoController::class . INSERT);
$app->put('/folha-rescisao', \FolhaRescisaoController::class . UPDATE);
$app->delete('/folha-rescisao/{id}', \FolhaRescisaoController::class . DELETE);
$app->options('/folha-rescisao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-rescisao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-rescisao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-ferias-coletivas
$app->get('/folha-ferias-coletivas[/]', \FolhaFeriasColetivasController::class . RESULT_LIST);
$app->get('/folha-ferias-coletivas/{id}', \FolhaFeriasColetivasController::class . RESULT_OBJECT);
$app->post('/folha-ferias-coletivas', \FolhaFeriasColetivasController::class . INSERT);
$app->put('/folha-ferias-coletivas', \FolhaFeriasColetivasController::class . UPDATE);
$app->delete('/folha-ferias-coletivas/{id}', \FolhaFeriasColetivasController::class . DELETE);
$app->options('/folha-ferias-coletivas', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-ferias-coletivas/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-ferias-coletivas/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-vale-transporte
$app->get('/folha-vale-transporte[/]', \FolhaValeTransporteController::class . RESULT_LIST);
$app->get('/folha-vale-transporte/{id}', \FolhaValeTransporteController::class . RESULT_OBJECT);
$app->post('/folha-vale-transporte', \FolhaValeTransporteController::class . INSERT);
$app->put('/folha-vale-transporte', \FolhaValeTransporteController::class . UPDATE);
$app->delete('/folha-vale-transporte/{id}', \FolhaValeTransporteController::class . DELETE);
$app->options('/folha-vale-transporte', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-vale-transporte/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-vale-transporte/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-inss-servico
$app->get('/folha-inss-servico[/]', \FolhaInssServicoController::class . RESULT_LIST);
$app->get('/folha-inss-servico/{id}', \FolhaInssServicoController::class . RESULT_OBJECT);
$app->post('/folha-inss-servico', \FolhaInssServicoController::class . INSERT);
$app->put('/folha-inss-servico', \FolhaInssServicoController::class . UPDATE);
$app->delete('/folha-inss-servico/{id}', \FolhaInssServicoController::class . DELETE);
$app->options('/folha-inss-servico', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-inss-servico/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-inss-servico/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// folha-historico-salarial
$app->get('/folha-historico-salarial[/]', \FolhaHistoricoSalarialController::class . RESULT_LIST);
$app->get('/folha-historico-salarial/{id}', \FolhaHistoricoSalarialController::class . RESULT_OBJECT);
$app->post('/folha-historico-salarial', \FolhaHistoricoSalarialController::class . INSERT);
$app->put('/folha-historico-salarial', \FolhaHistoricoSalarialController::class . UPDATE);
$app->delete('/folha-historico-salarial/{id}', \FolhaHistoricoSalarialController::class . DELETE);
$app->options('/folha-historico-salarial', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-historico-salarial/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/folha-historico-salarial/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// feriados
$app->get('/feriados[/]', \FeriadosController::class . RESULT_LIST);
$app->get('/feriados/{id}', \FeriadosController::class . RESULT_OBJECT);
$app->post('/feriados', \FeriadosController::class . INSERT);
$app->put('/feriados', \FeriadosController::class . UPDATE);
$app->delete('/feriados/{id}', \FeriadosController::class . DELETE);
$app->options('/feriados', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/feriados/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/feriados/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

