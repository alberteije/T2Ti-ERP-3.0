<?php
declare(strict_types=1);

class EmpresaTransporteItinerarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'empresa_transporte_itinerario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function empresaTransporteModel()
	{
		return $this->belongsTo(EmpresaTransporteModel::class, 'id_empresa_transporte', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getTarifaAttribute()
	{
		return (double)$this->attributes['tarifa'];
	}

	public function setTarifaAttribute($tarifa)
	{
		$this->attributes['tarifa'] = $tarifa;
	}

	public function getTrajetoAttribute()
	{
		return $this->attributes['trajeto'];
	}

	public function setTrajetoAttribute($trajeto)
	{
		$this->attributes['trajeto'] = $trajeto;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setTarifaAttribute($object->tarifa);
				$this->setTrajetoAttribute($object->trajeto);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'tarifa' => $this->getTarifaAttribute(),
				'trajeto' => $this->getTrajetoAttribute(),
			];
	}
}