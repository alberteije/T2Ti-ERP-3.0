<?php
declare(strict_types=1);

class OperadoraPlanoSaudeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'operadora_plano_saude';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getRegistroAnsAttribute()
	{
		return $this->attributes['registro_ans'];
	}

	public function setRegistroAnsAttribute($registroAns)
	{
		$this->attributes['registro_ans'] = $registroAns;
	}

	public function getClassificacaoContabilContaAttribute()
	{
		return $this->attributes['classificacao_contabil_conta'];
	}

	public function setClassificacaoContabilContaAttribute($classificacaoContabilConta)
	{
		$this->attributes['classificacao_contabil_conta'] = $classificacaoContabilConta;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setRegistroAnsAttribute($object->registroAns);
				$this->setClassificacaoContabilContaAttribute($object->classificacaoContabilConta);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'registroAns' => $this->getRegistroAnsAttribute(),
				'classificacaoContabilConta' => $this->getClassificacaoContabilContaAttribute(),
			];
	}
}