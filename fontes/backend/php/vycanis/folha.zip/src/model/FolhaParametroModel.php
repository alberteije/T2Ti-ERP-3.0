<?php
declare(strict_types=1);

class FolhaParametroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_parametro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getContribuiPisAttribute()
	{
		return $this->attributes['contribui_pis'];
	}

	public function setContribuiPisAttribute($contribuiPis)
	{
		$this->attributes['contribui_pis'] = $contribuiPis;
	}

	public function getAliquotaPisAttribute()
	{
		return (double)$this->attributes['aliquota_pis'];
	}

	public function setAliquotaPisAttribute($aliquotaPis)
	{
		$this->attributes['aliquota_pis'] = $aliquotaPis;
	}

	public function getDiscriminarDsrAttribute()
	{
		return $this->attributes['discriminar_dsr'];
	}

	public function setDiscriminarDsrAttribute($discriminarDsr)
	{
		$this->attributes['discriminar_dsr'] = $discriminarDsr;
	}

	public function getDiaPagamentoAttribute()
	{
		return $this->attributes['dia_pagamento'];
	}

	public function setDiaPagamentoAttribute($diaPagamento)
	{
		$this->attributes['dia_pagamento'] = $diaPagamento;
	}

	public function getCalculoProporcionalidadeAttribute()
	{
		return $this->attributes['calculo_proporcionalidade'];
	}

	public function setCalculoProporcionalidadeAttribute($calculoProporcionalidade)
	{
		$this->attributes['calculo_proporcionalidade'] = $calculoProporcionalidade;
	}

	public function getDescontarFaltas13Attribute()
	{
		return $this->attributes['descontar_faltas_13'];
	}

	public function setDescontarFaltas13Attribute($descontarFaltas13)
	{
		$this->attributes['descontar_faltas_13'] = $descontarFaltas13;
	}

	public function getPagarAdicionais13Attribute()
	{
		return $this->attributes['pagar_adicionais_13'];
	}

	public function setPagarAdicionais13Attribute($pagarAdicionais13)
	{
		$this->attributes['pagar_adicionais_13'] = $pagarAdicionais13;
	}

	public function getPagarEstagiarios13Attribute()
	{
		return $this->attributes['pagar_estagiarios_13'];
	}

	public function setPagarEstagiarios13Attribute($pagarEstagiarios13)
	{
		$this->attributes['pagar_estagiarios_13'] = $pagarEstagiarios13;
	}

	public function getMesAdiantamento13Attribute()
	{
		return $this->attributes['mes_adiantamento_13'];
	}

	public function setMesAdiantamento13Attribute($mesAdiantamento13)
	{
		$this->attributes['mes_adiantamento_13'] = $mesAdiantamento13;
	}

	public function getPercentualAdiantam13Attribute()
	{
		return (double)$this->attributes['percentual_adiantam_13'];
	}

	public function setPercentualAdiantam13Attribute($percentualAdiantam13)
	{
		$this->attributes['percentual_adiantam_13'] = $percentualAdiantam13;
	}

	public function getFeriasDescontarFaltasAttribute()
	{
		return $this->attributes['ferias_descontar_faltas'];
	}

	public function setFeriasDescontarFaltasAttribute($feriasDescontarFaltas)
	{
		$this->attributes['ferias_descontar_faltas'] = $feriasDescontarFaltas;
	}

	public function getFeriasPagarAdicionaisAttribute()
	{
		return $this->attributes['ferias_pagar_adicionais'];
	}

	public function setFeriasPagarAdicionaisAttribute($feriasPagarAdicionais)
	{
		$this->attributes['ferias_pagar_adicionais'] = $feriasPagarAdicionais;
	}

	public function getFeriasAdiantar13Attribute()
	{
		return $this->attributes['ferias_adiantar_13'];
	}

	public function setFeriasAdiantar13Attribute($feriasAdiantar13)
	{
		$this->attributes['ferias_adiantar_13'] = $feriasAdiantar13;
	}

	public function getFeriasPagarEstagiariosAttribute()
	{
		return $this->attributes['ferias_pagar_estagiarios'];
	}

	public function setFeriasPagarEstagiariosAttribute($feriasPagarEstagiarios)
	{
		$this->attributes['ferias_pagar_estagiarios'] = $feriasPagarEstagiarios;
	}

	public function getFeriasCalcJustaCausaAttribute()
	{
		return $this->attributes['ferias_calc_justa_causa'];
	}

	public function setFeriasCalcJustaCausaAttribute($feriasCalcJustaCausa)
	{
		$this->attributes['ferias_calc_justa_causa'] = $feriasCalcJustaCausa;
	}

	public function getFeriasMovimentoMensalAttribute()
	{
		return $this->attributes['ferias_movimento_mensal'];
	}

	public function setFeriasMovimentoMensalAttribute($feriasMovimentoMensal)
	{
		$this->attributes['ferias_movimento_mensal'] = $feriasMovimentoMensal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setContribuiPisAttribute($object->contribuiPis);
				$this->setAliquotaPisAttribute($object->aliquotaPis);
				$this->setDiscriminarDsrAttribute($object->discriminarDsr);
				$this->setDiaPagamentoAttribute($object->diaPagamento);
				$this->setCalculoProporcionalidadeAttribute($object->calculoProporcionalidade);
				$this->setDescontarFaltas13Attribute($object->descontarFaltas13);
				$this->setPagarAdicionais13Attribute($object->pagarAdicionais13);
				$this->setPagarEstagiarios13Attribute($object->pagarEstagiarios13);
				$this->setMesAdiantamento13Attribute($object->mesAdiantamento13);
				$this->setPercentualAdiantam13Attribute($object->percentualAdiantam13);
				$this->setFeriasDescontarFaltasAttribute($object->feriasDescontarFaltas);
				$this->setFeriasPagarAdicionaisAttribute($object->feriasPagarAdicionais);
				$this->setFeriasAdiantar13Attribute($object->feriasAdiantar13);
				$this->setFeriasPagarEstagiariosAttribute($object->feriasPagarEstagiarios);
				$this->setFeriasCalcJustaCausaAttribute($object->feriasCalcJustaCausa);
				$this->setFeriasMovimentoMensalAttribute($object->feriasMovimentoMensal);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'contribuiPis' => $this->getContribuiPisAttribute(),
				'aliquotaPis' => $this->getAliquotaPisAttribute(),
				'discriminarDsr' => $this->getDiscriminarDsrAttribute(),
				'diaPagamento' => $this->getDiaPagamentoAttribute(),
				'calculoProporcionalidade' => $this->getCalculoProporcionalidadeAttribute(),
				'descontarFaltas13' => $this->getDescontarFaltas13Attribute(),
				'pagarAdicionais13' => $this->getPagarAdicionais13Attribute(),
				'pagarEstagiarios13' => $this->getPagarEstagiarios13Attribute(),
				'mesAdiantamento13' => $this->getMesAdiantamento13Attribute(),
				'percentualAdiantam13' => $this->getPercentualAdiantam13Attribute(),
				'feriasDescontarFaltas' => $this->getFeriasDescontarFaltasAttribute(),
				'feriasPagarAdicionais' => $this->getFeriasPagarAdicionaisAttribute(),
				'feriasAdiantar13' => $this->getFeriasAdiantar13Attribute(),
				'feriasPagarEstagiarios' => $this->getFeriasPagarEstagiariosAttribute(),
				'feriasCalcJustaCausa' => $this->getFeriasCalcJustaCausaAttribute(),
				'feriasMovimentoMensal' => $this->getFeriasMovimentoMensalAttribute(),
			];
	}
}