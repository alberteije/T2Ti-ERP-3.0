<?php
declare(strict_types=1);

class FolhaPlanoSaudeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_plano_saude';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
		'operadoraPlanoSaudeModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function operadoraPlanoSaudeModel()
	{
		return $this->belongsTo(OperadoraPlanoSaudeModel::class, 'id_operadora_plano_saude', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getBeneficiarioAttribute()
	{
		return $this->attributes['beneficiario'];
	}

	public function setBeneficiarioAttribute($beneficiario)
	{
		$this->attributes['beneficiario'] = $beneficiario;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setBeneficiarioAttribute($object->beneficiario);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$operadoraPlanoSaudeModel = new OperadoraPlanoSaudeModel();
				$operadoraPlanoSaudeModel->mapping($object->operadoraPlanoSaudeModel);
				$this->operadoraPlanoSaudeModel()->associate($operadoraPlanoSaudeModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'beneficiario' => $this->getBeneficiarioAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'operadoraPlanoSaudeModel' => $this->operadoraPlanoSaudeModel,
			];
	}
}