<?php
declare(strict_types=1);

class FolhaLancamentoDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_lancamento_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'folhaEventoModel',
	];

	/**
		* Relations
		*/
	public function folhaLancamentoCabecalhoModel()
	{
		return $this->belongsTo(FolhaLancamentoCabecalhoModel::class, 'id_folha_lancamento_cabecalho', 'id');
	}

	public function folhaEventoModel()
	{
		return $this->belongsTo(FolhaEventoModel::class, 'id_folha_evento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getOrigemAttribute()
	{
		return (double)$this->attributes['origem'];
	}

	public function setOrigemAttribute($origem)
	{
		$this->attributes['origem'] = $origem;
	}

	public function getProventoAttribute()
	{
		return (double)$this->attributes['provento'];
	}

	public function setProventoAttribute($provento)
	{
		$this->attributes['provento'] = $provento;
	}

	public function getDescontoAttribute()
	{
		return (double)$this->attributes['desconto'];
	}

	public function setDescontoAttribute($desconto)
	{
		$this->attributes['desconto'] = $desconto;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setOrigemAttribute($object->origem);
				$this->setProventoAttribute($object->provento);
				$this->setDescontoAttribute($object->desconto);

				// link objects - lookups
				$folhaEventoModel = new FolhaEventoModel();
				$folhaEventoModel->mapping($object->folhaEventoModel);
				$this->folhaEventoModel()->associate($folhaEventoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'origem' => $this->getOrigemAttribute(),
				'provento' => $this->getProventoAttribute(),
				'desconto' => $this->getDescontoAttribute(),
				'folhaEventoModel' => $this->folhaEventoModel,
			];
	}
}