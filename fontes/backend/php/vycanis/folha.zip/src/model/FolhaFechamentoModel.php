<?php
declare(strict_types=1);

class FolhaFechamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_fechamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getFechamentoAtualAttribute()
	{
		return $this->attributes['fechamento_atual'];
	}

	public function setFechamentoAtualAttribute($fechamentoAtual)
	{
		$this->attributes['fechamento_atual'] = $fechamentoAtual;
	}

	public function getProximoFechamentoAttribute()
	{
		return $this->attributes['proximo_fechamento'];
	}

	public function setProximoFechamentoAttribute($proximoFechamento)
	{
		$this->attributes['proximo_fechamento'] = $proximoFechamento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setFechamentoAtualAttribute($object->fechamentoAtual);
				$this->setProximoFechamentoAttribute($object->proximoFechamento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'fechamentoAtual' => $this->getFechamentoAtualAttribute(),
				'proximoFechamento' => $this->getProximoFechamentoAttribute(),
			];
	}
}