<?php
declare(strict_types=1);

class FolhaInssRetencaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_inss_retencao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'folhaInssServicoModel',
	];

	/**
		* Relations
		*/
	public function folhaInssModel()
	{
		return $this->belongsTo(FolhaInssModel::class, 'id_folha_inss', 'id');
	}

	public function folhaInssServicoModel()
	{
		return $this->belongsTo(FolhaInssServicoModel::class, 'id_folha_inss_servico', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorMensalAttribute()
	{
		return (double)$this->attributes['valor_mensal'];
	}

	public function setValorMensalAttribute($valorMensal)
	{
		$this->attributes['valor_mensal'] = $valorMensal;
	}

	public function getValor13Attribute()
	{
		return (double)$this->attributes['valor_13'];
	}

	public function setValor13Attribute($valor13)
	{
		$this->attributes['valor_13'] = $valor13;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorMensalAttribute($object->valorMensal);
				$this->setValor13Attribute($object->valor13);

				// link objects - lookups
				$folhaInssServicoModel = new FolhaInssServicoModel();
				$folhaInssServicoModel->mapping($object->folhaInssServicoModel);
				$this->folhaInssServicoModel()->associate($folhaInssServicoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valorMensal' => $this->getValorMensalAttribute(),
				'valor13' => $this->getValor13Attribute(),
				'folhaInssServicoModel' => $this->folhaInssServicoModel,
			];
	}
}