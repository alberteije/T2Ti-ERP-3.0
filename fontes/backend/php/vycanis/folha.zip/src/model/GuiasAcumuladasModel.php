<?php
declare(strict_types=1);

class GuiasAcumuladasModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'guias_acumuladas';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getGpsTipoAttribute()
	{
		return $this->attributes['gps_tipo'];
	}

	public function setGpsTipoAttribute($gpsTipo)
	{
		$this->attributes['gps_tipo'] = $gpsTipo;
	}

	public function getGpsCompetenciaAttribute()
	{
		return $this->attributes['gps_competencia'];
	}

	public function setGpsCompetenciaAttribute($gpsCompetencia)
	{
		$this->attributes['gps_competencia'] = $gpsCompetencia;
	}

	public function getGpsValorInssAttribute()
	{
		return (double)$this->attributes['gps_valor_inss'];
	}

	public function setGpsValorInssAttribute($gpsValorInss)
	{
		$this->attributes['gps_valor_inss'] = $gpsValorInss;
	}

	public function getGpsValorOutrasEntAttribute()
	{
		return (double)$this->attributes['gps_valor_outras_ent'];
	}

	public function setGpsValorOutrasEntAttribute($gpsValorOutrasEnt)
	{
		$this->attributes['gps_valor_outras_ent'] = $gpsValorOutrasEnt;
	}

	public function getGpsDataPagamentoAttribute()
	{
		return $this->attributes['gps_data_pagamento'];
	}

	public function setGpsDataPagamentoAttribute($gpsDataPagamento)
	{
		$this->attributes['gps_data_pagamento'] = $gpsDataPagamento;
	}

	public function getIrrfCompetenciaAttribute()
	{
		return $this->attributes['irrf_competencia'];
	}

	public function setIrrfCompetenciaAttribute($irrfCompetencia)
	{
		$this->attributes['irrf_competencia'] = $irrfCompetencia;
	}

	public function getIrrfCodigoRecolhimentoAttribute()
	{
		return $this->attributes['irrf_codigo_recolhimento'];
	}

	public function setIrrfCodigoRecolhimentoAttribute($irrfCodigoRecolhimento)
	{
		$this->attributes['irrf_codigo_recolhimento'] = $irrfCodigoRecolhimento;
	}

	public function getIrrfValorAcumuladoAttribute()
	{
		return (double)$this->attributes['irrf_valor_acumulado'];
	}

	public function setIrrfValorAcumuladoAttribute($irrfValorAcumulado)
	{
		$this->attributes['irrf_valor_acumulado'] = $irrfValorAcumulado;
	}

	public function getIrrfDataPagamentoAttribute()
	{
		return $this->attributes['irrf_data_pagamento'];
	}

	public function setIrrfDataPagamentoAttribute($irrfDataPagamento)
	{
		$this->attributes['irrf_data_pagamento'] = $irrfDataPagamento;
	}

	public function getPisCompetenciaAttribute()
	{
		return $this->attributes['pis_competencia'];
	}

	public function setPisCompetenciaAttribute($pisCompetencia)
	{
		$this->attributes['pis_competencia'] = $pisCompetencia;
	}

	public function getPisValorAcumuladoAttribute()
	{
		return (double)$this->attributes['pis_valor_acumulado'];
	}

	public function setPisValorAcumuladoAttribute($pisValorAcumulado)
	{
		$this->attributes['pis_valor_acumulado'] = $pisValorAcumulado;
	}

	public function getPisDataPagamentoAttribute()
	{
		return $this->attributes['pis_data_pagamento'];
	}

	public function setPisDataPagamentoAttribute($pisDataPagamento)
	{
		$this->attributes['pis_data_pagamento'] = $pisDataPagamento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setGpsTipoAttribute($object->gpsTipo);
				$this->setGpsCompetenciaAttribute($object->gpsCompetencia);
				$this->setGpsValorInssAttribute($object->gpsValorInss);
				$this->setGpsValorOutrasEntAttribute($object->gpsValorOutrasEnt);
				$this->setGpsDataPagamentoAttribute($object->gpsDataPagamento);
				$this->setIrrfCompetenciaAttribute($object->irrfCompetencia);
				$this->setIrrfCodigoRecolhimentoAttribute($object->irrfCodigoRecolhimento);
				$this->setIrrfValorAcumuladoAttribute($object->irrfValorAcumulado);
				$this->setIrrfDataPagamentoAttribute($object->irrfDataPagamento);
				$this->setPisCompetenciaAttribute($object->pisCompetencia);
				$this->setPisValorAcumuladoAttribute($object->pisValorAcumulado);
				$this->setPisDataPagamentoAttribute($object->pisDataPagamento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'gpsTipo' => $this->getGpsTipoAttribute(),
				'gpsCompetencia' => $this->getGpsCompetenciaAttribute(),
				'gpsValorInss' => $this->getGpsValorInssAttribute(),
				'gpsValorOutrasEnt' => $this->getGpsValorOutrasEntAttribute(),
				'gpsDataPagamento' => $this->getGpsDataPagamentoAttribute(),
				'irrfCompetencia' => $this->getIrrfCompetenciaAttribute(),
				'irrfCodigoRecolhimento' => $this->getIrrfCodigoRecolhimentoAttribute(),
				'irrfValorAcumulado' => $this->getIrrfValorAcumuladoAttribute(),
				'irrfDataPagamento' => $this->getIrrfDataPagamentoAttribute(),
				'pisCompetencia' => $this->getPisCompetenciaAttribute(),
				'pisValorAcumulado' => $this->getPisValorAcumuladoAttribute(),
				'pisDataPagamento' => $this->getPisDataPagamentoAttribute(),
			];
	}
}