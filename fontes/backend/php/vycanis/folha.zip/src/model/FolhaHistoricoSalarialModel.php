<?php
declare(strict_types=1);

class FolhaHistoricoSalarialModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'folha_historico_salarial';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getSalarioAtualAttribute()
	{
		return (double)$this->attributes['salario_atual'];
	}

	public function setSalarioAtualAttribute($salarioAtual)
	{
		$this->attributes['salario_atual'] = $salarioAtual;
	}

	public function getPercentualAumentoAttribute()
	{
		return (double)$this->attributes['percentual_aumento'];
	}

	public function setPercentualAumentoAttribute($percentualAumento)
	{
		$this->attributes['percentual_aumento'] = $percentualAumento;
	}

	public function getSalarioNovoAttribute()
	{
		return (double)$this->attributes['salario_novo'];
	}

	public function setSalarioNovoAttribute($salarioNovo)
	{
		$this->attributes['salario_novo'] = $salarioNovo;
	}

	public function getValidoAPartirAttribute()
	{
		return $this->attributes['valido_a_partir'];
	}

	public function setValidoAPartirAttribute($validoAPartir)
	{
		$this->attributes['valido_a_partir'] = $validoAPartir;
	}

	public function getMotivoAttribute()
	{
		return $this->attributes['motivo'];
	}

	public function setMotivoAttribute($motivo)
	{
		$this->attributes['motivo'] = $motivo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setSalarioAtualAttribute($object->salarioAtual);
				$this->setPercentualAumentoAttribute($object->percentualAumento);
				$this->setSalarioNovoAttribute($object->salarioNovo);
				$this->setValidoAPartirAttribute($object->validoAPartir);
				$this->setMotivoAttribute($object->motivo);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'salarioAtual' => $this->getSalarioAtualAttribute(),
				'percentualAumento' => $this->getPercentualAumentoAttribute(),
				'salarioNovo' => $this->getSalarioNovoAttribute(),
				'validoAPartir' => $this->getValidoAPartirAttribute(),
				'motivo' => $this->getMotivoAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}