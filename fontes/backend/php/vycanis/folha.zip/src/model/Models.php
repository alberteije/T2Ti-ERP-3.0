<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'EmpresaTransporteItinerarioModel.php';
include 'FolhaLancamentoDetalheModel.php';
include 'FolhaInssRetencaoModel.php';
include 'FolhaPppCatModel.php';
include 'FolhaPppAtividadeModel.php';
include 'FolhaPppFatorRiscoModel.php';
include 'FolhaPppExameMedicoModel.php';
include 'EmpresaTransporteModel.php';
include 'FolhaLancamentoCabecalhoModel.php';
include 'FolhaInssModel.php';
include 'FolhaPppModel.php';
include 'OperadoraPlanoSaudeModel.php';
include 'FolhaLancamentoComissaoModel.php';
include 'FolhaParametroModel.php';
include 'GuiasAcumuladasModel.php';
include 'FolhaFechamentoModel.php';
include 'FeriasPeriodoAquisitivoModel.php';
include 'FolhaTipoAfastamentoModel.php';
include 'FolhaAfastamentoModel.php';
include 'FolhaPlanoSaudeModel.php';
include 'FolhaEventoModel.php';
include 'FolhaRescisaoModel.php';
include 'FolhaFeriasColetivasModel.php';
include 'FolhaValeTransporteModel.php';
include 'FolhaInssServicoModel.php';
include 'FolhaHistoricoSalarialModel.php';
include 'FeriadosModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';