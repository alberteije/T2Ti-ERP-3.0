<?php
class OperadoraPlanoSaudeController extends ControllerBase
{

		private $operadoraPlanoSaudeService = null;

		public function __construct()
		{	 
				$this->operadoraPlanoSaudeService = new OperadoraPlanoSaudeService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->operadoraPlanoSaudeService->getListFilter($filter);
						} else {
								$resultList = $this->operadoraPlanoSaudeService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList OperadoraPlanoSaude]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->operadoraPlanoSaudeService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject OperadoraPlanoSaude]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject OperadoraPlanoSaude]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert OperadoraPlanoSaude]', null);
						}

						$objModel = new OperadoraPlanoSaudeModel();
						$objModel->mapping($objJson);

						$this->operadoraPlanoSaudeService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert OperadoraPlanoSaude]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->operadoraPlanoSaudeService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update OperadoraPlanoSaude]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->operadoraPlanoSaudeService->save($objFromDatabase);
								$objFromDatabase = $this->operadoraPlanoSaudeService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update OperadoraPlanoSaude]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->operadoraPlanoSaudeService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete OperadoraPlanoSaude]', null);
						} else {
								$this->operadoraPlanoSaudeService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete OperadoraPlanoSaude]', $e);
				}
		}
}
