<?php
class FolhaFeriasColetivasController extends ControllerBase
{

		private $folhaFeriasColetivasService = null;

		public function __construct()
		{	 
				$this->folhaFeriasColetivasService = new FolhaFeriasColetivasService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->folhaFeriasColetivasService->getListFilter($filter);
						} else {
								$resultList = $this->folhaFeriasColetivasService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList FolhaFeriasColetivas]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->folhaFeriasColetivasService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject FolhaFeriasColetivas]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject FolhaFeriasColetivas]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert FolhaFeriasColetivas]', null);
						}

						$objModel = new FolhaFeriasColetivasModel();
						$objModel->mapping($objJson);

						$this->folhaFeriasColetivasService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert FolhaFeriasColetivas]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->folhaFeriasColetivasService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update FolhaFeriasColetivas]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->folhaFeriasColetivasService->save($objFromDatabase);
								$objFromDatabase = $this->folhaFeriasColetivasService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update FolhaFeriasColetivas]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->folhaFeriasColetivasService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete FolhaFeriasColetivas]', null);
						} else {
								$this->folhaFeriasColetivasService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete FolhaFeriasColetivas]', $e);
				}
		}
}
