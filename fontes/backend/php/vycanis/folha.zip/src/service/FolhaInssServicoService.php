<?php
class FolhaInssServicoService extends ServiceBase
{
  public function getList()
  {
    return FolhaInssServicoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaInssServicoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaInssServicoModel::find($id);
  }

}