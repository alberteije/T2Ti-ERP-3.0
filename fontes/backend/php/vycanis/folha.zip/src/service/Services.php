<?php

include 'ServiceBase.php';

include 'EmpresaTransporteService.php';
include 'FolhaLancamentoCabecalhoService.php';
include 'FolhaInssService.php';
include 'FolhaPppService.php';
include 'OperadoraPlanoSaudeService.php';
include 'FolhaLancamentoComissaoService.php';
include 'FolhaParametroService.php';
include 'GuiasAcumuladasService.php';
include 'FolhaFechamentoService.php';
include 'FeriasPeriodoAquisitivoService.php';
include 'FolhaTipoAfastamentoService.php';
include 'FolhaAfastamentoService.php';
include 'FolhaPlanoSaudeService.php';
include 'FolhaEventoService.php';
include 'FolhaRescisaoService.php';
include 'FolhaFeriasColetivasService.php';
include 'FolhaValeTransporteService.php';
include 'FolhaInssServicoService.php';
include 'FolhaHistoricoSalarialService.php';
include 'FeriadosService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';