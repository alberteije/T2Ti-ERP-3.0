<?php
class FolhaEventoService extends ServiceBase
{
  public function getList()
  {
    return FolhaEventoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaEventoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaEventoModel::find($id);
  }

}