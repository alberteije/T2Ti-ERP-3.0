<?php
class FolhaAfastamentoService extends ServiceBase
{
  public function getList()
  {
    return FolhaAfastamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaAfastamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaAfastamentoModel::find($id);
  }

}