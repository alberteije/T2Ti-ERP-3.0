<?php
use Illuminate\Database\Capsule\Manager as DB;
class FolhaPppService extends ServiceBase
{
	public function getList()
	{
		return FolhaPppModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FolhaPppModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FolhaPppModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// folhaPppCat
		$folhaPppCatModelListJson = $objJson->folhaPppCatModelList;
		if ($folhaPppCatModelListJson != null) {
			for ($i = 0; $i < count($folhaPppCatModelListJson); $i++) {
				$folhaPppCat = new FolhaPppCatModel();
				$folhaPppCat->mapping($folhaPppCatModelListJson[$i]);
				$objModel->folhaPppCatModelList()->save($folhaPppCat);
			}
		}

		// folhaPppAtividade
		$folhaPppAtividadeModelListJson = $objJson->folhaPppAtividadeModelList;
		if ($folhaPppAtividadeModelListJson != null) {
			for ($i = 0; $i < count($folhaPppAtividadeModelListJson); $i++) {
				$folhaPppAtividade = new FolhaPppAtividadeModel();
				$folhaPppAtividade->mapping($folhaPppAtividadeModelListJson[$i]);
				$objModel->folhaPppAtividadeModelList()->save($folhaPppAtividade);
			}
		}

		// folhaPppFatorRisco
		$folhaPppFatorRiscoModelListJson = $objJson->folhaPppFatorRiscoModelList;
		if ($folhaPppFatorRiscoModelListJson != null) {
			for ($i = 0; $i < count($folhaPppFatorRiscoModelListJson); $i++) {
				$folhaPppFatorRisco = new FolhaPppFatorRiscoModel();
				$folhaPppFatorRisco->mapping($folhaPppFatorRiscoModelListJson[$i]);
				$objModel->folhaPppFatorRiscoModelList()->save($folhaPppFatorRisco);
			}
		}

		// folhaPppExameMedico
		$folhaPppExameMedicoModelListJson = $objJson->folhaPppExameMedicoModelList;
		if ($folhaPppExameMedicoModelListJson != null) {
			for ($i = 0; $i < count($folhaPppExameMedicoModelListJson); $i++) {
				$folhaPppExameMedico = new FolhaPppExameMedicoModel();
				$folhaPppExameMedico->mapping($folhaPppExameMedicoModelListJson[$i]);
				$objModel->folhaPppExameMedicoModelList()->save($folhaPppExameMedico);
			}
		}

	}	

	public function deleteChildren($object)
	{
		FolhaPppCatModel::where('id_folha_ppp', $object->getIdAttribute())->delete();
		FolhaPppAtividadeModel::where('id_folha_ppp', $object->getIdAttribute())->delete();
		FolhaPppFatorRiscoModel::where('id_folha_ppp', $object->getIdAttribute())->delete();
		FolhaPppExameMedicoModel::where('id_folha_ppp', $object->getIdAttribute())->delete();
	}	
 
}