<?php
class FeriadosService extends ServiceBase
{
  public function getList()
  {
    return FeriadosModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FeriadosModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FeriadosModel::find($id);
  }

}