<?php
class OperadoraPlanoSaudeService extends ServiceBase
{
  public function getList()
  {
    return OperadoraPlanoSaudeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return OperadoraPlanoSaudeModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return OperadoraPlanoSaudeModel::find($id);
  }

}