<?php
use Illuminate\Database\Capsule\Manager as DB;
class FolhaLancamentoCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return FolhaLancamentoCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FolhaLancamentoCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FolhaLancamentoCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// folhaLancamentoDetalhe
		$folhaLancamentoDetalheModelListJson = $objJson->folhaLancamentoDetalheModelList;
		if ($folhaLancamentoDetalheModelListJson != null) {
			for ($i = 0; $i < count($folhaLancamentoDetalheModelListJson); $i++) {
				$folhaLancamentoDetalhe = new FolhaLancamentoDetalheModel();
				$folhaLancamentoDetalhe->mapping($folhaLancamentoDetalheModelListJson[$i]);
				$objModel->folhaLancamentoDetalheModelList()->save($folhaLancamentoDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		FolhaLancamentoDetalheModel::where('id_folha_lancamento_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}