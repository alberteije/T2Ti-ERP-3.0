<?php
use Illuminate\Database\Capsule\Manager as DB;
class FolhaInssService extends ServiceBase
{
	public function getList()
	{
		return FolhaInssModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FolhaInssModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FolhaInssModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// folhaInssRetencao
		$folhaInssRetencaoModelListJson = $objJson->folhaInssRetencaoModelList;
		if ($folhaInssRetencaoModelListJson != null) {
			for ($i = 0; $i < count($folhaInssRetencaoModelListJson); $i++) {
				$folhaInssRetencao = new FolhaInssRetencaoModel();
				$folhaInssRetencao->mapping($folhaInssRetencaoModelListJson[$i]);
				$objModel->folhaInssRetencaoModelList()->save($folhaInssRetencao);
			}
		}

	}	

	public function deleteChildren($object)
	{
		FolhaInssRetencaoModel::where('id_folha_inss', $object->getIdAttribute())->delete();
	}	
 
}