<?php
class FolhaFechamentoService extends ServiceBase
{
  public function getList()
  {
    return FolhaFechamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaFechamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaFechamentoModel::find($id);
  }

}