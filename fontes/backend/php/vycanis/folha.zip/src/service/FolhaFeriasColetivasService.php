<?php
class FolhaFeriasColetivasService extends ServiceBase
{
  public function getList()
  {
    return FolhaFeriasColetivasModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FolhaFeriasColetivasModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FolhaFeriasColetivasModel::find($id);
  }

}