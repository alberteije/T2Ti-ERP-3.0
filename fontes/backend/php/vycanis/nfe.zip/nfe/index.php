<?php 
$cnpjConnection = 'fenix'; 
if (isset($_SERVER['HTTP_CNPJ'])) { 
  $cnpjConnection = $_SERVER['HTTP_CNPJ']; 
} 

//error_reporting(E_ALL);
set_error_handler(function ($severity, $message, $file, $line) {
		if (error_reporting()& $severity) {
				switch ($severity) {
						case E_ERROR: // 1 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_WARNING: // 2 //
							break;
						case E_PARSE: // 4 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_NOTICE: // 8 //
							break;
						case E_CORE_ERROR: // 16 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_CORE_WARNING: // 32 //
							break;
						case E_COMPILE_ERROR: // 64 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_COMPILE_WARNING: // 128 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_USER_ERROR: // 256 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_USER_WARNING: // 512 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_USER_NOTICE: // 1024 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_STRICT: // 2048 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_RECOVERABLE_ERROR: // 4096 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_DEPRECATED: // 8192 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
						case E_USER_DEPRECATED: // 16384 //
							throw new \ErrorException($message, 0, $severity, $file, $line);
				}
		}
});

// resquest and response
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Server\MiddlewareInterface;

// database 
use Illuminate\Database\Capsule\Manager as DB;

// Slim
use Slim\Factory\AppFactory;
// route control
use Slim\Routing\RouteContext;

//use Illuminate\Database\Capsule\Manager as Capsule;
require __DIR__ . '/../vendor/autoload.php';

// Slim instance
$app = AppFactory::create();

#region CORS
// fonte: http://www.slimframework.com/docs/v4/cookbook/enable-cors.html
$app->addBodyParsingMiddleware();

// This middleware will append the response header Access-Control-Allow-Methods with all allowed methods
$app->add(function (Request $request, RequestHandlerInterface $handler): Response {
		$routeContext = RouteContext::fromRequest($request);
		$routingResults = $routeContext->getRoutingResults();
		$methods = $routingResults->getAllowedMethods();
		$requestHeaders = $request->getHeaderLine('Access-Control-Request-Headers');

		$response = $handler->handle($request); 

    try {
      $con = DB::connection()->getPdo();
    } catch(Exception $e) {
      return $response->withStatus(418)->withHeader('Content-Type', 'application/json');
    }

		$response = $response->withHeader('Access-Control-Allow-Origin', '*');
		$response = $response->withHeader('Access-Control-Allow-Methods', implode(',', $methods));
		$response = $response->withHeader('Access-Control-Allow-Headers', $requestHeaders);
		$response = $response->withHeader('Access-Control-Allow-Credentials', 'true');

		return $response;
});

// The RoutingMiddleware should be added after our CORS middleware so routing is performed first
$app->addRoutingMiddleware();
#endregion CORS

// Sub-Directory - no Virtual Host
$app->setBasePath('/erp3/nfe');

// standard route
$app->get('/', function (Request $request, Response $response, array $args) {
		$response->getBody()->write("T2Ti ERP 3.0 - NFe OK!");
		return $response;
});

// require once
require_once('./src/util/Util.php');
require_once('./src/util/Constants.php');
require_once('./src/controller/Controllers.php');
require_once('./src/service/Services.php');
require_once('./src/model/Models.php');
require_once('./routes.php');

// run application
$app->run();