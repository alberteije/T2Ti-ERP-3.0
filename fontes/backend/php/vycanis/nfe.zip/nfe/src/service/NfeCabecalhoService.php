<?php
use Illuminate\Database\Capsule\Manager as DB;
class NfeCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return NfeCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return NfeCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return NfeCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// nfeReferenciada
		$nfeReferenciadaModelListJson = $objJson->nfeReferenciadaModelList;
		if ($nfeReferenciadaModelListJson != null) {
			for ($i = 0; $i < count($nfeReferenciadaModelListJson); $i++) {
				$nfeReferenciada = new NfeReferenciadaModel();
				$nfeReferenciada->mapping($nfeReferenciadaModelListJson[$i]);
				$objModel->nfeReferenciadaModelList()->save($nfeReferenciada);
			}
		}

		// nfeEmitente
		$nfeEmitenteModelListJson = $objJson->nfeEmitenteModelList;
		if ($nfeEmitenteModelListJson != null) {
			for ($i = 0; $i < count($nfeEmitenteModelListJson); $i++) {
				$nfeEmitente = new NfeEmitenteModel();
				$nfeEmitente->mapping($nfeEmitenteModelListJson[$i]);
				$objModel->nfeEmitenteModelList()->save($nfeEmitente);
			}
		}

		// nfeDestinatario
		$nfeDestinatarioModelListJson = $objJson->nfeDestinatarioModelList;
		if ($nfeDestinatarioModelListJson != null) {
			for ($i = 0; $i < count($nfeDestinatarioModelListJson); $i++) {
				$nfeDestinatario = new NfeDestinatarioModel();
				$nfeDestinatario->mapping($nfeDestinatarioModelListJson[$i]);
				$objModel->nfeDestinatarioModelList()->save($nfeDestinatario);
			}
		}

		// nfeLocalRetirada
		$nfeLocalRetiradaModelListJson = $objJson->nfeLocalRetiradaModelList;
		if ($nfeLocalRetiradaModelListJson != null) {
			for ($i = 0; $i < count($nfeLocalRetiradaModelListJson); $i++) {
				$nfeLocalRetirada = new NfeLocalRetiradaModel();
				$nfeLocalRetirada->mapping($nfeLocalRetiradaModelListJson[$i]);
				$objModel->nfeLocalRetiradaModelList()->save($nfeLocalRetirada);
			}
		}

		// nfeLocalEntrega
		$nfeLocalEntregaModelListJson = $objJson->nfeLocalEntregaModelList;
		if ($nfeLocalEntregaModelListJson != null) {
			for ($i = 0; $i < count($nfeLocalEntregaModelListJson); $i++) {
				$nfeLocalEntrega = new NfeLocalEntregaModel();
				$nfeLocalEntrega->mapping($nfeLocalEntregaModelListJson[$i]);
				$objModel->nfeLocalEntregaModelList()->save($nfeLocalEntrega);
			}
		}

		// nfeTransporte
		$nfeTransporteModelListJson = $objJson->nfeTransporteModelList;
		if ($nfeTransporteModelListJson != null) {
			for ($i = 0; $i < count($nfeTransporteModelListJson); $i++) {
				$nfeTransporte = new NfeTransporteModel();
				$nfeTransporte->mapping($nfeTransporteModelListJson[$i]);
				$objModel->nfeTransporteModelList()->save($nfeTransporte);
			}
		}

		// nfeFatura
		$nfeFaturaModelListJson = $objJson->nfeFaturaModelList;
		if ($nfeFaturaModelListJson != null) {
			for ($i = 0; $i < count($nfeFaturaModelListJson); $i++) {
				$nfeFatura = new NfeFaturaModel();
				$nfeFatura->mapping($nfeFaturaModelListJson[$i]);
				$objModel->nfeFaturaModelList()->save($nfeFatura);
			}
		}

		// nfeCana
		$nfeCanaModelListJson = $objJson->nfeCanaModelList;
		if ($nfeCanaModelListJson != null) {
			for ($i = 0; $i < count($nfeCanaModelListJson); $i++) {
				$nfeCana = new NfeCanaModel();
				$nfeCana->mapping($nfeCanaModelListJson[$i]);
				$objModel->nfeCanaModelList()->save($nfeCana);
			}
		}

		// nfeProdRuralReferenciada
		$nfeProdRuralReferenciadaModelListJson = $objJson->nfeProdRuralReferenciadaModelList;
		if ($nfeProdRuralReferenciadaModelListJson != null) {
			for ($i = 0; $i < count($nfeProdRuralReferenciadaModelListJson); $i++) {
				$nfeProdRuralReferenciada = new NfeProdRuralReferenciadaModel();
				$nfeProdRuralReferenciada->mapping($nfeProdRuralReferenciadaModelListJson[$i]);
				$objModel->nfeProdRuralReferenciadaModelList()->save($nfeProdRuralReferenciada);
			}
		}

		// nfeNfReferenciada
		$nfeNfReferenciadaModelListJson = $objJson->nfeNfReferenciadaModelList;
		if ($nfeNfReferenciadaModelListJson != null) {
			for ($i = 0; $i < count($nfeNfReferenciadaModelListJson); $i++) {
				$nfeNfReferenciada = new NfeNfReferenciadaModel();
				$nfeNfReferenciada->mapping($nfeNfReferenciadaModelListJson[$i]);
				$objModel->nfeNfReferenciadaModelList()->save($nfeNfReferenciada);
			}
		}

		// nfeProcessoReferenciado
		$nfeProcessoReferenciadoModelListJson = $objJson->nfeProcessoReferenciadoModelList;
		if ($nfeProcessoReferenciadoModelListJson != null) {
			for ($i = 0; $i < count($nfeProcessoReferenciadoModelListJson); $i++) {
				$nfeProcessoReferenciado = new NfeProcessoReferenciadoModel();
				$nfeProcessoReferenciado->mapping($nfeProcessoReferenciadoModelListJson[$i]);
				$objModel->nfeProcessoReferenciadoModelList()->save($nfeProcessoReferenciado);
			}
		}

		// nfeAcessoXml
		$nfeAcessoXmlModelListJson = $objJson->nfeAcessoXmlModelList;
		if ($nfeAcessoXmlModelListJson != null) {
			for ($i = 0; $i < count($nfeAcessoXmlModelListJson); $i++) {
				$nfeAcessoXml = new NfeAcessoXmlModel();
				$nfeAcessoXml->mapping($nfeAcessoXmlModelListJson[$i]);
				$objModel->nfeAcessoXmlModelList()->save($nfeAcessoXml);
			}
		}

		// nfeInformacaoPagamento
		$nfeInformacaoPagamentoModelListJson = $objJson->nfeInformacaoPagamentoModelList;
		if ($nfeInformacaoPagamentoModelListJson != null) {
			for ($i = 0; $i < count($nfeInformacaoPagamentoModelListJson); $i++) {
				$nfeInformacaoPagamento = new NfeInformacaoPagamentoModel();
				$nfeInformacaoPagamento->mapping($nfeInformacaoPagamentoModelListJson[$i]);
				$objModel->nfeInformacaoPagamentoModelList()->save($nfeInformacaoPagamento);
			}
		}

		// nfeResponsavelTecnico
		$nfeResponsavelTecnicoModelListJson = $objJson->nfeResponsavelTecnicoModelList;
		if ($nfeResponsavelTecnicoModelListJson != null) {
			for ($i = 0; $i < count($nfeResponsavelTecnicoModelListJson); $i++) {
				$nfeResponsavelTecnico = new NfeResponsavelTecnicoModel();
				$nfeResponsavelTecnico->mapping($nfeResponsavelTecnicoModelListJson[$i]);
				$objModel->nfeResponsavelTecnicoModelList()->save($nfeResponsavelTecnico);
			}
		}

		// nfeCteReferenciado
		$nfeCteReferenciadoModelListJson = $objJson->nfeCteReferenciadoModelList;
		if ($nfeCteReferenciadoModelListJson != null) {
			for ($i = 0; $i < count($nfeCteReferenciadoModelListJson); $i++) {
				$nfeCteReferenciado = new NfeCteReferenciadoModel();
				$nfeCteReferenciado->mapping($nfeCteReferenciadoModelListJson[$i]);
				$objModel->nfeCteReferenciadoModelList()->save($nfeCteReferenciado);
			}
		}

		// nfeCupomFiscalReferenciado
		$nfeCupomFiscalReferenciadoModelListJson = $objJson->nfeCupomFiscalReferenciadoModelList;
		if ($nfeCupomFiscalReferenciadoModelListJson != null) {
			for ($i = 0; $i < count($nfeCupomFiscalReferenciadoModelListJson); $i++) {
				$nfeCupomFiscalReferenciado = new NfeCupomFiscalReferenciadoModel();
				$nfeCupomFiscalReferenciado->mapping($nfeCupomFiscalReferenciadoModelListJson[$i]);
				$objModel->nfeCupomFiscalReferenciadoModelList()->save($nfeCupomFiscalReferenciado);
			}
		}

	}	

	public function deleteChildren($object)
	{
		NfeReferenciadaModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeEmitenteModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeDestinatarioModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeLocalRetiradaModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeLocalEntregaModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeTransporteModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeFaturaModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeCanaModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeProdRuralReferenciadaModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeNfReferenciadaModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeProcessoReferenciadoModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeAcessoXmlModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeInformacaoPagamentoModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeResponsavelTecnicoModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeCteReferenciadoModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
		NfeCupomFiscalReferenciadoModel::where('id_nfe_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}