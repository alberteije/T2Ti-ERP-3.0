<?php
class NfeTransporteVolumeService extends ServiceBase
{
  public function getList()
  {
    return NfeTransporteVolumeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeTransporteVolumeModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeTransporteVolumeModel::find($id);
  }

}