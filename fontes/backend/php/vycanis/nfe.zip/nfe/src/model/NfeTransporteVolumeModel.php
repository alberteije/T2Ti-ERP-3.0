<?php
declare(strict_types=1);

class NfeTransporteVolumeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_transporte_volume';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeTransporteModel',
	];

	/**
		* Relations
		*/
	public function nfeTransporteModel()
	{
		return $this->belongsTo(NfeTransporteModel::class, 'id_nfe_transporte', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getEspecieAttribute()
	{
		return $this->attributes['especie'];
	}

	public function setEspecieAttribute($especie)
	{
		$this->attributes['especie'] = $especie;
	}

	public function getMarcaAttribute()
	{
		return $this->attributes['marca'];
	}

	public function setMarcaAttribute($marca)
	{
		$this->attributes['marca'] = $marca;
	}

	public function getNumeracaoAttribute()
	{
		return $this->attributes['numeracao'];
	}

	public function setNumeracaoAttribute($numeracao)
	{
		$this->attributes['numeracao'] = $numeracao;
	}

	public function getPesoLiquidoAttribute()
	{
		return (double)$this->attributes['peso_liquido'];
	}

	public function setPesoLiquidoAttribute($pesoLiquido)
	{
		$this->attributes['peso_liquido'] = $pesoLiquido;
	}

	public function getPesoBrutoAttribute()
	{
		return (double)$this->attributes['peso_bruto'];
	}

	public function setPesoBrutoAttribute($pesoBruto)
	{
		$this->attributes['peso_bruto'] = $pesoBruto;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);
				$this->setEspecieAttribute($object->especie);
				$this->setMarcaAttribute($object->marca);
				$this->setNumeracaoAttribute($object->numeracao);
				$this->setPesoLiquidoAttribute($object->pesoLiquido);
				$this->setPesoBrutoAttribute($object->pesoBruto);

				// link objects - lookups
				$nfeTransporteModel = new NfeTransporteModel();
				$nfeTransporteModel->mapping($object->nfeTransporteModel);
				$this->nfeTransporteModel()->associate($nfeTransporteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'especie' => $this->getEspecieAttribute(),
				'marca' => $this->getMarcaAttribute(),
				'numeracao' => $this->getNumeracaoAttribute(),
				'pesoLiquido' => $this->getPesoLiquidoAttribute(),
				'pesoBruto' => $this->getPesoBrutoAttribute(),
				'nfeTransporteModel' => $this->nfeTransporteModel,
			];
	}
}