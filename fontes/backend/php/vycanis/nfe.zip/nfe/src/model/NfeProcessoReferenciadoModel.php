<?php
declare(strict_types=1);

class NfeProcessoReferenciadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_processo_referenciado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdentificadorAttribute()
	{
		return $this->attributes['identificador'];
	}

	public function setIdentificadorAttribute($identificador)
	{
		$this->attributes['identificador'] = $identificador;
	}

	public function getOrigemAttribute()
	{
		return $this->attributes['origem'];
	}

	public function setOrigemAttribute($origem)
	{
		$this->attributes['origem'] = $origem;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdentificadorAttribute($object->identificador);
				$this->setOrigemAttribute($object->origem);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'identificador' => $this->getIdentificadorAttribute(),
				'origem' => $this->getOrigemAttribute(),
			];
	}
}