<?php
declare(strict_types=1);

class NfeDetEspecificoCombustivelModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_det_especifico_combustivel';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAnpAttribute()
	{
		return $this->attributes['codigo_anp'];
	}

	public function setCodigoAnpAttribute($codigoAnp)
	{
		$this->attributes['codigo_anp'] = $codigoAnp;
	}

	public function getDescricaoAnpAttribute()
	{
		return $this->attributes['descricao_anp'];
	}

	public function setDescricaoAnpAttribute($descricaoAnp)
	{
		$this->attributes['descricao_anp'] = $descricaoAnp;
	}

	public function getPercentualGlpAttribute()
	{
		return (double)$this->attributes['percentual_glp'];
	}

	public function setPercentualGlpAttribute($percentualGlp)
	{
		$this->attributes['percentual_glp'] = $percentualGlp;
	}

	public function getPercentualGasNacionalAttribute()
	{
		return (double)$this->attributes['percentual_gas_nacional'];
	}

	public function setPercentualGasNacionalAttribute($percentualGasNacional)
	{
		$this->attributes['percentual_gas_nacional'] = $percentualGasNacional;
	}

	public function getPercentualGasImportadoAttribute()
	{
		return (double)$this->attributes['percentual_gas_importado'];
	}

	public function setPercentualGasImportadoAttribute($percentualGasImportado)
	{
		$this->attributes['percentual_gas_importado'] = $percentualGasImportado;
	}

	public function getValorPartidaAttribute()
	{
		return (double)$this->attributes['valor_partida'];
	}

	public function setValorPartidaAttribute($valorPartida)
	{
		$this->attributes['valor_partida'] = $valorPartida;
	}

	public function getCodifAttribute()
	{
		return $this->attributes['codif'];
	}

	public function setCodifAttribute($codif)
	{
		$this->attributes['codif'] = $codif;
	}

	public function getQuantidadeTempAmbienteAttribute()
	{
		return (double)$this->attributes['quantidade_temp_ambiente'];
	}

	public function setQuantidadeTempAmbienteAttribute($quantidadeTempAmbiente)
	{
		$this->attributes['quantidade_temp_ambiente'] = $quantidadeTempAmbiente;
	}

	public function getUfConsumoAttribute()
	{
		return $this->attributes['uf_consumo'];
	}

	public function setUfConsumoAttribute($ufConsumo)
	{
		$this->attributes['uf_consumo'] = $ufConsumo;
	}

	public function getCideBaseCalculoAttribute()
	{
		return (double)$this->attributes['cide_base_calculo'];
	}

	public function setCideBaseCalculoAttribute($cideBaseCalculo)
	{
		$this->attributes['cide_base_calculo'] = $cideBaseCalculo;
	}

	public function getCideAliquotaAttribute()
	{
		return (double)$this->attributes['cide_aliquota'];
	}

	public function setCideAliquotaAttribute($cideAliquota)
	{
		$this->attributes['cide_aliquota'] = $cideAliquota;
	}

	public function getCideValorAttribute()
	{
		return (double)$this->attributes['cide_valor'];
	}

	public function setCideValorAttribute($cideValor)
	{
		$this->attributes['cide_valor'] = $cideValor;
	}

	public function getEncerranteBicoAttribute()
	{
		return $this->attributes['encerrante_bico'];
	}

	public function setEncerranteBicoAttribute($encerranteBico)
	{
		$this->attributes['encerrante_bico'] = $encerranteBico;
	}

	public function getEncerranteBombaAttribute()
	{
		return $this->attributes['encerrante_bomba'];
	}

	public function setEncerranteBombaAttribute($encerranteBomba)
	{
		$this->attributes['encerrante_bomba'] = $encerranteBomba;
	}

	public function getEncerranteTanqueAttribute()
	{
		return $this->attributes['encerrante_tanque'];
	}

	public function setEncerranteTanqueAttribute($encerranteTanque)
	{
		$this->attributes['encerrante_tanque'] = $encerranteTanque;
	}

	public function getEncerranteValorInicioAttribute()
	{
		return (double)$this->attributes['encerrante_valor_inicio'];
	}

	public function setEncerranteValorInicioAttribute($encerranteValorInicio)
	{
		$this->attributes['encerrante_valor_inicio'] = $encerranteValorInicio;
	}

	public function getEncerranteValorFimAttribute()
	{
		return (double)$this->attributes['encerrante_valor_fim'];
	}

	public function setEncerranteValorFimAttribute($encerranteValorFim)
	{
		$this->attributes['encerrante_valor_fim'] = $encerranteValorFim;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAnpAttribute($object->codigoAnp);
				$this->setDescricaoAnpAttribute($object->descricaoAnp);
				$this->setPercentualGlpAttribute($object->percentualGlp);
				$this->setPercentualGasNacionalAttribute($object->percentualGasNacional);
				$this->setPercentualGasImportadoAttribute($object->percentualGasImportado);
				$this->setValorPartidaAttribute($object->valorPartida);
				$this->setCodifAttribute($object->codif);
				$this->setQuantidadeTempAmbienteAttribute($object->quantidadeTempAmbiente);
				$this->setUfConsumoAttribute($object->ufConsumo);
				$this->setCideBaseCalculoAttribute($object->cideBaseCalculo);
				$this->setCideAliquotaAttribute($object->cideAliquota);
				$this->setCideValorAttribute($object->cideValor);
				$this->setEncerranteBicoAttribute($object->encerranteBico);
				$this->setEncerranteBombaAttribute($object->encerranteBomba);
				$this->setEncerranteTanqueAttribute($object->encerranteTanque);
				$this->setEncerranteValorInicioAttribute($object->encerranteValorInicio);
				$this->setEncerranteValorFimAttribute($object->encerranteValorFim);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoAnp' => $this->getCodigoAnpAttribute(),
				'descricaoAnp' => $this->getDescricaoAnpAttribute(),
				'percentualGlp' => $this->getPercentualGlpAttribute(),
				'percentualGasNacional' => $this->getPercentualGasNacionalAttribute(),
				'percentualGasImportado' => $this->getPercentualGasImportadoAttribute(),
				'valorPartida' => $this->getValorPartidaAttribute(),
				'codif' => $this->getCodifAttribute(),
				'quantidadeTempAmbiente' => $this->getQuantidadeTempAmbienteAttribute(),
				'ufConsumo' => $this->getUfConsumoAttribute(),
				'cideBaseCalculo' => $this->getCideBaseCalculoAttribute(),
				'cideAliquota' => $this->getCideAliquotaAttribute(),
				'cideValor' => $this->getCideValorAttribute(),
				'encerranteBico' => $this->getEncerranteBicoAttribute(),
				'encerranteBomba' => $this->getEncerranteBombaAttribute(),
				'encerranteTanque' => $this->getEncerranteTanqueAttribute(),
				'encerranteValorInicio' => $this->getEncerranteValorInicioAttribute(),
				'encerranteValorFim' => $this->getEncerranteValorFimAttribute(),
			];
	}
}