<?php
declare(strict_types=1);

class NfeDetEspecificoVeiculoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_det_especifico_veiculo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoOperacaoAttribute()
	{
		return $this->attributes['tipo_operacao'];
	}

	public function setTipoOperacaoAttribute($tipoOperacao)
	{
		$this->attributes['tipo_operacao'] = $tipoOperacao;
	}

	public function getChassiAttribute()
	{
		return $this->attributes['chassi'];
	}

	public function setChassiAttribute($chassi)
	{
		$this->attributes['chassi'] = $chassi;
	}

	public function getCorAttribute()
	{
		return $this->attributes['cor'];
	}

	public function setCorAttribute($cor)
	{
		$this->attributes['cor'] = $cor;
	}

	public function getDescricaoCorAttribute()
	{
		return $this->attributes['descricao_cor'];
	}

	public function setDescricaoCorAttribute($descricaoCor)
	{
		$this->attributes['descricao_cor'] = $descricaoCor;
	}

	public function getPotenciaMotorAttribute()
	{
		return $this->attributes['potencia_motor'];
	}

	public function setPotenciaMotorAttribute($potenciaMotor)
	{
		$this->attributes['potencia_motor'] = $potenciaMotor;
	}

	public function getCilindradasAttribute()
	{
		return $this->attributes['cilindradas'];
	}

	public function setCilindradasAttribute($cilindradas)
	{
		$this->attributes['cilindradas'] = $cilindradas;
	}

	public function getPesoLiquidoAttribute()
	{
		return $this->attributes['peso_liquido'];
	}

	public function setPesoLiquidoAttribute($pesoLiquido)
	{
		$this->attributes['peso_liquido'] = $pesoLiquido;
	}

	public function getPesoBrutoAttribute()
	{
		return $this->attributes['peso_bruto'];
	}

	public function setPesoBrutoAttribute($pesoBruto)
	{
		$this->attributes['peso_bruto'] = $pesoBruto;
	}

	public function getNumeroSerieAttribute()
	{
		return $this->attributes['numero_serie'];
	}

	public function setNumeroSerieAttribute($numeroSerie)
	{
		$this->attributes['numero_serie'] = $numeroSerie;
	}

	public function getTipoCombustivelAttribute()
	{
		return $this->attributes['tipo_combustivel'];
	}

	public function setTipoCombustivelAttribute($tipoCombustivel)
	{
		$this->attributes['tipo_combustivel'] = $tipoCombustivel;
	}

	public function getNumeroMotorAttribute()
	{
		return $this->attributes['numero_motor'];
	}

	public function setNumeroMotorAttribute($numeroMotor)
	{
		$this->attributes['numero_motor'] = $numeroMotor;
	}

	public function getCapacidadeMaximaTracaoAttribute()
	{
		return $this->attributes['capacidade_maxima_tracao'];
	}

	public function setCapacidadeMaximaTracaoAttribute($capacidadeMaximaTracao)
	{
		$this->attributes['capacidade_maxima_tracao'] = $capacidadeMaximaTracao;
	}

	public function getDistanciaEixosAttribute()
	{
		return $this->attributes['distancia_eixos'];
	}

	public function setDistanciaEixosAttribute($distanciaEixos)
	{
		$this->attributes['distancia_eixos'] = $distanciaEixos;
	}

	public function getAnoModeloAttribute()
	{
		return $this->attributes['ano_modelo'];
	}

	public function setAnoModeloAttribute($anoModelo)
	{
		$this->attributes['ano_modelo'] = $anoModelo;
	}

	public function getAnoFabricacaoAttribute()
	{
		return $this->attributes['ano_fabricacao'];
	}

	public function setAnoFabricacaoAttribute($anoFabricacao)
	{
		$this->attributes['ano_fabricacao'] = $anoFabricacao;
	}

	public function getTipoPinturaAttribute()
	{
		return $this->attributes['tipo_pintura'];
	}

	public function setTipoPinturaAttribute($tipoPintura)
	{
		$this->attributes['tipo_pintura'] = $tipoPintura;
	}

	public function getTipoVeiculoAttribute()
	{
		return $this->attributes['tipo_veiculo'];
	}

	public function setTipoVeiculoAttribute($tipoVeiculo)
	{
		$this->attributes['tipo_veiculo'] = $tipoVeiculo;
	}

	public function getEspecieVeiculoAttribute()
	{
		return $this->attributes['especie_veiculo'];
	}

	public function setEspecieVeiculoAttribute($especieVeiculo)
	{
		$this->attributes['especie_veiculo'] = $especieVeiculo;
	}

	public function getCondicaoVinAttribute()
	{
		return $this->attributes['condicao_vin'];
	}

	public function setCondicaoVinAttribute($condicaoVin)
	{
		$this->attributes['condicao_vin'] = $condicaoVin;
	}

	public function getCondicaoVeiculoAttribute()
	{
		return $this->attributes['condicao_veiculo'];
	}

	public function setCondicaoVeiculoAttribute($condicaoVeiculo)
	{
		$this->attributes['condicao_veiculo'] = $condicaoVeiculo;
	}

	public function getCodigoMarcaModeloAttribute()
	{
		return $this->attributes['codigo_marca_modelo'];
	}

	public function setCodigoMarcaModeloAttribute($codigoMarcaModelo)
	{
		$this->attributes['codigo_marca_modelo'] = $codigoMarcaModelo;
	}

	public function getCodigoCorDenatranAttribute()
	{
		return $this->attributes['codigo_cor_denatran'];
	}

	public function setCodigoCorDenatranAttribute($codigoCorDenatran)
	{
		$this->attributes['codigo_cor_denatran'] = $codigoCorDenatran;
	}

	public function getLotacaoMaximaAttribute()
	{
		return $this->attributes['lotacao_maxima'];
	}

	public function setLotacaoMaximaAttribute($lotacaoMaxima)
	{
		$this->attributes['lotacao_maxima'] = $lotacaoMaxima;
	}

	public function getRestricaoAttribute()
	{
		return $this->attributes['restricao'];
	}

	public function setRestricaoAttribute($restricao)
	{
		$this->attributes['restricao'] = $restricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoOperacaoAttribute($object->tipoOperacao);
				$this->setChassiAttribute($object->chassi);
				$this->setCorAttribute($object->cor);
				$this->setDescricaoCorAttribute($object->descricaoCor);
				$this->setPotenciaMotorAttribute($object->potenciaMotor);
				$this->setCilindradasAttribute($object->cilindradas);
				$this->setPesoLiquidoAttribute($object->pesoLiquido);
				$this->setPesoBrutoAttribute($object->pesoBruto);
				$this->setNumeroSerieAttribute($object->numeroSerie);
				$this->setTipoCombustivelAttribute($object->tipoCombustivel);
				$this->setNumeroMotorAttribute($object->numeroMotor);
				$this->setCapacidadeMaximaTracaoAttribute($object->capacidadeMaximaTracao);
				$this->setDistanciaEixosAttribute($object->distanciaEixos);
				$this->setAnoModeloAttribute($object->anoModelo);
				$this->setAnoFabricacaoAttribute($object->anoFabricacao);
				$this->setTipoPinturaAttribute($object->tipoPintura);
				$this->setTipoVeiculoAttribute($object->tipoVeiculo);
				$this->setEspecieVeiculoAttribute($object->especieVeiculo);
				$this->setCondicaoVinAttribute($object->condicaoVin);
				$this->setCondicaoVeiculoAttribute($object->condicaoVeiculo);
				$this->setCodigoMarcaModeloAttribute($object->codigoMarcaModelo);
				$this->setCodigoCorDenatranAttribute($object->codigoCorDenatran);
				$this->setLotacaoMaximaAttribute($object->lotacaoMaxima);
				$this->setRestricaoAttribute($object->restricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipoOperacao' => $this->getTipoOperacaoAttribute(),
				'chassi' => $this->getChassiAttribute(),
				'cor' => $this->getCorAttribute(),
				'descricaoCor' => $this->getDescricaoCorAttribute(),
				'potenciaMotor' => $this->getPotenciaMotorAttribute(),
				'cilindradas' => $this->getCilindradasAttribute(),
				'pesoLiquido' => $this->getPesoLiquidoAttribute(),
				'pesoBruto' => $this->getPesoBrutoAttribute(),
				'numeroSerie' => $this->getNumeroSerieAttribute(),
				'tipoCombustivel' => $this->getTipoCombustivelAttribute(),
				'numeroMotor' => $this->getNumeroMotorAttribute(),
				'capacidadeMaximaTracao' => $this->getCapacidadeMaximaTracaoAttribute(),
				'distanciaEixos' => $this->getDistanciaEixosAttribute(),
				'anoModelo' => $this->getAnoModeloAttribute(),
				'anoFabricacao' => $this->getAnoFabricacaoAttribute(),
				'tipoPintura' => $this->getTipoPinturaAttribute(),
				'tipoVeiculo' => $this->getTipoVeiculoAttribute(),
				'especieVeiculo' => $this->getEspecieVeiculoAttribute(),
				'condicaoVin' => $this->getCondicaoVinAttribute(),
				'condicaoVeiculo' => $this->getCondicaoVeiculoAttribute(),
				'codigoMarcaModelo' => $this->getCodigoMarcaModeloAttribute(),
				'codigoCorDenatran' => $this->getCodigoCorDenatranAttribute(),
				'lotacaoMaxima' => $this->getLotacaoMaximaAttribute(),
				'restricao' => $this->getRestricaoAttribute(),
			];
	}
}