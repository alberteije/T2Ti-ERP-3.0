<?php
declare(strict_types=1);

class NfeDetalheImpostoPisStModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_pis_st';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorBaseCalculoPisStAttribute()
	{
		return (double)$this->attributes['valor_base_calculo_pis_st'];
	}

	public function setValorBaseCalculoPisStAttribute($valorBaseCalculoPisSt)
	{
		$this->attributes['valor_base_calculo_pis_st'] = $valorBaseCalculoPisSt;
	}

	public function getAliquotaPisStPercentualAttribute()
	{
		return (double)$this->attributes['aliquota_pis_st_percentual'];
	}

	public function setAliquotaPisStPercentualAttribute($aliquotaPisStPercentual)
	{
		$this->attributes['aliquota_pis_st_percentual'] = $aliquotaPisStPercentual;
	}

	public function getQuantidadeVendidaPisStAttribute()
	{
		return (double)$this->attributes['quantidade_vendida_pis_st'];
	}

	public function setQuantidadeVendidaPisStAttribute($quantidadeVendidaPisSt)
	{
		$this->attributes['quantidade_vendida_pis_st'] = $quantidadeVendidaPisSt;
	}

	public function getAliquotaPisStReaisAttribute()
	{
		return (double)$this->attributes['aliquota_pis_st_reais'];
	}

	public function setAliquotaPisStReaisAttribute($aliquotaPisStReais)
	{
		$this->attributes['aliquota_pis_st_reais'] = $aliquotaPisStReais;
	}

	public function getValorPisStAttribute()
	{
		return (double)$this->attributes['valor_pis_st'];
	}

	public function setValorPisStAttribute($valorPisSt)
	{
		$this->attributes['valor_pis_st'] = $valorPisSt;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorBaseCalculoPisStAttribute($object->valorBaseCalculoPisSt);
				$this->setAliquotaPisStPercentualAttribute($object->aliquotaPisStPercentual);
				$this->setQuantidadeVendidaPisStAttribute($object->quantidadeVendidaPisSt);
				$this->setAliquotaPisStReaisAttribute($object->aliquotaPisStReais);
				$this->setValorPisStAttribute($object->valorPisSt);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valorBaseCalculoPisSt' => $this->getValorBaseCalculoPisStAttribute(),
				'aliquotaPisStPercentual' => $this->getAliquotaPisStPercentualAttribute(),
				'quantidadeVendidaPisSt' => $this->getQuantidadeVendidaPisStAttribute(),
				'aliquotaPisStReais' => $this->getAliquotaPisStReaisAttribute(),
				'valorPisSt' => $this->getValorPisStAttribute(),
			];
	}
}