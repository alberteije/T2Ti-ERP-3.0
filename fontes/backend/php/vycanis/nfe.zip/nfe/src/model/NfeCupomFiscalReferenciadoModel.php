<?php
declare(strict_types=1);

class NfeCupomFiscalReferenciadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_cupom_fiscal_referenciado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getModeloDocumentoFiscalAttribute()
	{
		return $this->attributes['modelo_documento_fiscal'];
	}

	public function setModeloDocumentoFiscalAttribute($modeloDocumentoFiscal)
	{
		$this->attributes['modelo_documento_fiscal'] = $modeloDocumentoFiscal;
	}

	public function getNumeroOrdemEcfAttribute()
	{
		return $this->attributes['numero_ordem_ecf'];
	}

	public function setNumeroOrdemEcfAttribute($numeroOrdemEcf)
	{
		$this->attributes['numero_ordem_ecf'] = $numeroOrdemEcf;
	}

	public function getCooAttribute()
	{
		return $this->attributes['coo'];
	}

	public function setCooAttribute($coo)
	{
		$this->attributes['coo'] = $coo;
	}

	public function getDataEmissaoCupomAttribute()
	{
		return $this->attributes['data_emissao_cupom'];
	}

	public function setDataEmissaoCupomAttribute($dataEmissaoCupom)
	{
		$this->attributes['data_emissao_cupom'] = $dataEmissaoCupom;
	}

	public function getNumeroCaixaAttribute()
	{
		return $this->attributes['numero_caixa'];
	}

	public function setNumeroCaixaAttribute($numeroCaixa)
	{
		$this->attributes['numero_caixa'] = $numeroCaixa;
	}

	public function getNumeroSerieEcfAttribute()
	{
		return $this->attributes['numero_serie_ecf'];
	}

	public function setNumeroSerieEcfAttribute($numeroSerieEcf)
	{
		$this->attributes['numero_serie_ecf'] = $numeroSerieEcf;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setModeloDocumentoFiscalAttribute($object->modeloDocumentoFiscal);
				$this->setNumeroOrdemEcfAttribute($object->numeroOrdemEcf);
				$this->setCooAttribute($object->coo);
				$this->setDataEmissaoCupomAttribute($object->dataEmissaoCupom);
				$this->setNumeroCaixaAttribute($object->numeroCaixa);
				$this->setNumeroSerieEcfAttribute($object->numeroSerieEcf);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'modeloDocumentoFiscal' => $this->getModeloDocumentoFiscalAttribute(),
				'numeroOrdemEcf' => $this->getNumeroOrdemEcfAttribute(),
				'coo' => $this->getCooAttribute(),
				'dataEmissaoCupom' => $this->getDataEmissaoCupomAttribute(),
				'numeroCaixa' => $this->getNumeroCaixaAttribute(),
				'numeroSerieEcf' => $this->getNumeroSerieEcfAttribute(),
			];
	}
}