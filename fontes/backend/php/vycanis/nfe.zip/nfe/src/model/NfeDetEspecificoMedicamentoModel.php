<?php
declare(strict_types=1);

class NfeDetEspecificoMedicamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_det_especifico_medicamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAnvisaAttribute()
	{
		return $this->attributes['codigo_anvisa'];
	}

	public function setCodigoAnvisaAttribute($codigoAnvisa)
	{
		$this->attributes['codigo_anvisa'] = $codigoAnvisa;
	}

	public function getMotivoIsencaoAttribute()
	{
		return $this->attributes['motivo_isencao'];
	}

	public function setMotivoIsencaoAttribute($motivoIsencao)
	{
		$this->attributes['motivo_isencao'] = $motivoIsencao;
	}

	public function getPrecoMaximoConsumidorAttribute()
	{
		return (double)$this->attributes['preco_maximo_consumidor'];
	}

	public function setPrecoMaximoConsumidorAttribute($precoMaximoConsumidor)
	{
		$this->attributes['preco_maximo_consumidor'] = $precoMaximoConsumidor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAnvisaAttribute($object->codigoAnvisa);
				$this->setMotivoIsencaoAttribute($object->motivoIsencao);
				$this->setPrecoMaximoConsumidorAttribute($object->precoMaximoConsumidor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoAnvisa' => $this->getCodigoAnvisaAttribute(),
				'motivoIsencao' => $this->getMotivoIsencaoAttribute(),
				'precoMaximoConsumidor' => $this->getPrecoMaximoConsumidorAttribute(),
			];
	}
}