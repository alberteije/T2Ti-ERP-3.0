<?php
declare(strict_types=1);

class NfeDetEspecificoArmamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_det_especifico_armamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoArmaAttribute()
	{
		return $this->attributes['tipo_arma'];
	}

	public function setTipoArmaAttribute($tipoArma)
	{
		$this->attributes['tipo_arma'] = $tipoArma;
	}

	public function getNumeroSerieArmaAttribute()
	{
		return $this->attributes['numero_serie_arma'];
	}

	public function setNumeroSerieArmaAttribute($numeroSerieArma)
	{
		$this->attributes['numero_serie_arma'] = $numeroSerieArma;
	}

	public function getNumeroSerieCanoAttribute()
	{
		return $this->attributes['numero_serie_cano'];
	}

	public function setNumeroSerieCanoAttribute($numeroSerieCano)
	{
		$this->attributes['numero_serie_cano'] = $numeroSerieCano;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoArmaAttribute($object->tipoArma);
				$this->setNumeroSerieArmaAttribute($object->numeroSerieArma);
				$this->setNumeroSerieCanoAttribute($object->numeroSerieCano);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipoArma' => $this->getTipoArmaAttribute(),
				'numeroSerieArma' => $this->getNumeroSerieArmaAttribute(),
				'numeroSerieCano' => $this->getNumeroSerieCanoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
			];
	}
}