<?php
declare(strict_types=1);

class NfeInformacaoPagamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_informacao_pagamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIndicadorPagamentoAttribute()
	{
		return $this->attributes['indicador_pagamento'];
	}

	public function setIndicadorPagamentoAttribute($indicadorPagamento)
	{
		$this->attributes['indicador_pagamento'] = $indicadorPagamento;
	}

	public function getMeioPagamentoAttribute()
	{
		return $this->attributes['meio_pagamento'];
	}

	public function setMeioPagamentoAttribute($meioPagamento)
	{
		$this->attributes['meio_pagamento'] = $meioPagamento;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getTipoIntegracaoAttribute()
	{
		return $this->attributes['tipo_integracao'];
	}

	public function setTipoIntegracaoAttribute($tipoIntegracao)
	{
		$this->attributes['tipo_integracao'] = $tipoIntegracao;
	}

	public function getCnpjOperadoraCartaoAttribute()
	{
		return $this->attributes['cnpj_operadora_cartao'];
	}

	public function setCnpjOperadoraCartaoAttribute($cnpjOperadoraCartao)
	{
		$this->attributes['cnpj_operadora_cartao'] = $cnpjOperadoraCartao;
	}

	public function getBandeiraAttribute()
	{
		return $this->attributes['bandeira'];
	}

	public function setBandeiraAttribute($bandeira)
	{
		$this->attributes['bandeira'] = $bandeira;
	}

	public function getNumeroAutorizacaoAttribute()
	{
		return $this->attributes['numero_autorizacao'];
	}

	public function setNumeroAutorizacaoAttribute($numeroAutorizacao)
	{
		$this->attributes['numero_autorizacao'] = $numeroAutorizacao;
	}

	public function getTrocoAttribute()
	{
		return (double)$this->attributes['troco'];
	}

	public function setTrocoAttribute($troco)
	{
		$this->attributes['troco'] = $troco;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIndicadorPagamentoAttribute($object->indicadorPagamento);
				$this->setMeioPagamentoAttribute($object->meioPagamento);
				$this->setValorAttribute($object->valor);
				$this->setTipoIntegracaoAttribute($object->tipoIntegracao);
				$this->setCnpjOperadoraCartaoAttribute($object->cnpjOperadoraCartao);
				$this->setBandeiraAttribute($object->bandeira);
				$this->setNumeroAutorizacaoAttribute($object->numeroAutorizacao);
				$this->setTrocoAttribute($object->troco);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'indicadorPagamento' => $this->getIndicadorPagamentoAttribute(),
				'meioPagamento' => $this->getMeioPagamentoAttribute(),
				'valor' => $this->getValorAttribute(),
				'tipoIntegracao' => $this->getTipoIntegracaoAttribute(),
				'cnpjOperadoraCartao' => $this->getCnpjOperadoraCartaoAttribute(),
				'bandeira' => $this->getBandeiraAttribute(),
				'numeroAutorizacao' => $this->getNumeroAutorizacaoAttribute(),
				'troco' => $this->getTrocoAttribute(),
			];
	}
}