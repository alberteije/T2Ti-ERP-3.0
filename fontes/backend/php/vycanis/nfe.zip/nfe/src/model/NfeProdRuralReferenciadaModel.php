<?php
declare(strict_types=1);

class NfeProdRuralReferenciadaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_prod_rural_referenciada';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoUfAttribute()
	{
		return $this->attributes['codigo_uf'];
	}

	public function setCodigoUfAttribute($codigoUf)
	{
		$this->attributes['codigo_uf'] = $codigoUf;
	}

	public function getAnoMesAttribute()
	{
		return $this->attributes['ano_mes'];
	}

	public function setAnoMesAttribute($anoMes)
	{
		$this->attributes['ano_mes'] = $anoMes;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	public function getModeloAttribute()
	{
		return $this->attributes['modelo'];
	}

	public function setModeloAttribute($modelo)
	{
		$this->attributes['modelo'] = $modelo;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroNfAttribute()
	{
		return $this->attributes['numero_nf'];
	}

	public function setNumeroNfAttribute($numeroNf)
	{
		$this->attributes['numero_nf'] = $numeroNf;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoUfAttribute($object->codigoUf);
				$this->setAnoMesAttribute($object->anoMes);
				$this->setCnpjAttribute($object->cnpj);
				$this->setCpfAttribute($object->cpf);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);
				$this->setModeloAttribute($object->modelo);
				$this->setSerieAttribute($object->serie);
				$this->setNumeroNfAttribute($object->numeroNf);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigoUf' => $this->getCodigoUfAttribute(),
				'anoMes' => $this->getAnoMesAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
				'modelo' => $this->getModeloAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numeroNf' => $this->getNumeroNfAttribute(),
			];
	}
}