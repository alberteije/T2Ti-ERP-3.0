<?php
class NfeTransporteVolumeController extends ControllerBase
{

		private $nfeTransporteVolumeService = null;

		public function __construct()
		{	 
				$this->nfeTransporteVolumeService = new NfeTransporteVolumeService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->nfeTransporteVolumeService->getListFilter($filter);
						} else {
								$resultList = $this->nfeTransporteVolumeService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList NfeTransporteVolume]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->nfeTransporteVolumeService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject NfeTransporteVolume]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject NfeTransporteVolume]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert NfeTransporteVolume]', null);
						}

						$objModel = new NfeTransporteVolumeModel();
						$objModel->mapping($objJson);

						$this->nfeTransporteVolumeService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert NfeTransporteVolume]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->nfeTransporteVolumeService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update NfeTransporteVolume]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->nfeTransporteVolumeService->save($objFromDatabase);
								$objFromDatabase = $this->nfeTransporteVolumeService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update NfeTransporteVolume]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->nfeTransporteVolumeService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete NfeTransporteVolume]', null);
						} else {
								$this->nfeTransporteVolumeService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete NfeTransporteVolume]', $e);
				}
		}
}
