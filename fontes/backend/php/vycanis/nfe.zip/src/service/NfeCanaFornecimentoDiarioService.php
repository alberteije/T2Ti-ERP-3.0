<?php
class NfeCanaFornecimentoDiarioService extends ServiceBase
{
  public function getList()
  {
    return NfeCanaFornecimentoDiarioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeCanaFornecimentoDiarioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeCanaFornecimentoDiarioModel::find($id);
  }

}