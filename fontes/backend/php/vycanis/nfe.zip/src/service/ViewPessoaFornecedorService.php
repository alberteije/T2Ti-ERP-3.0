<?php
class ViewPessoaFornecedorService extends ServiceBase
{
  public function getList()
  {
    return ViewPessoaFornecedorModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewPessoaFornecedorModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewPessoaFornecedorModel::find($id);
  }

}