<?php
class NfeNumeroService extends ServiceBase
{
  public function getList()
  {
    return NfeNumeroModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeNumeroModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeNumeroModel::find($id);
  }

}