<?php
class NfeTransporteReboqueService extends ServiceBase
{
  public function getList()
  {
    return NfeTransporteReboqueModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeTransporteReboqueModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeTransporteReboqueModel::find($id);
  }

}