<?php
class NfeImportacaoDetalheService extends ServiceBase
{
  public function getList()
  {
    return NfeImportacaoDetalheModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeImportacaoDetalheModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeImportacaoDetalheModel::find($id);
  }

}