<?php
class NfeDuplicataService extends ServiceBase
{
  public function getList()
  {
    return NfeDuplicataModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeDuplicataModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeDuplicataModel::find($id);
  }

}