<?php
require __DIR__ . '/../../../vendor/autoload.php';

use Illuminate\Database\Capsule\Manager as DB;

class NfeCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return NfeCabecalhoModel::select()->get();
	}

	public function getListFilter($filter)
	{
		return NfeCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return NfeCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});
	}

	public function insertChildren($objJson, $objModel)
	{
		// nfeDetalhe
		$this->insertDetalhesAndChildren($objJson, $objModel);

		// nfeEmitente
		if (isset($objJson->nfeEmitenteModel)) {
			$nfeEmitenteModel = new NfeEmitenteModel();
			$nfeEmitenteModel->mapping($objJson->nfeEmitenteModel);
			$objModel->nfeEmitenteModel()->save($nfeEmitenteModel);
		}

		// nfeDestinatario
		if (isset($objJson->nfeDestinatarioModel)) {
			$nfeDestinatarioModel = new NfeDestinatarioModel();
			$nfeDestinatarioModel->mapping($objJson->nfeDestinatarioModel);
			$objModel->nfeDestinatarioModel()->save($nfeDestinatarioModel);
		}

		// nfeLocalRetirada
		if (isset($objJson->nfeLocalRetiradaModel)) {
			$nfeLocalRetiradaModel = new NfeLocalRetiradaModel();
			$nfeLocalRetiradaModel->mapping($objJson->nfeLocalRetiradaModel);
			$objModel->nfeLocalRetiradaModel()->save($nfeLocalRetiradaModel);
		}

		// nfeLocalEntrega
		if (isset($objJson->nfeLocalEntregaModel)) {
			$nfeLocalEntregaModel = new NfeLocalEntregaModel();
			$nfeLocalEntregaModel->mapping($objJson->nfeLocalEntregaModel);
			$objModel->nfeLocalEntregaModel()->save($nfeLocalEntregaModel);
		}

		// nfeResponsavelTecnico
		if (isset($objJson->nfeResponsavelTecnicoModel)) {
			$nfeResponsavelTecnicoModel = new NfeResponsavelTecnicoModel();
			$nfeResponsavelTecnicoModel->mapping($objJson->nfeResponsavelTecnicoModel);
			$objModel->nfeResponsavelTecnicoModel()->save($nfeResponsavelTecnicoModel);
		}

		// nfeCana
		if (isset($objJson->nfeCanaModel)) {
			$nfeCanaModel = new NfeCanaModel();
			$nfeCanaModel->mapping($objJson->nfeCanaModel);
			$objModel->nfeCanaModel()->save($nfeCanaModel);

			// nfeCanaDeducoesSafra
			$nfeCanaDeducoesSafraListJson = $objJson->nfeCanaModel->nfeCanaDeducoesSafraModelList;
			if ($nfeCanaDeducoesSafraListJson != null) {
				for ($i = 0; $i < count($nfeCanaDeducoesSafraListJson); $i++) {
					$nfeCanaDeducoesSafra = new NfeCanaDeducoesSafraModel();
					$nfeCanaDeducoesSafra->mapping($nfeCanaDeducoesSafraListJson[$i]);
					$objModel->nfeCanaModel->nfeCanaDeducoesSafraModelList()->save($nfeCanaDeducoesSafra);
				}
			}

			// nfeCanaFornecimentoDiario
			$nfeCanaFornecimentoDiarioListJson = $objJson->nfeCanaModel->nfeCanaFornecimentoDiarioModelList;
			if ($nfeCanaFornecimentoDiarioListJson != null) {
				for ($i = 0; $i < count($nfeCanaFornecimentoDiarioListJson); $i++) {
					$nfeCanaFornecimentoDiario = new NfeCanaFornecimentoDiarioModel();
					$nfeCanaFornecimentoDiario->mapping($nfeCanaFornecimentoDiarioListJson[$i]);
					$objModel->nfeCanaModel->nfeCanaFornecimentoDiarioModelList()->save($nfeCanaFornecimentoDiario);
				}
			}
		}

		// nfeFatura
		if (isset($objJson->nfeFaturaModel)) {
			$nfeFaturaModel = new NfeFaturaModel();
			$nfeFaturaModel->mapping($objJson->nfeFaturaModel);
			$objModel->nfeFaturaModel()->save($nfeFaturaModel);

			// nfeDuplicata
			$nfeDuplicataListJson = $objJson->nfeFaturaModel->nfeDuplicataModelList;
			if ($nfeDuplicataListJson != null) {
				for ($i = 0; $i < count($nfeDuplicataListJson); $i++) {
					$nfeDuplicata = new NfeDuplicataModel();
					$nfeDuplicata->mapping($nfeDuplicataListJson[$i]);
					$objModel->nfeFaturaModel->nfeDuplicataModelList()->save($nfeDuplicata);
				}
			}
		}

		// nfeTransporte
		if (isset($objJson->nfeTransporteModel)) {
			$nfeTransporteModel = new NfeTransporteModel();
			$nfeTransporteModel->mapping($objJson->nfeTransporteModel);
			$objModel->nfeTransporteModel()->save($nfeTransporteModel);

			// nfeTransporteReboque
			$nfeTransporteReboqueListJson = $objJson->nfeTransporteModel->nfeTransporteReboqueModelList;
			if ($nfeTransporteReboqueListJson != null) {
				for ($i = 0; $i < count($nfeTransporteReboqueListJson); $i++) {
					$nfeTransporteReboque = new NfeTransporteReboqueModel();
					$nfeTransporteReboque->mapping($nfeTransporteReboqueListJson[$i]);
					$objModel->nfeTransporteModel->nfeTransporteReboqueModelList()->save($nfeTransporteReboque);
				}
			}

			// nfeTransporteVolume
			$nfeTransporteVolumeListJson = $objJson->nfeTransporteModel->nfeTransporteVolumeModelList;
			if ($nfeTransporteVolumeListJson != null) {
				for ($i = 0; $i < count($nfeTransporteVolumeListJson); $i++) {
					$nfeTransporteVolume = new NfeTransporteVolumeModel();
					$nfeTransporteVolume->mapping($nfeTransporteVolumeListJson[$i]);
					$objModel->nfeTransporteModel->nfeTransporteVolumeModelList()->save($nfeTransporteVolume);

					$nfeTransporteVolumeLacreListJson = $nfeTransporteVolumeListJson[$i]->nfeTransporteVolumeLacreModelList;
					if ($nfeTransporteVolumeLacreListJson != null) {
						for ($j = 0; $j < count($nfeTransporteVolumeLacreListJson); $j++) {
							$nfeTransporteVolumeLacre = new NfeTransporteVolumeLacreModel();
							$nfeTransporteVolumeLacre->mapping($nfeTransporteVolumeLacreListJson[$j]);
							$nfeTransporteVolume->nfeTransporteVolumeLacreModelList()->save($nfeTransporteVolumeLacre);
						}
					}
				}
			}
		}

		// nfeReferenciada
		$nfeReferenciadaModelListJson = $objJson->nfeReferenciadaModelList;
		if ($nfeReferenciadaModelListJson != null) {
			for ($i = 0; $i < count($nfeReferenciadaModelListJson); $i++) {
				$nfeReferenciada = new NfeReferenciadaModel();
				$nfeReferenciada->mapping($nfeReferenciadaModelListJson[$i]);
				$objModel->nfeReferenciadaModelList()->save($nfeReferenciada);
			}
		}

		// nfeProdRuralReferenciada
		$nfeProdRuralReferenciadaModelListJson = $objJson->nfeProdRuralReferenciadaModelList;
		if ($nfeProdRuralReferenciadaModelListJson != null) {
			for ($i = 0; $i < count($nfeProdRuralReferenciadaModelListJson); $i++) {
				$nfeProdRuralReferenciada = new NfeProdRuralReferenciadaModel();
				$nfeProdRuralReferenciada->mapping($nfeProdRuralReferenciadaModelListJson[$i]);
				$objModel->nfeProdRuralReferenciadaModelList()->save($nfeProdRuralReferenciada);
			}
		}

		// nfeNfReferenciada
		$nfeNfReferenciadaModelListJson = $objJson->nfeNfReferenciadaModelList;
		if ($nfeNfReferenciadaModelListJson != null) {
			for ($i = 0; $i < count($nfeNfReferenciadaModelListJson); $i++) {
				$nfeNfReferenciada = new NfeNfReferenciadaModel();
				$nfeNfReferenciada->mapping($nfeNfReferenciadaModelListJson[$i]);
				$objModel->nfeNfReferenciadaModelList()->save($nfeNfReferenciada);
			}
		}

		// nfeProcessoReferenciado
		$nfeProcessoReferenciadoModelListJson = $objJson->nfeProcessoReferenciadoModelList;
		if ($nfeProcessoReferenciadoModelListJson != null) {
			for ($i = 0; $i < count($nfeProcessoReferenciadoModelListJson); $i++) {
				$nfeProcessoReferenciado = new NfeProcessoReferenciadoModel();
				$nfeProcessoReferenciado->mapping($nfeProcessoReferenciadoModelListJson[$i]);
				$objModel->nfeProcessoReferenciadoModelList()->save($nfeProcessoReferenciado);
			}
		}

		// nfeAcessoXml
		$nfeAcessoXmlModelListJson = $objJson->nfeAcessoXmlModelList;
		if ($nfeAcessoXmlModelListJson != null) {
			for ($i = 0; $i < count($nfeAcessoXmlModelListJson); $i++) {
				$nfeAcessoXml = new NfeAcessoXmlModel();
				$nfeAcessoXml->mapping($nfeAcessoXmlModelListJson[$i]);
				$objModel->nfeAcessoXmlModelList()->save($nfeAcessoXml);
			}
		}

		// nfeInformacaoPagamento
		$nfeInformacaoPagamentoModelListJson = $objJson->nfeInformacaoPagamentoModelList;
		if ($nfeInformacaoPagamentoModelListJson != null) {
			for ($i = 0; $i < count($nfeInformacaoPagamentoModelListJson); $i++) {
				$nfeInformacaoPagamento = new NfeInformacaoPagamentoModel();
				$nfeInformacaoPagamento->mapping($nfeInformacaoPagamentoModelListJson[$i]);
				$objModel->nfeInformacaoPagamentoModelList()->save($nfeInformacaoPagamento);
			}
		}

		// nfeCupomFiscalReferenciado
		$nfeCupomFiscalReferenciadoModelListJson = $objJson->nfeCupomFiscalReferenciadoModelList;
		if ($nfeCupomFiscalReferenciadoModelListJson != null) {
			for ($i = 0; $i < count($nfeCupomFiscalReferenciadoModelListJson); $i++) {
				$nfeCupomFiscalReferenciado = new NfeCupomFiscalReferenciadoModel();
				$nfeCupomFiscalReferenciado->mapping($nfeCupomFiscalReferenciadoModelListJson[$i]);
				$objModel->nfeCupomFiscalReferenciadoModelList()->save($nfeCupomFiscalReferenciado);
			}
		}

		// nfeCteReferenciado
		$nfeCteReferenciadoModelListJson = $objJson->nfeCteReferenciadoModelList;
		if ($nfeCteReferenciadoModelListJson != null) {
			for ($i = 0; $i < count($nfeCteReferenciadoModelListJson); $i++) {
				$nfeCteReferenciado = new NfeCteReferenciadoModel();
				$nfeCteReferenciado->mapping($nfeCteReferenciadoModelListJson[$i]);
				$objModel->nfeCteReferenciadoModelList()->save($nfeCteReferenciado);
			}
		}
	}

	public function insertDetalhesAndChildren($objJson, $objModel)
	{
		if (!isset($objJson->nfeDetalheModelList)) {
			return;
		}

		foreach ($objJson->nfeDetalheModelList as $detalheJson) {
			// Detalhe
			$detalhe = new NfeDetalheModel();
			$detalhe->mapping($detalheJson);
			$objModel->nfeDetalheModelList()->save($detalhe);

			// ===================== 1:1 =====================
			$oneToOneMap = [
				'nfeDetEspecificoVeiculoModel' => NfeDetEspecificoVeiculoModel::class,
				'nfeDetEspecificoMedicamentoModel' => NfeDetEspecificoMedicamentoModel::class,
				'nfeDetEspecificoCombustivelModel' => NfeDetEspecificoCombustivelModel::class,
				'nfeDetalheImpostoIcmsModel' => NfeDetalheImpostoIcmsModel::class,
				'nfeDetalheImpostoIpiModel' => NfeDetalheImpostoIpiModel::class,
				'nfeDetalheImpostoIiModel' => NfeDetalheImpostoIiModel::class,
				'nfeDetalheImpostoPisModel' => NfeDetalheImpostoPisModel::class,
				'nfeDetalheImpostoPisStModel' => NfeDetalheImpostoPisStModel::class,
				'nfeDetalheImpostoCofinsModel' => NfeDetalheImpostoCofinsModel::class,
				'nfeDetalheImpostoCofinsStModel' => NfeDetalheImpostoCofinsStModel::class,
				'nfeDetalheImpostoIssqnModel' => NfeDetalheImpostoIssqnModel::class,
				'nfeDetalheImpostoIcmsUfdestModel' => NfeDetalheImpostoIcmsUfdestModel::class,
			];

			foreach ($oneToOneMap as $key => $modelClass) {
				if (isset($detalheJson->$key)) {
					$child = new $modelClass();
					$child->mapping($detalheJson->$key);
					$detalhe->$key()->save($child);
				}
			}

			// ===================== 1:N =====================
			if (isset($detalheJson->nfeDetEspecificoArmamentoModelList)) {
				foreach ($detalheJson->nfeDetEspecificoArmamentoModelList as $itemJson) {
					$item = new NfeDetEspecificoArmamentoModel();
					$item->mapping($itemJson);
					$detalhe->nfeDetEspecificoArmamentoModelList()->save($item);
				}
			}

			if (isset($detalheJson->nfeExportacaoModelList)) {
				foreach ($detalheJson->nfeExportacaoModelList as $itemJson) {
					$item = new NfeExportacaoModel();
					$item->mapping($itemJson);
					$detalhe->nfeExportacaoModelList()->save($item);
				}
			}

			if (isset($detalheJson->nfeItemRastreadoModelList)) {
				foreach ($detalheJson->nfeItemRastreadoModelList as $itemJson) {
					$item = new NfeItemRastreadoModel();
					$item->mapping($itemJson);
					$detalhe->nfeItemRastreadoModelList()->save($item);
				}
			}

			// ===================== Declaracao de Importacao (1:N + neto) =====================
			if (isset($detalheJson->nfeDeclaracaoImportacaoModelList)) {
				foreach ($detalheJson->nfeDeclaracaoImportacaoModelList as $importacaoJson) {
					$importacao = new NfeDeclaracaoImportacaoModel();
					$importacao->mapping($importacaoJson);
					$detalhe->nfeDeclaracaoImportacaoModelList()->save($importacao);

					if (isset($importacaoJson->nfeImportacaoDetalheModelList)) {
						foreach ($importacaoJson->nfeImportacaoDetalheModelList as $detalheImpJson) {
							$impDet = new NfeImportacaoDetalheModel();
							$impDet->mapping($detalheImpJson);
							$importacao->nfeImportacaoDetalheModelList()->save($impDet);
						}
					}
				}
			}
		}
	}

	public function deleteChildren($object)
	{
		$idCabecalho = $object->getIdAttribute();

		// Deleções diretas
		$modelsCabecalho = [
			NfeReferenciadaModel::class,
			NfeEmitenteModel::class,
			NfeDestinatarioModel::class,
			NfeLocalRetiradaModel::class,
			NfeLocalEntregaModel::class,
			NfeProdRuralReferenciadaModel::class,
			NfeNfReferenciadaModel::class,
			NfeProcessoReferenciadoModel::class,
			NfeAcessoXmlModel::class,
			NfeInformacaoPagamentoModel::class,
			NfeResponsavelTecnicoModel::class,
			NfeCteReferenciadoModel::class,
			NfeCupomFiscalReferenciadoModel::class
		];

		foreach ($modelsCabecalho as $model) {
			$model::where('id_nfe_cabecalho', $idCabecalho)->delete();
		}

		// Transporte
		if ($object->nfeTransporteModel) {
			$idTransporte = $object->nfeTransporteModel->getIdAttribute();

			$volumes = NfeTransporteVolumeModel::where('id_nfe_transporte', $idTransporte)->get();
			foreach ($volumes as $volume) {
				NfeTransporteVolumeLacreModel::where('id_nfe_transporte_volume', $volume->id)->delete();
			}

			NfeTransporteVolumeModel::where('id_nfe_transporte', $idTransporte)->delete();
			NfeTransporteReboqueModel::where('id_nfe_transporte', $idTransporte)->delete();
			NfeTransporteModel::where('id_nfe_cabecalho', $idCabecalho)->delete();
		}

		// Fatura
		if ($object->nfeFaturaModel) {
			$idFatura = $object->nfeFaturaModel->getIdAttribute();

			NfeDuplicataModel::where('id_nfe_fatura', $idFatura)->delete();
			NfeFaturaModel::where('id_nfe_cabecalho', $idCabecalho)->delete();
		}

		// Cana
		if ($object->nfeCanaModel) {
			$idCana = $object->nfeCanaModel->getIdAttribute();

			NfeCanaFornecimentoDiarioModel::where('id_nfe_cana', $idCana)->delete();
			NfeCanaDeducoesSafraModel::where('id_nfe_cana', $idCana)->delete();
			NfeCanaModel::where('id_nfe_cabecalho', $idCabecalho)->delete();
		}

		// Itens
		$this->deleteDetalhesAndChildren($idCabecalho);
	}

	public function deleteDetalhesAndChildren($idNfeCabecalho)
	{
		$detalhes = NfeDetalheModel::where('id_nfe_cabecalho', $idNfeCabecalho)->get();

		foreach ($detalhes as $detalhe) {
			$idDetalhe = $detalhe->id;

			// Filhos 1:1
			NfeDetEspecificoVeiculoModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetEspecificoMedicamentoModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetEspecificoCombustivelModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoIcmsModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoIpiModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoIiModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoPisModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoPisStModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoCofinsModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoCofinsStModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoIssqnModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeDetalheImpostoIcmsUfdestModel::where('id_nfe_detalhe', $idDetalhe)->delete();

			// Armamento, Exportação, Rastreamento
			NfeDetEspecificoArmamentoModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeExportacaoModel::where('id_nfe_detalhe', $idDetalhe)->delete();
			NfeItemRastreadoModel::where('id_nfe_detalhe', $idDetalhe)->delete();

			// Declaracao de Importacao e seus filhos
			$declaracoes = NfeDeclaracaoImportacaoModel::where('id_nfe_detalhe', $idDetalhe)->get();
			foreach ($declaracoes as $declaracao) {
				NfeImportacaoDetalheModel::where('id_nfe_declaracao_importacao', $declaracao->id)->delete();
				$declaracao->delete();
			}

			// Por fim, o próprio detalhe
			$detalhe->delete();
		}
	}

	/*
	* Métodos para geração e transmissão da NF-e
	*/

	public function calcularTotais($pNfeCabecalho)
	{
		// inicia variáveis
		$totalProdutos = 0;
		$valorFrete = 0;
		$valorSeguro = 0;
		$valorOutrasDespesas = 0;
		$desconto = 0;
		$baseCalculoIcms = 0;
		$valorIcms = 0;
		$baseCalculoIcmsSt = 0;
		$valorIcmsSt = 0;
		$valorIpi = 0;
		$valorPis = 0;
		$valorCofins = 0;
		// 
		$totalServicos = 0;
		$baseCalculoIssqn = 0;
		$valorIssqn = 0;
		$valorPisIssqn = 0;
		$valorCofinsIssqn = 0;

		//  Pega a empresa
		// $gerenteConexao = GerenteConexao::instance;
		$empresa = EmpresaModel::where('cnpj', CNPJ_CONNECTION)->first();

		//  Se houver CFOP cadastrado na Operação Fiscal, a nota é de serviços
		if ($pNfeCabecalho->tributOperacaoFiscal->cfop > 0) {
			for ($i = 0; $i < count($pNfeCabecalho->listaNfeDetalhe); $i++) {
				$nfeDetalhe = $pNfeCabecalho->listaNfeDetalhe[$i];

				$totalServicos += $nfeDetalhe->valorTotal;
				$valorFrete += $nfeDetalhe->valorFrete;
				$valorSeguro += $nfeDetalhe->valorSeguro;
				$valorOutrasDespesas += $nfeDetalhe->valorOutrasDespesas;
				$desconto += $nfeDetalhe->valorDesconto;
				$baseCalculoIssqn += $nfeDetalhe->nfeDetalheImpostoIssqn->baseCalculoIssqn;
				$valorIssqn += $nfeDetalhe->nfeDetalheImpostoIssqn->valorIssqn;
				$valorPisIssqn += $nfeDetalhe->nfeDetalheImpostoPis->valorPis;
				$valorCofinsIssqn = $valorCofinsIssqn + $valorPisIssqn + $nfeDetalhe->nfeDetalheImpostoCofins->valorCofins;
			}
			// 
			$valorNotaFiscal = $totalServicos + $valorPis + $valorCofins + $valorOutrasDespesas - $desconto;
			$pNfeCabecalho->valorServicos = $totalServicos;
		} else {
			$calculoNFe = new CalculoNFe;
			if ($empresa->crt != "")
				$calculoNFe->crtEmissor = $empresa->crt;
			$calculoNFe->ufEmissor = $empresa->codigoIbgeUf;
			if ($pNfeCabecalho->nfeDestinatario->cnpj != "")
				$calculoNFe->tipoCliente = "J";
			else
				$calculoNFe->tipoCliente = "F";
			$calculoNFe->ufCliente = $pNfeCabecalho->nfeDestinatario->uf;

			for ($i = 0; $i < count($pNfeCabecalho->listaNfeDetalhe); $i++) {
				$nfeDetalhe = $pNfeCabecalho->listaNfeDetalhe[$i];

				NfeCabecalhoService::processarCalculosNoItem($calculoNFe, $nfeDetalhe);

				$totalProdutos += $nfeDetalhe->valorTotal;
				$valorFrete += $nfeDetalhe->valorFrete;
				$valorSeguro += $nfeDetalhe->valorSeguro;
				$valorOutrasDespesas += $nfeDetalhe->valorOutrasDespesas;
				$desconto += $nfeDetalhe->valorDesconto;
				$baseCalculoIcms += $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms;
				$valorIcms += $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms;
				$baseCalculoIcmsSt += $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt;
				$valorIcmsSt += $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt;
				$valorIpi += $nfeDetalhe->nfeDetalheImpostoIpi->valorIpi;
				$valorPis += $nfeDetalhe->nfeDetalheImpostoPis->valorPis;
				$valorCofins += $nfeDetalhe->nfeDetalheImpostoCofins->valorCofins;
			}
			// 
			$valorNotaFiscal = $totalProdutos + $valorIcmsSt + $valorPis + $valorCofins + $valorIpi + $valorOutrasDespesas - $desconto;
		}

		$pNfeCabecalho->valorTotalProdutos = $totalProdutos;
		$pNfeCabecalho->valorFrete = $valorFrete;
		$pNfeCabecalho->valorSeguro = $valorSeguro;
		$pNfeCabecalho->valorDespesasAcessorias = $valorOutrasDespesas;
		$pNfeCabecalho->valorDesconto = $desconto;
		$pNfeCabecalho->baseCalculoIcms = $baseCalculoIcms;
		$pNfeCabecalho->valorIcms = $valorIcms;
		$pNfeCabecalho->baseCalculoIcmsSt = $baseCalculoIcmsSt;
		$pNfeCabecalho->valorIcmsSt = $valorIcmsSt;
		$pNfeCabecalho->valorIpi = $valorIpi;
		$pNfeCabecalho->valorPis = $valorPis;
		$pNfeCabecalho->valorCofins = $valorCofins;
		// 
		$pNfeCabecalho->baseCalculoIssqn = $baseCalculoIssqn;
		$pNfeCabecalho->valorIssqn = $valorIssqn;
		$pNfeCabecalho->valorPisIssqn = $valorPisIssqn;
		$pNfeCabecalho->valorCofinsIssqn = $valorCofinsIssqn;
		// 
		$pNfeCabecalho->valorTotal = $valorNotaFiscal;
	}

	public function processarCalculosNoItem(CalculoNFe $pCalculoNFe, $pNfeDetalhe)
	{
		$pCalculoNFe->valorBrutoProdutos = $pNfeDetalhe->valorBrutoProduto;
		$pCalculoNFe->valorFrete = $pNfeDetalhe->valorFrete;
		$pCalculoNFe->valorSeguro = $pNfeDetalhe->valorSeguro;
		$pCalculoNFe->valorOutrasDespesas = $pNfeDetalhe->valorOutrasDespesas;
		$pCalculoNFe->valorDesconto = $pNfeDetalhe->valorDesconto;
		$pCalculoNFe->cstIcms = $pNfeDetalhe->nfeDetalheImpostoIcms->cstIcms;
		$pCalculoNFe->csosn = $pNfeDetalhe->nfeDetalheImpostoIcms->csosn;
		$pCalculoNFe->modalidadeBcIcms = $pNfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms;
		$pCalculoNFe->taxaReducaoBcIcms = $pNfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcms;
		$pCalculoNFe->aliquotaIcms = $pNfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms;
		$pCalculoNFe->aliquotaIcmsInter = $pNfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms;
		$pCalculoNFe->modalidadeBcIcmsSt = $pNfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt;
		$pCalculoNFe->percentualMvaIcmsSt = $pNfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt;
		$pCalculoNFe->reducaoBcIcmsSt = $pNfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt;
		$pCalculoNFe->aliquotaIcmsSt = $pNfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt;
		$pCalculoNFe->aliquotaCreditoIcmsSn = $pNfeDetalhe->nfeDetalheImpostoIcms->aliquotaCreditoIcmsSn;
		$pCalculoNFe->cstIpi = $pNfeDetalhe->nfeDetalheImpostoIpi->cstIpi;
		$pCalculoNFe->aliquotaIpi = $pNfeDetalhe->nfeDetalheImpostoIpi->aliquotaIpi;
		$pCalculoNFe->cstPis = $pNfeDetalhe->nfeDetalheImpostoPis->cstPis;
		$pCalculoNFe->aliquotaPis = $pNfeDetalhe->nfeDetalheImpostoPis->aliquotaPisPercentual;
		$pCalculoNFe->aliquotaPisReais = $pNfeDetalhe->nfeDetalheImpostoPis->aliquotaPisReais;
		$pCalculoNFe->cstCofins = $pNfeDetalhe->nfeDetalheImpostoCofins->cstCofins;
		$pCalculoNFe->aliquotaCofins = $pNfeDetalhe->nfeDetalheImpostoCofins->aliquotaCofinsPercentual;
		$pCalculoNFe->aliquotaCofinsReais = $pNfeDetalhe->nfeDetalheImpostoCofins->aliquotaCofinsReais;

		NfeCalculoService::calcular($pCalculoNFe);

		//  Valores ICMS 
		$pNfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms = $pCalculoNFe->baseCalculoIcms;
		$pNfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt = $pCalculoNFe->reducaoBcIcmsSt;
		$pNfeDetalhe->nfeDetalheImpostoIcms->valorIcms = $pCalculoNFe->valorIcms;
		//  valores de ICMS ST
		$pNfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt = $pCalculoNFe->baseCalculoIcmsSt;
		$pNfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt = $pCalculoNFe->valorIcmsSt;
		//  credito de icmssn
		$pNfeDetalhe->nfeDetalheImpostoIcms->valorCreditoIcmsSn = $pCalculoNFe->valorCreditoIcmsSn;

		//  Valores IPI 
		$pNfeDetalhe->nfeDetalheImpostoIpi->valorBaseCalculoIpi = $pCalculoNFe->baseCalculoIpi;
		$pNfeDetalhe->nfeDetalheImpostoIpi->valorIpi = $pCalculoNFe->valorIpi;

		//  Valores PIS 
		$pNfeDetalhe->nfeDetalheImpostoPis->valorBaseCalculoPis = $pCalculoNFe->baseCalculoPis;
		$pNfeDetalhe->nfeDetalheImpostoPis->valorPis = $pCalculoNFe->valorPis;

		//  Valores COFINS 
		$pNfeDetalhe->nfeDetalheImpostoCofins->baseCalculoCofins = $pCalculoNFe->baseCalculoCofins;
		$pNfeDetalhe->nfeDetalheImpostoCofins->valorCofins = $pCalculoNFe->valorCofins;
	}

	public function TransmitirNfe(NfeCabecalhoModel $pNfeCabecalho)
	{
		//  primeiro passo - gerar o arquivo INI com a NF-e
		$caminhoArquivoIni = $this->gerarArquivoIniNFe($pNfeCabecalho);

		// chama o método para criar a nota
		$this->criarNFe($caminhoArquivoIni);
		// pega o caminho do XML criado
		$caminhoArquivoXml = $this->pegarRetornoSaida("ARQUIVO-XML");
		if (str_contains($caminhoArquivoXml, "ERRO")) {
			return $caminhoArquivoXml;
		}

		// chama o método para criar e enviar a nota
		$this->enviarNFe($caminhoArquivoXml);
		$retorno = $this->pegarRetornoSaida("Envio");
		if (!str_contains($retorno, "ERRO")) {
			// chama o método para gerar o PDF
			$this->imprimirDanfe($caminhoArquivoXml);
			// captura o retorno do arquivo SAI
			$retorno = $this->pegarRetornoSaida("ARQUIVO-PDF");

			// se chegou aqui, atualiza a chave de acesso e o status da nota
			$pNfeCabecalho->statusNota = "4";
			$chave = strrev($retorno);
			$chave = substr($chave, strrpos($chave, "-") + 1, 44);
			$chave = strrev($chave);
			$pNfeCabecalho->chaveAcesso = $chave;
			$pNfeCabecalho->digitoChaveAcesso = substr($chave, -1);

			DB::transaction(function () use ($pNfeCabecalho) {
				$pNfeCabecalho->save();
			});
		}
		return $retorno;
	}

	public function criarNFe($caminhoArquivoIniNfce)
	{
		$this->apagarArquivoSaida();
		$this->gerarArquivoEntrada("NFE.CriarNFe(" . $caminhoArquivoIniNfce . ")");
		$this->aguardarArquivoSaida();
	}

	public function enviarNFe($caminhoArquivoXml)
	{
		$this->apagarArquivoSaida();
		$this->gerarArquivoEntrada("NFE.EnviarNFe(" . $caminhoArquivoXml . ", 001, , , , 1, , )");
		$this->aguardarArquivoSaida();
	}

	public function imprimirDanfe($caminhoArquivoXml)
	{
		$this->apagarArquivoSaida();
		$this->gerarArquivoEntrada("NFE.ImprimirDANFEPDF(" . $caminhoArquivoXml . ", , , 1,)");
		$this->aguardarArquivoSaida();
	}

	public function gerarPdfDanfe($chave)
	{
		// pega o caminho do arquivo XML da nota em contingência
		$caminhoArquivoXml = CAMINHO_COM_CNPJ . "LOG_NFe\\" . $chave . "-nfe.xml";
		// chama o método para gerar o PDF
		$this->imprimirDanfe($caminhoArquivoXml);
		// captura o retorno do arquivo SAI
		return $this->pegarRetornoSaida("ARQUIVO-PDF");
	}

	public function gerarArquivoIniNFe(NfeCabecalhoModel $pNfeCabecalho)
	{
		$nomeArquivoIni = "c:\\t2ti\\nfe\\ini\\" . $pNfeCabecalho->numero . ".ini";
		// cria o arquivo
		$arquivo = fopen($nomeArquivoIni, "w");
		fclose($arquivo);

		// carrega o arquivo ini num array
		$NFeIni = parse_ini_file($nomeArquivoIni, true);

		//  Pega a empresa
		$empresa = EmpresaModel::where('cnpj', CNPJ_CONNECTION)->first();
		$empresa->enderecoPrincipal = $empresa->listaEmpresaEndereco[0];

		// *******************************************************************************************
		//   [infNFe]
		// *******************************************************************************************
		Util::iniWriteString("infNFe", "versao", "4.00", $NFeIni);

		// *******************************************************************************************
		//   [Identificacao]
		// *******************************************************************************************
		Util::iniWriteString("Identificacao", "cNF", $pNfeCabecalho->codigoNumerico, $NFeIni);
		Util::iniWriteString("Identificacao", "natOp", $pNfeCabecalho->naturezaOperacao, $NFeIni);
		Util::iniWriteString("Identificacao", "mod", "55", $NFeIni);
		Util::iniWriteString("Identificacao", "serie", $pNfeCabecalho->serie, $NFeIni);
		Util::iniWriteString("Identificacao", "nNF", $pNfeCabecalho->numero, $NFeIni);
		Util::iniWriteString("Identificacao", "dhEmi", date("d-m-Y H:i:s", strtotime($pNfeCabecalho->dataHoraEmissao)), $NFeIni);
		Util::iniWriteString("Identificacao", "dhSaiEnt", "", $NFeIni);
		Util::iniWriteString("Identificacao", "tpNF", $pNfeCabecalho->tipoOperacao, $NFeIni);    // 0=Entrada; 1=Saída
		Util::iniWriteString("Identificacao", "idDest", $pNfeCabecalho->localDestino, $NFeIni);  //  1=Operação interna; 2=Operação interestadual; 3=Operação com exterior->get
		Util::iniWriteString("Identificacao", "tpImp", $pNfeCabecalho->formatoImpressaoDanfe, $NFeIni);
		Util::iniWriteString("Identificacao", "tpEmis", $pNfeCabecalho->tipoEmissao, $NFeIni);
		Util::iniWriteString("Identificacao", "finNFe", $pNfeCabecalho->finalidadeEmissao, $NFeIni);
		Util::iniWriteString("Identificacao", "indFinal", $pNfeCabecalho->consumidorOperacao, $NFeIni); // 0=Normal; 1=Consumidor final;
		Util::iniWriteString("Identificacao", "indPres", $pNfeCabecalho->consumidorPresenca, $NFeIni);
		Util::iniWriteString("Identificacao", "procEmi", $pNfeCabecalho->processoEmissao, $NFeIni);
		Util::iniWriteString("Identificacao", "verProc", $pNfeCabecalho->versaoProcessoEmissao, $NFeIni);
		Util::iniWriteString("Identificacao", "dhCont", "", $NFeIni);
		Util::iniWriteString("Identificacao", "xJust", "", $NFeIni);
		Util::iniWriteString("Identificacao", "tpAmb", "2", $NFeIni); //  altera para '1' quando em produção ou trazer de tabela ADM

		// *******************************************************************************************
		//   [Emitente]
		// *******************************************************************************************
		Util::iniWriteString("Emitente", "CNPJCPF", $empresa->cnpj, $NFeIni);
		Util::iniWriteString("Emitente", "xNome", $empresa->razaoSocial, $NFeIni);
		Util::iniWriteString("Emitente", "xFant", $empresa->nomeFantasia, $NFeIni);
		Util::iniWriteString("Emitente", "IE", $empresa->inscricaoEstadual, $NFeIni);
		Util::iniWriteString("Emitente", "IEST", "", $NFeIni);
		Util::iniWriteString("Emitente", "IM", $empresa->inscricaoMunicipal, $NFeIni);
		Util::iniWriteString("Emitente", "CNAE", $empresa->codigoCnaePrincipal, $NFeIni);
		Util::iniWriteString("Emitente", "CRT", $empresa->crt, $NFeIni);
		Util::iniWriteString("Emitente", "xLgr", $empresa->enderecoPrincipal->logradouro, $NFeIni);
		Util::iniWriteString("Emitente", "nro", $empresa->enderecoPrincipal->numero, $NFeIni);
		Util::iniWriteString("Emitente", "xCpl", $empresa->enderecoPrincipal->complemento, $NFeIni);
		Util::iniWriteString("Emitente", "xBairro", $empresa->enderecoPrincipal->bairro, $NFeIni);
		Util::iniWriteString("Emitente", "cMun", $empresa->codigoIbgeCidade, $NFeIni);
		Util::iniWriteString("Emitente", "xMun", $empresa->enderecoPrincipal->cidade, $NFeIni);
		Util::iniWriteString("Emitente", "UF", $empresa->enderecoPrincipal->uf, $NFeIni);
		Util::iniWriteString("Emitente", "CEP", $empresa->enderecoPrincipal->cep, $NFeIni);
		Util::iniWriteString("Emitente", "cPais", "1058", $NFeIni);
		Util::iniWriteString("Emitente", "xPais", "BRASIL", $NFeIni);
		Util::iniWriteString("Emitente", "Fone", "", $NFeIni);
		Util::iniWriteString("Emitente", "cUF", $empresa->codigoIbgeUf, $NFeIni);
		Util::iniWriteString("Emitente", "cMunFG", "", $NFeIni);

		// *******************************************************************************************
		//   [Destinatario]
		// *******************************************************************************************
		if ($pNfeCabecalho->nfeDestinatario->cnpj != "")
			Util::iniWriteString("Destinatario", "CNPJCPF", $pNfeCabecalho->nfeDestinatario->cnpj, $NFeIni);
		else
			Util::iniWriteString("Destinatario", "CNPJCPF", $pNfeCabecalho->nfeDestinatario->cpf, $NFeIni);
		Util::iniWriteString("Destinatario", "xNome", $pNfeCabecalho->nfeDestinatario->nome, $NFeIni);
		Util::iniWriteString("Destinatario", "indIEDest", $pNfeCabecalho->nfeDestinatario->indicadorIe, $NFeIni);
		Util::iniWriteString("Destinatario", "IE", $pNfeCabecalho->nfeDestinatario->inscricaoEstadual, $NFeIni);
		Util::iniWriteString("Destinatario", "email", $pNfeCabecalho->nfeDestinatario->email, $NFeIni);
		Util::iniWriteString("Destinatario", "xLgr", $pNfeCabecalho->nfeDestinatario->logradouro, $NFeIni);
		Util::iniWriteString("Destinatario", "nro", $pNfeCabecalho->nfeDestinatario->numero, $NFeIni);
		Util::iniWriteString("Destinatario", "xCpl", $pNfeCabecalho->nfeDestinatario->complemento, $NFeIni);
		Util::iniWriteString("Destinatario", "xBairro", $pNfeCabecalho->nfeDestinatario->bairro, $NFeIni);
		Util::iniWriteString("Destinatario", "cMun", $pNfeCabecalho->nfeDestinatario->codigoMunicipio, $NFeIni);
		Util::iniWriteString("Destinatario", "xMun", $pNfeCabecalho->nfeDestinatario->nomeMunicipio, $NFeIni);
		Util::iniWriteString("Destinatario", "UF", $pNfeCabecalho->nfeDestinatario->uf, $NFeIni);
		Util::iniWriteString("Destinatario", "CEP", $pNfeCabecalho->nfeDestinatario->cep, $NFeIni);
		Util::iniWriteString("Destinatario", "cPais", $pNfeCabecalho->nfeDestinatario->codigoPais, $NFeIni);
		Util::iniWriteString("Destinatario", "xPais", $pNfeCabecalho->nfeDestinatario->nomePais, $NFeIni);
		Util::iniWriteString("Destinatario", "Fone", "", $NFeIni);

		// *******************************************************************************************
		//   Detalhes - Produtos e Impostos
		// *******************************************************************************************
		for ($i = 0; $i < count($pNfeCabecalho->listaNfeDetalhe); $i++) {
			$nfeDetalhe = $pNfeCabecalho->listaNfeDetalhe[$i];

			$tamanhoI = strlen(strval($i));
			$incrementoBloco = str_repeat("0", 3 - $tamanhoI) . strval($i + 1);

			// / [Produto]
			Util::iniWriteString("Produto" . $incrementoBloco, "cProd", $nfeDetalhe->gtin, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "cEAN", $nfeDetalhe->gtin, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "xProd", $nfeDetalhe->nomeProduto, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "ncm", $nfeDetalhe->ncm, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "CEST", $nfeDetalhe->cest, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "EXTIPI", "", $NFeIni); // $nfeDetalhe->extipi, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "CFOP", $nfeDetalhe->cfop, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "uCom", $nfeDetalhe->unidadeComercial, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "qCom", $nfeDetalhe->quantidadeComercial, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vUnCom", $nfeDetalhe->valorUnitarioComercial, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vProd", $nfeDetalhe->valorTotal, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "cEANTrib", $nfeDetalhe->gtinUnidadeTributavel, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "uTrib", $nfeDetalhe->unidadeTributavel, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "qTrib", $nfeDetalhe->quantidadeTributavel, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vUnTrib", $nfeDetalhe->valorUnitarioTributavel, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vFrete", $nfeDetalhe->valorFrete, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vSeg", $nfeDetalhe->valorSeguro, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vDesc", $nfeDetalhe->valorDesconto, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vOutro", $nfeDetalhe->valorOutrasDespesas, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "indTot", $nfeDetalhe->entraTotal, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "xPed", $pNfeCabecalho->compraPedido, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "nItemPed", $nfeDetalhe->itemPedidoCompra, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "nFCI", $nfeDetalhe->numeroFci, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "nRECOPI", $nfeDetalhe->numeroRecopi, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "pDevol", $nfeDetalhe->percentualDevolvido, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vIPIDevol", $nfeDetalhe->valorIpiDevolvido, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "vTotTrib", $nfeDetalhe->valorTotalTributos, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "infAdProd", $nfeDetalhe->informacoesAdicionais, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "indEscala", $nfeDetalhe->indicadorEscalaRelevante, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "CNPJFab", $nfeDetalhe->cnpjFabricante, $NFeIni);
			Util::iniWriteString("Produto" . $incrementoBloco, "cBenef", $nfeDetalhe->codigoBeneficioFiscal, $NFeIni);

			//  Detalhes -- Impostos 
			//  Se houver CFOP cadastrado na Operação Fiscal, a nota é de serviços
			if ($pNfeCabecalho->tributOperacaoFiscal->cfop > 0) {
				// / [ISSQN]
				Util::iniWriteString("ISSQN" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIssqn->baseCalculoIssqn, $NFeIni);
				Util::iniWriteString("ISSQN" . $incrementoBloco, "vAliq", $nfeDetalhe->nfeDetalheImpostoIssqn->aliquotaIssqn, $NFeIni);
				Util::iniWriteString("ISSQN" . $incrementoBloco, "vISSQN", $nfeDetalhe->nfeDetalheImpostoIssqn->valorIssqn, $NFeIni);
				Util::iniWriteString("ISSQN" . $incrementoBloco, "cMunFG", $nfeDetalhe->nfeDetalheImpostoIssqn->municipioIssqn, $NFeIni);
				Util::iniWriteString("ISSQN" . $incrementoBloco, "cListServ", $nfeDetalhe->nfeDetalheImpostoIssqn->itemListaServicos, $NFeIni);
			} else {
				// / [ICMS]
				if ($empresa->crt == "1")  // 1-Simples Nacional
				{
					Util::iniWriteString("ICMS" . $incrementoBloco, "CSOSN", $nfeDetalhe->nfeDetalheImpostoIcms->csosn, $NFeIni);

					//  csosn 101
					if ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "101") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pCredSN", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaCreditoIcmsSn, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vCredICMSSN", $nfeDetalhe->nfeDetalheImpostoIcms->valorCreditoIcmsSn, $NFeIni);
					}

					//  csosn 102, 103, 300, 400
					else if (($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "102")
						|| ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "103")
						|| ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "300")
						|| ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "400")
					) {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
					}

					//  csosn 201
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "201") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBCST", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pMVAST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBCST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCST", $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pCredSN", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaCreditoIcmsSn, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vCredICMSSN", $nfeDetalhe->nfeDetalheImpostoIcms->valorCreditoIcmsSn, $NFeIni);
					}

					//  csosn 202, 203
					else if (($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "202")
						|| ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "203")
					) {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBCST", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pMVAST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBCST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCST", $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt, $NFeIni);
					}

					//  csosn 500
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "500") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCSTRet", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcmsStRetido, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSSTRet", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsStRetido, $NFeIni);
					}

					//  csosn 900
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->csosn == "900") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBC", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBC", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMS", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBCST", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pMVAST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBCST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCST", $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pCredSN", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaCreditoIcmsSn, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vCredICMSSN", $nfeDetalhe->nfeDetalheImpostoIcms->valorCreditoIcmsSn, $NFeIni);
					}
				} else {
					Util::iniWriteString("ICMS" . $incrementoBloco, "CST", $nfeDetalhe->nfeDetalheImpostoIcms->cstIcms, $NFeIni);

					//  00 Tributada integralmente
					if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "00") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBC", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMS", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
					}

					//  10 Tributada e com cobranca do ICMS por ST
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "10") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBC", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMS", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBCST", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pMVAST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBCST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCST", $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt, $NFeIni);
					}

					//  20 Tributada com reducao de base de calculo
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "20") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBC", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBC", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMS", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
					}

					//  30 Isenta ou nao tributada e com cobranca do ICMS por ST
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "30") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBCST", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pMVAST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBCST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCST", $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt, $NFeIni);
					}

					//  40 Isenta
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "40") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "motDesICMS", $nfeDetalhe->nfeDetalheImpostoIcms->motivoDesoneracaoIcms, $NFeIni);
					}

					//  41 Nao tributada
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "41") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "motDesICMS", $nfeDetalhe->nfeDetalheImpostoIcms->motivoDesoneracaoIcms, $NFeIni);
					}

					//  50 Suspencao
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "50") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "motDesICMS", $nfeDetalhe->nfeDetalheImpostoIcms->motivoDesoneracaoIcms, $NFeIni);
					}

					//  51 Diferimento preenchimento do ICMS depende da UF
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "51") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBC", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBC", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMS", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
					}

					//  60 ICMS cobrado anteriormente por ST
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "60") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCSTRet", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcmsStRetido, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSSTRet", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsStRetido, $NFeIni);
					}

					//  70 ICMS com reducao de base de calculo e cobranca de ICMS por ST
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "70") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBC", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBC", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMS", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBCST", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pMVAST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBCST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCST", $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt, $NFeIni);
					}

					//  90 Outros
					else if ($nfeDetalhe->nfeDetalheImpostoIcms->cstIcms == "90") {
						Util::iniWriteString("ICMS" . $incrementoBloco, "orig", $nfeDetalhe->nfeDetalheImpostoIcms->origemMercadoria, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBC", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIcms->valorBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBC", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMS", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMS", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcms, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "modBCST", $nfeDetalhe->nfeDetalheImpostoIcms->modalidadeBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pMVAST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualMvaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pRedBCST", $nfeDetalhe->nfeDetalheImpostoIcms->percentualReducaoBcIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vBCST", $nfeDetalhe->nfeDetalheImpostoIcms->valorBaseCalculoIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "pICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->aliquotaIcmsSt, $NFeIni);
						Util::iniWriteString("ICMS" . $incrementoBloco, "vICMSST", $nfeDetalhe->nfeDetalheImpostoIcms->valorIcmsSt, $NFeIni);
					}
					/*
						Cabe a cada participante implementar o seguinte:
						ICMSPart partilha do ICMS entre a UF de Origem e UF de Destino->get->get
						ICMSST Repasse de ICMS ST retido anteriormente em ope->get interestadual->get->get->get
					*/
				}

				// / [IPI]
				Util::iniWriteString("IPI" . $incrementoBloco, "CST", $nfeDetalhe->nfeDetalheImpostoIpi->cstIpi, $NFeIni);
				Util::iniWriteString("IPI" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIpi->valorBaseCalculoIpi, $NFeIni);
				Util::iniWriteString("IPI" . $incrementoBloco, "pIPI", $nfeDetalhe->nfeDetalheImpostoIpi->aliquotaIpi, $NFeIni);
				Util::iniWriteString("IPI" . $incrementoBloco, "vIPI", $nfeDetalhe->nfeDetalheImpostoIpi->valorIpi, $NFeIni);

				// / [PIS]
				Util::iniWriteString("PIS" . $incrementoBloco, "CST", $nfeDetalhe->nfeDetalheImpostoPis->cstPis, $NFeIni);
				Util::iniWriteString("PIS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoPis->valorBaseCalculoPis, $NFeIni);
				if ($nfeDetalhe->nfeDetalheImpostoPis->cstPis == "01")
					Util::iniWriteString("PIS" . $incrementoBloco, "pPIS", $nfeDetalhe->nfeDetalheImpostoPis->aliquotaPisPercentual, $NFeIni);
				else if ($nfeDetalhe->nfeDetalheImpostoPis->cstPis == "02")
					Util::iniWriteString("PIS" . $incrementoBloco, "pPIS", $nfeDetalhe->nfeDetalheImpostoPis->aliquotaPisReais, $NFeIni);
				Util::iniWriteString("PIS" . $incrementoBloco, "vPIS", $nfeDetalhe->nfeDetalheImpostoPis->valorPis, $NFeIni);

				// / [COFINS]
				Util::iniWriteString("COFINS" . $incrementoBloco, "CST", $nfeDetalhe->nfeDetalheImpostoCofins->cstCofins, $NFeIni);
				Util::iniWriteString("COFINS" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoCofins->baseCalculoCofins, $NFeIni);
				if ($nfeDetalhe->nfeDetalheImpostoCofins->cstCofins == "01")
					Util::iniWriteString("COFINS" . $incrementoBloco, "pCOFINS", $nfeDetalhe->nfeDetalheImpostoCofins->aliquotaCofinsPercentual, $NFeIni);
				else if ($nfeDetalhe->nfeDetalheImpostoCofins->cstCofins == "02")
					Util::iniWriteString("COFINS" . $incrementoBloco, "pCOFINS", $nfeDetalhe->nfeDetalheImpostoCofins->aliquotaCofinsReais, $NFeIni);
				Util::iniWriteString("COFINS" . $incrementoBloco, "vCOFINS", $nfeDetalhe->nfeDetalheImpostoCofins->valorCofins, $NFeIni);

				// / [II]
				//if (!$nfeDetalhe->nfeDetalheImpostoIi->equals(null))
				//{
				//	Util::iniWriteString("II" . $incrementoBloco, "vBC", $nfeDetalhe->nfeDetalheImpostoIi->valorBcIi, $NFeIni);
				//	Util::iniWriteString("II" . $incrementoBloco, "vDespAdu", $nfeDetalhe->nfeDetalheImpostoIi->valorDespesasAduaneiras, $NFeIni);
				//	Util::iniWriteString("II" . $incrementoBloco, "vII", $nfeDetalhe->nfeDetalheImpostoIi->valorImpostoImportacao, $NFeIni);
				//	Util::iniWriteString("II" . $incrementoBloco, "vIOF", $nfeDetalhe->nfeDetalheImpostoIi->valorIof, $NFeIni);
				//}

			}
		}

		// *******************************************************************************************
		//   [Total]
		// *******************************************************************************************
		Util::iniWriteString("Total", "vNF", $pNfeCabecalho->valorTotal, $NFeIni);
		Util::iniWriteString("Total", "vBC", $pNfeCabecalho->baseCalculoIcms, $NFeIni);
		Util::iniWriteString("Total", "vICMS", $pNfeCabecalho->valorIcms, $NFeIni);
		Util::iniWriteString("Total", "vBCST", $pNfeCabecalho->baseCalculoIcmsSt, $NFeIni);
		Util::iniWriteString("Total", "vST", $pNfeCabecalho->valorIcmsSt, $NFeIni);
		Util::iniWriteString("Total", "vProd", $pNfeCabecalho->valorTotalProdutos, $NFeIni);
		Util::iniWriteString("Total", "vFrete", $pNfeCabecalho->valorFrete, $NFeIni);
		Util::iniWriteString("Total", "vSeg", $pNfeCabecalho->valorSeguro, $NFeIni);
		Util::iniWriteString("Total", "vDesc", $pNfeCabecalho->valorDesconto, $NFeIni);
		Util::iniWriteString("Total", "vII", $pNfeCabecalho->valorImpostoImportacao, $NFeIni);
		Util::iniWriteString("Total", "vIPI", $pNfeCabecalho->valorIpi, $NFeIni);
		Util::iniWriteString("Total", "vPIS", $pNfeCabecalho->valorPis, $NFeIni);
		Util::iniWriteString("Total", "vCOFINS", $pNfeCabecalho->valorCofins, $NFeIni);
		Util::iniWriteString("Total", "vOutro", $pNfeCabecalho->valorDespesasAcessorias, $NFeIni);
		Util::iniWriteString("Total", "vNF", $pNfeCabecalho->valorTotal, $NFeIni);

		// *******************************************************************************************
		//   [ISSQNtot]
		// *******************************************************************************************
		Util::iniWriteString("ISSQNtot", "vServ", $pNfeCabecalho->valorServicos, $NFeIni);
		Util::iniWriteString("ISSQNtot", "vBC", $pNfeCabecalho->baseCalculoIssqn, $NFeIni);
		Util::iniWriteString("ISSQNtot", "vISS", $pNfeCabecalho->valorIssqn, $NFeIni);
		Util::iniWriteString("ISSQNtot", "vPIS", $pNfeCabecalho->valorPisIssqn, $NFeIni);
		Util::iniWriteString("ISSQNtot", "vCOFINS", $pNfeCabecalho->valorCofinsIssqn, $NFeIni);

		// *******************************************************************************************
		//   [retTrib]
		// *******************************************************************************************
		Util::iniWriteString("retTrib", "vRetPIS", $pNfeCabecalho->valorRetidoPis, $NFeIni);
		Util::iniWriteString("retTrib", "vRetCOFINS", $pNfeCabecalho->valorRetidoCofins, $NFeIni);
		Util::iniWriteString("retTrib", "vRetCSLL", $pNfeCabecalho->valorRetidoCsll, $NFeIni);
		Util::iniWriteString("retTrib", "vBCIRRF", $pNfeCabecalho->baseCalculoIrrf, $NFeIni);
		Util::iniWriteString("retTrib", "vIRRF", $pNfeCabecalho->valorRetidoIrrf, $NFeIni);
		Util::iniWriteString("retTrib", "vBCRetPrev", $pNfeCabecalho->baseCalculoPrevidencia, $NFeIni);
		Util::iniWriteString("retTrib", "vRetPrev", $pNfeCabecalho->valorRetidoPrevidencia, $NFeIni);

		// *******************************************************************************************
		//   [PAG]
		// *******************************************************************************************
		Util::iniWriteString("PAG001", "tpag", "01", $NFeIni);
		Util::iniWriteString("PAG001", "vPag", $pNfeCabecalho->valorTotal, $NFeIni);
		Util::iniWriteString("PAG001", "indPag", "0", $NFeIni);
		Util::iniWriteString("PAG001", "vTroco", "0", $NFeIni);

		// *******************************************************************************************
		//   [DadosAdicionais]
		// *******************************************************************************************
		Util::iniWriteString("DadosAdicionais", "infAdFisco", "", $NFeIni);
		Util::iniWriteString("DadosAdicionais", "infCpl", "", $NFeIni);

		// grava arquivo INI
		Util::writeIniFile($nomeArquivoIni, $NFeIni);

		// remove aspas
		$arquivoComAspas = file_get_contents($nomeArquivoIni);
		$arquivoSemAspas = str_replace('"', '', $arquivoComAspas);
		file_put_contents($nomeArquivoIni, $arquivoSemAspas);

		return $nomeArquivoIni;
	}

	public function gerarArquivoEntrada($comando)
	{
		$nomeArquivoEntrada = CAMINHO_COM_CNPJ . "\\ent.txt";
		$arquivoEntrada = fopen($nomeArquivoEntrada, "w");
		fwrite($arquivoEntrada, $comando);
		fclose($arquivoEntrada);
	}

	public function pegarRetornoSaida($operacao)
	{
		$retorno = '';

		$nomeArquivoIni = CAMINHO_COM_CNPJ . 'sai.txt';
		$arquivoCompleto = file_get_contents($nomeArquivoIni);

		$codigoStatus = Util::IniReadString($operacao, "CStat", $nomeArquivoIni);
		$motivo = Util::IniReadString($operacao, "XMotivo", $nomeArquivoIni);

		$caminhoArquivoXml = '';

		if ($operacao === 'ARQUIVO-XML') {
			$caminhoArquivoXml = $arquivoCompleto;
			$caminhoArquivoXml = trim(str_replace('OK: ', '', $caminhoArquivoXml));
			return $caminhoArquivoXml;
		}
		if ($operacao === 'ARQUIVO-PDF') {
			$retorno = $arquivoCompleto;
			$retorno = trim(str_replace('OK: Arquivo criado em: ', '', $arquivoCompleto));
			return $retorno;
		}
		if ($operacao === 'Envio') {
			$retorno = $motivo;
		}
		if ($operacao === 'Cancelamento') {
			$retorno = $motivo;
		}
		if ($operacao === 'Consulta') {
			$retorno = $motivo;
		}
		if ($operacao === 'Inutilizacao') {
			return $arquivoCompleto;
		}

		$listaStatus = array("", "100", "102", "135"); // se o status não for um dos que estiverem nessa lista, vamos retornar um erro.
		if (!in_array($codigoStatus, $listaStatus)) {
			return "[ERRO] - [" . $codigoStatus . "] " . $motivo;
		}

		return $retorno;
	}

	public function apagarArquivoSaida()
	{
		unlink(CAMINHO_COM_CNPJ . "\\sai.txt");
	}

	public function aguardarArquivoSaida()
	{
		sleep(1);
		$tempoEspera = 0;
		while (!file_exists(CAMINHO_COM_CNPJ . "\\sai.txt")) {
			sleep(1);
			$tempoEspera = $tempoEspera + 1;

			if ($tempoEspera > 30) {
				return false;
			}
		}
		return true;
	}
}
