<?php
use Illuminate\Database\Capsule\Manager as DB;
class ProdutoMarcaService extends ServiceBase
{
	public function getList()
	{
		return ProdutoMarcaModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ProdutoMarcaModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ProdutoMarcaModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// produto
		$produtoModelListJson = $objJson->produtoModelList;
		if ($produtoModelListJson != null) {
			for ($i = 0; $i < count($produtoModelListJson); $i++) {
				$produto = new ProdutoModel();
				$produto->mapping($produtoModelListJson[$i]);
				$objModel->produtoModelList()->save($produto);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ProdutoModel::where('id_produto_marca', $object->getIdAttribute())->delete();
	}	
 
}