<?php
class NfeCanaDeducoesSafraService extends ServiceBase
{
  public function getList()
  {
    return NfeCanaDeducoesSafraModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeCanaDeducoesSafraModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeCanaDeducoesSafraModel::find($id);
  }

}