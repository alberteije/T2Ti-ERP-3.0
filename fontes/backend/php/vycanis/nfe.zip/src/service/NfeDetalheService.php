<?php
use Illuminate\Database\Capsule\Manager as DB;
class NfeDetalheService extends ServiceBase
{
	public function getList()
	{
		return NfeDetalheModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return NfeDetalheModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return NfeDetalheModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// nfeDetEspecificoVeiculo
		$nfeDetEspecificoVeiculoModelListJson = $objJson->nfeDetEspecificoVeiculoModelList;
		if ($nfeDetEspecificoVeiculoModelListJson != null) {
			for ($i = 0; $i < count($nfeDetEspecificoVeiculoModelListJson); $i++) {
				$nfeDetEspecificoVeiculo = new NfeDetEspecificoVeiculoModel();
				$nfeDetEspecificoVeiculo->mapping($nfeDetEspecificoVeiculoModelListJson[$i]);
				$objModel->nfeDetEspecificoVeiculoModelList()->save($nfeDetEspecificoVeiculo);
			}
		}

		// nfeDetEspecificoMedicamento
		$nfeDetEspecificoMedicamentoModelListJson = $objJson->nfeDetEspecificoMedicamentoModelList;
		if ($nfeDetEspecificoMedicamentoModelListJson != null) {
			for ($i = 0; $i < count($nfeDetEspecificoMedicamentoModelListJson); $i++) {
				$nfeDetEspecificoMedicamento = new NfeDetEspecificoMedicamentoModel();
				$nfeDetEspecificoMedicamento->mapping($nfeDetEspecificoMedicamentoModelListJson[$i]);
				$objModel->nfeDetEspecificoMedicamentoModelList()->save($nfeDetEspecificoMedicamento);
			}
		}

		// nfeDetEspecificoArmamento
		$nfeDetEspecificoArmamentoModelListJson = $objJson->nfeDetEspecificoArmamentoModelList;
		if ($nfeDetEspecificoArmamentoModelListJson != null) {
			for ($i = 0; $i < count($nfeDetEspecificoArmamentoModelListJson); $i++) {
				$nfeDetEspecificoArmamento = new NfeDetEspecificoArmamentoModel();
				$nfeDetEspecificoArmamento->mapping($nfeDetEspecificoArmamentoModelListJson[$i]);
				$objModel->nfeDetEspecificoArmamentoModelList()->save($nfeDetEspecificoArmamento);
			}
		}

		// nfeDetEspecificoCombustivel
		$nfeDetEspecificoCombustivelModelListJson = $objJson->nfeDetEspecificoCombustivelModelList;
		if ($nfeDetEspecificoCombustivelModelListJson != null) {
			for ($i = 0; $i < count($nfeDetEspecificoCombustivelModelListJson); $i++) {
				$nfeDetEspecificoCombustivel = new NfeDetEspecificoCombustivelModel();
				$nfeDetEspecificoCombustivel->mapping($nfeDetEspecificoCombustivelModelListJson[$i]);
				$objModel->nfeDetEspecificoCombustivelModelList()->save($nfeDetEspecificoCombustivel);
			}
		}

		// nfeDeclaracaoImportacao
		$nfeDeclaracaoImportacaoModelListJson = $objJson->nfeDeclaracaoImportacaoModelList;
		if ($nfeDeclaracaoImportacaoModelListJson != null) {
			for ($i = 0; $i < count($nfeDeclaracaoImportacaoModelListJson); $i++) {
				$nfeDeclaracaoImportacao = new NfeDeclaracaoImportacaoModel();
				$nfeDeclaracaoImportacao->mapping($nfeDeclaracaoImportacaoModelListJson[$i]);
				$objModel->nfeDeclaracaoImportacaoModelList()->save($nfeDeclaracaoImportacao);
			}
		}

		// nfeDetalheImpostoIcms
		$nfeDetalheImpostoIcmsModelListJson = $objJson->nfeDetalheImpostoIcmsModelList;
		if ($nfeDetalheImpostoIcmsModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoIcmsModelListJson); $i++) {
				$nfeDetalheImpostoIcms = new NfeDetalheImpostoIcmsModel();
				$nfeDetalheImpostoIcms->mapping($nfeDetalheImpostoIcmsModelListJson[$i]);
				$objModel->nfeDetalheImpostoIcmsModelList()->save($nfeDetalheImpostoIcms);
			}
		}

		// nfeDetalheImpostoIpi
		$nfeDetalheImpostoIpiModelListJson = $objJson->nfeDetalheImpostoIpiModelList;
		if ($nfeDetalheImpostoIpiModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoIpiModelListJson); $i++) {
				$nfeDetalheImpostoIpi = new NfeDetalheImpostoIpiModel();
				$nfeDetalheImpostoIpi->mapping($nfeDetalheImpostoIpiModelListJson[$i]);
				$objModel->nfeDetalheImpostoIpiModelList()->save($nfeDetalheImpostoIpi);
			}
		}

		// nfeDetalheImpostoIi
		$nfeDetalheImpostoIiModelListJson = $objJson->nfeDetalheImpostoIiModelList;
		if ($nfeDetalheImpostoIiModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoIiModelListJson); $i++) {
				$nfeDetalheImpostoIi = new NfeDetalheImpostoIiModel();
				$nfeDetalheImpostoIi->mapping($nfeDetalheImpostoIiModelListJson[$i]);
				$objModel->nfeDetalheImpostoIiModelList()->save($nfeDetalheImpostoIi);
			}
		}

		// nfeDetalheImpostoPis
		$nfeDetalheImpostoPisModelListJson = $objJson->nfeDetalheImpostoPisModelList;
		if ($nfeDetalheImpostoPisModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoPisModelListJson); $i++) {
				$nfeDetalheImpostoPis = new NfeDetalheImpostoPisModel();
				$nfeDetalheImpostoPis->mapping($nfeDetalheImpostoPisModelListJson[$i]);
				$objModel->nfeDetalheImpostoPisModelList()->save($nfeDetalheImpostoPis);
			}
		}

		// nfeDetalheImpostoCofins
		$nfeDetalheImpostoCofinsModelListJson = $objJson->nfeDetalheImpostoCofinsModelList;
		if ($nfeDetalheImpostoCofinsModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoCofinsModelListJson); $i++) {
				$nfeDetalheImpostoCofins = new NfeDetalheImpostoCofinsModel();
				$nfeDetalheImpostoCofins->mapping($nfeDetalheImpostoCofinsModelListJson[$i]);
				$objModel->nfeDetalheImpostoCofinsModelList()->save($nfeDetalheImpostoCofins);
			}
		}

		// nfeDetalheImpostoIssqn
		$nfeDetalheImpostoIssqnModelListJson = $objJson->nfeDetalheImpostoIssqnModelList;
		if ($nfeDetalheImpostoIssqnModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoIssqnModelListJson); $i++) {
				$nfeDetalheImpostoIssqn = new NfeDetalheImpostoIssqnModel();
				$nfeDetalheImpostoIssqn->mapping($nfeDetalheImpostoIssqnModelListJson[$i]);
				$objModel->nfeDetalheImpostoIssqnModelList()->save($nfeDetalheImpostoIssqn);
			}
		}

		// nfeExportacao
		$nfeExportacaoModelListJson = $objJson->nfeExportacaoModelList;
		if ($nfeExportacaoModelListJson != null) {
			for ($i = 0; $i < count($nfeExportacaoModelListJson); $i++) {
				$nfeExportacao = new NfeExportacaoModel();
				$nfeExportacao->mapping($nfeExportacaoModelListJson[$i]);
				$objModel->nfeExportacaoModelList()->save($nfeExportacao);
			}
		}

		// nfeItemRastreado
		$nfeItemRastreadoModelListJson = $objJson->nfeItemRastreadoModelList;
		if ($nfeItemRastreadoModelListJson != null) {
			for ($i = 0; $i < count($nfeItemRastreadoModelListJson); $i++) {
				$nfeItemRastreado = new NfeItemRastreadoModel();
				$nfeItemRastreado->mapping($nfeItemRastreadoModelListJson[$i]);
				$objModel->nfeItemRastreadoModelList()->save($nfeItemRastreado);
			}
		}

		// nfeDetalheImpostoPisSt
		$nfeDetalheImpostoPisStModelListJson = $objJson->nfeDetalheImpostoPisStModelList;
		if ($nfeDetalheImpostoPisStModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoPisStModelListJson); $i++) {
				$nfeDetalheImpostoPisSt = new NfeDetalheImpostoPisStModel();
				$nfeDetalheImpostoPisSt->mapping($nfeDetalheImpostoPisStModelListJson[$i]);
				$objModel->nfeDetalheImpostoPisStModelList()->save($nfeDetalheImpostoPisSt);
			}
		}

		// nfeDetalheImpostoIcmsUfdest
		$nfeDetalheImpostoIcmsUfdestModelListJson = $objJson->nfeDetalheImpostoIcmsUfdestModelList;
		if ($nfeDetalheImpostoIcmsUfdestModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoIcmsUfdestModelListJson); $i++) {
				$nfeDetalheImpostoIcmsUfdest = new NfeDetalheImpostoIcmsUfdestModel();
				$nfeDetalheImpostoIcmsUfdest->mapping($nfeDetalheImpostoIcmsUfdestModelListJson[$i]);
				$objModel->nfeDetalheImpostoIcmsUfdestModelList()->save($nfeDetalheImpostoIcmsUfdest);
			}
		}

		// nfeDetalheImpostoCofinsSt
		$nfeDetalheImpostoCofinsStModelListJson = $objJson->nfeDetalheImpostoCofinsStModelList;
		if ($nfeDetalheImpostoCofinsStModelListJson != null) {
			for ($i = 0; $i < count($nfeDetalheImpostoCofinsStModelListJson); $i++) {
				$nfeDetalheImpostoCofinsSt = new NfeDetalheImpostoCofinsStModel();
				$nfeDetalheImpostoCofinsSt->mapping($nfeDetalheImpostoCofinsStModelListJson[$i]);
				$objModel->nfeDetalheImpostoCofinsStModelList()->save($nfeDetalheImpostoCofinsSt);
			}
		}

	}	

	public function deleteChildren($object)
	{
		NfeDetEspecificoVeiculoModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetEspecificoMedicamentoModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetEspecificoArmamentoModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetEspecificoCombustivelModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDeclaracaoImportacaoModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoIcmsModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoIpiModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoIiModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoPisModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoCofinsModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoIssqnModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeExportacaoModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeItemRastreadoModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoPisStModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoIcmsUfdestModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
		NfeDetalheImpostoCofinsStModel::where('id_nfe_detalhe', $object->getIdAttribute())->delete();
	}	
 
}