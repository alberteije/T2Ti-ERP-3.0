<?php
class NfeTransporteVolumeLacreService extends ServiceBase
{
  public function getList()
  {
    return NfeTransporteVolumeLacreModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeTransporteVolumeLacreModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeTransporteVolumeLacreModel::find($id);
  }

}