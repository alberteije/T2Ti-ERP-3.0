<?php
class NfeConfiguracaoService extends ServiceBase
{
  public function getList()
  {
    return NfeConfiguracaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeConfiguracaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeConfiguracaoModel::find($id);
  }

}