<?php
class VendaCabecalhoService extends ServiceBase
{
  public function getList()
  {
    return VendaCabecalhoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return VendaCabecalhoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return VendaCabecalhoModel::find($id);
  }

}