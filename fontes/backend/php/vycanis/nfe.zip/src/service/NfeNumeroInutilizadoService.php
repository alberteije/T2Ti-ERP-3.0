<?php
class NfeNumeroInutilizadoService extends ServiceBase
{
  public function getList()
  {
    return NfeNumeroInutilizadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return NfeNumeroInutilizadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return NfeNumeroInutilizadoModel::find($id);
  }

}