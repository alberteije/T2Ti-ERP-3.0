<?php

declare(strict_types=1);

class Util
{

	public static function roundTruncateValue(string $pOperation, float $pValue, int $pDecimals)
	{
		return $pValue;
	}

	public static function camelCase($string)
	{
		$stringRetorno = ucwords(strtolower($string), "_");
		$stringRetorno = str_replace("_", "", $stringRetorno);
		$stringRetorno = lcfirst($stringRetorno);
		return $stringRetorno;
	}

	public static function sortArray(&$array, $field, $order = 'ASC')
	{
		usort(
			$array,
			function ($a, $b) use ($order, $field) {
				if ($a->$field == $b->$field) return 0;
				return (($a->$field < $b->$field) ? ($order == 'ASC' ? -1 : 1) : ($order == 'ASC' ? 1 : -1));
			}
		);
	}

	public static function crypt(string $valor)
	{
		$cifra_data = openssl_encrypt($valor, CYPHER, MAIN_KEY, OPENSSL_RAW_DATA, MAIN_VECTOR);
		$cifra_data_base64 = base64_encode($cifra_data);
		return $cifra_data_base64;
	}

	public static function decrypt(string $valor)
	{
		$decifra_data_base64 = base64_decode($valor);
		$decifra_data = openssl_decrypt($decifra_data_base64, CYPHER, MAIN_KEY, OPENSSL_RAW_DATA, MAIN_VECTOR);
		return $decifra_data;
	}

	public static function iniWriteString($secao, $chave, $valor, &$arquivoIni)
	{
		$arquivoIni[$secao][$chave] = $valor;
	}

	public static function iniReadString($secao, $chave, $arquivoIni)
	{
		$ini = file($arquivoIni);
		foreach ($ini as $line) {
			$line = trim($line);
			if (str_contains($line, "=")) {
				list($key, $value) = explode('=', $line, 2);
				$key = $key == null ? "" : trim($key);
				$value = $value == null ? "" : trim($value);
				if ($key === $chave) {
					return $value;
				}
			}
		}
		return "";
	}

	/**
	 * Write an ini configuration file
	 * 
	 * @param string $file
	 * @param array  $array
	 * @return bool
	 * Fonte: https://www.it-swarm.dev/pt/php/como-ler-e-gravar-em-um-arquivo-ini-com-php/971394629/
	 */
	public static function writeIniFile($file, $array = [])
	{
		// check first argument is string
		if (!is_string($file)) {
			throw new \InvalidArgumentException('Function argument 1 must be a string.');
		}

		// check second argument is array
		if (!is_array($array)) {
			throw new \InvalidArgumentException('Function argument 2 must be an array.');
		}

		// process array
		$data = array();
		foreach ($array as $key => $val) {
			if (is_array($val)) {
				$data[] = "[$key]";
				foreach ($val as $skey => $sval) {
					if (is_array($sval)) {
						foreach ($sval as $_skey => $_sval) {
							if (is_numeric($_skey)) {
								$data[] = $skey . '[] = ' . (is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"' . $_sval . '"'));
							} else {
								$data[] = $skey . '[' . $_skey . '] = ' . (is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"' . $_sval . '"'));
							}
						}
					} else {
						$data[] = $skey . ' = ' . (is_numeric($sval) ? $sval : (ctype_upper($sval) ? $sval : '"' . $sval . '"'));
					}
				}
			} else {
				$data[] = $key . ' = ' . (is_numeric($val) ? $val : (ctype_upper($val) ? $val : '"' . $val . '"'));
			}
			// empty line
			$data[] = null;
		}

		// open file pointer, init flock options
		$fp = fopen($file, 'w');
		$retries = 0;
		$max_retries = 100;

		if (!$fp) {
			return false;
		}

		// loop until get lock, or reach max retries
		do {
			if ($retries > 0) {
				usleep(Rand(1, 5000));
			}
			$retries += 1;
		} while (!flock($fp, LOCK_EX) && $retries <= $max_retries);

		// couldn't get the lock
		if ($retries == $max_retries) {
			return false;
		}

		// got lock, write data
		fwrite($fp, implode(PHP_EOL, $data) . PHP_EOL);

		// release lock
		flock($fp, LOCK_UN);
		fclose($fp);

		return true;
	}

	public static function ufToInt(string $pUF): int
	{
		$mapaUF = [
			'RO' => 11,
			'AC' => 12,
			'AM' => 13,
			'RR' => 14,
			'PA' => 15,
			'AP' => 16,
			'TO' => 17,
			'MA' => 21,
			'PI' => 22,
			'CE' => 23,
			'RN' => 24,
			'PB' => 25,
			'PE' => 26,
			'AL' => 27,
			'SE' => 28,
			'BA' => 29,
			'MG' => 31,
			'ES' => 32,
			'RJ' => 33,
			'SP' => 35,
			'PR' => 41,
			'SC' => 42,
			'RS' => 43,
			'MS' => 50,
			'MT' => 51,
			'GO' => 52,
			'DF' => 53,
		];

		return $mapaUF[$pUF] ?? 0;
	}
}
