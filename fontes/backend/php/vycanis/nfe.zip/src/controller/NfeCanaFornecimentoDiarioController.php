<?php
class NfeCanaFornecimentoDiarioController extends ControllerBase
{

		private $nfeCanaFornecimentoDiarioService = null;

		public function __construct()
		{	 
				$this->nfeCanaFornecimentoDiarioService = new NfeCanaFornecimentoDiarioService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->nfeCanaFornecimentoDiarioService->getListFilter($filter);
						} else {
								$resultList = $this->nfeCanaFornecimentoDiarioService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList NfeCanaFornecimentoDiario]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->nfeCanaFornecimentoDiarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject NfeCanaFornecimentoDiario]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject NfeCanaFornecimentoDiario]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert NfeCanaFornecimentoDiario]', null);
						}

						$objModel = new NfeCanaFornecimentoDiarioModel();
						$objModel->mapping($objJson);

						$this->nfeCanaFornecimentoDiarioService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert NfeCanaFornecimentoDiario]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->nfeCanaFornecimentoDiarioService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update NfeCanaFornecimentoDiario]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->nfeCanaFornecimentoDiarioService->save($objFromDatabase);
								$objFromDatabase = $this->nfeCanaFornecimentoDiarioService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update NfeCanaFornecimentoDiario]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->nfeCanaFornecimentoDiarioService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete NfeCanaFornecimentoDiario]', null);
						} else {
								$this->nfeCanaFornecimentoDiarioService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete NfeCanaFornecimentoDiario]', $e);
				}
		}
}
