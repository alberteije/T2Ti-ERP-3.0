<?php
class TributOperacaoFiscalController extends ControllerBase
{

		private $tributOperacaoFiscalService = null;

		public function __construct()
		{	 
				$this->tributOperacaoFiscalService = new TributOperacaoFiscalService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter(parent::handleFilter($request));
								$resultList = $this->tributOperacaoFiscalService->getListFilter($filter);
						} else {
								$resultList = $this->tributOperacaoFiscalService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList TributOperacaoFiscal]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->tributOperacaoFiscalService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject TributOperacaoFiscal]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject TributOperacaoFiscal]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert TributOperacaoFiscal]', null);
						}

						$objModel = new TributOperacaoFiscalModel();
						$objModel->mapping($objJson);

						$this->tributOperacaoFiscalService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert TributOperacaoFiscal]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->tributOperacaoFiscalService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update TributOperacaoFiscal]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->tributOperacaoFiscalService->save($objFromDatabase);
								$objFromDatabase = $this->tributOperacaoFiscalService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update TributOperacaoFiscal]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->tributOperacaoFiscalService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete TributOperacaoFiscal]', null);
						} else {
								$this->tributOperacaoFiscalService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete TributOperacaoFiscal]', $e);
				}
		}
}
