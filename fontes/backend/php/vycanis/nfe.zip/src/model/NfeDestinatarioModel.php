<?php
declare(strict_types=1);

class NfeDestinatarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_destinatario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getEstrangeiroIdentificacaoAttribute()
	{
		return $this->attributes['estrangeiro_identificacao'];
	}

	public function setEstrangeiroIdentificacaoAttribute($estrangeiroIdentificacao)
	{
		$this->attributes['estrangeiro_identificacao'] = $estrangeiroIdentificacao;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getComplementoAttribute()
	{
		return $this->attributes['complemento'];
	}

	public function setComplementoAttribute($complemento)
	{
		$this->attributes['complemento'] = $complemento;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getCodigoMunicipioAttribute()
	{
		return $this->attributes['codigo_municipio'];
	}

	public function setCodigoMunicipioAttribute($codigoMunicipio)
	{
		$this->attributes['codigo_municipio'] = $codigoMunicipio;
	}

	public function getNomeMunicipioAttribute()
	{
		return $this->attributes['nome_municipio'];
	}

	public function setNomeMunicipioAttribute($nomeMunicipio)
	{
		$this->attributes['nome_municipio'] = $nomeMunicipio;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getCepAttribute()
	{
		return $this->attributes['cep'];
	}

	public function setCepAttribute($cep)
	{
		$this->attributes['cep'] = $cep;
	}

	public function getCodigoPaisAttribute()
	{
		return $this->attributes['codigo_pais'];
	}

	public function setCodigoPaisAttribute($codigoPais)
	{
		$this->attributes['codigo_pais'] = $codigoPais;
	}

	public function getNomePaisAttribute()
	{
		return $this->attributes['nome_pais'];
	}

	public function setNomePaisAttribute($nomePais)
	{
		$this->attributes['nome_pais'] = $nomePais;
	}

	public function getTelefoneAttribute()
	{
		return $this->attributes['telefone'];
	}

	public function setTelefoneAttribute($telefone)
	{
		$this->attributes['telefone'] = $telefone;
	}

	public function getIndicadorIeAttribute()
	{
		return $this->attributes['indicador_ie'];
	}

	public function setIndicadorIeAttribute($indicadorIe)
	{
		$this->attributes['indicador_ie'] = $indicadorIe;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	public function getSuframaAttribute()
	{
		return $this->attributes['suframa'];
	}

	public function setSuframaAttribute($suframa)
	{
		$this->attributes['suframa'] = $suframa;
	}

	public function getInscricaoMunicipalAttribute()
	{
		return $this->attributes['inscricao_municipal'];
	}

	public function setInscricaoMunicipalAttribute($inscricaoMunicipal)
	{
		$this->attributes['inscricao_municipal'] = $inscricaoMunicipal;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjAttribute($object->cnpj);
				$this->setCpfAttribute($object->cpf);
				$this->setEstrangeiroIdentificacaoAttribute($object->estrangeiroIdentificacao);
				$this->setNomeAttribute($object->nome);
				$this->setLogradouroAttribute($object->logradouro);
				$this->setNumeroAttribute($object->numero);
				$this->setComplementoAttribute($object->complemento);
				$this->setBairroAttribute($object->bairro);
				$this->setCodigoMunicipioAttribute($object->codigoMunicipio);
				$this->setNomeMunicipioAttribute($object->nomeMunicipio);
				$this->setUfAttribute($object->uf);
				$this->setCepAttribute($object->cep);
				$this->setCodigoPaisAttribute($object->codigoPais);
				$this->setNomePaisAttribute($object->nomePais);
				$this->setTelefoneAttribute($object->telefone);
				$this->setIndicadorIeAttribute($object->indicadorIe);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);
				$this->setSuframaAttribute($object->suframa);
				$this->setInscricaoMunicipalAttribute($object->inscricaoMunicipal);
				$this->setEmailAttribute($object->email);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'estrangeiroIdentificacao' => $this->getEstrangeiroIdentificacaoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'complemento' => $this->getComplementoAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'codigoMunicipio' => $this->getCodigoMunicipioAttribute(),
				'nomeMunicipio' => $this->getNomeMunicipioAttribute(),
				'uf' => $this->getUfAttribute(),
				'cep' => $this->getCepAttribute(),
				'codigoPais' => $this->getCodigoPaisAttribute(),
				'nomePais' => $this->getNomePaisAttribute(),
				'telefone' => $this->getTelefoneAttribute(),
				'indicadorIe' => $this->getIndicadorIeAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
				'suframa' => $this->getSuframaAttribute(),
				'inscricaoMunicipal' => $this->getInscricaoMunicipalAttribute(),
				'email' => $this->getEmailAttribute(),
			];
	}
}