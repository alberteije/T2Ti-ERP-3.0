<?php
declare(strict_types=1);

class EmpresaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'empresa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'empresaEnderecoModelList',
		'empresaContatoModelList',
		'empresaTelefoneModelList',
		'empresaCnaeModelList',
	];

	/**
		* Relations
		*/
	public function empresaEnderecoModelList()
{
	return $this->hasMany(EmpresaEnderecoModel::class, 'id_empresa', 'id');
}

	public function empresaContatoModelList()
{
	return $this->hasMany(EmpresaContatoModel::class, 'id_empresa', 'id');
}

	public function empresaTelefoneModelList()
{
	return $this->hasMany(EmpresaTelefoneModel::class, 'id_empresa', 'id');
}

	public function empresaCnaeModelList()
{
	return $this->hasMany(EmpresaCnaeModel::class, 'id_empresa', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getRazaoSocialAttribute()
	{
		return $this->attributes['razao_social'];
	}

	public function setRazaoSocialAttribute($razaoSocial)
	{
		$this->attributes['razao_social'] = $razaoSocial;
	}

	public function getNomeFantasiaAttribute()
	{
		return $this->attributes['nome_fantasia'];
	}

	public function setNomeFantasiaAttribute($nomeFantasia)
	{
		$this->attributes['nome_fantasia'] = $nomeFantasia;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	public function getInscricaoMunicipalAttribute()
	{
		return $this->attributes['inscricao_municipal'];
	}

	public function setInscricaoMunicipalAttribute($inscricaoMunicipal)
	{
		$this->attributes['inscricao_municipal'] = $inscricaoMunicipal;
	}

	public function getTipoRegimeAttribute()
	{
		return $this->attributes['tipo_regime'];
	}

	public function setTipoRegimeAttribute($tipoRegime)
	{
		$this->attributes['tipo_regime'] = $tipoRegime;
	}

	public function getCrtAttribute()
	{
		return $this->attributes['crt'];
	}

	public function setCrtAttribute($crt)
	{
		$this->attributes['crt'] = $crt;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getSiteAttribute()
	{
		return $this->attributes['site'];
	}

	public function setSiteAttribute($site)
	{
		$this->attributes['site'] = $site;
	}

	public function getContatoAttribute()
	{
		return $this->attributes['contato'];
	}

	public function setContatoAttribute($contato)
	{
		$this->attributes['contato'] = $contato;
	}

	public function getDataConstituicaoAttribute()
	{
		return $this->attributes['data_constituicao'];
	}

	public function setDataConstituicaoAttribute($dataConstituicao)
	{
		$this->attributes['data_constituicao'] = $dataConstituicao;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getInscricaoJuntaComercialAttribute()
	{
		return $this->attributes['inscricao_junta_comercial'];
	}

	public function setInscricaoJuntaComercialAttribute($inscricaoJuntaComercial)
	{
		$this->attributes['inscricao_junta_comercial'] = $inscricaoJuntaComercial;
	}

	public function getDataInscJuntaComercialAttribute()
	{
		return $this->attributes['data_insc_junta_comercial'];
	}

	public function setDataInscJuntaComercialAttribute($dataInscJuntaComercial)
	{
		$this->attributes['data_insc_junta_comercial'] = $dataInscJuntaComercial;
	}

	public function getCodigoIbgeCidadeAttribute()
	{
		return $this->attributes['codigo_ibge_cidade'];
	}

	public function setCodigoIbgeCidadeAttribute($codigoIbgeCidade)
	{
		$this->attributes['codigo_ibge_cidade'] = $codigoIbgeCidade;
	}

	public function getCodigoIbgeUfAttribute()
	{
		return $this->attributes['codigo_ibge_uf'];
	}

	public function setCodigoIbgeUfAttribute($codigoIbgeUf)
	{
		$this->attributes['codigo_ibge_uf'] = $codigoIbgeUf;
	}

	public function getCeiAttribute()
	{
		return $this->attributes['cei'];
	}

	public function setCeiAttribute($cei)
	{
		$this->attributes['cei'] = $cei;
	}

	public function getCodigoCnaePrincipalAttribute()
	{
		return $this->attributes['codigo_cnae_principal'];
	}

	public function setCodigoCnaePrincipalAttribute($codigoCnaePrincipal)
	{
		$this->attributes['codigo_cnae_principal'] = $codigoCnaePrincipal;
	}

	public function getImagemLogotipoAttribute()
	{
		return $this->attributes['imagem_logotipo'];
	}

	public function setImagemLogotipoAttribute($imagemLogotipo)
	{
		$this->attributes['imagem_logotipo'] = $imagemLogotipo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setRazaoSocialAttribute($object->razaoSocial);
				$this->setNomeFantasiaAttribute($object->nomeFantasia);
				$this->setCnpjAttribute($object->cnpj);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);
				$this->setInscricaoMunicipalAttribute($object->inscricaoMunicipal);
				$this->setTipoRegimeAttribute($object->tipoRegime);
				$this->setCrtAttribute($object->crt);
				$this->setEmailAttribute($object->email);
				$this->setSiteAttribute($object->site);
				$this->setContatoAttribute($object->contato);
				$this->setDataConstituicaoAttribute($object->dataConstituicao);
				$this->setTipoAttribute($object->tipo);
				$this->setInscricaoJuntaComercialAttribute($object->inscricaoJuntaComercial);
				$this->setDataInscJuntaComercialAttribute($object->dataInscJuntaComercial);
				$this->setCodigoIbgeCidadeAttribute($object->codigoIbgeCidade);
				$this->setCodigoIbgeUfAttribute($object->codigoIbgeUf);
				$this->setCeiAttribute($object->cei);
				$this->setCodigoCnaePrincipalAttribute($object->codigoCnaePrincipal);
				$this->setImagemLogotipoAttribute($object->imagemLogotipo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'razaoSocial' => $this->getRazaoSocialAttribute(),
				'nomeFantasia' => $this->getNomeFantasiaAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
				'inscricaoMunicipal' => $this->getInscricaoMunicipalAttribute(),
				'tipoRegime' => $this->getTipoRegimeAttribute(),
				'crt' => $this->getCrtAttribute(),
				'email' => $this->getEmailAttribute(),
				'site' => $this->getSiteAttribute(),
				'contato' => $this->getContatoAttribute(),
				'dataConstituicao' => $this->getDataConstituicaoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'inscricaoJuntaComercial' => $this->getInscricaoJuntaComercialAttribute(),
				'dataInscJuntaComercial' => $this->getDataInscJuntaComercialAttribute(),
				'codigoIbgeCidade' => $this->getCodigoIbgeCidadeAttribute(),
				'codigoIbgeUf' => $this->getCodigoIbgeUfAttribute(),
				'cei' => $this->getCeiAttribute(),
				'codigoCnaePrincipal' => $this->getCodigoCnaePrincipalAttribute(),
				'imagemLogotipo' => $this->getImagemLogotipoAttribute(),
				'empresaEnderecoModelList' => $this->empresaEnderecoModelList,
				'empresaContatoModelList' => $this->empresaContatoModelList,
				'empresaTelefoneModelList' => $this->empresaTelefoneModelList,
				'empresaCnaeModelList' => $this->empresaCnaeModelList,
			];
	}
}