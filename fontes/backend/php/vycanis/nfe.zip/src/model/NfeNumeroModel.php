<?php
declare(strict_types=1);

class NfeNumeroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_numero';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setSerieAttribute($object->serie);
				$this->setNumeroAttribute($object->numero);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numero' => $this->getNumeroAttribute(),
			];
	}
}