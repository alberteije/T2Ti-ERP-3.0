<?php
declare(strict_types=1);

class NfeItemRastreadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_item_rastreado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroLoteAttribute()
	{
		return $this->attributes['numero_lote'];
	}

	public function setNumeroLoteAttribute($numeroLote)
	{
		$this->attributes['numero_lote'] = $numeroLote;
	}

	public function getQuantidadeItensAttribute()
	{
		return (double)$this->attributes['quantidade_itens'];
	}

	public function setQuantidadeItensAttribute($quantidadeItens)
	{
		$this->attributes['quantidade_itens'] = $quantidadeItens;
	}

	public function getDataFabricacaoAttribute()
	{
		return $this->attributes['data_fabricacao'];
	}

	public function setDataFabricacaoAttribute($dataFabricacao)
	{
		$this->attributes['data_fabricacao'] = $dataFabricacao;
	}

	public function getDataValidadeAttribute()
	{
		return $this->attributes['data_validade'];
	}

	public function setDataValidadeAttribute($dataValidade)
	{
		$this->attributes['data_validade'] = $dataValidade;
	}

	public function getCodigoAgregacaoAttribute()
	{
		return $this->attributes['codigo_agregacao'];
	}

	public function setCodigoAgregacaoAttribute($codigoAgregacao)
	{
		$this->attributes['codigo_agregacao'] = $codigoAgregacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroLoteAttribute($object->numeroLote);
				$this->setQuantidadeItensAttribute($object->quantidadeItens);
				$this->setDataFabricacaoAttribute($object->dataFabricacao);
				$this->setDataValidadeAttribute($object->dataValidade);
				$this->setCodigoAgregacaoAttribute($object->codigoAgregacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroLote' => $this->getNumeroLoteAttribute(),
				'quantidadeItens' => $this->getQuantidadeItensAttribute(),
				'dataFabricacao' => $this->getDataFabricacaoAttribute(),
				'dataValidade' => $this->getDataValidadeAttribute(),
				'codigoAgregacao' => $this->getCodigoAgregacaoAttribute(),
			];
	}
}