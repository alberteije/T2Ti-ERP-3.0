<?php
declare(strict_types=1);

class NfeNumeroInutilizadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_numero_inutilizado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataInutilizacaoAttribute()
	{
		return $this->attributes['data_inutilizacao'];
	}

	public function setDataInutilizacaoAttribute($dataInutilizacao)
	{
		$this->attributes['data_inutilizacao'] = $dataInutilizacao;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setSerieAttribute($object->serie);
				$this->setNumeroAttribute($object->numero);
				$this->setDataInutilizacaoAttribute($object->dataInutilizacao);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataInutilizacao' => $this->getDataInutilizacaoAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}