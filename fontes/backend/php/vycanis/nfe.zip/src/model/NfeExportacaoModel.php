<?php
declare(strict_types=1);

class NfeExportacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_exportacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDrawbackAttribute()
	{
		return $this->attributes['drawback'];
	}

	public function setDrawbackAttribute($drawback)
	{
		$this->attributes['drawback'] = $drawback;
	}

	public function getNumeroRegistroAttribute()
	{
		return $this->attributes['numero_registro'];
	}

	public function setNumeroRegistroAttribute($numeroRegistro)
	{
		$this->attributes['numero_registro'] = $numeroRegistro;
	}

	public function getChaveAcessoAttribute()
	{
		return $this->attributes['chave_acesso'];
	}

	public function setChaveAcessoAttribute($chaveAcesso)
	{
		$this->attributes['chave_acesso'] = $chaveAcesso;
	}

	public function getQuantidadeAttribute()
	{
		return (double)$this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDrawbackAttribute($object->drawback);
				$this->setNumeroRegistroAttribute($object->numeroRegistro);
				$this->setChaveAcessoAttribute($object->chaveAcesso);
				$this->setQuantidadeAttribute($object->quantidade);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'drawback' => $this->getDrawbackAttribute(),
				'numeroRegistro' => $this->getNumeroRegistroAttribute(),
				'chaveAcesso' => $this->getChaveAcessoAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
			];
	}
}