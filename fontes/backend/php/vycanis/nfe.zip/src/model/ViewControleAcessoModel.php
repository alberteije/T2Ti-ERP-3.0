<?php
declare(strict_types=1);

class ViewControleAcessoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'view_controle_acesso';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdPessoaAttribute()
	{
		return $this->attributes['id_pessoa'];
	}

	public function setIdPessoaAttribute($idPessoa)
	{
		$this->attributes['id_pessoa'] = $idPessoa;
	}

	public function getPessoaNomeAttribute()
	{
		return $this->attributes['pessoa_nome'];
	}

	public function setPessoaNomeAttribute($pessoaNome)
	{
		$this->attributes['pessoa_nome'] = $pessoaNome;
	}

	public function getIdColaboradorAttribute()
	{
		return $this->attributes['id_colaborador'];
	}

	public function setIdColaboradorAttribute($idColaborador)
	{
		$this->attributes['id_colaborador'] = $idColaborador;
	}

	public function getIdUsuarioAttribute()
	{
		return $this->attributes['id_usuario'];
	}

	public function setIdUsuarioAttribute($idUsuario)
	{
		$this->attributes['id_usuario'] = $idUsuario;
	}

	public function getAdministradorAttribute()
	{
		return $this->attributes['administrador'];
	}

	public function setAdministradorAttribute($administrador)
	{
		$this->attributes['administrador'] = $administrador;
	}

	public function getIdPapelAttribute()
	{
		return $this->attributes['id_papel'];
	}

	public function setIdPapelAttribute($idPapel)
	{
		$this->attributes['id_papel'] = $idPapel;
	}

	public function getPapelNomeAttribute()
	{
		return $this->attributes['papel_nome'];
	}

	public function setPapelNomeAttribute($papelNome)
	{
		$this->attributes['papel_nome'] = $papelNome;
	}

	public function getPapelDescricaoAttribute()
	{
		return $this->attributes['papel_descricao'];
	}

	public function setPapelDescricaoAttribute($papelDescricao)
	{
		$this->attributes['papel_descricao'] = $papelDescricao;
	}

	public function getIdFuncaoAttribute()
	{
		return $this->attributes['id_funcao'];
	}

	public function setIdFuncaoAttribute($idFuncao)
	{
		$this->attributes['id_funcao'] = $idFuncao;
	}

	public function getFuncaoNomeAttribute()
	{
		return $this->attributes['funcao_nome'];
	}

	public function setFuncaoNomeAttribute($funcaoNome)
	{
		$this->attributes['funcao_nome'] = $funcaoNome;
	}

	public function getFuncaoDescricaoAttribute()
	{
		return $this->attributes['funcao_descricao'];
	}

	public function setFuncaoDescricaoAttribute($funcaoDescricao)
	{
		$this->attributes['funcao_descricao'] = $funcaoDescricao;
	}

	public function getIdPapelFuncaoAttribute()
	{
		return $this->attributes['id_papel_funcao'];
	}

	public function setIdPapelFuncaoAttribute($idPapelFuncao)
	{
		$this->attributes['id_papel_funcao'] = $idPapelFuncao;
	}

	public function getHabilitadoAttribute()
	{
		return $this->attributes['habilitado'];
	}

	public function setHabilitadoAttribute($habilitado)
	{
		$this->attributes['habilitado'] = $habilitado;
	}

	public function getPodeInserirAttribute()
	{
		return $this->attributes['pode_inserir'];
	}

	public function setPodeInserirAttribute($podeInserir)
	{
		$this->attributes['pode_inserir'] = $podeInserir;
	}

	public function getPodeAlterarAttribute()
	{
		return $this->attributes['pode_alterar'];
	}

	public function setPodeAlterarAttribute($podeAlterar)
	{
		$this->attributes['pode_alterar'] = $podeAlterar;
	}

	public function getPodeExcluirAttribute()
	{
		return $this->attributes['pode_excluir'];
	}

	public function setPodeExcluirAttribute($podeExcluir)
	{
		$this->attributes['pode_excluir'] = $podeExcluir;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdAttribute($object->id);
				$this->setIdPessoaAttribute($object->idPessoa);
				$this->setPessoaNomeAttribute($object->pessoaNome);
				$this->setIdColaboradorAttribute($object->idColaborador);
				$this->setIdUsuarioAttribute($object->idUsuario);
				$this->setAdministradorAttribute($object->administrador);
				$this->setIdPapelAttribute($object->idPapel);
				$this->setPapelNomeAttribute($object->papelNome);
				$this->setPapelDescricaoAttribute($object->papelDescricao);
				$this->setIdFuncaoAttribute($object->idFuncao);
				$this->setFuncaoNomeAttribute($object->funcaoNome);
				$this->setFuncaoDescricaoAttribute($object->funcaoDescricao);
				$this->setIdPapelFuncaoAttribute($object->idPapelFuncao);
				$this->setHabilitadoAttribute($object->habilitado);
				$this->setPodeInserirAttribute($object->podeInserir);
				$this->setPodeAlterarAttribute($object->podeAlterar);
				$this->setPodeExcluirAttribute($object->podeExcluir);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idPessoa' => $this->getIdPessoaAttribute(),
				'pessoaNome' => $this->getPessoaNomeAttribute(),
				'idColaborador' => $this->getIdColaboradorAttribute(),
				'idUsuario' => $this->getIdUsuarioAttribute(),
				'administrador' => $this->getAdministradorAttribute(),
				'idPapel' => $this->getIdPapelAttribute(),
				'papelNome' => $this->getPapelNomeAttribute(),
				'papelDescricao' => $this->getPapelDescricaoAttribute(),
				'idFuncao' => $this->getIdFuncaoAttribute(),
				'funcaoNome' => $this->getFuncaoNomeAttribute(),
				'funcaoDescricao' => $this->getFuncaoDescricaoAttribute(),
				'idPapelFuncao' => $this->getIdPapelFuncaoAttribute(),
				'habilitado' => $this->getHabilitadoAttribute(),
				'podeInserir' => $this->getPodeInserirAttribute(),
				'podeAlterar' => $this->getPodeAlterarAttribute(),
				'podeExcluir' => $this->getPodeExcluirAttribute(),
			];
	}
}