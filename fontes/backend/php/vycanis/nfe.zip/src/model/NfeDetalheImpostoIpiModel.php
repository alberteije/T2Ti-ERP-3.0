<?php
declare(strict_types=1);

class NfeDetalheImpostoIpiModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_ipi';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjProdutorAttribute()
	{
		return $this->attributes['cnpj_produtor'];
	}

	public function setCnpjProdutorAttribute($cnpjProdutor)
	{
		$this->attributes['cnpj_produtor'] = $cnpjProdutor;
	}

	public function getCodigoSeloIpiAttribute()
	{
		return $this->attributes['codigo_selo_ipi'];
	}

	public function setCodigoSeloIpiAttribute($codigoSeloIpi)
	{
		$this->attributes['codigo_selo_ipi'] = $codigoSeloIpi;
	}

	public function getQuantidadeSeloIpiAttribute()
	{
		return $this->attributes['quantidade_selo_ipi'];
	}

	public function setQuantidadeSeloIpiAttribute($quantidadeSeloIpi)
	{
		$this->attributes['quantidade_selo_ipi'] = $quantidadeSeloIpi;
	}

	public function getEnquadramentoLegalIpiAttribute()
	{
		return $this->attributes['enquadramento_legal_ipi'];
	}

	public function setEnquadramentoLegalIpiAttribute($enquadramentoLegalIpi)
	{
		$this->attributes['enquadramento_legal_ipi'] = $enquadramentoLegalIpi;
	}

	public function getCstIpiAttribute()
	{
		return $this->attributes['cst_ipi'];
	}

	public function setCstIpiAttribute($cstIpi)
	{
		$this->attributes['cst_ipi'] = $cstIpi;
	}

	public function getValorBaseCalculoIpiAttribute()
	{
		return (double)$this->attributes['valor_base_calculo_ipi'];
	}

	public function setValorBaseCalculoIpiAttribute($valorBaseCalculoIpi)
	{
		$this->attributes['valor_base_calculo_ipi'] = $valorBaseCalculoIpi;
	}

	public function getQuantidadeUnidadeTributavelAttribute()
	{
		return (double)$this->attributes['quantidade_unidade_tributavel'];
	}

	public function setQuantidadeUnidadeTributavelAttribute($quantidadeUnidadeTributavel)
	{
		$this->attributes['quantidade_unidade_tributavel'] = $quantidadeUnidadeTributavel;
	}

	public function getValorUnidadeTributavelAttribute()
	{
		return (double)$this->attributes['valor_unidade_tributavel'];
	}

	public function setValorUnidadeTributavelAttribute($valorUnidadeTributavel)
	{
		$this->attributes['valor_unidade_tributavel'] = $valorUnidadeTributavel;
	}

	public function getAliquotaIpiAttribute()
	{
		return (double)$this->attributes['aliquota_ipi'];
	}

	public function setAliquotaIpiAttribute($aliquotaIpi)
	{
		$this->attributes['aliquota_ipi'] = $aliquotaIpi;
	}

	public function getValorIpiAttribute()
	{
		return (double)$this->attributes['valor_ipi'];
	}

	public function setValorIpiAttribute($valorIpi)
	{
		$this->attributes['valor_ipi'] = $valorIpi;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjProdutorAttribute($object->cnpjProdutor);
				$this->setCodigoSeloIpiAttribute($object->codigoSeloIpi);
				$this->setQuantidadeSeloIpiAttribute($object->quantidadeSeloIpi);
				$this->setEnquadramentoLegalIpiAttribute($object->enquadramentoLegalIpi);
				$this->setCstIpiAttribute($object->cstIpi);
				$this->setValorBaseCalculoIpiAttribute($object->valorBaseCalculoIpi);
				$this->setQuantidadeUnidadeTributavelAttribute($object->quantidadeUnidadeTributavel);
				$this->setValorUnidadeTributavelAttribute($object->valorUnidadeTributavel);
				$this->setAliquotaIpiAttribute($object->aliquotaIpi);
				$this->setValorIpiAttribute($object->valorIpi);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpjProdutor' => $this->getCnpjProdutorAttribute(),
				'codigoSeloIpi' => $this->getCodigoSeloIpiAttribute(),
				'quantidadeSeloIpi' => $this->getQuantidadeSeloIpiAttribute(),
				'enquadramentoLegalIpi' => $this->getEnquadramentoLegalIpiAttribute(),
				'cstIpi' => $this->getCstIpiAttribute(),
				'valorBaseCalculoIpi' => $this->getValorBaseCalculoIpiAttribute(),
				'quantidadeUnidadeTributavel' => $this->getQuantidadeUnidadeTributavelAttribute(),
				'valorUnidadeTributavel' => $this->getValorUnidadeTributavelAttribute(),
				'aliquotaIpi' => $this->getAliquotaIpiAttribute(),
				'valorIpi' => $this->getValorIpiAttribute(),
			];
	}
}