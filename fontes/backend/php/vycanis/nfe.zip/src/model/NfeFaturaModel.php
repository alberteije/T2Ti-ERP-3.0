<?php
declare(strict_types=1);

class NfeFaturaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_fatura';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeDuplicataModelList',
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeDuplicataModelList()
{
	return $this->hasMany(NfeDuplicataModel::class, 'id_nfe_fatura', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getValorOriginalAttribute()
	{
		return (double)$this->attributes['valor_original'];
	}

	public function setValorOriginalAttribute($valorOriginal)
	{
		$this->attributes['valor_original'] = $valorOriginal;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorLiquidoAttribute()
	{
		return (double)$this->attributes['valor_liquido'];
	}

	public function setValorLiquidoAttribute($valorLiquido)
	{
		$this->attributes['valor_liquido'] = $valorLiquido;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setValorOriginalAttribute($object->valorOriginal);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorLiquidoAttribute($object->valorLiquido);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'valorOriginal' => $this->getValorOriginalAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorLiquido' => $this->getValorLiquidoAttribute(),
				'nfeDuplicataModelList' => $this->nfeDuplicataModelList,
			];
	}
}