<?php
declare(strict_types=1);

class NfeTransporteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_transporte';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeTransporteReboqueModelList',
		'nfeTransporteVolumeModelList',
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeTransporteReboqueModelList()
{
	return $this->hasMany(NfeTransporteReboqueModel::class, 'id_nfe_transporte', 'id');
}

	public function nfeTransporteVolumeModelList()
{
	return $this->hasMany(NfeTransporteVolumeModel::class, 'id_nfe_transporte', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdTransportadoraAttribute()
	{
		return $this->attributes['id_transportadora'];
	}

	public function setIdTransportadoraAttribute($idTransportadora)
	{
		$this->attributes['id_transportadora'] = $idTransportadora;
	}

	public function getModalidadeFreteAttribute()
	{
		return $this->attributes['modalidade_frete'];
	}

	public function setModalidadeFreteAttribute($modalidadeFrete)
	{
		$this->attributes['modalidade_frete'] = $modalidadeFrete;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	public function getEnderecoAttribute()
	{
		return $this->attributes['endereco'];
	}

	public function setEnderecoAttribute($endereco)
	{
		$this->attributes['endereco'] = $endereco;
	}

	public function getNomeMunicipioAttribute()
	{
		return $this->attributes['nome_municipio'];
	}

	public function setNomeMunicipioAttribute($nomeMunicipio)
	{
		$this->attributes['nome_municipio'] = $nomeMunicipio;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getValorServicoAttribute()
	{
		return (double)$this->attributes['valor_servico'];
	}

	public function setValorServicoAttribute($valorServico)
	{
		$this->attributes['valor_servico'] = $valorServico;
	}

	public function getValorBcRetencaoIcmsAttribute()
	{
		return (double)$this->attributes['valor_bc_retencao_icms'];
	}

	public function setValorBcRetencaoIcmsAttribute($valorBcRetencaoIcms)
	{
		$this->attributes['valor_bc_retencao_icms'] = $valorBcRetencaoIcms;
	}

	public function getAliquotaRetencaoIcmsAttribute()
	{
		return (double)$this->attributes['aliquota_retencao_icms'];
	}

	public function setAliquotaRetencaoIcmsAttribute($aliquotaRetencaoIcms)
	{
		$this->attributes['aliquota_retencao_icms'] = $aliquotaRetencaoIcms;
	}

	public function getValorIcmsRetidoAttribute()
	{
		return (double)$this->attributes['valor_icms_retido'];
	}

	public function setValorIcmsRetidoAttribute($valorIcmsRetido)
	{
		$this->attributes['valor_icms_retido'] = $valorIcmsRetido;
	}

	public function getCfopAttribute()
	{
		return $this->attributes['cfop'];
	}

	public function setCfopAttribute($cfop)
	{
		$this->attributes['cfop'] = $cfop;
	}

	public function getMunicipioAttribute()
	{
		return $this->attributes['municipio'];
	}

	public function setMunicipioAttribute($municipio)
	{
		$this->attributes['municipio'] = $municipio;
	}

	public function getPlacaVeiculoAttribute()
	{
		return $this->attributes['placa_veiculo'];
	}

	public function setPlacaVeiculoAttribute($placaVeiculo)
	{
		$this->attributes['placa_veiculo'] = $placaVeiculo;
	}

	public function getUfVeiculoAttribute()
	{
		return $this->attributes['uf_veiculo'];
	}

	public function setUfVeiculoAttribute($ufVeiculo)
	{
		$this->attributes['uf_veiculo'] = $ufVeiculo;
	}

	public function getRntcVeiculoAttribute()
	{
		return $this->attributes['rntc_veiculo'];
	}

	public function setRntcVeiculoAttribute($rntcVeiculo)
	{
		$this->attributes['rntc_veiculo'] = $rntcVeiculo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdTransportadoraAttribute($object->idTransportadora);
				$this->setModalidadeFreteAttribute($object->modalidadeFrete);
				$this->setCnpjAttribute($object->cnpj);
				$this->setCpfAttribute($object->cpf);
				$this->setNomeAttribute($object->nome);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);
				$this->setEnderecoAttribute($object->endereco);
				$this->setNomeMunicipioAttribute($object->nomeMunicipio);
				$this->setUfAttribute($object->uf);
				$this->setValorServicoAttribute($object->valorServico);
				$this->setValorBcRetencaoIcmsAttribute($object->valorBcRetencaoIcms);
				$this->setAliquotaRetencaoIcmsAttribute($object->aliquotaRetencaoIcms);
				$this->setValorIcmsRetidoAttribute($object->valorIcmsRetido);
				$this->setCfopAttribute($object->cfop);
				$this->setMunicipioAttribute($object->municipio);
				$this->setPlacaVeiculoAttribute($object->placaVeiculo);
				$this->setUfVeiculoAttribute($object->ufVeiculo);
				$this->setRntcVeiculoAttribute($object->rntcVeiculo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idTransportadora' => $this->getIdTransportadoraAttribute(),
				'modalidadeFrete' => $this->getModalidadeFreteAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'nome' => $this->getNomeAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
				'endereco' => $this->getEnderecoAttribute(),
				'nomeMunicipio' => $this->getNomeMunicipioAttribute(),
				'uf' => $this->getUfAttribute(),
				'valorServico' => $this->getValorServicoAttribute(),
				'valorBcRetencaoIcms' => $this->getValorBcRetencaoIcmsAttribute(),
				'aliquotaRetencaoIcms' => $this->getAliquotaRetencaoIcmsAttribute(),
				'valorIcmsRetido' => $this->getValorIcmsRetidoAttribute(),
				'cfop' => $this->getCfopAttribute(),
				'municipio' => $this->getMunicipioAttribute(),
				'placaVeiculo' => $this->getPlacaVeiculoAttribute(),
				'ufVeiculo' => $this->getUfVeiculoAttribute(),
				'rntcVeiculo' => $this->getRntcVeiculoAttribute(),
				'nfeTransporteReboqueModelList' => $this->nfeTransporteReboqueModelList,
				'nfeTransporteVolumeModelList' => $this->nfeTransporteVolumeModelList,
			];
	}
}