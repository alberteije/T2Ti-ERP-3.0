<?php
declare(strict_types=1);

class NfeDetalheImpostoIssqnModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_issqn';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getBaseCalculoIssqnAttribute()
	{
		return (double)$this->attributes['base_calculo_issqn'];
	}

	public function setBaseCalculoIssqnAttribute($baseCalculoIssqn)
	{
		$this->attributes['base_calculo_issqn'] = $baseCalculoIssqn;
	}

	public function getAliquotaIssqnAttribute()
	{
		return (double)$this->attributes['aliquota_issqn'];
	}

	public function setAliquotaIssqnAttribute($aliquotaIssqn)
	{
		$this->attributes['aliquota_issqn'] = $aliquotaIssqn;
	}

	public function getValorIssqnAttribute()
	{
		return (double)$this->attributes['valor_issqn'];
	}

	public function setValorIssqnAttribute($valorIssqn)
	{
		$this->attributes['valor_issqn'] = $valorIssqn;
	}

	public function getMunicipioIssqnAttribute()
	{
		return $this->attributes['municipio_issqn'];
	}

	public function setMunicipioIssqnAttribute($municipioIssqn)
	{
		$this->attributes['municipio_issqn'] = $municipioIssqn;
	}

	public function getItemListaServicosAttribute()
	{
		return $this->attributes['item_lista_servicos'];
	}

	public function setItemListaServicosAttribute($itemListaServicos)
	{
		$this->attributes['item_lista_servicos'] = $itemListaServicos;
	}

	public function getValorDeducaoAttribute()
	{
		return (double)$this->attributes['valor_deducao'];
	}

	public function setValorDeducaoAttribute($valorDeducao)
	{
		$this->attributes['valor_deducao'] = $valorDeducao;
	}

	public function getValorOutrasRetencoesAttribute()
	{
		return (double)$this->attributes['valor_outras_retencoes'];
	}

	public function setValorOutrasRetencoesAttribute($valorOutrasRetencoes)
	{
		$this->attributes['valor_outras_retencoes'] = $valorOutrasRetencoes;
	}

	public function getValorDescontoIncondicionadoAttribute()
	{
		return (double)$this->attributes['valor_desconto_incondicionado'];
	}

	public function setValorDescontoIncondicionadoAttribute($valorDescontoIncondicionado)
	{
		$this->attributes['valor_desconto_incondicionado'] = $valorDescontoIncondicionado;
	}

	public function getValorDescontoCondicionadoAttribute()
	{
		return (double)$this->attributes['valor_desconto_condicionado'];
	}

	public function setValorDescontoCondicionadoAttribute($valorDescontoCondicionado)
	{
		$this->attributes['valor_desconto_condicionado'] = $valorDescontoCondicionado;
	}

	public function getValorRetencaoIssAttribute()
	{
		return (double)$this->attributes['valor_retencao_iss'];
	}

	public function setValorRetencaoIssAttribute($valorRetencaoIss)
	{
		$this->attributes['valor_retencao_iss'] = $valorRetencaoIss;
	}

	public function getIndicadorExigibilidadeIssAttribute()
	{
		return $this->attributes['indicador_exigibilidade_iss'];
	}

	public function setIndicadorExigibilidadeIssAttribute($indicadorExigibilidadeIss)
	{
		$this->attributes['indicador_exigibilidade_iss'] = $indicadorExigibilidadeIss;
	}

	public function getCodigoServicoAttribute()
	{
		return $this->attributes['codigo_servico'];
	}

	public function setCodigoServicoAttribute($codigoServico)
	{
		$this->attributes['codigo_servico'] = $codigoServico;
	}

	public function getMunicipioIncidenciaAttribute()
	{
		return $this->attributes['municipio_incidencia'];
	}

	public function setMunicipioIncidenciaAttribute($municipioIncidencia)
	{
		$this->attributes['municipio_incidencia'] = $municipioIncidencia;
	}

	public function getPaisSevicoPrestadoAttribute()
	{
		return $this->attributes['pais_sevico_prestado'];
	}

	public function setPaisSevicoPrestadoAttribute($paisSevicoPrestado)
	{
		$this->attributes['pais_sevico_prestado'] = $paisSevicoPrestado;
	}

	public function getNumeroProcessoAttribute()
	{
		return $this->attributes['numero_processo'];
	}

	public function setNumeroProcessoAttribute($numeroProcesso)
	{
		$this->attributes['numero_processo'] = $numeroProcesso;
	}

	public function getIndicadorIncentivoFiscalAttribute()
	{
		return $this->attributes['indicador_incentivo_fiscal'];
	}

	public function setIndicadorIncentivoFiscalAttribute($indicadorIncentivoFiscal)
	{
		$this->attributes['indicador_incentivo_fiscal'] = $indicadorIncentivoFiscal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setBaseCalculoIssqnAttribute($object->baseCalculoIssqn);
				$this->setAliquotaIssqnAttribute($object->aliquotaIssqn);
				$this->setValorIssqnAttribute($object->valorIssqn);
				$this->setMunicipioIssqnAttribute($object->municipioIssqn);
				$this->setItemListaServicosAttribute($object->itemListaServicos);
				$this->setValorDeducaoAttribute($object->valorDeducao);
				$this->setValorOutrasRetencoesAttribute($object->valorOutrasRetencoes);
				$this->setValorDescontoIncondicionadoAttribute($object->valorDescontoIncondicionado);
				$this->setValorDescontoCondicionadoAttribute($object->valorDescontoCondicionado);
				$this->setValorRetencaoIssAttribute($object->valorRetencaoIss);
				$this->setIndicadorExigibilidadeIssAttribute($object->indicadorExigibilidadeIss);
				$this->setCodigoServicoAttribute($object->codigoServico);
				$this->setMunicipioIncidenciaAttribute($object->municipioIncidencia);
				$this->setPaisSevicoPrestadoAttribute($object->paisSevicoPrestado);
				$this->setNumeroProcessoAttribute($object->numeroProcesso);
				$this->setIndicadorIncentivoFiscalAttribute($object->indicadorIncentivoFiscal);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'baseCalculoIssqn' => $this->getBaseCalculoIssqnAttribute(),
				'aliquotaIssqn' => $this->getAliquotaIssqnAttribute(),
				'valorIssqn' => $this->getValorIssqnAttribute(),
				'municipioIssqn' => $this->getMunicipioIssqnAttribute(),
				'itemListaServicos' => $this->getItemListaServicosAttribute(),
				'valorDeducao' => $this->getValorDeducaoAttribute(),
				'valorOutrasRetencoes' => $this->getValorOutrasRetencoesAttribute(),
				'valorDescontoIncondicionado' => $this->getValorDescontoIncondicionadoAttribute(),
				'valorDescontoCondicionado' => $this->getValorDescontoCondicionadoAttribute(),
				'valorRetencaoIss' => $this->getValorRetencaoIssAttribute(),
				'indicadorExigibilidadeIss' => $this->getIndicadorExigibilidadeIssAttribute(),
				'codigoServico' => $this->getCodigoServicoAttribute(),
				'municipioIncidencia' => $this->getMunicipioIncidenciaAttribute(),
				'paisSevicoPrestado' => $this->getPaisSevicoPrestadoAttribute(),
				'numeroProcesso' => $this->getNumeroProcessoAttribute(),
				'indicadorIncentivoFiscal' => $this->getIndicadorIncentivoFiscalAttribute(),
			];
	}
}