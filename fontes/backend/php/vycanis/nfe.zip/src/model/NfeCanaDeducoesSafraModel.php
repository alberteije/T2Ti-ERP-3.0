<?php
declare(strict_types=1);

class NfeCanaDeducoesSafraModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_cana_deducoes_safra';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCanaModel()
	{
		return $this->belongsTo(NfeCanaModel::class, 'id_nfe_cana', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDecricaoAttribute()
	{
		return $this->attributes['decricao'];
	}

	public function setDecricaoAttribute($decricao)
	{
		$this->attributes['decricao'] = $decricao;
	}

	public function getValorDeducaoAttribute()
	{
		return (double)$this->attributes['valor_deducao'];
	}

	public function setValorDeducaoAttribute($valorDeducao)
	{
		$this->attributes['valor_deducao'] = $valorDeducao;
	}

	public function getValorFornecimentoAttribute()
	{
		return (double)$this->attributes['valor_fornecimento'];
	}

	public function setValorFornecimentoAttribute($valorFornecimento)
	{
		$this->attributes['valor_fornecimento'] = $valorFornecimento;
	}

	public function getValorTotalDeducaoAttribute()
	{
		return (double)$this->attributes['valor_total_deducao'];
	}

	public function setValorTotalDeducaoAttribute($valorTotalDeducao)
	{
		$this->attributes['valor_total_deducao'] = $valorTotalDeducao;
	}

	public function getValorLiquidoFornecimentoAttribute()
	{
		return (double)$this->attributes['valor_liquido_fornecimento'];
	}

	public function setValorLiquidoFornecimentoAttribute($valorLiquidoFornecimento)
	{
		$this->attributes['valor_liquido_fornecimento'] = $valorLiquidoFornecimento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDecricaoAttribute($object->decricao);
				$this->setValorDeducaoAttribute($object->valorDeducao);
				$this->setValorFornecimentoAttribute($object->valorFornecimento);
				$this->setValorTotalDeducaoAttribute($object->valorTotalDeducao);
				$this->setValorLiquidoFornecimentoAttribute($object->valorLiquidoFornecimento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'decricao' => $this->getDecricaoAttribute(),
				'valorDeducao' => $this->getValorDeducaoAttribute(),
				'valorFornecimento' => $this->getValorFornecimentoAttribute(),
				'valorTotalDeducao' => $this->getValorTotalDeducaoAttribute(),
				'valorLiquidoFornecimento' => $this->getValorLiquidoFornecimentoAttribute(),
			];
	}
}