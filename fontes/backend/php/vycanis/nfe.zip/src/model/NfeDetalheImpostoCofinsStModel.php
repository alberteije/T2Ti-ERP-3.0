<?php
declare(strict_types=1);

class NfeDetalheImpostoCofinsStModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_cofins_st';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getBaseCalculoCofinsStAttribute()
	{
		return (double)$this->attributes['base_calculo_cofins_st'];
	}

	public function setBaseCalculoCofinsStAttribute($baseCalculoCofinsSt)
	{
		$this->attributes['base_calculo_cofins_st'] = $baseCalculoCofinsSt;
	}

	public function getAliquotaCofinsStPercentualAttribute()
	{
		return (double)$this->attributes['aliquota_cofins_st_percentual'];
	}

	public function setAliquotaCofinsStPercentualAttribute($aliquotaCofinsStPercentual)
	{
		$this->attributes['aliquota_cofins_st_percentual'] = $aliquotaCofinsStPercentual;
	}

	public function getQuantidadeVendidaCofinsStAttribute()
	{
		return (double)$this->attributes['quantidade_vendida_cofins_st'];
	}

	public function setQuantidadeVendidaCofinsStAttribute($quantidadeVendidaCofinsSt)
	{
		$this->attributes['quantidade_vendida_cofins_st'] = $quantidadeVendidaCofinsSt;
	}

	public function getAliquotaCofinsStReaisAttribute()
	{
		return (double)$this->attributes['aliquota_cofins_st_reais'];
	}

	public function setAliquotaCofinsStReaisAttribute($aliquotaCofinsStReais)
	{
		$this->attributes['aliquota_cofins_st_reais'] = $aliquotaCofinsStReais;
	}

	public function getValorCofinsStAttribute()
	{
		return (double)$this->attributes['valor_cofins_st'];
	}

	public function setValorCofinsStAttribute($valorCofinsSt)
	{
		$this->attributes['valor_cofins_st'] = $valorCofinsSt;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setBaseCalculoCofinsStAttribute($object->baseCalculoCofinsSt);
				$this->setAliquotaCofinsStPercentualAttribute($object->aliquotaCofinsStPercentual);
				$this->setQuantidadeVendidaCofinsStAttribute($object->quantidadeVendidaCofinsSt);
				$this->setAliquotaCofinsStReaisAttribute($object->aliquotaCofinsStReais);
				$this->setValorCofinsStAttribute($object->valorCofinsSt);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'baseCalculoCofinsSt' => $this->getBaseCalculoCofinsStAttribute(),
				'aliquotaCofinsStPercentual' => $this->getAliquotaCofinsStPercentualAttribute(),
				'quantidadeVendidaCofinsSt' => $this->getQuantidadeVendidaCofinsStAttribute(),
				'aliquotaCofinsStReais' => $this->getAliquotaCofinsStReaisAttribute(),
				'valorCofinsSt' => $this->getValorCofinsStAttribute(),
			];
	}
}