<?php
declare(strict_types=1);

class NfeTransporteReboqueModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_transporte_reboque';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeTransporteModel()
	{
		return $this->belongsTo(NfeTransporteModel::class, 'id_nfe_transporte', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getPlacaAttribute()
	{
		return $this->attributes['placa'];
	}

	public function setPlacaAttribute($placa)
	{
		$this->attributes['placa'] = $placa;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getRntcAttribute()
	{
		return $this->attributes['rntc'];
	}

	public function setRntcAttribute($rntc)
	{
		$this->attributes['rntc'] = $rntc;
	}

	public function getVagaoAttribute()
	{
		return $this->attributes['vagao'];
	}

	public function setVagaoAttribute($vagao)
	{
		$this->attributes['vagao'] = $vagao;
	}

	public function getBalsaAttribute()
	{
		return $this->attributes['balsa'];
	}

	public function setBalsaAttribute($balsa)
	{
		$this->attributes['balsa'] = $balsa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setPlacaAttribute($object->placa);
				$this->setUfAttribute($object->uf);
				$this->setRntcAttribute($object->rntc);
				$this->setVagaoAttribute($object->vagao);
				$this->setBalsaAttribute($object->balsa);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'placa' => $this->getPlacaAttribute(),
				'uf' => $this->getUfAttribute(),
				'rntc' => $this->getRntcAttribute(),
				'vagao' => $this->getVagaoAttribute(),
				'balsa' => $this->getBalsaAttribute(),
			];
	}
}