<?php
declare(strict_types=1);

class NfeResponsavelTecnicoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_responsavel_tecnico';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getContatoAttribute()
	{
		return $this->attributes['contato'];
	}

	public function setContatoAttribute($contato)
	{
		$this->attributes['contato'] = $contato;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getTelefoneAttribute()
	{
		return $this->attributes['telefone'];
	}

	public function setTelefoneAttribute($telefone)
	{
		$this->attributes['telefone'] = $telefone;
	}

	public function getIdentificadorCsrtAttribute()
	{
		return $this->attributes['identificador_csrt'];
	}

	public function setIdentificadorCsrtAttribute($identificadorCsrt)
	{
		$this->attributes['identificador_csrt'] = $identificadorCsrt;
	}

	public function getHashCsrtAttribute()
	{
		return $this->attributes['hash_csrt'];
	}

	public function setHashCsrtAttribute($hashCsrt)
	{
		$this->attributes['hash_csrt'] = $hashCsrt;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjAttribute($object->cnpj);
				$this->setContatoAttribute($object->contato);
				$this->setEmailAttribute($object->email);
				$this->setTelefoneAttribute($object->telefone);
				$this->setIdentificadorCsrtAttribute($object->identificadorCsrt);
				$this->setHashCsrtAttribute($object->hashCsrt);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'contato' => $this->getContatoAttribute(),
				'email' => $this->getEmailAttribute(),
				'telefone' => $this->getTelefoneAttribute(),
				'identificadorCsrt' => $this->getIdentificadorCsrtAttribute(),
				'hashCsrt' => $this->getHashCsrtAttribute(),
			];
	}
}