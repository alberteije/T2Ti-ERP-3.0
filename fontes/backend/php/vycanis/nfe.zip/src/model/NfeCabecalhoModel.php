<?php
declare(strict_types=1);

class NfeCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeEmitenteModel',
		'nfeDestinatarioModel',
		'nfeLocalRetiradaModel',
		'nfeLocalEntregaModel',
		'nfeResponsavelTecnicoModel',
		'nfeCanaModel',
		'nfeFaturaModel',
		'nfeTransporteModel',
		'nfeReferenciadaModelList',
		'nfeProdRuralReferenciadaModelList',
		'nfeNfReferenciadaModelList',
		'nfeProcessoReferenciadoModelList',
		'nfeAcessoXmlModelList',
		'nfeInformacaoPagamentoModelList',
		'tributOperacaoFiscalModel',
		'vendaCabecalhoModel',
		'viewPessoaClienteModel',
		'viewPessoaColaboradorModel',
		'viewPessoaFornecedorModel',
		'nfeCupomFiscalReferenciadoModelList',
		'nfeCteReferenciadoModelList',
		'nfeDetalheModelList',
	];

	/**
		* Relations
		*/
	public function nfeEmitenteModel()
	{
		return $this->hasOne(NfeEmitenteModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeDestinatarioModel()
	{
		return $this->hasOne(NfeDestinatarioModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeLocalRetiradaModel()
	{
		return $this->hasOne(NfeLocalRetiradaModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeLocalEntregaModel()
	{
		return $this->hasOne(NfeLocalEntregaModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeResponsavelTecnicoModel()
	{
		return $this->hasOne(NfeResponsavelTecnicoModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeCanaModel()
	{
		return $this->hasOne(NfeCanaModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeFaturaModel()
	{
		return $this->hasOne(NfeFaturaModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeTransporteModel()
	{
		return $this->hasOne(NfeTransporteModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeReferenciadaModelList()
{
	return $this->hasMany(NfeReferenciadaModel::class, 'id_nfe_cabecalho', 'id');
}

	public function nfeProdRuralReferenciadaModelList()
{
	return $this->hasMany(NfeProdRuralReferenciadaModel::class, 'id_nfe_cabecalho', 'id');
}

	public function nfeNfReferenciadaModelList()
{
	return $this->hasMany(NfeNfReferenciadaModel::class, 'id_nfe_cabecalho', 'id');
}

	public function nfeProcessoReferenciadoModelList()
{
	return $this->hasMany(NfeProcessoReferenciadoModel::class, 'id_nfe_cabecalho', 'id');
}

	public function nfeAcessoXmlModelList()
{
	return $this->hasMany(NfeAcessoXmlModel::class, 'id_nfe_cabecalho', 'id');
}

	public function nfeInformacaoPagamentoModelList()
{
	return $this->hasMany(NfeInformacaoPagamentoModel::class, 'id_nfe_cabecalho', 'id');
}

	public function tributOperacaoFiscalModel()
	{
		return $this->belongsTo(TributOperacaoFiscalModel::class, 'id_tribut_operacao_fiscal', 'id');
	}

	public function vendaCabecalhoModel()
	{
		return $this->belongsTo(VendaCabecalhoModel::class, 'id_venda_cabecalho', 'id');
	}

	public function viewPessoaClienteModel()
	{
		return $this->belongsTo(ViewPessoaClienteModel::class, 'id_cliente', 'id');
	}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function viewPessoaFornecedorModel()
	{
		return $this->belongsTo(ViewPessoaFornecedorModel::class, 'id_fornecedor', 'id');
	}

	public function nfeCupomFiscalReferenciadoModelList()
{
	return $this->hasMany(NfeCupomFiscalReferenciadoModel::class, 'id_nfe_cabecalho', 'id');
}

	public function nfeCteReferenciadoModelList()
	{
		return $this->hasMany(NfeCteReferenciadoModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function nfeDetalheModelList()
	{
		return $this->hasMany(NfeDetalheModel::class, 'id_nfe_cabecalho', 'id');
	}


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getUfEmitenteAttribute()
	{
		return $this->attributes['uf_emitente'];
	}

	public function setUfEmitenteAttribute($ufEmitente)
	{
		$this->attributes['uf_emitente'] = $ufEmitente;
	}

	public function getCodigoNumericoAttribute()
	{
		return $this->attributes['codigo_numerico'];
	}

	public function setCodigoNumericoAttribute($codigoNumerico)
	{
		$this->attributes['codigo_numerico'] = $codigoNumerico;
	}

	public function getNaturezaOperacaoAttribute()
	{
		return $this->attributes['natureza_operacao'];
	}

	public function setNaturezaOperacaoAttribute($naturezaOperacao)
	{
		$this->attributes['natureza_operacao'] = $naturezaOperacao;
	}

	public function getCodigoModeloAttribute()
	{
		return $this->attributes['codigo_modelo'];
	}

	public function setCodigoModeloAttribute($codigoModelo)
	{
		$this->attributes['codigo_modelo'] = $codigoModelo;
	}

	public function getSerieAttribute()
	{
		return $this->attributes['serie'];
	}

	public function setSerieAttribute($serie)
	{
		$this->attributes['serie'] = $serie;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataHoraEmissaoAttribute()
	{
		return $this->attributes['data_hora_emissao'];
	}

	public function setDataHoraEmissaoAttribute($dataHoraEmissao)
	{
		$this->attributes['data_hora_emissao'] = $dataHoraEmissao;
	}

	public function getDataHoraEntradaSaidaAttribute()
	{
		return $this->attributes['data_hora_entrada_saida'];
	}

	public function setDataHoraEntradaSaidaAttribute($dataHoraEntradaSaida)
	{
		$this->attributes['data_hora_entrada_saida'] = $dataHoraEntradaSaida;
	}

	public function getTipoOperacaoAttribute()
	{
		return $this->attributes['tipo_operacao'];
	}

	public function setTipoOperacaoAttribute($tipoOperacao)
	{
		$this->attributes['tipo_operacao'] = $tipoOperacao;
	}

	public function getLocalDestinoAttribute()
	{
		return $this->attributes['local_destino'];
	}

	public function setLocalDestinoAttribute($localDestino)
	{
		$this->attributes['local_destino'] = $localDestino;
	}

	public function getCodigoMunicipioAttribute()
	{
		return $this->attributes['codigo_municipio'];
	}

	public function setCodigoMunicipioAttribute($codigoMunicipio)
	{
		$this->attributes['codigo_municipio'] = $codigoMunicipio;
	}

	public function getFormatoImpressaoDanfeAttribute()
	{
		return $this->attributes['formato_impressao_danfe'];
	}

	public function setFormatoImpressaoDanfeAttribute($formatoImpressaoDanfe)
	{
		$this->attributes['formato_impressao_danfe'] = $formatoImpressaoDanfe;
	}

	public function getTipoEmissaoAttribute()
	{
		return $this->attributes['tipo_emissao'];
	}

	public function setTipoEmissaoAttribute($tipoEmissao)
	{
		$this->attributes['tipo_emissao'] = $tipoEmissao;
	}

	public function getChaveAcessoAttribute()
	{
		return $this->attributes['chave_acesso'];
	}

	public function setChaveAcessoAttribute($chaveAcesso)
	{
		$this->attributes['chave_acesso'] = $chaveAcesso;
	}

	public function getDigitoChaveAcessoAttribute()
	{
		return $this->attributes['digito_chave_acesso'];
	}

	public function setDigitoChaveAcessoAttribute($digitoChaveAcesso)
	{
		$this->attributes['digito_chave_acesso'] = $digitoChaveAcesso;
	}

	public function getAmbienteAttribute()
	{
		return $this->attributes['ambiente'];
	}

	public function setAmbienteAttribute($ambiente)
	{
		$this->attributes['ambiente'] = $ambiente;
	}

	public function getFinalidadeEmissaoAttribute()
	{
		return $this->attributes['finalidade_emissao'];
	}

	public function setFinalidadeEmissaoAttribute($finalidadeEmissao)
	{
		$this->attributes['finalidade_emissao'] = $finalidadeEmissao;
	}

	public function getConsumidorOperacaoAttribute()
	{
		return $this->attributes['consumidor_operacao'];
	}

	public function setConsumidorOperacaoAttribute($consumidorOperacao)
	{
		$this->attributes['consumidor_operacao'] = $consumidorOperacao;
	}

	public function getConsumidorPresencaAttribute()
	{
		return $this->attributes['consumidor_presenca'];
	}

	public function setConsumidorPresencaAttribute($consumidorPresenca)
	{
		$this->attributes['consumidor_presenca'] = $consumidorPresenca;
	}

	public function getIndicadorIntermediarioAttribute()
	{
		return $this->attributes['indicador_intermediario'];
	}

	public function setIndicadorIntermediarioAttribute($indicadorIntermediario)
	{
		$this->attributes['indicador_intermediario'] = $indicadorIntermediario;
	}

	public function getProcessoEmissaoAttribute()
	{
		return $this->attributes['processo_emissao'];
	}

	public function setProcessoEmissaoAttribute($processoEmissao)
	{
		$this->attributes['processo_emissao'] = $processoEmissao;
	}

	public function getVersaoProcessoEmissaoAttribute()
	{
		return $this->attributes['versao_processo_emissao'];
	}

	public function setVersaoProcessoEmissaoAttribute($versaoProcessoEmissao)
	{
		$this->attributes['versao_processo_emissao'] = $versaoProcessoEmissao;
	}

	public function getDataEntradaContingenciaAttribute()
	{
		return $this->attributes['data_entrada_contingencia'];
	}

	public function setDataEntradaContingenciaAttribute($dataEntradaContingencia)
	{
		$this->attributes['data_entrada_contingencia'] = $dataEntradaContingencia;
	}

	public function getJustificativaContingenciaAttribute()
	{
		return $this->attributes['justificativa_contingencia'];
	}

	public function setJustificativaContingenciaAttribute($justificativaContingencia)
	{
		$this->attributes['justificativa_contingencia'] = $justificativaContingencia;
	}

	public function getBaseCalculoIcmsAttribute()
	{
		return (double)$this->attributes['base_calculo_icms'];
	}

	public function setBaseCalculoIcmsAttribute($baseCalculoIcms)
	{
		$this->attributes['base_calculo_icms'] = $baseCalculoIcms;
	}

	public function getValorIcmsAttribute()
	{
		return (double)$this->attributes['valor_icms'];
	}

	public function setValorIcmsAttribute($valorIcms)
	{
		$this->attributes['valor_icms'] = $valorIcms;
	}

	public function getValorIcmsDesoneradoAttribute()
	{
		return (double)$this->attributes['valor_icms_desonerado'];
	}

	public function setValorIcmsDesoneradoAttribute($valorIcmsDesonerado)
	{
		$this->attributes['valor_icms_desonerado'] = $valorIcmsDesonerado;
	}

	public function getTotalIcmsFcpUfDestinoAttribute()
	{
		return (double)$this->attributes['total_icms_fcp_uf_destino'];
	}

	public function setTotalIcmsFcpUfDestinoAttribute($totalIcmsFcpUfDestino)
	{
		$this->attributes['total_icms_fcp_uf_destino'] = $totalIcmsFcpUfDestino;
	}

	public function getTotalIcmsInterestadualUfDestinoAttribute()
	{
		return (double)$this->attributes['total_icms_interestadual_uf_destino'];
	}

	public function setTotalIcmsInterestadualUfDestinoAttribute($totalIcmsInterestadualUfDestino)
	{
		$this->attributes['total_icms_interestadual_uf_destino'] = $totalIcmsInterestadualUfDestino;
	}

	public function getTotalIcmsInterestadualUfRemetenteAttribute()
	{
		return (double)$this->attributes['total_icms_interestadual_uf_remetente'];
	}

	public function setTotalIcmsInterestadualUfRemetenteAttribute($totalIcmsInterestadualUfRemetente)
	{
		$this->attributes['total_icms_interestadual_uf_remetente'] = $totalIcmsInterestadualUfRemetente;
	}

	public function getValorTotalFcpAttribute()
	{
		return (double)$this->attributes['valor_total_fcp'];
	}

	public function setValorTotalFcpAttribute($valorTotalFcp)
	{
		$this->attributes['valor_total_fcp'] = $valorTotalFcp;
	}

	public function getBaseCalculoIcmsStAttribute()
	{
		return (double)$this->attributes['base_calculo_icms_st'];
	}

	public function setBaseCalculoIcmsStAttribute($baseCalculoIcmsSt)
	{
		$this->attributes['base_calculo_icms_st'] = $baseCalculoIcmsSt;
	}

	public function getValorIcmsStAttribute()
	{
		return (double)$this->attributes['valor_icms_st'];
	}

	public function setValorIcmsStAttribute($valorIcmsSt)
	{
		$this->attributes['valor_icms_st'] = $valorIcmsSt;
	}

	public function getValorTotalFcpStAttribute()
	{
		return (double)$this->attributes['valor_total_fcp_st'];
	}

	public function setValorTotalFcpStAttribute($valorTotalFcpSt)
	{
		$this->attributes['valor_total_fcp_st'] = $valorTotalFcpSt;
	}

	public function getValorTotalFcpStRetidoAttribute()
	{
		return (double)$this->attributes['valor_total_fcp_st_retido'];
	}

	public function setValorTotalFcpStRetidoAttribute($valorTotalFcpStRetido)
	{
		$this->attributes['valor_total_fcp_st_retido'] = $valorTotalFcpStRetido;
	}

	public function getValorTotalProdutosAttribute()
	{
		return (double)$this->attributes['valor_total_produtos'];
	}

	public function setValorTotalProdutosAttribute($valorTotalProdutos)
	{
		$this->attributes['valor_total_produtos'] = $valorTotalProdutos;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	public function getValorSeguroAttribute()
	{
		return (double)$this->attributes['valor_seguro'];
	}

	public function setValorSeguroAttribute($valorSeguro)
	{
		$this->attributes['valor_seguro'] = $valorSeguro;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorImpostoImportacaoAttribute()
	{
		return (double)$this->attributes['valor_imposto_importacao'];
	}

	public function setValorImpostoImportacaoAttribute($valorImpostoImportacao)
	{
		$this->attributes['valor_imposto_importacao'] = $valorImpostoImportacao;
	}

	public function getValorIpiAttribute()
	{
		return (double)$this->attributes['valor_ipi'];
	}

	public function setValorIpiAttribute($valorIpi)
	{
		$this->attributes['valor_ipi'] = $valorIpi;
	}

	public function getValorIpiDevolvidoAttribute()
	{
		return (double)$this->attributes['valor_ipi_devolvido'];
	}

	public function setValorIpiDevolvidoAttribute($valorIpiDevolvido)
	{
		$this->attributes['valor_ipi_devolvido'] = $valorIpiDevolvido;
	}

	public function getValorPisAttribute()
	{
		return (double)$this->attributes['valor_pis'];
	}

	public function setValorPisAttribute($valorPis)
	{
		$this->attributes['valor_pis'] = $valorPis;
	}

	public function getValorCofinsAttribute()
	{
		return (double)$this->attributes['valor_cofins'];
	}

	public function setValorCofinsAttribute($valorCofins)
	{
		$this->attributes['valor_cofins'] = $valorCofins;
	}

	public function getValorDespesasAcessoriasAttribute()
	{
		return (double)$this->attributes['valor_despesas_acessorias'];
	}

	public function setValorDespesasAcessoriasAttribute($valorDespesasAcessorias)
	{
		$this->attributes['valor_despesas_acessorias'] = $valorDespesasAcessorias;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getValorTotalTributosAttribute()
	{
		return (double)$this->attributes['valor_total_tributos'];
	}

	public function setValorTotalTributosAttribute($valorTotalTributos)
	{
		$this->attributes['valor_total_tributos'] = $valorTotalTributos;
	}

	public function getValorServicosAttribute()
	{
		return (double)$this->attributes['valor_servicos'];
	}

	public function setValorServicosAttribute($valorServicos)
	{
		$this->attributes['valor_servicos'] = $valorServicos;
	}

	public function getBaseCalculoIssqnAttribute()
	{
		return (double)$this->attributes['base_calculo_issqn'];
	}

	public function setBaseCalculoIssqnAttribute($baseCalculoIssqn)
	{
		$this->attributes['base_calculo_issqn'] = $baseCalculoIssqn;
	}

	public function getValorIssqnAttribute()
	{
		return (double)$this->attributes['valor_issqn'];
	}

	public function setValorIssqnAttribute($valorIssqn)
	{
		$this->attributes['valor_issqn'] = $valorIssqn;
	}

	public function getValorPisIssqnAttribute()
	{
		return (double)$this->attributes['valor_pis_issqn'];
	}

	public function setValorPisIssqnAttribute($valorPisIssqn)
	{
		$this->attributes['valor_pis_issqn'] = $valorPisIssqn;
	}

	public function getValorCofinsIssqnAttribute()
	{
		return (double)$this->attributes['valor_cofins_issqn'];
	}

	public function setValorCofinsIssqnAttribute($valorCofinsIssqn)
	{
		$this->attributes['valor_cofins_issqn'] = $valorCofinsIssqn;
	}

	public function getDataPrestacaoServicoAttribute()
	{
		return $this->attributes['data_prestacao_servico'];
	}

	public function setDataPrestacaoServicoAttribute($dataPrestacaoServico)
	{
		$this->attributes['data_prestacao_servico'] = $dataPrestacaoServico;
	}

	public function getValorDeducaoIssqnAttribute()
	{
		return (double)$this->attributes['valor_deducao_issqn'];
	}

	public function setValorDeducaoIssqnAttribute($valorDeducaoIssqn)
	{
		$this->attributes['valor_deducao_issqn'] = $valorDeducaoIssqn;
	}

	public function getOutrasRetencoesIssqnAttribute()
	{
		return (double)$this->attributes['outras_retencoes_issqn'];
	}

	public function setOutrasRetencoesIssqnAttribute($outrasRetencoesIssqn)
	{
		$this->attributes['outras_retencoes_issqn'] = $outrasRetencoesIssqn;
	}

	public function getDescontoIncondicionadoIssqnAttribute()
	{
		return (double)$this->attributes['desconto_incondicionado_issqn'];
	}

	public function setDescontoIncondicionadoIssqnAttribute($descontoIncondicionadoIssqn)
	{
		$this->attributes['desconto_incondicionado_issqn'] = $descontoIncondicionadoIssqn;
	}

	public function getDescontoCondicionadoIssqnAttribute()
	{
		return (double)$this->attributes['desconto_condicionado_issqn'];
	}

	public function setDescontoCondicionadoIssqnAttribute($descontoCondicionadoIssqn)
	{
		$this->attributes['desconto_condicionado_issqn'] = $descontoCondicionadoIssqn;
	}

	public function getTotalRetencaoIssqnAttribute()
	{
		return (double)$this->attributes['total_retencao_issqn'];
	}

	public function setTotalRetencaoIssqnAttribute($totalRetencaoIssqn)
	{
		$this->attributes['total_retencao_issqn'] = $totalRetencaoIssqn;
	}

	public function getRegimeEspecialTributacaoAttribute()
	{
		return $this->attributes['regime_especial_tributacao'];
	}

	public function setRegimeEspecialTributacaoAttribute($regimeEspecialTributacao)
	{
		$this->attributes['regime_especial_tributacao'] = $regimeEspecialTributacao;
	}

	public function getValorRetidoPisAttribute()
	{
		return (double)$this->attributes['valor_retido_pis'];
	}

	public function setValorRetidoPisAttribute($valorRetidoPis)
	{
		$this->attributes['valor_retido_pis'] = $valorRetidoPis;
	}

	public function getValorRetidoCofinsAttribute()
	{
		return (double)$this->attributes['valor_retido_cofins'];
	}

	public function setValorRetidoCofinsAttribute($valorRetidoCofins)
	{
		$this->attributes['valor_retido_cofins'] = $valorRetidoCofins;
	}

	public function getValorRetidoCsllAttribute()
	{
		return (double)$this->attributes['valor_retido_csll'];
	}

	public function setValorRetidoCsllAttribute($valorRetidoCsll)
	{
		$this->attributes['valor_retido_csll'] = $valorRetidoCsll;
	}

	public function getBaseCalculoIrrfAttribute()
	{
		return (double)$this->attributes['base_calculo_irrf'];
	}

	public function setBaseCalculoIrrfAttribute($baseCalculoIrrf)
	{
		$this->attributes['base_calculo_irrf'] = $baseCalculoIrrf;
	}

	public function getValorRetidoIrrfAttribute()
	{
		return (double)$this->attributes['valor_retido_irrf'];
	}

	public function setValorRetidoIrrfAttribute($valorRetidoIrrf)
	{
		$this->attributes['valor_retido_irrf'] = $valorRetidoIrrf;
	}

	public function getBaseCalculoPrevidenciaAttribute()
	{
		return (double)$this->attributes['base_calculo_previdencia'];
	}

	public function setBaseCalculoPrevidenciaAttribute($baseCalculoPrevidencia)
	{
		$this->attributes['base_calculo_previdencia'] = $baseCalculoPrevidencia;
	}

	public function getValorRetidoPrevidenciaAttribute()
	{
		return (double)$this->attributes['valor_retido_previdencia'];
	}

	public function setValorRetidoPrevidenciaAttribute($valorRetidoPrevidencia)
	{
		$this->attributes['valor_retido_previdencia'] = $valorRetidoPrevidencia;
	}

	public function getInformacoesAddFiscoAttribute()
	{
		return $this->attributes['informacoes_add_fisco'];
	}

	public function setInformacoesAddFiscoAttribute($informacoesAddFisco)
	{
		$this->attributes['informacoes_add_fisco'] = $informacoesAddFisco;
	}

	public function getInformacoesAddContribuinteAttribute()
	{
		return $this->attributes['informacoes_add_contribuinte'];
	}

	public function setInformacoesAddContribuinteAttribute($informacoesAddContribuinte)
	{
		$this->attributes['informacoes_add_contribuinte'] = $informacoesAddContribuinte;
	}

	public function getComexUfEmbarqueAttribute()
	{
		return $this->attributes['comex_uf_embarque'];
	}

	public function setComexUfEmbarqueAttribute($comexUfEmbarque)
	{
		$this->attributes['comex_uf_embarque'] = $comexUfEmbarque;
	}

	public function getComexLocalEmbarqueAttribute()
	{
		return $this->attributes['comex_local_embarque'];
	}

	public function setComexLocalEmbarqueAttribute($comexLocalEmbarque)
	{
		$this->attributes['comex_local_embarque'] = $comexLocalEmbarque;
	}

	public function getComexLocalDespachoAttribute()
	{
		return $this->attributes['comex_local_despacho'];
	}

	public function setComexLocalDespachoAttribute($comexLocalDespacho)
	{
		$this->attributes['comex_local_despacho'] = $comexLocalDespacho;
	}

	public function getCompraNotaEmpenhoAttribute()
	{
		return $this->attributes['compra_nota_empenho'];
	}

	public function setCompraNotaEmpenhoAttribute($compraNotaEmpenho)
	{
		$this->attributes['compra_nota_empenho'] = $compraNotaEmpenho;
	}

	public function getCompraPedidoAttribute()
	{
		return $this->attributes['compra_pedido'];
	}

	public function setCompraPedidoAttribute($compraPedido)
	{
		$this->attributes['compra_pedido'] = $compraPedido;
	}

	public function getCompraContratoAttribute()
	{
		return $this->attributes['compra_contrato'];
	}

	public function setCompraContratoAttribute($compraContrato)
	{
		$this->attributes['compra_contrato'] = $compraContrato;
	}

	public function getQrcodeAttribute()
	{
		return $this->attributes['qrcode'];
	}

	public function setQrcodeAttribute($qrcode)
	{
		$this->attributes['qrcode'] = $qrcode;
	}

	public function getUrlChaveAttribute()
	{
		return $this->attributes['url_chave'];
	}

	public function setUrlChaveAttribute($urlChave)
	{
		$this->attributes['url_chave'] = $urlChave;
	}

	public function getStatusNotaAttribute()
	{
		return $this->attributes['status_nota'];
	}

	public function setStatusNotaAttribute($statusNota)
	{
		$this->attributes['status_nota'] = $statusNota;
	}

	public function getIntermediadorCnpjAttribute()
	{
		return $this->attributes['intermediador_cnpj'];
	}

	public function setIntermediadorCnpjAttribute($intermediadorCnpj)
	{
		$this->attributes['intermediador_cnpj'] = $intermediadorCnpj;
	}

	public function getIntermediadorIdCadastroAttribute()
	{
		return $this->attributes['intermediador_id_cadastro'];
	}

	public function setIntermediadorIdCadastroAttribute($intermediadorIdCadastro)
	{
		$this->attributes['intermediador_id_cadastro'] = $intermediadorIdCadastro;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setUfEmitenteAttribute($object->ufEmitente);
				$this->setCodigoNumericoAttribute($object->codigoNumerico);
				$this->setNaturezaOperacaoAttribute($object->naturezaOperacao);
				$this->setCodigoModeloAttribute($object->codigoModelo);
				$this->setSerieAttribute($object->serie);
				$this->setNumeroAttribute($object->numero);
				$this->setDataHoraEmissaoAttribute($object->dataHoraEmissao);
				$this->setDataHoraEntradaSaidaAttribute($object->dataHoraEntradaSaida);
				$this->setTipoOperacaoAttribute($object->tipoOperacao);
				$this->setLocalDestinoAttribute($object->localDestino);
				$this->setCodigoMunicipioAttribute($object->codigoMunicipio);
				$this->setFormatoImpressaoDanfeAttribute($object->formatoImpressaoDanfe);
				$this->setTipoEmissaoAttribute($object->tipoEmissao);
				$this->setChaveAcessoAttribute($object->chaveAcesso);
				$this->setDigitoChaveAcessoAttribute($object->digitoChaveAcesso);
				$this->setAmbienteAttribute($object->ambiente);
				$this->setFinalidadeEmissaoAttribute($object->finalidadeEmissao);
				$this->setConsumidorOperacaoAttribute($object->consumidorOperacao);
				$this->setConsumidorPresencaAttribute($object->consumidorPresenca);
				$this->setIndicadorIntermediarioAttribute($object->indicadorIntermediario);
				$this->setProcessoEmissaoAttribute($object->processoEmissao);
				$this->setVersaoProcessoEmissaoAttribute($object->versaoProcessoEmissao);
				$this->setDataEntradaContingenciaAttribute($object->dataEntradaContingencia);
				$this->setJustificativaContingenciaAttribute($object->justificativaContingencia);
				$this->setBaseCalculoIcmsAttribute($object->baseCalculoIcms);
				$this->setValorIcmsAttribute($object->valorIcms);
				$this->setValorIcmsDesoneradoAttribute($object->valorIcmsDesonerado);
				$this->setTotalIcmsFcpUfDestinoAttribute($object->totalIcmsFcpUfDestino);
				$this->setTotalIcmsInterestadualUfDestinoAttribute($object->totalIcmsInterestadualUfDestino);
				$this->setTotalIcmsInterestadualUfRemetenteAttribute($object->totalIcmsInterestadualUfRemetente);
				$this->setValorTotalFcpAttribute($object->valorTotalFcp);
				$this->setBaseCalculoIcmsStAttribute($object->baseCalculoIcmsSt);
				$this->setValorIcmsStAttribute($object->valorIcmsSt);
				$this->setValorTotalFcpStAttribute($object->valorTotalFcpSt);
				$this->setValorTotalFcpStRetidoAttribute($object->valorTotalFcpStRetido);
				$this->setValorTotalProdutosAttribute($object->valorTotalProdutos);
				$this->setValorFreteAttribute($object->valorFrete);
				$this->setValorSeguroAttribute($object->valorSeguro);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorImpostoImportacaoAttribute($object->valorImpostoImportacao);
				$this->setValorIpiAttribute($object->valorIpi);
				$this->setValorIpiDevolvidoAttribute($object->valorIpiDevolvido);
				$this->setValorPisAttribute($object->valorPis);
				$this->setValorCofinsAttribute($object->valorCofins);
				$this->setValorDespesasAcessoriasAttribute($object->valorDespesasAcessorias);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setValorTotalTributosAttribute($object->valorTotalTributos);
				$this->setValorServicosAttribute($object->valorServicos);
				$this->setBaseCalculoIssqnAttribute($object->baseCalculoIssqn);
				$this->setValorIssqnAttribute($object->valorIssqn);
				$this->setValorPisIssqnAttribute($object->valorPisIssqn);
				$this->setValorCofinsIssqnAttribute($object->valorCofinsIssqn);
				$this->setDataPrestacaoServicoAttribute($object->dataPrestacaoServico);
				$this->setValorDeducaoIssqnAttribute($object->valorDeducaoIssqn);
				$this->setOutrasRetencoesIssqnAttribute($object->outrasRetencoesIssqn);
				$this->setDescontoIncondicionadoIssqnAttribute($object->descontoIncondicionadoIssqn);
				$this->setDescontoCondicionadoIssqnAttribute($object->descontoCondicionadoIssqn);
				$this->setTotalRetencaoIssqnAttribute($object->totalRetencaoIssqn);
				$this->setRegimeEspecialTributacaoAttribute($object->regimeEspecialTributacao);
				$this->setValorRetidoPisAttribute($object->valorRetidoPis);
				$this->setValorRetidoCofinsAttribute($object->valorRetidoCofins);
				$this->setValorRetidoCsllAttribute($object->valorRetidoCsll);
				$this->setBaseCalculoIrrfAttribute($object->baseCalculoIrrf);
				$this->setValorRetidoIrrfAttribute($object->valorRetidoIrrf);
				$this->setBaseCalculoPrevidenciaAttribute($object->baseCalculoPrevidencia);
				$this->setValorRetidoPrevidenciaAttribute($object->valorRetidoPrevidencia);
				$this->setInformacoesAddFiscoAttribute($object->informacoesAddFisco);
				$this->setInformacoesAddContribuinteAttribute($object->informacoesAddContribuinte);
				$this->setComexUfEmbarqueAttribute($object->comexUfEmbarque);
				$this->setComexLocalEmbarqueAttribute($object->comexLocalEmbarque);
				$this->setComexLocalDespachoAttribute($object->comexLocalDespacho);
				$this->setCompraNotaEmpenhoAttribute($object->compraNotaEmpenho);
				$this->setCompraPedidoAttribute($object->compraPedido);
				$this->setCompraContratoAttribute($object->compraContrato);
				$this->setQrcodeAttribute($object->qrcode);
				$this->setUrlChaveAttribute($object->urlChave);
				$this->setStatusNotaAttribute($object->statusNota);
				$this->setIntermediadorCnpjAttribute($object->intermediadorCnpj);
				$this->setIntermediadorIdCadastroAttribute($object->intermediadorIdCadastro);

				// link objects - lookups
				$tributOperacaoFiscalModel = new TributOperacaoFiscalModel();
				$tributOperacaoFiscalModel->mapping($object->tributOperacaoFiscalModel);
				$this->tributOperacaoFiscalModel()->associate($tributOperacaoFiscalModel);
				$vendaCabecalhoModel = new VendaCabecalhoModel();
				$vendaCabecalhoModel->mapping($object->vendaCabecalhoModel);
				$this->vendaCabecalhoModel()->associate($vendaCabecalhoModel);
				$viewPessoaClienteModel = new ViewPessoaClienteModel();
				$viewPessoaClienteModel->mapping($object->viewPessoaClienteModel);
				$this->viewPessoaClienteModel()->associate($viewPessoaClienteModel);
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$viewPessoaFornecedorModel = new ViewPessoaFornecedorModel();
				$viewPessoaFornecedorModel->mapping($object->viewPessoaFornecedorModel);
				$this->viewPessoaFornecedorModel()->associate($viewPessoaFornecedorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ufEmitente' => $this->getUfEmitenteAttribute(),
				'codigoNumerico' => $this->getCodigoNumericoAttribute(),
				'naturezaOperacao' => $this->getNaturezaOperacaoAttribute(),
				'codigoModelo' => $this->getCodigoModeloAttribute(),
				'serie' => $this->getSerieAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataHoraEmissao' => $this->getDataHoraEmissaoAttribute(),
				'dataHoraEntradaSaida' => $this->getDataHoraEntradaSaidaAttribute(),
				'tipoOperacao' => $this->getTipoOperacaoAttribute(),
				'localDestino' => $this->getLocalDestinoAttribute(),
				'codigoMunicipio' => $this->getCodigoMunicipioAttribute(),
				'formatoImpressaoDanfe' => $this->getFormatoImpressaoDanfeAttribute(),
				'tipoEmissao' => $this->getTipoEmissaoAttribute(),
				'chaveAcesso' => $this->getChaveAcessoAttribute(),
				'digitoChaveAcesso' => $this->getDigitoChaveAcessoAttribute(),
				'ambiente' => $this->getAmbienteAttribute(),
				'finalidadeEmissao' => $this->getFinalidadeEmissaoAttribute(),
				'consumidorOperacao' => $this->getConsumidorOperacaoAttribute(),
				'consumidorPresenca' => $this->getConsumidorPresencaAttribute(),
				'indicadorIntermediario' => $this->getIndicadorIntermediarioAttribute(),
				'processoEmissao' => $this->getProcessoEmissaoAttribute(),
				'versaoProcessoEmissao' => $this->getVersaoProcessoEmissaoAttribute(),
				'dataEntradaContingencia' => $this->getDataEntradaContingenciaAttribute(),
				'justificativaContingencia' => $this->getJustificativaContingenciaAttribute(),
				'baseCalculoIcms' => $this->getBaseCalculoIcmsAttribute(),
				'valorIcms' => $this->getValorIcmsAttribute(),
				'valorIcmsDesonerado' => $this->getValorIcmsDesoneradoAttribute(),
				'totalIcmsFcpUfDestino' => $this->getTotalIcmsFcpUfDestinoAttribute(),
				'totalIcmsInterestadualUfDestino' => $this->getTotalIcmsInterestadualUfDestinoAttribute(),
				'totalIcmsInterestadualUfRemetente' => $this->getTotalIcmsInterestadualUfRemetenteAttribute(),
				'valorTotalFcp' => $this->getValorTotalFcpAttribute(),
				'baseCalculoIcmsSt' => $this->getBaseCalculoIcmsStAttribute(),
				'valorIcmsSt' => $this->getValorIcmsStAttribute(),
				'valorTotalFcpSt' => $this->getValorTotalFcpStAttribute(),
				'valorTotalFcpStRetido' => $this->getValorTotalFcpStRetidoAttribute(),
				'valorTotalProdutos' => $this->getValorTotalProdutosAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
				'valorSeguro' => $this->getValorSeguroAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorImpostoImportacao' => $this->getValorImpostoImportacaoAttribute(),
				'valorIpi' => $this->getValorIpiAttribute(),
				'valorIpiDevolvido' => $this->getValorIpiDevolvidoAttribute(),
				'valorPis' => $this->getValorPisAttribute(),
				'valorCofins' => $this->getValorCofinsAttribute(),
				'valorDespesasAcessorias' => $this->getValorDespesasAcessoriasAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'valorTotalTributos' => $this->getValorTotalTributosAttribute(),
				'valorServicos' => $this->getValorServicosAttribute(),
				'baseCalculoIssqn' => $this->getBaseCalculoIssqnAttribute(),
				'valorIssqn' => $this->getValorIssqnAttribute(),
				'valorPisIssqn' => $this->getValorPisIssqnAttribute(),
				'valorCofinsIssqn' => $this->getValorCofinsIssqnAttribute(),
				'dataPrestacaoServico' => $this->getDataPrestacaoServicoAttribute(),
				'valorDeducaoIssqn' => $this->getValorDeducaoIssqnAttribute(),
				'outrasRetencoesIssqn' => $this->getOutrasRetencoesIssqnAttribute(),
				'descontoIncondicionadoIssqn' => $this->getDescontoIncondicionadoIssqnAttribute(),
				'descontoCondicionadoIssqn' => $this->getDescontoCondicionadoIssqnAttribute(),
				'totalRetencaoIssqn' => $this->getTotalRetencaoIssqnAttribute(),
				'regimeEspecialTributacao' => $this->getRegimeEspecialTributacaoAttribute(),
				'valorRetidoPis' => $this->getValorRetidoPisAttribute(),
				'valorRetidoCofins' => $this->getValorRetidoCofinsAttribute(),
				'valorRetidoCsll' => $this->getValorRetidoCsllAttribute(),
				'baseCalculoIrrf' => $this->getBaseCalculoIrrfAttribute(),
				'valorRetidoIrrf' => $this->getValorRetidoIrrfAttribute(),
				'baseCalculoPrevidencia' => $this->getBaseCalculoPrevidenciaAttribute(),
				'valorRetidoPrevidencia' => $this->getValorRetidoPrevidenciaAttribute(),
				'informacoesAddFisco' => $this->getInformacoesAddFiscoAttribute(),
				'informacoesAddContribuinte' => $this->getInformacoesAddContribuinteAttribute(),
				'comexUfEmbarque' => $this->getComexUfEmbarqueAttribute(),
				'comexLocalEmbarque' => $this->getComexLocalEmbarqueAttribute(),
				'comexLocalDespacho' => $this->getComexLocalDespachoAttribute(),
				'compraNotaEmpenho' => $this->getCompraNotaEmpenhoAttribute(),
				'compraPedido' => $this->getCompraPedidoAttribute(),
				'compraContrato' => $this->getCompraContratoAttribute(),
				'qrcode' => $this->getQrcodeAttribute(),
				'urlChave' => $this->getUrlChaveAttribute(),
				'statusNota' => $this->getStatusNotaAttribute(),
				'intermediadorCnpj' => $this->getIntermediadorCnpjAttribute(),
				'intermediadorIdCadastro' => $this->getIntermediadorIdCadastroAttribute(),
				'nfeEmitenteModel' => $this->nfeEmitenteModel,
				'nfeDestinatarioModel' => $this->nfeDestinatarioModel,
				'nfeLocalRetiradaModel' => $this->nfeLocalRetiradaModel,
				'nfeLocalEntregaModel' => $this->nfeLocalEntregaModel,
				'nfeResponsavelTecnicoModel' => $this->nfeResponsavelTecnicoModel,
				'nfeCanaModel' => $this->nfeCanaModel,
				'nfeFaturaModel' => $this->nfeFaturaModel,
				'nfeTransporteModel' => $this->nfeTransporteModel,
				'nfeReferenciadaModelList' => $this->nfeReferenciadaModelList,
				'nfeProdRuralReferenciadaModelList' => $this->nfeProdRuralReferenciadaModelList,
				'nfeNfReferenciadaModelList' => $this->nfeNfReferenciadaModelList,
				'nfeProcessoReferenciadoModelList' => $this->nfeProcessoReferenciadoModelList,
				'nfeAcessoXmlModelList' => $this->nfeAcessoXmlModelList,
				'nfeInformacaoPagamentoModelList' => $this->nfeInformacaoPagamentoModelList,
				'tributOperacaoFiscalModel' => $this->tributOperacaoFiscalModel,
				'vendaCabecalhoModel' => $this->vendaCabecalhoModel,
				'viewPessoaClienteModel' => $this->viewPessoaClienteModel,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'viewPessoaFornecedorModel' => $this->viewPessoaFornecedorModel,
				'nfeCupomFiscalReferenciadoModelList' => $this->nfeCupomFiscalReferenciadoModelList,
				'nfeCteReferenciadoModelList' => $this->nfeCteReferenciadoModelList,
				'nfeDetalheModelList' => $this->nfeDetalheModelList,
			];
	}
}