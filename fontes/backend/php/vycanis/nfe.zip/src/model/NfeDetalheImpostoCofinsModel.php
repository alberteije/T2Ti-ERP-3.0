<?php
declare(strict_types=1);

class NfeDetalheImpostoCofinsModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_cofins';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCstCofinsAttribute()
	{
		return $this->attributes['cst_cofins'];
	}

	public function setCstCofinsAttribute($cstCofins)
	{
		$this->attributes['cst_cofins'] = $cstCofins;
	}

	public function getBaseCalculoCofinsAttribute()
	{
		return (double)$this->attributes['base_calculo_cofins'];
	}

	public function setBaseCalculoCofinsAttribute($baseCalculoCofins)
	{
		$this->attributes['base_calculo_cofins'] = $baseCalculoCofins;
	}

	public function getAliquotaCofinsPercentualAttribute()
	{
		return (double)$this->attributes['aliquota_cofins_percentual'];
	}

	public function setAliquotaCofinsPercentualAttribute($aliquotaCofinsPercentual)
	{
		$this->attributes['aliquota_cofins_percentual'] = $aliquotaCofinsPercentual;
	}

	public function getQuantidadeVendidaAttribute()
	{
		return (double)$this->attributes['quantidade_vendida'];
	}

	public function setQuantidadeVendidaAttribute($quantidadeVendida)
	{
		$this->attributes['quantidade_vendida'] = $quantidadeVendida;
	}

	public function getAliquotaCofinsReaisAttribute()
	{
		return (double)$this->attributes['aliquota_cofins_reais'];
	}

	public function setAliquotaCofinsReaisAttribute($aliquotaCofinsReais)
	{
		$this->attributes['aliquota_cofins_reais'] = $aliquotaCofinsReais;
	}

	public function getValorCofinsAttribute()
	{
		return (double)$this->attributes['valor_cofins'];
	}

	public function setValorCofinsAttribute($valorCofins)
	{
		$this->attributes['valor_cofins'] = $valorCofins;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCstCofinsAttribute($object->cstCofins);
				$this->setBaseCalculoCofinsAttribute($object->baseCalculoCofins);
				$this->setAliquotaCofinsPercentualAttribute($object->aliquotaCofinsPercentual);
				$this->setQuantidadeVendidaAttribute($object->quantidadeVendida);
				$this->setAliquotaCofinsReaisAttribute($object->aliquotaCofinsReais);
				$this->setValorCofinsAttribute($object->valorCofins);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cstCofins' => $this->getCstCofinsAttribute(),
				'baseCalculoCofins' => $this->getBaseCalculoCofinsAttribute(),
				'aliquotaCofinsPercentual' => $this->getAliquotaCofinsPercentualAttribute(),
				'quantidadeVendida' => $this->getQuantidadeVendidaAttribute(),
				'aliquotaCofinsReais' => $this->getAliquotaCofinsReaisAttribute(),
				'valorCofins' => $this->getValorCofinsAttribute(),
			];
	}
}