<?php
declare(strict_types=1);

class NfeDeclaracaoImportacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_declaracao_importacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeImportacaoDetalheModelList',
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}

	public function nfeImportacaoDetalheModelList()
	{
		return $this->hasMany(NfeImportacaoDetalheModel::class, 'id_nfe_declaracao_importacao', 'id');
	}


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroDocumentoAttribute()
	{
		return $this->attributes['numero_documento'];
	}

	public function setNumeroDocumentoAttribute($numeroDocumento)
	{
		$this->attributes['numero_documento'] = $numeroDocumento;
	}

	public function getDataRegistroAttribute()
	{
		return $this->attributes['data_registro'];
	}

	public function setDataRegistroAttribute($dataRegistro)
	{
		$this->attributes['data_registro'] = $dataRegistro;
	}

	public function getLocalDesembaracoAttribute()
	{
		return $this->attributes['local_desembaraco'];
	}

	public function setLocalDesembaracoAttribute($localDesembaraco)
	{
		$this->attributes['local_desembaraco'] = $localDesembaraco;
	}

	public function getUfDesembaracoAttribute()
	{
		return $this->attributes['uf_desembaraco'];
	}

	public function setUfDesembaracoAttribute($ufDesembaraco)
	{
		$this->attributes['uf_desembaraco'] = $ufDesembaraco;
	}

	public function getDataDesembaracoAttribute()
	{
		return $this->attributes['data_desembaraco'];
	}

	public function setDataDesembaracoAttribute($dataDesembaraco)
	{
		$this->attributes['data_desembaraco'] = $dataDesembaraco;
	}

	public function getViaTransporteAttribute()
	{
		return $this->attributes['via_transporte'];
	}

	public function setViaTransporteAttribute($viaTransporte)
	{
		$this->attributes['via_transporte'] = $viaTransporte;
	}

	public function getValorAfrmmAttribute()
	{
		return (double)$this->attributes['valor_afrmm'];
	}

	public function setValorAfrmmAttribute($valorAfrmm)
	{
		$this->attributes['valor_afrmm'] = $valorAfrmm;
	}

	public function getFormaIntermediacaoAttribute()
	{
		return $this->attributes['forma_intermediacao'];
	}

	public function setFormaIntermediacaoAttribute($formaIntermediacao)
	{
		$this->attributes['forma_intermediacao'] = $formaIntermediacao;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getUfTerceiroAttribute()
	{
		return $this->attributes['uf_terceiro'];
	}

	public function setUfTerceiroAttribute($ufTerceiro)
	{
		$this->attributes['uf_terceiro'] = $ufTerceiro;
	}

	public function getCodigoExportadorAttribute()
	{
		return $this->attributes['codigo_exportador'];
	}

	public function setCodigoExportadorAttribute($codigoExportador)
	{
		$this->attributes['codigo_exportador'] = $codigoExportador;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroDocumentoAttribute($object->numeroDocumento);
				$this->setDataRegistroAttribute($object->dataRegistro);
				$this->setLocalDesembaracoAttribute($object->localDesembaraco);
				$this->setUfDesembaracoAttribute($object->ufDesembaraco);
				$this->setDataDesembaracoAttribute($object->dataDesembaraco);
				$this->setViaTransporteAttribute($object->viaTransporte);
				$this->setValorAfrmmAttribute($object->valorAfrmm);
				$this->setFormaIntermediacaoAttribute($object->formaIntermediacao);
				$this->setCnpjAttribute($object->cnpj);
				$this->setUfTerceiroAttribute($object->ufTerceiro);
				$this->setCodigoExportadorAttribute($object->codigoExportador);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroDocumento' => $this->getNumeroDocumentoAttribute(),
				'dataRegistro' => $this->getDataRegistroAttribute(),
				'localDesembaraco' => $this->getLocalDesembaracoAttribute(),
				'ufDesembaraco' => $this->getUfDesembaracoAttribute(),
				'dataDesembaraco' => $this->getDataDesembaracoAttribute(),
				'viaTransporte' => $this->getViaTransporteAttribute(),
				'valorAfrmm' => $this->getValorAfrmmAttribute(),
				'formaIntermediacao' => $this->getFormaIntermediacaoAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'ufTerceiro' => $this->getUfTerceiroAttribute(),
				'codigoExportador' => $this->getCodigoExportadorAttribute(),
				'nfeImportacaoDetalheModelList' => $this->nfeImportacaoDetalheModelList,
			];
	}
}