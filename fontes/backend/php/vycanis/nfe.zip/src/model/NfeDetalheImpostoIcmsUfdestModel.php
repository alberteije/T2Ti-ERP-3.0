<?php
declare(strict_types=1);

class NfeDetalheImpostoIcmsUfdestModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_icms_ufdest';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorBcIcmsUfDestinoAttribute()
	{
		return (double)$this->attributes['valor_bc_icms_uf_destino'];
	}

	public function setValorBcIcmsUfDestinoAttribute($valorBcIcmsUfDestino)
	{
		$this->attributes['valor_bc_icms_uf_destino'] = $valorBcIcmsUfDestino;
	}

	public function getValorBcFcpUfDestinoAttribute()
	{
		return (double)$this->attributes['valor_bc_fcp_uf_destino'];
	}

	public function setValorBcFcpUfDestinoAttribute($valorBcFcpUfDestino)
	{
		$this->attributes['valor_bc_fcp_uf_destino'] = $valorBcFcpUfDestino;
	}

	public function getPercentualFcpUfDestinoAttribute()
	{
		return (double)$this->attributes['percentual_fcp_uf_destino'];
	}

	public function setPercentualFcpUfDestinoAttribute($percentualFcpUfDestino)
	{
		$this->attributes['percentual_fcp_uf_destino'] = $percentualFcpUfDestino;
	}

	public function getAliquotaInternaUfDestinoAttribute()
	{
		return (double)$this->attributes['aliquota_interna_uf_destino'];
	}

	public function setAliquotaInternaUfDestinoAttribute($aliquotaInternaUfDestino)
	{
		$this->attributes['aliquota_interna_uf_destino'] = $aliquotaInternaUfDestino;
	}

	public function getAliquotaInteresdatualUfEnvolvidasAttribute()
	{
		return (double)$this->attributes['aliquota_interesdatual_uf_envolvidas'];
	}

	public function setAliquotaInteresdatualUfEnvolvidasAttribute($aliquotaInteresdatualUfEnvolvidas)
	{
		$this->attributes['aliquota_interesdatual_uf_envolvidas'] = $aliquotaInteresdatualUfEnvolvidas;
	}

	public function getPercentualProvisorioPartilhaIcmsAttribute()
	{
		return (double)$this->attributes['percentual_provisorio_partilha_icms'];
	}

	public function setPercentualProvisorioPartilhaIcmsAttribute($percentualProvisorioPartilhaIcms)
	{
		$this->attributes['percentual_provisorio_partilha_icms'] = $percentualProvisorioPartilhaIcms;
	}

	public function getValorIcmsFcpUfDestinoAttribute()
	{
		return (double)$this->attributes['valor_icms_fcp_uf_destino'];
	}

	public function setValorIcmsFcpUfDestinoAttribute($valorIcmsFcpUfDestino)
	{
		$this->attributes['valor_icms_fcp_uf_destino'] = $valorIcmsFcpUfDestino;
	}

	public function getValorInterestadualUfDestinoAttribute()
	{
		return (double)$this->attributes['valor_interestadual_uf_destino'];
	}

	public function setValorInterestadualUfDestinoAttribute($valorInterestadualUfDestino)
	{
		$this->attributes['valor_interestadual_uf_destino'] = $valorInterestadualUfDestino;
	}

	public function getValorInterestadualUfRemetenteAttribute()
	{
		return (double)$this->attributes['valor_interestadual_uf_remetente'];
	}

	public function setValorInterestadualUfRemetenteAttribute($valorInterestadualUfRemetente)
	{
		$this->attributes['valor_interestadual_uf_remetente'] = $valorInterestadualUfRemetente;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorBcIcmsUfDestinoAttribute($object->valorBcIcmsUfDestino);
				$this->setValorBcFcpUfDestinoAttribute($object->valorBcFcpUfDestino);
				$this->setPercentualFcpUfDestinoAttribute($object->percentualFcpUfDestino);
				$this->setAliquotaInternaUfDestinoAttribute($object->aliquotaInternaUfDestino);
				$this->setAliquotaInteresdatualUfEnvolvidasAttribute($object->aliquotaInteresdatualUfEnvolvidas);
				$this->setPercentualProvisorioPartilhaIcmsAttribute($object->percentualProvisorioPartilhaIcms);
				$this->setValorIcmsFcpUfDestinoAttribute($object->valorIcmsFcpUfDestino);
				$this->setValorInterestadualUfDestinoAttribute($object->valorInterestadualUfDestino);
				$this->setValorInterestadualUfRemetenteAttribute($object->valorInterestadualUfRemetente);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valorBcIcmsUfDestino' => $this->getValorBcIcmsUfDestinoAttribute(),
				'valorBcFcpUfDestino' => $this->getValorBcFcpUfDestinoAttribute(),
				'percentualFcpUfDestino' => $this->getPercentualFcpUfDestinoAttribute(),
				'aliquotaInternaUfDestino' => $this->getAliquotaInternaUfDestinoAttribute(),
				'aliquotaInteresdatualUfEnvolvidas' => $this->getAliquotaInteresdatualUfEnvolvidasAttribute(),
				'percentualProvisorioPartilhaIcms' => $this->getPercentualProvisorioPartilhaIcmsAttribute(),
				'valorIcmsFcpUfDestino' => $this->getValorIcmsFcpUfDestinoAttribute(),
				'valorInterestadualUfDestino' => $this->getValorInterestadualUfDestinoAttribute(),
				'valorInterestadualUfRemetente' => $this->getValorInterestadualUfRemetenteAttribute(),
			];
	}
}