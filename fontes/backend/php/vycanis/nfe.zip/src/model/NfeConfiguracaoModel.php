<?php
declare(strict_types=1);

class NfeConfiguracaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_configuracao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCertificadoDigitalSerieAttribute()
	{
		return $this->attributes['certificado_digital_serie'];
	}

	public function setCertificadoDigitalSerieAttribute($certificadoDigitalSerie)
	{
		$this->attributes['certificado_digital_serie'] = $certificadoDigitalSerie;
	}

	public function getCertificadoDigitalCaminhoAttribute()
	{
		return $this->attributes['certificado_digital_caminho'];
	}

	public function setCertificadoDigitalCaminhoAttribute($certificadoDigitalCaminho)
	{
		$this->attributes['certificado_digital_caminho'] = $certificadoDigitalCaminho;
	}

	public function getCertificadoDigitalSenhaAttribute()
	{
		return $this->attributes['certificado_digital_senha'];
	}

	public function setCertificadoDigitalSenhaAttribute($certificadoDigitalSenha)
	{
		$this->attributes['certificado_digital_senha'] = $certificadoDigitalSenha;
	}

	public function getTipoEmissaoAttribute()
	{
		return $this->attributes['tipo_emissao'];
	}

	public function setTipoEmissaoAttribute($tipoEmissao)
	{
		$this->attributes['tipo_emissao'] = $tipoEmissao;
	}

	public function getFormatoImpressaoDanfeAttribute()
	{
		return $this->attributes['formato_impressao_danfe'];
	}

	public function setFormatoImpressaoDanfeAttribute($formatoImpressaoDanfe)
	{
		$this->attributes['formato_impressao_danfe'] = $formatoImpressaoDanfe;
	}

	public function getProcessoEmissaoAttribute()
	{
		return $this->attributes['processo_emissao'];
	}

	public function setProcessoEmissaoAttribute($processoEmissao)
	{
		$this->attributes['processo_emissao'] = $processoEmissao;
	}

	public function getVersaoProcessoEmissaoAttribute()
	{
		return $this->attributes['versao_processo_emissao'];
	}

	public function setVersaoProcessoEmissaoAttribute($versaoProcessoEmissao)
	{
		$this->attributes['versao_processo_emissao'] = $versaoProcessoEmissao;
	}

	public function getCaminhoLogomarcaAttribute()
	{
		return $this->attributes['caminho_logomarca'];
	}

	public function setCaminhoLogomarcaAttribute($caminhoLogomarca)
	{
		$this->attributes['caminho_logomarca'] = $caminhoLogomarca;
	}

	public function getSalvarXmlAttribute()
	{
		return $this->attributes['salvar_xml'];
	}

	public function setSalvarXmlAttribute($salvarXml)
	{
		$this->attributes['salvar_xml'] = $salvarXml;
	}

	public function getCaminhoSalvarXmlAttribute()
	{
		return $this->attributes['caminho_salvar_xml'];
	}

	public function setCaminhoSalvarXmlAttribute($caminhoSalvarXml)
	{
		$this->attributes['caminho_salvar_xml'] = $caminhoSalvarXml;
	}

	public function getCaminhoSchemasAttribute()
	{
		return $this->attributes['caminho_schemas'];
	}

	public function setCaminhoSchemasAttribute($caminhoSchemas)
	{
		$this->attributes['caminho_schemas'] = $caminhoSchemas;
	}

	public function getCaminhoArquivoDanfeAttribute()
	{
		return $this->attributes['caminho_arquivo_danfe'];
	}

	public function setCaminhoArquivoDanfeAttribute($caminhoArquivoDanfe)
	{
		$this->attributes['caminho_arquivo_danfe'] = $caminhoArquivoDanfe;
	}

	public function getCaminhoSalvarPdfAttribute()
	{
		return $this->attributes['caminho_salvar_pdf'];
	}

	public function setCaminhoSalvarPdfAttribute($caminhoSalvarPdf)
	{
		$this->attributes['caminho_salvar_pdf'] = $caminhoSalvarPdf;
	}

	public function getWebserviceUfAttribute()
	{
		return $this->attributes['webservice_uf'];
	}

	public function setWebserviceUfAttribute($webserviceUf)
	{
		$this->attributes['webservice_uf'] = $webserviceUf;
	}

	public function getWebserviceAmbienteAttribute()
	{
		return $this->attributes['webservice_ambiente'];
	}

	public function setWebserviceAmbienteAttribute($webserviceAmbiente)
	{
		$this->attributes['webservice_ambiente'] = $webserviceAmbiente;
	}

	public function getWebserviceProxyHostAttribute()
	{
		return $this->attributes['webservice_proxy_host'];
	}

	public function setWebserviceProxyHostAttribute($webserviceProxyHost)
	{
		$this->attributes['webservice_proxy_host'] = $webserviceProxyHost;
	}

	public function getWebserviceProxyPortaAttribute()
	{
		return $this->attributes['webservice_proxy_porta'];
	}

	public function setWebserviceProxyPortaAttribute($webserviceProxyPorta)
	{
		$this->attributes['webservice_proxy_porta'] = $webserviceProxyPorta;
	}

	public function getWebserviceProxyUsuarioAttribute()
	{
		return $this->attributes['webservice_proxy_usuario'];
	}

	public function setWebserviceProxyUsuarioAttribute($webserviceProxyUsuario)
	{
		$this->attributes['webservice_proxy_usuario'] = $webserviceProxyUsuario;
	}

	public function getWebserviceProxySenhaAttribute()
	{
		return $this->attributes['webservice_proxy_senha'];
	}

	public function setWebserviceProxySenhaAttribute($webserviceProxySenha)
	{
		$this->attributes['webservice_proxy_senha'] = $webserviceProxySenha;
	}

	public function getWebserviceVisualizarAttribute()
	{
		return $this->attributes['webservice_visualizar'];
	}

	public function setWebserviceVisualizarAttribute($webserviceVisualizar)
	{
		$this->attributes['webservice_visualizar'] = $webserviceVisualizar;
	}

	public function getEmailServidorSmtpAttribute()
	{
		return $this->attributes['email_servidor_smtp'];
	}

	public function setEmailServidorSmtpAttribute($emailServidorSmtp)
	{
		$this->attributes['email_servidor_smtp'] = $emailServidorSmtp;
	}

	public function getEmailPortaAttribute()
	{
		return $this->attributes['email_porta'];
	}

	public function setEmailPortaAttribute($emailPorta)
	{
		$this->attributes['email_porta'] = $emailPorta;
	}

	public function getEmailUsuarioAttribute()
	{
		return $this->attributes['email_usuario'];
	}

	public function setEmailUsuarioAttribute($emailUsuario)
	{
		$this->attributes['email_usuario'] = $emailUsuario;
	}

	public function getEmailSenhaAttribute()
	{
		return $this->attributes['email_senha'];
	}

	public function setEmailSenhaAttribute($emailSenha)
	{
		$this->attributes['email_senha'] = $emailSenha;
	}

	public function getEmailAssuntoAttribute()
	{
		return $this->attributes['email_assunto'];
	}

	public function setEmailAssuntoAttribute($emailAssunto)
	{
		$this->attributes['email_assunto'] = $emailAssunto;
	}

	public function getEmailAutenticaSslAttribute()
	{
		return $this->attributes['email_autentica_ssl'];
	}

	public function setEmailAutenticaSslAttribute($emailAutenticaSsl)
	{
		$this->attributes['email_autentica_ssl'] = $emailAutenticaSsl;
	}

	public function getEmailTextoAttribute()
	{
		return $this->attributes['email_texto'];
	}

	public function setEmailTextoAttribute($emailTexto)
	{
		$this->attributes['email_texto'] = $emailTexto;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCertificadoDigitalSerieAttribute($object->certificadoDigitalSerie);
				$this->setCertificadoDigitalCaminhoAttribute($object->certificadoDigitalCaminho);
				$this->setCertificadoDigitalSenhaAttribute($object->certificadoDigitalSenha);
				$this->setTipoEmissaoAttribute($object->tipoEmissao);
				$this->setFormatoImpressaoDanfeAttribute($object->formatoImpressaoDanfe);
				$this->setProcessoEmissaoAttribute($object->processoEmissao);
				$this->setVersaoProcessoEmissaoAttribute($object->versaoProcessoEmissao);
				$this->setCaminhoLogomarcaAttribute($object->caminhoLogomarca);
				$this->setSalvarXmlAttribute($object->salvarXml);
				$this->setCaminhoSalvarXmlAttribute($object->caminhoSalvarXml);
				$this->setCaminhoSchemasAttribute($object->caminhoSchemas);
				$this->setCaminhoArquivoDanfeAttribute($object->caminhoArquivoDanfe);
				$this->setCaminhoSalvarPdfAttribute($object->caminhoSalvarPdf);
				$this->setWebserviceUfAttribute($object->webserviceUf);
				$this->setWebserviceAmbienteAttribute($object->webserviceAmbiente);
				$this->setWebserviceProxyHostAttribute($object->webserviceProxyHost);
				$this->setWebserviceProxyPortaAttribute($object->webserviceProxyPorta);
				$this->setWebserviceProxyUsuarioAttribute($object->webserviceProxyUsuario);
				$this->setWebserviceProxySenhaAttribute($object->webserviceProxySenha);
				$this->setWebserviceVisualizarAttribute($object->webserviceVisualizar);
				$this->setEmailServidorSmtpAttribute($object->emailServidorSmtp);
				$this->setEmailPortaAttribute($object->emailPorta);
				$this->setEmailUsuarioAttribute($object->emailUsuario);
				$this->setEmailSenhaAttribute($object->emailSenha);
				$this->setEmailAssuntoAttribute($object->emailAssunto);
				$this->setEmailAutenticaSslAttribute($object->emailAutenticaSsl);
				$this->setEmailTextoAttribute($object->emailTexto);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'certificadoDigitalSerie' => $this->getCertificadoDigitalSerieAttribute(),
				'certificadoDigitalCaminho' => $this->getCertificadoDigitalCaminhoAttribute(),
				'certificadoDigitalSenha' => $this->getCertificadoDigitalSenhaAttribute(),
				'tipoEmissao' => $this->getTipoEmissaoAttribute(),
				'formatoImpressaoDanfe' => $this->getFormatoImpressaoDanfeAttribute(),
				'processoEmissao' => $this->getProcessoEmissaoAttribute(),
				'versaoProcessoEmissao' => $this->getVersaoProcessoEmissaoAttribute(),
				'caminhoLogomarca' => $this->getCaminhoLogomarcaAttribute(),
				'salvarXml' => $this->getSalvarXmlAttribute(),
				'caminhoSalvarXml' => $this->getCaminhoSalvarXmlAttribute(),
				'caminhoSchemas' => $this->getCaminhoSchemasAttribute(),
				'caminhoArquivoDanfe' => $this->getCaminhoArquivoDanfeAttribute(),
				'caminhoSalvarPdf' => $this->getCaminhoSalvarPdfAttribute(),
				'webserviceUf' => $this->getWebserviceUfAttribute(),
				'webserviceAmbiente' => $this->getWebserviceAmbienteAttribute(),
				'webserviceProxyHost' => $this->getWebserviceProxyHostAttribute(),
				'webserviceProxyPorta' => $this->getWebserviceProxyPortaAttribute(),
				'webserviceProxyUsuario' => $this->getWebserviceProxyUsuarioAttribute(),
				'webserviceProxySenha' => $this->getWebserviceProxySenhaAttribute(),
				'webserviceVisualizar' => $this->getWebserviceVisualizarAttribute(),
				'emailServidorSmtp' => $this->getEmailServidorSmtpAttribute(),
				'emailPorta' => $this->getEmailPortaAttribute(),
				'emailUsuario' => $this->getEmailUsuarioAttribute(),
				'emailSenha' => $this->getEmailSenhaAttribute(),
				'emailAssunto' => $this->getEmailAssuntoAttribute(),
				'emailAutenticaSsl' => $this->getEmailAutenticaSslAttribute(),
				'emailTexto' => $this->getEmailTextoAttribute(),
			];
	}
}