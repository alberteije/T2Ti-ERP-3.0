<?php
declare(strict_types=1);

class NfeLocalEntregaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_local_entrega';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCnpjAttribute()
	{
		return $this->attributes['cnpj'];
	}

	public function setCnpjAttribute($cnpj)
	{
		$this->attributes['cnpj'] = $cnpj;
	}

	public function getCpfAttribute()
	{
		return $this->attributes['cpf'];
	}

	public function setCpfAttribute($cpf)
	{
		$this->attributes['cpf'] = $cpf;
	}

	public function getNomeRecebedorAttribute()
	{
		return $this->attributes['nome_recebedor'];
	}

	public function setNomeRecebedorAttribute($nomeRecebedor)
	{
		$this->attributes['nome_recebedor'] = $nomeRecebedor;
	}

	public function getLogradouroAttribute()
	{
		return $this->attributes['logradouro'];
	}

	public function setLogradouroAttribute($logradouro)
	{
		$this->attributes['logradouro'] = $logradouro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getComplementoAttribute()
	{
		return $this->attributes['complemento'];
	}

	public function setComplementoAttribute($complemento)
	{
		$this->attributes['complemento'] = $complemento;
	}

	public function getBairroAttribute()
	{
		return $this->attributes['bairro'];
	}

	public function setBairroAttribute($bairro)
	{
		$this->attributes['bairro'] = $bairro;
	}

	public function getCodigoMunicipioAttribute()
	{
		return $this->attributes['codigo_municipio'];
	}

	public function setCodigoMunicipioAttribute($codigoMunicipio)
	{
		$this->attributes['codigo_municipio'] = $codigoMunicipio;
	}

	public function getNomeMunicipioAttribute()
	{
		return $this->attributes['nome_municipio'];
	}

	public function setNomeMunicipioAttribute($nomeMunicipio)
	{
		$this->attributes['nome_municipio'] = $nomeMunicipio;
	}

	public function getUfAttribute()
	{
		return $this->attributes['uf'];
	}

	public function setUfAttribute($uf)
	{
		$this->attributes['uf'] = $uf;
	}

	public function getCepAttribute()
	{
		return $this->attributes['cep'];
	}

	public function setCepAttribute($cep)
	{
		$this->attributes['cep'] = $cep;
	}

	public function getCodigoPaisAttribute()
	{
		return $this->attributes['codigo_pais'];
	}

	public function setCodigoPaisAttribute($codigoPais)
	{
		$this->attributes['codigo_pais'] = $codigoPais;
	}

	public function getNomePaisAttribute()
	{
		return $this->attributes['nome_pais'];
	}

	public function setNomePaisAttribute($nomePais)
	{
		$this->attributes['nome_pais'] = $nomePais;
	}

	public function getTelefoneAttribute()
	{
		return $this->attributes['telefone'];
	}

	public function setTelefoneAttribute($telefone)
	{
		$this->attributes['telefone'] = $telefone;
	}

	public function getEmailAttribute()
	{
		return $this->attributes['email'];
	}

	public function setEmailAttribute($email)
	{
		$this->attributes['email'] = $email;
	}

	public function getInscricaoEstadualAttribute()
	{
		return $this->attributes['inscricao_estadual'];
	}

	public function setInscricaoEstadualAttribute($inscricaoEstadual)
	{
		$this->attributes['inscricao_estadual'] = $inscricaoEstadual;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCnpjAttribute($object->cnpj);
				$this->setCpfAttribute($object->cpf);
				$this->setNomeRecebedorAttribute($object->nomeRecebedor);
				$this->setLogradouroAttribute($object->logradouro);
				$this->setNumeroAttribute($object->numero);
				$this->setComplementoAttribute($object->complemento);
				$this->setBairroAttribute($object->bairro);
				$this->setCodigoMunicipioAttribute($object->codigoMunicipio);
				$this->setNomeMunicipioAttribute($object->nomeMunicipio);
				$this->setUfAttribute($object->uf);
				$this->setCepAttribute($object->cep);
				$this->setCodigoPaisAttribute($object->codigoPais);
				$this->setNomePaisAttribute($object->nomePais);
				$this->setTelefoneAttribute($object->telefone);
				$this->setEmailAttribute($object->email);
				$this->setInscricaoEstadualAttribute($object->inscricaoEstadual);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cnpj' => $this->getCnpjAttribute(),
				'cpf' => $this->getCpfAttribute(),
				'nomeRecebedor' => $this->getNomeRecebedorAttribute(),
				'logradouro' => $this->getLogradouroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'complemento' => $this->getComplementoAttribute(),
				'bairro' => $this->getBairroAttribute(),
				'codigoMunicipio' => $this->getCodigoMunicipioAttribute(),
				'nomeMunicipio' => $this->getNomeMunicipioAttribute(),
				'uf' => $this->getUfAttribute(),
				'cep' => $this->getCepAttribute(),
				'codigoPais' => $this->getCodigoPaisAttribute(),
				'nomePais' => $this->getNomePaisAttribute(),
				'telefone' => $this->getTelefoneAttribute(),
				'email' => $this->getEmailAttribute(),
				'inscricaoEstadual' => $this->getInscricaoEstadualAttribute(),
			];
	}
}