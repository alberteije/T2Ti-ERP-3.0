<?php
declare(strict_types=1);

class NfeDetalheImpostoIiModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_ii';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorBcIiAttribute()
	{
		return (double)$this->attributes['valor_bc_ii'];
	}

	public function setValorBcIiAttribute($valorBcIi)
	{
		$this->attributes['valor_bc_ii'] = $valorBcIi;
	}

	public function getValorDespesasAduaneirasAttribute()
	{
		return (double)$this->attributes['valor_despesas_aduaneiras'];
	}

	public function setValorDespesasAduaneirasAttribute($valorDespesasAduaneiras)
	{
		$this->attributes['valor_despesas_aduaneiras'] = $valorDespesasAduaneiras;
	}

	public function getValorImpostoImportacaoAttribute()
	{
		return (double)$this->attributes['valor_imposto_importacao'];
	}

	public function setValorImpostoImportacaoAttribute($valorImpostoImportacao)
	{
		$this->attributes['valor_imposto_importacao'] = $valorImpostoImportacao;
	}

	public function getValorIofAttribute()
	{
		return (double)$this->attributes['valor_iof'];
	}

	public function setValorIofAttribute($valorIof)
	{
		$this->attributes['valor_iof'] = $valorIof;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorBcIiAttribute($object->valorBcIi);
				$this->setValorDespesasAduaneirasAttribute($object->valorDespesasAduaneiras);
				$this->setValorImpostoImportacaoAttribute($object->valorImpostoImportacao);
				$this->setValorIofAttribute($object->valorIof);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valorBcIi' => $this->getValorBcIiAttribute(),
				'valorDespesasAduaneiras' => $this->getValorDespesasAduaneirasAttribute(),
				'valorImpostoImportacao' => $this->getValorImpostoImportacaoAttribute(),
				'valorIof' => $this->getValorIofAttribute(),
			];
	}
}