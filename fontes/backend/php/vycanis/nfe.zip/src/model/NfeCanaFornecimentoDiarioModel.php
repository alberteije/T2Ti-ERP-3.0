<?php
declare(strict_types=1);

class NfeCanaFornecimentoDiarioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_cana_fornecimento_diario';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeCanaModel()
	{
		return $this->belongsTo(NfeCanaModel::class, 'id_nfe_cana', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDiaAttribute()
	{
		return $this->attributes['dia'];
	}

	public function setDiaAttribute($dia)
	{
		$this->attributes['dia'] = $dia;
	}

	public function getQuantidadeAttribute()
	{
		return (double)$this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getQuantidadeTotalMesAttribute()
	{
		return (double)$this->attributes['quantidade_total_mes'];
	}

	public function setQuantidadeTotalMesAttribute($quantidadeTotalMes)
	{
		$this->attributes['quantidade_total_mes'] = $quantidadeTotalMes;
	}

	public function getQuantidadeTotalAnteriorAttribute()
	{
		return (double)$this->attributes['quantidade_total_anterior'];
	}

	public function setQuantidadeTotalAnteriorAttribute($quantidadeTotalAnterior)
	{
		$this->attributes['quantidade_total_anterior'] = $quantidadeTotalAnterior;
	}

	public function getQuantidadeTotalGeralAttribute()
	{
		return (double)$this->attributes['quantidade_total_geral'];
	}

	public function setQuantidadeTotalGeralAttribute($quantidadeTotalGeral)
	{
		$this->attributes['quantidade_total_geral'] = $quantidadeTotalGeral;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDiaAttribute($object->dia);
				$this->setQuantidadeAttribute($object->quantidade);
				$this->setQuantidadeTotalMesAttribute($object->quantidadeTotalMes);
				$this->setQuantidadeTotalAnteriorAttribute($object->quantidadeTotalAnterior);
				$this->setQuantidadeTotalGeralAttribute($object->quantidadeTotalGeral);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dia' => $this->getDiaAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'quantidadeTotalMes' => $this->getQuantidadeTotalMesAttribute(),
				'quantidadeTotalAnterior' => $this->getQuantidadeTotalAnteriorAttribute(),
				'quantidadeTotalGeral' => $this->getQuantidadeTotalGeralAttribute(),
			];
	}
}