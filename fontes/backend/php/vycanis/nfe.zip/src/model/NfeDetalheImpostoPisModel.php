<?php
declare(strict_types=1);

class NfeDetalheImpostoPisModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_pis';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCstPisAttribute()
	{
		return $this->attributes['cst_pis'];
	}

	public function setCstPisAttribute($cstPis)
	{
		$this->attributes['cst_pis'] = $cstPis;
	}

	public function getValorBaseCalculoPisAttribute()
	{
		return (double)$this->attributes['valor_base_calculo_pis'];
	}

	public function setValorBaseCalculoPisAttribute($valorBaseCalculoPis)
	{
		$this->attributes['valor_base_calculo_pis'] = $valorBaseCalculoPis;
	}

	public function getAliquotaPisPercentualAttribute()
	{
		return (double)$this->attributes['aliquota_pis_percentual'];
	}

	public function setAliquotaPisPercentualAttribute($aliquotaPisPercentual)
	{
		$this->attributes['aliquota_pis_percentual'] = $aliquotaPisPercentual;
	}

	public function getValorPisAttribute()
	{
		return (double)$this->attributes['valor_pis'];
	}

	public function setValorPisAttribute($valorPis)
	{
		$this->attributes['valor_pis'] = $valorPis;
	}

	public function getQuantidadeVendidaAttribute()
	{
		return (double)$this->attributes['quantidade_vendida'];
	}

	public function setQuantidadeVendidaAttribute($quantidadeVendida)
	{
		$this->attributes['quantidade_vendida'] = $quantidadeVendida;
	}

	public function getAliquotaPisReaisAttribute()
	{
		return (double)$this->attributes['aliquota_pis_reais'];
	}

	public function setAliquotaPisReaisAttribute($aliquotaPisReais)
	{
		$this->attributes['aliquota_pis_reais'] = $aliquotaPisReais;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCstPisAttribute($object->cstPis);
				$this->setValorBaseCalculoPisAttribute($object->valorBaseCalculoPis);
				$this->setAliquotaPisPercentualAttribute($object->aliquotaPisPercentual);
				$this->setValorPisAttribute($object->valorPis);
				$this->setQuantidadeVendidaAttribute($object->quantidadeVendida);
				$this->setAliquotaPisReaisAttribute($object->aliquotaPisReais);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'cstPis' => $this->getCstPisAttribute(),
				'valorBaseCalculoPis' => $this->getValorBaseCalculoPisAttribute(),
				'aliquotaPisPercentual' => $this->getAliquotaPisPercentualAttribute(),
				'valorPis' => $this->getValorPisAttribute(),
				'quantidadeVendida' => $this->getQuantidadeVendidaAttribute(),
				'aliquotaPisReais' => $this->getAliquotaPisReaisAttribute(),
			];
	}
}