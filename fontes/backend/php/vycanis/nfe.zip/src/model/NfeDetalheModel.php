<?php
declare(strict_types=1);

class NfeDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeDetEspecificoVeiculoModelList',
		'nfeDetEspecificoMedicamentoModelList',
		'nfeDetEspecificoArmamentoModelList',
		'nfeDetEspecificoCombustivelModelList',
		'nfeDeclaracaoImportacaoModelList',
		'nfeDetalheImpostoIcmsModelList',
		'nfeDetalheImpostoIpiModelList',
		'nfeDetalheImpostoIiModelList',
		'nfeDetalheImpostoPisModelList',
		'nfeDetalheImpostoCofinsModelList',
		'nfeDetalheImpostoIssqnModelList',
		'nfeExportacaoModelList',
		'nfeItemRastreadoModelList',
		'nfeDetalheImpostoPisStModelList',
		'nfeDetalheImpostoIcmsUfdestModelList',
		'nfeDetalheImpostoCofinsStModelList',
		'nfeCabecalhoModel',
		'produtoModel',
	];

	/**
		* Relations
		*/
	public function nfeDetEspecificoVeiculoModelList()
{
	return $this->hasMany(NfeDetEspecificoVeiculoModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetEspecificoMedicamentoModelList()
{
	return $this->hasMany(NfeDetEspecificoMedicamentoModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetEspecificoArmamentoModelList()
{
	return $this->hasMany(NfeDetEspecificoArmamentoModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetEspecificoCombustivelModelList()
{
	return $this->hasMany(NfeDetEspecificoCombustivelModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDeclaracaoImportacaoModelList()
{
	return $this->hasMany(NfeDeclaracaoImportacaoModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoIcmsModelList()
{
	return $this->hasMany(NfeDetalheImpostoIcmsModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoIpiModelList()
{
	return $this->hasMany(NfeDetalheImpostoIpiModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoIiModelList()
{
	return $this->hasMany(NfeDetalheImpostoIiModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoPisModelList()
{
	return $this->hasMany(NfeDetalheImpostoPisModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoCofinsModelList()
{
	return $this->hasMany(NfeDetalheImpostoCofinsModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoIssqnModelList()
{
	return $this->hasMany(NfeDetalheImpostoIssqnModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeExportacaoModelList()
{
	return $this->hasMany(NfeExportacaoModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeItemRastreadoModelList()
{
	return $this->hasMany(NfeItemRastreadoModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoPisStModelList()
{
	return $this->hasMany(NfeDetalheImpostoPisStModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoIcmsUfdestModelList()
{
	return $this->hasMany(NfeDetalheImpostoIcmsUfdestModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeDetalheImpostoCofinsStModelList()
{
	return $this->hasMany(NfeDetalheImpostoCofinsStModel::class, 'id_nfe_detalhe', 'id');
}

	public function nfeCabecalhoModel()
	{
		return $this->belongsTo(NfeCabecalhoModel::class, 'id_nfe_cabecalho', 'id');
	}

	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroItemAttribute()
	{
		return $this->attributes['numero_item'];
	}

	public function setNumeroItemAttribute($numeroItem)
	{
		$this->attributes['numero_item'] = $numeroItem;
	}

	public function getCodigoProdutoAttribute()
	{
		return $this->attributes['codigo_produto'];
	}

	public function setCodigoProdutoAttribute($codigoProduto)
	{
		$this->attributes['codigo_produto'] = $codigoProduto;
	}

	public function getGtinAttribute()
	{
		return $this->attributes['gtin'];
	}

	public function setGtinAttribute($gtin)
	{
		$this->attributes['gtin'] = $gtin;
	}

	public function getNomeProdutoAttribute()
	{
		return $this->attributes['nome_produto'];
	}

	public function setNomeProdutoAttribute($nomeProduto)
	{
		$this->attributes['nome_produto'] = $nomeProduto;
	}

	public function getNcmAttribute()
	{
		return $this->attributes['ncm'];
	}

	public function setNcmAttribute($ncm)
	{
		$this->attributes['ncm'] = $ncm;
	}

	public function getNveAttribute()
	{
		return $this->attributes['nve'];
	}

	public function setNveAttribute($nve)
	{
		$this->attributes['nve'] = $nve;
	}

	public function getCestAttribute()
	{
		return $this->attributes['cest'];
	}

	public function setCestAttribute($cest)
	{
		$this->attributes['cest'] = $cest;
	}

	public function getIndicadorEscalaRelevanteAttribute()
	{
		return $this->attributes['indicador_escala_relevante'];
	}

	public function setIndicadorEscalaRelevanteAttribute($indicadorEscalaRelevante)
	{
		$this->attributes['indicador_escala_relevante'] = $indicadorEscalaRelevante;
	}

	public function getCnpjFabricanteAttribute()
	{
		return $this->attributes['cnpj_fabricante'];
	}

	public function setCnpjFabricanteAttribute($cnpjFabricante)
	{
		$this->attributes['cnpj_fabricante'] = $cnpjFabricante;
	}

	public function getCodigoBeneficioFiscalAttribute()
	{
		return $this->attributes['codigo_beneficio_fiscal'];
	}

	public function setCodigoBeneficioFiscalAttribute($codigoBeneficioFiscal)
	{
		$this->attributes['codigo_beneficio_fiscal'] = $codigoBeneficioFiscal;
	}

	public function getExTipiAttribute()
	{
		return $this->attributes['ex_tipi'];
	}

	public function setExTipiAttribute($exTipi)
	{
		$this->attributes['ex_tipi'] = $exTipi;
	}

	public function getCfopAttribute()
	{
		return $this->attributes['cfop'];
	}

	public function setCfopAttribute($cfop)
	{
		$this->attributes['cfop'] = $cfop;
	}

	public function getUnidadeComercialAttribute()
	{
		return $this->attributes['unidade_comercial'];
	}

	public function setUnidadeComercialAttribute($unidadeComercial)
	{
		$this->attributes['unidade_comercial'] = $unidadeComercial;
	}

	public function getQuantidadeComercialAttribute()
	{
		return (double)$this->attributes['quantidade_comercial'];
	}

	public function setQuantidadeComercialAttribute($quantidadeComercial)
	{
		$this->attributes['quantidade_comercial'] = $quantidadeComercial;
	}

	public function getNumeroPedidoCompraAttribute()
	{
		return $this->attributes['numero_pedido_compra'];
	}

	public function setNumeroPedidoCompraAttribute($numeroPedidoCompra)
	{
		$this->attributes['numero_pedido_compra'] = $numeroPedidoCompra;
	}

	public function getItemPedidoCompraAttribute()
	{
		return $this->attributes['item_pedido_compra'];
	}

	public function setItemPedidoCompraAttribute($itemPedidoCompra)
	{
		$this->attributes['item_pedido_compra'] = $itemPedidoCompra;
	}

	public function getNumeroFciAttribute()
	{
		return $this->attributes['numero_fci'];
	}

	public function setNumeroFciAttribute($numeroFci)
	{
		$this->attributes['numero_fci'] = $numeroFci;
	}

	public function getNumeroRecopiAttribute()
	{
		return $this->attributes['numero_recopi'];
	}

	public function setNumeroRecopiAttribute($numeroRecopi)
	{
		$this->attributes['numero_recopi'] = $numeroRecopi;
	}

	public function getValorUnitarioComercialAttribute()
	{
		return (double)$this->attributes['valor_unitario_comercial'];
	}

	public function setValorUnitarioComercialAttribute($valorUnitarioComercial)
	{
		$this->attributes['valor_unitario_comercial'] = $valorUnitarioComercial;
	}

	public function getValorBrutoProdutoAttribute()
	{
		return (double)$this->attributes['valor_bruto_produto'];
	}

	public function setValorBrutoProdutoAttribute($valorBrutoProduto)
	{
		$this->attributes['valor_bruto_produto'] = $valorBrutoProduto;
	}

	public function getGtinUnidadeTributavelAttribute()
	{
		return $this->attributes['gtin_unidade_tributavel'];
	}

	public function setGtinUnidadeTributavelAttribute($gtinUnidadeTributavel)
	{
		$this->attributes['gtin_unidade_tributavel'] = $gtinUnidadeTributavel;
	}

	public function getUnidadeTributavelAttribute()
	{
		return $this->attributes['unidade_tributavel'];
	}

	public function setUnidadeTributavelAttribute($unidadeTributavel)
	{
		$this->attributes['unidade_tributavel'] = $unidadeTributavel;
	}

	public function getQuantidadeTributavelAttribute()
	{
		return (double)$this->attributes['quantidade_tributavel'];
	}

	public function setQuantidadeTributavelAttribute($quantidadeTributavel)
	{
		$this->attributes['quantidade_tributavel'] = $quantidadeTributavel;
	}

	public function getValorUnitarioTributavelAttribute()
	{
		return (double)$this->attributes['valor_unitario_tributavel'];
	}

	public function setValorUnitarioTributavelAttribute($valorUnitarioTributavel)
	{
		$this->attributes['valor_unitario_tributavel'] = $valorUnitarioTributavel;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	public function getValorSeguroAttribute()
	{
		return (double)$this->attributes['valor_seguro'];
	}

	public function setValorSeguroAttribute($valorSeguro)
	{
		$this->attributes['valor_seguro'] = $valorSeguro;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorOutrasDespesasAttribute()
	{
		return (double)$this->attributes['valor_outras_despesas'];
	}

	public function setValorOutrasDespesasAttribute($valorOutrasDespesas)
	{
		$this->attributes['valor_outras_despesas'] = $valorOutrasDespesas;
	}

	public function getEntraTotalAttribute()
	{
		return $this->attributes['entra_total'];
	}

	public function setEntraTotalAttribute($entraTotal)
	{
		$this->attributes['entra_total'] = $entraTotal;
	}

	public function getValorTotalTributosAttribute()
	{
		return (double)$this->attributes['valor_total_tributos'];
	}

	public function setValorTotalTributosAttribute($valorTotalTributos)
	{
		$this->attributes['valor_total_tributos'] = $valorTotalTributos;
	}

	public function getPercentualDevolvidoAttribute()
	{
		return (double)$this->attributes['percentual_devolvido'];
	}

	public function setPercentualDevolvidoAttribute($percentualDevolvido)
	{
		$this->attributes['percentual_devolvido'] = $percentualDevolvido;
	}

	public function getValorIpiDevolvidoAttribute()
	{
		return (double)$this->attributes['valor_ipi_devolvido'];
	}

	public function setValorIpiDevolvidoAttribute($valorIpiDevolvido)
	{
		$this->attributes['valor_ipi_devolvido'] = $valorIpiDevolvido;
	}

	public function getInformacoesAdicionaisAttribute()
	{
		return $this->attributes['informacoes_adicionais'];
	}

	public function setInformacoesAdicionaisAttribute($informacoesAdicionais)
	{
		$this->attributes['informacoes_adicionais'] = $informacoesAdicionais;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroItemAttribute($object->numeroItem);
				$this->setCodigoProdutoAttribute($object->codigoProduto);
				$this->setGtinAttribute($object->gtin);
				$this->setNomeProdutoAttribute($object->nomeProduto);
				$this->setNcmAttribute($object->ncm);
				$this->setNveAttribute($object->nve);
				$this->setCestAttribute($object->cest);
				$this->setIndicadorEscalaRelevanteAttribute($object->indicadorEscalaRelevante);
				$this->setCnpjFabricanteAttribute($object->cnpjFabricante);
				$this->setCodigoBeneficioFiscalAttribute($object->codigoBeneficioFiscal);
				$this->setExTipiAttribute($object->exTipi);
				$this->setCfopAttribute($object->cfop);
				$this->setUnidadeComercialAttribute($object->unidadeComercial);
				$this->setQuantidadeComercialAttribute($object->quantidadeComercial);
				$this->setNumeroPedidoCompraAttribute($object->numeroPedidoCompra);
				$this->setItemPedidoCompraAttribute($object->itemPedidoCompra);
				$this->setNumeroFciAttribute($object->numeroFci);
				$this->setNumeroRecopiAttribute($object->numeroRecopi);
				$this->setValorUnitarioComercialAttribute($object->valorUnitarioComercial);
				$this->setValorBrutoProdutoAttribute($object->valorBrutoProduto);
				$this->setGtinUnidadeTributavelAttribute($object->gtinUnidadeTributavel);
				$this->setUnidadeTributavelAttribute($object->unidadeTributavel);
				$this->setQuantidadeTributavelAttribute($object->quantidadeTributavel);
				$this->setValorUnitarioTributavelAttribute($object->valorUnitarioTributavel);
				$this->setValorFreteAttribute($object->valorFrete);
				$this->setValorSeguroAttribute($object->valorSeguro);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorOutrasDespesasAttribute($object->valorOutrasDespesas);
				$this->setEntraTotalAttribute($object->entraTotal);
				$this->setValorTotalTributosAttribute($object->valorTotalTributos);
				$this->setPercentualDevolvidoAttribute($object->percentualDevolvido);
				$this->setValorIpiDevolvidoAttribute($object->valorIpiDevolvido);
				$this->setInformacoesAdicionaisAttribute($object->informacoesAdicionais);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setValorTotalAttribute($object->valorTotal);

				// link objects - lookups
				$nfeCabecalhoModel = new NfeCabecalhoModel();
				$nfeCabecalhoModel->mapping($object->nfeCabecalhoModel);
				$this->nfeCabecalhoModel()->associate($nfeCabecalhoModel);
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroItem' => $this->getNumeroItemAttribute(),
				'codigoProduto' => $this->getCodigoProdutoAttribute(),
				'gtin' => $this->getGtinAttribute(),
				'nomeProduto' => $this->getNomeProdutoAttribute(),
				'ncm' => $this->getNcmAttribute(),
				'nve' => $this->getNveAttribute(),
				'cest' => $this->getCestAttribute(),
				'indicadorEscalaRelevante' => $this->getIndicadorEscalaRelevanteAttribute(),
				'cnpjFabricante' => $this->getCnpjFabricanteAttribute(),
				'codigoBeneficioFiscal' => $this->getCodigoBeneficioFiscalAttribute(),
				'exTipi' => $this->getExTipiAttribute(),
				'cfop' => $this->getCfopAttribute(),
				'unidadeComercial' => $this->getUnidadeComercialAttribute(),
				'quantidadeComercial' => $this->getQuantidadeComercialAttribute(),
				'numeroPedidoCompra' => $this->getNumeroPedidoCompraAttribute(),
				'itemPedidoCompra' => $this->getItemPedidoCompraAttribute(),
				'numeroFci' => $this->getNumeroFciAttribute(),
				'numeroRecopi' => $this->getNumeroRecopiAttribute(),
				'valorUnitarioComercial' => $this->getValorUnitarioComercialAttribute(),
				'valorBrutoProduto' => $this->getValorBrutoProdutoAttribute(),
				'gtinUnidadeTributavel' => $this->getGtinUnidadeTributavelAttribute(),
				'unidadeTributavel' => $this->getUnidadeTributavelAttribute(),
				'quantidadeTributavel' => $this->getQuantidadeTributavelAttribute(),
				'valorUnitarioTributavel' => $this->getValorUnitarioTributavelAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
				'valorSeguro' => $this->getValorSeguroAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorOutrasDespesas' => $this->getValorOutrasDespesasAttribute(),
				'entraTotal' => $this->getEntraTotalAttribute(),
				'valorTotalTributos' => $this->getValorTotalTributosAttribute(),
				'percentualDevolvido' => $this->getPercentualDevolvidoAttribute(),
				'valorIpiDevolvido' => $this->getValorIpiDevolvidoAttribute(),
				'informacoesAdicionais' => $this->getInformacoesAdicionaisAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'nfeDetEspecificoVeiculoModelList' => $this->nfeDetEspecificoVeiculoModelList,
				'nfeDetEspecificoMedicamentoModelList' => $this->nfeDetEspecificoMedicamentoModelList,
				'nfeDetEspecificoArmamentoModelList' => $this->nfeDetEspecificoArmamentoModelList,
				'nfeDetEspecificoCombustivelModelList' => $this->nfeDetEspecificoCombustivelModelList,
				'nfeDeclaracaoImportacaoModelList' => $this->nfeDeclaracaoImportacaoModelList,
				'nfeDetalheImpostoIcmsModelList' => $this->nfeDetalheImpostoIcmsModelList,
				'nfeDetalheImpostoIpiModelList' => $this->nfeDetalheImpostoIpiModelList,
				'nfeDetalheImpostoIiModelList' => $this->nfeDetalheImpostoIiModelList,
				'nfeDetalheImpostoPisModelList' => $this->nfeDetalheImpostoPisModelList,
				'nfeDetalheImpostoCofinsModelList' => $this->nfeDetalheImpostoCofinsModelList,
				'nfeDetalheImpostoIssqnModelList' => $this->nfeDetalheImpostoIssqnModelList,
				'nfeExportacaoModelList' => $this->nfeExportacaoModelList,
				'nfeItemRastreadoModelList' => $this->nfeItemRastreadoModelList,
				'nfeDetalheImpostoPisStModelList' => $this->nfeDetalheImpostoPisStModelList,
				'nfeDetalheImpostoIcmsUfdestModelList' => $this->nfeDetalheImpostoIcmsUfdestModelList,
				'nfeDetalheImpostoCofinsStModelList' => $this->nfeDetalheImpostoCofinsStModelList,
				'nfeCabecalhoModel' => $this->nfeCabecalhoModel,
				'produtoModel' => $this->produtoModel,
			];
	}
}