<?php
declare(strict_types=1);

class NfeImportacaoDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_importacao_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'nfeDeclaracaoImportacaoModel',
	];

	/**
		* Relations
		*/
	public function nfeDeclaracaoImportacaoModel()
	{
		return $this->belongsTo(NfeDeclaracaoImportacaoModel::class, 'id_nfe_declaracao_importacao', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAdicaoAttribute()
	{
		return $this->attributes['numero_adicao'];
	}

	public function setNumeroAdicaoAttribute($numeroAdicao)
	{
		$this->attributes['numero_adicao'] = $numeroAdicao;
	}

	public function getNumeroSequencialAttribute()
	{
		return $this->attributes['numero_sequencial'];
	}

	public function setNumeroSequencialAttribute($numeroSequencial)
	{
		$this->attributes['numero_sequencial'] = $numeroSequencial;
	}

	public function getCodigoFabricanteEstrangeiroAttribute()
	{
		return $this->attributes['codigo_fabricante_estrangeiro'];
	}

	public function setCodigoFabricanteEstrangeiroAttribute($codigoFabricanteEstrangeiro)
	{
		$this->attributes['codigo_fabricante_estrangeiro'] = $codigoFabricanteEstrangeiro;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getDrawbackAttribute()
	{
		return $this->attributes['drawback'];
	}

	public function setDrawbackAttribute($drawback)
	{
		$this->attributes['drawback'] = $drawback;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAdicaoAttribute($object->numeroAdicao);
				$this->setNumeroSequencialAttribute($object->numeroSequencial);
				$this->setCodigoFabricanteEstrangeiroAttribute($object->codigoFabricanteEstrangeiro);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setDrawbackAttribute($object->drawback);

				// link objects - lookups
				$nfeDeclaracaoImportacaoModel = new NfeDeclaracaoImportacaoModel();
				$nfeDeclaracaoImportacaoModel->mapping($object->nfeDeclaracaoImportacaoModel);
				$this->nfeDeclaracaoImportacaoModel()->associate($nfeDeclaracaoImportacaoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numeroAdicao' => $this->getNumeroAdicaoAttribute(),
				'numeroSequencial' => $this->getNumeroSequencialAttribute(),
				'codigoFabricanteEstrangeiro' => $this->getCodigoFabricanteEstrangeiroAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'drawback' => $this->getDrawbackAttribute(),
				'nfeDeclaracaoImportacaoModel' => $this->nfeDeclaracaoImportacaoModel,
			];
	}
}