<?php
declare(strict_types=1);

class NfeDetalheImpostoIcmsModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'nfe_detalhe_imposto_icms';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function nfeDetalheModel()
	{
		return $this->belongsTo(NfeDetalheModel::class, 'id_nfe_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getOrigemMercadoriaAttribute()
	{
		return $this->attributes['origem_mercadoria'];
	}

	public function setOrigemMercadoriaAttribute($origemMercadoria)
	{
		$this->attributes['origem_mercadoria'] = $origemMercadoria;
	}

	public function getCstIcmsAttribute()
	{
		return $this->attributes['cst_icms'];
	}

	public function setCstIcmsAttribute($cstIcms)
	{
		$this->attributes['cst_icms'] = $cstIcms;
	}

	public function getCsosnAttribute()
	{
		return $this->attributes['csosn'];
	}

	public function setCsosnAttribute($csosn)
	{
		$this->attributes['csosn'] = $csosn;
	}

	public function getModalidadeBcIcmsAttribute()
	{
		return $this->attributes['modalidade_bc_icms'];
	}

	public function setModalidadeBcIcmsAttribute($modalidadeBcIcms)
	{
		$this->attributes['modalidade_bc_icms'] = $modalidadeBcIcms;
	}

	public function getPercentualReducaoBcIcmsAttribute()
	{
		return (double)$this->attributes['percentual_reducao_bc_icms'];
	}

	public function setPercentualReducaoBcIcmsAttribute($percentualReducaoBcIcms)
	{
		$this->attributes['percentual_reducao_bc_icms'] = $percentualReducaoBcIcms;
	}

	public function getValorBcIcmsAttribute()
	{
		return (double)$this->attributes['valor_bc_icms'];
	}

	public function setValorBcIcmsAttribute($valorBcIcms)
	{
		$this->attributes['valor_bc_icms'] = $valorBcIcms;
	}

	public function getAliquotaIcmsAttribute()
	{
		return (double)$this->attributes['aliquota_icms'];
	}

	public function setAliquotaIcmsAttribute($aliquotaIcms)
	{
		$this->attributes['aliquota_icms'] = $aliquotaIcms;
	}

	public function getValorIcmsOperacaoAttribute()
	{
		return (double)$this->attributes['valor_icms_operacao'];
	}

	public function setValorIcmsOperacaoAttribute($valorIcmsOperacao)
	{
		$this->attributes['valor_icms_operacao'] = $valorIcmsOperacao;
	}

	public function getPercentualDiferimentoAttribute()
	{
		return (double)$this->attributes['percentual_diferimento'];
	}

	public function setPercentualDiferimentoAttribute($percentualDiferimento)
	{
		$this->attributes['percentual_diferimento'] = $percentualDiferimento;
	}

	public function getValorIcmsDiferidoAttribute()
	{
		return (double)$this->attributes['valor_icms_diferido'];
	}

	public function setValorIcmsDiferidoAttribute($valorIcmsDiferido)
	{
		$this->attributes['valor_icms_diferido'] = $valorIcmsDiferido;
	}

	public function getValorIcmsAttribute()
	{
		return (double)$this->attributes['valor_icms'];
	}

	public function setValorIcmsAttribute($valorIcms)
	{
		$this->attributes['valor_icms'] = $valorIcms;
	}

	public function getBaseCalculoFcpAttribute()
	{
		return (double)$this->attributes['base_calculo_fcp'];
	}

	public function setBaseCalculoFcpAttribute($baseCalculoFcp)
	{
		$this->attributes['base_calculo_fcp'] = $baseCalculoFcp;
	}

	public function getPercentualFcpAttribute()
	{
		return (double)$this->attributes['percentual_fcp'];
	}

	public function setPercentualFcpAttribute($percentualFcp)
	{
		$this->attributes['percentual_fcp'] = $percentualFcp;
	}

	public function getValorFcpAttribute()
	{
		return (double)$this->attributes['valor_fcp'];
	}

	public function setValorFcpAttribute($valorFcp)
	{
		$this->attributes['valor_fcp'] = $valorFcp;
	}

	public function getModalidadeBcIcmsStAttribute()
	{
		return $this->attributes['modalidade_bc_icms_st'];
	}

	public function setModalidadeBcIcmsStAttribute($modalidadeBcIcmsSt)
	{
		$this->attributes['modalidade_bc_icms_st'] = $modalidadeBcIcmsSt;
	}

	public function getPercentualMvaIcmsStAttribute()
	{
		return (double)$this->attributes['percentual_mva_icms_st'];
	}

	public function setPercentualMvaIcmsStAttribute($percentualMvaIcmsSt)
	{
		$this->attributes['percentual_mva_icms_st'] = $percentualMvaIcmsSt;
	}

	public function getPercentualReducaoBcIcmsStAttribute()
	{
		return (double)$this->attributes['percentual_reducao_bc_icms_st'];
	}

	public function setPercentualReducaoBcIcmsStAttribute($percentualReducaoBcIcmsSt)
	{
		$this->attributes['percentual_reducao_bc_icms_st'] = $percentualReducaoBcIcmsSt;
	}

	public function getValorBaseCalculoIcmsStAttribute()
	{
		return (double)$this->attributes['valor_base_calculo_icms_st'];
	}

	public function setValorBaseCalculoIcmsStAttribute($valorBaseCalculoIcmsSt)
	{
		$this->attributes['valor_base_calculo_icms_st'] = $valorBaseCalculoIcmsSt;
	}

	public function getAliquotaIcmsStAttribute()
	{
		return (double)$this->attributes['aliquota_icms_st'];
	}

	public function setAliquotaIcmsStAttribute($aliquotaIcmsSt)
	{
		$this->attributes['aliquota_icms_st'] = $aliquotaIcmsSt;
	}

	public function getValorIcmsStAttribute()
	{
		return (double)$this->attributes['valor_icms_st'];
	}

	public function setValorIcmsStAttribute($valorIcmsSt)
	{
		$this->attributes['valor_icms_st'] = $valorIcmsSt;
	}

	public function getBaseCalculoFcpStAttribute()
	{
		return (double)$this->attributes['base_calculo_fcp_st'];
	}

	public function setBaseCalculoFcpStAttribute($baseCalculoFcpSt)
	{
		$this->attributes['base_calculo_fcp_st'] = $baseCalculoFcpSt;
	}

	public function getPercentualFcpStAttribute()
	{
		return (double)$this->attributes['percentual_fcp_st'];
	}

	public function setPercentualFcpStAttribute($percentualFcpSt)
	{
		$this->attributes['percentual_fcp_st'] = $percentualFcpSt;
	}

	public function getValorFcpStAttribute()
	{
		return (double)$this->attributes['valor_fcp_st'];
	}

	public function setValorFcpStAttribute($valorFcpSt)
	{
		$this->attributes['valor_fcp_st'] = $valorFcpSt;
	}

	public function getUfStAttribute()
	{
		return $this->attributes['uf_st'];
	}

	public function setUfStAttribute($ufSt)
	{
		$this->attributes['uf_st'] = $ufSt;
	}

	public function getPercentualBcOperacaoPropriaAttribute()
	{
		return (double)$this->attributes['percentual_bc_operacao_propria'];
	}

	public function setPercentualBcOperacaoPropriaAttribute($percentualBcOperacaoPropria)
	{
		$this->attributes['percentual_bc_operacao_propria'] = $percentualBcOperacaoPropria;
	}

	public function getValorBcIcmsStRetidoAttribute()
	{
		return (double)$this->attributes['valor_bc_icms_st_retido'];
	}

	public function setValorBcIcmsStRetidoAttribute($valorBcIcmsStRetido)
	{
		$this->attributes['valor_bc_icms_st_retido'] = $valorBcIcmsStRetido;
	}

	public function getAliquotaSuportadaConsumidorAttribute()
	{
		return (double)$this->attributes['aliquota_suportada_consumidor'];
	}

	public function setAliquotaSuportadaConsumidorAttribute($aliquotaSuportadaConsumidor)
	{
		$this->attributes['aliquota_suportada_consumidor'] = $aliquotaSuportadaConsumidor;
	}

	public function getValorIcmsSubstitutoAttribute()
	{
		return (double)$this->attributes['valor_icms_substituto'];
	}

	public function setValorIcmsSubstitutoAttribute($valorIcmsSubstituto)
	{
		$this->attributes['valor_icms_substituto'] = $valorIcmsSubstituto;
	}

	public function getValorIcmsStRetidoAttribute()
	{
		return (double)$this->attributes['valor_icms_st_retido'];
	}

	public function setValorIcmsStRetidoAttribute($valorIcmsStRetido)
	{
		$this->attributes['valor_icms_st_retido'] = $valorIcmsStRetido;
	}

	public function getBaseCalculoFcpStRetidoAttribute()
	{
		return (double)$this->attributes['base_calculo_fcp_st_retido'];
	}

	public function setBaseCalculoFcpStRetidoAttribute($baseCalculoFcpStRetido)
	{
		$this->attributes['base_calculo_fcp_st_retido'] = $baseCalculoFcpStRetido;
	}

	public function getPercentualFcpStRetidoAttribute()
	{
		return (double)$this->attributes['percentual_fcp_st_retido'];
	}

	public function setPercentualFcpStRetidoAttribute($percentualFcpStRetido)
	{
		$this->attributes['percentual_fcp_st_retido'] = $percentualFcpStRetido;
	}

	public function getValorFcpStRetidoAttribute()
	{
		return (double)$this->attributes['valor_fcp_st_retido'];
	}

	public function setValorFcpStRetidoAttribute($valorFcpStRetido)
	{
		$this->attributes['valor_fcp_st_retido'] = $valorFcpStRetido;
	}

	public function getMotivoDesoneracaoIcmsAttribute()
	{
		return $this->attributes['motivo_desoneracao_icms'];
	}

	public function setMotivoDesoneracaoIcmsAttribute($motivoDesoneracaoIcms)
	{
		$this->attributes['motivo_desoneracao_icms'] = $motivoDesoneracaoIcms;
	}

	public function getValorIcmsDesoneradoAttribute()
	{
		return (double)$this->attributes['valor_icms_desonerado'];
	}

	public function setValorIcmsDesoneradoAttribute($valorIcmsDesonerado)
	{
		$this->attributes['valor_icms_desonerado'] = $valorIcmsDesonerado;
	}

	public function getAliquotaCreditoIcmsSnAttribute()
	{
		return (double)$this->attributes['aliquota_credito_icms_sn'];
	}

	public function setAliquotaCreditoIcmsSnAttribute($aliquotaCreditoIcmsSn)
	{
		$this->attributes['aliquota_credito_icms_sn'] = $aliquotaCreditoIcmsSn;
	}

	public function getValorCreditoIcmsSnAttribute()
	{
		return (double)$this->attributes['valor_credito_icms_sn'];
	}

	public function setValorCreditoIcmsSnAttribute($valorCreditoIcmsSn)
	{
		$this->attributes['valor_credito_icms_sn'] = $valorCreditoIcmsSn;
	}

	public function getValorBcIcmsStDestinoAttribute()
	{
		return (double)$this->attributes['valor_bc_icms_st_destino'];
	}

	public function setValorBcIcmsStDestinoAttribute($valorBcIcmsStDestino)
	{
		$this->attributes['valor_bc_icms_st_destino'] = $valorBcIcmsStDestino;
	}

	public function getValorIcmsStDestinoAttribute()
	{
		return (double)$this->attributes['valor_icms_st_destino'];
	}

	public function setValorIcmsStDestinoAttribute($valorIcmsStDestino)
	{
		$this->attributes['valor_icms_st_destino'] = $valorIcmsStDestino;
	}

	public function getPercentualReducaoBcEfetivoAttribute()
	{
		return (double)$this->attributes['percentual_reducao_bc_efetivo'];
	}

	public function setPercentualReducaoBcEfetivoAttribute($percentualReducaoBcEfetivo)
	{
		$this->attributes['percentual_reducao_bc_efetivo'] = $percentualReducaoBcEfetivo;
	}

	public function getValorBcEfetivoAttribute()
	{
		return (double)$this->attributes['valor_bc_efetivo'];
	}

	public function setValorBcEfetivoAttribute($valorBcEfetivo)
	{
		$this->attributes['valor_bc_efetivo'] = $valorBcEfetivo;
	}

	public function getAliquotaIcmsEfetivoAttribute()
	{
		return (double)$this->attributes['aliquota_icms_efetivo'];
	}

	public function setAliquotaIcmsEfetivoAttribute($aliquotaIcmsEfetivo)
	{
		$this->attributes['aliquota_icms_efetivo'] = $aliquotaIcmsEfetivo;
	}

	public function getValorIcmsEfetivoAttribute()
	{
		return (double)$this->attributes['valor_icms_efetivo'];
	}

	public function setValorIcmsEfetivoAttribute($valorIcmsEfetivo)
	{
		$this->attributes['valor_icms_efetivo'] = $valorIcmsEfetivo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setOrigemMercadoriaAttribute($object->origemMercadoria);
				$this->setCstIcmsAttribute($object->cstIcms);
				$this->setCsosnAttribute($object->csosn);
				$this->setModalidadeBcIcmsAttribute($object->modalidadeBcIcms);
				$this->setPercentualReducaoBcIcmsAttribute($object->percentualReducaoBcIcms);
				$this->setValorBcIcmsAttribute($object->valorBcIcms);
				$this->setAliquotaIcmsAttribute($object->aliquotaIcms);
				$this->setValorIcmsOperacaoAttribute($object->valorIcmsOperacao);
				$this->setPercentualDiferimentoAttribute($object->percentualDiferimento);
				$this->setValorIcmsDiferidoAttribute($object->valorIcmsDiferido);
				$this->setValorIcmsAttribute($object->valorIcms);
				$this->setBaseCalculoFcpAttribute($object->baseCalculoFcp);
				$this->setPercentualFcpAttribute($object->percentualFcp);
				$this->setValorFcpAttribute($object->valorFcp);
				$this->setModalidadeBcIcmsStAttribute($object->modalidadeBcIcmsSt);
				$this->setPercentualMvaIcmsStAttribute($object->percentualMvaIcmsSt);
				$this->setPercentualReducaoBcIcmsStAttribute($object->percentualReducaoBcIcmsSt);
				$this->setValorBaseCalculoIcmsStAttribute($object->valorBaseCalculoIcmsSt);
				$this->setAliquotaIcmsStAttribute($object->aliquotaIcmsSt);
				$this->setValorIcmsStAttribute($object->valorIcmsSt);
				$this->setBaseCalculoFcpStAttribute($object->baseCalculoFcpSt);
				$this->setPercentualFcpStAttribute($object->percentualFcpSt);
				$this->setValorFcpStAttribute($object->valorFcpSt);
				$this->setUfStAttribute($object->ufSt);
				$this->setPercentualBcOperacaoPropriaAttribute($object->percentualBcOperacaoPropria);
				$this->setValorBcIcmsStRetidoAttribute($object->valorBcIcmsStRetido);
				$this->setAliquotaSuportadaConsumidorAttribute($object->aliquotaSuportadaConsumidor);
				$this->setValorIcmsSubstitutoAttribute($object->valorIcmsSubstituto);
				$this->setValorIcmsStRetidoAttribute($object->valorIcmsStRetido);
				$this->setBaseCalculoFcpStRetidoAttribute($object->baseCalculoFcpStRetido);
				$this->setPercentualFcpStRetidoAttribute($object->percentualFcpStRetido);
				$this->setValorFcpStRetidoAttribute($object->valorFcpStRetido);
				$this->setMotivoDesoneracaoIcmsAttribute($object->motivoDesoneracaoIcms);
				$this->setValorIcmsDesoneradoAttribute($object->valorIcmsDesonerado);
				$this->setAliquotaCreditoIcmsSnAttribute($object->aliquotaCreditoIcmsSn);
				$this->setValorCreditoIcmsSnAttribute($object->valorCreditoIcmsSn);
				$this->setValorBcIcmsStDestinoAttribute($object->valorBcIcmsStDestino);
				$this->setValorIcmsStDestinoAttribute($object->valorIcmsStDestino);
				$this->setPercentualReducaoBcEfetivoAttribute($object->percentualReducaoBcEfetivo);
				$this->setValorBcEfetivoAttribute($object->valorBcEfetivo);
				$this->setAliquotaIcmsEfetivoAttribute($object->aliquotaIcmsEfetivo);
				$this->setValorIcmsEfetivoAttribute($object->valorIcmsEfetivo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'origemMercadoria' => $this->getOrigemMercadoriaAttribute(),
				'cstIcms' => $this->getCstIcmsAttribute(),
				'csosn' => $this->getCsosnAttribute(),
				'modalidadeBcIcms' => $this->getModalidadeBcIcmsAttribute(),
				'percentualReducaoBcIcms' => $this->getPercentualReducaoBcIcmsAttribute(),
				'valorBcIcms' => $this->getValorBcIcmsAttribute(),
				'aliquotaIcms' => $this->getAliquotaIcmsAttribute(),
				'valorIcmsOperacao' => $this->getValorIcmsOperacaoAttribute(),
				'percentualDiferimento' => $this->getPercentualDiferimentoAttribute(),
				'valorIcmsDiferido' => $this->getValorIcmsDiferidoAttribute(),
				'valorIcms' => $this->getValorIcmsAttribute(),
				'baseCalculoFcp' => $this->getBaseCalculoFcpAttribute(),
				'percentualFcp' => $this->getPercentualFcpAttribute(),
				'valorFcp' => $this->getValorFcpAttribute(),
				'modalidadeBcIcmsSt' => $this->getModalidadeBcIcmsStAttribute(),
				'percentualMvaIcmsSt' => $this->getPercentualMvaIcmsStAttribute(),
				'percentualReducaoBcIcmsSt' => $this->getPercentualReducaoBcIcmsStAttribute(),
				'valorBaseCalculoIcmsSt' => $this->getValorBaseCalculoIcmsStAttribute(),
				'aliquotaIcmsSt' => $this->getAliquotaIcmsStAttribute(),
				'valorIcmsSt' => $this->getValorIcmsStAttribute(),
				'baseCalculoFcpSt' => $this->getBaseCalculoFcpStAttribute(),
				'percentualFcpSt' => $this->getPercentualFcpStAttribute(),
				'valorFcpSt' => $this->getValorFcpStAttribute(),
				'ufSt' => $this->getUfStAttribute(),
				'percentualBcOperacaoPropria' => $this->getPercentualBcOperacaoPropriaAttribute(),
				'valorBcIcmsStRetido' => $this->getValorBcIcmsStRetidoAttribute(),
				'aliquotaSuportadaConsumidor' => $this->getAliquotaSuportadaConsumidorAttribute(),
				'valorIcmsSubstituto' => $this->getValorIcmsSubstitutoAttribute(),
				'valorIcmsStRetido' => $this->getValorIcmsStRetidoAttribute(),
				'baseCalculoFcpStRetido' => $this->getBaseCalculoFcpStRetidoAttribute(),
				'percentualFcpStRetido' => $this->getPercentualFcpStRetidoAttribute(),
				'valorFcpStRetido' => $this->getValorFcpStRetidoAttribute(),
				'motivoDesoneracaoIcms' => $this->getMotivoDesoneracaoIcmsAttribute(),
				'valorIcmsDesonerado' => $this->getValorIcmsDesoneradoAttribute(),
				'aliquotaCreditoIcmsSn' => $this->getAliquotaCreditoIcmsSnAttribute(),
				'valorCreditoIcmsSn' => $this->getValorCreditoIcmsSnAttribute(),
				'valorBcIcmsStDestino' => $this->getValorBcIcmsStDestinoAttribute(),
				'valorIcmsStDestino' => $this->getValorIcmsStDestinoAttribute(),
				'percentualReducaoBcEfetivo' => $this->getPercentualReducaoBcEfetivoAttribute(),
				'valorBcEfetivo' => $this->getValorBcEfetivoAttribute(),
				'aliquotaIcmsEfetivo' => $this->getAliquotaIcmsEfetivoAttribute(),
				'valorIcmsEfetivo' => $this->getValorIcmsEfetivoAttribute(),
			];
	}
}