<?php
declare(strict_types=1);

class VendaCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'venda_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdVendaOrcamentoCabecalhoAttribute()
	{
		return $this->attributes['id_venda_orcamento_cabecalho'];
	}

	public function setIdVendaOrcamentoCabecalhoAttribute($idVendaOrcamentoCabecalho)
	{
		$this->attributes['id_venda_orcamento_cabecalho'] = $idVendaOrcamentoCabecalho;
	}

	public function getIdVendaCondicoesPagamentoAttribute()
	{
		return $this->attributes['id_venda_condicoes_pagamento'];
	}

	public function setIdVendaCondicoesPagamentoAttribute($idVendaCondicoesPagamento)
	{
		$this->attributes['id_venda_condicoes_pagamento'] = $idVendaCondicoesPagamento;
	}

	public function getIdNotaFiscalTipoAttribute()
	{
		return $this->attributes['id_nota_fiscal_tipo'];
	}

	public function setIdNotaFiscalTipoAttribute($idNotaFiscalTipo)
	{
		$this->attributes['id_nota_fiscal_tipo'] = $idNotaFiscalTipo;
	}

	public function getIdTransportadoraAttribute()
	{
		return $this->attributes['id_transportadora'];
	}

	public function setIdTransportadoraAttribute($idTransportadora)
	{
		$this->attributes['id_transportadora'] = $idTransportadora;
	}

	public function getDataVendaAttribute()
	{
		return $this->attributes['data_venda'];
	}

	public function setDataVendaAttribute($dataVenda)
	{
		$this->attributes['data_venda'] = $dataVenda;
	}

	public function getDataSaidaAttribute()
	{
		return $this->attributes['data_saida'];
	}

	public function setDataSaidaAttribute($dataSaida)
	{
		$this->attributes['data_saida'] = $dataSaida;
	}

	public function getHoraSaidaAttribute()
	{
		return $this->attributes['hora_saida'];
	}

	public function setHoraSaidaAttribute($horaSaida)
	{
		$this->attributes['hora_saida'] = $horaSaida;
	}

	public function getNumeroFaturaAttribute()
	{
		return $this->attributes['numero_fatura'];
	}

	public function setNumeroFaturaAttribute($numeroFatura)
	{
		$this->attributes['numero_fatura'] = $numeroFatura;
	}

	public function getLocalEntregaAttribute()
	{
		return $this->attributes['local_entrega'];
	}

	public function setLocalEntregaAttribute($localEntrega)
	{
		$this->attributes['local_entrega'] = $localEntrega;
	}

	public function getLocalCobrancaAttribute()
	{
		return $this->attributes['local_cobranca'];
	}

	public function setLocalCobrancaAttribute($localCobranca)
	{
		$this->attributes['local_cobranca'] = $localCobranca;
	}

	public function getValorSubtotalAttribute()
	{
		return (double)$this->attributes['valor_subtotal'];
	}

	public function setValorSubtotalAttribute($valorSubtotal)
	{
		$this->attributes['valor_subtotal'] = $valorSubtotal;
	}

	public function getTaxaComissaoAttribute()
	{
		return (double)$this->attributes['taxa_comissao'];
	}

	public function setTaxaComissaoAttribute($taxaComissao)
	{
		$this->attributes['taxa_comissao'] = $taxaComissao;
	}

	public function getValorComissaoAttribute()
	{
		return (double)$this->attributes['valor_comissao'];
	}

	public function setValorComissaoAttribute($valorComissao)
	{
		$this->attributes['valor_comissao'] = $valorComissao;
	}

	public function getTaxaDescontoAttribute()
	{
		return (double)$this->attributes['taxa_desconto'];
	}

	public function setTaxaDescontoAttribute($taxaDesconto)
	{
		$this->attributes['taxa_desconto'] = $taxaDesconto;
	}

	public function getValorDescontoAttribute()
	{
		return (double)$this->attributes['valor_desconto'];
	}

	public function setValorDescontoAttribute($valorDesconto)
	{
		$this->attributes['valor_desconto'] = $valorDesconto;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getTipoFreteAttribute()
	{
		return $this->attributes['tipo_frete'];
	}

	public function setTipoFreteAttribute($tipoFrete)
	{
		$this->attributes['tipo_frete'] = $tipoFrete;
	}

	public function getFormaPagamentoAttribute()
	{
		return $this->attributes['forma_pagamento'];
	}

	public function setFormaPagamentoAttribute($formaPagamento)
	{
		$this->attributes['forma_pagamento'] = $formaPagamento;
	}

	public function getValorFreteAttribute()
	{
		return (double)$this->attributes['valor_frete'];
	}

	public function setValorFreteAttribute($valorFrete)
	{
		$this->attributes['valor_frete'] = $valorFrete;
	}

	public function getValorSeguroAttribute()
	{
		return (double)$this->attributes['valor_seguro'];
	}

	public function setValorSeguroAttribute($valorSeguro)
	{
		$this->attributes['valor_seguro'] = $valorSeguro;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	public function getDiaFixoParcelaAttribute()
	{
		return $this->attributes['dia_fixo_parcela'];
	}

	public function setDiaFixoParcelaAttribute($diaFixoParcela)
	{
		$this->attributes['dia_fixo_parcela'] = $diaFixoParcela;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdVendaOrcamentoCabecalhoAttribute($object->idVendaOrcamentoCabecalho);
				$this->setIdVendaCondicoesPagamentoAttribute($object->idVendaCondicoesPagamento);
				$this->setIdNotaFiscalTipoAttribute($object->idNotaFiscalTipo);
				$this->setIdTransportadoraAttribute($object->idTransportadora);
				$this->setDataVendaAttribute($object->dataVenda);
				$this->setDataSaidaAttribute($object->dataSaida);
				$this->setHoraSaidaAttribute($object->horaSaida);
				$this->setNumeroFaturaAttribute($object->numeroFatura);
				$this->setLocalEntregaAttribute($object->localEntrega);
				$this->setLocalCobrancaAttribute($object->localCobranca);
				$this->setValorSubtotalAttribute($object->valorSubtotal);
				$this->setTaxaComissaoAttribute($object->taxaComissao);
				$this->setValorComissaoAttribute($object->valorComissao);
				$this->setTaxaDescontoAttribute($object->taxaDesconto);
				$this->setValorDescontoAttribute($object->valorDesconto);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setTipoFreteAttribute($object->tipoFrete);
				$this->setFormaPagamentoAttribute($object->formaPagamento);
				$this->setValorFreteAttribute($object->valorFrete);
				$this->setValorSeguroAttribute($object->valorSeguro);
				$this->setObservacaoAttribute($object->observacao);
				$this->setSituacaoAttribute($object->situacao);
				$this->setDiaFixoParcelaAttribute($object->diaFixoParcela);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idVendaOrcamentoCabecalho' => $this->getIdVendaOrcamentoCabecalhoAttribute(),
				'idVendaCondicoesPagamento' => $this->getIdVendaCondicoesPagamentoAttribute(),
				'idNotaFiscalTipo' => $this->getIdNotaFiscalTipoAttribute(),
				'idTransportadora' => $this->getIdTransportadoraAttribute(),
				'dataVenda' => $this->getDataVendaAttribute(),
				'dataSaida' => $this->getDataSaidaAttribute(),
				'horaSaida' => $this->getHoraSaidaAttribute(),
				'numeroFatura' => $this->getNumeroFaturaAttribute(),
				'localEntrega' => $this->getLocalEntregaAttribute(),
				'localCobranca' => $this->getLocalCobrancaAttribute(),
				'valorSubtotal' => $this->getValorSubtotalAttribute(),
				'taxaComissao' => $this->getTaxaComissaoAttribute(),
				'valorComissao' => $this->getValorComissaoAttribute(),
				'taxaDesconto' => $this->getTaxaDescontoAttribute(),
				'valorDesconto' => $this->getValorDescontoAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'tipoFrete' => $this->getTipoFreteAttribute(),
				'formaPagamento' => $this->getFormaPagamentoAttribute(),
				'valorFrete' => $this->getValorFreteAttribute(),
				'valorSeguro' => $this->getValorSeguroAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'diaFixoParcela' => $this->getDiaFixoParcelaAttribute(),
			];
	}
}