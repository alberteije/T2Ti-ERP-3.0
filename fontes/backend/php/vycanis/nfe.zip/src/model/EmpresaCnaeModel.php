<?php
declare(strict_types=1);

class EmpresaCnaeModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'empresa_cnae';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'cnaeModel',
	];

	/**
		* Relations
		*/
	public function empresaModel()
	{
		return $this->belongsTo(EmpresaModel::class, 'id_empresa', 'id');
	}

	public function cnaeModel()
	{
		return $this->belongsTo(CnaeModel::class, 'id_cnae', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getPrincipalAttribute()
	{
		return $this->attributes['principal'];
	}

	public function setPrincipalAttribute($principal)
	{
		$this->attributes['principal'] = $principal;
	}

	public function getRamoAtividadeAttribute()
	{
		return $this->attributes['ramo_atividade'];
	}

	public function setRamoAtividadeAttribute($ramoAtividade)
	{
		$this->attributes['ramo_atividade'] = $ramoAtividade;
	}

	public function getObjetoSocialAttribute()
	{
		return $this->attributes['objeto_social'];
	}

	public function setObjetoSocialAttribute($objetoSocial)
	{
		$this->attributes['objeto_social'] = $objetoSocial;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setPrincipalAttribute($object->principal);
				$this->setRamoAtividadeAttribute($object->ramoAtividade);
				$this->setObjetoSocialAttribute($object->objetoSocial);

				// link objects - lookups
				$cnaeModel = new CnaeModel();
				$cnaeModel->mapping($object->cnaeModel);
				$this->cnaeModel()->associate($cnaeModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'principal' => $this->getPrincipalAttribute(),
				'ramoAtividade' => $this->getRamoAtividadeAttribute(),
				'objetoSocial' => $this->getObjetoSocialAttribute(),
				'cnaeModel' => $this->cnaeModel,
			];
	}
}