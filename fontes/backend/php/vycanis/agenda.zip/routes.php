<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// agenda-compromisso
$app->get('/agenda-compromisso[/]', \AgendaCompromissoController::class . RESULT_LIST);
$app->get('/agenda-compromisso/{id}', \AgendaCompromissoController::class . RESULT_OBJECT);
$app->post('/agenda-compromisso', \AgendaCompromissoController::class . INSERT);
$app->put('/agenda-compromisso', \AgendaCompromissoController::class . UPDATE);
$app->delete('/agenda-compromisso/{id}', \AgendaCompromissoController::class . DELETE);
$app->options('/agenda-compromisso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/agenda-compromisso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/agenda-compromisso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// recado-remetente
$app->get('/recado-remetente[/]', \RecadoRemetenteController::class . RESULT_LIST);
$app->get('/recado-remetente/{id}', \RecadoRemetenteController::class . RESULT_OBJECT);
$app->post('/recado-remetente', \RecadoRemetenteController::class . INSERT);
$app->put('/recado-remetente', \RecadoRemetenteController::class . UPDATE);
$app->delete('/recado-remetente/{id}', \RecadoRemetenteController::class . DELETE);
$app->options('/recado-remetente', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/recado-remetente/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/recado-remetente/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// agenda-categoria-compromisso
$app->get('/agenda-categoria-compromisso[/]', \AgendaCategoriaCompromissoController::class . RESULT_LIST);
$app->get('/agenda-categoria-compromisso/{id}', \AgendaCategoriaCompromissoController::class . RESULT_OBJECT);
$app->post('/agenda-categoria-compromisso', \AgendaCategoriaCompromissoController::class . INSERT);
$app->put('/agenda-categoria-compromisso', \AgendaCategoriaCompromissoController::class . UPDATE);
$app->delete('/agenda-categoria-compromisso/{id}', \AgendaCategoriaCompromissoController::class . DELETE);
$app->options('/agenda-categoria-compromisso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/agenda-categoria-compromisso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/agenda-categoria-compromisso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// reuniao-sala
$app->get('/reuniao-sala[/]', \ReuniaoSalaController::class . RESULT_LIST);
$app->get('/reuniao-sala/{id}', \ReuniaoSalaController::class . RESULT_OBJECT);
$app->post('/reuniao-sala', \ReuniaoSalaController::class . INSERT);
$app->put('/reuniao-sala', \ReuniaoSalaController::class . UPDATE);
$app->delete('/reuniao-sala/{id}', \ReuniaoSalaController::class . DELETE);
$app->options('/reuniao-sala', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/reuniao-sala/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/reuniao-sala/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-colaborador
$app->get('/view-pessoa-colaborador[/]', \ViewPessoaColaboradorController::class . RESULT_LIST);
$app->get('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . RESULT_OBJECT);
$app->post('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . INSERT);
$app->put('/view-pessoa-colaborador', \ViewPessoaColaboradorController::class . UPDATE);
$app->delete('/view-pessoa-colaborador/{id}', \ViewPessoaColaboradorController::class . DELETE);
$app->options('/view-pessoa-colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

