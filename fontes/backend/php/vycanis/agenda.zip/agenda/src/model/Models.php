<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'AgendaNotificacaoModel.php';
include 'AgendaCompromissoConvidadoModel.php';
include 'ReuniaoSalaEventoModel.php';
include 'RecadoDestinatarioModel.php';
include 'AgendaCompromissoModel.php';
include 'RecadoRemetenteModel.php';
include 'AgendaCategoriaCompromissoModel.php';
include 'ReuniaoSalaModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';