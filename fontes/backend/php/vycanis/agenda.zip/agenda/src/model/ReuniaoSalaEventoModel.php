<?php
declare(strict_types=1);

class ReuniaoSalaEventoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'reuniao_sala_evento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'reuniaoSalaModel',
	];

	/**
		* Relations
		*/
	public function agendaCompromissoModel()
	{
		return $this->belongsTo(AgendaCompromissoModel::class, 'id_agenda_compromisso', 'id');
	}

	public function reuniaoSalaModel()
	{
		return $this->belongsTo(ReuniaoSalaModel::class, 'id_reuniao_sala', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataReservaAttribute()
	{
		return $this->attributes['data_reserva'];
	}

	public function setDataReservaAttribute($dataReserva)
	{
		$this->attributes['data_reserva'] = $dataReserva;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataReservaAttribute($object->dataReserva);

				// link objects - lookups
				$reuniaoSalaModel = new ReuniaoSalaModel();
				$reuniaoSalaModel->mapping($object->reuniaoSalaModel);
				$this->reuniaoSalaModel()->associate($reuniaoSalaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataReserva' => $this->getDataReservaAttribute(),
				'reuniaoSalaModel' => $this->reuniaoSalaModel,
			];
	}
}