<?php
class ReuniaoSalaService extends ServiceBase
{
  public function getList()
  {
    return ReuniaoSalaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ReuniaoSalaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ReuniaoSalaModel::find($id);
  }

}