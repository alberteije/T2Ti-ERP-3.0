<?php
class AgendaCategoriaCompromissoService extends ServiceBase
{
  public function getList()
  {
    return AgendaCategoriaCompromissoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return AgendaCategoriaCompromissoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return AgendaCategoriaCompromissoModel::find($id);
  }

}