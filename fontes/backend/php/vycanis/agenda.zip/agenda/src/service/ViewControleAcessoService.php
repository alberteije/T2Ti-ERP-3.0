<?php
class ViewControleAcessoService extends ServiceBase
{
  public function getList()
  {
    return ViewControleAcessoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ViewControleAcessoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ViewControleAcessoModel::find($id);
  }

}