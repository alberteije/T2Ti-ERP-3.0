<?php
declare(strict_types=1);

class AgendaNotificacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'agenda_notificacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function agendaCompromissoModel()
	{
		return $this->belongsTo(AgendaCompromissoModel::class, 'id_agenda_compromisso', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataNotificacaoAttribute()
	{
		return $this->attributes['data_notificacao'];
	}

	public function setDataNotificacaoAttribute($dataNotificacao)
	{
		$this->attributes['data_notificacao'] = $dataNotificacao;
	}

	public function getHoraAttribute()
	{
		return $this->attributes['hora'];
	}

	public function setHoraAttribute($hora)
	{
		$this->attributes['hora'] = $hora;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataNotificacaoAttribute($object->dataNotificacao);
				$this->setHoraAttribute($object->hora);
				$this->setTipoAttribute($object->tipo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataNotificacao' => $this->getDataNotificacaoAttribute(),
				'hora' => $this->getHoraAttribute(),
				'tipo' => $this->getTipoAttribute(),
			];
	}
}