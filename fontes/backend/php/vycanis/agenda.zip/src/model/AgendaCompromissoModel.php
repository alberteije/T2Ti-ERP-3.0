<?php
declare(strict_types=1);

class AgendaCompromissoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'agenda_compromisso';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'agendaNotificacaoModelList',
		'agendaCompromissoConvidadoModelList',
		'reuniaoSalaEventoModelList',
		'viewPessoaColaboradorModel',
		'agendaCategoriaCompromissoModel',
	];

	/**
		* Relations
		*/
	public function agendaNotificacaoModelList()
{
	return $this->hasMany(AgendaNotificacaoModel::class, 'id_agenda_compromisso', 'id');
}

	public function agendaCompromissoConvidadoModelList()
{
	return $this->hasMany(AgendaCompromissoConvidadoModel::class, 'id_agenda_compromisso', 'id');
}

	public function reuniaoSalaEventoModelList()
{
	return $this->hasMany(ReuniaoSalaEventoModel::class, 'id_agenda_compromisso', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}

	public function agendaCategoriaCompromissoModel()
	{
		return $this->belongsTo(AgendaCategoriaCompromissoModel::class, 'id_agenda_categoria_compromisso', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataCompromissoAttribute()
	{
		return $this->attributes['data_compromisso'];
	}

	public function setDataCompromissoAttribute($dataCompromisso)
	{
		$this->attributes['data_compromisso'] = $dataCompromisso;
	}

	public function getHoraAttribute()
	{
		return $this->attributes['hora'];
	}

	public function setHoraAttribute($hora)
	{
		$this->attributes['hora'] = $hora;
	}

	public function getDuracaoAttribute()
	{
		return $this->attributes['duracao'];
	}

	public function setDuracaoAttribute($duracao)
	{
		$this->attributes['duracao'] = $duracao;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getOndeAttribute()
	{
		return $this->attributes['onde'];
	}

	public function setOndeAttribute($onde)
	{
		$this->attributes['onde'] = $onde;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataCompromissoAttribute($object->dataCompromisso);
				$this->setHoraAttribute($object->hora);
				$this->setDuracaoAttribute($object->duracao);
				$this->setTipoAttribute($object->tipo);
				$this->setOndeAttribute($object->onde);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
				$agendaCategoriaCompromissoModel = new AgendaCategoriaCompromissoModel();
				$agendaCategoriaCompromissoModel->mapping($object->agendaCategoriaCompromissoModel);
				$this->agendaCategoriaCompromissoModel()->associate($agendaCategoriaCompromissoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataCompromisso' => $this->getDataCompromissoAttribute(),
				'hora' => $this->getHoraAttribute(),
				'duracao' => $this->getDuracaoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'onde' => $this->getOndeAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'agendaNotificacaoModelList' => $this->agendaNotificacaoModelList,
				'agendaCompromissoConvidadoModelList' => $this->agendaCompromissoConvidadoModelList,
				'reuniaoSalaEventoModelList' => $this->reuniaoSalaEventoModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
				'agendaCategoriaCompromissoModel' => $this->agendaCategoriaCompromissoModel,
			];
	}
}