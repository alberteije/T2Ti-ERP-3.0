<?php
declare(strict_types=1);

class RecadoRemetenteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'recado_remetente';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'recadoDestinatarioModelList',
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function recadoDestinatarioModelList()
{
	return $this->hasMany(RecadoDestinatarioModel::class, 'id_recado_remetente', 'id');
}

	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataEnvioAttribute()
	{
		return $this->attributes['data_envio'];
	}

	public function setDataEnvioAttribute($dataEnvio)
	{
		$this->attributes['data_envio'] = $dataEnvio;
	}

	public function getHoraEnvioAttribute()
	{
		return $this->attributes['hora_envio'];
	}

	public function setHoraEnvioAttribute($horaEnvio)
	{
		$this->attributes['hora_envio'] = $horaEnvio;
	}

	public function getAssuntoAttribute()
	{
		return $this->attributes['assunto'];
	}

	public function setAssuntoAttribute($assunto)
	{
		$this->attributes['assunto'] = $assunto;
	}

	public function getTextoAttribute()
	{
		return $this->attributes['texto'];
	}

	public function setTextoAttribute($texto)
	{
		$this->attributes['texto'] = $texto;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataEnvioAttribute($object->dataEnvio);
				$this->setHoraEnvioAttribute($object->horaEnvio);
				$this->setAssuntoAttribute($object->assunto);
				$this->setTextoAttribute($object->texto);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataEnvio' => $this->getDataEnvioAttribute(),
				'horaEnvio' => $this->getHoraEnvioAttribute(),
				'assunto' => $this->getAssuntoAttribute(),
				'texto' => $this->getTextoAttribute(),
				'recadoDestinatarioModelList' => $this->recadoDestinatarioModelList,
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}