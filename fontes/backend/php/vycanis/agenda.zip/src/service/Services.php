<?php

include 'ServiceBase.php';

include 'AgendaCompromissoService.php';
include 'RecadoRemetenteService.php';
include 'AgendaCategoriaCompromissoService.php';
include 'ReuniaoSalaService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';