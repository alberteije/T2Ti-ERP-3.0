<?php
use Illuminate\Database\Capsule\Manager as DB;
class AgendaCompromissoService extends ServiceBase
{
	public function getList()
	{
		return AgendaCompromissoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return AgendaCompromissoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return AgendaCompromissoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// agendaNotificacao
		$agendaNotificacaoModelListJson = $objJson->agendaNotificacaoModelList;
		if ($agendaNotificacaoModelListJson != null) {
			for ($i = 0; $i < count($agendaNotificacaoModelListJson); $i++) {
				$agendaNotificacao = new AgendaNotificacaoModel();
				$agendaNotificacao->mapping($agendaNotificacaoModelListJson[$i]);
				$objModel->agendaNotificacaoModelList()->save($agendaNotificacao);
			}
		}

		// agendaCompromissoConvidado
		$agendaCompromissoConvidadoModelListJson = $objJson->agendaCompromissoConvidadoModelList;
		if ($agendaCompromissoConvidadoModelListJson != null) {
			for ($i = 0; $i < count($agendaCompromissoConvidadoModelListJson); $i++) {
				$agendaCompromissoConvidado = new AgendaCompromissoConvidadoModel();
				$agendaCompromissoConvidado->mapping($agendaCompromissoConvidadoModelListJson[$i]);
				$objModel->agendaCompromissoConvidadoModelList()->save($agendaCompromissoConvidado);
			}
		}

		// reuniaoSalaEvento
		$reuniaoSalaEventoModelListJson = $objJson->reuniaoSalaEventoModelList;
		if ($reuniaoSalaEventoModelListJson != null) {
			for ($i = 0; $i < count($reuniaoSalaEventoModelListJson); $i++) {
				$reuniaoSalaEvento = new ReuniaoSalaEventoModel();
				$reuniaoSalaEvento->mapping($reuniaoSalaEventoModelListJson[$i]);
				$objModel->reuniaoSalaEventoModelList()->save($reuniaoSalaEvento);
			}
		}

	}	

	public function deleteChildren($object)
	{
		AgendaNotificacaoModel::where('id_agenda_compromisso', $object->getIdAttribute())->delete();
		AgendaCompromissoConvidadoModel::where('id_agenda_compromisso', $object->getIdAttribute())->delete();
		ReuniaoSalaEventoModel::where('id_agenda_compromisso', $object->getIdAttribute())->delete();
	}	
 
}