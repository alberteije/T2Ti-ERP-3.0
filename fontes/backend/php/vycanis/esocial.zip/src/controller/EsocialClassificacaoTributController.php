<?php
class EsocialClassificacaoTributController extends ControllerBase
{

		private $esocialClassificacaoTributService = null;

		public function __construct()
		{	 
				$this->esocialClassificacaoTributService = new EsocialClassificacaoTributService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->esocialClassificacaoTributService->getListFilter($filter);
						} else {
								$resultList = $this->esocialClassificacaoTributService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList EsocialClassificacaoTribut]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->esocialClassificacaoTributService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject EsocialClassificacaoTribut]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject EsocialClassificacaoTribut]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert EsocialClassificacaoTribut]', null);
						}

						$objModel = new EsocialClassificacaoTributModel();
						$objModel->mapping($objJson);

						$this->esocialClassificacaoTributService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert EsocialClassificacaoTribut]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->esocialClassificacaoTributService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update EsocialClassificacaoTribut]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->esocialClassificacaoTributService->save($objFromDatabase);
								$objFromDatabase = $this->esocialClassificacaoTributService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update EsocialClassificacaoTribut]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->esocialClassificacaoTributService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete EsocialClassificacaoTribut]', null);
						} else {
								$this->esocialClassificacaoTributService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete EsocialClassificacaoTribut]', $e);
				}
		}
}
