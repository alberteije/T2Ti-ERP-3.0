<?php
class EsocialMotivoDesligamentoService extends ServiceBase
{
  public function getList()
  {
    return EsocialMotivoDesligamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EsocialMotivoDesligamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EsocialMotivoDesligamentoModel::find($id);
  }

}