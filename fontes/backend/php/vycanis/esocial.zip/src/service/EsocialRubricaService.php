<?php
class EsocialRubricaService extends ServiceBase
{
  public function getList()
  {
    return EsocialRubricaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EsocialRubricaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EsocialRubricaModel::find($id);
  }

}