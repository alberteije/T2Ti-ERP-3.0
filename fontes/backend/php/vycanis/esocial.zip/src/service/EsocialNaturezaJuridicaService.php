<?php
class EsocialNaturezaJuridicaService extends ServiceBase
{
  public function getList()
  {
    return EsocialNaturezaJuridicaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EsocialNaturezaJuridicaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EsocialNaturezaJuridicaModel::find($id);
  }

}