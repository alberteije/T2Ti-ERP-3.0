<?php
class EsocialTipoAfastamentoService extends ServiceBase
{
  public function getList()
  {
    return EsocialTipoAfastamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EsocialTipoAfastamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EsocialTipoAfastamentoModel::find($id);
  }

}