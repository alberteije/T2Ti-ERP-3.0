<?php
class EsocialClassificacaoTributService extends ServiceBase
{
  public function getList()
  {
    return EsocialClassificacaoTributModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EsocialClassificacaoTributModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EsocialClassificacaoTributModel::find($id);
  }

}