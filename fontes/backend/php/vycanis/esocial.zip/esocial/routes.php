<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// esocial-natureza-juridica
$app->get('/esocial-natureza-juridica[/]', \EsocialNaturezaJuridicaController::class . RESULT_LIST);
$app->get('/esocial-natureza-juridica/{id}', \EsocialNaturezaJuridicaController::class . RESULT_OBJECT);
$app->post('/esocial-natureza-juridica', \EsocialNaturezaJuridicaController::class . INSERT);
$app->put('/esocial-natureza-juridica', \EsocialNaturezaJuridicaController::class . UPDATE);
$app->delete('/esocial-natureza-juridica/{id}', \EsocialNaturezaJuridicaController::class . DELETE);
$app->options('/esocial-natureza-juridica', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-natureza-juridica/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-natureza-juridica/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// esocial-rubrica
$app->get('/esocial-rubrica[/]', \EsocialRubricaController::class . RESULT_LIST);
$app->get('/esocial-rubrica/{id}', \EsocialRubricaController::class . RESULT_OBJECT);
$app->post('/esocial-rubrica', \EsocialRubricaController::class . INSERT);
$app->put('/esocial-rubrica', \EsocialRubricaController::class . UPDATE);
$app->delete('/esocial-rubrica/{id}', \EsocialRubricaController::class . DELETE);
$app->options('/esocial-rubrica', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-rubrica/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-rubrica/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// esocial-tipo-afastamento
$app->get('/esocial-tipo-afastamento[/]', \EsocialTipoAfastamentoController::class . RESULT_LIST);
$app->get('/esocial-tipo-afastamento/{id}', \EsocialTipoAfastamentoController::class . RESULT_OBJECT);
$app->post('/esocial-tipo-afastamento', \EsocialTipoAfastamentoController::class . INSERT);
$app->put('/esocial-tipo-afastamento', \EsocialTipoAfastamentoController::class . UPDATE);
$app->delete('/esocial-tipo-afastamento/{id}', \EsocialTipoAfastamentoController::class . DELETE);
$app->options('/esocial-tipo-afastamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-tipo-afastamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-tipo-afastamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// esocial-motivo-desligamento
$app->get('/esocial-motivo-desligamento[/]', \EsocialMotivoDesligamentoController::class . RESULT_LIST);
$app->get('/esocial-motivo-desligamento/{id}', \EsocialMotivoDesligamentoController::class . RESULT_OBJECT);
$app->post('/esocial-motivo-desligamento', \EsocialMotivoDesligamentoController::class . INSERT);
$app->put('/esocial-motivo-desligamento', \EsocialMotivoDesligamentoController::class . UPDATE);
$app->delete('/esocial-motivo-desligamento/{id}', \EsocialMotivoDesligamentoController::class . DELETE);
$app->options('/esocial-motivo-desligamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-motivo-desligamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-motivo-desligamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// esocial-classificacao-tribut
$app->get('/esocial-classificacao-tribut[/]', \EsocialClassificacaoTributController::class . RESULT_LIST);
$app->get('/esocial-classificacao-tribut/{id}', \EsocialClassificacaoTributController::class . RESULT_OBJECT);
$app->post('/esocial-classificacao-tribut', \EsocialClassificacaoTributController::class . INSERT);
$app->put('/esocial-classificacao-tribut', \EsocialClassificacaoTributController::class . UPDATE);
$app->delete('/esocial-classificacao-tribut/{id}', \EsocialClassificacaoTributController::class . DELETE);
$app->options('/esocial-classificacao-tribut', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-classificacao-tribut/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/esocial-classificacao-tribut/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

