<?php
class EsocialNaturezaJuridicaController extends ControllerBase
{

		private $esocialNaturezaJuridicaService = null;

		public function __construct()
		{	 
				$this->esocialNaturezaJuridicaService = new EsocialNaturezaJuridicaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->esocialNaturezaJuridicaService->getListFilter($filter);
						} else {
								$resultList = $this->esocialNaturezaJuridicaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList EsocialNaturezaJuridica]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->esocialNaturezaJuridicaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject EsocialNaturezaJuridica]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject EsocialNaturezaJuridica]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert EsocialNaturezaJuridica]', null);
						}

						$objModel = new EsocialNaturezaJuridicaModel();
						$objModel->mapping($objJson);

						$this->esocialNaturezaJuridicaService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert EsocialNaturezaJuridica]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->esocialNaturezaJuridicaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update EsocialNaturezaJuridica]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->esocialNaturezaJuridicaService->save($objFromDatabase);
								$objFromDatabase = $this->esocialNaturezaJuridicaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update EsocialNaturezaJuridica]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->esocialNaturezaJuridicaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete EsocialNaturezaJuridica]', null);
						} else {
								$this->esocialNaturezaJuridicaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete EsocialNaturezaJuridica]', $e);
				}
		}
}
