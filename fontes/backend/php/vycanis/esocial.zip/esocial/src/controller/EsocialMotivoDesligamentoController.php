<?php
class EsocialMotivoDesligamentoController extends ControllerBase
{

		private $esocialMotivoDesligamentoService = null;

		public function __construct()
		{	 
				$this->esocialMotivoDesligamentoService = new EsocialMotivoDesligamentoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->esocialMotivoDesligamentoService->getListFilter($filter);
						} else {
								$resultList = $this->esocialMotivoDesligamentoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList EsocialMotivoDesligamento]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->esocialMotivoDesligamentoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject EsocialMotivoDesligamento]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject EsocialMotivoDesligamento]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert EsocialMotivoDesligamento]', null);
						}

						$objModel = new EsocialMotivoDesligamentoModel();
						$objModel->mapping($objJson);

						$this->esocialMotivoDesligamentoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert EsocialMotivoDesligamento]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->esocialMotivoDesligamentoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update EsocialMotivoDesligamento]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->esocialMotivoDesligamentoService->save($objFromDatabase);
								$objFromDatabase = $this->esocialMotivoDesligamentoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update EsocialMotivoDesligamento]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->esocialMotivoDesligamentoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete EsocialMotivoDesligamento]', null);
						} else {
								$this->esocialMotivoDesligamentoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete EsocialMotivoDesligamento]', $e);
				}
		}
}
