<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'EsocialNaturezaJuridicaModel.php';
include 'EsocialRubricaModel.php';
include 'EsocialTipoAfastamentoModel.php';
include 'EsocialMotivoDesligamentoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'EsocialClassificacaoTributModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';