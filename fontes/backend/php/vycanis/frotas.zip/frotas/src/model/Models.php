<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'FrotaIpvaControleModel.php';
include 'FrotaDpvatControleModel.php';
include 'FrotaVeiculoSinistroModel.php';
include 'FrotaVeiculoMovimentacaoModel.php';
include 'FrotaVeiculoPneuModel.php';
include 'FrotaVeiculoManutencaoModel.php';
include 'FrotaMultaControleModel.php';
include 'FrotaCombustivelControleModel.php';
include 'FrotaVeiculoModel.php';
include 'FrotaVeiculoTipoModel.php';
include 'FrotaCombustivelTipoModel.php';
include 'FrotaMotoristaModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'ViewPessoaColaboradorModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';