<?php
class FrotaMotoristaService extends ServiceBase
{
  public function getList()
  {
    return FrotaMotoristaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FrotaMotoristaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FrotaMotoristaModel::find($id);
  }

}