<?php

include 'ServiceBase.php';

include 'FrotaVeiculoService.php';
include 'FrotaVeiculoTipoService.php';
include 'FrotaCombustivelTipoService.php';
include 'FrotaMotoristaService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'ViewPessoaColaboradorService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';