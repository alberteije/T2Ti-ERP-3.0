<?php
class FrotaVeiculoTipoService extends ServiceBase
{
  public function getList()
  {
    return FrotaVeiculoTipoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FrotaVeiculoTipoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FrotaVeiculoTipoModel::find($id);
  }

}