<?php
use Illuminate\Database\Capsule\Manager as DB;
class FrotaVeiculoService extends ServiceBase
{
	public function getList()
	{
		return FrotaVeiculoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return FrotaVeiculoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return FrotaVeiculoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// frotaIpvaControle
		$frotaIpvaControleModelListJson = $objJson->frotaIpvaControleModelList;
		if ($frotaIpvaControleModelListJson != null) {
			for ($i = 0; $i < count($frotaIpvaControleModelListJson); $i++) {
				$frotaIpvaControle = new FrotaIpvaControleModel();
				$frotaIpvaControle->mapping($frotaIpvaControleModelListJson[$i]);
				$objModel->frotaIpvaControleModelList()->save($frotaIpvaControle);
			}
		}

		// frotaDpvatControle
		$frotaDpvatControleModelListJson = $objJson->frotaDpvatControleModelList;
		if ($frotaDpvatControleModelListJson != null) {
			for ($i = 0; $i < count($frotaDpvatControleModelListJson); $i++) {
				$frotaDpvatControle = new FrotaDpvatControleModel();
				$frotaDpvatControle->mapping($frotaDpvatControleModelListJson[$i]);
				$objModel->frotaDpvatControleModelList()->save($frotaDpvatControle);
			}
		}

		// frotaVeiculoSinistro
		$frotaVeiculoSinistroModelListJson = $objJson->frotaVeiculoSinistroModelList;
		if ($frotaVeiculoSinistroModelListJson != null) {
			for ($i = 0; $i < count($frotaVeiculoSinistroModelListJson); $i++) {
				$frotaVeiculoSinistro = new FrotaVeiculoSinistroModel();
				$frotaVeiculoSinistro->mapping($frotaVeiculoSinistroModelListJson[$i]);
				$objModel->frotaVeiculoSinistroModelList()->save($frotaVeiculoSinistro);
			}
		}

		// frotaVeiculoMovimentacao
		$frotaVeiculoMovimentacaoModelListJson = $objJson->frotaVeiculoMovimentacaoModelList;
		if ($frotaVeiculoMovimentacaoModelListJson != null) {
			for ($i = 0; $i < count($frotaVeiculoMovimentacaoModelListJson); $i++) {
				$frotaVeiculoMovimentacao = new FrotaVeiculoMovimentacaoModel();
				$frotaVeiculoMovimentacao->mapping($frotaVeiculoMovimentacaoModelListJson[$i]);
				$objModel->frotaVeiculoMovimentacaoModelList()->save($frotaVeiculoMovimentacao);
			}
		}

		// frotaVeiculoPneu
		$frotaVeiculoPneuModelListJson = $objJson->frotaVeiculoPneuModelList;
		if ($frotaVeiculoPneuModelListJson != null) {
			for ($i = 0; $i < count($frotaVeiculoPneuModelListJson); $i++) {
				$frotaVeiculoPneu = new FrotaVeiculoPneuModel();
				$frotaVeiculoPneu->mapping($frotaVeiculoPneuModelListJson[$i]);
				$objModel->frotaVeiculoPneuModelList()->save($frotaVeiculoPneu);
			}
		}

		// frotaVeiculoManutencao
		$frotaVeiculoManutencaoModelListJson = $objJson->frotaVeiculoManutencaoModelList;
		if ($frotaVeiculoManutencaoModelListJson != null) {
			for ($i = 0; $i < count($frotaVeiculoManutencaoModelListJson); $i++) {
				$frotaVeiculoManutencao = new FrotaVeiculoManutencaoModel();
				$frotaVeiculoManutencao->mapping($frotaVeiculoManutencaoModelListJson[$i]);
				$objModel->frotaVeiculoManutencaoModelList()->save($frotaVeiculoManutencao);
			}
		}

		// frotaMultaControle
		$frotaMultaControleModelListJson = $objJson->frotaMultaControleModelList;
		if ($frotaMultaControleModelListJson != null) {
			for ($i = 0; $i < count($frotaMultaControleModelListJson); $i++) {
				$frotaMultaControle = new FrotaMultaControleModel();
				$frotaMultaControle->mapping($frotaMultaControleModelListJson[$i]);
				$objModel->frotaMultaControleModelList()->save($frotaMultaControle);
			}
		}

		// frotaCombustivelControle
		$frotaCombustivelControleModelListJson = $objJson->frotaCombustivelControleModelList;
		if ($frotaCombustivelControleModelListJson != null) {
			for ($i = 0; $i < count($frotaCombustivelControleModelListJson); $i++) {
				$frotaCombustivelControle = new FrotaCombustivelControleModel();
				$frotaCombustivelControle->mapping($frotaCombustivelControleModelListJson[$i]);
				$objModel->frotaCombustivelControleModelList()->save($frotaCombustivelControle);
			}
		}

	}	

	public function deleteChildren($object)
	{
		FrotaIpvaControleModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
		FrotaDpvatControleModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
		FrotaVeiculoSinistroModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
		FrotaVeiculoMovimentacaoModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
		FrotaVeiculoPneuModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
		FrotaVeiculoManutencaoModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
		FrotaMultaControleModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
		FrotaCombustivelControleModel::where('id_frota_veiculo', $object->getIdAttribute())->delete();
	}	
 
}