<?php
class FrotaCombustivelTipoService extends ServiceBase
{
  public function getList()
  {
    return FrotaCombustivelTipoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FrotaCombustivelTipoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FrotaCombustivelTipoModel::find($id);
  }

}