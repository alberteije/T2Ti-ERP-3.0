<?php
declare(strict_types=1);

class FrotaCombustivelControleModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_combustivel_controle';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function frotaVeiculoModel()
	{
		return $this->belongsTo(FrotaVeiculoModel::class, 'id_frota_veiculo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataAbastecimentoAttribute()
	{
		return $this->attributes['data_abastecimento'];
	}

	public function setDataAbastecimentoAttribute($dataAbastecimento)
	{
		$this->attributes['data_abastecimento'] = $dataAbastecimento;
	}

	public function getHoraAbastecimentoAttribute()
	{
		return $this->attributes['hora_abastecimento'];
	}

	public function setHoraAbastecimentoAttribute($horaAbastecimento)
	{
		$this->attributes['hora_abastecimento'] = $horaAbastecimento;
	}

	public function getValorAbastecimentoAttribute()
	{
		return (double)$this->attributes['valor_abastecimento'];
	}

	public function setValorAbastecimentoAttribute($valorAbastecimento)
	{
		$this->attributes['valor_abastecimento'] = $valorAbastecimento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataAbastecimentoAttribute($object->dataAbastecimento);
				$this->setHoraAbastecimentoAttribute($object->horaAbastecimento);
				$this->setValorAbastecimentoAttribute($object->valorAbastecimento);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataAbastecimento' => $this->getDataAbastecimentoAttribute(),
				'horaAbastecimento' => $this->getHoraAbastecimentoAttribute(),
				'valorAbastecimento' => $this->getValorAbastecimentoAttribute(),
			];
	}
}