<?php
declare(strict_types=1);

class FrotaIpvaControleModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_ipva_controle';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function frotaVeiculoModel()
	{
		return $this->belongsTo(FrotaVeiculoModel::class, 'id_frota_veiculo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getAnoAttribute()
	{
		return $this->attributes['ano'];
	}

	public function setAnoAttribute($ano)
	{
		$this->attributes['ano'] = $ano;
	}

	public function getParcelaAttribute()
	{
		return $this->attributes['parcela'];
	}

	public function setParcelaAttribute($parcela)
	{
		$this->attributes['parcela'] = $parcela;
	}

	public function getDataVencimentoAttribute()
	{
		return $this->attributes['data_vencimento'];
	}

	public function setDataVencimentoAttribute($dataVencimento)
	{
		$this->attributes['data_vencimento'] = $dataVencimento;
	}

	public function getDataPagamentoAttribute()
	{
		return $this->attributes['data_pagamento'];
	}

	public function setDataPagamentoAttribute($dataPagamento)
	{
		$this->attributes['data_pagamento'] = $dataPagamento;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setAnoAttribute($object->ano);
				$this->setParcelaAttribute($object->parcela);
				$this->setDataVencimentoAttribute($object->dataVencimento);
				$this->setDataPagamentoAttribute($object->dataPagamento);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ano' => $this->getAnoAttribute(),
				'parcela' => $this->getParcelaAttribute(),
				'dataVencimento' => $this->getDataVencimentoAttribute(),
				'dataPagamento' => $this->getDataPagamentoAttribute(),
				'valor' => $this->getValorAttribute(),
			];
	}
}