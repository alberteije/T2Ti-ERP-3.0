<?php
declare(strict_types=1);

class FrotaVeiculoMovimentacaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_veiculo_movimentacao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'frotaMotoristaModel',
	];

	/**
		* Relations
		*/
	public function frotaVeiculoModel()
	{
		return $this->belongsTo(FrotaVeiculoModel::class, 'id_frota_veiculo', 'id');
	}

	public function frotaMotoristaModel()
	{
		return $this->belongsTo(FrotaMotoristaModel::class, 'id_frota_motorista', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataSaidaAttribute()
	{
		return $this->attributes['data_saida'];
	}

	public function setDataSaidaAttribute($dataSaida)
	{
		$this->attributes['data_saida'] = $dataSaida;
	}

	public function getHoraSaidaAttribute()
	{
		return $this->attributes['hora_saida'];
	}

	public function setHoraSaidaAttribute($horaSaida)
	{
		$this->attributes['hora_saida'] = $horaSaida;
	}

	public function getDataEntradaAttribute()
	{
		return $this->attributes['data_entrada'];
	}

	public function setDataEntradaAttribute($dataEntrada)
	{
		$this->attributes['data_entrada'] = $dataEntrada;
	}

	public function getHoraEntradaAttribute()
	{
		return $this->attributes['hora_entrada'];
	}

	public function setHoraEntradaAttribute($horaEntrada)
	{
		$this->attributes['hora_entrada'] = $horaEntrada;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataSaidaAttribute($object->dataSaida);
				$this->setHoraSaidaAttribute($object->horaSaida);
				$this->setDataEntradaAttribute($object->dataEntrada);
				$this->setHoraEntradaAttribute($object->horaEntrada);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$frotaMotoristaModel = new FrotaMotoristaModel();
				$frotaMotoristaModel->mapping($object->frotaMotoristaModel);
				$this->frotaMotoristaModel()->associate($frotaMotoristaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataSaida' => $this->getDataSaidaAttribute(),
				'horaSaida' => $this->getHoraSaidaAttribute(),
				'dataEntrada' => $this->getDataEntradaAttribute(),
				'horaEntrada' => $this->getHoraEntradaAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'frotaMotoristaModel' => $this->frotaMotoristaModel,
			];
	}
}