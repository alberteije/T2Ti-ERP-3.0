<?php
declare(strict_types=1);

class FrotaMotoristaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_motorista';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'viewPessoaColaboradorModel',
	];

	/**
		* Relations
		*/
	public function viewPessoaColaboradorModel()
	{
		return $this->belongsTo(ViewPessoaColaboradorModel::class, 'id_colaborador', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getNumeroCnhAttribute()
	{
		return $this->attributes['numero_cnh'];
	}

	public function setNumeroCnhAttribute($numeroCnh)
	{
		$this->attributes['numero_cnh'] = $numeroCnh;
	}

	public function getCnhCategoriaAttribute()
	{
		return $this->attributes['cnh_categoria'];
	}

	public function setCnhCategoriaAttribute($cnhCategoria)
	{
		$this->attributes['cnh_categoria'] = $cnhCategoria;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setNumeroCnhAttribute($object->numeroCnh);
				$this->setCnhCategoriaAttribute($object->cnhCategoria);

				// link objects - lookups
				$viewPessoaColaboradorModel = new ViewPessoaColaboradorModel();
				$viewPessoaColaboradorModel->mapping($object->viewPessoaColaboradorModel);
				$this->viewPessoaColaboradorModel()->associate($viewPessoaColaboradorModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'numeroCnh' => $this->getNumeroCnhAttribute(),
				'cnhCategoria' => $this->getCnhCategoriaAttribute(),
				'viewPessoaColaboradorModel' => $this->viewPessoaColaboradorModel,
			];
	}
}