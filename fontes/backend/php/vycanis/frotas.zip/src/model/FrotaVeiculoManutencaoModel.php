<?php
declare(strict_types=1);

class FrotaVeiculoManutencaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_veiculo_manutencao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function frotaVeiculoModel()
	{
		return $this->belongsTo(FrotaVeiculoModel::class, 'id_frota_veiculo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getDataManutencaoAttribute()
	{
		return $this->attributes['data_manutencao'];
	}

	public function setDataManutencaoAttribute($dataManutencao)
	{
		$this->attributes['data_manutencao'] = $dataManutencao;
	}

	public function getValorManutencaoAttribute()
	{
		return (double)$this->attributes['valor_manutencao'];
	}

	public function setValorManutencaoAttribute($valorManutencao)
	{
		$this->attributes['valor_manutencao'] = $valorManutencao;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoAttribute($object->tipo);
				$this->setDataManutencaoAttribute($object->dataManutencao);
				$this->setValorManutencaoAttribute($object->valorManutencao);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'dataManutencao' => $this->getDataManutencaoAttribute(),
				'valorManutencao' => $this->getValorManutencaoAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}