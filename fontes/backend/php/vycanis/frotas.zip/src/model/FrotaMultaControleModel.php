<?php
declare(strict_types=1);

class FrotaMultaControleModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_multa_controle';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function frotaVeiculoModel()
	{
		return $this->belongsTo(FrotaVeiculoModel::class, 'id_frota_veiculo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataMultaAttribute()
	{
		return $this->attributes['data_multa'];
	}

	public function setDataMultaAttribute($dataMulta)
	{
		$this->attributes['data_multa'] = $dataMulta;
	}

	public function getPontosAttribute()
	{
		return $this->attributes['pontos'];
	}

	public function setPontosAttribute($pontos)
	{
		$this->attributes['pontos'] = $pontos;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataMultaAttribute($object->dataMulta);
				$this->setPontosAttribute($object->pontos);
				$this->setValorAttribute($object->valor);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataMulta' => $this->getDataMultaAttribute(),
				'pontos' => $this->getPontosAttribute(),
				'valor' => $this->getValorAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
			];
	}
}