<?php
declare(strict_types=1);

class FrotaVeiculoPneuModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_veiculo_pneu';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function frotaVeiculoModel()
	{
		return $this->belongsTo(FrotaVeiculoModel::class, 'id_frota_veiculo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataTrocaAttribute()
	{
		return $this->attributes['data_troca'];
	}

	public function setDataTrocaAttribute($dataTroca)
	{
		$this->attributes['data_troca'] = $dataTroca;
	}

	public function getValorTrocaAttribute()
	{
		return (double)$this->attributes['valor_troca'];
	}

	public function setValorTrocaAttribute($valorTroca)
	{
		$this->attributes['valor_troca'] = $valorTroca;
	}

	public function getPosicaoPneuAttribute()
	{
		return $this->attributes['posicao_pneu'];
	}

	public function setPosicaoPneuAttribute($posicaoPneu)
	{
		$this->attributes['posicao_pneu'] = $posicaoPneu;
	}

	public function getMarcaPneuAttribute()
	{
		return $this->attributes['marca_pneu'];
	}

	public function setMarcaPneuAttribute($marcaPneu)
	{
		$this->attributes['marca_pneu'] = $marcaPneu;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataTrocaAttribute($object->dataTroca);
				$this->setValorTrocaAttribute($object->valorTroca);
				$this->setPosicaoPneuAttribute($object->posicaoPneu);
				$this->setMarcaPneuAttribute($object->marcaPneu);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataTroca' => $this->getDataTrocaAttribute(),
				'valorTroca' => $this->getValorTrocaAttribute(),
				'posicaoPneu' => $this->getPosicaoPneuAttribute(),
				'marcaPneu' => $this->getMarcaPneuAttribute(),
			];
	}
}