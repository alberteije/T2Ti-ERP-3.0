<?php
declare(strict_types=1);

class FrotaVeiculoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'frota_veiculo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'frotaIpvaControleModelList',
		'frotaDpvatControleModelList',
		'frotaVeiculoSinistroModelList',
		'frotaVeiculoMovimentacaoModelList',
		'frotaVeiculoPneuModelList',
		'frotaVeiculoManutencaoModelList',
		'frotaMultaControleModelList',
		'frotaCombustivelControleModelList',
		'frotaVeiculoTipoModel',
		'frotaCombustivelTipoModel',
	];

	/**
		* Relations
		*/
	public function frotaIpvaControleModelList()
{
	return $this->hasMany(FrotaIpvaControleModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaDpvatControleModelList()
{
	return $this->hasMany(FrotaDpvatControleModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaVeiculoSinistroModelList()
{
	return $this->hasMany(FrotaVeiculoSinistroModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaVeiculoMovimentacaoModelList()
{
	return $this->hasMany(FrotaVeiculoMovimentacaoModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaVeiculoPneuModelList()
{
	return $this->hasMany(FrotaVeiculoPneuModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaVeiculoManutencaoModelList()
{
	return $this->hasMany(FrotaVeiculoManutencaoModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaMultaControleModelList()
{
	return $this->hasMany(FrotaMultaControleModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaCombustivelControleModelList()
{
	return $this->hasMany(FrotaCombustivelControleModel::class, 'id_frota_veiculo', 'id');
}

	public function frotaVeiculoTipoModel()
	{
		return $this->belongsTo(FrotaVeiculoTipoModel::class, 'id_frota_veiculo_tipo', 'id');
	}

	public function frotaCombustivelTipoModel()
	{
		return $this->belongsTo(FrotaCombustivelTipoModel::class, 'id_frota_combustivel_tipo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getMarcaAttribute()
	{
		return $this->attributes['marca'];
	}

	public function setMarcaAttribute($marca)
	{
		$this->attributes['marca'] = $marca;
	}

	public function getModeloAttribute()
	{
		return $this->attributes['modelo'];
	}

	public function setModeloAttribute($modelo)
	{
		$this->attributes['modelo'] = $modelo;
	}

	public function getModeloAnoAttribute()
	{
		return $this->attributes['modelo_ano'];
	}

	public function setModeloAnoAttribute($modeloAno)
	{
		$this->attributes['modelo_ano'] = $modeloAno;
	}

	public function getPlacaAttribute()
	{
		return $this->attributes['placa'];
	}

	public function setPlacaAttribute($placa)
	{
		$this->attributes['placa'] = $placa;
	}

	public function getCodigoFipeAttribute()
	{
		return $this->attributes['codigo_fipe'];
	}

	public function setCodigoFipeAttribute($codigoFipe)
	{
		$this->attributes['codigo_fipe'] = $codigoFipe;
	}

	public function getRenavamAttribute()
	{
		return $this->attributes['renavam'];
	}

	public function setRenavamAttribute($renavam)
	{
		$this->attributes['renavam'] = $renavam;
	}

	public function getIpvaMesVencimentoAttribute()
	{
		return $this->attributes['ipva_mes_vencimento'];
	}

	public function setIpvaMesVencimentoAttribute($ipvaMesVencimento)
	{
		$this->attributes['ipva_mes_vencimento'] = $ipvaMesVencimento;
	}

	public function getDpvatMesVencimentoAttribute()
	{
		return $this->attributes['dpvat_mes_vencimento'];
	}

	public function setDpvatMesVencimentoAttribute($dpvatMesVencimento)
	{
		$this->attributes['dpvat_mes_vencimento'] = $dpvatMesVencimento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setMarcaAttribute($object->marca);
				$this->setModeloAttribute($object->modelo);
				$this->setModeloAnoAttribute($object->modeloAno);
				$this->setPlacaAttribute($object->placa);
				$this->setCodigoFipeAttribute($object->codigoFipe);
				$this->setRenavamAttribute($object->renavam);
				$this->setIpvaMesVencimentoAttribute($object->ipvaMesVencimento);
				$this->setDpvatMesVencimentoAttribute($object->dpvatMesVencimento);

				// link objects - lookups
				$frotaVeiculoTipoModel = new FrotaVeiculoTipoModel();
				$frotaVeiculoTipoModel->mapping($object->frotaVeiculoTipoModel);
				$this->frotaVeiculoTipoModel()->associate($frotaVeiculoTipoModel);
				$frotaCombustivelTipoModel = new FrotaCombustivelTipoModel();
				$frotaCombustivelTipoModel->mapping($object->frotaCombustivelTipoModel);
				$this->frotaCombustivelTipoModel()->associate($frotaCombustivelTipoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'marca' => $this->getMarcaAttribute(),
				'modelo' => $this->getModeloAttribute(),
				'modeloAno' => $this->getModeloAnoAttribute(),
				'placa' => $this->getPlacaAttribute(),
				'codigoFipe' => $this->getCodigoFipeAttribute(),
				'renavam' => $this->getRenavamAttribute(),
				'ipvaMesVencimento' => $this->getIpvaMesVencimentoAttribute(),
				'dpvatMesVencimento' => $this->getDpvatMesVencimentoAttribute(),
				'frotaIpvaControleModelList' => $this->frotaIpvaControleModelList,
				'frotaDpvatControleModelList' => $this->frotaDpvatControleModelList,
				'frotaVeiculoSinistroModelList' => $this->frotaVeiculoSinistroModelList,
				'frotaVeiculoMovimentacaoModelList' => $this->frotaVeiculoMovimentacaoModelList,
				'frotaVeiculoPneuModelList' => $this->frotaVeiculoPneuModelList,
				'frotaVeiculoManutencaoModelList' => $this->frotaVeiculoManutencaoModelList,
				'frotaMultaControleModelList' => $this->frotaMultaControleModelList,
				'frotaCombustivelControleModelList' => $this->frotaCombustivelControleModelList,
				'frotaVeiculoTipoModel' => $this->frotaVeiculoTipoModel,
				'frotaCombustivelTipoModel' => $this->frotaCombustivelTipoModel,
			];
	}
}