<?php
use Illuminate\Database\Capsule\Manager as DB;
class ContabilIndiceService extends ServiceBase
{
	public function getList()
	{
		return ContabilIndiceModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ContabilIndiceModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ContabilIndiceModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// contabilIndiceValor
		$contabilIndiceValorModelListJson = $objJson->contabilIndiceValorModelList;
		if ($contabilIndiceValorModelListJson != null) {
			for ($i = 0; $i < count($contabilIndiceValorModelListJson); $i++) {
				$contabilIndiceValor = new ContabilIndiceValorModel();
				$contabilIndiceValor->mapping($contabilIndiceValorModelListJson[$i]);
				$objModel->contabilIndiceValorModelList()->save($contabilIndiceValor);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ContabilIndiceValorModel::where('id_contabil_indice', $object->getIdAttribute())->delete();
	}	
 
}