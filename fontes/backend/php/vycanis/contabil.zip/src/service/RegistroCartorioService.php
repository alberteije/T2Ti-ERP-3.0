<?php
class RegistroCartorioService extends ServiceBase
{
  public function getList()
  {
    return RegistroCartorioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return RegistroCartorioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return RegistroCartorioModel::find($id);
  }

}