<?php
class PlanoContaService extends ServiceBase
{
  public function getList()
  {
    return PlanoContaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PlanoContaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PlanoContaModel::find($id);
  }

}