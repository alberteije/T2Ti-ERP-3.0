<?php
class ContabilContaRateioService extends ServiceBase
{
  public function getList()
  {
    return ContabilContaRateioModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilContaRateioModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilContaRateioModel::find($id);
  }

}