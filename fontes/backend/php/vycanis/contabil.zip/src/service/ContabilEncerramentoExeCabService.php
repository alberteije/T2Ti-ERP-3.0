<?php
use Illuminate\Database\Capsule\Manager as DB;
class ContabilEncerramentoExeCabService extends ServiceBase
{
	public function getList()
	{
		return ContabilEncerramentoExeCabModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ContabilEncerramentoExeCabModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ContabilEncerramentoExeCabModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// contabilEncerramentoExeDet
		$contabilEncerramentoExeDetModelListJson = $objJson->contabilEncerramentoExeDetModelList;
		if ($contabilEncerramentoExeDetModelListJson != null) {
			for ($i = 0; $i < count($contabilEncerramentoExeDetModelListJson); $i++) {
				$contabilEncerramentoExeDet = new ContabilEncerramentoExeDetModel();
				$contabilEncerramentoExeDet->mapping($contabilEncerramentoExeDetModelListJson[$i]);
				$objModel->contabilEncerramentoExeDetModelList()->save($contabilEncerramentoExeDet);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ContabilEncerramentoExeDetModel::where('id_contabil_encerramento_exe', $object->getIdAttribute())->delete();
	}	
 
}