<?php
class FapService extends ServiceBase
{
  public function getList()
  {
    return FapModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FapModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FapModel::find($id);
  }

}