<?php
class ContabilHistoricoService extends ServiceBase
{
  public function getList()
  {
    return ContabilHistoricoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilHistoricoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilHistoricoModel::find($id);
  }

}