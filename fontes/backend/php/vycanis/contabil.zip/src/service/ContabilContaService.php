<?php
class ContabilContaService extends ServiceBase
{
  public function getList()
  {
    return ContabilContaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilContaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilContaModel::find($id);
  }

}