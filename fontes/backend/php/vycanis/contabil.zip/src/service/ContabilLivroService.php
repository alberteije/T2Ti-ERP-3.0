<?php
use Illuminate\Database\Capsule\Manager as DB;
class ContabilLivroService extends ServiceBase
{
	public function getList()
	{
		return ContabilLivroModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ContabilLivroModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ContabilLivroModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// contabilTermo
		$contabilTermoModelListJson = $objJson->contabilTermoModelList;
		if ($contabilTermoModelListJson != null) {
			for ($i = 0; $i < count($contabilTermoModelListJson); $i++) {
				$contabilTermo = new ContabilTermoModel();
				$contabilTermo->mapping($contabilTermoModelListJson[$i]);
				$objModel->contabilTermoModelList()->save($contabilTermo);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ContabilTermoModel::where('id_contabil_livro', $object->getIdAttribute())->delete();
	}	
 
}