<?php
class ContabilLoteService extends ServiceBase
{
  public function getList()
  {
    return ContabilLoteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilLoteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilLoteModel::find($id);
  }

}