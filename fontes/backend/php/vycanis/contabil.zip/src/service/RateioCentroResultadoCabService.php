<?php
use Illuminate\Database\Capsule\Manager as DB;
class RateioCentroResultadoCabService extends ServiceBase
{
	public function getList()
	{
		return RateioCentroResultadoCabModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return RateioCentroResultadoCabModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return RateioCentroResultadoCabModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// rateioCentroResultadoDet
		$rateioCentroResultadoDetModelListJson = $objJson->rateioCentroResultadoDetModelList;
		if ($rateioCentroResultadoDetModelListJson != null) {
			for ($i = 0; $i < count($rateioCentroResultadoDetModelListJson); $i++) {
				$rateioCentroResultadoDet = new RateioCentroResultadoDetModel();
				$rateioCentroResultadoDet->mapping($rateioCentroResultadoDetModelListJson[$i]);
				$objModel->rateioCentroResultadoDetModelList()->save($rateioCentroResultadoDet);
			}
		}

	}	

	public function deleteChildren($object)
	{
		RateioCentroResultadoDetModel::where('id_rateio_centro_resul_cab', $object->getIdAttribute())->delete();
	}	
 
}