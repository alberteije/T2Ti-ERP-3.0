<?php
class ContabilParametroService extends ServiceBase
{
  public function getList()
  {
    return ContabilParametroModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilParametroModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilParametroModel::find($id);
  }

}