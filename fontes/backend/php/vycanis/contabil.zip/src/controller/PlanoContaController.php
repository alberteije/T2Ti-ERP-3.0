<?php
class PlanoContaController extends ControllerBase
{

		private $planoContaService = null;

		public function __construct()
		{	 
				$this->planoContaService = new PlanoContaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->planoContaService->getListFilter($filter);
						} else {
								$resultList = $this->planoContaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList PlanoConta]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->planoContaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject PlanoConta]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject PlanoConta]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert PlanoConta]', null);
						}

						$objModel = new PlanoContaModel();
						$objModel->mapping($objJson);

						$this->planoContaService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert PlanoConta]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->planoContaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update PlanoConta]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->planoContaService->save($objFromDatabase);
								$objFromDatabase = $this->planoContaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update PlanoConta]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->planoContaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete PlanoConta]', null);
						} else {
								$this->planoContaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete PlanoConta]', $e);
				}
		}
}
