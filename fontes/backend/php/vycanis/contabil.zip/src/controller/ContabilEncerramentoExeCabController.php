<?php
class ContabilEncerramentoExeCabController extends ControllerBase
{

		private $contabilEncerramentoExeCabService = null;

		public function __construct()
		{	 
				$this->contabilEncerramentoExeCabService = new ContabilEncerramentoExeCabService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->contabilEncerramentoExeCabService->getListFilter($filter);
						} else {
								$resultList = $this->contabilEncerramentoExeCabService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList ContabilEncerramentoExeCab]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contabilEncerramentoExeCabService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject ContabilEncerramentoExeCab]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject ContabilEncerramentoExeCab]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert ContabilEncerramentoExeCab]', null);
						}

						$objModel = new ContabilEncerramentoExeCabModel();
						$objModel->mapping($objJson);

						$this->contabilEncerramentoExeCabService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert ContabilEncerramentoExeCab]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->contabilEncerramentoExeCabService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update ContabilEncerramentoExeCab]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->contabilEncerramentoExeCabService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->contabilEncerramentoExeCabService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update ContabilEncerramentoExeCab]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contabilEncerramentoExeCabService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete ContabilEncerramentoExeCab]', null);
						} else {
								$this->contabilEncerramentoExeCabService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete ContabilEncerramentoExeCab]', $e);
				}
		}
}
