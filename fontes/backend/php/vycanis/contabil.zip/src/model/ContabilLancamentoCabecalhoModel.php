<?php
declare(strict_types=1);

class ContabilLancamentoCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_lancamento_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilLancamentoDetalheModelList',
		'contabilLoteModel',
	];

	/**
		* Relations
		*/
	public function contabilLancamentoDetalheModelList()
{
	return $this->hasMany(ContabilLancamentoDetalheModel::class, 'id_contabil_lancamento_cab', 'id');
}

	public function contabilLoteModel()
	{
		return $this->belongsTo(ContabilLoteModel::class, 'id_contabil_lote', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataLancamentoAttribute()
	{
		return $this->attributes['data_lancamento'];
	}

	public function setDataLancamentoAttribute($dataLancamento)
	{
		$this->attributes['data_lancamento'] = $dataLancamento;
	}

	public function getDataInclusaoAttribute()
	{
		return $this->attributes['data_inclusao'];
	}

	public function setDataInclusaoAttribute($dataInclusao)
	{
		$this->attributes['data_inclusao'] = $dataInclusao;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getLiberadoAttribute()
	{
		return $this->attributes['liberado'];
	}

	public function setLiberadoAttribute($liberado)
	{
		$this->attributes['liberado'] = $liberado;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataLancamentoAttribute($object->dataLancamento);
				$this->setDataInclusaoAttribute($object->dataInclusao);
				$this->setTipoAttribute($object->tipo);
				$this->setLiberadoAttribute($object->liberado);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
				$contabilLoteModel = new ContabilLoteModel();
				$contabilLoteModel->mapping($object->contabilLoteModel);
				$this->contabilLoteModel()->associate($contabilLoteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataLancamento' => $this->getDataLancamentoAttribute(),
				'dataInclusao' => $this->getDataInclusaoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'liberado' => $this->getLiberadoAttribute(),
				'valor' => $this->getValorAttribute(),
				'contabilLancamentoDetalheModelList' => $this->contabilLancamentoDetalheModelList,
				'contabilLoteModel' => $this->contabilLoteModel,
			];
	}
}