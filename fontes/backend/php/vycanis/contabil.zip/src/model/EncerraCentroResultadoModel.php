<?php
declare(strict_types=1);

class EncerraCentroResultadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'encerra_centro_resultado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'centroResultadoModel',
	];

	/**
		* Relations
		*/
	public function centroResultadoModel()
	{
		return $this->belongsTo(CentroResultadoModel::class, 'id_centro_resultado', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getValorTotalAttribute()
	{
		return (double)$this->attributes['valor_total'];
	}

	public function setValorTotalAttribute($valorTotal)
	{
		$this->attributes['valor_total'] = $valorTotal;
	}

	public function getValorSubRateioAttribute()
	{
		return (double)$this->attributes['valor_sub_rateio'];
	}

	public function setValorSubRateioAttribute($valorSubRateio)
	{
		$this->attributes['valor_sub_rateio'] = $valorSubRateio;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setValorTotalAttribute($object->valorTotal);
				$this->setValorSubRateioAttribute($object->valorSubRateio);

				// link objects - lookups
				$centroResultadoModel = new CentroResultadoModel();
				$centroResultadoModel->mapping($object->centroResultadoModel);
				$this->centroResultadoModel()->associate($centroResultadoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'valorTotal' => $this->getValorTotalAttribute(),
				'valorSubRateio' => $this->getValorSubRateioAttribute(),
				'centroResultadoModel' => $this->centroResultadoModel,
			];
	}
}