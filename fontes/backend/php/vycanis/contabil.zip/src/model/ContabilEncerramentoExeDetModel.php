<?php
declare(strict_types=1);

class ContabilEncerramentoExeDetModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_encerramento_exe_det';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilContaModel',
	];

	/**
		* Relations
		*/
	public function contabilEncerramentoExeCabModel()
	{
		return $this->belongsTo(ContabilEncerramentoExeCabModel::class, 'id_contabil_encerramento_exe', 'id');
	}

	public function contabilContaModel()
	{
		return $this->belongsTo(ContabilContaModel::class, 'id_contabil_conta', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getSaldoAnteriorAttribute()
	{
		return (double)$this->attributes['saldo_anterior'];
	}

	public function setSaldoAnteriorAttribute($saldoAnterior)
	{
		$this->attributes['saldo_anterior'] = $saldoAnterior;
	}

	public function getValorDebitoAttribute()
	{
		return (double)$this->attributes['valor_debito'];
	}

	public function setValorDebitoAttribute($valorDebito)
	{
		$this->attributes['valor_debito'] = $valorDebito;
	}

	public function getValorCreditoAttribute()
	{
		return (double)$this->attributes['valor_credito'];
	}

	public function setValorCreditoAttribute($valorCredito)
	{
		$this->attributes['valor_credito'] = $valorCredito;
	}

	public function getSaldoAttribute()
	{
		return (double)$this->attributes['saldo'];
	}

	public function setSaldoAttribute($saldo)
	{
		$this->attributes['saldo'] = $saldo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setSaldoAnteriorAttribute($object->saldoAnterior);
				$this->setValorDebitoAttribute($object->valorDebito);
				$this->setValorCreditoAttribute($object->valorCredito);
				$this->setSaldoAttribute($object->saldo);

				// link objects - lookups
				$contabilContaModel = new ContabilContaModel();
				$contabilContaModel->mapping($object->contabilContaModel);
				$this->contabilContaModel()->associate($contabilContaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'saldoAnterior' => $this->getSaldoAnteriorAttribute(),
				'valorDebito' => $this->getValorDebitoAttribute(),
				'valorCredito' => $this->getValorCreditoAttribute(),
				'saldo' => $this->getSaldoAttribute(),
				'contabilContaModel' => $this->contabilContaModel,
			];
	}
}