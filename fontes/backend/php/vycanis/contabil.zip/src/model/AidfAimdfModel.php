<?php
declare(strict_types=1);

class AidfAimdfModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'aidf_aimdf';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDataValidadeAttribute()
	{
		return $this->attributes['data_validade'];
	}

	public function setDataValidadeAttribute($dataValidade)
	{
		$this->attributes['data_validade'] = $dataValidade;
	}

	public function getDataAutorizacaoAttribute()
	{
		return $this->attributes['data_autorizacao'];
	}

	public function setDataAutorizacaoAttribute($dataAutorizacao)
	{
		$this->attributes['data_autorizacao'] = $dataAutorizacao;
	}

	public function getNumeroAutorizacaoAttribute()
	{
		return $this->attributes['numero_autorizacao'];
	}

	public function setNumeroAutorizacaoAttribute($numeroAutorizacao)
	{
		$this->attributes['numero_autorizacao'] = $numeroAutorizacao;
	}

	public function getFormularioDisponivelAttribute()
	{
		return $this->attributes['formulario_disponivel'];
	}

	public function setFormularioDisponivelAttribute($formularioDisponivel)
	{
		$this->attributes['formulario_disponivel'] = $formularioDisponivel;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setDataValidadeAttribute($object->dataValidade);
				$this->setDataAutorizacaoAttribute($object->dataAutorizacao);
				$this->setNumeroAutorizacaoAttribute($object->numeroAutorizacao);
				$this->setFormularioDisponivelAttribute($object->formularioDisponivel);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'dataValidade' => $this->getDataValidadeAttribute(),
				'dataAutorizacao' => $this->getDataAutorizacaoAttribute(),
				'numeroAutorizacao' => $this->getNumeroAutorizacaoAttribute(),
				'formularioDisponivel' => $this->getFormularioDisponivelAttribute(),
			];
	}
}