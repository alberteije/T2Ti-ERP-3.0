<?php
declare(strict_types=1);

class ContabilIndiceValorModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_indice_valor';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function contabilIndiceModel()
	{
		return $this->belongsTo(ContabilIndiceModel::class, 'id_contabil_indice', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataIndiceAttribute()
	{
		return $this->attributes['data_indice'];
	}

	public function setDataIndiceAttribute($dataIndice)
	{
		$this->attributes['data_indice'] = $dataIndice;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataIndiceAttribute($object->dataIndice);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataIndice' => $this->getDataIndiceAttribute(),
				'valor' => $this->getValorAttribute(),
			];
	}
}