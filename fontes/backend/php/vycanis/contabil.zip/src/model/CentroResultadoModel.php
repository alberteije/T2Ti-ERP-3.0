<?php
declare(strict_types=1);

class CentroResultadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'centro_resultado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'planoCentroResultadoModel',
		'ctResultadoNtFinanceiraModelList',
	];

	/**
		* Relations
		*/
	public function planoCentroResultadoModel()
	{
		return $this->belongsTo(PlanoCentroResultadoModel::class, 'id_plano_centro_resultado', 'id');
	}

	public function ctResultadoNtFinanceiraModelList()
{
	return $this->hasMany(CtResultadoNtFinanceiraModel::class, 'id_centro_resultado', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getClassificacaoAttribute()
	{
		return $this->attributes['classificacao'];
	}

	public function setClassificacaoAttribute($classificacao)
	{
		$this->attributes['classificacao'] = $classificacao;
	}

	public function getSofreRateiroAttribute()
	{
		return $this->attributes['sofre_rateiro'];
	}

	public function setSofreRateiroAttribute($sofreRateiro)
	{
		$this->attributes['sofre_rateiro'] = $sofreRateiro;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setClassificacaoAttribute($object->classificacao);
				$this->setSofreRateiroAttribute($object->sofreRateiro);

				// link objects - lookups
				$planoCentroResultadoModel = new PlanoCentroResultadoModel();
				$planoCentroResultadoModel->mapping($object->planoCentroResultadoModel);
				$this->planoCentroResultadoModel()->associate($planoCentroResultadoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'classificacao' => $this->getClassificacaoAttribute(),
				'sofreRateiro' => $this->getSofreRateiroAttribute(),
				'planoCentroResultadoModel' => $this->planoCentroResultadoModel,
				'ctResultadoNtFinanceiraModelList' => $this->ctResultadoNtFinanceiraModelList,
			];
	}
}