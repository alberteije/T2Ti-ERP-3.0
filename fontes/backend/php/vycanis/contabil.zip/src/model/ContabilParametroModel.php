<?php
declare(strict_types=1);

class ContabilParametroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_parametro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getMascaraAttribute()
	{
		return $this->attributes['mascara'];
	}

	public function setMascaraAttribute($mascara)
	{
		$this->attributes['mascara'] = $mascara;
	}

	public function getNiveisAttribute()
	{
		return $this->attributes['niveis'];
	}

	public function setNiveisAttribute($niveis)
	{
		$this->attributes['niveis'] = $niveis;
	}

	public function getInformarContaPorAttribute()
	{
		return $this->attributes['informar_conta_por'];
	}

	public function setInformarContaPorAttribute($informarContaPor)
	{
		$this->attributes['informar_conta_por'] = $informarContaPor;
	}

	public function getCompartilhaPlanoContaAttribute()
	{
		return $this->attributes['compartilha_plano_conta'];
	}

	public function setCompartilhaPlanoContaAttribute($compartilhaPlanoConta)
	{
		$this->attributes['compartilha_plano_conta'] = $compartilhaPlanoConta;
	}

	public function getCompartilhaHistoricosAttribute()
	{
		return $this->attributes['compartilha_historicos'];
	}

	public function setCompartilhaHistoricosAttribute($compartilhaHistoricos)
	{
		$this->attributes['compartilha_historicos'] = $compartilhaHistoricos;
	}

	public function getAlteraLancamentoOutroAttribute()
	{
		return $this->attributes['altera_lancamento_outro'];
	}

	public function setAlteraLancamentoOutroAttribute($alteraLancamentoOutro)
	{
		$this->attributes['altera_lancamento_outro'] = $alteraLancamentoOutro;
	}

	public function getHistoricoObrigatorioAttribute()
	{
		return $this->attributes['historico_obrigatorio'];
	}

	public function setHistoricoObrigatorioAttribute($historicoObrigatorio)
	{
		$this->attributes['historico_obrigatorio'] = $historicoObrigatorio;
	}

	public function getPermiteLancamentoZeradoAttribute()
	{
		return $this->attributes['permite_lancamento_zerado'];
	}

	public function setPermiteLancamentoZeradoAttribute($permiteLancamentoZerado)
	{
		$this->attributes['permite_lancamento_zerado'] = $permiteLancamentoZerado;
	}

	public function getGeraInformativoSpedAttribute()
	{
		return $this->attributes['gera_informativo_sped'];
	}

	public function setGeraInformativoSpedAttribute($geraInformativoSped)
	{
		$this->attributes['gera_informativo_sped'] = $geraInformativoSped;
	}

	public function getSpedFormaEscritDiarioAttribute()
	{
		return $this->attributes['sped_forma_escrit_diario'];
	}

	public function setSpedFormaEscritDiarioAttribute($spedFormaEscritDiario)
	{
		$this->attributes['sped_forma_escrit_diario'] = $spedFormaEscritDiario;
	}

	public function getSpedNomeLivroDiarioAttribute()
	{
		return $this->attributes['sped_nome_livro_diario'];
	}

	public function setSpedNomeLivroDiarioAttribute($spedNomeLivroDiario)
	{
		$this->attributes['sped_nome_livro_diario'] = $spedNomeLivroDiario;
	}

	public function getAssinaturaDireitaAttribute()
	{
		return $this->attributes['assinatura_direita'];
	}

	public function setAssinaturaDireitaAttribute($assinaturaDireita)
	{
		$this->attributes['assinatura_direita'] = $assinaturaDireita;
	}

	public function getAssinaturaEsquerdaAttribute()
	{
		return $this->attributes['assinatura_esquerda'];
	}

	public function setAssinaturaEsquerdaAttribute($assinaturaEsquerda)
	{
		$this->attributes['assinatura_esquerda'] = $assinaturaEsquerda;
	}

	public function getContaAtivoAttribute()
	{
		return $this->attributes['conta_ativo'];
	}

	public function setContaAtivoAttribute($contaAtivo)
	{
		$this->attributes['conta_ativo'] = $contaAtivo;
	}

	public function getContaPassivoAttribute()
	{
		return $this->attributes['conta_passivo'];
	}

	public function setContaPassivoAttribute($contaPassivo)
	{
		$this->attributes['conta_passivo'] = $contaPassivo;
	}

	public function getContaPatrimonioLiquidoAttribute()
	{
		return $this->attributes['conta_patrimonio_liquido'];
	}

	public function setContaPatrimonioLiquidoAttribute($contaPatrimonioLiquido)
	{
		$this->attributes['conta_patrimonio_liquido'] = $contaPatrimonioLiquido;
	}

	public function getContaDepreciacaoAcumuladaAttribute()
	{
		return $this->attributes['conta_depreciacao_acumulada'];
	}

	public function setContaDepreciacaoAcumuladaAttribute($contaDepreciacaoAcumulada)
	{
		$this->attributes['conta_depreciacao_acumulada'] = $contaDepreciacaoAcumulada;
	}

	public function getContaCapitalSocialAttribute()
	{
		return $this->attributes['conta_capital_social'];
	}

	public function setContaCapitalSocialAttribute($contaCapitalSocial)
	{
		$this->attributes['conta_capital_social'] = $contaCapitalSocial;
	}

	public function getContaResultadoExercicioAttribute()
	{
		return $this->attributes['conta_resultado_exercicio'];
	}

	public function setContaResultadoExercicioAttribute($contaResultadoExercicio)
	{
		$this->attributes['conta_resultado_exercicio'] = $contaResultadoExercicio;
	}

	public function getContaPrejuizoAcumuladoAttribute()
	{
		return $this->attributes['conta_prejuizo_acumulado'];
	}

	public function setContaPrejuizoAcumuladoAttribute($contaPrejuizoAcumulado)
	{
		$this->attributes['conta_prejuizo_acumulado'] = $contaPrejuizoAcumulado;
	}

	public function getContaLucroAcumuladoAttribute()
	{
		return $this->attributes['conta_lucro_acumulado'];
	}

	public function setContaLucroAcumuladoAttribute($contaLucroAcumulado)
	{
		$this->attributes['conta_lucro_acumulado'] = $contaLucroAcumulado;
	}

	public function getContaTituloPagarAttribute()
	{
		return $this->attributes['conta_titulo_pagar'];
	}

	public function setContaTituloPagarAttribute($contaTituloPagar)
	{
		$this->attributes['conta_titulo_pagar'] = $contaTituloPagar;
	}

	public function getContaTituloReceberAttribute()
	{
		return $this->attributes['conta_titulo_receber'];
	}

	public function setContaTituloReceberAttribute($contaTituloReceber)
	{
		$this->attributes['conta_titulo_receber'] = $contaTituloReceber;
	}

	public function getContaJurosPassivoAttribute()
	{
		return $this->attributes['conta_juros_passivo'];
	}

	public function setContaJurosPassivoAttribute($contaJurosPassivo)
	{
		$this->attributes['conta_juros_passivo'] = $contaJurosPassivo;
	}

	public function getContaJurosAtivoAttribute()
	{
		return $this->attributes['conta_juros_ativo'];
	}

	public function setContaJurosAtivoAttribute($contaJurosAtivo)
	{
		$this->attributes['conta_juros_ativo'] = $contaJurosAtivo;
	}

	public function getContaDescontoObtidoAttribute()
	{
		return $this->attributes['conta_desconto_obtido'];
	}

	public function setContaDescontoObtidoAttribute($contaDescontoObtido)
	{
		$this->attributes['conta_desconto_obtido'] = $contaDescontoObtido;
	}

	public function getContaDescontoConcedidoAttribute()
	{
		return $this->attributes['conta_desconto_concedido'];
	}

	public function setContaDescontoConcedidoAttribute($contaDescontoConcedido)
	{
		$this->attributes['conta_desconto_concedido'] = $contaDescontoConcedido;
	}

	public function getContaCmvAttribute()
	{
		return $this->attributes['conta_cmv'];
	}

	public function setContaCmvAttribute($contaCmv)
	{
		$this->attributes['conta_cmv'] = $contaCmv;
	}

	public function getContaVendaAttribute()
	{
		return $this->attributes['conta_venda'];
	}

	public function setContaVendaAttribute($contaVenda)
	{
		$this->attributes['conta_venda'] = $contaVenda;
	}

	public function getContaVendaServicoAttribute()
	{
		return $this->attributes['conta_venda_servico'];
	}

	public function setContaVendaServicoAttribute($contaVendaServico)
	{
		$this->attributes['conta_venda_servico'] = $contaVendaServico;
	}

	public function getContaEstoqueAttribute()
	{
		return $this->attributes['conta_estoque'];
	}

	public function setContaEstoqueAttribute($contaEstoque)
	{
		$this->attributes['conta_estoque'] = $contaEstoque;
	}

	public function getContaApuraResultadoAttribute()
	{
		return $this->attributes['conta_apura_resultado'];
	}

	public function setContaApuraResultadoAttribute($contaApuraResultado)
	{
		$this->attributes['conta_apura_resultado'] = $contaApuraResultado;
	}

	public function getContaJurosApropriarAttribute()
	{
		return $this->attributes['conta_juros_apropriar'];
	}

	public function setContaJurosApropriarAttribute($contaJurosApropriar)
	{
		$this->attributes['conta_juros_apropriar'] = $contaJurosApropriar;
	}

	public function getIdHistPadraoResultadoAttribute()
	{
		return $this->attributes['id_hist_padrao_resultado'];
	}

	public function setIdHistPadraoResultadoAttribute($idHistPadraoResultado)
	{
		$this->attributes['id_hist_padrao_resultado'] = $idHistPadraoResultado;
	}

	public function getIdHistPadraoLucroAttribute()
	{
		return $this->attributes['id_hist_padrao_lucro'];
	}

	public function setIdHistPadraoLucroAttribute($idHistPadraoLucro)
	{
		$this->attributes['id_hist_padrao_lucro'] = $idHistPadraoLucro;
	}

	public function getIdHistPadraoPrejuizoAttribute()
	{
		return $this->attributes['id_hist_padrao_prejuizo'];
	}

	public function setIdHistPadraoPrejuizoAttribute($idHistPadraoPrejuizo)
	{
		$this->attributes['id_hist_padrao_prejuizo'] = $idHistPadraoPrejuizo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setMascaraAttribute($object->mascara);
				$this->setNiveisAttribute($object->niveis);
				$this->setInformarContaPorAttribute($object->informarContaPor);
				$this->setCompartilhaPlanoContaAttribute($object->compartilhaPlanoConta);
				$this->setCompartilhaHistoricosAttribute($object->compartilhaHistoricos);
				$this->setAlteraLancamentoOutroAttribute($object->alteraLancamentoOutro);
				$this->setHistoricoObrigatorioAttribute($object->historicoObrigatorio);
				$this->setPermiteLancamentoZeradoAttribute($object->permiteLancamentoZerado);
				$this->setGeraInformativoSpedAttribute($object->geraInformativoSped);
				$this->setSpedFormaEscritDiarioAttribute($object->spedFormaEscritDiario);
				$this->setSpedNomeLivroDiarioAttribute($object->spedNomeLivroDiario);
				$this->setAssinaturaDireitaAttribute($object->assinaturaDireita);
				$this->setAssinaturaEsquerdaAttribute($object->assinaturaEsquerda);
				$this->setContaAtivoAttribute($object->contaAtivo);
				$this->setContaPassivoAttribute($object->contaPassivo);
				$this->setContaPatrimonioLiquidoAttribute($object->contaPatrimonioLiquido);
				$this->setContaDepreciacaoAcumuladaAttribute($object->contaDepreciacaoAcumulada);
				$this->setContaCapitalSocialAttribute($object->contaCapitalSocial);
				$this->setContaResultadoExercicioAttribute($object->contaResultadoExercicio);
				$this->setContaPrejuizoAcumuladoAttribute($object->contaPrejuizoAcumulado);
				$this->setContaLucroAcumuladoAttribute($object->contaLucroAcumulado);
				$this->setContaTituloPagarAttribute($object->contaTituloPagar);
				$this->setContaTituloReceberAttribute($object->contaTituloReceber);
				$this->setContaJurosPassivoAttribute($object->contaJurosPassivo);
				$this->setContaJurosAtivoAttribute($object->contaJurosAtivo);
				$this->setContaDescontoObtidoAttribute($object->contaDescontoObtido);
				$this->setContaDescontoConcedidoAttribute($object->contaDescontoConcedido);
				$this->setContaCmvAttribute($object->contaCmv);
				$this->setContaVendaAttribute($object->contaVenda);
				$this->setContaVendaServicoAttribute($object->contaVendaServico);
				$this->setContaEstoqueAttribute($object->contaEstoque);
				$this->setContaApuraResultadoAttribute($object->contaApuraResultado);
				$this->setContaJurosApropriarAttribute($object->contaJurosApropriar);
				$this->setIdHistPadraoResultadoAttribute($object->idHistPadraoResultado);
				$this->setIdHistPadraoLucroAttribute($object->idHistPadraoLucro);
				$this->setIdHistPadraoPrejuizoAttribute($object->idHistPadraoPrejuizo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'mascara' => $this->getMascaraAttribute(),
				'niveis' => $this->getNiveisAttribute(),
				'informarContaPor' => $this->getInformarContaPorAttribute(),
				'compartilhaPlanoConta' => $this->getCompartilhaPlanoContaAttribute(),
				'compartilhaHistoricos' => $this->getCompartilhaHistoricosAttribute(),
				'alteraLancamentoOutro' => $this->getAlteraLancamentoOutroAttribute(),
				'historicoObrigatorio' => $this->getHistoricoObrigatorioAttribute(),
				'permiteLancamentoZerado' => $this->getPermiteLancamentoZeradoAttribute(),
				'geraInformativoSped' => $this->getGeraInformativoSpedAttribute(),
				'spedFormaEscritDiario' => $this->getSpedFormaEscritDiarioAttribute(),
				'spedNomeLivroDiario' => $this->getSpedNomeLivroDiarioAttribute(),
				'assinaturaDireita' => $this->getAssinaturaDireitaAttribute(),
				'assinaturaEsquerda' => $this->getAssinaturaEsquerdaAttribute(),
				'contaAtivo' => $this->getContaAtivoAttribute(),
				'contaPassivo' => $this->getContaPassivoAttribute(),
				'contaPatrimonioLiquido' => $this->getContaPatrimonioLiquidoAttribute(),
				'contaDepreciacaoAcumulada' => $this->getContaDepreciacaoAcumuladaAttribute(),
				'contaCapitalSocial' => $this->getContaCapitalSocialAttribute(),
				'contaResultadoExercicio' => $this->getContaResultadoExercicioAttribute(),
				'contaPrejuizoAcumulado' => $this->getContaPrejuizoAcumuladoAttribute(),
				'contaLucroAcumulado' => $this->getContaLucroAcumuladoAttribute(),
				'contaTituloPagar' => $this->getContaTituloPagarAttribute(),
				'contaTituloReceber' => $this->getContaTituloReceberAttribute(),
				'contaJurosPassivo' => $this->getContaJurosPassivoAttribute(),
				'contaJurosAtivo' => $this->getContaJurosAtivoAttribute(),
				'contaDescontoObtido' => $this->getContaDescontoObtidoAttribute(),
				'contaDescontoConcedido' => $this->getContaDescontoConcedidoAttribute(),
				'contaCmv' => $this->getContaCmvAttribute(),
				'contaVenda' => $this->getContaVendaAttribute(),
				'contaVendaServico' => $this->getContaVendaServicoAttribute(),
				'contaEstoque' => $this->getContaEstoqueAttribute(),
				'contaApuraResultado' => $this->getContaApuraResultadoAttribute(),
				'contaJurosApropriar' => $this->getContaJurosApropriarAttribute(),
				'idHistPadraoResultado' => $this->getIdHistPadraoResultadoAttribute(),
				'idHistPadraoLucro' => $this->getIdHistPadraoLucroAttribute(),
				'idHistPadraoPrejuizo' => $this->getIdHistPadraoPrejuizoAttribute(),
			];
	}
}