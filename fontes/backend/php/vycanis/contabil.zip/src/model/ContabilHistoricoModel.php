<?php
declare(strict_types=1);

class ContabilHistoricoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_historico';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getPedeComplementoAttribute()
	{
		return $this->attributes['pede_complemento'];
	}

	public function setPedeComplementoAttribute($pedeComplemento)
	{
		$this->attributes['pede_complemento'] = $pedeComplemento;
	}

	public function getHistoricoAttribute()
	{
		return $this->attributes['historico'];
	}

	public function setHistoricoAttribute($historico)
	{
		$this->attributes['historico'] = $historico;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setPedeComplementoAttribute($object->pedeComplemento);
				$this->setHistoricoAttribute($object->historico);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'pedeComplemento' => $this->getPedeComplementoAttribute(),
				'historico' => $this->getHistoricoAttribute(),
			];
	}
}