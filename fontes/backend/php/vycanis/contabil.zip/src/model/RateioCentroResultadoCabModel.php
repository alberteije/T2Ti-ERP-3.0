<?php
declare(strict_types=1);

class RateioCentroResultadoCabModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'rateio_centro_resultado_cab';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'rateioCentroResultadoDetModelList',
		'centroResultadoModel',
	];

	/**
		* Relations
		*/
	public function rateioCentroResultadoDetModelList()
{
	return $this->hasMany(RateioCentroResultadoDetModel::class, 'id_rateio_centro_resul_cab', 'id');
}

	public function centroResultadoModel()
	{
		return $this->belongsTo(CentroResultadoModel::class, 'id_centro_resultado', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
				$centroResultadoModel = new CentroResultadoModel();
				$centroResultadoModel->mapping($object->centroResultadoModel);
				$this->centroResultadoModel()->associate($centroResultadoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'rateioCentroResultadoDetModelList' => $this->rateioCentroResultadoDetModelList,
				'centroResultadoModel' => $this->centroResultadoModel,
			];
	}
}