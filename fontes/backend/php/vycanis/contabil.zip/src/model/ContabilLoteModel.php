<?php
declare(strict_types=1);

class ContabilLoteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_lote';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getDataInclusaoAttribute()
	{
		return $this->attributes['data_inclusao'];
	}

	public function setDataInclusaoAttribute($dataInclusao)
	{
		$this->attributes['data_inclusao'] = $dataInclusao;
	}

	public function getDataLiberacaoAttribute()
	{
		return $this->attributes['data_liberacao'];
	}

	public function setDataLiberacaoAttribute($dataLiberacao)
	{
		$this->attributes['data_liberacao'] = $dataLiberacao;
	}

	public function getLiberadoAttribute()
	{
		return $this->attributes['liberado'];
	}

	public function setLiberadoAttribute($liberado)
	{
		$this->attributes['liberado'] = $liberado;
	}

	public function getProgramadoAttribute()
	{
		return $this->attributes['programado'];
	}

	public function setProgramadoAttribute($programado)
	{
		$this->attributes['programado'] = $programado;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setDataInclusaoAttribute($object->dataInclusao);
				$this->setDataLiberacaoAttribute($object->dataLiberacao);
				$this->setLiberadoAttribute($object->liberado);
				$this->setProgramadoAttribute($object->programado);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'dataInclusao' => $this->getDataInclusaoAttribute(),
				'dataLiberacao' => $this->getDataLiberacaoAttribute(),
				'liberado' => $this->getLiberadoAttribute(),
				'programado' => $this->getProgramadoAttribute(),
				'valor' => $this->getValorAttribute(),
			];
	}
}