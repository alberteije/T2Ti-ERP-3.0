<?php
declare(strict_types=1);

class ContabilLancamentoOrcadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_lancamento_orcado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilContaModel',
	];

	/**
		* Relations
		*/
	public function contabilContaModel()
	{
		return $this->belongsTo(ContabilContaModel::class, 'id_contabil_conta', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getAnoAttribute()
	{
		return $this->attributes['ano'];
	}

	public function setAnoAttribute($ano)
	{
		$this->attributes['ano'] = $ano;
	}

	public function getJaneiroAttribute()
	{
		return (double)$this->attributes['janeiro'];
	}

	public function setJaneiroAttribute($janeiro)
	{
		$this->attributes['janeiro'] = $janeiro;
	}

	public function getFevereiroAttribute()
	{
		return (double)$this->attributes['fevereiro'];
	}

	public function setFevereiroAttribute($fevereiro)
	{
		$this->attributes['fevereiro'] = $fevereiro;
	}

	public function getMarcoAttribute()
	{
		return (double)$this->attributes['marco'];
	}

	public function setMarcoAttribute($marco)
	{
		$this->attributes['marco'] = $marco;
	}

	public function getAbrilAttribute()
	{
		return (double)$this->attributes['abril'];
	}

	public function setAbrilAttribute($abril)
	{
		$this->attributes['abril'] = $abril;
	}

	public function getMaioAttribute()
	{
		return (double)$this->attributes['maio'];
	}

	public function setMaioAttribute($maio)
	{
		$this->attributes['maio'] = $maio;
	}

	public function getJunhoAttribute()
	{
		return (double)$this->attributes['junho'];
	}

	public function setJunhoAttribute($junho)
	{
		$this->attributes['junho'] = $junho;
	}

	public function getJulhoAttribute()
	{
		return (double)$this->attributes['julho'];
	}

	public function setJulhoAttribute($julho)
	{
		$this->attributes['julho'] = $julho;
	}

	public function getAgostoAttribute()
	{
		return (double)$this->attributes['agosto'];
	}

	public function setAgostoAttribute($agosto)
	{
		$this->attributes['agosto'] = $agosto;
	}

	public function getSetembroAttribute()
	{
		return (double)$this->attributes['setembro'];
	}

	public function setSetembroAttribute($setembro)
	{
		$this->attributes['setembro'] = $setembro;
	}

	public function getOutubroAttribute()
	{
		return (double)$this->attributes['outubro'];
	}

	public function setOutubroAttribute($outubro)
	{
		$this->attributes['outubro'] = $outubro;
	}

	public function getNovembroAttribute()
	{
		return (double)$this->attributes['novembro'];
	}

	public function setNovembroAttribute($novembro)
	{
		$this->attributes['novembro'] = $novembro;
	}

	public function getDezembroAttribute()
	{
		return (double)$this->attributes['dezembro'];
	}

	public function setDezembroAttribute($dezembro)
	{
		$this->attributes['dezembro'] = $dezembro;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setAnoAttribute($object->ano);
				$this->setJaneiroAttribute($object->janeiro);
				$this->setFevereiroAttribute($object->fevereiro);
				$this->setMarcoAttribute($object->marco);
				$this->setAbrilAttribute($object->abril);
				$this->setMaioAttribute($object->maio);
				$this->setJunhoAttribute($object->junho);
				$this->setJulhoAttribute($object->julho);
				$this->setAgostoAttribute($object->agosto);
				$this->setSetembroAttribute($object->setembro);
				$this->setOutubroAttribute($object->outubro);
				$this->setNovembroAttribute($object->novembro);
				$this->setDezembroAttribute($object->dezembro);

				// link objects - lookups
				$contabilContaModel = new ContabilContaModel();
				$contabilContaModel->mapping($object->contabilContaModel);
				$this->contabilContaModel()->associate($contabilContaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'ano' => $this->getAnoAttribute(),
				'janeiro' => $this->getJaneiroAttribute(),
				'fevereiro' => $this->getFevereiroAttribute(),
				'marco' => $this->getMarcoAttribute(),
				'abril' => $this->getAbrilAttribute(),
				'maio' => $this->getMaioAttribute(),
				'junho' => $this->getJunhoAttribute(),
				'julho' => $this->getJulhoAttribute(),
				'agosto' => $this->getAgostoAttribute(),
				'setembro' => $this->getSetembroAttribute(),
				'outubro' => $this->getOutubroAttribute(),
				'novembro' => $this->getNovembroAttribute(),
				'dezembro' => $this->getDezembroAttribute(),
				'contabilContaModel' => $this->contabilContaModel,
			];
	}
}