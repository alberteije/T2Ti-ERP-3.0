<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// contabil-lancamento-cabecalho
$app->get('/contabil-lancamento-cabecalho[/]', \ContabilLancamentoCabecalhoController::class . RESULT_LIST);
$app->get('/contabil-lancamento-cabecalho/{id}', \ContabilLancamentoCabecalhoController::class . RESULT_OBJECT);
$app->post('/contabil-lancamento-cabecalho', \ContabilLancamentoCabecalhoController::class . INSERT);
$app->put('/contabil-lancamento-cabecalho', \ContabilLancamentoCabecalhoController::class . UPDATE);
$app->delete('/contabil-lancamento-cabecalho/{id}', \ContabilLancamentoCabecalhoController::class . DELETE);
$app->options('/contabil-lancamento-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lancamento-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lancamento-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-dre-cabecalho
$app->get('/contabil-dre-cabecalho[/]', \ContabilDreCabecalhoController::class . RESULT_LIST);
$app->get('/contabil-dre-cabecalho/{id}', \ContabilDreCabecalhoController::class . RESULT_OBJECT);
$app->post('/contabil-dre-cabecalho', \ContabilDreCabecalhoController::class . INSERT);
$app->put('/contabil-dre-cabecalho', \ContabilDreCabecalhoController::class . UPDATE);
$app->delete('/contabil-dre-cabecalho/{id}', \ContabilDreCabecalhoController::class . DELETE);
$app->options('/contabil-dre-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-dre-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-dre-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-livro
$app->get('/contabil-livro[/]', \ContabilLivroController::class . RESULT_LIST);
$app->get('/contabil-livro/{id}', \ContabilLivroController::class . RESULT_OBJECT);
$app->post('/contabil-livro', \ContabilLivroController::class . INSERT);
$app->put('/contabil-livro', \ContabilLivroController::class . UPDATE);
$app->delete('/contabil-livro/{id}', \ContabilLivroController::class . DELETE);
$app->options('/contabil-livro', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-livro/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-livro/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-encerramento-exe-cab
$app->get('/contabil-encerramento-exe-cab[/]', \ContabilEncerramentoExeCabController::class . RESULT_LIST);
$app->get('/contabil-encerramento-exe-cab/{id}', \ContabilEncerramentoExeCabController::class . RESULT_OBJECT);
$app->post('/contabil-encerramento-exe-cab', \ContabilEncerramentoExeCabController::class . INSERT);
$app->put('/contabil-encerramento-exe-cab', \ContabilEncerramentoExeCabController::class . UPDATE);
$app->delete('/contabil-encerramento-exe-cab/{id}', \ContabilEncerramentoExeCabController::class . DELETE);
$app->options('/contabil-encerramento-exe-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-encerramento-exe-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-encerramento-exe-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// centro-resultado
$app->get('/centro-resultado[/]', \CentroResultadoController::class . RESULT_LIST);
$app->get('/centro-resultado/{id}', \CentroResultadoController::class . RESULT_OBJECT);
$app->post('/centro-resultado', \CentroResultadoController::class . INSERT);
$app->put('/centro-resultado', \CentroResultadoController::class . UPDATE);
$app->delete('/centro-resultado/{id}', \CentroResultadoController::class . DELETE);
$app->options('/centro-resultado', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/centro-resultado/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/centro-resultado/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// rateio-centro-resultado-cab
$app->get('/rateio-centro-resultado-cab[/]', \RateioCentroResultadoCabController::class . RESULT_LIST);
$app->get('/rateio-centro-resultado-cab/{id}', \RateioCentroResultadoCabController::class . RESULT_OBJECT);
$app->post('/rateio-centro-resultado-cab', \RateioCentroResultadoCabController::class . INSERT);
$app->put('/rateio-centro-resultado-cab', \RateioCentroResultadoCabController::class . UPDATE);
$app->delete('/rateio-centro-resultado-cab/{id}', \RateioCentroResultadoCabController::class . DELETE);
$app->options('/rateio-centro-resultado-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/rateio-centro-resultado-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/rateio-centro-resultado-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-indice
$app->get('/contabil-indice[/]', \ContabilIndiceController::class . RESULT_LIST);
$app->get('/contabil-indice/{id}', \ContabilIndiceController::class . RESULT_OBJECT);
$app->post('/contabil-indice', \ContabilIndiceController::class . INSERT);
$app->put('/contabil-indice', \ContabilIndiceController::class . UPDATE);
$app->delete('/contabil-indice/{id}', \ContabilIndiceController::class . DELETE);
$app->options('/contabil-indice', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-indice/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-indice/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fin-natureza-financeira
$app->get('/fin-natureza-financeira[/]', \FinNaturezaFinanceiraController::class . RESULT_LIST);
$app->get('/fin-natureza-financeira/{id}', \FinNaturezaFinanceiraController::class . RESULT_OBJECT);
$app->post('/fin-natureza-financeira', \FinNaturezaFinanceiraController::class . INSERT);
$app->put('/fin-natureza-financeira', \FinNaturezaFinanceiraController::class . UPDATE);
$app->delete('/fin-natureza-financeira/{id}', \FinNaturezaFinanceiraController::class . DELETE);
$app->options('/fin-natureza-financeira', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-natureza-financeira/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fin-natureza-financeira/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// aidf-aimdf
$app->get('/aidf-aimdf[/]', \AidfAimdfController::class . RESULT_LIST);
$app->get('/aidf-aimdf/{id}', \AidfAimdfController::class . RESULT_OBJECT);
$app->post('/aidf-aimdf', \AidfAimdfController::class . INSERT);
$app->put('/aidf-aimdf', \AidfAimdfController::class . UPDATE);
$app->delete('/aidf-aimdf/{id}', \AidfAimdfController::class . DELETE);
$app->options('/aidf-aimdf', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/aidf-aimdf/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/aidf-aimdf/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// fap
$app->get('/fap[/]', \FapController::class . RESULT_LIST);
$app->get('/fap/{id}', \FapController::class . RESULT_OBJECT);
$app->post('/fap', \FapController::class . INSERT);
$app->put('/fap', \FapController::class . UPDATE);
$app->delete('/fap/{id}', \FapController::class . DELETE);
$app->options('/fap', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fap/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/fap/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// registro-cartorio
$app->get('/registro-cartorio[/]', \RegistroCartorioController::class . RESULT_LIST);
$app->get('/registro-cartorio/{id}', \RegistroCartorioController::class . RESULT_OBJECT);
$app->post('/registro-cartorio', \RegistroCartorioController::class . INSERT);
$app->put('/registro-cartorio', \RegistroCartorioController::class . UPDATE);
$app->delete('/registro-cartorio/{id}', \RegistroCartorioController::class . DELETE);
$app->options('/registro-cartorio', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/registro-cartorio/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/registro-cartorio/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-parametro
$app->get('/contabil-parametro[/]', \ContabilParametroController::class . RESULT_LIST);
$app->get('/contabil-parametro/{id}', \ContabilParametroController::class . RESULT_OBJECT);
$app->post('/contabil-parametro', \ContabilParametroController::class . INSERT);
$app->put('/contabil-parametro', \ContabilParametroController::class . UPDATE);
$app->delete('/contabil-parametro/{id}', \ContabilParametroController::class . DELETE);
$app->options('/contabil-parametro', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-parametro/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-parametro/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// plano-conta-ref-sped
$app->get('/plano-conta-ref-sped[/]', \PlanoContaRefSpedController::class . RESULT_LIST);
$app->get('/plano-conta-ref-sped/{id}', \PlanoContaRefSpedController::class . RESULT_OBJECT);
$app->post('/plano-conta-ref-sped', \PlanoContaRefSpedController::class . INSERT);
$app->put('/plano-conta-ref-sped', \PlanoContaRefSpedController::class . UPDATE);
$app->delete('/plano-conta-ref-sped/{id}', \PlanoContaRefSpedController::class . DELETE);
$app->options('/plano-conta-ref-sped', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/plano-conta-ref-sped/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/plano-conta-ref-sped/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// plano-conta
$app->get('/plano-conta[/]', \PlanoContaController::class . RESULT_LIST);
$app->get('/plano-conta/{id}', \PlanoContaController::class . RESULT_OBJECT);
$app->post('/plano-conta', \PlanoContaController::class . INSERT);
$app->put('/plano-conta', \PlanoContaController::class . UPDATE);
$app->delete('/plano-conta/{id}', \PlanoContaController::class . DELETE);
$app->options('/plano-conta', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/plano-conta/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/plano-conta/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-conta
$app->get('/contabil-conta[/]', \ContabilContaController::class . RESULT_LIST);
$app->get('/contabil-conta/{id}', \ContabilContaController::class . RESULT_OBJECT);
$app->post('/contabil-conta', \ContabilContaController::class . INSERT);
$app->put('/contabil-conta', \ContabilContaController::class . UPDATE);
$app->delete('/contabil-conta/{id}', \ContabilContaController::class . DELETE);
$app->options('/contabil-conta', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-conta/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-conta/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-historico
$app->get('/contabil-historico[/]', \ContabilHistoricoController::class . RESULT_LIST);
$app->get('/contabil-historico/{id}', \ContabilHistoricoController::class . RESULT_OBJECT);
$app->post('/contabil-historico', \ContabilHistoricoController::class . INSERT);
$app->put('/contabil-historico', \ContabilHistoricoController::class . UPDATE);
$app->delete('/contabil-historico/{id}', \ContabilHistoricoController::class . DELETE);
$app->options('/contabil-historico', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-historico/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-historico/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-lancamento-padrao
$app->get('/contabil-lancamento-padrao[/]', \ContabilLancamentoPadraoController::class . RESULT_LIST);
$app->get('/contabil-lancamento-padrao/{id}', \ContabilLancamentoPadraoController::class . RESULT_OBJECT);
$app->post('/contabil-lancamento-padrao', \ContabilLancamentoPadraoController::class . INSERT);
$app->put('/contabil-lancamento-padrao', \ContabilLancamentoPadraoController::class . UPDATE);
$app->delete('/contabil-lancamento-padrao/{id}', \ContabilLancamentoPadraoController::class . DELETE);
$app->options('/contabil-lancamento-padrao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lancamento-padrao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lancamento-padrao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-lote
$app->get('/contabil-lote[/]', \ContabilLoteController::class . RESULT_LIST);
$app->get('/contabil-lote/{id}', \ContabilLoteController::class . RESULT_OBJECT);
$app->post('/contabil-lote', \ContabilLoteController::class . INSERT);
$app->put('/contabil-lote', \ContabilLoteController::class . UPDATE);
$app->delete('/contabil-lote/{id}', \ContabilLoteController::class . DELETE);
$app->options('/contabil-lote', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lote/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lote/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-lancamento-orcado
$app->get('/contabil-lancamento-orcado[/]', \ContabilLancamentoOrcadoController::class . RESULT_LIST);
$app->get('/contabil-lancamento-orcado/{id}', \ContabilLancamentoOrcadoController::class . RESULT_OBJECT);
$app->post('/contabil-lancamento-orcado', \ContabilLancamentoOrcadoController::class . INSERT);
$app->put('/contabil-lancamento-orcado', \ContabilLancamentoOrcadoController::class . UPDATE);
$app->delete('/contabil-lancamento-orcado/{id}', \ContabilLancamentoOrcadoController::class . DELETE);
$app->options('/contabil-lancamento-orcado', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lancamento-orcado/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-lancamento-orcado/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// lanca-centro-resultado
$app->get('/lanca-centro-resultado[/]', \LancaCentroResultadoController::class . RESULT_LIST);
$app->get('/lanca-centro-resultado/{id}', \LancaCentroResultadoController::class . RESULT_OBJECT);
$app->post('/lanca-centro-resultado', \LancaCentroResultadoController::class . INSERT);
$app->put('/lanca-centro-resultado', \LancaCentroResultadoController::class . UPDATE);
$app->delete('/lanca-centro-resultado/{id}', \LancaCentroResultadoController::class . DELETE);
$app->options('/lanca-centro-resultado', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/lanca-centro-resultado/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/lanca-centro-resultado/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// encerra-centro-resultado
$app->get('/encerra-centro-resultado[/]', \EncerraCentroResultadoController::class . RESULT_LIST);
$app->get('/encerra-centro-resultado/{id}', \EncerraCentroResultadoController::class . RESULT_OBJECT);
$app->post('/encerra-centro-resultado', \EncerraCentroResultadoController::class . INSERT);
$app->put('/encerra-centro-resultado', \EncerraCentroResultadoController::class . UPDATE);
$app->delete('/encerra-centro-resultado/{id}', \EncerraCentroResultadoController::class . DELETE);
$app->options('/encerra-centro-resultado', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/encerra-centro-resultado/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/encerra-centro-resultado/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-conta-rateio
$app->get('/contabil-conta-rateio[/]', \ContabilContaRateioController::class . RESULT_LIST);
$app->get('/contabil-conta-rateio/{id}', \ContabilContaRateioController::class . RESULT_OBJECT);
$app->post('/contabil-conta-rateio', \ContabilContaRateioController::class . INSERT);
$app->put('/contabil-conta-rateio', \ContabilContaRateioController::class . UPDATE);
$app->delete('/contabil-conta-rateio/{id}', \ContabilContaRateioController::class . DELETE);
$app->options('/contabil-conta-rateio', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-conta-rateio/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-conta-rateio/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// contabil-fechamento
$app->get('/contabil-fechamento[/]', \ContabilFechamentoController::class . RESULT_LIST);
$app->get('/contabil-fechamento/{id}', \ContabilFechamentoController::class . RESULT_OBJECT);
$app->post('/contabil-fechamento', \ContabilFechamentoController::class . INSERT);
$app->put('/contabil-fechamento', \ContabilFechamentoController::class . UPDATE);
$app->delete('/contabil-fechamento/{id}', \ContabilFechamentoController::class . DELETE);
$app->options('/contabil-fechamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-fechamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/contabil-fechamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// plano-centro-resultado
$app->get('/plano-centro-resultado[/]', \PlanoCentroResultadoController::class . RESULT_LIST);
$app->get('/plano-centro-resultado/{id}', \PlanoCentroResultadoController::class . RESULT_OBJECT);
$app->post('/plano-centro-resultado', \PlanoCentroResultadoController::class . INSERT);
$app->put('/plano-centro-resultado', \PlanoCentroResultadoController::class . UPDATE);
$app->delete('/plano-centro-resultado/{id}', \PlanoCentroResultadoController::class . DELETE);
$app->options('/plano-centro-resultado', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/plano-centro-resultado/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/plano-centro-resultado/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

