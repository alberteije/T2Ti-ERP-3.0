<?php
class ContabilLancamentoPadraoController extends ControllerBase
{

		private $contabilLancamentoPadraoService = null;

		public function __construct()
		{	 
				$this->contabilLancamentoPadraoService = new ContabilLancamentoPadraoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->contabilLancamentoPadraoService->getListFilter($filter);
						} else {
								$resultList = $this->contabilLancamentoPadraoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList ContabilLancamentoPadrao]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contabilLancamentoPadraoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject ContabilLancamentoPadrao]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject ContabilLancamentoPadrao]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert ContabilLancamentoPadrao]', null);
						}

						$objModel = new ContabilLancamentoPadraoModel();
						$objModel->mapping($objJson);

						$this->contabilLancamentoPadraoService->save($objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert ContabilLancamentoPadrao]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->contabilLancamentoPadraoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update ContabilLancamentoPadrao]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->contabilLancamentoPadraoService->save($objFromDatabase);
								$objFromDatabase = $this->contabilLancamentoPadraoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update ContabilLancamentoPadrao]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->contabilLancamentoPadraoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete ContabilLancamentoPadrao]', null);
						} else {
								$this->contabilLancamentoPadraoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete ContabilLancamentoPadrao]', $e);
				}
		}
}
