<?php
declare(strict_types=1);

class ContabilEncerramentoExeCabModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_encerramento_exe_cab';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilEncerramentoExeDetModelList',
	];

	/**
		* Relations
		*/
	public function contabilEncerramentoExeDetModelList()
{
	return $this->hasMany(ContabilEncerramentoExeDetModel::class, 'id_contabil_encerramento_exe', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataInicioAttribute()
	{
		return $this->attributes['data_inicio'];
	}

	public function setDataInicioAttribute($dataInicio)
	{
		$this->attributes['data_inicio'] = $dataInicio;
	}

	public function getDataFimAttribute()
	{
		return $this->attributes['data_fim'];
	}

	public function setDataFimAttribute($dataFim)
	{
		$this->attributes['data_fim'] = $dataFim;
	}

	public function getDataInclusaoAttribute()
	{
		return $this->attributes['data_inclusao'];
	}

	public function setDataInclusaoAttribute($dataInclusao)
	{
		$this->attributes['data_inclusao'] = $dataInclusao;
	}

	public function getMotivoAttribute()
	{
		return $this->attributes['motivo'];
	}

	public function setMotivoAttribute($motivo)
	{
		$this->attributes['motivo'] = $motivo;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataInicioAttribute($object->dataInicio);
				$this->setDataFimAttribute($object->dataFim);
				$this->setDataInclusaoAttribute($object->dataInclusao);
				$this->setMotivoAttribute($object->motivo);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataInicio' => $this->getDataInicioAttribute(),
				'dataFim' => $this->getDataFimAttribute(),
				'dataInclusao' => $this->getDataInclusaoAttribute(),
				'motivo' => $this->getMotivoAttribute(),
				'contabilEncerramentoExeDetModelList' => $this->contabilEncerramentoExeDetModelList,
			];
	}
}