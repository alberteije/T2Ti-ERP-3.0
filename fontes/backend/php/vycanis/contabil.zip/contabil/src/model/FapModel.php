<?php
declare(strict_types=1);

class FapModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'fap';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getFapAttribute()
	{
		return (double)$this->attributes['fap'];
	}

	public function setFapAttribute($fap)
	{
		$this->attributes['fap'] = $fap;
	}

	public function getDataInicialAttribute()
	{
		return $this->attributes['data_inicial'];
	}

	public function setDataInicialAttribute($dataInicial)
	{
		$this->attributes['data_inicial'] = $dataInicial;
	}

	public function getDataFinalAttribute()
	{
		return $this->attributes['data_final'];
	}

	public function setDataFinalAttribute($dataFinal)
	{
		$this->attributes['data_final'] = $dataFinal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setFapAttribute($object->fap);
				$this->setDataInicialAttribute($object->dataInicial);
				$this->setDataFinalAttribute($object->dataFinal);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'fap' => $this->getFapAttribute(),
				'dataInicial' => $this->getDataInicialAttribute(),
				'dataFinal' => $this->getDataFinalAttribute(),
			];
	}
}