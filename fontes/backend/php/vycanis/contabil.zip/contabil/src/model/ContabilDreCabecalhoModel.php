<?php
declare(strict_types=1);

class ContabilDreCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_dre_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilDreDetalheModelList',
	];

	/**
		* Relations
		*/
	public function contabilDreDetalheModelList()
{
	return $this->hasMany(ContabilDreDetalheModel::class, 'id_contabil_dre_cabecalho', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getPadraoAttribute()
	{
		return $this->attributes['padrao'];
	}

	public function setPadraoAttribute($padrao)
	{
		$this->attributes['padrao'] = $padrao;
	}

	public function getPeriodoInicialAttribute()
	{
		return $this->attributes['periodo_inicial'];
	}

	public function setPeriodoInicialAttribute($periodoInicial)
	{
		$this->attributes['periodo_inicial'] = $periodoInicial;
	}

	public function getPeriodoFinalAttribute()
	{
		return $this->attributes['periodo_final'];
	}

	public function setPeriodoFinalAttribute($periodoFinal)
	{
		$this->attributes['periodo_final'] = $periodoFinal;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setPadraoAttribute($object->padrao);
				$this->setPeriodoInicialAttribute($object->periodoInicial);
				$this->setPeriodoFinalAttribute($object->periodoFinal);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'padrao' => $this->getPadraoAttribute(),
				'periodoInicial' => $this->getPeriodoInicialAttribute(),
				'periodoFinal' => $this->getPeriodoFinalAttribute(),
				'contabilDreDetalheModelList' => $this->contabilDreDetalheModelList,
			];
	}
}