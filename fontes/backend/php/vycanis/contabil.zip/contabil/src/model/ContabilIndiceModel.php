<?php
declare(strict_types=1);

class ContabilIndiceModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_indice';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilIndiceValorModelList',
	];

	/**
		* Relations
		*/
	public function contabilIndiceValorModelList()
{
	return $this->hasMany(ContabilIndiceValorModel::class, 'id_contabil_indice', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIndiceAttribute()
	{
		return $this->attributes['indice'];
	}

	public function setIndiceAttribute($indice)
	{
		$this->attributes['indice'] = $indice;
	}

	public function getPeriodicidadeAttribute()
	{
		return $this->attributes['periodicidade'];
	}

	public function setPeriodicidadeAttribute($periodicidade)
	{
		$this->attributes['periodicidade'] = $periodicidade;
	}

	public function getDiarioAPartirDeAttribute()
	{
		return $this->attributes['diario_a_partir_de'];
	}

	public function setDiarioAPartirDeAttribute($diarioAPartirDe)
	{
		$this->attributes['diario_a_partir_de'] = $diarioAPartirDe;
	}

	public function getMensalMesAnoAttribute()
	{
		return $this->attributes['mensal_mes_ano'];
	}

	public function setMensalMesAnoAttribute($mensalMesAno)
	{
		$this->attributes['mensal_mes_ano'] = $mensalMesAno;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIndiceAttribute($object->indice);
				$this->setPeriodicidadeAttribute($object->periodicidade);
				$this->setDiarioAPartirDeAttribute($object->diarioAPartirDe);
				$this->setMensalMesAnoAttribute($object->mensalMesAno);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'indice' => $this->getIndiceAttribute(),
				'periodicidade' => $this->getPeriodicidadeAttribute(),
				'diarioAPartirDe' => $this->getDiarioAPartirDeAttribute(),
				'mensalMesAno' => $this->getMensalMesAnoAttribute(),
				'contabilIndiceValorModelList' => $this->contabilIndiceValorModelList,
			];
	}
}