<?php
declare(strict_types=1);

class ContabilLivroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_livro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilTermoModelList',
	];

	/**
		* Relations
		*/
	public function contabilTermoModelList()
{
	return $this->hasMany(ContabilTermoModel::class, 'id_contabil_livro', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCompetenciaAttribute()
	{
		return $this->attributes['competencia'];
	}

	public function setCompetenciaAttribute($competencia)
	{
		$this->attributes['competencia'] = $competencia;
	}

	public function getFormaEscrituracaoAttribute()
	{
		return $this->attributes['forma_escrituracao'];
	}

	public function setFormaEscrituracaoAttribute($formaEscrituracao)
	{
		$this->attributes['forma_escrituracao'] = $formaEscrituracao;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCompetenciaAttribute($object->competencia);
				$this->setFormaEscrituracaoAttribute($object->formaEscrituracao);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'competencia' => $this->getCompetenciaAttribute(),
				'formaEscrituracao' => $this->getFormaEscrituracaoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'contabilTermoModelList' => $this->contabilTermoModelList,
			];
	}
}