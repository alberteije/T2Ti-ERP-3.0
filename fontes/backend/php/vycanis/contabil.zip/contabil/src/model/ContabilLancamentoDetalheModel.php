<?php
declare(strict_types=1);

class ContabilLancamentoDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_lancamento_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilHistoricoModel',
		'contabilContaModel',
	];

	/**
		* Relations
		*/
	public function contabilLancamentoCabecalhoModel()
	{
		return $this->belongsTo(ContabilLancamentoCabecalhoModel::class, 'id_contabil_lancamento_cab', 'id');
	}

	public function contabilHistoricoModel()
	{
		return $this->belongsTo(ContabilHistoricoModel::class, 'id_contabil_historico', 'id');
	}

	public function contabilContaModel()
	{
		return $this->belongsTo(ContabilContaModel::class, 'id_contabil_conta', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getHistoricoAttribute()
	{
		return $this->attributes['historico'];
	}

	public function setHistoricoAttribute($historico)
	{
		$this->attributes['historico'] = $historico;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setTipoAttribute($object->tipo);
				$this->setValorAttribute($object->valor);
				$this->setHistoricoAttribute($object->historico);

				// link objects - lookups
				$contabilHistoricoModel = new ContabilHistoricoModel();
				$contabilHistoricoModel->mapping($object->contabilHistoricoModel);
				$this->contabilHistoricoModel()->associate($contabilHistoricoModel);
				$contabilContaModel = new ContabilContaModel();
				$contabilContaModel->mapping($object->contabilContaModel);
				$this->contabilContaModel()->associate($contabilContaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'valor' => $this->getValorAttribute(),
				'historico' => $this->getHistoricoAttribute(),
				'contabilHistoricoModel' => $this->contabilHistoricoModel,
				'contabilContaModel' => $this->contabilContaModel,
			];
	}
}