<?php
declare(strict_types=1);

class RateioCentroResultadoDetModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'rateio_centro_resultado_det';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'centroResultadoModel',
	];

	/**
		* Relations
		*/
	public function rateioCentroResultadoCabModel()
	{
		return $this->belongsTo(RateioCentroResultadoCabModel::class, 'id_rateio_centro_resul_cab', 'id');
	}

	public function centroResultadoModel()
	{
		return $this->belongsTo(CentroResultadoModel::class, 'id_centro_resultado_destino', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getPorcentoRateioAttribute()
	{
		return (double)$this->attributes['porcento_rateio'];
	}

	public function setPorcentoRateioAttribute($porcentoRateio)
	{
		$this->attributes['porcento_rateio'] = $porcentoRateio;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setPorcentoRateioAttribute($object->porcentoRateio);

				// link objects - lookups
				$centroResultadoModel = new CentroResultadoModel();
				$centroResultadoModel->mapping($object->centroResultadoModel);
				$this->centroResultadoModel()->associate($centroResultadoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'porcentoRateio' => $this->getPorcentoRateioAttribute(),
				'centroResultadoModel' => $this->centroResultadoModel,
			];
	}
}