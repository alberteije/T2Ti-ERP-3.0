<?php
declare(strict_types=1);

class LancaCentroResultadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'lanca_centro_resultado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'centroResultadoModel',
	];

	/**
		* Relations
		*/
	public function centroResultadoModel()
	{
		return $this->belongsTo(CentroResultadoModel::class, 'id_centro_resultado', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	public function getDataLancamentoAttribute()
	{
		return $this->attributes['data_lancamento'];
	}

	public function setDataLancamentoAttribute($dataLancamento)
	{
		$this->attributes['data_lancamento'] = $dataLancamento;
	}

	public function getDataInclusaoAttribute()
	{
		return $this->attributes['data_inclusao'];
	}

	public function setDataInclusaoAttribute($dataInclusao)
	{
		$this->attributes['data_inclusao'] = $dataInclusao;
	}

	public function getOrigemDeRateioAttribute()
	{
		return $this->attributes['origem_de_rateio'];
	}

	public function setOrigemDeRateioAttribute($origemDeRateio)
	{
		$this->attributes['origem_de_rateio'] = $origemDeRateio;
	}

	public function getHistoricoAttribute()
	{
		return $this->attributes['historico'];
	}

	public function setHistoricoAttribute($historico)
	{
		$this->attributes['historico'] = $historico;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setValorAttribute($object->valor);
				$this->setDataLancamentoAttribute($object->dataLancamento);
				$this->setDataInclusaoAttribute($object->dataInclusao);
				$this->setOrigemDeRateioAttribute($object->origemDeRateio);
				$this->setHistoricoAttribute($object->historico);

				// link objects - lookups
				$centroResultadoModel = new CentroResultadoModel();
				$centroResultadoModel->mapping($object->centroResultadoModel);
				$this->centroResultadoModel()->associate($centroResultadoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'valor' => $this->getValorAttribute(),
				'dataLancamento' => $this->getDataLancamentoAttribute(),
				'dataInclusao' => $this->getDataInclusaoAttribute(),
				'origemDeRateio' => $this->getOrigemDeRateioAttribute(),
				'historico' => $this->getHistoricoAttribute(),
				'centroResultadoModel' => $this->centroResultadoModel,
			];
	}
}