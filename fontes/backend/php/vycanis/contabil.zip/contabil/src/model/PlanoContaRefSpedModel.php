<?php
declare(strict_types=1);

class PlanoContaRefSpedModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'plano_conta_ref_sped';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodCtaRefAttribute()
	{
		return $this->attributes['cod_cta_ref'];
	}

	public function setCodCtaRefAttribute($codCtaRef)
	{
		$this->attributes['cod_cta_ref'] = $codCtaRef;
	}

	public function getInicioValidadeAttribute()
	{
		return $this->attributes['inicio_validade'];
	}

	public function setInicioValidadeAttribute($inicioValidade)
	{
		$this->attributes['inicio_validade'] = $inicioValidade;
	}

	public function getFimValidadeAttribute()
	{
		return $this->attributes['fim_validade'];
	}

	public function setFimValidadeAttribute($fimValidade)
	{
		$this->attributes['fim_validade'] = $fimValidade;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getOrientacoesAttribute()
	{
		return $this->attributes['orientacoes'];
	}

	public function setOrientacoesAttribute($orientacoes)
	{
		$this->attributes['orientacoes'] = $orientacoes;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodCtaRefAttribute($object->codCtaRef);
				$this->setInicioValidadeAttribute($object->inicioValidade);
				$this->setFimValidadeAttribute($object->fimValidade);
				$this->setTipoAttribute($object->tipo);
				$this->setDescricaoAttribute($object->descricao);
				$this->setOrientacoesAttribute($object->orientacoes);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codCtaRef' => $this->getCodCtaRefAttribute(),
				'inicioValidade' => $this->getInicioValidadeAttribute(),
				'fimValidade' => $this->getFimValidadeAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'orientacoes' => $this->getOrientacoesAttribute(),
			];
	}
}