<?php
declare(strict_types=1);

class RegistroCartorioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'registro_cartorio';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeCartorioAttribute()
	{
		return $this->attributes['nome_cartorio'];
	}

	public function setNomeCartorioAttribute($nomeCartorio)
	{
		$this->attributes['nome_cartorio'] = $nomeCartorio;
	}

	public function getDataRegistroAttribute()
	{
		return $this->attributes['data_registro'];
	}

	public function setDataRegistroAttribute($dataRegistro)
	{
		$this->attributes['data_registro'] = $dataRegistro;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getFolhaAttribute()
	{
		return $this->attributes['folha'];
	}

	public function setFolhaAttribute($folha)
	{
		$this->attributes['folha'] = $folha;
	}

	public function getLivroAttribute()
	{
		return $this->attributes['livro'];
	}

	public function setLivroAttribute($livro)
	{
		$this->attributes['livro'] = $livro;
	}

	public function getNireAttribute()
	{
		return $this->attributes['nire'];
	}

	public function setNireAttribute($nire)
	{
		$this->attributes['nire'] = $nire;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeCartorioAttribute($object->nomeCartorio);
				$this->setDataRegistroAttribute($object->dataRegistro);
				$this->setNumeroAttribute($object->numero);
				$this->setFolhaAttribute($object->folha);
				$this->setLivroAttribute($object->livro);
				$this->setNireAttribute($object->nire);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nomeCartorio' => $this->getNomeCartorioAttribute(),
				'dataRegistro' => $this->getDataRegistroAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'folha' => $this->getFolhaAttribute(),
				'livro' => $this->getLivroAttribute(),
				'nire' => $this->getNireAttribute(),
			];
	}
}