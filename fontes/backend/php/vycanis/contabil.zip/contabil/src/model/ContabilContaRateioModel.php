<?php
declare(strict_types=1);

class ContabilContaRateioModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_conta_rateio';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'contabilContaModel',
		'centroResultadoModel',
	];

	/**
		* Relations
		*/
	public function contabilContaModel()
	{
		return $this->belongsTo(ContabilContaModel::class, 'id_contabil_conta', 'id');
	}

	public function centroResultadoModel()
	{
		return $this->belongsTo(CentroResultadoModel::class, 'id_centro_resultado', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getPorcentoRateioAttribute()
	{
		return (double)$this->attributes['porcento_rateio'];
	}

	public function setPorcentoRateioAttribute($porcentoRateio)
	{
		$this->attributes['porcento_rateio'] = $porcentoRateio;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setPorcentoRateioAttribute($object->porcentoRateio);

				// link objects - lookups
				$contabilContaModel = new ContabilContaModel();
				$contabilContaModel->mapping($object->contabilContaModel);
				$this->contabilContaModel()->associate($contabilContaModel);
				$centroResultadoModel = new CentroResultadoModel();
				$centroResultadoModel->mapping($object->centroResultadoModel);
				$this->centroResultadoModel()->associate($centroResultadoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'porcentoRateio' => $this->getPorcentoRateioAttribute(),
				'contabilContaModel' => $this->contabilContaModel,
				'centroResultadoModel' => $this->centroResultadoModel,
			];
	}
}