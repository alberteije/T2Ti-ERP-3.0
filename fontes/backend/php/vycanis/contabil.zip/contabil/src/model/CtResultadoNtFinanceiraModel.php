<?php
declare(strict_types=1);

class CtResultadoNtFinanceiraModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'ct_resultado_nt_financeira';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'finNaturezaFinanceiraModel',
	];

	/**
		* Relations
		*/
	public function finNaturezaFinanceiraModel()
	{
		return $this->belongsTo(FinNaturezaFinanceiraModel::class, 'id_fin_natureza_financeira', 'id');
	}

	public function centroResultadoModel()
	{
		return $this->belongsTo(CentroResultadoModel::class, 'id_centro_resultado', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getPercentualRateioAttribute()
	{
		return (double)$this->attributes['percentual_rateio'];
	}

	public function setPercentualRateioAttribute($percentualRateio)
	{
		$this->attributes['percentual_rateio'] = $percentualRateio;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setPercentualRateioAttribute($object->percentualRateio);

				// link objects - lookups
				$finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel();
				$finNaturezaFinanceiraModel->mapping($object->finNaturezaFinanceiraModel);
				$this->finNaturezaFinanceiraModel()->associate($finNaturezaFinanceiraModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'percentualRateio' => $this->getPercentualRateioAttribute(),
				'finNaturezaFinanceiraModel' => $this->finNaturezaFinanceiraModel,
			];
	}
}