<?php
declare(strict_types=1);

class ContabilDreDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_dre_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/
	public function contabilDreCabecalhoModel()
	{
		return $this->belongsTo(ContabilDreCabecalhoModel::class, 'id_contabil_dre_cabecalho', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getClassificacaoAttribute()
	{
		return $this->attributes['classificacao'];
	}

	public function setClassificacaoAttribute($classificacao)
	{
		$this->attributes['classificacao'] = $classificacao;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getFormaCalculoAttribute()
	{
		return $this->attributes['forma_calculo'];
	}

	public function setFormaCalculoAttribute($formaCalculo)
	{
		$this->attributes['forma_calculo'] = $formaCalculo;
	}

	public function getSinalAttribute()
	{
		return $this->attributes['sinal'];
	}

	public function setSinalAttribute($sinal)
	{
		$this->attributes['sinal'] = $sinal;
	}

	public function getNaturezaAttribute()
	{
		return $this->attributes['natureza'];
	}

	public function setNaturezaAttribute($natureza)
	{
		$this->attributes['natureza'] = $natureza;
	}

	public function getValorAttribute()
	{
		return (double)$this->attributes['valor'];
	}

	public function setValorAttribute($valor)
	{
		$this->attributes['valor'] = $valor;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setClassificacaoAttribute($object->classificacao);
				$this->setDescricaoAttribute($object->descricao);
				$this->setFormaCalculoAttribute($object->formaCalculo);
				$this->setSinalAttribute($object->sinal);
				$this->setNaturezaAttribute($object->natureza);
				$this->setValorAttribute($object->valor);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'classificacao' => $this->getClassificacaoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'formaCalculo' => $this->getFormaCalculoAttribute(),
				'sinal' => $this->getSinalAttribute(),
				'natureza' => $this->getNaturezaAttribute(),
				'valor' => $this->getValorAttribute(),
			];
	}
}