<?php
declare(strict_types=1);

class PlanoCentroResultadoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'plano_centro_resultado';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getMascaraAttribute()
	{
		return $this->attributes['mascara'];
	}

	public function setMascaraAttribute($mascara)
	{
		$this->attributes['mascara'] = $mascara;
	}

	public function getNiveisAttribute()
	{
		return $this->attributes['niveis'];
	}

	public function setNiveisAttribute($niveis)
	{
		$this->attributes['niveis'] = $niveis;
	}

	public function getDataInclusaoAttribute()
	{
		return $this->attributes['data_inclusao'];
	}

	public function setDataInclusaoAttribute($dataInclusao)
	{
		$this->attributes['data_inclusao'] = $dataInclusao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setMascaraAttribute($object->mascara);
				$this->setNiveisAttribute($object->niveis);
				$this->setDataInclusaoAttribute($object->dataInclusao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'mascara' => $this->getMascaraAttribute(),
				'niveis' => $this->getNiveisAttribute(),
				'dataInclusao' => $this->getDataInclusaoAttribute(),
			];
	}
}