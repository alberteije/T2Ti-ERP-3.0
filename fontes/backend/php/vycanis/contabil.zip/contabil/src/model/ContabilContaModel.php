<?php
declare(strict_types=1);

class ContabilContaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_conta';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'planoContaModel',
		'planoContaRefSpedModel',
	];

	/**
		* Relations
		*/
	public function planoContaModel()
	{
		return $this->belongsTo(PlanoContaModel::class, 'id_plano_conta', 'id');
	}

	public function planoContaRefSpedModel()
	{
		return $this->belongsTo(PlanoContaRefSpedModel::class, 'id_plano_conta_ref_sped', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getIdContabilContaAttribute()
	{
		return $this->attributes['id_contabil_conta'];
	}

	public function setIdContabilContaAttribute($idContabilConta)
	{
		$this->attributes['id_contabil_conta'] = $idContabilConta;
	}

	public function getClassificacaoAttribute()
	{
		return $this->attributes['classificacao'];
	}

	public function setClassificacaoAttribute($classificacao)
	{
		$this->attributes['classificacao'] = $classificacao;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getDataInclusaoAttribute()
	{
		return $this->attributes['data_inclusao'];
	}

	public function setDataInclusaoAttribute($dataInclusao)
	{
		$this->attributes['data_inclusao'] = $dataInclusao;
	}

	public function getSituacaoAttribute()
	{
		return $this->attributes['situacao'];
	}

	public function setSituacaoAttribute($situacao)
	{
		$this->attributes['situacao'] = $situacao;
	}

	public function getNaturezaAttribute()
	{
		return $this->attributes['natureza'];
	}

	public function setNaturezaAttribute($natureza)
	{
		$this->attributes['natureza'] = $natureza;
	}

	public function getPatrimonioResultadoAttribute()
	{
		return $this->attributes['patrimonio_resultado'];
	}

	public function setPatrimonioResultadoAttribute($patrimonioResultado)
	{
		$this->attributes['patrimonio_resultado'] = $patrimonioResultado;
	}

	public function getLivroCaixaAttribute()
	{
		return $this->attributes['livro_caixa'];
	}

	public function setLivroCaixaAttribute($livroCaixa)
	{
		$this->attributes['livro_caixa'] = $livroCaixa;
	}

	public function getDfcAttribute()
	{
		return $this->attributes['dfc'];
	}

	public function setDfcAttribute($dfc)
	{
		$this->attributes['dfc'] = $dfc;
	}

	public function getCodigoEfdAttribute()
	{
		return $this->attributes['codigo_efd'];
	}

	public function setCodigoEfdAttribute($codigoEfd)
	{
		$this->attributes['codigo_efd'] = $codigoEfd;
	}

	public function getOrdemAttribute()
	{
		return $this->attributes['ordem'];
	}

	public function setOrdemAttribute($ordem)
	{
		$this->attributes['ordem'] = $ordem;
	}

	public function getCodigoReduzidoAttribute()
	{
		return $this->attributes['codigo_reduzido'];
	}

	public function setCodigoReduzidoAttribute($codigoReduzido)
	{
		$this->attributes['codigo_reduzido'] = $codigoReduzido;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setIdContabilContaAttribute($object->idContabilConta);
				$this->setClassificacaoAttribute($object->classificacao);
				$this->setTipoAttribute($object->tipo);
				$this->setDescricaoAttribute($object->descricao);
				$this->setDataInclusaoAttribute($object->dataInclusao);
				$this->setSituacaoAttribute($object->situacao);
				$this->setNaturezaAttribute($object->natureza);
				$this->setPatrimonioResultadoAttribute($object->patrimonioResultado);
				$this->setLivroCaixaAttribute($object->livroCaixa);
				$this->setDfcAttribute($object->dfc);
				$this->setCodigoEfdAttribute($object->codigoEfd);
				$this->setOrdemAttribute($object->ordem);
				$this->setCodigoReduzidoAttribute($object->codigoReduzido);

				// link objects - lookups
				$planoContaModel = new PlanoContaModel();
				$planoContaModel->mapping($object->planoContaModel);
				$this->planoContaModel()->associate($planoContaModel);
				$planoContaRefSpedModel = new PlanoContaRefSpedModel();
				$planoContaRefSpedModel->mapping($object->planoContaRefSpedModel);
				$this->planoContaRefSpedModel()->associate($planoContaRefSpedModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'idContabilConta' => $this->getIdContabilContaAttribute(),
				'classificacao' => $this->getClassificacaoAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'dataInclusao' => $this->getDataInclusaoAttribute(),
				'situacao' => $this->getSituacaoAttribute(),
				'natureza' => $this->getNaturezaAttribute(),
				'patrimonioResultado' => $this->getPatrimonioResultadoAttribute(),
				'livroCaixa' => $this->getLivroCaixaAttribute(),
				'dfc' => $this->getDfcAttribute(),
				'codigoEfd' => $this->getCodigoEfdAttribute(),
				'ordem' => $this->getOrdemAttribute(),
				'codigoReduzido' => $this->getCodigoReduzidoAttribute(),
				'planoContaModel' => $this->planoContaModel,
				'planoContaRefSpedModel' => $this->planoContaRefSpedModel,
			];
	}
}