<?php
declare(strict_types=1);

class ContabilLancamentoPadraoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'contabil_lancamento_padrao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	public function getHistoricoAttribute()
	{
		return $this->attributes['historico'];
	}

	public function setHistoricoAttribute($historico)
	{
		$this->attributes['historico'] = $historico;
	}

	public function getIdContaDebitoAttribute()
	{
		return $this->attributes['id_conta_debito'];
	}

	public function setIdContaDebitoAttribute($idContaDebito)
	{
		$this->attributes['id_conta_debito'] = $idContaDebito;
	}

	public function getIdContaCreditoAttribute()
	{
		return $this->attributes['id_conta_credito'];
	}

	public function setIdContaCreditoAttribute($idContaCredito)
	{
		$this->attributes['id_conta_credito'] = $idContaCredito;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDescricaoAttribute($object->descricao);
				$this->setHistoricoAttribute($object->historico);
				$this->setIdContaDebitoAttribute($object->idContaDebito);
				$this->setIdContaCreditoAttribute($object->idContaCredito);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'historico' => $this->getHistoricoAttribute(),
				'idContaDebito' => $this->getIdContaDebitoAttribute(),
				'idContaCredito' => $this->getIdContaCreditoAttribute(),
			];
	}
}