<?php
class ContabilLancamentoPadraoService extends ServiceBase
{
  public function getList()
  {
    return ContabilLancamentoPadraoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilLancamentoPadraoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilLancamentoPadraoModel::find($id);
  }

}