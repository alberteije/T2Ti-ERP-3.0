<?php
class ContabilFechamentoService extends ServiceBase
{
  public function getList()
  {
    return ContabilFechamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilFechamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilFechamentoModel::find($id);
  }

}