<?php
class ContabilLancamentoOrcadoService extends ServiceBase
{
  public function getList()
  {
    return ContabilLancamentoOrcadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ContabilLancamentoOrcadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return ContabilLancamentoOrcadoModel::find($id);
  }

}