<?php
class PlanoCentroResultadoService extends ServiceBase
{
  public function getList()
  {
    return PlanoCentroResultadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PlanoCentroResultadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PlanoCentroResultadoModel::find($id);
  }

}