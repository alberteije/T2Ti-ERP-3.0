<?php
class LancaCentroResultadoService extends ServiceBase
{
  public function getList()
  {
    return LancaCentroResultadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return LancaCentroResultadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return LancaCentroResultadoModel::find($id);
  }

}