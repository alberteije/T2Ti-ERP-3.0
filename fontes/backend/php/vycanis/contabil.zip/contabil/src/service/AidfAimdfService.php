<?php
class AidfAimdfService extends ServiceBase
{
  public function getList()
  {
    return AidfAimdfModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return AidfAimdfModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return AidfAimdfModel::find($id);
  }

}