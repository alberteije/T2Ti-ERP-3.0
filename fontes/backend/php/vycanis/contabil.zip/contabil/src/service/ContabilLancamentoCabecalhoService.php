<?php
use Illuminate\Database\Capsule\Manager as DB;
class ContabilLancamentoCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return ContabilLancamentoCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ContabilLancamentoCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return ContabilLancamentoCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// contabilLancamentoDetalhe
		$contabilLancamentoDetalheModelListJson = $objJson->contabilLancamentoDetalheModelList;
		if ($contabilLancamentoDetalheModelListJson != null) {
			for ($i = 0; $i < count($contabilLancamentoDetalheModelListJson); $i++) {
				$contabilLancamentoDetalhe = new ContabilLancamentoDetalheModel();
				$contabilLancamentoDetalhe->mapping($contabilLancamentoDetalheModelListJson[$i]);
				$objModel->contabilLancamentoDetalheModelList()->save($contabilLancamentoDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		ContabilLancamentoDetalheModel::where('id_contabil_lancamento_cab', $object->getIdAttribute())->delete();
	}	
 
}