<?php
class PlanoContaRefSpedService extends ServiceBase
{
  public function getList()
  {
    return PlanoContaRefSpedModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return PlanoContaRefSpedModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return PlanoContaRefSpedModel::find($id);
  }

}