<?php
class EncerraCentroResultadoService extends ServiceBase
{
  public function getList()
  {
    return EncerraCentroResultadoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return EncerraCentroResultadoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return EncerraCentroResultadoModel::find($id);
  }

}