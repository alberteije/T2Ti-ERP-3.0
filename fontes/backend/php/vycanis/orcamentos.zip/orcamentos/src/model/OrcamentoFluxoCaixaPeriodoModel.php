<?php
declare(strict_types=1);

class OrcamentoFluxoCaixaPeriodoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'orcamento_fluxo_caixa_periodo';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'bancoContaCaixaModel',
	];

	/**
		* Relations
		*/
	public function bancoContaCaixaModel()
	{
		return $this->belongsTo(BancoContaCaixaModel::class, 'id_banco_conta_caixa', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getPeriodoAttribute()
	{
		return $this->attributes['periodo'];
	}

	public function setPeriodoAttribute($periodo)
	{
		$this->attributes['periodo'] = $periodo;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setPeriodoAttribute($object->periodo);
				$this->setNomeAttribute($object->nome);

				// link objects - lookups
				$bancoContaCaixaModel = new BancoContaCaixaModel();
				$bancoContaCaixaModel->mapping($object->bancoContaCaixaModel);
				$this->bancoContaCaixaModel()->associate($bancoContaCaixaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'periodo' => $this->getPeriodoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'bancoContaCaixaModel' => $this->bancoContaCaixaModel,
			];
	}
}