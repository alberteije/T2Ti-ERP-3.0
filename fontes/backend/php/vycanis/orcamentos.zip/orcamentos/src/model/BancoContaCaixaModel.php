<?php
declare(strict_types=1);

class BancoContaCaixaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'banco_conta_caixa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNumeroAttribute()
	{
		return $this->attributes['numero'];
	}

	public function setNumeroAttribute($numero)
	{
		$this->attributes['numero'] = $numero;
	}

	public function getDigitoAttribute()
	{
		return $this->attributes['digito'];
	}

	public function setDigitoAttribute($digito)
	{
		$this->attributes['digito'] = $digito;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getTipoAttribute()
	{
		return $this->attributes['tipo'];
	}

	public function setTipoAttribute($tipo)
	{
		$this->attributes['tipo'] = $tipo;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNumeroAttribute($object->numero);
				$this->setDigitoAttribute($object->digito);
				$this->setNomeAttribute($object->nome);
				$this->setTipoAttribute($object->tipo);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'numero' => $this->getNumeroAttribute(),
				'digito' => $this->getDigitoAttribute(),
				'nome' => $this->getNomeAttribute(),
				'tipo' => $this->getTipoAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
			];
	}
}