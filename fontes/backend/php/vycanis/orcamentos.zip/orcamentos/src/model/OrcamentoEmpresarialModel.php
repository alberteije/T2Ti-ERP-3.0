<?php
declare(strict_types=1);

class OrcamentoEmpresarialModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'orcamento_empresarial';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'orcamentoDetalheModelList',
		'orcamentoPeriodoModel',
	];

	/**
		* Relations
		*/
	public function orcamentoDetalheModelList()
{
	return $this->hasMany(OrcamentoDetalheModel::class, 'id_orcamento_empresarial', 'id');
}

	public function orcamentoPeriodoModel()
	{
		return $this->belongsTo(OrcamentoPeriodoModel::class, 'id_orcamento_periodo', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getDataInicialAttribute()
	{
		return $this->attributes['data_inicial'];
	}

	public function setDataInicialAttribute($dataInicial)
	{
		$this->attributes['data_inicial'] = $dataInicial;
	}

	public function getNumeroPeriodosAttribute()
	{
		return $this->attributes['numero_periodos'];
	}

	public function setNumeroPeriodosAttribute($numeroPeriodos)
	{
		$this->attributes['numero_periodos'] = $numeroPeriodos;
	}

	public function getDataBaseAttribute()
	{
		return $this->attributes['data_base'];
	}

	public function setDataBaseAttribute($dataBase)
	{
		$this->attributes['data_base'] = $dataBase;
	}

	public function getDescricaoAttribute()
	{
		return $this->attributes['descricao'];
	}

	public function setDescricaoAttribute($descricao)
	{
		$this->attributes['descricao'] = $descricao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setDataInicialAttribute($object->dataInicial);
				$this->setNumeroPeriodosAttribute($object->numeroPeriodos);
				$this->setDataBaseAttribute($object->dataBase);
				$this->setDescricaoAttribute($object->descricao);

				// link objects - lookups
				$orcamentoPeriodoModel = new OrcamentoPeriodoModel();
				$orcamentoPeriodoModel->mapping($object->orcamentoPeriodoModel);
				$this->orcamentoPeriodoModel()->associate($orcamentoPeriodoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'dataInicial' => $this->getDataInicialAttribute(),
				'numeroPeriodos' => $this->getNumeroPeriodosAttribute(),
				'dataBase' => $this->getDataBaseAttribute(),
				'descricao' => $this->getDescricaoAttribute(),
				'orcamentoDetalheModelList' => $this->orcamentoDetalheModelList,
				'orcamentoPeriodoModel' => $this->orcamentoPeriodoModel,
			];
	}
}