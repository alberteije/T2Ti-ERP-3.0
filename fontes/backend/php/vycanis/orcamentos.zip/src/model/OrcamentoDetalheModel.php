<?php
declare(strict_types=1);

class OrcamentoDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'orcamento_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'finNaturezaFinanceiraModel',
	];

	/**
		* Relations
		*/
	public function orcamentoEmpresarialModel()
	{
		return $this->belongsTo(OrcamentoEmpresarialModel::class, 'id_orcamento_empresarial', 'id');
	}

	public function finNaturezaFinanceiraModel()
	{
		return $this->belongsTo(FinNaturezaFinanceiraModel::class, 'id_fin_natureza_financeira', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getPeriodoAttribute()
	{
		return $this->attributes['periodo'];
	}

	public function setPeriodoAttribute($periodo)
	{
		$this->attributes['periodo'] = $periodo;
	}

	public function getValorOrcadoAttribute()
	{
		return (double)$this->attributes['valor_orcado'];
	}

	public function setValorOrcadoAttribute($valorOrcado)
	{
		$this->attributes['valor_orcado'] = $valorOrcado;
	}

	public function getValorRealizadoAttribute()
	{
		return (double)$this->attributes['valor_realizado'];
	}

	public function setValorRealizadoAttribute($valorRealizado)
	{
		$this->attributes['valor_realizado'] = $valorRealizado;
	}

	public function getTaxaVariacaoAttribute()
	{
		return (double)$this->attributes['taxa_variacao'];
	}

	public function setTaxaVariacaoAttribute($taxaVariacao)
	{
		$this->attributes['taxa_variacao'] = $taxaVariacao;
	}

	public function getValorVariacaoAttribute()
	{
		return (double)$this->attributes['valor_variacao'];
	}

	public function setValorVariacaoAttribute($valorVariacao)
	{
		$this->attributes['valor_variacao'] = $valorVariacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setPeriodoAttribute($object->periodo);
				$this->setValorOrcadoAttribute($object->valorOrcado);
				$this->setValorRealizadoAttribute($object->valorRealizado);
				$this->setTaxaVariacaoAttribute($object->taxaVariacao);
				$this->setValorVariacaoAttribute($object->valorVariacao);

				// link objects - lookups
				$finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel();
				$finNaturezaFinanceiraModel->mapping($object->finNaturezaFinanceiraModel);
				$this->finNaturezaFinanceiraModel()->associate($finNaturezaFinanceiraModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'periodo' => $this->getPeriodoAttribute(),
				'valorOrcado' => $this->getValorOrcadoAttribute(),
				'valorRealizado' => $this->getValorRealizadoAttribute(),
				'taxaVariacao' => $this->getTaxaVariacaoAttribute(),
				'valorVariacao' => $this->getValorVariacaoAttribute(),
				'finNaturezaFinanceiraModel' => $this->finNaturezaFinanceiraModel,
			];
	}
}