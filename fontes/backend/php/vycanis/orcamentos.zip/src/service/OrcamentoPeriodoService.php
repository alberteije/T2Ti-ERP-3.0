<?php
class OrcamentoPeriodoService extends ServiceBase
{
  public function getList()
  {
    return OrcamentoPeriodoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return OrcamentoPeriodoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return OrcamentoPeriodoModel::find($id);
  }

}