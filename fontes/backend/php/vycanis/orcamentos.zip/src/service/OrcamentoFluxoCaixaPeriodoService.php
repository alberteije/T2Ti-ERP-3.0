<?php
class OrcamentoFluxoCaixaPeriodoService extends ServiceBase
{
  public function getList()
  {
    return OrcamentoFluxoCaixaPeriodoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return OrcamentoFluxoCaixaPeriodoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return OrcamentoFluxoCaixaPeriodoModel::find($id);
  }

}