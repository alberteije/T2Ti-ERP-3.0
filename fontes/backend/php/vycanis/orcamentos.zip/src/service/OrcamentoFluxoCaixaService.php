<?php
use Illuminate\Database\Capsule\Manager as DB;
class OrcamentoFluxoCaixaService extends ServiceBase
{
	public function getList()
	{
		return OrcamentoFluxoCaixaModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return OrcamentoFluxoCaixaModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return OrcamentoFluxoCaixaModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// orcamentoFluxoCaixaDetalhe
		$orcamentoFluxoCaixaDetalheModelListJson = $objJson->orcamentoFluxoCaixaDetalheModelList;
		if ($orcamentoFluxoCaixaDetalheModelListJson != null) {
			for ($i = 0; $i < count($orcamentoFluxoCaixaDetalheModelListJson); $i++) {
				$orcamentoFluxoCaixaDetalhe = new OrcamentoFluxoCaixaDetalheModel();
				$orcamentoFluxoCaixaDetalhe->mapping($orcamentoFluxoCaixaDetalheModelListJson[$i]);
				$objModel->orcamentoFluxoCaixaDetalheModelList()->save($orcamentoFluxoCaixaDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		OrcamentoFluxoCaixaDetalheModel::where('id_orcamento_fluxo_caixa', $object->getIdAttribute())->delete();
	}	
 
}