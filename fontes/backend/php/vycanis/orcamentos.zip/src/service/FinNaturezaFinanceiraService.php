<?php
class FinNaturezaFinanceiraService extends ServiceBase
{
  public function getList()
  {
    return FinNaturezaFinanceiraModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return FinNaturezaFinanceiraModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return FinNaturezaFinanceiraModel::find($id);
  }

}