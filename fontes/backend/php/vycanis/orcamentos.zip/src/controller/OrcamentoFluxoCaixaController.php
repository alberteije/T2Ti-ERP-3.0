<?php
class OrcamentoFluxoCaixaController extends ControllerBase
{

		private $orcamentoFluxoCaixaService = null;

		public function __construct()
		{	 
				$this->orcamentoFluxoCaixaService = new OrcamentoFluxoCaixaService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->orcamentoFluxoCaixaService->getListFilter($filter);
						} else {
								$resultList = $this->orcamentoFluxoCaixaService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList OrcamentoFluxoCaixa]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->orcamentoFluxoCaixaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject OrcamentoFluxoCaixa]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject OrcamentoFluxoCaixa]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert OrcamentoFluxoCaixa]', null);
						}

						$objModel = new OrcamentoFluxoCaixaModel();
						$objModel->mapping($objJson);

						$this->orcamentoFluxoCaixaService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert OrcamentoFluxoCaixa]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->orcamentoFluxoCaixaService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update OrcamentoFluxoCaixa]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->orcamentoFluxoCaixaService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->orcamentoFluxoCaixaService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update OrcamentoFluxoCaixa]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->orcamentoFluxoCaixaService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete OrcamentoFluxoCaixa]', null);
						} else {
								$this->orcamentoFluxoCaixaService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete OrcamentoFluxoCaixa]', $e);
				}
		}
}
