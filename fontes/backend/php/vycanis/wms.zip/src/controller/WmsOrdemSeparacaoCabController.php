<?php
class WmsOrdemSeparacaoCabController extends ControllerBase
{

		private $wmsOrdemSeparacaoCabService = null;

		public function __construct()
		{	 
				$this->wmsOrdemSeparacaoCabService = new WmsOrdemSeparacaoCabService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->wmsOrdemSeparacaoCabService->getListFilter($filter);
						} else {
								$resultList = $this->wmsOrdemSeparacaoCabService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList WmsOrdemSeparacaoCab]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->wmsOrdemSeparacaoCabService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject WmsOrdemSeparacaoCab]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject WmsOrdemSeparacaoCab]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert WmsOrdemSeparacaoCab]', null);
						}

						$objModel = new WmsOrdemSeparacaoCabModel();
						$objModel->mapping($objJson);

						$this->wmsOrdemSeparacaoCabService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert WmsOrdemSeparacaoCab]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->wmsOrdemSeparacaoCabService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update WmsOrdemSeparacaoCab]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->wmsOrdemSeparacaoCabService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->wmsOrdemSeparacaoCabService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update WmsOrdemSeparacaoCab]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->wmsOrdemSeparacaoCabService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete WmsOrdemSeparacaoCab]', null);
						} else {
								$this->wmsOrdemSeparacaoCabService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete WmsOrdemSeparacaoCab]', $e);
				}
		}
}
