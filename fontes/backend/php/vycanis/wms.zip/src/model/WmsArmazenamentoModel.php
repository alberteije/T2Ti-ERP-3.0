<?php
declare(strict_types=1);

class WmsArmazenamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_armazenamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'wmsCaixaModel',
		'wmsRecebimentoCabecalhoModel',
		'produtoModel',
	];

	/**
		* Relations
		*/
	public function wmsCaixaModel()
	{
		return $this->belongsTo(WmsCaixaModel::class, 'id_wms_caixa', 'id');
	}

	public function wmsRecebimentoCabecalhoModel()
	{
		return $this->belongsTo(WmsRecebimentoCabecalhoModel::class, 'id_wms_recebimento_cabecalho', 'id');
	}

	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getDataArmazenagemAttribute()
	{
		return $this->attributes['data_armazenagem'];
	}

	public function setDataArmazenagemAttribute($dataArmazenagem)
	{
		$this->attributes['data_armazenagem'] = $dataArmazenagem;
	}

	public function getHoraArmazenagemAttribute()
	{
		return $this->attributes['hora_armazenagem'];
	}

	public function setHoraArmazenagemAttribute($horaArmazenagem)
	{
		$this->attributes['hora_armazenagem'] = $horaArmazenagem;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);
				$this->setDataArmazenagemAttribute($object->dataArmazenagem);
				$this->setHoraArmazenagemAttribute($object->horaArmazenagem);

				// link objects - lookups
				$wmsCaixaModel = new WmsCaixaModel();
				$wmsCaixaModel->mapping($object->wmsCaixaModel);
				$this->wmsCaixaModel()->associate($wmsCaixaModel);
				$wmsRecebimentoCabecalhoModel = new WmsRecebimentoCabecalhoModel();
				$wmsRecebimentoCabecalhoModel->mapping($object->wmsRecebimentoCabecalhoModel);
				$this->wmsRecebimentoCabecalhoModel()->associate($wmsRecebimentoCabecalhoModel);
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'dataArmazenagem' => $this->getDataArmazenagemAttribute(),
				'horaArmazenagem' => $this->getHoraArmazenagemAttribute(),
				'wmsCaixaModel' => $this->wmsCaixaModel,
				'wmsRecebimentoCabecalhoModel' => $this->wmsRecebimentoCabecalhoModel,
				'produtoModel' => $this->produtoModel,
			];
	}
}