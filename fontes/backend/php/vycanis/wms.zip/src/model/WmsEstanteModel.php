<?php
declare(strict_types=1);

class WmsEstanteModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_estante';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'wmsRuaModel',
	];

	/**
		* Relations
		*/
	public function wmsRuaModel()
	{
		return $this->belongsTo(WmsRuaModel::class, 'id_wms_rua', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getQuantidadeCaixaAttribute()
	{
		return $this->attributes['quantidade_caixa'];
	}

	public function setQuantidadeCaixaAttribute($quantidadeCaixa)
	{
		$this->attributes['quantidade_caixa'] = $quantidadeCaixa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setQuantidadeCaixaAttribute($object->quantidadeCaixa);

				// link objects - lookups
				$wmsRuaModel = new WmsRuaModel();
				$wmsRuaModel->mapping($object->wmsRuaModel);
				$this->wmsRuaModel()->associate($wmsRuaModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'quantidadeCaixa' => $this->getQuantidadeCaixaAttribute(),
				'wmsRuaModel' => $this->wmsRuaModel,
			];
	}
}