<?php
declare(strict_types=1);

class WmsExpedicaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_expedicao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'wmsOrdemSeparacaoDetModel',
		'wmsArmazenamentoModel',
	];

	/**
		* Relations
		*/
	public function wmsOrdemSeparacaoDetModel()
	{
		return $this->belongsTo(WmsOrdemSeparacaoDetModel::class, 'id_wms_ordem_separacao_det', 'id');
	}

	public function wmsArmazenamentoModel()
	{
		return $this->belongsTo(WmsArmazenamentoModel::class, 'id_wms_armazenamento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getDataSaidaAttribute()
	{
		return $this->attributes['data_saida'];
	}

	public function setDataSaidaAttribute($dataSaida)
	{
		$this->attributes['data_saida'] = $dataSaida;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);
				$this->setDataSaidaAttribute($object->dataSaida);

				// link objects - lookups
				$wmsOrdemSeparacaoDetModel = new WmsOrdemSeparacaoDetModel();
				$wmsOrdemSeparacaoDetModel->mapping($object->wmsOrdemSeparacaoDetModel);
				$this->wmsOrdemSeparacaoDetModel()->associate($wmsOrdemSeparacaoDetModel);
				$wmsArmazenamentoModel = new WmsArmazenamentoModel();
				$wmsArmazenamentoModel->mapping($object->wmsArmazenamentoModel);
				$this->wmsArmazenamentoModel()->associate($wmsArmazenamentoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'dataSaida' => $this->getDataSaidaAttribute(),
				'wmsOrdemSeparacaoDetModel' => $this->wmsOrdemSeparacaoDetModel,
				'wmsArmazenamentoModel' => $this->wmsArmazenamentoModel,
			];
	}
}