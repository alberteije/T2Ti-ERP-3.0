<?php
declare(strict_types=1);

class WmsExpedicaoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_expedicao';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'produtoModel',
	];

	/**
		* Relations
		*/
	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	public function getDataSaidaAttribute()
	{
		return $this->attributes['data_saida'];
	}

	public function setDataSaidaAttribute($dataSaida)
	{
		$this->attributes['data_saida'] = $dataSaida;
	}

	public function getHoraSaidaAttribute()
	{
		return $this->attributes['hora_saida'];
	}

	public function setHoraSaidaAttribute($horaSaida)
	{
		$this->attributes['hora_saida'] = $horaSaida;
	}

	public function getVeioDeOndeAttribute()
	{
		return $this->attributes['veio_de_onde'];
	}

	public function setVeioDeOndeAttribute($veioDeOnde)
	{
		$this->attributes['veio_de_onde'] = $veioDeOnde;
	}

	public function getCodigoSeparacaoRecebimentoAttribute()
	{
		return $this->attributes['codigo_separacao_recebimento'];
	}

	public function setCodigoSeparacaoRecebimentoAttribute($codigoSeparacaoRecebimento)
	{
		$this->attributes['codigo_separacao_recebimento'] = $codigoSeparacaoRecebimento;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);
				$this->setDataSaidaAttribute($object->dataSaida);
				$this->setHoraSaidaAttribute($object->horaSaida);
				$this->setVeioDeOndeAttribute($object->veioDeOnde);
				$this->setCodigoSeparacaoRecebimentoAttribute($object->codigoSeparacaoRecebimento);

				// link objects - lookups
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'dataSaida' => $this->getDataSaidaAttribute(),
				'horaSaida' => $this->getHoraSaidaAttribute(),
				'veioDeOnde' => $this->getVeioDeOndeAttribute(),
				'codigoSeparacaoRecebimento' => $this->getCodigoSeparacaoRecebimentoAttribute(),
				'produtoModel' => $this->produtoModel,
			];
	}
}