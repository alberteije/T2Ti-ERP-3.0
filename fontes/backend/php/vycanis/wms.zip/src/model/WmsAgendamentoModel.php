<?php
declare(strict_types=1);

class WmsAgendamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_agendamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataOperacaoAttribute()
	{
		return $this->attributes['data_operacao'];
	}

	public function setDataOperacaoAttribute($dataOperacao)
	{
		$this->attributes['data_operacao'] = $dataOperacao;
	}

	public function getHoraOperacaoAttribute()
	{
		return $this->attributes['hora_operacao'];
	}

	public function setHoraOperacaoAttribute($horaOperacao)
	{
		$this->attributes['hora_operacao'] = $horaOperacao;
	}

	public function getLocalOperacaoAttribute()
	{
		return $this->attributes['local_operacao'];
	}

	public function setLocalOperacaoAttribute($localOperacao)
	{
		$this->attributes['local_operacao'] = $localOperacao;
	}

	public function getQuantidadeVolumeAttribute()
	{
		return $this->attributes['quantidade_volume'];
	}

	public function setQuantidadeVolumeAttribute($quantidadeVolume)
	{
		$this->attributes['quantidade_volume'] = $quantidadeVolume;
	}

	public function getPesoTotalVolumeAttribute()
	{
		return (double)$this->attributes['peso_total_volume'];
	}

	public function setPesoTotalVolumeAttribute($pesoTotalVolume)
	{
		$this->attributes['peso_total_volume'] = $pesoTotalVolume;
	}

	public function getQuantidadePessoaAttribute()
	{
		return $this->attributes['quantidade_pessoa'];
	}

	public function setQuantidadePessoaAttribute($quantidadePessoa)
	{
		$this->attributes['quantidade_pessoa'] = $quantidadePessoa;
	}

	public function getQuantidadeHoraAttribute()
	{
		return $this->attributes['quantidade_hora'];
	}

	public function setQuantidadeHoraAttribute($quantidadeHora)
	{
		$this->attributes['quantidade_hora'] = $quantidadeHora;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataOperacaoAttribute($object->dataOperacao);
				$this->setHoraOperacaoAttribute($object->horaOperacao);
				$this->setLocalOperacaoAttribute($object->localOperacao);
				$this->setQuantidadeVolumeAttribute($object->quantidadeVolume);
				$this->setPesoTotalVolumeAttribute($object->pesoTotalVolume);
				$this->setQuantidadePessoaAttribute($object->quantidadePessoa);
				$this->setQuantidadeHoraAttribute($object->quantidadeHora);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataOperacao' => $this->getDataOperacaoAttribute(),
				'horaOperacao' => $this->getHoraOperacaoAttribute(),
				'localOperacao' => $this->getLocalOperacaoAttribute(),
				'quantidadeVolume' => $this->getQuantidadeVolumeAttribute(),
				'pesoTotalVolume' => $this->getPesoTotalVolumeAttribute(),
				'quantidadePessoa' => $this->getQuantidadePessoaAttribute(),
				'quantidadeHora' => $this->getQuantidadeHoraAttribute(),
			];
	}
}