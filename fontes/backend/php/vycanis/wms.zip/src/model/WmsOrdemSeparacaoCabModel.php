<?php
declare(strict_types=1);

class WmsOrdemSeparacaoCabModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_ordem_separacao_cab';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'wmsOrdemSeparacaoDetModelList',
	];

	/**
		* Relations
		*/
	public function wmsOrdemSeparacaoDetModelList()
{
	return $this->hasMany(WmsOrdemSeparacaoDetModel::class, 'id_wms_ordem_separacao_cab', 'id');
}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getOrigemAttribute()
	{
		return $this->attributes['origem'];
	}

	public function setOrigemAttribute($origem)
	{
		$this->attributes['origem'] = $origem;
	}

	public function getDataSolicitacaoAttribute()
	{
		return $this->attributes['data_solicitacao'];
	}

	public function setDataSolicitacaoAttribute($dataSolicitacao)
	{
		$this->attributes['data_solicitacao'] = $dataSolicitacao;
	}

	public function getDataLimiteAttribute()
	{
		return $this->attributes['data_limite'];
	}

	public function setDataLimiteAttribute($dataLimite)
	{
		$this->attributes['data_limite'] = $dataLimite;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setOrigemAttribute($object->origem);
				$this->setDataSolicitacaoAttribute($object->dataSolicitacao);
				$this->setDataLimiteAttribute($object->dataLimite);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'origem' => $this->getOrigemAttribute(),
				'dataSolicitacao' => $this->getDataSolicitacaoAttribute(),
				'dataLimite' => $this->getDataLimiteAttribute(),
				'wmsOrdemSeparacaoDetModelList' => $this->wmsOrdemSeparacaoDetModelList,
			];
	}
}