<?php
declare(strict_types=1);

class WmsCaixaModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_caixa';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'wmsArmazenamentoModelList',
		'wmsEstanteModel',
	];

	/**
		* Relations
		*/
	public function wmsArmazenamentoModelList()
{
	return $this->hasMany(WmsArmazenamentoModel::class, 'id_wms_caixa', 'id');
}

	public function wmsEstanteModel()
	{
		return $this->belongsTo(WmsEstanteModel::class, 'id_wms_estante', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getAlturaAttribute()
	{
		return $this->attributes['altura'];
	}

	public function setAlturaAttribute($altura)
	{
		$this->attributes['altura'] = $altura;
	}

	public function getLarguraAttribute()
	{
		return $this->attributes['largura'];
	}

	public function setLarguraAttribute($largura)
	{
		$this->attributes['largura'] = $largura;
	}

	public function getProfundidadeAttribute()
	{
		return $this->attributes['profundidade'];
	}

	public function setProfundidadeAttribute($profundidade)
	{
		$this->attributes['profundidade'] = $profundidade;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setCodigoAttribute($object->codigo);
				$this->setAlturaAttribute($object->altura);
				$this->setLarguraAttribute($object->largura);
				$this->setProfundidadeAttribute($object->profundidade);

				// link objects - lookups
				$wmsEstanteModel = new WmsEstanteModel();
				$wmsEstanteModel->mapping($object->wmsEstanteModel);
				$this->wmsEstanteModel()->associate($wmsEstanteModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'altura' => $this->getAlturaAttribute(),
				'largura' => $this->getLarguraAttribute(),
				'profundidade' => $this->getProfundidadeAttribute(),
				'wmsArmazenamentoModelList' => $this->wmsArmazenamentoModelList,
				'wmsEstanteModel' => $this->wmsEstanteModel,
			];
	}
}