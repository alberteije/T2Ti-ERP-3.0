<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'WmsRecebimentoDetalheModel.php';
include 'WmsCaixaModel.php';
include 'WmsOrdemSeparacaoDetModel.php';
include 'WmsRecebimentoCabecalhoModel.php';
include 'WmsEstanteModel.php';
include 'WmsOrdemSeparacaoCabModel.php';
include 'ProdutoModel.php';
include 'WmsAgendamentoModel.php';
include 'WmsParametroModel.php';
include 'WmsRuaModel.php';
include 'WmsArmazenamentoModel.php';
include 'WmsExpedicaoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';
include 'UsuarioTokenModel.php';
include 'AuditoriaModel.php';