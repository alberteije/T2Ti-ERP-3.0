<?php

include 'EloquentModel.php';
// Transientes
include 'transient/Filter.php';
include 'transient/ResultJsonError.php';

include 'WmsRecebimentoDetalheModel.php';
include 'WmsArmazenamentoModel.php';
include 'WmsOrdemSeparacaoDetModel.php';
include 'WmsRecebimentoCabecalhoModel.php';
include 'WmsCaixaModel.php';
include 'WmsOrdemSeparacaoCabModel.php';
include 'ProdutoModel.php';
include 'WmsAgendamentoModel.php';
include 'WmsParametroModel.php';
include 'WmsRuaModel.php';
include 'WmsEstanteModel.php';
include 'WmsExpedicaoModel.php';
include 'ViewControleAcessoModel.php';
include 'ViewPessoaUsuarioModel.php';