<?php
use Illuminate\Database\Capsule\Manager as DB;
class WmsRecebimentoCabecalhoService extends ServiceBase
{
	public function getList()
	{
		return WmsRecebimentoCabecalhoModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return WmsRecebimentoCabecalhoModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return WmsRecebimentoCabecalhoModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// wmsRecebimentoDetalhe
		$wmsRecebimentoDetalheModelListJson = $objJson->wmsRecebimentoDetalheModelList;
		if ($wmsRecebimentoDetalheModelListJson != null) {
			for ($i = 0; $i < count($wmsRecebimentoDetalheModelListJson); $i++) {
				$wmsRecebimentoDetalhe = new WmsRecebimentoDetalheModel();
				$wmsRecebimentoDetalhe->mapping($wmsRecebimentoDetalheModelListJson[$i]);
				$objModel->wmsRecebimentoDetalheModelList()->save($wmsRecebimentoDetalhe);
			}
		}

	}	

	public function deleteChildren($object)
	{
		WmsRecebimentoDetalheModel::where('id_wms_recebimento_cabecalho', $object->getIdAttribute())->delete();
	}	
 
}