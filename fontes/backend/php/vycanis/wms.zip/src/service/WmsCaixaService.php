<?php
class WmsCaixaService extends ServiceBase
{
  public function getList()
  {
    return WmsCaixaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return WmsCaixaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return WmsCaixaModel::find($id);
  }

}