<?php

include 'ServiceBase.php';

include 'WmsCaixaService.php';
include 'WmsRecebimentoCabecalhoService.php';
include 'WmsEstanteService.php';
include 'WmsOrdemSeparacaoCabService.php';
include 'ProdutoService.php';
include 'WmsAgendamentoService.php';
include 'WmsParametroService.php';
include 'WmsRuaService.php';
include 'WmsArmazenamentoService.php';
include 'WmsExpedicaoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';