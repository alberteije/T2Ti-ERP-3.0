<?php
class WmsParametroService extends ServiceBase
{
  public function getList()
  {
    return WmsParametroModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return WmsParametroModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return WmsParametroModel::find($id);
  }

}