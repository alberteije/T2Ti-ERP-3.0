<?php
class WmsExpedicaoService extends ServiceBase
{
  public function getList()
  {
    return WmsExpedicaoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return WmsExpedicaoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return WmsExpedicaoModel::find($id);
  }

}