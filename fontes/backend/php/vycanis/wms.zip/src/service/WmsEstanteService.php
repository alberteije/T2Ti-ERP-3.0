<?php
use Illuminate\Database\Capsule\Manager as DB;
class WmsEstanteService extends ServiceBase
{
	public function getList()
	{
		return WmsEstanteModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return WmsEstanteModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return WmsEstanteModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// wmsCaixa
		$wmsCaixaModelListJson = $objJson->wmsCaixaModelList;
		if ($wmsCaixaModelListJson != null) {
			for ($i = 0; $i < count($wmsCaixaModelListJson); $i++) {
				$wmsCaixa = new WmsCaixaModel();
				$wmsCaixa->mapping($wmsCaixaModelListJson[$i]);
				$objModel->wmsCaixaModelList()->save($wmsCaixa);
			}
		}

	}	

	public function deleteChildren($object)
	{
		WmsCaixaModel::where('id_wms_estante', $object->getIdAttribute())->delete();
	}	
 
}