<?php
class WmsArmazenamentoService extends ServiceBase
{
  public function getList()
  {
    return WmsArmazenamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return WmsArmazenamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return WmsArmazenamentoModel::find($id);
  }

}