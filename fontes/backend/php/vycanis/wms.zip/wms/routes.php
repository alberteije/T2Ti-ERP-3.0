<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// wms-recebimento-cabecalho
$app->get('/wms-recebimento-cabecalho[/]', \WmsRecebimentoCabecalhoController::class . RESULT_LIST);
$app->get('/wms-recebimento-cabecalho/{id}', \WmsRecebimentoCabecalhoController::class . RESULT_OBJECT);
$app->post('/wms-recebimento-cabecalho', \WmsRecebimentoCabecalhoController::class . INSERT);
$app->put('/wms-recebimento-cabecalho', \WmsRecebimentoCabecalhoController::class . UPDATE);
$app->delete('/wms-recebimento-cabecalho/{id}', \WmsRecebimentoCabecalhoController::class . DELETE);
$app->options('/wms-recebimento-cabecalho', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-recebimento-cabecalho/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-recebimento-cabecalho/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// wms-caixa
$app->get('/wms-caixa[/]', \WmsCaixaController::class . RESULT_LIST);
$app->get('/wms-caixa/{id}', \WmsCaixaController::class . RESULT_OBJECT);
$app->post('/wms-caixa', \WmsCaixaController::class . INSERT);
$app->put('/wms-caixa', \WmsCaixaController::class . UPDATE);
$app->delete('/wms-caixa/{id}', \WmsCaixaController::class . DELETE);
$app->options('/wms-caixa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-caixa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-caixa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// wms-ordem-separacao-cab
$app->get('/wms-ordem-separacao-cab[/]', \WmsOrdemSeparacaoCabController::class . RESULT_LIST);
$app->get('/wms-ordem-separacao-cab/{id}', \WmsOrdemSeparacaoCabController::class . RESULT_OBJECT);
$app->post('/wms-ordem-separacao-cab', \WmsOrdemSeparacaoCabController::class . INSERT);
$app->put('/wms-ordem-separacao-cab', \WmsOrdemSeparacaoCabController::class . UPDATE);
$app->delete('/wms-ordem-separacao-cab/{id}', \WmsOrdemSeparacaoCabController::class . DELETE);
$app->options('/wms-ordem-separacao-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-ordem-separacao-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-ordem-separacao-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto
$app->get('/produto[/]', \ProdutoController::class . RESULT_LIST);
$app->get('/produto/{id}', \ProdutoController::class . RESULT_OBJECT);
$app->post('/produto', \ProdutoController::class . INSERT);
$app->put('/produto', \ProdutoController::class . UPDATE);
$app->delete('/produto/{id}', \ProdutoController::class . DELETE);
$app->options('/produto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// wms-agendamento
$app->get('/wms-agendamento[/]', \WmsAgendamentoController::class . RESULT_LIST);
$app->get('/wms-agendamento/{id}', \WmsAgendamentoController::class . RESULT_OBJECT);
$app->post('/wms-agendamento', \WmsAgendamentoController::class . INSERT);
$app->put('/wms-agendamento', \WmsAgendamentoController::class . UPDATE);
$app->delete('/wms-agendamento/{id}', \WmsAgendamentoController::class . DELETE);
$app->options('/wms-agendamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-agendamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-agendamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// wms-parametro
$app->get('/wms-parametro[/]', \WmsParametroController::class . RESULT_LIST);
$app->get('/wms-parametro/{id}', \WmsParametroController::class . RESULT_OBJECT);
$app->post('/wms-parametro', \WmsParametroController::class . INSERT);
$app->put('/wms-parametro', \WmsParametroController::class . UPDATE);
$app->delete('/wms-parametro/{id}', \WmsParametroController::class . DELETE);
$app->options('/wms-parametro', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-parametro/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-parametro/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// wms-rua
$app->get('/wms-rua[/]', \WmsRuaController::class . RESULT_LIST);
$app->get('/wms-rua/{id}', \WmsRuaController::class . RESULT_OBJECT);
$app->post('/wms-rua', \WmsRuaController::class . INSERT);
$app->put('/wms-rua', \WmsRuaController::class . UPDATE);
$app->delete('/wms-rua/{id}', \WmsRuaController::class . DELETE);
$app->options('/wms-rua', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-rua/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-rua/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// wms-estante
$app->get('/wms-estante[/]', \WmsEstanteController::class . RESULT_LIST);
$app->get('/wms-estante/{id}', \WmsEstanteController::class . RESULT_OBJECT);
$app->post('/wms-estante', \WmsEstanteController::class . INSERT);
$app->put('/wms-estante', \WmsEstanteController::class . UPDATE);
$app->delete('/wms-estante/{id}', \WmsEstanteController::class . DELETE);
$app->options('/wms-estante', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-estante/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-estante/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// wms-expedicao
$app->get('/wms-expedicao[/]', \WmsExpedicaoController::class . RESULT_LIST);
$app->get('/wms-expedicao/{id}', \WmsExpedicaoController::class . RESULT_OBJECT);
$app->post('/wms-expedicao', \WmsExpedicaoController::class . INSERT);
$app->put('/wms-expedicao', \WmsExpedicaoController::class . UPDATE);
$app->delete('/wms-expedicao/{id}', \WmsExpedicaoController::class . DELETE);
$app->options('/wms-expedicao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-expedicao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/wms-expedicao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST);
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT);
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT);
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE);
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE);
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST);
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT);
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT);
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE);
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE);
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

