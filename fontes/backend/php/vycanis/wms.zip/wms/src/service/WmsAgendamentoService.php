<?php
class WmsAgendamentoService extends ServiceBase
{
  public function getList()
  {
    return WmsAgendamentoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return WmsAgendamentoModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return WmsAgendamentoModel::find($id);
  }

}