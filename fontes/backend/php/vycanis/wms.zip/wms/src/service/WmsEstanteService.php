<?php
class WmsEstanteService extends ServiceBase
{
  public function getList()
  {
    return WmsEstanteModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return WmsEstanteModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return WmsEstanteModel::find($id);
  }

}