<?php
class WmsRuaService extends ServiceBase
{
  public function getList()
  {
    return WmsRuaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return WmsRuaModel::whereRaw($filter->where)->get();
  }

  public function getObject(int $id)
  {
    return WmsRuaModel::find($id);
  }

}