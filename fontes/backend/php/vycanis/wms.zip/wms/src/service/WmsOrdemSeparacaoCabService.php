<?php
use Illuminate\Database\Capsule\Manager as DB;
class WmsOrdemSeparacaoCabService extends ServiceBase
{
	public function getList()
	{
		return WmsOrdemSeparacaoCabModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return WmsOrdemSeparacaoCabModel::whereRaw($filter->where)->get();
	}

	public function getObject(int $id)
	{
		return WmsOrdemSeparacaoCabModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// wmsOrdemSeparacaoDet
		$wmsOrdemSeparacaoDetModelListJson = $objJson->wmsOrdemSeparacaoDetModelList;
		if ($wmsOrdemSeparacaoDetModelListJson != null) {
			for ($i = 0; $i < count($wmsOrdemSeparacaoDetModelListJson); $i++) {
				$wmsOrdemSeparacaoDet = new WmsOrdemSeparacaoDetModel();
				$wmsOrdemSeparacaoDet->mapping($wmsOrdemSeparacaoDetModelListJson[$i]);
				$objModel->wmsOrdemSeparacaoDetModelList()->save($wmsOrdemSeparacaoDet);
			}
		}

	}	

	public function deleteChildren($object)
	{
		WmsOrdemSeparacaoDetModel::where('id_wms_ordem_separacao_cab', $object->getIdAttribute())->delete();
	}	
 
}