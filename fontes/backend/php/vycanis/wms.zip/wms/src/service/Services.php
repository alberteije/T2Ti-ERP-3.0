<?php

include 'ServiceBase.php';

include 'WmsRecebimentoCabecalhoService.php';
include 'WmsCaixaService.php';
include 'WmsOrdemSeparacaoCabService.php';
include 'ProdutoService.php';
include 'WmsAgendamentoService.php';
include 'WmsParametroService.php';
include 'WmsRuaService.php';
include 'WmsEstanteService.php';
include 'WmsExpedicaoService.php';
include 'ViewControleAcessoService.php';
include 'ViewPessoaUsuarioService.php';
include 'UsuarioTokenService.php';
include 'AuditoriaService.php';