<?php
declare(strict_types=1);

class WmsParametroModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_parametro';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getHoraPorVolumeAttribute()
	{
		return $this->attributes['hora_por_volume'];
	}

	public function setHoraPorVolumeAttribute($horaPorVolume)
	{
		$this->attributes['hora_por_volume'] = $horaPorVolume;
	}

	public function getPessoaPorVolumeAttribute()
	{
		return $this->attributes['pessoa_por_volume'];
	}

	public function setPessoaPorVolumeAttribute($pessoaPorVolume)
	{
		$this->attributes['pessoa_por_volume'] = $pessoaPorVolume;
	}

	public function getHoraPorPesoAttribute()
	{
		return $this->attributes['hora_por_peso'];
	}

	public function setHoraPorPesoAttribute($horaPorPeso)
	{
		$this->attributes['hora_por_peso'] = $horaPorPeso;
	}

	public function getPessoaPorPesoAttribute()
	{
		return $this->attributes['pessoa_por_peso'];
	}

	public function setPessoaPorPesoAttribute($pessoaPorPeso)
	{
		$this->attributes['pessoa_por_peso'] = $pessoaPorPeso;
	}

	public function getItemDiferenteCaixaAttribute()
	{
		return $this->attributes['item_diferente_caixa'];
	}

	public function setItemDiferenteCaixaAttribute($itemDiferenteCaixa)
	{
		$this->attributes['item_diferente_caixa'] = $itemDiferenteCaixa;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setHoraPorVolumeAttribute($object->horaPorVolume);
				$this->setPessoaPorVolumeAttribute($object->pessoaPorVolume);
				$this->setHoraPorPesoAttribute($object->horaPorPeso);
				$this->setPessoaPorPesoAttribute($object->pessoaPorPeso);
				$this->setItemDiferenteCaixaAttribute($object->itemDiferenteCaixa);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'horaPorVolume' => $this->getHoraPorVolumeAttribute(),
				'pessoaPorVolume' => $this->getPessoaPorVolumeAttribute(),
				'horaPorPeso' => $this->getHoraPorPesoAttribute(),
				'pessoaPorPeso' => $this->getPessoaPorPesoAttribute(),
				'itemDiferenteCaixa' => $this->getItemDiferenteCaixaAttribute(),
			];
	}
}