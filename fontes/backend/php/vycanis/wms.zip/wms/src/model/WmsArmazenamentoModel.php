<?php
declare(strict_types=1);

class WmsArmazenamentoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_armazenamento';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'wmsRecebimentoDetalheModel',
	];

	/**
		* Relations
		*/
	public function wmsCaixaModel()
	{
		return $this->belongsTo(WmsCaixaModel::class, 'id_wms_caixa', 'id');
	}

	public function wmsRecebimentoDetalheModel()
	{
		return $this->belongsTo(WmsRecebimentoDetalheModel::class, 'id_wms_recebimento_detalhe', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeAttribute()
	{
		return $this->attributes['quantidade'];
	}

	public function setQuantidadeAttribute($quantidade)
	{
		$this->attributes['quantidade'] = $quantidade;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeAttribute($object->quantidade);

				// link objects - lookups
				$wmsRecebimentoDetalheModel = new WmsRecebimentoDetalheModel();
				$wmsRecebimentoDetalheModel->mapping($object->wmsRecebimentoDetalheModel);
				$this->wmsRecebimentoDetalheModel()->associate($wmsRecebimentoDetalheModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidade' => $this->getQuantidadeAttribute(),
				'wmsRecebimentoDetalheModel' => $this->wmsRecebimentoDetalheModel,
			];
	}
}