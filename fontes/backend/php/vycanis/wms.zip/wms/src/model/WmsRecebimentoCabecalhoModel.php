<?php
declare(strict_types=1);

class WmsRecebimentoCabecalhoModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_recebimento_cabecalho';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'wmsRecebimentoDetalheModelList',
		'wmsAgendamentoModel',
	];

	/**
		* Relations
		*/
	public function wmsRecebimentoDetalheModelList()
{
	return $this->hasMany(WmsRecebimentoDetalheModel::class, 'id_wms_recebimento_cabecalho', 'id');
}

	public function wmsAgendamentoModel()
	{
		return $this->belongsTo(WmsAgendamentoModel::class, 'id_wms_agendamento', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getDataRecebimentoAttribute()
	{
		return $this->attributes['data_recebimento'];
	}

	public function setDataRecebimentoAttribute($dataRecebimento)
	{
		$this->attributes['data_recebimento'] = $dataRecebimento;
	}

	public function getHoraInicioAttribute()
	{
		return $this->attributes['hora_inicio'];
	}

	public function setHoraInicioAttribute($horaInicio)
	{
		$this->attributes['hora_inicio'] = $horaInicio;
	}

	public function getHoraFimAttribute()
	{
		return $this->attributes['hora_fim'];
	}

	public function setHoraFimAttribute($horaFim)
	{
		$this->attributes['hora_fim'] = $horaFim;
	}

	public function getVolumeRecebidoAttribute()
	{
		return $this->attributes['volume_recebido'];
	}

	public function setVolumeRecebidoAttribute($volumeRecebido)
	{
		$this->attributes['volume_recebido'] = $volumeRecebido;
	}

	public function getPesoRecebidoAttribute()
	{
		return (double)$this->attributes['peso_recebido'];
	}

	public function setPesoRecebidoAttribute($pesoRecebido)
	{
		$this->attributes['peso_recebido'] = $pesoRecebido;
	}

	public function getInconsistenciaAttribute()
	{
		return $this->attributes['inconsistencia'];
	}

	public function setInconsistenciaAttribute($inconsistencia)
	{
		$this->attributes['inconsistencia'] = $inconsistencia;
	}

	public function getObservacaoAttribute()
	{
		return $this->attributes['observacao'];
	}

	public function setObservacaoAttribute($observacao)
	{
		$this->attributes['observacao'] = $observacao;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setDataRecebimentoAttribute($object->dataRecebimento);
				$this->setHoraInicioAttribute($object->horaInicio);
				$this->setHoraFimAttribute($object->horaFim);
				$this->setVolumeRecebidoAttribute($object->volumeRecebido);
				$this->setPesoRecebidoAttribute($object->pesoRecebido);
				$this->setInconsistenciaAttribute($object->inconsistencia);
				$this->setObservacaoAttribute($object->observacao);

				// link objects - lookups
				$wmsAgendamentoModel = new WmsAgendamentoModel();
				$wmsAgendamentoModel->mapping($object->wmsAgendamentoModel);
				$this->wmsAgendamentoModel()->associate($wmsAgendamentoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'dataRecebimento' => $this->getDataRecebimentoAttribute(),
				'horaInicio' => $this->getHoraInicioAttribute(),
				'horaFim' => $this->getHoraFimAttribute(),
				'volumeRecebido' => $this->getVolumeRecebidoAttribute(),
				'pesoRecebido' => $this->getPesoRecebidoAttribute(),
				'inconsistencia' => $this->getInconsistenciaAttribute(),
				'observacao' => $this->getObservacaoAttribute(),
				'wmsRecebimentoDetalheModelList' => $this->wmsRecebimentoDetalheModelList,
				'wmsAgendamentoModel' => $this->wmsAgendamentoModel,
			];
	}
}