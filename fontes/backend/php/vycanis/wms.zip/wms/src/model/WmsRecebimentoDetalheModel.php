<?php
declare(strict_types=1);

class WmsRecebimentoDetalheModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'wms_recebimento_detalhe';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
		'produtoModel',
	];

	/**
		* Relations
		*/
	public function wmsRecebimentoCabecalhoModel()
	{
		return $this->belongsTo(WmsRecebimentoCabecalhoModel::class, 'id_wms_recebimento_cabecalho', 'id');
	}

	public function produtoModel()
	{
		return $this->belongsTo(ProdutoModel::class, 'id_produto', 'id');
	}



	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getQuantidadeVolumeAttribute()
	{
		return $this->attributes['quantidade_volume'];
	}

	public function setQuantidadeVolumeAttribute($quantidadeVolume)
	{
		$this->attributes['quantidade_volume'] = $quantidadeVolume;
	}

	public function getQuantidadeItemPorVolumeAttribute()
	{
		return $this->attributes['quantidade_item_por_volume'];
	}

	public function setQuantidadeItemPorVolumeAttribute($quantidadeItemPorVolume)
	{
		$this->attributes['quantidade_item_por_volume'] = $quantidadeItemPorVolume;
	}

	public function getQuantidadeRecebidaAttribute()
	{
		return $this->attributes['quantidade_recebida'];
	}

	public function setQuantidadeRecebidaAttribute($quantidadeRecebida)
	{
		$this->attributes['quantidade_recebida'] = $quantidadeRecebida;
	}

	public function getDestinoAttribute()
	{
		return $this->attributes['destino'];
	}

	public function setDestinoAttribute($destino)
	{
		$this->attributes['destino'] = $destino;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setQuantidadeVolumeAttribute($object->quantidadeVolume);
				$this->setQuantidadeItemPorVolumeAttribute($object->quantidadeItemPorVolume);
				$this->setQuantidadeRecebidaAttribute($object->quantidadeRecebida);
				$this->setDestinoAttribute($object->destino);

				// link objects - lookups
				$produtoModel = new ProdutoModel();
				$produtoModel->mapping($object->produtoModel);
				$this->produtoModel()->associate($produtoModel);
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'quantidadeVolume' => $this->getQuantidadeVolumeAttribute(),
				'quantidadeItemPorVolume' => $this->getQuantidadeItemPorVolumeAttribute(),
				'quantidadeRecebida' => $this->getQuantidadeRecebidaAttribute(),
				'destino' => $this->getDestinoAttribute(),
				'produtoModel' => $this->produtoModel,
			];
	}
}