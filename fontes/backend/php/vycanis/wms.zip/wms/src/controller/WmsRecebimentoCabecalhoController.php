<?php
class WmsRecebimentoCabecalhoController extends ControllerBase
{

		private $wmsRecebimentoCabecalhoService = null;

		public function __construct()
		{	 
				$this->wmsRecebimentoCabecalhoService = new WmsRecebimentoCabecalhoService();
		}

		public function getList($request, $response, $args)
		{
				try {
						if (count($request->getQueryParams()) > 0) {
								$filter = new Filter($request->getQueryParams()['filter']);
								$resultList = $this->wmsRecebimentoCabecalhoService->getListFilter($filter);
						} else {
								$resultList = $this->wmsRecebimentoCabecalhoService->getList();
						}
						$return = json_encode($resultList);
						$response->getBody()->write($return);
						return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getList WmsRecebimentoCabecalho]', $e);
				}
		}

		public function getObject($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->wmsRecebimentoCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 404, 'Not Found [getObject WmsRecebimentoCabecalho]', null);
						} else {
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [getObject WmsRecebimentoCabecalho]', $e);
				}
		}

		public function insert($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						if (!isset($objJson)) {
								return parent::handleError($response, 400, 'Invalid Object [insert WmsRecebimentoCabecalho]', null);
						}

						$objModel = new WmsRecebimentoCabecalhoModel();
						$objModel->mapping($objJson);

						$this->wmsRecebimentoCabecalhoService->insert($objJson, $objModel);
			
						$return = json_encode($objModel);
						$response->getBody()->write($return);

						return $response
								->withStatus(201)
								->withHeader('Content-Type', 'application/json');
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [insert WmsRecebimentoCabecalho]', $e);
				}
		}

		public function update($request, $response, $args)
		{
				try {
						$objJson = json_decode($request->getBody());

						$objFromDatabase = $this->wmsRecebimentoCabecalhoService->getObject($objJson->id);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [update WmsRecebimentoCabecalho]', null);
						} else {				
								$objFromDatabase->mapping($objJson);
				
								$this->wmsRecebimentoCabecalhoService->update($objJson, $objFromDatabase);
								$objFromDatabase = $this->wmsRecebimentoCabecalhoService->getObject($objJson->id);
				
								$return = json_encode($objFromDatabase);
								$response->getBody()->write($return);
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [update WmsRecebimentoCabecalho]', $e);
				}
		}

		public function delete($request, $response, $args)
		{
				try {
						$objFromDatabase = $this->wmsRecebimentoCabecalhoService->getObject($args['id']);

						if ($objFromDatabase == null) {
								return parent::handleError($response, 400, 'Invalid Object [delete WmsRecebimentoCabecalho]', null);
						} else {
								$this->wmsRecebimentoCabecalhoService->delete($objFromDatabase);
								
								return $response
										->withStatus(200)
										->withHeader('Content-Type', 'application/json');
						}
				} catch (Exception $e) {
						return parent::handleError($response, 500, 'Error [delete WmsRecebimentoCabecalho]', $e);
				}
		}
}
