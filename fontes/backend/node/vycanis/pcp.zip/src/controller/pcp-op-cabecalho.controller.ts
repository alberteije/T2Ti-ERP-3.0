import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PcpOpCabecalhoService } from '../service/pcp-op-cabecalho.service';
import { PcpOpCabecalhoModel } from '../model/pcp-op-cabecalho.entity';

@Crud({
  model: {
    type: PcpOpCabecalhoModel,
  },
  query: {
    join: {
			pcpOpDetalheModelList: { eager: true },
			pcpInstrucaoOpModelList: { eager: true },
    },
  },
})
@Controller('pcp-op-cabecalho')
export class PcpOpCabecalhoController implements CrudController<PcpOpCabecalhoModel> {
  constructor(public service: PcpOpCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const pcpOpCabecalho = new PcpOpCabecalhoModel(jsonObj);
		const result = await this.service.save(pcpOpCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pcpOpCabecalho = new PcpOpCabecalhoModel(jsonObj);
		const result = await this.service.save(pcpOpCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}