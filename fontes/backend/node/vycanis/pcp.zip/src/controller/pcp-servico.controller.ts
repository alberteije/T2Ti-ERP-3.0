import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PcpServicoService } from '../service/pcp-servico.service';
import { PcpServicoModel } from '../model/pcp-servico.entity';

@Crud({
  model: {
    type: PcpServicoModel,
  },
  query: {
    join: {
			pcpServicoColaboradorModelList: { eager: true },
			pcpServicoEquipamentoModelList: { eager: true },
			pcpOpDetalheModel: { eager: true },
    },
  },
})
@Controller('pcp-servico')
export class PcpServicoController implements CrudController<PcpServicoModel> {
  constructor(public service: PcpServicoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const pcpServico = new PcpServicoModel(jsonObj);
		const result = await this.service.save(pcpServico, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pcpServico = new PcpServicoModel(jsonObj);
		const result = await this.service.save(pcpServico, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}