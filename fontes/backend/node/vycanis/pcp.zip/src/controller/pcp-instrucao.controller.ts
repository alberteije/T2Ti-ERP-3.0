import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PcpInstrucaoService } from '../service/pcp-instrucao.service';
import { PcpInstrucaoModel } from '../model/pcp-instrucao.entity';

@Crud({
  model: {
    type: PcpInstrucaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('pcp-instrucao')
export class PcpInstrucaoController implements CrudController<PcpInstrucaoModel> {
  constructor(public service: PcpInstrucaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pcpInstrucaoModel = new PcpInstrucaoModel(jsonObj);
		const result = await this.service.save(pcpInstrucaoModel);
		return result;
	}  


}


















