import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PcpInstrucaoModel } from '../entities-export';

@Injectable()
export class PcpInstrucaoService extends TypeOrmCrudService<PcpInstrucaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PcpInstrucaoModel)
    private readonly repository: Repository<PcpInstrucaoModel>
  ) {
    super(repository);
  }

	async save(pcpInstrucaoModel: PcpInstrucaoModel): Promise<PcpInstrucaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(pcpInstrucaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
