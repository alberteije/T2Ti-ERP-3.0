import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PcpServicoController } from '../controller/pcp-servico.controller';
import { PcpServicoService } from '../service/pcp-servico.service';
import { PcpServicoModel } from '../model/pcp-servico.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PcpServicoModel])],
    controllers: [PcpServicoController],
    providers: [PcpServicoService],
})
export class PcpServicoModule { }
