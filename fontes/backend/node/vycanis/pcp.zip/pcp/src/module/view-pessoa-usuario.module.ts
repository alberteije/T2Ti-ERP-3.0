import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaUsuarioController } from '../controller/view-pessoa-usuario.controller';
import { ViewPessoaUsuarioService } from '../service/view-pessoa-usuario.service';
import { ViewPessoaUsuarioModel } from '../model/view-pessoa-usuario.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaUsuarioModel])],
    controllers: [ViewPessoaUsuarioController],
    providers: [ViewPessoaUsuarioService],
})
export class ViewPessoaUsuarioModule { }
