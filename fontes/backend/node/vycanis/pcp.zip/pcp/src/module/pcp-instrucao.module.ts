import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PcpInstrucaoController } from '../controller/pcp-instrucao.controller';
import { PcpInstrucaoService } from '../service/pcp-instrucao.service';
import { PcpInstrucaoModel } from '../model/pcp-instrucao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PcpInstrucaoModel])],
    controllers: [PcpInstrucaoController],
    providers: [PcpInstrucaoService],
})
export class PcpInstrucaoModule { }
