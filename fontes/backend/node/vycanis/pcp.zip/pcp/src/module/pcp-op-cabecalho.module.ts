import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PcpOpCabecalhoController } from '../controller/pcp-op-cabecalho.controller';
import { PcpOpCabecalhoService } from '../service/pcp-op-cabecalho.service';
import { PcpOpCabecalhoModel } from '../model/pcp-op-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PcpOpCabecalhoModel])],
    controllers: [PcpOpCabecalhoController],
    providers: [PcpOpCabecalhoService],
})
export class PcpOpCabecalhoModule { }
