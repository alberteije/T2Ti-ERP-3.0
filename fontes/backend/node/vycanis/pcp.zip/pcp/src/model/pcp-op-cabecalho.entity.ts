import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PcpOpDetalheModel } from '../entities-export';
import { PcpInstrucaoOpModel } from '../entities-export';

@Entity({ name: 'pcp_op_cabecalho' })
export class PcpOpCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_previsao_entrega' }) 
	dataPrevisaoEntrega: Date; 

	@Column({ name: 'data_termino' }) 
	dataTermino: Date; 

	@Column({ name: 'custo_total_previsto', type: 'decimal', precision: 18, scale: 6 }) 
	custoTotalPrevisto: number; 

	@Column({ name: 'custo_total_realizado', type: 'decimal', precision: 18, scale: 6 }) 
	custoTotalRealizado: number; 

	@Column({ name: 'porcento_venda', type: 'decimal', precision: 18, scale: 6 }) 
	porcentoVenda: number; 

	@Column({ name: 'porcento_estoque', type: 'decimal', precision: 18, scale: 6 }) 
	porcentoEstoque: number; 


	/**
	* Relations
	*/
	@OneToMany(() => PcpOpDetalheModel, pcpOpDetalheModel => pcpOpDetalheModel.pcpOpCabecalhoModel, { cascade: true })
	pcpOpDetalheModelList: PcpOpDetalheModel[];

	@OneToMany(() => PcpInstrucaoOpModel, pcpInstrucaoOpModel => pcpInstrucaoOpModel.pcpOpCabecalhoModel, { cascade: true })
	pcpInstrucaoOpModelList: PcpInstrucaoOpModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataPrevisaoEntrega = jsonObj['dataPrevisaoEntrega'];
			this.dataTermino = jsonObj['dataTermino'];
			this.custoTotalPrevisto = jsonObj['custoTotalPrevisto'];
			this.custoTotalRealizado = jsonObj['custoTotalRealizado'];
			this.porcentoVenda = jsonObj['porcentoVenda'];
			this.porcentoEstoque = jsonObj['porcentoEstoque'];
			this.pcpOpDetalheModelList = [];
			let pcpOpDetalheModelJsonList = jsonObj['pcpOpDetalheModelList'];
			if (pcpOpDetalheModelJsonList != null) {
				for (let i = 0; i < pcpOpDetalheModelJsonList.length; i++) {
					let obj = new PcpOpDetalheModel(pcpOpDetalheModelJsonList[i]);
					this.pcpOpDetalheModelList.push(obj);
				}
			}

			this.pcpInstrucaoOpModelList = [];
			let pcpInstrucaoOpModelJsonList = jsonObj['pcpInstrucaoOpModelList'];
			if (pcpInstrucaoOpModelJsonList != null) {
				for (let i = 0; i < pcpInstrucaoOpModelJsonList.length; i++) {
					let obj = new PcpInstrucaoOpModel(pcpInstrucaoOpModelJsonList[i]);
					this.pcpInstrucaoOpModelList.push(obj);
				}
			}

		}
	}
}