import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PcpServicoColaboradorModel } from '../entities-export';
import { PcpServicoEquipamentoModel } from '../entities-export';
import { PcpOpDetalheModel } from '../entities-export';

@Entity({ name: 'pcp_servico' })
export class PcpServicoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'inicio_realizado' }) 
	inicioRealizado: Date; 

	@Column({ name: 'termino_realizado' }) 
	terminoRealizado: Date; 

	@Column({ name: 'horas_realizado' }) 
	horasRealizado: number; 

	@Column({ name: 'minutos_realizado' }) 
	minutosRealizado: number; 

	@Column({ name: 'segundos_realizado' }) 
	segundosRealizado: number; 

	@Column({ name: 'custo_realizado', type: 'decimal', precision: 18, scale: 6 }) 
	custoRealizado: number; 

	@Column({ name: 'inicio_previsto' }) 
	inicioPrevisto: Date; 

	@Column({ name: 'termino_previsto' }) 
	terminoPrevisto: Date; 

	@Column({ name: 'horas_previsto' }) 
	horasPrevisto: number; 

	@Column({ name: 'minutos_previsto' }) 
	minutosPrevisto: number; 

	@Column({ name: 'segundos_previsto' }) 
	segundosPrevisto: number; 

	@Column({ name: 'custo_previsto', type: 'decimal', precision: 18, scale: 6 }) 
	custoPrevisto: number; 


	/**
	* Relations
	*/
	@OneToMany(() => PcpServicoColaboradorModel, pcpServicoColaboradorModel => pcpServicoColaboradorModel.pcpServicoModel, { cascade: true })
	pcpServicoColaboradorModelList: PcpServicoColaboradorModel[];

	@OneToMany(() => PcpServicoEquipamentoModel, pcpServicoEquipamentoModel => pcpServicoEquipamentoModel.pcpServicoModel, { cascade: true })
	pcpServicoEquipamentoModelList: PcpServicoEquipamentoModel[];

	@OneToOne(() => PcpOpDetalheModel)
	@JoinColumn({ name: 'id_pcp_op_detalhe' })
	pcpOpDetalheModel: PcpOpDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.inicioRealizado = jsonObj['inicioRealizado'];
			this.terminoRealizado = jsonObj['terminoRealizado'];
			this.horasRealizado = jsonObj['horasRealizado'];
			this.minutosRealizado = jsonObj['minutosRealizado'];
			this.segundosRealizado = jsonObj['segundosRealizado'];
			this.custoRealizado = jsonObj['custoRealizado'];
			this.inicioPrevisto = jsonObj['inicioPrevisto'];
			this.terminoPrevisto = jsonObj['terminoPrevisto'];
			this.horasPrevisto = jsonObj['horasPrevisto'];
			this.minutosPrevisto = jsonObj['minutosPrevisto'];
			this.segundosPrevisto = jsonObj['segundosPrevisto'];
			this.custoPrevisto = jsonObj['custoPrevisto'];
			if (jsonObj['pcpOpDetalheModel'] != null) {
				this.pcpOpDetalheModel = new PcpOpDetalheModel(jsonObj['pcpOpDetalheModel']);
			}

			this.pcpServicoColaboradorModelList = [];
			let pcpServicoColaboradorModelJsonList = jsonObj['pcpServicoColaboradorModelList'];
			if (pcpServicoColaboradorModelJsonList != null) {
				for (let i = 0; i < pcpServicoColaboradorModelJsonList.length; i++) {
					let obj = new PcpServicoColaboradorModel(pcpServicoColaboradorModelJsonList[i]);
					this.pcpServicoColaboradorModelList.push(obj);
				}
			}

			this.pcpServicoEquipamentoModelList = [];
			let pcpServicoEquipamentoModelJsonList = jsonObj['pcpServicoEquipamentoModelList'];
			if (pcpServicoEquipamentoModelJsonList != null) {
				for (let i = 0; i < pcpServicoEquipamentoModelJsonList.length; i++) {
					let obj = new PcpServicoEquipamentoModel(pcpServicoEquipamentoModelJsonList[i]);
					this.pcpServicoEquipamentoModelList.push(obj);
				}
			}

		}
	}
}