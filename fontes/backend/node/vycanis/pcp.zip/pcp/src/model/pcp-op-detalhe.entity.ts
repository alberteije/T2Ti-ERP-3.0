import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PcpOpCabecalhoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'pcp_op_detalhe' })
export class PcpOpDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade_produzir', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeProduzir: number; 

	@Column({ name: 'quantidade_produzida', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeProduzida: number; 

	@Column({ name: 'quantidade_entregue', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeEntregue: number; 

	@Column({ name: 'custo_previsto', type: 'decimal', precision: 18, scale: 6 }) 
	custoPrevisto: number; 

	@Column({ name: 'custo_realizado', type: 'decimal', precision: 18, scale: 6 }) 
	custoRealizado: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => PcpOpCabecalhoModel, pcpOpCabecalhoModel => pcpOpCabecalhoModel.pcpOpDetalheModelList)
	@JoinColumn({ name: 'id_pcp_op_cabecalho' })
	pcpOpCabecalhoModel: PcpOpCabecalhoModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidadeProduzir = jsonObj['quantidadeProduzir'];
			this.quantidadeProduzida = jsonObj['quantidadeProduzida'];
			this.quantidadeEntregue = jsonObj['quantidadeEntregue'];
			this.custoPrevisto = jsonObj['custoPrevisto'];
			this.custoRealizado = jsonObj['custoRealizado'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}