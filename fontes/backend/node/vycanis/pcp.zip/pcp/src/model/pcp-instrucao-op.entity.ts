import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PcpOpCabecalhoModel } from '../entities-export';
import { PcpInstrucaoModel } from '../entities-export';

@Entity({ name: 'pcp_instrucao_op' })
export class PcpInstrucaoOpModel { 

	@PrimaryGeneratedColumn() 
	id: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => PcpOpCabecalhoModel, pcpOpCabecalhoModel => pcpOpCabecalhoModel.pcpInstrucaoOpModelList)
	@JoinColumn({ name: 'id_pcp_op_cabecalho' })
	pcpOpCabecalhoModel: PcpOpCabecalhoModel;

	@OneToOne(() => PcpInstrucaoModel)
	@JoinColumn({ name: 'id_pcp_instrucao' })
	pcpInstrucaoModel: PcpInstrucaoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			if (jsonObj['pcpInstrucaoModel'] != null) {
				this.pcpInstrucaoModel = new PcpInstrucaoModel(jsonObj['pcpInstrucaoModel']);
			}

		}
	}
}