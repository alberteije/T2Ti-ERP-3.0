import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'patrim_bem' })
export class PatrimBemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_centro_resultado' }) 
	idCentroResultado: number; 

	@Column({ name: 'id_patrim_tipo_aquisicao_bem' }) 
	idPatrimTipoAquisicaoBem: number; 

	@Column({ name: 'id_patrim_estado_conservacao' }) 
	idPatrimEstadoConservacao: number; 

	@Column({ name: 'id_patrim_grupo_bem' }) 
	idPatrimGrupoBem: number; 

	@Column({ name: 'id_fornecedor' }) 
	idFornecedor: number; 

	@Column({ name: 'id_setor' }) 
	idSetor: number; 

	@Column({ name: 'numero_nb' }) 
	numeroNb: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'numero_serie' }) 
	numeroSerie: string; 

	@Column({ name: 'data_aquisicao' }) 
	dataAquisicao: Date; 

	@Column({ name: 'data_aceite' }) 
	dataAceite: Date; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'data_contabilizado' }) 
	dataContabilizado: Date; 

	@Column({ name: 'data_vistoria' }) 
	dataVistoria: Date; 

	@Column({ name: 'data_marcacao' }) 
	dataMarcacao: Date; 

	@Column({ name: 'data_baixa' }) 
	dataBaixa: Date; 

	@Column({ name: 'vencimento_garantia' }) 
	vencimentoGarantia: Date; 

	@Column({ name: 'numero_nota_fiscal' }) 
	numeroNotaFiscal: string; 

	@Column({ name: 'chave_nfe' }) 
	chaveNfe: string; 

	@Column({ name: 'valor_original', type: 'decimal', precision: 18, scale: 6 }) 
	valorOriginal: number; 

	@Column({ name: 'valor_compra', type: 'decimal', precision: 18, scale: 6 }) 
	valorCompra: number; 

	@Column({ name: 'valor_atualizado', type: 'decimal', precision: 18, scale: 6 }) 
	valorAtualizado: number; 

	@Column({ name: 'valor_baixa', type: 'decimal', precision: 18, scale: 6 }) 
	valorBaixa: number; 

	@Column({ name: 'deprecia' }) 
	deprecia: string; 

	@Column({ name: 'metodo_depreciacao' }) 
	metodoDepreciacao: string; 

	@Column({ name: 'inicio_depreciacao' }) 
	inicioDepreciacao: Date; 

	@Column({ name: 'ultima_depreciacao' }) 
	ultimaDepreciacao: Date; 

	@Column({ name: 'tipo_depreciacao' }) 
	tipoDepreciacao: string; 

	@Column({ name: 'taxa_anual_depreciacao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaAnualDepreciacao: number; 

	@Column({ name: 'taxa_mensal_depreciacao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaMensalDepreciacao: number; 

	@Column({ name: 'taxa_depreciacao_acelerada', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDepreciacaoAcelerada: number; 

	@Column({ name: 'taxa_depreciacao_incentivada', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDepreciacaoIncentivada: number; 

	@Column({ name: 'funcao' }) 
	funcao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idCentroResultado = jsonObj['idCentroResultado'];
			this.idPatrimTipoAquisicaoBem = jsonObj['idPatrimTipoAquisicaoBem'];
			this.idPatrimEstadoConservacao = jsonObj['idPatrimEstadoConservacao'];
			this.idPatrimGrupoBem = jsonObj['idPatrimGrupoBem'];
			this.idFornecedor = jsonObj['idFornecedor'];
			this.idSetor = jsonObj['idSetor'];
			this.numeroNb = jsonObj['numeroNb'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.numeroSerie = jsonObj['numeroSerie'];
			this.dataAquisicao = jsonObj['dataAquisicao'];
			this.dataAceite = jsonObj['dataAceite'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.dataContabilizado = jsonObj['dataContabilizado'];
			this.dataVistoria = jsonObj['dataVistoria'];
			this.dataMarcacao = jsonObj['dataMarcacao'];
			this.dataBaixa = jsonObj['dataBaixa'];
			this.vencimentoGarantia = jsonObj['vencimentoGarantia'];
			this.numeroNotaFiscal = jsonObj['numeroNotaFiscal'];
			this.chaveNfe = jsonObj['chaveNfe'];
			this.valorOriginal = jsonObj['valorOriginal'];
			this.valorCompra = jsonObj['valorCompra'];
			this.valorAtualizado = jsonObj['valorAtualizado'];
			this.valorBaixa = jsonObj['valorBaixa'];
			this.deprecia = jsonObj['deprecia'];
			this.metodoDepreciacao = jsonObj['metodoDepreciacao'];
			this.inicioDepreciacao = jsonObj['inicioDepreciacao'];
			this.ultimaDepreciacao = jsonObj['ultimaDepreciacao'];
			this.tipoDepreciacao = jsonObj['tipoDepreciacao'];
			this.taxaAnualDepreciacao = jsonObj['taxaAnualDepreciacao'];
			this.taxaMensalDepreciacao = jsonObj['taxaMensalDepreciacao'];
			this.taxaDepreciacaoAcelerada = jsonObj['taxaDepreciacaoAcelerada'];
			this.taxaDepreciacaoIncentivada = jsonObj['taxaDepreciacaoIncentivada'];
			this.funcao = jsonObj['funcao'];
		}
	}
}