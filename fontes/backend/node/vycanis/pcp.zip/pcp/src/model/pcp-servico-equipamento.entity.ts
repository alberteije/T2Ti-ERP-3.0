import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PcpServicoModel } from '../entities-export';
import { PatrimBemModel } from '../entities-export';

@Entity({ name: 'pcp_servico_equipamento' })
export class PcpServicoEquipamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => PcpServicoModel, pcpServicoModel => pcpServicoModel.pcpServicoEquipamentoModelList)
	@JoinColumn({ name: 'id_pcp_servico' })
	pcpServicoModel: PcpServicoModel;

	@OneToOne(() => PatrimBemModel)
	@JoinColumn({ name: 'id_patrim_bem' })
	patrimBemModel: PatrimBemModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			if (jsonObj['patrimBemModel'] != null) {
				this.patrimBemModel = new PatrimBemModel(jsonObj['patrimBemModel']);
			}

		}
	}
}