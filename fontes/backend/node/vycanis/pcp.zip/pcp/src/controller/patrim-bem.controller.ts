import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PatrimBemService } from '../service/patrim-bem.service';
import { PatrimBemModel } from '../model/patrim-bem.entity';

@Crud({
  model: {
    type: PatrimBemModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('patrim-bem')
export class PatrimBemController implements CrudController<PatrimBemModel> {
  constructor(public service: PatrimBemService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimBemModel = new PatrimBemModel(jsonObj);
		const result = await this.service.save(patrimBemModel);
		return result;
	}  


}


















