import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';

@Injectable()
export class FrotaVeiculoService extends TypeOrmCrudService<FrotaVeiculoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(FrotaVeiculoModel) 
    private readonly repository: Repository<FrotaVeiculoModel>,
  ) {
    super(repository);
  }

	async save(frotaVeiculoModel: FrotaVeiculoModel, operation: string): Promise<FrotaVeiculoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, frotaVeiculoModel.id);
      }

      const resultObj = await queryRunner.manager.save(frotaVeiculoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(FrotaVeiculoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from frota_ipva_controle where id_frota_veiculo=' + id); 

		await queryRunner.query('delete from frota_dpvat_controle where id_frota_veiculo=' + id); 

		await queryRunner.query('delete from frota_veiculo_sinistro where id_frota_veiculo=' + id); 

		await queryRunner.query('delete from frota_veiculo_movimentacao where id_frota_veiculo=' + id); 

		await queryRunner.query('delete from frota_veiculo_pneu where id_frota_veiculo=' + id); 

		await queryRunner.query('delete from frota_veiculo_manutencao where id_frota_veiculo=' + id); 

		await queryRunner.query('delete from frota_multa_controle where id_frota_veiculo=' + id); 

		await queryRunner.query('delete from frota_combustivel_controle where id_frota_veiculo=' + id); 

	}
	
}