import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FrotaVeiculoTipoModel } from '../entities-export';

@Injectable()
export class FrotaVeiculoTipoService extends TypeOrmCrudService<FrotaVeiculoTipoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FrotaVeiculoTipoModel)
    private readonly repository: Repository<FrotaVeiculoTipoModel>
  ) {
    super(repository);
  }

	async save(frotaVeiculoTipoModel: FrotaVeiculoTipoModel): Promise<FrotaVeiculoTipoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(frotaVeiculoTipoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
