import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FrotaMotoristaModel } from '../entities-export';

@Injectable()
export class FrotaMotoristaService extends TypeOrmCrudService<FrotaMotoristaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FrotaMotoristaModel)
    private readonly repository: Repository<FrotaMotoristaModel>
  ) {
    super(repository);
  }

	async save(frotaMotoristaModel: FrotaMotoristaModel): Promise<FrotaMotoristaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(frotaMotoristaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
