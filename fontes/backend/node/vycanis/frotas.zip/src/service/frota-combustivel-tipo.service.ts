import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FrotaCombustivelTipoModel } from '../entities-export';

@Injectable()
export class FrotaCombustivelTipoService extends TypeOrmCrudService<FrotaCombustivelTipoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FrotaCombustivelTipoModel)
    private readonly repository: Repository<FrotaCombustivelTipoModel>
  ) {
    super(repository);
  }

	async save(frotaCombustivelTipoModel: FrotaCombustivelTipoModel): Promise<FrotaCombustivelTipoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(frotaCombustivelTipoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
