import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FrotaCombustivelTipoService } from '../service/frota-combustivel-tipo.service';
import { FrotaCombustivelTipoModel } from '../model/frota-combustivel-tipo.entity';

@Crud({
  model: {
    type: FrotaCombustivelTipoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('frota-combustivel-tipo')
export class FrotaCombustivelTipoController implements CrudController<FrotaCombustivelTipoModel> {
  constructor(public service: FrotaCombustivelTipoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const frotaCombustivelTipoModel = new FrotaCombustivelTipoModel(jsonObj);
		const result = await this.service.save(frotaCombustivelTipoModel);
		return result;
	}  


}


















