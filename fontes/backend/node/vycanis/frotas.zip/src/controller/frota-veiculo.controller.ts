import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FrotaVeiculoService } from '../service/frota-veiculo.service';
import { FrotaVeiculoModel } from '../model/frota-veiculo.entity';

@Crud({
  model: {
    type: FrotaVeiculoModel,
  },
  query: {
    join: {
			frotaIpvaControleModelList: { eager: true },
			frotaDpvatControleModelList: { eager: true },
			frotaVeiculoSinistroModelList: { eager: true },
			frotaVeiculoMovimentacaoModelList: { eager: true },
			frotaVeiculoPneuModelList: { eager: true },
			frotaVeiculoManutencaoModelList: { eager: true },
			frotaMultaControleModelList: { eager: true },
			frotaCombustivelControleModelList: { eager: true },
			frotaVeiculoTipoModel: { eager: true },
			frotaCombustivelTipoModel: { eager: true },
    },
  },
})
@Controller('frota-veiculo')
export class FrotaVeiculoController implements CrudController<FrotaVeiculoModel> {
  constructor(public service: FrotaVeiculoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const frotaVeiculo = new FrotaVeiculoModel(jsonObj);
		const result = await this.service.save(frotaVeiculo, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const frotaVeiculo = new FrotaVeiculoModel(jsonObj);
		const result = await this.service.save(frotaVeiculo, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}