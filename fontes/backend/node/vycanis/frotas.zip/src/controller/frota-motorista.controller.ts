import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FrotaMotoristaService } from '../service/frota-motorista.service';
import { FrotaMotoristaModel } from '../model/frota-motorista.entity';

@Crud({
  model: {
    type: FrotaMotoristaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('frota-motorista')
export class FrotaMotoristaController implements CrudController<FrotaMotoristaModel> {
  constructor(public service: FrotaMotoristaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const frotaMotoristaModel = new FrotaMotoristaModel(jsonObj);
		const result = await this.service.save(frotaMotoristaModel);
		return result;
	}  


}


















