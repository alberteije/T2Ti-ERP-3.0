import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';
import { FrotaMotoristaModel } from '../entities-export';

@Entity({ name: 'frota_veiculo_movimentacao' })
export class FrotaVeiculoMovimentacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_saida' }) 
	dataSaida: Date; 

	@Column({ name: 'hora_saida' }) 
	horaSaida: string; 

	@Column({ name: 'data_entrada' }) 
	dataEntrada: Date; 

	@Column({ name: 'hora_entrada' }) 
	horaEntrada: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FrotaVeiculoModel, frotaVeiculoModel => frotaVeiculoModel.frotaVeiculoMovimentacaoModelList)
	@JoinColumn({ name: 'id_frota_veiculo' })
	frotaVeiculoModel: FrotaVeiculoModel;

	@OneToOne(() => FrotaMotoristaModel)
	@JoinColumn({ name: 'id_frota_motorista' })
	frotaMotoristaModel: FrotaMotoristaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataSaida = jsonObj['dataSaida'];
			this.horaSaida = jsonObj['horaSaida'];
			this.dataEntrada = jsonObj['dataEntrada'];
			this.horaEntrada = jsonObj['horaEntrada'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['frotaMotoristaModel'] != null) {
				this.frotaMotoristaModel = new FrotaMotoristaModel(jsonObj['frotaMotoristaModel']);
			}

		}
	}
}