import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'frota_motorista' })
export class FrotaMotoristaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'numero_cnh' }) 
	numeroCnh: string; 

	@Column({ name: 'cnh_categoria' }) 
	cnhCategoria: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.numeroCnh = jsonObj['numeroCnh'];
			this.cnhCategoria = jsonObj['cnhCategoria'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}