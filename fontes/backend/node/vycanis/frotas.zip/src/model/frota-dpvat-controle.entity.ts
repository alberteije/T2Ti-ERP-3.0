import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';

@Entity({ name: 'frota_dpvat_controle' })
export class FrotaDpvatControleModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'ano' }) 
	ano: string; 

	@Column({ name: 'parcela' }) 
	parcela: string; 

	@Column({ name: 'data_vencimento' }) 
	dataVencimento: Date; 

	@Column({ name: 'data_pagamento' }) 
	dataPagamento: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => FrotaVeiculoModel, frotaVeiculoModel => frotaVeiculoModel.frotaDpvatControleModelList)
	@JoinColumn({ name: 'id_frota_veiculo' })
	frotaVeiculoModel: FrotaVeiculoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ano = jsonObj['ano'];
			this.parcela = jsonObj['parcela'];
			this.dataVencimento = jsonObj['dataVencimento'];
			this.dataPagamento = jsonObj['dataPagamento'];
			this.valor = jsonObj['valor'];
		}
	}
}