import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';

@Entity({ name: 'frota_veiculo_sinistro' })
export class FrotaVeiculoSinistroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_sinistro' }) 
	dataSinistro: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FrotaVeiculoModel, frotaVeiculoModel => frotaVeiculoModel.frotaVeiculoSinistroModelList)
	@JoinColumn({ name: 'id_frota_veiculo' })
	frotaVeiculoModel: FrotaVeiculoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataSinistro = jsonObj['dataSinistro'];
			this.observacao = jsonObj['observacao'];
		}
	}
}