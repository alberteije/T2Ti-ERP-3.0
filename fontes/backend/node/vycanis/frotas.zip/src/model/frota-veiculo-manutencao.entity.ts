import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';

@Entity({ name: 'frota_veiculo_manutencao' })
export class FrotaVeiculoManutencaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'data_manutencao' }) 
	dataManutencao: Date; 

	@Column({ name: 'valor_manutencao', type: 'decimal', precision: 18, scale: 6 }) 
	valorManutencao: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FrotaVeiculoModel, frotaVeiculoModel => frotaVeiculoModel.frotaVeiculoManutencaoModelList)
	@JoinColumn({ name: 'id_frota_veiculo' })
	frotaVeiculoModel: FrotaVeiculoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipo = jsonObj['tipo'];
			this.dataManutencao = jsonObj['dataManutencao'];
			this.valorManutencao = jsonObj['valorManutencao'];
			this.observacao = jsonObj['observacao'];
		}
	}
}