import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FrotaVeiculoController } from '../controller/frota-veiculo.controller';
import { FrotaVeiculoService } from '../service/frota-veiculo.service';
import { FrotaVeiculoModel } from '../model/frota-veiculo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FrotaVeiculoModel])],
    controllers: [FrotaVeiculoController],
    providers: [FrotaVeiculoService],
})
export class FrotaVeiculoModule { }
