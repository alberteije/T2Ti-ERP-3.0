import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FrotaVeiculoTipoController } from '../controller/frota-veiculo-tipo.controller';
import { FrotaVeiculoTipoService } from '../service/frota-veiculo-tipo.service';
import { FrotaVeiculoTipoModel } from '../model/frota-veiculo-tipo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FrotaVeiculoTipoModel])],
    controllers: [FrotaVeiculoTipoController],
    providers: [FrotaVeiculoTipoService],
})
export class FrotaVeiculoTipoModule { }
