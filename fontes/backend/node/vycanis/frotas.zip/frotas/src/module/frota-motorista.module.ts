import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FrotaMotoristaController } from '../controller/frota-motorista.controller';
import { FrotaMotoristaService } from '../service/frota-motorista.service';
import { FrotaMotoristaModel } from '../model/frota-motorista.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FrotaMotoristaModel])],
    controllers: [FrotaMotoristaController],
    providers: [FrotaMotoristaService],
})
export class FrotaMotoristaModule { }
