import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FrotaCombustivelTipoController } from '../controller/frota-combustivel-tipo.controller';
import { FrotaCombustivelTipoService } from '../service/frota-combustivel-tipo.service';
import { FrotaCombustivelTipoModel } from '../model/frota-combustivel-tipo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FrotaCombustivelTipoModel])],
    controllers: [FrotaCombustivelTipoController],
    providers: [FrotaCombustivelTipoService],
})
export class FrotaCombustivelTipoModule { }
