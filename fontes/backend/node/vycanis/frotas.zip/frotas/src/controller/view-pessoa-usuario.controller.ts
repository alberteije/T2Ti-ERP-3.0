import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ViewPessoaUsuarioService } from '../service/view-pessoa-usuario.service';
import { ViewPessoaUsuarioModel } from '../model/view-pessoa-usuario.entity';

@Crud({
  model: {
    type: ViewPessoaUsuarioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('view-pessoa-usuario')
export class ViewPessoaUsuarioController implements CrudController<ViewPessoaUsuarioModel> {
  constructor(public service: ViewPessoaUsuarioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const viewPessoaUsuarioModel = new ViewPessoaUsuarioModel(jsonObj);
		const result = await this.service.save(viewPessoaUsuarioModel);
		return result;
	}  


}


















