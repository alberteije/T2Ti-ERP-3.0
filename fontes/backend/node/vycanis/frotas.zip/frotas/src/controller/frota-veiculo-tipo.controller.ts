import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FrotaVeiculoTipoService } from '../service/frota-veiculo-tipo.service';
import { FrotaVeiculoTipoModel } from '../model/frota-veiculo-tipo.entity';

@Crud({
  model: {
    type: FrotaVeiculoTipoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('frota-veiculo-tipo')
export class FrotaVeiculoTipoController implements CrudController<FrotaVeiculoTipoModel> {
  constructor(public service: FrotaVeiculoTipoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const frotaVeiculoTipoModel = new FrotaVeiculoTipoModel(jsonObj);
		const result = await this.service.save(frotaVeiculoTipoModel);
		return result;
	}  


}


















