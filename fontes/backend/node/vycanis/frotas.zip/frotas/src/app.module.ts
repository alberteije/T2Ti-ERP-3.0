import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { FrotaVeiculoModule } from './modules-export';
import { FrotaVeiculoTipoModule } from './modules-export';
import { FrotaCombustivelTipoModule } from './modules-export';
import { FrotaMotoristaModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaColaboradorModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';
import { AuditoriaModule } from './modules-export';
import { UsuarioTokenModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			FrotaVeiculoModule,
			FrotaVeiculoTipoModule,
			FrotaCombustivelTipoModule,
			FrotaMotoristaModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaColaboradorModule,
      LoginModule,
      AuditoriaModule,
      UsuarioTokenModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
],

  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}