export { FrotaIpvaControleModel } from './model/frota-ipva-controle.entity';
export { FrotaDpvatControleModel } from './model/frota-dpvat-controle.entity';
export { FrotaVeiculoSinistroModel } from './model/frota-veiculo-sinistro.entity';
export { FrotaVeiculoMovimentacaoModel } from './model/frota-veiculo-movimentacao.entity';
export { FrotaVeiculoPneuModel } from './model/frota-veiculo-pneu.entity';
export { FrotaVeiculoManutencaoModel } from './model/frota-veiculo-manutencao.entity';
export { FrotaMultaControleModel } from './model/frota-multa-controle.entity';
export { FrotaCombustivelControleModel } from './model/frota-combustivel-controle.entity';
export { FrotaVeiculoModel } from './model/frota-veiculo.entity';
export { FrotaVeiculoTipoModel } from './model/frota-veiculo-tipo.entity';
export { FrotaCombustivelTipoModel } from './model/frota-combustivel-tipo.entity';
export { FrotaMotoristaModel } from './model/frota-motorista.entity';
export { ViewControleAcessoModel } from './model/view-controle-acesso.entity';
export { ViewPessoaUsuarioModel } from './model/view-pessoa-usuario.entity';
export { ViewPessoaColaboradorModel } from './model/view-pessoa-colaborador.entity';

export { UsuarioTokenModel } from './model/usuario-token.entity';
export { AuditoriaModel } from './model/auditoria.entity';