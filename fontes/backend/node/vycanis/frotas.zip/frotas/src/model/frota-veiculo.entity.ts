import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaIpvaControleModel } from '../entities-export';
import { FrotaDpvatControleModel } from '../entities-export';
import { FrotaVeiculoSinistroModel } from '../entities-export';
import { FrotaVeiculoMovimentacaoModel } from '../entities-export';
import { FrotaVeiculoPneuModel } from '../entities-export';
import { FrotaVeiculoManutencaoModel } from '../entities-export';
import { FrotaMultaControleModel } from '../entities-export';
import { FrotaCombustivelControleModel } from '../entities-export';
import { FrotaVeiculoTipoModel } from '../entities-export';
import { FrotaCombustivelTipoModel } from '../entities-export';

@Entity({ name: 'frota_veiculo' })
export class FrotaVeiculoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'marca' }) 
	marca: string; 

	@Column({ name: 'modelo' }) 
	modelo: string; 

	@Column({ name: 'modelo_ano' }) 
	modeloAno: string; 

	@Column({ name: 'placa' }) 
	placa: string; 

	@Column({ name: 'codigo_fipe' }) 
	codigoFipe: string; 

	@Column({ name: 'renavam' }) 
	renavam: string; 

	@Column({ name: 'ipva_mes_vencimento' }) 
	ipvaMesVencimento: string; 

	@Column({ name: 'dpvat_mes_vencimento' }) 
	dpvatMesVencimento: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FrotaIpvaControleModel, frotaIpvaControleModel => frotaIpvaControleModel.frotaVeiculoModel, { cascade: true })
	frotaIpvaControleModelList: FrotaIpvaControleModel[];

	@OneToMany(() => FrotaDpvatControleModel, frotaDpvatControleModel => frotaDpvatControleModel.frotaVeiculoModel, { cascade: true })
	frotaDpvatControleModelList: FrotaDpvatControleModel[];

	@OneToMany(() => FrotaVeiculoSinistroModel, frotaVeiculoSinistroModel => frotaVeiculoSinistroModel.frotaVeiculoModel, { cascade: true })
	frotaVeiculoSinistroModelList: FrotaVeiculoSinistroModel[];

	@OneToMany(() => FrotaVeiculoMovimentacaoModel, frotaVeiculoMovimentacaoModel => frotaVeiculoMovimentacaoModel.frotaVeiculoModel, { cascade: true })
	frotaVeiculoMovimentacaoModelList: FrotaVeiculoMovimentacaoModel[];

	@OneToMany(() => FrotaVeiculoPneuModel, frotaVeiculoPneuModel => frotaVeiculoPneuModel.frotaVeiculoModel, { cascade: true })
	frotaVeiculoPneuModelList: FrotaVeiculoPneuModel[];

	@OneToMany(() => FrotaVeiculoManutencaoModel, frotaVeiculoManutencaoModel => frotaVeiculoManutencaoModel.frotaVeiculoModel, { cascade: true })
	frotaVeiculoManutencaoModelList: FrotaVeiculoManutencaoModel[];

	@OneToMany(() => FrotaMultaControleModel, frotaMultaControleModel => frotaMultaControleModel.frotaVeiculoModel, { cascade: true })
	frotaMultaControleModelList: FrotaMultaControleModel[];

	@OneToMany(() => FrotaCombustivelControleModel, frotaCombustivelControleModel => frotaCombustivelControleModel.frotaVeiculoModel, { cascade: true })
	frotaCombustivelControleModelList: FrotaCombustivelControleModel[];

	@OneToOne(() => FrotaVeiculoTipoModel)
	@JoinColumn({ name: 'id_frota_veiculo_tipo' })
	frotaVeiculoTipoModel: FrotaVeiculoTipoModel;

	@OneToOne(() => FrotaCombustivelTipoModel)
	@JoinColumn({ name: 'id_frota_combustivel_tipo' })
	frotaCombustivelTipoModel: FrotaCombustivelTipoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.marca = jsonObj['marca'];
			this.modelo = jsonObj['modelo'];
			this.modeloAno = jsonObj['modeloAno'];
			this.placa = jsonObj['placa'];
			this.codigoFipe = jsonObj['codigoFipe'];
			this.renavam = jsonObj['renavam'];
			this.ipvaMesVencimento = jsonObj['ipvaMesVencimento'];
			this.dpvatMesVencimento = jsonObj['dpvatMesVencimento'];
			if (jsonObj['frotaVeiculoTipoModel'] != null) {
				this.frotaVeiculoTipoModel = new FrotaVeiculoTipoModel(jsonObj['frotaVeiculoTipoModel']);
			}

			if (jsonObj['frotaCombustivelTipoModel'] != null) {
				this.frotaCombustivelTipoModel = new FrotaCombustivelTipoModel(jsonObj['frotaCombustivelTipoModel']);
			}

			this.frotaIpvaControleModelList = [];
			let frotaIpvaControleModelJsonList = jsonObj['frotaIpvaControleModelList'];
			if (frotaIpvaControleModelJsonList != null) {
				for (let i = 0; i < frotaIpvaControleModelJsonList.length; i++) {
					let obj = new FrotaIpvaControleModel(frotaIpvaControleModelJsonList[i]);
					this.frotaIpvaControleModelList.push(obj);
				}
			}

			this.frotaDpvatControleModelList = [];
			let frotaDpvatControleModelJsonList = jsonObj['frotaDpvatControleModelList'];
			if (frotaDpvatControleModelJsonList != null) {
				for (let i = 0; i < frotaDpvatControleModelJsonList.length; i++) {
					let obj = new FrotaDpvatControleModel(frotaDpvatControleModelJsonList[i]);
					this.frotaDpvatControleModelList.push(obj);
				}
			}

			this.frotaVeiculoSinistroModelList = [];
			let frotaVeiculoSinistroModelJsonList = jsonObj['frotaVeiculoSinistroModelList'];
			if (frotaVeiculoSinistroModelJsonList != null) {
				for (let i = 0; i < frotaVeiculoSinistroModelJsonList.length; i++) {
					let obj = new FrotaVeiculoSinistroModel(frotaVeiculoSinistroModelJsonList[i]);
					this.frotaVeiculoSinistroModelList.push(obj);
				}
			}

			this.frotaVeiculoMovimentacaoModelList = [];
			let frotaVeiculoMovimentacaoModelJsonList = jsonObj['frotaVeiculoMovimentacaoModelList'];
			if (frotaVeiculoMovimentacaoModelJsonList != null) {
				for (let i = 0; i < frotaVeiculoMovimentacaoModelJsonList.length; i++) {
					let obj = new FrotaVeiculoMovimentacaoModel(frotaVeiculoMovimentacaoModelJsonList[i]);
					this.frotaVeiculoMovimentacaoModelList.push(obj);
				}
			}

			this.frotaVeiculoPneuModelList = [];
			let frotaVeiculoPneuModelJsonList = jsonObj['frotaVeiculoPneuModelList'];
			if (frotaVeiculoPneuModelJsonList != null) {
				for (let i = 0; i < frotaVeiculoPneuModelJsonList.length; i++) {
					let obj = new FrotaVeiculoPneuModel(frotaVeiculoPneuModelJsonList[i]);
					this.frotaVeiculoPneuModelList.push(obj);
				}
			}

			this.frotaVeiculoManutencaoModelList = [];
			let frotaVeiculoManutencaoModelJsonList = jsonObj['frotaVeiculoManutencaoModelList'];
			if (frotaVeiculoManutencaoModelJsonList != null) {
				for (let i = 0; i < frotaVeiculoManutencaoModelJsonList.length; i++) {
					let obj = new FrotaVeiculoManutencaoModel(frotaVeiculoManutencaoModelJsonList[i]);
					this.frotaVeiculoManutencaoModelList.push(obj);
				}
			}

			this.frotaMultaControleModelList = [];
			let frotaMultaControleModelJsonList = jsonObj['frotaMultaControleModelList'];
			if (frotaMultaControleModelJsonList != null) {
				for (let i = 0; i < frotaMultaControleModelJsonList.length; i++) {
					let obj = new FrotaMultaControleModel(frotaMultaControleModelJsonList[i]);
					this.frotaMultaControleModelList.push(obj);
				}
			}

			this.frotaCombustivelControleModelList = [];
			let frotaCombustivelControleModelJsonList = jsonObj['frotaCombustivelControleModelList'];
			if (frotaCombustivelControleModelJsonList != null) {
				for (let i = 0; i < frotaCombustivelControleModelJsonList.length; i++) {
					let obj = new FrotaCombustivelControleModel(frotaCombustivelControleModelJsonList[i]);
					this.frotaCombustivelControleModelList.push(obj);
				}
			}

		}
	}
}