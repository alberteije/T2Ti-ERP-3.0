import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'view_pessoa_colaborador' })
export class ViewPessoaColaboradorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'site' }) 
	site: string; 

	@Column({ name: 'cpf_cnpj' }) 
	cpfCnpj: string; 

	@Column({ name: 'rg_ie' }) 
	rgIe: string; 

	@Column({ name: 'matricula' }) 
	matricula: string; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'data_admissao' }) 
	dataAdmissao: Date; 

	@Column({ name: 'data_demissao' }) 
	dataDemissao: Date; 

	@Column({ name: 'ctps_numero' }) 
	ctpsNumero: string; 

	@Column({ name: 'ctps_serie' }) 
	ctpsSerie: string; 

	@Column({ name: 'ctps_data_expedicao' }) 
	ctpsDataExpedicao: Date; 

	@Column({ name: 'ctps_uf' }) 
	ctpsUf: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'cidade' }) 
	cidade: string; 

	@Column({ name: 'cep' }) 
	cep: string; 

	@Column({ name: 'municipio_ibge' }) 
	municipioIbge: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'id_pessoa' }) 
	idPessoa: number; 

	@Column({ name: 'id_cargo' }) 
	idCargo: number; 

	@Column({ name: 'id_setor' }) 
	idSetor: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.tipo = jsonObj['tipo'];
			this.email = jsonObj['email'];
			this.site = jsonObj['site'];
			this.cpfCnpj = jsonObj['cpfCnpj'];
			this.rgIe = jsonObj['rgIe'];
			this.matricula = jsonObj['matricula'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.dataAdmissao = jsonObj['dataAdmissao'];
			this.dataDemissao = jsonObj['dataDemissao'];
			this.ctpsNumero = jsonObj['ctpsNumero'];
			this.ctpsSerie = jsonObj['ctpsSerie'];
			this.ctpsDataExpedicao = jsonObj['ctpsDataExpedicao'];
			this.ctpsUf = jsonObj['ctpsUf'];
			this.observacao = jsonObj['observacao'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.cidade = jsonObj['cidade'];
			this.cep = jsonObj['cep'];
			this.municipioIbge = jsonObj['municipioIbge'];
			this.uf = jsonObj['uf'];
			this.idPessoa = jsonObj['idPessoa'];
			this.idCargo = jsonObj['idCargo'];
			this.idSetor = jsonObj['idSetor'];
		}
	}
}