import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';

@Entity({ name: 'frota_combustivel_controle' })
export class FrotaCombustivelControleModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_abastecimento' }) 
	dataAbastecimento: Date; 

	@Column({ name: 'hora_abastecimento' }) 
	horaAbastecimento: string; 

	@Column({ name: 'valor_abastecimento', type: 'decimal', precision: 18, scale: 6 }) 
	valorAbastecimento: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => FrotaVeiculoModel, frotaVeiculoModel => frotaVeiculoModel.frotaCombustivelControleModelList)
	@JoinColumn({ name: 'id_frota_veiculo' })
	frotaVeiculoModel: FrotaVeiculoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataAbastecimento = jsonObj['dataAbastecimento'];
			this.horaAbastecimento = jsonObj['horaAbastecimento'];
			this.valorAbastecimento = jsonObj['valorAbastecimento'];
		}
	}
}