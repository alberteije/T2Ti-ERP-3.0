import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';

@Entity({ name: 'frota_veiculo_pneu' })
export class FrotaVeiculoPneuModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_troca' }) 
	dataTroca: Date; 

	@Column({ name: 'valor_troca', type: 'decimal', precision: 18, scale: 6 }) 
	valorTroca: number; 

	@Column({ name: 'posicao_pneu' }) 
	posicaoPneu: string; 

	@Column({ name: 'marca_pneu' }) 
	marcaPneu: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FrotaVeiculoModel, frotaVeiculoModel => frotaVeiculoModel.frotaVeiculoPneuModelList)
	@JoinColumn({ name: 'id_frota_veiculo' })
	frotaVeiculoModel: FrotaVeiculoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataTroca = jsonObj['dataTroca'];
			this.valorTroca = jsonObj['valorTroca'];
			this.posicaoPneu = jsonObj['posicaoPneu'];
			this.marcaPneu = jsonObj['marcaPneu'];
		}
	}
}