import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FrotaVeiculoModel } from '../entities-export';

@Entity({ name: 'frota_multa_controle' })
export class FrotaMultaControleModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_multa' }) 
	dataMulta: Date; 

	@Column({ name: 'pontos' }) 
	pontos: number; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FrotaVeiculoModel, frotaVeiculoModel => frotaVeiculoModel.frotaMultaControleModelList)
	@JoinColumn({ name: 'id_frota_veiculo' })
	frotaVeiculoModel: FrotaVeiculoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataMulta = jsonObj['dataMulta'];
			this.pontos = jsonObj['pontos'];
			this.valor = jsonObj['valor'];
			this.observacao = jsonObj['observacao'];
		}
	}
}