export { FrotaVeiculoModule } from './module/frota-veiculo.module';
export { FrotaVeiculoTipoModule } from './module/frota-veiculo-tipo.module';
export { FrotaCombustivelTipoModule } from './module/frota-combustivel-tipo.module';
export { FrotaMotoristaModule } from './module/frota-motorista.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';

export { UsuarioTokenModule } from './module/usuario-token.module';
export { AuditoriaModule } from './module/auditoria.module';