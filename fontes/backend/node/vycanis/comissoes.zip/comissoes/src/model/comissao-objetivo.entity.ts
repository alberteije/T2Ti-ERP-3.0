import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ComissaoPerfilModel } from '../entities-export';

@Entity({ name: 'comissao_objetivo' })
export class ComissaoObjetivoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'taxa_pagamento', type: 'decimal', precision: 18, scale: 6 }) 
	taxaPagamento: number; 

	@Column({ name: 'valor_pagamento', type: 'decimal', precision: 18, scale: 6 }) 
	valorPagamento: number; 

	@Column({ name: 'valor_meta', type: 'decimal', precision: 18, scale: 6 }) 
	valorMeta: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 


	/**
	* Relations
	*/
	@OneToOne(() => ComissaoPerfilModel)
	@JoinColumn({ name: 'id_comissao_perfil' })
	comissaoPerfilModel: ComissaoPerfilModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.taxaPagamento = jsonObj['taxaPagamento'];
			this.valorPagamento = jsonObj['valorPagamento'];
			this.valorMeta = jsonObj['valorMeta'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
			if (jsonObj['comissaoPerfilModel'] != null) {
				this.comissaoPerfilModel = new ComissaoPerfilModel(jsonObj['comissaoPerfilModel']);
			}

		}
	}
}