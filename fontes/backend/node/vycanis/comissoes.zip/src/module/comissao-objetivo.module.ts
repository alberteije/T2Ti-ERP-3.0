import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ComissaoObjetivoController } from '../controller/comissao-objetivo.controller';
import { ComissaoObjetivoService } from '../service/comissao-objetivo.service';
import { ComissaoObjetivoModel } from '../model/comissao-objetivo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ComissaoObjetivoModel])],
    controllers: [ComissaoObjetivoController],
    providers: [ComissaoObjetivoService],
})
export class ComissaoObjetivoModule { }
