import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ComissaoObjetivoModel } from '../entities-export';

@Injectable()
export class ComissaoObjetivoService extends TypeOrmCrudService<ComissaoObjetivoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ComissaoObjetivoModel)
    private readonly repository: Repository<ComissaoObjetivoModel>
  ) {
    super(repository);
  }

	async save(comissaoObjetivoModel: ComissaoObjetivoModel): Promise<ComissaoObjetivoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(comissaoObjetivoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
