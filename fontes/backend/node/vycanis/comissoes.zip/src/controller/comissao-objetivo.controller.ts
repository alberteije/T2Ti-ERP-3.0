import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ComissaoObjetivoService } from '../service/comissao-objetivo.service';
import { ComissaoObjetivoModel } from '../model/comissao-objetivo.entity';

@Crud({
  model: {
    type: ComissaoObjetivoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('comissao-objetivo')
export class ComissaoObjetivoController implements CrudController<ComissaoObjetivoModel> {
  constructor(public service: ComissaoObjetivoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const comissaoObjetivoModel = new ComissaoObjetivoModel(jsonObj);
		const result = await this.service.save(comissaoObjetivoModel);
		return result;
	}  


}


















