import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { EtiquetaLayoutService } from '../service/etiqueta-layout.service';
import { EtiquetaLayoutModel } from '../model/etiqueta-layout.entity';

@Crud({
  model: {
    type: EtiquetaLayoutModel,
  },
  query: {
    join: {
			etiquetaTemplateModelList: { eager: true },
			etiquetaFormatoPapelModel: { eager: true },
    },
  },
})
@Controller('etiqueta-layout')
export class EtiquetaLayoutController implements CrudController<EtiquetaLayoutModel> {
  constructor(public service: EtiquetaLayoutService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const etiquetaLayout = new EtiquetaLayoutModel(jsonObj);
		const result = await this.service.save(etiquetaLayout, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const etiquetaLayout = new EtiquetaLayoutModel(jsonObj);
		const result = await this.service.save(etiquetaLayout, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}