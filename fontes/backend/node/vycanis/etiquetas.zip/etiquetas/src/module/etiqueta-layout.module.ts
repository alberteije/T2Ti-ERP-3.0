import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EtiquetaLayoutController } from '../controller/etiqueta-layout.controller';
import { EtiquetaLayoutService } from '../service/etiqueta-layout.service';
import { EtiquetaLayoutModel } from '../model/etiqueta-layout.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EtiquetaLayoutModel])],
    controllers: [EtiquetaLayoutController],
    providers: [EtiquetaLayoutService],
})
export class EtiquetaLayoutModule { }
