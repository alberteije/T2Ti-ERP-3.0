import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EtiquetaTemplateModel } from '../entities-export';
import { EtiquetaFormatoPapelModel } from '../entities-export';

@Entity({ name: 'etiqueta_layout' })
export class EtiquetaLayoutModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_fabricante' }) 
	codigoFabricante: string; 

	@Column({ name: 'quantidade' }) 
	quantidade: number; 

	@Column({ name: 'quantidade_horizontal' }) 
	quantidadeHorizontal: number; 

	@Column({ name: 'quantidade_vertical' }) 
	quantidadeVertical: number; 

	@Column({ name: 'margem_superior' }) 
	margemSuperior: number; 

	@Column({ name: 'margem_inferior' }) 
	margemInferior: number; 

	@Column({ name: 'margem_esquerda' }) 
	margemEsquerda: number; 

	@Column({ name: 'margem_direita' }) 
	margemDireita: number; 

	@Column({ name: 'espacamento_horizontal' }) 
	espacamentoHorizontal: number; 

	@Column({ name: 'espacamento_vertical' }) 
	espacamentoVertical: number; 


	/**
	* Relations
	*/
	@OneToMany(() => EtiquetaTemplateModel, etiquetaTemplateModel => etiquetaTemplateModel.etiquetaLayoutModel, { cascade: true })
	etiquetaTemplateModelList: EtiquetaTemplateModel[];

	@OneToOne(() => EtiquetaFormatoPapelModel)
	@JoinColumn({ name: 'id_formato_papel' })
	etiquetaFormatoPapelModel: EtiquetaFormatoPapelModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoFabricante = jsonObj['codigoFabricante'];
			this.quantidade = jsonObj['quantidade'];
			this.quantidadeHorizontal = jsonObj['quantidadeHorizontal'];
			this.quantidadeVertical = jsonObj['quantidadeVertical'];
			this.margemSuperior = jsonObj['margemSuperior'];
			this.margemInferior = jsonObj['margemInferior'];
			this.margemEsquerda = jsonObj['margemEsquerda'];
			this.margemDireita = jsonObj['margemDireita'];
			this.espacamentoHorizontal = jsonObj['espacamentoHorizontal'];
			this.espacamentoVertical = jsonObj['espacamentoVertical'];
			if (jsonObj['etiquetaFormatoPapelModel'] != null) {
				this.etiquetaFormatoPapelModel = new EtiquetaFormatoPapelModel(jsonObj['etiquetaFormatoPapelModel']);
			}

			this.etiquetaTemplateModelList = [];
			let etiquetaTemplateModelJsonList = jsonObj['etiquetaTemplateModelList'];
			if (etiquetaTemplateModelJsonList != null) {
				for (let i = 0; i < etiquetaTemplateModelJsonList.length; i++) {
					let obj = new EtiquetaTemplateModel(etiquetaTemplateModelJsonList[i]);
					this.etiquetaTemplateModelList.push(obj);
				}
			}

		}
	}
}