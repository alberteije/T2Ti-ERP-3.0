import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'usuario_token' })
export class UsuarioTokenModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'login' }) 
	login: string; 

	@Column({ name: 'token' }) 
	token: string; 

	@Column({ name: 'data_criacao' }) 
	dataCriacao: Date; 

	@Column({ name: 'hora_criacao' }) 
	horaCriacao: string; 

	@Column({ name: 'data_expiracao' }) 
	dataExpiracao: Date; 

	@Column({ name: 'hora_expiracao' }) 
	horaExpiracao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.login = jsonObj['login'];
			this.token = jsonObj['token'];
			this.dataCriacao = jsonObj['dataCriacao'];
			this.horaCriacao = jsonObj['horaCriacao'];
			this.dataExpiracao = jsonObj['dataExpiracao'];
			this.horaExpiracao = jsonObj['horaExpiracao'];
		}
	}
}