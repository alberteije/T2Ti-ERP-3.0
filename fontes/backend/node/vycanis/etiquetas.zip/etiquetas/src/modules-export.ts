export { EtiquetaLayoutModule } from './module/etiqueta-layout.module';
export { EtiquetaFormatoPapelModule } from './module/etiqueta-formato-papel.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';

export { UsuarioTokenModule } from './module/usuario-token.module';
export { AuditoriaModule } from './module/auditoria.module';