import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { EtiquetaLayoutModel } from '../entities-export';

@Injectable()
export class EtiquetaLayoutService extends TypeOrmCrudService<EtiquetaLayoutModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(EtiquetaLayoutModel) 
    private readonly repository: Repository<EtiquetaLayoutModel>,
  ) {
    super(repository);
  }

	async save(etiquetaLayoutModel: EtiquetaLayoutModel, operation: string): Promise<EtiquetaLayoutModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, etiquetaLayoutModel.id);
      }

      const resultObj = await queryRunner.manager.save(etiquetaLayoutModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(EtiquetaLayoutModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from etiqueta_template where id_etiqueta_layout=' + id); 

	}
	
}