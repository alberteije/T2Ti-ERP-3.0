import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EtiquetaFormatoPapelController } from '../controller/etiqueta-formato-papel.controller';
import { EtiquetaFormatoPapelService } from '../service/etiqueta-formato-papel.service';
import { EtiquetaFormatoPapelModel } from '../model/etiqueta-formato-papel.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EtiquetaFormatoPapelModel])],
    controllers: [EtiquetaFormatoPapelController],
    providers: [EtiquetaFormatoPapelService],
})
export class EtiquetaFormatoPapelModule { }
