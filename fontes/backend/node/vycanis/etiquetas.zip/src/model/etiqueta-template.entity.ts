import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EtiquetaLayoutModel } from '../entities-export';

@Entity({ name: 'etiqueta_template' })
export class EtiquetaTemplateModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tabela' }) 
	tabela: string; 

	@Column({ name: 'campo' }) 
	campo: string; 

	@Column({ name: 'formato' }) 
	formato: string; 

	@Column({ name: 'quantidade_repeticoes' }) 
	quantidadeRepeticoes: number; 

	@Column({ name: 'filtro' }) 
	filtro: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => EtiquetaLayoutModel, etiquetaLayoutModel => etiquetaLayoutModel.etiquetaTemplateModelList)
	@JoinColumn({ name: 'id_etiqueta_layout' })
	etiquetaLayoutModel: EtiquetaLayoutModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tabela = jsonObj['tabela'];
			this.campo = jsonObj['campo'];
			this.formato = jsonObj['formato'];
			this.quantidadeRepeticoes = jsonObj['quantidadeRepeticoes'];
			this.filtro = jsonObj['filtro'];
		}
	}
}