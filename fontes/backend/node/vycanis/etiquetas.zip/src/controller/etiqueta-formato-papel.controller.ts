import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EtiquetaFormatoPapelService } from '../service/etiqueta-formato-papel.service';
import { EtiquetaFormatoPapelModel } from '../model/etiqueta-formato-papel.entity';

@Crud({
  model: {
    type: EtiquetaFormatoPapelModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('etiqueta-formato-papel')
export class EtiquetaFormatoPapelController implements CrudController<EtiquetaFormatoPapelModel> {
  constructor(public service: EtiquetaFormatoPapelService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const etiquetaFormatoPapelModel = new EtiquetaFormatoPapelModel(jsonObj);
		const result = await this.service.save(etiquetaFormatoPapelModel);
		return result;
	}  


}


















