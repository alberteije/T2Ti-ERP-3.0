import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { ViewPessoaUsuarioModel } from '../model/view-pessoa-usuario.entity';
import { ObjetoLogin } from '../util/objeto.login';
import { Util } from '../util/util'

@Injectable()
export class LoginService extends TypeOrmCrudService<ViewPessoaUsuarioModel>{

    private key: string = "#Sua-chave-de-32-caracteres-aqui";

    constructor(
        @InjectRepository(ViewPessoaUsuarioModel) repository) { super(repository); }

    async login(usuario: ViewPessoaUsuarioModel) {
        const md5Senha = Util.md5String(usuario.login + usuario.senha);

        let user = await this.findOne({ where: { login: usuario.login, senha: md5Senha } });

        if (user != null) {
            let objetoLogin = new ObjetoLogin({});
            objetoLogin.token = Util.cifrar(this.gerarJwt(usuario.login));
            objetoLogin.user = Util.cifrar(JSON.stringify(user.toJSON()));
            return objetoLogin;
        }
        throw new UnauthorizedException();
    }

    gerarJwt(login: string) {
        const jwt = require('jsonwebtoken');
        return jwt.sign({ sub: login }, this.key);
    }

    verificarToken(token: string): boolean {
        try {
            const jwt = require('jsonwebtoken');
            let decoded = jwt.verify(token, this.key);    
            if (decoded != null) {
                return true;
            }
        } catch (error) {
            return false;
        }
        return false;
    }
}