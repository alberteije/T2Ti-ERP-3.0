import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BpeCabecalhoModel } from '../entities-export';

@Entity({ name: 'bpe_passagem' })
export class BpePassagemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_localidade_origem' }) 
	codigoLocalidadeOrigem: string; 

	@Column({ name: 'descricao_localidade_origem' }) 
	descricaoLocalidadeOrigem: string; 

	@Column({ name: 'codigo_localidade_destino' }) 
	codigoLocalidadeDestino: string; 

	@Column({ name: 'descricao_localidade_destino' }) 
	descricaoLocalidadeDestino: string; 

	@Column({ name: 'data_hora_embarque' }) 
	dataHoraEmbarque: Date; 

	@Column({ name: 'data_hora_validade' }) 
	dataHoraValidade: Date; 


	/**
	* Relations
	*/
	@ManyToOne(() => BpeCabecalhoModel, bpeCabecalhoModel => bpeCabecalhoModel.bpePassagemModelList)
	@JoinColumn({ name: 'id_bpe_cabecalho' })
	bpeCabecalhoModel: BpeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoLocalidadeOrigem = jsonObj['codigoLocalidadeOrigem'];
			this.descricaoLocalidadeOrigem = jsonObj['descricaoLocalidadeOrigem'];
			this.codigoLocalidadeDestino = jsonObj['codigoLocalidadeDestino'];
			this.descricaoLocalidadeDestino = jsonObj['descricaoLocalidadeDestino'];
			this.dataHoraEmbarque = jsonObj['dataHoraEmbarque'];
			this.dataHoraValidade = jsonObj['dataHoraValidade'];
		}
	}
}