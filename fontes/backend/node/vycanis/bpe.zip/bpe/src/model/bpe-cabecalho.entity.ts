import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BpeEmitenteModel } from '../entities-export';
import { BpePassageiroModel } from '../entities-export';
import { BpeCompradorModel } from '../entities-export';
import { BpeViagemModel } from '../entities-export';
import { BpeAgenciaModel } from '../entities-export';
import { BpePassagemModel } from '../entities-export';

@Entity({ name: 'bpe_cabecalho' })
export class BpeCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'uf_emitente' }) 
	ufEmitente: string; 

	@Column({ name: 'ambiente' }) 
	ambiente: string; 

	@Column({ name: 'modelo' }) 
	modelo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'codigo_numerico' }) 
	codigoNumerico: string; 

	@Column({ name: 'chave_acesso' }) 
	chaveAcesso: string; 

	@Column({ name: 'digito_chave_acesso' }) 
	digitoChaveAcesso: string; 

	@Column({ name: 'modal' }) 
	modal: string; 

	@Column({ name: 'data_hora_emissao' }) 
	dataHoraEmissao: Date; 

	@Column({ name: 'tipo_emissao' }) 
	tipoEmissao: string; 

	@Column({ name: 'versao_processo_emissao' }) 
	versaoProcessoEmissao: string; 

	@Column({ name: 'tipo_bpe' }) 
	tipoBpe: string; 

	@Column({ name: 'consumidor_presenca' }) 
	consumidorPresenca: string; 

	@Column({ name: 'uf_inicio_viagem' }) 
	ufInicioViagem: string; 

	@Column({ name: 'codigo_municipio_inicio_viagem' }) 
	codigoMunicipioInicioViagem: number; 

	@Column({ name: 'uf_fim_viagem' }) 
	ufFimViagem: string; 

	@Column({ name: 'codigo_municipio_fim_viagem' }) 
	codigoMunicipioFimViagem: number; 

	@Column({ name: 'valor_bilhete', type: 'decimal', precision: 18, scale: 6 }) 
	valorBilhete: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_pago', type: 'decimal', precision: 18, scale: 6 }) 
	valorPago: number; 

	@Column({ name: 'valor_troco', type: 'decimal', precision: 18, scale: 6 }) 
	valorTroco: number; 

	@Column({ name: 'tipo_desconto' }) 
	tipoDesconto: string; 

	@Column({ name: 'desconto_descricao' }) 
	descontoDescricao: string; 

	@Column({ name: 'desconto_concedido_outros' }) 
	descontoConcedidoOutros: string; 

	@Column({ name: 'forma_pagamento' }) 
	formaPagamento: string; 

	@Column({ name: 'forma_pagamento_outros' }) 
	formaPagamentoOutros: string; 

	@Column({ name: 'forma_pagamento_documento' }) 
	formaPagamentoDocumento: string; 

	@Column({ name: 'cst' }) 
	cst: string; 

	@Column({ name: 'base_calculo_icms', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcms: number; 

	@Column({ name: 'aliquota_icms', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcms: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'percentual_reducao_bc_icms', type: 'decimal', precision: 18, scale: 6 }) 
	percentualReducaoBcIcms: number; 

	@Column({ name: 'informacoes_add_fisco' }) 
	informacoesAddFisco: string; 


	/**
	* Relations
	*/
	@OneToMany(() => BpeEmitenteModel, bpeEmitenteModel => bpeEmitenteModel.bpeCabecalhoModel, { cascade: true })
	bpeEmitenteModelList: BpeEmitenteModel[];

	@OneToMany(() => BpePassageiroModel, bpePassageiroModel => bpePassageiroModel.bpeCabecalhoModel, { cascade: true })
	bpePassageiroModelList: BpePassageiroModel[];

	@OneToMany(() => BpeCompradorModel, bpeCompradorModel => bpeCompradorModel.bpeCabecalhoModel, { cascade: true })
	bpeCompradorModelList: BpeCompradorModel[];

	@OneToMany(() => BpeViagemModel, bpeViagemModel => bpeViagemModel.bpeCabecalhoModel, { cascade: true })
	bpeViagemModelList: BpeViagemModel[];

	@OneToMany(() => BpeAgenciaModel, bpeAgenciaModel => bpeAgenciaModel.bpeCabecalhoModel, { cascade: true })
	bpeAgenciaModelList: BpeAgenciaModel[];

	@OneToMany(() => BpePassagemModel, bpePassagemModel => bpePassagemModel.bpeCabecalhoModel, { cascade: true })
	bpePassagemModelList: BpePassagemModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ufEmitente = jsonObj['ufEmitente'];
			this.ambiente = jsonObj['ambiente'];
			this.modelo = jsonObj['modelo'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
			this.codigoNumerico = jsonObj['codigoNumerico'];
			this.chaveAcesso = jsonObj['chaveAcesso'];
			this.digitoChaveAcesso = jsonObj['digitoChaveAcesso'];
			this.modal = jsonObj['modal'];
			this.dataHoraEmissao = jsonObj['dataHoraEmissao'];
			this.tipoEmissao = jsonObj['tipoEmissao'];
			this.versaoProcessoEmissao = jsonObj['versaoProcessoEmissao'];
			this.tipoBpe = jsonObj['tipoBpe'];
			this.consumidorPresenca = jsonObj['consumidorPresenca'];
			this.ufInicioViagem = jsonObj['ufInicioViagem'];
			this.codigoMunicipioInicioViagem = jsonObj['codigoMunicipioInicioViagem'];
			this.ufFimViagem = jsonObj['ufFimViagem'];
			this.codigoMunicipioFimViagem = jsonObj['codigoMunicipioFimViagem'];
			this.valorBilhete = jsonObj['valorBilhete'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorPago = jsonObj['valorPago'];
			this.valorTroco = jsonObj['valorTroco'];
			this.tipoDesconto = jsonObj['tipoDesconto'];
			this.descontoDescricao = jsonObj['descontoDescricao'];
			this.descontoConcedidoOutros = jsonObj['descontoConcedidoOutros'];
			this.formaPagamento = jsonObj['formaPagamento'];
			this.formaPagamentoOutros = jsonObj['formaPagamentoOutros'];
			this.formaPagamentoDocumento = jsonObj['formaPagamentoDocumento'];
			this.cst = jsonObj['cst'];
			this.baseCalculoIcms = jsonObj['baseCalculoIcms'];
			this.aliquotaIcms = jsonObj['aliquotaIcms'];
			this.valorIcms = jsonObj['valorIcms'];
			this.percentualReducaoBcIcms = jsonObj['percentualReducaoBcIcms'];
			this.informacoesAddFisco = jsonObj['informacoesAddFisco'];
			this.bpeEmitenteModelList = [];
			let bpeEmitenteModelJsonList = jsonObj['bpeEmitenteModelList'];
			if (bpeEmitenteModelJsonList != null) {
				for (let i = 0; i < bpeEmitenteModelJsonList.length; i++) {
					let obj = new BpeEmitenteModel(bpeEmitenteModelJsonList[i]);
					this.bpeEmitenteModelList.push(obj);
				}
			}

			this.bpePassageiroModelList = [];
			let bpePassageiroModelJsonList = jsonObj['bpePassageiroModelList'];
			if (bpePassageiroModelJsonList != null) {
				for (let i = 0; i < bpePassageiroModelJsonList.length; i++) {
					let obj = new BpePassageiroModel(bpePassageiroModelJsonList[i]);
					this.bpePassageiroModelList.push(obj);
				}
			}

			this.bpeCompradorModelList = [];
			let bpeCompradorModelJsonList = jsonObj['bpeCompradorModelList'];
			if (bpeCompradorModelJsonList != null) {
				for (let i = 0; i < bpeCompradorModelJsonList.length; i++) {
					let obj = new BpeCompradorModel(bpeCompradorModelJsonList[i]);
					this.bpeCompradorModelList.push(obj);
				}
			}

			this.bpeViagemModelList = [];
			let bpeViagemModelJsonList = jsonObj['bpeViagemModelList'];
			if (bpeViagemModelJsonList != null) {
				for (let i = 0; i < bpeViagemModelJsonList.length; i++) {
					let obj = new BpeViagemModel(bpeViagemModelJsonList[i]);
					this.bpeViagemModelList.push(obj);
				}
			}

			this.bpeAgenciaModelList = [];
			let bpeAgenciaModelJsonList = jsonObj['bpeAgenciaModelList'];
			if (bpeAgenciaModelJsonList != null) {
				for (let i = 0; i < bpeAgenciaModelJsonList.length; i++) {
					let obj = new BpeAgenciaModel(bpeAgenciaModelJsonList[i]);
					this.bpeAgenciaModelList.push(obj);
				}
			}

			this.bpePassagemModelList = [];
			let bpePassagemModelJsonList = jsonObj['bpePassagemModelList'];
			if (bpePassagemModelJsonList != null) {
				for (let i = 0; i < bpePassagemModelJsonList.length; i++) {
					let obj = new BpePassagemModel(bpePassagemModelJsonList[i]);
					this.bpePassagemModelList.push(obj);
				}
			}

		}
	}
}