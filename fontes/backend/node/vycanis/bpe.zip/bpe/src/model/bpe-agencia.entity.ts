import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BpeCabecalhoModel } from '../entities-export';

@Entity({ name: 'bpe_agencia' })
export class BpeAgenciaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'telefone' }) 
	telefone: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: number; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'cep' }) 
	cep: string; 

	@Column({ name: 'codigo_pais' }) 
	codigoPais: number; 

	@Column({ name: 'nome_pais' }) 
	nomePais: string; 

	@Column({ name: 'email' }) 
	email: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => BpeCabecalhoModel, bpeCabecalhoModel => bpeCabecalhoModel.bpeAgenciaModelList)
	@JoinColumn({ name: 'id_bpe_cabecalho' })
	bpeCabecalhoModel: BpeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.nome = jsonObj['nome'];
			this.telefone = jsonObj['telefone'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
			this.uf = jsonObj['uf'];
			this.cep = jsonObj['cep'];
			this.codigoPais = jsonObj['codigoPais'];
			this.nomePais = jsonObj['nomePais'];
			this.email = jsonObj['email'];
		}
	}
}