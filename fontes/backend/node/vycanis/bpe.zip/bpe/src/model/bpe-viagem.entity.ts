import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BpeCabecalhoModel } from '../entities-export';

@Entity({ name: 'bpe_viagem' })
export class BpeViagemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_percurso' }) 
	codigoPercurso: string; 

	@Column({ name: 'descricao_percurso' }) 
	descricaoPercurso: string; 

	@Column({ name: 'tipo_viagem' }) 
	tipoViagem: string; 

	@Column({ name: 'tipo_servico' }) 
	tipoServico: string; 

	@Column({ name: 'tipo_acomodacao' }) 
	tipoAcomodacao: string; 

	@Column({ name: 'tipo_trecho' }) 
	tipoTrecho: string; 

	@Column({ name: 'data_hora_viagem' }) 
	dataHoraViagem: Date; 

	@Column({ name: 'data_hora_conexao' }) 
	dataHoraConexao: Date; 

	@Column({ name: 'prefixo_linha' }) 
	prefixoLinha: string; 

	@Column({ name: 'poltrona' }) 
	poltrona: string; 

	@Column({ name: 'plataforma' }) 
	plataforma: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => BpeCabecalhoModel, bpeCabecalhoModel => bpeCabecalhoModel.bpeViagemModelList)
	@JoinColumn({ name: 'id_bpe_cabecalho' })
	bpeCabecalhoModel: BpeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoPercurso = jsonObj['codigoPercurso'];
			this.descricaoPercurso = jsonObj['descricaoPercurso'];
			this.tipoViagem = jsonObj['tipoViagem'];
			this.tipoServico = jsonObj['tipoServico'];
			this.tipoAcomodacao = jsonObj['tipoAcomodacao'];
			this.tipoTrecho = jsonObj['tipoTrecho'];
			this.dataHoraViagem = jsonObj['dataHoraViagem'];
			this.dataHoraConexao = jsonObj['dataHoraConexao'];
			this.prefixoLinha = jsonObj['prefixoLinha'];
			this.poltrona = jsonObj['poltrona'];
			this.plataforma = jsonObj['plataforma'];
		}
	}
}