import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BpeCabecalhoModel } from '../entities-export';

@Entity({ name: 'bpe_passageiro' })
export class BpePassageiroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'tipo_documento_identificacao' }) 
	tipoDocumentoIdentificacao: string; 

	@Column({ name: 'numero_documento' }) 
	numeroDocumento: string; 

	@Column({ name: 'documento_outros_descricao' }) 
	documentoOutrosDescricao: string; 

	@Column({ name: 'data_nascimento' }) 
	dataNascimento: Date; 

	@Column({ name: 'telefone' }) 
	telefone: string; 

	@Column({ name: 'email' }) 
	email: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => BpeCabecalhoModel, bpeCabecalhoModel => bpeCabecalhoModel.bpePassageiroModelList)
	@JoinColumn({ name: 'id_bpe_cabecalho' })
	bpeCabecalhoModel: BpeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.cpf = jsonObj['cpf'];
			this.tipoDocumentoIdentificacao = jsonObj['tipoDocumentoIdentificacao'];
			this.numeroDocumento = jsonObj['numeroDocumento'];
			this.documentoOutrosDescricao = jsonObj['documentoOutrosDescricao'];
			this.dataNascimento = jsonObj['dataNascimento'];
			this.telefone = jsonObj['telefone'];
			this.email = jsonObj['email'];
		}
	}
}