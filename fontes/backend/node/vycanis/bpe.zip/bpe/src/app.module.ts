import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { BpeCabecalhoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			BpeCabecalhoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}
}