import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ViewControleAcessoModel } from '../entities-export';

@Injectable()
export class ViewControleAcessoService extends TypeOrmCrudService<ViewControleAcessoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ViewControleAcessoModel)
    private readonly repository: Repository<ViewControleAcessoModel>
  ) {
    super(repository);
  }

	async save(viewControleAcessoModel: ViewControleAcessoModel): Promise<ViewControleAcessoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(viewControleAcessoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
