import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { BpeCabecalhoModel } from '../entities-export';

@Injectable()
export class BpeCabecalhoService extends TypeOrmCrudService<BpeCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(BpeCabecalhoModel) 
    private readonly repository: Repository<BpeCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(bpeCabecalhoModel: BpeCabecalhoModel, operation: string): Promise<BpeCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, bpeCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(bpeCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(BpeCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from bpe_emitente where id_bpe_cabecalho=' + id); 

		await queryRunner.query('delete from bpe_passageiro where id_bpe_cabecalho=' + id); 

		await queryRunner.query('delete from bpe_comprador where id_bpe_cabecalho=' + id); 

		await queryRunner.query('delete from bpe_viagem where id_bpe_cabecalho=' + id); 

		await queryRunner.query('delete from bpe_agencia where id_bpe_cabecalho=' + id); 

		await queryRunner.query('delete from bpe_passagem where id_bpe_cabecalho=' + id); 

	}
	
}