import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BpeCabecalhoController } from '../controller/bpe-cabecalho.controller';
import { BpeCabecalhoService } from '../service/bpe-cabecalho.service';
import { BpeCabecalhoModel } from '../model/bpe-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([BpeCabecalhoModel])],
    controllers: [BpeCabecalhoController],
    providers: [BpeCabecalhoService],
})
export class BpeCabecalhoModule { }
