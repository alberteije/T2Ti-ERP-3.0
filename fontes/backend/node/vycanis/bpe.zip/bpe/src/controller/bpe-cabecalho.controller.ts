import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { BpeCabecalhoService } from '../service/bpe-cabecalho.service';
import { BpeCabecalhoModel } from '../model/bpe-cabecalho.entity';

@Crud({
  model: {
    type: BpeCabecalhoModel,
  },
  query: {
    join: {
			bpeEmitenteModelList: { eager: true },
			bpePassageiroModelList: { eager: true },
			bpeCompradorModelList: { eager: true },
			bpeViagemModelList: { eager: true },
			bpeAgenciaModelList: { eager: true },
			bpePassagemModelList: { eager: true },
    },
  },
})
@Controller('bpe-cabecalho')
export class BpeCabecalhoController implements CrudController<BpeCabecalhoModel> {
  constructor(public service: BpeCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const bpeCabecalho = new BpeCabecalhoModel(jsonObj);
		const result = await this.service.save(bpeCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const bpeCabecalho = new BpeCabecalhoModel(jsonObj);
		const result = await this.service.save(bpeCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}