import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { PessoaModule } from './modules-export';
import { ColaboradorModule } from './modules-export';
import { PapelModule } from './modules-export';
import { FuncaoModule } from './modules-export';
import { EstadoCivilModule } from './modules-export';
import { CargoModule } from './modules-export';
import { SetorModule } from './modules-export';
import { ColaboradorSituacaoModule } from './modules-export';
import { TipoAdmissaoModule } from './modules-export';
import { ColaboradorTipoModule } from './modules-export';
import { ProdutoGrupoModule } from './modules-export';
import { ProdutoSubgrupoModule } from './modules-export';
import { ProdutoMarcaModule } from './modules-export';
import { ProdutoUnidadeModule } from './modules-export';
import { ProdutoModule } from './modules-export';
import { BancoModule } from './modules-export';
import { BancoAgenciaModule } from './modules-export';
import { BancoContaCaixaModule } from './modules-export';
import { CepModule } from './modules-export';
import { UfModule } from './modules-export';
import { MunicipioModule } from './modules-export';
import { NcmModule } from './modules-export';
import { CfopModule } from './modules-export';
import { CstIcmsModule } from './modules-export';
import { CstIpiModule } from './modules-export';
import { CstCofinsModule } from './modules-export';
import { CstPisModule } from './modules-export';
import { CsosnModule } from './modules-export';
import { CnaeModule } from './modules-export';
import { PaisModule } from './modules-export';
import { NivelFormacaoModule } from './modules-export';
import { TabelaPrecoModule } from './modules-export';
import { TipoRelacionamentoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ComissaoPerfilModule } from './modules-export';
import { SindicatoModule } from './modules-export';
import { TributIcmsCustomCabModule } from './modules-export';
import { TributGrupoTributarioModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			PessoaModule,
			ColaboradorModule,
			PapelModule,
			FuncaoModule,
			EstadoCivilModule,
			CargoModule,
			SetorModule,
			ColaboradorSituacaoModule,
			TipoAdmissaoModule,
			ColaboradorTipoModule,
			ProdutoGrupoModule,
			ProdutoSubgrupoModule,
			ProdutoMarcaModule,
			ProdutoUnidadeModule,
			ProdutoModule,
			BancoModule,
			BancoAgenciaModule,
			BancoContaCaixaModule,
			CepModule,
			UfModule,
			MunicipioModule,
			NcmModule,
			CfopModule,
			CstIcmsModule,
			CstIpiModule,
			CstCofinsModule,
			CstPisModule,
			CsosnModule,
			CnaeModule,
			PaisModule,
			NivelFormacaoModule,
			TabelaPrecoModule,
			TipoRelacionamentoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ComissaoPerfilModule,
			SindicatoModule,
			TributIcmsCustomCabModule,
			TributGrupoTributarioModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}