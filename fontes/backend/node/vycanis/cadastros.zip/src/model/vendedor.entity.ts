import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ColaboradorModel } from '../entities-export';
import { ComissaoPerfilModel } from '../entities-export';

@Entity({ name: 'vendedor' })
export class VendedorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'comissao', type: 'decimal', precision: 18, scale: 6 }) 
	comissao: number; 

	@Column({ name: 'meta_venda', type: 'decimal', precision: 18, scale: 6 }) 
	metaVenda: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ColaboradorModel, colaboradorModel => colaboradorModel.vendedorModel)
	@JoinColumn({ name: 'id_colaborador' })
	colaboradorModel: ColaboradorModel;

	@OneToOne(() => ComissaoPerfilModel)
	@JoinColumn({ name: 'id_comissao_perfil' })
	comissaoPerfilModel: ComissaoPerfilModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.comissao = jsonObj['comissao'];
			this.metaVenda = jsonObj['metaVenda'];
			if (jsonObj['comissaoPerfilModel'] != null) {
				this.comissaoPerfilModel = new ComissaoPerfilModel(jsonObj['comissaoPerfilModel']);
			}

		}
	}
}