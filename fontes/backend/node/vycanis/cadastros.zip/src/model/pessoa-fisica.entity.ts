import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaModel } from '../entities-export';
import { EstadoCivilModel } from '../entities-export';
import { NivelFormacaoModel } from '../entities-export';

@Entity({ name: 'pessoa_fisica' })
export class PessoaFisicaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'rg' }) 
	rg: string; 

	@Column({ name: 'orgao_rg' }) 
	orgaoRg: string; 

	@Column({ name: 'data_emissao_rg' }) 
	dataEmissaoRg: Date; 

	@Column({ name: 'data_nascimento' }) 
	dataNascimento: Date; 

	@Column({ name: 'sexo' }) 
	sexo: string; 

	@Column({ name: 'raca' }) 
	raca: string; 

	@Column({ name: 'nacionalidade' }) 
	nacionalidade: string; 

	@Column({ name: 'naturalidade' }) 
	naturalidade: string; 

	@Column({ name: 'nome_pai' }) 
	nomePai: string; 

	@Column({ name: 'nome_mae' }) 
	nomeMae: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PessoaModel, pessoaModel => pessoaModel.pessoaFisicaModel)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;

	@OneToOne(() => EstadoCivilModel)
	@JoinColumn({ name: 'id_estado_civil' })
	estadoCivilModel: EstadoCivilModel;

	@OneToOne(() => NivelFormacaoModel)
	@JoinColumn({ name: 'id_nivel_formacao' })
	nivelFormacaoModel: NivelFormacaoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cpf = jsonObj['cpf'];
			this.rg = jsonObj['rg'];
			this.orgaoRg = jsonObj['orgaoRg'];
			this.dataEmissaoRg = jsonObj['dataEmissaoRg'];
			this.dataNascimento = jsonObj['dataNascimento'];
			this.sexo = jsonObj['sexo'];
			this.raca = jsonObj['raca'];
			this.nacionalidade = jsonObj['nacionalidade'];
			this.naturalidade = jsonObj['naturalidade'];
			this.nomePai = jsonObj['nomePai'];
			this.nomeMae = jsonObj['nomeMae'];
			if (jsonObj['estadoCivilModel'] != null) {
				this.estadoCivilModel = new EstadoCivilModel(jsonObj['estadoCivilModel']);
			}

			if (jsonObj['nivelFormacaoModel'] != null) {
				this.nivelFormacaoModel = new NivelFormacaoModel(jsonObj['nivelFormacaoModel']);
			}

		}
	}
}