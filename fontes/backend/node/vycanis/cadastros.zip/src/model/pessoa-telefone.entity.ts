import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaModel } from '../entities-export';

@Entity({ name: 'pessoa_telefone' })
export class PessoaTelefoneModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'numero' }) 
	numero: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PessoaModel, pessoaModel => pessoaModel.pessoaTelefoneModelList)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipo = jsonObj['tipo'];
			this.numero = jsonObj['numero'];
		}
	}
}