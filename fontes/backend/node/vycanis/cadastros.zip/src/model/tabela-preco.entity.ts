import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'tabela_preco' })
export class TabelaPrecoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'principal' }) 
	principal: string; 

	@Column({ name: 'coeficiente', type: 'decimal', precision: 10, scale: 2 }) 
	coeficiente: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.principal = jsonObj['principal'];
			this.coeficiente = jsonObj['coeficiente'];
		}
	}
}