import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { VendedorModel } from '../entities-export';
import { PessoaModel } from '../entities-export';
import { ColaboradorSituacaoModel } from '../entities-export';
import { ColaboradorTipoModel } from '../entities-export';
import { SetorModel } from '../entities-export';
import { CargoModel } from '../entities-export';
import { TipoAdmissaoModel } from '../entities-export';
import { ColaboradorRelacionamentoModel } from '../entities-export';
import { SindicatoModel } from '../entities-export';

@Entity({ name: 'colaborador' })
export class ColaboradorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'matricula' }) 
	matricula: string; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'data_admissao' }) 
	dataAdmissao: Date; 

	@Column({ name: 'data_demissao' }) 
	dataDemissao: Date; 

	@Column({ name: 'ctps_numero' }) 
	ctpsNumero: string; 

	@Column({ name: 'ctps_serie' }) 
	ctpsSerie: string; 

	@Column({ name: 'ctps_data_expedicao' }) 
	ctpsDataExpedicao: Date; 

	@Column({ name: 'ctps_uf' }) 
	ctpsUf: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => VendedorModel, vendedorModel => vendedorModel.colaboradorModel, { cascade: true })
	vendedorModel: VendedorModel;

	@OneToOne(() => PessoaModel)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;

	@OneToOne(() => ColaboradorSituacaoModel)
	@JoinColumn({ name: 'id_colaborador_situacao' })
	colaboradorSituacaoModel: ColaboradorSituacaoModel;

	@OneToOne(() => ColaboradorTipoModel)
	@JoinColumn({ name: 'id_colaborador_tipo' })
	colaboradorTipoModel: ColaboradorTipoModel;

	@OneToOne(() => SetorModel)
	@JoinColumn({ name: 'id_setor' })
	setorModel: SetorModel;

	@OneToOne(() => CargoModel)
	@JoinColumn({ name: 'id_cargo' })
	cargoModel: CargoModel;

	@OneToOne(() => TipoAdmissaoModel)
	@JoinColumn({ name: 'id_tipo_admissao' })
	tipoAdmissaoModel: TipoAdmissaoModel;

	@OneToMany(() => ColaboradorRelacionamentoModel, colaboradorRelacionamentoModel => colaboradorRelacionamentoModel.colaboradorModel, { cascade: true })
	colaboradorRelacionamentoModelList: ColaboradorRelacionamentoModel[];

	@OneToOne(() => SindicatoModel)
	@JoinColumn({ name: 'id_sindicato' })
	sindicatoModel: SindicatoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.matricula = jsonObj['matricula'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.dataAdmissao = jsonObj['dataAdmissao'];
			this.dataDemissao = jsonObj['dataDemissao'];
			this.ctpsNumero = jsonObj['ctpsNumero'];
			this.ctpsSerie = jsonObj['ctpsSerie'];
			this.ctpsDataExpedicao = jsonObj['ctpsDataExpedicao'];
			this.ctpsUf = jsonObj['ctpsUf'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['vendedorModel'] != null) {
				this.vendedorModel = new VendedorModel(jsonObj['vendedorModel']);
			}

			if (jsonObj['pessoaModel'] != null) {
				this.pessoaModel = new PessoaModel(jsonObj['pessoaModel']);
			}

			if (jsonObj['colaboradorSituacaoModel'] != null) {
				this.colaboradorSituacaoModel = new ColaboradorSituacaoModel(jsonObj['colaboradorSituacaoModel']);
			}

			if (jsonObj['colaboradorTipoModel'] != null) {
				this.colaboradorTipoModel = new ColaboradorTipoModel(jsonObj['colaboradorTipoModel']);
			}

			if (jsonObj['setorModel'] != null) {
				this.setorModel = new SetorModel(jsonObj['setorModel']);
			}

			if (jsonObj['cargoModel'] != null) {
				this.cargoModel = new CargoModel(jsonObj['cargoModel']);
			}

			if (jsonObj['tipoAdmissaoModel'] != null) {
				this.tipoAdmissaoModel = new TipoAdmissaoModel(jsonObj['tipoAdmissaoModel']);
			}

			if (jsonObj['sindicatoModel'] != null) {
				this.sindicatoModel = new SindicatoModel(jsonObj['sindicatoModel']);
			}

			this.colaboradorRelacionamentoModelList = [];
			let colaboradorRelacionamentoModelJsonList = jsonObj['colaboradorRelacionamentoModelList'];
			if (colaboradorRelacionamentoModelJsonList != null) {
				for (let i = 0; i < colaboradorRelacionamentoModelJsonList.length; i++) {
					let obj = new ColaboradorRelacionamentoModel(colaboradorRelacionamentoModelJsonList[i]);
					this.colaboradorRelacionamentoModelList.push(obj);
				}
			}

		}
	}
}