import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaModel } from '../entities-export';
import { TabelaPrecoModel } from '../entities-export';

@Entity({ name: 'cliente' })
export class ClienteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'desde' }) 
	desde: Date; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'limite_credito', type: 'decimal', precision: 18, scale: 6 }) 
	limiteCredito: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PessoaModel, pessoaModel => pessoaModel.clienteModel)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;

	@OneToOne(() => TabelaPrecoModel)
	@JoinColumn({ name: 'id_tabela_preco' })
	tabelaPrecoModel: TabelaPrecoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.desde = jsonObj['desde'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.limiteCredito = jsonObj['limiteCredito'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['tabelaPrecoModel'] != null) {
				this.tabelaPrecoModel = new TabelaPrecoModel(jsonObj['tabelaPrecoModel']);
			}

		}
	}
}