import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { UfModel } from '../entities-export';

@Entity({ name: 'municipio' })
export class MunicipioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'codigo_ibge' }) 
	codigoIbge: number; 

	@Column({ name: 'codigo_receita_federal' }) 
	codigoReceitaFederal: number; 

	@Column({ name: 'codigo_estadual' }) 
	codigoEstadual: number; 


	/**
	* Relations
	*/
	@OneToOne(() => UfModel)
	@JoinColumn({ name: 'id_uf' })
	ufModel: UfModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.codigoIbge = jsonObj['codigoIbge'];
			this.codigoReceitaFederal = jsonObj['codigoReceitaFederal'];
			this.codigoEstadual = jsonObj['codigoEstadual'];
			if (jsonObj['ufModel'] != null) {
				this.ufModel = new UfModel(jsonObj['ufModel']);
			}

		}
	}
}