import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaJuridicaModel } from '../entities-export';
import { FornecedorModel } from '../entities-export';
import { ClienteModel } from '../entities-export';
import { PessoaFisicaModel } from '../entities-export';
import { TransportadoraModel } from '../entities-export';
import { ContadorModel } from '../entities-export';
import { PessoaContatoModel } from '../entities-export';
import { PessoaTelefoneModel } from '../entities-export';
import { PessoaEnderecoModel } from '../entities-export';

@Entity({ name: 'pessoa' })
export class PessoaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'site' }) 
	site: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'eh_cliente' }) 
	ehCliente: string; 

	@Column({ name: 'eh_fornecedor' }) 
	ehFornecedor: string; 

	@Column({ name: 'eh_transportadora' }) 
	ehTransportadora: string; 

	@Column({ name: 'eh_colaborador' }) 
	ehColaborador: string; 

	@Column({ name: 'eh_contador' }) 
	ehContador: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PessoaJuridicaModel, pessoaJuridicaModel => pessoaJuridicaModel.pessoaModel, { cascade: true })
	pessoaJuridicaModel: PessoaJuridicaModel;

	@OneToOne(() => FornecedorModel, fornecedorModel => fornecedorModel.pessoaModel, { cascade: true })
	fornecedorModel: FornecedorModel;

	@OneToOne(() => ClienteModel, clienteModel => clienteModel.pessoaModel, { cascade: true })
	clienteModel: ClienteModel;

	@OneToOne(() => PessoaFisicaModel, pessoaFisicaModel => pessoaFisicaModel.pessoaModel, { cascade: true })
	pessoaFisicaModel: PessoaFisicaModel;

	@OneToOne(() => TransportadoraModel, transportadoraModel => transportadoraModel.pessoaModel, { cascade: true })
	transportadoraModel: TransportadoraModel;

	@OneToOne(() => ContadorModel, contadorModel => contadorModel.pessoaModel, { cascade: true })
	contadorModel: ContadorModel;

	@OneToMany(() => PessoaContatoModel, pessoaContatoModel => pessoaContatoModel.pessoaModel, { cascade: true })
	pessoaContatoModelList: PessoaContatoModel[];

	@OneToMany(() => PessoaTelefoneModel, pessoaTelefoneModel => pessoaTelefoneModel.pessoaModel, { cascade: true })
	pessoaTelefoneModelList: PessoaTelefoneModel[];

	@OneToMany(() => PessoaEnderecoModel, pessoaEnderecoModel => pessoaEnderecoModel.pessoaModel, { cascade: true })
	pessoaEnderecoModelList: PessoaEnderecoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.tipo = jsonObj['tipo'];
			this.site = jsonObj['site'];
			this.email = jsonObj['email'];
			this.ehCliente = jsonObj['ehCliente'];
			this.ehFornecedor = jsonObj['ehFornecedor'];
			this.ehTransportadora = jsonObj['ehTransportadora'];
			this.ehColaborador = jsonObj['ehColaborador'];
			this.ehContador = jsonObj['ehContador'];
			if (jsonObj['pessoaJuridicaModel'] != null) {
				this.pessoaJuridicaModel = new PessoaJuridicaModel(jsonObj['pessoaJuridicaModel']);
			}

			if (jsonObj['fornecedorModel'] != null) {
				this.fornecedorModel = new FornecedorModel(jsonObj['fornecedorModel']);
			}

			if (jsonObj['clienteModel'] != null) {
				this.clienteModel = new ClienteModel(jsonObj['clienteModel']);
			}

			if (jsonObj['pessoaFisicaModel'] != null) {
				this.pessoaFisicaModel = new PessoaFisicaModel(jsonObj['pessoaFisicaModel']);
			}

			if (jsonObj['transportadoraModel'] != null) {
				this.transportadoraModel = new TransportadoraModel(jsonObj['transportadoraModel']);
			}

			if (jsonObj['contadorModel'] != null) {
				this.contadorModel = new ContadorModel(jsonObj['contadorModel']);
			}

			this.pessoaContatoModelList = [];
			let pessoaContatoModelJsonList = jsonObj['pessoaContatoModelList'];
			if (pessoaContatoModelJsonList != null) {
				for (let i = 0; i < pessoaContatoModelJsonList.length; i++) {
					let obj = new PessoaContatoModel(pessoaContatoModelJsonList[i]);
					this.pessoaContatoModelList.push(obj);
				}
			}

			this.pessoaTelefoneModelList = [];
			let pessoaTelefoneModelJsonList = jsonObj['pessoaTelefoneModelList'];
			if (pessoaTelefoneModelJsonList != null) {
				for (let i = 0; i < pessoaTelefoneModelJsonList.length; i++) {
					let obj = new PessoaTelefoneModel(pessoaTelefoneModelJsonList[i]);
					this.pessoaTelefoneModelList.push(obj);
				}
			}

			this.pessoaEnderecoModelList = [];
			let pessoaEnderecoModelJsonList = jsonObj['pessoaEnderecoModelList'];
			if (pessoaEnderecoModelJsonList != null) {
				for (let i = 0; i < pessoaEnderecoModelJsonList.length; i++) {
					let obj = new PessoaEnderecoModel(pessoaEnderecoModelJsonList[i]);
					this.pessoaEnderecoModelList.push(obj);
				}
			}

		}
	}
}