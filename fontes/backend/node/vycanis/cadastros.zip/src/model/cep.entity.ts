import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'cep' })
export class CepModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'municipio' }) 
	municipio: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'codigo_ibge_municipio' }) 
	codigoIbgeMunicipio: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.logradouro = jsonObj['logradouro'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.municipio = jsonObj['municipio'];
			this.uf = jsonObj['uf'];
			this.codigoIbgeMunicipio = jsonObj['codigoIbgeMunicipio'];
		}
	}
}