import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaModel } from '../entities-export';

@Entity({ name: 'pessoa_contato' })
export class PessoaContatoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PessoaModel, pessoaModel => pessoaModel.pessoaContatoModelList)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.email = jsonObj['email'];
			this.observacao = jsonObj['observacao'];
		}
	}
}