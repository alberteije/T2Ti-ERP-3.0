import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstadoCivilController } from '../controller/estado-civil.controller';
import { EstadoCivilService } from '../service/estado-civil.service';
import { EstadoCivilModel } from '../model/estado-civil.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EstadoCivilModel])],
    controllers: [EstadoCivilController],
    providers: [EstadoCivilService],
})
export class EstadoCivilModule { }
