import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaisController } from '../controller/pais.controller';
import { PaisService } from '../service/pais.service';
import { PaisModel } from '../model/pais.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PaisModel])],
    controllers: [PaisController],
    providers: [PaisService],
})
export class PaisModule { }
