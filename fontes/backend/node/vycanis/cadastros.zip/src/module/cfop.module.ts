import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CfopController } from '../controller/cfop.controller';
import { CfopService } from '../service/cfop.service';
import { CfopModel } from '../model/cfop.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CfopModel])],
    controllers: [CfopController],
    providers: [CfopService],
})
export class CfopModule { }
