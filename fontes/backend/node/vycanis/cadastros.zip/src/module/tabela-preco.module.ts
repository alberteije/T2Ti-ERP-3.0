import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TabelaPrecoController } from '../controller/tabela-preco.controller';
import { TabelaPrecoService } from '../service/tabela-preco.service';
import { TabelaPrecoModel } from '../model/tabela-preco.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TabelaPrecoModel])],
    controllers: [TabelaPrecoController],
    providers: [TabelaPrecoService],
})
export class TabelaPrecoModule { }
