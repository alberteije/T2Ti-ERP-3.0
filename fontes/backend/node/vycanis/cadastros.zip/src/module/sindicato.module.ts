import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SindicatoController } from '../controller/sindicato.controller';
import { SindicatoService } from '../service/sindicato.service';
import { SindicatoModel } from '../model/sindicato.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SindicatoModel])],
    controllers: [SindicatoController],
    providers: [SindicatoService],
})
export class SindicatoModule { }
