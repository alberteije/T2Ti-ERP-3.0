import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MunicipioController } from '../controller/municipio.controller';
import { MunicipioService } from '../service/municipio.service';
import { MunicipioModel } from '../model/municipio.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MunicipioModel])],
    controllers: [MunicipioController],
    providers: [MunicipioService],
})
export class MunicipioModule { }
