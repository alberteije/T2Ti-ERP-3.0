import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TipoAdmissaoController } from '../controller/tipo-admissao.controller';
import { TipoAdmissaoService } from '../service/tipo-admissao.service';
import { TipoAdmissaoModel } from '../model/tipo-admissao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TipoAdmissaoModel])],
    controllers: [TipoAdmissaoController],
    providers: [TipoAdmissaoService],
})
export class TipoAdmissaoModule { }
