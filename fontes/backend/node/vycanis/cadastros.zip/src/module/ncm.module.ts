import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NcmController } from '../controller/ncm.controller';
import { NcmService } from '../service/ncm.service';
import { NcmModel } from '../model/ncm.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NcmModel])],
    controllers: [NcmController],
    providers: [NcmService],
})
export class NcmModule { }
