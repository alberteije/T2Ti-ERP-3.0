import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ComissaoPerfilController } from '../controller/comissao-perfil.controller';
import { ComissaoPerfilService } from '../service/comissao-perfil.service';
import { ComissaoPerfilModel } from '../model/comissao-perfil.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ComissaoPerfilModel])],
    controllers: [ComissaoPerfilController],
    providers: [ComissaoPerfilService],
})
export class ComissaoPerfilModule { }
