import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ColaboradorSituacaoController } from '../controller/colaborador-situacao.controller';
import { ColaboradorSituacaoService } from '../service/colaborador-situacao.service';
import { ColaboradorSituacaoModel } from '../model/colaborador-situacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ColaboradorSituacaoModel])],
    controllers: [ColaboradorSituacaoController],
    providers: [ColaboradorSituacaoService],
})
export class ColaboradorSituacaoModule { }
