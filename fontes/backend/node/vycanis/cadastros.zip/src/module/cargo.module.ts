import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CargoController } from '../controller/cargo.controller';
import { CargoService } from '../service/cargo.service';
import { CargoModel } from '../model/cargo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CargoModel])],
    controllers: [CargoController],
    providers: [CargoService],
})
export class CargoModule { }
