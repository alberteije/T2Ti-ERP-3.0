import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BancoContaCaixaController } from '../controller/banco-conta-caixa.controller';
import { BancoContaCaixaService } from '../service/banco-conta-caixa.service';
import { BancoContaCaixaModel } from '../model/banco-conta-caixa.entity';

@Module({
    imports: [TypeOrmModule.forFeature([BancoContaCaixaModel])],
    controllers: [BancoContaCaixaController],
    providers: [BancoContaCaixaService],
})
export class BancoContaCaixaModule { }
