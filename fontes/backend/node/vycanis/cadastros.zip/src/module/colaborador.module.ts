import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ColaboradorController } from '../controller/colaborador.controller';
import { ColaboradorService } from '../service/colaborador.service';
import { ColaboradorModel } from '../model/colaborador.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ColaboradorModel])],
    controllers: [ColaboradorController],
    providers: [ColaboradorService],
})
export class ColaboradorModule { }
