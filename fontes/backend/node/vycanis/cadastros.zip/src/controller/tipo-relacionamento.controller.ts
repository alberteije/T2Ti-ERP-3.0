import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TipoRelacionamentoService } from '../service/tipo-relacionamento.service';
import { TipoRelacionamentoModel } from '../model/tipo-relacionamento.entity';

@Crud({
  model: {
    type: TipoRelacionamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tipo-relacionamento')
export class TipoRelacionamentoController implements CrudController<TipoRelacionamentoModel> {
  constructor(public service: TipoRelacionamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tipoRelacionamentoModel = new TipoRelacionamentoModel(jsonObj);
		const result = await this.service.save(tipoRelacionamentoModel);
		return result;
	}  


}


















