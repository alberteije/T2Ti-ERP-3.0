import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SindicatoService } from '../service/sindicato.service';
import { SindicatoModel } from '../model/sindicato.entity';

@Crud({
  model: {
    type: SindicatoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('sindicato')
export class SindicatoController implements CrudController<SindicatoModel> {
  constructor(public service: SindicatoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const sindicatoModel = new SindicatoModel(jsonObj);
		const result = await this.service.save(sindicatoModel);
		return result;
	}  


}


















