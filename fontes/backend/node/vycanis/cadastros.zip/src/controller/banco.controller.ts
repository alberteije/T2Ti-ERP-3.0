import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { BancoService } from '../service/banco.service';
import { BancoModel } from '../model/banco.entity';

@Crud({
  model: {
    type: BancoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('banco')
export class BancoController implements CrudController<BancoModel> {
  constructor(public service: BancoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const bancoModel = new BancoModel(jsonObj);
		const result = await this.service.save(bancoModel);
		return result;
	}  


}


















