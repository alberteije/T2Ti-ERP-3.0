import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CstCofinsService } from '../service/cst-cofins.service';
import { CstCofinsModel } from '../model/cst-cofins.entity';

@Crud({
  model: {
    type: CstCofinsModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cst-cofins')
export class CstCofinsController implements CrudController<CstCofinsModel> {
  constructor(public service: CstCofinsService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cstCofinsModel = new CstCofinsModel(jsonObj);
		const result = await this.service.save(cstCofinsModel);
		return result;
	}  


}


















