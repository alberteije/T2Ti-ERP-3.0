import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ColaboradorTipoService } from '../service/colaborador-tipo.service';
import { ColaboradorTipoModel } from '../model/colaborador-tipo.entity';

@Crud({
  model: {
    type: ColaboradorTipoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('colaborador-tipo')
export class ColaboradorTipoController implements CrudController<ColaboradorTipoModel> {
  constructor(public service: ColaboradorTipoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const colaboradorTipoModel = new ColaboradorTipoModel(jsonObj);
		const result = await this.service.save(colaboradorTipoModel);
		return result;
	}  


}


















