import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NivelFormacaoService } from '../service/nivel-formacao.service';
import { NivelFormacaoModel } from '../model/nivel-formacao.entity';

@Crud({
  model: {
    type: NivelFormacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nivel-formacao')
export class NivelFormacaoController implements CrudController<NivelFormacaoModel> {
  constructor(public service: NivelFormacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nivelFormacaoModel = new NivelFormacaoModel(jsonObj);
		const result = await this.service.save(nivelFormacaoModel);
		return result;
	}  


}


















