import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CsosnService } from '../service/csosn.service';
import { CsosnModel } from '../model/csosn.entity';

@Crud({
  model: {
    type: CsosnModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('csosn')
export class CsosnController implements CrudController<CsosnModel> {
  constructor(public service: CsosnService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const csosnModel = new CsosnModel(jsonObj);
		const result = await this.service.save(csosnModel);
		return result;
	}  


}


















