import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CstIpiService } from '../service/cst-ipi.service';
import { CstIpiModel } from '../model/cst-ipi.entity';

@Crud({
  model: {
    type: CstIpiModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cst-ipi')
export class CstIpiController implements CrudController<CstIpiModel> {
  constructor(public service: CstIpiService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cstIpiModel = new CstIpiModel(jsonObj);
		const result = await this.service.save(cstIpiModel);
		return result;
	}  


}


















