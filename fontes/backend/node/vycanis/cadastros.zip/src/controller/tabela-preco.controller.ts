import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TabelaPrecoService } from '../service/tabela-preco.service';
import { TabelaPrecoModel } from '../model/tabela-preco.entity';

@Crud({
  model: {
    type: TabelaPrecoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tabela-preco')
export class TabelaPrecoController implements CrudController<TabelaPrecoModel> {
  constructor(public service: TabelaPrecoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tabelaPrecoModel = new TabelaPrecoModel(jsonObj);
		const result = await this.service.save(tabelaPrecoModel);
		return result;
	}  


}


















