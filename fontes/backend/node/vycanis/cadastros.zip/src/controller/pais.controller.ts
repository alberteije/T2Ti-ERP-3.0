import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PaisService } from '../service/pais.service';
import { PaisModel } from '../model/pais.entity';

@Crud({
  model: {
    type: PaisModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('pais')
export class PaisController implements CrudController<PaisModel> {
  constructor(public service: PaisService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const paisModel = new PaisModel(jsonObj);
		const result = await this.service.save(paisModel);
		return result;
	}  


}


















