import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ColaboradorService } from '../service/colaborador.service';
import { ColaboradorModel } from '../model/colaborador.entity';

@Crud({
  model: {
    type: ColaboradorModel,
  },
  query: {
    join: {
			vendedorModel: { eager: true },
			pessoaModel: { eager: true },
			colaboradorSituacaoModel: { eager: true },
			colaboradorTipoModel: { eager: true },
			setorModel: { eager: true },
			cargoModel: { eager: true },
			tipoAdmissaoModel: { eager: true },
			colaboradorRelacionamentoModelList: { eager: true },
			sindicatoModel: { eager: true },
    },
  },
})
@Controller('colaborador')
export class ColaboradorController implements CrudController<ColaboradorModel> {
  constructor(public service: ColaboradorService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const colaborador = new ColaboradorModel(jsonObj);
		const result = await this.service.save(colaborador, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const colaborador = new ColaboradorModel(jsonObj);
		const result = await this.service.save(colaborador, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}