import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CfopService } from '../service/cfop.service';
import { CfopModel } from '../model/cfop.entity';

@Crud({
  model: {
    type: CfopModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cfop')
export class CfopController implements CrudController<CfopModel> {
  constructor(public service: CfopService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cfopModel = new CfopModel(jsonObj);
		const result = await this.service.save(cfopModel);
		return result;
	}  


}


















