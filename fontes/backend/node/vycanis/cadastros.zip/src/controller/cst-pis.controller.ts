import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CstPisService } from '../service/cst-pis.service';
import { CstPisModel } from '../model/cst-pis.entity';

@Crud({
  model: {
    type: CstPisModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cst-pis')
export class CstPisController implements CrudController<CstPisModel> {
  constructor(public service: CstPisService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cstPisModel = new CstPisModel(jsonObj);
		const result = await this.service.save(cstPisModel);
		return result;
	}  


}


















