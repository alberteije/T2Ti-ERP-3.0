import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { MunicipioService } from '../service/municipio.service';
import { MunicipioModel } from '../model/municipio.entity';

@Crud({
  model: {
    type: MunicipioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('municipio')
export class MunicipioController implements CrudController<MunicipioModel> {
  constructor(public service: MunicipioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const municipioModel = new MunicipioModel(jsonObj);
		const result = await this.service.save(municipioModel);
		return result;
	}  


}


















