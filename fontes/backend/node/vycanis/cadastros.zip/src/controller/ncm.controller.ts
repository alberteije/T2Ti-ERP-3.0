import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NcmService } from '../service/ncm.service';
import { NcmModel } from '../model/ncm.entity';

@Crud({
  model: {
    type: NcmModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ncm')
export class NcmController implements CrudController<NcmModel> {
  constructor(public service: NcmService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const ncmModel = new NcmModel(jsonObj);
		const result = await this.service.save(ncmModel);
		return result;
	}  


}


















