import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CepService } from '../service/cep.service';
import { CepModel } from '../model/cep.entity';

@Crud({
  model: {
    type: CepModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cep')
export class CepController implements CrudController<CepModel> {
  constructor(public service: CepService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cepModel = new CepModel(jsonObj);
		const result = await this.service.save(cepModel);
		return result;
	}  


}


















