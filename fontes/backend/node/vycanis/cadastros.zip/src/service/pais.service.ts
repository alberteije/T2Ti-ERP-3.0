import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PaisModel } from '../entities-export';

@Injectable()
export class PaisService extends TypeOrmCrudService<PaisModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PaisModel)
    private readonly repository: Repository<PaisModel>
  ) {
    super(repository);
  }

	async save(paisModel: PaisModel): Promise<PaisModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(paisModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
