import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { TipoAdmissaoModel } from '../entities-export';

@Injectable()
export class TipoAdmissaoService extends TypeOrmCrudService<TipoAdmissaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(TipoAdmissaoModel)
    private readonly repository: Repository<TipoAdmissaoModel>
  ) {
    super(repository);
  }

	async save(tipoAdmissaoModel: TipoAdmissaoModel): Promise<TipoAdmissaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(tipoAdmissaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
