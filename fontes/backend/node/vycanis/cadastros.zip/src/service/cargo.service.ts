import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CargoModel } from '../entities-export';

@Injectable()
export class CargoService extends TypeOrmCrudService<CargoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CargoModel)
    private readonly repository: Repository<CargoModel>
  ) {
    super(repository);
  }

	async save(cargoModel: CargoModel): Promise<CargoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cargoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
