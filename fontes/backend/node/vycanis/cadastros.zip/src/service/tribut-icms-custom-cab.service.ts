import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { TributIcmsCustomCabModel } from '../entities-export';

@Injectable()
export class TributIcmsCustomCabService extends TypeOrmCrudService<TributIcmsCustomCabModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(TributIcmsCustomCabModel)
    private readonly repository: Repository<TributIcmsCustomCabModel>
  ) {
    super(repository);
  }

	async save(tributIcmsCustomCabModel: TributIcmsCustomCabModel): Promise<TributIcmsCustomCabModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(tributIcmsCustomCabModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
