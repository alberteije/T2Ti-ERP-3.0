import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NcmModel } from '../entities-export';

@Injectable()
export class NcmService extends TypeOrmCrudService<NcmModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NcmModel)
    private readonly repository: Repository<NcmModel>
  ) {
    super(repository);
  }

	async save(ncmModel: NcmModel): Promise<NcmModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(ncmModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
