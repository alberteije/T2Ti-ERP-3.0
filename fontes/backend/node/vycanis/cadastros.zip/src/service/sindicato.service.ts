import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SindicatoModel } from '../entities-export';

@Injectable()
export class SindicatoService extends TypeOrmCrudService<SindicatoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SindicatoModel)
    private readonly repository: Repository<SindicatoModel>
  ) {
    super(repository);
  }

	async save(sindicatoModel: SindicatoModel): Promise<SindicatoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(sindicatoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
