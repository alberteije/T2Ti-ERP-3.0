import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CstCofinsModel } from '../entities-export';

@Injectable()
export class CstCofinsService extends TypeOrmCrudService<CstCofinsModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CstCofinsModel)
    private readonly repository: Repository<CstCofinsModel>
  ) {
    super(repository);
  }

	async save(cstCofinsModel: CstCofinsModel): Promise<CstCofinsModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cstCofinsModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
