import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { UfModel } from '../entities-export';

@Injectable()
export class UfService extends TypeOrmCrudService<UfModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(UfModel)
    private readonly repository: Repository<UfModel>
  ) {
    super(repository);
  }

	async save(ufModel: UfModel): Promise<UfModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(ufModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
