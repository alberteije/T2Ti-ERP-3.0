import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'sindicato' })
export class SindicatoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'codigo_banco' }) 
	codigoBanco: number; 

	@Column({ name: 'codigo_agencia' }) 
	codigoAgencia: number; 

	@Column({ name: 'conta_banco' }) 
	contaBanco: string; 

	@Column({ name: 'codigo_cedente' }) 
	codigoCedente: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'municipio_ibge' }) 
	municipioIbge: number; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'fone1' }) 
	fone1: string; 

	@Column({ name: 'fone2' }) 
	fone2: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'tipo_sindicato' }) 
	tipoSindicato: string; 

	@Column({ name: 'data_base' }) 
	dataBase: Date; 

	@Column({ name: 'piso_salarial', type: 'decimal', precision: 18, scale: 6 }) 
	pisoSalarial: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'classificacao_contabil_conta' }) 
	classificacaoContabilConta: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.codigoBanco = jsonObj['codigoBanco'];
			this.codigoAgencia = jsonObj['codigoAgencia'];
			this.contaBanco = jsonObj['contaBanco'];
			this.codigoCedente = jsonObj['codigoCedente'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.bairro = jsonObj['bairro'];
			this.municipioIbge = jsonObj['municipioIbge'];
			this.uf = jsonObj['uf'];
			this.fone1 = jsonObj['fone1'];
			this.fone2 = jsonObj['fone2'];
			this.email = jsonObj['email'];
			this.tipoSindicato = jsonObj['tipoSindicato'];
			this.dataBase = jsonObj['dataBase'];
			this.pisoSalarial = jsonObj['pisoSalarial'];
			this.cnpj = jsonObj['cnpj'];
			this.classificacaoContabilConta = jsonObj['classificacaoContabilConta'];
		}
	}
}