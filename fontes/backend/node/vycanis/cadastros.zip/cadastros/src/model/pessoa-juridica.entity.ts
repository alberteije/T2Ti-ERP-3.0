import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaModel } from '../entities-export';

@Entity({ name: 'pessoa_juridica' })
export class PessoaJuridicaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'nome_fantasia' }) 
	nomeFantasia: string; 

	@Column({ name: 'inscricao_estadual' }) 
	inscricaoEstadual: string; 

	@Column({ name: 'inscricao_municipal' }) 
	inscricaoMunicipal: string; 

	@Column({ name: 'data_constituicao' }) 
	dataConstituicao: Date; 

	@Column({ name: 'tipo_regime' }) 
	tipoRegime: string; 

	@Column({ name: 'crt' }) 
	crt: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PessoaModel, pessoaModel => pessoaModel.pessoaJuridicaModel)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.nomeFantasia = jsonObj['nomeFantasia'];
			this.inscricaoEstadual = jsonObj['inscricaoEstadual'];
			this.inscricaoMunicipal = jsonObj['inscricaoMunicipal'];
			this.dataConstituicao = jsonObj['dataConstituicao'];
			this.tipoRegime = jsonObj['tipoRegime'];
			this.crt = jsonObj['crt'];
		}
	}
}