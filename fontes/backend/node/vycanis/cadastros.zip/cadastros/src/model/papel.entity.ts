import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PapelFuncaoModel } from '../entities-export';
import { UsuarioModel } from '../entities-export';

@Entity({ name: 'papel' })
export class PapelModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descrica' }) 
	descrica: string; 


	/**
	* Relations
	*/
	@OneToMany(() => PapelFuncaoModel, papelFuncaoModel => papelFuncaoModel.papelModel, { cascade: true })
	papelFuncaoModelList: PapelFuncaoModel[];

	@OneToMany(() => UsuarioModel, usuarioModel => usuarioModel.papelModel, { cascade: true })
	usuarioModelList: UsuarioModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descrica = jsonObj['descrica'];
			this.papelFuncaoModelList = [];
			let papelFuncaoModelJsonList = jsonObj['papelFuncaoModelList'];
			if (papelFuncaoModelJsonList != null) {
				for (let i = 0; i < papelFuncaoModelJsonList.length; i++) {
					let obj = new PapelFuncaoModel(papelFuncaoModelJsonList[i]);
					this.papelFuncaoModelList.push(obj);
				}
			}

			this.usuarioModelList = [];
			let usuarioModelJsonList = jsonObj['usuarioModelList'];
			if (usuarioModelJsonList != null) {
				for (let i = 0; i < usuarioModelJsonList.length; i++) {
					let obj = new UsuarioModel(usuarioModelJsonList[i]);
					this.usuarioModelList.push(obj);
				}
			}

		}
	}
}