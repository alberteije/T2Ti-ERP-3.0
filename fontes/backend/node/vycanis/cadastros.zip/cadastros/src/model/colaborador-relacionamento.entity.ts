import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ColaboradorModel } from '../entities-export';
import { TipoRelacionamentoModel } from '../entities-export';

@Entity({ name: 'colaborador_relacionamento' })
export class ColaboradorRelacionamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'data_nascimento' }) 
	dataNascimento: Date; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'registro_matricula' }) 
	registroMatricula: string; 

	@Column({ name: 'registro_cartorio' }) 
	registroCartorio: string; 

	@Column({ name: 'registro_cartorio_numero' }) 
	registroCartorioNumero: string; 

	@Column({ name: 'registro_numero_livro' }) 
	registroNumeroLivro: string; 

	@Column({ name: 'registro_numero_folha' }) 
	registroNumeroFolha: string; 

	@Column({ name: 'data_entrega_documento' }) 
	dataEntregaDocumento: Date; 

	@Column({ name: 'salario_familia' }) 
	salarioFamilia: string; 

	@Column({ name: 'salario_familia_idade_limite' }) 
	salarioFamiliaIdadeLimite: number; 

	@Column({ name: 'salario_familia_data_fim' }) 
	salarioFamiliaDataFim: Date; 

	@Column({ name: 'imposto_renda_idade_limite' }) 
	impostoRendaIdadeLimite: number; 

	@Column({ name: 'imposto_renda_data_fim' }) 
	impostoRendaDataFim: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => ColaboradorModel, colaboradorModel => colaboradorModel.colaboradorRelacionamentoModelList)
	@JoinColumn({ name: 'id_colaborador' })
	colaboradorModel: ColaboradorModel;

	@OneToOne(() => TipoRelacionamentoModel)
	@JoinColumn({ name: 'id_tipo_relacionamento' })
	tipoRelacionamentoModel: TipoRelacionamentoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.dataNascimento = jsonObj['dataNascimento'];
			this.cpf = jsonObj['cpf'];
			this.registroMatricula = jsonObj['registroMatricula'];
			this.registroCartorio = jsonObj['registroCartorio'];
			this.registroCartorioNumero = jsonObj['registroCartorioNumero'];
			this.registroNumeroLivro = jsonObj['registroNumeroLivro'];
			this.registroNumeroFolha = jsonObj['registroNumeroFolha'];
			this.dataEntregaDocumento = jsonObj['dataEntregaDocumento'];
			this.salarioFamilia = jsonObj['salarioFamilia'];
			this.salarioFamiliaIdadeLimite = jsonObj['salarioFamiliaIdadeLimite'];
			this.salarioFamiliaDataFim = jsonObj['salarioFamiliaDataFim'];
			this.impostoRendaIdadeLimite = jsonObj['impostoRendaIdadeLimite'];
			this.impostoRendaDataFim = jsonObj['impostoRendaDataFim'];
			if (jsonObj['tipoRelacionamentoModel'] != null) {
				this.tipoRelacionamentoModel = new TipoRelacionamentoModel(jsonObj['tipoRelacionamentoModel']);
			}

		}
	}
}