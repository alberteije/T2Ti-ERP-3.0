import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaModel } from '../entities-export';

@Entity({ name: 'fornecedor' })
export class FornecedorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'desde' }) 
	desde: Date; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PessoaModel, pessoaModel => pessoaModel.fornecedorModel)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.desde = jsonObj['desde'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.observacao = jsonObj['observacao'];
		}
	}
}