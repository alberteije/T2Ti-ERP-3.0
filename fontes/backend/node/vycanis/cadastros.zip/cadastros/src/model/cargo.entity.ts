import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'cargo' })
export class CargoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'salario', type: 'decimal', precision: 18, scale: 6 }) 
	salario: number; 

	@Column({ name: 'cbo_1994' }) 
	cbo1994: string; 

	@Column({ name: 'cbo_2002' }) 
	cbo2002: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.salario = jsonObj['salario'];
			this.cbo1994 = jsonObj['cbo1994'];
			this.cbo2002 = jsonObj['cbo2002'];
		}
	}
}