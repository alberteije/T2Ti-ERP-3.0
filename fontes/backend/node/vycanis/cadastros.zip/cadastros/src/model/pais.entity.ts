import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'pais' })
export class PaisModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome_ptbr' }) 
	nomePtbr: string; 

	@Column({ name: 'nome_en' }) 
	nomeEn: string; 

	@Column({ name: 'codigo' }) 
	codigo: number; 

	@Column({ name: 'sigla2' }) 
	sigla2: string; 

	@Column({ name: 'sigla3' }) 
	sigla3: string; 

	@Column({ name: 'codigo_bacen' }) 
	codigoBacen: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nomePtbr = jsonObj['nomePtbr'];
			this.nomeEn = jsonObj['nomeEn'];
			this.codigo = jsonObj['codigo'];
			this.sigla2 = jsonObj['sigla2'];
			this.sigla3 = jsonObj['sigla3'];
			this.codigoBacen = jsonObj['codigoBacen'];
		}
	}
}