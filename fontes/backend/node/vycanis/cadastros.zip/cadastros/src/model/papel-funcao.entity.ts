import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PapelModel } from '../entities-export';
import { FuncaoModel } from '../entities-export';

@Entity({ name: 'papel_funcao' })
export class PapelFuncaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'habilitado' }) 
	habilitado: string; 

	@Column({ name: 'pode_inserir' }) 
	podeInserir: string; 

	@Column({ name: 'pode_alterar' }) 
	podeAlterar: string; 

	@Column({ name: 'pode_excluir' }) 
	podeExcluir: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PapelModel, papelModel => papelModel.papelFuncaoModelList)
	@JoinColumn({ name: 'id_papel' })
	papelModel: PapelModel;

	@ManyToOne(() => FuncaoModel, funcaoModel => funcaoModel.papelFuncaoModelList)
	@JoinColumn({ name: 'id_funcao' })
	funcaoModel: FuncaoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.habilitado = jsonObj['habilitado'];
			this.podeInserir = jsonObj['podeInserir'];
			this.podeAlterar = jsonObj['podeAlterar'];
			this.podeExcluir = jsonObj['podeExcluir'];
		}
	}
}