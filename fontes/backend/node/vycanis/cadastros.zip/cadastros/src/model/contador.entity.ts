import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PessoaModel } from '../entities-export';

@Entity({ name: 'contador' })
export class ContadorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'crc_inscricao' }) 
	crcInscricao: string; 

	@Column({ name: 'crc_uf' }) 
	crcUf: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PessoaModel, pessoaModel => pessoaModel.contadorModel)
	@JoinColumn({ name: 'id_pessoa' })
	pessoaModel: PessoaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.crcInscricao = jsonObj['crcInscricao'];
			this.crcUf = jsonObj['crcUf'];
		}
	}
}