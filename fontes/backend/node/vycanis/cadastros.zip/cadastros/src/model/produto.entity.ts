import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoMarcaModel } from '../entities-export';
import { ProdutoUnidadeModel } from '../entities-export';
import { ProdutoSubgrupoModel } from '../entities-export';
import { TributIcmsCustomCabModel } from '../entities-export';
import { TributGrupoTributarioModel } from '../entities-export';

@Entity({ name: 'produto' })
export class ProdutoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'gtin' }) 
	gtin: string; 

	@Column({ name: 'codigo_interno' }) 
	codigoInterno: string; 

	@Column({ name: 'valor_compra', type: 'decimal', precision: 18, scale: 6 }) 
	valorCompra: number; 

	@Column({ name: 'valor_venda', type: 'decimal', precision: 18, scale: 6 }) 
	valorVenda: number; 

	@Column({ name: 'codigo_ncm' }) 
	codigoNcm: string; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'estoque_minimo', type: 'decimal', precision: 18, scale: 6 }) 
	estoqueMinimo: number; 

	@Column({ name: 'estoque_maximo', type: 'decimal', precision: 18, scale: 6 }) 
	estoqueMaximo: number; 

	@Column({ name: 'quantidade_estoque', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeEstoque: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ProdutoMarcaModel)
	@JoinColumn({ name: 'id_produto_marca' })
	produtoMarcaModel: ProdutoMarcaModel;

	@OneToOne(() => ProdutoUnidadeModel)
	@JoinColumn({ name: 'id_produto_unidade' })
	produtoUnidadeModel: ProdutoUnidadeModel;

	@OneToOne(() => ProdutoSubgrupoModel)
	@JoinColumn({ name: 'id_produto_subgrupo' })
	produtoSubgrupoModel: ProdutoSubgrupoModel;

	@OneToOne(() => TributIcmsCustomCabModel)
	@JoinColumn({ name: 'id_tribut_icms_custom_cab' })
	tributIcmsCustomCabModel: TributIcmsCustomCabModel;

	@OneToOne(() => TributGrupoTributarioModel)
	@JoinColumn({ name: 'id_tribut_grupo_tributario' })
	tributGrupoTributarioModel: TributGrupoTributarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.gtin = jsonObj['gtin'];
			this.codigoInterno = jsonObj['codigoInterno'];
			this.valorCompra = jsonObj['valorCompra'];
			this.valorVenda = jsonObj['valorVenda'];
			this.codigoNcm = jsonObj['codigoNcm'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.estoqueMinimo = jsonObj['estoqueMinimo'];
			this.estoqueMaximo = jsonObj['estoqueMaximo'];
			this.quantidadeEstoque = jsonObj['quantidadeEstoque'];
			if (jsonObj['produtoMarcaModel'] != null) {
				this.produtoMarcaModel = new ProdutoMarcaModel(jsonObj['produtoMarcaModel']);
			}

			if (jsonObj['produtoUnidadeModel'] != null) {
				this.produtoUnidadeModel = new ProdutoUnidadeModel(jsonObj['produtoUnidadeModel']);
			}

			if (jsonObj['produtoSubgrupoModel'] != null) {
				this.produtoSubgrupoModel = new ProdutoSubgrupoModel(jsonObj['produtoSubgrupoModel']);
			}

			if (jsonObj['tributIcmsCustomCabModel'] != null) {
				this.tributIcmsCustomCabModel = new TributIcmsCustomCabModel(jsonObj['tributIcmsCustomCabModel']);
			}

			if (jsonObj['tributGrupoTributarioModel'] != null) {
				this.tributGrupoTributarioModel = new TributGrupoTributarioModel(jsonObj['tributGrupoTributarioModel']);
			}

		}
	}
}