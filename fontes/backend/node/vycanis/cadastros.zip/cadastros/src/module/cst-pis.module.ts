import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CstPisController } from '../controller/cst-pis.controller';
import { CstPisService } from '../service/cst-pis.service';
import { CstPisModel } from '../model/cst-pis.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CstPisModel])],
    controllers: [CstPisController],
    providers: [CstPisService],
})
export class CstPisModule { }
