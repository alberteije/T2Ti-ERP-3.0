import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CstIpiController } from '../controller/cst-ipi.controller';
import { CstIpiService } from '../service/cst-ipi.service';
import { CstIpiModel } from '../model/cst-ipi.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CstIpiModel])],
    controllers: [CstIpiController],
    providers: [CstIpiService],
})
export class CstIpiModule { }
