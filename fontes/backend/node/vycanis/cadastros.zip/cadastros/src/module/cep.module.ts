import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CepController } from '../controller/cep.controller';
import { CepService } from '../service/cep.service';
import { CepModel } from '../model/cep.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CepModel])],
    controllers: [CepController],
    providers: [CepService],
})
export class CepModule { }
