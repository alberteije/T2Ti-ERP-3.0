import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NivelFormacaoController } from '../controller/nivel-formacao.controller';
import { NivelFormacaoService } from '../service/nivel-formacao.service';
import { NivelFormacaoModel } from '../model/nivel-formacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NivelFormacaoModel])],
    controllers: [NivelFormacaoController],
    providers: [NivelFormacaoService],
})
export class NivelFormacaoModule { }
