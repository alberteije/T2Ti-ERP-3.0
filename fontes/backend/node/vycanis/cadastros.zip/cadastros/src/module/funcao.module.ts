import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FuncaoController } from '../controller/funcao.controller';
import { FuncaoService } from '../service/funcao.service';
import { FuncaoModel } from '../model/funcao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FuncaoModel])],
    controllers: [FuncaoController],
    providers: [FuncaoService],
})
export class FuncaoModule { }
