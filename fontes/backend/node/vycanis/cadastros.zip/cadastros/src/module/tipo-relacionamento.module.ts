import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TipoRelacionamentoController } from '../controller/tipo-relacionamento.controller';
import { TipoRelacionamentoService } from '../service/tipo-relacionamento.service';
import { TipoRelacionamentoModel } from '../model/tipo-relacionamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TipoRelacionamentoModel])],
    controllers: [TipoRelacionamentoController],
    providers: [TipoRelacionamentoService],
})
export class TipoRelacionamentoModule { }
