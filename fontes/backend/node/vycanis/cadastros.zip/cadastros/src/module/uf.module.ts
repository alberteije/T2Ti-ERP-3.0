import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UfController } from '../controller/uf.controller';
import { UfService } from '../service/uf.service';
import { UfModel } from '../model/uf.entity';

@Module({
    imports: [TypeOrmModule.forFeature([UfModel])],
    controllers: [UfController],
    providers: [UfService],
})
export class UfModule { }
