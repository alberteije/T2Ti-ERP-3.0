import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProdutoSubgrupoController } from '../controller/produto-subgrupo.controller';
import { ProdutoSubgrupoService } from '../service/produto-subgrupo.service';
import { ProdutoSubgrupoModel } from '../model/produto-subgrupo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ProdutoSubgrupoModel])],
    controllers: [ProdutoSubgrupoController],
    providers: [ProdutoSubgrupoService],
})
export class ProdutoSubgrupoModule { }
