import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CstCofinsController } from '../controller/cst-cofins.controller';
import { CstCofinsService } from '../service/cst-cofins.service';
import { CstCofinsModel } from '../model/cst-cofins.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CstCofinsModel])],
    controllers: [CstCofinsController],
    providers: [CstCofinsService],
})
export class CstCofinsModule { }
