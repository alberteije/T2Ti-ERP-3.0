import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CstIcmsController } from '../controller/cst-icms.controller';
import { CstIcmsService } from '../service/cst-icms.service';
import { CstIcmsModel } from '../model/cst-icms.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CstIcmsModel])],
    controllers: [CstIcmsController],
    providers: [CstIcmsService],
})
export class CstIcmsModule { }
