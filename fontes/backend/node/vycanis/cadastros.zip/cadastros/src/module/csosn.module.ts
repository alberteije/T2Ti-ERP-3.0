import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CsosnController } from '../controller/csosn.controller';
import { CsosnService } from '../service/csosn.service';
import { CsosnModel } from '../model/csosn.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CsosnModel])],
    controllers: [CsosnController],
    providers: [CsosnService],
})
export class CsosnModule { }
