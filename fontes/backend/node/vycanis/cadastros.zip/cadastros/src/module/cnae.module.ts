import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CnaeController } from '../controller/cnae.controller';
import { CnaeService } from '../service/cnae.service';
import { CnaeModel } from '../model/cnae.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CnaeModel])],
    controllers: [CnaeController],
    providers: [CnaeService],
})
export class CnaeModule { }
