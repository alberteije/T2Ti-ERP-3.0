import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ColaboradorTipoController } from '../controller/colaborador-tipo.controller';
import { ColaboradorTipoService } from '../service/colaborador-tipo.service';
import { ColaboradorTipoModel } from '../model/colaborador-tipo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ColaboradorTipoModel])],
    controllers: [ColaboradorTipoController],
    providers: [ColaboradorTipoService],
})
export class ColaboradorTipoModule { }
