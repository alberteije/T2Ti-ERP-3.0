import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CstPisModel } from '../entities-export';

@Injectable()
export class CstPisService extends TypeOrmCrudService<CstPisModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CstPisModel)
    private readonly repository: Repository<CstPisModel>
  ) {
    super(repository);
  }

	async save(cstPisModel: CstPisModel): Promise<CstPisModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cstPisModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
