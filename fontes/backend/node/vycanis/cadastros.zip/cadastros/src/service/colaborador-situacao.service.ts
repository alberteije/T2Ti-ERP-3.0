import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ColaboradorSituacaoModel } from '../entities-export';

@Injectable()
export class ColaboradorSituacaoService extends TypeOrmCrudService<ColaboradorSituacaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ColaboradorSituacaoModel)
    private readonly repository: Repository<ColaboradorSituacaoModel>
  ) {
    super(repository);
  }

	async save(colaboradorSituacaoModel: ColaboradorSituacaoModel): Promise<ColaboradorSituacaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(colaboradorSituacaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
