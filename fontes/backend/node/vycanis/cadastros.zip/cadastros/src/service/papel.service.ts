import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { PapelModel } from '../entities-export';

@Injectable()
export class PapelService extends TypeOrmCrudService<PapelModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(PapelModel) 
    private readonly repository: Repository<PapelModel>,
  ) {
    super(repository);
  }

	async save(papelModel: PapelModel, operation: string): Promise<PapelModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, papelModel.id);
      }

      const resultObj = await queryRunner.manager.save(papelModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(PapelModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from papel_funcao where id_papel=' + id); 

		await queryRunner.query('delete from usuario where id_papel=' + id); 

	}
	
}