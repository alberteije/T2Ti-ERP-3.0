import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CstIcmsModel } from '../entities-export';

@Injectable()
export class CstIcmsService extends TypeOrmCrudService<CstIcmsModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CstIcmsModel)
    private readonly repository: Repository<CstIcmsModel>
  ) {
    super(repository);
  }

	async save(cstIcmsModel: CstIcmsModel): Promise<CstIcmsModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cstIcmsModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
