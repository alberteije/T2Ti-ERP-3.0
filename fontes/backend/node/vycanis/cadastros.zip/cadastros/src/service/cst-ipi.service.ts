import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CstIpiModel } from '../entities-export';

@Injectable()
export class CstIpiService extends TypeOrmCrudService<CstIpiModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CstIpiModel)
    private readonly repository: Repository<CstIpiModel>
  ) {
    super(repository);
  }

	async save(cstIpiModel: CstIpiModel): Promise<CstIpiModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cstIpiModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
