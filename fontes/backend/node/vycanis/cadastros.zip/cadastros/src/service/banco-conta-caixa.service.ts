import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { BancoContaCaixaModel } from '../entities-export';

@Injectable()
export class BancoContaCaixaService extends TypeOrmCrudService<BancoContaCaixaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(BancoContaCaixaModel)
    private readonly repository: Repository<BancoContaCaixaModel>
  ) {
    super(repository);
  }

	async save(bancoContaCaixaModel: BancoContaCaixaModel): Promise<BancoContaCaixaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(bancoContaCaixaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
