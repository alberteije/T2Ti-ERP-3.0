import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EstadoCivilModel } from '../entities-export';

@Injectable()
export class EstadoCivilService extends TypeOrmCrudService<EstadoCivilModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EstadoCivilModel)
    private readonly repository: Repository<EstadoCivilModel>
  ) {
    super(repository);
  }

	async save(estadoCivilModel: EstadoCivilModel): Promise<EstadoCivilModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(estadoCivilModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
