import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CsosnModel } from '../entities-export';

@Injectable()
export class CsosnService extends TypeOrmCrudService<CsosnModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CsosnModel)
    private readonly repository: Repository<CsosnModel>
  ) {
    super(repository);
  }

	async save(csosnModel: CsosnModel): Promise<CsosnModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(csosnModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
