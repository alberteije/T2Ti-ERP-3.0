import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { PessoaModel } from '../entities-export';

@Injectable()
export class PessoaService extends TypeOrmCrudService<PessoaModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(PessoaModel) 
    private readonly repository: Repository<PessoaModel>,
  ) {
    super(repository);
  }

	async save(pessoaModel: PessoaModel, operation: string): Promise<PessoaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, pessoaModel.id);
      }

      const resultObj = await queryRunner.manager.save(pessoaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(PessoaModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from pessoa_juridica where id_pessoa=' + id); 

		await queryRunner.query('delete from fornecedor where id_pessoa=' + id); 

		await queryRunner.query('delete from cliente where id_pessoa=' + id); 

		await queryRunner.query('delete from pessoa_fisica where id_pessoa=' + id); 

		await queryRunner.query('delete from transportadora where id_pessoa=' + id); 

		await queryRunner.query('delete from contador where id_pessoa=' + id); 

		await queryRunner.query('delete from pessoa_contato where id_pessoa=' + id); 

		await queryRunner.query('delete from pessoa_telefone where id_pessoa=' + id); 

		await queryRunner.query('delete from pessoa_endereco where id_pessoa=' + id); 

	}
	
}