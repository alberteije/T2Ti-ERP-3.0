import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ColaboradorModel } from '../entities-export';

@Injectable()
export class ColaboradorService extends TypeOrmCrudService<ColaboradorModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ColaboradorModel) 
    private readonly repository: Repository<ColaboradorModel>,
  ) {
    super(repository);
  }

	async save(colaboradorModel: ColaboradorModel, operation: string): Promise<ColaboradorModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, colaboradorModel.id);
      }

      const resultObj = await queryRunner.manager.save(colaboradorModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ColaboradorModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from vendedor where id_colaborador=' + id); 

		await queryRunner.query('delete from colaborador_relacionamento where id_colaborador=' + id); 

	}
	
}