import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ProdutoService } from '../service/produto.service';
import { ProdutoModel } from '../model/produto.entity';

@Crud({
  model: {
    type: ProdutoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('produto')
export class ProdutoController implements CrudController<ProdutoModel> {
  constructor(public service: ProdutoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoModel = new ProdutoModel(jsonObj);
		const result = await this.service.save(produtoModel);
		return result;
	}  


}


















