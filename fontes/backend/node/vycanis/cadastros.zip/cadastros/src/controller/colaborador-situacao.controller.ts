import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ColaboradorSituacaoService } from '../service/colaborador-situacao.service';
import { ColaboradorSituacaoModel } from '../model/colaborador-situacao.entity';

@Crud({
  model: {
    type: ColaboradorSituacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('colaborador-situacao')
export class ColaboradorSituacaoController implements CrudController<ColaboradorSituacaoModel> {
  constructor(public service: ColaboradorSituacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const colaboradorSituacaoModel = new ColaboradorSituacaoModel(jsonObj);
		const result = await this.service.save(colaboradorSituacaoModel);
		return result;
	}  


}


















