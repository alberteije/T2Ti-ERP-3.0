import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CnaeService } from '../service/cnae.service';
import { CnaeModel } from '../model/cnae.entity';

@Crud({
  model: {
    type: CnaeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cnae')
export class CnaeController implements CrudController<CnaeModel> {
  constructor(public service: CnaeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cnaeModel = new CnaeModel(jsonObj);
		const result = await this.service.save(cnaeModel);
		return result;
	}  


}


















