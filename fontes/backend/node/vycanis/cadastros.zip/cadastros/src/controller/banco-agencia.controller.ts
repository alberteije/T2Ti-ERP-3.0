import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { BancoAgenciaService } from '../service/banco-agencia.service';
import { BancoAgenciaModel } from '../model/banco-agencia.entity';

@Crud({
  model: {
    type: BancoAgenciaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('banco-agencia')
export class BancoAgenciaController implements CrudController<BancoAgenciaModel> {
  constructor(public service: BancoAgenciaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const bancoAgenciaModel = new BancoAgenciaModel(jsonObj);
		const result = await this.service.save(bancoAgenciaModel);
		return result;
	}  


}


















