import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CargoService } from '../service/cargo.service';
import { CargoModel } from '../model/cargo.entity';

@Crud({
  model: {
    type: CargoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cargo')
export class CargoController implements CrudController<CargoModel> {
  constructor(public service: CargoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cargoModel = new CargoModel(jsonObj);
		const result = await this.service.save(cargoModel);
		return result;
	}  


}


















