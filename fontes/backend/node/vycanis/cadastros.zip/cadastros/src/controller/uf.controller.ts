import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { UfService } from '../service/uf.service';
import { UfModel } from '../model/uf.entity';

@Crud({
  model: {
    type: UfModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('uf')
export class UfController implements CrudController<UfModel> {
  constructor(public service: UfService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const ufModel = new UfModel(jsonObj);
		const result = await this.service.save(ufModel);
		return result;
	}  


}


















