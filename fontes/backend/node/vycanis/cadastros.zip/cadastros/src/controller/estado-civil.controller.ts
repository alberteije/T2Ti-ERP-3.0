import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EstadoCivilService } from '../service/estado-civil.service';
import { EstadoCivilModel } from '../model/estado-civil.entity';

@Crud({
  model: {
    type: EstadoCivilModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('estado-civil')
export class EstadoCivilController implements CrudController<EstadoCivilModel> {
  constructor(public service: EstadoCivilService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const estadoCivilModel = new EstadoCivilModel(jsonObj);
		const result = await this.service.save(estadoCivilModel);
		return result;
	}  


}


















