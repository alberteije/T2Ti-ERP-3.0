import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FuncaoService } from '../service/funcao.service';
import { FuncaoModel } from '../model/funcao.entity';

@Crud({
  model: {
    type: FuncaoModel,
  },
  query: {
    join: {
			papelFuncaoModelList: { eager: true },
    },
  },
})
@Controller('funcao')
export class FuncaoController implements CrudController<FuncaoModel> {
  constructor(public service: FuncaoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const funcao = new FuncaoModel(jsonObj);
		const result = await this.service.save(funcao, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const funcao = new FuncaoModel(jsonObj);
		const result = await this.service.save(funcao, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}