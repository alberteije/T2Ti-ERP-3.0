import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TributIcmsCustomCabService } from '../service/tribut-icms-custom-cab.service';
import { TributIcmsCustomCabModel } from '../model/tribut-icms-custom-cab.entity';

@Crud({
  model: {
    type: TributIcmsCustomCabModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tribut-icms-custom-cab')
export class TributIcmsCustomCabController implements CrudController<TributIcmsCustomCabModel> {
  constructor(public service: TributIcmsCustomCabService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tributIcmsCustomCabModel = new TributIcmsCustomCabModel(jsonObj);
		const result = await this.service.save(tributIcmsCustomCabModel);
		return result;
	}  


}


















