import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PessoaService } from '../service/pessoa.service';
import { PessoaModel } from '../model/pessoa.entity';

@Crud({
  model: {
    type: PessoaModel,
  },
  query: {
    join: {
			pessoaJuridicaModel: { eager: true },
			fornecedorModel: { eager: true },
			clienteModel: { eager: true },
			pessoaFisicaModel: { eager: true },
			transportadoraModel: { eager: true },
			contadorModel: { eager: true },
			pessoaContatoModelList: { eager: true },
			pessoaTelefoneModelList: { eager: true },
			pessoaEnderecoModelList: { eager: true },
    },
  },
})
@Controller('pessoa')
export class PessoaController implements CrudController<PessoaModel> {
  constructor(public service: PessoaService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const pessoa = new PessoaModel(jsonObj);
		const result = await this.service.save(pessoa, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pessoa = new PessoaModel(jsonObj);
		const result = await this.service.save(pessoa, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}