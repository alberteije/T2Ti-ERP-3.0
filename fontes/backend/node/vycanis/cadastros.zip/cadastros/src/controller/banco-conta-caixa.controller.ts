import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { BancoContaCaixaService } from '../service/banco-conta-caixa.service';
import { BancoContaCaixaModel } from '../model/banco-conta-caixa.entity';

@Crud({
  model: {
    type: BancoContaCaixaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('banco-conta-caixa')
export class BancoContaCaixaController implements CrudController<BancoContaCaixaModel> {
  constructor(public service: BancoContaCaixaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj);
		const result = await this.service.save(bancoContaCaixaModel);
		return result;
	}  


}


















