import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CstIcmsService } from '../service/cst-icms.service';
import { CstIcmsModel } from '../model/cst-icms.entity';

@Crud({
  model: {
    type: CstIcmsModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cst-icms')
export class CstIcmsController implements CrudController<CstIcmsModel> {
  constructor(public service: CstIcmsService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cstIcmsModel = new CstIcmsModel(jsonObj);
		const result = await this.service.save(cstIcmsModel);
		return result;
	}  


}


















