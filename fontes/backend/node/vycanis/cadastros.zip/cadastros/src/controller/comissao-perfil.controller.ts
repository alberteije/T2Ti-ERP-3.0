import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ComissaoPerfilService } from '../service/comissao-perfil.service';
import { ComissaoPerfilModel } from '../model/comissao-perfil.entity';

@Crud({
  model: {
    type: ComissaoPerfilModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('comissao-perfil')
export class ComissaoPerfilController implements CrudController<ComissaoPerfilModel> {
  constructor(public service: ComissaoPerfilService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const comissaoPerfilModel = new ComissaoPerfilModel(jsonObj);
		const result = await this.service.save(comissaoPerfilModel);
		return result;
	}  


}


















