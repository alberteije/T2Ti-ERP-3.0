import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TipoAdmissaoService } from '../service/tipo-admissao.service';
import { TipoAdmissaoModel } from '../model/tipo-admissao.entity';

@Crud({
  model: {
    type: TipoAdmissaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tipo-admissao')
export class TipoAdmissaoController implements CrudController<TipoAdmissaoModel> {
  constructor(public service: TipoAdmissaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tipoAdmissaoModel = new TipoAdmissaoModel(jsonObj);
		const result = await this.service.save(tipoAdmissaoModel);
		return result;
	}  


}


















