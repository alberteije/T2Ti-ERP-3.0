import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { TributIcmsCustomCabModel } from '../entities-export';

@Injectable()
export class TributIcmsCustomCabService extends TypeOrmCrudService<TributIcmsCustomCabModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(TributIcmsCustomCabModel) 
    private readonly repository: Repository<TributIcmsCustomCabModel>,
  ) {
    super(repository);
  }

	async save(tributIcmsCustomCabModel: TributIcmsCustomCabModel, operation: string): Promise<TributIcmsCustomCabModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, tributIcmsCustomCabModel.id);
      }

      const resultObj = await queryRunner.manager.save(tributIcmsCustomCabModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(TributIcmsCustomCabModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from tribut_icms_custom_det where id_tribut_icms_custom_cab=' + id); 

	}
	
}