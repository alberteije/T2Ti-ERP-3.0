import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TributGrupoTributarioService } from '../service/tribut-grupo-tributario.service';
import { TributGrupoTributarioModel } from '../model/tribut-grupo-tributario.entity';

@Crud({
  model: {
    type: TributGrupoTributarioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tribut-grupo-tributario')
export class TributGrupoTributarioController implements CrudController<TributGrupoTributarioModel> {
  constructor(public service: TributGrupoTributarioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tributGrupoTributarioModel = new TributGrupoTributarioModel(jsonObj);
		const result = await this.service.save(tributGrupoTributarioModel);
		return result;
	}  


}