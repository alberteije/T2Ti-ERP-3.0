import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TributIssService } from '../service/tribut-iss.service';
import { TributIssModel } from '../model/tribut-iss.entity';

@Crud({
  model: {
    type: TributIssModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tribut-iss')
export class TributIssController implements CrudController<TributIssModel> {
  constructor(public service: TributIssService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tributIssModel = new TributIssModel(jsonObj);
		const result = await this.service.save(tributIssModel);
		return result;
	}  


}


















