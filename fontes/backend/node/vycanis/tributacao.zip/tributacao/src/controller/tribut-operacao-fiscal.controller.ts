import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TributOperacaoFiscalService } from '../service/tribut-operacao-fiscal.service';
import { TributOperacaoFiscalModel } from '../model/tribut-operacao-fiscal.entity';

@Crud({
  model: {
    type: TributOperacaoFiscalModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tribut-operacao-fiscal')
export class TributOperacaoFiscalController implements CrudController<TributOperacaoFiscalModel> {
  constructor(public service: TributOperacaoFiscalService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tributOperacaoFiscalModel = new TributOperacaoFiscalModel(jsonObj);
		const result = await this.service.save(tributOperacaoFiscalModel);
		return result;
	}  


}


















