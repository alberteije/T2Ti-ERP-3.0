import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TributOperacaoFiscalController } from '../controller/tribut-operacao-fiscal.controller';
import { TributOperacaoFiscalService } from '../service/tribut-operacao-fiscal.service';
import { TributOperacaoFiscalModel } from '../model/tribut-operacao-fiscal.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TributOperacaoFiscalModel])],
    controllers: [TributOperacaoFiscalController],
    providers: [TributOperacaoFiscalService],
})
export class TributOperacaoFiscalModule { }
