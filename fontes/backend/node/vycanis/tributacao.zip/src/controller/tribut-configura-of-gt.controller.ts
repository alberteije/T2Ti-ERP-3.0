import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { TributConfiguraOfGtService } from '../service/tribut-configura-of-gt.service';
import { TributConfiguraOfGtModel } from '../model/tribut-configura-of-gt.entity';

@Crud({
  model: {
    type: TributConfiguraOfGtModel,
  },
  query: {
    join: {
			tributIpiModel: { eager: true },
			tributCofinsModel: { eager: true },
			tributPisModel: { eager: true },
			tributGrupoTributarioModel: { eager: true },
			tributOperacaoFiscalModel: { eager: true },
			tributIcmsUfModelList: { eager: true },
    },
  },
})
@Controller('tribut-configura-of-gt')
export class TributConfiguraOfGtController implements CrudController<TributConfiguraOfGtModel> {
  constructor(public service: TributConfiguraOfGtService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const tributConfiguraOfGt = new TributConfiguraOfGtModel(jsonObj);
		const result = await this.service.save(tributConfiguraOfGt, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tributConfiguraOfGt = new TributConfiguraOfGtModel(jsonObj);
		const result = await this.service.save(tributConfiguraOfGt, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}