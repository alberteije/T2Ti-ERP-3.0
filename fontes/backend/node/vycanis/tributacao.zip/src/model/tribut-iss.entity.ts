import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { TributOperacaoFiscalModel } from '../entities-export';

@Entity({ name: 'tribut_iss' })
export class TributIssModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'modalidade_base_calculo' }) 
	modalidadeBaseCalculo: string; 

	@Column({ name: 'codigo_tributacao' }) 
	codigoTributacao: string; 

	@Column({ name: 'item_lista_servico' }) 
	itemListaServico: number; 

	@Column({ name: 'porcento_base_calculo', type: 'decimal', precision: 18, scale: 6 }) 
	porcentoBaseCalculo: number; 

	@Column({ name: 'aliquota_porcento', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaPorcento: number; 

	@Column({ name: 'aliquota_unidade', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaUnidade: number; 

	@Column({ name: 'valor_preco_maximo', type: 'decimal', precision: 18, scale: 6 }) 
	valorPrecoMaximo: number; 

	@Column({ name: 'valor_pauta_fiscal', type: 'decimal', precision: 18, scale: 6 }) 
	valorPautaFiscal: number; 


	/**
	* Relations
	*/
	@OneToOne(() => TributOperacaoFiscalModel)
	@JoinColumn({ name: 'id_tribut_operacao_fiscal' })
	tributOperacaoFiscalModel: TributOperacaoFiscalModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.modalidadeBaseCalculo = jsonObj['modalidadeBaseCalculo'];
			this.codigoTributacao = jsonObj['codigoTributacao'];
			this.itemListaServico = jsonObj['itemListaServico'];
			this.porcentoBaseCalculo = jsonObj['porcentoBaseCalculo'];
			this.aliquotaPorcento = jsonObj['aliquotaPorcento'];
			this.aliquotaUnidade = jsonObj['aliquotaUnidade'];
			this.valorPrecoMaximo = jsonObj['valorPrecoMaximo'];
			this.valorPautaFiscal = jsonObj['valorPautaFiscal'];
			if (jsonObj['tributOperacaoFiscalModel'] != null) {
				this.tributOperacaoFiscalModel = new TributOperacaoFiscalModel(jsonObj['tributOperacaoFiscalModel']);
			}

		}
	}
}