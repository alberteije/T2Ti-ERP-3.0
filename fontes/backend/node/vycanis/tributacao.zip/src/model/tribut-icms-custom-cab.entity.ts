import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { TributIcmsCustomDetModel } from '../entities-export';

@Entity({ name: 'tribut_icms_custom_cab' })
export class TributIcmsCustomCabModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'origem_mercadoria' }) 
	origemMercadoria: string; 


	/**
	* Relations
	*/
	@OneToMany(() => TributIcmsCustomDetModel, tributIcmsCustomDetModel => tributIcmsCustomDetModel.tributIcmsCustomCabModel, { cascade: true })
	tributIcmsCustomDetModelList: TributIcmsCustomDetModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.origemMercadoria = jsonObj['origemMercadoria'];
			this.tributIcmsCustomDetModelList = [];
			let tributIcmsCustomDetModelJsonList = jsonObj['tributIcmsCustomDetModelList'];
			if (tributIcmsCustomDetModelJsonList != null) {
				for (let i = 0; i < tributIcmsCustomDetModelJsonList.length; i++) {
					let obj = new TributIcmsCustomDetModel(tributIcmsCustomDetModelJsonList[i]);
					this.tributIcmsCustomDetModelList.push(obj);
				}
			}

		}
	}
}