import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { TributConfiguraOfGtModel } from '../entities-export';

@Entity({ name: 'tribut_icms_uf' })
export class TributIcmsUfModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'uf_destino' }) 
	ufDestino: string; 

	@Column({ name: 'cst' }) 
	cst: string; 

	@Column({ name: 'csosn' }) 
	csosn: string; 

	@Column({ name: 'modalidade_bc' }) 
	modalidadeBc: string; 

	@Column({ name: 'cfop' }) 
	cfop: number; 

	@Column({ name: 'aliquota', type: 'decimal', precision: 18, scale: 6 }) 
	aliquota: number; 

	@Column({ name: 'valor_pauta', type: 'decimal', precision: 18, scale: 6 }) 
	valorPauta: number; 

	@Column({ name: 'valor_preco_maximo', type: 'decimal', precision: 18, scale: 6 }) 
	valorPrecoMaximo: number; 

	@Column({ name: 'mva', type: 'decimal', precision: 18, scale: 6 }) 
	mva: number; 

	@Column({ name: 'porcento_bc', type: 'decimal', precision: 18, scale: 6 }) 
	porcentoBc: number; 

	@Column({ name: 'modalidade_bc_st' }) 
	modalidadeBcSt: string; 

	@Column({ name: 'aliquota_interna_st', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaInternaSt: number; 

	@Column({ name: 'aliquota_interestadual_st', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaInterestadualSt: number; 

	@Column({ name: 'porcento_bc_st', type: 'decimal', precision: 18, scale: 6 }) 
	porcentoBcSt: number; 

	@Column({ name: 'aliquota_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcmsSt: number; 

	@Column({ name: 'valor_pauta_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorPautaSt: number; 

	@Column({ name: 'valor_preco_maximo_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorPrecoMaximoSt: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => TributConfiguraOfGtModel, tributConfiguraOfGtModel => tributConfiguraOfGtModel.tributIcmsUfModelList)
	@JoinColumn({ name: 'id_tribut_configura_of_gt' })
	tributConfiguraOfGtModel: TributConfiguraOfGtModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ufDestino = jsonObj['ufDestino'];
			this.cst = jsonObj['cst'];
			this.csosn = jsonObj['csosn'];
			this.modalidadeBc = jsonObj['modalidadeBc'];
			this.cfop = jsonObj['cfop'];
			this.aliquota = jsonObj['aliquota'];
			this.valorPauta = jsonObj['valorPauta'];
			this.valorPrecoMaximo = jsonObj['valorPrecoMaximo'];
			this.mva = jsonObj['mva'];
			this.porcentoBc = jsonObj['porcentoBc'];
			this.modalidadeBcSt = jsonObj['modalidadeBcSt'];
			this.aliquotaInternaSt = jsonObj['aliquotaInternaSt'];
			this.aliquotaInterestadualSt = jsonObj['aliquotaInterestadualSt'];
			this.porcentoBcSt = jsonObj['porcentoBcSt'];
			this.aliquotaIcmsSt = jsonObj['aliquotaIcmsSt'];
			this.valorPautaSt = jsonObj['valorPautaSt'];
			this.valorPrecoMaximoSt = jsonObj['valorPrecoMaximoSt'];
		}
	}
}