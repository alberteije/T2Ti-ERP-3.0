import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { TributIpiModel } from '../entities-export';
import { TributCofinsModel } from '../entities-export';
import { TributPisModel } from '../entities-export';
import { TributGrupoTributarioModel } from '../entities-export';
import { TributOperacaoFiscalModel } from '../entities-export';
import { TributIcmsUfModel } from '../entities-export';

@Entity({ name: 'tribut_configura_of_gt' })
export class TributConfiguraOfGtModel { 

	@PrimaryGeneratedColumn() 
	id: number; 


	/**
	* Relations
	*/
	@OneToOne(() => TributIpiModel, tributIpiModel => tributIpiModel.tributConfiguraOfGtModel, { cascade: true })
	tributIpiModel: TributIpiModel;

	@OneToOne(() => TributCofinsModel, tributCofinsModel => tributCofinsModel.tributConfiguraOfGtModel, { cascade: true })
	tributCofinsModel: TributCofinsModel;

	@OneToOne(() => TributPisModel, tributPisModel => tributPisModel.tributConfiguraOfGtModel, { cascade: true })
	tributPisModel: TributPisModel;

	@OneToOne(() => TributGrupoTributarioModel)
	@JoinColumn({ name: 'id_tribut_grupo_tributario' })
	tributGrupoTributarioModel: TributGrupoTributarioModel;

	@OneToOne(() => TributOperacaoFiscalModel)
	@JoinColumn({ name: 'id_tribut_operacao_fiscal' })
	tributOperacaoFiscalModel: TributOperacaoFiscalModel;

	@OneToMany(() => TributIcmsUfModel, tributIcmsUfModel => tributIcmsUfModel.tributConfiguraOfGtModel, { cascade: true })
	tributIcmsUfModelList: TributIcmsUfModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			if (jsonObj['tributIpiModel'] != null) {
				this.tributIpiModel = new TributIpiModel(jsonObj['tributIpiModel']);
			}

			if (jsonObj['tributCofinsModel'] != null) {
				this.tributCofinsModel = new TributCofinsModel(jsonObj['tributCofinsModel']);
			}

			if (jsonObj['tributPisModel'] != null) {
				this.tributPisModel = new TributPisModel(jsonObj['tributPisModel']);
			}

			if (jsonObj['tributGrupoTributarioModel'] != null) {
				this.tributGrupoTributarioModel = new TributGrupoTributarioModel(jsonObj['tributGrupoTributarioModel']);
			}

			if (jsonObj['tributOperacaoFiscalModel'] != null) {
				this.tributOperacaoFiscalModel = new TributOperacaoFiscalModel(jsonObj['tributOperacaoFiscalModel']);
			}

			this.tributIcmsUfModelList = [];
			let tributIcmsUfModelJsonList = jsonObj['tributIcmsUfModelList'];
			if (tributIcmsUfModelJsonList != null) {
				for (let i = 0; i < tributIcmsUfModelJsonList.length; i++) {
					let obj = new TributIcmsUfModel(tributIcmsUfModelJsonList[i]);
					this.tributIcmsUfModelList.push(obj);
				}
			}

		}
	}
}