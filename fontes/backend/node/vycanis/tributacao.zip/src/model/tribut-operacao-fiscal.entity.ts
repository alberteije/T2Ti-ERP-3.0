import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'tribut_operacao_fiscal' })
export class TributOperacaoFiscalModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cfop' }) 
	cfop: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'descricao_na_nf' }) 
	descricaoNaNf: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cfop = jsonObj['cfop'];
			this.descricao = jsonObj['descricao'];
			this.descricaoNaNf = jsonObj['descricaoNaNf'];
			this.observacao = jsonObj['observacao'];
		}
	}
}