import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TributConfiguraOfGtController } from '../controller/tribut-configura-of-gt.controller';
import { TributConfiguraOfGtService } from '../service/tribut-configura-of-gt.service';
import { TributConfiguraOfGtModel } from '../model/tribut-configura-of-gt.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TributConfiguraOfGtModel])],
    controllers: [TributConfiguraOfGtController],
    providers: [TributConfiguraOfGtService],
})
export class TributConfiguraOfGtModule { }
