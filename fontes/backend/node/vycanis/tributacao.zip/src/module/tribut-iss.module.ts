import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TributIssController } from '../controller/tribut-iss.controller';
import { TributIssService } from '../service/tribut-iss.service';
import { TributIssModel } from '../model/tribut-iss.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TributIssModel])],
    controllers: [TributIssController],
    providers: [TributIssService],
})
export class TributIssModule { }
