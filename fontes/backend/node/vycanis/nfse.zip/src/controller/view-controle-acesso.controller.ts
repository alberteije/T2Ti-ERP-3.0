import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ViewControleAcessoService } from '../service/view-controle-acesso.service';
import { ViewControleAcessoModel } from '../model/view-controle-acesso.entity';

@Crud({
  model: {
    type: ViewControleAcessoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('view-controle-acesso')
export class ViewControleAcessoController implements CrudController<ViewControleAcessoModel> {
  constructor(public service: ViewControleAcessoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const viewControleAcessoModel = new ViewControleAcessoModel(jsonObj);
		const result = await this.service.save(viewControleAcessoModel);
		return result;
	}  


}


















