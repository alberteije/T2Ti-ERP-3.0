import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfseDetalheModel } from '../entities-export';
import { NfseIntermediarioModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';
import { OsAberturaModel } from '../entities-export';

@Entity({ name: 'nfse_cabecalho' })
export class NfseCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'codigo_verificacao' }) 
	codigoVerificacao: string; 

	@Column({ name: 'data_hora_emissao' }) 
	dataHoraEmissao: Date; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'numero_substituida' }) 
	numeroSubstituida: string; 

	@Column({ name: 'natureza_operacao' }) 
	naturezaOperacao: string; 

	@Column({ name: 'regime_especial_tributacao' }) 
	regimeEspecialTributacao: string; 

	@Column({ name: 'optante_simples_nacional' }) 
	optanteSimplesNacional: string; 

	@Column({ name: 'incentivador_cultural' }) 
	incentivadorCultural: string; 

	@Column({ name: 'numero_rps' }) 
	numeroRps: string; 

	@Column({ name: 'serie_rps' }) 
	serieRps: string; 

	@Column({ name: 'tipo_rps' }) 
	tipoRps: string; 

	@Column({ name: 'data_emissao_rps' }) 
	dataEmissaoRps: Date; 

	@Column({ name: 'outras_informacoes' }) 
	outrasInformacoes: string; 


	/**
	* Relations
	*/
	@OneToMany(() => NfseDetalheModel, nfseDetalheModel => nfseDetalheModel.nfseCabecalhoModel, { cascade: true })
	nfseDetalheModelList: NfseDetalheModel[];

	@OneToMany(() => NfseIntermediarioModel, nfseIntermediarioModel => nfseIntermediarioModel.nfseCabecalhoModel, { cascade: true })
	nfseIntermediarioModelList: NfseIntermediarioModel[];

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;

	@OneToOne(() => OsAberturaModel)
	@JoinColumn({ name: 'id_os_abertura' })
	osAberturaModel: OsAberturaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.codigoVerificacao = jsonObj['codigoVerificacao'];
			this.dataHoraEmissao = jsonObj['dataHoraEmissao'];
			this.competencia = jsonObj['competencia'];
			this.numeroSubstituida = jsonObj['numeroSubstituida'];
			this.naturezaOperacao = jsonObj['naturezaOperacao'];
			this.regimeEspecialTributacao = jsonObj['regimeEspecialTributacao'];
			this.optanteSimplesNacional = jsonObj['optanteSimplesNacional'];
			this.incentivadorCultural = jsonObj['incentivadorCultural'];
			this.numeroRps = jsonObj['numeroRps'];
			this.serieRps = jsonObj['serieRps'];
			this.tipoRps = jsonObj['tipoRps'];
			this.dataEmissaoRps = jsonObj['dataEmissaoRps'];
			this.outrasInformacoes = jsonObj['outrasInformacoes'];
			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

			if (jsonObj['osAberturaModel'] != null) {
				this.osAberturaModel = new OsAberturaModel(jsonObj['osAberturaModel']);
			}

			this.nfseDetalheModelList = [];
			let nfseDetalheModelJsonList = jsonObj['nfseDetalheModelList'];
			if (nfseDetalheModelJsonList != null) {
				for (let i = 0; i < nfseDetalheModelJsonList.length; i++) {
					let obj = new NfseDetalheModel(nfseDetalheModelJsonList[i]);
					this.nfseDetalheModelList.push(obj);
				}
			}

			this.nfseIntermediarioModelList = [];
			let nfseIntermediarioModelJsonList = jsonObj['nfseIntermediarioModelList'];
			if (nfseIntermediarioModelJsonList != null) {
				for (let i = 0; i < nfseIntermediarioModelJsonList.length; i++) {
					let obj = new NfseIntermediarioModel(nfseIntermediarioModelJsonList[i]);
					this.nfseIntermediarioModelList.push(obj);
				}
			}

		}
	}
}