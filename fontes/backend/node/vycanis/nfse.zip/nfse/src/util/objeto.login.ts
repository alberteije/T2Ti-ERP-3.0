/**
   * classe transiente que armazena o objeto de login para ser retornado para o cliente
   */

export class ObjetoLogin {

    token: string;
    user: string;
	
	/**
	* Constructor
	*/
	constructor(objetoJson: object) {
		if (objetoJson != null) {
			this.token = objetoJson['token'];
			this.user = objetoJson['user'];
		}
	}
    
}