import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfseCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfse_intermediario' })
export class NfseIntermediarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'inscricao_municipal' }) 
	inscricaoMunicipal: string; 

	@Column({ name: 'razao' }) 
	razao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfseCabecalhoModel, nfseCabecalhoModel => nfseCabecalhoModel.nfseIntermediarioModelList)
	@JoinColumn({ name: 'id_nfse_cabecalho' })
	nfseCabecalhoModel: NfseCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.inscricaoMunicipal = jsonObj['inscricaoMunicipal'];
			this.razao = jsonObj['razao'];
		}
	}
}