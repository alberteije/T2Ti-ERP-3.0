import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OsAberturaModel } from '../entities-export';

@Entity({ name: 'os_status' })
export class OsStatusModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 


	/**
	* Relations
	*/
	@OneToMany(() => OsAberturaModel, osAberturaModel => osAberturaModel.osStatusModel, { cascade: true })
	osAberturaModelList: OsAberturaModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
			this.osAberturaModelList = [];
			let osAberturaModelJsonList = jsonObj['osAberturaModelList'];
			if (osAberturaModelJsonList != null) {
				for (let i = 0; i < osAberturaModelJsonList.length; i++) {
					let obj = new OsAberturaModel(osAberturaModelJsonList[i]);
					this.osAberturaModelList.push(obj);
				}
			}

		}
	}
}