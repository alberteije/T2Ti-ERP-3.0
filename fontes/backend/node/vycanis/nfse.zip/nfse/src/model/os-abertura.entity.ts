import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OsStatusModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';

@Entity({ name: 'os_abertura' })
export class OsAberturaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'hora_inicio' }) 
	horaInicio: string; 

	@Column({ name: 'data_previsao' }) 
	dataPrevisao: Date; 

	@Column({ name: 'hora_previsao' }) 
	horaPrevisao: string; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'hora_fim' }) 
	horaFim: string; 

	@Column({ name: 'nome_contato' }) 
	nomeContato: string; 

	@Column({ name: 'fone_contato' }) 
	foneContato: string; 

	@Column({ name: 'observacao_cliente' }) 
	observacaoCliente: string; 

	@Column({ name: 'observacao_abertura' }) 
	observacaoAbertura: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => OsStatusModel, osStatusModel => osStatusModel.osAberturaModelList)
	@JoinColumn({ name: 'id_os_status' })
	osStatusModel: OsStatusModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.dataInicio = jsonObj['dataInicio'];
			this.horaInicio = jsonObj['horaInicio'];
			this.dataPrevisao = jsonObj['dataPrevisao'];
			this.horaPrevisao = jsonObj['horaPrevisao'];
			this.dataFim = jsonObj['dataFim'];
			this.horaFim = jsonObj['horaFim'];
			this.nomeContato = jsonObj['nomeContato'];
			this.foneContato = jsonObj['foneContato'];
			this.observacaoCliente = jsonObj['observacaoCliente'];
			this.observacaoAbertura = jsonObj['observacaoAbertura'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

		}
	}
}