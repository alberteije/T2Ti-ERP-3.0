import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfseCabecalhoModel } from '../entities-export';
import { NfseListaServicoModel } from '../entities-export';

@Entity({ name: 'nfse_detalhe' })
export class NfseDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_cnae' }) 
	codigoCnae: string; 

	@Column({ name: 'codigo_tributacao_municipio' }) 
	codigoTributacaoMunicipio: string; 

	@Column({ name: 'valor_servicos', type: 'decimal', precision: 18, scale: 6 }) 
	valorServicos: number; 

	@Column({ name: 'valor_deducoes', type: 'decimal', precision: 18, scale: 6 }) 
	valorDeducoes: number; 

	@Column({ name: 'valor_pis', type: 'decimal', precision: 18, scale: 6 }) 
	valorPis: number; 

	@Column({ name: 'valor_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofins: number; 

	@Column({ name: 'valor_inss', type: 'decimal', precision: 18, scale: 6 }) 
	valorInss: number; 

	@Column({ name: 'valor_ir', type: 'decimal', precision: 18, scale: 6 }) 
	valorIr: number; 

	@Column({ name: 'valor_csll', type: 'decimal', precision: 18, scale: 6 }) 
	valorCsll: number; 

	@Column({ name: 'valor_base_calculo', type: 'decimal', precision: 18, scale: 6 }) 
	valorBaseCalculo: number; 

	@Column({ name: 'aliquota', type: 'decimal', precision: 18, scale: 6 }) 
	aliquota: number; 

	@Column({ name: 'valor_iss', type: 'decimal', precision: 18, scale: 6 }) 
	valorIss: number; 

	@Column({ name: 'valor_liquido', type: 'decimal', precision: 18, scale: 6 }) 
	valorLiquido: number; 

	@Column({ name: 'outras_retencoes', type: 'decimal', precision: 18, scale: 6 }) 
	outrasRetencoes: number; 

	@Column({ name: 'valor_credito', type: 'decimal', precision: 18, scale: 6 }) 
	valorCredito: number; 

	@Column({ name: 'iss_retido' }) 
	issRetido: string; 

	@Column({ name: 'valor_iss_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIssRetido: number; 

	@Column({ name: 'valor_desconto_condicionado', type: 'decimal', precision: 18, scale: 6 }) 
	valorDescontoCondicionado: number; 

	@Column({ name: 'valor_desconto_incondicionado', type: 'decimal', precision: 18, scale: 6 }) 
	valorDescontoIncondicionado: number; 

	@Column({ name: 'municipio_prestacao' }) 
	municipioPrestacao: number; 

	@Column({ name: 'discriminacao' }) 
	discriminacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfseCabecalhoModel, nfseCabecalhoModel => nfseCabecalhoModel.nfseDetalheModelList)
	@JoinColumn({ name: 'id_nfse_cabecalho' })
	nfseCabecalhoModel: NfseCabecalhoModel;

	@OneToOne(() => NfseListaServicoModel)
	@JoinColumn({ name: 'id_nfse_lista_servico' })
	nfseListaServicoModel: NfseListaServicoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoCnae = jsonObj['codigoCnae'];
			this.codigoTributacaoMunicipio = jsonObj['codigoTributacaoMunicipio'];
			this.valorServicos = jsonObj['valorServicos'];
			this.valorDeducoes = jsonObj['valorDeducoes'];
			this.valorPis = jsonObj['valorPis'];
			this.valorCofins = jsonObj['valorCofins'];
			this.valorInss = jsonObj['valorInss'];
			this.valorIr = jsonObj['valorIr'];
			this.valorCsll = jsonObj['valorCsll'];
			this.valorBaseCalculo = jsonObj['valorBaseCalculo'];
			this.aliquota = jsonObj['aliquota'];
			this.valorIss = jsonObj['valorIss'];
			this.valorLiquido = jsonObj['valorLiquido'];
			this.outrasRetencoes = jsonObj['outrasRetencoes'];
			this.valorCredito = jsonObj['valorCredito'];
			this.issRetido = jsonObj['issRetido'];
			this.valorIssRetido = jsonObj['valorIssRetido'];
			this.valorDescontoCondicionado = jsonObj['valorDescontoCondicionado'];
			this.valorDescontoIncondicionado = jsonObj['valorDescontoIncondicionado'];
			this.municipioPrestacao = jsonObj['municipioPrestacao'];
			this.discriminacao = jsonObj['discriminacao'];
			if (jsonObj['nfseListaServicoModel'] != null) {
				this.nfseListaServicoModel = new NfseListaServicoModel(jsonObj['nfseListaServicoModel']);
			}

		}
	}
}