import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NfseListaServicoModel } from '../entities-export';

@Injectable()
export class NfseListaServicoService extends TypeOrmCrudService<NfseListaServicoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NfseListaServicoModel)
    private readonly repository: Repository<NfseListaServicoModel>
  ) {
    super(repository);
  }

	async save(nfseListaServicoModel: NfseListaServicoModel): Promise<NfseListaServicoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(nfseListaServicoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
