import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { NfseCabecalhoModel } from '../entities-export';

@Injectable()
export class NfseCabecalhoService extends TypeOrmCrudService<NfseCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(NfseCabecalhoModel) 
    private readonly repository: Repository<NfseCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(nfseCabecalhoModel: NfseCabecalhoModel, operation: string): Promise<NfseCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, nfseCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(nfseCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(NfseCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from nfse_detalhe where id_nfse_cabecalho=' + id); 

		await queryRunner.query('delete from nfse_intermediario where id_nfse_cabecalho=' + id); 

	}
	
}