import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { OsStatusService } from '../service/os-status.service';
import { OsStatusModel } from '../model/os-status.entity';

@Crud({
  model: {
    type: OsStatusModel,
  },
  query: {
    join: {
			osAberturaModelList: { eager: true },
    },
  },
})
@Controller('os-status')
export class OsStatusController implements CrudController<OsStatusModel> {
  constructor(public service: OsStatusService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const osStatus = new OsStatusModel(jsonObj);
		const result = await this.service.save(osStatus, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const osStatus = new OsStatusModel(jsonObj);
		const result = await this.service.save(osStatus, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}