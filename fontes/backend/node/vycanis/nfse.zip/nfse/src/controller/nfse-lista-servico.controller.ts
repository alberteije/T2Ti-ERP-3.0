import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfseListaServicoService } from '../service/nfse-lista-servico.service';
import { NfseListaServicoModel } from '../model/nfse-lista-servico.entity';

@Crud({
  model: {
    type: NfseListaServicoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfse-lista-servico')
export class NfseListaServicoController implements CrudController<NfseListaServicoModel> {
  constructor(public service: NfseListaServicoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfseListaServicoModel = new NfseListaServicoModel(jsonObj);
		const result = await this.service.save(nfseListaServicoModel);
		return result;
	}  


}


















