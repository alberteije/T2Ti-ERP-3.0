import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfseListaServicoController } from '../controller/nfse-lista-servico.controller';
import { NfseListaServicoService } from '../service/nfse-lista-servico.service';
import { NfseListaServicoModel } from '../model/nfse-lista-servico.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfseListaServicoModel])],
    controllers: [NfseListaServicoController],
    providers: [NfseListaServicoService],
})
export class NfseListaServicoModule { }
