import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfseCabecalhoController } from '../controller/nfse-cabecalho.controller';
import { NfseCabecalhoService } from '../service/nfse-cabecalho.service';
import { NfseCabecalhoModel } from '../model/nfse-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfseCabecalhoModel])],
    controllers: [NfseCabecalhoController],
    providers: [NfseCabecalhoService],
})
export class NfseCabecalhoModule { }
