import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EfdContribuicoesController } from '../controller/efd-contribuicoes.controller';
import { EfdContribuicoesService } from '../service/efd-contribuicoes.service';
import { EfdContribuicoesModel } from '../model/efd-contribuicoes.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EfdContribuicoesModel])],
    controllers: [EfdContribuicoesController],
    providers: [EfdContribuicoesService],
})
export class EfdContribuicoesModule { }
