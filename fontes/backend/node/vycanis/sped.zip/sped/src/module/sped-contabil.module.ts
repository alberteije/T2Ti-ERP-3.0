import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SpedContabilController } from '../controller/sped-contabil.controller';
import { SpedContabilService } from '../service/sped-contabil.service';
import { SpedContabilModel } from '../model/sped-contabil.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SpedContabilModel])],
    controllers: [SpedContabilController],
    providers: [SpedContabilService],
})
export class SpedContabilModule { }
