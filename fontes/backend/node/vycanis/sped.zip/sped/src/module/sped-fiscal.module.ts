import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SpedFiscalController } from '../controller/sped-fiscal.controller';
import { SpedFiscalService } from '../service/sped-fiscal.service';
import { SpedFiscalModel } from '../model/sped-fiscal.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SpedFiscalModel])],
    controllers: [SpedFiscalController],
    providers: [SpedFiscalService],
})
export class SpedFiscalModule { }
