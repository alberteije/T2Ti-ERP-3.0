import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SpedFiscalService } from '../service/sped-fiscal.service';
import { SpedFiscalModel } from '../model/sped-fiscal.entity';

@Crud({
  model: {
    type: SpedFiscalModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('sped-fiscal')
export class SpedFiscalController implements CrudController<SpedFiscalModel> {
  constructor(public service: SpedFiscalService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const spedFiscalModel = new SpedFiscalModel(jsonObj);
		const result = await this.service.save(spedFiscalModel);
		return result;
	}  


}


















