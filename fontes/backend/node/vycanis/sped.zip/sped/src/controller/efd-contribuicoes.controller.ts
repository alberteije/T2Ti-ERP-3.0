import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EfdContribuicoesService } from '../service/efd-contribuicoes.service';
import { EfdContribuicoesModel } from '../model/efd-contribuicoes.entity';

@Crud({
  model: {
    type: EfdContribuicoesModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('efd-contribuicoes')
export class EfdContribuicoesController implements CrudController<EfdContribuicoesModel> {
  constructor(public service: EfdContribuicoesService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const efdContribuicoesModel = new EfdContribuicoesModel(jsonObj);
		const result = await this.service.save(efdContribuicoesModel);
		return result;
	}  


}


















