import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SpedContabilModel } from '../entities-export';

@Injectable()
export class SpedContabilService extends TypeOrmCrudService<SpedContabilModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SpedContabilModel)
    private readonly repository: Repository<SpedContabilModel>
  ) {
    super(repository);
  }

	async save(spedContabilModel: SpedContabilModel): Promise<SpedContabilModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(spedContabilModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
