import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'sintegra' })
export class SintegraModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'periodo_inicial' }) 
	periodoInicial: Date; 

	@Column({ name: 'periodo_final' }) 
	periodoFinal: Date; 

	@Column({ name: 'codigo_convenio' }) 
	codigoConvenio: string; 

	@Column({ name: 'inventario' }) 
	inventario: string; 

	@Column({ name: 'finalidade_arquivo' }) 
	finalidadeArquivo: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.periodoInicial = jsonObj['periodoInicial'];
			this.periodoFinal = jsonObj['periodoFinal'];
			this.codigoConvenio = jsonObj['codigoConvenio'];
			this.inventario = jsonObj['inventario'];
			this.finalidadeArquivo = jsonObj['finalidadeArquivo'];
		}
	}
}