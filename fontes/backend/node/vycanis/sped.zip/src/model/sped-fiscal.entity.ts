import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'sped_fiscal' })
export class SpedFiscalModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'periodo_inicial' }) 
	periodoInicial: Date; 

	@Column({ name: 'periodo_final' }) 
	periodoFinal: Date; 

	@Column({ name: 'perfil_apresentacao' }) 
	perfilApresentacao: string; 

	@Column({ name: 'finalidade_arquivo' }) 
	finalidadeArquivo: string; 

	@Column({ name: 'versao_layout' }) 
	versaoLayout: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.periodoInicial = jsonObj['periodoInicial'];
			this.periodoFinal = jsonObj['periodoFinal'];
			this.perfilApresentacao = jsonObj['perfilApresentacao'];
			this.finalidadeArquivo = jsonObj['finalidadeArquivo'];
			this.versaoLayout = jsonObj['versaoLayout'];
		}
	}
}