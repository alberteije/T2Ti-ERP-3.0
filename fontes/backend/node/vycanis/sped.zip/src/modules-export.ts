export { SpedContabilModule } from './module/sped-contabil.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { SpedFiscalModule } from './module/sped-fiscal.module';
export { SintegraModule } from './module/sintegra.module';
export { EfdContribuicoesModule } from './module/efd-contribuicoes.module';
export { EfdReinfModule } from './module/efd-reinf.module';
