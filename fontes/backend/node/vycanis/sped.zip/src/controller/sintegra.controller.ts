import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SintegraService } from '../service/sintegra.service';
import { SintegraModel } from '../model/sintegra.entity';

@Crud({
  model: {
    type: SintegraModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('sintegra')
export class SintegraController implements CrudController<SintegraModel> {
  constructor(public service: SintegraService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const sintegraModel = new SintegraModel(jsonObj);
		const result = await this.service.save(sintegraModel);
		return result;
	}  


}


















