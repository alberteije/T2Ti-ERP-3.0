import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SpedContabilService } from '../service/sped-contabil.service';
import { SpedContabilModel } from '../model/sped-contabil.entity';

@Crud({
  model: {
    type: SpedContabilModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('sped-contabil')
export class SpedContabilController implements CrudController<SpedContabilModel> {
  constructor(public service: SpedContabilService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const spedContabilModel = new SpedContabilModel(jsonObj);
		const result = await this.service.save(spedContabilModel);
		return result;
	}  


}


















