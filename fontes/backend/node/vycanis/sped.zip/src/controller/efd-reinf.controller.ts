import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EfdReinfService } from '../service/efd-reinf.service';
import { EfdReinfModel } from '../model/efd-reinf.entity';

@Crud({
  model: {
    type: EfdReinfModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('efd-reinf')
export class EfdReinfController implements CrudController<EfdReinfModel> {
  constructor(public service: EfdReinfService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const efdReinfModel = new EfdReinfModel(jsonObj);
		const result = await this.service.save(efdReinfModel);
		return result;
	}  


}


















