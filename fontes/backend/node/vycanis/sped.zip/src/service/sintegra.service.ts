import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SintegraModel } from '../entities-export';

@Injectable()
export class SintegraService extends TypeOrmCrudService<SintegraModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SintegraModel)
    private readonly repository: Repository<SintegraModel>
  ) {
    super(repository);
  }

	async save(sintegraModel: SintegraModel): Promise<SintegraModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(sintegraModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
