import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SintegraController } from '../controller/sintegra.controller';
import { SintegraService } from '../service/sintegra.service';
import { SintegraModel } from '../model/sintegra.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SintegraModel])],
    controllers: [SintegraController],
    providers: [SintegraService],
})
export class SintegraModule { }
