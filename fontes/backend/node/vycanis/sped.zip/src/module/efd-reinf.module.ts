import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EfdReinfController } from '../controller/efd-reinf.controller';
import { EfdReinfService } from '../service/efd-reinf.service';
import { EfdReinfModel } from '../model/efd-reinf.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EfdReinfModel])],
    controllers: [EfdReinfController],
    providers: [EfdReinfService],
})
export class EfdReinfModule { }
