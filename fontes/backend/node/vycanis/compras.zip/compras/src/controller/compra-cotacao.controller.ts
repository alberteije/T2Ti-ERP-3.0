import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { CompraCotacaoService } from '../service/compra-cotacao.service';
import { CompraCotacaoModel } from '../model/compra-cotacao.entity';

@Crud({
  model: {
    type: CompraCotacaoModel,
  },
  query: {
    join: {
			compraFornecedorCotacaoModelList: { eager: true },
			compraRequisicaoModel: { eager: true },
			compraCotacaoDetalheModelList: { eager: true },
    },
  },
})
@Controller('compra-cotacao')
export class CompraCotacaoController implements CrudController<CompraCotacaoModel> {
  constructor(public service: CompraCotacaoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const compraCotacao = new CompraCotacaoModel(jsonObj);
		const result = await this.service.save(compraCotacao, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const compraCotacao = new CompraCotacaoModel(jsonObj);
		const result = await this.service.save(compraCotacao, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}