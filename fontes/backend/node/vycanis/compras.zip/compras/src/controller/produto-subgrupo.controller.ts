import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ProdutoSubgrupoService } from '../service/produto-subgrupo.service';
import { ProdutoSubgrupoModel } from '../model/produto-subgrupo.entity';

@Crud({
  model: {
    type: ProdutoSubgrupoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('produto-subgrupo')
export class ProdutoSubgrupoController implements CrudController<ProdutoSubgrupoModel> {
  constructor(public service: ProdutoSubgrupoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoSubgrupoModel = new ProdutoSubgrupoModel(jsonObj);
		const result = await this.service.save(produtoSubgrupoModel);
		return result;
	}  


}


















