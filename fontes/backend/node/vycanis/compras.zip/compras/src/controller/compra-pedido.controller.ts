import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { CompraPedidoService } from '../service/compra-pedido.service';
import { CompraPedidoModel } from '../model/compra-pedido.entity';

@Crud({
  model: {
    type: CompraPedidoModel,
  },
  query: {
    join: {
			compraPedidoDetalheModelList: { eager: true },
			compraTipoPedidoModel: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
			viewPessoaFornecedorModel: { eager: true },
    },
  },
})
@Controller('compra-pedido')
export class CompraPedidoController implements CrudController<CompraPedidoModel> {
  constructor(public service: CompraPedidoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const compraPedido = new CompraPedidoModel(jsonObj);
		const result = await this.service.save(compraPedido, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const compraPedido = new CompraPedidoModel(jsonObj);
		const result = await this.service.save(compraPedido, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}