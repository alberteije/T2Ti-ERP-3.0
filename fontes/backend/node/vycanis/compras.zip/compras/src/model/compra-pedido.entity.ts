import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CompraPedidoDetalheModel } from '../entities-export';
import { CompraTipoPedidoModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { ViewPessoaFornecedorModel } from '../entities-export';

@Entity({ name: 'compra_pedido' })
export class CompraPedidoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_cotacao' }) 
	codigoCotacao: string; 

	@Column({ name: 'data_pedido' }) 
	dataPedido: Date; 

	@Column({ name: 'data_prevista_entrega' }) 
	dataPrevistaEntrega: Date; 

	@Column({ name: 'data_previsao_pagamento' }) 
	dataPrevisaoPagamento: Date; 

	@Column({ name: 'local_entrega' }) 
	localEntrega: string; 

	@Column({ name: 'local_cobranca' }) 
	localCobranca: string; 

	@Column({ name: 'contato' }) 
	contato: string; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'tipo_frete' }) 
	tipoFrete: string; 

	@Column({ name: 'forma_pagamento' }) 
	formaPagamento: string; 

	@Column({ name: 'base_calculo_icms', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcms: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'base_calculo_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcmsSt: number; 

	@Column({ name: 'valor_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsSt: number; 

	@Column({ name: 'valor_total_produtos', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalProdutos: number; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 

	@Column({ name: 'valor_seguro', type: 'decimal', precision: 18, scale: 6 }) 
	valorSeguro: number; 

	@Column({ name: 'valor_outras_despesas', type: 'decimal', precision: 18, scale: 6 }) 
	valorOutrasDespesas: number; 

	@Column({ name: 'valor_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpi: number; 

	@Column({ name: 'valor_total_nf', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalNf: number; 

	@Column({ name: 'quantidade_parcelas' }) 
	quantidadeParcelas: number; 

	@Column({ name: 'dia_primeiro_vencimento' }) 
	diaPrimeiroVencimento: string; 

	@Column({ name: 'intervalo_entre_parcelas' }) 
	intervaloEntreParcelas: number; 

	@Column({ name: 'dia_fixo_parcela' }) 
	diaFixoParcela: string; 


	/**
	* Relations
	*/
	@OneToMany(() => CompraPedidoDetalheModel, compraPedidoDetalheModel => compraPedidoDetalheModel.compraPedidoModel, { cascade: true })
	compraPedidoDetalheModelList: CompraPedidoDetalheModel[];

	@OneToOne(() => CompraTipoPedidoModel)
	@JoinColumn({ name: 'id_compra_tipo_pedido' })
	compraTipoPedidoModel: CompraTipoPedidoModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => ViewPessoaFornecedorModel)
	@JoinColumn({ name: 'id_fornecedor' })
	viewPessoaFornecedorModel: ViewPessoaFornecedorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoCotacao = jsonObj['codigoCotacao'];
			this.dataPedido = jsonObj['dataPedido'];
			this.dataPrevistaEntrega = jsonObj['dataPrevistaEntrega'];
			this.dataPrevisaoPagamento = jsonObj['dataPrevisaoPagamento'];
			this.localEntrega = jsonObj['localEntrega'];
			this.localCobranca = jsonObj['localCobranca'];
			this.contato = jsonObj['contato'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorTotal = jsonObj['valorTotal'];
			this.tipoFrete = jsonObj['tipoFrete'];
			this.formaPagamento = jsonObj['formaPagamento'];
			this.baseCalculoIcms = jsonObj['baseCalculoIcms'];
			this.valorIcms = jsonObj['valorIcms'];
			this.baseCalculoIcmsSt = jsonObj['baseCalculoIcmsSt'];
			this.valorIcmsSt = jsonObj['valorIcmsSt'];
			this.valorTotalProdutos = jsonObj['valorTotalProdutos'];
			this.valorFrete = jsonObj['valorFrete'];
			this.valorSeguro = jsonObj['valorSeguro'];
			this.valorOutrasDespesas = jsonObj['valorOutrasDespesas'];
			this.valorIpi = jsonObj['valorIpi'];
			this.valorTotalNf = jsonObj['valorTotalNf'];
			this.quantidadeParcelas = jsonObj['quantidadeParcelas'];
			this.diaPrimeiroVencimento = jsonObj['diaPrimeiroVencimento'];
			this.intervaloEntreParcelas = jsonObj['intervaloEntreParcelas'];
			this.diaFixoParcela = jsonObj['diaFixoParcela'];
			if (jsonObj['compraTipoPedidoModel'] != null) {
				this.compraTipoPedidoModel = new CompraTipoPedidoModel(jsonObj['compraTipoPedidoModel']);
			}

			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['viewPessoaFornecedorModel'] != null) {
				this.viewPessoaFornecedorModel = new ViewPessoaFornecedorModel(jsonObj['viewPessoaFornecedorModel']);
			}

			this.compraPedidoDetalheModelList = [];
			let compraPedidoDetalheModelJsonList = jsonObj['compraPedidoDetalheModelList'];
			if (compraPedidoDetalheModelJsonList != null) {
				for (let i = 0; i < compraPedidoDetalheModelJsonList.length; i++) {
					let obj = new CompraPedidoDetalheModel(compraPedidoDetalheModelJsonList[i]);
					this.compraPedidoDetalheModelList.push(obj);
				}
			}

		}
	}
}