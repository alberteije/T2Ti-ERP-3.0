import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CompraFornecedorCotacaoModel } from '../entities-export';
import { CompraRequisicaoModel } from '../entities-export';
import { CompraCotacaoDetalheModel } from '../entities-export';

@Entity({ name: 'compra_cotacao' })
export class CompraCotacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_cotacao' }) 
	dataCotacao: Date; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => CompraFornecedorCotacaoModel, compraFornecedorCotacaoModel => compraFornecedorCotacaoModel.compraCotacaoModel, { cascade: true })
	compraFornecedorCotacaoModelList: CompraFornecedorCotacaoModel[];

	@OneToOne(() => CompraRequisicaoModel)
	@JoinColumn({ name: 'id_compra_requisicao' })
	compraRequisicaoModel: CompraRequisicaoModel;

	@OneToMany(() => CompraCotacaoDetalheModel, compraCotacaoDetalheModel => compraCotacaoDetalheModel.compraCotacaoModel, { cascade: true })
	compraCotacaoDetalheModelList: CompraCotacaoDetalheModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataCotacao = jsonObj['dataCotacao'];
			this.descricao = jsonObj['descricao'];
			if (jsonObj['compraRequisicaoModel'] != null) {
				this.compraRequisicaoModel = new CompraRequisicaoModel(jsonObj['compraRequisicaoModel']);
			}

			this.compraFornecedorCotacaoModelList = [];
			let compraFornecedorCotacaoModelJsonList = jsonObj['compraFornecedorCotacaoModelList'];
			if (compraFornecedorCotacaoModelJsonList != null) {
				for (let i = 0; i < compraFornecedorCotacaoModelJsonList.length; i++) {
					let obj = new CompraFornecedorCotacaoModel(compraFornecedorCotacaoModelJsonList[i]);
					this.compraFornecedorCotacaoModelList.push(obj);
				}
			}

			this.compraCotacaoDetalheModelList = [];
			let compraCotacaoDetalheModelJsonList = jsonObj['compraCotacaoDetalheModelList'];
			if (compraCotacaoDetalheModelJsonList != null) {
				for (let i = 0; i < compraCotacaoDetalheModelJsonList.length; i++) {
					let obj = new CompraCotacaoDetalheModel(compraCotacaoDetalheModelJsonList[i]);
					this.compraCotacaoDetalheModelList.push(obj);
				}
			}

		}
	}
}