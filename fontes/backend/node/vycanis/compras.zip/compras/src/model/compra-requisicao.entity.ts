import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CompraRequisicaoDetalheModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { CompraTipoRequisicaoModel } from '../entities-export';

@Entity({ name: 'compra_requisicao' })
export class CompraRequisicaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'data_requisicao' }) 
	dataRequisicao: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => CompraRequisicaoDetalheModel, compraRequisicaoDetalheModel => compraRequisicaoDetalheModel.compraRequisicaoModel, { cascade: true })
	compraRequisicaoDetalheModelList: CompraRequisicaoDetalheModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => CompraTipoRequisicaoModel)
	@JoinColumn({ name: 'id_compra_tipo_requisicao' })
	compraTipoRequisicaoModel: CompraTipoRequisicaoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.dataRequisicao = jsonObj['dataRequisicao'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['compraTipoRequisicaoModel'] != null) {
				this.compraTipoRequisicaoModel = new CompraTipoRequisicaoModel(jsonObj['compraTipoRequisicaoModel']);
			}

			this.compraRequisicaoDetalheModelList = [];
			let compraRequisicaoDetalheModelJsonList = jsonObj['compraRequisicaoDetalheModelList'];
			if (compraRequisicaoDetalheModelJsonList != null) {
				for (let i = 0; i < compraRequisicaoDetalheModelJsonList.length; i++) {
					let obj = new CompraRequisicaoDetalheModel(compraRequisicaoDetalheModelJsonList[i]);
					this.compraRequisicaoDetalheModelList.push(obj);
				}
			}

		}
	}
}