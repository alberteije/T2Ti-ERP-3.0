import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CompraPedidoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'compra_pedido_detalhe' })
export class CompraPedidoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade', type: 'decimal', precision: 18, scale: 6 }) 
	quantidade: number; 

	@Column({ name: 'valor_unitario', type: 'decimal', precision: 18, scale: 6 }) 
	valorUnitario: number; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'cst' }) 
	cst: string; 

	@Column({ name: 'csosn' }) 
	csosn: string; 

	@Column({ name: 'cfop' }) 
	cfop: number; 

	@Column({ name: 'base_calculo_icms', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcms: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'valor_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpi: number; 

	@Column({ name: 'aliquota_icms', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcms: number; 

	@Column({ name: 'aliquota_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIpi: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CompraPedidoModel, compraPedidoModel => compraPedidoModel.compraPedidoDetalheModelList)
	@JoinColumn({ name: 'id_compra_pedido' })
	compraPedidoModel: CompraPedidoModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			this.valorUnitario = jsonObj['valorUnitario'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorTotal = jsonObj['valorTotal'];
			this.cst = jsonObj['cst'];
			this.csosn = jsonObj['csosn'];
			this.cfop = jsonObj['cfop'];
			this.baseCalculoIcms = jsonObj['baseCalculoIcms'];
			this.valorIcms = jsonObj['valorIcms'];
			this.valorIpi = jsonObj['valorIpi'];
			this.aliquotaIcms = jsonObj['aliquotaIcms'];
			this.aliquotaIpi = jsonObj['aliquotaIpi'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}