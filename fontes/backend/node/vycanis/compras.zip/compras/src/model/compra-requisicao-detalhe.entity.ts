import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CompraRequisicaoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'compra_requisicao_detalhe' })
export class CompraRequisicaoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade', type: 'decimal', precision: 18, scale: 6 }) 
	quantidade: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CompraRequisicaoModel, compraRequisicaoModel => compraRequisicaoModel.compraRequisicaoDetalheModelList)
	@JoinColumn({ name: 'id_compra_requisicao' })
	compraRequisicaoModel: CompraRequisicaoModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}