import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaFornecedorController } from '../controller/view-pessoa-fornecedor.controller';
import { ViewPessoaFornecedorService } from '../service/view-pessoa-fornecedor.service';
import { ViewPessoaFornecedorModel } from '../model/view-pessoa-fornecedor.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaFornecedorModel])],
    controllers: [ViewPessoaFornecedorController],
    providers: [ViewPessoaFornecedorService],
})
export class ViewPessoaFornecedorModule { }
