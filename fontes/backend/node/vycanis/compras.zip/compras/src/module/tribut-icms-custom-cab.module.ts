import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TributIcmsCustomCabController } from '../controller/tribut-icms-custom-cab.controller';
import { TributIcmsCustomCabService } from '../service/tribut-icms-custom-cab.service';
import { TributIcmsCustomCabModel } from '../model/tribut-icms-custom-cab.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TributIcmsCustomCabModel])],
    controllers: [TributIcmsCustomCabController],
    providers: [TributIcmsCustomCabService],
})
export class TributIcmsCustomCabModule { }
