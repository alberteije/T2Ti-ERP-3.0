import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CompraTipoPedidoController } from '../controller/compra-tipo-pedido.controller';
import { CompraTipoPedidoService } from '../service/compra-tipo-pedido.service';
import { CompraTipoPedidoModel } from '../model/compra-tipo-pedido.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CompraTipoPedidoModel])],
    controllers: [CompraTipoPedidoController],
    providers: [CompraTipoPedidoService],
})
export class CompraTipoPedidoModule { }
