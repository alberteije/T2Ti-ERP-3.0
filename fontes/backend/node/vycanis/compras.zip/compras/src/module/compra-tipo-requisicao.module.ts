import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CompraTipoRequisicaoController } from '../controller/compra-tipo-requisicao.controller';
import { CompraTipoRequisicaoService } from '../service/compra-tipo-requisicao.service';
import { CompraTipoRequisicaoModel } from '../model/compra-tipo-requisicao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CompraTipoRequisicaoModel])],
    controllers: [CompraTipoRequisicaoController],
    providers: [CompraTipoRequisicaoService],
})
export class CompraTipoRequisicaoModule { }
