import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CompraCotacaoController } from '../controller/compra-cotacao.controller';
import { CompraCotacaoService } from '../service/compra-cotacao.service';
import { CompraCotacaoModel } from '../model/compra-cotacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CompraCotacaoModel])],
    controllers: [CompraCotacaoController],
    providers: [CompraCotacaoService],
})
export class CompraCotacaoModule { }
