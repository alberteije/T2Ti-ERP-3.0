import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { CompraCotacaoModel } from '../entities-export';

@Injectable()
export class CompraCotacaoService extends TypeOrmCrudService<CompraCotacaoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(CompraCotacaoModel) 
    private readonly repository: Repository<CompraCotacaoModel>,
  ) {
    super(repository);
  }

	async save(compraCotacaoModel: CompraCotacaoModel, operation: string): Promise<CompraCotacaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, compraCotacaoModel.id);
      }

      const resultObj = await queryRunner.manager.save(compraCotacaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(CompraCotacaoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from compra_fornecedor_cotacao where id_compra_cotacao=' + id); 

		await queryRunner.query('delete from compra_cotacao_detalhe where id_compra_cotacao=' + id); 

	}
	
}