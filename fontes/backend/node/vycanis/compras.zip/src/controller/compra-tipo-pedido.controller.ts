import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CompraTipoPedidoService } from '../service/compra-tipo-pedido.service';
import { CompraTipoPedidoModel } from '../model/compra-tipo-pedido.entity';

@Crud({
  model: {
    type: CompraTipoPedidoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('compra-tipo-pedido')
export class CompraTipoPedidoController implements CrudController<CompraTipoPedidoModel> {
  constructor(public service: CompraTipoPedidoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const compraTipoPedidoModel = new CompraTipoPedidoModel(jsonObj);
		const result = await this.service.save(compraTipoPedidoModel);
		return result;
	}  


}


















