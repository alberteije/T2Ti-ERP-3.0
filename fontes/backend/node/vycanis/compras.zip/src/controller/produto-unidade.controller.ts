import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ProdutoUnidadeService } from '../service/produto-unidade.service';
import { ProdutoUnidadeModel } from '../model/produto-unidade.entity';

@Crud({
  model: {
    type: ProdutoUnidadeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('produto-unidade')
export class ProdutoUnidadeController implements CrudController<ProdutoUnidadeModel> {
  constructor(public service: ProdutoUnidadeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoUnidadeModel = new ProdutoUnidadeModel(jsonObj);
		const result = await this.service.save(produtoUnidadeModel);
		return result;
	}  


}


















