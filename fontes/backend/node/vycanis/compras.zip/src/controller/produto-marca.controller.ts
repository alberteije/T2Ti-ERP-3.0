import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ProdutoMarcaService } from '../service/produto-marca.service';
import { ProdutoMarcaModel } from '../model/produto-marca.entity';

@Crud({
  model: {
    type: ProdutoMarcaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('produto-marca')
export class ProdutoMarcaController implements CrudController<ProdutoMarcaModel> {
  constructor(public service: ProdutoMarcaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoMarcaModel = new ProdutoMarcaModel(jsonObj);
		const result = await this.service.save(produtoMarcaModel);
		return result;
	}  


}


















