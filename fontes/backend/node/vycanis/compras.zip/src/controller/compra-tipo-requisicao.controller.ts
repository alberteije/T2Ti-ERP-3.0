import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CompraTipoRequisicaoService } from '../service/compra-tipo-requisicao.service';
import { CompraTipoRequisicaoModel } from '../model/compra-tipo-requisicao.entity';

@Crud({
  model: {
    type: CompraTipoRequisicaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('compra-tipo-requisicao')
export class CompraTipoRequisicaoController implements CrudController<CompraTipoRequisicaoModel> {
  constructor(public service: CompraTipoRequisicaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const compraTipoRequisicaoModel = new CompraTipoRequisicaoModel(jsonObj);
		const result = await this.service.save(compraTipoRequisicaoModel);
		return result;
	}  


}


















