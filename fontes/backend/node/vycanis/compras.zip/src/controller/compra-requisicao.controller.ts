import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { CompraRequisicaoService } from '../service/compra-requisicao.service';
import { CompraRequisicaoModel } from '../model/compra-requisicao.entity';

@Crud({
  model: {
    type: CompraRequisicaoModel,
  },
  query: {
    join: {
			compraRequisicaoDetalheModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
			compraTipoRequisicaoModel: { eager: true },
    },
  },
})
@Controller('compra-requisicao')
export class CompraRequisicaoController implements CrudController<CompraRequisicaoModel> {
  constructor(public service: CompraRequisicaoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const compraRequisicao = new CompraRequisicaoModel(jsonObj);
		const result = await this.service.save(compraRequisicao, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const compraRequisicao = new CompraRequisicaoModel(jsonObj);
		const result = await this.service.save(compraRequisicao, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}