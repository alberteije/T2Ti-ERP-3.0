import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { CompraPedidoModel } from '../entities-export';

@Injectable()
export class CompraPedidoService extends TypeOrmCrudService<CompraPedidoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(CompraPedidoModel) 
    private readonly repository: Repository<CompraPedidoModel>,
  ) {
    super(repository);
  }

	async save(compraPedidoModel: CompraPedidoModel, operation: string): Promise<CompraPedidoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, compraPedidoModel.id);
      }

      const resultObj = await queryRunner.manager.save(compraPedidoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(CompraPedidoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from compra_pedido_detalhe where id_compra_pedido=' + id); 

	}
	
}