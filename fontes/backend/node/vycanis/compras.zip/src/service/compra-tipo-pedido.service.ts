import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CompraTipoPedidoModel } from '../entities-export';

@Injectable()
export class CompraTipoPedidoService extends TypeOrmCrudService<CompraTipoPedidoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CompraTipoPedidoModel)
    private readonly repository: Repository<CompraTipoPedidoModel>
  ) {
    super(repository);
  }

	async save(compraTipoPedidoModel: CompraTipoPedidoModel): Promise<CompraTipoPedidoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(compraTipoPedidoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
