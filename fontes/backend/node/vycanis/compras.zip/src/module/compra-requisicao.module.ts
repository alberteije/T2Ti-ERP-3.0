import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CompraRequisicaoController } from '../controller/compra-requisicao.controller';
import { CompraRequisicaoService } from '../service/compra-requisicao.service';
import { CompraRequisicaoModel } from '../model/compra-requisicao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CompraRequisicaoModel])],
    controllers: [CompraRequisicaoController],
    providers: [CompraRequisicaoService],
})
export class CompraRequisicaoModule { }
