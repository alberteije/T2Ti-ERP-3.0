import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TributGrupoTributarioController } from '../controller/tribut-grupo-tributario.controller';
import { TributGrupoTributarioService } from '../service/tribut-grupo-tributario.service';
import { TributGrupoTributarioModel } from '../model/tribut-grupo-tributario.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TributGrupoTributarioModel])],
    controllers: [TributGrupoTributarioController],
    providers: [TributGrupoTributarioService],
})
export class TributGrupoTributarioModule { }
