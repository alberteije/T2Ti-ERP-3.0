import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CompraPedidoController } from '../controller/compra-pedido.controller';
import { CompraPedidoService } from '../service/compra-pedido.service';
import { CompraPedidoModel } from '../model/compra-pedido.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CompraPedidoModel])],
    controllers: [CompraPedidoController],
    providers: [CompraPedidoService],
})
export class CompraPedidoModule { }
