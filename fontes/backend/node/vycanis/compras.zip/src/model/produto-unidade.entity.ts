import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'produto_unidade' })
export class ProdutoUnidadeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'sigla' }) 
	sigla: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'pode_fracionar' }) 
	podeFracionar: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.sigla = jsonObj['sigla'];
			this.descricao = jsonObj['descricao'];
			this.podeFracionar = jsonObj['podeFracionar'];
		}
	}
}