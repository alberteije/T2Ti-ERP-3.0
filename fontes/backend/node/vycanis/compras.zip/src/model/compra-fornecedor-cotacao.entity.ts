import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaFornecedorModel } from '../entities-export';
import { CompraCotacaoModel } from '../entities-export';

@Entity({ name: 'compra_fornecedor_cotacao' })
export class CompraFornecedorCotacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'prazo_entrega' }) 
	prazoEntrega: string; 

	@Column({ name: 'venda_condicoes_pagamento' }) 
	vendaCondicoesPagamento: string; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaFornecedorModel)
	@JoinColumn({ name: 'id_fornecedor' })
	viewPessoaFornecedorModel: ViewPessoaFornecedorModel;

	@ManyToOne(() => CompraCotacaoModel, compraCotacaoModel => compraCotacaoModel.compraFornecedorCotacaoModelList)
	@JoinColumn({ name: 'id_compra_cotacao' })
	compraCotacaoModel: CompraCotacaoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.prazoEntrega = jsonObj['prazoEntrega'];
			this.vendaCondicoesPagamento = jsonObj['vendaCondicoesPagamento'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorTotal = jsonObj['valorTotal'];
			if (jsonObj['viewPessoaFornecedorModel'] != null) {
				this.viewPessoaFornecedorModel = new ViewPessoaFornecedorModel(jsonObj['viewPessoaFornecedorModel']);
			}

		}
	}
}