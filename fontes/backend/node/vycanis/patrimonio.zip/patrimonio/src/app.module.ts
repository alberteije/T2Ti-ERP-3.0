import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { PatrimBemModule } from './modules-export';
import { SetorModule } from './modules-export';
import { CentroResultadoModule } from './modules-export';
import { PatrimIndiceAtualizacaoModule } from './modules-export';
import { PatrimTaxaDepreciacaoModule } from './modules-export';
import { PatrimGrupoBemModule } from './modules-export';
import { PatrimTipoAquisicaoBemModule } from './modules-export';
import { PatrimEstadoConservacaoModule } from './modules-export';
import { SeguradoraModule } from './modules-export';
import { PatrimTipoMovimentacaoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaFornecedorModule } from './modules-export';
import { ViewPessoaColaboradorModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';
import { AuditoriaModule } from './modules-export';
import { UsuarioTokenModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			PatrimBemModule,
			SetorModule,
			CentroResultadoModule,
			PatrimIndiceAtualizacaoModule,
			PatrimTaxaDepreciacaoModule,
			PatrimGrupoBemModule,
			PatrimTipoAquisicaoBemModule,
			PatrimEstadoConservacaoModule,
			SeguradoraModule,
			PatrimTipoMovimentacaoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaFornecedorModule,
			ViewPessoaColaboradorModule,
      LoginModule,
      AuditoriaModule,
      UsuarioTokenModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],

  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}