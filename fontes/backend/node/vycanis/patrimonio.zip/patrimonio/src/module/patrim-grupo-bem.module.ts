import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatrimGrupoBemController } from '../controller/patrim-grupo-bem.controller';
import { PatrimGrupoBemService } from '../service/patrim-grupo-bem.service';
import { PatrimGrupoBemModel } from '../model/patrim-grupo-bem.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PatrimGrupoBemModel])],
    controllers: [PatrimGrupoBemController],
    providers: [PatrimGrupoBemService],
})
export class PatrimGrupoBemModule { }
