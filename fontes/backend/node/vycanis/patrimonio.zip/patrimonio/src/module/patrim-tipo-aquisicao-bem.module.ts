import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatrimTipoAquisicaoBemController } from '../controller/patrim-tipo-aquisicao-bem.controller';
import { PatrimTipoAquisicaoBemService } from '../service/patrim-tipo-aquisicao-bem.service';
import { PatrimTipoAquisicaoBemModel } from '../model/patrim-tipo-aquisicao-bem.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PatrimTipoAquisicaoBemModel])],
    controllers: [PatrimTipoAquisicaoBemController],
    providers: [PatrimTipoAquisicaoBemService],
})
export class PatrimTipoAquisicaoBemModule { }
