import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsuarioTokenService } from '../service/usuario-token.service';
import { UsuarioTokenModel } from '../model/usuario-token.entity';

@Module({
    imports: [TypeOrmModule.forFeature([UsuarioTokenModel])],
    providers: [UsuarioTokenService],
})
export class UsuarioTokenModule { }
