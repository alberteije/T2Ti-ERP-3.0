import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatrimEstadoConservacaoController } from '../controller/patrim-estado-conservacao.controller';
import { PatrimEstadoConservacaoService } from '../service/patrim-estado-conservacao.service';
import { PatrimEstadoConservacaoModel } from '../model/patrim-estado-conservacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PatrimEstadoConservacaoModel])],
    controllers: [PatrimEstadoConservacaoController],
    providers: [PatrimEstadoConservacaoService],
})
export class PatrimEstadoConservacaoModule { }
