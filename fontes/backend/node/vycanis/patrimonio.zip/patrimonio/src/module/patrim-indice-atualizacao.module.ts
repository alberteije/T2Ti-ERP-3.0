import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatrimIndiceAtualizacaoController } from '../controller/patrim-indice-atualizacao.controller';
import { PatrimIndiceAtualizacaoService } from '../service/patrim-indice-atualizacao.service';
import { PatrimIndiceAtualizacaoModel } from '../model/patrim-indice-atualizacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PatrimIndiceAtualizacaoModel])],
    controllers: [PatrimIndiceAtualizacaoController],
    providers: [PatrimIndiceAtualizacaoService],
})
export class PatrimIndiceAtualizacaoModule { }
