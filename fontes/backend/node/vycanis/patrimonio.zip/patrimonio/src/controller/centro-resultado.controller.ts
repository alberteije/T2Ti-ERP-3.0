import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CentroResultadoService } from '../service/centro-resultado.service';
import { CentroResultadoModel } from '../model/centro-resultado.entity';

@Crud({
  model: {
    type: CentroResultadoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('centro-resultado')
export class CentroResultadoController implements CrudController<CentroResultadoModel> {
  constructor(public service: CentroResultadoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const centroResultadoModel = new CentroResultadoModel(jsonObj);
		const result = await this.service.save(centroResultadoModel);
		return result;
	}  


}


















