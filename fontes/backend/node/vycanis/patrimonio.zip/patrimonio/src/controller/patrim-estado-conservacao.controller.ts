import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PatrimEstadoConservacaoService } from '../service/patrim-estado-conservacao.service';
import { PatrimEstadoConservacaoModel } from '../model/patrim-estado-conservacao.entity';

@Crud({
  model: {
    type: PatrimEstadoConservacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('patrim-estado-conservacao')
export class PatrimEstadoConservacaoController implements CrudController<PatrimEstadoConservacaoModel> {
  constructor(public service: PatrimEstadoConservacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimEstadoConservacaoModel = new PatrimEstadoConservacaoModel(jsonObj);
		const result = await this.service.save(patrimEstadoConservacaoModel);
		return result;
	}  


}


















