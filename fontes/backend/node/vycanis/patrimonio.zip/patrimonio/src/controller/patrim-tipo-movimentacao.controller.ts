import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PatrimTipoMovimentacaoService } from '../service/patrim-tipo-movimentacao.service';
import { PatrimTipoMovimentacaoModel } from '../model/patrim-tipo-movimentacao.entity';

@Crud({
  model: {
    type: PatrimTipoMovimentacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('patrim-tipo-movimentacao')
export class PatrimTipoMovimentacaoController implements CrudController<PatrimTipoMovimentacaoModel> {
  constructor(public service: PatrimTipoMovimentacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimTipoMovimentacaoModel = new PatrimTipoMovimentacaoModel(jsonObj);
		const result = await this.service.save(patrimTipoMovimentacaoModel);
		return result;
	}  


}


















