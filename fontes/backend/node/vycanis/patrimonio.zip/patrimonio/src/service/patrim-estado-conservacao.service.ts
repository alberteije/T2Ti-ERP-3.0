import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PatrimEstadoConservacaoModel } from '../entities-export';

@Injectable()
export class PatrimEstadoConservacaoService extends TypeOrmCrudService<PatrimEstadoConservacaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PatrimEstadoConservacaoModel)
    private readonly repository: Repository<PatrimEstadoConservacaoModel>
  ) {
    super(repository);
  }

	async save(patrimEstadoConservacaoModel: PatrimEstadoConservacaoModel): Promise<PatrimEstadoConservacaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(patrimEstadoConservacaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
