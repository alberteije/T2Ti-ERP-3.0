import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PatrimTipoMovimentacaoModel } from '../entities-export';

@Injectable()
export class PatrimTipoMovimentacaoService extends TypeOrmCrudService<PatrimTipoMovimentacaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PatrimTipoMovimentacaoModel)
    private readonly repository: Repository<PatrimTipoMovimentacaoModel>
  ) {
    super(repository);
  }

	async save(patrimTipoMovimentacaoModel: PatrimTipoMovimentacaoModel): Promise<PatrimTipoMovimentacaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(patrimTipoMovimentacaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
