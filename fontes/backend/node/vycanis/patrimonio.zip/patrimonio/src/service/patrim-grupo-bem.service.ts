import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PatrimGrupoBemModel } from '../entities-export';

@Injectable()
export class PatrimGrupoBemService extends TypeOrmCrudService<PatrimGrupoBemModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PatrimGrupoBemModel)
    private readonly repository: Repository<PatrimGrupoBemModel>
  ) {
    super(repository);
  }

	async save(patrimGrupoBemModel: PatrimGrupoBemModel): Promise<PatrimGrupoBemModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(patrimGrupoBemModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
