import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CentroResultadoModel } from '../entities-export';

@Injectable()
export class CentroResultadoService extends TypeOrmCrudService<CentroResultadoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CentroResultadoModel)
    private readonly repository: Repository<CentroResultadoModel>
  ) {
    super(repository);
  }

	async save(centroResultadoModel: CentroResultadoModel): Promise<CentroResultadoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(centroResultadoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
