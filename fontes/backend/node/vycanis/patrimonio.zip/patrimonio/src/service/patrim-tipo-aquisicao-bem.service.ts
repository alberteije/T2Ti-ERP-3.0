import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PatrimTipoAquisicaoBemModel } from '../entities-export';

@Injectable()
export class PatrimTipoAquisicaoBemService extends TypeOrmCrudService<PatrimTipoAquisicaoBemModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PatrimTipoAquisicaoBemModel)
    private readonly repository: Repository<PatrimTipoAquisicaoBemModel>
  ) {
    super(repository);
  }

	async save(patrimTipoAquisicaoBemModel: PatrimTipoAquisicaoBemModel): Promise<PatrimTipoAquisicaoBemModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(patrimTipoAquisicaoBemModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
