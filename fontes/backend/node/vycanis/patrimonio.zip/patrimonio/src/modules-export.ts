export { PatrimBemModule } from './module/patrim-bem.module';
export { SetorModule } from './module/setor.module';
export { CentroResultadoModule } from './module/centro-resultado.module';
export { PatrimIndiceAtualizacaoModule } from './module/patrim-indice-atualizacao.module';
export { PatrimTaxaDepreciacaoModule } from './module/patrim-taxa-depreciacao.module';
export { PatrimGrupoBemModule } from './module/patrim-grupo-bem.module';
export { PatrimTipoAquisicaoBemModule } from './module/patrim-tipo-aquisicao-bem.module';
export { PatrimEstadoConservacaoModule } from './module/patrim-estado-conservacao.module';
export { SeguradoraModule } from './module/seguradora.module';
export { PatrimTipoMovimentacaoModule } from './module/patrim-tipo-movimentacao.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaFornecedorModule } from './module/view-pessoa-fornecedor.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';

export { UsuarioTokenModule } from './module/usuario-token.module';
export { AuditoriaModule } from './module/auditoria.module';