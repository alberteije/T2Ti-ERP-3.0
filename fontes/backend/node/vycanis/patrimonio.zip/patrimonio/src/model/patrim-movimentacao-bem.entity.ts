import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PatrimBemModel } from '../entities-export';
import { PatrimTipoMovimentacaoModel } from '../entities-export';

@Entity({ name: 'patrim_movimentacao_bem' })
export class PatrimMovimentacaoBemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_movimentacao' }) 
	dataMovimentacao: Date; 

	@Column({ name: 'responsavel' }) 
	responsavel: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PatrimBemModel, patrimBemModel => patrimBemModel.patrimMovimentacaoBemModelList)
	@JoinColumn({ name: 'id_patrim_bem' })
	patrimBemModel: PatrimBemModel;

	@OneToOne(() => PatrimTipoMovimentacaoModel)
	@JoinColumn({ name: 'id_patrim_tipo_movimentacao' })
	patrimTipoMovimentacaoModel: PatrimTipoMovimentacaoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataMovimentacao = jsonObj['dataMovimentacao'];
			this.responsavel = jsonObj['responsavel'];
			if (jsonObj['patrimTipoMovimentacaoModel'] != null) {
				this.patrimTipoMovimentacaoModel = new PatrimTipoMovimentacaoModel(jsonObj['patrimTipoMovimentacaoModel']);
			}

		}
	}
}