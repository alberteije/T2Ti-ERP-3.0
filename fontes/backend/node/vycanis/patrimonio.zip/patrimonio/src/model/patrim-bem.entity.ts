import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PatrimDocumentoBemModel } from '../entities-export';
import { PatrimDepreciacaoBemModel } from '../entities-export';
import { PatrimMovimentacaoBemModel } from '../entities-export';
import { PatrimApoliceSeguroModel } from '../entities-export';
import { CentroResultadoModel } from '../entities-export';
import { PatrimEstadoConservacaoModel } from '../entities-export';
import { SetorModel } from '../entities-export';
import { ViewPessoaFornecedorModel } from '../entities-export';
import { PatrimTipoAquisicaoBemModel } from '../entities-export';
import { PatrimGrupoBemModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'patrim_bem' })
export class PatrimBemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_nb' }) 
	numeroNb: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'data_aquisicao' }) 
	dataAquisicao: Date; 

	@Column({ name: 'data_aceite' }) 
	dataAceite: Date; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'data_contabilizado' }) 
	dataContabilizado: Date; 

	@Column({ name: 'data_vistoria' }) 
	dataVistoria: Date; 

	@Column({ name: 'data_marcacao' }) 
	dataMarcacao: Date; 

	@Column({ name: 'data_baixa' }) 
	dataBaixa: Date; 

	@Column({ name: 'vencimento_garantia' }) 
	vencimentoGarantia: Date; 

	@Column({ name: 'numero_nota_fiscal' }) 
	numeroNotaFiscal: string; 

	@Column({ name: 'numero_serie' }) 
	numeroSerie: string; 

	@Column({ name: 'chave_nfe' }) 
	chaveNfe: string; 

	@Column({ name: 'valor_original', type: 'decimal', precision: 18, scale: 6 }) 
	valorOriginal: number; 

	@Column({ name: 'valor_compra', type: 'decimal', precision: 18, scale: 6 }) 
	valorCompra: number; 

	@Column({ name: 'valor_atualizado', type: 'decimal', precision: 18, scale: 6 }) 
	valorAtualizado: number; 

	@Column({ name: 'valor_baixa', type: 'decimal', precision: 18, scale: 6 }) 
	valorBaixa: number; 

	@Column({ name: 'deprecia' }) 
	deprecia: string; 

	@Column({ name: 'metodo_depreciacao' }) 
	metodoDepreciacao: string; 

	@Column({ name: 'inicio_depreciacao' }) 
	inicioDepreciacao: Date; 

	@Column({ name: 'ultima_depreciacao' }) 
	ultimaDepreciacao: Date; 

	@Column({ name: 'tipo_depreciacao' }) 
	tipoDepreciacao: string; 

	@Column({ name: 'taxa_anual_depreciacao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaAnualDepreciacao: number; 

	@Column({ name: 'taxa_mensal_depreciacao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaMensalDepreciacao: number; 

	@Column({ name: 'taxa_depreciacao_acelerada', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDepreciacaoAcelerada: number; 

	@Column({ name: 'taxa_depreciacao_incentivada', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDepreciacaoIncentivada: number; 

	@Column({ name: 'funcao' }) 
	funcao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => PatrimDocumentoBemModel, patrimDocumentoBemModel => patrimDocumentoBemModel.patrimBemModel, { cascade: true })
	patrimDocumentoBemModelList: PatrimDocumentoBemModel[];

	@OneToMany(() => PatrimDepreciacaoBemModel, patrimDepreciacaoBemModel => patrimDepreciacaoBemModel.patrimBemModel, { cascade: true })
	patrimDepreciacaoBemModelList: PatrimDepreciacaoBemModel[];

	@OneToMany(() => PatrimMovimentacaoBemModel, patrimMovimentacaoBemModel => patrimMovimentacaoBemModel.patrimBemModel, { cascade: true })
	patrimMovimentacaoBemModelList: PatrimMovimentacaoBemModel[];

	@OneToMany(() => PatrimApoliceSeguroModel, patrimApoliceSeguroModel => patrimApoliceSeguroModel.patrimBemModel, { cascade: true })
	patrimApoliceSeguroModelList: PatrimApoliceSeguroModel[];

	@OneToOne(() => CentroResultadoModel)
	@JoinColumn({ name: 'id_centro_resultado' })
	centroResultadoModel: CentroResultadoModel;

	@OneToOne(() => PatrimEstadoConservacaoModel)
	@JoinColumn({ name: 'id_patrim_estado_conservacao' })
	patrimEstadoConservacaoModel: PatrimEstadoConservacaoModel;

	@OneToOne(() => SetorModel)
	@JoinColumn({ name: 'id_setor' })
	setorModel: SetorModel;

	@OneToOne(() => ViewPessoaFornecedorModel)
	@JoinColumn({ name: 'id_fornecedor' })
	viewPessoaFornecedorModel: ViewPessoaFornecedorModel;

	@OneToOne(() => PatrimTipoAquisicaoBemModel)
	@JoinColumn({ name: 'id_patrim_tipo_aquisicao_bem' })
	patrimTipoAquisicaoBemModel: PatrimTipoAquisicaoBemModel;

	@OneToOne(() => PatrimGrupoBemModel)
	@JoinColumn({ name: 'id_patrim_grupo_bem' })
	patrimGrupoBemModel: PatrimGrupoBemModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroNb = jsonObj['numeroNb'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.dataAquisicao = jsonObj['dataAquisicao'];
			this.dataAceite = jsonObj['dataAceite'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.dataContabilizado = jsonObj['dataContabilizado'];
			this.dataVistoria = jsonObj['dataVistoria'];
			this.dataMarcacao = jsonObj['dataMarcacao'];
			this.dataBaixa = jsonObj['dataBaixa'];
			this.vencimentoGarantia = jsonObj['vencimentoGarantia'];
			this.numeroNotaFiscal = jsonObj['numeroNotaFiscal'];
			this.numeroSerie = jsonObj['numeroSerie'];
			this.chaveNfe = jsonObj['chaveNfe'];
			this.valorOriginal = jsonObj['valorOriginal'];
			this.valorCompra = jsonObj['valorCompra'];
			this.valorAtualizado = jsonObj['valorAtualizado'];
			this.valorBaixa = jsonObj['valorBaixa'];
			this.deprecia = jsonObj['deprecia'];
			this.metodoDepreciacao = jsonObj['metodoDepreciacao'];
			this.inicioDepreciacao = jsonObj['inicioDepreciacao'];
			this.ultimaDepreciacao = jsonObj['ultimaDepreciacao'];
			this.tipoDepreciacao = jsonObj['tipoDepreciacao'];
			this.taxaAnualDepreciacao = jsonObj['taxaAnualDepreciacao'];
			this.taxaMensalDepreciacao = jsonObj['taxaMensalDepreciacao'];
			this.taxaDepreciacaoAcelerada = jsonObj['taxaDepreciacaoAcelerada'];
			this.taxaDepreciacaoIncentivada = jsonObj['taxaDepreciacaoIncentivada'];
			this.funcao = jsonObj['funcao'];
			if (jsonObj['centroResultadoModel'] != null) {
				this.centroResultadoModel = new CentroResultadoModel(jsonObj['centroResultadoModel']);
			}

			if (jsonObj['patrimEstadoConservacaoModel'] != null) {
				this.patrimEstadoConservacaoModel = new PatrimEstadoConservacaoModel(jsonObj['patrimEstadoConservacaoModel']);
			}

			if (jsonObj['setorModel'] != null) {
				this.setorModel = new SetorModel(jsonObj['setorModel']);
			}

			if (jsonObj['viewPessoaFornecedorModel'] != null) {
				this.viewPessoaFornecedorModel = new ViewPessoaFornecedorModel(jsonObj['viewPessoaFornecedorModel']);
			}

			if (jsonObj['patrimTipoAquisicaoBemModel'] != null) {
				this.patrimTipoAquisicaoBemModel = new PatrimTipoAquisicaoBemModel(jsonObj['patrimTipoAquisicaoBemModel']);
			}

			if (jsonObj['patrimGrupoBemModel'] != null) {
				this.patrimGrupoBemModel = new PatrimGrupoBemModel(jsonObj['patrimGrupoBemModel']);
			}

			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.patrimDocumentoBemModelList = [];
			let patrimDocumentoBemModelJsonList = jsonObj['patrimDocumentoBemModelList'];
			if (patrimDocumentoBemModelJsonList != null) {
				for (let i = 0; i < patrimDocumentoBemModelJsonList.length; i++) {
					let obj = new PatrimDocumentoBemModel(patrimDocumentoBemModelJsonList[i]);
					this.patrimDocumentoBemModelList.push(obj);
				}
			}

			this.patrimDepreciacaoBemModelList = [];
			let patrimDepreciacaoBemModelJsonList = jsonObj['patrimDepreciacaoBemModelList'];
			if (patrimDepreciacaoBemModelJsonList != null) {
				for (let i = 0; i < patrimDepreciacaoBemModelJsonList.length; i++) {
					let obj = new PatrimDepreciacaoBemModel(patrimDepreciacaoBemModelJsonList[i]);
					this.patrimDepreciacaoBemModelList.push(obj);
				}
			}

			this.patrimMovimentacaoBemModelList = [];
			let patrimMovimentacaoBemModelJsonList = jsonObj['patrimMovimentacaoBemModelList'];
			if (patrimMovimentacaoBemModelJsonList != null) {
				for (let i = 0; i < patrimMovimentacaoBemModelJsonList.length; i++) {
					let obj = new PatrimMovimentacaoBemModel(patrimMovimentacaoBemModelJsonList[i]);
					this.patrimMovimentacaoBemModelList.push(obj);
				}
			}

			this.patrimApoliceSeguroModelList = [];
			let patrimApoliceSeguroModelJsonList = jsonObj['patrimApoliceSeguroModelList'];
			if (patrimApoliceSeguroModelJsonList != null) {
				for (let i = 0; i < patrimApoliceSeguroModelJsonList.length; i++) {
					let obj = new PatrimApoliceSeguroModel(patrimApoliceSeguroModelJsonList[i]);
					this.patrimApoliceSeguroModelList.push(obj);
				}
			}

		}
	}
}