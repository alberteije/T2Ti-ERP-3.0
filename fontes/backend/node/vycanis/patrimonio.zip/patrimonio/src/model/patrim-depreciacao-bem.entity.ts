import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PatrimBemModel } from '../entities-export';

@Entity({ name: 'patrim_depreciacao_bem' })
export class PatrimDepreciacaoBemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_depreciacao' }) 
	dataDepreciacao: Date; 

	@Column({ name: 'dias' }) 
	dias: number; 

	@Column({ name: 'taxa', type: 'decimal', precision: 18, scale: 6 }) 
	taxa: number; 

	@Column({ name: 'indice', type: 'decimal', precision: 18, scale: 6 }) 
	indice: number; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'depreciacao_acumulada', type: 'decimal', precision: 18, scale: 6 }) 
	depreciacaoAcumulada: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => PatrimBemModel, patrimBemModel => patrimBemModel.patrimDepreciacaoBemModelList)
	@JoinColumn({ name: 'id_patrim_bem' })
	patrimBemModel: PatrimBemModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataDepreciacao = jsonObj['dataDepreciacao'];
			this.dias = jsonObj['dias'];
			this.taxa = jsonObj['taxa'];
			this.indice = jsonObj['indice'];
			this.valor = jsonObj['valor'];
			this.depreciacaoAcumulada = jsonObj['depreciacaoAcumulada'];
		}
	}
}