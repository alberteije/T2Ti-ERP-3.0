import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PatrimBemModel } from '../entities-export';

@Entity({ name: 'patrim_documento_bem' })
export class PatrimDocumentoBemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'imagem' }) 
	imagem: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PatrimBemModel, patrimBemModel => patrimBemModel.patrimDocumentoBemModelList)
	@JoinColumn({ name: 'id_patrim_bem' })
	patrimBemModel: PatrimBemModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.imagem = jsonObj['imagem'];
		}
	}
}