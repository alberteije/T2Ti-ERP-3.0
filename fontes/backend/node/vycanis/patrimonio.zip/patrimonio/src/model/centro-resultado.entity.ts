import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'centro_resultado' })
export class CentroResultadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_plano_centro_resultado' }) 
	idPlanoCentroResultado: number; 

	@Column({ name: 'classificacao' }) 
	classificacao: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'sofre_rateiro' }) 
	sofreRateiro: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idPlanoCentroResultado = jsonObj['idPlanoCentroResultado'];
			this.classificacao = jsonObj['classificacao'];
			this.descricao = jsonObj['descricao'];
			this.sofreRateiro = jsonObj['sofreRateiro'];
		}
	}
}