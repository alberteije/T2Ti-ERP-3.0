import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PatrimBemModel } from '../entities-export';
import { SeguradoraModel } from '../entities-export';

@Entity({ name: 'patrim_apolice_seguro' })
export class PatrimApoliceSeguroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_contratacao' }) 
	dataContratacao: Date; 

	@Column({ name: 'data_vencimento' }) 
	dataVencimento: Date; 

	@Column({ name: 'valor_premio', type: 'decimal', precision: 18, scale: 6 }) 
	valorPremio: number; 

	@Column({ name: 'valor_segurado', type: 'decimal', precision: 18, scale: 6 }) 
	valorSegurado: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 

	@Column({ name: 'imagem' }) 
	imagem: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PatrimBemModel, patrimBemModel => patrimBemModel.patrimApoliceSeguroModelList)
	@JoinColumn({ name: 'id_patrim_bem' })
	patrimBemModel: PatrimBemModel;

	@OneToOne(() => SeguradoraModel)
	@JoinColumn({ name: 'id_seguradora' })
	seguradoraModel: SeguradoraModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.dataContratacao = jsonObj['dataContratacao'];
			this.dataVencimento = jsonObj['dataVencimento'];
			this.valorPremio = jsonObj['valorPremio'];
			this.valorSegurado = jsonObj['valorSegurado'];
			this.observacao = jsonObj['observacao'];
			this.imagem = jsonObj['imagem'];
			if (jsonObj['seguradoraModel'] != null) {
				this.seguradoraModel = new SeguradoraModel(jsonObj['seguradoraModel']);
			}

		}
	}
}