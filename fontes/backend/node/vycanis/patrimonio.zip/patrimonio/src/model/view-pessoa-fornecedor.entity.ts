import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'view_pessoa_fornecedor' })
export class ViewPessoaFornecedorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'site' }) 
	site: string; 

	@Column({ name: 'cpf_cnpj' }) 
	cpfCnpj: string; 

	@Column({ name: 'rg_ie' }) 
	rgIe: string; 

	@Column({ name: 'desde' }) 
	desde: Date; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 

	@Column({ name: 'id_pessoa' }) 
	idPessoa: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.tipo = jsonObj['tipo'];
			this.email = jsonObj['email'];
			this.site = jsonObj['site'];
			this.cpfCnpj = jsonObj['cpfCnpj'];
			this.rgIe = jsonObj['rgIe'];
			this.desde = jsonObj['desde'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.observacao = jsonObj['observacao'];
			this.idPessoa = jsonObj['idPessoa'];
		}
	}
}