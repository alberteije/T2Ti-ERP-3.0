import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ViewPessoaFornecedorService } from '../service/view-pessoa-fornecedor.service';
import { ViewPessoaFornecedorModel } from '../model/view-pessoa-fornecedor.entity';

@Crud({
  model: {
    type: ViewPessoaFornecedorModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('view-pessoa-fornecedor')
export class ViewPessoaFornecedorController implements CrudController<ViewPessoaFornecedorModel> {
  constructor(public service: ViewPessoaFornecedorService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const viewPessoaFornecedorModel = new ViewPessoaFornecedorModel(jsonObj);
		const result = await this.service.save(viewPessoaFornecedorModel);
		return result;
	}  


}


















