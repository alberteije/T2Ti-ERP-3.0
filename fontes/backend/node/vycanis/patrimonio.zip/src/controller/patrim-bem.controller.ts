import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PatrimBemService } from '../service/patrim-bem.service';
import { PatrimBemModel } from '../model/patrim-bem.entity';

@Crud({
  model: {
    type: PatrimBemModel,
  },
  query: {
    join: {
			patrimDocumentoBemModelList: { eager: true },
			patrimDepreciacaoBemModelList: { eager: true },
			patrimMovimentacaoBemModelList: { eager: true },
			patrimApoliceSeguroModelList: { eager: true },
			centroResultadoModel: { eager: true },
			patrimEstadoConservacaoModel: { eager: true },
			setorModel: { eager: true },
			viewPessoaFornecedorModel: { eager: true },
			patrimTipoAquisicaoBemModel: { eager: true },
			patrimGrupoBemModel: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('patrim-bem')
export class PatrimBemController implements CrudController<PatrimBemModel> {
  constructor(public service: PatrimBemService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimBem = new PatrimBemModel(jsonObj);
		const result = await this.service.save(patrimBem, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimBem = new PatrimBemModel(jsonObj);
		const result = await this.service.save(patrimBem, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}