import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SeguradoraService } from '../service/seguradora.service';
import { SeguradoraModel } from '../model/seguradora.entity';

@Crud({
  model: {
    type: SeguradoraModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('seguradora')
export class SeguradoraController implements CrudController<SeguradoraModel> {
  constructor(public service: SeguradoraService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const seguradoraModel = new SeguradoraModel(jsonObj);
		const result = await this.service.save(seguradoraModel);
		return result;
	}  


}


















