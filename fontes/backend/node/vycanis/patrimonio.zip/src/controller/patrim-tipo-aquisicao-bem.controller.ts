import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PatrimTipoAquisicaoBemService } from '../service/patrim-tipo-aquisicao-bem.service';
import { PatrimTipoAquisicaoBemModel } from '../model/patrim-tipo-aquisicao-bem.entity';

@Crud({
  model: {
    type: PatrimTipoAquisicaoBemModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('patrim-tipo-aquisicao-bem')
export class PatrimTipoAquisicaoBemController implements CrudController<PatrimTipoAquisicaoBemModel> {
  constructor(public service: PatrimTipoAquisicaoBemService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimTipoAquisicaoBemModel = new PatrimTipoAquisicaoBemModel(jsonObj);
		const result = await this.service.save(patrimTipoAquisicaoBemModel);
		return result;
	}  


}


















