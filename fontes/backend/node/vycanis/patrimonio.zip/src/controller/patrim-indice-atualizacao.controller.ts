import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PatrimIndiceAtualizacaoService } from '../service/patrim-indice-atualizacao.service';
import { PatrimIndiceAtualizacaoModel } from '../model/patrim-indice-atualizacao.entity';

@Crud({
  model: {
    type: PatrimIndiceAtualizacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('patrim-indice-atualizacao')
export class PatrimIndiceAtualizacaoController implements CrudController<PatrimIndiceAtualizacaoModel> {
  constructor(public service: PatrimIndiceAtualizacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimIndiceAtualizacaoModel = new PatrimIndiceAtualizacaoModel(jsonObj);
		const result = await this.service.save(patrimIndiceAtualizacaoModel);
		return result;
	}  


}


















