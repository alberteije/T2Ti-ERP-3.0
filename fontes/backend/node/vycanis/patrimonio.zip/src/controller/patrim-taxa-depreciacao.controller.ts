import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PatrimTaxaDepreciacaoService } from '../service/patrim-taxa-depreciacao.service';
import { PatrimTaxaDepreciacaoModel } from '../model/patrim-taxa-depreciacao.entity';

@Crud({
  model: {
    type: PatrimTaxaDepreciacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('patrim-taxa-depreciacao')
export class PatrimTaxaDepreciacaoController implements CrudController<PatrimTaxaDepreciacaoModel> {
  constructor(public service: PatrimTaxaDepreciacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimTaxaDepreciacaoModel = new PatrimTaxaDepreciacaoModel(jsonObj);
		const result = await this.service.save(patrimTaxaDepreciacaoModel);
		return result;
	}  


}


















