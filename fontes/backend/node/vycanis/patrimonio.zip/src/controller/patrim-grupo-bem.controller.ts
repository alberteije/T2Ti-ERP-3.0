import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PatrimGrupoBemService } from '../service/patrim-grupo-bem.service';
import { PatrimGrupoBemModel } from '../model/patrim-grupo-bem.entity';

@Crud({
  model: {
    type: PatrimGrupoBemModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('patrim-grupo-bem')
export class PatrimGrupoBemController implements CrudController<PatrimGrupoBemModel> {
  constructor(public service: PatrimGrupoBemService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const patrimGrupoBemModel = new PatrimGrupoBemModel(jsonObj);
		const result = await this.service.save(patrimGrupoBemModel);
		return result;
	}  


}


















