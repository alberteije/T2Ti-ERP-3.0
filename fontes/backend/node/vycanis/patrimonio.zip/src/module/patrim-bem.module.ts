import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatrimBemController } from '../controller/patrim-bem.controller';
import { PatrimBemService } from '../service/patrim-bem.service';
import { PatrimBemModel } from '../model/patrim-bem.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PatrimBemModel])],
    controllers: [PatrimBemController],
    providers: [PatrimBemService],
})
export class PatrimBemModule { }
