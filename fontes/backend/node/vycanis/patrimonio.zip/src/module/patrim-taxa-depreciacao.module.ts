import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatrimTaxaDepreciacaoController } from '../controller/patrim-taxa-depreciacao.controller';
import { PatrimTaxaDepreciacaoService } from '../service/patrim-taxa-depreciacao.service';
import { PatrimTaxaDepreciacaoModel } from '../model/patrim-taxa-depreciacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PatrimTaxaDepreciacaoModel])],
    controllers: [PatrimTaxaDepreciacaoController],
    providers: [PatrimTaxaDepreciacaoService],
})
export class PatrimTaxaDepreciacaoModule { }
