import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatrimTipoMovimentacaoController } from '../controller/patrim-tipo-movimentacao.controller';
import { PatrimTipoMovimentacaoService } from '../service/patrim-tipo-movimentacao.service';
import { PatrimTipoMovimentacaoModel } from '../model/patrim-tipo-movimentacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PatrimTipoMovimentacaoModel])],
    controllers: [PatrimTipoMovimentacaoController],
    providers: [PatrimTipoMovimentacaoService],
})
export class PatrimTipoMovimentacaoModule { }
