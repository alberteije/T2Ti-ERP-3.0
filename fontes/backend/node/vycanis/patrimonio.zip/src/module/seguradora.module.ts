import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SeguradoraController } from '../controller/seguradora.controller';
import { SeguradoraService } from '../service/seguradora.service';
import { SeguradoraModel } from '../model/seguradora.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SeguradoraModel])],
    controllers: [SeguradoraController],
    providers: [SeguradoraService],
})
export class SeguradoraModule { }
