import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SetorController } from '../controller/setor.controller';
import { SetorService } from '../service/setor.service';
import { SetorModel } from '../model/setor.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SetorModel])],
    controllers: [SetorController],
    providers: [SetorService],
})
export class SetorModule { }
