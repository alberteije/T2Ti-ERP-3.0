import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'patrim_grupo_bem' })
export class PatrimGrupoBemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'conta_ativo_imobilizado' }) 
	contaAtivoImobilizado: string; 

	@Column({ name: 'conta_depreciacao_acumulada' }) 
	contaDepreciacaoAcumulada: string; 

	@Column({ name: 'conta_despesa_depreciacao' }) 
	contaDespesaDepreciacao: string; 

	@Column({ name: 'codigo_historico' }) 
	codigoHistorico: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.contaAtivoImobilizado = jsonObj['contaAtivoImobilizado'];
			this.contaDepreciacaoAcumulada = jsonObj['contaDepreciacaoAcumulada'];
			this.contaDespesaDepreciacao = jsonObj['contaDespesaDepreciacao'];
			this.codigoHistorico = jsonObj['codigoHistorico'];
		}
	}
}