import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'patrim_taxa_depreciacao' })
export class PatrimTaxaDepreciacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'ncm' }) 
	ncm: string; 

	@Column({ name: 'bem' }) 
	bem: string; 

	@Column({ name: 'vida', type: 'decimal', precision: 18, scale: 6 }) 
	vida: number; 

	@Column({ name: 'taxa', type: 'decimal', precision: 18, scale: 6 }) 
	taxa: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ncm = jsonObj['ncm'];
			this.bem = jsonObj['bem'];
			this.vida = jsonObj['vida'];
			this.taxa = jsonObj['taxa'];
		}
	}
}