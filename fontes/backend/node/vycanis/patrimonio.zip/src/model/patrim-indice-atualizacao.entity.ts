import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'patrim_indice_atualizacao' })
export class PatrimIndiceAtualizacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_indice' }) 
	dataIndice: Date; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'valor_alternativo', type: 'decimal', precision: 18, scale: 6 }) 
	valorAlternativo: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataIndice = jsonObj['dataIndice'];
			this.nome = jsonObj['nome'];
			this.valor = jsonObj['valor'];
			this.valorAlternativo = jsonObj['valorAlternativo'];
		}
	}
}