import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PatrimIndiceAtualizacaoModel } from '../entities-export';

@Injectable()
export class PatrimIndiceAtualizacaoService extends TypeOrmCrudService<PatrimIndiceAtualizacaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PatrimIndiceAtualizacaoModel)
    private readonly repository: Repository<PatrimIndiceAtualizacaoModel>
  ) {
    super(repository);
  }

	async save(patrimIndiceAtualizacaoModel: PatrimIndiceAtualizacaoModel): Promise<PatrimIndiceAtualizacaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(patrimIndiceAtualizacaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
