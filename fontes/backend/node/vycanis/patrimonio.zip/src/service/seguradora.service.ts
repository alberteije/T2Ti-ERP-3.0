import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SeguradoraModel } from '../entities-export';

@Injectable()
export class SeguradoraService extends TypeOrmCrudService<SeguradoraModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SeguradoraModel)
    private readonly repository: Repository<SeguradoraModel>
  ) {
    super(repository);
  }

	async save(seguradoraModel: SeguradoraModel): Promise<SeguradoraModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(seguradoraModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
