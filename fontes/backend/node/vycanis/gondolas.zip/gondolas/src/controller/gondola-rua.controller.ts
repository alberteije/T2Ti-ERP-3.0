import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { GondolaRuaService } from '../service/gondola-rua.service';
import { GondolaRuaModel } from '../model/gondola-rua.entity';

@Crud({
  model: {
    type: GondolaRuaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('gondola-rua')
export class GondolaRuaController implements CrudController<GondolaRuaModel> {
  constructor(public service: GondolaRuaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const gondolaRuaModel = new GondolaRuaModel(jsonObj);
		const result = await this.service.save(gondolaRuaModel);
		return result;
	}  


}


















