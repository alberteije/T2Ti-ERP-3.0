import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { GondolaRuaModel } from '../entities-export';

@Injectable()
export class GondolaRuaService extends TypeOrmCrudService<GondolaRuaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(GondolaRuaModel)
    private readonly repository: Repository<GondolaRuaModel>
  ) {
    super(repository);
  }

	async save(gondolaRuaModel: GondolaRuaModel): Promise<GondolaRuaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(gondolaRuaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
