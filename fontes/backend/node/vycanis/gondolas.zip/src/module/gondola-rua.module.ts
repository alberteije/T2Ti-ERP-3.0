import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GondolaRuaController } from '../controller/gondola-rua.controller';
import { GondolaRuaService } from '../service/gondola-rua.service';
import { GondolaRuaModel } from '../model/gondola-rua.entity';

@Module({
    imports: [TypeOrmModule.forFeature([GondolaRuaModel])],
    controllers: [GondolaRuaController],
    providers: [GondolaRuaService],
})
export class GondolaRuaModule { }
