import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GondolaEstanteController } from '../controller/gondola-estante.controller';
import { GondolaEstanteService } from '../service/gondola-estante.service';
import { GondolaEstanteModel } from '../model/gondola-estante.entity';

@Module({
    imports: [TypeOrmModule.forFeature([GondolaEstanteModel])],
    controllers: [GondolaEstanteController],
    providers: [GondolaEstanteService],
})
export class GondolaEstanteModule { }
