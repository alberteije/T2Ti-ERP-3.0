import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GondolaCaixaController } from '../controller/gondola-caixa.controller';
import { GondolaCaixaService } from '../service/gondola-caixa.service';
import { GondolaCaixaModel } from '../model/gondola-caixa.entity';

@Module({
    imports: [TypeOrmModule.forFeature([GondolaCaixaModel])],
    controllers: [GondolaCaixaController],
    providers: [GondolaCaixaService],
})
export class GondolaCaixaModule { }
