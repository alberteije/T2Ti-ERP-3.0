import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { GondolaCaixaService } from '../service/gondola-caixa.service';
import { GondolaCaixaModel } from '../model/gondola-caixa.entity';

@Crud({
  model: {
    type: GondolaCaixaModel,
  },
  query: {
    join: {
			gondolaArmazenamentoModelList: { eager: true },
			gondolaEstanteModel: { eager: true },
    },
  },
})
@Controller('gondola-caixa')
export class GondolaCaixaController implements CrudController<GondolaCaixaModel> {
  constructor(public service: GondolaCaixaService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const gondolaCaixa = new GondolaCaixaModel(jsonObj);
		const result = await this.service.save(gondolaCaixa, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const gondolaCaixa = new GondolaCaixaModel(jsonObj);
		const result = await this.service.save(gondolaCaixa, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}