import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { GondolaEstanteService } from '../service/gondola-estante.service';
import { GondolaEstanteModel } from '../model/gondola-estante.entity';

@Crud({
  model: {
    type: GondolaEstanteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('gondola-estante')
export class GondolaEstanteController implements CrudController<GondolaEstanteModel> {
  constructor(public service: GondolaEstanteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const gondolaEstanteModel = new GondolaEstanteModel(jsonObj);
		const result = await this.service.save(gondolaEstanteModel);
		return result;
	}  


}


















