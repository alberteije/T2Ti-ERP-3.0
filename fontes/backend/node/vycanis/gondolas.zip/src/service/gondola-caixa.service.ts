import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { GondolaCaixaModel } from '../entities-export';

@Injectable()
export class GondolaCaixaService extends TypeOrmCrudService<GondolaCaixaModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(GondolaCaixaModel) 
    private readonly repository: Repository<GondolaCaixaModel>,
  ) {
    super(repository);
  }

	async save(gondolaCaixaModel: GondolaCaixaModel, operation: string): Promise<GondolaCaixaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, gondolaCaixaModel.id);
      }

      const resultObj = await queryRunner.manager.save(gondolaCaixaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(GondolaCaixaModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from gondola_armazenamento where id_gondola_caixa=' + id); 

	}
	
}