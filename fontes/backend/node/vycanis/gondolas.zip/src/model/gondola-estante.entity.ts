import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { GondolaRuaModel } from '../entities-export';

@Entity({ name: 'gondola_estante' })
export class GondolaEstanteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'quantidade_caixa' }) 
	quantidadeCaixa: number; 


	/**
	* Relations
	*/
	@OneToOne(() => GondolaRuaModel)
	@JoinColumn({ name: 'id_gondola_rua' })
	gondolaRuaModel: GondolaRuaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.quantidadeCaixa = jsonObj['quantidadeCaixa'];
			if (jsonObj['gondolaRuaModel'] != null) {
				this.gondolaRuaModel = new GondolaRuaModel(jsonObj['gondolaRuaModel']);
			}

		}
	}
}