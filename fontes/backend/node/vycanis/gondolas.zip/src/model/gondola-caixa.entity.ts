import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { GondolaArmazenamentoModel } from '../entities-export';
import { GondolaEstanteModel } from '../entities-export';

@Entity({ name: 'gondola_caixa' })
export class GondolaCaixaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'altura' }) 
	altura: number; 

	@Column({ name: 'largura' }) 
	largura: number; 

	@Column({ name: 'profundidade' }) 
	profundidade: number; 


	/**
	* Relations
	*/
	@OneToMany(() => GondolaArmazenamentoModel, gondolaArmazenamentoModel => gondolaArmazenamentoModel.gondolaCaixaModel, { cascade: true })
	gondolaArmazenamentoModelList: GondolaArmazenamentoModel[];

	@OneToOne(() => GondolaEstanteModel)
	@JoinColumn({ name: 'id_gondola_estante' })
	gondolaEstanteModel: GondolaEstanteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.altura = jsonObj['altura'];
			this.largura = jsonObj['largura'];
			this.profundidade = jsonObj['profundidade'];
			if (jsonObj['gondolaEstanteModel'] != null) {
				this.gondolaEstanteModel = new GondolaEstanteModel(jsonObj['gondolaEstanteModel']);
			}

			this.gondolaArmazenamentoModelList = [];
			let gondolaArmazenamentoModelJsonList = jsonObj['gondolaArmazenamentoModelList'];
			if (gondolaArmazenamentoModelJsonList != null) {
				for (let i = 0; i < gondolaArmazenamentoModelJsonList.length; i++) {
					let obj = new GondolaArmazenamentoModel(gondolaArmazenamentoModelJsonList[i]);
					this.gondolaArmazenamentoModelList.push(obj);
				}
			}

		}
	}
}