export { GondolaCaixaModule } from './module/gondola-caixa.module';
export { ProdutoModule } from './module/produto.module';
export { GondolaRuaModule } from './module/gondola-rua.module';
export { GondolaEstanteModule } from './module/gondola-estante.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
