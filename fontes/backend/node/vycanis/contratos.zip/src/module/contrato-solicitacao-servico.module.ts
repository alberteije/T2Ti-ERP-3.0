import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContratoSolicitacaoServicoController } from '../controller/contrato-solicitacao-servico.controller';
import { ContratoSolicitacaoServicoService } from '../service/contrato-solicitacao-servico.service';
import { ContratoSolicitacaoServicoModel } from '../model/contrato-solicitacao-servico.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContratoSolicitacaoServicoModel])],
    controllers: [ContratoSolicitacaoServicoController],
    providers: [ContratoSolicitacaoServicoService],
})
export class ContratoSolicitacaoServicoModule { }
