import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContratoTipoServicoController } from '../controller/contrato-tipo-servico.controller';
import { ContratoTipoServicoService } from '../service/contrato-tipo-servico.service';
import { ContratoTipoServicoModel } from '../model/contrato-tipo-servico.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContratoTipoServicoModel])],
    controllers: [ContratoTipoServicoController],
    providers: [ContratoTipoServicoService],
})
export class ContratoTipoServicoModule { }
