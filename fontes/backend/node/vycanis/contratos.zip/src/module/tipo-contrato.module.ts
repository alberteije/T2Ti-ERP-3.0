import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TipoContratoController } from '../controller/tipo-contrato.controller';
import { TipoContratoService } from '../service/tipo-contrato.service';
import { TipoContratoModel } from '../model/tipo-contrato.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TipoContratoModel])],
    controllers: [TipoContratoController],
    providers: [TipoContratoService],
})
export class TipoContratoModule { }
