import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContratoTemplateController } from '../controller/contrato-template.controller';
import { ContratoTemplateService } from '../service/contrato-template.service';
import { ContratoTemplateModel } from '../model/contrato-template.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContratoTemplateModel])],
    controllers: [ContratoTemplateController],
    providers: [ContratoTemplateService],
})
export class ContratoTemplateModule { }
