import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContratoController } from '../controller/contrato.controller';
import { ContratoService } from '../service/contrato.service';
import { ContratoModel } from '../model/contrato.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContratoModel])],
    controllers: [ContratoController],
    providers: [ContratoService],
})
export class ContratoModule { }
