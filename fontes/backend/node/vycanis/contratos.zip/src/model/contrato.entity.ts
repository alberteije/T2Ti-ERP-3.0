import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContratoHistoricoReajusteModel } from '../entities-export';
import { ContratoPrevFaturamentoModel } from '../entities-export';
import { ContratoHistFaturamentoModel } from '../entities-export';
import { TipoContratoModel } from '../entities-export';
import { ContratoSolicitacaoServicoModel } from '../entities-export';

@Entity({ name: 'contrato' })
export class ContratoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'data_inicio_vigencia' }) 
	dataInicioVigencia: Date; 

	@Column({ name: 'data_fim_vigencia' }) 
	dataFimVigencia: Date; 

	@Column({ name: 'dia_faturamento' }) 
	diaFaturamento: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'quantidade_parcelas' }) 
	quantidadeParcelas: number; 

	@Column({ name: 'intervalo_entre_parcelas' }) 
	intervaloEntreParcelas: number; 

	@Column({ name: 'classificacao_contabil_conta' }) 
	classificacaoContabilConta: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ContratoHistoricoReajusteModel, contratoHistoricoReajusteModel => contratoHistoricoReajusteModel.contratoModel, { cascade: true })
	contratoHistoricoReajusteModelList: ContratoHistoricoReajusteModel[];

	@OneToMany(() => ContratoPrevFaturamentoModel, contratoPrevFaturamentoModel => contratoPrevFaturamentoModel.contratoModel, { cascade: true })
	contratoPrevFaturamentoModelList: ContratoPrevFaturamentoModel[];

	@OneToMany(() => ContratoHistFaturamentoModel, contratoHistFaturamentoModel => contratoHistFaturamentoModel.contratoModel, { cascade: true })
	contratoHistFaturamentoModelList: ContratoHistFaturamentoModel[];

	@OneToOne(() => TipoContratoModel)
	@JoinColumn({ name: 'id_tipo_contrato' })
	tipoContratoModel: TipoContratoModel;

	@OneToOne(() => ContratoSolicitacaoServicoModel)
	@JoinColumn({ name: 'id_solicitacao_servico' })
	contratoSolicitacaoServicoModel: ContratoSolicitacaoServicoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.dataInicioVigencia = jsonObj['dataInicioVigencia'];
			this.dataFimVigencia = jsonObj['dataFimVigencia'];
			this.diaFaturamento = jsonObj['diaFaturamento'];
			this.valor = jsonObj['valor'];
			this.quantidadeParcelas = jsonObj['quantidadeParcelas'];
			this.intervaloEntreParcelas = jsonObj['intervaloEntreParcelas'];
			this.classificacaoContabilConta = jsonObj['classificacaoContabilConta'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['tipoContratoModel'] != null) {
				this.tipoContratoModel = new TipoContratoModel(jsonObj['tipoContratoModel']);
			}

			if (jsonObj['contratoSolicitacaoServicoModel'] != null) {
				this.contratoSolicitacaoServicoModel = new ContratoSolicitacaoServicoModel(jsonObj['contratoSolicitacaoServicoModel']);
			}

			this.contratoHistoricoReajusteModelList = [];
			let contratoHistoricoReajusteModelJsonList = jsonObj['contratoHistoricoReajusteModelList'];
			if (contratoHistoricoReajusteModelJsonList != null) {
				for (let i = 0; i < contratoHistoricoReajusteModelJsonList.length; i++) {
					let obj = new ContratoHistoricoReajusteModel(contratoHistoricoReajusteModelJsonList[i]);
					this.contratoHistoricoReajusteModelList.push(obj);
				}
			}

			this.contratoPrevFaturamentoModelList = [];
			let contratoPrevFaturamentoModelJsonList = jsonObj['contratoPrevFaturamentoModelList'];
			if (contratoPrevFaturamentoModelJsonList != null) {
				for (let i = 0; i < contratoPrevFaturamentoModelJsonList.length; i++) {
					let obj = new ContratoPrevFaturamentoModel(contratoPrevFaturamentoModelJsonList[i]);
					this.contratoPrevFaturamentoModelList.push(obj);
				}
			}

			this.contratoHistFaturamentoModelList = [];
			let contratoHistFaturamentoModelJsonList = jsonObj['contratoHistFaturamentoModelList'];
			if (contratoHistFaturamentoModelJsonList != null) {
				for (let i = 0; i < contratoHistFaturamentoModelJsonList.length; i++) {
					let obj = new ContratoHistFaturamentoModel(contratoHistFaturamentoModelJsonList[i]);
					this.contratoHistFaturamentoModelList.push(obj);
				}
			}

		}
	}
}