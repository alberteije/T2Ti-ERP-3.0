import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContratoModel } from '../entities-export';

@Entity({ name: 'contrato_prev_faturamento' })
export class ContratoPrevFaturamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_prevista' }) 
	dataPrevista: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContratoModel, contratoModel => contratoModel.contratoPrevFaturamentoModelList)
	@JoinColumn({ name: 'id_contrato' })
	contratoModel: ContratoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataPrevista = jsonObj['dataPrevista'];
			this.valor = jsonObj['valor'];
		}
	}
}