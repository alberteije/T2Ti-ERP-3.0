import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContratoModel } from '../entities-export';

@Entity({ name: 'contrato_historico_reajuste' })
export class ContratoHistoricoReajusteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'indice', type: 'decimal', precision: 18, scale: 6 }) 
	indice: number; 

	@Column({ name: 'valor_anterior', type: 'decimal', precision: 18, scale: 6 }) 
	valorAnterior: number; 

	@Column({ name: 'valor_atual', type: 'decimal', precision: 18, scale: 6 }) 
	valorAtual: number; 

	@Column({ name: 'data_reajuste' }) 
	dataReajuste: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContratoModel, contratoModel => contratoModel.contratoHistoricoReajusteModelList)
	@JoinColumn({ name: 'id_contrato' })
	contratoModel: ContratoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.indice = jsonObj['indice'];
			this.valorAnterior = jsonObj['valorAnterior'];
			this.valorAtual = jsonObj['valorAtual'];
			this.dataReajuste = jsonObj['dataReajuste'];
			this.observacao = jsonObj['observacao'];
		}
	}
}