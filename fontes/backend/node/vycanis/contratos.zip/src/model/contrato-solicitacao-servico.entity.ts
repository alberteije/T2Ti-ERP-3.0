import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';
import { ViewPessoaFornecedorModel } from '../entities-export';
import { SetorModel } from '../entities-export';
import { ContratoTipoServicoModel } from '../entities-export';

@Entity({ name: 'contrato_solicitacao_servico' })
export class ContratoSolicitacaoServicoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_solicitacao' }) 
	dataSolicitacao: Date; 

	@Column({ name: 'data_desejada_inicio' }) 
	dataDesejadaInicio: Date; 

	@Column({ name: 'urgente' }) 
	urgente: string; 

	@Column({ name: 'status_solicitacao' }) 
	statusSolicitacao: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;

	@OneToOne(() => ViewPessoaFornecedorModel)
	@JoinColumn({ name: 'id_fornecedor' })
	viewPessoaFornecedorModel: ViewPessoaFornecedorModel;

	@OneToOne(() => SetorModel)
	@JoinColumn({ name: 'id_setor' })
	setorModel: SetorModel;

	@OneToOne(() => ContratoTipoServicoModel)
	@JoinColumn({ name: 'id_contrato_tipo_servico' })
	contratoTipoServicoModel: ContratoTipoServicoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataSolicitacao = jsonObj['dataSolicitacao'];
			this.dataDesejadaInicio = jsonObj['dataDesejadaInicio'];
			this.urgente = jsonObj['urgente'];
			this.statusSolicitacao = jsonObj['statusSolicitacao'];
			this.descricao = jsonObj['descricao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

			if (jsonObj['viewPessoaFornecedorModel'] != null) {
				this.viewPessoaFornecedorModel = new ViewPessoaFornecedorModel(jsonObj['viewPessoaFornecedorModel']);
			}

			if (jsonObj['setorModel'] != null) {
				this.setorModel = new SetorModel(jsonObj['setorModel']);
			}

			if (jsonObj['contratoTipoServicoModel'] != null) {
				this.contratoTipoServicoModel = new ContratoTipoServicoModel(jsonObj['contratoTipoServicoModel']);
			}

		}
	}
}