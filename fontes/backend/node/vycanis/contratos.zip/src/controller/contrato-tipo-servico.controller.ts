import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContratoTipoServicoService } from '../service/contrato-tipo-servico.service';
import { ContratoTipoServicoModel } from '../model/contrato-tipo-servico.entity';

@Crud({
  model: {
    type: ContratoTipoServicoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contrato-tipo-servico')
export class ContratoTipoServicoController implements CrudController<ContratoTipoServicoModel> {
  constructor(public service: ContratoTipoServicoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contratoTipoServicoModel = new ContratoTipoServicoModel(jsonObj);
		const result = await this.service.save(contratoTipoServicoModel);
		return result;
	}  


}


















