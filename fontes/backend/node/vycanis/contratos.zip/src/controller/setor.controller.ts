import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SetorService } from '../service/setor.service';
import { SetorModel } from '../model/setor.entity';

@Crud({
  model: {
    type: SetorModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('setor')
export class SetorController implements CrudController<SetorModel> {
  constructor(public service: SetorService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const setorModel = new SetorModel(jsonObj);
		const result = await this.service.save(setorModel);
		return result;
	}  


}


















