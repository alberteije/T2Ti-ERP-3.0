import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContratoSolicitacaoServicoService } from '../service/contrato-solicitacao-servico.service';
import { ContratoSolicitacaoServicoModel } from '../model/contrato-solicitacao-servico.entity';

@Crud({
  model: {
    type: ContratoSolicitacaoServicoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contrato-solicitacao-servico')
export class ContratoSolicitacaoServicoController implements CrudController<ContratoSolicitacaoServicoModel> {
  constructor(public service: ContratoSolicitacaoServicoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contratoSolicitacaoServicoModel = new ContratoSolicitacaoServicoModel(jsonObj);
		const result = await this.service.save(contratoSolicitacaoServicoModel);
		return result;
	}  


}


















