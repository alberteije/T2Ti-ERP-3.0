import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { ContratoModule } from './modules-export';
import { SetorModule } from './modules-export';
import { TipoContratoModule } from './modules-export';
import { ContratoTipoServicoModule } from './modules-export';
import { ContratoSolicitacaoServicoModule } from './modules-export';
import { ContratoTemplateModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaClienteModule } from './modules-export';
import { ViewPessoaFornecedorModule } from './modules-export';
import { ViewPessoaColaboradorModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			ContratoModule,
			SetorModule,
			TipoContratoModule,
			ContratoTipoServicoModule,
			ContratoSolicitacaoServicoModule,
			ContratoTemplateModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaClienteModule,
			ViewPessoaFornecedorModule,
			ViewPessoaColaboradorModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}