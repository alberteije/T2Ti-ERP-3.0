import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContratoTemplateService } from '../service/contrato-template.service';
import { ContratoTemplateModel } from '../model/contrato-template.entity';

@Crud({
  model: {
    type: ContratoTemplateModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contrato-template')
export class ContratoTemplateController implements CrudController<ContratoTemplateModel> {
  constructor(public service: ContratoTemplateService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contratoTemplateModel = new ContratoTemplateModel(jsonObj);
		const result = await this.service.save(contratoTemplateModel);
		return result;
	}  


}


















