import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { TipoContratoService } from '../service/tipo-contrato.service';
import { TipoContratoModel } from '../model/tipo-contrato.entity';

@Crud({
  model: {
    type: TipoContratoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('tipo-contrato')
export class TipoContratoController implements CrudController<TipoContratoModel> {
  constructor(public service: TipoContratoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const tipoContratoModel = new TipoContratoModel(jsonObj);
		const result = await this.service.save(tipoContratoModel);
		return result;
	}  


}


















