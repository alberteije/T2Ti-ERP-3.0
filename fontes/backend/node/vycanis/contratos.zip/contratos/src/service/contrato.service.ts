import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ContratoModel } from '../entities-export';

@Injectable()
export class ContratoService extends TypeOrmCrudService<ContratoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ContratoModel) 
    private readonly repository: Repository<ContratoModel>,
  ) {
    super(repository);
  }

	async save(contratoModel: ContratoModel, operation: string): Promise<ContratoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, contratoModel.id);
      }

      const resultObj = await queryRunner.manager.save(contratoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ContratoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from contrato_historico_reajuste where id_contrato=' + id); 

		await queryRunner.query('delete from contrato_prev_faturamento where id_contrato=' + id); 

		await queryRunner.query('delete from contrato_hist_faturamento where id_contrato=' + id); 

	}
	
}