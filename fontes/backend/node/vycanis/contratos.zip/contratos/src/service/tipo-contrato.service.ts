import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { TipoContratoModel } from '../entities-export';

@Injectable()
export class TipoContratoService extends TypeOrmCrudService<TipoContratoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(TipoContratoModel)
    private readonly repository: Repository<TipoContratoModel>
  ) {
    super(repository);
  }

	async save(tipoContratoModel: TipoContratoModel): Promise<TipoContratoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(tipoContratoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
