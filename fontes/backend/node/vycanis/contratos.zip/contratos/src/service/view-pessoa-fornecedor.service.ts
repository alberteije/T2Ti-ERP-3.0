import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ViewPessoaFornecedorModel } from '../entities-export';

@Injectable()
export class ViewPessoaFornecedorService extends TypeOrmCrudService<ViewPessoaFornecedorModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ViewPessoaFornecedorModel)
    private readonly repository: Repository<ViewPessoaFornecedorModel>
  ) {
    super(repository);
  }

	async save(viewPessoaFornecedorModel: ViewPessoaFornecedorModel): Promise<ViewPessoaFornecedorModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(viewPessoaFornecedorModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
