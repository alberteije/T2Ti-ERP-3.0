import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ContratoSolicitacaoServicoModel } from '../entities-export';

@Injectable()
export class ContratoSolicitacaoServicoService extends TypeOrmCrudService<ContratoSolicitacaoServicoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ContratoSolicitacaoServicoModel)
    private readonly repository: Repository<ContratoSolicitacaoServicoModel>
  ) {
    super(repository);
  }

	async save(contratoSolicitacaoServicoModel: ContratoSolicitacaoServicoModel): Promise<ContratoSolicitacaoServicoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(contratoSolicitacaoServicoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
