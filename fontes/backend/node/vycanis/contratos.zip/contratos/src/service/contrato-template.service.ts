import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ContratoTemplateModel } from '../entities-export';

@Injectable()
export class ContratoTemplateService extends TypeOrmCrudService<ContratoTemplateModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ContratoTemplateModel)
    private readonly repository: Repository<ContratoTemplateModel>
  ) {
    super(repository);
  }

	async save(contratoTemplateModel: ContratoTemplateModel): Promise<ContratoTemplateModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(contratoTemplateModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
