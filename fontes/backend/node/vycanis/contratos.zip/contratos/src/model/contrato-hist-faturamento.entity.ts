import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContratoModel } from '../entities-export';

@Entity({ name: 'contrato_hist_faturamento' })
export class ContratoHistFaturamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_fatura' }) 
	dataFatura: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContratoModel, contratoModel => contratoModel.contratoHistFaturamentoModelList)
	@JoinColumn({ name: 'id_contrato' })
	contratoModel: ContratoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataFatura = jsonObj['dataFatura'];
			this.valor = jsonObj['valor'];
		}
	}
}