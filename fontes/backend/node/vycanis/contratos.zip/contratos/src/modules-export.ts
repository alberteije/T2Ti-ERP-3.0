export { ContratoModule } from './module/contrato.module';
export { SetorModule } from './module/setor.module';
export { TipoContratoModule } from './module/tipo-contrato.module';
export { ContratoTipoServicoModule } from './module/contrato-tipo-servico.module';
export { ContratoSolicitacaoServicoModule } from './module/contrato-solicitacao-servico.module';
export { ContratoTemplateModule } from './module/contrato-template.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaClienteModule } from './module/view-pessoa-cliente.module';
export { ViewPessoaFornecedorModule } from './module/view-pessoa-fornecedor.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';

export { UsuarioTokenModule } from './module/usuario-token.module';
export { AuditoriaModule } from './module/auditoria.module';