import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EsocialNaturezaJuridicaController } from '../controller/esocial-natureza-juridica.controller';
import { EsocialNaturezaJuridicaService } from '../service/esocial-natureza-juridica.service';
import { EsocialNaturezaJuridicaModel } from '../model/esocial-natureza-juridica.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EsocialNaturezaJuridicaModel])],
    controllers: [EsocialNaturezaJuridicaController],
    providers: [EsocialNaturezaJuridicaService],
})
export class EsocialNaturezaJuridicaModule { }
