import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EsocialClassificacaoTributController } from '../controller/esocial-classificacao-tribut.controller';
import { EsocialClassificacaoTributService } from '../service/esocial-classificacao-tribut.service';
import { EsocialClassificacaoTributModel } from '../model/esocial-classificacao-tribut.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EsocialClassificacaoTributModel])],
    controllers: [EsocialClassificacaoTributController],
    providers: [EsocialClassificacaoTributService],
})
export class EsocialClassificacaoTributModule { }
