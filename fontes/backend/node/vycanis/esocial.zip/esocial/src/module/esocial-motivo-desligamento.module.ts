import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EsocialMotivoDesligamentoController } from '../controller/esocial-motivo-desligamento.controller';
import { EsocialMotivoDesligamentoService } from '../service/esocial-motivo-desligamento.service';
import { EsocialMotivoDesligamentoModel } from '../model/esocial-motivo-desligamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EsocialMotivoDesligamentoModel])],
    controllers: [EsocialMotivoDesligamentoController],
    providers: [EsocialMotivoDesligamentoService],
})
export class EsocialMotivoDesligamentoModule { }
