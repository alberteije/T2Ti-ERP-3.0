import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EsocialNaturezaJuridicaService } from '../service/esocial-natureza-juridica.service';
import { EsocialNaturezaJuridicaModel } from '../model/esocial-natureza-juridica.entity';

@Crud({
  model: {
    type: EsocialNaturezaJuridicaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('esocial-natureza-juridica')
export class EsocialNaturezaJuridicaController implements CrudController<EsocialNaturezaJuridicaModel> {
  constructor(public service: EsocialNaturezaJuridicaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const esocialNaturezaJuridicaModel = new EsocialNaturezaJuridicaModel(jsonObj);
		const result = await this.service.save(esocialNaturezaJuridicaModel);
		return result;
	}  


}


















