import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EsocialMotivoDesligamentoService } from '../service/esocial-motivo-desligamento.service';
import { EsocialMotivoDesligamentoModel } from '../model/esocial-motivo-desligamento.entity';

@Crud({
  model: {
    type: EsocialMotivoDesligamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('esocial-motivo-desligamento')
export class EsocialMotivoDesligamentoController implements CrudController<EsocialMotivoDesligamentoModel> {
  constructor(public service: EsocialMotivoDesligamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const esocialMotivoDesligamentoModel = new EsocialMotivoDesligamentoModel(jsonObj);
		const result = await this.service.save(esocialMotivoDesligamentoModel);
		return result;
	}  


}


















