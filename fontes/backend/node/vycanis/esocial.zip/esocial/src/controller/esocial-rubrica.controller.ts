import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EsocialRubricaService } from '../service/esocial-rubrica.service';
import { EsocialRubricaModel } from '../model/esocial-rubrica.entity';

@Crud({
  model: {
    type: EsocialRubricaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('esocial-rubrica')
export class EsocialRubricaController implements CrudController<EsocialRubricaModel> {
  constructor(public service: EsocialRubricaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const esocialRubricaModel = new EsocialRubricaModel(jsonObj);
		const result = await this.service.save(esocialRubricaModel);
		return result;
	}  


}


















