import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EsocialClassificacaoTributService } from '../service/esocial-classificacao-tribut.service';
import { EsocialClassificacaoTributModel } from '../model/esocial-classificacao-tribut.entity';

@Crud({
  model: {
    type: EsocialClassificacaoTributModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('esocial-classificacao-tribut')
export class EsocialClassificacaoTributController implements CrudController<EsocialClassificacaoTributModel> {
  constructor(public service: EsocialClassificacaoTributService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const esocialClassificacaoTributModel = new EsocialClassificacaoTributModel(jsonObj);
		const result = await this.service.save(esocialClassificacaoTributModel);
		return result;
	}  


}


















