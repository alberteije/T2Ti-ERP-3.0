import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'esocial_rubrica' })
export class EsocialRubricaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
		}
	}
}