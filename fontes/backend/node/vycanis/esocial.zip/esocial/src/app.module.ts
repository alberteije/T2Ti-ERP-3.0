import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { EsocialNaturezaJuridicaModule } from './modules-export';
import { EsocialRubricaModule } from './modules-export';
import { EsocialTipoAfastamentoModule } from './modules-export';
import { EsocialMotivoDesligamentoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { EsocialClassificacaoTributModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';
import { AuditoriaModule } from './modules-export';
import { UsuarioTokenModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			EsocialNaturezaJuridicaModule,
			EsocialRubricaModule,
			EsocialTipoAfastamentoModule,
			EsocialMotivoDesligamentoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			EsocialClassificacaoTributModule,
      LoginModule,
      AuditoriaModule,
      UsuarioTokenModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],

  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}