import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EsocialNaturezaJuridicaModel } from '../entities-export';

@Injectable()
export class EsocialNaturezaJuridicaService extends TypeOrmCrudService<EsocialNaturezaJuridicaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EsocialNaturezaJuridicaModel)
    private readonly repository: Repository<EsocialNaturezaJuridicaModel>
  ) {
    super(repository);
  }

	async save(esocialNaturezaJuridicaModel: EsocialNaturezaJuridicaModel): Promise<EsocialNaturezaJuridicaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(esocialNaturezaJuridicaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
