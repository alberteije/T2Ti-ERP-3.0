import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EsocialClassificacaoTributModel } from '../entities-export';

@Injectable()
export class EsocialClassificacaoTributService extends TypeOrmCrudService<EsocialClassificacaoTributModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EsocialClassificacaoTributModel)
    private readonly repository: Repository<EsocialClassificacaoTributModel>
  ) {
    super(repository);
  }

	async save(esocialClassificacaoTributModel: EsocialClassificacaoTributModel): Promise<EsocialClassificacaoTributModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(esocialClassificacaoTributModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
