export { EsocialNaturezaJuridicaModule } from './module/esocial-natureza-juridica.module';
export { EsocialRubricaModule } from './module/esocial-rubrica.module';
export { EsocialTipoAfastamentoModule } from './module/esocial-tipo-afastamento.module';
export { EsocialMotivoDesligamentoModule } from './module/esocial-motivo-desligamento.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { EsocialClassificacaoTributModule } from './module/esocial-classificacao-tribut.module';
