import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewControleAcessoController } from '../controller/view-controle-acesso.controller';
import { ViewControleAcessoService } from '../service/view-controle-acesso.service';
import { ViewControleAcessoModel } from '../model/view-controle-acesso.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ViewControleAcessoModel])],
    controllers: [ViewControleAcessoController],
    providers: [ViewControleAcessoService],
})
export class ViewControleAcessoModule { }
