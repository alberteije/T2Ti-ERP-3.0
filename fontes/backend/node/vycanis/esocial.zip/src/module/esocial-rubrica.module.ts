import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EsocialRubricaController } from '../controller/esocial-rubrica.controller';
import { EsocialRubricaService } from '../service/esocial-rubrica.service';
import { EsocialRubricaModel } from '../model/esocial-rubrica.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EsocialRubricaModel])],
    controllers: [EsocialRubricaController],
    providers: [EsocialRubricaService],
})
export class EsocialRubricaModule { }
