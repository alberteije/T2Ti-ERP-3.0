import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EsocialTipoAfastamentoController } from '../controller/esocial-tipo-afastamento.controller';
import { EsocialTipoAfastamentoService } from '../service/esocial-tipo-afastamento.service';
import { EsocialTipoAfastamentoModel } from '../model/esocial-tipo-afastamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EsocialTipoAfastamentoModel])],
    controllers: [EsocialTipoAfastamentoController],
    providers: [EsocialTipoAfastamentoService],
})
export class EsocialTipoAfastamentoModule { }
