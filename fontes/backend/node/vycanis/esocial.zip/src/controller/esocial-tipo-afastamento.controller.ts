import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EsocialTipoAfastamentoService } from '../service/esocial-tipo-afastamento.service';
import { EsocialTipoAfastamentoModel } from '../model/esocial-tipo-afastamento.entity';

@Crud({
  model: {
    type: EsocialTipoAfastamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('esocial-tipo-afastamento')
export class EsocialTipoAfastamentoController implements CrudController<EsocialTipoAfastamentoModel> {
  constructor(public service: EsocialTipoAfastamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const esocialTipoAfastamentoModel = new EsocialTipoAfastamentoModel(jsonObj);
		const result = await this.service.save(esocialTipoAfastamentoModel);
		return result;
	}  


}


















