import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EsocialRubricaModel } from '../entities-export';

@Injectable()
export class EsocialRubricaService extends TypeOrmCrudService<EsocialRubricaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EsocialRubricaModel)
    private readonly repository: Repository<EsocialRubricaModel>
  ) {
    super(repository);
  }

	async save(esocialRubricaModel: EsocialRubricaModel): Promise<EsocialRubricaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(esocialRubricaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
