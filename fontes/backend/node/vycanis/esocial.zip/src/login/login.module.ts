import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaUsuarioModel } from '../model/view-pessoa-usuario.entity';
import { LoginController } from './login.controller';
import { LoginService } from './login.service';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaUsuarioModel])],
    controllers: [LoginController],
    providers: [LoginService],
    exports: [LoginService]
})
export class LoginModule { }
