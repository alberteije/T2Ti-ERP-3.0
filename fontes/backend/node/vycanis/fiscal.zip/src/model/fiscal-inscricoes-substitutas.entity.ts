import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FiscalParametroModel } from '../entities-export';

@Entity({ name: 'fiscal_inscricoes_substitutas' })
export class FiscalInscricoesSubstitutasModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'inscricao_estadual' }) 
	inscricaoEstadual: string; 

	@Column({ name: 'pmpf' }) 
	pmpf: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FiscalParametroModel, fiscalParametroModel => fiscalParametroModel.fiscalInscricoesSubstitutasModelList)
	@JoinColumn({ name: 'id_fiscal_parametros' })
	fiscalParametroModel: FiscalParametroModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.uf = jsonObj['uf'];
			this.inscricaoEstadual = jsonObj['inscricaoEstadual'];
			this.pmpf = jsonObj['pmpf'];
		}
	}
}