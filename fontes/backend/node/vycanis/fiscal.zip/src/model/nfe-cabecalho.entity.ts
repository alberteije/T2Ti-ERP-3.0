import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'nfe_cabecalho' })
export class NfeCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_vendedor' }) 
	idVendedor: number; 

	@Column({ name: 'uf_emitente' }) 
	ufEmitente: number; 

	@Column({ name: 'codigo_numerico' }) 
	codigoNumerico: string; 

	@Column({ name: 'natureza_operacao' }) 
	naturezaOperacao: string; 

	@Column({ name: 'codigo_modelo' }) 
	codigoModelo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_hora_emissao' }) 
	dataHoraEmissao: Date; 

	@Column({ name: 'data_hora_entrada_saida' }) 
	dataHoraEntradaSaida: Date; 

	@Column({ name: 'tipo_operacao' }) 
	tipoOperacao: string; 

	@Column({ name: 'local_destino' }) 
	localDestino: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: number; 

	@Column({ name: 'formato_impressao_danfe' }) 
	formatoImpressaoDanfe: string; 

	@Column({ name: 'tipo_emissao' }) 
	tipoEmissao: string; 

	@Column({ name: 'chave_acesso' }) 
	chaveAcesso: string; 

	@Column({ name: 'digito_chave_acesso' }) 
	digitoChaveAcesso: string; 

	@Column({ name: 'ambiente' }) 
	ambiente: string; 

	@Column({ name: 'finalidade_emissao' }) 
	finalidadeEmissao: string; 

	@Column({ name: 'consumidor_operacao' }) 
	consumidorOperacao: string; 

	@Column({ name: 'consumidor_presenca' }) 
	consumidorPresenca: string; 

	@Column({ name: 'processo_emissao' }) 
	processoEmissao: string; 

	@Column({ name: 'versao_processo_emissao' }) 
	versaoProcessoEmissao: string; 

	@Column({ name: 'data_entrada_contingencia' }) 
	dataEntradaContingencia: Date; 

	@Column({ name: 'justificativa_contingencia' }) 
	justificativaContingencia: string; 

	@Column({ name: 'base_calculo_icms', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcms: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'valor_icms_desonerado', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsDesonerado: number; 

	@Column({ name: 'total_icms_fcp_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	totalIcmsFcpUfDestino: number; 

	@Column({ name: 'total_icms_interestadual_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	totalIcmsInterestadualUfDestino: number; 

	@Column({ name: 'total_icms_interestadual_uf_remetente', type: 'decimal', precision: 18, scale: 6 }) 
	totalIcmsInterestadualUfRemetente: number; 

	@Column({ name: 'valor_total_fcp', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalFcp: number; 

	@Column({ name: 'base_calculo_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcmsSt: number; 

	@Column({ name: 'valor_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsSt: number; 

	@Column({ name: 'valor_total_fcp_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalFcpSt: number; 

	@Column({ name: 'valor_total_fcp_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalFcpStRetido: number; 

	@Column({ name: 'valor_total_produtos', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalProdutos: number; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 

	@Column({ name: 'valor_seguro', type: 'decimal', precision: 18, scale: 6 }) 
	valorSeguro: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_imposto_importacao', type: 'decimal', precision: 18, scale: 6 }) 
	valorImpostoImportacao: number; 

	@Column({ name: 'valor_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpi: number; 

	@Column({ name: 'valor_ipi_devolvido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpiDevolvido: number; 

	@Column({ name: 'valor_pis', type: 'decimal', precision: 18, scale: 6 }) 
	valorPis: number; 

	@Column({ name: 'valor_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofins: number; 

	@Column({ name: 'valor_despesas_acessorias', type: 'decimal', precision: 18, scale: 6 }) 
	valorDespesasAcessorias: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'valor_total_tributos', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalTributos: number; 

	@Column({ name: 'valor_servicos', type: 'decimal', precision: 18, scale: 6 }) 
	valorServicos: number; 

	@Column({ name: 'base_calculo_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIssqn: number; 

	@Column({ name: 'valor_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorIssqn: number; 

	@Column({ name: 'valor_pis_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorPisIssqn: number; 

	@Column({ name: 'valor_cofins_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofinsIssqn: number; 

	@Column({ name: 'data_prestacao_servico' }) 
	dataPrestacaoServico: Date; 

	@Column({ name: 'valor_deducao_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorDeducaoIssqn: number; 

	@Column({ name: 'outras_retencoes_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	outrasRetencoesIssqn: number; 

	@Column({ name: 'desconto_incondicionado_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	descontoIncondicionadoIssqn: number; 

	@Column({ name: 'desconto_condicionado_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	descontoCondicionadoIssqn: number; 

	@Column({ name: 'total_retencao_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	totalRetencaoIssqn: number; 

	@Column({ name: 'regime_especial_tributacao' }) 
	regimeEspecialTributacao: string; 

	@Column({ name: 'valor_retido_pis', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoPis: number; 

	@Column({ name: 'valor_retido_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoCofins: number; 

	@Column({ name: 'valor_retido_csll', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoCsll: number; 

	@Column({ name: 'base_calculo_irrf', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIrrf: number; 

	@Column({ name: 'valor_retido_irrf', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoIrrf: number; 

	@Column({ name: 'base_calculo_previdencia', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoPrevidencia: number; 

	@Column({ name: 'valor_retido_previdencia', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoPrevidencia: number; 

	@Column({ name: 'informacoes_add_fisco' }) 
	informacoesAddFisco: string; 

	@Column({ name: 'informacoes_add_contribuinte' }) 
	informacoesAddContribuinte: string; 

	@Column({ name: 'comex_uf_embarque' }) 
	comexUfEmbarque: string; 

	@Column({ name: 'comex_local_embarque' }) 
	comexLocalEmbarque: string; 

	@Column({ name: 'comex_local_despacho' }) 
	comexLocalDespacho: string; 

	@Column({ name: 'compra_nota_empenho' }) 
	compraNotaEmpenho: string; 

	@Column({ name: 'compra_pedido' }) 
	compraPedido: string; 

	@Column({ name: 'compra_contrato' }) 
	compraContrato: string; 

	@Column({ name: 'qrcode' }) 
	qrcode: string; 

	@Column({ name: 'url_chave' }) 
	urlChave: string; 

	@Column({ name: 'status_nota' }) 
	statusNota: string; 

	@Column({ name: 'id_fornecedor' }) 
	idFornecedor: number; 

	@Column({ name: 'id_nfce_movimento' }) 
	idNfceMovimento: number; 

	@Column({ name: 'id_venda_cabecalho' }) 
	idVendaCabecalho: number; 

	@Column({ name: 'id_tribut_operacao_fiscal' }) 
	idTributOperacaoFiscal: number; 

	@Column({ name: 'id_cliente' }) 
	idCliente: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idVendedor = jsonObj['idVendedor'];
			this.ufEmitente = jsonObj['ufEmitente'];
			this.codigoNumerico = jsonObj['codigoNumerico'];
			this.naturezaOperacao = jsonObj['naturezaOperacao'];
			this.codigoModelo = jsonObj['codigoModelo'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
			this.dataHoraEmissao = jsonObj['dataHoraEmissao'];
			this.dataHoraEntradaSaida = jsonObj['dataHoraEntradaSaida'];
			this.tipoOperacao = jsonObj['tipoOperacao'];
			this.localDestino = jsonObj['localDestino'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.formatoImpressaoDanfe = jsonObj['formatoImpressaoDanfe'];
			this.tipoEmissao = jsonObj['tipoEmissao'];
			this.chaveAcesso = jsonObj['chaveAcesso'];
			this.digitoChaveAcesso = jsonObj['digitoChaveAcesso'];
			this.ambiente = jsonObj['ambiente'];
			this.finalidadeEmissao = jsonObj['finalidadeEmissao'];
			this.consumidorOperacao = jsonObj['consumidorOperacao'];
			this.consumidorPresenca = jsonObj['consumidorPresenca'];
			this.processoEmissao = jsonObj['processoEmissao'];
			this.versaoProcessoEmissao = jsonObj['versaoProcessoEmissao'];
			this.dataEntradaContingencia = jsonObj['dataEntradaContingencia'];
			this.justificativaContingencia = jsonObj['justificativaContingencia'];
			this.baseCalculoIcms = jsonObj['baseCalculoIcms'];
			this.valorIcms = jsonObj['valorIcms'];
			this.valorIcmsDesonerado = jsonObj['valorIcmsDesonerado'];
			this.totalIcmsFcpUfDestino = jsonObj['totalIcmsFcpUfDestino'];
			this.totalIcmsInterestadualUfDestino = jsonObj['totalIcmsInterestadualUfDestino'];
			this.totalIcmsInterestadualUfRemetente = jsonObj['totalIcmsInterestadualUfRemetente'];
			this.valorTotalFcp = jsonObj['valorTotalFcp'];
			this.baseCalculoIcmsSt = jsonObj['baseCalculoIcmsSt'];
			this.valorIcmsSt = jsonObj['valorIcmsSt'];
			this.valorTotalFcpSt = jsonObj['valorTotalFcpSt'];
			this.valorTotalFcpStRetido = jsonObj['valorTotalFcpStRetido'];
			this.valorTotalProdutos = jsonObj['valorTotalProdutos'];
			this.valorFrete = jsonObj['valorFrete'];
			this.valorSeguro = jsonObj['valorSeguro'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorImpostoImportacao = jsonObj['valorImpostoImportacao'];
			this.valorIpi = jsonObj['valorIpi'];
			this.valorIpiDevolvido = jsonObj['valorIpiDevolvido'];
			this.valorPis = jsonObj['valorPis'];
			this.valorCofins = jsonObj['valorCofins'];
			this.valorDespesasAcessorias = jsonObj['valorDespesasAcessorias'];
			this.valorTotal = jsonObj['valorTotal'];
			this.valorTotalTributos = jsonObj['valorTotalTributos'];
			this.valorServicos = jsonObj['valorServicos'];
			this.baseCalculoIssqn = jsonObj['baseCalculoIssqn'];
			this.valorIssqn = jsonObj['valorIssqn'];
			this.valorPisIssqn = jsonObj['valorPisIssqn'];
			this.valorCofinsIssqn = jsonObj['valorCofinsIssqn'];
			this.dataPrestacaoServico = jsonObj['dataPrestacaoServico'];
			this.valorDeducaoIssqn = jsonObj['valorDeducaoIssqn'];
			this.outrasRetencoesIssqn = jsonObj['outrasRetencoesIssqn'];
			this.descontoIncondicionadoIssqn = jsonObj['descontoIncondicionadoIssqn'];
			this.descontoCondicionadoIssqn = jsonObj['descontoCondicionadoIssqn'];
			this.totalRetencaoIssqn = jsonObj['totalRetencaoIssqn'];
			this.regimeEspecialTributacao = jsonObj['regimeEspecialTributacao'];
			this.valorRetidoPis = jsonObj['valorRetidoPis'];
			this.valorRetidoCofins = jsonObj['valorRetidoCofins'];
			this.valorRetidoCsll = jsonObj['valorRetidoCsll'];
			this.baseCalculoIrrf = jsonObj['baseCalculoIrrf'];
			this.valorRetidoIrrf = jsonObj['valorRetidoIrrf'];
			this.baseCalculoPrevidencia = jsonObj['baseCalculoPrevidencia'];
			this.valorRetidoPrevidencia = jsonObj['valorRetidoPrevidencia'];
			this.informacoesAddFisco = jsonObj['informacoesAddFisco'];
			this.informacoesAddContribuinte = jsonObj['informacoesAddContribuinte'];
			this.comexUfEmbarque = jsonObj['comexUfEmbarque'];
			this.comexLocalEmbarque = jsonObj['comexLocalEmbarque'];
			this.comexLocalDespacho = jsonObj['comexLocalDespacho'];
			this.compraNotaEmpenho = jsonObj['compraNotaEmpenho'];
			this.compraPedido = jsonObj['compraPedido'];
			this.compraContrato = jsonObj['compraContrato'];
			this.qrcode = jsonObj['qrcode'];
			this.urlChave = jsonObj['urlChave'];
			this.statusNota = jsonObj['statusNota'];
			this.idFornecedor = jsonObj['idFornecedor'];
			this.idNfceMovimento = jsonObj['idNfceMovimento'];
			this.idVendaCabecalho = jsonObj['idVendaCabecalho'];
			this.idTributOperacaoFiscal = jsonObj['idTributOperacaoFiscal'];
			this.idCliente = jsonObj['idCliente'];
		}
	}
}