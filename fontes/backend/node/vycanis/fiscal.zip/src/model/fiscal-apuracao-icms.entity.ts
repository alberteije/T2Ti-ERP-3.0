import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'fiscal_apuracao_icms' })
export class FiscalApuracaoIcmsModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'valor_total_debito', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalDebito: number; 

	@Column({ name: 'valor_ajuste_debito', type: 'decimal', precision: 18, scale: 6 }) 
	valorAjusteDebito: number; 

	@Column({ name: 'valor_total_ajuste_debito', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalAjusteDebito: number; 

	@Column({ name: 'valor_estorno_credito', type: 'decimal', precision: 18, scale: 6 }) 
	valorEstornoCredito: number; 

	@Column({ name: 'valor_total_credito', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalCredito: number; 

	@Column({ name: 'valor_ajuste_credito', type: 'decimal', precision: 18, scale: 6 }) 
	valorAjusteCredito: number; 

	@Column({ name: 'valor_total_ajuste_credito', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalAjusteCredito: number; 

	@Column({ name: 'valor_estorno_debito', type: 'decimal', precision: 18, scale: 6 }) 
	valorEstornoDebito: number; 

	@Column({ name: 'valor_saldo_credor_anterior', type: 'decimal', precision: 18, scale: 6 }) 
	valorSaldoCredorAnterior: number; 

	@Column({ name: 'valor_saldo_apurado', type: 'decimal', precision: 18, scale: 6 }) 
	valorSaldoApurado: number; 

	@Column({ name: 'valor_total_deducao', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalDeducao: number; 

	@Column({ name: 'valor_icms_recolher', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsRecolher: number; 

	@Column({ name: 'valor_saldo_credor_transp', type: 'decimal', precision: 18, scale: 6 }) 
	valorSaldoCredorTransp: number; 

	@Column({ name: 'valor_debito_especial', type: 'decimal', precision: 18, scale: 6 }) 
	valorDebitoEspecial: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.valorTotalDebito = jsonObj['valorTotalDebito'];
			this.valorAjusteDebito = jsonObj['valorAjusteDebito'];
			this.valorTotalAjusteDebito = jsonObj['valorTotalAjusteDebito'];
			this.valorEstornoCredito = jsonObj['valorEstornoCredito'];
			this.valorTotalCredito = jsonObj['valorTotalCredito'];
			this.valorAjusteCredito = jsonObj['valorAjusteCredito'];
			this.valorTotalAjusteCredito = jsonObj['valorTotalAjusteCredito'];
			this.valorEstornoDebito = jsonObj['valorEstornoDebito'];
			this.valorSaldoCredorAnterior = jsonObj['valorSaldoCredorAnterior'];
			this.valorSaldoApurado = jsonObj['valorSaldoApurado'];
			this.valorTotalDeducao = jsonObj['valorTotalDeducao'];
			this.valorIcmsRecolher = jsonObj['valorIcmsRecolher'];
			this.valorSaldoCredorTransp = jsonObj['valorSaldoCredorTransp'];
			this.valorDebitoEspecial = jsonObj['valorDebitoEspecial'];
		}
	}
}