import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'fiscal_estadual_porte' })
export class FiscalEstadualPorteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.uf = jsonObj['uf'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
		}
	}
}