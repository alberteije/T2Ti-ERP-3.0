import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FiscalTermoModel } from '../entities-export';

@Entity({ name: 'fiscal_livro' })
export class FiscalLivroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FiscalTermoModel, fiscalTermoModel => fiscalTermoModel.fiscalLivroModel, { cascade: true })
	fiscalTermoModelList: FiscalTermoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.fiscalTermoModelList = [];
			let fiscalTermoModelJsonList = jsonObj['fiscalTermoModelList'];
			if (fiscalTermoModelJsonList != null) {
				for (let i = 0; i < fiscalTermoModelJsonList.length; i++) {
					let obj = new FiscalTermoModel(fiscalTermoModelJsonList[i]);
					this.fiscalTermoModelList.push(obj);
				}
			}

		}
	}
}