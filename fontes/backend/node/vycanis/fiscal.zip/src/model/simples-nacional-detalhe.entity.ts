import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { SimplesNacionalCabecalhoModel } from '../entities-export';

@Entity({ name: 'simples_nacional_detalhe' })
export class SimplesNacionalDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'faixa' }) 
	faixa: number; 

	@Column({ name: 'valor_inicial', type: 'decimal', precision: 18, scale: 6 }) 
	valorInicial: number; 

	@Column({ name: 'valor_final', type: 'decimal', precision: 18, scale: 6 }) 
	valorFinal: number; 

	@Column({ name: 'aliquota', type: 'decimal', precision: 18, scale: 6 }) 
	aliquota: number; 

	@Column({ name: 'irpj', type: 'decimal', precision: 18, scale: 6 }) 
	irpj: number; 

	@Column({ name: 'csll', type: 'decimal', precision: 18, scale: 6 }) 
	csll: number; 

	@Column({ name: 'cofins', type: 'decimal', precision: 18, scale: 6 }) 
	cofins: number; 

	@Column({ name: 'pis_pasep', type: 'decimal', precision: 18, scale: 6 }) 
	pisPasep: number; 

	@Column({ name: 'cpp', type: 'decimal', precision: 18, scale: 6 }) 
	cpp: number; 

	@Column({ name: 'icms', type: 'decimal', precision: 18, scale: 6 }) 
	icms: number; 

	@Column({ name: 'ipi', type: 'decimal', precision: 18, scale: 6 }) 
	ipi: number; 

	@Column({ name: 'iss', type: 'decimal', precision: 18, scale: 6 }) 
	iss: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => SimplesNacionalCabecalhoModel, simplesNacionalCabecalhoModel => simplesNacionalCabecalhoModel.simplesNacionalDetalheModelList)
	@JoinColumn({ name: 'id_simples_nacional_cabecalho' })
	simplesNacionalCabecalhoModel: SimplesNacionalCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.faixa = jsonObj['faixa'];
			this.valorInicial = jsonObj['valorInicial'];
			this.valorFinal = jsonObj['valorFinal'];
			this.aliquota = jsonObj['aliquota'];
			this.irpj = jsonObj['irpj'];
			this.csll = jsonObj['csll'];
			this.cofins = jsonObj['cofins'];
			this.pisPasep = jsonObj['pisPasep'];
			this.cpp = jsonObj['cpp'];
			this.icms = jsonObj['icms'];
			this.ipi = jsonObj['ipi'];
			this.iss = jsonObj['iss'];
		}
	}
}