import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeCabecalhoService } from '../service/nfe-cabecalho.service';
import { NfeCabecalhoModel } from '../model/nfe-cabecalho.entity';

@Crud({
  model: {
    type: NfeCabecalhoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-cabecalho')
export class NfeCabecalhoController implements CrudController<NfeCabecalhoModel> {
  constructor(public service: NfeCabecalhoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeCabecalhoModel = new NfeCabecalhoModel(jsonObj);
		const result = await this.service.save(nfeCabecalhoModel);
		return result;
	}  


}


















