import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FiscalParametroService } from '../service/fiscal-parametro.service';
import { FiscalParametroModel } from '../model/fiscal-parametro.entity';

@Crud({
  model: {
    type: FiscalParametroModel,
  },
  query: {
    join: {
			fiscalInscricoesSubstitutasModelList: { eager: true },
			fiscalEstadualRegimeModel: { eager: true },
			fiscalEstadualPorteModel: { eager: true },
			fiscalMunicipalRegimeModel: { eager: true },
    },
  },
})
@Controller('fiscal-parametro')
export class FiscalParametroController implements CrudController<FiscalParametroModel> {
  constructor(public service: FiscalParametroService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalParametro = new FiscalParametroModel(jsonObj);
		const result = await this.service.save(fiscalParametro, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalParametro = new FiscalParametroModel(jsonObj);
		const result = await this.service.save(fiscalParametro, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}