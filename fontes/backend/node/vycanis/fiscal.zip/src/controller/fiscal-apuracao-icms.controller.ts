import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FiscalApuracaoIcmsService } from '../service/fiscal-apuracao-icms.service';
import { FiscalApuracaoIcmsModel } from '../model/fiscal-apuracao-icms.entity';

@Crud({
  model: {
    type: FiscalApuracaoIcmsModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fiscal-apuracao-icms')
export class FiscalApuracaoIcmsController implements CrudController<FiscalApuracaoIcmsModel> {
  constructor(public service: FiscalApuracaoIcmsService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalApuracaoIcmsModel = new FiscalApuracaoIcmsModel(jsonObj);
		const result = await this.service.save(fiscalApuracaoIcmsModel);
		return result;
	}  


}


















