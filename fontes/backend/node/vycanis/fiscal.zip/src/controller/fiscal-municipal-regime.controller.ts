import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FiscalMunicipalRegimeService } from '../service/fiscal-municipal-regime.service';
import { FiscalMunicipalRegimeModel } from '../model/fiscal-municipal-regime.entity';

@Crud({
  model: {
    type: FiscalMunicipalRegimeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fiscal-municipal-regime')
export class FiscalMunicipalRegimeController implements CrudController<FiscalMunicipalRegimeModel> {
  constructor(public service: FiscalMunicipalRegimeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalMunicipalRegimeModel = new FiscalMunicipalRegimeModel(jsonObj);
		const result = await this.service.save(fiscalMunicipalRegimeModel);
		return result;
	}  


}


















