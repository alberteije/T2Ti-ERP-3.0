import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FiscalEstadualPorteService } from '../service/fiscal-estadual-porte.service';
import { FiscalEstadualPorteModel } from '../model/fiscal-estadual-porte.entity';

@Crud({
  model: {
    type: FiscalEstadualPorteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fiscal-estadual-porte')
export class FiscalEstadualPorteController implements CrudController<FiscalEstadualPorteModel> {
  constructor(public service: FiscalEstadualPorteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalEstadualPorteModel = new FiscalEstadualPorteModel(jsonObj);
		const result = await this.service.save(fiscalEstadualPorteModel);
		return result;
	}  


}


















