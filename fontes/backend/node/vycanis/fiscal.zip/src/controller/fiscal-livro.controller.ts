import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FiscalLivroService } from '../service/fiscal-livro.service';
import { FiscalLivroModel } from '../model/fiscal-livro.entity';

@Crud({
  model: {
    type: FiscalLivroModel,
  },
  query: {
    join: {
			fiscalTermoModelList: { eager: true },
    },
  },
})
@Controller('fiscal-livro')
export class FiscalLivroController implements CrudController<FiscalLivroModel> {
  constructor(public service: FiscalLivroService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalLivro = new FiscalLivroModel(jsonObj);
		const result = await this.service.save(fiscalLivro, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalLivro = new FiscalLivroModel(jsonObj);
		const result = await this.service.save(fiscalLivro, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}