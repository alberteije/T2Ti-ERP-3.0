import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FiscalNotaFiscalEntradaService } from '../service/fiscal-nota-fiscal-entrada.service';
import { FiscalNotaFiscalEntradaModel } from '../model/fiscal-nota-fiscal-entrada.entity';

@Crud({
  model: {
    type: FiscalNotaFiscalEntradaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fiscal-nota-fiscal-entrada')
export class FiscalNotaFiscalEntradaController implements CrudController<FiscalNotaFiscalEntradaModel> {
  constructor(public service: FiscalNotaFiscalEntradaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalNotaFiscalEntradaModel = new FiscalNotaFiscalEntradaModel(jsonObj);
		const result = await this.service.save(fiscalNotaFiscalEntradaModel);
		return result;
	}  


}


















