import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { SimplesNacionalCabecalhoModel } from '../entities-export';

@Injectable()
export class SimplesNacionalCabecalhoService extends TypeOrmCrudService<SimplesNacionalCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(SimplesNacionalCabecalhoModel) 
    private readonly repository: Repository<SimplesNacionalCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(simplesNacionalCabecalhoModel: SimplesNacionalCabecalhoModel, operation: string): Promise<SimplesNacionalCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, simplesNacionalCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(simplesNacionalCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(SimplesNacionalCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from simples_nacional_detalhe where id_simples_nacional_cabecalho=' + id); 

	}
	
}