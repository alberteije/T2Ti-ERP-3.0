import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { FiscalLivroModel } from '../entities-export';

@Injectable()
export class FiscalLivroService extends TypeOrmCrudService<FiscalLivroModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(FiscalLivroModel) 
    private readonly repository: Repository<FiscalLivroModel>,
  ) {
    super(repository);
  }

	async save(fiscalLivroModel: FiscalLivroModel, operation: string): Promise<FiscalLivroModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, fiscalLivroModel.id);
      }

      const resultObj = await queryRunner.manager.save(fiscalLivroModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(FiscalLivroModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from fiscal_termo where id_fiscal_livro=' + id); 

	}
	
}