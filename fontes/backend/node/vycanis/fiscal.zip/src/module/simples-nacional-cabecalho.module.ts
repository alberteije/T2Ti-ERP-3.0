import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SimplesNacionalCabecalhoController } from '../controller/simples-nacional-cabecalho.controller';
import { SimplesNacionalCabecalhoService } from '../service/simples-nacional-cabecalho.service';
import { SimplesNacionalCabecalhoModel } from '../model/simples-nacional-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SimplesNacionalCabecalhoModel])],
    controllers: [SimplesNacionalCabecalhoController],
    providers: [SimplesNacionalCabecalhoService],
})
export class SimplesNacionalCabecalhoModule { }
