import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalNotaFiscalEntradaController } from '../controller/fiscal-nota-fiscal-entrada.controller';
import { FiscalNotaFiscalEntradaService } from '../service/fiscal-nota-fiscal-entrada.service';
import { FiscalNotaFiscalEntradaModel } from '../model/fiscal-nota-fiscal-entrada.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalNotaFiscalEntradaModel])],
    controllers: [FiscalNotaFiscalEntradaController],
    providers: [FiscalNotaFiscalEntradaService],
})
export class FiscalNotaFiscalEntradaModule { }
