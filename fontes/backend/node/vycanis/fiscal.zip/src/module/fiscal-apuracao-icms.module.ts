import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalApuracaoIcmsController } from '../controller/fiscal-apuracao-icms.controller';
import { FiscalApuracaoIcmsService } from '../service/fiscal-apuracao-icms.service';
import { FiscalApuracaoIcmsModel } from '../model/fiscal-apuracao-icms.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalApuracaoIcmsModel])],
    controllers: [FiscalApuracaoIcmsController],
    providers: [FiscalApuracaoIcmsService],
})
export class FiscalApuracaoIcmsModule { }
