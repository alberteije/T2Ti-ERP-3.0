import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalEstadualRegimeController } from '../controller/fiscal-estadual-regime.controller';
import { FiscalEstadualRegimeService } from '../service/fiscal-estadual-regime.service';
import { FiscalEstadualRegimeModel } from '../model/fiscal-estadual-regime.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalEstadualRegimeModel])],
    controllers: [FiscalEstadualRegimeController],
    providers: [FiscalEstadualRegimeService],
})
export class FiscalEstadualRegimeModule { }
