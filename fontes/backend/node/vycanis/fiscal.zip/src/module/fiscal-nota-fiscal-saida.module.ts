import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalNotaFiscalSaidaController } from '../controller/fiscal-nota-fiscal-saida.controller';
import { FiscalNotaFiscalSaidaService } from '../service/fiscal-nota-fiscal-saida.service';
import { FiscalNotaFiscalSaidaModel } from '../model/fiscal-nota-fiscal-saida.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalNotaFiscalSaidaModel])],
    controllers: [FiscalNotaFiscalSaidaController],
    providers: [FiscalNotaFiscalSaidaService],
})
export class FiscalNotaFiscalSaidaModule { }
