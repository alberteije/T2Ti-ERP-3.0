import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalParametroController } from '../controller/fiscal-parametro.controller';
import { FiscalParametroService } from '../service/fiscal-parametro.service';
import { FiscalParametroModel } from '../model/fiscal-parametro.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalParametroModel])],
    controllers: [FiscalParametroController],
    providers: [FiscalParametroService],
})
export class FiscalParametroModule { }
