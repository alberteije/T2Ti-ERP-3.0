import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalLivroController } from '../controller/fiscal-livro.controller';
import { FiscalLivroService } from '../service/fiscal-livro.service';
import { FiscalLivroModel } from '../model/fiscal-livro.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalLivroModel])],
    controllers: [FiscalLivroController],
    providers: [FiscalLivroService],
})
export class FiscalLivroModule { }
