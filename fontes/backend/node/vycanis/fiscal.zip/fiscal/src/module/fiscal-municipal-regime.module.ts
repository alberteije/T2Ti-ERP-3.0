import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalMunicipalRegimeController } from '../controller/fiscal-municipal-regime.controller';
import { FiscalMunicipalRegimeService } from '../service/fiscal-municipal-regime.service';
import { FiscalMunicipalRegimeModel } from '../model/fiscal-municipal-regime.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalMunicipalRegimeModel])],
    controllers: [FiscalMunicipalRegimeController],
    providers: [FiscalMunicipalRegimeService],
})
export class FiscalMunicipalRegimeModule { }
