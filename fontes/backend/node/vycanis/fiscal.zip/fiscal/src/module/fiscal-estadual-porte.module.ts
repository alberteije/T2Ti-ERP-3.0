import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FiscalEstadualPorteController } from '../controller/fiscal-estadual-porte.controller';
import { FiscalEstadualPorteService } from '../service/fiscal-estadual-porte.service';
import { FiscalEstadualPorteModel } from '../model/fiscal-estadual-porte.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FiscalEstadualPorteModel])],
    controllers: [FiscalEstadualPorteController],
    providers: [FiscalEstadualPorteService],
})
export class FiscalEstadualPorteModule { }
