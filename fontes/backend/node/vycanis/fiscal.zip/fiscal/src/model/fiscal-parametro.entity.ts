import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FiscalInscricoesSubstitutasModel } from '../entities-export';
import { FiscalEstadualRegimeModel } from '../entities-export';
import { FiscalEstadualPorteModel } from '../entities-export';
import { FiscalMunicipalRegimeModel } from '../entities-export';

@Entity({ name: 'fiscal_parametro' })
export class FiscalParametroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'vigencia' }) 
	vigencia: string; 

	@Column({ name: 'descricao_vigencia' }) 
	descricaoVigencia: string; 

	@Column({ name: 'criterio_lancamento' }) 
	criterioLancamento: string; 

	@Column({ name: 'apuracao' }) 
	apuracao: string; 

	@Column({ name: 'microempree_individual' }) 
	microempreeIndividual: string; 

	@Column({ name: 'calc_pis_cofins_efd' }) 
	calcPisCofinsEfd: string; 

	@Column({ name: 'simples_codigo_acesso' }) 
	simplesCodigoAcesso: string; 

	@Column({ name: 'simples_tabela' }) 
	simplesTabela: string; 

	@Column({ name: 'simples_atividade' }) 
	simplesAtividade: string; 

	@Column({ name: 'perfil_sped' }) 
	perfilSped: string; 

	@Column({ name: 'apuracao_consolidada' }) 
	apuracaoConsolidada: string; 

	@Column({ name: 'substituicao_tributaria' }) 
	substituicaoTributaria: string; 

	@Column({ name: 'forma_calculo_iss' }) 
	formaCalculoIss: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FiscalInscricoesSubstitutasModel, fiscalInscricoesSubstitutasModel => fiscalInscricoesSubstitutasModel.fiscalParametroModel, { cascade: true })
	fiscalInscricoesSubstitutasModelList: FiscalInscricoesSubstitutasModel[];

	@OneToOne(() => FiscalEstadualRegimeModel)
	@JoinColumn({ name: 'id_fiscal_estadual_regime' })
	fiscalEstadualRegimeModel: FiscalEstadualRegimeModel;

	@OneToOne(() => FiscalEstadualPorteModel)
	@JoinColumn({ name: 'id_fiscal_estadual_porte' })
	fiscalEstadualPorteModel: FiscalEstadualPorteModel;

	@OneToOne(() => FiscalMunicipalRegimeModel)
	@JoinColumn({ name: 'id_fiscal_municipal_regime' })
	fiscalMunicipalRegimeModel: FiscalMunicipalRegimeModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.vigencia = jsonObj['vigencia'];
			this.descricaoVigencia = jsonObj['descricaoVigencia'];
			this.criterioLancamento = jsonObj['criterioLancamento'];
			this.apuracao = jsonObj['apuracao'];
			this.microempreeIndividual = jsonObj['microempreeIndividual'];
			this.calcPisCofinsEfd = jsonObj['calcPisCofinsEfd'];
			this.simplesCodigoAcesso = jsonObj['simplesCodigoAcesso'];
			this.simplesTabela = jsonObj['simplesTabela'];
			this.simplesAtividade = jsonObj['simplesAtividade'];
			this.perfilSped = jsonObj['perfilSped'];
			this.apuracaoConsolidada = jsonObj['apuracaoConsolidada'];
			this.substituicaoTributaria = jsonObj['substituicaoTributaria'];
			this.formaCalculoIss = jsonObj['formaCalculoIss'];
			if (jsonObj['fiscalEstadualRegimeModel'] != null) {
				this.fiscalEstadualRegimeModel = new FiscalEstadualRegimeModel(jsonObj['fiscalEstadualRegimeModel']);
			}

			if (jsonObj['fiscalEstadualPorteModel'] != null) {
				this.fiscalEstadualPorteModel = new FiscalEstadualPorteModel(jsonObj['fiscalEstadualPorteModel']);
			}

			if (jsonObj['fiscalMunicipalRegimeModel'] != null) {
				this.fiscalMunicipalRegimeModel = new FiscalMunicipalRegimeModel(jsonObj['fiscalMunicipalRegimeModel']);
			}

			this.fiscalInscricoesSubstitutasModelList = [];
			let fiscalInscricoesSubstitutasModelJsonList = jsonObj['fiscalInscricoesSubstitutasModelList'];
			if (fiscalInscricoesSubstitutasModelJsonList != null) {
				for (let i = 0; i < fiscalInscricoesSubstitutasModelJsonList.length; i++) {
					let obj = new FiscalInscricoesSubstitutasModel(fiscalInscricoesSubstitutasModelJsonList[i]);
					this.fiscalInscricoesSubstitutasModelList.push(obj);
				}
			}

		}
	}
}