import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FiscalLivroModel } from '../entities-export';

@Entity({ name: 'fiscal_termo' })
export class FiscalTermoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'abertura_encerramento' }) 
	aberturaEncerramento: string; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'pagina_inicial' }) 
	paginaInicial: number; 

	@Column({ name: 'pagina_final' }) 
	paginaFinal: number; 

	@Column({ name: 'numero_registro' }) 
	numeroRegistro: string; 

	@Column({ name: 'registrado' }) 
	registrado: string; 

	@Column({ name: 'data_despacho' }) 
	dataDespacho: Date; 

	@Column({ name: 'data_abertura' }) 
	dataAbertura: Date; 

	@Column({ name: 'data_encerramento' }) 
	dataEncerramento: Date; 

	@Column({ name: 'escrituracao_inicio' }) 
	escrituracaoInicio: Date; 

	@Column({ name: 'escrituracao_fim' }) 
	escrituracaoFim: Date; 

	@Column({ name: 'texto' }) 
	texto: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FiscalLivroModel, fiscalLivroModel => fiscalLivroModel.fiscalTermoModelList)
	@JoinColumn({ name: 'id_fiscal_livro' })
	fiscalLivroModel: FiscalLivroModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.aberturaEncerramento = jsonObj['aberturaEncerramento'];
			this.numero = jsonObj['numero'];
			this.paginaInicial = jsonObj['paginaInicial'];
			this.paginaFinal = jsonObj['paginaFinal'];
			this.numeroRegistro = jsonObj['numeroRegistro'];
			this.registrado = jsonObj['registrado'];
			this.dataDespacho = jsonObj['dataDespacho'];
			this.dataAbertura = jsonObj['dataAbertura'];
			this.dataEncerramento = jsonObj['dataEncerramento'];
			this.escrituracaoInicio = jsonObj['escrituracaoInicio'];
			this.escrituracaoFim = jsonObj['escrituracaoFim'];
			this.texto = jsonObj['texto'];
		}
	}
}