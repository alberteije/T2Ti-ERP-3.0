import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { SimplesNacionalDetalheModel } from '../entities-export';

@Entity({ name: 'simples_nacional_cabecalho' })
export class SimplesNacionalCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'vigencia_inicial' }) 
	vigenciaInicial: Date; 

	@Column({ name: 'vigencia_final' }) 
	vigenciaFinal: Date; 

	@Column({ name: 'anexo' }) 
	anexo: string; 

	@Column({ name: 'tabela' }) 
	tabela: string; 


	/**
	* Relations
	*/
	@OneToMany(() => SimplesNacionalDetalheModel, simplesNacionalDetalheModel => simplesNacionalDetalheModel.simplesNacionalCabecalhoModel, { cascade: true })
	simplesNacionalDetalheModelList: SimplesNacionalDetalheModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.vigenciaInicial = jsonObj['vigenciaInicial'];
			this.vigenciaFinal = jsonObj['vigenciaFinal'];
			this.anexo = jsonObj['anexo'];
			this.tabela = jsonObj['tabela'];
			this.simplesNacionalDetalheModelList = [];
			let simplesNacionalDetalheModelJsonList = jsonObj['simplesNacionalDetalheModelList'];
			if (simplesNacionalDetalheModelJsonList != null) {
				for (let i = 0; i < simplesNacionalDetalheModelJsonList.length; i++) {
					let obj = new SimplesNacionalDetalheModel(simplesNacionalDetalheModelJsonList[i]);
					this.simplesNacionalDetalheModelList.push(obj);
				}
			}

		}
	}
}