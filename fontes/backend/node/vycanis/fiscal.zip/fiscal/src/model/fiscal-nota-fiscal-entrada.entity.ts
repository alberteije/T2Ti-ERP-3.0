import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'fiscal_nota_fiscal_entrada' })
export class FiscalNotaFiscalEntradaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'cfop_entrada' }) 
	cfopEntrada: number; 

	@Column({ name: 'valor_rateio_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorRateioFrete: number; 

	@Column({ name: 'valor_custo_medio', type: 'decimal', precision: 18, scale: 6 }) 
	valorCustoMedio: number; 

	@Column({ name: 'valor_icms_antecipado', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsAntecipado: number; 

	@Column({ name: 'valor_bc_icms_antecipado', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcmsAntecipado: number; 

	@Column({ name: 'valor_bc_icms_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcmsCreditado: number; 

	@Column({ name: 'valor_bc_pis_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcPisCreditado: number; 

	@Column({ name: 'valor_bc_cofins_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcCofinsCreditado: number; 

	@Column({ name: 'valor_bc_ipi_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIpiCreditado: number; 

	@Column({ name: 'cst_credito_icms' }) 
	cstCreditoIcms: string; 

	@Column({ name: 'cst_credito_pis' }) 
	cstCreditoPis: string; 

	@Column({ name: 'cst_credito_cofins' }) 
	cstCreditoCofins: string; 

	@Column({ name: 'cst_credito_ipi' }) 
	cstCreditoIpi: string; 

	@Column({ name: 'valor_icms_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsCreditado: number; 

	@Column({ name: 'valor_pis_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorPisCreditado: number; 

	@Column({ name: 'valor_cofins_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofinsCreditado: number; 

	@Column({ name: 'valor_ipi_creditado', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpiCreditado: number; 

	@Column({ name: 'qtde_parcela_credito_pis' }) 
	qtdeParcelaCreditoPis: number; 

	@Column({ name: 'qtde_parcela_credito_cofins' }) 
	qtdeParcelaCreditoCofins: number; 

	@Column({ name: 'qtde_parcela_credito_icms' }) 
	qtdeParcelaCreditoIcms: number; 

	@Column({ name: 'qtde_parcela_credito_ipi' }) 
	qtdeParcelaCreditoIpi: number; 

	@Column({ name: 'aliquota_credito_icms', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCreditoIcms: number; 

	@Column({ name: 'aliquota_credito_pis', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCreditoPis: number; 

	@Column({ name: 'aliquota_credito_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCreditoCofins: number; 

	@Column({ name: 'aliquota_credito_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCreditoIpi: number; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeCabecalhoModel)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.cfopEntrada = jsonObj['cfopEntrada'];
			this.valorRateioFrete = jsonObj['valorRateioFrete'];
			this.valorCustoMedio = jsonObj['valorCustoMedio'];
			this.valorIcmsAntecipado = jsonObj['valorIcmsAntecipado'];
			this.valorBcIcmsAntecipado = jsonObj['valorBcIcmsAntecipado'];
			this.valorBcIcmsCreditado = jsonObj['valorBcIcmsCreditado'];
			this.valorBcPisCreditado = jsonObj['valorBcPisCreditado'];
			this.valorBcCofinsCreditado = jsonObj['valorBcCofinsCreditado'];
			this.valorBcIpiCreditado = jsonObj['valorBcIpiCreditado'];
			this.cstCreditoIcms = jsonObj['cstCreditoIcms'];
			this.cstCreditoPis = jsonObj['cstCreditoPis'];
			this.cstCreditoCofins = jsonObj['cstCreditoCofins'];
			this.cstCreditoIpi = jsonObj['cstCreditoIpi'];
			this.valorIcmsCreditado = jsonObj['valorIcmsCreditado'];
			this.valorPisCreditado = jsonObj['valorPisCreditado'];
			this.valorCofinsCreditado = jsonObj['valorCofinsCreditado'];
			this.valorIpiCreditado = jsonObj['valorIpiCreditado'];
			this.qtdeParcelaCreditoPis = jsonObj['qtdeParcelaCreditoPis'];
			this.qtdeParcelaCreditoCofins = jsonObj['qtdeParcelaCreditoCofins'];
			this.qtdeParcelaCreditoIcms = jsonObj['qtdeParcelaCreditoIcms'];
			this.qtdeParcelaCreditoIpi = jsonObj['qtdeParcelaCreditoIpi'];
			this.aliquotaCreditoIcms = jsonObj['aliquotaCreditoIcms'];
			this.aliquotaCreditoPis = jsonObj['aliquotaCreditoPis'];
			this.aliquotaCreditoCofins = jsonObj['aliquotaCreditoCofins'];
			this.aliquotaCreditoIpi = jsonObj['aliquotaCreditoIpi'];
			if (jsonObj['nfeCabecalhoModel'] != null) {
				this.nfeCabecalhoModel = new NfeCabecalhoModel(jsonObj['nfeCabecalhoModel']);
			}

		}
	}
}