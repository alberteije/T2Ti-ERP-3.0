import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FiscalNotaFiscalSaidaService } from '../service/fiscal-nota-fiscal-saida.service';
import { FiscalNotaFiscalSaidaModel } from '../model/fiscal-nota-fiscal-saida.entity';

@Crud({
  model: {
    type: FiscalNotaFiscalSaidaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fiscal-nota-fiscal-saida')
export class FiscalNotaFiscalSaidaController implements CrudController<FiscalNotaFiscalSaidaModel> {
  constructor(public service: FiscalNotaFiscalSaidaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalNotaFiscalSaidaModel = new FiscalNotaFiscalSaidaModel(jsonObj);
		const result = await this.service.save(fiscalNotaFiscalSaidaModel);
		return result;
	}  


}


















