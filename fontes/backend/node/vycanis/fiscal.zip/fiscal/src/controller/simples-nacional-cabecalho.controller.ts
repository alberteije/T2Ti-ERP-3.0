import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { SimplesNacionalCabecalhoService } from '../service/simples-nacional-cabecalho.service';
import { SimplesNacionalCabecalhoModel } from '../model/simples-nacional-cabecalho.entity';

@Crud({
  model: {
    type: SimplesNacionalCabecalhoModel,
  },
  query: {
    join: {
			simplesNacionalDetalheModelList: { eager: true },
    },
  },
})
@Controller('simples-nacional-cabecalho')
export class SimplesNacionalCabecalhoController implements CrudController<SimplesNacionalCabecalhoModel> {
  constructor(public service: SimplesNacionalCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const simplesNacionalCabecalho = new SimplesNacionalCabecalhoModel(jsonObj);
		const result = await this.service.save(simplesNacionalCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const simplesNacionalCabecalho = new SimplesNacionalCabecalhoModel(jsonObj);
		const result = await this.service.save(simplesNacionalCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}