import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FiscalEstadualRegimeService } from '../service/fiscal-estadual-regime.service';
import { FiscalEstadualRegimeModel } from '../model/fiscal-estadual-regime.entity';

@Crud({
  model: {
    type: FiscalEstadualRegimeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fiscal-estadual-regime')
export class FiscalEstadualRegimeController implements CrudController<FiscalEstadualRegimeModel> {
  constructor(public service: FiscalEstadualRegimeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fiscalEstadualRegimeModel = new FiscalEstadualRegimeModel(jsonObj);
		const result = await this.service.save(fiscalEstadualRegimeModel);
		return result;
	}  


}


















