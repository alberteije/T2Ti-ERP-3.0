import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FiscalApuracaoIcmsModel } from '../entities-export';

@Injectable()
export class FiscalApuracaoIcmsService extends TypeOrmCrudService<FiscalApuracaoIcmsModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FiscalApuracaoIcmsModel)
    private readonly repository: Repository<FiscalApuracaoIcmsModel>
  ) {
    super(repository);
  }

	async save(fiscalApuracaoIcmsModel: FiscalApuracaoIcmsModel): Promise<FiscalApuracaoIcmsModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(fiscalApuracaoIcmsModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
