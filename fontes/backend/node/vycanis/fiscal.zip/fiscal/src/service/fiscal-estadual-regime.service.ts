import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FiscalEstadualRegimeModel } from '../entities-export';

@Injectable()
export class FiscalEstadualRegimeService extends TypeOrmCrudService<FiscalEstadualRegimeModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FiscalEstadualRegimeModel)
    private readonly repository: Repository<FiscalEstadualRegimeModel>
  ) {
    super(repository);
  }

	async save(fiscalEstadualRegimeModel: FiscalEstadualRegimeModel): Promise<FiscalEstadualRegimeModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(fiscalEstadualRegimeModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
