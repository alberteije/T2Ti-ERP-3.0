import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FiscalNotaFiscalEntradaModel } from '../entities-export';

@Injectable()
export class FiscalNotaFiscalEntradaService extends TypeOrmCrudService<FiscalNotaFiscalEntradaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FiscalNotaFiscalEntradaModel)
    private readonly repository: Repository<FiscalNotaFiscalEntradaModel>
  ) {
    super(repository);
  }

	async save(fiscalNotaFiscalEntradaModel: FiscalNotaFiscalEntradaModel): Promise<FiscalNotaFiscalEntradaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(fiscalNotaFiscalEntradaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
