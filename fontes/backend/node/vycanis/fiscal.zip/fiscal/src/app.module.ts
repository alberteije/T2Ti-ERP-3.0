import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { FiscalParametroModule } from './modules-export';
import { FiscalLivroModule } from './modules-export';
import { SimplesNacionalCabecalhoModule } from './modules-export';
import { NfeCabecalhoModule } from './modules-export';
import { FiscalMunicipalRegimeModule } from './modules-export';
import { FiscalEstadualRegimeModule } from './modules-export';
import { FiscalEstadualPorteModule } from './modules-export';
import { FiscalNotaFiscalEntradaModule } from './modules-export';
import { FiscalApuracaoIcmsModule } from './modules-export';
import { FiscalNotaFiscalSaidaModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';
import { AuditoriaModule } from './modules-export';
import { UsuarioTokenModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			FiscalParametroModule,
			FiscalLivroModule,
			SimplesNacionalCabecalhoModule,
			NfeCabecalhoModule,
			FiscalMunicipalRegimeModule,
			FiscalEstadualRegimeModule,
			FiscalEstadualPorteModule,
			FiscalNotaFiscalEntradaModule,
			FiscalApuracaoIcmsModule,
			FiscalNotaFiscalSaidaModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
      LoginModule,
      AuditoriaModule,
      UsuarioTokenModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],

  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}