import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ReuniaoSalaModel } from '../entities-export';

@Injectable()
export class ReuniaoSalaService extends TypeOrmCrudService<ReuniaoSalaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ReuniaoSalaModel)
    private readonly repository: Repository<ReuniaoSalaModel>
  ) {
    super(repository);
  }

	async save(reuniaoSalaModel: ReuniaoSalaModel): Promise<ReuniaoSalaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(reuniaoSalaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
