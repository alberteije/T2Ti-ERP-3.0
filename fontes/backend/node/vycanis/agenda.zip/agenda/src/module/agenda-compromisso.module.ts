import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AgendaCompromissoController } from '../controller/agenda-compromisso.controller';
import { AgendaCompromissoService } from '../service/agenda-compromisso.service';
import { AgendaCompromissoModel } from '../model/agenda-compromisso.entity';

@Module({
    imports: [TypeOrmModule.forFeature([AgendaCompromissoModel])],
    controllers: [AgendaCompromissoController],
    providers: [AgendaCompromissoService],
})
export class AgendaCompromissoModule { }
