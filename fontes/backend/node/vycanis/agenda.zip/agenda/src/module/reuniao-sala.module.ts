import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReuniaoSalaController } from '../controller/reuniao-sala.controller';
import { ReuniaoSalaService } from '../service/reuniao-sala.service';
import { ReuniaoSalaModel } from '../model/reuniao-sala.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ReuniaoSalaModel])],
    controllers: [ReuniaoSalaController],
    providers: [ReuniaoSalaService],
})
export class ReuniaoSalaModule { }
