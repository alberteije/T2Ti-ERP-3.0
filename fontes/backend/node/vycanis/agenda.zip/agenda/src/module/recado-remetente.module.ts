import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecadoRemetenteController } from '../controller/recado-remetente.controller';
import { RecadoRemetenteService } from '../service/recado-remetente.service';
import { RecadoRemetenteModel } from '../model/recado-remetente.entity';

@Module({
    imports: [TypeOrmModule.forFeature([RecadoRemetenteModel])],
    controllers: [RecadoRemetenteController],
    providers: [RecadoRemetenteService],
})
export class RecadoRemetenteModule { }
