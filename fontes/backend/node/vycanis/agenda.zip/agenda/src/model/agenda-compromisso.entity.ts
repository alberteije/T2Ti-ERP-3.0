import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { AgendaNotificacaoModel } from '../entities-export';
import { AgendaCompromissoConvidadoModel } from '../entities-export';
import { ReuniaoSalaEventoModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { AgendaCategoriaCompromissoModel } from '../entities-export';

@Entity({ name: 'agenda_compromisso' })
export class AgendaCompromissoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_compromisso' }) 
	dataCompromisso: Date; 

	@Column({ name: 'hora' }) 
	hora: string; 

	@Column({ name: 'duracao' }) 
	duracao: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'onde' }) 
	onde: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => AgendaNotificacaoModel, agendaNotificacaoModel => agendaNotificacaoModel.agendaCompromissoModel, { cascade: true })
	agendaNotificacaoModelList: AgendaNotificacaoModel[];

	@OneToMany(() => AgendaCompromissoConvidadoModel, agendaCompromissoConvidadoModel => agendaCompromissoConvidadoModel.agendaCompromissoModel, { cascade: true })
	agendaCompromissoConvidadoModelList: AgendaCompromissoConvidadoModel[];

	@OneToMany(() => ReuniaoSalaEventoModel, reuniaoSalaEventoModel => reuniaoSalaEventoModel.agendaCompromissoModel, { cascade: true })
	reuniaoSalaEventoModelList: ReuniaoSalaEventoModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => AgendaCategoriaCompromissoModel)
	@JoinColumn({ name: 'id_agenda_categoria_compromisso' })
	agendaCategoriaCompromissoModel: AgendaCategoriaCompromissoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataCompromisso = jsonObj['dataCompromisso'];
			this.hora = jsonObj['hora'];
			this.duracao = jsonObj['duracao'];
			this.tipo = jsonObj['tipo'];
			this.onde = jsonObj['onde'];
			this.descricao = jsonObj['descricao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['agendaCategoriaCompromissoModel'] != null) {
				this.agendaCategoriaCompromissoModel = new AgendaCategoriaCompromissoModel(jsonObj['agendaCategoriaCompromissoModel']);
			}

			this.agendaNotificacaoModelList = [];
			let agendaNotificacaoModelJsonList = jsonObj['agendaNotificacaoModelList'];
			if (agendaNotificacaoModelJsonList != null) {
				for (let i = 0; i < agendaNotificacaoModelJsonList.length; i++) {
					let obj = new AgendaNotificacaoModel(agendaNotificacaoModelJsonList[i]);
					this.agendaNotificacaoModelList.push(obj);
				}
			}

			this.agendaCompromissoConvidadoModelList = [];
			let agendaCompromissoConvidadoModelJsonList = jsonObj['agendaCompromissoConvidadoModelList'];
			if (agendaCompromissoConvidadoModelJsonList != null) {
				for (let i = 0; i < agendaCompromissoConvidadoModelJsonList.length; i++) {
					let obj = new AgendaCompromissoConvidadoModel(agendaCompromissoConvidadoModelJsonList[i]);
					this.agendaCompromissoConvidadoModelList.push(obj);
				}
			}

			this.reuniaoSalaEventoModelList = [];
			let reuniaoSalaEventoModelJsonList = jsonObj['reuniaoSalaEventoModelList'];
			if (reuniaoSalaEventoModelJsonList != null) {
				for (let i = 0; i < reuniaoSalaEventoModelJsonList.length; i++) {
					let obj = new ReuniaoSalaEventoModel(reuniaoSalaEventoModelJsonList[i]);
					this.reuniaoSalaEventoModelList.push(obj);
				}
			}

		}
	}
}