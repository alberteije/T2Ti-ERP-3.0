import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { AgendaCompromissoService } from '../service/agenda-compromisso.service';
import { AgendaCompromissoModel } from '../model/agenda-compromisso.entity';

@Crud({
  model: {
    type: AgendaCompromissoModel,
  },
  query: {
    join: {
			agendaNotificacaoModelList: { eager: true },
			agendaCompromissoConvidadoModelList: { eager: true },
			reuniaoSalaEventoModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
			agendaCategoriaCompromissoModel: { eager: true },
    },
  },
})
@Controller('agenda-compromisso')
export class AgendaCompromissoController implements CrudController<AgendaCompromissoModel> {
  constructor(public service: AgendaCompromissoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const agendaCompromisso = new AgendaCompromissoModel(jsonObj);
		const result = await this.service.save(agendaCompromisso, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const agendaCompromisso = new AgendaCompromissoModel(jsonObj);
		const result = await this.service.save(agendaCompromisso, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}