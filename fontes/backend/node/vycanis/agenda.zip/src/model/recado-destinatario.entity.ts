import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { RecadoRemetenteModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'recado_destinatario' })
export class RecadoDestinatarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => RecadoRemetenteModel, recadoRemetenteModel => recadoRemetenteModel.recadoDestinatarioModelList)
	@JoinColumn({ name: 'id_recado_remetente' })
	recadoRemetenteModel: RecadoRemetenteModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}