import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { AgendaCompromissoModel } from '../entities-export';

@Entity({ name: 'agenda_notificacao' })
export class AgendaNotificacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_notificacao' }) 
	dataNotificacao: Date; 

	@Column({ name: 'hora' }) 
	hora: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => AgendaCompromissoModel, agendaCompromissoModel => agendaCompromissoModel.agendaNotificacaoModelList)
	@JoinColumn({ name: 'id_agenda_compromisso' })
	agendaCompromissoModel: AgendaCompromissoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataNotificacao = jsonObj['dataNotificacao'];
			this.hora = jsonObj['hora'];
			this.tipo = jsonObj['tipo'];
		}
	}
}