import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'reuniao_sala' })
export class ReuniaoSalaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'predio' }) 
	predio: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'andar' }) 
	andar: string; 

	@Column({ name: 'numero' }) 
	numero: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.predio = jsonObj['predio'];
			this.nome = jsonObj['nome'];
			this.andar = jsonObj['andar'];
			this.numero = jsonObj['numero'];
		}
	}
}