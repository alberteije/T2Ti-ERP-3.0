import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { AgendaCompromissoModel } from '../entities-export';
import { ReuniaoSalaModel } from '../entities-export';

@Entity({ name: 'reuniao_sala_evento' })
export class ReuniaoSalaEventoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_reserva' }) 
	dataReserva: Date; 


	/**
	* Relations
	*/
	@ManyToOne(() => AgendaCompromissoModel, agendaCompromissoModel => agendaCompromissoModel.reuniaoSalaEventoModelList)
	@JoinColumn({ name: 'id_agenda_compromisso' })
	agendaCompromissoModel: AgendaCompromissoModel;

	@OneToOne(() => ReuniaoSalaModel)
	@JoinColumn({ name: 'id_reuniao_sala' })
	reuniaoSalaModel: ReuniaoSalaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataReserva = jsonObj['dataReserva'];
			if (jsonObj['reuniaoSalaModel'] != null) {
				this.reuniaoSalaModel = new ReuniaoSalaModel(jsonObj['reuniaoSalaModel']);
			}

		}
	}
}