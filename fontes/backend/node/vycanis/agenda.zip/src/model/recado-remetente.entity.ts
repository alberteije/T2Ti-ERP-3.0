import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { RecadoDestinatarioModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'recado_remetente' })
export class RecadoRemetenteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_envio' }) 
	dataEnvio: Date; 

	@Column({ name: 'hora_envio' }) 
	horaEnvio: string; 

	@Column({ name: 'assunto' }) 
	assunto: string; 

	@Column({ name: 'texto' }) 
	texto: string; 


	/**
	* Relations
	*/
	@OneToMany(() => RecadoDestinatarioModel, recadoDestinatarioModel => recadoDestinatarioModel.recadoRemetenteModel, { cascade: true })
	recadoDestinatarioModelList: RecadoDestinatarioModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataEnvio = jsonObj['dataEnvio'];
			this.horaEnvio = jsonObj['horaEnvio'];
			this.assunto = jsonObj['assunto'];
			this.texto = jsonObj['texto'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.recadoDestinatarioModelList = [];
			let recadoDestinatarioModelJsonList = jsonObj['recadoDestinatarioModelList'];
			if (recadoDestinatarioModelJsonList != null) {
				for (let i = 0; i < recadoDestinatarioModelJsonList.length; i++) {
					let obj = new RecadoDestinatarioModel(recadoDestinatarioModelJsonList[i]);
					this.recadoDestinatarioModelList.push(obj);
				}
			}

		}
	}
}