import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { RecadoRemetenteService } from '../service/recado-remetente.service';
import { RecadoRemetenteModel } from '../model/recado-remetente.entity';

@Crud({
  model: {
    type: RecadoRemetenteModel,
  },
  query: {
    join: {
			recadoDestinatarioModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('recado-remetente')
export class RecadoRemetenteController implements CrudController<RecadoRemetenteModel> {
  constructor(public service: RecadoRemetenteService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const recadoRemetente = new RecadoRemetenteModel(jsonObj);
		const result = await this.service.save(recadoRemetente, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const recadoRemetente = new RecadoRemetenteModel(jsonObj);
		const result = await this.service.save(recadoRemetente, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}