import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ReuniaoSalaService } from '../service/reuniao-sala.service';
import { ReuniaoSalaModel } from '../model/reuniao-sala.entity';

@Crud({
  model: {
    type: ReuniaoSalaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('reuniao-sala')
export class ReuniaoSalaController implements CrudController<ReuniaoSalaModel> {
  constructor(public service: ReuniaoSalaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const reuniaoSalaModel = new ReuniaoSalaModel(jsonObj);
		const result = await this.service.save(reuniaoSalaModel);
		return result;
	}  


}


















