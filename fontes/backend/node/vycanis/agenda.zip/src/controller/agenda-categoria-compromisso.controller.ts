import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { AgendaCategoriaCompromissoService } from '../service/agenda-categoria-compromisso.service';
import { AgendaCategoriaCompromissoModel } from '../model/agenda-categoria-compromisso.entity';

@Crud({
  model: {
    type: AgendaCategoriaCompromissoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('agenda-categoria-compromisso')
export class AgendaCategoriaCompromissoController implements CrudController<AgendaCategoriaCompromissoModel> {
  constructor(public service: AgendaCategoriaCompromissoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const agendaCategoriaCompromissoModel = new AgendaCategoriaCompromissoModel(jsonObj);
		const result = await this.service.save(agendaCategoriaCompromissoModel);
		return result;
	}  


}


















