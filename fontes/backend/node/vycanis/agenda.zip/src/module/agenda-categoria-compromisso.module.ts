import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AgendaCategoriaCompromissoController } from '../controller/agenda-categoria-compromisso.controller';
import { AgendaCategoriaCompromissoService } from '../service/agenda-categoria-compromisso.service';
import { AgendaCategoriaCompromissoModel } from '../model/agenda-categoria-compromisso.entity';

@Module({
    imports: [TypeOrmModule.forFeature([AgendaCategoriaCompromissoModel])],
    controllers: [AgendaCategoriaCompromissoController],
    providers: [AgendaCategoriaCompromissoService],
})
export class AgendaCategoriaCompromissoModule { }
