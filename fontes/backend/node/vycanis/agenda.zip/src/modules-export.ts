export { AgendaCompromissoModule } from './module/agenda-compromisso.module';
export { RecadoRemetenteModule } from './module/recado-remetente.module';
export { AgendaCategoriaCompromissoModule } from './module/agenda-categoria-compromisso.module';
export { ReuniaoSalaModule } from './module/reuniao-sala.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';
