import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { AgendaCompromissoModel } from '../entities-export';

@Injectable()
export class AgendaCompromissoService extends TypeOrmCrudService<AgendaCompromissoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(AgendaCompromissoModel) 
    private readonly repository: Repository<AgendaCompromissoModel>,
  ) {
    super(repository);
  }

	async save(agendaCompromissoModel: AgendaCompromissoModel, operation: string): Promise<AgendaCompromissoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, agendaCompromissoModel.id);
      }

      const resultObj = await queryRunner.manager.save(agendaCompromissoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(AgendaCompromissoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from agenda_notificacao where id_agenda_compromisso=' + id); 

		await queryRunner.query('delete from agenda_compromisso_convidado where id_agenda_compromisso=' + id); 

		await queryRunner.query('delete from reuniao_sala_evento where id_agenda_compromisso=' + id); 

	}
	
}