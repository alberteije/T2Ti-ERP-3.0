import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { EstoqueReajusteCabecalhoService } from '../service/estoque-reajuste-cabecalho.service';
import { EstoqueReajusteCabecalhoModel } from '../model/estoque-reajuste-cabecalho.entity';

@Crud({
  model: {
    type: EstoqueReajusteCabecalhoModel,
  },
  query: {
    join: {
			estoqueReajusteDetalheModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('estoque-reajuste-cabecalho')
export class EstoqueReajusteCabecalhoController implements CrudController<EstoqueReajusteCabecalhoModel> {
  constructor(public service: EstoqueReajusteCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const estoqueReajusteCabecalho = new EstoqueReajusteCabecalhoModel(jsonObj);
		const result = await this.service.save(estoqueReajusteCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const estoqueReajusteCabecalho = new EstoqueReajusteCabecalhoModel(jsonObj);
		const result = await this.service.save(estoqueReajusteCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}