import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EstoqueSaborService } from '../service/estoque-sabor.service';
import { EstoqueSaborModel } from '../model/estoque-sabor.entity';

@Crud({
  model: {
    type: EstoqueSaborModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('estoque-sabor')
export class EstoqueSaborController implements CrudController<EstoqueSaborModel> {
  constructor(public service: EstoqueSaborService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const estoqueSaborModel = new EstoqueSaborModel(jsonObj);
		const result = await this.service.save(estoqueSaborModel);
		return result;
	}  


}


















