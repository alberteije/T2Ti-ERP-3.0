import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EstoqueMarcaService } from '../service/estoque-marca.service';
import { EstoqueMarcaModel } from '../model/estoque-marca.entity';

@Crud({
  model: {
    type: EstoqueMarcaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('estoque-marca')
export class EstoqueMarcaController implements CrudController<EstoqueMarcaModel> {
  constructor(public service: EstoqueMarcaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const estoqueMarcaModel = new EstoqueMarcaModel(jsonObj);
		const result = await this.service.save(estoqueMarcaModel);
		return result;
	}  


}


















