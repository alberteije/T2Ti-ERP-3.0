import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EstoqueTamanhoService } from '../service/estoque-tamanho.service';
import { EstoqueTamanhoModel } from '../model/estoque-tamanho.entity';

@Crud({
  model: {
    type: EstoqueTamanhoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('estoque-tamanho')
export class EstoqueTamanhoController implements CrudController<EstoqueTamanhoModel> {
  constructor(public service: EstoqueTamanhoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const estoqueTamanhoModel = new EstoqueTamanhoModel(jsonObj);
		const result = await this.service.save(estoqueTamanhoModel);
		return result;
	}  


}


















