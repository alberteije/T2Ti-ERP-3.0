import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EstoqueCorService } from '../service/estoque-cor.service';
import { EstoqueCorModel } from '../model/estoque-cor.entity';

@Crud({
  model: {
    type: EstoqueCorModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('estoque-cor')
export class EstoqueCorController implements CrudController<EstoqueCorModel> {
  constructor(public service: EstoqueCorService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const estoqueCorModel = new EstoqueCorModel(jsonObj);
		const result = await this.service.save(estoqueCorModel);
		return result;
	}  


}


















