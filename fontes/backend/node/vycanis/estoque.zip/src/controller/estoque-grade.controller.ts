import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EstoqueGradeService } from '../service/estoque-grade.service';
import { EstoqueGradeModel } from '../model/estoque-grade.entity';

@Crud({
  model: {
    type: EstoqueGradeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('estoque-grade')
export class EstoqueGradeController implements CrudController<EstoqueGradeModel> {
  constructor(public service: EstoqueGradeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const estoqueGradeModel = new EstoqueGradeModel(jsonObj);
		const result = await this.service.save(estoqueGradeModel);
		return result;
	}  


}


















