import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { RequisicaoInternaCabecalhoService } from '../service/requisicao-interna-cabecalho.service';
import { RequisicaoInternaCabecalhoModel } from '../model/requisicao-interna-cabecalho.entity';

@Crud({
  model: {
    type: RequisicaoInternaCabecalhoModel,
  },
  query: {
    join: {
			requisicaoInternaDetalheModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('requisicao-interna-cabecalho')
export class RequisicaoInternaCabecalhoController implements CrudController<RequisicaoInternaCabecalhoModel> {
  constructor(public service: RequisicaoInternaCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const requisicaoInternaCabecalho = new RequisicaoInternaCabecalhoModel(jsonObj);
		const result = await this.service.save(requisicaoInternaCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const requisicaoInternaCabecalho = new RequisicaoInternaCabecalhoModel(jsonObj);
		const result = await this.service.save(requisicaoInternaCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}