import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EstoqueGradeModel } from '../entities-export';

@Injectable()
export class EstoqueGradeService extends TypeOrmCrudService<EstoqueGradeModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EstoqueGradeModel)
    private readonly repository: Repository<EstoqueGradeModel>
  ) {
    super(repository);
  }

	async save(estoqueGradeModel: EstoqueGradeModel): Promise<EstoqueGradeModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(estoqueGradeModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
