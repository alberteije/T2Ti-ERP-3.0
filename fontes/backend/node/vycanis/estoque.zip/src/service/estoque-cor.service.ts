import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EstoqueCorModel } from '../entities-export';

@Injectable()
export class EstoqueCorService extends TypeOrmCrudService<EstoqueCorModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EstoqueCorModel)
    private readonly repository: Repository<EstoqueCorModel>
  ) {
    super(repository);
  }

	async save(estoqueCorModel: EstoqueCorModel): Promise<EstoqueCorModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(estoqueCorModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
