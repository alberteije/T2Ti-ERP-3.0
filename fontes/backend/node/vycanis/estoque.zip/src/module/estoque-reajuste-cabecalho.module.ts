import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstoqueReajusteCabecalhoController } from '../controller/estoque-reajuste-cabecalho.controller';
import { EstoqueReajusteCabecalhoService } from '../service/estoque-reajuste-cabecalho.service';
import { EstoqueReajusteCabecalhoModel } from '../model/estoque-reajuste-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EstoqueReajusteCabecalhoModel])],
    controllers: [EstoqueReajusteCabecalhoController],
    providers: [EstoqueReajusteCabecalhoService],
})
export class EstoqueReajusteCabecalhoModule { }
