import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstoqueSaborController } from '../controller/estoque-sabor.controller';
import { EstoqueSaborService } from '../service/estoque-sabor.service';
import { EstoqueSaborModel } from '../model/estoque-sabor.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EstoqueSaborModel])],
    controllers: [EstoqueSaborController],
    providers: [EstoqueSaborService],
})
export class EstoqueSaborModule { }
