import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProdutoGrupoController } from '../controller/produto-grupo.controller';
import { ProdutoGrupoService } from '../service/produto-grupo.service';
import { ProdutoGrupoModel } from '../model/produto-grupo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ProdutoGrupoModel])],
    controllers: [ProdutoGrupoController],
    providers: [ProdutoGrupoService],
})
export class ProdutoGrupoModule { }
