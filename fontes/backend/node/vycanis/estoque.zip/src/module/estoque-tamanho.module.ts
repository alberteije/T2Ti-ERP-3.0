import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstoqueTamanhoController } from '../controller/estoque-tamanho.controller';
import { EstoqueTamanhoService } from '../service/estoque-tamanho.service';
import { EstoqueTamanhoModel } from '../model/estoque-tamanho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EstoqueTamanhoModel])],
    controllers: [EstoqueTamanhoController],
    providers: [EstoqueTamanhoService],
})
export class EstoqueTamanhoModule { }
