import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstoqueGradeController } from '../controller/estoque-grade.controller';
import { EstoqueGradeService } from '../service/estoque-grade.service';
import { EstoqueGradeModel } from '../model/estoque-grade.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EstoqueGradeModel])],
    controllers: [EstoqueGradeController],
    providers: [EstoqueGradeService],
})
export class EstoqueGradeModule { }
