import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RequisicaoInternaCabecalhoController } from '../controller/requisicao-interna-cabecalho.controller';
import { RequisicaoInternaCabecalhoService } from '../service/requisicao-interna-cabecalho.service';
import { RequisicaoInternaCabecalhoModel } from '../model/requisicao-interna-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([RequisicaoInternaCabecalhoModel])],
    controllers: [RequisicaoInternaCabecalhoController],
    providers: [RequisicaoInternaCabecalhoService],
})
export class RequisicaoInternaCabecalhoModule { }
