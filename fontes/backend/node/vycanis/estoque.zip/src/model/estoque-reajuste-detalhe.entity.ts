import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EstoqueReajusteCabecalhoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'estoque_reajuste_detalhe' })
export class EstoqueReajusteDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_original', type: 'decimal', precision: 18, scale: 6 }) 
	valorOriginal: number; 

	@Column({ name: 'valor_reajuste', type: 'decimal', precision: 18, scale: 6 }) 
	valorReajuste: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => EstoqueReajusteCabecalhoModel, estoqueReajusteCabecalhoModel => estoqueReajusteCabecalhoModel.estoqueReajusteDetalheModelList)
	@JoinColumn({ name: 'id_estoque_reajuste_cabecalho' })
	estoqueReajusteCabecalhoModel: EstoqueReajusteCabecalhoModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorOriginal = jsonObj['valorOriginal'];
			this.valorReajuste = jsonObj['valorReajuste'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}