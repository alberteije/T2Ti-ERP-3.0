import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'estoque_tamanho' })
export class EstoqueTamanhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'altura', type: 'decimal', precision: 18, scale: 6 }) 
	altura: number; 

	@Column({ name: 'comprimento', type: 'decimal', precision: 18, scale: 6 }) 
	comprimento: number; 

	@Column({ name: 'largura', type: 'decimal', precision: 18, scale: 6 }) 
	largura: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
			this.altura = jsonObj['altura'];
			this.comprimento = jsonObj['comprimento'];
			this.largura = jsonObj['largura'];
		}
	}
}