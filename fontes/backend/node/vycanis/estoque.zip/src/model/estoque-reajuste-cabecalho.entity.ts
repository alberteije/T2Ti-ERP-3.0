import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EstoqueReajusteDetalheModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'estoque_reajuste_cabecalho' })
export class EstoqueReajusteCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_reajuste' }) 
	dataReajuste: Date; 

	@Column({ name: 'taxa', type: 'decimal', precision: 18, scale: 6 }) 
	taxa: number; 

	@Column({ name: 'tipo_reajuste' }) 
	tipoReajuste: string; 

	@Column({ name: 'justificativa' }) 
	justificativa: string; 


	/**
	* Relations
	*/
	@OneToMany(() => EstoqueReajusteDetalheModel, estoqueReajusteDetalheModel => estoqueReajusteDetalheModel.estoqueReajusteCabecalhoModel, { cascade: true })
	estoqueReajusteDetalheModelList: EstoqueReajusteDetalheModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataReajuste = jsonObj['dataReajuste'];
			this.taxa = jsonObj['taxa'];
			this.tipoReajuste = jsonObj['tipoReajuste'];
			this.justificativa = jsonObj['justificativa'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.estoqueReajusteDetalheModelList = [];
			let estoqueReajusteDetalheModelJsonList = jsonObj['estoqueReajusteDetalheModelList'];
			if (estoqueReajusteDetalheModelJsonList != null) {
				for (let i = 0; i < estoqueReajusteDetalheModelJsonList.length; i++) {
					let obj = new EstoqueReajusteDetalheModel(estoqueReajusteDetalheModelJsonList[i]);
					this.estoqueReajusteDetalheModelList.push(obj);
				}
			}

		}
	}
}