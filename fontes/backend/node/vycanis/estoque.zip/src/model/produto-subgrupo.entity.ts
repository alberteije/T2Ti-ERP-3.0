import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoGrupoModel } from '../entities-export';

@Entity({ name: 'produto_subgrupo' })
export class ProdutoSubgrupoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ProdutoGrupoModel)
	@JoinColumn({ name: 'id_produto_grupo' })
	produtoGrupoModel: ProdutoGrupoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			if (jsonObj['produtoGrupoModel'] != null) {
				this.produtoGrupoModel = new ProdutoGrupoModel(jsonObj['produtoGrupoModel']);
			}

		}
	}
}