import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstoqueCorController } from '../controller/estoque-cor.controller';
import { EstoqueCorService } from '../service/estoque-cor.service';
import { EstoqueCorModel } from '../model/estoque-cor.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EstoqueCorModel])],
    controllers: [EstoqueCorController],
    providers: [EstoqueCorService],
})
export class EstoqueCorModule { }
