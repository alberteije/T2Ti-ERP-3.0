import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstoqueMarcaController } from '../controller/estoque-marca.controller';
import { EstoqueMarcaService } from '../service/estoque-marca.service';
import { EstoqueMarcaModel } from '../model/estoque-marca.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EstoqueMarcaModel])],
    controllers: [EstoqueMarcaController],
    providers: [EstoqueMarcaService],
})
export class EstoqueMarcaModule { }
