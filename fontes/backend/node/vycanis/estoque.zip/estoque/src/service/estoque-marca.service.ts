import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EstoqueMarcaModel } from '../entities-export';

@Injectable()
export class EstoqueMarcaService extends TypeOrmCrudService<EstoqueMarcaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EstoqueMarcaModel)
    private readonly repository: Repository<EstoqueMarcaModel>
  ) {
    super(repository);
  }

	async save(estoqueMarcaModel: EstoqueMarcaModel): Promise<EstoqueMarcaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(estoqueMarcaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
