import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ProdutoGrupoService } from '../service/produto-grupo.service';
import { ProdutoGrupoModel } from '../model/produto-grupo.entity';

@Crud({
  model: {
    type: ProdutoGrupoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('produto-grupo')
export class ProdutoGrupoController implements CrudController<ProdutoGrupoModel> {
  constructor(public service: ProdutoGrupoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoGrupoModel = new ProdutoGrupoModel(jsonObj);
		const result = await this.service.save(produtoGrupoModel);
		return result;
	}  


}


















