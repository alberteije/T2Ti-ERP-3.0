import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoModel } from '../entities-export';
import { EstoqueCorModel } from '../entities-export';
import { EstoqueTamanhoModel } from '../entities-export';
import { EstoqueSaborModel } from '../entities-export';
import { EstoqueMarcaModel } from '../entities-export';

@Entity({ name: 'estoque_grade' })
export class EstoqueGradeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'quantidade', type: 'decimal', precision: 18, scale: 6 }) 
	quantidade: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;

	@OneToOne(() => EstoqueCorModel)
	@JoinColumn({ name: 'id_estoque_cor' })
	estoqueCorModel: EstoqueCorModel;

	@OneToOne(() => EstoqueTamanhoModel)
	@JoinColumn({ name: 'id_estoque_tamanho' })
	estoqueTamanhoModel: EstoqueTamanhoModel;

	@OneToOne(() => EstoqueSaborModel)
	@JoinColumn({ name: 'id_estoque_sabor' })
	estoqueSaborModel: EstoqueSaborModel;

	@OneToOne(() => EstoqueMarcaModel)
	@JoinColumn({ name: 'id_estoque_marca' })
	estoqueMarcaModel: EstoqueMarcaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.quantidade = jsonObj['quantidade'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

			if (jsonObj['estoqueCorModel'] != null) {
				this.estoqueCorModel = new EstoqueCorModel(jsonObj['estoqueCorModel']);
			}

			if (jsonObj['estoqueTamanhoModel'] != null) {
				this.estoqueTamanhoModel = new EstoqueTamanhoModel(jsonObj['estoqueTamanhoModel']);
			}

			if (jsonObj['estoqueSaborModel'] != null) {
				this.estoqueSaborModel = new EstoqueSaborModel(jsonObj['estoqueSaborModel']);
			}

			if (jsonObj['estoqueMarcaModel'] != null) {
				this.estoqueMarcaModel = new EstoqueMarcaModel(jsonObj['estoqueMarcaModel']);
			}

		}
	}
}