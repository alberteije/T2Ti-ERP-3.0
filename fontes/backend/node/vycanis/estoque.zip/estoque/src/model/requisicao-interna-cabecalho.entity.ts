import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { RequisicaoInternaDetalheModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'requisicao_interna_cabecalho' })
export class RequisicaoInternaCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_requisicao' }) 
	dataRequisicao: Date; 

	@Column({ name: 'situacao' }) 
	situacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => RequisicaoInternaDetalheModel, requisicaoInternaDetalheModel => requisicaoInternaDetalheModel.requisicaoInternaCabecalhoModel, { cascade: true })
	requisicaoInternaDetalheModelList: RequisicaoInternaDetalheModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataRequisicao = jsonObj['dataRequisicao'];
			this.situacao = jsonObj['situacao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.requisicaoInternaDetalheModelList = [];
			let requisicaoInternaDetalheModelJsonList = jsonObj['requisicaoInternaDetalheModelList'];
			if (requisicaoInternaDetalheModelJsonList != null) {
				for (let i = 0; i < requisicaoInternaDetalheModelJsonList.length; i++) {
					let obj = new RequisicaoInternaDetalheModel(requisicaoInternaDetalheModelJsonList[i]);
					this.requisicaoInternaDetalheModelList.push(obj);
				}
			}

		}
	}
}