import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { OsAberturaModel } from '../entities-export';

@Injectable()
export class OsAberturaService extends TypeOrmCrudService<OsAberturaModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(OsAberturaModel) 
    private readonly repository: Repository<OsAberturaModel>,
  ) {
    super(repository);
  }

	async save(osAberturaModel: OsAberturaModel, operation: string): Promise<OsAberturaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, osAberturaModel.id);
      }

      const resultObj = await queryRunner.manager.save(osAberturaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(OsAberturaModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from os_abertura_equipamento where id_os_abertura=' + id); 

		await queryRunner.query('delete from os_produto_servico where id_os_abertura=' + id); 

		await queryRunner.query('delete from os_evolucao where id_os_abertura=' + id); 

	}
	
}