export { ProdutoGrupoModule } from './module/produto-grupo.module';
export { ProdutoSubgrupoModule } from './module/produto-subgrupo.module';
export { ProdutoMarcaModule } from './module/produto-marca.module';
export { ProdutoUnidadeModule } from './module/produto-unidade.module';
export { OsAberturaModule } from './module/os-abertura.module';
export { OsStatusModule } from './module/os-status.module';
export { OsEquipamentoModule } from './module/os-equipamento.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaClienteModule } from './module/view-pessoa-cliente.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';

export { UsuarioTokenModule } from './module/usuario-token.module';
export { AuditoriaModule } from './module/auditoria.module';