import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoGrupoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'produto_subgrupo' })
export class ProdutoSubgrupoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => ProdutoGrupoModel, produtoGrupoModel => produtoGrupoModel.produtoSubgrupoModelList)
	@JoinColumn({ name: 'id_produto_grupo' })
	produtoGrupoModel: ProdutoGrupoModel;

	@OneToMany(() => ProdutoModel, produtoModel => produtoModel.produtoSubgrupoModel, { cascade: true })
	produtoModelList: ProdutoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.produtoModelList = [];
			let produtoModelJsonList = jsonObj['produtoModelList'];
			if (produtoModelJsonList != null) {
				for (let i = 0; i < produtoModelJsonList.length; i++) {
					let obj = new ProdutoModel(produtoModelJsonList[i]);
					this.produtoModelList.push(obj);
				}
			}

		}
	}
}