import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OsAberturaEquipamentoModel } from '../entities-export';
import { OsProdutoServicoModel } from '../entities-export';
import { OsEvolucaoModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { OsStatusModel } from '../entities-export';

@Entity({ name: 'os_abertura' })
export class OsAberturaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'hora_inicio' }) 
	horaInicio: string; 

	@Column({ name: 'data_previsao' }) 
	dataPrevisao: Date; 

	@Column({ name: 'hora_previsao' }) 
	horaPrevisao: string; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'hora_fim' }) 
	horaFim: string; 

	@Column({ name: 'nome_contato' }) 
	nomeContato: string; 

	@Column({ name: 'fone_contato' }) 
	foneContato: string; 

	@Column({ name: 'observacao_cliente' }) 
	observacaoCliente: string; 

	@Column({ name: 'observacao_abertura' }) 
	observacaoAbertura: string; 


	/**
	* Relations
	*/
	@OneToMany(() => OsAberturaEquipamentoModel, osAberturaEquipamentoModel => osAberturaEquipamentoModel.osAberturaModel, { cascade: true })
	osAberturaEquipamentoModelList: OsAberturaEquipamentoModel[];

	@OneToMany(() => OsProdutoServicoModel, osProdutoServicoModel => osProdutoServicoModel.osAberturaModel, { cascade: true })
	osProdutoServicoModelList: OsProdutoServicoModel[];

	@OneToMany(() => OsEvolucaoModel, osEvolucaoModel => osEvolucaoModel.osAberturaModel, { cascade: true })
	osEvolucaoModelList: OsEvolucaoModel[];

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => OsStatusModel)
	@JoinColumn({ name: 'id_os_status' })
	osStatusModel: OsStatusModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.dataInicio = jsonObj['dataInicio'];
			this.horaInicio = jsonObj['horaInicio'];
			this.dataPrevisao = jsonObj['dataPrevisao'];
			this.horaPrevisao = jsonObj['horaPrevisao'];
			this.dataFim = jsonObj['dataFim'];
			this.horaFim = jsonObj['horaFim'];
			this.nomeContato = jsonObj['nomeContato'];
			this.foneContato = jsonObj['foneContato'];
			this.observacaoCliente = jsonObj['observacaoCliente'];
			this.observacaoAbertura = jsonObj['observacaoAbertura'];
			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['osStatusModel'] != null) {
				this.osStatusModel = new OsStatusModel(jsonObj['osStatusModel']);
			}

			this.osAberturaEquipamentoModelList = [];
			let osAberturaEquipamentoModelJsonList = jsonObj['osAberturaEquipamentoModelList'];
			if (osAberturaEquipamentoModelJsonList != null) {
				for (let i = 0; i < osAberturaEquipamentoModelJsonList.length; i++) {
					let obj = new OsAberturaEquipamentoModel(osAberturaEquipamentoModelJsonList[i]);
					this.osAberturaEquipamentoModelList.push(obj);
				}
			}

			this.osProdutoServicoModelList = [];
			let osProdutoServicoModelJsonList = jsonObj['osProdutoServicoModelList'];
			if (osProdutoServicoModelJsonList != null) {
				for (let i = 0; i < osProdutoServicoModelJsonList.length; i++) {
					let obj = new OsProdutoServicoModel(osProdutoServicoModelJsonList[i]);
					this.osProdutoServicoModelList.push(obj);
				}
			}

			this.osEvolucaoModelList = [];
			let osEvolucaoModelJsonList = jsonObj['osEvolucaoModelList'];
			if (osEvolucaoModelJsonList != null) {
				for (let i = 0; i < osEvolucaoModelJsonList.length; i++) {
					let obj = new OsEvolucaoModel(osEvolucaoModelJsonList[i]);
					this.osEvolucaoModelList.push(obj);
				}
			}

		}
	}
}