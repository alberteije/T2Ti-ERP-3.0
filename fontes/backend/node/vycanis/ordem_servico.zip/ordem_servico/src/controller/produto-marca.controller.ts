import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ProdutoMarcaService } from '../service/produto-marca.service';
import { ProdutoMarcaModel } from '../model/produto-marca.entity';

@Crud({
  model: {
    type: ProdutoMarcaModel,
  },
  query: {
    join: {
			produtoModelList: { eager: true },
    },
  },
})
@Controller('produto-marca')
export class ProdutoMarcaController implements CrudController<ProdutoMarcaModel> {
  constructor(public service: ProdutoMarcaService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoMarca = new ProdutoMarcaModel(jsonObj);
		const result = await this.service.save(produtoMarca, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoMarca = new ProdutoMarcaModel(jsonObj);
		const result = await this.service.save(produtoMarca, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}