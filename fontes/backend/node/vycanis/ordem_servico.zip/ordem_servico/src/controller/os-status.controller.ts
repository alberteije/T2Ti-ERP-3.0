import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { OsStatusService } from '../service/os-status.service';
import { OsStatusModel } from '../model/os-status.entity';

@Crud({
  model: {
    type: OsStatusModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('os-status')
export class OsStatusController implements CrudController<OsStatusModel> {
  constructor(public service: OsStatusService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const osStatusModel = new OsStatusModel(jsonObj);
		const result = await this.service.save(osStatusModel);
		return result;
	}  


}


















