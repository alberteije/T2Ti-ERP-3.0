import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OsStatusController } from '../controller/os-status.controller';
import { OsStatusService } from '../service/os-status.service';
import { OsStatusModel } from '../model/os-status.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OsStatusModel])],
    controllers: [OsStatusController],
    providers: [OsStatusService],
})
export class OsStatusModule { }
