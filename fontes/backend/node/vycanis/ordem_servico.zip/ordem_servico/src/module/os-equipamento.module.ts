import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OsEquipamentoController } from '../controller/os-equipamento.controller';
import { OsEquipamentoService } from '../service/os-equipamento.service';
import { OsEquipamentoModel } from '../model/os-equipamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OsEquipamentoModel])],
    controllers: [OsEquipamentoController],
    providers: [OsEquipamentoService],
})
export class OsEquipamentoModule { }
