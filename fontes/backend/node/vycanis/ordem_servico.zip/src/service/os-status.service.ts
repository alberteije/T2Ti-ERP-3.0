import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { OsStatusModel } from '../entities-export';

@Injectable()
export class OsStatusService extends TypeOrmCrudService<OsStatusModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(OsStatusModel)
    private readonly repository: Repository<OsStatusModel>
  ) {
    super(repository);
  }

	async save(osStatusModel: OsStatusModel): Promise<OsStatusModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(osStatusModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
