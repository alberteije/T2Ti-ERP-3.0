import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { OsEquipamentoModel } from '../entities-export';

@Injectable()
export class OsEquipamentoService extends TypeOrmCrudService<OsEquipamentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(OsEquipamentoModel)
    private readonly repository: Repository<OsEquipamentoModel>
  ) {
    super(repository);
  }

	async save(osEquipamentoModel: OsEquipamentoModel): Promise<OsEquipamentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(osEquipamentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
