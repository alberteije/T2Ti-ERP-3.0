import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OsAberturaModel } from '../entities-export';

@Entity({ name: 'os_evolucao' })
export class OsEvolucaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_registro' }) 
	dataRegistro: Date; 

	@Column({ name: 'hora_registro' }) 
	horaRegistro: string; 

	@Column({ name: 'enviar_email' }) 
	enviarEmail: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => OsAberturaModel, osAberturaModel => osAberturaModel.osEvolucaoModelList)
	@JoinColumn({ name: 'id_os_abertura' })
	osAberturaModel: OsAberturaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataRegistro = jsonObj['dataRegistro'];
			this.horaRegistro = jsonObj['horaRegistro'];
			this.enviarEmail = jsonObj['enviarEmail'];
			this.observacao = jsonObj['observacao'];
		}
	}
}