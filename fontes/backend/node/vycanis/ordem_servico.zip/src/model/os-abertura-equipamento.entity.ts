import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OsAberturaModel } from '../entities-export';
import { OsEquipamentoModel } from '../entities-export';

@Entity({ name: 'os_abertura_equipamento' })
export class OsAberturaEquipamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo_cobertura' }) 
	tipoCobertura: string; 

	@Column({ name: 'numero_serie' }) 
	numeroSerie: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => OsAberturaModel, osAberturaModel => osAberturaModel.osAberturaEquipamentoModelList)
	@JoinColumn({ name: 'id_os_abertura' })
	osAberturaModel: OsAberturaModel;

	@OneToOne(() => OsEquipamentoModel)
	@JoinColumn({ name: 'id_os_equipamento' })
	osEquipamentoModel: OsEquipamentoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipoCobertura = jsonObj['tipoCobertura'];
			this.numeroSerie = jsonObj['numeroSerie'];
			if (jsonObj['osEquipamentoModel'] != null) {
				this.osEquipamentoModel = new OsEquipamentoModel(jsonObj['osEquipamentoModel']);
			}

		}
	}
}