import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaClienteController } from '../controller/view-pessoa-cliente.controller';
import { ViewPessoaClienteService } from '../service/view-pessoa-cliente.service';
import { ViewPessoaClienteModel } from '../model/view-pessoa-cliente.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaClienteModel])],
    controllers: [ViewPessoaClienteController],
    providers: [ViewPessoaClienteService],
})
export class ViewPessoaClienteModule { }
