import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OsAberturaController } from '../controller/os-abertura.controller';
import { OsAberturaService } from '../service/os-abertura.service';
import { OsAberturaModel } from '../model/os-abertura.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OsAberturaModel])],
    controllers: [OsAberturaController],
    providers: [OsAberturaService],
})
export class OsAberturaModule { }
