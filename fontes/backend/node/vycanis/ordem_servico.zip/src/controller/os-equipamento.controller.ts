import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { OsEquipamentoService } from '../service/os-equipamento.service';
import { OsEquipamentoModel } from '../model/os-equipamento.entity';

@Crud({
  model: {
    type: OsEquipamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('os-equipamento')
export class OsEquipamentoController implements CrudController<OsEquipamentoModel> {
  constructor(public service: OsEquipamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const osEquipamentoModel = new OsEquipamentoModel(jsonObj);
		const result = await this.service.save(osEquipamentoModel);
		return result;
	}  


}


















