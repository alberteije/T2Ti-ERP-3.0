import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { OsAberturaService } from '../service/os-abertura.service';
import { OsAberturaModel } from '../model/os-abertura.entity';

@Crud({
  model: {
    type: OsAberturaModel,
  },
  query: {
    join: {
			osAberturaEquipamentoModelList: { eager: true },
			osProdutoServicoModelList: { eager: true },
			osEvolucaoModelList: { eager: true },
			viewPessoaClienteModel: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
			osStatusModel: { eager: true },
    },
  },
})
@Controller('os-abertura')
export class OsAberturaController implements CrudController<OsAberturaModel> {
  constructor(public service: OsAberturaService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const osAbertura = new OsAberturaModel(jsonObj);
		const result = await this.service.save(osAbertura, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const osAbertura = new OsAberturaModel(jsonObj);
		const result = await this.service.save(osAbertura, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}