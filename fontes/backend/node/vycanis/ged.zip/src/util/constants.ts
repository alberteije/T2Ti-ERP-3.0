export class Constants {
    static CHAVE = '#Sua-Chave-de-32-caracteres-aqui';
    static VETOR = '#Seu-Vetor-aqui#';	
}