import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'view_pessoa_usuario' })
export class ViewPessoaUsuarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_pessoa' }) 
	idPessoa: number; 

	@Column({ name: 'pessoa_nome' }) 
	pessoaNome: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'id_colaborador' }) 
	idColaborador: number; 

	@Column({ name: 'id_usuario' }) 
	idUsuario: number; 

	@Column({ name: 'login' }) 
	login: string; 

	@Column({ name: 'senha' }) 
	senha: string; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'administrador' }) 
	administrador: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idPessoa = jsonObj['idPessoa'];
			this.pessoaNome = jsonObj['pessoaNome'];
			this.tipo = jsonObj['tipo'];
			this.email = jsonObj['email'];
			this.idColaborador = jsonObj['idColaborador'];
			this.idUsuario = jsonObj['idUsuario'];
			this.login = jsonObj['login'];
			this.senha = jsonObj['senha'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.administrador = jsonObj['administrador'];
		}
	}

	/**
	* Convert object to JSON
	*/
	toJSON() {
		return {
			id: this.id,
			idPessoa: this.idPessoa,
			pessoaNome: this.pessoaNome,
			tipo: this.tipo,
			email: this.email,
			idColaborador: this.idColaborador,
			idUsuario: this.idUsuario,
			login: this.login,
			senha: this.senha,
			dataCadastro: this.dataCadastro,
			administrador: this.administrador
		};
	}

}