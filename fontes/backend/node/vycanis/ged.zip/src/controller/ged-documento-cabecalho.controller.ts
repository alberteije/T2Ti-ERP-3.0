import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { GedDocumentoCabecalhoService } from '../service/ged-documento-cabecalho.service';
import { GedDocumentoCabecalhoModel } from '../model/ged-documento-cabecalho.entity';

@Crud({
  model: {
    type: GedDocumentoCabecalhoModel,
  },
  query: {
    join: {
			gedDocumentoDetalheModelList: { eager: true },
    },
  },
})
@Controller('ged-documento-cabecalho')
export class GedDocumentoCabecalhoController implements CrudController<GedDocumentoCabecalhoModel> {
  constructor(public service: GedDocumentoCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const gedDocumentoCabecalho = new GedDocumentoCabecalhoModel(jsonObj);
		const result = await this.service.save(gedDocumentoCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const gedDocumentoCabecalho = new GedDocumentoCabecalhoModel(jsonObj);
		const result = await this.service.save(gedDocumentoCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}