import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ViewPessoaVendedorService } from '../service/view-pessoa-vendedor.service';
import { ViewPessoaVendedorModel } from '../model/view-pessoa-vendedor.entity';

@Crud({
  model: {
    type: ViewPessoaVendedorModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('view-pessoa-vendedor')
export class ViewPessoaVendedorController implements CrudController<ViewPessoaVendedorModel> {
  constructor(public service: ViewPessoaVendedorService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const viewPessoaVendedorModel = new ViewPessoaVendedorModel(jsonObj);
		const result = await this.service.save(viewPessoaVendedorModel);
		return result;
	}  


}


















