import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { GedVersaoDocumentoService } from '../service/ged-versao-documento.service';
import { GedVersaoDocumentoModel } from '../model/ged-versao-documento.entity';

@Crud({
  model: {
    type: GedVersaoDocumentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ged-versao-documento')
export class GedVersaoDocumentoController implements CrudController<GedVersaoDocumentoModel> {
  constructor(public service: GedVersaoDocumentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const gedVersaoDocumentoModel = new GedVersaoDocumentoModel(jsonObj);
		const result = await this.service.save(gedVersaoDocumentoModel);
		return result;
	}  


}


















