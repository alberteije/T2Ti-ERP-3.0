import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { GedTipoDocumentoModel } from '../entities-export';
import { GedDocumentoCabecalhoModel } from '../entities-export';

@Entity({ name: 'ged_documento_detalhe' })
export class GedDocumentoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'palavras_chave' }) 
	palavrasChave: string; 

	@Column({ name: 'pode_excluir' }) 
	podeExcluir: string; 

	@Column({ name: 'pode_alterar' }) 
	podeAlterar: string; 

	@Column({ name: 'assinado' }) 
	assinado: string; 

	@Column({ name: 'data_fim_vigencia' }) 
	dataFimVigencia: Date; 

	@Column({ name: 'data_exclusao' }) 
	dataExclusao: Date; 


	/**
	* Relations
	*/
	@OneToOne(() => GedTipoDocumentoModel)
	@JoinColumn({ name: 'id_ged_tipo_documento' })
	gedTipoDocumentoModel: GedTipoDocumentoModel;

	@ManyToOne(() => GedDocumentoCabecalhoModel, gedDocumentoCabecalhoModel => gedDocumentoCabecalhoModel.gedDocumentoDetalheModelList)
	@JoinColumn({ name: 'id_ged_documento_cabecalho' })
	gedDocumentoCabecalhoModel: GedDocumentoCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.palavrasChave = jsonObj['palavrasChave'];
			this.podeExcluir = jsonObj['podeExcluir'];
			this.podeAlterar = jsonObj['podeAlterar'];
			this.assinado = jsonObj['assinado'];
			this.dataFimVigencia = jsonObj['dataFimVigencia'];
			this.dataExclusao = jsonObj['dataExclusao'];
			if (jsonObj['gedTipoDocumentoModel'] != null) {
				this.gedTipoDocumentoModel = new GedTipoDocumentoModel(jsonObj['gedTipoDocumentoModel']);
			}

		}
	}
}