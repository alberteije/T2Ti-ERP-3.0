import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { GedDocumentoDetalheModel } from '../entities-export';

@Entity({ name: 'ged_documento_cabecalho' })
export class GedDocumentoCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => GedDocumentoDetalheModel, gedDocumentoDetalheModel => gedDocumentoDetalheModel.gedDocumentoCabecalhoModel, { cascade: true })
	gedDocumentoDetalheModelList: GedDocumentoDetalheModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.dataInclusao = jsonObj['dataInclusao'];
			this.descricao = jsonObj['descricao'];
			this.gedDocumentoDetalheModelList = [];
			let gedDocumentoDetalheModelJsonList = jsonObj['gedDocumentoDetalheModelList'];
			if (gedDocumentoDetalheModelJsonList != null) {
				for (let i = 0; i < gedDocumentoDetalheModelJsonList.length; i++) {
					let obj = new GedDocumentoDetalheModel(gedDocumentoDetalheModelJsonList[i]);
					this.gedDocumentoDetalheModelList.push(obj);
				}
			}

		}
	}
}