import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { GedDocumentoDetalheModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'ged_versao_documento' })
export class GedVersaoDocumentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'acao' }) 
	acao: string; 

	@Column({ name: 'versao' }) 
	versao: number; 

	@Column({ name: 'data_versao' }) 
	dataVersao: Date; 

	@Column({ name: 'hora_versao' }) 
	horaVersao: string; 

	@Column({ name: 'hash_arquivo' }) 
	hashArquivo: string; 

	@Column({ name: 'caminho' }) 
	caminho: string; 


	/**
	* Relations
	*/
	@OneToOne(() => GedDocumentoDetalheModel)
	@JoinColumn({ name: 'id_ged_documento_detalhe' })
	gedDocumentoDetalheModel: GedDocumentoDetalheModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.acao = jsonObj['acao'];
			this.versao = jsonObj['versao'];
			this.dataVersao = jsonObj['dataVersao'];
			this.horaVersao = jsonObj['horaVersao'];
			this.hashArquivo = jsonObj['hashArquivo'];
			this.caminho = jsonObj['caminho'];
			if (jsonObj['gedDocumentoDetalheModel'] != null) {
				this.gedDocumentoDetalheModel = new GedDocumentoDetalheModel(jsonObj['gedDocumentoDetalheModel']);
			}

			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}