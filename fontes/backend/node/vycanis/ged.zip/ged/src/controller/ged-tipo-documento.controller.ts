import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { GedTipoDocumentoService } from '../service/ged-tipo-documento.service';
import { GedTipoDocumentoModel } from '../model/ged-tipo-documento.entity';

@Crud({
  model: {
    type: GedTipoDocumentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ged-tipo-documento')
export class GedTipoDocumentoController implements CrudController<GedTipoDocumentoModel> {
  constructor(public service: GedTipoDocumentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const gedTipoDocumentoModel = new GedTipoDocumentoModel(jsonObj);
		const result = await this.service.save(gedTipoDocumentoModel);
		return result;
	}  


}


















