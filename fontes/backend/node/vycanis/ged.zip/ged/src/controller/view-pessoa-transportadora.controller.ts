import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ViewPessoaTransportadoraService } from '../service/view-pessoa-transportadora.service';
import { ViewPessoaTransportadoraModel } from '../model/view-pessoa-transportadora.entity';

@Crud({
  model: {
    type: ViewPessoaTransportadoraModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('view-pessoa-transportadora')
export class ViewPessoaTransportadoraController implements CrudController<ViewPessoaTransportadoraModel> {
  constructor(public service: ViewPessoaTransportadoraService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const viewPessoaTransportadoraModel = new ViewPessoaTransportadoraModel(jsonObj);
		const result = await this.service.save(viewPessoaTransportadoraModel);
		return result;
	}  


}


















