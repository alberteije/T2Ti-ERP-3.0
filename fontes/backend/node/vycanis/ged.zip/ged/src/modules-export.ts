export { GedDocumentoCabecalhoModule } from './module/ged-documento-cabecalho.module';
export { GedTipoDocumentoModule } from './module/ged-tipo-documento.module';
export { GedVersaoDocumentoModule } from './module/ged-versao-documento.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';
export { ViewPessoaVendedorModule } from './module/view-pessoa-vendedor.module';
export { ViewPessoaTransportadoraModule } from './module/view-pessoa-transportadora.module';

export { UsuarioTokenModule } from './module/usuario-token.module';
export { AuditoriaModule } from './module/auditoria.module';