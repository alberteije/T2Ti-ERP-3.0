import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GedVersaoDocumentoController } from '../controller/ged-versao-documento.controller';
import { GedVersaoDocumentoService } from '../service/ged-versao-documento.service';
import { GedVersaoDocumentoModel } from '../model/ged-versao-documento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([GedVersaoDocumentoModel])],
    controllers: [GedVersaoDocumentoController],
    providers: [GedVersaoDocumentoService],
})
export class GedVersaoDocumentoModule { }
