import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GedTipoDocumentoController } from '../controller/ged-tipo-documento.controller';
import { GedTipoDocumentoService } from '../service/ged-tipo-documento.service';
import { GedTipoDocumentoModel } from '../model/ged-tipo-documento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([GedTipoDocumentoModel])],
    controllers: [GedTipoDocumentoController],
    providers: [GedTipoDocumentoService],
})
export class GedTipoDocumentoModule { }
