import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GedDocumentoCabecalhoController } from '../controller/ged-documento-cabecalho.controller';
import { GedDocumentoCabecalhoService } from '../service/ged-documento-cabecalho.service';
import { GedDocumentoCabecalhoModel } from '../model/ged-documento-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([GedDocumentoCabecalhoModel])],
    controllers: [GedDocumentoCabecalhoController],
    providers: [GedDocumentoCabecalhoService],
})
export class GedDocumentoCabecalhoModule { }
