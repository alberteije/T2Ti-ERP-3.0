import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { PapelModel } from '../entities-export';

@Entity({ name: 'usuario' })
export class UsuarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'login' }) 
	login: string; 

	@Column({ name: 'senha' }) 
	senha: string; 

	@Column({ name: 'administrador' }) 
	administrador: string; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => PapelModel)
	@JoinColumn({ name: 'id_papel' })
	papelModel: PapelModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.login = jsonObj['login'];
			this.senha = jsonObj['senha'];
			this.administrador = jsonObj['administrador'];
			this.dataCadastro = jsonObj['dataCadastro'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['papelModel'] != null) {
				this.papelModel = new PapelModel(jsonObj['papelModel']);
			}

		}
	}
}