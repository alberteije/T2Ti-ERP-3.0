import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PapelFuncaoModel } from '../entities-export';

@Entity({ name: 'papel' })
export class PapelModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => PapelFuncaoModel, papelFuncaoModel => papelFuncaoModel.papelModel, { cascade: true })
	papelFuncaoModelList: PapelFuncaoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.papelFuncaoModelList = [];
			let papelFuncaoModelJsonList = jsonObj['papelFuncaoModelList'];
			if (papelFuncaoModelJsonList != null) {
				for (let i = 0; i < papelFuncaoModelJsonList.length; i++) {
					let obj = new PapelFuncaoModel(papelFuncaoModelJsonList[i]);
					this.papelFuncaoModelList.push(obj);
				}
			}

		}
	}
}