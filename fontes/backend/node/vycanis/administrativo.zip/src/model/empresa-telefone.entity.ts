import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EmpresaModel } from '../entities-export';

@Entity({ name: 'empresa_telefone' })
export class EmpresaTelefoneModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'numero' }) 
	numero: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => EmpresaModel, empresaModel => empresaModel.empresaTelefoneModelList)
	@JoinColumn({ name: 'id_empresa' })
	empresaModel: EmpresaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipo = jsonObj['tipo'];
			this.numero = jsonObj['numero'];
		}
	}
}