import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CnaeModel } from '../entities-export';
import { EmpresaModel } from '../entities-export';

@Entity({ name: 'empresa_cnae' })
export class EmpresaCnaeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'principal' }) 
	principal: string; 

	@Column({ name: 'ramo_atividade' }) 
	ramoAtividade: string; 

	@Column({ name: 'objeto_social' }) 
	objetoSocial: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CnaeModel)
	@JoinColumn({ name: 'id_cnae' })
	cnaeModel: CnaeModel;

	@ManyToOne(() => EmpresaModel, empresaModel => empresaModel.empresaCnaeModelList)
	@JoinColumn({ name: 'id_empresa' })
	empresaModel: EmpresaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.principal = jsonObj['principal'];
			this.ramoAtividade = jsonObj['ramoAtividade'];
			this.objetoSocial = jsonObj['objetoSocial'];
			if (jsonObj['cnaeModel'] != null) {
				this.cnaeModel = new CnaeModel(jsonObj['cnaeModel']);
			}

		}
	}
}