import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FuncaoModel } from '../entities-export';
import { PapelModel } from '../entities-export';

@Entity({ name: 'papel_funcao' })
export class PapelFuncaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'habilitado' }) 
	habilitado: string; 

	@Column({ name: 'pode_inserir' }) 
	podeInserir: string; 

	@Column({ name: 'pode_alterar' }) 
	podeAlterar: string; 

	@Column({ name: 'pode_excluir' }) 
	podeExcluir: string; 


	/**
	* Relations
	*/
	@OneToOne(() => FuncaoModel)
	@JoinColumn({ name: 'id_funcao' })
	funcaoModel: FuncaoModel;

	@ManyToOne(() => PapelModel, papelModel => papelModel.papelFuncaoModelList)
	@JoinColumn({ name: 'id_papel' })
	papelModel: PapelModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.habilitado = jsonObj['habilitado'];
			this.podeInserir = jsonObj['podeInserir'];
			this.podeAlterar = jsonObj['podeAlterar'];
			this.podeExcluir = jsonObj['podeExcluir'];
			if (jsonObj['funcaoModel'] != null) {
				this.funcaoModel = new FuncaoModel(jsonObj['funcaoModel']);
			}

		}
	}
}