import { UsuarioTokenModel } from '../entities-export';
import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'auditoria' })
export class AuditoriaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_registro' }) 
	dataRegistro: Date; 

	@Column({ name: 'hora_registro' }) 
	horaRegistro: string; 

	@Column({ name: 'janela_controller' }) 
	janelaController: string; 

	@Column({ name: 'acao' }) 
	acao: string; 

	@Column({ name: 'conteudo' }) 
	conteudo: string; 

	@Column({ name: 'token_jwt' }) 
	tokenJwt: string; 


	/**
	* Relations
	*/
	@OneToOne(() => UsuarioTokenModel)
	@JoinColumn({ name: 'token_jwt', referencedColumnName: 'token' }) 
	usuarioTokenModel: UsuarioTokenModel;	

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataRegistro = jsonObj['dataRegistro'];
			this.horaRegistro = jsonObj['horaRegistro'];
			this.janelaController = jsonObj['janelaController'];
			this.acao = jsonObj['acao'];
			this.conteudo = jsonObj['conteudo'];
			this.tokenJwt = jsonObj['tokenJwt'];
		}
	}
}