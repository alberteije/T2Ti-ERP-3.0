import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EmpresaContatoModel } from '../entities-export';
import { EmpresaTelefoneModel } from '../entities-export';
import { EmpresaCnaeModel } from '../entities-export';
import { EmpresaEnderecoModel } from '../entities-export';

@Entity({ name: 'empresa' })
export class EmpresaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'razao_social' }) 
	razaoSocial: string; 

	@Column({ name: 'nome_fantasia' }) 
	nomeFantasia: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'inscricao_estadual' }) 
	inscricaoEstadual: string; 

	@Column({ name: 'inscricao_municipal' }) 
	inscricaoMunicipal: string; 

	@Column({ name: 'tipo_regime' }) 
	tipoRegime: string; 

	@Column({ name: 'crt' }) 
	crt: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'site' }) 
	site: string; 

	@Column({ name: 'contato' }) 
	contato: string; 

	@Column({ name: 'data_constituicao' }) 
	dataConstituicao: Date; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'inscricao_junta_comercial' }) 
	inscricaoJuntaComercial: string; 

	@Column({ name: 'data_insc_junta_comercial' }) 
	dataInscJuntaComercial: Date; 

	@Column({ name: 'codigo_ibge_cidade' }) 
	codigoIbgeCidade: number; 

	@Column({ name: 'codigo_ibge_uf' }) 
	codigoIbgeUf: number; 

	@Column({ name: 'cei' }) 
	cei: string; 

	@Column({ name: 'codigo_cnae_principal' }) 
	codigoCnaePrincipal: string; 

	@Column({ name: 'imagem_logotipo' }) 
	imagemLogotipo: string; 


	/**
	* Relations
	*/
	@OneToMany(() => EmpresaContatoModel, empresaContatoModel => empresaContatoModel.empresaModel, { cascade: true })
	empresaContatoModelList: EmpresaContatoModel[];

	@OneToMany(() => EmpresaTelefoneModel, empresaTelefoneModel => empresaTelefoneModel.empresaModel, { cascade: true })
	empresaTelefoneModelList: EmpresaTelefoneModel[];

	@OneToMany(() => EmpresaCnaeModel, empresaCnaeModel => empresaCnaeModel.empresaModel, { cascade: true })
	empresaCnaeModelList: EmpresaCnaeModel[];

	@OneToMany(() => EmpresaEnderecoModel, empresaEnderecoModel => empresaEnderecoModel.empresaModel, { cascade: true })
	empresaEnderecoModelList: EmpresaEnderecoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.razaoSocial = jsonObj['razaoSocial'];
			this.nomeFantasia = jsonObj['nomeFantasia'];
			this.cnpj = jsonObj['cnpj'];
			this.inscricaoEstadual = jsonObj['inscricaoEstadual'];
			this.inscricaoMunicipal = jsonObj['inscricaoMunicipal'];
			this.tipoRegime = jsonObj['tipoRegime'];
			this.crt = jsonObj['crt'];
			this.email = jsonObj['email'];
			this.site = jsonObj['site'];
			this.contato = jsonObj['contato'];
			this.dataConstituicao = jsonObj['dataConstituicao'];
			this.tipo = jsonObj['tipo'];
			this.inscricaoJuntaComercial = jsonObj['inscricaoJuntaComercial'];
			this.dataInscJuntaComercial = jsonObj['dataInscJuntaComercial'];
			this.codigoIbgeCidade = jsonObj['codigoIbgeCidade'];
			this.codigoIbgeUf = jsonObj['codigoIbgeUf'];
			this.cei = jsonObj['cei'];
			this.codigoCnaePrincipal = jsonObj['codigoCnaePrincipal'];
			this.imagemLogotipo = jsonObj['imagemLogotipo'];
			this.empresaContatoModelList = [];
			let empresaContatoModelJsonList = jsonObj['empresaContatoModelList'];
			if (empresaContatoModelJsonList != null) {
				for (let i = 0; i < empresaContatoModelJsonList.length; i++) {
					let obj = new EmpresaContatoModel(empresaContatoModelJsonList[i]);
					this.empresaContatoModelList.push(obj);
				}
			}

			this.empresaTelefoneModelList = [];
			let empresaTelefoneModelJsonList = jsonObj['empresaTelefoneModelList'];
			if (empresaTelefoneModelJsonList != null) {
				for (let i = 0; i < empresaTelefoneModelJsonList.length; i++) {
					let obj = new EmpresaTelefoneModel(empresaTelefoneModelJsonList[i]);
					this.empresaTelefoneModelList.push(obj);
				}
			}

			this.empresaCnaeModelList = [];
			let empresaCnaeModelJsonList = jsonObj['empresaCnaeModelList'];
			if (empresaCnaeModelJsonList != null) {
				for (let i = 0; i < empresaCnaeModelJsonList.length; i++) {
					let obj = new EmpresaCnaeModel(empresaCnaeModelJsonList[i]);
					this.empresaCnaeModelList.push(obj);
				}
			}

			this.empresaEnderecoModelList = [];
			let empresaEnderecoModelJsonList = jsonObj['empresaEnderecoModelList'];
			if (empresaEnderecoModelJsonList != null) {
				for (let i = 0; i < empresaEnderecoModelJsonList.length; i++) {
					let obj = new EmpresaEnderecoModel(empresaEnderecoModelJsonList[i]);
					this.empresaEnderecoModelList.push(obj);
				}
			}

		}
	}
}