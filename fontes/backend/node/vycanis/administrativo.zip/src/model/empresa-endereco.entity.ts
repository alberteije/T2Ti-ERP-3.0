import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EmpresaModel } from '../entities-export';

@Entity({ name: 'empresa_endereco' })
export class EmpresaEnderecoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'cidade' }) 
	cidade: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'cep' }) 
	cep: string; 

	@Column({ name: 'municipio_ibge' }) 
	municipioIbge: number; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'principal' }) 
	principal: string; 

	@Column({ name: 'entrega' }) 
	entrega: string; 

	@Column({ name: 'cobranca' }) 
	cobranca: string; 

	@Column({ name: 'correspondencia' }) 
	correspondencia: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => EmpresaModel, empresaModel => empresaModel.empresaEnderecoModelList)
	@JoinColumn({ name: 'id_empresa' })
	empresaModel: EmpresaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.bairro = jsonObj['bairro'];
			this.cidade = jsonObj['cidade'];
			this.uf = jsonObj['uf'];
			this.cep = jsonObj['cep'];
			this.municipioIbge = jsonObj['municipioIbge'];
			this.complemento = jsonObj['complemento'];
			this.principal = jsonObj['principal'];
			this.entrega = jsonObj['entrega'];
			this.cobranca = jsonObj['cobranca'];
			this.correspondencia = jsonObj['correspondencia'];
		}
	}
}