import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsuarioTokenController } from '../controller/usuario-token.controller';
import { UsuarioTokenService } from '../service/usuario-token.service';
import { UsuarioTokenModel } from '../model/usuario-token.entity';

@Module({
    imports: [TypeOrmModule.forFeature([UsuarioTokenModel])],
    controllers: [UsuarioTokenController],
    providers: [UsuarioTokenService],
})
export class UsuarioTokenModule { }
