import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PapelController } from '../controller/papel.controller';
import { PapelService } from '../service/papel.service';
import { PapelModel } from '../model/papel.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PapelModel])],
    controllers: [PapelController],
    providers: [PapelService],
})
export class PapelModule { }
