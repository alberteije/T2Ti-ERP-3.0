import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsuarioController } from '../controller/usuario.controller';
import { UsuarioService } from '../service/usuario.service';
import { UsuarioModel } from '../model/usuario.entity';

@Module({
    imports: [TypeOrmModule.forFeature([UsuarioModel])],
    controllers: [UsuarioController],
    providers: [UsuarioService],
})
export class UsuarioModule { }
