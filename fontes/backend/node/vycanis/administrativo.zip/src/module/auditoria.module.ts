import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuditoriaController } from '../controller/auditoria.controller';
import { AuditoriaService } from '../service/auditoria.service';
import { AuditoriaModel } from '../model/auditoria.entity';

@Module({
    imports: [TypeOrmModule.forFeature([AuditoriaModel])],
    controllers: [AuditoriaController],
    providers: [AuditoriaService],
    exports: [AuditoriaService], 
})
export class AuditoriaModule { }
