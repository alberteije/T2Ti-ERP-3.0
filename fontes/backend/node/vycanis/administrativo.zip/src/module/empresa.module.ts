import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EmpresaController } from '../controller/empresa.controller';
import { EmpresaService } from '../service/empresa.service';
import { EmpresaModel } from '../model/empresa.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EmpresaModel])],
    controllers: [EmpresaController],
    providers: [EmpresaService],
})
export class EmpresaModule { }
