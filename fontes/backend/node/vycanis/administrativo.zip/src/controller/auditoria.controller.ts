import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { AuditoriaService } from '../service/auditoria.service';
import { AuditoriaModel } from '../model/auditoria.entity';

@Crud({
  model: {
    type: AuditoriaModel,
  },
  query: {
    join: {
      usuarioTokenModel: { eager: true },
    },
  },
})
@Controller('auditoria')
export class AuditoriaController implements CrudController<AuditoriaModel> {
  constructor(public service: AuditoriaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const auditoriaModel = new AuditoriaModel(jsonObj);
		const result = await this.service.save(auditoriaModel);
		return result;
	}  


}


















