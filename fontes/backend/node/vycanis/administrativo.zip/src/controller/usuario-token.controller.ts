import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { UsuarioTokenService } from '../service/usuario-token.service';
import { UsuarioTokenModel } from '../model/usuario-token.entity';

@Crud({
  model: {
    type: UsuarioTokenModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('usuario-token')
export class UsuarioTokenController implements CrudController<UsuarioTokenModel> {
  constructor(public service: UsuarioTokenService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const usuarioTokenModel = new UsuarioTokenModel(jsonObj);
		const result = await this.service.save(usuarioTokenModel);
		return result;
	}  


}


















