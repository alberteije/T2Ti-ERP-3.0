import { Controller, Put, Req, Get, Res, Param } from '@nestjs/common';
import { Request, Response } from 'express';
import { Crud, CrudController } from '@nestjsx/crud';
import { UsuarioService } from '../service/usuario.service';
import { UsuarioModel } from '../model/usuario.entity';

@Crud({
  model: {
    type: UsuarioModel,
  },
  query: {
    join: {
      viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('usuario')
export class UsuarioController implements CrudController<UsuarioModel> {
  constructor(public service: UsuarioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const usuarioModel = new UsuarioModel(jsonObj);
		const result = await this.service.save(usuarioModel);
		return result;
	}  

  @Get('verifica-login/:login')
	async getUsuarioPorLogin(
    @Req() request: Request, 
    @Res() response: Response,
    @Param('login') login
  ) {
    const usuario = await this.service.getUsuarioPeloLogin(login);
    
    if (usuario == null) {
      response.status(404);
      response.send('Registro não localizado [Consultar Usuário pelo Login]');    
    } else {
      response.setHeader('Content-Type', 'application/json');
      response.status(200);
      response.send(usuario);    
    }
  } 
}


















