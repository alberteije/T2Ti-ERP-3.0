import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FuncaoService } from '../service/funcao.service';
import { FuncaoModel } from '../model/funcao.entity';

@Crud({
  model: {
    type: FuncaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('funcao')
export class FuncaoController implements CrudController<FuncaoModel> {
  constructor(public service: FuncaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const funcaoModel = new FuncaoModel(jsonObj);
		const result = await this.service.save(funcaoModel);
		return result;
	}  


}


















