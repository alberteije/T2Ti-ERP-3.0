import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PapelService } from '../service/papel.service';
import { PapelModel } from '../model/papel.entity';

@Crud({
  model: {
    type: PapelModel,
  },
  query: {
    join: {
			papelFuncaoModelList: { eager: true },
			"papelFuncaoModelList.funcaoModel": { eager: true },
    },
  },
})
@Controller('papel')
export class PapelController implements CrudController<PapelModel> {
  constructor(public service: PapelService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const papel = new PapelModel(jsonObj);
		const result = await this.service.save(papel, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const papel = new PapelModel(jsonObj);
		const result = await this.service.save(papel, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}