import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ViewPessoaColaboradorService } from '../service/view-pessoa-colaborador.service';
import { ViewPessoaColaboradorModel } from '../model/view-pessoa-colaborador.entity';

@Crud({
  model: {
    type: ViewPessoaColaboradorModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('view-pessoa-colaborador')
export class ViewPessoaColaboradorController implements CrudController<ViewPessoaColaboradorModel> {
  constructor(public service: ViewPessoaColaboradorService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj);
		const result = await this.service.save(viewPessoaColaboradorModel);
		return result;
	}  


}


















