import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { EmpresaService } from '../service/empresa.service';
import { EmpresaModel } from '../model/empresa.entity';

@Crud({
  model: {
    type: EmpresaModel,
  },
  query: {
    join: {
			empresaContatoModelList: { eager: true },
			empresaTelefoneModelList: { eager: true },
			empresaCnaeModelList: { eager: true },
			empresaEnderecoModelList: { eager: true },
    },
  },
})
@Controller('empresa')
export class EmpresaController implements CrudController<EmpresaModel> {
  constructor(public service: EmpresaService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const empresa = new EmpresaModel(jsonObj);
		const result = await this.service.save(empresa, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const empresa = new EmpresaModel(jsonObj);
		const result = await this.service.save(empresa, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}