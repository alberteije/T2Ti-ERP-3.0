import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { EmpresaModel } from '../entities-export';

@Injectable()
export class EmpresaService extends TypeOrmCrudService<EmpresaModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(EmpresaModel) 
    private readonly repository: Repository<EmpresaModel>,
  ) {
    super(repository);
  }

	async save(empresaModel: EmpresaModel, operation: string): Promise<EmpresaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, empresaModel.id);
      }

      const resultObj = await queryRunner.manager.save(empresaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(EmpresaModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from empresa_contato where id_empresa=' + id); 

		await queryRunner.query('delete from empresa_telefone where id_empresa=' + id); 

		await queryRunner.query('delete from empresa_cnae where id_empresa=' + id); 

		await queryRunner.query('delete from empresa_endereco where id_empresa=' + id); 

	}
	
}