import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { UsuarioModel } from '../entities-export';

@Injectable()
export class UsuarioService extends TypeOrmCrudService<UsuarioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(UsuarioModel)
    private readonly repository: Repository<UsuarioModel>
  ) {
    super(repository);
  }

	async save(usuarioModel: UsuarioModel): Promise<UsuarioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(usuarioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  async getUsuarioPeloLogin(login: string) {
    const entityManager = this.dataSource.manager; 

    const usuario = await entityManager.findOne(UsuarioModel, {
      where: { login: login },
      relations: ['viewPessoaColaboradorModel'], // Especificando a relação a ser carregada
    });
    return usuario;
  }  
}
