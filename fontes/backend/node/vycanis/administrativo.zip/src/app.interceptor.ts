import { Injectable, NestInterceptor, ExecutionContext, CallHandler, UnauthorizedException } from '@nestjs/common';
import { Observable } from 'rxjs';
import { LoginService } from './login/login.service';
import { AuditoriaModel } from './entities-export';
import { AuditoriaService } from './service/auditoria.service';

//https://docs.nestjs.com/interceptors

@Injectable()
export class AppInterceptor implements NestInterceptor {

    constructor(private loginService: LoginService, private auditoriaService: AuditoriaService) { };

    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {

        const rotasLiberadas = ["/login"]; // array que contém as rotas que podem ser acessadas sem necessidade de envio do JWT.

        if (rotasLiberadas.includes(context.switchToHttp().getRequest().originalUrl)) {
            return next.handle();
        }
    
        // TODO: remova a linha abaixo e descomente o restante do codigo para liberar o esquema de autenticacao
        return next.handle();
        // TODO: descomente para liberar o esquema de autenticação
        // let token: string = context.switchToHttp().getRequest().headers['authorization'];

        // if (token != null) {
        //     token = token.replace("Bearer ", "");
        //     if (this.loginService.verificarToken(token)) {

        //         // Auditoria
        //         const request = context.switchToHttp().getRequest();
        //         const current_time = new Date();
        //         const objetoAuditoria = new AuditoriaModel({
        //             dataRegistro: current_time,
        //             horaRegistro: current_time.toTimeString().split(' ')[0],
        //             janelaController: request.url,
        //             acao: request.method,
        //             conteudo: (request.method === 'POST' || request.method === 'PUT') && request.body ? JSON.stringify(request.body) : request.url,
        //             tokenJwt: token
        //         });
                
        //         this.auditoriaService.save(objetoAuditoria);

        //         return next.handle();
        //     } else {
        //         throw new UnauthorizedException();
        //     }
        // }

        // throw new UnauthorizedException();
    }
}