import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeTransporteReboqueController } from '../controller/nfe-transporte-reboque.controller';
import { NfeTransporteReboqueService } from '../service/nfe-transporte-reboque.service';
import { NfeTransporteReboqueModel } from '../model/nfe-transporte-reboque.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeTransporteReboqueModel])],
    controllers: [NfeTransporteReboqueController],
    providers: [NfeTransporteReboqueService],
})
export class NfeTransporteReboqueModule { }
