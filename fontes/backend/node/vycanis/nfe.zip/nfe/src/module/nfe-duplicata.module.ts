import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeDuplicataController } from '../controller/nfe-duplicata.controller';
import { NfeDuplicataService } from '../service/nfe-duplicata.service';
import { NfeDuplicataModel } from '../model/nfe-duplicata.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeDuplicataModel])],
    controllers: [NfeDuplicataController],
    providers: [NfeDuplicataService],
})
export class NfeDuplicataModule { }
