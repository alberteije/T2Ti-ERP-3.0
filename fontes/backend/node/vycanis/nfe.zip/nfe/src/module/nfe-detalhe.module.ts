import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeDetalheController } from '../controller/nfe-detalhe.controller';
import { NfeDetalheService } from '../service/nfe-detalhe.service';
import { NfeDetalheModel } from '../model/nfe-detalhe.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeDetalheModel])],
    controllers: [NfeDetalheController],
    providers: [NfeDetalheService],
})
export class NfeDetalheModule { }
