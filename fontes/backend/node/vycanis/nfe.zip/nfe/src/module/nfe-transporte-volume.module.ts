import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeTransporteVolumeController } from '../controller/nfe-transporte-volume.controller';
import { NfeTransporteVolumeService } from '../service/nfe-transporte-volume.service';
import { NfeTransporteVolumeModel } from '../model/nfe-transporte-volume.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeTransporteVolumeModel])],
    controllers: [NfeTransporteVolumeController],
    providers: [NfeTransporteVolumeService],
})
export class NfeTransporteVolumeModule { }
