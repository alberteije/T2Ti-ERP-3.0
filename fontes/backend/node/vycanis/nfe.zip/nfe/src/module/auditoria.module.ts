import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuditoriaService } from '../service/auditoria.service';
import { AuditoriaModel } from '../model/auditoria.entity';

@Module({
    imports: [TypeOrmModule.forFeature([AuditoriaModel])],
    providers: [AuditoriaService],
    exports: [AuditoriaService],
})
export class AuditoriaModule { }
