import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ProdutoSubgrupoModel } from '../entities-export';

@Injectable()
export class ProdutoSubgrupoService extends TypeOrmCrudService<ProdutoSubgrupoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ProdutoSubgrupoModel) 
    private readonly repository: Repository<ProdutoSubgrupoModel>,
  ) {
    super(repository);
  }

	async save(produtoSubgrupoModel: ProdutoSubgrupoModel, operation: string): Promise<ProdutoSubgrupoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, produtoSubgrupoModel.id);
      }

      const resultObj = await queryRunner.manager.save(produtoSubgrupoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ProdutoSubgrupoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from produto where id_produto_subgrupo=' + id); 

	}
	
}