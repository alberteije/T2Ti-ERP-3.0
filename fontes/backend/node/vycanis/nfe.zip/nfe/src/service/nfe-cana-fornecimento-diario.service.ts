import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NfeCanaFornecimentoDiarioModel } from '../entities-export';

@Injectable()
export class NfeCanaFornecimentoDiarioService extends TypeOrmCrudService<NfeCanaFornecimentoDiarioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NfeCanaFornecimentoDiarioModel)
    private readonly repository: Repository<NfeCanaFornecimentoDiarioModel>
  ) {
    super(repository);
  }

	async save(nfeCanaFornecimentoDiarioModel: NfeCanaFornecimentoDiarioModel): Promise<NfeCanaFornecimentoDiarioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(nfeCanaFornecimentoDiarioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
