import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NfeImportacaoDetalheModel } from '../entities-export';

@Injectable()
export class NfeImportacaoDetalheService extends TypeOrmCrudService<NfeImportacaoDetalheModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NfeImportacaoDetalheModel)
    private readonly repository: Repository<NfeImportacaoDetalheModel>
  ) {
    super(repository);
  }

	async save(nfeImportacaoDetalheModel: NfeImportacaoDetalheModel): Promise<NfeImportacaoDetalheModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(nfeImportacaoDetalheModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
