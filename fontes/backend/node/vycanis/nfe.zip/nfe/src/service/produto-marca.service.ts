import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ProdutoMarcaModel } from '../entities-export';

@Injectable()
export class ProdutoMarcaService extends TypeOrmCrudService<ProdutoMarcaModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ProdutoMarcaModel) 
    private readonly repository: Repository<ProdutoMarcaModel>,
  ) {
    super(repository);
  }

	async save(produtoMarcaModel: ProdutoMarcaModel, operation: string): Promise<ProdutoMarcaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, produtoMarcaModel.id);
      }

      const resultObj = await queryRunner.manager.save(produtoMarcaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ProdutoMarcaModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from produto where id_produto_marca=' + id); 

	}
	
}