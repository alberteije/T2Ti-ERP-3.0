import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCanaModel } from '../entities-export';

@Entity({ name: 'nfe_cana_deducoes_safra' })
export class NfeCanaDeducoesSafraModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'decricao' }) 
	decricao: string; 

	@Column({ name: 'valor_deducao', type: 'decimal', precision: 18, scale: 6 }) 
	valorDeducao: number; 

	@Column({ name: 'valor_fornecimento', type: 'decimal', precision: 18, scale: 6 }) 
	valorFornecimento: number; 

	@Column({ name: 'valor_total_deducao', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalDeducao: number; 

	@Column({ name: 'valor_liquido_fornecimento', type: 'decimal', precision: 18, scale: 6 }) 
	valorLiquidoFornecimento: number; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeCanaModel)
	@JoinColumn({ name: 'id_nfe_cana' })
	nfeCanaModel: NfeCanaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.decricao = jsonObj['decricao'];
			this.valorDeducao = jsonObj['valorDeducao'];
			this.valorFornecimento = jsonObj['valorFornecimento'];
			this.valorTotalDeducao = jsonObj['valorTotalDeducao'];
			this.valorLiquidoFornecimento = jsonObj['valorLiquidoFornecimento'];
			if (jsonObj['nfeCanaModel'] != null) {
				this.nfeCanaModel = new NfeCanaModel(jsonObj['nfeCanaModel']);
			}

		}
	}
}