import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_cte_referenciado' })
export class NfeCteReferenciadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'chave_acesso' }) 
	chaveAcesso: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeCteReferenciadoModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.chaveAcesso = jsonObj['chaveAcesso'];
		}
	}
}