import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_pis_st' })
export class NfeDetalheImpostoPisStModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_base_calculo_pis_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorBaseCalculoPisSt: number; 

	@Column({ name: 'aliquota_pis_st_percentual', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaPisStPercentual: number; 

	@Column({ name: 'quantidade_vendida_pis_st', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeVendidaPisSt: number; 

	@Column({ name: 'aliquota_pis_st_reais', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaPisStReais: number; 

	@Column({ name: 'valor_pis_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorPisSt: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoPisStModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorBaseCalculoPisSt = jsonObj['valorBaseCalculoPisSt'];
			this.aliquotaPisStPercentual = jsonObj['aliquotaPisStPercentual'];
			this.quantidadeVendidaPisSt = jsonObj['quantidadeVendidaPisSt'];
			this.aliquotaPisStReais = jsonObj['aliquotaPisStReais'];
			this.valorPisSt = jsonObj['valorPisSt'];
		}
	}
}