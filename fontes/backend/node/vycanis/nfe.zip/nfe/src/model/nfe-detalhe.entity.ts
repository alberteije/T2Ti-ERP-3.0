import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetEspecificoVeiculoModel } from '../entities-export';
import { NfeDetEspecificoMedicamentoModel } from '../entities-export';
import { NfeDetEspecificoArmamentoModel } from '../entities-export';
import { NfeDetEspecificoCombustivelModel } from '../entities-export';
import { NfeDeclaracaoImportacaoModel } from '../entities-export';
import { NfeDetalheImpostoIcmsModel } from '../entities-export';
import { NfeDetalheImpostoIpiModel } from '../entities-export';
import { NfeDetalheImpostoIiModel } from '../entities-export';
import { NfeDetalheImpostoPisModel } from '../entities-export';
import { NfeDetalheImpostoCofinsModel } from '../entities-export';
import { NfeDetalheImpostoIssqnModel } from '../entities-export';
import { NfeExportacaoModel } from '../entities-export';
import { NfeItemRastreadoModel } from '../entities-export';
import { NfeDetalheImpostoPisStModel } from '../entities-export';
import { NfeDetalheImpostoIcmsUfdestModel } from '../entities-export';
import { NfeDetalheImpostoCofinsStModel } from '../entities-export';
import { NfeCabecalhoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe' })
export class NfeDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_item' }) 
	numeroItem: number; 

	@Column({ name: 'codigo_produto' }) 
	codigoProduto: string; 

	@Column({ name: 'gtin' }) 
	gtin: string; 

	@Column({ name: 'nome_produto' }) 
	nomeProduto: string; 

	@Column({ name: 'ncm' }) 
	ncm: string; 

	@Column({ name: 'nve' }) 
	nve: string; 

	@Column({ name: 'cest' }) 
	cest: string; 

	@Column({ name: 'indicador_escala_relevante' }) 
	indicadorEscalaRelevante: string; 

	@Column({ name: 'cnpj_fabricante' }) 
	cnpjFabricante: string; 

	@Column({ name: 'codigo_beneficio_fiscal' }) 
	codigoBeneficioFiscal: string; 

	@Column({ name: 'ex_tipi' }) 
	exTipi: number; 

	@Column({ name: 'cfop' }) 
	cfop: number; 

	@Column({ name: 'unidade_comercial' }) 
	unidadeComercial: string; 

	@Column({ name: 'quantidade_comercial', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeComercial: number; 

	@Column({ name: 'numero_pedido_compra' }) 
	numeroPedidoCompra: string; 

	@Column({ name: 'item_pedido_compra' }) 
	itemPedidoCompra: number; 

	@Column({ name: 'numero_fci' }) 
	numeroFci: string; 

	@Column({ name: 'numero_recopi' }) 
	numeroRecopi: string; 

	@Column({ name: 'valor_unitario_comercial', type: 'decimal', precision: 18, scale: 6 }) 
	valorUnitarioComercial: number; 

	@Column({ name: 'valor_bruto_produto', type: 'decimal', precision: 18, scale: 6 }) 
	valorBrutoProduto: number; 

	@Column({ name: 'gtin_unidade_tributavel' }) 
	gtinUnidadeTributavel: string; 

	@Column({ name: 'unidade_tributavel' }) 
	unidadeTributavel: string; 

	@Column({ name: 'quantidade_tributavel', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeTributavel: number; 

	@Column({ name: 'valor_unitario_tributavel', type: 'decimal', precision: 18, scale: 6 }) 
	valorUnitarioTributavel: number; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 

	@Column({ name: 'valor_seguro', type: 'decimal', precision: 18, scale: 6 }) 
	valorSeguro: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_outras_despesas', type: 'decimal', precision: 18, scale: 6 }) 
	valorOutrasDespesas: number; 

	@Column({ name: 'entra_total' }) 
	entraTotal: string; 

	@Column({ name: 'valor_total_tributos', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalTributos: number; 

	@Column({ name: 'percentual_devolvido', type: 'decimal', precision: 18, scale: 6 }) 
	percentualDevolvido: number; 

	@Column({ name: 'valor_ipi_devolvido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpiDevolvido: number; 

	@Column({ name: 'informacoes_adicionais' }) 
	informacoesAdicionais: string; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 


	/**
	* Relations
	*/
	@OneToMany(() => NfeDetEspecificoVeiculoModel, nfeDetEspecificoVeiculoModel => nfeDetEspecificoVeiculoModel.nfeDetalheModel, { cascade: true })
	nfeDetEspecificoVeiculoModelList: NfeDetEspecificoVeiculoModel[];

	@OneToMany(() => NfeDetEspecificoMedicamentoModel, nfeDetEspecificoMedicamentoModel => nfeDetEspecificoMedicamentoModel.nfeDetalheModel, { cascade: true })
	nfeDetEspecificoMedicamentoModelList: NfeDetEspecificoMedicamentoModel[];

	@OneToMany(() => NfeDetEspecificoArmamentoModel, nfeDetEspecificoArmamentoModel => nfeDetEspecificoArmamentoModel.nfeDetalheModel, { cascade: true })
	nfeDetEspecificoArmamentoModelList: NfeDetEspecificoArmamentoModel[];

	@OneToMany(() => NfeDetEspecificoCombustivelModel, nfeDetEspecificoCombustivelModel => nfeDetEspecificoCombustivelModel.nfeDetalheModel, { cascade: true })
	nfeDetEspecificoCombustivelModelList: NfeDetEspecificoCombustivelModel[];

	@OneToMany(() => NfeDeclaracaoImportacaoModel, nfeDeclaracaoImportacaoModel => nfeDeclaracaoImportacaoModel.nfeDetalheModel, { cascade: true })
	nfeDeclaracaoImportacaoModelList: NfeDeclaracaoImportacaoModel[];

	@OneToMany(() => NfeDetalheImpostoIcmsModel, nfeDetalheImpostoIcmsModel => nfeDetalheImpostoIcmsModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoIcmsModelList: NfeDetalheImpostoIcmsModel[];

	@OneToMany(() => NfeDetalheImpostoIpiModel, nfeDetalheImpostoIpiModel => nfeDetalheImpostoIpiModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoIpiModelList: NfeDetalheImpostoIpiModel[];

	@OneToMany(() => NfeDetalheImpostoIiModel, nfeDetalheImpostoIiModel => nfeDetalheImpostoIiModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoIiModelList: NfeDetalheImpostoIiModel[];

	@OneToMany(() => NfeDetalheImpostoPisModel, nfeDetalheImpostoPisModel => nfeDetalheImpostoPisModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoPisModelList: NfeDetalheImpostoPisModel[];

	@OneToMany(() => NfeDetalheImpostoCofinsModel, nfeDetalheImpostoCofinsModel => nfeDetalheImpostoCofinsModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoCofinsModelList: NfeDetalheImpostoCofinsModel[];

	@OneToMany(() => NfeDetalheImpostoIssqnModel, nfeDetalheImpostoIssqnModel => nfeDetalheImpostoIssqnModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoIssqnModelList: NfeDetalheImpostoIssqnModel[];

	@OneToMany(() => NfeExportacaoModel, nfeExportacaoModel => nfeExportacaoModel.nfeDetalheModel, { cascade: true })
	nfeExportacaoModelList: NfeExportacaoModel[];

	@OneToMany(() => NfeItemRastreadoModel, nfeItemRastreadoModel => nfeItemRastreadoModel.nfeDetalheModel, { cascade: true })
	nfeItemRastreadoModelList: NfeItemRastreadoModel[];

	@OneToMany(() => NfeDetalheImpostoPisStModel, nfeDetalheImpostoPisStModel => nfeDetalheImpostoPisStModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoPisStModelList: NfeDetalheImpostoPisStModel[];

	@OneToMany(() => NfeDetalheImpostoIcmsUfdestModel, nfeDetalheImpostoIcmsUfdestModel => nfeDetalheImpostoIcmsUfdestModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoIcmsUfdestModelList: NfeDetalheImpostoIcmsUfdestModel[];

	@OneToMany(() => NfeDetalheImpostoCofinsStModel, nfeDetalheImpostoCofinsStModel => nfeDetalheImpostoCofinsStModel.nfeDetalheModel, { cascade: true })
	nfeDetalheImpostoCofinsStModelList: NfeDetalheImpostoCofinsStModel[];

	@OneToOne(() => NfeCabecalhoModel)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroItem = jsonObj['numeroItem'];
			this.codigoProduto = jsonObj['codigoProduto'];
			this.gtin = jsonObj['gtin'];
			this.nomeProduto = jsonObj['nomeProduto'];
			this.ncm = jsonObj['ncm'];
			this.nve = jsonObj['nve'];
			this.cest = jsonObj['cest'];
			this.indicadorEscalaRelevante = jsonObj['indicadorEscalaRelevante'];
			this.cnpjFabricante = jsonObj['cnpjFabricante'];
			this.codigoBeneficioFiscal = jsonObj['codigoBeneficioFiscal'];
			this.exTipi = jsonObj['exTipi'];
			this.cfop = jsonObj['cfop'];
			this.unidadeComercial = jsonObj['unidadeComercial'];
			this.quantidadeComercial = jsonObj['quantidadeComercial'];
			this.numeroPedidoCompra = jsonObj['numeroPedidoCompra'];
			this.itemPedidoCompra = jsonObj['itemPedidoCompra'];
			this.numeroFci = jsonObj['numeroFci'];
			this.numeroRecopi = jsonObj['numeroRecopi'];
			this.valorUnitarioComercial = jsonObj['valorUnitarioComercial'];
			this.valorBrutoProduto = jsonObj['valorBrutoProduto'];
			this.gtinUnidadeTributavel = jsonObj['gtinUnidadeTributavel'];
			this.unidadeTributavel = jsonObj['unidadeTributavel'];
			this.quantidadeTributavel = jsonObj['quantidadeTributavel'];
			this.valorUnitarioTributavel = jsonObj['valorUnitarioTributavel'];
			this.valorFrete = jsonObj['valorFrete'];
			this.valorSeguro = jsonObj['valorSeguro'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorOutrasDespesas = jsonObj['valorOutrasDespesas'];
			this.entraTotal = jsonObj['entraTotal'];
			this.valorTotalTributos = jsonObj['valorTotalTributos'];
			this.percentualDevolvido = jsonObj['percentualDevolvido'];
			this.valorIpiDevolvido = jsonObj['valorIpiDevolvido'];
			this.informacoesAdicionais = jsonObj['informacoesAdicionais'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.valorTotal = jsonObj['valorTotal'];
			if (jsonObj['nfeCabecalhoModel'] != null) {
				this.nfeCabecalhoModel = new NfeCabecalhoModel(jsonObj['nfeCabecalhoModel']);
			}

			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

			this.nfeDetEspecificoVeiculoModelList = [];
			let nfeDetEspecificoVeiculoModelJsonList = jsonObj['nfeDetEspecificoVeiculoModelList'];
			if (nfeDetEspecificoVeiculoModelJsonList != null) {
				for (let i = 0; i < nfeDetEspecificoVeiculoModelJsonList.length; i++) {
					let obj = new NfeDetEspecificoVeiculoModel(nfeDetEspecificoVeiculoModelJsonList[i]);
					this.nfeDetEspecificoVeiculoModelList.push(obj);
				}
			}

			this.nfeDetEspecificoMedicamentoModelList = [];
			let nfeDetEspecificoMedicamentoModelJsonList = jsonObj['nfeDetEspecificoMedicamentoModelList'];
			if (nfeDetEspecificoMedicamentoModelJsonList != null) {
				for (let i = 0; i < nfeDetEspecificoMedicamentoModelJsonList.length; i++) {
					let obj = new NfeDetEspecificoMedicamentoModel(nfeDetEspecificoMedicamentoModelJsonList[i]);
					this.nfeDetEspecificoMedicamentoModelList.push(obj);
				}
			}

			this.nfeDetEspecificoArmamentoModelList = [];
			let nfeDetEspecificoArmamentoModelJsonList = jsonObj['nfeDetEspecificoArmamentoModelList'];
			if (nfeDetEspecificoArmamentoModelJsonList != null) {
				for (let i = 0; i < nfeDetEspecificoArmamentoModelJsonList.length; i++) {
					let obj = new NfeDetEspecificoArmamentoModel(nfeDetEspecificoArmamentoModelJsonList[i]);
					this.nfeDetEspecificoArmamentoModelList.push(obj);
				}
			}

			this.nfeDetEspecificoCombustivelModelList = [];
			let nfeDetEspecificoCombustivelModelJsonList = jsonObj['nfeDetEspecificoCombustivelModelList'];
			if (nfeDetEspecificoCombustivelModelJsonList != null) {
				for (let i = 0; i < nfeDetEspecificoCombustivelModelJsonList.length; i++) {
					let obj = new NfeDetEspecificoCombustivelModel(nfeDetEspecificoCombustivelModelJsonList[i]);
					this.nfeDetEspecificoCombustivelModelList.push(obj);
				}
			}

			this.nfeDeclaracaoImportacaoModelList = [];
			let nfeDeclaracaoImportacaoModelJsonList = jsonObj['nfeDeclaracaoImportacaoModelList'];
			if (nfeDeclaracaoImportacaoModelJsonList != null) {
				for (let i = 0; i < nfeDeclaracaoImportacaoModelJsonList.length; i++) {
					let obj = new NfeDeclaracaoImportacaoModel(nfeDeclaracaoImportacaoModelJsonList[i]);
					this.nfeDeclaracaoImportacaoModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoIcmsModelList = [];
			let nfeDetalheImpostoIcmsModelJsonList = jsonObj['nfeDetalheImpostoIcmsModelList'];
			if (nfeDetalheImpostoIcmsModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoIcmsModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoIcmsModel(nfeDetalheImpostoIcmsModelJsonList[i]);
					this.nfeDetalheImpostoIcmsModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoIpiModelList = [];
			let nfeDetalheImpostoIpiModelJsonList = jsonObj['nfeDetalheImpostoIpiModelList'];
			if (nfeDetalheImpostoIpiModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoIpiModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoIpiModel(nfeDetalheImpostoIpiModelJsonList[i]);
					this.nfeDetalheImpostoIpiModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoIiModelList = [];
			let nfeDetalheImpostoIiModelJsonList = jsonObj['nfeDetalheImpostoIiModelList'];
			if (nfeDetalheImpostoIiModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoIiModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoIiModel(nfeDetalheImpostoIiModelJsonList[i]);
					this.nfeDetalheImpostoIiModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoPisModelList = [];
			let nfeDetalheImpostoPisModelJsonList = jsonObj['nfeDetalheImpostoPisModelList'];
			if (nfeDetalheImpostoPisModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoPisModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoPisModel(nfeDetalheImpostoPisModelJsonList[i]);
					this.nfeDetalheImpostoPisModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoCofinsModelList = [];
			let nfeDetalheImpostoCofinsModelJsonList = jsonObj['nfeDetalheImpostoCofinsModelList'];
			if (nfeDetalheImpostoCofinsModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoCofinsModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoCofinsModel(nfeDetalheImpostoCofinsModelJsonList[i]);
					this.nfeDetalheImpostoCofinsModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoIssqnModelList = [];
			let nfeDetalheImpostoIssqnModelJsonList = jsonObj['nfeDetalheImpostoIssqnModelList'];
			if (nfeDetalheImpostoIssqnModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoIssqnModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoIssqnModel(nfeDetalheImpostoIssqnModelJsonList[i]);
					this.nfeDetalheImpostoIssqnModelList.push(obj);
				}
			}

			this.nfeExportacaoModelList = [];
			let nfeExportacaoModelJsonList = jsonObj['nfeExportacaoModelList'];
			if (nfeExportacaoModelJsonList != null) {
				for (let i = 0; i < nfeExportacaoModelJsonList.length; i++) {
					let obj = new NfeExportacaoModel(nfeExportacaoModelJsonList[i]);
					this.nfeExportacaoModelList.push(obj);
				}
			}

			this.nfeItemRastreadoModelList = [];
			let nfeItemRastreadoModelJsonList = jsonObj['nfeItemRastreadoModelList'];
			if (nfeItemRastreadoModelJsonList != null) {
				for (let i = 0; i < nfeItemRastreadoModelJsonList.length; i++) {
					let obj = new NfeItemRastreadoModel(nfeItemRastreadoModelJsonList[i]);
					this.nfeItemRastreadoModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoPisStModelList = [];
			let nfeDetalheImpostoPisStModelJsonList = jsonObj['nfeDetalheImpostoPisStModelList'];
			if (nfeDetalheImpostoPisStModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoPisStModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoPisStModel(nfeDetalheImpostoPisStModelJsonList[i]);
					this.nfeDetalheImpostoPisStModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoIcmsUfdestModelList = [];
			let nfeDetalheImpostoIcmsUfdestModelJsonList = jsonObj['nfeDetalheImpostoIcmsUfdestModelList'];
			if (nfeDetalheImpostoIcmsUfdestModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoIcmsUfdestModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoIcmsUfdestModel(nfeDetalheImpostoIcmsUfdestModelJsonList[i]);
					this.nfeDetalheImpostoIcmsUfdestModelList.push(obj);
				}
			}

			this.nfeDetalheImpostoCofinsStModelList = [];
			let nfeDetalheImpostoCofinsStModelJsonList = jsonObj['nfeDetalheImpostoCofinsStModelList'];
			if (nfeDetalheImpostoCofinsStModelJsonList != null) {
				for (let i = 0; i < nfeDetalheImpostoCofinsStModelJsonList.length; i++) {
					let obj = new NfeDetalheImpostoCofinsStModel(nfeDetalheImpostoCofinsStModelJsonList[i]);
					this.nfeDetalheImpostoCofinsStModelList.push(obj);
				}
			}

		}
	}
}