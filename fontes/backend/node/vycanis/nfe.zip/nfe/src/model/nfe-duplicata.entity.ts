import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeFaturaModel } from '../entities-export';

@Entity({ name: 'nfe_duplicata' })
export class NfeDuplicataModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_vencimento' }) 
	dataVencimento: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeFaturaModel)
	@JoinColumn({ name: 'id_nfe_fatura' })
	nfeFaturaModel: NfeFaturaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.dataVencimento = jsonObj['dataVencimento'];
			this.valor = jsonObj['valor'];
			if (jsonObj['nfeFaturaModel'] != null) {
				this.nfeFaturaModel = new NfeFaturaModel(jsonObj['nfeFaturaModel']);
			}

		}
	}
}