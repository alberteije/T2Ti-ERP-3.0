import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_declaracao_importacao' })
export class NfeDeclaracaoImportacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_documento' }) 
	numeroDocumento: string; 

	@Column({ name: 'data_registro' }) 
	dataRegistro: Date; 

	@Column({ name: 'local_desembaraco' }) 
	localDesembaraco: string; 

	@Column({ name: 'uf_desembaraco' }) 
	ufDesembaraco: string; 

	@Column({ name: 'data_desembaraco' }) 
	dataDesembaraco: Date; 

	@Column({ name: 'via_transporte' }) 
	viaTransporte: string; 

	@Column({ name: 'valor_afrmm', type: 'decimal', precision: 18, scale: 6 }) 
	valorAfrmm: number; 

	@Column({ name: 'forma_intermediacao' }) 
	formaIntermediacao: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'uf_terceiro' }) 
	ufTerceiro: string; 

	@Column({ name: 'codigo_exportador' }) 
	codigoExportador: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDeclaracaoImportacaoModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroDocumento = jsonObj['numeroDocumento'];
			this.dataRegistro = jsonObj['dataRegistro'];
			this.localDesembaraco = jsonObj['localDesembaraco'];
			this.ufDesembaraco = jsonObj['ufDesembaraco'];
			this.dataDesembaraco = jsonObj['dataDesembaraco'];
			this.viaTransporte = jsonObj['viaTransporte'];
			this.valorAfrmm = jsonObj['valorAfrmm'];
			this.formaIntermediacao = jsonObj['formaIntermediacao'];
			this.cnpj = jsonObj['cnpj'];
			this.ufTerceiro = jsonObj['ufTerceiro'];
			this.codigoExportador = jsonObj['codigoExportador'];
		}
	}
}