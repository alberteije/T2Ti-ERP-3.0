import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_transporte' })
export class NfeTransporteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_transportadora' }) 
	idTransportadora: number; 

	@Column({ name: 'modalidade_frete' }) 
	modalidadeFrete: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'inscricao_estadual' }) 
	inscricaoEstadual: string; 

	@Column({ name: 'endereco' }) 
	endereco: string; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'valor_servico', type: 'decimal', precision: 18, scale: 6 }) 
	valorServico: number; 

	@Column({ name: 'valor_bc_retencao_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcRetencaoIcms: number; 

	@Column({ name: 'aliquota_retencao_icms', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaRetencaoIcms: number; 

	@Column({ name: 'valor_icms_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsRetido: number; 

	@Column({ name: 'cfop' }) 
	cfop: number; 

	@Column({ name: 'municipio' }) 
	municipio: number; 

	@Column({ name: 'placa_veiculo' }) 
	placaVeiculo: string; 

	@Column({ name: 'uf_veiculo' }) 
	ufVeiculo: string; 

	@Column({ name: 'rntc_veiculo' }) 
	rntcVeiculo: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeTransporteModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idTransportadora = jsonObj['idTransportadora'];
			this.modalidadeFrete = jsonObj['modalidadeFrete'];
			this.cnpj = jsonObj['cnpj'];
			this.cpf = jsonObj['cpf'];
			this.nome = jsonObj['nome'];
			this.inscricaoEstadual = jsonObj['inscricaoEstadual'];
			this.endereco = jsonObj['endereco'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
			this.uf = jsonObj['uf'];
			this.valorServico = jsonObj['valorServico'];
			this.valorBcRetencaoIcms = jsonObj['valorBcRetencaoIcms'];
			this.aliquotaRetencaoIcms = jsonObj['aliquotaRetencaoIcms'];
			this.valorIcmsRetido = jsonObj['valorIcmsRetido'];
			this.cfop = jsonObj['cfop'];
			this.municipio = jsonObj['municipio'];
			this.placaVeiculo = jsonObj['placaVeiculo'];
			this.ufVeiculo = jsonObj['ufVeiculo'];
			this.rntcVeiculo = jsonObj['rntcVeiculo'];
		}
	}
}