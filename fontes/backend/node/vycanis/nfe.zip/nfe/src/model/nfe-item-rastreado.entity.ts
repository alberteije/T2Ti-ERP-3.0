import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_item_rastreado' })
export class NfeItemRastreadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_lote' }) 
	numeroLote: string; 

	@Column({ name: 'quantidade_itens', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeItens: number; 

	@Column({ name: 'data_fabricacao' }) 
	dataFabricacao: Date; 

	@Column({ name: 'data_validade' }) 
	dataValidade: Date; 

	@Column({ name: 'codigo_agregacao' }) 
	codigoAgregacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeItemRastreadoModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroLote = jsonObj['numeroLote'];
			this.quantidadeItens = jsonObj['quantidadeItens'];
			this.dataFabricacao = jsonObj['dataFabricacao'];
			this.dataValidade = jsonObj['dataValidade'];
			this.codigoAgregacao = jsonObj['codigoAgregacao'];
		}
	}
}