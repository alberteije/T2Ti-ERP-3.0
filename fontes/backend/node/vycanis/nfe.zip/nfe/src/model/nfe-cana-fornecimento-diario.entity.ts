import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCanaModel } from '../entities-export';

@Entity({ name: 'nfe_cana_fornecimento_diario' })
export class NfeCanaFornecimentoDiarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'dia' }) 
	dia: string; 

	@Column({ name: 'quantidade', type: 'decimal', precision: 18, scale: 6 }) 
	quantidade: number; 

	@Column({ name: 'quantidade_total_mes', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeTotalMes: number; 

	@Column({ name: 'quantidade_total_anterior', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeTotalAnterior: number; 

	@Column({ name: 'quantidade_total_geral', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeTotalGeral: number; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeCanaModel)
	@JoinColumn({ name: 'id_nfe_cana' })
	nfeCanaModel: NfeCanaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dia = jsonObj['dia'];
			this.quantidade = jsonObj['quantidade'];
			this.quantidadeTotalMes = jsonObj['quantidadeTotalMes'];
			this.quantidadeTotalAnterior = jsonObj['quantidadeTotalAnterior'];
			this.quantidadeTotalGeral = jsonObj['quantidadeTotalGeral'];
			if (jsonObj['nfeCanaModel'] != null) {
				this.nfeCanaModel = new NfeCanaModel(jsonObj['nfeCanaModel']);
			}

		}
	}
}