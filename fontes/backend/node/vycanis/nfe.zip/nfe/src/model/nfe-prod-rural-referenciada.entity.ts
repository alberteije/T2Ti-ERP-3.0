import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_prod_rural_referenciada' })
export class NfeProdRuralReferenciadaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_uf' }) 
	codigoUf: number; 

	@Column({ name: 'ano_mes' }) 
	anoMes: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'inscricao_estadual' }) 
	inscricaoEstadual: string; 

	@Column({ name: 'modelo' }) 
	modelo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero_nf' }) 
	numeroNf: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeProdRuralReferenciadaModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoUf = jsonObj['codigoUf'];
			this.anoMes = jsonObj['anoMes'];
			this.cnpj = jsonObj['cnpj'];
			this.cpf = jsonObj['cpf'];
			this.inscricaoEstadual = jsonObj['inscricaoEstadual'];
			this.modelo = jsonObj['modelo'];
			this.serie = jsonObj['serie'];
			this.numeroNf = jsonObj['numeroNf'];
		}
	}
}