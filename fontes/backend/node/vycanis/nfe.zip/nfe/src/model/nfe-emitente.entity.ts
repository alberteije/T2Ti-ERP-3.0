import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_emitente' })
export class NfeEmitenteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'fantasia' }) 
	fantasia: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: number; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'cep' }) 
	cep: string; 

	@Column({ name: 'codigo_pais' }) 
	codigoPais: number; 

	@Column({ name: 'nome_pais' }) 
	nomePais: string; 

	@Column({ name: 'telefone' }) 
	telefone: string; 

	@Column({ name: 'inscricao_estadual' }) 
	inscricaoEstadual: string; 

	@Column({ name: 'inscricao_estadual_st' }) 
	inscricaoEstadualSt: string; 

	@Column({ name: 'inscricao_municipal' }) 
	inscricaoMunicipal: string; 

	@Column({ name: 'cnae' }) 
	cnae: string; 

	@Column({ name: 'crt' }) 
	crt: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeEmitenteModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.cpf = jsonObj['cpf'];
			this.nome = jsonObj['nome'];
			this.fantasia = jsonObj['fantasia'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
			this.uf = jsonObj['uf'];
			this.cep = jsonObj['cep'];
			this.codigoPais = jsonObj['codigoPais'];
			this.nomePais = jsonObj['nomePais'];
			this.telefone = jsonObj['telefone'];
			this.inscricaoEstadual = jsonObj['inscricaoEstadual'];
			this.inscricaoEstadualSt = jsonObj['inscricaoEstadualSt'];
			this.inscricaoMunicipal = jsonObj['inscricaoMunicipal'];
			this.cnae = jsonObj['cnae'];
			this.crt = jsonObj['crt'];
		}
	}
}