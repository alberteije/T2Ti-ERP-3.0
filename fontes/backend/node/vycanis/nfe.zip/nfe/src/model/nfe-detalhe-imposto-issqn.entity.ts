import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_issqn' })
export class NfeDetalheImpostoIssqnModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'base_calculo_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIssqn: number; 

	@Column({ name: 'aliquota_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIssqn: number; 

	@Column({ name: 'valor_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorIssqn: number; 

	@Column({ name: 'municipio_issqn' }) 
	municipioIssqn: number; 

	@Column({ name: 'item_lista_servicos' }) 
	itemListaServicos: number; 

	@Column({ name: 'valor_deducao', type: 'decimal', precision: 18, scale: 6 }) 
	valorDeducao: number; 

	@Column({ name: 'valor_outras_retencoes', type: 'decimal', precision: 18, scale: 6 }) 
	valorOutrasRetencoes: number; 

	@Column({ name: 'valor_desconto_incondicionado', type: 'decimal', precision: 18, scale: 6 }) 
	valorDescontoIncondicionado: number; 

	@Column({ name: 'valor_desconto_condicionado', type: 'decimal', precision: 18, scale: 6 }) 
	valorDescontoCondicionado: number; 

	@Column({ name: 'valor_retencao_iss', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetencaoIss: number; 

	@Column({ name: 'indicador_exigibilidade_iss' }) 
	indicadorExigibilidadeIss: string; 

	@Column({ name: 'codigo_servico' }) 
	codigoServico: string; 

	@Column({ name: 'municipio_incidencia' }) 
	municipioIncidencia: number; 

	@Column({ name: 'pais_sevico_prestado' }) 
	paisSevicoPrestado: number; 

	@Column({ name: 'numero_processo' }) 
	numeroProcesso: string; 

	@Column({ name: 'indicador_incentivo_fiscal' }) 
	indicadorIncentivoFiscal: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoIssqnModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.baseCalculoIssqn = jsonObj['baseCalculoIssqn'];
			this.aliquotaIssqn = jsonObj['aliquotaIssqn'];
			this.valorIssqn = jsonObj['valorIssqn'];
			this.municipioIssqn = jsonObj['municipioIssqn'];
			this.itemListaServicos = jsonObj['itemListaServicos'];
			this.valorDeducao = jsonObj['valorDeducao'];
			this.valorOutrasRetencoes = jsonObj['valorOutrasRetencoes'];
			this.valorDescontoIncondicionado = jsonObj['valorDescontoIncondicionado'];
			this.valorDescontoCondicionado = jsonObj['valorDescontoCondicionado'];
			this.valorRetencaoIss = jsonObj['valorRetencaoIss'];
			this.indicadorExigibilidadeIss = jsonObj['indicadorExigibilidadeIss'];
			this.codigoServico = jsonObj['codigoServico'];
			this.municipioIncidencia = jsonObj['municipioIncidencia'];
			this.paisSevicoPrestado = jsonObj['paisSevicoPrestado'];
			this.numeroProcesso = jsonObj['numeroProcesso'];
			this.indicadorIncentivoFiscal = jsonObj['indicadorIncentivoFiscal'];
		}
	}
}