import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_informacao_pagamento' })
export class NfeInformacaoPagamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'indicador_pagamento' }) 
	indicadorPagamento: string; 

	@Column({ name: 'meio_pagamento' }) 
	meioPagamento: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'tipo_integracao' }) 
	tipoIntegracao: string; 

	@Column({ name: 'cnpj_operadora_cartao' }) 
	cnpjOperadoraCartao: string; 

	@Column({ name: 'bandeira' }) 
	bandeira: string; 

	@Column({ name: 'numero_autorizacao' }) 
	numeroAutorizacao: string; 

	@Column({ name: 'troco', type: 'decimal', precision: 18, scale: 6 }) 
	troco: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeInformacaoPagamentoModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.indicadorPagamento = jsonObj['indicadorPagamento'];
			this.meioPagamento = jsonObj['meioPagamento'];
			this.valor = jsonObj['valor'];
			this.tipoIntegracao = jsonObj['tipoIntegracao'];
			this.cnpjOperadoraCartao = jsonObj['cnpjOperadoraCartao'];
			this.bandeira = jsonObj['bandeira'];
			this.numeroAutorizacao = jsonObj['numeroAutorizacao'];
			this.troco = jsonObj['troco'];
		}
	}
}