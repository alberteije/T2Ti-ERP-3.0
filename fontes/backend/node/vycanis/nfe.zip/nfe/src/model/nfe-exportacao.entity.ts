import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_exportacao' })
export class NfeExportacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'drawback' }) 
	drawback: number; 

	@Column({ name: 'numero_registro' }) 
	numeroRegistro: number; 

	@Column({ name: 'chave_acesso' }) 
	chaveAcesso: string; 

	@Column({ name: 'quantidade', type: 'decimal', precision: 18, scale: 6 }) 
	quantidade: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeExportacaoModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.drawback = jsonObj['drawback'];
			this.numeroRegistro = jsonObj['numeroRegistro'];
			this.chaveAcesso = jsonObj['chaveAcesso'];
			this.quantidade = jsonObj['quantidade'];
		}
	}
}