import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeTransporteModel } from '../entities-export';

@Entity({ name: 'nfe_transporte_volume' })
export class NfeTransporteVolumeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade' }) 
	quantidade: number; 

	@Column({ name: 'especie' }) 
	especie: string; 

	@Column({ name: 'marca' }) 
	marca: string; 

	@Column({ name: 'numeracao' }) 
	numeracao: string; 

	@Column({ name: 'peso_liquido', type: 'decimal', precision: 18, scale: 6 }) 
	pesoLiquido: number; 

	@Column({ name: 'peso_bruto', type: 'decimal', precision: 18, scale: 6 }) 
	pesoBruto: number; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeTransporteModel)
	@JoinColumn({ name: 'id_nfe_transporte' })
	nfeTransporteModel: NfeTransporteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			this.especie = jsonObj['especie'];
			this.marca = jsonObj['marca'];
			this.numeracao = jsonObj['numeracao'];
			this.pesoLiquido = jsonObj['pesoLiquido'];
			this.pesoBruto = jsonObj['pesoBruto'];
			if (jsonObj['nfeTransporteModel'] != null) {
				this.nfeTransporteModel = new NfeTransporteModel(jsonObj['nfeTransporteModel']);
			}

		}
	}
}