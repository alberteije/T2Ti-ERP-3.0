import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_det_especifico_veiculo' })
export class NfeDetEspecificoVeiculoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo_operacao' }) 
	tipoOperacao: string; 

	@Column({ name: 'chassi' }) 
	chassi: string; 

	@Column({ name: 'cor' }) 
	cor: string; 

	@Column({ name: 'descricao_cor' }) 
	descricaoCor: string; 

	@Column({ name: 'potencia_motor' }) 
	potenciaMotor: string; 

	@Column({ name: 'cilindradas' }) 
	cilindradas: string; 

	@Column({ name: 'peso_liquido' }) 
	pesoLiquido: string; 

	@Column({ name: 'peso_bruto' }) 
	pesoBruto: string; 

	@Column({ name: 'numero_serie' }) 
	numeroSerie: string; 

	@Column({ name: 'tipo_combustivel' }) 
	tipoCombustivel: string; 

	@Column({ name: 'numero_motor' }) 
	numeroMotor: string; 

	@Column({ name: 'capacidade_maxima_tracao' }) 
	capacidadeMaximaTracao: string; 

	@Column({ name: 'distancia_eixos' }) 
	distanciaEixos: string; 

	@Column({ name: 'ano_modelo' }) 
	anoModelo: string; 

	@Column({ name: 'ano_fabricacao' }) 
	anoFabricacao: string; 

	@Column({ name: 'tipo_pintura' }) 
	tipoPintura: string; 

	@Column({ name: 'tipo_veiculo' }) 
	tipoVeiculo: string; 

	@Column({ name: 'especie_veiculo' }) 
	especieVeiculo: string; 

	@Column({ name: 'condicao_vin' }) 
	condicaoVin: string; 

	@Column({ name: 'condicao_veiculo' }) 
	condicaoVeiculo: string; 

	@Column({ name: 'codigo_marca_modelo' }) 
	codigoMarcaModelo: string; 

	@Column({ name: 'codigo_cor_denatran' }) 
	codigoCorDenatran: string; 

	@Column({ name: 'lotacao_maxima' }) 
	lotacaoMaxima: number; 

	@Column({ name: 'restricao' }) 
	restricao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetEspecificoVeiculoModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipoOperacao = jsonObj['tipoOperacao'];
			this.chassi = jsonObj['chassi'];
			this.cor = jsonObj['cor'];
			this.descricaoCor = jsonObj['descricaoCor'];
			this.potenciaMotor = jsonObj['potenciaMotor'];
			this.cilindradas = jsonObj['cilindradas'];
			this.pesoLiquido = jsonObj['pesoLiquido'];
			this.pesoBruto = jsonObj['pesoBruto'];
			this.numeroSerie = jsonObj['numeroSerie'];
			this.tipoCombustivel = jsonObj['tipoCombustivel'];
			this.numeroMotor = jsonObj['numeroMotor'];
			this.capacidadeMaximaTracao = jsonObj['capacidadeMaximaTracao'];
			this.distanciaEixos = jsonObj['distanciaEixos'];
			this.anoModelo = jsonObj['anoModelo'];
			this.anoFabricacao = jsonObj['anoFabricacao'];
			this.tipoPintura = jsonObj['tipoPintura'];
			this.tipoVeiculo = jsonObj['tipoVeiculo'];
			this.especieVeiculo = jsonObj['especieVeiculo'];
			this.condicaoVin = jsonObj['condicaoVin'];
			this.condicaoVeiculo = jsonObj['condicaoVeiculo'];
			this.codigoMarcaModelo = jsonObj['codigoMarcaModelo'];
			this.codigoCorDenatran = jsonObj['codigoCorDenatran'];
			this.lotacaoMaxima = jsonObj['lotacaoMaxima'];
			this.restricao = jsonObj['restricao'];
		}
	}
}