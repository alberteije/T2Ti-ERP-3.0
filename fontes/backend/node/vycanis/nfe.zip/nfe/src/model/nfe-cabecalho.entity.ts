import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeReferenciadaModel } from '../entities-export';
import { NfeEmitenteModel } from '../entities-export';
import { NfeDestinatarioModel } from '../entities-export';
import { NfeLocalRetiradaModel } from '../entities-export';
import { NfeLocalEntregaModel } from '../entities-export';
import { NfeTransporteModel } from '../entities-export';
import { NfeFaturaModel } from '../entities-export';
import { NfeCanaModel } from '../entities-export';
import { NfeProdRuralReferenciadaModel } from '../entities-export';
import { NfeNfReferenciadaModel } from '../entities-export';
import { NfeProcessoReferenciadoModel } from '../entities-export';
import { NfeAcessoXmlModel } from '../entities-export';
import { NfeInformacaoPagamentoModel } from '../entities-export';
import { NfeResponsavelTecnicoModel } from '../entities-export';
import { TributOperacaoFiscalModel } from '../entities-export';
import { VendaCabecalhoModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { ViewPessoaFornecedorModel } from '../entities-export';
import { NfeCteReferenciadoModel } from '../entities-export';
import { NfeCupomFiscalReferenciadoModel } from '../entities-export';

@Entity({ name: 'nfe_cabecalho' })
export class NfeCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'uf_emitente' }) 
	ufEmitente: string; 

	@Column({ name: 'codigo_numerico' }) 
	codigoNumerico: string; 

	@Column({ name: 'natureza_operacao' }) 
	naturezaOperacao: string; 

	@Column({ name: 'codigo_modelo' }) 
	codigoModelo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_hora_emissao' }) 
	dataHoraEmissao: Date; 

	@Column({ name: 'data_hora_entrada_saida' }) 
	dataHoraEntradaSaida: Date; 

	@Column({ name: 'tipo_operacao' }) 
	tipoOperacao: string; 

	@Column({ name: 'local_destino' }) 
	localDestino: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: number; 

	@Column({ name: 'formato_impressao_danfe' }) 
	formatoImpressaoDanfe: string; 

	@Column({ name: 'tipo_emissao' }) 
	tipoEmissao: string; 

	@Column({ name: 'chave_acesso' }) 
	chaveAcesso: string; 

	@Column({ name: 'digito_chave_acesso' }) 
	digitoChaveAcesso: string; 

	@Column({ name: 'ambiente' }) 
	ambiente: string; 

	@Column({ name: 'finalidade_emissao' }) 
	finalidadeEmissao: string; 

	@Column({ name: 'consumidor_operacao' }) 
	consumidorOperacao: string; 

	@Column({ name: 'consumidor_presenca' }) 
	consumidorPresenca: string; 

	@Column({ name: 'processo_emissao' }) 
	processoEmissao: string; 

	@Column({ name: 'versao_processo_emissao' }) 
	versaoProcessoEmissao: string; 

	@Column({ name: 'data_entrada_contingencia' }) 
	dataEntradaContingencia: Date; 

	@Column({ name: 'justificativa_contingencia' }) 
	justificativaContingencia: string; 

	@Column({ name: 'base_calculo_icms', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcms: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'valor_icms_desonerado', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsDesonerado: number; 

	@Column({ name: 'total_icms_fcp_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	totalIcmsFcpUfDestino: number; 

	@Column({ name: 'total_icms_interestadual_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	totalIcmsInterestadualUfDestino: number; 

	@Column({ name: 'total_icms_interestadual_uf_remetente', type: 'decimal', precision: 18, scale: 6 }) 
	totalIcmsInterestadualUfRemetente: number; 

	@Column({ name: 'valor_total_fcp', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalFcp: number; 

	@Column({ name: 'base_calculo_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcmsSt: number; 

	@Column({ name: 'valor_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsSt: number; 

	@Column({ name: 'valor_total_fcp_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalFcpSt: number; 

	@Column({ name: 'valor_total_fcp_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalFcpStRetido: number; 

	@Column({ name: 'valor_total_produtos', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalProdutos: number; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 

	@Column({ name: 'valor_seguro', type: 'decimal', precision: 18, scale: 6 }) 
	valorSeguro: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_imposto_importacao', type: 'decimal', precision: 18, scale: 6 }) 
	valorImpostoImportacao: number; 

	@Column({ name: 'valor_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpi: number; 

	@Column({ name: 'valor_ipi_devolvido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpiDevolvido: number; 

	@Column({ name: 'valor_pis', type: 'decimal', precision: 18, scale: 6 }) 
	valorPis: number; 

	@Column({ name: 'valor_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofins: number; 

	@Column({ name: 'valor_despesas_acessorias', type: 'decimal', precision: 18, scale: 6 }) 
	valorDespesasAcessorias: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'valor_total_tributos', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalTributos: number; 

	@Column({ name: 'valor_servicos', type: 'decimal', precision: 18, scale: 6 }) 
	valorServicos: number; 

	@Column({ name: 'base_calculo_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIssqn: number; 

	@Column({ name: 'valor_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorIssqn: number; 

	@Column({ name: 'valor_pis_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorPisIssqn: number; 

	@Column({ name: 'valor_cofins_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofinsIssqn: number; 

	@Column({ name: 'data_prestacao_servico' }) 
	dataPrestacaoServico: Date; 

	@Column({ name: 'valor_deducao_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	valorDeducaoIssqn: number; 

	@Column({ name: 'outras_retencoes_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	outrasRetencoesIssqn: number; 

	@Column({ name: 'desconto_incondicionado_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	descontoIncondicionadoIssqn: number; 

	@Column({ name: 'desconto_condicionado_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	descontoCondicionadoIssqn: number; 

	@Column({ name: 'total_retencao_issqn', type: 'decimal', precision: 18, scale: 6 }) 
	totalRetencaoIssqn: number; 

	@Column({ name: 'regime_especial_tributacao' }) 
	regimeEspecialTributacao: string; 

	@Column({ name: 'valor_retido_pis', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoPis: number; 

	@Column({ name: 'valor_retido_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoCofins: number; 

	@Column({ name: 'valor_retido_csll', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoCsll: number; 

	@Column({ name: 'base_calculo_irrf', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIrrf: number; 

	@Column({ name: 'valor_retido_irrf', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoIrrf: number; 

	@Column({ name: 'base_calculo_previdencia', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoPrevidencia: number; 

	@Column({ name: 'valor_retido_previdencia', type: 'decimal', precision: 18, scale: 6 }) 
	valorRetidoPrevidencia: number; 

	@Column({ name: 'informacoes_add_fisco' }) 
	informacoesAddFisco: string; 

	@Column({ name: 'informacoes_add_contribuinte' }) 
	informacoesAddContribuinte: string; 

	@Column({ name: 'comex_uf_embarque' }) 
	comexUfEmbarque: string; 

	@Column({ name: 'comex_local_embarque' }) 
	comexLocalEmbarque: string; 

	@Column({ name: 'comex_local_despacho' }) 
	comexLocalDespacho: string; 

	@Column({ name: 'compra_nota_empenho' }) 
	compraNotaEmpenho: string; 

	@Column({ name: 'compra_pedido' }) 
	compraPedido: string; 

	@Column({ name: 'compra_contrato' }) 
	compraContrato: string; 

	@Column({ name: 'qrcode' }) 
	qrcode: string; 

	@Column({ name: 'url_chave' }) 
	urlChave: string; 

	@Column({ name: 'status_nota' }) 
	statusNota: string; 


	/**
	* Relations
	*/
	@OneToMany(() => NfeReferenciadaModel, nfeReferenciadaModel => nfeReferenciadaModel.nfeCabecalhoModel, { cascade: true })
	nfeReferenciadaModelList: NfeReferenciadaModel[];

	@OneToMany(() => NfeEmitenteModel, nfeEmitenteModel => nfeEmitenteModel.nfeCabecalhoModel, { cascade: true })
	nfeEmitenteModelList: NfeEmitenteModel[];

	@OneToMany(() => NfeDestinatarioModel, nfeDestinatarioModel => nfeDestinatarioModel.nfeCabecalhoModel, { cascade: true })
	nfeDestinatarioModelList: NfeDestinatarioModel[];

	@OneToMany(() => NfeLocalRetiradaModel, nfeLocalRetiradaModel => nfeLocalRetiradaModel.nfeCabecalhoModel, { cascade: true })
	nfeLocalRetiradaModelList: NfeLocalRetiradaModel[];

	@OneToMany(() => NfeLocalEntregaModel, nfeLocalEntregaModel => nfeLocalEntregaModel.nfeCabecalhoModel, { cascade: true })
	nfeLocalEntregaModelList: NfeLocalEntregaModel[];

	@OneToMany(() => NfeTransporteModel, nfeTransporteModel => nfeTransporteModel.nfeCabecalhoModel, { cascade: true })
	nfeTransporteModelList: NfeTransporteModel[];

	@OneToMany(() => NfeFaturaModel, nfeFaturaModel => nfeFaturaModel.nfeCabecalhoModel, { cascade: true })
	nfeFaturaModelList: NfeFaturaModel[];

	@OneToMany(() => NfeCanaModel, nfeCanaModel => nfeCanaModel.nfeCabecalhoModel, { cascade: true })
	nfeCanaModelList: NfeCanaModel[];

	@OneToMany(() => NfeProdRuralReferenciadaModel, nfeProdRuralReferenciadaModel => nfeProdRuralReferenciadaModel.nfeCabecalhoModel, { cascade: true })
	nfeProdRuralReferenciadaModelList: NfeProdRuralReferenciadaModel[];

	@OneToMany(() => NfeNfReferenciadaModel, nfeNfReferenciadaModel => nfeNfReferenciadaModel.nfeCabecalhoModel, { cascade: true })
	nfeNfReferenciadaModelList: NfeNfReferenciadaModel[];

	@OneToMany(() => NfeProcessoReferenciadoModel, nfeProcessoReferenciadoModel => nfeProcessoReferenciadoModel.nfeCabecalhoModel, { cascade: true })
	nfeProcessoReferenciadoModelList: NfeProcessoReferenciadoModel[];

	@OneToMany(() => NfeAcessoXmlModel, nfeAcessoXmlModel => nfeAcessoXmlModel.nfeCabecalhoModel, { cascade: true })
	nfeAcessoXmlModelList: NfeAcessoXmlModel[];

	@OneToMany(() => NfeInformacaoPagamentoModel, nfeInformacaoPagamentoModel => nfeInformacaoPagamentoModel.nfeCabecalhoModel, { cascade: true })
	nfeInformacaoPagamentoModelList: NfeInformacaoPagamentoModel[];

	@OneToMany(() => NfeResponsavelTecnicoModel, nfeResponsavelTecnicoModel => nfeResponsavelTecnicoModel.nfeCabecalhoModel, { cascade: true })
	nfeResponsavelTecnicoModelList: NfeResponsavelTecnicoModel[];

	@OneToOne(() => TributOperacaoFiscalModel)
	@JoinColumn({ name: 'id_tribut_operacao_fiscal' })
	tributOperacaoFiscalModel: TributOperacaoFiscalModel;

	@OneToOne(() => VendaCabecalhoModel)
	@JoinColumn({ name: 'id_venda_cabecalho' })
	vendaCabecalhoModel: VendaCabecalhoModel;

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => ViewPessoaFornecedorModel)
	@JoinColumn({ name: 'id_fornecedor' })
	viewPessoaFornecedorModel: ViewPessoaFornecedorModel;

	@OneToMany(() => NfeCteReferenciadoModel, nfeCteReferenciadoModel => nfeCteReferenciadoModel.nfeCabecalhoModel, { cascade: true })
	nfeCteReferenciadoModelList: NfeCteReferenciadoModel[];

	@OneToMany(() => NfeCupomFiscalReferenciadoModel, nfeCupomFiscalReferenciadoModel => nfeCupomFiscalReferenciadoModel.nfeCabecalhoModel, { cascade: true })
	nfeCupomFiscalReferenciadoModelList: NfeCupomFiscalReferenciadoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ufEmitente = jsonObj['ufEmitente'];
			this.codigoNumerico = jsonObj['codigoNumerico'];
			this.naturezaOperacao = jsonObj['naturezaOperacao'];
			this.codigoModelo = jsonObj['codigoModelo'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
			this.dataHoraEmissao = jsonObj['dataHoraEmissao'];
			this.dataHoraEntradaSaida = jsonObj['dataHoraEntradaSaida'];
			this.tipoOperacao = jsonObj['tipoOperacao'];
			this.localDestino = jsonObj['localDestino'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.formatoImpressaoDanfe = jsonObj['formatoImpressaoDanfe'];
			this.tipoEmissao = jsonObj['tipoEmissao'];
			this.chaveAcesso = jsonObj['chaveAcesso'];
			this.digitoChaveAcesso = jsonObj['digitoChaveAcesso'];
			this.ambiente = jsonObj['ambiente'];
			this.finalidadeEmissao = jsonObj['finalidadeEmissao'];
			this.consumidorOperacao = jsonObj['consumidorOperacao'];
			this.consumidorPresenca = jsonObj['consumidorPresenca'];
			this.processoEmissao = jsonObj['processoEmissao'];
			this.versaoProcessoEmissao = jsonObj['versaoProcessoEmissao'];
			this.dataEntradaContingencia = jsonObj['dataEntradaContingencia'];
			this.justificativaContingencia = jsonObj['justificativaContingencia'];
			this.baseCalculoIcms = jsonObj['baseCalculoIcms'];
			this.valorIcms = jsonObj['valorIcms'];
			this.valorIcmsDesonerado = jsonObj['valorIcmsDesonerado'];
			this.totalIcmsFcpUfDestino = jsonObj['totalIcmsFcpUfDestino'];
			this.totalIcmsInterestadualUfDestino = jsonObj['totalIcmsInterestadualUfDestino'];
			this.totalIcmsInterestadualUfRemetente = jsonObj['totalIcmsInterestadualUfRemetente'];
			this.valorTotalFcp = jsonObj['valorTotalFcp'];
			this.baseCalculoIcmsSt = jsonObj['baseCalculoIcmsSt'];
			this.valorIcmsSt = jsonObj['valorIcmsSt'];
			this.valorTotalFcpSt = jsonObj['valorTotalFcpSt'];
			this.valorTotalFcpStRetido = jsonObj['valorTotalFcpStRetido'];
			this.valorTotalProdutos = jsonObj['valorTotalProdutos'];
			this.valorFrete = jsonObj['valorFrete'];
			this.valorSeguro = jsonObj['valorSeguro'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorImpostoImportacao = jsonObj['valorImpostoImportacao'];
			this.valorIpi = jsonObj['valorIpi'];
			this.valorIpiDevolvido = jsonObj['valorIpiDevolvido'];
			this.valorPis = jsonObj['valorPis'];
			this.valorCofins = jsonObj['valorCofins'];
			this.valorDespesasAcessorias = jsonObj['valorDespesasAcessorias'];
			this.valorTotal = jsonObj['valorTotal'];
			this.valorTotalTributos = jsonObj['valorTotalTributos'];
			this.valorServicos = jsonObj['valorServicos'];
			this.baseCalculoIssqn = jsonObj['baseCalculoIssqn'];
			this.valorIssqn = jsonObj['valorIssqn'];
			this.valorPisIssqn = jsonObj['valorPisIssqn'];
			this.valorCofinsIssqn = jsonObj['valorCofinsIssqn'];
			this.dataPrestacaoServico = jsonObj['dataPrestacaoServico'];
			this.valorDeducaoIssqn = jsonObj['valorDeducaoIssqn'];
			this.outrasRetencoesIssqn = jsonObj['outrasRetencoesIssqn'];
			this.descontoIncondicionadoIssqn = jsonObj['descontoIncondicionadoIssqn'];
			this.descontoCondicionadoIssqn = jsonObj['descontoCondicionadoIssqn'];
			this.totalRetencaoIssqn = jsonObj['totalRetencaoIssqn'];
			this.regimeEspecialTributacao = jsonObj['regimeEspecialTributacao'];
			this.valorRetidoPis = jsonObj['valorRetidoPis'];
			this.valorRetidoCofins = jsonObj['valorRetidoCofins'];
			this.valorRetidoCsll = jsonObj['valorRetidoCsll'];
			this.baseCalculoIrrf = jsonObj['baseCalculoIrrf'];
			this.valorRetidoIrrf = jsonObj['valorRetidoIrrf'];
			this.baseCalculoPrevidencia = jsonObj['baseCalculoPrevidencia'];
			this.valorRetidoPrevidencia = jsonObj['valorRetidoPrevidencia'];
			this.informacoesAddFisco = jsonObj['informacoesAddFisco'];
			this.informacoesAddContribuinte = jsonObj['informacoesAddContribuinte'];
			this.comexUfEmbarque = jsonObj['comexUfEmbarque'];
			this.comexLocalEmbarque = jsonObj['comexLocalEmbarque'];
			this.comexLocalDespacho = jsonObj['comexLocalDespacho'];
			this.compraNotaEmpenho = jsonObj['compraNotaEmpenho'];
			this.compraPedido = jsonObj['compraPedido'];
			this.compraContrato = jsonObj['compraContrato'];
			this.qrcode = jsonObj['qrcode'];
			this.urlChave = jsonObj['urlChave'];
			this.statusNota = jsonObj['statusNota'];
			if (jsonObj['tributOperacaoFiscalModel'] != null) {
				this.tributOperacaoFiscalModel = new TributOperacaoFiscalModel(jsonObj['tributOperacaoFiscalModel']);
			}

			if (jsonObj['vendaCabecalhoModel'] != null) {
				this.vendaCabecalhoModel = new VendaCabecalhoModel(jsonObj['vendaCabecalhoModel']);
			}

			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['viewPessoaFornecedorModel'] != null) {
				this.viewPessoaFornecedorModel = new ViewPessoaFornecedorModel(jsonObj['viewPessoaFornecedorModel']);
			}

			this.nfeReferenciadaModelList = [];
			let nfeReferenciadaModelJsonList = jsonObj['nfeReferenciadaModelList'];
			if (nfeReferenciadaModelJsonList != null) {
				for (let i = 0; i < nfeReferenciadaModelJsonList.length; i++) {
					let obj = new NfeReferenciadaModel(nfeReferenciadaModelJsonList[i]);
					this.nfeReferenciadaModelList.push(obj);
				}
			}

			this.nfeEmitenteModelList = [];
			let nfeEmitenteModelJsonList = jsonObj['nfeEmitenteModelList'];
			if (nfeEmitenteModelJsonList != null) {
				for (let i = 0; i < nfeEmitenteModelJsonList.length; i++) {
					let obj = new NfeEmitenteModel(nfeEmitenteModelJsonList[i]);
					this.nfeEmitenteModelList.push(obj);
				}
			}

			this.nfeDestinatarioModelList = [];
			let nfeDestinatarioModelJsonList = jsonObj['nfeDestinatarioModelList'];
			if (nfeDestinatarioModelJsonList != null) {
				for (let i = 0; i < nfeDestinatarioModelJsonList.length; i++) {
					let obj = new NfeDestinatarioModel(nfeDestinatarioModelJsonList[i]);
					this.nfeDestinatarioModelList.push(obj);
				}
			}

			this.nfeLocalRetiradaModelList = [];
			let nfeLocalRetiradaModelJsonList = jsonObj['nfeLocalRetiradaModelList'];
			if (nfeLocalRetiradaModelJsonList != null) {
				for (let i = 0; i < nfeLocalRetiradaModelJsonList.length; i++) {
					let obj = new NfeLocalRetiradaModel(nfeLocalRetiradaModelJsonList[i]);
					this.nfeLocalRetiradaModelList.push(obj);
				}
			}

			this.nfeLocalEntregaModelList = [];
			let nfeLocalEntregaModelJsonList = jsonObj['nfeLocalEntregaModelList'];
			if (nfeLocalEntregaModelJsonList != null) {
				for (let i = 0; i < nfeLocalEntregaModelJsonList.length; i++) {
					let obj = new NfeLocalEntregaModel(nfeLocalEntregaModelJsonList[i]);
					this.nfeLocalEntregaModelList.push(obj);
				}
			}

			this.nfeTransporteModelList = [];
			let nfeTransporteModelJsonList = jsonObj['nfeTransporteModelList'];
			if (nfeTransporteModelJsonList != null) {
				for (let i = 0; i < nfeTransporteModelJsonList.length; i++) {
					let obj = new NfeTransporteModel(nfeTransporteModelJsonList[i]);
					this.nfeTransporteModelList.push(obj);
				}
			}

			this.nfeFaturaModelList = [];
			let nfeFaturaModelJsonList = jsonObj['nfeFaturaModelList'];
			if (nfeFaturaModelJsonList != null) {
				for (let i = 0; i < nfeFaturaModelJsonList.length; i++) {
					let obj = new NfeFaturaModel(nfeFaturaModelJsonList[i]);
					this.nfeFaturaModelList.push(obj);
				}
			}

			this.nfeCanaModelList = [];
			let nfeCanaModelJsonList = jsonObj['nfeCanaModelList'];
			if (nfeCanaModelJsonList != null) {
				for (let i = 0; i < nfeCanaModelJsonList.length; i++) {
					let obj = new NfeCanaModel(nfeCanaModelJsonList[i]);
					this.nfeCanaModelList.push(obj);
				}
			}

			this.nfeProdRuralReferenciadaModelList = [];
			let nfeProdRuralReferenciadaModelJsonList = jsonObj['nfeProdRuralReferenciadaModelList'];
			if (nfeProdRuralReferenciadaModelJsonList != null) {
				for (let i = 0; i < nfeProdRuralReferenciadaModelJsonList.length; i++) {
					let obj = new NfeProdRuralReferenciadaModel(nfeProdRuralReferenciadaModelJsonList[i]);
					this.nfeProdRuralReferenciadaModelList.push(obj);
				}
			}

			this.nfeNfReferenciadaModelList = [];
			let nfeNfReferenciadaModelJsonList = jsonObj['nfeNfReferenciadaModelList'];
			if (nfeNfReferenciadaModelJsonList != null) {
				for (let i = 0; i < nfeNfReferenciadaModelJsonList.length; i++) {
					let obj = new NfeNfReferenciadaModel(nfeNfReferenciadaModelJsonList[i]);
					this.nfeNfReferenciadaModelList.push(obj);
				}
			}

			this.nfeProcessoReferenciadoModelList = [];
			let nfeProcessoReferenciadoModelJsonList = jsonObj['nfeProcessoReferenciadoModelList'];
			if (nfeProcessoReferenciadoModelJsonList != null) {
				for (let i = 0; i < nfeProcessoReferenciadoModelJsonList.length; i++) {
					let obj = new NfeProcessoReferenciadoModel(nfeProcessoReferenciadoModelJsonList[i]);
					this.nfeProcessoReferenciadoModelList.push(obj);
				}
			}

			this.nfeAcessoXmlModelList = [];
			let nfeAcessoXmlModelJsonList = jsonObj['nfeAcessoXmlModelList'];
			if (nfeAcessoXmlModelJsonList != null) {
				for (let i = 0; i < nfeAcessoXmlModelJsonList.length; i++) {
					let obj = new NfeAcessoXmlModel(nfeAcessoXmlModelJsonList[i]);
					this.nfeAcessoXmlModelList.push(obj);
				}
			}

			this.nfeInformacaoPagamentoModelList = [];
			let nfeInformacaoPagamentoModelJsonList = jsonObj['nfeInformacaoPagamentoModelList'];
			if (nfeInformacaoPagamentoModelJsonList != null) {
				for (let i = 0; i < nfeInformacaoPagamentoModelJsonList.length; i++) {
					let obj = new NfeInformacaoPagamentoModel(nfeInformacaoPagamentoModelJsonList[i]);
					this.nfeInformacaoPagamentoModelList.push(obj);
				}
			}

			this.nfeResponsavelTecnicoModelList = [];
			let nfeResponsavelTecnicoModelJsonList = jsonObj['nfeResponsavelTecnicoModelList'];
			if (nfeResponsavelTecnicoModelJsonList != null) {
				for (let i = 0; i < nfeResponsavelTecnicoModelJsonList.length; i++) {
					let obj = new NfeResponsavelTecnicoModel(nfeResponsavelTecnicoModelJsonList[i]);
					this.nfeResponsavelTecnicoModelList.push(obj);
				}
			}

			this.nfeCteReferenciadoModelList = [];
			let nfeCteReferenciadoModelJsonList = jsonObj['nfeCteReferenciadoModelList'];
			if (nfeCteReferenciadoModelJsonList != null) {
				for (let i = 0; i < nfeCteReferenciadoModelJsonList.length; i++) {
					let obj = new NfeCteReferenciadoModel(nfeCteReferenciadoModelJsonList[i]);
					this.nfeCteReferenciadoModelList.push(obj);
				}
			}

			this.nfeCupomFiscalReferenciadoModelList = [];
			let nfeCupomFiscalReferenciadoModelJsonList = jsonObj['nfeCupomFiscalReferenciadoModelList'];
			if (nfeCupomFiscalReferenciadoModelJsonList != null) {
				for (let i = 0; i < nfeCupomFiscalReferenciadoModelJsonList.length; i++) {
					let obj = new NfeCupomFiscalReferenciadoModel(nfeCupomFiscalReferenciadoModelJsonList[i]);
					this.nfeCupomFiscalReferenciadoModelList.push(obj);
				}
			}

		}
	}
}