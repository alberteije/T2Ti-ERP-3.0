import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_icms_ufdest' })
export class NfeDetalheImpostoIcmsUfdestModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_bc_icms_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcmsUfDestino: number; 

	@Column({ name: 'valor_bc_fcp_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcFcpUfDestino: number; 

	@Column({ name: 'percentual_fcp_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	percentualFcpUfDestino: number; 

	@Column({ name: 'aliquota_interna_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaInternaUfDestino: number; 

	@Column({ name: 'aliquota_interesdatual_uf_envolvidas', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaInteresdatualUfEnvolvidas: number; 

	@Column({ name: 'percentual_provisorio_partilha_icms', type: 'decimal', precision: 18, scale: 6 }) 
	percentualProvisorioPartilhaIcms: number; 

	@Column({ name: 'valor_icms_fcp_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsFcpUfDestino: number; 

	@Column({ name: 'valor_interestadual_uf_destino', type: 'decimal', precision: 18, scale: 6 }) 
	valorInterestadualUfDestino: number; 

	@Column({ name: 'valor_interestadual_uf_remetente', type: 'decimal', precision: 18, scale: 6 }) 
	valorInterestadualUfRemetente: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoIcmsUfdestModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorBcIcmsUfDestino = jsonObj['valorBcIcmsUfDestino'];
			this.valorBcFcpUfDestino = jsonObj['valorBcFcpUfDestino'];
			this.percentualFcpUfDestino = jsonObj['percentualFcpUfDestino'];
			this.aliquotaInternaUfDestino = jsonObj['aliquotaInternaUfDestino'];
			this.aliquotaInteresdatualUfEnvolvidas = jsonObj['aliquotaInteresdatualUfEnvolvidas'];
			this.percentualProvisorioPartilhaIcms = jsonObj['percentualProvisorioPartilhaIcms'];
			this.valorIcmsFcpUfDestino = jsonObj['valorIcmsFcpUfDestino'];
			this.valorInterestadualUfDestino = jsonObj['valorInterestadualUfDestino'];
			this.valorInterestadualUfRemetente = jsonObj['valorInterestadualUfRemetente'];
		}
	}
}