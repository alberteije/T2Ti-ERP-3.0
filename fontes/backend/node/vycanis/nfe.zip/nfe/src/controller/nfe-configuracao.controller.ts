import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeConfiguracaoService } from '../service/nfe-configuracao.service';
import { NfeConfiguracaoModel } from '../model/nfe-configuracao.entity';

@Crud({
  model: {
    type: NfeConfiguracaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-configuracao')
export class NfeConfiguracaoController implements CrudController<NfeConfiguracaoModel> {
  constructor(public service: NfeConfiguracaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeConfiguracaoModel = new NfeConfiguracaoModel(jsonObj);
		const result = await this.service.save(nfeConfiguracaoModel);
		return result;
	}  


}


















