import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeCanaFornecimentoDiarioService } from '../service/nfe-cana-fornecimento-diario.service';
import { NfeCanaFornecimentoDiarioModel } from '../model/nfe-cana-fornecimento-diario.entity';

@Crud({
  model: {
    type: NfeCanaFornecimentoDiarioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-cana-fornecimento-diario')
export class NfeCanaFornecimentoDiarioController implements CrudController<NfeCanaFornecimentoDiarioModel> {
  constructor(public service: NfeCanaFornecimentoDiarioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeCanaFornecimentoDiarioModel = new NfeCanaFornecimentoDiarioModel(jsonObj);
		const result = await this.service.save(nfeCanaFornecimentoDiarioModel);
		return result;
	}  


}


















