import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeNumeroService } from '../service/nfe-numero.service';
import { NfeNumeroModel } from '../model/nfe-numero.entity';

@Crud({
  model: {
    type: NfeNumeroModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-numero')
export class NfeNumeroController implements CrudController<NfeNumeroModel> {
  constructor(public service: NfeNumeroService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeNumeroModel = new NfeNumeroModel(jsonObj);
		const result = await this.service.save(nfeNumeroModel);
		return result;
	}  


}


















