import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeNumeroInutilizadoService } from '../service/nfe-numero-inutilizado.service';
import { NfeNumeroInutilizadoModel } from '../model/nfe-numero-inutilizado.entity';

@Crud({
  model: {
    type: NfeNumeroInutilizadoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-numero-inutilizado')
export class NfeNumeroInutilizadoController implements CrudController<NfeNumeroInutilizadoModel> {
  constructor(public service: NfeNumeroInutilizadoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeNumeroInutilizadoModel = new NfeNumeroInutilizadoModel(jsonObj);
		const result = await this.service.save(nfeNumeroInutilizadoModel);
		return result;
	}  


}


















