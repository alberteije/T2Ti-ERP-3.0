import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeTransporteVolumeService } from '../service/nfe-transporte-volume.service';
import { NfeTransporteVolumeModel } from '../model/nfe-transporte-volume.entity';

@Crud({
  model: {
    type: NfeTransporteVolumeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-transporte-volume')
export class NfeTransporteVolumeController implements CrudController<NfeTransporteVolumeModel> {
  constructor(public service: NfeTransporteVolumeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeTransporteVolumeModel = new NfeTransporteVolumeModel(jsonObj);
		const result = await this.service.save(nfeTransporteVolumeModel);
		return result;
	}  


}


















