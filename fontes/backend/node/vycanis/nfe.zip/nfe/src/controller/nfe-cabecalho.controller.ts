import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { NfeCabecalhoService } from '../service/nfe-cabecalho.service';
import { NfeCabecalhoModel } from '../model/nfe-cabecalho.entity';

@Crud({
  model: {
    type: NfeCabecalhoModel,
  },
  query: {
    join: {
			nfeReferenciadaModelList: { eager: true },
			nfeEmitenteModelList: { eager: true },
			nfeDestinatarioModelList: { eager: true },
			nfeLocalRetiradaModelList: { eager: true },
			nfeLocalEntregaModelList: { eager: true },
			nfeTransporteModelList: { eager: true },
			nfeFaturaModelList: { eager: true },
			nfeCanaModelList: { eager: true },
			nfeProdRuralReferenciadaModelList: { eager: true },
			nfeNfReferenciadaModelList: { eager: true },
			nfeProcessoReferenciadoModelList: { eager: true },
			nfeAcessoXmlModelList: { eager: true },
			nfeInformacaoPagamentoModelList: { eager: true },
			nfeResponsavelTecnicoModelList: { eager: true },
			tributOperacaoFiscalModel: { eager: true },
			vendaCabecalhoModel: { eager: true },
			viewPessoaClienteModel: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
			viewPessoaFornecedorModel: { eager: true },
			nfeCteReferenciadoModelList: { eager: true },
			nfeCupomFiscalReferenciadoModelList: { eager: true },
    },
  },
})
@Controller('nfe-cabecalho')
export class NfeCabecalhoController implements CrudController<NfeCabecalhoModel> {
  constructor(public service: NfeCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeCabecalho = new NfeCabecalhoModel(jsonObj);
		const result = await this.service.save(nfeCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeCabecalho = new NfeCabecalhoModel(jsonObj);
		const result = await this.service.save(nfeCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}