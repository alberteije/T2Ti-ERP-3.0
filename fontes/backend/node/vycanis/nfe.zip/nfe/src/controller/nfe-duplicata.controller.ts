import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeDuplicataService } from '../service/nfe-duplicata.service';
import { NfeDuplicataModel } from '../model/nfe-duplicata.entity';

@Crud({
  model: {
    type: NfeDuplicataModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-duplicata')
export class NfeDuplicataController implements CrudController<NfeDuplicataModel> {
  constructor(public service: NfeDuplicataService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeDuplicataModel = new NfeDuplicataModel(jsonObj);
		const result = await this.service.save(nfeDuplicataModel);
		return result;
	}  


}


















