import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeCanaDeducoesSafraService } from '../service/nfe-cana-deducoes-safra.service';
import { NfeCanaDeducoesSafraModel } from '../model/nfe-cana-deducoes-safra.entity';

@Crud({
  model: {
    type: NfeCanaDeducoesSafraModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-cana-deducoes-safra')
export class NfeCanaDeducoesSafraController implements CrudController<NfeCanaDeducoesSafraModel> {
  constructor(public service: NfeCanaDeducoesSafraService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeCanaDeducoesSafraModel = new NfeCanaDeducoesSafraModel(jsonObj);
		const result = await this.service.save(nfeCanaDeducoesSafraModel);
		return result;
	}  


}


















