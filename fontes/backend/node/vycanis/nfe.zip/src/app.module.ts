import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { ProdutoGrupoModule } from './modules-export';
import { ProdutoSubgrupoModule } from './modules-export';
import { ProdutoMarcaModule } from './modules-export';
import { ProdutoUnidadeModule } from './modules-export';
import { NfeCabecalhoModule } from './modules-export';
import { NfeDetalheModule } from './modules-export';
import { TributOperacaoFiscalModule } from './modules-export';
import { VendaCabecalhoModule } from './modules-export';
import { NfeDuplicataModule } from './modules-export';
import { NfeImportacaoDetalheModule } from './modules-export';
import { NfeCanaFornecimentoDiarioModule } from './modules-export';
import { NfeCanaDeducoesSafraModule } from './modules-export';
import { NfeNumeroModule } from './modules-export';
import { NfeTransporteReboqueModule } from './modules-export';
import { NfeTransporteVolumeModule } from './modules-export';
import { NfeTransporteVolumeLacreModule } from './modules-export';
import { NfeConfiguracaoModule } from './modules-export';
import { NfeNumeroInutilizadoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaClienteModule } from './modules-export';
import { ViewPessoaFornecedorModule } from './modules-export';
import { ViewPessoaColaboradorModule } from './modules-export';
import { ViewPessoaVendedorModule } from './modules-export';
import { ViewPessoaTransportadoraModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			ProdutoGrupoModule,
			ProdutoSubgrupoModule,
			ProdutoMarcaModule,
			ProdutoUnidadeModule,
			NfeCabecalhoModule,
			NfeDetalheModule,
			TributOperacaoFiscalModule,
			VendaCabecalhoModule,
			NfeDuplicataModule,
			NfeImportacaoDetalheModule,
			NfeCanaFornecimentoDiarioModule,
			NfeCanaDeducoesSafraModule,
			NfeNumeroModule,
			NfeTransporteReboqueModule,
			NfeTransporteVolumeModule,
			NfeTransporteVolumeLacreModule,
			NfeConfiguracaoModule,
			NfeNumeroInutilizadoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaClienteModule,
			ViewPessoaFornecedorModule,
			ViewPessoaColaboradorModule,
			ViewPessoaVendedorModule,
			ViewPessoaTransportadoraModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}