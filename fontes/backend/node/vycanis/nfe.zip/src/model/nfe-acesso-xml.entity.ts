import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_acesso_xml' })
export class NfeAcessoXmlModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeAcessoXmlModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.cpf = jsonObj['cpf'];
		}
	}
}