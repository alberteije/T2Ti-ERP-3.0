import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_cupom_fiscal_referenciado' })
export class NfeCupomFiscalReferenciadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'modelo_documento_fiscal' }) 
	modeloDocumentoFiscal: string; 

	@Column({ name: 'numero_ordem_ecf' }) 
	numeroOrdemEcf: number; 

	@Column({ name: 'coo' }) 
	coo: number; 

	@Column({ name: 'data_emissao_cupom' }) 
	dataEmissaoCupom: Date; 

	@Column({ name: 'numero_caixa' }) 
	numeroCaixa: number; 

	@Column({ name: 'numero_serie_ecf' }) 
	numeroSerieEcf: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeCupomFiscalReferenciadoModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.modeloDocumentoFiscal = jsonObj['modeloDocumentoFiscal'];
			this.numeroOrdemEcf = jsonObj['numeroOrdemEcf'];
			this.coo = jsonObj['coo'];
			this.dataEmissaoCupom = jsonObj['dataEmissaoCupom'];
			this.numeroCaixa = jsonObj['numeroCaixa'];
			this.numeroSerieEcf = jsonObj['numeroSerieEcf'];
		}
	}
}