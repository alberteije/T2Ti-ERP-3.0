import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_cofins_st' })
export class NfeDetalheImpostoCofinsStModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'base_calculo_cofins_st', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoCofinsSt: number; 

	@Column({ name: 'aliquota_cofins_st_percentual', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCofinsStPercentual: number; 

	@Column({ name: 'quantidade_vendida_cofins_st', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeVendidaCofinsSt: number; 

	@Column({ name: 'aliquota_cofins_st_reais', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCofinsStReais: number; 

	@Column({ name: 'valor_cofins_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofinsSt: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoCofinsStModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.baseCalculoCofinsSt = jsonObj['baseCalculoCofinsSt'];
			this.aliquotaCofinsStPercentual = jsonObj['aliquotaCofinsStPercentual'];
			this.quantidadeVendidaCofinsSt = jsonObj['quantidadeVendidaCofinsSt'];
			this.aliquotaCofinsStReais = jsonObj['aliquotaCofinsStReais'];
			this.valorCofinsSt = jsonObj['valorCofinsSt'];
		}
	}
}