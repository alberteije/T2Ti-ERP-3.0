import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_icms' })
export class NfeDetalheImpostoIcmsModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'origem_mercadoria' }) 
	origemMercadoria: string; 

	@Column({ name: 'cst_icms' }) 
	cstIcms: string; 

	@Column({ name: 'csosn' }) 
	csosn: string; 

	@Column({ name: 'modalidade_bc_icms' }) 
	modalidadeBcIcms: string; 

	@Column({ name: 'percentual_reducao_bc_icms', type: 'decimal', precision: 18, scale: 6 }) 
	percentualReducaoBcIcms: number; 

	@Column({ name: 'valor_bc_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcms: number; 

	@Column({ name: 'aliquota_icms', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcms: number; 

	@Column({ name: 'valor_icms_operacao', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsOperacao: number; 

	@Column({ name: 'percentual_diferimento', type: 'decimal', precision: 18, scale: 6 }) 
	percentualDiferimento: number; 

	@Column({ name: 'valor_icms_diferido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsDiferido: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'base_calculo_fcp', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoFcp: number; 

	@Column({ name: 'percentual_fcp', type: 'decimal', precision: 18, scale: 6 }) 
	percentualFcp: number; 

	@Column({ name: 'valor_fcp', type: 'decimal', precision: 18, scale: 6 }) 
	valorFcp: number; 

	@Column({ name: 'modalidade_bc_icms_st' }) 
	modalidadeBcIcmsSt: string; 

	@Column({ name: 'percentual_mva_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	percentualMvaIcmsSt: number; 

	@Column({ name: 'percentual_reducao_bc_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	percentualReducaoBcIcmsSt: number; 

	@Column({ name: 'valor_base_calculo_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorBaseCalculoIcmsSt: number; 

	@Column({ name: 'aliquota_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcmsSt: number; 

	@Column({ name: 'valor_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsSt: number; 

	@Column({ name: 'base_calculo_fcp_st', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoFcpSt: number; 

	@Column({ name: 'percentual_fcp_st', type: 'decimal', precision: 18, scale: 6 }) 
	percentualFcpSt: number; 

	@Column({ name: 'valor_fcp_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorFcpSt: number; 

	@Column({ name: 'uf_st' }) 
	ufSt: string; 

	@Column({ name: 'percentual_bc_operacao_propria', type: 'decimal', precision: 18, scale: 6 }) 
	percentualBcOperacaoPropria: number; 

	@Column({ name: 'valor_bc_icms_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcmsStRetido: number; 

	@Column({ name: 'aliquota_suportada_consumidor', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaSuportadaConsumidor: number; 

	@Column({ name: 'valor_icms_substituto', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsSubstituto: number; 

	@Column({ name: 'valor_icms_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsStRetido: number; 

	@Column({ name: 'base_calculo_fcp_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoFcpStRetido: number; 

	@Column({ name: 'percentual_fcp_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	percentualFcpStRetido: number; 

	@Column({ name: 'valor_fcp_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorFcpStRetido: number; 

	@Column({ name: 'motivo_desoneracao_icms' }) 
	motivoDesoneracaoIcms: string; 

	@Column({ name: 'valor_icms_desonerado', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsDesonerado: number; 

	@Column({ name: 'aliquota_credito_icms_sn', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCreditoIcmsSn: number; 

	@Column({ name: 'valor_credito_icms_sn', type: 'decimal', precision: 18, scale: 6 }) 
	valorCreditoIcmsSn: number; 

	@Column({ name: 'valor_bc_icms_st_destino', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcmsStDestino: number; 

	@Column({ name: 'valor_icms_st_destino', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsStDestino: number; 

	@Column({ name: 'percentual_reducao_bc_efetivo', type: 'decimal', precision: 18, scale: 6 }) 
	percentualReducaoBcEfetivo: number; 

	@Column({ name: 'valor_bc_efetivo', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcEfetivo: number; 

	@Column({ name: 'aliquota_icms_efetivo', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcmsEfetivo: number; 

	@Column({ name: 'valor_icms_efetivo', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsEfetivo: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoIcmsModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.origemMercadoria = jsonObj['origemMercadoria'];
			this.cstIcms = jsonObj['cstIcms'];
			this.csosn = jsonObj['csosn'];
			this.modalidadeBcIcms = jsonObj['modalidadeBcIcms'];
			this.percentualReducaoBcIcms = jsonObj['percentualReducaoBcIcms'];
			this.valorBcIcms = jsonObj['valorBcIcms'];
			this.aliquotaIcms = jsonObj['aliquotaIcms'];
			this.valorIcmsOperacao = jsonObj['valorIcmsOperacao'];
			this.percentualDiferimento = jsonObj['percentualDiferimento'];
			this.valorIcmsDiferido = jsonObj['valorIcmsDiferido'];
			this.valorIcms = jsonObj['valorIcms'];
			this.baseCalculoFcp = jsonObj['baseCalculoFcp'];
			this.percentualFcp = jsonObj['percentualFcp'];
			this.valorFcp = jsonObj['valorFcp'];
			this.modalidadeBcIcmsSt = jsonObj['modalidadeBcIcmsSt'];
			this.percentualMvaIcmsSt = jsonObj['percentualMvaIcmsSt'];
			this.percentualReducaoBcIcmsSt = jsonObj['percentualReducaoBcIcmsSt'];
			this.valorBaseCalculoIcmsSt = jsonObj['valorBaseCalculoIcmsSt'];
			this.aliquotaIcmsSt = jsonObj['aliquotaIcmsSt'];
			this.valorIcmsSt = jsonObj['valorIcmsSt'];
			this.baseCalculoFcpSt = jsonObj['baseCalculoFcpSt'];
			this.percentualFcpSt = jsonObj['percentualFcpSt'];
			this.valorFcpSt = jsonObj['valorFcpSt'];
			this.ufSt = jsonObj['ufSt'];
			this.percentualBcOperacaoPropria = jsonObj['percentualBcOperacaoPropria'];
			this.valorBcIcmsStRetido = jsonObj['valorBcIcmsStRetido'];
			this.aliquotaSuportadaConsumidor = jsonObj['aliquotaSuportadaConsumidor'];
			this.valorIcmsSubstituto = jsonObj['valorIcmsSubstituto'];
			this.valorIcmsStRetido = jsonObj['valorIcmsStRetido'];
			this.baseCalculoFcpStRetido = jsonObj['baseCalculoFcpStRetido'];
			this.percentualFcpStRetido = jsonObj['percentualFcpStRetido'];
			this.valorFcpStRetido = jsonObj['valorFcpStRetido'];
			this.motivoDesoneracaoIcms = jsonObj['motivoDesoneracaoIcms'];
			this.valorIcmsDesonerado = jsonObj['valorIcmsDesonerado'];
			this.aliquotaCreditoIcmsSn = jsonObj['aliquotaCreditoIcmsSn'];
			this.valorCreditoIcmsSn = jsonObj['valorCreditoIcmsSn'];
			this.valorBcIcmsStDestino = jsonObj['valorBcIcmsStDestino'];
			this.valorIcmsStDestino = jsonObj['valorIcmsStDestino'];
			this.percentualReducaoBcEfetivo = jsonObj['percentualReducaoBcEfetivo'];
			this.valorBcEfetivo = jsonObj['valorBcEfetivo'];
			this.aliquotaIcmsEfetivo = jsonObj['aliquotaIcmsEfetivo'];
			this.valorIcmsEfetivo = jsonObj['valorIcmsEfetivo'];
		}
	}
}