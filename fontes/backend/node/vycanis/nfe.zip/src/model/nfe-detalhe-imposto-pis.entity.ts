import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_pis' })
export class NfeDetalheImpostoPisModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cst_pis' }) 
	cstPis: string; 

	@Column({ name: 'valor_base_calculo_pis', type: 'decimal', precision: 18, scale: 6 }) 
	valorBaseCalculoPis: number; 

	@Column({ name: 'aliquota_pis_percentual', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaPisPercentual: number; 

	@Column({ name: 'valor_pis', type: 'decimal', precision: 18, scale: 6 }) 
	valorPis: number; 

	@Column({ name: 'quantidade_vendida', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeVendida: number; 

	@Column({ name: 'aliquota_pis_reais', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaPisReais: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoPisModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cstPis = jsonObj['cstPis'];
			this.valorBaseCalculoPis = jsonObj['valorBaseCalculoPis'];
			this.aliquotaPisPercentual = jsonObj['aliquotaPisPercentual'];
			this.valorPis = jsonObj['valorPis'];
			this.quantidadeVendida = jsonObj['quantidadeVendida'];
			this.aliquotaPisReais = jsonObj['aliquotaPisReais'];
		}
	}
}