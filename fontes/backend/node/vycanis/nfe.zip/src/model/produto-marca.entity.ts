import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'produto_marca' })
export class ProdutoMarcaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ProdutoModel, produtoModel => produtoModel.produtoMarcaModel, { cascade: true })
	produtoModelList: ProdutoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.produtoModelList = [];
			let produtoModelJsonList = jsonObj['produtoModelList'];
			if (produtoModelJsonList != null) {
				for (let i = 0; i < produtoModelJsonList.length; i++) {
					let obj = new ProdutoModel(produtoModelJsonList[i]);
					this.produtoModelList.push(obj);
				}
			}

		}
	}
}