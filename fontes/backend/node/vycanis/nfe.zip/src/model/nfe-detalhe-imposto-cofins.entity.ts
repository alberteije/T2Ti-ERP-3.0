import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_cofins' })
export class NfeDetalheImpostoCofinsModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cst_cofins' }) 
	cstCofins: string; 

	@Column({ name: 'base_calculo_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoCofins: number; 

	@Column({ name: 'aliquota_cofins_percentual', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCofinsPercentual: number; 

	@Column({ name: 'quantidade_vendida', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeVendida: number; 

	@Column({ name: 'aliquota_cofins_reais', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaCofinsReais: number; 

	@Column({ name: 'valor_cofins', type: 'decimal', precision: 18, scale: 6 }) 
	valorCofins: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoCofinsModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cstCofins = jsonObj['cstCofins'];
			this.baseCalculoCofins = jsonObj['baseCalculoCofins'];
			this.aliquotaCofinsPercentual = jsonObj['aliquotaCofinsPercentual'];
			this.quantidadeVendida = jsonObj['quantidadeVendida'];
			this.aliquotaCofinsReais = jsonObj['aliquotaCofinsReais'];
			this.valorCofins = jsonObj['valorCofins'];
		}
	}
}