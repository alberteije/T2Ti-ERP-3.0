import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_nf_referenciada' })
export class NfeNfReferenciadaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_uf' }) 
	codigoUf: number; 

	@Column({ name: 'ano_mes' }) 
	anoMes: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'modelo' }) 
	modelo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero_nf' }) 
	numeroNf: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeNfReferenciadaModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoUf = jsonObj['codigoUf'];
			this.anoMes = jsonObj['anoMes'];
			this.cnpj = jsonObj['cnpj'];
			this.modelo = jsonObj['modelo'];
			this.serie = jsonObj['serie'];
			this.numeroNf = jsonObj['numeroNf'];
		}
	}
}