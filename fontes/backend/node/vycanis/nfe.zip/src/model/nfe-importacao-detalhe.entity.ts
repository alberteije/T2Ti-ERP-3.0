import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDeclaracaoImportacaoModel } from '../entities-export';

@Entity({ name: 'nfe_importacao_detalhe' })
export class NfeImportacaoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_adicao' }) 
	numeroAdicao: number; 

	@Column({ name: 'numero_sequencial' }) 
	numeroSequencial: number; 

	@Column({ name: 'codigo_fabricante_estrangeiro' }) 
	codigoFabricanteEstrangeiro: string; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'drawback' }) 
	drawback: number; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeDeclaracaoImportacaoModel)
	@JoinColumn({ name: 'id_nfe_declaracao_importacao' })
	nfeDeclaracaoImportacaoModel: NfeDeclaracaoImportacaoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroAdicao = jsonObj['numeroAdicao'];
			this.numeroSequencial = jsonObj['numeroSequencial'];
			this.codigoFabricanteEstrangeiro = jsonObj['codigoFabricanteEstrangeiro'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.drawback = jsonObj['drawback'];
			if (jsonObj['nfeDeclaracaoImportacaoModel'] != null) {
				this.nfeDeclaracaoImportacaoModel = new NfeDeclaracaoImportacaoModel(jsonObj['nfeDeclaracaoImportacaoModel']);
			}

		}
	}
}