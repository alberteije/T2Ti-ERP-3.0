import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_det_especifico_combustivel' })
export class NfeDetEspecificoCombustivelModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_anp' }) 
	codigoAnp: number; 

	@Column({ name: 'descricao_anp' }) 
	descricaoAnp: string; 

	@Column({ name: 'percentual_glp', type: 'decimal', precision: 18, scale: 6 }) 
	percentualGlp: number; 

	@Column({ name: 'percentual_gas_nacional', type: 'decimal', precision: 18, scale: 6 }) 
	percentualGasNacional: number; 

	@Column({ name: 'percentual_gas_importado', type: 'decimal', precision: 18, scale: 6 }) 
	percentualGasImportado: number; 

	@Column({ name: 'valor_partida', type: 'decimal', precision: 18, scale: 6 }) 
	valorPartida: number; 

	@Column({ name: 'codif' }) 
	codif: string; 

	@Column({ name: 'quantidade_temp_ambiente', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeTempAmbiente: number; 

	@Column({ name: 'uf_consumo' }) 
	ufConsumo: string; 

	@Column({ name: 'cide_base_calculo', type: 'decimal', precision: 18, scale: 6 }) 
	cideBaseCalculo: number; 

	@Column({ name: 'cide_aliquota', type: 'decimal', precision: 18, scale: 6 }) 
	cideAliquota: number; 

	@Column({ name: 'cide_valor', type: 'decimal', precision: 18, scale: 6 }) 
	cideValor: number; 

	@Column({ name: 'encerrante_bico' }) 
	encerranteBico: number; 

	@Column({ name: 'encerrante_bomba' }) 
	encerranteBomba: number; 

	@Column({ name: 'encerrante_tanque' }) 
	encerranteTanque: number; 

	@Column({ name: 'encerrante_valor_inicio', type: 'decimal', precision: 18, scale: 6 }) 
	encerranteValorInicio: number; 

	@Column({ name: 'encerrante_valor_fim', type: 'decimal', precision: 18, scale: 6 }) 
	encerranteValorFim: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetEspecificoCombustivelModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoAnp = jsonObj['codigoAnp'];
			this.descricaoAnp = jsonObj['descricaoAnp'];
			this.percentualGlp = jsonObj['percentualGlp'];
			this.percentualGasNacional = jsonObj['percentualGasNacional'];
			this.percentualGasImportado = jsonObj['percentualGasImportado'];
			this.valorPartida = jsonObj['valorPartida'];
			this.codif = jsonObj['codif'];
			this.quantidadeTempAmbiente = jsonObj['quantidadeTempAmbiente'];
			this.ufConsumo = jsonObj['ufConsumo'];
			this.cideBaseCalculo = jsonObj['cideBaseCalculo'];
			this.cideAliquota = jsonObj['cideAliquota'];
			this.cideValor = jsonObj['cideValor'];
			this.encerranteBico = jsonObj['encerranteBico'];
			this.encerranteBomba = jsonObj['encerranteBomba'];
			this.encerranteTanque = jsonObj['encerranteTanque'];
			this.encerranteValorInicio = jsonObj['encerranteValorInicio'];
			this.encerranteValorFim = jsonObj['encerranteValorFim'];
		}
	}
}