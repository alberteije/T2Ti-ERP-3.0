import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'nfe_configuracao' })
export class NfeConfiguracaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'certificado_digital_serie' }) 
	certificadoDigitalSerie: string; 

	@Column({ name: 'certificado_digital_caminho' }) 
	certificadoDigitalCaminho: string; 

	@Column({ name: 'certificado_digital_senha' }) 
	certificadoDigitalSenha: string; 

	@Column({ name: 'tipo_emissao' }) 
	tipoEmissao: number; 

	@Column({ name: 'formato_impressao_danfe' }) 
	formatoImpressaoDanfe: number; 

	@Column({ name: 'processo_emissao' }) 
	processoEmissao: number; 

	@Column({ name: 'versao_processo_emissao' }) 
	versaoProcessoEmissao: string; 

	@Column({ name: 'caminho_logomarca' }) 
	caminhoLogomarca: string; 

	@Column({ name: 'salvar_xml' }) 
	salvarXml: string; 

	@Column({ name: 'caminho_salvar_xml' }) 
	caminhoSalvarXml: string; 

	@Column({ name: 'caminho_schemas' }) 
	caminhoSchemas: string; 

	@Column({ name: 'caminho_arquivo_danfe' }) 
	caminhoArquivoDanfe: string; 

	@Column({ name: 'caminho_salvar_pdf' }) 
	caminhoSalvarPdf: string; 

	@Column({ name: 'webservice_uf' }) 
	webserviceUf: string; 

	@Column({ name: 'webservice_ambiente' }) 
	webserviceAmbiente: number; 

	@Column({ name: 'webservice_proxy_host' }) 
	webserviceProxyHost: string; 

	@Column({ name: 'webservice_proxy_porta' }) 
	webserviceProxyPorta: number; 

	@Column({ name: 'webservice_proxy_usuario' }) 
	webserviceProxyUsuario: string; 

	@Column({ name: 'webservice_proxy_senha' }) 
	webserviceProxySenha: string; 

	@Column({ name: 'webservice_visualizar' }) 
	webserviceVisualizar: string; 

	@Column({ name: 'email_servidor_smtp' }) 
	emailServidorSmtp: string; 

	@Column({ name: 'email_porta' }) 
	emailPorta: number; 

	@Column({ name: 'email_usuario' }) 
	emailUsuario: string; 

	@Column({ name: 'email_senha' }) 
	emailSenha: string; 

	@Column({ name: 'email_assunto' }) 
	emailAssunto: string; 

	@Column({ name: 'email_autentica_ssl' }) 
	emailAutenticaSsl: string; 

	@Column({ name: 'email_texto' }) 
	emailTexto: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.certificadoDigitalSerie = jsonObj['certificadoDigitalSerie'];
			this.certificadoDigitalCaminho = jsonObj['certificadoDigitalCaminho'];
			this.certificadoDigitalSenha = jsonObj['certificadoDigitalSenha'];
			this.tipoEmissao = jsonObj['tipoEmissao'];
			this.formatoImpressaoDanfe = jsonObj['formatoImpressaoDanfe'];
			this.processoEmissao = jsonObj['processoEmissao'];
			this.versaoProcessoEmissao = jsonObj['versaoProcessoEmissao'];
			this.caminhoLogomarca = jsonObj['caminhoLogomarca'];
			this.salvarXml = jsonObj['salvarXml'];
			this.caminhoSalvarXml = jsonObj['caminhoSalvarXml'];
			this.caminhoSchemas = jsonObj['caminhoSchemas'];
			this.caminhoArquivoDanfe = jsonObj['caminhoArquivoDanfe'];
			this.caminhoSalvarPdf = jsonObj['caminhoSalvarPdf'];
			this.webserviceUf = jsonObj['webserviceUf'];
			this.webserviceAmbiente = jsonObj['webserviceAmbiente'];
			this.webserviceProxyHost = jsonObj['webserviceProxyHost'];
			this.webserviceProxyPorta = jsonObj['webserviceProxyPorta'];
			this.webserviceProxyUsuario = jsonObj['webserviceProxyUsuario'];
			this.webserviceProxySenha = jsonObj['webserviceProxySenha'];
			this.webserviceVisualizar = jsonObj['webserviceVisualizar'];
			this.emailServidorSmtp = jsonObj['emailServidorSmtp'];
			this.emailPorta = jsonObj['emailPorta'];
			this.emailUsuario = jsonObj['emailUsuario'];
			this.emailSenha = jsonObj['emailSenha'];
			this.emailAssunto = jsonObj['emailAssunto'];
			this.emailAutenticaSsl = jsonObj['emailAutenticaSsl'];
			this.emailTexto = jsonObj['emailTexto'];
		}
	}
}