import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_ipi' })
export class NfeDetalheImpostoIpiModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj_produtor' }) 
	cnpjProdutor: string; 

	@Column({ name: 'codigo_selo_ipi' }) 
	codigoSeloIpi: string; 

	@Column({ name: 'quantidade_selo_ipi' }) 
	quantidadeSeloIpi: number; 

	@Column({ name: 'enquadramento_legal_ipi' }) 
	enquadramentoLegalIpi: string; 

	@Column({ name: 'cst_ipi' }) 
	cstIpi: string; 

	@Column({ name: 'valor_base_calculo_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	valorBaseCalculoIpi: number; 

	@Column({ name: 'quantidade_unidade_tributavel', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeUnidadeTributavel: number; 

	@Column({ name: 'valor_unidade_tributavel', type: 'decimal', precision: 18, scale: 6 }) 
	valorUnidadeTributavel: number; 

	@Column({ name: 'aliquota_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIpi: number; 

	@Column({ name: 'valor_ipi', type: 'decimal', precision: 18, scale: 6 }) 
	valorIpi: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoIpiModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpjProdutor = jsonObj['cnpjProdutor'];
			this.codigoSeloIpi = jsonObj['codigoSeloIpi'];
			this.quantidadeSeloIpi = jsonObj['quantidadeSeloIpi'];
			this.enquadramentoLegalIpi = jsonObj['enquadramentoLegalIpi'];
			this.cstIpi = jsonObj['cstIpi'];
			this.valorBaseCalculoIpi = jsonObj['valorBaseCalculoIpi'];
			this.quantidadeUnidadeTributavel = jsonObj['quantidadeUnidadeTributavel'];
			this.valorUnidadeTributavel = jsonObj['valorUnidadeTributavel'];
			this.aliquotaIpi = jsonObj['aliquotaIpi'];
			this.valorIpi = jsonObj['valorIpi'];
		}
	}
}