import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_det_especifico_armamento' })
export class NfeDetEspecificoArmamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo_arma' }) 
	tipoArma: string; 

	@Column({ name: 'numero_serie_arma' }) 
	numeroSerieArma: string; 

	@Column({ name: 'numero_serie_cano' }) 
	numeroSerieCano: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetEspecificoArmamentoModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipoArma = jsonObj['tipoArma'];
			this.numeroSerieArma = jsonObj['numeroSerieArma'];
			this.numeroSerieCano = jsonObj['numeroSerieCano'];
			this.descricao = jsonObj['descricao'];
		}
	}
}