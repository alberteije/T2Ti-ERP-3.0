import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeTransporteVolumeModel } from '../entities-export';

@Entity({ name: 'nfe_transporte_volume_lacre' })
export class NfeTransporteVolumeLacreModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeTransporteVolumeModel)
	@JoinColumn({ name: 'id_nfe_transporte_volume' })
	nfeTransporteVolumeModel: NfeTransporteVolumeModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			if (jsonObj['nfeTransporteVolumeModel'] != null) {
				this.nfeTransporteVolumeModel = new NfeTransporteVolumeModel(jsonObj['nfeTransporteVolumeModel']);
			}

		}
	}
}