import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_detalhe_imposto_ii' })
export class NfeDetalheImpostoIiModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_bc_ii', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIi: number; 

	@Column({ name: 'valor_despesas_aduaneiras', type: 'decimal', precision: 18, scale: 6 }) 
	valorDespesasAduaneiras: number; 

	@Column({ name: 'valor_imposto_importacao', type: 'decimal', precision: 18, scale: 6 }) 
	valorImpostoImportacao: number; 

	@Column({ name: 'valor_iof', type: 'decimal', precision: 18, scale: 6 }) 
	valorIof: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetalheImpostoIiModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorBcIi = jsonObj['valorBcIi'];
			this.valorDespesasAduaneiras = jsonObj['valorDespesasAduaneiras'];
			this.valorImpostoImportacao = jsonObj['valorImpostoImportacao'];
			this.valorIof = jsonObj['valorIof'];
		}
	}
}