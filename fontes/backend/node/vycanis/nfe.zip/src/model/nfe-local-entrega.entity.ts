import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_local_entrega' })
export class NfeLocalEntregaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'nome_recebedor' }) 
	nomeRecebedor: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: number; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'cep' }) 
	cep: string; 

	@Column({ name: 'codigo_pais' }) 
	codigoPais: number; 

	@Column({ name: 'nome_pais' }) 
	nomePais: string; 

	@Column({ name: 'telefone' }) 
	telefone: string; 

	@Column({ name: 'email' }) 
	email: string; 

	@Column({ name: 'inscricao_estadual' }) 
	inscricaoEstadual: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeLocalEntregaModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.cpf = jsonObj['cpf'];
			this.nomeRecebedor = jsonObj['nomeRecebedor'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
			this.uf = jsonObj['uf'];
			this.cep = jsonObj['cep'];
			this.codigoPais = jsonObj['codigoPais'];
			this.nomePais = jsonObj['nomePais'];
			this.telefone = jsonObj['telefone'];
			this.email = jsonObj['email'];
			this.inscricaoEstadual = jsonObj['inscricaoEstadual'];
		}
	}
}