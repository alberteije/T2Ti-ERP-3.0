import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'tribut_operacao_fiscal' })
export class TributOperacaoFiscalModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'descricao_na_nf' }) 
	descricaoNaNf: string; 

	@Column({ name: 'cfop' }) 
	cfop: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.descricaoNaNf = jsonObj['descricaoNaNf'];
			this.cfop = jsonObj['cfop'];
			this.observacao = jsonObj['observacao'];
		}
	}
}