import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'nfe_cana' })
export class NfeCanaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'safra' }) 
	safra: string; 

	@Column({ name: 'mes_ano_referencia' }) 
	mesAnoReferencia: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeCabecalhoModel, nfeCabecalhoModel => nfeCabecalhoModel.nfeCanaModelList)
	@JoinColumn({ name: 'id_nfe_cabecalho' })
	nfeCabecalhoModel: NfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.safra = jsonObj['safra'];
			this.mesAnoReferencia = jsonObj['mesAnoReferencia'];
		}
	}
}