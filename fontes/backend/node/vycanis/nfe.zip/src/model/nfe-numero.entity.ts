import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'nfe_numero' })
export class NfeNumeroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
		}
	}
}