import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Entity({ name: 'nfe_det_especifico_medicamento' })
export class NfeDetEspecificoMedicamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_anvisa' }) 
	codigoAnvisa: string; 

	@Column({ name: 'motivo_isencao' }) 
	motivoIsencao: string; 

	@Column({ name: 'preco_maximo_consumidor', type: 'decimal', precision: 18, scale: 6 }) 
	precoMaximoConsumidor: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => NfeDetalheModel, nfeDetalheModel => nfeDetalheModel.nfeDetEspecificoMedicamentoModelList)
	@JoinColumn({ name: 'id_nfe_detalhe' })
	nfeDetalheModel: NfeDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoAnvisa = jsonObj['codigoAnvisa'];
			this.motivoIsencao = jsonObj['motivoIsencao'];
			this.precoMaximoConsumidor = jsonObj['precoMaximoConsumidor'];
		}
	}
}