import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NfeTransporteModel } from '../entities-export';

@Entity({ name: 'nfe_transporte_reboque' })
export class NfeTransporteReboqueModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'placa' }) 
	placa: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'rntc' }) 
	rntc: string; 

	@Column({ name: 'vagao' }) 
	vagao: string; 

	@Column({ name: 'balsa' }) 
	balsa: string; 


	/**
	* Relations
	*/
	@OneToOne(() => NfeTransporteModel)
	@JoinColumn({ name: 'id_nfe_transporte' })
	nfeTransporteModel: NfeTransporteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.placa = jsonObj['placa'];
			this.uf = jsonObj['uf'];
			this.rntc = jsonObj['rntc'];
			this.vagao = jsonObj['vagao'];
			this.balsa = jsonObj['balsa'];
			if (jsonObj['nfeTransporteModel'] != null) {
				this.nfeTransporteModel = new NfeTransporteModel(jsonObj['nfeTransporteModel']);
			}

		}
	}
}