import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'nfe_numero_inutilizado' })
export class NfeNumeroInutilizadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'data_inutilizacao' }) 
	dataInutilizacao: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
			this.dataInutilizacao = jsonObj['dataInutilizacao'];
			this.observacao = jsonObj['observacao'];
		}
	}
}