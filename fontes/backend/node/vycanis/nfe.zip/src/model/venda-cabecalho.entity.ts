import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'venda_cabecalho' })
export class VendaCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_venda_orcamento_cabecalho' }) 
	idVendaOrcamentoCabecalho: number; 

	@Column({ name: 'id_venda_condicoes_pagamento' }) 
	idVendaCondicoesPagamento: number; 

	@Column({ name: 'id_nota_fiscal_tipo' }) 
	idNotaFiscalTipo: number; 

	@Column({ name: 'id_transportadora' }) 
	idTransportadora: number; 

	@Column({ name: 'data_venda' }) 
	dataVenda: Date; 

	@Column({ name: 'data_saida' }) 
	dataSaida: Date; 

	@Column({ name: 'hora_saida' }) 
	horaSaida: string; 

	@Column({ name: 'numero_fatura' }) 
	numeroFatura: number; 

	@Column({ name: 'local_entrega' }) 
	localEntrega: string; 

	@Column({ name: 'local_cobranca' }) 
	localCobranca: string; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'taxa_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaComissao: number; 

	@Column({ name: 'valor_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	valorComissao: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'tipo_frete' }) 
	tipoFrete: string; 

	@Column({ name: 'forma_pagamento' }) 
	formaPagamento: string; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 

	@Column({ name: 'valor_seguro', type: 'decimal', precision: 18, scale: 6 }) 
	valorSeguro: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 

	@Column({ name: 'situacao' }) 
	situacao: string; 

	@Column({ name: 'dia_fixo_parcela' }) 
	diaFixoParcela: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idVendaOrcamentoCabecalho = jsonObj['idVendaOrcamentoCabecalho'];
			this.idVendaCondicoesPagamento = jsonObj['idVendaCondicoesPagamento'];
			this.idNotaFiscalTipo = jsonObj['idNotaFiscalTipo'];
			this.idTransportadora = jsonObj['idTransportadora'];
			this.dataVenda = jsonObj['dataVenda'];
			this.dataSaida = jsonObj['dataSaida'];
			this.horaSaida = jsonObj['horaSaida'];
			this.numeroFatura = jsonObj['numeroFatura'];
			this.localEntrega = jsonObj['localEntrega'];
			this.localCobranca = jsonObj['localCobranca'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.taxaComissao = jsonObj['taxaComissao'];
			this.valorComissao = jsonObj['valorComissao'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorTotal = jsonObj['valorTotal'];
			this.tipoFrete = jsonObj['tipoFrete'];
			this.formaPagamento = jsonObj['formaPagamento'];
			this.valorFrete = jsonObj['valorFrete'];
			this.valorSeguro = jsonObj['valorSeguro'];
			this.observacao = jsonObj['observacao'];
			this.situacao = jsonObj['situacao'];
			this.diaFixoParcela = jsonObj['diaFixoParcela'];
		}
	}
}