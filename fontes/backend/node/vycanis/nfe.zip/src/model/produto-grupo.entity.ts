import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoSubgrupoModel } from '../entities-export';

@Entity({ name: 'produto_grupo' })
export class ProdutoGrupoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ProdutoSubgrupoModel, produtoSubgrupoModel => produtoSubgrupoModel.produtoGrupoModel, { cascade: true })
	produtoSubgrupoModelList: ProdutoSubgrupoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.produtoSubgrupoModelList = [];
			let produtoSubgrupoModelJsonList = jsonObj['produtoSubgrupoModelList'];
			if (produtoSubgrupoModelJsonList != null) {
				for (let i = 0; i < produtoSubgrupoModelJsonList.length; i++) {
					let obj = new ProdutoSubgrupoModel(produtoSubgrupoModelJsonList[i]);
					this.produtoSubgrupoModelList.push(obj);
				}
			}

		}
	}
}