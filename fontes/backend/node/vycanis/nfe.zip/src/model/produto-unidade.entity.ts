import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'produto_unidade' })
export class ProdutoUnidadeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'sigla' }) 
	sigla: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'pode_fracionar' }) 
	podeFracionar: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ProdutoModel, produtoModel => produtoModel.produtoUnidadeModel, { cascade: true })
	produtoModelList: ProdutoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.sigla = jsonObj['sigla'];
			this.descricao = jsonObj['descricao'];
			this.podeFracionar = jsonObj['podeFracionar'];
			this.produtoModelList = [];
			let produtoModelJsonList = jsonObj['produtoModelList'];
			if (produtoModelJsonList != null) {
				for (let i = 0; i < produtoModelJsonList.length; i++) {
					let obj = new ProdutoModel(produtoModelJsonList[i]);
					this.produtoModelList.push(obj);
				}
			}

		}
	}
}