import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NfeNumeroInutilizadoModel } from '../entities-export';

@Injectable()
export class NfeNumeroInutilizadoService extends TypeOrmCrudService<NfeNumeroInutilizadoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NfeNumeroInutilizadoModel)
    private readonly repository: Repository<NfeNumeroInutilizadoModel>
  ) {
    super(repository);
  }

	async save(nfeNumeroInutilizadoModel: NfeNumeroInutilizadoModel): Promise<NfeNumeroInutilizadoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(nfeNumeroInutilizadoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
