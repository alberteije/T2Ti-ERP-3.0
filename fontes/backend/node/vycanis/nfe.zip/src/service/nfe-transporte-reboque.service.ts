import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NfeTransporteReboqueModel } from '../entities-export';

@Injectable()
export class NfeTransporteReboqueService extends TypeOrmCrudService<NfeTransporteReboqueModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NfeTransporteReboqueModel)
    private readonly repository: Repository<NfeTransporteReboqueModel>
  ) {
    super(repository);
  }

	async save(nfeTransporteReboqueModel: NfeTransporteReboqueModel): Promise<NfeTransporteReboqueModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(nfeTransporteReboqueModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
