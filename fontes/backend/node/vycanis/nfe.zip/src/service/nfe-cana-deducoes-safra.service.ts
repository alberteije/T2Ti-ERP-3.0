import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NfeCanaDeducoesSafraModel } from '../entities-export';

@Injectable()
export class NfeCanaDeducoesSafraService extends TypeOrmCrudService<NfeCanaDeducoesSafraModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NfeCanaDeducoesSafraModel)
    private readonly repository: Repository<NfeCanaDeducoesSafraModel>
  ) {
    super(repository);
  }

	async save(nfeCanaDeducoesSafraModel: NfeCanaDeducoesSafraModel): Promise<NfeCanaDeducoesSafraModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(nfeCanaDeducoesSafraModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
