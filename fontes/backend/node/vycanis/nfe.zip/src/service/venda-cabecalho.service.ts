import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { VendaCabecalhoModel } from '../entities-export';

@Injectable()
export class VendaCabecalhoService extends TypeOrmCrudService<VendaCabecalhoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(VendaCabecalhoModel)
    private readonly repository: Repository<VendaCabecalhoModel>
  ) {
    super(repository);
  }

	async save(vendaCabecalhoModel: VendaCabecalhoModel): Promise<VendaCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(vendaCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
