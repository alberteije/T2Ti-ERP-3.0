import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { NfeDetalheModel } from '../entities-export';

@Injectable()
export class NfeDetalheService extends TypeOrmCrudService<NfeDetalheModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(NfeDetalheModel) 
    private readonly repository: Repository<NfeDetalheModel>,
  ) {
    super(repository);
  }

	async save(nfeDetalheModel: NfeDetalheModel, operation: string): Promise<NfeDetalheModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, nfeDetalheModel.id);
      }

      const resultObj = await queryRunner.manager.save(nfeDetalheModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(NfeDetalheModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from nfe_det_especifico_veiculo where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_det_especifico_medicamento where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_det_especifico_armamento where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_det_especifico_combustivel where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_declaracao_importacao where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_icms where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_ipi where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_ii where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_pis where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_cofins where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_issqn where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_exportacao where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_item_rastreado where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_pis_st where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_icms_ufdest where id_nfe_detalhe=' + id); 

		await queryRunner.query('delete from nfe_detalhe_imposto_cofins_st where id_nfe_detalhe=' + id); 

	}
	
}