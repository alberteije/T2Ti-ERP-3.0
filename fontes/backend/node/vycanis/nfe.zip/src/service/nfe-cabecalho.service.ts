import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { NfeCabecalhoModel } from '../entities-export';

@Injectable()
export class NfeCabecalhoService extends TypeOrmCrudService<NfeCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(NfeCabecalhoModel) 
    private readonly repository: Repository<NfeCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(nfeCabecalhoModel: NfeCabecalhoModel, operation: string): Promise<NfeCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, nfeCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(nfeCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(NfeCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from nfe_referenciada where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_emitente where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_destinatario where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_local_retirada where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_local_entrega where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_transporte where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_fatura where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_cana where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_prod_rural_referenciada where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_nf_referenciada where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_processo_referenciado where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_acesso_xml where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_informacao_pagamento where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_responsavel_tecnico where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_cte_referenciado where id_nfe_cabecalho=' + id); 

		await queryRunner.query('delete from nfe_cupom_fiscal_referenciado where id_nfe_cabecalho=' + id); 

	}
	
}