import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { VendaCabecalhoService } from '../service/venda-cabecalho.service';
import { VendaCabecalhoModel } from '../model/venda-cabecalho.entity';

@Crud({
  model: {
    type: VendaCabecalhoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('venda-cabecalho')
export class VendaCabecalhoController implements CrudController<VendaCabecalhoModel> {
  constructor(public service: VendaCabecalhoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const vendaCabecalhoModel = new VendaCabecalhoModel(jsonObj);
		const result = await this.service.save(vendaCabecalhoModel);
		return result;
	}  


}


















