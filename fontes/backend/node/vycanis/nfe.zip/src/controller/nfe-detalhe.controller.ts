import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { NfeDetalheService } from '../service/nfe-detalhe.service';
import { NfeDetalheModel } from '../model/nfe-detalhe.entity';

@Crud({
  model: {
    type: NfeDetalheModel,
  },
  query: {
    join: {
			nfeDetEspecificoVeiculoModelList: { eager: true },
			nfeDetEspecificoMedicamentoModelList: { eager: true },
			nfeDetEspecificoArmamentoModelList: { eager: true },
			nfeDetEspecificoCombustivelModelList: { eager: true },
			nfeDeclaracaoImportacaoModelList: { eager: true },
			nfeDetalheImpostoIcmsModelList: { eager: true },
			nfeDetalheImpostoIpiModelList: { eager: true },
			nfeDetalheImpostoIiModelList: { eager: true },
			nfeDetalheImpostoPisModelList: { eager: true },
			nfeDetalheImpostoCofinsModelList: { eager: true },
			nfeDetalheImpostoIssqnModelList: { eager: true },
			nfeExportacaoModelList: { eager: true },
			nfeItemRastreadoModelList: { eager: true },
			nfeDetalheImpostoPisStModelList: { eager: true },
			nfeDetalheImpostoIcmsUfdestModelList: { eager: true },
			nfeDetalheImpostoCofinsStModelList: { eager: true },
			nfeCabecalhoModel: { eager: true },
			produtoModel: { eager: true },
    },
  },
})
@Controller('nfe-detalhe')
export class NfeDetalheController implements CrudController<NfeDetalheModel> {
  constructor(public service: NfeDetalheService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeDetalhe = new NfeDetalheModel(jsonObj);
		const result = await this.service.save(nfeDetalhe, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeDetalhe = new NfeDetalheModel(jsonObj);
		const result = await this.service.save(nfeDetalhe, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}