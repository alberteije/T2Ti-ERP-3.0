import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeTransporteVolumeLacreService } from '../service/nfe-transporte-volume-lacre.service';
import { NfeTransporteVolumeLacreModel } from '../model/nfe-transporte-volume-lacre.entity';

@Crud({
  model: {
    type: NfeTransporteVolumeLacreModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-transporte-volume-lacre')
export class NfeTransporteVolumeLacreController implements CrudController<NfeTransporteVolumeLacreModel> {
  constructor(public service: NfeTransporteVolumeLacreService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeTransporteVolumeLacreModel = new NfeTransporteVolumeLacreModel(jsonObj);
		const result = await this.service.save(nfeTransporteVolumeLacreModel);
		return result;
	}  


}


















