import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeTransporteReboqueService } from '../service/nfe-transporte-reboque.service';
import { NfeTransporteReboqueModel } from '../model/nfe-transporte-reboque.entity';

@Crud({
  model: {
    type: NfeTransporteReboqueModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-transporte-reboque')
export class NfeTransporteReboqueController implements CrudController<NfeTransporteReboqueModel> {
  constructor(public service: NfeTransporteReboqueService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeTransporteReboqueModel = new NfeTransporteReboqueModel(jsonObj);
		const result = await this.service.save(nfeTransporteReboqueModel);
		return result;
	}  


}


















