import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NfeImportacaoDetalheService } from '../service/nfe-importacao-detalhe.service';
import { NfeImportacaoDetalheModel } from '../model/nfe-importacao-detalhe.entity';

@Crud({
  model: {
    type: NfeImportacaoDetalheModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nfe-importacao-detalhe')
export class NfeImportacaoDetalheController implements CrudController<NfeImportacaoDetalheModel> {
  constructor(public service: NfeImportacaoDetalheService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const nfeImportacaoDetalheModel = new NfeImportacaoDetalheModel(jsonObj);
		const result = await this.service.save(nfeImportacaoDetalheModel);
		return result;
	}  


}


















