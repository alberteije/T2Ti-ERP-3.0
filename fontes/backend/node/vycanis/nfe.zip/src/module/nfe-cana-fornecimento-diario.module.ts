import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeCanaFornecimentoDiarioController } from '../controller/nfe-cana-fornecimento-diario.controller';
import { NfeCanaFornecimentoDiarioService } from '../service/nfe-cana-fornecimento-diario.service';
import { NfeCanaFornecimentoDiarioModel } from '../model/nfe-cana-fornecimento-diario.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeCanaFornecimentoDiarioModel])],
    controllers: [NfeCanaFornecimentoDiarioController],
    providers: [NfeCanaFornecimentoDiarioService],
})
export class NfeCanaFornecimentoDiarioModule { }
