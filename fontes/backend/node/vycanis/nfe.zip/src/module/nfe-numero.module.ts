import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeNumeroController } from '../controller/nfe-numero.controller';
import { NfeNumeroService } from '../service/nfe-numero.service';
import { NfeNumeroModel } from '../model/nfe-numero.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeNumeroModel])],
    controllers: [NfeNumeroController],
    providers: [NfeNumeroService],
})
export class NfeNumeroModule { }
