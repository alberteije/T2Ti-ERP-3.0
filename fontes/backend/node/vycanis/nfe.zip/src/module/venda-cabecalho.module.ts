import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VendaCabecalhoController } from '../controller/venda-cabecalho.controller';
import { VendaCabecalhoService } from '../service/venda-cabecalho.service';
import { VendaCabecalhoModel } from '../model/venda-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([VendaCabecalhoModel])],
    controllers: [VendaCabecalhoController],
    providers: [VendaCabecalhoService],
})
export class VendaCabecalhoModule { }
