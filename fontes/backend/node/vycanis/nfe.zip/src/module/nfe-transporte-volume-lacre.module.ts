import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeTransporteVolumeLacreController } from '../controller/nfe-transporte-volume-lacre.controller';
import { NfeTransporteVolumeLacreService } from '../service/nfe-transporte-volume-lacre.service';
import { NfeTransporteVolumeLacreModel } from '../model/nfe-transporte-volume-lacre.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeTransporteVolumeLacreModel])],
    controllers: [NfeTransporteVolumeLacreController],
    providers: [NfeTransporteVolumeLacreService],
})
export class NfeTransporteVolumeLacreModule { }
