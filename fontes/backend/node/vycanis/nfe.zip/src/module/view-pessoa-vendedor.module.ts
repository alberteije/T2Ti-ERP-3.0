import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaVendedorController } from '../controller/view-pessoa-vendedor.controller';
import { ViewPessoaVendedorService } from '../service/view-pessoa-vendedor.service';
import { ViewPessoaVendedorModel } from '../model/view-pessoa-vendedor.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaVendedorModel])],
    controllers: [ViewPessoaVendedorController],
    providers: [ViewPessoaVendedorService],
})
export class ViewPessoaVendedorModule { }
