import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeImportacaoDetalheController } from '../controller/nfe-importacao-detalhe.controller';
import { NfeImportacaoDetalheService } from '../service/nfe-importacao-detalhe.service';
import { NfeImportacaoDetalheModel } from '../model/nfe-importacao-detalhe.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeImportacaoDetalheModel])],
    controllers: [NfeImportacaoDetalheController],
    providers: [NfeImportacaoDetalheService],
})
export class NfeImportacaoDetalheModule { }
