import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeNumeroInutilizadoController } from '../controller/nfe-numero-inutilizado.controller';
import { NfeNumeroInutilizadoService } from '../service/nfe-numero-inutilizado.service';
import { NfeNumeroInutilizadoModel } from '../model/nfe-numero-inutilizado.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeNumeroInutilizadoModel])],
    controllers: [NfeNumeroInutilizadoController],
    providers: [NfeNumeroInutilizadoService],
})
export class NfeNumeroInutilizadoModule { }
