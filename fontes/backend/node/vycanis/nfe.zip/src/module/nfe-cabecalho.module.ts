import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeCabecalhoController } from '../controller/nfe-cabecalho.controller';
import { NfeCabecalhoService } from '../service/nfe-cabecalho.service';
import { NfeCabecalhoModel } from '../model/nfe-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeCabecalhoModel])],
    controllers: [NfeCabecalhoController],
    providers: [NfeCabecalhoService],
})
export class NfeCabecalhoModule { }
