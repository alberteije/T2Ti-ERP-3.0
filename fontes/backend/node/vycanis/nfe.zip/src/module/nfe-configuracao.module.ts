import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeConfiguracaoController } from '../controller/nfe-configuracao.controller';
import { NfeConfiguracaoService } from '../service/nfe-configuracao.service';
import { NfeConfiguracaoModel } from '../model/nfe-configuracao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeConfiguracaoModel])],
    controllers: [NfeConfiguracaoController],
    providers: [NfeConfiguracaoService],
})
export class NfeConfiguracaoModule { }
