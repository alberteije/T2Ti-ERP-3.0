import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProdutoUnidadeController } from '../controller/produto-unidade.controller';
import { ProdutoUnidadeService } from '../service/produto-unidade.service';
import { ProdutoUnidadeModel } from '../model/produto-unidade.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ProdutoUnidadeModel])],
    controllers: [ProdutoUnidadeController],
    providers: [ProdutoUnidadeService],
})
export class ProdutoUnidadeModule { }
