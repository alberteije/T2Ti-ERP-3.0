import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NfeCanaDeducoesSafraController } from '../controller/nfe-cana-deducoes-safra.controller';
import { NfeCanaDeducoesSafraService } from '../service/nfe-cana-deducoes-safra.service';
import { NfeCanaDeducoesSafraModel } from '../model/nfe-cana-deducoes-safra.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NfeCanaDeducoesSafraModel])],
    controllers: [NfeCanaDeducoesSafraController],
    providers: [NfeCanaDeducoesSafraService],
})
export class NfeCanaDeducoesSafraModule { }
