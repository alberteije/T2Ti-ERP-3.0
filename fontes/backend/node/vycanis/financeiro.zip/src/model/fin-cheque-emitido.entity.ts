import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ChequeModel } from '../entities-export';

@Entity({ name: 'fin_cheque_emitido' })
export class FinChequeEmitidoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'bom_para' }) 
	bomPara: Date; 

	@Column({ name: 'data_compensacao' }) 
	dataCompensacao: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'nominal_a' }) 
	nominalA: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ChequeModel)
	@JoinColumn({ name: 'id_cheque' })
	chequeModel: ChequeModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.bomPara = jsonObj['bomPara'];
			this.dataCompensacao = jsonObj['dataCompensacao'];
			this.valor = jsonObj['valor'];
			this.nominalA = jsonObj['nominalA'];
			if (jsonObj['chequeModel'] != null) {
				this.chequeModel = new ChequeModel(jsonObj['chequeModel']);
			}

		}
	}
}