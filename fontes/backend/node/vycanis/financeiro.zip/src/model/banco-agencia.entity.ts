import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BancoModel } from '../entities-export';

@Entity({ name: 'banco_agencia' })
export class BancoAgenciaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'digito' }) 
	digito: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'telefone' }) 
	telefone: string; 

	@Column({ name: 'contato' }) 
	contato: string; 

	@Column({ name: 'gerente' }) 
	gerente: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => BancoModel)
	@JoinColumn({ name: 'id_banco' })
	bancoModel: BancoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.digito = jsonObj['digito'];
			this.nome = jsonObj['nome'];
			this.telefone = jsonObj['telefone'];
			this.contato = jsonObj['contato'];
			this.gerente = jsonObj['gerente'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['bancoModel'] != null) {
				this.bancoModel = new BancoModel(jsonObj['bancoModel']);
			}

		}
	}
}