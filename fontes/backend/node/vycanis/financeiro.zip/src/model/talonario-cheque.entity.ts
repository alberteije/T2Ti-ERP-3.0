import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ChequeModel } from '../entities-export';
import { BancoContaCaixaModel } from '../entities-export';

@Entity({ name: 'talonario_cheque' })
export class TalonarioChequeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'talao' }) 
	talao: string; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'status_talao' }) 
	statusTalao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ChequeModel, chequeModel => chequeModel.talonarioChequeModel, { cascade: true })
	chequeModelList: ChequeModel[];

	@OneToOne(() => BancoContaCaixaModel)
	@JoinColumn({ name: 'id_banco_conta_caixa' })
	bancoContaCaixaModel: BancoContaCaixaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.talao = jsonObj['talao'];
			this.numero = jsonObj['numero'];
			this.statusTalao = jsonObj['statusTalao'];
			if (jsonObj['bancoContaCaixaModel'] != null) {
				this.bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj['bancoContaCaixaModel']);
			}

			this.chequeModelList = [];
			let chequeModelJsonList = jsonObj['chequeModelList'];
			if (chequeModelJsonList != null) {
				for (let i = 0; i < chequeModelJsonList.length; i++) {
					let obj = new ChequeModel(chequeModelJsonList[i]);
					this.chequeModelList.push(obj);
				}
			}

		}
	}
}