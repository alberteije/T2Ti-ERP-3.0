import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FinLancamentoReceberModel } from '../entities-export';
import { FinStatusParcelaModel } from '../entities-export';
import { FinTipoRecebimentoModel } from '../entities-export';

@Entity({ name: 'fin_parcela_receber' })
export class FinParcelaReceberModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_parcela' }) 
	numeroParcela: number; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'data_vencimento' }) 
	dataVencimento: Date; 

	@Column({ name: 'data_recebimento' }) 
	dataRecebimento: Date; 

	@Column({ name: 'desconto_ate' }) 
	descontoAte: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'taxa_juro', type: 'decimal', precision: 18, scale: 6 }) 
	taxaJuro: number; 

	@Column({ name: 'taxa_multa', type: 'decimal', precision: 18, scale: 6 }) 
	taxaMulta: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_juro', type: 'decimal', precision: 18, scale: 6 }) 
	valorJuro: number; 

	@Column({ name: 'valor_multa', type: 'decimal', precision: 18, scale: 6 }) 
	valorMulta: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'emitiu_boleto' }) 
	emitiuBoleto: string; 

	@Column({ name: 'boleto_nosso_numero' }) 
	boletoNossoNumero: string; 

	@Column({ name: 'valor_recebido', type: 'decimal', precision: 18, scale: 6 }) 
	valorRecebido: number; 

	@Column({ name: 'historico' }) 
	historico: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FinLancamentoReceberModel, finLancamentoReceberModel => finLancamentoReceberModel.finParcelaReceberModelList)
	@JoinColumn({ name: 'id_fin_lancamento_receber' })
	finLancamentoReceberModel: FinLancamentoReceberModel;

	@OneToOne(() => FinStatusParcelaModel)
	@JoinColumn({ name: 'id_fin_status_parcela' })
	finStatusParcelaModel: FinStatusParcelaModel;

	@OneToOne(() => FinTipoRecebimentoModel)
	@JoinColumn({ name: 'id_fin_tipo_recebimento' })
	finTipoRecebimentoModel: FinTipoRecebimentoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroParcela = jsonObj['numeroParcela'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.dataVencimento = jsonObj['dataVencimento'];
			this.dataRecebimento = jsonObj['dataRecebimento'];
			this.descontoAte = jsonObj['descontoAte'];
			this.valor = jsonObj['valor'];
			this.taxaJuro = jsonObj['taxaJuro'];
			this.taxaMulta = jsonObj['taxaMulta'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorJuro = jsonObj['valorJuro'];
			this.valorMulta = jsonObj['valorMulta'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.emitiuBoleto = jsonObj['emitiuBoleto'];
			this.boletoNossoNumero = jsonObj['boletoNossoNumero'];
			this.valorRecebido = jsonObj['valorRecebido'];
			this.historico = jsonObj['historico'];
			if (jsonObj['finStatusParcelaModel'] != null) {
				this.finStatusParcelaModel = new FinStatusParcelaModel(jsonObj['finStatusParcelaModel']);
			}

			if (jsonObj['finTipoRecebimentoModel'] != null) {
				this.finTipoRecebimentoModel = new FinTipoRecebimentoModel(jsonObj['finTipoRecebimentoModel']);
			}

		}
	}
}