import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FinParcelaReceberModel } from '../entities-export';
import { FinDocumentoOrigemModel } from '../entities-export';
import { BancoContaCaixaModel } from '../entities-export';
import { FinNaturezaFinanceiraModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';

@Entity({ name: 'fin_lancamento_receber' })
export class FinLancamentoReceberModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade_parcela' }) 
	quantidadeParcela: number; 

	@Column({ name: 'valor_a_receber', type: 'decimal', precision: 18, scale: 6 }) 
	valorAReceber: number; 

	@Column({ name: 'data_lancamento' }) 
	dataLancamento: Date; 

	@Column({ name: 'numero_documento' }) 
	numeroDocumento: string; 

	@Column({ name: 'primeiro_vencimento' }) 
	primeiroVencimento: Date; 

	@Column({ name: 'taxa_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaComissao: number; 

	@Column({ name: 'valor_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	valorComissao: number; 

	@Column({ name: 'intervalo_entre_parcelas' }) 
	intervaloEntreParcelas: number; 

	@Column({ name: 'dia_fixo' }) 
	diaFixo: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FinParcelaReceberModel, finParcelaReceberModel => finParcelaReceberModel.finLancamentoReceberModel, { cascade: true })
	finParcelaReceberModelList: FinParcelaReceberModel[];

	@OneToOne(() => FinDocumentoOrigemModel)
	@JoinColumn({ name: 'id_fin_documento_origem' })
	finDocumentoOrigemModel: FinDocumentoOrigemModel;

	@OneToOne(() => BancoContaCaixaModel)
	@JoinColumn({ name: 'id_banco_conta_caixa' })
	bancoContaCaixaModel: BancoContaCaixaModel;

	@OneToOne(() => FinNaturezaFinanceiraModel)
	@JoinColumn({ name: 'id_fin_natureza_financeira' })
	finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel;

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidadeParcela = jsonObj['quantidadeParcela'];
			this.valorAReceber = jsonObj['valorAReceber'];
			this.dataLancamento = jsonObj['dataLancamento'];
			this.numeroDocumento = jsonObj['numeroDocumento'];
			this.primeiroVencimento = jsonObj['primeiroVencimento'];
			this.taxaComissao = jsonObj['taxaComissao'];
			this.valorComissao = jsonObj['valorComissao'];
			this.intervaloEntreParcelas = jsonObj['intervaloEntreParcelas'];
			this.diaFixo = jsonObj['diaFixo'];
			if (jsonObj['finDocumentoOrigemModel'] != null) {
				this.finDocumentoOrigemModel = new FinDocumentoOrigemModel(jsonObj['finDocumentoOrigemModel']);
			}

			if (jsonObj['bancoContaCaixaModel'] != null) {
				this.bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj['bancoContaCaixaModel']);
			}

			if (jsonObj['finNaturezaFinanceiraModel'] != null) {
				this.finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel(jsonObj['finNaturezaFinanceiraModel']);
			}

			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

			this.finParcelaReceberModelList = [];
			let finParcelaReceberModelJsonList = jsonObj['finParcelaReceberModelList'];
			if (finParcelaReceberModelJsonList != null) {
				for (let i = 0; i < finParcelaReceberModelJsonList.length; i++) {
					let obj = new FinParcelaReceberModel(finParcelaReceberModelJsonList[i]);
					this.finParcelaReceberModelList.push(obj);
				}
			}

		}
	}
}