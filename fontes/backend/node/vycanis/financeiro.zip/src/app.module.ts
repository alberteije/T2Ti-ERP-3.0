import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { TalonarioChequeModule } from './modules-export';
import { FinLancamentoPagarModule } from './modules-export';
import { FinLancamentoReceberModule } from './modules-export';
import { BancoModule } from './modules-export';
import { BancoAgenciaModule } from './modules-export';
import { BancoContaCaixaModule } from './modules-export';
import { FinFechamentoCaixaBancoModule } from './modules-export';
import { FinExtratoContaBancoModule } from './modules-export';
import { FinDocumentoOrigemModule } from './modules-export';
import { FinNaturezaFinanceiraModule } from './modules-export';
import { FinStatusParcelaModule } from './modules-export';
import { FinTipoPagamentoModule } from './modules-export';
import { FinChequeEmitidoModule } from './modules-export';
import { FinTipoRecebimentoModule } from './modules-export';
import { FinChequeRecebidoModule } from './modules-export';
import { FinConfiguracaoBoletoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaClienteModule } from './modules-export';
import { ViewPessoaFornecedorModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			TalonarioChequeModule,
			FinLancamentoPagarModule,
			FinLancamentoReceberModule,
			BancoModule,
			BancoAgenciaModule,
			BancoContaCaixaModule,
			FinFechamentoCaixaBancoModule,
			FinExtratoContaBancoModule,
			FinDocumentoOrigemModule,
			FinNaturezaFinanceiraModule,
			FinStatusParcelaModule,
			FinTipoPagamentoModule,
			FinChequeEmitidoModule,
			FinTipoRecebimentoModule,
			FinChequeRecebidoModule,
			FinConfiguracaoBoletoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaClienteModule,
			ViewPessoaFornecedorModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}