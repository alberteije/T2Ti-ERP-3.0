import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinExtratoContaBancoController } from '../controller/fin-extrato-conta-banco.controller';
import { FinExtratoContaBancoService } from '../service/fin-extrato-conta-banco.service';
import { FinExtratoContaBancoModel } from '../model/fin-extrato-conta-banco.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinExtratoContaBancoModel])],
    controllers: [FinExtratoContaBancoController],
    providers: [FinExtratoContaBancoService],
})
export class FinExtratoContaBancoModule { }
