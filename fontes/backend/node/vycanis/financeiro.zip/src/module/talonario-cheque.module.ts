import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TalonarioChequeController } from '../controller/talonario-cheque.controller';
import { TalonarioChequeService } from '../service/talonario-cheque.service';
import { TalonarioChequeModel } from '../model/talonario-cheque.entity';

@Module({
    imports: [TypeOrmModule.forFeature([TalonarioChequeModel])],
    controllers: [TalonarioChequeController],
    providers: [TalonarioChequeService],
})
export class TalonarioChequeModule { }
