import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BancoController } from '../controller/banco.controller';
import { BancoService } from '../service/banco.service';
import { BancoModel } from '../model/banco.entity';

@Module({
    imports: [TypeOrmModule.forFeature([BancoModel])],
    controllers: [BancoController],
    providers: [BancoService],
})
export class BancoModule { }
