import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinFechamentoCaixaBancoController } from '../controller/fin-fechamento-caixa-banco.controller';
import { FinFechamentoCaixaBancoService } from '../service/fin-fechamento-caixa-banco.service';
import { FinFechamentoCaixaBancoModel } from '../model/fin-fechamento-caixa-banco.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinFechamentoCaixaBancoModel])],
    controllers: [FinFechamentoCaixaBancoController],
    providers: [FinFechamentoCaixaBancoService],
})
export class FinFechamentoCaixaBancoModule { }
