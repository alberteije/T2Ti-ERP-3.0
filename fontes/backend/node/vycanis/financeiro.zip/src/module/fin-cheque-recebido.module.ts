import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinChequeRecebidoController } from '../controller/fin-cheque-recebido.controller';
import { FinChequeRecebidoService } from '../service/fin-cheque-recebido.service';
import { FinChequeRecebidoModel } from '../model/fin-cheque-recebido.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinChequeRecebidoModel])],
    controllers: [FinChequeRecebidoController],
    providers: [FinChequeRecebidoService],
})
export class FinChequeRecebidoModule { }
