import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinTipoRecebimentoController } from '../controller/fin-tipo-recebimento.controller';
import { FinTipoRecebimentoService } from '../service/fin-tipo-recebimento.service';
import { FinTipoRecebimentoModel } from '../model/fin-tipo-recebimento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinTipoRecebimentoModel])],
    controllers: [FinTipoRecebimentoController],
    providers: [FinTipoRecebimentoService],
})
export class FinTipoRecebimentoModule { }
