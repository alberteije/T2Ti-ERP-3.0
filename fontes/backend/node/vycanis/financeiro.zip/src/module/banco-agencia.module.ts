import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BancoAgenciaController } from '../controller/banco-agencia.controller';
import { BancoAgenciaService } from '../service/banco-agencia.service';
import { BancoAgenciaModel } from '../model/banco-agencia.entity';

@Module({
    imports: [TypeOrmModule.forFeature([BancoAgenciaModel])],
    controllers: [BancoAgenciaController],
    providers: [BancoAgenciaService],
})
export class BancoAgenciaModule { }
