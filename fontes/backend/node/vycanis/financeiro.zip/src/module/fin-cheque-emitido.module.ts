import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinChequeEmitidoController } from '../controller/fin-cheque-emitido.controller';
import { FinChequeEmitidoService } from '../service/fin-cheque-emitido.service';
import { FinChequeEmitidoModel } from '../model/fin-cheque-emitido.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinChequeEmitidoModel])],
    controllers: [FinChequeEmitidoController],
    providers: [FinChequeEmitidoService],
})
export class FinChequeEmitidoModule { }
