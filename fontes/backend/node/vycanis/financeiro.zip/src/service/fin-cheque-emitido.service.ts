import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinChequeEmitidoModel } from '../entities-export';

@Injectable()
export class FinChequeEmitidoService extends TypeOrmCrudService<FinChequeEmitidoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinChequeEmitidoModel)
    private readonly repository: Repository<FinChequeEmitidoModel>
  ) {
    super(repository);
  }

	async save(finChequeEmitidoModel: FinChequeEmitidoModel): Promise<FinChequeEmitidoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finChequeEmitidoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
