import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinDocumentoOrigemModel } from '../entities-export';

@Injectable()
export class FinDocumentoOrigemService extends TypeOrmCrudService<FinDocumentoOrigemModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinDocumentoOrigemModel)
    private readonly repository: Repository<FinDocumentoOrigemModel>
  ) {
    super(repository);
  }

	async save(finDocumentoOrigemModel: FinDocumentoOrigemModel): Promise<FinDocumentoOrigemModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finDocumentoOrigemModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
