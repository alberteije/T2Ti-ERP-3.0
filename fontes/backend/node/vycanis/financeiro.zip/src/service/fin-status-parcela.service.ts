import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinStatusParcelaModel } from '../entities-export';

@Injectable()
export class FinStatusParcelaService extends TypeOrmCrudService<FinStatusParcelaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinStatusParcelaModel)
    private readonly repository: Repository<FinStatusParcelaModel>
  ) {
    super(repository);
  }

	async save(finStatusParcelaModel: FinStatusParcelaModel): Promise<FinStatusParcelaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finStatusParcelaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
