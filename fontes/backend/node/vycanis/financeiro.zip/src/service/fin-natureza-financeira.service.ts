import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinNaturezaFinanceiraModel } from '../entities-export';

@Injectable()
export class FinNaturezaFinanceiraService extends TypeOrmCrudService<FinNaturezaFinanceiraModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinNaturezaFinanceiraModel)
    private readonly repository: Repository<FinNaturezaFinanceiraModel>
  ) {
    super(repository);
  }

	async save(finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel): Promise<FinNaturezaFinanceiraModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finNaturezaFinanceiraModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
