import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { BancoAgenciaModel } from '../entities-export';

@Injectable()
export class BancoAgenciaService extends TypeOrmCrudService<BancoAgenciaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(BancoAgenciaModel)
    private readonly repository: Repository<BancoAgenciaModel>
  ) {
    super(repository);
  }

	async save(bancoAgenciaModel: BancoAgenciaModel): Promise<BancoAgenciaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(bancoAgenciaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
