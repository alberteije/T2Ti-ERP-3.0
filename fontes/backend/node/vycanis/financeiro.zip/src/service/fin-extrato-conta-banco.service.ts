import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinExtratoContaBancoModel } from '../entities-export';

@Injectable()
export class FinExtratoContaBancoService extends TypeOrmCrudService<FinExtratoContaBancoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinExtratoContaBancoModel)
    private readonly repository: Repository<FinExtratoContaBancoModel>
  ) {
    super(repository);
  }

	async save(finExtratoContaBancoModel: FinExtratoContaBancoModel): Promise<FinExtratoContaBancoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finExtratoContaBancoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
