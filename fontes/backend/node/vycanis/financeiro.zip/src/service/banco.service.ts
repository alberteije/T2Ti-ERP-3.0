import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { BancoModel } from '../entities-export';

@Injectable()
export class BancoService extends TypeOrmCrudService<BancoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(BancoModel)
    private readonly repository: Repository<BancoModel>
  ) {
    super(repository);
  }

	async save(bancoModel: BancoModel): Promise<BancoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(bancoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
