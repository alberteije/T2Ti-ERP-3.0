import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinConfiguracaoBoletoService } from '../service/fin-configuracao-boleto.service';
import { FinConfiguracaoBoletoModel } from '../model/fin-configuracao-boleto.entity';

@Crud({
  model: {
    type: FinConfiguracaoBoletoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-configuracao-boleto')
export class FinConfiguracaoBoletoController implements CrudController<FinConfiguracaoBoletoModel> {
  constructor(public service: FinConfiguracaoBoletoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finConfiguracaoBoletoModel = new FinConfiguracaoBoletoModel(jsonObj);
		const result = await this.service.save(finConfiguracaoBoletoModel);
		return result;
	}  


}


















