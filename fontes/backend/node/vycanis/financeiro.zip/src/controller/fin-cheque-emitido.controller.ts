import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinChequeEmitidoService } from '../service/fin-cheque-emitido.service';
import { FinChequeEmitidoModel } from '../model/fin-cheque-emitido.entity';

@Crud({
  model: {
    type: FinChequeEmitidoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-cheque-emitido')
export class FinChequeEmitidoController implements CrudController<FinChequeEmitidoModel> {
  constructor(public service: FinChequeEmitidoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finChequeEmitidoModel = new FinChequeEmitidoModel(jsonObj);
		const result = await this.service.save(finChequeEmitidoModel);
		return result;
	}  


}


















