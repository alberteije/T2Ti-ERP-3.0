import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { TalonarioChequeService } from '../service/talonario-cheque.service';
import { TalonarioChequeModel } from '../model/talonario-cheque.entity';

@Crud({
  model: {
    type: TalonarioChequeModel,
  },
  query: {
    join: {
			chequeModelList: { eager: true },
			bancoContaCaixaModel: { eager: true },
    },
  },
})
@Controller('talonario-cheque')
export class TalonarioChequeController implements CrudController<TalonarioChequeModel> {
  constructor(public service: TalonarioChequeService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const talonarioCheque = new TalonarioChequeModel(jsonObj);
		const result = await this.service.save(talonarioCheque, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const talonarioCheque = new TalonarioChequeModel(jsonObj);
		const result = await this.service.save(talonarioCheque, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}