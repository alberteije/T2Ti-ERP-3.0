import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FinLancamentoPagarService } from '../service/fin-lancamento-pagar.service';
import { FinLancamentoPagarModel } from '../model/fin-lancamento-pagar.entity';

@Crud({
  model: {
    type: FinLancamentoPagarModel,
  },
  query: {
    join: {
			finParcelaPagarModelList: { eager: true },
			finDocumentoOrigemModel: { eager: true },
			bancoContaCaixaModel: { eager: true },
			finNaturezaFinanceiraModel: { eager: true },
			viewPessoaFornecedorModel: { eager: true },
    },
  },
})
@Controller('fin-lancamento-pagar')
export class FinLancamentoPagarController implements CrudController<FinLancamentoPagarModel> {
  constructor(public service: FinLancamentoPagarService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const finLancamentoPagar = new FinLancamentoPagarModel(jsonObj);
		const result = await this.service.save(finLancamentoPagar, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finLancamentoPagar = new FinLancamentoPagarModel(jsonObj);
		const result = await this.service.save(finLancamentoPagar, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}