import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FinLancamentoReceberService } from '../service/fin-lancamento-receber.service';
import { FinLancamentoReceberModel } from '../model/fin-lancamento-receber.entity';

@Crud({
  model: {
    type: FinLancamentoReceberModel,
  },
  query: {
    join: {
			finParcelaReceberModelList: { eager: true },
			finDocumentoOrigemModel: { eager: true },
			bancoContaCaixaModel: { eager: true },
			finNaturezaFinanceiraModel: { eager: true },
			viewPessoaClienteModel: { eager: true },
    },
  },
})
@Controller('fin-lancamento-receber')
export class FinLancamentoReceberController implements CrudController<FinLancamentoReceberModel> {
  constructor(public service: FinLancamentoReceberService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const finLancamentoReceber = new FinLancamentoReceberModel(jsonObj);
		const result = await this.service.save(finLancamentoReceber, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finLancamentoReceber = new FinLancamentoReceberModel(jsonObj);
		const result = await this.service.save(finLancamentoReceber, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}