import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinChequeRecebidoService } from '../service/fin-cheque-recebido.service';
import { FinChequeRecebidoModel } from '../model/fin-cheque-recebido.entity';

@Crud({
  model: {
    type: FinChequeRecebidoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-cheque-recebido')
export class FinChequeRecebidoController implements CrudController<FinChequeRecebidoModel> {
  constructor(public service: FinChequeRecebidoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finChequeRecebidoModel = new FinChequeRecebidoModel(jsonObj);
		const result = await this.service.save(finChequeRecebidoModel);
		return result;
	}  


}


















