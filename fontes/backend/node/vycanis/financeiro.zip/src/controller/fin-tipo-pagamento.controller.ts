import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinTipoPagamentoService } from '../service/fin-tipo-pagamento.service';
import { FinTipoPagamentoModel } from '../model/fin-tipo-pagamento.entity';

@Crud({
  model: {
    type: FinTipoPagamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-tipo-pagamento')
export class FinTipoPagamentoController implements CrudController<FinTipoPagamentoModel> {
  constructor(public service: FinTipoPagamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finTipoPagamentoModel = new FinTipoPagamentoModel(jsonObj);
		const result = await this.service.save(finTipoPagamentoModel);
		return result;
	}  


}


















