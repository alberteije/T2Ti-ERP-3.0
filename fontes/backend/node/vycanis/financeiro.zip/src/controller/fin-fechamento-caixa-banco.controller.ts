import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinFechamentoCaixaBancoService } from '../service/fin-fechamento-caixa-banco.service';
import { FinFechamentoCaixaBancoModel } from '../model/fin-fechamento-caixa-banco.entity';

@Crud({
  model: {
    type: FinFechamentoCaixaBancoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-fechamento-caixa-banco')
export class FinFechamentoCaixaBancoController implements CrudController<FinFechamentoCaixaBancoModel> {
  constructor(public service: FinFechamentoCaixaBancoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finFechamentoCaixaBancoModel = new FinFechamentoCaixaBancoModel(jsonObj);
		const result = await this.service.save(finFechamentoCaixaBancoModel);
		return result;
	}  


}


















