import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinStatusParcelaService } from '../service/fin-status-parcela.service';
import { FinStatusParcelaModel } from '../model/fin-status-parcela.entity';

@Crud({
  model: {
    type: FinStatusParcelaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-status-parcela')
export class FinStatusParcelaController implements CrudController<FinStatusParcelaModel> {
  constructor(public service: FinStatusParcelaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finStatusParcelaModel = new FinStatusParcelaModel(jsonObj);
		const result = await this.service.save(finStatusParcelaModel);
		return result;
	}  


}


















