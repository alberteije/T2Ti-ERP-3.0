import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinExtratoContaBancoService } from '../service/fin-extrato-conta-banco.service';
import { FinExtratoContaBancoModel } from '../model/fin-extrato-conta-banco.entity';

@Crud({
  model: {
    type: FinExtratoContaBancoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-extrato-conta-banco')
export class FinExtratoContaBancoController implements CrudController<FinExtratoContaBancoModel> {
  constructor(public service: FinExtratoContaBancoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finExtratoContaBancoModel = new FinExtratoContaBancoModel(jsonObj);
		const result = await this.service.save(finExtratoContaBancoModel);
		return result;
	}  


}


















