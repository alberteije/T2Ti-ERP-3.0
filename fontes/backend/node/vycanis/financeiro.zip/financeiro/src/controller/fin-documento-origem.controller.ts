import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinDocumentoOrigemService } from '../service/fin-documento-origem.service';
import { FinDocumentoOrigemModel } from '../model/fin-documento-origem.entity';

@Crud({
  model: {
    type: FinDocumentoOrigemModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-documento-origem')
export class FinDocumentoOrigemController implements CrudController<FinDocumentoOrigemModel> {
  constructor(public service: FinDocumentoOrigemService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finDocumentoOrigemModel = new FinDocumentoOrigemModel(jsonObj);
		const result = await this.service.save(finDocumentoOrigemModel);
		return result;
	}  


}


















