import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinTipoRecebimentoService } from '../service/fin-tipo-recebimento.service';
import { FinTipoRecebimentoModel } from '../model/fin-tipo-recebimento.entity';

@Crud({
  model: {
    type: FinTipoRecebimentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-tipo-recebimento')
export class FinTipoRecebimentoController implements CrudController<FinTipoRecebimentoModel> {
  constructor(public service: FinTipoRecebimentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finTipoRecebimentoModel = new FinTipoRecebimentoModel(jsonObj);
		const result = await this.service.save(finTipoRecebimentoModel);
		return result;
	}  


}


















