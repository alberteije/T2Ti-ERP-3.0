import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinFechamentoCaixaBancoModel } from '../entities-export';

@Injectable()
export class FinFechamentoCaixaBancoService extends TypeOrmCrudService<FinFechamentoCaixaBancoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinFechamentoCaixaBancoModel)
    private readonly repository: Repository<FinFechamentoCaixaBancoModel>
  ) {
    super(repository);
  }

	async save(finFechamentoCaixaBancoModel: FinFechamentoCaixaBancoModel): Promise<FinFechamentoCaixaBancoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finFechamentoCaixaBancoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
