import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinTipoPagamentoModel } from '../entities-export';

@Injectable()
export class FinTipoPagamentoService extends TypeOrmCrudService<FinTipoPagamentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinTipoPagamentoModel)
    private readonly repository: Repository<FinTipoPagamentoModel>
  ) {
    super(repository);
  }

	async save(finTipoPagamentoModel: FinTipoPagamentoModel): Promise<FinTipoPagamentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finTipoPagamentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
