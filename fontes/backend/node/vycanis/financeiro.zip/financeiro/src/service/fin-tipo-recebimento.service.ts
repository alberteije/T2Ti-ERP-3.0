import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinTipoRecebimentoModel } from '../entities-export';

@Injectable()
export class FinTipoRecebimentoService extends TypeOrmCrudService<FinTipoRecebimentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinTipoRecebimentoModel)
    private readonly repository: Repository<FinTipoRecebimentoModel>
  ) {
    super(repository);
  }

	async save(finTipoRecebimentoModel: FinTipoRecebimentoModel): Promise<FinTipoRecebimentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finTipoRecebimentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
