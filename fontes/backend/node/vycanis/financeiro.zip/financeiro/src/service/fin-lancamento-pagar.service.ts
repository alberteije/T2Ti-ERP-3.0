import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { FinLancamentoPagarModel } from '../entities-export';

@Injectable()
export class FinLancamentoPagarService extends TypeOrmCrudService<FinLancamentoPagarModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(FinLancamentoPagarModel) 
    private readonly repository: Repository<FinLancamentoPagarModel>,
  ) {
    super(repository);
  }

	async save(finLancamentoPagarModel: FinLancamentoPagarModel, operation: string): Promise<FinLancamentoPagarModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, finLancamentoPagarModel.id);
      }

      const resultObj = await queryRunner.manager.save(finLancamentoPagarModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(FinLancamentoPagarModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from fin_parcela_pagar where id_fin_lancamento_pagar=' + id); 

	}
	
}