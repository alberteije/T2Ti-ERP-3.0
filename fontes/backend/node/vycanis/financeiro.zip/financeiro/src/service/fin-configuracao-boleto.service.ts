import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FinConfiguracaoBoletoModel } from '../entities-export';

@Injectable()
export class FinConfiguracaoBoletoService extends TypeOrmCrudService<FinConfiguracaoBoletoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FinConfiguracaoBoletoModel)
    private readonly repository: Repository<FinConfiguracaoBoletoModel>
  ) {
    super(repository);
  }

	async save(finConfiguracaoBoletoModel: FinConfiguracaoBoletoModel): Promise<FinConfiguracaoBoletoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(finConfiguracaoBoletoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
