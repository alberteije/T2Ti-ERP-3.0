import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinLancamentoReceberController } from '../controller/fin-lancamento-receber.controller';
import { FinLancamentoReceberService } from '../service/fin-lancamento-receber.service';
import { FinLancamentoReceberModel } from '../model/fin-lancamento-receber.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinLancamentoReceberModel])],
    controllers: [FinLancamentoReceberController],
    providers: [FinLancamentoReceberService],
})
export class FinLancamentoReceberModule { }
