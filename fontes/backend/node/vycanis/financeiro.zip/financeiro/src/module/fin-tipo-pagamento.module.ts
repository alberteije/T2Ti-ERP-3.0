import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinTipoPagamentoController } from '../controller/fin-tipo-pagamento.controller';
import { FinTipoPagamentoService } from '../service/fin-tipo-pagamento.service';
import { FinTipoPagamentoModel } from '../model/fin-tipo-pagamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinTipoPagamentoModel])],
    controllers: [FinTipoPagamentoController],
    providers: [FinTipoPagamentoService],
})
export class FinTipoPagamentoModule { }
