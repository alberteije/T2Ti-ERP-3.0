import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinLancamentoPagarController } from '../controller/fin-lancamento-pagar.controller';
import { FinLancamentoPagarService } from '../service/fin-lancamento-pagar.service';
import { FinLancamentoPagarModel } from '../model/fin-lancamento-pagar.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinLancamentoPagarModel])],
    controllers: [FinLancamentoPagarController],
    providers: [FinLancamentoPagarService],
})
export class FinLancamentoPagarModule { }
