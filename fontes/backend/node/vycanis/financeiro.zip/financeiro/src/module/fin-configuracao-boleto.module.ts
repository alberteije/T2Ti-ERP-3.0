import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinConfiguracaoBoletoController } from '../controller/fin-configuracao-boleto.controller';
import { FinConfiguracaoBoletoService } from '../service/fin-configuracao-boleto.service';
import { FinConfiguracaoBoletoModel } from '../model/fin-configuracao-boleto.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinConfiguracaoBoletoModel])],
    controllers: [FinConfiguracaoBoletoController],
    providers: [FinConfiguracaoBoletoService],
})
export class FinConfiguracaoBoletoModule { }
