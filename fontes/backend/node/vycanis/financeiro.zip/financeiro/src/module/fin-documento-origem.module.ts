import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinDocumentoOrigemController } from '../controller/fin-documento-origem.controller';
import { FinDocumentoOrigemService } from '../service/fin-documento-origem.service';
import { FinDocumentoOrigemModel } from '../model/fin-documento-origem.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinDocumentoOrigemModel])],
    controllers: [FinDocumentoOrigemController],
    providers: [FinDocumentoOrigemService],
})
export class FinDocumentoOrigemModule { }
