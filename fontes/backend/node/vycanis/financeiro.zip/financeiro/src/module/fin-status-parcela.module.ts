import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinStatusParcelaController } from '../controller/fin-status-parcela.controller';
import { FinStatusParcelaService } from '../service/fin-status-parcela.service';
import { FinStatusParcelaModel } from '../model/fin-status-parcela.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinStatusParcelaModel])],
    controllers: [FinStatusParcelaController],
    providers: [FinStatusParcelaService],
})
export class FinStatusParcelaModule { }
