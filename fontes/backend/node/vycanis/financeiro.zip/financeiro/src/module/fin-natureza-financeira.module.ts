import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FinNaturezaFinanceiraController } from '../controller/fin-natureza-financeira.controller';
import { FinNaturezaFinanceiraService } from '../service/fin-natureza-financeira.service';
import { FinNaturezaFinanceiraModel } from '../model/fin-natureza-financeira.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FinNaturezaFinanceiraModel])],
    controllers: [FinNaturezaFinanceiraController],
    providers: [FinNaturezaFinanceiraService],
})
export class FinNaturezaFinanceiraModule { }
