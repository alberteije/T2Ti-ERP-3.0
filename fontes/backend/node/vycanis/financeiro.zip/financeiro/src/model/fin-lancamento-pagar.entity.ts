import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FinParcelaPagarModel } from '../entities-export';
import { FinDocumentoOrigemModel } from '../entities-export';
import { BancoContaCaixaModel } from '../entities-export';
import { FinNaturezaFinanceiraModel } from '../entities-export';
import { ViewPessoaFornecedorModel } from '../entities-export';

@Entity({ name: 'fin_lancamento_pagar' })
export class FinLancamentoPagarModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade_parcela' }) 
	quantidadeParcela: number; 

	@Column({ name: 'valor_a_pagar', type: 'decimal', precision: 18, scale: 6 }) 
	valorAPagar: number; 

	@Column({ name: 'data_lancamento' }) 
	dataLancamento: Date; 

	@Column({ name: 'numero_documento' }) 
	numeroDocumento: string; 

	@Column({ name: 'primeiro_vencimento' }) 
	primeiroVencimento: Date; 

	@Column({ name: 'intervalo_entre_parcelas' }) 
	intervaloEntreParcelas: number; 

	@Column({ name: 'dia_fixo' }) 
	diaFixo: string; 

	@Column({ name: 'imagem_documento' }) 
	imagemDocumento: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FinParcelaPagarModel, finParcelaPagarModel => finParcelaPagarModel.finLancamentoPagarModel, { cascade: true })
	finParcelaPagarModelList: FinParcelaPagarModel[];

	@OneToOne(() => FinDocumentoOrigemModel)
	@JoinColumn({ name: 'id_fin_documento_origem' })
	finDocumentoOrigemModel: FinDocumentoOrigemModel;

	@OneToOne(() => BancoContaCaixaModel)
	@JoinColumn({ name: 'id_banco_conta_caixa' })
	bancoContaCaixaModel: BancoContaCaixaModel;

	@OneToOne(() => FinNaturezaFinanceiraModel)
	@JoinColumn({ name: 'id_fin_natureza_financeira' })
	finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel;

	@OneToOne(() => ViewPessoaFornecedorModel)
	@JoinColumn({ name: 'id_fornecedor' })
	viewPessoaFornecedorModel: ViewPessoaFornecedorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidadeParcela = jsonObj['quantidadeParcela'];
			this.valorAPagar = jsonObj['valorAPagar'];
			this.dataLancamento = jsonObj['dataLancamento'];
			this.numeroDocumento = jsonObj['numeroDocumento'];
			this.primeiroVencimento = jsonObj['primeiroVencimento'];
			this.intervaloEntreParcelas = jsonObj['intervaloEntreParcelas'];
			this.diaFixo = jsonObj['diaFixo'];
			this.imagemDocumento = jsonObj['imagemDocumento'];
			if (jsonObj['finDocumentoOrigemModel'] != null) {
				this.finDocumentoOrigemModel = new FinDocumentoOrigemModel(jsonObj['finDocumentoOrigemModel']);
			}

			if (jsonObj['bancoContaCaixaModel'] != null) {
				this.bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj['bancoContaCaixaModel']);
			}

			if (jsonObj['finNaturezaFinanceiraModel'] != null) {
				this.finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel(jsonObj['finNaturezaFinanceiraModel']);
			}

			if (jsonObj['viewPessoaFornecedorModel'] != null) {
				this.viewPessoaFornecedorModel = new ViewPessoaFornecedorModel(jsonObj['viewPessoaFornecedorModel']);
			}

			this.finParcelaPagarModelList = [];
			let finParcelaPagarModelJsonList = jsonObj['finParcelaPagarModelList'];
			if (finParcelaPagarModelJsonList != null) {
				for (let i = 0; i < finParcelaPagarModelJsonList.length; i++) {
					let obj = new FinParcelaPagarModel(finParcelaPagarModelJsonList[i]);
					this.finParcelaPagarModelList.push(obj);
				}
			}

		}
	}
}