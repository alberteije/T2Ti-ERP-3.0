import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BancoContaCaixaModel } from '../entities-export';

@Entity({ name: 'fin_extrato_conta_banco' })
export class FinExtratoContaBancoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'mes_ano' }) 
	mesAno: string; 

	@Column({ name: 'mes' }) 
	mes: string; 

	@Column({ name: 'ano' }) 
	ano: string; 

	@Column({ name: 'data_movimento' }) 
	dataMovimento: Date; 

	@Column({ name: 'data_balancete' }) 
	dataBalancete: Date; 

	@Column({ name: 'historico' }) 
	historico: string; 

	@Column({ name: 'documento' }) 
	documento: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'conciliado' }) 
	conciliado: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => BancoContaCaixaModel)
	@JoinColumn({ name: 'id_banco_conta_caixa' })
	bancoContaCaixaModel: BancoContaCaixaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.mesAno = jsonObj['mesAno'];
			this.mes = jsonObj['mes'];
			this.ano = jsonObj['ano'];
			this.dataMovimento = jsonObj['dataMovimento'];
			this.dataBalancete = jsonObj['dataBalancete'];
			this.historico = jsonObj['historico'];
			this.documento = jsonObj['documento'];
			this.valor = jsonObj['valor'];
			this.conciliado = jsonObj['conciliado'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['bancoContaCaixaModel'] != null) {
				this.bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj['bancoContaCaixaModel']);
			}

		}
	}
}