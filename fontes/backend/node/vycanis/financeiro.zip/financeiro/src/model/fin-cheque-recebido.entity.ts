import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaClienteModel } from '../entities-export';

@Entity({ name: 'fin_cheque_recebido' })
export class FinChequeRecebidoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'codigo_banco' }) 
	codigoBanco: string; 

	@Column({ name: 'codigo_agencia' }) 
	codigoAgencia: string; 

	@Column({ name: 'conta' }) 
	conta: string; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'bom_para' }) 
	bomPara: Date; 

	@Column({ name: 'data_compensacao' }) 
	dataCompensacao: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'custodia_data' }) 
	custodiaData: Date; 

	@Column({ name: 'custodia_tarifa', type: 'decimal', precision: 18, scale: 6 }) 
	custodiaTarifa: number; 

	@Column({ name: 'custodia_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	custodiaComissao: number; 

	@Column({ name: 'desconto_data' }) 
	descontoData: Date; 

	@Column({ name: 'desconto_tarifa', type: 'decimal', precision: 18, scale: 6 }) 
	descontoTarifa: number; 

	@Column({ name: 'desconto_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	descontoComissao: number; 

	@Column({ name: 'valor_recebido', type: 'decimal', precision: 18, scale: 6 }) 
	valorRecebido: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cpf = jsonObj['cpf'];
			this.cnpj = jsonObj['cnpj'];
			this.nome = jsonObj['nome'];
			this.codigoBanco = jsonObj['codigoBanco'];
			this.codigoAgencia = jsonObj['codigoAgencia'];
			this.conta = jsonObj['conta'];
			this.numero = jsonObj['numero'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.bomPara = jsonObj['bomPara'];
			this.dataCompensacao = jsonObj['dataCompensacao'];
			this.valor = jsonObj['valor'];
			this.custodiaData = jsonObj['custodiaData'];
			this.custodiaTarifa = jsonObj['custodiaTarifa'];
			this.custodiaComissao = jsonObj['custodiaComissao'];
			this.descontoData = jsonObj['descontoData'];
			this.descontoTarifa = jsonObj['descontoTarifa'];
			this.descontoComissao = jsonObj['descontoComissao'];
			this.valorRecebido = jsonObj['valorRecebido'];
			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

		}
	}
}