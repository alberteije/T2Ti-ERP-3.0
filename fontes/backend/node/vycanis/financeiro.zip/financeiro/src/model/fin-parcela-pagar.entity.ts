import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FinLancamentoPagarModel } from '../entities-export';
import { FinStatusParcelaModel } from '../entities-export';
import { FinTipoPagamentoModel } from '../entities-export';

@Entity({ name: 'fin_parcela_pagar' })
export class FinParcelaPagarModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_parcela' }) 
	numeroParcela: number; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'data_vencimento' }) 
	dataVencimento: Date; 

	@Column({ name: 'data_pagamento' }) 
	dataPagamento: Date; 

	@Column({ name: 'desconto_ate' }) 
	descontoAte: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'taxa_juro', type: 'decimal', precision: 18, scale: 6 }) 
	taxaJuro: number; 

	@Column({ name: 'taxa_multa', type: 'decimal', precision: 18, scale: 6 }) 
	taxaMulta: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_juro', type: 'decimal', precision: 18, scale: 6 }) 
	valorJuro: number; 

	@Column({ name: 'valor_multa', type: 'decimal', precision: 18, scale: 6 }) 
	valorMulta: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_pago', type: 'decimal', precision: 18, scale: 6 }) 
	valorPago: number; 

	@Column({ name: 'historico' }) 
	historico: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FinLancamentoPagarModel, finLancamentoPagarModel => finLancamentoPagarModel.finParcelaPagarModelList)
	@JoinColumn({ name: 'id_fin_lancamento_pagar' })
	finLancamentoPagarModel: FinLancamentoPagarModel;

	@OneToOne(() => FinStatusParcelaModel)
	@JoinColumn({ name: 'id_fin_status_parcela' })
	finStatusParcelaModel: FinStatusParcelaModel;

	@OneToOne(() => FinTipoPagamentoModel)
	@JoinColumn({ name: 'id_fin_tipo_pagamento' })
	finTipoPagamentoModel: FinTipoPagamentoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroParcela = jsonObj['numeroParcela'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.dataVencimento = jsonObj['dataVencimento'];
			this.dataPagamento = jsonObj['dataPagamento'];
			this.descontoAte = jsonObj['descontoAte'];
			this.valor = jsonObj['valor'];
			this.taxaJuro = jsonObj['taxaJuro'];
			this.taxaMulta = jsonObj['taxaMulta'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorJuro = jsonObj['valorJuro'];
			this.valorMulta = jsonObj['valorMulta'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorPago = jsonObj['valorPago'];
			this.historico = jsonObj['historico'];
			if (jsonObj['finStatusParcelaModel'] != null) {
				this.finStatusParcelaModel = new FinStatusParcelaModel(jsonObj['finStatusParcelaModel']);
			}

			if (jsonObj['finTipoPagamentoModel'] != null) {
				this.finTipoPagamentoModel = new FinTipoPagamentoModel(jsonObj['finTipoPagamentoModel']);
			}

		}
	}
}