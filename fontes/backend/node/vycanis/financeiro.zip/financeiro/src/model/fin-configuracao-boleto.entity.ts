import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BancoContaCaixaModel } from '../entities-export';

@Entity({ name: 'fin_configuracao_boleto' })
export class FinConfiguracaoBoletoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'instrucao01' }) 
	instrucao01: string; 

	@Column({ name: 'instrucao02' }) 
	instrucao02: string; 

	@Column({ name: 'caminho_arquivo_remessa' }) 
	caminhoArquivoRemessa: string; 

	@Column({ name: 'caminho_arquivo_retorno' }) 
	caminhoArquivoRetorno: string; 

	@Column({ name: 'caminho_arquivo_logotipo' }) 
	caminhoArquivoLogotipo: string; 

	@Column({ name: 'caminho_arquivo_pdf' }) 
	caminhoArquivoPdf: string; 

	@Column({ name: 'mensagem' }) 
	mensagem: string; 

	@Column({ name: 'local_pagamento' }) 
	localPagamento: string; 

	@Column({ name: 'layout_remessa' }) 
	layoutRemessa: string; 

	@Column({ name: 'aceite' }) 
	aceite: string; 

	@Column({ name: 'especie' }) 
	especie: string; 

	@Column({ name: 'carteira' }) 
	carteira: string; 

	@Column({ name: 'codigo_convenio' }) 
	codigoConvenio: string; 

	@Column({ name: 'codigo_cedente' }) 
	codigoCedente: string; 

	@Column({ name: 'taxa_multa', type: 'decimal', precision: 18, scale: 6 }) 
	taxaMulta: number; 

	@Column({ name: 'taxa_juro', type: 'decimal', precision: 18, scale: 6 }) 
	taxaJuro: number; 

	@Column({ name: 'dias_protesto' }) 
	diasProtesto: number; 

	@Column({ name: 'nosso_numero_anterior' }) 
	nossoNumeroAnterior: string; 


	/**
	* Relations
	*/
	@OneToOne(() => BancoContaCaixaModel)
	@JoinColumn({ name: 'id_banco_conta_caixa' })
	bancoContaCaixaModel: BancoContaCaixaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.instrucao01 = jsonObj['instrucao01'];
			this.instrucao02 = jsonObj['instrucao02'];
			this.caminhoArquivoRemessa = jsonObj['caminhoArquivoRemessa'];
			this.caminhoArquivoRetorno = jsonObj['caminhoArquivoRetorno'];
			this.caminhoArquivoLogotipo = jsonObj['caminhoArquivoLogotipo'];
			this.caminhoArquivoPdf = jsonObj['caminhoArquivoPdf'];
			this.mensagem = jsonObj['mensagem'];
			this.localPagamento = jsonObj['localPagamento'];
			this.layoutRemessa = jsonObj['layoutRemessa'];
			this.aceite = jsonObj['aceite'];
			this.especie = jsonObj['especie'];
			this.carteira = jsonObj['carteira'];
			this.codigoConvenio = jsonObj['codigoConvenio'];
			this.codigoCedente = jsonObj['codigoCedente'];
			this.taxaMulta = jsonObj['taxaMulta'];
			this.taxaJuro = jsonObj['taxaJuro'];
			this.diasProtesto = jsonObj['diasProtesto'];
			this.nossoNumeroAnterior = jsonObj['nossoNumeroAnterior'];
			if (jsonObj['bancoContaCaixaModel'] != null) {
				this.bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj['bancoContaCaixaModel']);
			}

		}
	}
}