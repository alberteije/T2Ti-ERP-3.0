import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BancoContaCaixaModel } from '../entities-export';

@Entity({ name: 'fin_fechamento_caixa_banco' })
export class FinFechamentoCaixaBancoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_fechamento' }) 
	dataFechamento: Date; 

	@Column({ name: 'mes_ano' }) 
	mesAno: string; 

	@Column({ name: 'mes' }) 
	mes: string; 

	@Column({ name: 'ano' }) 
	ano: string; 

	@Column({ name: 'saldo_anterior', type: 'decimal', precision: 18, scale: 6 }) 
	saldoAnterior: number; 

	@Column({ name: 'recebimentos', type: 'decimal', precision: 18, scale: 6 }) 
	recebimentos: number; 

	@Column({ name: 'pagamentos', type: 'decimal', precision: 18, scale: 6 }) 
	pagamentos: number; 

	@Column({ name: 'saldo_conta', type: 'decimal', precision: 18, scale: 6 }) 
	saldoConta: number; 

	@Column({ name: 'cheque_nao_compensado', type: 'decimal', precision: 18, scale: 6 }) 
	chequeNaoCompensado: number; 

	@Column({ name: 'saldo_disponivel', type: 'decimal', precision: 18, scale: 6 }) 
	saldoDisponivel: number; 


	/**
	* Relations
	*/
	@OneToOne(() => BancoContaCaixaModel)
	@JoinColumn({ name: 'id_banco_conta_caixa' })
	bancoContaCaixaModel: BancoContaCaixaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataFechamento = jsonObj['dataFechamento'];
			this.mesAno = jsonObj['mesAno'];
			this.mes = jsonObj['mes'];
			this.ano = jsonObj['ano'];
			this.saldoAnterior = jsonObj['saldoAnterior'];
			this.recebimentos = jsonObj['recebimentos'];
			this.pagamentos = jsonObj['pagamentos'];
			this.saldoConta = jsonObj['saldoConta'];
			this.chequeNaoCompensado = jsonObj['chequeNaoCompensado'];
			this.saldoDisponivel = jsonObj['saldoDisponivel'];
			if (jsonObj['bancoContaCaixaModel'] != null) {
				this.bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj['bancoContaCaixaModel']);
			}

		}
	}
}