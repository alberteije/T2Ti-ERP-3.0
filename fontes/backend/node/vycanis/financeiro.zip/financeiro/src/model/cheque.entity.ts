import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { TalonarioChequeModel } from '../entities-export';

@Entity({ name: 'cheque' })
export class ChequeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'status_cheque' }) 
	statusCheque: string; 

	@Column({ name: 'data_status' }) 
	dataStatus: Date; 


	/**
	* Relations
	*/
	@ManyToOne(() => TalonarioChequeModel, talonarioChequeModel => talonarioChequeModel.chequeModelList)
	@JoinColumn({ name: 'id_talonario_cheque' })
	talonarioChequeModel: TalonarioChequeModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.statusCheque = jsonObj['statusCheque'];
			this.dataStatus = jsonObj['dataStatus'];
		}
	}
}