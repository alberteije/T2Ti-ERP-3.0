import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'produto' })
export class ProdutoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_tribut_icms_custom_cab' }) 
	idTributIcmsCustomCab: number; 

	@Column({ name: 'id_tribut_grupo_tributario' }) 
	idTributGrupoTributario: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'gtin' }) 
	gtin: string; 

	@Column({ name: 'codigo_interno' }) 
	codigoInterno: string; 

	@Column({ name: 'valor_compra', type: 'decimal', precision: 18, scale: 6 }) 
	valorCompra: number; 

	@Column({ name: 'valor_venda', type: 'decimal', precision: 18, scale: 6 }) 
	valorVenda: number; 

	@Column({ name: 'codigo_ncm' }) 
	codigoNcm: string; 

	@Column({ name: 'estoque_minimo', type: 'decimal', precision: 18, scale: 6 }) 
	estoqueMinimo: number; 

	@Column({ name: 'estoque_maximo', type: 'decimal', precision: 18, scale: 6 }) 
	estoqueMaximo: number; 

	@Column({ name: 'quantidade_estoque', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeEstoque: number; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idTributIcmsCustomCab = jsonObj['idTributIcmsCustomCab'];
			this.idTributGrupoTributario = jsonObj['idTributGrupoTributario'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.gtin = jsonObj['gtin'];
			this.codigoInterno = jsonObj['codigoInterno'];
			this.valorCompra = jsonObj['valorCompra'];
			this.valorVenda = jsonObj['valorVenda'];
			this.codigoNcm = jsonObj['codigoNcm'];
			this.estoqueMinimo = jsonObj['estoqueMinimo'];
			this.estoqueMaximo = jsonObj['estoqueMaximo'];
			this.quantidadeEstoque = jsonObj['quantidadeEstoque'];
			this.dataCadastro = jsonObj['dataCadastro'];
		}
	}
}