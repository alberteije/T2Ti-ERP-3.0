export { InventarioContagemCabModule } from './module/inventario-contagem-cab.module';
export { InventarioAjusteCabModule } from './module/inventario-ajuste-cab.module';
export { ProdutoModule } from './module/produto.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';
