import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { InventarioContagemCabService } from '../service/inventario-contagem-cab.service';
import { InventarioContagemCabModel } from '../model/inventario-contagem-cab.entity';

@Crud({
  model: {
    type: InventarioContagemCabModel,
  },
  query: {
    join: {
			inventarioContagemDetModelList: { eager: true },
    },
  },
})
@Controller('inventario-contagem-cab')
export class InventarioContagemCabController implements CrudController<InventarioContagemCabModel> {
  constructor(public service: InventarioContagemCabService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const inventarioContagemCab = new InventarioContagemCabModel(jsonObj);
		const result = await this.service.save(inventarioContagemCab, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const inventarioContagemCab = new InventarioContagemCabModel(jsonObj);
		const result = await this.service.save(inventarioContagemCab, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}