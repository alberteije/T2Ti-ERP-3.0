import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { InventarioContagemDetModel } from '../entities-export';

@Entity({ name: 'inventario_contagem_cab' })
export class InventarioContagemCabModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_contagem' }) 
	dataContagem: Date; 

	@Column({ name: 'estoque_atualizado' }) 
	estoqueAtualizado: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 


	/**
	* Relations
	*/
	@OneToMany(() => InventarioContagemDetModel, inventarioContagemDetModel => inventarioContagemDetModel.inventarioContagemCabModel, { cascade: true })
	inventarioContagemDetModelList: InventarioContagemDetModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataContagem = jsonObj['dataContagem'];
			this.estoqueAtualizado = jsonObj['estoqueAtualizado'];
			this.tipo = jsonObj['tipo'];
			this.inventarioContagemDetModelList = [];
			let inventarioContagemDetModelJsonList = jsonObj['inventarioContagemDetModelList'];
			if (inventarioContagemDetModelJsonList != null) {
				for (let i = 0; i < inventarioContagemDetModelJsonList.length; i++) {
					let obj = new InventarioContagemDetModel(inventarioContagemDetModelJsonList[i]);
					this.inventarioContagemDetModelList.push(obj);
				}
			}

		}
	}
}