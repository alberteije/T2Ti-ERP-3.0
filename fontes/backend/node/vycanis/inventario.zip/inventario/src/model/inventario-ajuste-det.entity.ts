import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { InventarioAjusteCabModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'inventario_ajuste_det' })
export class InventarioAjusteDetModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_original', type: 'decimal', precision: 18, scale: 6 }) 
	valorOriginal: number; 

	@Column({ name: 'valor_reajuste', type: 'decimal', precision: 18, scale: 6 }) 
	valorReajuste: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => InventarioAjusteCabModel, inventarioAjusteCabModel => inventarioAjusteCabModel.inventarioAjusteDetModelList)
	@JoinColumn({ name: 'id_inventario_ajuste_cab' })
	inventarioAjusteCabModel: InventarioAjusteCabModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorOriginal = jsonObj['valorOriginal'];
			this.valorReajuste = jsonObj['valorReajuste'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}