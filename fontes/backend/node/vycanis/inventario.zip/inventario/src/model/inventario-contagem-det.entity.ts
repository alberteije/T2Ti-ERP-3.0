import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { InventarioContagemCabModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'inventario_contagem_det' })
export class InventarioContagemDetModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'contagem01', type: 'decimal', precision: 18, scale: 6 }) 
	contagem01: number; 

	@Column({ name: 'contagem02', type: 'decimal', precision: 18, scale: 6 }) 
	contagem02: number; 

	@Column({ name: 'contagem03', type: 'decimal', precision: 18, scale: 6 }) 
	contagem03: number; 

	@Column({ name: 'fechado_contagem' }) 
	fechadoContagem: string; 

	@Column({ name: 'quantidade_sistema', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeSistema: number; 

	@Column({ name: 'acuracidade', type: 'decimal', precision: 18, scale: 6 }) 
	acuracidade: number; 

	@Column({ name: 'divergencia', type: 'decimal', precision: 18, scale: 6 }) 
	divergencia: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => InventarioContagemCabModel, inventarioContagemCabModel => inventarioContagemCabModel.inventarioContagemDetModelList)
	@JoinColumn({ name: 'id_inventario_contagem_cab' })
	inventarioContagemCabModel: InventarioContagemCabModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.contagem01 = jsonObj['contagem01'];
			this.contagem02 = jsonObj['contagem02'];
			this.contagem03 = jsonObj['contagem03'];
			this.fechadoContagem = jsonObj['fechadoContagem'];
			this.quantidadeSistema = jsonObj['quantidadeSistema'];
			this.acuracidade = jsonObj['acuracidade'];
			this.divergencia = jsonObj['divergencia'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}