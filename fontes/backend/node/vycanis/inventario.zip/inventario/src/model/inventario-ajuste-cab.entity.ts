import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { InventarioAjusteDetModel } from '../entities-export';

@Entity({ name: 'inventario_ajuste_cab' })
export class InventarioAjusteCabModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_ajuste' }) 
	dataAjuste: Date; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'taxa', type: 'decimal', precision: 10, scale: 2 }) 
	taxa: number; 

	@Column({ name: 'justificativa' }) 
	justificativa: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_view_pessoa_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToMany(() => InventarioAjusteDetModel, inventarioAjusteDetModel => inventarioAjusteDetModel.inventarioAjusteCabModel, { cascade: true })
	inventarioAjusteDetModelList: InventarioAjusteDetModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataAjuste = jsonObj['dataAjuste'];
			this.tipo = jsonObj['tipo'];
			this.taxa = jsonObj['taxa'];
			this.justificativa = jsonObj['justificativa'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.inventarioAjusteDetModelList = [];
			let inventarioAjusteDetModelJsonList = jsonObj['inventarioAjusteDetModelList'];
			if (inventarioAjusteDetModelJsonList != null) {
				for (let i = 0; i < inventarioAjusteDetModelJsonList.length; i++) {
					let obj = new InventarioAjusteDetModel(inventarioAjusteDetModelJsonList[i]);
					this.inventarioAjusteDetModelList.push(obj);
				}
			}

		}
	}
}