import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { InventarioAjusteCabService } from '../service/inventario-ajuste-cab.service';
import { InventarioAjusteCabModel } from '../model/inventario-ajuste-cab.entity';

@Crud({
  model: {
    type: InventarioAjusteCabModel,
  },
  query: {
    join: {
			viewPessoaColaboradorModel: { eager: true },
			inventarioAjusteDetModelList: { eager: true },
    },
  },
})
@Controller('inventario-ajuste-cab')
export class InventarioAjusteCabController implements CrudController<InventarioAjusteCabModel> {
  constructor(public service: InventarioAjusteCabService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const inventarioAjusteCab = new InventarioAjusteCabModel(jsonObj);
		const result = await this.service.save(inventarioAjusteCab, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const inventarioAjusteCab = new InventarioAjusteCabModel(jsonObj);
		const result = await this.service.save(inventarioAjusteCab, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}