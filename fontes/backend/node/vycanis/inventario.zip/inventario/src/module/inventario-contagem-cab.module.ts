import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InventarioContagemCabController } from '../controller/inventario-contagem-cab.controller';
import { InventarioContagemCabService } from '../service/inventario-contagem-cab.service';
import { InventarioContagemCabModel } from '../model/inventario-contagem-cab.entity';

@Module({
    imports: [TypeOrmModule.forFeature([InventarioContagemCabModel])],
    controllers: [InventarioContagemCabController],
    providers: [InventarioContagemCabService],
})
export class InventarioContagemCabModule { }
