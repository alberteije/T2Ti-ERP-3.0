import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InventarioAjusteCabController } from '../controller/inventario-ajuste-cab.controller';
import { InventarioAjusteCabService } from '../service/inventario-ajuste-cab.service';
import { InventarioAjusteCabModel } from '../model/inventario-ajuste-cab.entity';

@Module({
    imports: [TypeOrmModule.forFeature([InventarioAjusteCabModel])],
    controllers: [InventarioAjusteCabController],
    providers: [InventarioAjusteCabService],
})
export class InventarioAjusteCabModule { }
