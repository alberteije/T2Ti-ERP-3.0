import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { WmsRecebimentoCabecalhoModule } from './modules-export';
import { WmsCaixaModule } from './modules-export';
import { WmsOrdemSeparacaoCabModule } from './modules-export';
import { ProdutoModule } from './modules-export';
import { WmsAgendamentoModule } from './modules-export';
import { WmsParametroModule } from './modules-export';
import { WmsRuaModule } from './modules-export';
import { WmsEstanteModule } from './modules-export';
import { WmsExpedicaoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';
import { AuditoriaModule } from './modules-export';
import { UsuarioTokenModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			WmsRecebimentoCabecalhoModule,
			WmsCaixaModule,
			WmsOrdemSeparacaoCabModule,
			ProdutoModule,
			WmsAgendamentoModule,
			WmsParametroModule,
			WmsRuaModule,
			WmsEstanteModule,
			WmsExpedicaoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
      LoginModule,
      AuditoriaModule,
      UsuarioTokenModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],

  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}