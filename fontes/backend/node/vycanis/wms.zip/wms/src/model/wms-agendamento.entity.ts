import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'wms_agendamento' })
export class WmsAgendamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_operacao' }) 
	dataOperacao: Date; 

	@Column({ name: 'hora_operacao' }) 
	horaOperacao: string; 

	@Column({ name: 'local_operacao' }) 
	localOperacao: string; 

	@Column({ name: 'quantidade_volume' }) 
	quantidadeVolume: number; 

	@Column({ name: 'peso_total_volume', type: 'decimal', precision: 18, scale: 6 }) 
	pesoTotalVolume: number; 

	@Column({ name: 'quantidade_pessoa' }) 
	quantidadePessoa: number; 

	@Column({ name: 'quantidade_hora' }) 
	quantidadeHora: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataOperacao = jsonObj['dataOperacao'];
			this.horaOperacao = jsonObj['horaOperacao'];
			this.localOperacao = jsonObj['localOperacao'];
			this.quantidadeVolume = jsonObj['quantidadeVolume'];
			this.pesoTotalVolume = jsonObj['pesoTotalVolume'];
			this.quantidadePessoa = jsonObj['quantidadePessoa'];
			this.quantidadeHora = jsonObj['quantidadeHora'];
		}
	}
}