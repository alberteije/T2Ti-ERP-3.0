import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { WmsCaixaModel } from '../entities-export';
import { WmsRecebimentoDetalheModel } from '../entities-export';

@Entity({ name: 'wms_armazenamento' })
export class WmsArmazenamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade' }) 
	quantidade: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => WmsCaixaModel, wmsCaixaModel => wmsCaixaModel.wmsArmazenamentoModelList)
	@JoinColumn({ name: 'id_wms_caixa' })
	wmsCaixaModel: WmsCaixaModel;

	@OneToOne(() => WmsRecebimentoDetalheModel)
	@JoinColumn({ name: 'id_wms_recebimento_detalhe' })
	wmsRecebimentoDetalheModel: WmsRecebimentoDetalheModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			if (jsonObj['wmsRecebimentoDetalheModel'] != null) {
				this.wmsRecebimentoDetalheModel = new WmsRecebimentoDetalheModel(jsonObj['wmsRecebimentoDetalheModel']);
			}

		}
	}
}