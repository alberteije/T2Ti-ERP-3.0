import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'wms_parametro' })
export class WmsParametroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'hora_por_volume' }) 
	horaPorVolume: number; 

	@Column({ name: 'pessoa_por_volume' }) 
	pessoaPorVolume: number; 

	@Column({ name: 'hora_por_peso' }) 
	horaPorPeso: number; 

	@Column({ name: 'pessoa_por_peso' }) 
	pessoaPorPeso: number; 

	@Column({ name: 'item_diferente_caixa' }) 
	itemDiferenteCaixa: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.horaPorVolume = jsonObj['horaPorVolume'];
			this.pessoaPorVolume = jsonObj['pessoaPorVolume'];
			this.horaPorPeso = jsonObj['horaPorPeso'];
			this.pessoaPorPeso = jsonObj['pessoaPorPeso'];
			this.itemDiferenteCaixa = jsonObj['itemDiferenteCaixa'];
		}
	}
}