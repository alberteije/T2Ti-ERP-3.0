import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { WmsArmazenamentoModel } from '../entities-export';
import { WmsEstanteModel } from '../entities-export';

@Entity({ name: 'wms_caixa' })
export class WmsCaixaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'altura' }) 
	altura: number; 

	@Column({ name: 'largura' }) 
	largura: number; 

	@Column({ name: 'profundidade' }) 
	profundidade: number; 


	/**
	* Relations
	*/
	@OneToMany(() => WmsArmazenamentoModel, wmsArmazenamentoModel => wmsArmazenamentoModel.wmsCaixaModel, { cascade: true })
	wmsArmazenamentoModelList: WmsArmazenamentoModel[];

	@OneToOne(() => WmsEstanteModel)
	@JoinColumn({ name: 'id_wms_estante' })
	wmsEstanteModel: WmsEstanteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.altura = jsonObj['altura'];
			this.largura = jsonObj['largura'];
			this.profundidade = jsonObj['profundidade'];
			if (jsonObj['wmsEstanteModel'] != null) {
				this.wmsEstanteModel = new WmsEstanteModel(jsonObj['wmsEstanteModel']);
			}

			this.wmsArmazenamentoModelList = [];
			let wmsArmazenamentoModelJsonList = jsonObj['wmsArmazenamentoModelList'];
			if (wmsArmazenamentoModelJsonList != null) {
				for (let i = 0; i < wmsArmazenamentoModelJsonList.length; i++) {
					let obj = new WmsArmazenamentoModel(wmsArmazenamentoModelJsonList[i]);
					this.wmsArmazenamentoModelList.push(obj);
				}
			}

		}
	}
}