import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { WmsOrdemSeparacaoDetModel } from '../entities-export';

@Entity({ name: 'wms_ordem_separacao_cab' })
export class WmsOrdemSeparacaoCabModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'origem' }) 
	origem: string; 

	@Column({ name: 'data_solicitacao' }) 
	dataSolicitacao: Date; 

	@Column({ name: 'data_limite' }) 
	dataLimite: Date; 


	/**
	* Relations
	*/
	@OneToMany(() => WmsOrdemSeparacaoDetModel, wmsOrdemSeparacaoDetModel => wmsOrdemSeparacaoDetModel.wmsOrdemSeparacaoCabModel, { cascade: true })
	wmsOrdemSeparacaoDetModelList: WmsOrdemSeparacaoDetModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.origem = jsonObj['origem'];
			this.dataSolicitacao = jsonObj['dataSolicitacao'];
			this.dataLimite = jsonObj['dataLimite'];
			this.wmsOrdemSeparacaoDetModelList = [];
			let wmsOrdemSeparacaoDetModelJsonList = jsonObj['wmsOrdemSeparacaoDetModelList'];
			if (wmsOrdemSeparacaoDetModelJsonList != null) {
				for (let i = 0; i < wmsOrdemSeparacaoDetModelJsonList.length; i++) {
					let obj = new WmsOrdemSeparacaoDetModel(wmsOrdemSeparacaoDetModelJsonList[i]);
					this.wmsOrdemSeparacaoDetModelList.push(obj);
				}
			}

		}
	}
}