import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { WmsRecebimentoCabecalhoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'wms_recebimento_detalhe' })
export class WmsRecebimentoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade_volume' }) 
	quantidadeVolume: number; 

	@Column({ name: 'quantidade_item_por_volume' }) 
	quantidadeItemPorVolume: number; 

	@Column({ name: 'quantidade_recebida' }) 
	quantidadeRecebida: number; 

	@Column({ name: 'destino' }) 
	destino: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => WmsRecebimentoCabecalhoModel, wmsRecebimentoCabecalhoModel => wmsRecebimentoCabecalhoModel.wmsRecebimentoDetalheModelList)
	@JoinColumn({ name: 'id_wms_recebimento_cabecalho' })
	wmsRecebimentoCabecalhoModel: WmsRecebimentoCabecalhoModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidadeVolume = jsonObj['quantidadeVolume'];
			this.quantidadeItemPorVolume = jsonObj['quantidadeItemPorVolume'];
			this.quantidadeRecebida = jsonObj['quantidadeRecebida'];
			this.destino = jsonObj['destino'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}