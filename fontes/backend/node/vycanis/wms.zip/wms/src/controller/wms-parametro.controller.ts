import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { WmsParametroService } from '../service/wms-parametro.service';
import { WmsParametroModel } from '../model/wms-parametro.entity';

@Crud({
  model: {
    type: WmsParametroModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('wms-parametro')
export class WmsParametroController implements CrudController<WmsParametroModel> {
  constructor(public service: WmsParametroService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsParametroModel = new WmsParametroModel(jsonObj);
		const result = await this.service.save(wmsParametroModel);
		return result;
	}  


}


















