import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { WmsEstanteService } from '../service/wms-estante.service';
import { WmsEstanteModel } from '../model/wms-estante.entity';

@Crud({
  model: {
    type: WmsEstanteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('wms-estante')
export class WmsEstanteController implements CrudController<WmsEstanteModel> {
  constructor(public service: WmsEstanteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsEstanteModel = new WmsEstanteModel(jsonObj);
		const result = await this.service.save(wmsEstanteModel);
		return result;
	}  


}


















