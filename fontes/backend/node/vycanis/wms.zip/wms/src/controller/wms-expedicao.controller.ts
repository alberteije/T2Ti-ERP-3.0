import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { WmsExpedicaoService } from '../service/wms-expedicao.service';
import { WmsExpedicaoModel } from '../model/wms-expedicao.entity';

@Crud({
  model: {
    type: WmsExpedicaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('wms-expedicao')
export class WmsExpedicaoController implements CrudController<WmsExpedicaoModel> {
  constructor(public service: WmsExpedicaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsExpedicaoModel = new WmsExpedicaoModel(jsonObj);
		const result = await this.service.save(wmsExpedicaoModel);
		return result;
	}  


}


















