import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProdutoController } from '../controller/produto.controller';
import { ProdutoService } from '../service/produto.service';
import { ProdutoModel } from '../model/produto.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ProdutoModel])],
    controllers: [ProdutoController],
    providers: [ProdutoService],
})
export class ProdutoModule { }
