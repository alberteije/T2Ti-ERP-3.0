import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsEstanteController } from '../controller/wms-estante.controller';
import { WmsEstanteService } from '../service/wms-estante.service';
import { WmsEstanteModel } from '../model/wms-estante.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsEstanteModel])],
    controllers: [WmsEstanteController],
    providers: [WmsEstanteService],
})
export class WmsEstanteModule { }
