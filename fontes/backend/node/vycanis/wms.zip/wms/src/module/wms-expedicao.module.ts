import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsExpedicaoController } from '../controller/wms-expedicao.controller';
import { WmsExpedicaoService } from '../service/wms-expedicao.service';
import { WmsExpedicaoModel } from '../model/wms-expedicao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsExpedicaoModel])],
    controllers: [WmsExpedicaoController],
    providers: [WmsExpedicaoService],
})
export class WmsExpedicaoModule { }
