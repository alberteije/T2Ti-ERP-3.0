import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsParametroController } from '../controller/wms-parametro.controller';
import { WmsParametroService } from '../service/wms-parametro.service';
import { WmsParametroModel } from '../model/wms-parametro.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsParametroModel])],
    controllers: [WmsParametroController],
    providers: [WmsParametroService],
})
export class WmsParametroModule { }
