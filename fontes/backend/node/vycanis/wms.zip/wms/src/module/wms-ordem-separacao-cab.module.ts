import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsOrdemSeparacaoCabController } from '../controller/wms-ordem-separacao-cab.controller';
import { WmsOrdemSeparacaoCabService } from '../service/wms-ordem-separacao-cab.service';
import { WmsOrdemSeparacaoCabModel } from '../model/wms-ordem-separacao-cab.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsOrdemSeparacaoCabModel])],
    controllers: [WmsOrdemSeparacaoCabController],
    providers: [WmsOrdemSeparacaoCabService],
})
export class WmsOrdemSeparacaoCabModule { }
