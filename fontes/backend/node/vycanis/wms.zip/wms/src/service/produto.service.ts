import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ProdutoModel } from '../entities-export';

@Injectable()
export class ProdutoService extends TypeOrmCrudService<ProdutoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ProdutoModel)
    private readonly repository: Repository<ProdutoModel>
  ) {
    super(repository);
  }

	async save(produtoModel: ProdutoModel): Promise<ProdutoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(produtoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
