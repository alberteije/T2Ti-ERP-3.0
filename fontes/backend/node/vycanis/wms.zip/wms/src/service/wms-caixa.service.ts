import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { WmsCaixaModel } from '../entities-export';

@Injectable()
export class WmsCaixaService extends TypeOrmCrudService<WmsCaixaModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(WmsCaixaModel) 
    private readonly repository: Repository<WmsCaixaModel>,
  ) {
    super(repository);
  }

	async save(wmsCaixaModel: WmsCaixaModel, operation: string): Promise<WmsCaixaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, wmsCaixaModel.id);
      }

      const resultObj = await queryRunner.manager.save(wmsCaixaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(WmsCaixaModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from wms_armazenamento where id_wms_caixa=' + id); 

	}
	
}