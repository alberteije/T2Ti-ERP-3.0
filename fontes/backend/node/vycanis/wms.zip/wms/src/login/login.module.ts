import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaUsuarioModel } from '../model/view-pessoa-usuario.entity';
import { UsuarioTokenModel } from '../model/usuario-token.entity';
import { LoginController } from './login.controller';
import { LoginService } from './login.service';
import { UsuarioTokenService } from '../service/usuario-token.service';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaUsuarioModel, UsuarioTokenModel])],
    controllers: [LoginController],
    providers: [LoginService, UsuarioTokenService],
    exports: [LoginService]
})
export class LoginModule { }
