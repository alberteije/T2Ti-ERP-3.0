import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProdutoModel } from '../entities-export';
import { WmsOrdemSeparacaoCabModel } from '../entities-export';

@Entity({ name: 'wms_ordem_separacao_det' })
export class WmsOrdemSeparacaoDetModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade' }) 
	quantidade: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;

	@ManyToOne(() => WmsOrdemSeparacaoCabModel, wmsOrdemSeparacaoCabModel => wmsOrdemSeparacaoCabModel.wmsOrdemSeparacaoDetModelList)
	@JoinColumn({ name: 'id_wms_ordem_separacao_cab' })
	wmsOrdemSeparacaoCabModel: WmsOrdemSeparacaoCabModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}