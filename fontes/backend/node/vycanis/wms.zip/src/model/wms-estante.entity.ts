import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { WmsRuaModel } from '../entities-export';

@Entity({ name: 'wms_estante' })
export class WmsEstanteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'quantidade_caixa' }) 
	quantidadeCaixa: number; 


	/**
	* Relations
	*/
	@OneToOne(() => WmsRuaModel)
	@JoinColumn({ name: 'id_wms_rua' })
	wmsRuaModel: WmsRuaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.quantidadeCaixa = jsonObj['quantidadeCaixa'];
			if (jsonObj['wmsRuaModel'] != null) {
				this.wmsRuaModel = new WmsRuaModel(jsonObj['wmsRuaModel']);
			}

		}
	}
}