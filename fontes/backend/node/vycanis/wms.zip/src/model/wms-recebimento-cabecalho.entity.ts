import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { WmsRecebimentoDetalheModel } from '../entities-export';
import { WmsAgendamentoModel } from '../entities-export';

@Entity({ name: 'wms_recebimento_cabecalho' })
export class WmsRecebimentoCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_recebimento' }) 
	dataRecebimento: Date; 

	@Column({ name: 'hora_inicio' }) 
	horaInicio: string; 

	@Column({ name: 'hora_fim' }) 
	horaFim: string; 

	@Column({ name: 'volume_recebido' }) 
	volumeRecebido: number; 

	@Column({ name: 'peso_recebido', type: 'decimal', precision: 18, scale: 6 }) 
	pesoRecebido: number; 

	@Column({ name: 'inconsistencia' }) 
	inconsistencia: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => WmsRecebimentoDetalheModel, wmsRecebimentoDetalheModel => wmsRecebimentoDetalheModel.wmsRecebimentoCabecalhoModel, { cascade: true })
	wmsRecebimentoDetalheModelList: WmsRecebimentoDetalheModel[];

	@OneToOne(() => WmsAgendamentoModel)
	@JoinColumn({ name: 'id_wms_agendamento' })
	wmsAgendamentoModel: WmsAgendamentoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataRecebimento = jsonObj['dataRecebimento'];
			this.horaInicio = jsonObj['horaInicio'];
			this.horaFim = jsonObj['horaFim'];
			this.volumeRecebido = jsonObj['volumeRecebido'];
			this.pesoRecebido = jsonObj['pesoRecebido'];
			this.inconsistencia = jsonObj['inconsistencia'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['wmsAgendamentoModel'] != null) {
				this.wmsAgendamentoModel = new WmsAgendamentoModel(jsonObj['wmsAgendamentoModel']);
			}

			this.wmsRecebimentoDetalheModelList = [];
			let wmsRecebimentoDetalheModelJsonList = jsonObj['wmsRecebimentoDetalheModelList'];
			if (wmsRecebimentoDetalheModelJsonList != null) {
				for (let i = 0; i < wmsRecebimentoDetalheModelJsonList.length; i++) {
					let obj = new WmsRecebimentoDetalheModel(wmsRecebimentoDetalheModelJsonList[i]);
					this.wmsRecebimentoDetalheModelList.push(obj);
				}
			}

		}
	}
}