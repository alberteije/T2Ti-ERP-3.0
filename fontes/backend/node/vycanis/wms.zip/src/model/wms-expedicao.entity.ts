import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { WmsOrdemSeparacaoDetModel } from '../entities-export';
import { WmsArmazenamentoModel } from '../entities-export';

@Entity({ name: 'wms_expedicao' })
export class WmsExpedicaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade' }) 
	quantidade: number; 

	@Column({ name: 'data_saida' }) 
	dataSaida: Date; 


	/**
	* Relations
	*/
	@OneToOne(() => WmsOrdemSeparacaoDetModel)
	@JoinColumn({ name: 'id_wms_ordem_separacao_det' })
	wmsOrdemSeparacaoDetModel: WmsOrdemSeparacaoDetModel;

	@OneToOne(() => WmsArmazenamentoModel)
	@JoinColumn({ name: 'id_wms_armazenamento' })
	wmsArmazenamentoModel: WmsArmazenamentoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			this.dataSaida = jsonObj['dataSaida'];
			if (jsonObj['wmsOrdemSeparacaoDetModel'] != null) {
				this.wmsOrdemSeparacaoDetModel = new WmsOrdemSeparacaoDetModel(jsonObj['wmsOrdemSeparacaoDetModel']);
			}

			if (jsonObj['wmsArmazenamentoModel'] != null) {
				this.wmsArmazenamentoModel = new WmsArmazenamentoModel(jsonObj['wmsArmazenamentoModel']);
			}

		}
	}
}