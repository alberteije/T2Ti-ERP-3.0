import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { WmsAgendamentoService } from '../service/wms-agendamento.service';
import { WmsAgendamentoModel } from '../model/wms-agendamento.entity';

@Crud({
  model: {
    type: WmsAgendamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('wms-agendamento')
export class WmsAgendamentoController implements CrudController<WmsAgendamentoModel> {
  constructor(public service: WmsAgendamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsAgendamentoModel = new WmsAgendamentoModel(jsonObj);
		const result = await this.service.save(wmsAgendamentoModel);
		return result;
	}  


}


















