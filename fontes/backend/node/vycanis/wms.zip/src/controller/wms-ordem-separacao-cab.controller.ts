import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { WmsOrdemSeparacaoCabService } from '../service/wms-ordem-separacao-cab.service';
import { WmsOrdemSeparacaoCabModel } from '../model/wms-ordem-separacao-cab.entity';

@Crud({
  model: {
    type: WmsOrdemSeparacaoCabModel,
  },
  query: {
    join: {
			wmsOrdemSeparacaoDetModelList: { eager: true },
    },
  },
})
@Controller('wms-ordem-separacao-cab')
export class WmsOrdemSeparacaoCabController implements CrudController<WmsOrdemSeparacaoCabModel> {
  constructor(public service: WmsOrdemSeparacaoCabService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsOrdemSeparacaoCab = new WmsOrdemSeparacaoCabModel(jsonObj);
		const result = await this.service.save(wmsOrdemSeparacaoCab, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsOrdemSeparacaoCab = new WmsOrdemSeparacaoCabModel(jsonObj);
		const result = await this.service.save(wmsOrdemSeparacaoCab, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}