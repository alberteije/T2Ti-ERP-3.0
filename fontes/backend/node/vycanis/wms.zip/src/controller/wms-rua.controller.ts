import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { WmsRuaService } from '../service/wms-rua.service';
import { WmsRuaModel } from '../model/wms-rua.entity';

@Crud({
  model: {
    type: WmsRuaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('wms-rua')
export class WmsRuaController implements CrudController<WmsRuaModel> {
  constructor(public service: WmsRuaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsRuaModel = new WmsRuaModel(jsonObj);
		const result = await this.service.save(wmsRuaModel);
		return result;
	}  


}


















