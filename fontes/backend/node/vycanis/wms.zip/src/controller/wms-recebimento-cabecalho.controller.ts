import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { WmsRecebimentoCabecalhoService } from '../service/wms-recebimento-cabecalho.service';
import { WmsRecebimentoCabecalhoModel } from '../model/wms-recebimento-cabecalho.entity';

@Crud({
  model: {
    type: WmsRecebimentoCabecalhoModel,
  },
  query: {
    join: {
			wmsRecebimentoDetalheModelList: { eager: true },
			wmsAgendamentoModel: { eager: true },
    },
  },
})
@Controller('wms-recebimento-cabecalho')
export class WmsRecebimentoCabecalhoController implements CrudController<WmsRecebimentoCabecalhoModel> {
  constructor(public service: WmsRecebimentoCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsRecebimentoCabecalho = new WmsRecebimentoCabecalhoModel(jsonObj);
		const result = await this.service.save(wmsRecebimentoCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsRecebimentoCabecalho = new WmsRecebimentoCabecalhoModel(jsonObj);
		const result = await this.service.save(wmsRecebimentoCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}