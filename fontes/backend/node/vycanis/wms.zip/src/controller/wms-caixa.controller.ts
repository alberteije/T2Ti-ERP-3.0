import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { WmsCaixaService } from '../service/wms-caixa.service';
import { WmsCaixaModel } from '../model/wms-caixa.entity';

@Crud({
  model: {
    type: WmsCaixaModel,
  },
  query: {
    join: {
			wmsArmazenamentoModelList: { eager: true },
			wmsEstanteModel: { eager: true },
    },
  },
})
@Controller('wms-caixa')
export class WmsCaixaController implements CrudController<WmsCaixaModel> {
  constructor(public service: WmsCaixaService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsCaixa = new WmsCaixaModel(jsonObj);
		const result = await this.service.save(wmsCaixa, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const wmsCaixa = new WmsCaixaModel(jsonObj);
		const result = await this.service.save(wmsCaixa, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}