import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { WmsRecebimentoCabecalhoModel } from '../entities-export';

@Injectable()
export class WmsRecebimentoCabecalhoService extends TypeOrmCrudService<WmsRecebimentoCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(WmsRecebimentoCabecalhoModel) 
    private readonly repository: Repository<WmsRecebimentoCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(wmsRecebimentoCabecalhoModel: WmsRecebimentoCabecalhoModel, operation: string): Promise<WmsRecebimentoCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, wmsRecebimentoCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(wmsRecebimentoCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(WmsRecebimentoCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from wms_recebimento_detalhe where id_wms_recebimento_cabecalho=' + id); 

	}
	
}