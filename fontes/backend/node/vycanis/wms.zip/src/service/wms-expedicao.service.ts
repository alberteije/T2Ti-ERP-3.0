import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { WmsExpedicaoModel } from '../entities-export';

@Injectable()
export class WmsExpedicaoService extends TypeOrmCrudService<WmsExpedicaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(WmsExpedicaoModel)
    private readonly repository: Repository<WmsExpedicaoModel>
  ) {
    super(repository);
  }

	async save(wmsExpedicaoModel: WmsExpedicaoModel): Promise<WmsExpedicaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(wmsExpedicaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
