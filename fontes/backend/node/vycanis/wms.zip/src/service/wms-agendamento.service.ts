import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { WmsAgendamentoModel } from '../entities-export';

@Injectable()
export class WmsAgendamentoService extends TypeOrmCrudService<WmsAgendamentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(WmsAgendamentoModel)
    private readonly repository: Repository<WmsAgendamentoModel>
  ) {
    super(repository);
  }

	async save(wmsAgendamentoModel: WmsAgendamentoModel): Promise<WmsAgendamentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(wmsAgendamentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
