import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { WmsRuaModel } from '../entities-export';

@Injectable()
export class WmsRuaService extends TypeOrmCrudService<WmsRuaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(WmsRuaModel)
    private readonly repository: Repository<WmsRuaModel>
  ) {
    super(repository);
  }

	async save(wmsRuaModel: WmsRuaModel): Promise<WmsRuaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(wmsRuaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
