import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsCaixaController } from '../controller/wms-caixa.controller';
import { WmsCaixaService } from '../service/wms-caixa.service';
import { WmsCaixaModel } from '../model/wms-caixa.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsCaixaModel])],
    controllers: [WmsCaixaController],
    providers: [WmsCaixaService],
})
export class WmsCaixaModule { }
