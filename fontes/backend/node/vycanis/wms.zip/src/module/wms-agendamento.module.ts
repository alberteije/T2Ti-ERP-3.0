import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsAgendamentoController } from '../controller/wms-agendamento.controller';
import { WmsAgendamentoService } from '../service/wms-agendamento.service';
import { WmsAgendamentoModel } from '../model/wms-agendamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsAgendamentoModel])],
    controllers: [WmsAgendamentoController],
    providers: [WmsAgendamentoService],
})
export class WmsAgendamentoModule { }
