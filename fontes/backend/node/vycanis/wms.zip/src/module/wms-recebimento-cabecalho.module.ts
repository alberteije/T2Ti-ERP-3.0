import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsRecebimentoCabecalhoController } from '../controller/wms-recebimento-cabecalho.controller';
import { WmsRecebimentoCabecalhoService } from '../service/wms-recebimento-cabecalho.service';
import { WmsRecebimentoCabecalhoModel } from '../model/wms-recebimento-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsRecebimentoCabecalhoModel])],
    controllers: [WmsRecebimentoCabecalhoController],
    providers: [WmsRecebimentoCabecalhoService],
})
export class WmsRecebimentoCabecalhoModule { }
