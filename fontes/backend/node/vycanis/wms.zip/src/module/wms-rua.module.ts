import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WmsRuaController } from '../controller/wms-rua.controller';
import { WmsRuaService } from '../service/wms-rua.service';
import { WmsRuaModel } from '../model/wms-rua.entity';

@Module({
    imports: [TypeOrmModule.forFeature([WmsRuaModel])],
    controllers: [WmsRuaController],
    providers: [WmsRuaService],
})
export class WmsRuaModule { }
