import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MdfeInformacaoNfeController } from '../controller/mdfe-informacao-nfe.controller';
import { MdfeInformacaoNfeService } from '../service/mdfe-informacao-nfe.service';
import { MdfeInformacaoNfeModel } from '../model/mdfe-informacao-nfe.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MdfeInformacaoNfeModel])],
    controllers: [MdfeInformacaoNfeController],
    providers: [MdfeInformacaoNfeService],
})
export class MdfeInformacaoNfeModule { }
