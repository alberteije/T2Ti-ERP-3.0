import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MdfeRodoviarioPedagioController } from '../controller/mdfe-rodoviario-pedagio.controller';
import { MdfeRodoviarioPedagioService } from '../service/mdfe-rodoviario-pedagio.service';
import { MdfeRodoviarioPedagioModel } from '../model/mdfe-rodoviario-pedagio.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MdfeRodoviarioPedagioModel])],
    controllers: [MdfeRodoviarioPedagioController],
    providers: [MdfeRodoviarioPedagioService],
})
export class MdfeRodoviarioPedagioModule { }
