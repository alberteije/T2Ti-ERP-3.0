import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MdfeInformacaoCteController } from '../controller/mdfe-informacao-cte.controller';
import { MdfeInformacaoCteService } from '../service/mdfe-informacao-cte.service';
import { MdfeInformacaoCteModel } from '../model/mdfe-informacao-cte.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MdfeInformacaoCteModel])],
    controllers: [MdfeInformacaoCteController],
    providers: [MdfeInformacaoCteService],
})
export class MdfeInformacaoCteModule { }
