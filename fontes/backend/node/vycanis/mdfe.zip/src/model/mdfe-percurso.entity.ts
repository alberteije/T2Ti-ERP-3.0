import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'mdfe_percurso' })
export class MdfePercursoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'uf_percurso' }) 
	ufPercurso: string; 

	@Column({ name: 'data_inicio_viagem' }) 
	dataInicioViagem: Date; 


	/**
	* Relations
	*/
	@ManyToOne(() => MdfeCabecalhoModel, mdfeCabecalhoModel => mdfeCabecalhoModel.mdfePercursoModelList)
	@JoinColumn({ name: 'id_mdfe_cabecalho' })
	mdfeCabecalhoModel: MdfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ufPercurso = jsonObj['ufPercurso'];
			this.dataInicioViagem = jsonObj['dataInicioViagem'];
		}
	}
}