import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'mdfe_emitente' })
export class MdfeEmitenteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'fantasia' }) 
	fantasia: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'ie' }) 
	ie: number; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: string; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 

	@Column({ name: 'cep' }) 
	cep: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'telefone' }) 
	telefone: string; 

	@Column({ name: 'email' }) 
	email: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => MdfeCabecalhoModel, mdfeCabecalhoModel => mdfeCabecalhoModel.mdfeEmitenteModelList)
	@JoinColumn({ name: 'id_mdfe_cabecalho' })
	mdfeCabecalhoModel: MdfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.fantasia = jsonObj['fantasia'];
			this.cnpj = jsonObj['cnpj'];
			this.ie = jsonObj['ie'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
			this.cep = jsonObj['cep'];
			this.uf = jsonObj['uf'];
			this.telefone = jsonObj['telefone'];
			this.email = jsonObj['email'];
		}
	}
}