import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeMunicipioDescarregaModel } from '../entities-export';

@Entity({ name: 'mdfe_informacao_cte' })
export class MdfeInformacaoCteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'chave_cte' }) 
	chaveCte: string; 

	@Column({ name: 'segundo_codigo_barra' }) 
	segundoCodigoBarra: string; 

	@Column({ name: 'indicador_reentrega' }) 
	indicadorReentrega: number; 


	/**
	* Relations
	*/
	@OneToOne(() => MdfeMunicipioDescarregaModel)
	@JoinColumn({ name: 'id_mdfe_municipio_descarrega' })
	mdfeMunicipioDescarregaModel: MdfeMunicipioDescarregaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.chaveCte = jsonObj['chaveCte'];
			this.segundoCodigoBarra = jsonObj['segundoCodigoBarra'];
			this.indicadorReentrega = jsonObj['indicadorReentrega'];
			if (jsonObj['mdfeMunicipioDescarregaModel'] != null) {
				this.mdfeMunicipioDescarregaModel = new MdfeMunicipioDescarregaModel(jsonObj['mdfeMunicipioDescarregaModel']);
			}

		}
	}
}