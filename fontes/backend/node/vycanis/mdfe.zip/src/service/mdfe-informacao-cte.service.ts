import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { MdfeInformacaoCteModel } from '../entities-export';

@Injectable()
export class MdfeInformacaoCteService extends TypeOrmCrudService<MdfeInformacaoCteModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(MdfeInformacaoCteModel)
    private readonly repository: Repository<MdfeInformacaoCteModel>
  ) {
    super(repository);
  }

	async save(mdfeInformacaoCteModel: MdfeInformacaoCteModel): Promise<MdfeInformacaoCteModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(mdfeInformacaoCteModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
