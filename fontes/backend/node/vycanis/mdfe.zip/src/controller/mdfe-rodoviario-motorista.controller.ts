import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { MdfeRodoviarioMotoristaService } from '../service/mdfe-rodoviario-motorista.service';
import { MdfeRodoviarioMotoristaModel } from '../model/mdfe-rodoviario-motorista.entity';

@Crud({
  model: {
    type: MdfeRodoviarioMotoristaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('mdfe-rodoviario-motorista')
export class MdfeRodoviarioMotoristaController implements CrudController<MdfeRodoviarioMotoristaModel> {
  constructor(public service: MdfeRodoviarioMotoristaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeRodoviarioMotoristaModel = new MdfeRodoviarioMotoristaModel(jsonObj);
		const result = await this.service.save(mdfeRodoviarioMotoristaModel);
		return result;
	}  


}


















