import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { MdfeRodoviarioCiotService } from '../service/mdfe-rodoviario-ciot.service';
import { MdfeRodoviarioCiotModel } from '../model/mdfe-rodoviario-ciot.entity';

@Crud({
  model: {
    type: MdfeRodoviarioCiotModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('mdfe-rodoviario-ciot')
export class MdfeRodoviarioCiotController implements CrudController<MdfeRodoviarioCiotModel> {
  constructor(public service: MdfeRodoviarioCiotService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeRodoviarioCiotModel = new MdfeRodoviarioCiotModel(jsonObj);
		const result = await this.service.save(mdfeRodoviarioCiotModel);
		return result;
	}  


}


















