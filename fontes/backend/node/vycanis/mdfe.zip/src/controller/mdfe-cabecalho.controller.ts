import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { MdfeCabecalhoService } from '../service/mdfe-cabecalho.service';
import { MdfeCabecalhoModel } from '../model/mdfe-cabecalho.entity';

@Crud({
  model: {
    type: MdfeCabecalhoModel,
  },
  query: {
    join: {
			mdfeLacreModelList: { eager: true },
			mdfeMunicipioDescarregaModelList: { eager: true },
			mdfeEmitenteModelList: { eager: true },
			mdfePercursoModelList: { eager: true },
			mdfeMunicipioCarregamentoModelList: { eager: true },
			mdfeRodoviarioModelList: { eager: true },
			mdfeInformacaoSeguroModelList: { eager: true },
    },
  },
})
@Controller('mdfe-cabecalho')
export class MdfeCabecalhoController implements CrudController<MdfeCabecalhoModel> {
  constructor(public service: MdfeCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeCabecalho = new MdfeCabecalhoModel(jsonObj);
		const result = await this.service.save(mdfeCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeCabecalho = new MdfeCabecalhoModel(jsonObj);
		const result = await this.service.save(mdfeCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}