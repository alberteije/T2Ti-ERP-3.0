import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { MdfeCabecalhoModule } from './modules-export';
import { MdfeInformacaoCteModule } from './modules-export';
import { MdfeInformacaoNfeModule } from './modules-export';
import { MdfeRodoviarioMotoristaModule } from './modules-export';
import { MdfeRodoviarioVeiculoModule } from './modules-export';
import { MdfeRodoviarioPedagioModule } from './modules-export';
import { MdfeRodoviarioCiotModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			MdfeCabecalhoModule,
			MdfeInformacaoCteModule,
			MdfeInformacaoNfeModule,
			MdfeRodoviarioMotoristaModule,
			MdfeRodoviarioVeiculoModule,
			MdfeRodoviarioPedagioModule,
			MdfeRodoviarioCiotModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}