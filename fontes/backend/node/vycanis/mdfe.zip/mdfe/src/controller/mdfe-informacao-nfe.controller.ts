import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { MdfeInformacaoNfeService } from '../service/mdfe-informacao-nfe.service';
import { MdfeInformacaoNfeModel } from '../model/mdfe-informacao-nfe.entity';

@Crud({
  model: {
    type: MdfeInformacaoNfeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('mdfe-informacao-nfe')
export class MdfeInformacaoNfeController implements CrudController<MdfeInformacaoNfeModel> {
  constructor(public service: MdfeInformacaoNfeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeInformacaoNfeModel = new MdfeInformacaoNfeModel(jsonObj);
		const result = await this.service.save(mdfeInformacaoNfeModel);
		return result;
	}  


}


















