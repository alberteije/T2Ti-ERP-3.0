import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { MdfeInformacaoCteService } from '../service/mdfe-informacao-cte.service';
import { MdfeInformacaoCteModel } from '../model/mdfe-informacao-cte.entity';

@Crud({
  model: {
    type: MdfeInformacaoCteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('mdfe-informacao-cte')
export class MdfeInformacaoCteController implements CrudController<MdfeInformacaoCteModel> {
  constructor(public service: MdfeInformacaoCteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeInformacaoCteModel = new MdfeInformacaoCteModel(jsonObj);
		const result = await this.service.save(mdfeInformacaoCteModel);
		return result;
	}  


}


















