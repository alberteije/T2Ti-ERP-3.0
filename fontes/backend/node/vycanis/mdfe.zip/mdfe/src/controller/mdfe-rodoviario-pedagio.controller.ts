import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { MdfeRodoviarioPedagioService } from '../service/mdfe-rodoviario-pedagio.service';
import { MdfeRodoviarioPedagioModel } from '../model/mdfe-rodoviario-pedagio.entity';

@Crud({
  model: {
    type: MdfeRodoviarioPedagioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('mdfe-rodoviario-pedagio')
export class MdfeRodoviarioPedagioController implements CrudController<MdfeRodoviarioPedagioModel> {
  constructor(public service: MdfeRodoviarioPedagioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeRodoviarioPedagioModel = new MdfeRodoviarioPedagioModel(jsonObj);
		const result = await this.service.save(mdfeRodoviarioPedagioModel);
		return result;
	}  


}


















