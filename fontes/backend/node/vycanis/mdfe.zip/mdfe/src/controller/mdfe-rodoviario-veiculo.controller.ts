import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { MdfeRodoviarioVeiculoService } from '../service/mdfe-rodoviario-veiculo.service';
import { MdfeRodoviarioVeiculoModel } from '../model/mdfe-rodoviario-veiculo.entity';

@Crud({
  model: {
    type: MdfeRodoviarioVeiculoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('mdfe-rodoviario-veiculo')
export class MdfeRodoviarioVeiculoController implements CrudController<MdfeRodoviarioVeiculoModel> {
  constructor(public service: MdfeRodoviarioVeiculoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const mdfeRodoviarioVeiculoModel = new MdfeRodoviarioVeiculoModel(jsonObj);
		const result = await this.service.save(mdfeRodoviarioVeiculoModel);
		return result;
	}  


}


















