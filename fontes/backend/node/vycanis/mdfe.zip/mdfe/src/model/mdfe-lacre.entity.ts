import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'mdfe_lacre' })
export class MdfeLacreModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_lacre' }) 
	numeroLacre: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => MdfeCabecalhoModel, mdfeCabecalhoModel => mdfeCabecalhoModel.mdfeLacreModelList)
	@JoinColumn({ name: 'id_mdfe_cabecalho' })
	mdfeCabecalhoModel: MdfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroLacre = jsonObj['numeroLacre'];
		}
	}
}