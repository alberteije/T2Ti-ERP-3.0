import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeRodoviarioModel } from '../entities-export';

@Entity({ name: 'mdfe_rodoviario_motorista' })
export class MdfeRodoviarioMotoristaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 


	/**
	* Relations
	*/
	@OneToOne(() => MdfeRodoviarioModel)
	@JoinColumn({ name: 'id_mdfe_rodoviario' })
	mdfeRodoviarioModel: MdfeRodoviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.cpf = jsonObj['cpf'];
			if (jsonObj['mdfeRodoviarioModel'] != null) {
				this.mdfeRodoviarioModel = new MdfeRodoviarioModel(jsonObj['mdfeRodoviarioModel']);
			}

		}
	}
}