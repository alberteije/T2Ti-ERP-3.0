import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeRodoviarioModel } from '../entities-export';

@Entity({ name: 'mdfe_rodoviario_veiculo' })
export class MdfeRodoviarioVeiculoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_interno' }) 
	codigoInterno: string; 

	@Column({ name: 'placa' }) 
	placa: string; 

	@Column({ name: 'renavam' }) 
	renavam: string; 

	@Column({ name: 'tara' }) 
	tara: number; 

	@Column({ name: 'capacidade_kg' }) 
	capacidadeKg: number; 

	@Column({ name: 'capacidade_m3' }) 
	capacidadeM3: number; 

	@Column({ name: 'tipo_rodado' }) 
	tipoRodado: string; 

	@Column({ name: 'tipo_carroceria' }) 
	tipoCarroceria: string; 

	@Column({ name: 'uf_licenciamento' }) 
	ufLicenciamento: string; 

	@Column({ name: 'proprietario_cpf' }) 
	proprietarioCpf: string; 

	@Column({ name: 'proprietario_cnpj' }) 
	proprietarioCnpj: string; 

	@Column({ name: 'proprietario_rntrc' }) 
	proprietarioRntrc: string; 

	@Column({ name: 'proprietario_nome' }) 
	proprietarioNome: string; 

	@Column({ name: 'proprietario_ie' }) 
	proprietarioIe: string; 

	@Column({ name: 'proprietario_tipo' }) 
	proprietarioTipo: number; 


	/**
	* Relations
	*/
	@OneToOne(() => MdfeRodoviarioModel)
	@JoinColumn({ name: 'id_mdfe_rodoviario' })
	mdfeRodoviarioModel: MdfeRodoviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoInterno = jsonObj['codigoInterno'];
			this.placa = jsonObj['placa'];
			this.renavam = jsonObj['renavam'];
			this.tara = jsonObj['tara'];
			this.capacidadeKg = jsonObj['capacidadeKg'];
			this.capacidadeM3 = jsonObj['capacidadeM3'];
			this.tipoRodado = jsonObj['tipoRodado'];
			this.tipoCarroceria = jsonObj['tipoCarroceria'];
			this.ufLicenciamento = jsonObj['ufLicenciamento'];
			this.proprietarioCpf = jsonObj['proprietarioCpf'];
			this.proprietarioCnpj = jsonObj['proprietarioCnpj'];
			this.proprietarioRntrc = jsonObj['proprietarioRntrc'];
			this.proprietarioNome = jsonObj['proprietarioNome'];
			this.proprietarioIe = jsonObj['proprietarioIe'];
			this.proprietarioTipo = jsonObj['proprietarioTipo'];
			if (jsonObj['mdfeRodoviarioModel'] != null) {
				this.mdfeRodoviarioModel = new MdfeRodoviarioModel(jsonObj['mdfeRodoviarioModel']);
			}

		}
	}
}