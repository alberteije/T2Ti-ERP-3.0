import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'mdfe_informacao_seguro' })
export class MdfeInformacaoSeguroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'responsavel' }) 
	responsavel: number; 

	@Column({ name: 'cnpj_cpf' }) 
	cnpjCpf: string; 

	@Column({ name: 'seguradora' }) 
	seguradora: string; 

	@Column({ name: 'cnpj_seguradora' }) 
	cnpjSeguradora: string; 

	@Column({ name: 'apolice' }) 
	apolice: string; 

	@Column({ name: 'averbacao' }) 
	averbacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => MdfeCabecalhoModel, mdfeCabecalhoModel => mdfeCabecalhoModel.mdfeInformacaoSeguroModelList)
	@JoinColumn({ name: 'id_mdfe_cabecalho' })
	mdfeCabecalhoModel: MdfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.responsavel = jsonObj['responsavel'];
			this.cnpjCpf = jsonObj['cnpjCpf'];
			this.seguradora = jsonObj['seguradora'];
			this.cnpjSeguradora = jsonObj['cnpjSeguradora'];
			this.apolice = jsonObj['apolice'];
			this.averbacao = jsonObj['averbacao'];
		}
	}
}