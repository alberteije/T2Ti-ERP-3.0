import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeLacreModel } from '../entities-export';
import { MdfeMunicipioDescarregaModel } from '../entities-export';
import { MdfeEmitenteModel } from '../entities-export';
import { MdfePercursoModel } from '../entities-export';
import { MdfeMunicipioCarregamentoModel } from '../entities-export';
import { MdfeRodoviarioModel } from '../entities-export';
import { MdfeInformacaoSeguroModel } from '../entities-export';

@Entity({ name: 'mdfe_cabecalho' })
export class MdfeCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'tipo_ambiente' }) 
	tipoAmbiente: string; 

	@Column({ name: 'tipo_emitente' }) 
	tipoEmitente: string; 

	@Column({ name: 'tipo_transportadora' }) 
	tipoTransportadora: string; 

	@Column({ name: 'modelo' }) 
	modelo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero_mdfe' }) 
	numeroMdfe: string; 

	@Column({ name: 'codigo_numerico' }) 
	codigoNumerico: string; 

	@Column({ name: 'chave_acesso' }) 
	chaveAcesso: string; 

	@Column({ name: 'digito_verificador' }) 
	digitoVerificador: number; 

	@Column({ name: 'modal' }) 
	modal: string; 

	@Column({ name: 'data_hora_emissao' }) 
	dataHoraEmissao: Date; 

	@Column({ name: 'tipo_emissao' }) 
	tipoEmissao: string; 

	@Column({ name: 'processo_emissao' }) 
	processoEmissao: string; 

	@Column({ name: 'versao_processo_emissao' }) 
	versaoProcessoEmissao: string; 

	@Column({ name: 'uf_inicio' }) 
	ufInicio: string; 

	@Column({ name: 'uf_fim' }) 
	ufFim: string; 

	@Column({ name: 'data_hora_previsao_viagem' }) 
	dataHoraPrevisaoViagem: Date; 

	@Column({ name: 'quantidade_total_cte' }) 
	quantidadeTotalCte: number; 

	@Column({ name: 'quantidade_total_nfe' }) 
	quantidadeTotalNfe: number; 

	@Column({ name: 'quantidade_total_mdfe' }) 
	quantidadeTotalMdfe: number; 

	@Column({ name: 'codigo_unidade_medida' }) 
	codigoUnidadeMedida: string; 

	@Column({ name: 'peso_bruto_carga', type: 'decimal', precision: 18, scale: 6 }) 
	pesoBrutoCarga: number; 

	@Column({ name: 'valor_carga', type: 'decimal', precision: 18, scale: 6 }) 
	valorCarga: number; 

	@Column({ name: 'numero_protocolo' }) 
	numeroProtocolo: string; 


	/**
	* Relations
	*/
	@OneToMany(() => MdfeLacreModel, mdfeLacreModel => mdfeLacreModel.mdfeCabecalhoModel, { cascade: true })
	mdfeLacreModelList: MdfeLacreModel[];

	@OneToMany(() => MdfeMunicipioDescarregaModel, mdfeMunicipioDescarregaModel => mdfeMunicipioDescarregaModel.mdfeCabecalhoModel, { cascade: true })
	mdfeMunicipioDescarregaModelList: MdfeMunicipioDescarregaModel[];

	@OneToMany(() => MdfeEmitenteModel, mdfeEmitenteModel => mdfeEmitenteModel.mdfeCabecalhoModel, { cascade: true })
	mdfeEmitenteModelList: MdfeEmitenteModel[];

	@OneToMany(() => MdfePercursoModel, mdfePercursoModel => mdfePercursoModel.mdfeCabecalhoModel, { cascade: true })
	mdfePercursoModelList: MdfePercursoModel[];

	@OneToMany(() => MdfeMunicipioCarregamentoModel, mdfeMunicipioCarregamentoModel => mdfeMunicipioCarregamentoModel.mdfeCabecalhoModel, { cascade: true })
	mdfeMunicipioCarregamentoModelList: MdfeMunicipioCarregamentoModel[];

	@OneToMany(() => MdfeRodoviarioModel, mdfeRodoviarioModel => mdfeRodoviarioModel.mdfeCabecalhoModel, { cascade: true })
	mdfeRodoviarioModelList: MdfeRodoviarioModel[];

	@OneToMany(() => MdfeInformacaoSeguroModel, mdfeInformacaoSeguroModel => mdfeInformacaoSeguroModel.mdfeCabecalhoModel, { cascade: true })
	mdfeInformacaoSeguroModelList: MdfeInformacaoSeguroModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.uf = jsonObj['uf'];
			this.tipoAmbiente = jsonObj['tipoAmbiente'];
			this.tipoEmitente = jsonObj['tipoEmitente'];
			this.tipoTransportadora = jsonObj['tipoTransportadora'];
			this.modelo = jsonObj['modelo'];
			this.serie = jsonObj['serie'];
			this.numeroMdfe = jsonObj['numeroMdfe'];
			this.codigoNumerico = jsonObj['codigoNumerico'];
			this.chaveAcesso = jsonObj['chaveAcesso'];
			this.digitoVerificador = jsonObj['digitoVerificador'];
			this.modal = jsonObj['modal'];
			this.dataHoraEmissao = jsonObj['dataHoraEmissao'];
			this.tipoEmissao = jsonObj['tipoEmissao'];
			this.processoEmissao = jsonObj['processoEmissao'];
			this.versaoProcessoEmissao = jsonObj['versaoProcessoEmissao'];
			this.ufInicio = jsonObj['ufInicio'];
			this.ufFim = jsonObj['ufFim'];
			this.dataHoraPrevisaoViagem = jsonObj['dataHoraPrevisaoViagem'];
			this.quantidadeTotalCte = jsonObj['quantidadeTotalCte'];
			this.quantidadeTotalNfe = jsonObj['quantidadeTotalNfe'];
			this.quantidadeTotalMdfe = jsonObj['quantidadeTotalMdfe'];
			this.codigoUnidadeMedida = jsonObj['codigoUnidadeMedida'];
			this.pesoBrutoCarga = jsonObj['pesoBrutoCarga'];
			this.valorCarga = jsonObj['valorCarga'];
			this.numeroProtocolo = jsonObj['numeroProtocolo'];
			this.mdfeLacreModelList = [];
			let mdfeLacreModelJsonList = jsonObj['mdfeLacreModelList'];
			if (mdfeLacreModelJsonList != null) {
				for (let i = 0; i < mdfeLacreModelJsonList.length; i++) {
					let obj = new MdfeLacreModel(mdfeLacreModelJsonList[i]);
					this.mdfeLacreModelList.push(obj);
				}
			}

			this.mdfeMunicipioDescarregaModelList = [];
			let mdfeMunicipioDescarregaModelJsonList = jsonObj['mdfeMunicipioDescarregaModelList'];
			if (mdfeMunicipioDescarregaModelJsonList != null) {
				for (let i = 0; i < mdfeMunicipioDescarregaModelJsonList.length; i++) {
					let obj = new MdfeMunicipioDescarregaModel(mdfeMunicipioDescarregaModelJsonList[i]);
					this.mdfeMunicipioDescarregaModelList.push(obj);
				}
			}

			this.mdfeEmitenteModelList = [];
			let mdfeEmitenteModelJsonList = jsonObj['mdfeEmitenteModelList'];
			if (mdfeEmitenteModelJsonList != null) {
				for (let i = 0; i < mdfeEmitenteModelJsonList.length; i++) {
					let obj = new MdfeEmitenteModel(mdfeEmitenteModelJsonList[i]);
					this.mdfeEmitenteModelList.push(obj);
				}
			}

			this.mdfePercursoModelList = [];
			let mdfePercursoModelJsonList = jsonObj['mdfePercursoModelList'];
			if (mdfePercursoModelJsonList != null) {
				for (let i = 0; i < mdfePercursoModelJsonList.length; i++) {
					let obj = new MdfePercursoModel(mdfePercursoModelJsonList[i]);
					this.mdfePercursoModelList.push(obj);
				}
			}

			this.mdfeMunicipioCarregamentoModelList = [];
			let mdfeMunicipioCarregamentoModelJsonList = jsonObj['mdfeMunicipioCarregamentoModelList'];
			if (mdfeMunicipioCarregamentoModelJsonList != null) {
				for (let i = 0; i < mdfeMunicipioCarregamentoModelJsonList.length; i++) {
					let obj = new MdfeMunicipioCarregamentoModel(mdfeMunicipioCarregamentoModelJsonList[i]);
					this.mdfeMunicipioCarregamentoModelList.push(obj);
				}
			}

			this.mdfeRodoviarioModelList = [];
			let mdfeRodoviarioModelJsonList = jsonObj['mdfeRodoviarioModelList'];
			if (mdfeRodoviarioModelJsonList != null) {
				for (let i = 0; i < mdfeRodoviarioModelJsonList.length; i++) {
					let obj = new MdfeRodoviarioModel(mdfeRodoviarioModelJsonList[i]);
					this.mdfeRodoviarioModelList.push(obj);
				}
			}

			this.mdfeInformacaoSeguroModelList = [];
			let mdfeInformacaoSeguroModelJsonList = jsonObj['mdfeInformacaoSeguroModelList'];
			if (mdfeInformacaoSeguroModelJsonList != null) {
				for (let i = 0; i < mdfeInformacaoSeguroModelJsonList.length; i++) {
					let obj = new MdfeInformacaoSeguroModel(mdfeInformacaoSeguroModelJsonList[i]);
					this.mdfeInformacaoSeguroModelList.push(obj);
				}
			}

		}
	}
}