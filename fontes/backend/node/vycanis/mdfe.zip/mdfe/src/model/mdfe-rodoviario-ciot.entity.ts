import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeRodoviarioModel } from '../entities-export';

@Entity({ name: 'mdfe_rodoviario_ciot' })
export class MdfeRodoviarioCiotModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'ciot' }) 
	ciot: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 


	/**
	* Relations
	*/
	@OneToOne(() => MdfeRodoviarioModel)
	@JoinColumn({ name: 'id_mdfe_rodoviario' })
	mdfeRodoviarioModel: MdfeRodoviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ciot = jsonObj['ciot'];
			this.cpf = jsonObj['cpf'];
			this.cnpj = jsonObj['cnpj'];
			if (jsonObj['mdfeRodoviarioModel'] != null) {
				this.mdfeRodoviarioModel = new MdfeRodoviarioModel(jsonObj['mdfeRodoviarioModel']);
			}

		}
	}
}