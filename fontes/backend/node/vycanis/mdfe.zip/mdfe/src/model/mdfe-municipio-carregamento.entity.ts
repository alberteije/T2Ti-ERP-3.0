import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { MdfeCabecalhoModel } from '../entities-export';

@Entity({ name: 'mdfe_municipio_carregamento' })
export class MdfeMunicipioCarregamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: string; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => MdfeCabecalhoModel, mdfeCabecalhoModel => mdfeCabecalhoModel.mdfeMunicipioCarregamentoModelList)
	@JoinColumn({ name: 'id_mdfe_cabecalho' })
	mdfeCabecalhoModel: MdfeCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
		}
	}
}