import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { MdfeInformacaoNfeModel } from '../entities-export';

@Injectable()
export class MdfeInformacaoNfeService extends TypeOrmCrudService<MdfeInformacaoNfeModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(MdfeInformacaoNfeModel)
    private readonly repository: Repository<MdfeInformacaoNfeModel>
  ) {
    super(repository);
  }

	async save(mdfeInformacaoNfeModel: MdfeInformacaoNfeModel): Promise<MdfeInformacaoNfeModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(mdfeInformacaoNfeModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
