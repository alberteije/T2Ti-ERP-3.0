import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { MdfeRodoviarioVeiculoModel } from '../entities-export';

@Injectable()
export class MdfeRodoviarioVeiculoService extends TypeOrmCrudService<MdfeRodoviarioVeiculoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(MdfeRodoviarioVeiculoModel)
    private readonly repository: Repository<MdfeRodoviarioVeiculoModel>
  ) {
    super(repository);
  }

	async save(mdfeRodoviarioVeiculoModel: MdfeRodoviarioVeiculoModel): Promise<MdfeRodoviarioVeiculoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(mdfeRodoviarioVeiculoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
