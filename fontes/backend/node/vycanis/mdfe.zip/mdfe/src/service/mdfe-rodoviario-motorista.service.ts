import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { MdfeRodoviarioMotoristaModel } from '../entities-export';

@Injectable()
export class MdfeRodoviarioMotoristaService extends TypeOrmCrudService<MdfeRodoviarioMotoristaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(MdfeRodoviarioMotoristaModel)
    private readonly repository: Repository<MdfeRodoviarioMotoristaModel>
  ) {
    super(repository);
  }

	async save(mdfeRodoviarioMotoristaModel: MdfeRodoviarioMotoristaModel): Promise<MdfeRodoviarioMotoristaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(mdfeRodoviarioMotoristaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
