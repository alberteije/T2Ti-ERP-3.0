import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { MdfeCabecalhoModel } from '../entities-export';

@Injectable()
export class MdfeCabecalhoService extends TypeOrmCrudService<MdfeCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(MdfeCabecalhoModel) 
    private readonly repository: Repository<MdfeCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(mdfeCabecalhoModel: MdfeCabecalhoModel, operation: string): Promise<MdfeCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, mdfeCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(mdfeCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(MdfeCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from mdfe_lacre where id_mdfe_cabecalho=' + id); 

		await queryRunner.query('delete from mdfe_municipio_descarrega where id_mdfe_cabecalho=' + id); 

		await queryRunner.query('delete from mdfe_emitente where id_mdfe_cabecalho=' + id); 

		await queryRunner.query('delete from mdfe_percurso where id_mdfe_cabecalho=' + id); 

		await queryRunner.query('delete from mdfe_municipio_carregamento where id_mdfe_cabecalho=' + id); 

		await queryRunner.query('delete from mdfe_rodoviario where id_mdfe_cabecalho=' + id); 

		await queryRunner.query('delete from mdfe_informacao_seguro where id_mdfe_cabecalho=' + id); 

	}
	
}