import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MdfeCabecalhoController } from '../controller/mdfe-cabecalho.controller';
import { MdfeCabecalhoService } from '../service/mdfe-cabecalho.service';
import { MdfeCabecalhoModel } from '../model/mdfe-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MdfeCabecalhoModel])],
    controllers: [MdfeCabecalhoController],
    providers: [MdfeCabecalhoService],
})
export class MdfeCabecalhoModule { }
