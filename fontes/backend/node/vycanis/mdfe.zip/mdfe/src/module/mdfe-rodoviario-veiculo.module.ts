import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MdfeRodoviarioVeiculoController } from '../controller/mdfe-rodoviario-veiculo.controller';
import { MdfeRodoviarioVeiculoService } from '../service/mdfe-rodoviario-veiculo.service';
import { MdfeRodoviarioVeiculoModel } from '../model/mdfe-rodoviario-veiculo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MdfeRodoviarioVeiculoModel])],
    controllers: [MdfeRodoviarioVeiculoController],
    providers: [MdfeRodoviarioVeiculoService],
})
export class MdfeRodoviarioVeiculoModule { }
