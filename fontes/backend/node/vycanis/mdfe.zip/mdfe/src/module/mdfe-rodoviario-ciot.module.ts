import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MdfeRodoviarioCiotController } from '../controller/mdfe-rodoviario-ciot.controller';
import { MdfeRodoviarioCiotService } from '../service/mdfe-rodoviario-ciot.service';
import { MdfeRodoviarioCiotModel } from '../model/mdfe-rodoviario-ciot.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MdfeRodoviarioCiotModel])],
    controllers: [MdfeRodoviarioCiotController],
    providers: [MdfeRodoviarioCiotService],
})
export class MdfeRodoviarioCiotModule { }
