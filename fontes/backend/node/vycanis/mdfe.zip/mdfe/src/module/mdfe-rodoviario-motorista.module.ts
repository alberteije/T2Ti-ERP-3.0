import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MdfeRodoviarioMotoristaController } from '../controller/mdfe-rodoviario-motorista.controller';
import { MdfeRodoviarioMotoristaService } from '../service/mdfe-rodoviario-motorista.service';
import { MdfeRodoviarioMotoristaModel } from '../model/mdfe-rodoviario-motorista.entity';

@Module({
    imports: [TypeOrmModule.forFeature([MdfeRodoviarioMotoristaModel])],
    controllers: [MdfeRodoviarioMotoristaController],
    providers: [MdfeRodoviarioMotoristaService],
})
export class MdfeRodoviarioMotoristaModule { }
