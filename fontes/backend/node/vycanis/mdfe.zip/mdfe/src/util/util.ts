/* eslint-disable @typescript-eslint/no-var-requires */
import * as fs from 'fs';
import { Constants } from './constants';
const crypto = require('crypto');

export class Util {

    /**
      * Salva o arquivo no disco
      */
     static async gravarArquivo(caminho: string, conteudo: any) {
        fs.writeFile(caminho, conteudo, function (erro: any) {
            if (erro) {
                return erro;
            } else {
                return true;
            }
        });
    }
	
    static md5String(texto: string): string {
        const hash = crypto.createHash('md5').update(texto).digest("hex");    
        return hash;
    }

    static cifrar(valor: string): string {
        const algorithm = 'aes-256-ctr';
        const cipher = crypto.createCipheriv(algorithm, Constants.CHAVE, Constants.VETOR);
        const valor_cifrado = cipher.update(valor);
        const valor_cifrado_base64 = valor_cifrado.toString('base64');
        return valor_cifrado_base64;        
    }

    static decifrar(valor: string): string {
        const algorithm = 'aes-256-ctr';
        const decipher = crypto.createDecipheriv(algorithm, Constants.CHAVE, Constants.VETOR);
        const valor_decifrado_base64 = Buffer.from(valor, 'base64');
        const valor_decifrado = decipher.update(valor_decifrado_base64);
        return valor_decifrado.toString();        
    }

}