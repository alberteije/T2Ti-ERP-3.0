import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { CteCabecalhoModule } from './modules-export';
import { CteInformacaoNfTransporteModule } from './modules-export';
import { CteInfNfTransporteLacreModule } from './modules-export';
import { CteInformacaoNfCargaModule } from './modules-export';
import { CteInfNfCargaLacreModule } from './modules-export';
import { CteDocumentoAnteriorIdModule } from './modules-export';
import { CteRodoviarioOccModule } from './modules-export';
import { CteRodoviarioPedagioModule } from './modules-export';
import { CteRodoviarioVeiculoModule } from './modules-export';
import { CteRodoviarioLacreModule } from './modules-export';
import { CteRodoviarioMotoristaModule } from './modules-export';
import { CteAquaviarioBalsaModule } from './modules-export';
import { CteFerroviarioFerroviaModule } from './modules-export';
import { CteFerroviarioVagaoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			CteCabecalhoModule,
			CteInformacaoNfTransporteModule,
			CteInfNfTransporteLacreModule,
			CteInformacaoNfCargaModule,
			CteInfNfCargaLacreModule,
			CteDocumentoAnteriorIdModule,
			CteRodoviarioOccModule,
			CteRodoviarioPedagioModule,
			CteRodoviarioVeiculoModule,
			CteRodoviarioLacreModule,
			CteRodoviarioMotoristaModule,
			CteAquaviarioBalsaModule,
			CteFerroviarioFerroviaModule,
			CteFerroviarioVagaoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}