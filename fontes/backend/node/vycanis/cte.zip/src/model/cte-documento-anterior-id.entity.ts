import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'cte_documento_anterior_id' })
export class CteDocumentoAnteriorIdModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'subserie' }) 
	subserie: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'chave_cte' }) 
	chaveCte: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipo = jsonObj['tipo'];
			this.serie = jsonObj['serie'];
			this.subserie = jsonObj['subserie'];
			this.numero = jsonObj['numero'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.chaveCte = jsonObj['chaveCte'];
		}
	}
}