import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_carga' })
export class CteCargaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_unidade_medida' }) 
	codigoUnidadeMedida: string; 

	@Column({ name: 'tipo_medida' }) 
	tipoMedida: string; 

	@Column({ name: 'quantidade', type: 'decimal', precision: 18, scale: 6 }) 
	quantidade: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteCargaModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoUnidadeMedida = jsonObj['codigoUnidadeMedida'];
			this.tipoMedida = jsonObj['tipoMedida'];
			this.quantidade = jsonObj['quantidade'];
		}
	}
}