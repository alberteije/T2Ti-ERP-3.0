import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteRodoviarioModel } from '../entities-export';

@Entity({ name: 'cte_rodoviario_occ' })
export class CteRodoviarioOccModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'codigo_interno' }) 
	codigoInterno: string; 

	@Column({ name: 'ie' }) 
	ie: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'telefone' }) 
	telefone: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteRodoviarioModel)
	@JoinColumn({ name: 'id_cte_rodoviario' })
	cteRodoviarioModel: CteRodoviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.cnpj = jsonObj['cnpj'];
			this.codigoInterno = jsonObj['codigoInterno'];
			this.ie = jsonObj['ie'];
			this.uf = jsonObj['uf'];
			this.telefone = jsonObj['telefone'];
			if (jsonObj['cteRodoviarioModel'] != null) {
				this.cteRodoviarioModel = new CteRodoviarioModel(jsonObj['cteRodoviarioModel']);
			}

		}
	}
}