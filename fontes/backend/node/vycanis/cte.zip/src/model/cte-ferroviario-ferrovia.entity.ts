import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteFerroviarioModel } from '../entities-export';

@Entity({ name: 'cte_ferroviario_ferrovia' })
export class CteFerroviarioFerroviaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'codigo_interno' }) 
	codigoInterno: string; 

	@Column({ name: 'ie' }) 
	ie: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: number; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'cep' }) 
	cep: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteFerroviarioModel)
	@JoinColumn({ name: 'id_cte_ferroviario' })
	cteFerroviarioModel: CteFerroviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.codigoInterno = jsonObj['codigoInterno'];
			this.ie = jsonObj['ie'];
			this.nome = jsonObj['nome'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
			this.uf = jsonObj['uf'];
			this.cep = jsonObj['cep'];
			if (jsonObj['cteFerroviarioModel'] != null) {
				this.cteFerroviarioModel = new CteFerroviarioModel(jsonObj['cteFerroviarioModel']);
			}

		}
	}
}