import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteInformacaoNfOutrosModel } from '../entities-export';

@Entity({ name: 'cte_informacao_nf_carga' })
export class CteInformacaoNfCargaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo_unidade_carga' }) 
	tipoUnidadeCarga: string; 

	@Column({ name: 'id_unidade_carga' }) 
	idUnidadeCarga: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteInformacaoNfOutrosModel)
	@JoinColumn({ name: 'id_cte_informacao_nf' })
	cteInformacaoNfOutrosModel: CteInformacaoNfOutrosModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipoUnidadeCarga = jsonObj['tipoUnidadeCarga'];
			this.idUnidadeCarga = jsonObj['idUnidadeCarga'];
			if (jsonObj['cteInformacaoNfOutrosModel'] != null) {
				this.cteInformacaoNfOutrosModel = new CteInformacaoNfOutrosModel(jsonObj['cteInformacaoNfOutrosModel']);
			}

		}
	}
}