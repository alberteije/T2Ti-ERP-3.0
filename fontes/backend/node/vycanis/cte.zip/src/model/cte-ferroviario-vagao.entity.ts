import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteFerroviarioModel } from '../entities-export';

@Entity({ name: 'cte_ferroviario_vagao' })
export class CteFerroviarioVagaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_vagao' }) 
	numeroVagao: number; 

	@Column({ name: 'capacidade', type: 'decimal', precision: 18, scale: 6 }) 
	capacidade: number; 

	@Column({ name: 'tipo_vagao' }) 
	tipoVagao: string; 

	@Column({ name: 'peso_real', type: 'decimal', precision: 18, scale: 6 }) 
	pesoReal: number; 

	@Column({ name: 'peso_bc', type: 'decimal', precision: 18, scale: 6 }) 
	pesoBc: number; 


	/**
	* Relations
	*/
	@OneToOne(() => CteFerroviarioModel)
	@JoinColumn({ name: 'id_cte_ferroviario' })
	cteFerroviarioModel: CteFerroviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroVagao = jsonObj['numeroVagao'];
			this.capacidade = jsonObj['capacidade'];
			this.tipoVagao = jsonObj['tipoVagao'];
			this.pesoReal = jsonObj['pesoReal'];
			this.pesoBc = jsonObj['pesoBc'];
			if (jsonObj['cteFerroviarioModel'] != null) {
				this.cteFerroviarioModel = new CteFerroviarioModel(jsonObj['cteFerroviarioModel']);
			}

		}
	}
}