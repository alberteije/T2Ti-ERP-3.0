import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteEmitenteModel } from '../entities-export';
import { CteLocalColetaModel } from '../entities-export';
import { CteTomadorModel } from '../entities-export';
import { CtePassagemModel } from '../entities-export';
import { CteRemetenteModel } from '../entities-export';
import { CteExpedidorModel } from '../entities-export';
import { CteRecebedorModel } from '../entities-export';
import { CteDestinatarioModel } from '../entities-export';
import { CteLocalEntregaModel } from '../entities-export';
import { CteComponenteModel } from '../entities-export';
import { CteCargaModel } from '../entities-export';
import { CteInformacaoNfOutrosModel } from '../entities-export';
import { CteSeguroModel } from '../entities-export';
import { CtePerigosoModel } from '../entities-export';
import { CteVeiculoNovoModel } from '../entities-export';
import { CteFaturaModel } from '../entities-export';
import { CteDuplicataModel } from '../entities-export';
import { CteRodoviarioModel } from '../entities-export';
import { CteAereoModel } from '../entities-export';
import { CteAquaviarioModel } from '../entities-export';
import { CteFerroviarioModel } from '../entities-export';
import { CteDutoviarioModel } from '../entities-export';
import { CteMultimodalModel } from '../entities-export';

@Entity({ name: 'cte_cabecalho' })
export class CteCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'natureza_operacao' }) 
	naturezaOperacao: string; 

	@Column({ name: 'chave_acesso' }) 
	chaveAcesso: string; 

	@Column({ name: 'digito_chave_acesso' }) 
	digitoChaveAcesso: string; 

	@Column({ name: 'codigo_numerico' }) 
	codigoNumerico: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_hora_emissao' }) 
	dataHoraEmissao: Date; 

	@Column({ name: 'uf_emitente' }) 
	ufEmitente: string; 

	@Column({ name: 'cfop' }) 
	cfop: number; 

	@Column({ name: 'forma_pagamento' }) 
	formaPagamento: string; 

	@Column({ name: 'modelo' }) 
	modelo: string; 

	@Column({ name: 'formato_impressao_dacte' }) 
	formatoImpressaoDacte: string; 

	@Column({ name: 'tipo_emissao' }) 
	tipoEmissao: string; 

	@Column({ name: 'ambiente' }) 
	ambiente: string; 

	@Column({ name: 'tipo_cte' }) 
	tipoCte: string; 

	@Column({ name: 'processo_emissao' }) 
	processoEmissao: string; 

	@Column({ name: 'versao_processo_emissao' }) 
	versaoProcessoEmissao: string; 

	@Column({ name: 'chave_referenciado' }) 
	chaveReferenciado: string; 

	@Column({ name: 'codigo_municipio_envio' }) 
	codigoMunicipioEnvio: number; 

	@Column({ name: 'nome_municipio_envio' }) 
	nomeMunicipioEnvio: string; 

	@Column({ name: 'uf_envio' }) 
	ufEnvio: string; 

	@Column({ name: 'modal' }) 
	modal: string; 

	@Column({ name: 'tipo_servico' }) 
	tipoServico: string; 

	@Column({ name: 'codigo_municipio_ini_prestacao' }) 
	codigoMunicipioIniPrestacao: number; 

	@Column({ name: 'nome_municipio_ini_prestacao' }) 
	nomeMunicipioIniPrestacao: string; 

	@Column({ name: 'uf_ini_prestacao' }) 
	ufIniPrestacao: string; 

	@Column({ name: 'codigo_municipio_fim_prestacao' }) 
	codigoMunicipioFimPrestacao: number; 

	@Column({ name: 'nome_municipio_fim_prestacao' }) 
	nomeMunicipioFimPrestacao: string; 

	@Column({ name: 'uf_fim_prestacao' }) 
	ufFimPrestacao: string; 

	@Column({ name: 'retira' }) 
	retira: string; 

	@Column({ name: 'retira_detalhe' }) 
	retiraDetalhe: string; 

	@Column({ name: 'tomador' }) 
	tomador: string; 

	@Column({ name: 'data_entrada_contingencia' }) 
	dataEntradaContingencia: Date; 

	@Column({ name: 'justificativa_contingencia' }) 
	justificativaContingencia: string; 

	@Column({ name: 'carac_adicional_transporte' }) 
	caracAdicionalTransporte: string; 

	@Column({ name: 'carac_adicional_servico' }) 
	caracAdicionalServico: string; 

	@Column({ name: 'funcionario_emissor' }) 
	funcionarioEmissor: string; 

	@Column({ name: 'fluxo_origem' }) 
	fluxoOrigem: string; 

	@Column({ name: 'entrega_tipo_periodo' }) 
	entregaTipoPeriodo: string; 

	@Column({ name: 'entrega_data_programada' }) 
	entregaDataProgramada: Date; 

	@Column({ name: 'entrega_data_inicial' }) 
	entregaDataInicial: Date; 

	@Column({ name: 'entrega_data_final' }) 
	entregaDataFinal: Date; 

	@Column({ name: 'entrega_tipo_hora' }) 
	entregaTipoHora: string; 

	@Column({ name: 'entrega_hora_programada' }) 
	entregaHoraProgramada: string; 

	@Column({ name: 'entrega_hora_inicial' }) 
	entregaHoraInicial: string; 

	@Column({ name: 'entrega_hora_final' }) 
	entregaHoraFinal: string; 

	@Column({ name: 'municipio_origem_calculo' }) 
	municipioOrigemCalculo: string; 

	@Column({ name: 'municipio_destino_calculo' }) 
	municipioDestinoCalculo: string; 

	@Column({ name: 'observacoes_gerais' }) 
	observacoesGerais: string; 

	@Column({ name: 'valor_total_servico', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalServico: number; 

	@Column({ name: 'valor_receber', type: 'decimal', precision: 18, scale: 6 }) 
	valorReceber: number; 

	@Column({ name: 'cst' }) 
	cst: string; 

	@Column({ name: 'base_calculo_icms', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcms: number; 

	@Column({ name: 'aliquota_icms', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcms: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'percentual_reducao_bc_icms', type: 'decimal', precision: 18, scale: 6 }) 
	percentualReducaoBcIcms: number; 

	@Column({ name: 'valor_bc_icms_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcmsStRetido: number; 

	@Column({ name: 'valor_icms_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsStRetido: number; 

	@Column({ name: 'aliquota_icms_st_retido', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcmsStRetido: number; 

	@Column({ name: 'valor_credito_presumido_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorCreditoPresumidoIcms: number; 

	@Column({ name: 'percentual_bc_icms_outra_uf', type: 'decimal', precision: 18, scale: 6 }) 
	percentualBcIcmsOutraUf: number; 

	@Column({ name: 'valor_bc_icms_outra_uf', type: 'decimal', precision: 18, scale: 6 }) 
	valorBcIcmsOutraUf: number; 

	@Column({ name: 'aliquota_icms_outra_uf', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaIcmsOutraUf: number; 

	@Column({ name: 'valor_icms_outra_uf', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsOutraUf: number; 

	@Column({ name: 'simples_nacional_indicador' }) 
	simplesNacionalIndicador: string; 

	@Column({ name: 'simples_nacional_total', type: 'decimal', precision: 18, scale: 6 }) 
	simplesNacionalTotal: number; 

	@Column({ name: 'informacoes_add_fisco' }) 
	informacoesAddFisco: string; 

	@Column({ name: 'valor_total_carga', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalCarga: number; 

	@Column({ name: 'produto_predominante' }) 
	produtoPredominante: string; 

	@Column({ name: 'carga_outras_caracteristicas' }) 
	cargaOutrasCaracteristicas: string; 

	@Column({ name: 'modal_versao_layout' }) 
	modalVersaoLayout: number; 

	@Column({ name: 'chave_cte_substituido' }) 
	chaveCteSubstituido: string; 


	/**
	* Relations
	*/
	@OneToMany(() => CteEmitenteModel, cteEmitenteModel => cteEmitenteModel.cteCabecalhoModel, { cascade: true })
	cteEmitenteModelList: CteEmitenteModel[];

	@OneToMany(() => CteLocalColetaModel, cteLocalColetaModel => cteLocalColetaModel.cteCabecalhoModel, { cascade: true })
	cteLocalColetaModelList: CteLocalColetaModel[];

	@OneToMany(() => CteTomadorModel, cteTomadorModel => cteTomadorModel.cteCabecalhoModel, { cascade: true })
	cteTomadorModelList: CteTomadorModel[];

	@OneToMany(() => CtePassagemModel, ctePassagemModel => ctePassagemModel.cteCabecalhoModel, { cascade: true })
	ctePassagemModelList: CtePassagemModel[];

	@OneToMany(() => CteRemetenteModel, cteRemetenteModel => cteRemetenteModel.cteCabecalhoModel, { cascade: true })
	cteRemetenteModelList: CteRemetenteModel[];

	@OneToMany(() => CteExpedidorModel, cteExpedidorModel => cteExpedidorModel.cteCabecalhoModel, { cascade: true })
	cteExpedidorModelList: CteExpedidorModel[];

	@OneToMany(() => CteRecebedorModel, cteRecebedorModel => cteRecebedorModel.cteCabecalhoModel, { cascade: true })
	cteRecebedorModelList: CteRecebedorModel[];

	@OneToMany(() => CteDestinatarioModel, cteDestinatarioModel => cteDestinatarioModel.cteCabecalhoModel, { cascade: true })
	cteDestinatarioModelList: CteDestinatarioModel[];

	@OneToMany(() => CteLocalEntregaModel, cteLocalEntregaModel => cteLocalEntregaModel.cteCabecalhoModel, { cascade: true })
	cteLocalEntregaModelList: CteLocalEntregaModel[];

	@OneToMany(() => CteComponenteModel, cteComponenteModel => cteComponenteModel.cteCabecalhoModel, { cascade: true })
	cteComponenteModelList: CteComponenteModel[];

	@OneToMany(() => CteCargaModel, cteCargaModel => cteCargaModel.cteCabecalhoModel, { cascade: true })
	cteCargaModelList: CteCargaModel[];

	@OneToMany(() => CteInformacaoNfOutrosModel, cteInformacaoNfOutrosModel => cteInformacaoNfOutrosModel.cteCabecalhoModel, { cascade: true })
	cteInformacaoNfOutrosModelList: CteInformacaoNfOutrosModel[];

	@OneToMany(() => CteSeguroModel, cteSeguroModel => cteSeguroModel.cteCabecalhoModel, { cascade: true })
	cteSeguroModelList: CteSeguroModel[];

	@OneToMany(() => CtePerigosoModel, ctePerigosoModel => ctePerigosoModel.cteCabecalhoModel, { cascade: true })
	ctePerigosoModelList: CtePerigosoModel[];

	@OneToMany(() => CteVeiculoNovoModel, cteVeiculoNovoModel => cteVeiculoNovoModel.cteCabecalhoModel, { cascade: true })
	cteVeiculoNovoModelList: CteVeiculoNovoModel[];

	@OneToMany(() => CteFaturaModel, cteFaturaModel => cteFaturaModel.cteCabecalhoModel, { cascade: true })
	cteFaturaModelList: CteFaturaModel[];

	@OneToMany(() => CteDuplicataModel, cteDuplicataModel => cteDuplicataModel.cteCabecalhoModel, { cascade: true })
	cteDuplicataModelList: CteDuplicataModel[];

	@OneToMany(() => CteRodoviarioModel, cteRodoviarioModel => cteRodoviarioModel.cteCabecalhoModel, { cascade: true })
	cteRodoviarioModelList: CteRodoviarioModel[];

	@OneToMany(() => CteAereoModel, cteAereoModel => cteAereoModel.cteCabecalhoModel, { cascade: true })
	cteAereoModelList: CteAereoModel[];

	@OneToMany(() => CteAquaviarioModel, cteAquaviarioModel => cteAquaviarioModel.cteCabecalhoModel, { cascade: true })
	cteAquaviarioModelList: CteAquaviarioModel[];

	@OneToMany(() => CteFerroviarioModel, cteFerroviarioModel => cteFerroviarioModel.cteCabecalhoModel, { cascade: true })
	cteFerroviarioModelList: CteFerroviarioModel[];

	@OneToMany(() => CteDutoviarioModel, cteDutoviarioModel => cteDutoviarioModel.cteCabecalhoModel, { cascade: true })
	cteDutoviarioModelList: CteDutoviarioModel[];

	@OneToMany(() => CteMultimodalModel, cteMultimodalModel => cteMultimodalModel.cteCabecalhoModel, { cascade: true })
	cteMultimodalModelList: CteMultimodalModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.naturezaOperacao = jsonObj['naturezaOperacao'];
			this.chaveAcesso = jsonObj['chaveAcesso'];
			this.digitoChaveAcesso = jsonObj['digitoChaveAcesso'];
			this.codigoNumerico = jsonObj['codigoNumerico'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
			this.dataHoraEmissao = jsonObj['dataHoraEmissao'];
			this.ufEmitente = jsonObj['ufEmitente'];
			this.cfop = jsonObj['cfop'];
			this.formaPagamento = jsonObj['formaPagamento'];
			this.modelo = jsonObj['modelo'];
			this.formatoImpressaoDacte = jsonObj['formatoImpressaoDacte'];
			this.tipoEmissao = jsonObj['tipoEmissao'];
			this.ambiente = jsonObj['ambiente'];
			this.tipoCte = jsonObj['tipoCte'];
			this.processoEmissao = jsonObj['processoEmissao'];
			this.versaoProcessoEmissao = jsonObj['versaoProcessoEmissao'];
			this.chaveReferenciado = jsonObj['chaveReferenciado'];
			this.codigoMunicipioEnvio = jsonObj['codigoMunicipioEnvio'];
			this.nomeMunicipioEnvio = jsonObj['nomeMunicipioEnvio'];
			this.ufEnvio = jsonObj['ufEnvio'];
			this.modal = jsonObj['modal'];
			this.tipoServico = jsonObj['tipoServico'];
			this.codigoMunicipioIniPrestacao = jsonObj['codigoMunicipioIniPrestacao'];
			this.nomeMunicipioIniPrestacao = jsonObj['nomeMunicipioIniPrestacao'];
			this.ufIniPrestacao = jsonObj['ufIniPrestacao'];
			this.codigoMunicipioFimPrestacao = jsonObj['codigoMunicipioFimPrestacao'];
			this.nomeMunicipioFimPrestacao = jsonObj['nomeMunicipioFimPrestacao'];
			this.ufFimPrestacao = jsonObj['ufFimPrestacao'];
			this.retira = jsonObj['retira'];
			this.retiraDetalhe = jsonObj['retiraDetalhe'];
			this.tomador = jsonObj['tomador'];
			this.dataEntradaContingencia = jsonObj['dataEntradaContingencia'];
			this.justificativaContingencia = jsonObj['justificativaContingencia'];
			this.caracAdicionalTransporte = jsonObj['caracAdicionalTransporte'];
			this.caracAdicionalServico = jsonObj['caracAdicionalServico'];
			this.funcionarioEmissor = jsonObj['funcionarioEmissor'];
			this.fluxoOrigem = jsonObj['fluxoOrigem'];
			this.entregaTipoPeriodo = jsonObj['entregaTipoPeriodo'];
			this.entregaDataProgramada = jsonObj['entregaDataProgramada'];
			this.entregaDataInicial = jsonObj['entregaDataInicial'];
			this.entregaDataFinal = jsonObj['entregaDataFinal'];
			this.entregaTipoHora = jsonObj['entregaTipoHora'];
			this.entregaHoraProgramada = jsonObj['entregaHoraProgramada'];
			this.entregaHoraInicial = jsonObj['entregaHoraInicial'];
			this.entregaHoraFinal = jsonObj['entregaHoraFinal'];
			this.municipioOrigemCalculo = jsonObj['municipioOrigemCalculo'];
			this.municipioDestinoCalculo = jsonObj['municipioDestinoCalculo'];
			this.observacoesGerais = jsonObj['observacoesGerais'];
			this.valorTotalServico = jsonObj['valorTotalServico'];
			this.valorReceber = jsonObj['valorReceber'];
			this.cst = jsonObj['cst'];
			this.baseCalculoIcms = jsonObj['baseCalculoIcms'];
			this.aliquotaIcms = jsonObj['aliquotaIcms'];
			this.valorIcms = jsonObj['valorIcms'];
			this.percentualReducaoBcIcms = jsonObj['percentualReducaoBcIcms'];
			this.valorBcIcmsStRetido = jsonObj['valorBcIcmsStRetido'];
			this.valorIcmsStRetido = jsonObj['valorIcmsStRetido'];
			this.aliquotaIcmsStRetido = jsonObj['aliquotaIcmsStRetido'];
			this.valorCreditoPresumidoIcms = jsonObj['valorCreditoPresumidoIcms'];
			this.percentualBcIcmsOutraUf = jsonObj['percentualBcIcmsOutraUf'];
			this.valorBcIcmsOutraUf = jsonObj['valorBcIcmsOutraUf'];
			this.aliquotaIcmsOutraUf = jsonObj['aliquotaIcmsOutraUf'];
			this.valorIcmsOutraUf = jsonObj['valorIcmsOutraUf'];
			this.simplesNacionalIndicador = jsonObj['simplesNacionalIndicador'];
			this.simplesNacionalTotal = jsonObj['simplesNacionalTotal'];
			this.informacoesAddFisco = jsonObj['informacoesAddFisco'];
			this.valorTotalCarga = jsonObj['valorTotalCarga'];
			this.produtoPredominante = jsonObj['produtoPredominante'];
			this.cargaOutrasCaracteristicas = jsonObj['cargaOutrasCaracteristicas'];
			this.modalVersaoLayout = jsonObj['modalVersaoLayout'];
			this.chaveCteSubstituido = jsonObj['chaveCteSubstituido'];
			this.cteEmitenteModelList = [];
			let cteEmitenteModelJsonList = jsonObj['cteEmitenteModelList'];
			if (cteEmitenteModelJsonList != null) {
				for (let i = 0; i < cteEmitenteModelJsonList.length; i++) {
					let obj = new CteEmitenteModel(cteEmitenteModelJsonList[i]);
					this.cteEmitenteModelList.push(obj);
				}
			}

			this.cteLocalColetaModelList = [];
			let cteLocalColetaModelJsonList = jsonObj['cteLocalColetaModelList'];
			if (cteLocalColetaModelJsonList != null) {
				for (let i = 0; i < cteLocalColetaModelJsonList.length; i++) {
					let obj = new CteLocalColetaModel(cteLocalColetaModelJsonList[i]);
					this.cteLocalColetaModelList.push(obj);
				}
			}

			this.cteTomadorModelList = [];
			let cteTomadorModelJsonList = jsonObj['cteTomadorModelList'];
			if (cteTomadorModelJsonList != null) {
				for (let i = 0; i < cteTomadorModelJsonList.length; i++) {
					let obj = new CteTomadorModel(cteTomadorModelJsonList[i]);
					this.cteTomadorModelList.push(obj);
				}
			}

			this.ctePassagemModelList = [];
			let ctePassagemModelJsonList = jsonObj['ctePassagemModelList'];
			if (ctePassagemModelJsonList != null) {
				for (let i = 0; i < ctePassagemModelJsonList.length; i++) {
					let obj = new CtePassagemModel(ctePassagemModelJsonList[i]);
					this.ctePassagemModelList.push(obj);
				}
			}

			this.cteRemetenteModelList = [];
			let cteRemetenteModelJsonList = jsonObj['cteRemetenteModelList'];
			if (cteRemetenteModelJsonList != null) {
				for (let i = 0; i < cteRemetenteModelJsonList.length; i++) {
					let obj = new CteRemetenteModel(cteRemetenteModelJsonList[i]);
					this.cteRemetenteModelList.push(obj);
				}
			}

			this.cteExpedidorModelList = [];
			let cteExpedidorModelJsonList = jsonObj['cteExpedidorModelList'];
			if (cteExpedidorModelJsonList != null) {
				for (let i = 0; i < cteExpedidorModelJsonList.length; i++) {
					let obj = new CteExpedidorModel(cteExpedidorModelJsonList[i]);
					this.cteExpedidorModelList.push(obj);
				}
			}

			this.cteRecebedorModelList = [];
			let cteRecebedorModelJsonList = jsonObj['cteRecebedorModelList'];
			if (cteRecebedorModelJsonList != null) {
				for (let i = 0; i < cteRecebedorModelJsonList.length; i++) {
					let obj = new CteRecebedorModel(cteRecebedorModelJsonList[i]);
					this.cteRecebedorModelList.push(obj);
				}
			}

			this.cteDestinatarioModelList = [];
			let cteDestinatarioModelJsonList = jsonObj['cteDestinatarioModelList'];
			if (cteDestinatarioModelJsonList != null) {
				for (let i = 0; i < cteDestinatarioModelJsonList.length; i++) {
					let obj = new CteDestinatarioModel(cteDestinatarioModelJsonList[i]);
					this.cteDestinatarioModelList.push(obj);
				}
			}

			this.cteLocalEntregaModelList = [];
			let cteLocalEntregaModelJsonList = jsonObj['cteLocalEntregaModelList'];
			if (cteLocalEntregaModelJsonList != null) {
				for (let i = 0; i < cteLocalEntregaModelJsonList.length; i++) {
					let obj = new CteLocalEntregaModel(cteLocalEntregaModelJsonList[i]);
					this.cteLocalEntregaModelList.push(obj);
				}
			}

			this.cteComponenteModelList = [];
			let cteComponenteModelJsonList = jsonObj['cteComponenteModelList'];
			if (cteComponenteModelJsonList != null) {
				for (let i = 0; i < cteComponenteModelJsonList.length; i++) {
					let obj = new CteComponenteModel(cteComponenteModelJsonList[i]);
					this.cteComponenteModelList.push(obj);
				}
			}

			this.cteCargaModelList = [];
			let cteCargaModelJsonList = jsonObj['cteCargaModelList'];
			if (cteCargaModelJsonList != null) {
				for (let i = 0; i < cteCargaModelJsonList.length; i++) {
					let obj = new CteCargaModel(cteCargaModelJsonList[i]);
					this.cteCargaModelList.push(obj);
				}
			}

			this.cteInformacaoNfOutrosModelList = [];
			let cteInformacaoNfOutrosModelJsonList = jsonObj['cteInformacaoNfOutrosModelList'];
			if (cteInformacaoNfOutrosModelJsonList != null) {
				for (let i = 0; i < cteInformacaoNfOutrosModelJsonList.length; i++) {
					let obj = new CteInformacaoNfOutrosModel(cteInformacaoNfOutrosModelJsonList[i]);
					this.cteInformacaoNfOutrosModelList.push(obj);
				}
			}

			this.cteSeguroModelList = [];
			let cteSeguroModelJsonList = jsonObj['cteSeguroModelList'];
			if (cteSeguroModelJsonList != null) {
				for (let i = 0; i < cteSeguroModelJsonList.length; i++) {
					let obj = new CteSeguroModel(cteSeguroModelJsonList[i]);
					this.cteSeguroModelList.push(obj);
				}
			}

			this.ctePerigosoModelList = [];
			let ctePerigosoModelJsonList = jsonObj['ctePerigosoModelList'];
			if (ctePerigosoModelJsonList != null) {
				for (let i = 0; i < ctePerigosoModelJsonList.length; i++) {
					let obj = new CtePerigosoModel(ctePerigosoModelJsonList[i]);
					this.ctePerigosoModelList.push(obj);
				}
			}

			this.cteVeiculoNovoModelList = [];
			let cteVeiculoNovoModelJsonList = jsonObj['cteVeiculoNovoModelList'];
			if (cteVeiculoNovoModelJsonList != null) {
				for (let i = 0; i < cteVeiculoNovoModelJsonList.length; i++) {
					let obj = new CteVeiculoNovoModel(cteVeiculoNovoModelJsonList[i]);
					this.cteVeiculoNovoModelList.push(obj);
				}
			}

			this.cteFaturaModelList = [];
			let cteFaturaModelJsonList = jsonObj['cteFaturaModelList'];
			if (cteFaturaModelJsonList != null) {
				for (let i = 0; i < cteFaturaModelJsonList.length; i++) {
					let obj = new CteFaturaModel(cteFaturaModelJsonList[i]);
					this.cteFaturaModelList.push(obj);
				}
			}

			this.cteDuplicataModelList = [];
			let cteDuplicataModelJsonList = jsonObj['cteDuplicataModelList'];
			if (cteDuplicataModelJsonList != null) {
				for (let i = 0; i < cteDuplicataModelJsonList.length; i++) {
					let obj = new CteDuplicataModel(cteDuplicataModelJsonList[i]);
					this.cteDuplicataModelList.push(obj);
				}
			}

			this.cteRodoviarioModelList = [];
			let cteRodoviarioModelJsonList = jsonObj['cteRodoviarioModelList'];
			if (cteRodoviarioModelJsonList != null) {
				for (let i = 0; i < cteRodoviarioModelJsonList.length; i++) {
					let obj = new CteRodoviarioModel(cteRodoviarioModelJsonList[i]);
					this.cteRodoviarioModelList.push(obj);
				}
			}

			this.cteAereoModelList = [];
			let cteAereoModelJsonList = jsonObj['cteAereoModelList'];
			if (cteAereoModelJsonList != null) {
				for (let i = 0; i < cteAereoModelJsonList.length; i++) {
					let obj = new CteAereoModel(cteAereoModelJsonList[i]);
					this.cteAereoModelList.push(obj);
				}
			}

			this.cteAquaviarioModelList = [];
			let cteAquaviarioModelJsonList = jsonObj['cteAquaviarioModelList'];
			if (cteAquaviarioModelJsonList != null) {
				for (let i = 0; i < cteAquaviarioModelJsonList.length; i++) {
					let obj = new CteAquaviarioModel(cteAquaviarioModelJsonList[i]);
					this.cteAquaviarioModelList.push(obj);
				}
			}

			this.cteFerroviarioModelList = [];
			let cteFerroviarioModelJsonList = jsonObj['cteFerroviarioModelList'];
			if (cteFerroviarioModelJsonList != null) {
				for (let i = 0; i < cteFerroviarioModelJsonList.length; i++) {
					let obj = new CteFerroviarioModel(cteFerroviarioModelJsonList[i]);
					this.cteFerroviarioModelList.push(obj);
				}
			}

			this.cteDutoviarioModelList = [];
			let cteDutoviarioModelJsonList = jsonObj['cteDutoviarioModelList'];
			if (cteDutoviarioModelJsonList != null) {
				for (let i = 0; i < cteDutoviarioModelJsonList.length; i++) {
					let obj = new CteDutoviarioModel(cteDutoviarioModelJsonList[i]);
					this.cteDutoviarioModelList.push(obj);
				}
			}

			this.cteMultimodalModelList = [];
			let cteMultimodalModelJsonList = jsonObj['cteMultimodalModelList'];
			if (cteMultimodalModelJsonList != null) {
				for (let i = 0; i < cteMultimodalModelJsonList.length; i++) {
					let obj = new CteMultimodalModel(cteMultimodalModelJsonList[i]);
					this.cteMultimodalModelList.push(obj);
				}
			}

		}
	}
}