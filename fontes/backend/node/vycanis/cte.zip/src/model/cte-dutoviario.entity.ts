import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_dutoviario' })
export class CteDutoviarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_tarifa', type: 'decimal', precision: 18, scale: 6 }) 
	valorTarifa: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteDutoviarioModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorTarifa = jsonObj['valorTarifa'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
		}
	}
}