import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_rodoviario' })
export class CteRodoviarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'rntrc' }) 
	rntrc: string; 

	@Column({ name: 'data_prevista_entrega' }) 
	dataPrevistaEntrega: Date; 

	@Column({ name: 'indicador_lotacao' }) 
	indicadorLotacao: string; 

	@Column({ name: 'ciot' }) 
	ciot: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteRodoviarioModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.rntrc = jsonObj['rntrc'];
			this.dataPrevistaEntrega = jsonObj['dataPrevistaEntrega'];
			this.indicadorLotacao = jsonObj['indicadorLotacao'];
			this.ciot = jsonObj['ciot'];
		}
	}
}