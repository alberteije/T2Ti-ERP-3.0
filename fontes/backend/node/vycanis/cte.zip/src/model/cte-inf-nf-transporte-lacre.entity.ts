import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteInformacaoNfTransporteModel } from '../entities-export';

@Entity({ name: 'cte_inf_nf_transporte_lacre' })
export class CteInfNfTransporteLacreModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteInformacaoNfTransporteModel)
	@JoinColumn({ name: 'id_cte_informacao_nf_transporte' })
	cteInformacaoNfTransporteModel: CteInformacaoNfTransporteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			if (jsonObj['cteInformacaoNfTransporteModel'] != null) {
				this.cteInformacaoNfTransporteModel = new CteInformacaoNfTransporteModel(jsonObj['cteInformacaoNfTransporteModel']);
			}

		}
	}
}