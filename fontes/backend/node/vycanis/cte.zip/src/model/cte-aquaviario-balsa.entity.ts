import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteAquaviarioModel } from '../entities-export';

@Entity({ name: 'cte_aquaviario_balsa' })
export class CteAquaviarioBalsaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_balsa' }) 
	idBalsa: string; 

	@Column({ name: 'numero_viagem' }) 
	numeroViagem: number; 

	@Column({ name: 'direcao' }) 
	direcao: string; 

	@Column({ name: 'porto_embarque' }) 
	portoEmbarque: string; 

	@Column({ name: 'porto_transbordo' }) 
	portoTransbordo: string; 

	@Column({ name: 'porto_destino' }) 
	portoDestino: string; 

	@Column({ name: 'tipo_navegacao' }) 
	tipoNavegacao: string; 

	@Column({ name: 'irin' }) 
	irin: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteAquaviarioModel)
	@JoinColumn({ name: 'id_cte_aquaviario' })
	cteAquaviarioModel: CteAquaviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idBalsa = jsonObj['idBalsa'];
			this.numeroViagem = jsonObj['numeroViagem'];
			this.direcao = jsonObj['direcao'];
			this.portoEmbarque = jsonObj['portoEmbarque'];
			this.portoTransbordo = jsonObj['portoTransbordo'];
			this.portoDestino = jsonObj['portoDestino'];
			this.tipoNavegacao = jsonObj['tipoNavegacao'];
			this.irin = jsonObj['irin'];
			if (jsonObj['cteAquaviarioModel'] != null) {
				this.cteAquaviarioModel = new CteAquaviarioModel(jsonObj['cteAquaviarioModel']);
			}

		}
	}
}