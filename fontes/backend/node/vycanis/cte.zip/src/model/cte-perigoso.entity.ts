import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_perigoso' })
export class CtePerigosoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_onu' }) 
	numeroOnu: string; 

	@Column({ name: 'nome_apropriado' }) 
	nomeApropriado: string; 

	@Column({ name: 'classe_risco' }) 
	classeRisco: string; 

	@Column({ name: 'grupo_embalagem' }) 
	grupoEmbalagem: string; 

	@Column({ name: 'quantidade_total_produto' }) 
	quantidadeTotalProduto: string; 

	@Column({ name: 'quantidade_tipo_volume' }) 
	quantidadeTipoVolume: string; 

	@Column({ name: 'ponto_fulgor' }) 
	pontoFulgor: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.ctePerigosoModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroOnu = jsonObj['numeroOnu'];
			this.nomeApropriado = jsonObj['nomeApropriado'];
			this.classeRisco = jsonObj['classeRisco'];
			this.grupoEmbalagem = jsonObj['grupoEmbalagem'];
			this.quantidadeTotalProduto = jsonObj['quantidadeTotalProduto'];
			this.quantidadeTipoVolume = jsonObj['quantidadeTipoVolume'];
			this.pontoFulgor = jsonObj['pontoFulgor'];
		}
	}
}