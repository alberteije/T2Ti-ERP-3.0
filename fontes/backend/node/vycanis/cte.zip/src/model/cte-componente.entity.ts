import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_componente' })
export class CteComponenteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteComponenteModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.valor = jsonObj['valor'];
		}
	}
}