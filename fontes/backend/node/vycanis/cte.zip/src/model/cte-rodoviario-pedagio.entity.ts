import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteRodoviarioModel } from '../entities-export';

@Entity({ name: 'cte_rodoviario_pedagio' })
export class CteRodoviarioPedagioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj_fornecedor' }) 
	cnpjFornecedor: string; 

	@Column({ name: 'comprovante_compra' }) 
	comprovanteCompra: string; 

	@Column({ name: 'cnpj_responsavel' }) 
	cnpjResponsavel: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@OneToOne(() => CteRodoviarioModel)
	@JoinColumn({ name: 'id_cte_rodoviario' })
	cteRodoviarioModel: CteRodoviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpjFornecedor = jsonObj['cnpjFornecedor'];
			this.comprovanteCompra = jsonObj['comprovanteCompra'];
			this.cnpjResponsavel = jsonObj['cnpjResponsavel'];
			this.valor = jsonObj['valor'];
			if (jsonObj['cteRodoviarioModel'] != null) {
				this.cteRodoviarioModel = new CteRodoviarioModel(jsonObj['cteRodoviarioModel']);
			}

		}
	}
}