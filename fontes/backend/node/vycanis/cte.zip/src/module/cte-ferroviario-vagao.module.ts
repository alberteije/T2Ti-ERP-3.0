import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteFerroviarioVagaoController } from '../controller/cte-ferroviario-vagao.controller';
import { CteFerroviarioVagaoService } from '../service/cte-ferroviario-vagao.service';
import { CteFerroviarioVagaoModel } from '../model/cte-ferroviario-vagao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteFerroviarioVagaoModel])],
    controllers: [CteFerroviarioVagaoController],
    providers: [CteFerroviarioVagaoService],
})
export class CteFerroviarioVagaoModule { }
