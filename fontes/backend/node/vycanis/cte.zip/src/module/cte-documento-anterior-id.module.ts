import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteDocumentoAnteriorIdController } from '../controller/cte-documento-anterior-id.controller';
import { CteDocumentoAnteriorIdService } from '../service/cte-documento-anterior-id.service';
import { CteDocumentoAnteriorIdModel } from '../model/cte-documento-anterior-id.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteDocumentoAnteriorIdModel])],
    controllers: [CteDocumentoAnteriorIdController],
    providers: [CteDocumentoAnteriorIdService],
})
export class CteDocumentoAnteriorIdModule { }
