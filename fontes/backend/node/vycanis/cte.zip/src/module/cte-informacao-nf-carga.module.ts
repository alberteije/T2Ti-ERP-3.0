import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteInformacaoNfCargaController } from '../controller/cte-informacao-nf-carga.controller';
import { CteInformacaoNfCargaService } from '../service/cte-informacao-nf-carga.service';
import { CteInformacaoNfCargaModel } from '../model/cte-informacao-nf-carga.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteInformacaoNfCargaModel])],
    controllers: [CteInformacaoNfCargaController],
    providers: [CteInformacaoNfCargaService],
})
export class CteInformacaoNfCargaModule { }
