import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteRodoviarioMotoristaController } from '../controller/cte-rodoviario-motorista.controller';
import { CteRodoviarioMotoristaService } from '../service/cte-rodoviario-motorista.service';
import { CteRodoviarioMotoristaModel } from '../model/cte-rodoviario-motorista.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteRodoviarioMotoristaModel])],
    controllers: [CteRodoviarioMotoristaController],
    providers: [CteRodoviarioMotoristaService],
})
export class CteRodoviarioMotoristaModule { }
