import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteRodoviarioOccController } from '../controller/cte-rodoviario-occ.controller';
import { CteRodoviarioOccService } from '../service/cte-rodoviario-occ.service';
import { CteRodoviarioOccModel } from '../model/cte-rodoviario-occ.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteRodoviarioOccModel])],
    controllers: [CteRodoviarioOccController],
    providers: [CteRodoviarioOccService],
})
export class CteRodoviarioOccModule { }
