import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteInfNfTransporteLacreController } from '../controller/cte-inf-nf-transporte-lacre.controller';
import { CteInfNfTransporteLacreService } from '../service/cte-inf-nf-transporte-lacre.service';
import { CteInfNfTransporteLacreModel } from '../model/cte-inf-nf-transporte-lacre.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteInfNfTransporteLacreModel])],
    controllers: [CteInfNfTransporteLacreController],
    providers: [CteInfNfTransporteLacreService],
})
export class CteInfNfTransporteLacreModule { }
