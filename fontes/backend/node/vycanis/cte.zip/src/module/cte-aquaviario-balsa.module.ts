import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteAquaviarioBalsaController } from '../controller/cte-aquaviario-balsa.controller';
import { CteAquaviarioBalsaService } from '../service/cte-aquaviario-balsa.service';
import { CteAquaviarioBalsaModel } from '../model/cte-aquaviario-balsa.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteAquaviarioBalsaModel])],
    controllers: [CteAquaviarioBalsaController],
    providers: [CteAquaviarioBalsaService],
})
export class CteAquaviarioBalsaModule { }
