import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteInfNfTransporteLacreService } from '../service/cte-inf-nf-transporte-lacre.service';
import { CteInfNfTransporteLacreModel } from '../model/cte-inf-nf-transporte-lacre.entity';

@Crud({
  model: {
    type: CteInfNfTransporteLacreModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-inf-nf-transporte-lacre')
export class CteInfNfTransporteLacreController implements CrudController<CteInfNfTransporteLacreModel> {
  constructor(public service: CteInfNfTransporteLacreService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteInfNfTransporteLacreModel = new CteInfNfTransporteLacreModel(jsonObj);
		const result = await this.service.save(cteInfNfTransporteLacreModel);
		return result;
	}  


}


















