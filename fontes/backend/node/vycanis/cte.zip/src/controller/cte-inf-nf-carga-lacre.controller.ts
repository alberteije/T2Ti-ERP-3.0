import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteInfNfCargaLacreService } from '../service/cte-inf-nf-carga-lacre.service';
import { CteInfNfCargaLacreModel } from '../model/cte-inf-nf-carga-lacre.entity';

@Crud({
  model: {
    type: CteInfNfCargaLacreModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-inf-nf-carga-lacre')
export class CteInfNfCargaLacreController implements CrudController<CteInfNfCargaLacreModel> {
  constructor(public service: CteInfNfCargaLacreService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteInfNfCargaLacreModel = new CteInfNfCargaLacreModel(jsonObj);
		const result = await this.service.save(cteInfNfCargaLacreModel);
		return result;
	}  


}


















