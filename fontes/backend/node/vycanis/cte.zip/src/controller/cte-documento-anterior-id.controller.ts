import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteDocumentoAnteriorIdService } from '../service/cte-documento-anterior-id.service';
import { CteDocumentoAnteriorIdModel } from '../model/cte-documento-anterior-id.entity';

@Crud({
  model: {
    type: CteDocumentoAnteriorIdModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-documento-anterior-id')
export class CteDocumentoAnteriorIdController implements CrudController<CteDocumentoAnteriorIdModel> {
  constructor(public service: CteDocumentoAnteriorIdService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteDocumentoAnteriorIdModel = new CteDocumentoAnteriorIdModel(jsonObj);
		const result = await this.service.save(cteDocumentoAnteriorIdModel);
		return result;
	}  


}


















