import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteRodoviarioOccService } from '../service/cte-rodoviario-occ.service';
import { CteRodoviarioOccModel } from '../model/cte-rodoviario-occ.entity';

@Crud({
  model: {
    type: CteRodoviarioOccModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-rodoviario-occ')
export class CteRodoviarioOccController implements CrudController<CteRodoviarioOccModel> {
  constructor(public service: CteRodoviarioOccService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteRodoviarioOccModel = new CteRodoviarioOccModel(jsonObj);
		const result = await this.service.save(cteRodoviarioOccModel);
		return result;
	}  


}


















