import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteRodoviarioVeiculoService } from '../service/cte-rodoviario-veiculo.service';
import { CteRodoviarioVeiculoModel } from '../model/cte-rodoviario-veiculo.entity';

@Crud({
  model: {
    type: CteRodoviarioVeiculoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-rodoviario-veiculo')
export class CteRodoviarioVeiculoController implements CrudController<CteRodoviarioVeiculoModel> {
  constructor(public service: CteRodoviarioVeiculoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteRodoviarioVeiculoModel = new CteRodoviarioVeiculoModel(jsonObj);
		const result = await this.service.save(cteRodoviarioVeiculoModel);
		return result;
	}  


}


















