import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteFerroviarioVagaoService } from '../service/cte-ferroviario-vagao.service';
import { CteFerroviarioVagaoModel } from '../model/cte-ferroviario-vagao.entity';

@Crud({
  model: {
    type: CteFerroviarioVagaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-ferroviario-vagao')
export class CteFerroviarioVagaoController implements CrudController<CteFerroviarioVagaoModel> {
  constructor(public service: CteFerroviarioVagaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteFerroviarioVagaoModel = new CteFerroviarioVagaoModel(jsonObj);
		const result = await this.service.save(cteFerroviarioVagaoModel);
		return result;
	}  


}


















