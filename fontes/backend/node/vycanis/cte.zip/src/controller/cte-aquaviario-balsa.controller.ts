import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteAquaviarioBalsaService } from '../service/cte-aquaviario-balsa.service';
import { CteAquaviarioBalsaModel } from '../model/cte-aquaviario-balsa.entity';

@Crud({
  model: {
    type: CteAquaviarioBalsaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-aquaviario-balsa')
export class CteAquaviarioBalsaController implements CrudController<CteAquaviarioBalsaModel> {
  constructor(public service: CteAquaviarioBalsaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteAquaviarioBalsaModel = new CteAquaviarioBalsaModel(jsonObj);
		const result = await this.service.save(cteAquaviarioBalsaModel);
		return result;
	}  


}


















