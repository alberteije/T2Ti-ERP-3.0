import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteRodoviarioLacreService } from '../service/cte-rodoviario-lacre.service';
import { CteRodoviarioLacreModel } from '../model/cte-rodoviario-lacre.entity';

@Crud({
  model: {
    type: CteRodoviarioLacreModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-rodoviario-lacre')
export class CteRodoviarioLacreController implements CrudController<CteRodoviarioLacreModel> {
  constructor(public service: CteRodoviarioLacreService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteRodoviarioLacreModel = new CteRodoviarioLacreModel(jsonObj);
		const result = await this.service.save(cteRodoviarioLacreModel);
		return result;
	}  


}


















