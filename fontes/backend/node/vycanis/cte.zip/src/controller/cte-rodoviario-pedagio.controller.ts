import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteRodoviarioPedagioService } from '../service/cte-rodoviario-pedagio.service';
import { CteRodoviarioPedagioModel } from '../model/cte-rodoviario-pedagio.entity';

@Crud({
  model: {
    type: CteRodoviarioPedagioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-rodoviario-pedagio')
export class CteRodoviarioPedagioController implements CrudController<CteRodoviarioPedagioModel> {
  constructor(public service: CteRodoviarioPedagioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteRodoviarioPedagioModel = new CteRodoviarioPedagioModel(jsonObj);
		const result = await this.service.save(cteRodoviarioPedagioModel);
		return result;
	}  


}


















