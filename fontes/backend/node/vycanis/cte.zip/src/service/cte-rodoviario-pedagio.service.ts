import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteRodoviarioPedagioModel } from '../entities-export';

@Injectable()
export class CteRodoviarioPedagioService extends TypeOrmCrudService<CteRodoviarioPedagioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteRodoviarioPedagioModel)
    private readonly repository: Repository<CteRodoviarioPedagioModel>
  ) {
    super(repository);
  }

	async save(cteRodoviarioPedagioModel: CteRodoviarioPedagioModel): Promise<CteRodoviarioPedagioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteRodoviarioPedagioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
