import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteFerroviarioFerroviaModel } from '../entities-export';

@Injectable()
export class CteFerroviarioFerroviaService extends TypeOrmCrudService<CteFerroviarioFerroviaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteFerroviarioFerroviaModel)
    private readonly repository: Repository<CteFerroviarioFerroviaModel>
  ) {
    super(repository);
  }

	async save(cteFerroviarioFerroviaModel: CteFerroviarioFerroviaModel): Promise<CteFerroviarioFerroviaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteFerroviarioFerroviaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
