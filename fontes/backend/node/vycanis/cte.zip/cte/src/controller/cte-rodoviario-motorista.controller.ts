import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteRodoviarioMotoristaService } from '../service/cte-rodoviario-motorista.service';
import { CteRodoviarioMotoristaModel } from '../model/cte-rodoviario-motorista.entity';

@Crud({
  model: {
    type: CteRodoviarioMotoristaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-rodoviario-motorista')
export class CteRodoviarioMotoristaController implements CrudController<CteRodoviarioMotoristaModel> {
  constructor(public service: CteRodoviarioMotoristaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteRodoviarioMotoristaModel = new CteRodoviarioMotoristaModel(jsonObj);
		const result = await this.service.save(cteRodoviarioMotoristaModel);
		return result;
	}  


}


















