import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteInformacaoNfCargaService } from '../service/cte-informacao-nf-carga.service';
import { CteInformacaoNfCargaModel } from '../model/cte-informacao-nf-carga.entity';

@Crud({
  model: {
    type: CteInformacaoNfCargaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-informacao-nf-carga')
export class CteInformacaoNfCargaController implements CrudController<CteInformacaoNfCargaModel> {
  constructor(public service: CteInformacaoNfCargaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteInformacaoNfCargaModel = new CteInformacaoNfCargaModel(jsonObj);
		const result = await this.service.save(cteInformacaoNfCargaModel);
		return result;
	}  


}


















