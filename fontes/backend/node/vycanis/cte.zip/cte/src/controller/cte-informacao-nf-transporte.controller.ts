import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteInformacaoNfTransporteService } from '../service/cte-informacao-nf-transporte.service';
import { CteInformacaoNfTransporteModel } from '../model/cte-informacao-nf-transporte.entity';

@Crud({
  model: {
    type: CteInformacaoNfTransporteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-informacao-nf-transporte')
export class CteInformacaoNfTransporteController implements CrudController<CteInformacaoNfTransporteModel> {
  constructor(public service: CteInformacaoNfTransporteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteInformacaoNfTransporteModel = new CteInformacaoNfTransporteModel(jsonObj);
		const result = await this.service.save(cteInformacaoNfTransporteModel);
		return result;
	}  


}


















