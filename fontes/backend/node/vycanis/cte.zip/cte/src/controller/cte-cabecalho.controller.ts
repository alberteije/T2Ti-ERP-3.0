import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { CteCabecalhoService } from '../service/cte-cabecalho.service';
import { CteCabecalhoModel } from '../model/cte-cabecalho.entity';

@Crud({
  model: {
    type: CteCabecalhoModel,
  },
  query: {
    join: {
			cteEmitenteModelList: { eager: true },
			cteLocalColetaModelList: { eager: true },
			cteTomadorModelList: { eager: true },
			ctePassagemModelList: { eager: true },
			cteRemetenteModelList: { eager: true },
			cteExpedidorModelList: { eager: true },
			cteRecebedorModelList: { eager: true },
			cteDestinatarioModelList: { eager: true },
			cteLocalEntregaModelList: { eager: true },
			cteComponenteModelList: { eager: true },
			cteCargaModelList: { eager: true },
			cteInformacaoNfOutrosModelList: { eager: true },
			cteSeguroModelList: { eager: true },
			ctePerigosoModelList: { eager: true },
			cteVeiculoNovoModelList: { eager: true },
			cteFaturaModelList: { eager: true },
			cteDuplicataModelList: { eager: true },
			cteRodoviarioModelList: { eager: true },
			cteAereoModelList: { eager: true },
			cteAquaviarioModelList: { eager: true },
			cteFerroviarioModelList: { eager: true },
			cteDutoviarioModelList: { eager: true },
			cteMultimodalModelList: { eager: true },
    },
  },
})
@Controller('cte-cabecalho')
export class CteCabecalhoController implements CrudController<CteCabecalhoModel> {
  constructor(public service: CteCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const cteCabecalho = new CteCabecalhoModel(jsonObj);
		const result = await this.service.save(cteCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteCabecalho = new CteCabecalhoModel(jsonObj);
		const result = await this.service.save(cteCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}