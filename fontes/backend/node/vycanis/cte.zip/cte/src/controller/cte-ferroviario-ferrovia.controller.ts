import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CteFerroviarioFerroviaService } from '../service/cte-ferroviario-ferrovia.service';
import { CteFerroviarioFerroviaModel } from '../model/cte-ferroviario-ferrovia.entity';

@Crud({
  model: {
    type: CteFerroviarioFerroviaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cte-ferroviario-ferrovia')
export class CteFerroviarioFerroviaController implements CrudController<CteFerroviarioFerroviaModel> {
  constructor(public service: CteFerroviarioFerroviaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cteFerroviarioFerroviaModel = new CteFerroviarioFerroviaModel(jsonObj);
		const result = await this.service.save(cteFerroviarioFerroviaModel);
		return result;
	}  


}


















