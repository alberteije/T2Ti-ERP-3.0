import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_multimodal' })
export class CteMultimodalModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cotm' }) 
	cotm: string; 

	@Column({ name: 'indicador_negociavel' }) 
	indicadorNegociavel: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteMultimodalModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cotm = jsonObj['cotm'];
			this.indicadorNegociavel = jsonObj['indicadorNegociavel'];
		}
	}
}