import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_informacao_nf_outros' })
export class CteInformacaoNfOutrosModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_romaneio' }) 
	numeroRomaneio: string; 

	@Column({ name: 'numero_pedido' }) 
	numeroPedido: string; 

	@Column({ name: 'chave_acesso_nfe' }) 
	chaveAcessoNfe: string; 

	@Column({ name: 'codigo_modelo' }) 
	codigoModelo: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'data_emissao' }) 
	dataEmissao: Date; 

	@Column({ name: 'uf_emitente' }) 
	ufEmitente: number; 

	@Column({ name: 'base_calculo_icms', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcms: number; 

	@Column({ name: 'valor_icms', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcms: number; 

	@Column({ name: 'base_calculo_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	baseCalculoIcmsSt: number; 

	@Column({ name: 'valor_icms_st', type: 'decimal', precision: 18, scale: 6 }) 
	valorIcmsSt: number; 

	@Column({ name: 'valor_total_produtos', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotalProdutos: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'cfop_predominante' }) 
	cfopPredominante: number; 

	@Column({ name: 'peso_total_kg', type: 'decimal', precision: 18, scale: 6 }) 
	pesoTotalKg: number; 

	@Column({ name: 'pin_suframa' }) 
	pinSuframa: number; 

	@Column({ name: 'data_prevista_entrega' }) 
	dataPrevistaEntrega: Date; 

	@Column({ name: 'outro_tipo_doc_orig' }) 
	outroTipoDocOrig: string; 

	@Column({ name: 'outro_descricao' }) 
	outroDescricao: string; 

	@Column({ name: 'outro_valor_documento', type: 'decimal', precision: 18, scale: 6 }) 
	outroValorDocumento: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteInformacaoNfOutrosModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroRomaneio = jsonObj['numeroRomaneio'];
			this.numeroPedido = jsonObj['numeroPedido'];
			this.chaveAcessoNfe = jsonObj['chaveAcessoNfe'];
			this.codigoModelo = jsonObj['codigoModelo'];
			this.serie = jsonObj['serie'];
			this.numero = jsonObj['numero'];
			this.dataEmissao = jsonObj['dataEmissao'];
			this.ufEmitente = jsonObj['ufEmitente'];
			this.baseCalculoIcms = jsonObj['baseCalculoIcms'];
			this.valorIcms = jsonObj['valorIcms'];
			this.baseCalculoIcmsSt = jsonObj['baseCalculoIcmsSt'];
			this.valorIcmsSt = jsonObj['valorIcmsSt'];
			this.valorTotalProdutos = jsonObj['valorTotalProdutos'];
			this.valorTotal = jsonObj['valorTotal'];
			this.cfopPredominante = jsonObj['cfopPredominante'];
			this.pesoTotalKg = jsonObj['pesoTotalKg'];
			this.pinSuframa = jsonObj['pinSuframa'];
			this.dataPrevistaEntrega = jsonObj['dataPrevistaEntrega'];
			this.outroTipoDocOrig = jsonObj['outroTipoDocOrig'];
			this.outroDescricao = jsonObj['outroDescricao'];
			this.outroValorDocumento = jsonObj['outroValorDocumento'];
		}
	}
}