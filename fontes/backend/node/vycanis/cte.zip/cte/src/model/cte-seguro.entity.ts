import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_seguro' })
export class CteSeguroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'responsavel' }) 
	responsavel: string; 

	@Column({ name: 'seguradora' }) 
	seguradora: string; 

	@Column({ name: 'apolice' }) 
	apolice: string; 

	@Column({ name: 'averbacao' }) 
	averbacao: string; 

	@Column({ name: 'valor_carga', type: 'decimal', precision: 18, scale: 6 }) 
	valorCarga: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteSeguroModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.responsavel = jsonObj['responsavel'];
			this.seguradora = jsonObj['seguradora'];
			this.apolice = jsonObj['apolice'];
			this.averbacao = jsonObj['averbacao'];
			this.valorCarga = jsonObj['valorCarga'];
		}
	}
}