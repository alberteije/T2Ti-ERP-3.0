import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_ferroviario' })
export class CteFerroviarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo_trafego' }) 
	tipoTrafego: string; 

	@Column({ name: 'responsavel_faturamento' }) 
	responsavelFaturamento: string; 

	@Column({ name: 'ferrovia_emitente_cte' }) 
	ferroviaEmitenteCte: string; 

	@Column({ name: 'fluxo' }) 
	fluxo: string; 

	@Column({ name: 'id_trem' }) 
	idTrem: string; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteFerroviarioModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipoTrafego = jsonObj['tipoTrafego'];
			this.responsavelFaturamento = jsonObj['responsavelFaturamento'];
			this.ferroviaEmitenteCte = jsonObj['ferroviaEmitenteCte'];
			this.fluxo = jsonObj['fluxo'];
			this.idTrem = jsonObj['idTrem'];
			this.valorFrete = jsonObj['valorFrete'];
		}
	}
}