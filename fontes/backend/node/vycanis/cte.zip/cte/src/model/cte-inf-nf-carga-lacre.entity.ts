import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteInformacaoNfCargaModel } from '../entities-export';

@Entity({ name: 'cte_inf_nf_carga_lacre' })
export class CteInfNfCargaLacreModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'quantidade_rateada', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeRateada: number; 


	/**
	* Relations
	*/
	@OneToOne(() => CteInformacaoNfCargaModel)
	@JoinColumn({ name: 'id_cte_informacao_nf_carga' })
	cteInformacaoNfCargaModel: CteInformacaoNfCargaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.quantidadeRateada = jsonObj['quantidadeRateada'];
			if (jsonObj['cteInformacaoNfCargaModel'] != null) {
				this.cteInformacaoNfCargaModel = new CteInformacaoNfCargaModel(jsonObj['cteInformacaoNfCargaModel']);
			}

		}
	}
}