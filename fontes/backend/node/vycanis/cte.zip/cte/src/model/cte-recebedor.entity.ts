import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_recebedor' })
export class CteRecebedorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cnpj' }) 
	cnpj: string; 

	@Column({ name: 'cpf' }) 
	cpf: string; 

	@Column({ name: 'ie' }) 
	ie: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'fantasia' }) 
	fantasia: string; 

	@Column({ name: 'telefone' }) 
	telefone: string; 

	@Column({ name: 'logradouro' }) 
	logradouro: string; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'complemento' }) 
	complemento: string; 

	@Column({ name: 'bairro' }) 
	bairro: string; 

	@Column({ name: 'codigo_municipio' }) 
	codigoMunicipio: number; 

	@Column({ name: 'nome_municipio' }) 
	nomeMunicipio: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'cep' }) 
	cep: string; 

	@Column({ name: 'codigo_pais' }) 
	codigoPais: number; 

	@Column({ name: 'nome_pais' }) 
	nomePais: string; 

	@Column({ name: 'email' }) 
	email: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteRecebedorModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.cnpj = jsonObj['cnpj'];
			this.cpf = jsonObj['cpf'];
			this.ie = jsonObj['ie'];
			this.nome = jsonObj['nome'];
			this.fantasia = jsonObj['fantasia'];
			this.telefone = jsonObj['telefone'];
			this.logradouro = jsonObj['logradouro'];
			this.numero = jsonObj['numero'];
			this.complemento = jsonObj['complemento'];
			this.bairro = jsonObj['bairro'];
			this.codigoMunicipio = jsonObj['codigoMunicipio'];
			this.nomeMunicipio = jsonObj['nomeMunicipio'];
			this.uf = jsonObj['uf'];
			this.cep = jsonObj['cep'];
			this.codigoPais = jsonObj['codigoPais'];
			this.nomePais = jsonObj['nomePais'];
			this.email = jsonObj['email'];
		}
	}
}