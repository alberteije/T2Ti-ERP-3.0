import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_passagem' })
export class CtePassagemModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'sigla_passagem' }) 
	siglaPassagem: string; 

	@Column({ name: 'sigla_destino' }) 
	siglaDestino: string; 

	@Column({ name: 'rota' }) 
	rota: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.ctePassagemModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.siglaPassagem = jsonObj['siglaPassagem'];
			this.siglaDestino = jsonObj['siglaDestino'];
			this.rota = jsonObj['rota'];
		}
	}
}