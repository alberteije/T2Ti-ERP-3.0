import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteRodoviarioModel } from '../entities-export';

@Entity({ name: 'cte_rodoviario_lacre' })
export class CteRodoviarioLacreModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteRodoviarioModel)
	@JoinColumn({ name: 'id_cte_rodoviario' })
	cteRodoviarioModel: CteRodoviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			if (jsonObj['cteRodoviarioModel'] != null) {
				this.cteRodoviarioModel = new CteRodoviarioModel(jsonObj['cteRodoviarioModel']);
			}

		}
	}
}