import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteInformacaoNfOutrosModel } from '../entities-export';

@Entity({ name: 'cte_informacao_nf_transporte' })
export class CteInformacaoNfTransporteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo_unidade_transporte' }) 
	tipoUnidadeTransporte: string; 

	@Column({ name: 'id_unidade_transporte' }) 
	idUnidadeTransporte: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteInformacaoNfOutrosModel)
	@JoinColumn({ name: 'id_cte_informacao_nf' })
	cteInformacaoNfOutrosModel: CteInformacaoNfOutrosModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipoUnidadeTransporte = jsonObj['tipoUnidadeTransporte'];
			this.idUnidadeTransporte = jsonObj['idUnidadeTransporte'];
			if (jsonObj['cteInformacaoNfOutrosModel'] != null) {
				this.cteInformacaoNfOutrosModel = new CteInformacaoNfOutrosModel(jsonObj['cteInformacaoNfOutrosModel']);
			}

		}
	}
}