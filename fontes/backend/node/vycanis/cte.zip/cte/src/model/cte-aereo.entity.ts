import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_aereo' })
export class CteAereoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_minuta' }) 
	numeroMinuta: number; 

	@Column({ name: 'numero_conhecimento' }) 
	numeroConhecimento: number; 

	@Column({ name: 'data_prevista_entrega' }) 
	dataPrevistaEntrega: Date; 

	@Column({ name: 'id_emissor' }) 
	idEmissor: string; 

	@Column({ name: 'id_interna_tomador' }) 
	idInternaTomador: string; 

	@Column({ name: 'tarifa_classe' }) 
	tarifaClasse: string; 

	@Column({ name: 'tarifa_codigo' }) 
	tarifaCodigo: string; 

	@Column({ name: 'tarifa_valor', type: 'decimal', precision: 18, scale: 6 }) 
	tarifaValor: number; 

	@Column({ name: 'carga_dimensao' }) 
	cargaDimensao: string; 

	@Column({ name: 'carga_informacao_manuseio' }) 
	cargaInformacaoManuseio: string; 

	@Column({ name: 'carga_especial' }) 
	cargaEspecial: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteAereoModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroMinuta = jsonObj['numeroMinuta'];
			this.numeroConhecimento = jsonObj['numeroConhecimento'];
			this.dataPrevistaEntrega = jsonObj['dataPrevistaEntrega'];
			this.idEmissor = jsonObj['idEmissor'];
			this.idInternaTomador = jsonObj['idInternaTomador'];
			this.tarifaClasse = jsonObj['tarifaClasse'];
			this.tarifaCodigo = jsonObj['tarifaCodigo'];
			this.tarifaValor = jsonObj['tarifaValor'];
			this.cargaDimensao = jsonObj['cargaDimensao'];
			this.cargaInformacaoManuseio = jsonObj['cargaInformacaoManuseio'];
			this.cargaEspecial = jsonObj['cargaEspecial'];
		}
	}
}