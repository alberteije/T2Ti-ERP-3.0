import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_aquaviario' })
export class CteAquaviarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_prestacao', type: 'decimal', precision: 18, scale: 6 }) 
	valorPrestacao: number; 

	@Column({ name: 'afrmm', type: 'decimal', precision: 18, scale: 6 }) 
	afrmm: number; 

	@Column({ name: 'numero_booking' }) 
	numeroBooking: string; 

	@Column({ name: 'numero_controle' }) 
	numeroControle: string; 

	@Column({ name: 'id_navio' }) 
	idNavio: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteAquaviarioModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorPrestacao = jsonObj['valorPrestacao'];
			this.afrmm = jsonObj['afrmm'];
			this.numeroBooking = jsonObj['numeroBooking'];
			this.numeroControle = jsonObj['numeroControle'];
			this.idNavio = jsonObj['idNavio'];
		}
	}
}