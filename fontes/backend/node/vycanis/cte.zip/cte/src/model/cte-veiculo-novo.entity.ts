import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Entity({ name: 'cte_veiculo_novo' })
export class CteVeiculoNovoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'chassi' }) 
	chassi: string; 

	@Column({ name: 'cor' }) 
	cor: string; 

	@Column({ name: 'descricao_cor' }) 
	descricaoCor: string; 

	@Column({ name: 'codigo_marca_modelo' }) 
	codigoMarcaModelo: string; 

	@Column({ name: 'valor_unitario', type: 'decimal', precision: 18, scale: 6 }) 
	valorUnitario: number; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => CteCabecalhoModel, cteCabecalhoModel => cteCabecalhoModel.cteVeiculoNovoModelList)
	@JoinColumn({ name: 'id_cte_cabecalho' })
	cteCabecalhoModel: CteCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.chassi = jsonObj['chassi'];
			this.cor = jsonObj['cor'];
			this.descricaoCor = jsonObj['descricaoCor'];
			this.codigoMarcaModelo = jsonObj['codigoMarcaModelo'];
			this.valorUnitario = jsonObj['valorUnitario'];
			this.valorFrete = jsonObj['valorFrete'];
		}
	}
}