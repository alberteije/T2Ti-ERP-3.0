import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CteRodoviarioModel } from '../entities-export';

@Entity({ name: 'cte_rodoviario_veiculo' })
export class CteRodoviarioVeiculoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo_interno' }) 
	codigoInterno: string; 

	@Column({ name: 'renavam' }) 
	renavam: string; 

	@Column({ name: 'placa' }) 
	placa: string; 

	@Column({ name: 'tara' }) 
	tara: number; 

	@Column({ name: 'capacidade_kg' }) 
	capacidadeKg: number; 

	@Column({ name: 'capacidade_m3' }) 
	capacidadeM3: number; 

	@Column({ name: 'tipo_propriedade' }) 
	tipoPropriedade: string; 

	@Column({ name: 'tipo_veiculo' }) 
	tipoVeiculo: string; 

	@Column({ name: 'tipo_rodado' }) 
	tipoRodado: string; 

	@Column({ name: 'tipo_carroceria' }) 
	tipoCarroceria: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'proprietario_cpf' }) 
	proprietarioCpf: string; 

	@Column({ name: 'proprietario_cnpj' }) 
	proprietarioCnpj: string; 

	@Column({ name: 'proprietario_rntrc' }) 
	proprietarioRntrc: string; 

	@Column({ name: 'proprietario_nome' }) 
	proprietarioNome: string; 

	@Column({ name: 'proprietario_ie' }) 
	proprietarioIe: string; 

	@Column({ name: 'proprietario_uf' }) 
	proprietarioUf: string; 

	@Column({ name: 'proprietario_tipo' }) 
	proprietarioTipo: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CteRodoviarioModel)
	@JoinColumn({ name: 'id_cte_rodoviario' })
	cteRodoviarioModel: CteRodoviarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigoInterno = jsonObj['codigoInterno'];
			this.renavam = jsonObj['renavam'];
			this.placa = jsonObj['placa'];
			this.tara = jsonObj['tara'];
			this.capacidadeKg = jsonObj['capacidadeKg'];
			this.capacidadeM3 = jsonObj['capacidadeM3'];
			this.tipoPropriedade = jsonObj['tipoPropriedade'];
			this.tipoVeiculo = jsonObj['tipoVeiculo'];
			this.tipoRodado = jsonObj['tipoRodado'];
			this.tipoCarroceria = jsonObj['tipoCarroceria'];
			this.uf = jsonObj['uf'];
			this.proprietarioCpf = jsonObj['proprietarioCpf'];
			this.proprietarioCnpj = jsonObj['proprietarioCnpj'];
			this.proprietarioRntrc = jsonObj['proprietarioRntrc'];
			this.proprietarioNome = jsonObj['proprietarioNome'];
			this.proprietarioIe = jsonObj['proprietarioIe'];
			this.proprietarioUf = jsonObj['proprietarioUf'];
			this.proprietarioTipo = jsonObj['proprietarioTipo'];
			if (jsonObj['cteRodoviarioModel'] != null) {
				this.cteRodoviarioModel = new CteRodoviarioModel(jsonObj['cteRodoviarioModel']);
			}

		}
	}
}