import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteRodoviarioVeiculoModel } from '../entities-export';

@Injectable()
export class CteRodoviarioVeiculoService extends TypeOrmCrudService<CteRodoviarioVeiculoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteRodoviarioVeiculoModel)
    private readonly repository: Repository<CteRodoviarioVeiculoModel>
  ) {
    super(repository);
  }

	async save(cteRodoviarioVeiculoModel: CteRodoviarioVeiculoModel): Promise<CteRodoviarioVeiculoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteRodoviarioVeiculoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
