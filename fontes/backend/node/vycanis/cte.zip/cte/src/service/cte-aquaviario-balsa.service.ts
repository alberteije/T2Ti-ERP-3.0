import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteAquaviarioBalsaModel } from '../entities-export';

@Injectable()
export class CteAquaviarioBalsaService extends TypeOrmCrudService<CteAquaviarioBalsaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteAquaviarioBalsaModel)
    private readonly repository: Repository<CteAquaviarioBalsaModel>
  ) {
    super(repository);
  }

	async save(cteAquaviarioBalsaModel: CteAquaviarioBalsaModel): Promise<CteAquaviarioBalsaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteAquaviarioBalsaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
