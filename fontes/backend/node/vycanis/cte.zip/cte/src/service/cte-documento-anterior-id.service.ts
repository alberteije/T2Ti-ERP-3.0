import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteDocumentoAnteriorIdModel } from '../entities-export';

@Injectable()
export class CteDocumentoAnteriorIdService extends TypeOrmCrudService<CteDocumentoAnteriorIdModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteDocumentoAnteriorIdModel)
    private readonly repository: Repository<CteDocumentoAnteriorIdModel>
  ) {
    super(repository);
  }

	async save(cteDocumentoAnteriorIdModel: CteDocumentoAnteriorIdModel): Promise<CteDocumentoAnteriorIdModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteDocumentoAnteriorIdModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
