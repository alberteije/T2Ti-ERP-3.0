import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteInfNfCargaLacreModel } from '../entities-export';

@Injectable()
export class CteInfNfCargaLacreService extends TypeOrmCrudService<CteInfNfCargaLacreModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteInfNfCargaLacreModel)
    private readonly repository: Repository<CteInfNfCargaLacreModel>
  ) {
    super(repository);
  }

	async save(cteInfNfCargaLacreModel: CteInfNfCargaLacreModel): Promise<CteInfNfCargaLacreModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteInfNfCargaLacreModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
