import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteInformacaoNfTransporteModel } from '../entities-export';

@Injectable()
export class CteInformacaoNfTransporteService extends TypeOrmCrudService<CteInformacaoNfTransporteModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteInformacaoNfTransporteModel)
    private readonly repository: Repository<CteInformacaoNfTransporteModel>
  ) {
    super(repository);
  }

	async save(cteInformacaoNfTransporteModel: CteInformacaoNfTransporteModel): Promise<CteInformacaoNfTransporteModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteInformacaoNfTransporteModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
