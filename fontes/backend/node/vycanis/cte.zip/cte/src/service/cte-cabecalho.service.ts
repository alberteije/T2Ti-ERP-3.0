import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { CteCabecalhoModel } from '../entities-export';

@Injectable()
export class CteCabecalhoService extends TypeOrmCrudService<CteCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(CteCabecalhoModel) 
    private readonly repository: Repository<CteCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(cteCabecalhoModel: CteCabecalhoModel, operation: string): Promise<CteCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, cteCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(cteCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(CteCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from cte_emitente where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_local_coleta where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_tomador where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_passagem where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_remetente where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_expedidor where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_recebedor where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_destinatario where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_local_entrega where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_componente where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_carga where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_informacao_nf_outros where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_seguro where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_perigoso where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_veiculo_novo where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_fatura where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_duplicata where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_rodoviario where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_aereo where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_aquaviario where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_ferroviario where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_dutoviario where id_cte_cabecalho=' + id); 

		await queryRunner.query('delete from cte_multimodal where id_cte_cabecalho=' + id); 

	}
	
}