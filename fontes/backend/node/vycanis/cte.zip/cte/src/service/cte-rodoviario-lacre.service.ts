import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CteRodoviarioLacreModel } from '../entities-export';

@Injectable()
export class CteRodoviarioLacreService extends TypeOrmCrudService<CteRodoviarioLacreModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CteRodoviarioLacreModel)
    private readonly repository: Repository<CteRodoviarioLacreModel>
  ) {
    super(repository);
  }

	async save(cteRodoviarioLacreModel: CteRodoviarioLacreModel): Promise<CteRodoviarioLacreModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cteRodoviarioLacreModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
