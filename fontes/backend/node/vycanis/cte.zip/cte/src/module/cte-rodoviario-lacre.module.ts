import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteRodoviarioLacreController } from '../controller/cte-rodoviario-lacre.controller';
import { CteRodoviarioLacreService } from '../service/cte-rodoviario-lacre.service';
import { CteRodoviarioLacreModel } from '../model/cte-rodoviario-lacre.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteRodoviarioLacreModel])],
    controllers: [CteRodoviarioLacreController],
    providers: [CteRodoviarioLacreService],
})
export class CteRodoviarioLacreModule { }
