import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteInformacaoNfTransporteController } from '../controller/cte-informacao-nf-transporte.controller';
import { CteInformacaoNfTransporteService } from '../service/cte-informacao-nf-transporte.service';
import { CteInformacaoNfTransporteModel } from '../model/cte-informacao-nf-transporte.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteInformacaoNfTransporteModel])],
    controllers: [CteInformacaoNfTransporteController],
    providers: [CteInformacaoNfTransporteService],
})
export class CteInformacaoNfTransporteModule { }
