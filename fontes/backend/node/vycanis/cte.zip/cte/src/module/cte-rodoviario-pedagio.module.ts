import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteRodoviarioPedagioController } from '../controller/cte-rodoviario-pedagio.controller';
import { CteRodoviarioPedagioService } from '../service/cte-rodoviario-pedagio.service';
import { CteRodoviarioPedagioModel } from '../model/cte-rodoviario-pedagio.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteRodoviarioPedagioModel])],
    controllers: [CteRodoviarioPedagioController],
    providers: [CteRodoviarioPedagioService],
})
export class CteRodoviarioPedagioModule { }
