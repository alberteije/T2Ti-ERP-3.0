import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteCabecalhoController } from '../controller/cte-cabecalho.controller';
import { CteCabecalhoService } from '../service/cte-cabecalho.service';
import { CteCabecalhoModel } from '../model/cte-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteCabecalhoModel])],
    controllers: [CteCabecalhoController],
    providers: [CteCabecalhoService],
})
export class CteCabecalhoModule { }
