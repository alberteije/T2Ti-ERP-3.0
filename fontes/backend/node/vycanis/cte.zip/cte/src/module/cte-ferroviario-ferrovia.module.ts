import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteFerroviarioFerroviaController } from '../controller/cte-ferroviario-ferrovia.controller';
import { CteFerroviarioFerroviaService } from '../service/cte-ferroviario-ferrovia.service';
import { CteFerroviarioFerroviaModel } from '../model/cte-ferroviario-ferrovia.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteFerroviarioFerroviaModel])],
    controllers: [CteFerroviarioFerroviaController],
    providers: [CteFerroviarioFerroviaService],
})
export class CteFerroviarioFerroviaModule { }
