import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteRodoviarioVeiculoController } from '../controller/cte-rodoviario-veiculo.controller';
import { CteRodoviarioVeiculoService } from '../service/cte-rodoviario-veiculo.service';
import { CteRodoviarioVeiculoModel } from '../model/cte-rodoviario-veiculo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteRodoviarioVeiculoModel])],
    controllers: [CteRodoviarioVeiculoController],
    providers: [CteRodoviarioVeiculoService],
})
export class CteRodoviarioVeiculoModule { }
