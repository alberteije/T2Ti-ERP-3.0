import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CteInfNfCargaLacreController } from '../controller/cte-inf-nf-carga-lacre.controller';
import { CteInfNfCargaLacreService } from '../service/cte-inf-nf-carga-lacre.service';
import { CteInfNfCargaLacreModel } from '../model/cte-inf-nf-carga-lacre.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CteInfNfCargaLacreModel])],
    controllers: [CteInfNfCargaLacreController],
    providers: [CteInfNfCargaLacreService],
})
export class CteInfNfCargaLacreModule { }
