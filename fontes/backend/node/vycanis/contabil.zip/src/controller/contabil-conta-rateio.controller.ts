import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilContaRateioService } from '../service/contabil-conta-rateio.service';
import { ContabilContaRateioModel } from '../model/contabil-conta-rateio.entity';

@Crud({
  model: {
    type: ContabilContaRateioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-conta-rateio')
export class ContabilContaRateioController implements CrudController<ContabilContaRateioModel> {
  constructor(public service: ContabilContaRateioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilContaRateioModel = new ContabilContaRateioModel(jsonObj);
		const result = await this.service.save(contabilContaRateioModel);
		return result;
	}  


}


















