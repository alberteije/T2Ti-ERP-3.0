import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ContabilEncerramentoExeCabService } from '../service/contabil-encerramento-exe-cab.service';
import { ContabilEncerramentoExeCabModel } from '../model/contabil-encerramento-exe-cab.entity';

@Crud({
  model: {
    type: ContabilEncerramentoExeCabModel,
  },
  query: {
    join: {
			contabilEncerramentoExeDetModelList: { eager: true },
    },
  },
})
@Controller('contabil-encerramento-exe-cab')
export class ContabilEncerramentoExeCabController implements CrudController<ContabilEncerramentoExeCabModel> {
  constructor(public service: ContabilEncerramentoExeCabService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilEncerramentoExeCab = new ContabilEncerramentoExeCabModel(jsonObj);
		const result = await this.service.save(contabilEncerramentoExeCab, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilEncerramentoExeCab = new ContabilEncerramentoExeCabModel(jsonObj);
		const result = await this.service.save(contabilEncerramentoExeCab, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}