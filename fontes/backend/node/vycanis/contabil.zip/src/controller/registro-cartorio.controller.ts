import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { RegistroCartorioService } from '../service/registro-cartorio.service';
import { RegistroCartorioModel } from '../model/registro-cartorio.entity';

@Crud({
  model: {
    type: RegistroCartorioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('registro-cartorio')
export class RegistroCartorioController implements CrudController<RegistroCartorioModel> {
  constructor(public service: RegistroCartorioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const registroCartorioModel = new RegistroCartorioModel(jsonObj);
		const result = await this.service.save(registroCartorioModel);
		return result;
	}  


}


















