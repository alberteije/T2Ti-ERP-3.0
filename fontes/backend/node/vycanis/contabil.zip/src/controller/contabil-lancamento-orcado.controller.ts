import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilLancamentoOrcadoService } from '../service/contabil-lancamento-orcado.service';
import { ContabilLancamentoOrcadoModel } from '../model/contabil-lancamento-orcado.entity';

@Crud({
  model: {
    type: ContabilLancamentoOrcadoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-lancamento-orcado')
export class ContabilLancamentoOrcadoController implements CrudController<ContabilLancamentoOrcadoModel> {
  constructor(public service: ContabilLancamentoOrcadoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilLancamentoOrcadoModel = new ContabilLancamentoOrcadoModel(jsonObj);
		const result = await this.service.save(contabilLancamentoOrcadoModel);
		return result;
	}  


}


















