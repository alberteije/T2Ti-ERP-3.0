import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { AidfAimdfService } from '../service/aidf-aimdf.service';
import { AidfAimdfModel } from '../model/aidf-aimdf.entity';

@Crud({
  model: {
    type: AidfAimdfModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('aidf-aimdf')
export class AidfAimdfController implements CrudController<AidfAimdfModel> {
  constructor(public service: AidfAimdfService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const aidfAimdfModel = new AidfAimdfModel(jsonObj);
		const result = await this.service.save(aidfAimdfModel);
		return result;
	}  


}


















