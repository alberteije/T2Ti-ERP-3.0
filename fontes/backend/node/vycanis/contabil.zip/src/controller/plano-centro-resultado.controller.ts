import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PlanoCentroResultadoService } from '../service/plano-centro-resultado.service';
import { PlanoCentroResultadoModel } from '../model/plano-centro-resultado.entity';

@Crud({
  model: {
    type: PlanoCentroResultadoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('plano-centro-resultado')
export class PlanoCentroResultadoController implements CrudController<PlanoCentroResultadoModel> {
  constructor(public service: PlanoCentroResultadoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const planoCentroResultadoModel = new PlanoCentroResultadoModel(jsonObj);
		const result = await this.service.save(planoCentroResultadoModel);
		return result;
	}  


}


















