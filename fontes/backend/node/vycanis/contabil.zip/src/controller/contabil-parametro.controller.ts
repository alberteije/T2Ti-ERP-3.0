import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilParametroService } from '../service/contabil-parametro.service';
import { ContabilParametroModel } from '../model/contabil-parametro.entity';

@Crud({
  model: {
    type: ContabilParametroModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-parametro')
export class ContabilParametroController implements CrudController<ContabilParametroModel> {
  constructor(public service: ContabilParametroService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilParametroModel = new ContabilParametroModel(jsonObj);
		const result = await this.service.save(contabilParametroModel);
		return result;
	}  


}


















