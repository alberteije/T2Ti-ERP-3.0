import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ContabilLivroService } from '../service/contabil-livro.service';
import { ContabilLivroModel } from '../model/contabil-livro.entity';

@Crud({
  model: {
    type: ContabilLivroModel,
  },
  query: {
    join: {
			contabilTermoModelList: { eager: true },
    },
  },
})
@Controller('contabil-livro')
export class ContabilLivroController implements CrudController<ContabilLivroModel> {
  constructor(public service: ContabilLivroService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilLivro = new ContabilLivroModel(jsonObj);
		const result = await this.service.save(contabilLivro, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilLivro = new ContabilLivroModel(jsonObj);
		const result = await this.service.save(contabilLivro, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}