import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FapService } from '../service/fap.service';
import { FapModel } from '../model/fap.entity';

@Crud({
  model: {
    type: FapModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fap')
export class FapController implements CrudController<FapModel> {
  constructor(public service: FapService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fapModel = new FapModel(jsonObj);
		const result = await this.service.save(fapModel);
		return result;
	}  


}


















