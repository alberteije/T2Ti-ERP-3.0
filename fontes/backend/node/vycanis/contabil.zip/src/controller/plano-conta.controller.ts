import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PlanoContaService } from '../service/plano-conta.service';
import { PlanoContaModel } from '../model/plano-conta.entity';

@Crud({
  model: {
    type: PlanoContaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('plano-conta')
export class PlanoContaController implements CrudController<PlanoContaModel> {
  constructor(public service: PlanoContaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const planoContaModel = new PlanoContaModel(jsonObj);
		const result = await this.service.save(planoContaModel);
		return result;
	}  


}


















