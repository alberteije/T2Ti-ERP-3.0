import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ContabilIndiceService } from '../service/contabil-indice.service';
import { ContabilIndiceModel } from '../model/contabil-indice.entity';

@Crud({
  model: {
    type: ContabilIndiceModel,
  },
  query: {
    join: {
			contabilIndiceValorModelList: { eager: true },
    },
  },
})
@Controller('contabil-indice')
export class ContabilIndiceController implements CrudController<ContabilIndiceModel> {
  constructor(public service: ContabilIndiceService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilIndice = new ContabilIndiceModel(jsonObj);
		const result = await this.service.save(contabilIndice, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilIndice = new ContabilIndiceModel(jsonObj);
		const result = await this.service.save(contabilIndice, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}