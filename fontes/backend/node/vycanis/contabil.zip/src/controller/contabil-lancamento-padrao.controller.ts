import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilLancamentoPadraoService } from '../service/contabil-lancamento-padrao.service';
import { ContabilLancamentoPadraoModel } from '../model/contabil-lancamento-padrao.entity';

@Crud({
  model: {
    type: ContabilLancamentoPadraoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-lancamento-padrao')
export class ContabilLancamentoPadraoController implements CrudController<ContabilLancamentoPadraoModel> {
  constructor(public service: ContabilLancamentoPadraoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilLancamentoPadraoModel = new ContabilLancamentoPadraoModel(jsonObj);
		const result = await this.service.save(contabilLancamentoPadraoModel);
		return result;
	}  


}


















