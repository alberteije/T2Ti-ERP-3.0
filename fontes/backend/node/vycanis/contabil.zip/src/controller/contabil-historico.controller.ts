import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilHistoricoService } from '../service/contabil-historico.service';
import { ContabilHistoricoModel } from '../model/contabil-historico.entity';

@Crud({
  model: {
    type: ContabilHistoricoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-historico')
export class ContabilHistoricoController implements CrudController<ContabilHistoricoModel> {
  constructor(public service: ContabilHistoricoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilHistoricoModel = new ContabilHistoricoModel(jsonObj);
		const result = await this.service.save(contabilHistoricoModel);
		return result;
	}  


}


















