import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LancaCentroResultadoController } from '../controller/lanca-centro-resultado.controller';
import { LancaCentroResultadoService } from '../service/lanca-centro-resultado.service';
import { LancaCentroResultadoModel } from '../model/lanca-centro-resultado.entity';

@Module({
    imports: [TypeOrmModule.forFeature([LancaCentroResultadoModel])],
    controllers: [LancaCentroResultadoController],
    providers: [LancaCentroResultadoService],
})
export class LancaCentroResultadoModule { }
