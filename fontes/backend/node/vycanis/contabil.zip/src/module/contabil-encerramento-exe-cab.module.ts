import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilEncerramentoExeCabController } from '../controller/contabil-encerramento-exe-cab.controller';
import { ContabilEncerramentoExeCabService } from '../service/contabil-encerramento-exe-cab.service';
import { ContabilEncerramentoExeCabModel } from '../model/contabil-encerramento-exe-cab.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilEncerramentoExeCabModel])],
    controllers: [ContabilEncerramentoExeCabController],
    providers: [ContabilEncerramentoExeCabService],
})
export class ContabilEncerramentoExeCabModule { }
