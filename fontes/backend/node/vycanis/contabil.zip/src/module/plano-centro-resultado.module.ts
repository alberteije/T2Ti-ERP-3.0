import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PlanoCentroResultadoController } from '../controller/plano-centro-resultado.controller';
import { PlanoCentroResultadoService } from '../service/plano-centro-resultado.service';
import { PlanoCentroResultadoModel } from '../model/plano-centro-resultado.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PlanoCentroResultadoModel])],
    controllers: [PlanoCentroResultadoController],
    providers: [PlanoCentroResultadoService],
})
export class PlanoCentroResultadoModule { }
