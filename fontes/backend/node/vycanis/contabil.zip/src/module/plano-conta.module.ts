import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PlanoContaController } from '../controller/plano-conta.controller';
import { PlanoContaService } from '../service/plano-conta.service';
import { PlanoContaModel } from '../model/plano-conta.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PlanoContaModel])],
    controllers: [PlanoContaController],
    providers: [PlanoContaService],
})
export class PlanoContaModule { }
