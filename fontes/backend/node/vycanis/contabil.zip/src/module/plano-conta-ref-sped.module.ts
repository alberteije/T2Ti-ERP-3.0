import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PlanoContaRefSpedController } from '../controller/plano-conta-ref-sped.controller';
import { PlanoContaRefSpedService } from '../service/plano-conta-ref-sped.service';
import { PlanoContaRefSpedModel } from '../model/plano-conta-ref-sped.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PlanoContaRefSpedModel])],
    controllers: [PlanoContaRefSpedController],
    providers: [PlanoContaRefSpedService],
})
export class PlanoContaRefSpedModule { }
