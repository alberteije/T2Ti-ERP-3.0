import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilContaController } from '../controller/contabil-conta.controller';
import { ContabilContaService } from '../service/contabil-conta.service';
import { ContabilContaModel } from '../model/contabil-conta.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilContaModel])],
    controllers: [ContabilContaController],
    providers: [ContabilContaService],
})
export class ContabilContaModule { }
