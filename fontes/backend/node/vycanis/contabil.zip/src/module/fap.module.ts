import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FapController } from '../controller/fap.controller';
import { FapService } from '../service/fap.service';
import { FapModel } from '../model/fap.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FapModel])],
    controllers: [FapController],
    providers: [FapService],
})
export class FapModule { }
