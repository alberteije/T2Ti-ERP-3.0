import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilContaRateioController } from '../controller/contabil-conta-rateio.controller';
import { ContabilContaRateioService } from '../service/contabil-conta-rateio.service';
import { ContabilContaRateioModel } from '../model/contabil-conta-rateio.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilContaRateioModel])],
    controllers: [ContabilContaRateioController],
    providers: [ContabilContaRateioService],
})
export class ContabilContaRateioModule { }
