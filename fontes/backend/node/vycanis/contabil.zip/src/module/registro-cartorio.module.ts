import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RegistroCartorioController } from '../controller/registro-cartorio.controller';
import { RegistroCartorioService } from '../service/registro-cartorio.service';
import { RegistroCartorioModel } from '../model/registro-cartorio.entity';

@Module({
    imports: [TypeOrmModule.forFeature([RegistroCartorioModel])],
    controllers: [RegistroCartorioController],
    providers: [RegistroCartorioService],
})
export class RegistroCartorioModule { }
