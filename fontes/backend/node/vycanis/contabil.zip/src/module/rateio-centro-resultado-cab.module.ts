import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RateioCentroResultadoCabController } from '../controller/rateio-centro-resultado-cab.controller';
import { RateioCentroResultadoCabService } from '../service/rateio-centro-resultado-cab.service';
import { RateioCentroResultadoCabModel } from '../model/rateio-centro-resultado-cab.entity';

@Module({
    imports: [TypeOrmModule.forFeature([RateioCentroResultadoCabModel])],
    controllers: [RateioCentroResultadoCabController],
    providers: [RateioCentroResultadoCabService],
})
export class RateioCentroResultadoCabModule { }
