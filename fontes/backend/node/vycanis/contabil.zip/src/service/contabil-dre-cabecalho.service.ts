import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ContabilDreCabecalhoModel } from '../entities-export';

@Injectable()
export class ContabilDreCabecalhoService extends TypeOrmCrudService<ContabilDreCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ContabilDreCabecalhoModel) 
    private readonly repository: Repository<ContabilDreCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(contabilDreCabecalhoModel: ContabilDreCabecalhoModel, operation: string): Promise<ContabilDreCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, contabilDreCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(contabilDreCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ContabilDreCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from contabil_dre_detalhe where id_contabil_dre_cabecalho=' + id); 

	}
	
}