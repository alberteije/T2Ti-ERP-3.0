import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ContabilLoteModel } from '../entities-export';

@Injectable()
export class ContabilLoteService extends TypeOrmCrudService<ContabilLoteModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ContabilLoteModel)
    private readonly repository: Repository<ContabilLoteModel>
  ) {
    super(repository);
  }

	async save(contabilLoteModel: ContabilLoteModel): Promise<ContabilLoteModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(contabilLoteModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
