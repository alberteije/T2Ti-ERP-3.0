import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ContabilHistoricoModel } from '../entities-export';

@Injectable()
export class ContabilHistoricoService extends TypeOrmCrudService<ContabilHistoricoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ContabilHistoricoModel)
    private readonly repository: Repository<ContabilHistoricoModel>
  ) {
    super(repository);
  }

	async save(contabilHistoricoModel: ContabilHistoricoModel): Promise<ContabilHistoricoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(contabilHistoricoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
