import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PlanoContaRefSpedModel } from '../entities-export';

@Injectable()
export class PlanoContaRefSpedService extends TypeOrmCrudService<PlanoContaRefSpedModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PlanoContaRefSpedModel)
    private readonly repository: Repository<PlanoContaRefSpedModel>
  ) {
    super(repository);
  }

	async save(planoContaRefSpedModel: PlanoContaRefSpedModel): Promise<PlanoContaRefSpedModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(planoContaRefSpedModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
