import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ContabilLancamentoCabecalhoModel } from '../entities-export';

@Injectable()
export class ContabilLancamentoCabecalhoService extends TypeOrmCrudService<ContabilLancamentoCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ContabilLancamentoCabecalhoModel) 
    private readonly repository: Repository<ContabilLancamentoCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(contabilLancamentoCabecalhoModel: ContabilLancamentoCabecalhoModel, operation: string): Promise<ContabilLancamentoCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, contabilLancamentoCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(contabilLancamentoCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ContabilLancamentoCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from contabil_lancamento_detalhe where id_contabil_lancamento_cab=' + id); 

	}
	
}