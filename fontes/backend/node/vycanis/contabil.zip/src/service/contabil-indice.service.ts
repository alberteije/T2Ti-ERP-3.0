import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ContabilIndiceModel } from '../entities-export';

@Injectable()
export class ContabilIndiceService extends TypeOrmCrudService<ContabilIndiceModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ContabilIndiceModel) 
    private readonly repository: Repository<ContabilIndiceModel>,
  ) {
    super(repository);
  }

	async save(contabilIndiceModel: ContabilIndiceModel, operation: string): Promise<ContabilIndiceModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, contabilIndiceModel.id);
      }

      const resultObj = await queryRunner.manager.save(contabilIndiceModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ContabilIndiceModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from contabil_indice_valor where id_contabil_indice=' + id); 

	}
	
}