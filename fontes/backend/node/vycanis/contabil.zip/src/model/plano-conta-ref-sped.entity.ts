import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'plano_conta_ref_sped' })
export class PlanoContaRefSpedModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'cod_cta_ref' }) 
	codCtaRef: string; 

	@Column({ name: 'inicio_validade' }) 
	inicioValidade: Date; 

	@Column({ name: 'fim_validade' }) 
	fimValidade: Date; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'orientacoes' }) 
	orientacoes: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codCtaRef = jsonObj['codCtaRef'];
			this.inicioValidade = jsonObj['inicioValidade'];
			this.fimValidade = jsonObj['fimValidade'];
			this.tipo = jsonObj['tipo'];
			this.descricao = jsonObj['descricao'];
			this.orientacoes = jsonObj['orientacoes'];
		}
	}
}