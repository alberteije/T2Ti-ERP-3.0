import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilLancamentoCabecalhoModel } from '../entities-export';
import { ContabilHistoricoModel } from '../entities-export';
import { ContabilContaModel } from '../entities-export';

@Entity({ name: 'contabil_lancamento_detalhe' })
export class ContabilLancamentoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'historico' }) 
	historico: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContabilLancamentoCabecalhoModel, contabilLancamentoCabecalhoModel => contabilLancamentoCabecalhoModel.contabilLancamentoDetalheModelList)
	@JoinColumn({ name: 'id_contabil_lancamento_cab' })
	contabilLancamentoCabecalhoModel: ContabilLancamentoCabecalhoModel;

	@OneToOne(() => ContabilHistoricoModel)
	@JoinColumn({ name: 'id_contabil_historico' })
	contabilHistoricoModel: ContabilHistoricoModel;

	@OneToOne(() => ContabilContaModel)
	@JoinColumn({ name: 'id_contabil_conta' })
	contabilContaModel: ContabilContaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipo = jsonObj['tipo'];
			this.valor = jsonObj['valor'];
			this.historico = jsonObj['historico'];
			if (jsonObj['contabilHistoricoModel'] != null) {
				this.contabilHistoricoModel = new ContabilHistoricoModel(jsonObj['contabilHistoricoModel']);
			}

			if (jsonObj['contabilContaModel'] != null) {
				this.contabilContaModel = new ContabilContaModel(jsonObj['contabilContaModel']);
			}

		}
	}
}