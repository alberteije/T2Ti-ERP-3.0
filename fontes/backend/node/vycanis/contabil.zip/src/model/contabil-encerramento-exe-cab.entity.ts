import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilEncerramentoExeDetModel } from '../entities-export';

@Entity({ name: 'contabil_encerramento_exe_cab' })
export class ContabilEncerramentoExeCabModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 

	@Column({ name: 'motivo' }) 
	motivo: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ContabilEncerramentoExeDetModel, contabilEncerramentoExeDetModel => contabilEncerramentoExeDetModel.contabilEncerramentoExeCabModel, { cascade: true })
	contabilEncerramentoExeDetModelList: ContabilEncerramentoExeDetModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
			this.dataInclusao = jsonObj['dataInclusao'];
			this.motivo = jsonObj['motivo'];
			this.contabilEncerramentoExeDetModelList = [];
			let contabilEncerramentoExeDetModelJsonList = jsonObj['contabilEncerramentoExeDetModelList'];
			if (contabilEncerramentoExeDetModelJsonList != null) {
				for (let i = 0; i < contabilEncerramentoExeDetModelJsonList.length; i++) {
					let obj = new ContabilEncerramentoExeDetModel(contabilEncerramentoExeDetModelJsonList[i]);
					this.contabilEncerramentoExeDetModelList.push(obj);
				}
			}

		}
	}
}