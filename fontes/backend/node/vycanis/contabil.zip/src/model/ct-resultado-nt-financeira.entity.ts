import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FinNaturezaFinanceiraModel } from '../entities-export';
import { CentroResultadoModel } from '../entities-export';

@Entity({ name: 'ct_resultado_nt_financeira' })
export class CtResultadoNtFinanceiraModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'percentual_rateio', type: 'decimal', precision: 18, scale: 6 }) 
	percentualRateio: number; 


	/**
	* Relations
	*/
	@OneToOne(() => FinNaturezaFinanceiraModel)
	@JoinColumn({ name: 'id_fin_natureza_financeira' })
	finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel;

	@ManyToOne(() => CentroResultadoModel, centroResultadoModel => centroResultadoModel.ctResultadoNtFinanceiraModelList)
	@JoinColumn({ name: 'id_centro_resultado' })
	centroResultadoModel: CentroResultadoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.percentualRateio = jsonObj['percentualRateio'];
			if (jsonObj['finNaturezaFinanceiraModel'] != null) {
				this.finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel(jsonObj['finNaturezaFinanceiraModel']);
			}

		}
	}
}