import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilDreDetalheModel } from '../entities-export';

@Entity({ name: 'contabil_dre_cabecalho' })
export class ContabilDreCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'padrao' }) 
	padrao: string; 

	@Column({ name: 'periodo_inicial' }) 
	periodoInicial: string; 

	@Column({ name: 'periodo_final' }) 
	periodoFinal: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ContabilDreDetalheModel, contabilDreDetalheModel => contabilDreDetalheModel.contabilDreCabecalhoModel, { cascade: true })
	contabilDreDetalheModelList: ContabilDreDetalheModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.padrao = jsonObj['padrao'];
			this.periodoInicial = jsonObj['periodoInicial'];
			this.periodoFinal = jsonObj['periodoFinal'];
			this.contabilDreDetalheModelList = [];
			let contabilDreDetalheModelJsonList = jsonObj['contabilDreDetalheModelList'];
			if (contabilDreDetalheModelJsonList != null) {
				for (let i = 0; i < contabilDreDetalheModelJsonList.length; i++) {
					let obj = new ContabilDreDetalheModel(contabilDreDetalheModelJsonList[i]);
					this.contabilDreDetalheModelList.push(obj);
				}
			}

		}
	}
}