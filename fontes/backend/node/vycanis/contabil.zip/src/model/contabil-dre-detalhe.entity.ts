import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilDreCabecalhoModel } from '../entities-export';

@Entity({ name: 'contabil_dre_detalhe' })
export class ContabilDreDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'classificacao' }) 
	classificacao: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'forma_calculo' }) 
	formaCalculo: string; 

	@Column({ name: 'sinal' }) 
	sinal: string; 

	@Column({ name: 'natureza' }) 
	natureza: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContabilDreCabecalhoModel, contabilDreCabecalhoModel => contabilDreCabecalhoModel.contabilDreDetalheModelList)
	@JoinColumn({ name: 'id_contabil_dre_cabecalho' })
	contabilDreCabecalhoModel: ContabilDreCabecalhoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.classificacao = jsonObj['classificacao'];
			this.descricao = jsonObj['descricao'];
			this.formaCalculo = jsonObj['formaCalculo'];
			this.sinal = jsonObj['sinal'];
			this.natureza = jsonObj['natureza'];
			this.valor = jsonObj['valor'];
		}
	}
}