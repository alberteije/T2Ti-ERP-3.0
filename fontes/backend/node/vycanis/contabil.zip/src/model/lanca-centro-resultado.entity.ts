import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CentroResultadoModel } from '../entities-export';

@Entity({ name: 'lanca_centro_resultado' })
export class LancaCentroResultadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 

	@Column({ name: 'data_lancamento' }) 
	dataLancamento: Date; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 

	@Column({ name: 'origem_de_rateio' }) 
	origemDeRateio: string; 

	@Column({ name: 'historico' }) 
	historico: string; 


	/**
	* Relations
	*/
	@OneToOne(() => CentroResultadoModel)
	@JoinColumn({ name: 'id_centro_resultado' })
	centroResultadoModel: CentroResultadoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valor = jsonObj['valor'];
			this.dataLancamento = jsonObj['dataLancamento'];
			this.dataInclusao = jsonObj['dataInclusao'];
			this.origemDeRateio = jsonObj['origemDeRateio'];
			this.historico = jsonObj['historico'];
			if (jsonObj['centroResultadoModel'] != null) {
				this.centroResultadoModel = new CentroResultadoModel(jsonObj['centroResultadoModel']);
			}

		}
	}
}