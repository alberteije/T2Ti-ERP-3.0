import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'plano_centro_resultado' })
export class PlanoCentroResultadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'mascara' }) 
	mascara: string; 

	@Column({ name: 'niveis' }) 
	niveis: number; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.mascara = jsonObj['mascara'];
			this.niveis = jsonObj['niveis'];
			this.dataInclusao = jsonObj['dataInclusao'];
		}
	}
}