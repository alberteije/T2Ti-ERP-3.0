import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'fap' })
export class FapModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'fap', type: 'decimal', precision: 18, scale: 6 }) 
	fap: number; 

	@Column({ name: 'data_inicial' }) 
	dataInicial: Date; 

	@Column({ name: 'data_final' }) 
	dataFinal: Date; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.fap = jsonObj['fap'];
			this.dataInicial = jsonObj['dataInicial'];
			this.dataFinal = jsonObj['dataFinal'];
		}
	}
}