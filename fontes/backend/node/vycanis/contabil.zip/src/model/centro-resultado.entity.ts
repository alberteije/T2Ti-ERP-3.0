import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PlanoCentroResultadoModel } from '../entities-export';
import { CtResultadoNtFinanceiraModel } from '../entities-export';

@Entity({ name: 'centro_resultado' })
export class CentroResultadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'classificacao' }) 
	classificacao: string; 

	@Column({ name: 'sofre_rateiro' }) 
	sofreRateiro: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PlanoCentroResultadoModel)
	@JoinColumn({ name: 'id_plano_centro_resultado' })
	planoCentroResultadoModel: PlanoCentroResultadoModel;

	@OneToMany(() => CtResultadoNtFinanceiraModel, ctResultadoNtFinanceiraModel => ctResultadoNtFinanceiraModel.centroResultadoModel, { cascade: true })
	ctResultadoNtFinanceiraModelList: CtResultadoNtFinanceiraModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.classificacao = jsonObj['classificacao'];
			this.sofreRateiro = jsonObj['sofreRateiro'];
			if (jsonObj['planoCentroResultadoModel'] != null) {
				this.planoCentroResultadoModel = new PlanoCentroResultadoModel(jsonObj['planoCentroResultadoModel']);
			}

			this.ctResultadoNtFinanceiraModelList = [];
			let ctResultadoNtFinanceiraModelJsonList = jsonObj['ctResultadoNtFinanceiraModelList'];
			if (ctResultadoNtFinanceiraModelJsonList != null) {
				for (let i = 0; i < ctResultadoNtFinanceiraModelJsonList.length; i++) {
					let obj = new CtResultadoNtFinanceiraModel(ctResultadoNtFinanceiraModelJsonList[i]);
					this.ctResultadoNtFinanceiraModelList.push(obj);
				}
			}

		}
	}
}