import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'contabil_parametro' })
export class ContabilParametroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'mascara' }) 
	mascara: string; 

	@Column({ name: 'niveis' }) 
	niveis: number; 

	@Column({ name: 'informar_conta_por' }) 
	informarContaPor: string; 

	@Column({ name: 'compartilha_plano_conta' }) 
	compartilhaPlanoConta: string; 

	@Column({ name: 'compartilha_historicos' }) 
	compartilhaHistoricos: string; 

	@Column({ name: 'altera_lancamento_outro' }) 
	alteraLancamentoOutro: string; 

	@Column({ name: 'historico_obrigatorio' }) 
	historicoObrigatorio: string; 

	@Column({ name: 'permite_lancamento_zerado' }) 
	permiteLancamentoZerado: string; 

	@Column({ name: 'gera_informativo_sped' }) 
	geraInformativoSped: string; 

	@Column({ name: 'sped_forma_escrit_diario' }) 
	spedFormaEscritDiario: string; 

	@Column({ name: 'sped_nome_livro_diario' }) 
	spedNomeLivroDiario: string; 

	@Column({ name: 'assinatura_direita' }) 
	assinaturaDireita: string; 

	@Column({ name: 'assinatura_esquerda' }) 
	assinaturaEsquerda: string; 

	@Column({ name: 'conta_ativo' }) 
	contaAtivo: string; 

	@Column({ name: 'conta_passivo' }) 
	contaPassivo: string; 

	@Column({ name: 'conta_patrimonio_liquido' }) 
	contaPatrimonioLiquido: string; 

	@Column({ name: 'conta_depreciacao_acumulada' }) 
	contaDepreciacaoAcumulada: string; 

	@Column({ name: 'conta_capital_social' }) 
	contaCapitalSocial: string; 

	@Column({ name: 'conta_resultado_exercicio' }) 
	contaResultadoExercicio: string; 

	@Column({ name: 'conta_prejuizo_acumulado' }) 
	contaPrejuizoAcumulado: string; 

	@Column({ name: 'conta_lucro_acumulado' }) 
	contaLucroAcumulado: string; 

	@Column({ name: 'conta_titulo_pagar' }) 
	contaTituloPagar: string; 

	@Column({ name: 'conta_titulo_receber' }) 
	contaTituloReceber: string; 

	@Column({ name: 'conta_juros_passivo' }) 
	contaJurosPassivo: string; 

	@Column({ name: 'conta_juros_ativo' }) 
	contaJurosAtivo: string; 

	@Column({ name: 'conta_desconto_obtido' }) 
	contaDescontoObtido: string; 

	@Column({ name: 'conta_desconto_concedido' }) 
	contaDescontoConcedido: string; 

	@Column({ name: 'conta_cmv' }) 
	contaCmv: string; 

	@Column({ name: 'conta_venda' }) 
	contaVenda: string; 

	@Column({ name: 'conta_venda_servico' }) 
	contaVendaServico: string; 

	@Column({ name: 'conta_estoque' }) 
	contaEstoque: string; 

	@Column({ name: 'conta_apura_resultado' }) 
	contaApuraResultado: string; 

	@Column({ name: 'conta_juros_apropriar' }) 
	contaJurosApropriar: string; 

	@Column({ name: 'id_hist_padrao_resultado' }) 
	idHistPadraoResultado: number; 

	@Column({ name: 'id_hist_padrao_lucro' }) 
	idHistPadraoLucro: number; 

	@Column({ name: 'id_hist_padrao_prejuizo' }) 
	idHistPadraoPrejuizo: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.mascara = jsonObj['mascara'];
			this.niveis = jsonObj['niveis'];
			this.informarContaPor = jsonObj['informarContaPor'];
			this.compartilhaPlanoConta = jsonObj['compartilhaPlanoConta'];
			this.compartilhaHistoricos = jsonObj['compartilhaHistoricos'];
			this.alteraLancamentoOutro = jsonObj['alteraLancamentoOutro'];
			this.historicoObrigatorio = jsonObj['historicoObrigatorio'];
			this.permiteLancamentoZerado = jsonObj['permiteLancamentoZerado'];
			this.geraInformativoSped = jsonObj['geraInformativoSped'];
			this.spedFormaEscritDiario = jsonObj['spedFormaEscritDiario'];
			this.spedNomeLivroDiario = jsonObj['spedNomeLivroDiario'];
			this.assinaturaDireita = jsonObj['assinaturaDireita'];
			this.assinaturaEsquerda = jsonObj['assinaturaEsquerda'];
			this.contaAtivo = jsonObj['contaAtivo'];
			this.contaPassivo = jsonObj['contaPassivo'];
			this.contaPatrimonioLiquido = jsonObj['contaPatrimonioLiquido'];
			this.contaDepreciacaoAcumulada = jsonObj['contaDepreciacaoAcumulada'];
			this.contaCapitalSocial = jsonObj['contaCapitalSocial'];
			this.contaResultadoExercicio = jsonObj['contaResultadoExercicio'];
			this.contaPrejuizoAcumulado = jsonObj['contaPrejuizoAcumulado'];
			this.contaLucroAcumulado = jsonObj['contaLucroAcumulado'];
			this.contaTituloPagar = jsonObj['contaTituloPagar'];
			this.contaTituloReceber = jsonObj['contaTituloReceber'];
			this.contaJurosPassivo = jsonObj['contaJurosPassivo'];
			this.contaJurosAtivo = jsonObj['contaJurosAtivo'];
			this.contaDescontoObtido = jsonObj['contaDescontoObtido'];
			this.contaDescontoConcedido = jsonObj['contaDescontoConcedido'];
			this.contaCmv = jsonObj['contaCmv'];
			this.contaVenda = jsonObj['contaVenda'];
			this.contaVendaServico = jsonObj['contaVendaServico'];
			this.contaEstoque = jsonObj['contaEstoque'];
			this.contaApuraResultado = jsonObj['contaApuraResultado'];
			this.contaJurosApropriar = jsonObj['contaJurosApropriar'];
			this.idHistPadraoResultado = jsonObj['idHistPadraoResultado'];
			this.idHistPadraoLucro = jsonObj['idHistPadraoLucro'];
			this.idHistPadraoPrejuizo = jsonObj['idHistPadraoPrejuizo'];
		}
	}
}