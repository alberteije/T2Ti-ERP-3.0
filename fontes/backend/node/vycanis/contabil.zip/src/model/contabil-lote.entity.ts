import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'contabil_lote' })
export class ContabilLoteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 

	@Column({ name: 'data_liberacao' }) 
	dataLiberacao: Date; 

	@Column({ name: 'liberado' }) 
	liberado: string; 

	@Column({ name: 'programado' }) 
	programado: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.dataInclusao = jsonObj['dataInclusao'];
			this.dataLiberacao = jsonObj['dataLiberacao'];
			this.liberado = jsonObj['liberado'];
			this.programado = jsonObj['programado'];
			this.valor = jsonObj['valor'];
		}
	}
}