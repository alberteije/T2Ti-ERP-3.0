import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { CentroResultadoModel } from '../entities-export';

@Entity({ name: 'encerra_centro_resultado' })
export class EncerraCentroResultadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'valor_sub_rateio', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubRateio: number; 


	/**
	* Relations
	*/
	@OneToOne(() => CentroResultadoModel)
	@JoinColumn({ name: 'id_centro_resultado' })
	centroResultadoModel: CentroResultadoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.valorTotal = jsonObj['valorTotal'];
			this.valorSubRateio = jsonObj['valorSubRateio'];
			if (jsonObj['centroResultadoModel'] != null) {
				this.centroResultadoModel = new CentroResultadoModel(jsonObj['centroResultadoModel']);
			}

		}
	}
}