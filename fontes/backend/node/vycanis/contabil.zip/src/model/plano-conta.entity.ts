import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'plano_conta' })
export class PlanoContaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 

	@Column({ name: 'mascara' }) 
	mascara: string; 

	@Column({ name: 'niveis' }) 
	niveis: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.dataInclusao = jsonObj['dataInclusao'];
			this.mascara = jsonObj['mascara'];
			this.niveis = jsonObj['niveis'];
		}
	}
}