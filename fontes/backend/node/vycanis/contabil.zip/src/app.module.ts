import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { ContabilLancamentoCabecalhoModule } from './modules-export';
import { ContabilDreCabecalhoModule } from './modules-export';
import { ContabilLivroModule } from './modules-export';
import { ContabilEncerramentoExeCabModule } from './modules-export';
import { CentroResultadoModule } from './modules-export';
import { RateioCentroResultadoCabModule } from './modules-export';
import { ContabilIndiceModule } from './modules-export';
import { FinNaturezaFinanceiraModule } from './modules-export';
import { AidfAimdfModule } from './modules-export';
import { FapModule } from './modules-export';
import { RegistroCartorioModule } from './modules-export';
import { ContabilParametroModule } from './modules-export';
import { PlanoContaRefSpedModule } from './modules-export';
import { PlanoContaModule } from './modules-export';
import { ContabilContaModule } from './modules-export';
import { ContabilHistoricoModule } from './modules-export';
import { ContabilLancamentoPadraoModule } from './modules-export';
import { ContabilLoteModule } from './modules-export';
import { ContabilLancamentoOrcadoModule } from './modules-export';
import { LancaCentroResultadoModule } from './modules-export';
import { EncerraCentroResultadoModule } from './modules-export';
import { ContabilContaRateioModule } from './modules-export';
import { ContabilFechamentoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { PlanoCentroResultadoModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			ContabilLancamentoCabecalhoModule,
			ContabilDreCabecalhoModule,
			ContabilLivroModule,
			ContabilEncerramentoExeCabModule,
			CentroResultadoModule,
			RateioCentroResultadoCabModule,
			ContabilIndiceModule,
			FinNaturezaFinanceiraModule,
			AidfAimdfModule,
			FapModule,
			RegistroCartorioModule,
			ContabilParametroModule,
			PlanoContaRefSpedModule,
			PlanoContaModule,
			ContabilContaModule,
			ContabilHistoricoModule,
			ContabilLancamentoPadraoModule,
			ContabilLoteModule,
			ContabilLancamentoOrcadoModule,
			LancaCentroResultadoModule,
			EncerraCentroResultadoModule,
			ContabilContaRateioModule,
			ContabilFechamentoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			PlanoCentroResultadoModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}