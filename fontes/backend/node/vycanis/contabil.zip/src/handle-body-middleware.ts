import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class HandleBodyMiddleware implements NestMiddleware {
  async use(request: Request, response: Response, next: NextFunction) {
    if (request.method === 'POST' || request.method === 'PUT') {
      const contentType = request.headers['content-type'];

      // Verifica se o content-type é JSON
      if (contentType && contentType.includes('application/json')) {
        let data = '';

        // Coleta o corpo da requisição como string
        request.on('data', chunk => {
          data += chunk;
        });

        // Quando o corpo estiver completo, tenta processar como JSON
        request.on('end', () => {
          try {
            request.body = JSON.parse(data);
          } catch (err) {
            // Se não for JSON válido, trata como texto
            request.body = data;
          }
          next();
        });
      } else {
        // Trata como texto se não for JSON
        let data = '';

        // Coleta o corpo da requisição como string
        request.on('data', chunk => {
          data += chunk;
        });

        // Quando o corpo estiver completo, atribui como texto
        request.on('end', () => {
          request.body = data;
          next();
        });
      }
    } else {
      next();
    }
  }
}
