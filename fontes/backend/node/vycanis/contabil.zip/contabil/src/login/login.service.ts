import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { ViewPessoaUsuarioModel } from '../model/view-pessoa-usuario.entity';
import { ObjetoLogin } from '../util/objeto.login';
import { Util } from '../util/util'
import { UsuarioTokenModel } from '../entities-export';
import { UsuarioTokenService } from '../service/usuario-token.service';

@Injectable()
export class LoginService extends TypeOrmCrudService<ViewPessoaUsuarioModel>{

    private key: string = "#Sua-chave-de-32-caracteres-aqui";

    constructor(
        private readonly usuarioTokenService: UsuarioTokenService,
        @InjectRepository(ViewPessoaUsuarioModel) repository) { super(repository); }

    async login(usuario: ViewPessoaUsuarioModel) {
        const md5Senha = Util.md5String(usuario.login + usuario.senha);

        let user = await this.findOne({ where: { login: usuario.login, senha: md5Senha } });

        if (user != null) {
            const token_jwt = this.gerarJwt(usuario.login);
            //auditoria
            const current_time = new Date();
            const usuarioToken = new UsuarioTokenModel({
              login: usuario.login,
              token: token_jwt,
              dataCriacao: current_time,
              horaCriacao: current_time.toTimeString().split(' ')[0],
              dataExpiracao: new Date(current_time.getTime() + 24 * 60 * 60 * 1000), // 1 dia depois
              horaExpiracao: new Date(current_time.getTime() + 24 * 60 * 60 * 1000).toTimeString().split(' ')[0]
            });            
            await this.usuarioTokenService.save(usuarioToken);
            
            let objetoLogin = new ObjetoLogin({});
            objetoLogin.token = Util.cifrar(token_jwt);
            objetoLogin.user = Util.cifrar(JSON.stringify(user.toJSON()));
            return objetoLogin;
        }
        throw new UnauthorizedException();
    }

    gerarJwt(login: string) {
        const jwt = require('jsonwebtoken');
        return jwt.sign({ sub: login, expiresIn: '1d', iss: 'T2Ti' }, this.key);
    }

    verificarToken(token: string): boolean {
        try {
            const jwt = require('jsonwebtoken');
            let decoded = jwt.verify(token, this.key);    
            if (decoded != null) {
                return true;
            }
        } catch (error) {
            return false;
        }
        return false;
    }
}