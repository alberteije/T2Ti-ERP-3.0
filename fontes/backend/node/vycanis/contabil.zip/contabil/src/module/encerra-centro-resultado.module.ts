import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EncerraCentroResultadoController } from '../controller/encerra-centro-resultado.controller';
import { EncerraCentroResultadoService } from '../service/encerra-centro-resultado.service';
import { EncerraCentroResultadoModel } from '../model/encerra-centro-resultado.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EncerraCentroResultadoModel])],
    controllers: [EncerraCentroResultadoController],
    providers: [EncerraCentroResultadoService],
})
export class EncerraCentroResultadoModule { }
