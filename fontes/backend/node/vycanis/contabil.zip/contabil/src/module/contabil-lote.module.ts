import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilLoteController } from '../controller/contabil-lote.controller';
import { ContabilLoteService } from '../service/contabil-lote.service';
import { ContabilLoteModel } from '../model/contabil-lote.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilLoteModel])],
    controllers: [ContabilLoteController],
    providers: [ContabilLoteService],
})
export class ContabilLoteModule { }
