import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilParametroController } from '../controller/contabil-parametro.controller';
import { ContabilParametroService } from '../service/contabil-parametro.service';
import { ContabilParametroModel } from '../model/contabil-parametro.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilParametroModel])],
    controllers: [ContabilParametroController],
    providers: [ContabilParametroService],
})
export class ContabilParametroModule { }
