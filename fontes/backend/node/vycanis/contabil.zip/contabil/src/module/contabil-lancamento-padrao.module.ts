import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilLancamentoPadraoController } from '../controller/contabil-lancamento-padrao.controller';
import { ContabilLancamentoPadraoService } from '../service/contabil-lancamento-padrao.service';
import { ContabilLancamentoPadraoModel } from '../model/contabil-lancamento-padrao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilLancamentoPadraoModel])],
    controllers: [ContabilLancamentoPadraoController],
    providers: [ContabilLancamentoPadraoService],
})
export class ContabilLancamentoPadraoModule { }
