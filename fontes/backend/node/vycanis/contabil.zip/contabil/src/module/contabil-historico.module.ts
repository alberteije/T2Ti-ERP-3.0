import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilHistoricoController } from '../controller/contabil-historico.controller';
import { ContabilHistoricoService } from '../service/contabil-historico.service';
import { ContabilHistoricoModel } from '../model/contabil-historico.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilHistoricoModel])],
    controllers: [ContabilHistoricoController],
    providers: [ContabilHistoricoService],
})
export class ContabilHistoricoModule { }
