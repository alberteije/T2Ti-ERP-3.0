import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilIndiceController } from '../controller/contabil-indice.controller';
import { ContabilIndiceService } from '../service/contabil-indice.service';
import { ContabilIndiceModel } from '../model/contabil-indice.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilIndiceModel])],
    controllers: [ContabilIndiceController],
    providers: [ContabilIndiceService],
})
export class ContabilIndiceModule { }
