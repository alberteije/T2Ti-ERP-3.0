import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilDreCabecalhoController } from '../controller/contabil-dre-cabecalho.controller';
import { ContabilDreCabecalhoService } from '../service/contabil-dre-cabecalho.service';
import { ContabilDreCabecalhoModel } from '../model/contabil-dre-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilDreCabecalhoModel])],
    controllers: [ContabilDreCabecalhoController],
    providers: [ContabilDreCabecalhoService],
})
export class ContabilDreCabecalhoModule { }
