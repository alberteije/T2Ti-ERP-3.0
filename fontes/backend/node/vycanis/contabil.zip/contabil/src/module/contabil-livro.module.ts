import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilLivroController } from '../controller/contabil-livro.controller';
import { ContabilLivroService } from '../service/contabil-livro.service';
import { ContabilLivroModel } from '../model/contabil-livro.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilLivroModel])],
    controllers: [ContabilLivroController],
    providers: [ContabilLivroService],
})
export class ContabilLivroModule { }
