import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CentroResultadoController } from '../controller/centro-resultado.controller';
import { CentroResultadoService } from '../service/centro-resultado.service';
import { CentroResultadoModel } from '../model/centro-resultado.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CentroResultadoModel])],
    controllers: [CentroResultadoController],
    providers: [CentroResultadoService],
})
export class CentroResultadoModule { }
