import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AidfAimdfController } from '../controller/aidf-aimdf.controller';
import { AidfAimdfService } from '../service/aidf-aimdf.service';
import { AidfAimdfModel } from '../model/aidf-aimdf.entity';

@Module({
    imports: [TypeOrmModule.forFeature([AidfAimdfModel])],
    controllers: [AidfAimdfController],
    providers: [AidfAimdfService],
})
export class AidfAimdfModule { }
