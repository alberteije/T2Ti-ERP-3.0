import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilLancamentoOrcadoController } from '../controller/contabil-lancamento-orcado.controller';
import { ContabilLancamentoOrcadoService } from '../service/contabil-lancamento-orcado.service';
import { ContabilLancamentoOrcadoModel } from '../model/contabil-lancamento-orcado.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilLancamentoOrcadoModel])],
    controllers: [ContabilLancamentoOrcadoController],
    providers: [ContabilLancamentoOrcadoService],
})
export class ContabilLancamentoOrcadoModule { }
