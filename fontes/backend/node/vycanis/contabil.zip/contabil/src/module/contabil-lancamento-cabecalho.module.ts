import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilLancamentoCabecalhoController } from '../controller/contabil-lancamento-cabecalho.controller';
import { ContabilLancamentoCabecalhoService } from '../service/contabil-lancamento-cabecalho.service';
import { ContabilLancamentoCabecalhoModel } from '../model/contabil-lancamento-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilLancamentoCabecalhoModel])],
    controllers: [ContabilLancamentoCabecalhoController],
    providers: [ContabilLancamentoCabecalhoService],
})
export class ContabilLancamentoCabecalhoModule { }
