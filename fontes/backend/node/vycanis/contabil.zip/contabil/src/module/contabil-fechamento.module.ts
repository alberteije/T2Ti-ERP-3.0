import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ContabilFechamentoController } from '../controller/contabil-fechamento.controller';
import { ContabilFechamentoService } from '../service/contabil-fechamento.service';
import { ContabilFechamentoModel } from '../model/contabil-fechamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ContabilFechamentoModel])],
    controllers: [ContabilFechamentoController],
    providers: [ContabilFechamentoService],
})
export class ContabilFechamentoModule { }
