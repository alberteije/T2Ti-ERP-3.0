import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { RegistroCartorioModel } from '../entities-export';

@Injectable()
export class RegistroCartorioService extends TypeOrmCrudService<RegistroCartorioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(RegistroCartorioModel)
    private readonly repository: Repository<RegistroCartorioModel>
  ) {
    super(repository);
  }

	async save(registroCartorioModel: RegistroCartorioModel): Promise<RegistroCartorioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(registroCartorioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
