import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ContabilParametroModel } from '../entities-export';

@Injectable()
export class ContabilParametroService extends TypeOrmCrudService<ContabilParametroModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ContabilParametroModel)
    private readonly repository: Repository<ContabilParametroModel>
  ) {
    super(repository);
  }

	async save(contabilParametroModel: ContabilParametroModel): Promise<ContabilParametroModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(contabilParametroModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
