import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { CentroResultadoModel } from '../entities-export';

@Injectable()
export class CentroResultadoService extends TypeOrmCrudService<CentroResultadoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(CentroResultadoModel) 
    private readonly repository: Repository<CentroResultadoModel>,
  ) {
    super(repository);
  }

	async save(centroResultadoModel: CentroResultadoModel, operation: string): Promise<CentroResultadoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, centroResultadoModel.id);
      }

      const resultObj = await queryRunner.manager.save(centroResultadoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(CentroResultadoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from ct_resultado_nt_financeira where id_centro_resultado=' + id); 

	}
	
}