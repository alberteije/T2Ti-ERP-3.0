import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ContabilEncerramentoExeCabModel } from '../entities-export';

@Injectable()
export class ContabilEncerramentoExeCabService extends TypeOrmCrudService<ContabilEncerramentoExeCabModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ContabilEncerramentoExeCabModel) 
    private readonly repository: Repository<ContabilEncerramentoExeCabModel>,
  ) {
    super(repository);
  }

	async save(contabilEncerramentoExeCabModel: ContabilEncerramentoExeCabModel, operation: string): Promise<ContabilEncerramentoExeCabModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, contabilEncerramentoExeCabModel.id);
      }

      const resultObj = await queryRunner.manager.save(contabilEncerramentoExeCabModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ContabilEncerramentoExeCabModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from contabil_encerramento_exe_det where id_contabil_encerramento_exe=' + id); 

	}
	
}