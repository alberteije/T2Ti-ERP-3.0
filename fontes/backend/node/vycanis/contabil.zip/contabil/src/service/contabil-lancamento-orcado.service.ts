import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ContabilLancamentoOrcadoModel } from '../entities-export';

@Injectable()
export class ContabilLancamentoOrcadoService extends TypeOrmCrudService<ContabilLancamentoOrcadoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ContabilLancamentoOrcadoModel)
    private readonly repository: Repository<ContabilLancamentoOrcadoModel>
  ) {
    super(repository);
  }

	async save(contabilLancamentoOrcadoModel: ContabilLancamentoOrcadoModel): Promise<ContabilLancamentoOrcadoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(contabilLancamentoOrcadoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
