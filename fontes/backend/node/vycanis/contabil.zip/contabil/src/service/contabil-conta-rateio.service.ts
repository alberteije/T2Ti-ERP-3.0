import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ContabilContaRateioModel } from '../entities-export';

@Injectable()
export class ContabilContaRateioService extends TypeOrmCrudService<ContabilContaRateioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ContabilContaRateioModel)
    private readonly repository: Repository<ContabilContaRateioModel>
  ) {
    super(repository);
  }

	async save(contabilContaRateioModel: ContabilContaRateioModel): Promise<ContabilContaRateioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(contabilContaRateioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
