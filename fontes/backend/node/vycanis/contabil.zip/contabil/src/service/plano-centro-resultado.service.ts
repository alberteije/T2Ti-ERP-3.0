import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PlanoCentroResultadoModel } from '../entities-export';

@Injectable()
export class PlanoCentroResultadoService extends TypeOrmCrudService<PlanoCentroResultadoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PlanoCentroResultadoModel)
    private readonly repository: Repository<PlanoCentroResultadoModel>
  ) {
    super(repository);
  }

	async save(planoCentroResultadoModel: PlanoCentroResultadoModel): Promise<PlanoCentroResultadoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(planoCentroResultadoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
