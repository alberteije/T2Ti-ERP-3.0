import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'contabil_lancamento_padrao' })
export class ContabilLancamentoPadraoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'historico' }) 
	historico: string; 

	@Column({ name: 'id_conta_debito' }) 
	idContaDebito: number; 

	@Column({ name: 'id_conta_credito' }) 
	idContaCredito: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.descricao = jsonObj['descricao'];
			this.historico = jsonObj['historico'];
			this.idContaDebito = jsonObj['idContaDebito'];
			this.idContaCredito = jsonObj['idContaCredito'];
		}
	}
}