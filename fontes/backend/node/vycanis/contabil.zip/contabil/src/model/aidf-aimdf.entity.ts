import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'aidf_aimdf' })
export class AidfAimdfModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'data_validade' }) 
	dataValidade: Date; 

	@Column({ name: 'data_autorizacao' }) 
	dataAutorizacao: Date; 

	@Column({ name: 'numero_autorizacao' }) 
	numeroAutorizacao: string; 

	@Column({ name: 'formulario_disponivel' }) 
	formularioDisponivel: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.dataValidade = jsonObj['dataValidade'];
			this.dataAutorizacao = jsonObj['dataAutorizacao'];
			this.numeroAutorizacao = jsonObj['numeroAutorizacao'];
			this.formularioDisponivel = jsonObj['formularioDisponivel'];
		}
	}
}