import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'registro_cartorio' })
export class RegistroCartorioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome_cartorio' }) 
	nomeCartorio: string; 

	@Column({ name: 'data_registro' }) 
	dataRegistro: Date; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'folha' }) 
	folha: number; 

	@Column({ name: 'livro' }) 
	livro: number; 

	@Column({ name: 'nire' }) 
	nire: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nomeCartorio = jsonObj['nomeCartorio'];
			this.dataRegistro = jsonObj['dataRegistro'];
			this.numero = jsonObj['numero'];
			this.folha = jsonObj['folha'];
			this.livro = jsonObj['livro'];
			this.nire = jsonObj['nire'];
		}
	}
}