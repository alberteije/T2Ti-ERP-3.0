import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilLancamentoDetalheModel } from '../entities-export';
import { ContabilLoteModel } from '../entities-export';

@Entity({ name: 'contabil_lancamento_cabecalho' })
export class ContabilLancamentoCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_lancamento' }) 
	dataLancamento: Date; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'liberado' }) 
	liberado: string; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@OneToMany(() => ContabilLancamentoDetalheModel, contabilLancamentoDetalheModel => contabilLancamentoDetalheModel.contabilLancamentoCabecalhoModel, { cascade: true })
	contabilLancamentoDetalheModelList: ContabilLancamentoDetalheModel[];

	@OneToOne(() => ContabilLoteModel)
	@JoinColumn({ name: 'id_contabil_lote' })
	contabilLoteModel: ContabilLoteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataLancamento = jsonObj['dataLancamento'];
			this.dataInclusao = jsonObj['dataInclusao'];
			this.tipo = jsonObj['tipo'];
			this.liberado = jsonObj['liberado'];
			this.valor = jsonObj['valor'];
			if (jsonObj['contabilLoteModel'] != null) {
				this.contabilLoteModel = new ContabilLoteModel(jsonObj['contabilLoteModel']);
			}

			this.contabilLancamentoDetalheModelList = [];
			let contabilLancamentoDetalheModelJsonList = jsonObj['contabilLancamentoDetalheModelList'];
			if (contabilLancamentoDetalheModelJsonList != null) {
				for (let i = 0; i < contabilLancamentoDetalheModelJsonList.length; i++) {
					let obj = new ContabilLancamentoDetalheModel(contabilLancamentoDetalheModelJsonList[i]);
					this.contabilLancamentoDetalheModelList.push(obj);
				}
			}

		}
	}
}