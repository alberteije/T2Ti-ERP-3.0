import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilIndiceModel } from '../entities-export';

@Entity({ name: 'contabil_indice_valor' })
export class ContabilIndiceValorModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_indice' }) 
	dataIndice: Date; 

	@Column({ name: 'valor', type: 'decimal', precision: 18, scale: 6 }) 
	valor: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContabilIndiceModel, contabilIndiceModel => contabilIndiceModel.contabilIndiceValorModelList)
	@JoinColumn({ name: 'id_contabil_indice' })
	contabilIndiceModel: ContabilIndiceModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataIndice = jsonObj['dataIndice'];
			this.valor = jsonObj['valor'];
		}
	}
}