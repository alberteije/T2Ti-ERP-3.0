import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilLivroModel } from '../entities-export';

@Entity({ name: 'contabil_termo' })
export class ContabilTermoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'abertura_encerramento' }) 
	aberturaEncerramento: string; 

	@Column({ name: 'numero' }) 
	numero: number; 

	@Column({ name: 'pagina_inicial' }) 
	paginaInicial: number; 

	@Column({ name: 'pagina_final' }) 
	paginaFinal: number; 

	@Column({ name: 'registrado' }) 
	registrado: string; 

	@Column({ name: 'numero_registro' }) 
	numeroRegistro: string; 

	@Column({ name: 'data_despacho' }) 
	dataDespacho: Date; 

	@Column({ name: 'data_abertura' }) 
	dataAbertura: Date; 

	@Column({ name: 'data_encerramento' }) 
	dataEncerramento: Date; 

	@Column({ name: 'escrituracao_inicio' }) 
	escrituracaoInicio: Date; 

	@Column({ name: 'escrituracao_fim' }) 
	escrituracaoFim: Date; 

	@Column({ name: 'texto' }) 
	texto: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContabilLivroModel, contabilLivroModel => contabilLivroModel.contabilTermoModelList)
	@JoinColumn({ name: 'id_contabil_livro' })
	contabilLivroModel: ContabilLivroModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.aberturaEncerramento = jsonObj['aberturaEncerramento'];
			this.numero = jsonObj['numero'];
			this.paginaInicial = jsonObj['paginaInicial'];
			this.paginaFinal = jsonObj['paginaFinal'];
			this.registrado = jsonObj['registrado'];
			this.numeroRegistro = jsonObj['numeroRegistro'];
			this.dataDespacho = jsonObj['dataDespacho'];
			this.dataAbertura = jsonObj['dataAbertura'];
			this.dataEncerramento = jsonObj['dataEncerramento'];
			this.escrituracaoInicio = jsonObj['escrituracaoInicio'];
			this.escrituracaoFim = jsonObj['escrituracaoFim'];
			this.texto = jsonObj['texto'];
		}
	}
}