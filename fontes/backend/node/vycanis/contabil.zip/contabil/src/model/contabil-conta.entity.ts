import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PlanoContaModel } from '../entities-export';
import { PlanoContaRefSpedModel } from '../entities-export';

@Entity({ name: 'contabil_conta' })
export class ContabilContaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_contabil_conta' }) 
	idContabilConta: number; 

	@Column({ name: 'classificacao' }) 
	classificacao: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'data_inclusao' }) 
	dataInclusao: Date; 

	@Column({ name: 'situacao' }) 
	situacao: string; 

	@Column({ name: 'natureza' }) 
	natureza: string; 

	@Column({ name: 'patrimonio_resultado' }) 
	patrimonioResultado: string; 

	@Column({ name: 'livro_caixa' }) 
	livroCaixa: string; 

	@Column({ name: 'dfc' }) 
	dfc: string; 

	@Column({ name: 'codigo_efd' }) 
	codigoEfd: string; 

	@Column({ name: 'ordem' }) 
	ordem: string; 

	@Column({ name: 'codigo_reduzido' }) 
	codigoReduzido: string; 


	/**
	* Relations
	*/
	@OneToOne(() => PlanoContaModel)
	@JoinColumn({ name: 'id_plano_conta' })
	planoContaModel: PlanoContaModel;

	@OneToOne(() => PlanoContaRefSpedModel)
	@JoinColumn({ name: 'id_plano_conta_ref_sped' })
	planoContaRefSpedModel: PlanoContaRefSpedModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idContabilConta = jsonObj['idContabilConta'];
			this.classificacao = jsonObj['classificacao'];
			this.tipo = jsonObj['tipo'];
			this.descricao = jsonObj['descricao'];
			this.dataInclusao = jsonObj['dataInclusao'];
			this.situacao = jsonObj['situacao'];
			this.natureza = jsonObj['natureza'];
			this.patrimonioResultado = jsonObj['patrimonioResultado'];
			this.livroCaixa = jsonObj['livroCaixa'];
			this.dfc = jsonObj['dfc'];
			this.codigoEfd = jsonObj['codigoEfd'];
			this.ordem = jsonObj['ordem'];
			this.codigoReduzido = jsonObj['codigoReduzido'];
			if (jsonObj['planoContaModel'] != null) {
				this.planoContaModel = new PlanoContaModel(jsonObj['planoContaModel']);
			}

			if (jsonObj['planoContaRefSpedModel'] != null) {
				this.planoContaRefSpedModel = new PlanoContaRefSpedModel(jsonObj['planoContaRefSpedModel']);
			}

		}
	}
}