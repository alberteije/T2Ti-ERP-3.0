import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilTermoModel } from '../entities-export';

@Entity({ name: 'contabil_livro' })
export class ContabilLivroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'forma_escrituracao' }) 
	formaEscrituracao: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ContabilTermoModel, contabilTermoModel => contabilTermoModel.contabilLivroModel, { cascade: true })
	contabilTermoModelList: ContabilTermoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.formaEscrituracao = jsonObj['formaEscrituracao'];
			this.descricao = jsonObj['descricao'];
			this.contabilTermoModelList = [];
			let contabilTermoModelJsonList = jsonObj['contabilTermoModelList'];
			if (contabilTermoModelJsonList != null) {
				for (let i = 0; i < contabilTermoModelJsonList.length; i++) {
					let obj = new ContabilTermoModel(contabilTermoModelJsonList[i]);
					this.contabilTermoModelList.push(obj);
				}
			}

		}
	}
}