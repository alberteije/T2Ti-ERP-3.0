import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilEncerramentoExeCabModel } from '../entities-export';
import { ContabilContaModel } from '../entities-export';

@Entity({ name: 'contabil_encerramento_exe_det' })
export class ContabilEncerramentoExeDetModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'saldo_anterior', type: 'decimal', precision: 18, scale: 6 }) 
	saldoAnterior: number; 

	@Column({ name: 'valor_debito', type: 'decimal', precision: 18, scale: 6 }) 
	valorDebito: number; 

	@Column({ name: 'valor_credito', type: 'decimal', precision: 18, scale: 6 }) 
	valorCredito: number; 

	@Column({ name: 'saldo', type: 'decimal', precision: 18, scale: 6 }) 
	saldo: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => ContabilEncerramentoExeCabModel, contabilEncerramentoExeCabModel => contabilEncerramentoExeCabModel.contabilEncerramentoExeDetModelList)
	@JoinColumn({ name: 'id_contabil_encerramento_exe' })
	contabilEncerramentoExeCabModel: ContabilEncerramentoExeCabModel;

	@OneToOne(() => ContabilContaModel)
	@JoinColumn({ name: 'id_contabil_conta' })
	contabilContaModel: ContabilContaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.saldoAnterior = jsonObj['saldoAnterior'];
			this.valorDebito = jsonObj['valorDebito'];
			this.valorCredito = jsonObj['valorCredito'];
			this.saldo = jsonObj['saldo'];
			if (jsonObj['contabilContaModel'] != null) {
				this.contabilContaModel = new ContabilContaModel(jsonObj['contabilContaModel']);
			}

		}
	}
}