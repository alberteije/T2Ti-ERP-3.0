import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilIndiceValorModel } from '../entities-export';

@Entity({ name: 'contabil_indice' })
export class ContabilIndiceModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'indice' }) 
	indice: string; 

	@Column({ name: 'periodicidade' }) 
	periodicidade: string; 

	@Column({ name: 'diario_a_partir_de' }) 
	diarioAPartirDe: Date; 

	@Column({ name: 'mensal_mes_ano' }) 
	mensalMesAno: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ContabilIndiceValorModel, contabilIndiceValorModel => contabilIndiceValorModel.contabilIndiceModel, { cascade: true })
	contabilIndiceValorModelList: ContabilIndiceValorModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.indice = jsonObj['indice'];
			this.periodicidade = jsonObj['periodicidade'];
			this.diarioAPartirDe = jsonObj['diarioAPartirDe'];
			this.mensalMesAno = jsonObj['mensalMesAno'];
			this.contabilIndiceValorModelList = [];
			let contabilIndiceValorModelJsonList = jsonObj['contabilIndiceValorModelList'];
			if (contabilIndiceValorModelJsonList != null) {
				for (let i = 0; i < contabilIndiceValorModelJsonList.length; i++) {
					let obj = new ContabilIndiceValorModel(contabilIndiceValorModelJsonList[i]);
					this.contabilIndiceValorModelList.push(obj);
				}
			}

		}
	}
}