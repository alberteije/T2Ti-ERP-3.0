import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilContaModel } from '../entities-export';

@Entity({ name: 'contabil_lancamento_orcado' })
export class ContabilLancamentoOrcadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'ano' }) 
	ano: string; 

	@Column({ name: 'janeiro', type: 'decimal', precision: 18, scale: 6 }) 
	janeiro: number; 

	@Column({ name: 'fevereiro', type: 'decimal', precision: 18, scale: 6 }) 
	fevereiro: number; 

	@Column({ name: 'marco', type: 'decimal', precision: 18, scale: 6 }) 
	marco: number; 

	@Column({ name: 'abril', type: 'decimal', precision: 18, scale: 6 }) 
	abril: number; 

	@Column({ name: 'maio', type: 'decimal', precision: 18, scale: 6 }) 
	maio: number; 

	@Column({ name: 'junho', type: 'decimal', precision: 18, scale: 6 }) 
	junho: number; 

	@Column({ name: 'julho', type: 'decimal', precision: 18, scale: 6 }) 
	julho: number; 

	@Column({ name: 'agosto', type: 'decimal', precision: 18, scale: 6 }) 
	agosto: number; 

	@Column({ name: 'setembro', type: 'decimal', precision: 18, scale: 6 }) 
	setembro: number; 

	@Column({ name: 'outubro', type: 'decimal', precision: 18, scale: 6 }) 
	outubro: number; 

	@Column({ name: 'novembro', type: 'decimal', precision: 18, scale: 6 }) 
	novembro: number; 

	@Column({ name: 'dezembro', type: 'decimal', precision: 18, scale: 6 }) 
	dezembro: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ContabilContaModel)
	@JoinColumn({ name: 'id_contabil_conta' })
	contabilContaModel: ContabilContaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ano = jsonObj['ano'];
			this.janeiro = jsonObj['janeiro'];
			this.fevereiro = jsonObj['fevereiro'];
			this.marco = jsonObj['marco'];
			this.abril = jsonObj['abril'];
			this.maio = jsonObj['maio'];
			this.junho = jsonObj['junho'];
			this.julho = jsonObj['julho'];
			this.agosto = jsonObj['agosto'];
			this.setembro = jsonObj['setembro'];
			this.outubro = jsonObj['outubro'];
			this.novembro = jsonObj['novembro'];
			this.dezembro = jsonObj['dezembro'];
			if (jsonObj['contabilContaModel'] != null) {
				this.contabilContaModel = new ContabilContaModel(jsonObj['contabilContaModel']);
			}

		}
	}
}