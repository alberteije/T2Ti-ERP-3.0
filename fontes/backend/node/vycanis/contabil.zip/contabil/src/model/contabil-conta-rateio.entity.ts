import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ContabilContaModel } from '../entities-export';
import { CentroResultadoModel } from '../entities-export';

@Entity({ name: 'contabil_conta_rateio' })
export class ContabilContaRateioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'porcento_rateio', type: 'decimal', precision: 18, scale: 6 }) 
	porcentoRateio: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ContabilContaModel)
	@JoinColumn({ name: 'id_contabil_conta' })
	contabilContaModel: ContabilContaModel;

	@OneToOne(() => CentroResultadoModel)
	@JoinColumn({ name: 'id_centro_resultado' })
	centroResultadoModel: CentroResultadoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.porcentoRateio = jsonObj['porcentoRateio'];
			if (jsonObj['contabilContaModel'] != null) {
				this.contabilContaModel = new ContabilContaModel(jsonObj['contabilContaModel']);
			}

			if (jsonObj['centroResultadoModel'] != null) {
				this.centroResultadoModel = new CentroResultadoModel(jsonObj['centroResultadoModel']);
			}

		}
	}
}