import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilFechamentoService } from '../service/contabil-fechamento.service';
import { ContabilFechamentoModel } from '../model/contabil-fechamento.entity';

@Crud({
  model: {
    type: ContabilFechamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-fechamento')
export class ContabilFechamentoController implements CrudController<ContabilFechamentoModel> {
  constructor(public service: ContabilFechamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilFechamentoModel = new ContabilFechamentoModel(jsonObj);
		const result = await this.service.save(contabilFechamentoModel);
		return result;
	}  


}


















