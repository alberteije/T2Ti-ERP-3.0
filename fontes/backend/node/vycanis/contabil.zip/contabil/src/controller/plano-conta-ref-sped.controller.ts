import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PlanoContaRefSpedService } from '../service/plano-conta-ref-sped.service';
import { PlanoContaRefSpedModel } from '../model/plano-conta-ref-sped.entity';

@Crud({
  model: {
    type: PlanoContaRefSpedModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('plano-conta-ref-sped')
export class PlanoContaRefSpedController implements CrudController<PlanoContaRefSpedModel> {
  constructor(public service: PlanoContaRefSpedService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const planoContaRefSpedModel = new PlanoContaRefSpedModel(jsonObj);
		const result = await this.service.save(planoContaRefSpedModel);
		return result;
	}  


}


















