import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ContabilDreCabecalhoService } from '../service/contabil-dre-cabecalho.service';
import { ContabilDreCabecalhoModel } from '../model/contabil-dre-cabecalho.entity';

@Crud({
  model: {
    type: ContabilDreCabecalhoModel,
  },
  query: {
    join: {
			contabilDreDetalheModelList: { eager: true },
    },
  },
})
@Controller('contabil-dre-cabecalho')
export class ContabilDreCabecalhoController implements CrudController<ContabilDreCabecalhoModel> {
  constructor(public service: ContabilDreCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilDreCabecalho = new ContabilDreCabecalhoModel(jsonObj);
		const result = await this.service.save(contabilDreCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilDreCabecalho = new ContabilDreCabecalhoModel(jsonObj);
		const result = await this.service.save(contabilDreCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}