import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilLoteService } from '../service/contabil-lote.service';
import { ContabilLoteModel } from '../model/contabil-lote.entity';

@Crud({
  model: {
    type: ContabilLoteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-lote')
export class ContabilLoteController implements CrudController<ContabilLoteModel> {
  constructor(public service: ContabilLoteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilLoteModel = new ContabilLoteModel(jsonObj);
		const result = await this.service.save(contabilLoteModel);
		return result;
	}  


}


















