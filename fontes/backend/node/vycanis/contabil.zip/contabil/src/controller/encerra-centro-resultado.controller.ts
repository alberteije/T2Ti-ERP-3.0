import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EncerraCentroResultadoService } from '../service/encerra-centro-resultado.service';
import { EncerraCentroResultadoModel } from '../model/encerra-centro-resultado.entity';

@Crud({
  model: {
    type: EncerraCentroResultadoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('encerra-centro-resultado')
export class EncerraCentroResultadoController implements CrudController<EncerraCentroResultadoModel> {
  constructor(public service: EncerraCentroResultadoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const encerraCentroResultadoModel = new EncerraCentroResultadoModel(jsonObj);
		const result = await this.service.save(encerraCentroResultadoModel);
		return result;
	}  


}


















