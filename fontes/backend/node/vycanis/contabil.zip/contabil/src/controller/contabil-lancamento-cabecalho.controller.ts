import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ContabilLancamentoCabecalhoService } from '../service/contabil-lancamento-cabecalho.service';
import { ContabilLancamentoCabecalhoModel } from '../model/contabil-lancamento-cabecalho.entity';

@Crud({
  model: {
    type: ContabilLancamentoCabecalhoModel,
  },
  query: {
    join: {
			contabilLancamentoDetalheModelList: { eager: true },
			contabilLoteModel: { eager: true },
    },
  },
})
@Controller('contabil-lancamento-cabecalho')
export class ContabilLancamentoCabecalhoController implements CrudController<ContabilLancamentoCabecalhoModel> {
  constructor(public service: ContabilLancamentoCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilLancamentoCabecalho = new ContabilLancamentoCabecalhoModel(jsonObj);
		const result = await this.service.save(contabilLancamentoCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilLancamentoCabecalho = new ContabilLancamentoCabecalhoModel(jsonObj);
		const result = await this.service.save(contabilLancamentoCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}