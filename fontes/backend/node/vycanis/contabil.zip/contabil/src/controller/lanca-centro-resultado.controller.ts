import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { LancaCentroResultadoService } from '../service/lanca-centro-resultado.service';
import { LancaCentroResultadoModel } from '../model/lanca-centro-resultado.entity';

@Crud({
  model: {
    type: LancaCentroResultadoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('lanca-centro-resultado')
export class LancaCentroResultadoController implements CrudController<LancaCentroResultadoModel> {
  constructor(public service: LancaCentroResultadoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const lancaCentroResultadoModel = new LancaCentroResultadoModel(jsonObj);
		const result = await this.service.save(lancaCentroResultadoModel);
		return result;
	}  


}


















