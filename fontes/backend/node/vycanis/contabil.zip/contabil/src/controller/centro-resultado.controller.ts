import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { CentroResultadoService } from '../service/centro-resultado.service';
import { CentroResultadoModel } from '../model/centro-resultado.entity';

@Crud({
  model: {
    type: CentroResultadoModel,
  },
  query: {
    join: {
			planoCentroResultadoModel: { eager: true },
			ctResultadoNtFinanceiraModelList: { eager: true },
    },
  },
})
@Controller('centro-resultado')
export class CentroResultadoController implements CrudController<CentroResultadoModel> {
  constructor(public service: CentroResultadoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const centroResultado = new CentroResultadoModel(jsonObj);
		const result = await this.service.save(centroResultado, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const centroResultado = new CentroResultadoModel(jsonObj);
		const result = await this.service.save(centroResultado, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}