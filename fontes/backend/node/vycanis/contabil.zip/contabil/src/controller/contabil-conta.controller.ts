import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ContabilContaService } from '../service/contabil-conta.service';
import { ContabilContaModel } from '../model/contabil-conta.entity';

@Crud({
  model: {
    type: ContabilContaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('contabil-conta')
export class ContabilContaController implements CrudController<ContabilContaModel> {
  constructor(public service: ContabilContaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const contabilContaModel = new ContabilContaModel(jsonObj);
		const result = await this.service.save(contabilContaModel);
		return result;
	}  


}


















