import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FinNaturezaFinanceiraService } from '../service/fin-natureza-financeira.service';
import { FinNaturezaFinanceiraModel } from '../model/fin-natureza-financeira.entity';

@Crud({
  model: {
    type: FinNaturezaFinanceiraModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fin-natureza-financeira')
export class FinNaturezaFinanceiraController implements CrudController<FinNaturezaFinanceiraModel> {
  constructor(public service: FinNaturezaFinanceiraService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel(jsonObj);
		const result = await this.service.save(finNaturezaFinanceiraModel);
		return result;
	}  


}


















