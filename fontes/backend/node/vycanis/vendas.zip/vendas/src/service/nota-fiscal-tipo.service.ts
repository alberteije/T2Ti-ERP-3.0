import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NotaFiscalTipoModel } from '../entities-export';

@Injectable()
export class NotaFiscalTipoService extends TypeOrmCrudService<NotaFiscalTipoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NotaFiscalTipoModel)
    private readonly repository: Repository<NotaFiscalTipoModel>
  ) {
    super(repository);
  }

	async save(notaFiscalTipoModel: NotaFiscalTipoModel): Promise<NotaFiscalTipoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(notaFiscalTipoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
