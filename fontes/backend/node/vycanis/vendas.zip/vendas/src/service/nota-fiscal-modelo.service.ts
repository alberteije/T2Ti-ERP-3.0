import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { NotaFiscalModeloModel } from '../entities-export';

@Injectable()
export class NotaFiscalModeloService extends TypeOrmCrudService<NotaFiscalModeloModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(NotaFiscalModeloModel)
    private readonly repository: Repository<NotaFiscalModeloModel>
  ) {
    super(repository);
  }

	async save(notaFiscalModeloModel: NotaFiscalModeloModel): Promise<NotaFiscalModeloModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(notaFiscalModeloModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
