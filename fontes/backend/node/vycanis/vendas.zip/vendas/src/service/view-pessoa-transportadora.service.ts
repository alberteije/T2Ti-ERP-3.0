import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ViewPessoaTransportadoraModel } from '../entities-export';

@Injectable()
export class ViewPessoaTransportadoraService extends TypeOrmCrudService<ViewPessoaTransportadoraModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ViewPessoaTransportadoraModel)
    private readonly repository: Repository<ViewPessoaTransportadoraModel>
  ) {
    super(repository);
  }

	async save(viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel): Promise<ViewPessoaTransportadoraModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(viewPessoaTransportadoraModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
