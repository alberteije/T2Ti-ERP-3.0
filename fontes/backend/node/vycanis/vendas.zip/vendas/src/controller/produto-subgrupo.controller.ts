import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ProdutoSubgrupoService } from '../service/produto-subgrupo.service';
import { ProdutoSubgrupoModel } from '../model/produto-subgrupo.entity';

@Crud({
  model: {
    type: ProdutoSubgrupoModel,
  },
  query: {
    join: {
			produtoModelList: { eager: true },
    },
  },
})
@Controller('produto-subgrupo')
export class ProdutoSubgrupoController implements CrudController<ProdutoSubgrupoModel> {
  constructor(public service: ProdutoSubgrupoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoSubgrupo = new ProdutoSubgrupoModel(jsonObj);
		const result = await this.service.save(produtoSubgrupo, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoSubgrupo = new ProdutoSubgrupoModel(jsonObj);
		const result = await this.service.save(produtoSubgrupo, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}