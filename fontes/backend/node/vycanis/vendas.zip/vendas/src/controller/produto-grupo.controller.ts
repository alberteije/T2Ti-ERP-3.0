import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ProdutoGrupoService } from '../service/produto-grupo.service';
import { ProdutoGrupoModel } from '../model/produto-grupo.entity';

@Crud({
  model: {
    type: ProdutoGrupoModel,
  },
  query: {
    join: {
			produtoSubgrupoModelList: { eager: true },
    },
  },
})
@Controller('produto-grupo')
export class ProdutoGrupoController implements CrudController<ProdutoGrupoModel> {
  constructor(public service: ProdutoGrupoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoGrupo = new ProdutoGrupoModel(jsonObj);
		const result = await this.service.save(produtoGrupo, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoGrupo = new ProdutoGrupoModel(jsonObj);
		const result = await this.service.save(produtoGrupo, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}