import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { ViewPessoaClienteService } from '../service/view-pessoa-cliente.service';
import { ViewPessoaClienteModel } from '../model/view-pessoa-cliente.entity';

@Crud({
  model: {
    type: ViewPessoaClienteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('view-pessoa-cliente')
export class ViewPessoaClienteController implements CrudController<ViewPessoaClienteModel> {
  constructor(public service: ViewPessoaClienteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj);
		const result = await this.service.save(viewPessoaClienteModel);
		return result;
	}  


}


















