import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { VendaCabecalhoService } from '../service/venda-cabecalho.service';
import { VendaCabecalhoModel } from '../model/venda-cabecalho.entity';

@Crud({
  model: {
    type: VendaCabecalhoModel,
  },
  query: {
    join: {
			vendaComissaoModel: { eager: true },
			vendaDetalheModelList: { eager: true },
			vendaFreteModelList: { eager: true },
			vendaCondicoesPagamentoModel: { eager: true },
			viewPessoaVendedorModel: { eager: true },
			viewPessoaTransportadoraModel: { eager: true },
			viewPessoaClienteModel: { eager: true },
			vendaOrcamentoCabecalhoModel: { eager: true },
			notaFiscalTipoModel: { eager: true },
    },
  },
})
@Controller('venda-cabecalho')
export class VendaCabecalhoController implements CrudController<VendaCabecalhoModel> {
  constructor(public service: VendaCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const vendaCabecalho = new VendaCabecalhoModel(jsonObj);
		const result = await this.service.save(vendaCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const vendaCabecalho = new VendaCabecalhoModel(jsonObj);
		const result = await this.service.save(vendaCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}