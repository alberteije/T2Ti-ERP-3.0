import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { VendaOrcamentoCabecalhoService } from '../service/venda-orcamento-cabecalho.service';
import { VendaOrcamentoCabecalhoModel } from '../model/venda-orcamento-cabecalho.entity';

@Crud({
  model: {
    type: VendaOrcamentoCabecalhoModel,
  },
  query: {
    join: {
			vendaOrcamentoDetalheModelList: { eager: true },
			vendaCondicoesPagamentoModel: { eager: true },
			viewPessoaVendedorModel: { eager: true },
			viewPessoaTransportadoraModel: { eager: true },
			viewPessoaClienteModel: { eager: true },
    },
  },
})
@Controller('venda-orcamento-cabecalho')
export class VendaOrcamentoCabecalhoController implements CrudController<VendaOrcamentoCabecalhoModel> {
  constructor(public service: VendaOrcamentoCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const vendaOrcamentoCabecalho = new VendaOrcamentoCabecalhoModel(jsonObj);
		const result = await this.service.save(vendaOrcamentoCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const vendaOrcamentoCabecalho = new VendaOrcamentoCabecalhoModel(jsonObj);
		const result = await this.service.save(vendaOrcamentoCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}