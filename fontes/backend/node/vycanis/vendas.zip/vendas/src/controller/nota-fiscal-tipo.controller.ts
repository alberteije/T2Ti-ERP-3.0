import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NotaFiscalTipoService } from '../service/nota-fiscal-tipo.service';
import { NotaFiscalTipoModel } from '../model/nota-fiscal-tipo.entity';

@Crud({
  model: {
    type: NotaFiscalTipoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nota-fiscal-tipo')
export class NotaFiscalTipoController implements CrudController<NotaFiscalTipoModel> {
  constructor(public service: NotaFiscalTipoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const notaFiscalTipoModel = new NotaFiscalTipoModel(jsonObj);
		const result = await this.service.save(notaFiscalTipoModel);
		return result;
	}  


}


















