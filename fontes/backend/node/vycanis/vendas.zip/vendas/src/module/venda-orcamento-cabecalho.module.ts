import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VendaOrcamentoCabecalhoController } from '../controller/venda-orcamento-cabecalho.controller';
import { VendaOrcamentoCabecalhoService } from '../service/venda-orcamento-cabecalho.service';
import { VendaOrcamentoCabecalhoModel } from '../model/venda-orcamento-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([VendaOrcamentoCabecalhoModel])],
    controllers: [VendaOrcamentoCabecalhoController],
    providers: [VendaOrcamentoCabecalhoService],
})
export class VendaOrcamentoCabecalhoModule { }
