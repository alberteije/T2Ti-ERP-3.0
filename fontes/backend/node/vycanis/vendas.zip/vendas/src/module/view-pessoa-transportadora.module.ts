import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaTransportadoraController } from '../controller/view-pessoa-transportadora.controller';
import { ViewPessoaTransportadoraService } from '../service/view-pessoa-transportadora.service';
import { ViewPessoaTransportadoraModel } from '../model/view-pessoa-transportadora.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaTransportadoraModel])],
    controllers: [ViewPessoaTransportadoraController],
    providers: [ViewPessoaTransportadoraService],
})
export class ViewPessoaTransportadoraModule { }
