import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProdutoMarcaController } from '../controller/produto-marca.controller';
import { ProdutoMarcaService } from '../service/produto-marca.service';
import { ProdutoMarcaModel } from '../model/produto-marca.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ProdutoMarcaModel])],
    controllers: [ProdutoMarcaController],
    providers: [ProdutoMarcaService],
})
export class ProdutoMarcaModule { }
