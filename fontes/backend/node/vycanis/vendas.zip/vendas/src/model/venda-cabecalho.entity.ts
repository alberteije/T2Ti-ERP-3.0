import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { VendaComissaoModel } from '../entities-export';
import { VendaDetalheModel } from '../entities-export';
import { VendaFreteModel } from '../entities-export';
import { VendaCondicoesPagamentoModel } from '../entities-export';
import { ViewPessoaVendedorModel } from '../entities-export';
import { ViewPessoaTransportadoraModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';
import { VendaOrcamentoCabecalhoModel } from '../entities-export';
import { NotaFiscalTipoModel } from '../entities-export';

@Entity({ name: 'venda_cabecalho' })
export class VendaCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'local_entrega' }) 
	localEntrega: string; 

	@Column({ name: 'local_cobranca' }) 
	localCobranca: string; 

	@Column({ name: 'tipo_frete' }) 
	tipoFrete: string; 

	@Column({ name: 'forma_pagamento' }) 
	formaPagamento: string; 

	@Column({ name: 'data_venda' }) 
	dataVenda: Date; 

	@Column({ name: 'data_saida' }) 
	dataSaida: Date; 

	@Column({ name: 'hora_saida' }) 
	horaSaida: string; 

	@Column({ name: 'numero_fatura' }) 
	numeroFatura: number; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 

	@Column({ name: 'valor_seguro', type: 'decimal', precision: 18, scale: 6 }) 
	valorSeguro: number; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'taxa_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaComissao: number; 

	@Column({ name: 'valor_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	valorComissao: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'situacao' }) 
	situacao: string; 

	@Column({ name: 'dia_fixo_parcela' }) 
	diaFixoParcela: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => VendaComissaoModel, vendaComissaoModel => vendaComissaoModel.vendaCabecalhoModel, { cascade: true })
	vendaComissaoModel: VendaComissaoModel;

	@OneToMany(() => VendaDetalheModel, vendaDetalheModel => vendaDetalheModel.vendaCabecalhoModel, { cascade: true })
	vendaDetalheModelList: VendaDetalheModel[];

	@OneToMany(() => VendaFreteModel, vendaFreteModel => vendaFreteModel.vendaCabecalhoModel, { cascade: true })
	vendaFreteModelList: VendaFreteModel[];

	@OneToOne(() => VendaCondicoesPagamentoModel)
	@JoinColumn({ name: 'id_venda_condicoes_pagamento' })
	vendaCondicoesPagamentoModel: VendaCondicoesPagamentoModel;

	@OneToOne(() => ViewPessoaVendedorModel)
	@JoinColumn({ name: 'id_vendedor' })
	viewPessoaVendedorModel: ViewPessoaVendedorModel;

	@OneToOne(() => ViewPessoaTransportadoraModel)
	@JoinColumn({ name: 'id_transportadora' })
	viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel;

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;

	@OneToOne(() => VendaOrcamentoCabecalhoModel)
	@JoinColumn({ name: 'id_venda_orcamento_cabecalho' })
	vendaOrcamentoCabecalhoModel: VendaOrcamentoCabecalhoModel;

	@OneToOne(() => NotaFiscalTipoModel)
	@JoinColumn({ name: 'id_nota_fiscal_tipo' })
	notaFiscalTipoModel: NotaFiscalTipoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.localEntrega = jsonObj['localEntrega'];
			this.localCobranca = jsonObj['localCobranca'];
			this.tipoFrete = jsonObj['tipoFrete'];
			this.formaPagamento = jsonObj['formaPagamento'];
			this.dataVenda = jsonObj['dataVenda'];
			this.dataSaida = jsonObj['dataSaida'];
			this.horaSaida = jsonObj['horaSaida'];
			this.numeroFatura = jsonObj['numeroFatura'];
			this.valorFrete = jsonObj['valorFrete'];
			this.valorSeguro = jsonObj['valorSeguro'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.taxaComissao = jsonObj['taxaComissao'];
			this.valorComissao = jsonObj['valorComissao'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorTotal = jsonObj['valorTotal'];
			this.situacao = jsonObj['situacao'];
			this.diaFixoParcela = jsonObj['diaFixoParcela'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['vendaComissaoModel'] != null) {
				this.vendaComissaoModel = new VendaComissaoModel(jsonObj['vendaComissaoModel']);
			}

			if (jsonObj['vendaCondicoesPagamentoModel'] != null) {
				this.vendaCondicoesPagamentoModel = new VendaCondicoesPagamentoModel(jsonObj['vendaCondicoesPagamentoModel']);
			}

			if (jsonObj['viewPessoaVendedorModel'] != null) {
				this.viewPessoaVendedorModel = new ViewPessoaVendedorModel(jsonObj['viewPessoaVendedorModel']);
			}

			if (jsonObj['viewPessoaTransportadoraModel'] != null) {
				this.viewPessoaTransportadoraModel = new ViewPessoaTransportadoraModel(jsonObj['viewPessoaTransportadoraModel']);
			}

			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

			if (jsonObj['vendaOrcamentoCabecalhoModel'] != null) {
				this.vendaOrcamentoCabecalhoModel = new VendaOrcamentoCabecalhoModel(jsonObj['vendaOrcamentoCabecalhoModel']);
			}

			if (jsonObj['notaFiscalTipoModel'] != null) {
				this.notaFiscalTipoModel = new NotaFiscalTipoModel(jsonObj['notaFiscalTipoModel']);
			}

			this.vendaDetalheModelList = [];
			let vendaDetalheModelJsonList = jsonObj['vendaDetalheModelList'];
			if (vendaDetalheModelJsonList != null) {
				for (let i = 0; i < vendaDetalheModelJsonList.length; i++) {
					let obj = new VendaDetalheModel(vendaDetalheModelJsonList[i]);
					this.vendaDetalheModelList.push(obj);
				}
			}

			this.vendaFreteModelList = [];
			let vendaFreteModelJsonList = jsonObj['vendaFreteModelList'];
			if (vendaFreteModelJsonList != null) {
				for (let i = 0; i < vendaFreteModelJsonList.length; i++) {
					let obj = new VendaFreteModel(vendaFreteModelJsonList[i]);
					this.vendaFreteModelList.push(obj);
				}
			}

		}
	}
}