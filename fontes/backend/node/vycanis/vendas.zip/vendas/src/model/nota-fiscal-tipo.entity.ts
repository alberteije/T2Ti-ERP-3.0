import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { NotaFiscalModeloModel } from '../entities-export';

@Entity({ name: 'nota_fiscal_tipo' })
export class NotaFiscalTipoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'serie' }) 
	serie: string; 

	@Column({ name: 'serie_scan' }) 
	serieScan: string; 

	@Column({ name: 'ultimo_numero' }) 
	ultimoNumero: number; 


	/**
	* Relations
	*/
	@OneToOne(() => NotaFiscalModeloModel)
	@JoinColumn({ name: 'id_nota_fiscal_modelo' })
	notaFiscalModeloModel: NotaFiscalModeloModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.serie = jsonObj['serie'];
			this.serieScan = jsonObj['serieScan'];
			this.ultimoNumero = jsonObj['ultimoNumero'];
			if (jsonObj['notaFiscalModeloModel'] != null) {
				this.notaFiscalModeloModel = new NotaFiscalModeloModel(jsonObj['notaFiscalModeloModel']);
			}

		}
	}
}