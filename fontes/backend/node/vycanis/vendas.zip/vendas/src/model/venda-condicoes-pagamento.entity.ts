import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { VendaCondicoesParcelasModel } from '../entities-export';

@Entity({ name: 'venda_condicoes_pagamento' })
export class VendaCondicoesPagamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'faturamento_minimo', type: 'decimal', precision: 18, scale: 6 }) 
	faturamentoMinimo: number; 

	@Column({ name: 'faturamento_maximo', type: 'decimal', precision: 18, scale: 6 }) 
	faturamentoMaximo: number; 

	@Column({ name: 'indice_correcao', type: 'decimal', precision: 18, scale: 6 }) 
	indiceCorrecao: number; 

	@Column({ name: 'dias_tolerancia' }) 
	diasTolerancia: number; 

	@Column({ name: 'valor_tolerancia', type: 'decimal', precision: 18, scale: 6 }) 
	valorTolerancia: number; 

	@Column({ name: 'prazo_medio' }) 
	prazoMedio: number; 

	@Column({ name: 'vista_prazo' }) 
	vistaPrazo: string; 


	/**
	* Relations
	*/
	@OneToMany(() => VendaCondicoesParcelasModel, vendaCondicoesParcelasModel => vendaCondicoesParcelasModel.vendaCondicoesPagamentoModel, { cascade: true })
	vendaCondicoesParcelasModelList: VendaCondicoesParcelasModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.faturamentoMinimo = jsonObj['faturamentoMinimo'];
			this.faturamentoMaximo = jsonObj['faturamentoMaximo'];
			this.indiceCorrecao = jsonObj['indiceCorrecao'];
			this.diasTolerancia = jsonObj['diasTolerancia'];
			this.valorTolerancia = jsonObj['valorTolerancia'];
			this.prazoMedio = jsonObj['prazoMedio'];
			this.vistaPrazo = jsonObj['vistaPrazo'];
			this.vendaCondicoesParcelasModelList = [];
			let vendaCondicoesParcelasModelJsonList = jsonObj['vendaCondicoesParcelasModelList'];
			if (vendaCondicoesParcelasModelJsonList != null) {
				for (let i = 0; i < vendaCondicoesParcelasModelJsonList.length; i++) {
					let obj = new VendaCondicoesParcelasModel(vendaCondicoesParcelasModelJsonList[i]);
					this.vendaCondicoesParcelasModelList.push(obj);
				}
			}

		}
	}
}