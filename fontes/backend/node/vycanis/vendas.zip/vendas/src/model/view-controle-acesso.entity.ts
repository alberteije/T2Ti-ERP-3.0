import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'view_controle_acesso' })
export class ViewControleAcessoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'id_pessoa' }) 
	idPessoa: number; 

	@Column({ name: 'pessoa_nome' }) 
	pessoaNome: string; 

	@Column({ name: 'id_colaborador' }) 
	idColaborador: number; 

	@Column({ name: 'id_usuario' }) 
	idUsuario: number; 

	@Column({ name: 'administrador' }) 
	administrador: string; 

	@Column({ name: 'id_papel' }) 
	idPapel: number; 

	@Column({ name: 'papel_nome' }) 
	papelNome: string; 

	@Column({ name: 'papel_descricao' }) 
	papelDescricao: string; 

	@Column({ name: 'id_funcao' }) 
	idFuncao: number; 

	@Column({ name: 'funcao_nome' }) 
	funcaoNome: string; 

	@Column({ name: 'funcao_descricao' }) 
	funcaoDescricao: string; 

	@Column({ name: 'id_papel_funcao' }) 
	idPapelFuncao: number; 

	@Column({ name: 'habilitado' }) 
	habilitado: string; 

	@Column({ name: 'pode_inserir' }) 
	podeInserir: string; 

	@Column({ name: 'pode_alterar' }) 
	podeAlterar: string; 

	@Column({ name: 'pode_excluir' }) 
	podeExcluir: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.idPessoa = jsonObj['idPessoa'];
			this.pessoaNome = jsonObj['pessoaNome'];
			this.idColaborador = jsonObj['idColaborador'];
			this.idUsuario = jsonObj['idUsuario'];
			this.administrador = jsonObj['administrador'];
			this.idPapel = jsonObj['idPapel'];
			this.papelNome = jsonObj['papelNome'];
			this.papelDescricao = jsonObj['papelDescricao'];
			this.idFuncao = jsonObj['idFuncao'];
			this.funcaoNome = jsonObj['funcaoNome'];
			this.funcaoDescricao = jsonObj['funcaoDescricao'];
			this.idPapelFuncao = jsonObj['idPapelFuncao'];
			this.habilitado = jsonObj['habilitado'];
			this.podeInserir = jsonObj['podeInserir'];
			this.podeAlterar = jsonObj['podeAlterar'];
			this.podeExcluir = jsonObj['podeExcluir'];
		}
	}
}