import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { VendaCabecalhoModel } from '../entities-export';
import { ProdutoModel } from '../entities-export';

@Entity({ name: 'venda_detalhe' })
export class VendaDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade', type: 'decimal', precision: 18, scale: 6 }) 
	quantidade: number; 

	@Column({ name: 'valor_unitario', type: 'decimal', precision: 18, scale: 6 }) 
	valorUnitario: number; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => VendaCabecalhoModel, vendaCabecalhoModel => vendaCabecalhoModel.vendaDetalheModelList)
	@JoinColumn({ name: 'id_venda_cabecalho' })
	vendaCabecalhoModel: VendaCabecalhoModel;

	@OneToOne(() => ProdutoModel)
	@JoinColumn({ name: 'id_produto' })
	produtoModel: ProdutoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			this.valorUnitario = jsonObj['valorUnitario'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorTotal = jsonObj['valorTotal'];
			if (jsonObj['produtoModel'] != null) {
				this.produtoModel = new ProdutoModel(jsonObj['produtoModel']);
			}

		}
	}
}