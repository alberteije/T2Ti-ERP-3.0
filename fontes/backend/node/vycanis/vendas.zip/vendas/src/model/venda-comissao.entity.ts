import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { VendaCabecalhoModel } from '../entities-export';
import { ViewPessoaVendedorModel } from '../entities-export';

@Entity({ name: 'venda_comissao' })
export class VendaComissaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_venda', type: 'decimal', precision: 18, scale: 6 }) 
	valorVenda: number; 

	@Column({ name: 'tipo_contabil' }) 
	tipoContabil: string; 

	@Column({ name: 'valor_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	valorComissao: number; 

	@Column({ name: 'situacao' }) 
	situacao: string; 

	@Column({ name: 'data_lancamento' }) 
	dataLancamento: Date; 


	/**
	* Relations
	*/
	@OneToOne(() => VendaCabecalhoModel, vendaCabecalhoModel => vendaCabecalhoModel.vendaComissaoModel)
	@JoinColumn({ name: 'id_venda_cabecalho' })
	vendaCabecalhoModel: VendaCabecalhoModel;

	@OneToOne(() => ViewPessoaVendedorModel)
	@JoinColumn({ name: 'id_vendedor' })
	viewPessoaVendedorModel: ViewPessoaVendedorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorVenda = jsonObj['valorVenda'];
			this.tipoContabil = jsonObj['tipoContabil'];
			this.valorComissao = jsonObj['valorComissao'];
			this.situacao = jsonObj['situacao'];
			this.dataLancamento = jsonObj['dataLancamento'];
			if (jsonObj['viewPessoaVendedorModel'] != null) {
				this.viewPessoaVendedorModel = new ViewPessoaVendedorModel(jsonObj['viewPessoaVendedorModel']);
			}

		}
	}
}