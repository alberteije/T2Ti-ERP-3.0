import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { VendaCabecalhoModel } from '../entities-export';
import { ViewPessoaTransportadoraModel } from '../entities-export';

@Entity({ name: 'venda_frete' })
export class VendaFreteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'responsavel' }) 
	responsavel: string; 

	@Column({ name: 'conhecimento' }) 
	conhecimento: number; 

	@Column({ name: 'placa' }) 
	placa: string; 

	@Column({ name: 'uf_placa' }) 
	ufPlaca: string; 

	@Column({ name: 'selo_fiscal' }) 
	seloFiscal: number; 

	@Column({ name: 'quantidade_volume', type: 'decimal', precision: 18, scale: 6 }) 
	quantidadeVolume: number; 

	@Column({ name: 'marca_volume' }) 
	marcaVolume: string; 

	@Column({ name: 'especie_volume' }) 
	especieVolume: string; 

	@Column({ name: 'peso_bruto', type: 'decimal', precision: 18, scale: 6 }) 
	pesoBruto: number; 

	@Column({ name: 'peso_liquido', type: 'decimal', precision: 18, scale: 6 }) 
	pesoLiquido: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => VendaCabecalhoModel, vendaCabecalhoModel => vendaCabecalhoModel.vendaFreteModelList)
	@JoinColumn({ name: 'id_venda_cabecalho' })
	vendaCabecalhoModel: VendaCabecalhoModel;

	@OneToOne(() => ViewPessoaTransportadoraModel)
	@JoinColumn({ name: 'id_transportadora' })
	viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.responsavel = jsonObj['responsavel'];
			this.conhecimento = jsonObj['conhecimento'];
			this.placa = jsonObj['placa'];
			this.ufPlaca = jsonObj['ufPlaca'];
			this.seloFiscal = jsonObj['seloFiscal'];
			this.quantidadeVolume = jsonObj['quantidadeVolume'];
			this.marcaVolume = jsonObj['marcaVolume'];
			this.especieVolume = jsonObj['especieVolume'];
			this.pesoBruto = jsonObj['pesoBruto'];
			this.pesoLiquido = jsonObj['pesoLiquido'];
			if (jsonObj['viewPessoaTransportadoraModel'] != null) {
				this.viewPessoaTransportadoraModel = new ViewPessoaTransportadoraModel(jsonObj['viewPessoaTransportadoraModel']);
			}

		}
	}
}