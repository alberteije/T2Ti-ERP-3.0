import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { VendaOrcamentoDetalheModel } from '../entities-export';
import { VendaCondicoesPagamentoModel } from '../entities-export';
import { ViewPessoaVendedorModel } from '../entities-export';
import { ViewPessoaTransportadoraModel } from '../entities-export';
import { ViewPessoaClienteModel } from '../entities-export';

@Entity({ name: 'venda_orcamento_cabecalho' })
export class VendaOrcamentoCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo_frete' }) 
	tipoFrete: string; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'data_entrega' }) 
	dataEntrega: Date; 

	@Column({ name: 'data_validade' }) 
	dataValidade: Date; 

	@Column({ name: 'valor_subtotal', type: 'decimal', precision: 18, scale: 6 }) 
	valorSubtotal: number; 

	@Column({ name: 'valor_frete', type: 'decimal', precision: 18, scale: 6 }) 
	valorFrete: number; 

	@Column({ name: 'taxa_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaComissao: number; 

	@Column({ name: 'valor_comissao', type: 'decimal', precision: 18, scale: 6 }) 
	valorComissao: number; 

	@Column({ name: 'taxa_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	taxaDesconto: number; 

	@Column({ name: 'valor_desconto', type: 'decimal', precision: 18, scale: 6 }) 
	valorDesconto: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => VendaOrcamentoDetalheModel, vendaOrcamentoDetalheModel => vendaOrcamentoDetalheModel.vendaOrcamentoCabecalhoModel, { cascade: true })
	vendaOrcamentoDetalheModelList: VendaOrcamentoDetalheModel[];

	@OneToOne(() => VendaCondicoesPagamentoModel)
	@JoinColumn({ name: 'id_venda_condicoes_pagamento' })
	vendaCondicoesPagamentoModel: VendaCondicoesPagamentoModel;

	@OneToOne(() => ViewPessoaVendedorModel)
	@JoinColumn({ name: 'id_vendedor' })
	viewPessoaVendedorModel: ViewPessoaVendedorModel;

	@OneToOne(() => ViewPessoaTransportadoraModel)
	@JoinColumn({ name: 'id_transportadora' })
	viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel;

	@OneToOne(() => ViewPessoaClienteModel)
	@JoinColumn({ name: 'id_cliente' })
	viewPessoaClienteModel: ViewPessoaClienteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipoFrete = jsonObj['tipoFrete'];
			this.codigo = jsonObj['codigo'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.dataEntrega = jsonObj['dataEntrega'];
			this.dataValidade = jsonObj['dataValidade'];
			this.valorSubtotal = jsonObj['valorSubtotal'];
			this.valorFrete = jsonObj['valorFrete'];
			this.taxaComissao = jsonObj['taxaComissao'];
			this.valorComissao = jsonObj['valorComissao'];
			this.taxaDesconto = jsonObj['taxaDesconto'];
			this.valorDesconto = jsonObj['valorDesconto'];
			this.valorTotal = jsonObj['valorTotal'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['vendaCondicoesPagamentoModel'] != null) {
				this.vendaCondicoesPagamentoModel = new VendaCondicoesPagamentoModel(jsonObj['vendaCondicoesPagamentoModel']);
			}

			if (jsonObj['viewPessoaVendedorModel'] != null) {
				this.viewPessoaVendedorModel = new ViewPessoaVendedorModel(jsonObj['viewPessoaVendedorModel']);
			}

			if (jsonObj['viewPessoaTransportadoraModel'] != null) {
				this.viewPessoaTransportadoraModel = new ViewPessoaTransportadoraModel(jsonObj['viewPessoaTransportadoraModel']);
			}

			if (jsonObj['viewPessoaClienteModel'] != null) {
				this.viewPessoaClienteModel = new ViewPessoaClienteModel(jsonObj['viewPessoaClienteModel']);
			}

			this.vendaOrcamentoDetalheModelList = [];
			let vendaOrcamentoDetalheModelJsonList = jsonObj['vendaOrcamentoDetalheModelList'];
			if (vendaOrcamentoDetalheModelJsonList != null) {
				for (let i = 0; i < vendaOrcamentoDetalheModelJsonList.length; i++) {
					let obj = new VendaOrcamentoDetalheModel(vendaOrcamentoDetalheModelJsonList[i]);
					this.vendaOrcamentoDetalheModelList.push(obj);
				}
			}

		}
	}
}