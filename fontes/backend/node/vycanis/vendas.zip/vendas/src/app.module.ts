import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { ProdutoGrupoModule } from './modules-export';
import { ProdutoSubgrupoModule } from './modules-export';
import { ProdutoMarcaModule } from './modules-export';
import { ProdutoUnidadeModule } from './modules-export';
import { VendaCondicoesPagamentoModule } from './modules-export';
import { VendaOrcamentoCabecalhoModule } from './modules-export';
import { VendaCabecalhoModule } from './modules-export';
import { NotaFiscalModeloModule } from './modules-export';
import { NotaFiscalTipoModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaClienteModule } from './modules-export';
import { ViewPessoaVendedorModule } from './modules-export';
import { ViewPessoaTransportadoraModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';
import { AuditoriaModule } from './modules-export';
import { UsuarioTokenModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			ProdutoGrupoModule,
			ProdutoSubgrupoModule,
			ProdutoMarcaModule,
			ProdutoUnidadeModule,
			VendaCondicoesPagamentoModule,
			VendaOrcamentoCabecalhoModule,
			VendaCabecalhoModule,
			NotaFiscalModeloModule,
			NotaFiscalTipoModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaClienteModule,
			ViewPessoaVendedorModule,
			ViewPessoaTransportadoraModule,
      LoginModule,
      AuditoriaModule,
      UsuarioTokenModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],

  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}