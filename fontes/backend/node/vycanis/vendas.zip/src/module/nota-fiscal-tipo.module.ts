import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NotaFiscalTipoController } from '../controller/nota-fiscal-tipo.controller';
import { NotaFiscalTipoService } from '../service/nota-fiscal-tipo.service';
import { NotaFiscalTipoModel } from '../model/nota-fiscal-tipo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NotaFiscalTipoModel])],
    controllers: [NotaFiscalTipoController],
    providers: [NotaFiscalTipoService],
})
export class NotaFiscalTipoModule { }
