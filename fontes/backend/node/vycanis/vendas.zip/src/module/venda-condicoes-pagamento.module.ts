import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VendaCondicoesPagamentoController } from '../controller/venda-condicoes-pagamento.controller';
import { VendaCondicoesPagamentoService } from '../service/venda-condicoes-pagamento.service';
import { VendaCondicoesPagamentoModel } from '../model/venda-condicoes-pagamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([VendaCondicoesPagamentoModel])],
    controllers: [VendaCondicoesPagamentoController],
    providers: [VendaCondicoesPagamentoService],
})
export class VendaCondicoesPagamentoModule { }
