import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NotaFiscalModeloController } from '../controller/nota-fiscal-modelo.controller';
import { NotaFiscalModeloService } from '../service/nota-fiscal-modelo.service';
import { NotaFiscalModeloModel } from '../model/nota-fiscal-modelo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([NotaFiscalModeloModel])],
    controllers: [NotaFiscalModeloController],
    providers: [NotaFiscalModeloService],
})
export class NotaFiscalModeloModule { }
