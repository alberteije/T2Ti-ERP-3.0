import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { VendaOrcamentoCabecalhoModel } from '../entities-export';

@Injectable()
export class VendaOrcamentoCabecalhoService extends TypeOrmCrudService<VendaOrcamentoCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(VendaOrcamentoCabecalhoModel) 
    private readonly repository: Repository<VendaOrcamentoCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(vendaOrcamentoCabecalhoModel: VendaOrcamentoCabecalhoModel, operation: string): Promise<VendaOrcamentoCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, vendaOrcamentoCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(vendaOrcamentoCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(VendaOrcamentoCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from venda_orcamento_detalhe where id_venda_orcamento_cabecalho=' + id); 

	}
	
}