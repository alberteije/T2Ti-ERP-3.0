import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { VendaCondicoesPagamentoModel } from '../entities-export';

@Injectable()
export class VendaCondicoesPagamentoService extends TypeOrmCrudService<VendaCondicoesPagamentoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(VendaCondicoesPagamentoModel) 
    private readonly repository: Repository<VendaCondicoesPagamentoModel>,
  ) {
    super(repository);
  }

	async save(vendaCondicoesPagamentoModel: VendaCondicoesPagamentoModel, operation: string): Promise<VendaCondicoesPagamentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, vendaCondicoesPagamentoModel.id);
      }

      const resultObj = await queryRunner.manager.save(vendaCondicoesPagamentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(VendaCondicoesPagamentoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from venda_condicoes_parcelas where id_venda_condicoes_pagamento=' + id); 

	}
	
}