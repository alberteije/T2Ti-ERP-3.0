import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { ProdutoGrupoModel } from '../entities-export';

@Injectable()
export class ProdutoGrupoService extends TypeOrmCrudService<ProdutoGrupoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(ProdutoGrupoModel) 
    private readonly repository: Repository<ProdutoGrupoModel>,
  ) {
    super(repository);
  }

	async save(produtoGrupoModel: ProdutoGrupoModel, operation: string): Promise<ProdutoGrupoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, produtoGrupoModel.id);
      }

      const resultObj = await queryRunner.manager.save(produtoGrupoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(ProdutoGrupoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from produto_subgrupo where id_produto_grupo=' + id); 

	}
	
}