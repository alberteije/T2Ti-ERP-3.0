import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { VendaCabecalhoModel } from '../entities-export';

@Injectable()
export class VendaCabecalhoService extends TypeOrmCrudService<VendaCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(VendaCabecalhoModel) 
    private readonly repository: Repository<VendaCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(vendaCabecalhoModel: VendaCabecalhoModel, operation: string): Promise<VendaCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, vendaCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(vendaCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(VendaCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from venda_comissao where id_venda_cabecalho=' + id); 

		await queryRunner.query('delete from venda_detalhe where id_venda_cabecalho=' + id); 

		await queryRunner.query('delete from venda_frete where id_venda_cabecalho=' + id); 

	}
	
}