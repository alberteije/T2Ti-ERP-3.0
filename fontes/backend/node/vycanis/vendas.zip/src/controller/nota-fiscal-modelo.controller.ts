import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { NotaFiscalModeloService } from '../service/nota-fiscal-modelo.service';
import { NotaFiscalModeloModel } from '../model/nota-fiscal-modelo.entity';

@Crud({
  model: {
    type: NotaFiscalModeloModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('nota-fiscal-modelo')
export class NotaFiscalModeloController implements CrudController<NotaFiscalModeloModel> {
  constructor(public service: NotaFiscalModeloService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const notaFiscalModeloModel = new NotaFiscalModeloModel(jsonObj);
		const result = await this.service.save(notaFiscalModeloModel);
		return result;
	}  


}


















