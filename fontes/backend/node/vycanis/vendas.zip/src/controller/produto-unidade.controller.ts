import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ProdutoUnidadeService } from '../service/produto-unidade.service';
import { ProdutoUnidadeModel } from '../model/produto-unidade.entity';

@Crud({
  model: {
    type: ProdutoUnidadeModel,
  },
  query: {
    join: {
			produtoModelList: { eager: true },
    },
  },
})
@Controller('produto-unidade')
export class ProdutoUnidadeController implements CrudController<ProdutoUnidadeModel> {
  constructor(public service: ProdutoUnidadeService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoUnidade = new ProdutoUnidadeModel(jsonObj);
		const result = await this.service.save(produtoUnidade, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const produtoUnidade = new ProdutoUnidadeModel(jsonObj);
		const result = await this.service.save(produtoUnidade, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}