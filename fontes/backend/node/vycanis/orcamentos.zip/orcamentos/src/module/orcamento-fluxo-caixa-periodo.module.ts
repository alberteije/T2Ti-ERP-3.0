import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrcamentoFluxoCaixaPeriodoController } from '../controller/orcamento-fluxo-caixa-periodo.controller';
import { OrcamentoFluxoCaixaPeriodoService } from '../service/orcamento-fluxo-caixa-periodo.service';
import { OrcamentoFluxoCaixaPeriodoModel } from '../model/orcamento-fluxo-caixa-periodo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OrcamentoFluxoCaixaPeriodoModel])],
    controllers: [OrcamentoFluxoCaixaPeriodoController],
    providers: [OrcamentoFluxoCaixaPeriodoService],
})
export class OrcamentoFluxoCaixaPeriodoModule { }
