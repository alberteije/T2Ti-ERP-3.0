import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrcamentoPeriodoController } from '../controller/orcamento-periodo.controller';
import { OrcamentoPeriodoService } from '../service/orcamento-periodo.service';
import { OrcamentoPeriodoModel } from '../model/orcamento-periodo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OrcamentoPeriodoModel])],
    controllers: [OrcamentoPeriodoController],
    providers: [OrcamentoPeriodoService],
})
export class OrcamentoPeriodoModule { }
