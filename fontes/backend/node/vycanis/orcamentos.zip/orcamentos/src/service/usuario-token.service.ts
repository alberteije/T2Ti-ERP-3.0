import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { UsuarioTokenModel } from '../entities-export';

@Injectable()
export class UsuarioTokenService extends TypeOrmCrudService<UsuarioTokenModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(UsuarioTokenModel)
    private readonly repository: Repository<UsuarioTokenModel>
  ) {
    super(repository);
  }

	async save(usuarioTokenModel: UsuarioTokenModel): Promise<UsuarioTokenModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(usuarioTokenModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
