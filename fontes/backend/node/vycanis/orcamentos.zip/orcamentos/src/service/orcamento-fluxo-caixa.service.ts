import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { OrcamentoFluxoCaixaModel } from '../entities-export';

@Injectable()
export class OrcamentoFluxoCaixaService extends TypeOrmCrudService<OrcamentoFluxoCaixaModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(OrcamentoFluxoCaixaModel) 
    private readonly repository: Repository<OrcamentoFluxoCaixaModel>,
  ) {
    super(repository);
  }

	async save(orcamentoFluxoCaixaModel: OrcamentoFluxoCaixaModel, operation: string): Promise<OrcamentoFluxoCaixaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, orcamentoFluxoCaixaModel.id);
      }

      const resultObj = await queryRunner.manager.save(orcamentoFluxoCaixaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(OrcamentoFluxoCaixaModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from orcamento_fluxo_caixa_detalhe where id_orcamento_fluxo_caixa=' + id); 

	}
	
}