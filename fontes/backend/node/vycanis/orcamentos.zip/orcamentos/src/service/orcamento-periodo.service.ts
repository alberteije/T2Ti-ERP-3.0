import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { OrcamentoPeriodoModel } from '../entities-export';

@Injectable()
export class OrcamentoPeriodoService extends TypeOrmCrudService<OrcamentoPeriodoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(OrcamentoPeriodoModel)
    private readonly repository: Repository<OrcamentoPeriodoModel>
  ) {
    super(repository);
  }

	async save(orcamentoPeriodoModel: OrcamentoPeriodoModel): Promise<OrcamentoPeriodoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(orcamentoPeriodoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
