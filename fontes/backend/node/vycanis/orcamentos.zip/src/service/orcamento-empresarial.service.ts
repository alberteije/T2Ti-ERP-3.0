import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { OrcamentoEmpresarialModel } from '../entities-export';

@Injectable()
export class OrcamentoEmpresarialService extends TypeOrmCrudService<OrcamentoEmpresarialModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(OrcamentoEmpresarialModel) 
    private readonly repository: Repository<OrcamentoEmpresarialModel>,
  ) {
    super(repository);
  }

	async save(orcamentoEmpresarialModel: OrcamentoEmpresarialModel, operation: string): Promise<OrcamentoEmpresarialModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, orcamentoEmpresarialModel.id);
      }

      const resultObj = await queryRunner.manager.save(orcamentoEmpresarialModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(OrcamentoEmpresarialModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from orcamento_detalhe where id_orcamento_empresarial=' + id); 

	}
	
}