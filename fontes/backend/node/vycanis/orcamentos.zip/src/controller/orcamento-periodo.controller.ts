import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { OrcamentoPeriodoService } from '../service/orcamento-periodo.service';
import { OrcamentoPeriodoModel } from '../model/orcamento-periodo.entity';

@Crud({
  model: {
    type: OrcamentoPeriodoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('orcamento-periodo')
export class OrcamentoPeriodoController implements CrudController<OrcamentoPeriodoModel> {
  constructor(public service: OrcamentoPeriodoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const orcamentoPeriodoModel = new OrcamentoPeriodoModel(jsonObj);
		const result = await this.service.save(orcamentoPeriodoModel);
		return result;
	}  


}


















