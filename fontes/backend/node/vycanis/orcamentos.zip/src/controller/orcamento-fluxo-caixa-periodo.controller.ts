import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { OrcamentoFluxoCaixaPeriodoService } from '../service/orcamento-fluxo-caixa-periodo.service';
import { OrcamentoFluxoCaixaPeriodoModel } from '../model/orcamento-fluxo-caixa-periodo.entity';

@Crud({
  model: {
    type: OrcamentoFluxoCaixaPeriodoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('orcamento-fluxo-caixa-periodo')
export class OrcamentoFluxoCaixaPeriodoController implements CrudController<OrcamentoFluxoCaixaPeriodoModel> {
  constructor(public service: OrcamentoFluxoCaixaPeriodoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const orcamentoFluxoCaixaPeriodoModel = new OrcamentoFluxoCaixaPeriodoModel(jsonObj);
		const result = await this.service.save(orcamentoFluxoCaixaPeriodoModel);
		return result;
	}  


}


















