import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { OrcamentoEmpresarialService } from '../service/orcamento-empresarial.service';
import { OrcamentoEmpresarialModel } from '../model/orcamento-empresarial.entity';

@Crud({
  model: {
    type: OrcamentoEmpresarialModel,
  },
  query: {
    join: {
			orcamentoDetalheModelList: { eager: true },
			orcamentoPeriodoModel: { eager: true },
    },
  },
})
@Controller('orcamento-empresarial')
export class OrcamentoEmpresarialController implements CrudController<OrcamentoEmpresarialModel> {
  constructor(public service: OrcamentoEmpresarialService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const orcamentoEmpresarial = new OrcamentoEmpresarialModel(jsonObj);
		const result = await this.service.save(orcamentoEmpresarial, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const orcamentoEmpresarial = new OrcamentoEmpresarialModel(jsonObj);
		const result = await this.service.save(orcamentoEmpresarial, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}