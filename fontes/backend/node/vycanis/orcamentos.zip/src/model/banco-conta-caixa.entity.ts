import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'banco_conta_caixa' })
export class BancoContaCaixaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero' }) 
	numero: string; 

	@Column({ name: 'digito' }) 
	digito: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numero = jsonObj['numero'];
			this.digito = jsonObj['digito'];
			this.nome = jsonObj['nome'];
			this.tipo = jsonObj['tipo'];
			this.descricao = jsonObj['descricao'];
		}
	}
}