import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OrcamentoDetalheModel } from '../entities-export';
import { OrcamentoPeriodoModel } from '../entities-export';

@Entity({ name: 'orcamento_empresarial' })
export class OrcamentoEmpresarialModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'data_inicial' }) 
	dataInicial: Date; 

	@Column({ name: 'numero_periodos' }) 
	numeroPeriodos: number; 

	@Column({ name: 'data_base' }) 
	dataBase: Date; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => OrcamentoDetalheModel, orcamentoDetalheModel => orcamentoDetalheModel.orcamentoEmpresarialModel, { cascade: true })
	orcamentoDetalheModelList: OrcamentoDetalheModel[];

	@OneToOne(() => OrcamentoPeriodoModel)
	@JoinColumn({ name: 'id_orcamento_periodo' })
	orcamentoPeriodoModel: OrcamentoPeriodoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.dataInicial = jsonObj['dataInicial'];
			this.numeroPeriodos = jsonObj['numeroPeriodos'];
			this.dataBase = jsonObj['dataBase'];
			this.descricao = jsonObj['descricao'];
			if (jsonObj['orcamentoPeriodoModel'] != null) {
				this.orcamentoPeriodoModel = new OrcamentoPeriodoModel(jsonObj['orcamentoPeriodoModel']);
			}

			this.orcamentoDetalheModelList = [];
			let orcamentoDetalheModelJsonList = jsonObj['orcamentoDetalheModelList'];
			if (orcamentoDetalheModelJsonList != null) {
				for (let i = 0; i < orcamentoDetalheModelJsonList.length; i++) {
					let obj = new OrcamentoDetalheModel(orcamentoDetalheModelJsonList[i]);
					this.orcamentoDetalheModelList.push(obj);
				}
			}

		}
	}
}