import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OrcamentoFluxoCaixaDetalheModel } from '../entities-export';
import { OrcamentoFluxoCaixaPeriodoModel } from '../entities-export';

@Entity({ name: 'orcamento_fluxo_caixa' })
export class OrcamentoFluxoCaixaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'data_inicial' }) 
	dataInicial: Date; 

	@Column({ name: 'numero_periodos' }) 
	numeroPeriodos: number; 

	@Column({ name: 'data_base' }) 
	dataBase: Date; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => OrcamentoFluxoCaixaDetalheModel, orcamentoFluxoCaixaDetalheModel => orcamentoFluxoCaixaDetalheModel.orcamentoFluxoCaixaModel, { cascade: true })
	orcamentoFluxoCaixaDetalheModelList: OrcamentoFluxoCaixaDetalheModel[];

	@OneToOne(() => OrcamentoFluxoCaixaPeriodoModel)
	@JoinColumn({ name: 'id_orc_fluxo_caixa_periodo' })
	orcamentoFluxoCaixaPeriodoModel: OrcamentoFluxoCaixaPeriodoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.dataInicial = jsonObj['dataInicial'];
			this.numeroPeriodos = jsonObj['numeroPeriodos'];
			this.dataBase = jsonObj['dataBase'];
			this.descricao = jsonObj['descricao'];
			if (jsonObj['orcamentoFluxoCaixaPeriodoModel'] != null) {
				this.orcamentoFluxoCaixaPeriodoModel = new OrcamentoFluxoCaixaPeriodoModel(jsonObj['orcamentoFluxoCaixaPeriodoModel']);
			}

			this.orcamentoFluxoCaixaDetalheModelList = [];
			let orcamentoFluxoCaixaDetalheModelJsonList = jsonObj['orcamentoFluxoCaixaDetalheModelList'];
			if (orcamentoFluxoCaixaDetalheModelJsonList != null) {
				for (let i = 0; i < orcamentoFluxoCaixaDetalheModelJsonList.length; i++) {
					let obj = new OrcamentoFluxoCaixaDetalheModel(orcamentoFluxoCaixaDetalheModelJsonList[i]);
					this.orcamentoFluxoCaixaDetalheModelList.push(obj);
				}
			}

		}
	}
}