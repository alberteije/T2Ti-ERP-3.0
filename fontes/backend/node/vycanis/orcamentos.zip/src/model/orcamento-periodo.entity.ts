import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'orcamento_periodo' })
export class OrcamentoPeriodoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'periodo' }) 
	periodo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.periodo = jsonObj['periodo'];
			this.nome = jsonObj['nome'];
		}
	}
}