import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { OrcamentoEmpresarialModel } from '../entities-export';
import { FinNaturezaFinanceiraModel } from '../entities-export';

@Entity({ name: 'orcamento_detalhe' })
export class OrcamentoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'periodo' }) 
	periodo: string; 

	@Column({ name: 'valor_orcado', type: 'decimal', precision: 18, scale: 6 }) 
	valorOrcado: number; 

	@Column({ name: 'valor_realizado', type: 'decimal', precision: 18, scale: 6 }) 
	valorRealizado: number; 

	@Column({ name: 'taxa_variacao', type: 'decimal', precision: 18, scale: 6 }) 
	taxaVariacao: number; 

	@Column({ name: 'valor_variacao', type: 'decimal', precision: 18, scale: 6 }) 
	valorVariacao: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => OrcamentoEmpresarialModel, orcamentoEmpresarialModel => orcamentoEmpresarialModel.orcamentoDetalheModelList)
	@JoinColumn({ name: 'id_orcamento_empresarial' })
	orcamentoEmpresarialModel: OrcamentoEmpresarialModel;

	@OneToOne(() => FinNaturezaFinanceiraModel)
	@JoinColumn({ name: 'id_fin_natureza_financeira' })
	finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.periodo = jsonObj['periodo'];
			this.valorOrcado = jsonObj['valorOrcado'];
			this.valorRealizado = jsonObj['valorRealizado'];
			this.taxaVariacao = jsonObj['taxaVariacao'];
			this.valorVariacao = jsonObj['valorVariacao'];
			if (jsonObj['finNaturezaFinanceiraModel'] != null) {
				this.finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel(jsonObj['finNaturezaFinanceiraModel']);
			}

		}
	}
}