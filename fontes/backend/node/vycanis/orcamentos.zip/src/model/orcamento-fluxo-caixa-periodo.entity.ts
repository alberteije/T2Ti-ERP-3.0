import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { BancoContaCaixaModel } from '../entities-export';

@Entity({ name: 'orcamento_fluxo_caixa_periodo' })
export class OrcamentoFluxoCaixaPeriodoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'periodo' }) 
	periodo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 


	/**
	* Relations
	*/
	@OneToOne(() => BancoContaCaixaModel)
	@JoinColumn({ name: 'id_banco_conta_caixa' })
	bancoContaCaixaModel: BancoContaCaixaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.periodo = jsonObj['periodo'];
			this.nome = jsonObj['nome'];
			if (jsonObj['bancoContaCaixaModel'] != null) {
				this.bancoContaCaixaModel = new BancoContaCaixaModel(jsonObj['bancoContaCaixaModel']);
			}

		}
	}
}