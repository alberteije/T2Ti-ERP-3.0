import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrcamentoFluxoCaixaController } from '../controller/orcamento-fluxo-caixa.controller';
import { OrcamentoFluxoCaixaService } from '../service/orcamento-fluxo-caixa.service';
import { OrcamentoFluxoCaixaModel } from '../model/orcamento-fluxo-caixa.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OrcamentoFluxoCaixaModel])],
    controllers: [OrcamentoFluxoCaixaController],
    providers: [OrcamentoFluxoCaixaService],
})
export class OrcamentoFluxoCaixaModule { }
