import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrcamentoEmpresarialController } from '../controller/orcamento-empresarial.controller';
import { OrcamentoEmpresarialService } from '../service/orcamento-empresarial.service';
import { OrcamentoEmpresarialModel } from '../model/orcamento-empresarial.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OrcamentoEmpresarialModel])],
    controllers: [OrcamentoEmpresarialController],
    providers: [OrcamentoEmpresarialService],
})
export class OrcamentoEmpresarialModule { }
