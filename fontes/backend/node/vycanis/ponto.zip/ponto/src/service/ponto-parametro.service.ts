import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PontoParametroModel } from '../entities-export';

@Injectable()
export class PontoParametroService extends TypeOrmCrudService<PontoParametroModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PontoParametroModel)
    private readonly repository: Repository<PontoParametroModel>
  ) {
    super(repository);
  }

	async save(pontoParametroModel: PontoParametroModel): Promise<PontoParametroModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(pontoParametroModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
