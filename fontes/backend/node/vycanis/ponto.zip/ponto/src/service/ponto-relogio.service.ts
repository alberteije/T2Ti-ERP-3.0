import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PontoRelogioModel } from '../entities-export';

@Injectable()
export class PontoRelogioService extends TypeOrmCrudService<PontoRelogioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PontoRelogioModel)
    private readonly repository: Repository<PontoRelogioModel>
  ) {
    super(repository);
  }

	async save(pontoRelogioModel: PontoRelogioModel): Promise<PontoRelogioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(pontoRelogioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
