import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { PontoAbonoModel } from '../entities-export';

@Injectable()
export class PontoAbonoService extends TypeOrmCrudService<PontoAbonoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(PontoAbonoModel) 
    private readonly repository: Repository<PontoAbonoModel>,
  ) {
    super(repository);
  }

	async save(pontoAbonoModel: PontoAbonoModel, operation: string): Promise<PontoAbonoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, pontoAbonoModel.id);
      }

      const resultObj = await queryRunner.manager.save(pontoAbonoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(PontoAbonoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from ponto_abono_utilizacao where id_ponto_abono=' + id); 

	}
	
}