export { PontoEscalaModule } from './module/ponto-escala.module';
export { PontoBancoHorasModule } from './module/ponto-banco-horas.module';
export { PontoAbonoModule } from './module/ponto-abono.module';
export { PontoParametroModule } from './module/ponto-parametro.module';
export { PontoHorarioModule } from './module/ponto-horario.module';
export { PontoRelogioModule } from './module/ponto-relogio.module';
export { PontoMarcacaoModule } from './module/ponto-marcacao.module';
export { PontoClassificacaoJornadaModule } from './module/ponto-classificacao-jornada.module';
export { PontoHorarioAutorizadoModule } from './module/ponto-horario-autorizado.module';
export { PontoFechamentoJornadaModule } from './module/ponto-fechamento-jornada.module';
export { ViewControleAcessoModule } from './module/view-controle-acesso.module';
export { ViewPessoaUsuarioModule } from './module/view-pessoa-usuario.module';
export { ViewPessoaColaboradorModule } from './module/view-pessoa-colaborador.module';

export { UsuarioTokenModule } from './module/usuario-token.module';
export { AuditoriaModule } from './module/auditoria.module';