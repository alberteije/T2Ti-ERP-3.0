import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PontoAbonoService } from '../service/ponto-abono.service';
import { PontoAbonoModel } from '../model/ponto-abono.entity';

@Crud({
  model: {
    type: PontoAbonoModel,
  },
  query: {
    join: {
			pontoAbonoUtilizacaoModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('ponto-abono')
export class PontoAbonoController implements CrudController<PontoAbonoModel> {
  constructor(public service: PontoAbonoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoAbono = new PontoAbonoModel(jsonObj);
		const result = await this.service.save(pontoAbono, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoAbono = new PontoAbonoModel(jsonObj);
		const result = await this.service.save(pontoAbono, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}