import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PontoRelogioService } from '../service/ponto-relogio.service';
import { PontoRelogioModel } from '../model/ponto-relogio.entity';

@Crud({
  model: {
    type: PontoRelogioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ponto-relogio')
export class PontoRelogioController implements CrudController<PontoRelogioModel> {
  constructor(public service: PontoRelogioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoRelogioModel = new PontoRelogioModel(jsonObj);
		const result = await this.service.save(pontoRelogioModel);
		return result;
	}  


}


















