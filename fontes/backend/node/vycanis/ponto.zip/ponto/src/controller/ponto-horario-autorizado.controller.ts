import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PontoHorarioAutorizadoService } from '../service/ponto-horario-autorizado.service';
import { PontoHorarioAutorizadoModel } from '../model/ponto-horario-autorizado.entity';

@Crud({
  model: {
    type: PontoHorarioAutorizadoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ponto-horario-autorizado')
export class PontoHorarioAutorizadoController implements CrudController<PontoHorarioAutorizadoModel> {
  constructor(public service: PontoHorarioAutorizadoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoHorarioAutorizadoModel = new PontoHorarioAutorizadoModel(jsonObj);
		const result = await this.service.save(pontoHorarioAutorizadoModel);
		return result;
	}  


}


















