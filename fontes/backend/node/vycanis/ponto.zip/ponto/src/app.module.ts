import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { PontoEscalaModule } from './modules-export';
import { PontoBancoHorasModule } from './modules-export';
import { PontoAbonoModule } from './modules-export';
import { PontoParametroModule } from './modules-export';
import { PontoHorarioModule } from './modules-export';
import { PontoRelogioModule } from './modules-export';
import { PontoMarcacaoModule } from './modules-export';
import { PontoClassificacaoJornadaModule } from './modules-export';
import { PontoHorarioAutorizadoModule } from './modules-export';
import { PontoFechamentoJornadaModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaColaboradorModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';
import { AuditoriaModule } from './modules-export';
import { UsuarioTokenModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			PontoEscalaModule,
			PontoBancoHorasModule,
			PontoAbonoModule,
			PontoParametroModule,
			PontoHorarioModule,
			PontoRelogioModule,
			PontoMarcacaoModule,
			PontoClassificacaoJornadaModule,
			PontoHorarioAutorizadoModule,
			PontoFechamentoJornadaModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaColaboradorModule,
      LoginModule,
      AuditoriaModule,
      UsuarioTokenModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],

  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}