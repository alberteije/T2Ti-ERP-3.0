import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PontoEscalaModel } from '../entities-export';

@Entity({ name: 'ponto_turma' })
export class PontoTurmaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PontoEscalaModel, pontoEscalaModel => pontoEscalaModel.pontoTurmaModelList)
	@JoinColumn({ name: 'id_ponto_escala' })
	pontoEscalaModel: PontoEscalaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
		}
	}
}