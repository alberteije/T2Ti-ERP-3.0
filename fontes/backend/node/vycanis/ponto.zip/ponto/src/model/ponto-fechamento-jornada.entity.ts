import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { PontoClassificacaoJornadaModel } from '../entities-export';

@Entity({ name: 'ponto_fechamento_jornada' })
export class PontoFechamentoJornadaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_fechamento' }) 
	dataFechamento: Date; 

	@Column({ name: 'dia_semana' }) 
	diaSemana: string; 

	@Column({ name: 'codigo_horario' }) 
	codigoHorario: string; 

	@Column({ name: 'carga_horaria_esperada' }) 
	cargaHorariaEsperada: string; 

	@Column({ name: 'carga_horaria_diurna' }) 
	cargaHorariaDiurna: string; 

	@Column({ name: 'carga_horaria_noturna' }) 
	cargaHorariaNoturna: string; 

	@Column({ name: 'carga_horaria_total' }) 
	cargaHorariaTotal: string; 

	@Column({ name: 'entrada01' }) 
	entrada01: string; 

	@Column({ name: 'saida01' }) 
	saida01: string; 

	@Column({ name: 'entrada02' }) 
	entrada02: string; 

	@Column({ name: 'saida02' }) 
	saida02: string; 

	@Column({ name: 'entrada03' }) 
	entrada03: string; 

	@Column({ name: 'saida03' }) 
	saida03: string; 

	@Column({ name: 'entrada04' }) 
	entrada04: string; 

	@Column({ name: 'saida04' }) 
	saida04: string; 

	@Column({ name: 'entrada05' }) 
	entrada05: string; 

	@Column({ name: 'saida05' }) 
	saida05: string; 

	@Column({ name: 'hora_inicio_jornada' }) 
	horaInicioJornada: string; 

	@Column({ name: 'hora_fim_jornada' }) 
	horaFimJornada: string; 

	@Column({ name: 'hora_extra01' }) 
	horaExtra01: string; 

	@Column({ name: 'percentual_hora_extra01', type: 'decimal', precision: 18, scale: 6 }) 
	percentualHoraExtra01: number; 

	@Column({ name: 'modalidade_hora_extra01' }) 
	modalidadeHoraExtra01: string; 

	@Column({ name: 'hora_extra02' }) 
	horaExtra02: string; 

	@Column({ name: 'percentual_hora_extra02', type: 'decimal', precision: 18, scale: 6 }) 
	percentualHoraExtra02: number; 

	@Column({ name: 'modalidade_hora_extra02' }) 
	modalidadeHoraExtra02: string; 

	@Column({ name: 'hora_extra03' }) 
	horaExtra03: string; 

	@Column({ name: 'percentual_hora_extra03', type: 'decimal', precision: 18, scale: 6 }) 
	percentualHoraExtra03: number; 

	@Column({ name: 'modalidade_hora_extra03' }) 
	modalidadeHoraExtra03: string; 

	@Column({ name: 'hora_extra04' }) 
	horaExtra04: string; 

	@Column({ name: 'percentual_hora_extra04', type: 'decimal', precision: 18, scale: 6 }) 
	percentualHoraExtra04: number; 

	@Column({ name: 'modalidade_hora_extra04' }) 
	modalidadeHoraExtra04: string; 

	@Column({ name: 'falta_atraso' }) 
	faltaAtraso: string; 

	@Column({ name: 'compensar' }) 
	compensar: string; 

	@Column({ name: 'banco_horas' }) 
	bancoHoras: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => PontoClassificacaoJornadaModel)
	@JoinColumn({ name: 'id_ponto_classificacao_jornada' })
	pontoClassificacaoJornadaModel: PontoClassificacaoJornadaModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataFechamento = jsonObj['dataFechamento'];
			this.diaSemana = jsonObj['diaSemana'];
			this.codigoHorario = jsonObj['codigoHorario'];
			this.cargaHorariaEsperada = jsonObj['cargaHorariaEsperada'];
			this.cargaHorariaDiurna = jsonObj['cargaHorariaDiurna'];
			this.cargaHorariaNoturna = jsonObj['cargaHorariaNoturna'];
			this.cargaHorariaTotal = jsonObj['cargaHorariaTotal'];
			this.entrada01 = jsonObj['entrada01'];
			this.saida01 = jsonObj['saida01'];
			this.entrada02 = jsonObj['entrada02'];
			this.saida02 = jsonObj['saida02'];
			this.entrada03 = jsonObj['entrada03'];
			this.saida03 = jsonObj['saida03'];
			this.entrada04 = jsonObj['entrada04'];
			this.saida04 = jsonObj['saida04'];
			this.entrada05 = jsonObj['entrada05'];
			this.saida05 = jsonObj['saida05'];
			this.horaInicioJornada = jsonObj['horaInicioJornada'];
			this.horaFimJornada = jsonObj['horaFimJornada'];
			this.horaExtra01 = jsonObj['horaExtra01'];
			this.percentualHoraExtra01 = jsonObj['percentualHoraExtra01'];
			this.modalidadeHoraExtra01 = jsonObj['modalidadeHoraExtra01'];
			this.horaExtra02 = jsonObj['horaExtra02'];
			this.percentualHoraExtra02 = jsonObj['percentualHoraExtra02'];
			this.modalidadeHoraExtra02 = jsonObj['modalidadeHoraExtra02'];
			this.horaExtra03 = jsonObj['horaExtra03'];
			this.percentualHoraExtra03 = jsonObj['percentualHoraExtra03'];
			this.modalidadeHoraExtra03 = jsonObj['modalidadeHoraExtra03'];
			this.horaExtra04 = jsonObj['horaExtra04'];
			this.percentualHoraExtra04 = jsonObj['percentualHoraExtra04'];
			this.modalidadeHoraExtra04 = jsonObj['modalidadeHoraExtra04'];
			this.faltaAtraso = jsonObj['faltaAtraso'];
			this.compensar = jsonObj['compensar'];
			this.bancoHoras = jsonObj['bancoHoras'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['pontoClassificacaoJornadaModel'] != null) {
				this.pontoClassificacaoJornadaModel = new PontoClassificacaoJornadaModel(jsonObj['pontoClassificacaoJornadaModel']);
			}

		}
	}
}