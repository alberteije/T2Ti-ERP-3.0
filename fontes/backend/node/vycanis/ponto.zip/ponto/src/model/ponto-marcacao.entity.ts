import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { PontoRelogioModel } from '../entities-export';

@Entity({ name: 'ponto_marcacao' })
export class PontoMarcacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nsr' }) 
	nsr: number; 

	@Column({ name: 'data_marcacao' }) 
	dataMarcacao: Date; 

	@Column({ name: 'hora_marcacao' }) 
	horaMarcacao: string; 

	@Column({ name: 'tipo_marcacao' }) 
	tipoMarcacao: string; 

	@Column({ name: 'tipo_registro' }) 
	tipoRegistro: string; 

	@Column({ name: 'par_entrada_saida' }) 
	parEntradaSaida: string; 

	@Column({ name: 'justificativa' }) 
	justificativa: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => PontoRelogioModel)
	@JoinColumn({ name: 'id_ponto_relogio' })
	pontoRelogioModel: PontoRelogioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nsr = jsonObj['nsr'];
			this.dataMarcacao = jsonObj['dataMarcacao'];
			this.horaMarcacao = jsonObj['horaMarcacao'];
			this.tipoMarcacao = jsonObj['tipoMarcacao'];
			this.tipoRegistro = jsonObj['tipoRegistro'];
			this.parEntradaSaida = jsonObj['parEntradaSaida'];
			this.justificativa = jsonObj['justificativa'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['pontoRelogioModel'] != null) {
				this.pontoRelogioModel = new PontoRelogioModel(jsonObj['pontoRelogioModel']);
			}

		}
	}
}