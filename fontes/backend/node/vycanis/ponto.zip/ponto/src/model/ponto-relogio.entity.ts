import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'ponto_relogio' })
export class PontoRelogioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'localizacao' }) 
	localizacao: string; 

	@Column({ name: 'marca' }) 
	marca: string; 

	@Column({ name: 'fabricante' }) 
	fabricante: string; 

	@Column({ name: 'numero_serie' }) 
	numeroSerie: string; 

	@Column({ name: 'utilizacao' }) 
	utilizacao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.localizacao = jsonObj['localizacao'];
			this.marca = jsonObj['marca'];
			this.fabricante = jsonObj['fabricante'];
			this.numeroSerie = jsonObj['numeroSerie'];
			this.utilizacao = jsonObj['utilizacao'];
		}
	}
}