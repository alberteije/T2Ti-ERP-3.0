import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'ponto_parametro' })
export class PontoParametroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'mes_ano' }) 
	mesAno: string; 

	@Column({ name: 'dia_inicial_apuracao' }) 
	diaInicialApuracao: number; 

	@Column({ name: 'hora_noturna_inicio' }) 
	horaNoturnaInicio: string; 

	@Column({ name: 'hora_noturna_fim' }) 
	horaNoturnaFim: string; 

	@Column({ name: 'periodo_minimo_interjornada' }) 
	periodoMinimoInterjornada: string; 

	@Column({ name: 'percentual_he_diurna', type: 'decimal', precision: 18, scale: 6 }) 
	percentualHeDiurna: number; 

	@Column({ name: 'percentual_he_noturna', type: 'decimal', precision: 18, scale: 6 }) 
	percentualHeNoturna: number; 

	@Column({ name: 'duracao_hora_noturna' }) 
	duracaoHoraNoturna: string; 

	@Column({ name: 'tratamento_hora_mais' }) 
	tratamentoHoraMais: string; 

	@Column({ name: 'tratamento_hora_menos' }) 
	tratamentoHoraMenos: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.mesAno = jsonObj['mesAno'];
			this.diaInicialApuracao = jsonObj['diaInicialApuracao'];
			this.horaNoturnaInicio = jsonObj['horaNoturnaInicio'];
			this.horaNoturnaFim = jsonObj['horaNoturnaFim'];
			this.periodoMinimoInterjornada = jsonObj['periodoMinimoInterjornada'];
			this.percentualHeDiurna = jsonObj['percentualHeDiurna'];
			this.percentualHeNoturna = jsonObj['percentualHeNoturna'];
			this.duracaoHoraNoturna = jsonObj['duracaoHoraNoturna'];
			this.tratamentoHoraMais = jsonObj['tratamentoHoraMais'];
			this.tratamentoHoraMenos = jsonObj['tratamentoHoraMenos'];
		}
	}
}