import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PontoAbonoModel } from '../entities-export';

@Entity({ name: 'ponto_abono_utilizacao' })
export class PontoAbonoUtilizacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_utilizacao' }) 
	dataUtilizacao: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PontoAbonoModel, pontoAbonoModel => pontoAbonoModel.pontoAbonoUtilizacaoModelList)
	@JoinColumn({ name: 'id_ponto_abono' })
	pontoAbonoModel: PontoAbonoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataUtilizacao = jsonObj['dataUtilizacao'];
			this.observacao = jsonObj['observacao'];
		}
	}
}