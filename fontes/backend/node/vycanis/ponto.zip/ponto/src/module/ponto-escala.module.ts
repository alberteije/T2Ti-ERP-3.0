import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoEscalaController } from '../controller/ponto-escala.controller';
import { PontoEscalaService } from '../service/ponto-escala.service';
import { PontoEscalaModel } from '../model/ponto-escala.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoEscalaModel])],
    controllers: [PontoEscalaController],
    providers: [PontoEscalaService],
})
export class PontoEscalaModule { }
