import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PontoBancoHorasModel } from '../entities-export';

@Entity({ name: 'ponto_banco_horas_utilizacao' })
export class PontoBancoHorasUtilizacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_utilizacao' }) 
	dataUtilizacao: Date; 

	@Column({ name: 'quantidade_utilizada' }) 
	quantidadeUtilizada: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => PontoBancoHorasModel, pontoBancoHorasModel => pontoBancoHorasModel.pontoBancoHorasUtilizacaoModelList)
	@JoinColumn({ name: 'id_ponto_banco_horas' })
	pontoBancoHorasModel: PontoBancoHorasModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataUtilizacao = jsonObj['dataUtilizacao'];
			this.quantidadeUtilizada = jsonObj['quantidadeUtilizada'];
			this.observacao = jsonObj['observacao'];
		}
	}
}