import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PontoAbonoUtilizacaoModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'ponto_abono' })
export class PontoAbonoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade' }) 
	quantidade: number; 

	@Column({ name: 'utilizado' }) 
	utilizado: number; 

	@Column({ name: 'saldo' }) 
	saldo: number; 

	@Column({ name: 'data_cadastro' }) 
	dataCadastro: Date; 

	@Column({ name: 'inicio_utilizacao' }) 
	inicioUtilizacao: Date; 

	@Column({ name: 'data_validade' }) 
	dataValidade: Date; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => PontoAbonoUtilizacaoModel, pontoAbonoUtilizacaoModel => pontoAbonoUtilizacaoModel.pontoAbonoModel, { cascade: true })
	pontoAbonoUtilizacaoModelList: PontoAbonoUtilizacaoModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			this.utilizado = jsonObj['utilizado'];
			this.saldo = jsonObj['saldo'];
			this.dataCadastro = jsonObj['dataCadastro'];
			this.inicioUtilizacao = jsonObj['inicioUtilizacao'];
			this.dataValidade = jsonObj['dataValidade'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.pontoAbonoUtilizacaoModelList = [];
			let pontoAbonoUtilizacaoModelJsonList = jsonObj['pontoAbonoUtilizacaoModelList'];
			if (pontoAbonoUtilizacaoModelJsonList != null) {
				for (let i = 0; i < pontoAbonoUtilizacaoModelJsonList.length; i++) {
					let obj = new PontoAbonoUtilizacaoModel(pontoAbonoUtilizacaoModelJsonList[i]);
					this.pontoAbonoUtilizacaoModelList.push(obj);
				}
			}

		}
	}
}