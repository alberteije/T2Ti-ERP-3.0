import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PontoBancoHorasUtilizacaoModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'ponto_banco_horas' })
export class PontoBancoHorasModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_trabalho' }) 
	dataTrabalho: Date; 

	@Column({ name: 'quantidade' }) 
	quantidade: string; 

	@Column({ name: 'situacao' }) 
	situacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => PontoBancoHorasUtilizacaoModel, pontoBancoHorasUtilizacaoModel => pontoBancoHorasUtilizacaoModel.pontoBancoHorasModel, { cascade: true })
	pontoBancoHorasUtilizacaoModelList: PontoBancoHorasUtilizacaoModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataTrabalho = jsonObj['dataTrabalho'];
			this.quantidade = jsonObj['quantidade'];
			this.situacao = jsonObj['situacao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.pontoBancoHorasUtilizacaoModelList = [];
			let pontoBancoHorasUtilizacaoModelJsonList = jsonObj['pontoBancoHorasUtilizacaoModelList'];
			if (pontoBancoHorasUtilizacaoModelJsonList != null) {
				for (let i = 0; i < pontoBancoHorasUtilizacaoModelJsonList.length; i++) {
					let obj = new PontoBancoHorasUtilizacaoModel(pontoBancoHorasUtilizacaoModelJsonList[i]);
					this.pontoBancoHorasUtilizacaoModelList.push(obj);
				}
			}

		}
	}
}