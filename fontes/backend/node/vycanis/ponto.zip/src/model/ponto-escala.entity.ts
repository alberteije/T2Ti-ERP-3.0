import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { PontoTurmaModel } from '../entities-export';

@Entity({ name: 'ponto_escala' })
export class PontoEscalaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'desconto_hora_dia' }) 
	descontoHoraDia: string; 

	@Column({ name: 'desconto_dsr' }) 
	descontoDsr: string; 

	@Column({ name: 'codigo_horario_domingo' }) 
	codigoHorarioDomingo: string; 

	@Column({ name: 'codigo_horario_segunda' }) 
	codigoHorarioSegunda: string; 

	@Column({ name: 'codigo_horario_terca' }) 
	codigoHorarioTerca: string; 

	@Column({ name: 'codigo_horario_quarta' }) 
	codigoHorarioQuarta: string; 

	@Column({ name: 'codigo_horario_quinta' }) 
	codigoHorarioQuinta: string; 

	@Column({ name: 'codigo_horario_sexta' }) 
	codigoHorarioSexta: string; 

	@Column({ name: 'codigo_horario_sabado' }) 
	codigoHorarioSabado: string; 


	/**
	* Relations
	*/
	@OneToMany(() => PontoTurmaModel, pontoTurmaModel => pontoTurmaModel.pontoEscalaModel, { cascade: true })
	pontoTurmaModelList: PontoTurmaModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.descontoHoraDia = jsonObj['descontoHoraDia'];
			this.descontoDsr = jsonObj['descontoDsr'];
			this.codigoHorarioDomingo = jsonObj['codigoHorarioDomingo'];
			this.codigoHorarioSegunda = jsonObj['codigoHorarioSegunda'];
			this.codigoHorarioTerca = jsonObj['codigoHorarioTerca'];
			this.codigoHorarioQuarta = jsonObj['codigoHorarioQuarta'];
			this.codigoHorarioQuinta = jsonObj['codigoHorarioQuinta'];
			this.codigoHorarioSexta = jsonObj['codigoHorarioSexta'];
			this.codigoHorarioSabado = jsonObj['codigoHorarioSabado'];
			this.pontoTurmaModelList = [];
			let pontoTurmaModelJsonList = jsonObj['pontoTurmaModelList'];
			if (pontoTurmaModelJsonList != null) {
				for (let i = 0; i < pontoTurmaModelJsonList.length; i++) {
					let obj = new PontoTurmaModel(pontoTurmaModelJsonList[i]);
					this.pontoTurmaModelList.push(obj);
				}
			}

		}
	}
}