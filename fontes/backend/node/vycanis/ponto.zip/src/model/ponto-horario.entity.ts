import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'ponto_horario' })
export class PontoHorarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'tipo_trabalho' }) 
	tipoTrabalho: string; 

	@Column({ name: 'carga_horaria' }) 
	cargaHoraria: string; 

	@Column({ name: 'entrada01' }) 
	entrada01: string; 

	@Column({ name: 'saida01' }) 
	saida01: string; 

	@Column({ name: 'entrada02' }) 
	entrada02: string; 

	@Column({ name: 'saida02' }) 
	saida02: string; 

	@Column({ name: 'entrada03' }) 
	entrada03: string; 

	@Column({ name: 'saida03' }) 
	saida03: string; 

	@Column({ name: 'entrada04' }) 
	entrada04: string; 

	@Column({ name: 'saida04' }) 
	saida04: string; 

	@Column({ name: 'entrada05' }) 
	entrada05: string; 

	@Column({ name: 'saida05' }) 
	saida05: string; 

	@Column({ name: 'hora_inicio_jornada' }) 
	horaInicioJornada: string; 

	@Column({ name: 'hora_fim_jornada' }) 
	horaFimJornada: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tipo = jsonObj['tipo'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
			this.tipoTrabalho = jsonObj['tipoTrabalho'];
			this.cargaHoraria = jsonObj['cargaHoraria'];
			this.entrada01 = jsonObj['entrada01'];
			this.saida01 = jsonObj['saida01'];
			this.entrada02 = jsonObj['entrada02'];
			this.saida02 = jsonObj['saida02'];
			this.entrada03 = jsonObj['entrada03'];
			this.saida03 = jsonObj['saida03'];
			this.entrada04 = jsonObj['entrada04'];
			this.saida04 = jsonObj['saida04'];
			this.entrada05 = jsonObj['entrada05'];
			this.saida05 = jsonObj['saida05'];
			this.horaInicioJornada = jsonObj['horaInicioJornada'];
			this.horaFimJornada = jsonObj['horaFimJornada'];
		}
	}
}