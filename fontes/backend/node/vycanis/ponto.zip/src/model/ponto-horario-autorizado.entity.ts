import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'ponto_horario_autorizado' })
export class PontoHorarioAutorizadoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_horario' }) 
	dataHorario: Date; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'carga_horaria' }) 
	cargaHoraria: string; 

	@Column({ name: 'entrada01' }) 
	entrada01: string; 

	@Column({ name: 'saida01' }) 
	saida01: string; 

	@Column({ name: 'entrada02' }) 
	entrada02: string; 

	@Column({ name: 'saida02' }) 
	saida02: string; 

	@Column({ name: 'entrada03' }) 
	entrada03: string; 

	@Column({ name: 'saida03' }) 
	saida03: string; 

	@Column({ name: 'entrada04' }) 
	entrada04: string; 

	@Column({ name: 'saida04' }) 
	saida04: string; 

	@Column({ name: 'entrada05' }) 
	entrada05: string; 

	@Column({ name: 'saida05' }) 
	saida05: string; 

	@Column({ name: 'hora_fechamento_dia' }) 
	horaFechamentoDia: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataHorario = jsonObj['dataHorario'];
			this.tipo = jsonObj['tipo'];
			this.cargaHoraria = jsonObj['cargaHoraria'];
			this.entrada01 = jsonObj['entrada01'];
			this.saida01 = jsonObj['saida01'];
			this.entrada02 = jsonObj['entrada02'];
			this.saida02 = jsonObj['saida02'];
			this.entrada03 = jsonObj['entrada03'];
			this.saida03 = jsonObj['saida03'];
			this.entrada04 = jsonObj['entrada04'];
			this.saida04 = jsonObj['saida04'];
			this.entrada05 = jsonObj['entrada05'];
			this.saida05 = jsonObj['saida05'];
			this.horaFechamentoDia = jsonObj['horaFechamentoDia'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}