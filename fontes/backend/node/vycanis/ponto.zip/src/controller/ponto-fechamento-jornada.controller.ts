import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PontoFechamentoJornadaService } from '../service/ponto-fechamento-jornada.service';
import { PontoFechamentoJornadaModel } from '../model/ponto-fechamento-jornada.entity';

@Crud({
  model: {
    type: PontoFechamentoJornadaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ponto-fechamento-jornada')
export class PontoFechamentoJornadaController implements CrudController<PontoFechamentoJornadaModel> {
  constructor(public service: PontoFechamentoJornadaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoFechamentoJornadaModel = new PontoFechamentoJornadaModel(jsonObj);
		const result = await this.service.save(pontoFechamentoJornadaModel);
		return result;
	}  


}


















