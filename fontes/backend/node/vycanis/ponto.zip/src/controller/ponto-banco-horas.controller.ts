import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PontoBancoHorasService } from '../service/ponto-banco-horas.service';
import { PontoBancoHorasModel } from '../model/ponto-banco-horas.entity';

@Crud({
  model: {
    type: PontoBancoHorasModel,
  },
  query: {
    join: {
			pontoBancoHorasUtilizacaoModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('ponto-banco-horas')
export class PontoBancoHorasController implements CrudController<PontoBancoHorasModel> {
  constructor(public service: PontoBancoHorasService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoBancoHoras = new PontoBancoHorasModel(jsonObj);
		const result = await this.service.save(pontoBancoHoras, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoBancoHoras = new PontoBancoHorasModel(jsonObj);
		const result = await this.service.save(pontoBancoHoras, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}