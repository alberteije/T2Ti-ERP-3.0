import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PontoParametroService } from '../service/ponto-parametro.service';
import { PontoParametroModel } from '../model/ponto-parametro.entity';

@Crud({
  model: {
    type: PontoParametroModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ponto-parametro')
export class PontoParametroController implements CrudController<PontoParametroModel> {
  constructor(public service: PontoParametroService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoParametroModel = new PontoParametroModel(jsonObj);
		const result = await this.service.save(pontoParametroModel);
		return result;
	}  


}


















