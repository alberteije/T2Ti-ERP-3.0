import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { PontoEscalaService } from '../service/ponto-escala.service';
import { PontoEscalaModel } from '../model/ponto-escala.entity';

@Crud({
  model: {
    type: PontoEscalaModel,
  },
  query: {
    join: {
			pontoTurmaModelList: { eager: true },
    },
  },
})
@Controller('ponto-escala')
export class PontoEscalaController implements CrudController<PontoEscalaModel> {
  constructor(public service: PontoEscalaService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoEscala = new PontoEscalaModel(jsonObj);
		const result = await this.service.save(pontoEscala, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoEscala = new PontoEscalaModel(jsonObj);
		const result = await this.service.save(pontoEscala, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}