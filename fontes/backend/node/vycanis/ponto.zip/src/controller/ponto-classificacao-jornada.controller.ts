import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PontoClassificacaoJornadaService } from '../service/ponto-classificacao-jornada.service';
import { PontoClassificacaoJornadaModel } from '../model/ponto-classificacao-jornada.entity';

@Crud({
  model: {
    type: PontoClassificacaoJornadaModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ponto-classificacao-jornada')
export class PontoClassificacaoJornadaController implements CrudController<PontoClassificacaoJornadaModel> {
  constructor(public service: PontoClassificacaoJornadaService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoClassificacaoJornadaModel = new PontoClassificacaoJornadaModel(jsonObj);
		const result = await this.service.save(pontoClassificacaoJornadaModel);
		return result;
	}  


}


















