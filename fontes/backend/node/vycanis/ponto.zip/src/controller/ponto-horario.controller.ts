import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PontoHorarioService } from '../service/ponto-horario.service';
import { PontoHorarioModel } from '../model/ponto-horario.entity';

@Crud({
  model: {
    type: PontoHorarioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ponto-horario')
export class PontoHorarioController implements CrudController<PontoHorarioModel> {
  constructor(public service: PontoHorarioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoHorarioModel = new PontoHorarioModel(jsonObj);
		const result = await this.service.save(pontoHorarioModel);
		return result;
	}  


}


















