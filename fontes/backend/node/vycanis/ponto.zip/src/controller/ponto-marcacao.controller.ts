import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { PontoMarcacaoService } from '../service/ponto-marcacao.service';
import { PontoMarcacaoModel } from '../model/ponto-marcacao.entity';

@Crud({
  model: {
    type: PontoMarcacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ponto-marcacao')
export class PontoMarcacaoController implements CrudController<PontoMarcacaoModel> {
  constructor(public service: PontoMarcacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const pontoMarcacaoModel = new PontoMarcacaoModel(jsonObj);
		const result = await this.service.save(pontoMarcacaoModel);
		return result;
	}  


}


















