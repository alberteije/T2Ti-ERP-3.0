import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PontoClassificacaoJornadaModel } from '../entities-export';

@Injectable()
export class PontoClassificacaoJornadaService extends TypeOrmCrudService<PontoClassificacaoJornadaModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PontoClassificacaoJornadaModel)
    private readonly repository: Repository<PontoClassificacaoJornadaModel>
  ) {
    super(repository);
  }

	async save(pontoClassificacaoJornadaModel: PontoClassificacaoJornadaModel): Promise<PontoClassificacaoJornadaModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(pontoClassificacaoJornadaModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
