import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PontoHorarioModel } from '../entities-export';

@Injectable()
export class PontoHorarioService extends TypeOrmCrudService<PontoHorarioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PontoHorarioModel)
    private readonly repository: Repository<PontoHorarioModel>
  ) {
    super(repository);
  }

	async save(pontoHorarioModel: PontoHorarioModel): Promise<PontoHorarioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(pontoHorarioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
