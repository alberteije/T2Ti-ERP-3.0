import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PontoMarcacaoModel } from '../entities-export';

@Injectable()
export class PontoMarcacaoService extends TypeOrmCrudService<PontoMarcacaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PontoMarcacaoModel)
    private readonly repository: Repository<PontoMarcacaoModel>
  ) {
    super(repository);
  }

	async save(pontoMarcacaoModel: PontoMarcacaoModel): Promise<PontoMarcacaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(pontoMarcacaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
