import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { PontoHorarioAutorizadoModel } from '../entities-export';

@Injectable()
export class PontoHorarioAutorizadoService extends TypeOrmCrudService<PontoHorarioAutorizadoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(PontoHorarioAutorizadoModel)
    private readonly repository: Repository<PontoHorarioAutorizadoModel>
  ) {
    super(repository);
  }

	async save(pontoHorarioAutorizadoModel: PontoHorarioAutorizadoModel): Promise<PontoHorarioAutorizadoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(pontoHorarioAutorizadoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
