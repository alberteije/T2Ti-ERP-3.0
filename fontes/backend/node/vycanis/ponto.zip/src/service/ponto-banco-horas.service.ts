import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { PontoBancoHorasModel } from '../entities-export';

@Injectable()
export class PontoBancoHorasService extends TypeOrmCrudService<PontoBancoHorasModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(PontoBancoHorasModel) 
    private readonly repository: Repository<PontoBancoHorasModel>,
  ) {
    super(repository);
  }

	async save(pontoBancoHorasModel: PontoBancoHorasModel, operation: string): Promise<PontoBancoHorasModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, pontoBancoHorasModel.id);
      }

      const resultObj = await queryRunner.manager.save(pontoBancoHorasModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(PontoBancoHorasModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from ponto_banco_horas_utilizacao where id_ponto_banco_horas=' + id); 

	}
	
}