import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoParametroController } from '../controller/ponto-parametro.controller';
import { PontoParametroService } from '../service/ponto-parametro.service';
import { PontoParametroModel } from '../model/ponto-parametro.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoParametroModel])],
    controllers: [PontoParametroController],
    providers: [PontoParametroService],
})
export class PontoParametroModule { }
