import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoClassificacaoJornadaController } from '../controller/ponto-classificacao-jornada.controller';
import { PontoClassificacaoJornadaService } from '../service/ponto-classificacao-jornada.service';
import { PontoClassificacaoJornadaModel } from '../model/ponto-classificacao-jornada.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoClassificacaoJornadaModel])],
    controllers: [PontoClassificacaoJornadaController],
    providers: [PontoClassificacaoJornadaService],
})
export class PontoClassificacaoJornadaModule { }
