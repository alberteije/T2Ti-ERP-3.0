import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoHorarioController } from '../controller/ponto-horario.controller';
import { PontoHorarioService } from '../service/ponto-horario.service';
import { PontoHorarioModel } from '../model/ponto-horario.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoHorarioModel])],
    controllers: [PontoHorarioController],
    providers: [PontoHorarioService],
})
export class PontoHorarioModule { }
