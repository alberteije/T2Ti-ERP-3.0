import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoFechamentoJornadaController } from '../controller/ponto-fechamento-jornada.controller';
import { PontoFechamentoJornadaService } from '../service/ponto-fechamento-jornada.service';
import { PontoFechamentoJornadaModel } from '../model/ponto-fechamento-jornada.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoFechamentoJornadaModel])],
    controllers: [PontoFechamentoJornadaController],
    providers: [PontoFechamentoJornadaService],
})
export class PontoFechamentoJornadaModule { }
