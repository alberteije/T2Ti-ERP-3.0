import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoBancoHorasController } from '../controller/ponto-banco-horas.controller';
import { PontoBancoHorasService } from '../service/ponto-banco-horas.service';
import { PontoBancoHorasModel } from '../model/ponto-banco-horas.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoBancoHorasModel])],
    controllers: [PontoBancoHorasController],
    providers: [PontoBancoHorasService],
})
export class PontoBancoHorasModule { }
