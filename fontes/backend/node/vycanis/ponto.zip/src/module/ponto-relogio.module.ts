import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoRelogioController } from '../controller/ponto-relogio.controller';
import { PontoRelogioService } from '../service/ponto-relogio.service';
import { PontoRelogioModel } from '../model/ponto-relogio.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoRelogioModel])],
    controllers: [PontoRelogioController],
    providers: [PontoRelogioService],
})
export class PontoRelogioModule { }
