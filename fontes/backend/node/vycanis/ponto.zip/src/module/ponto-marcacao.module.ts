import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoMarcacaoController } from '../controller/ponto-marcacao.controller';
import { PontoMarcacaoService } from '../service/ponto-marcacao.service';
import { PontoMarcacaoModel } from '../model/ponto-marcacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoMarcacaoModel])],
    controllers: [PontoMarcacaoController],
    providers: [PontoMarcacaoService],
})
export class PontoMarcacaoModule { }
