import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoAbonoController } from '../controller/ponto-abono.controller';
import { PontoAbonoService } from '../service/ponto-abono.service';
import { PontoAbonoModel } from '../model/ponto-abono.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoAbonoModel])],
    controllers: [PontoAbonoController],
    providers: [PontoAbonoService],
})
export class PontoAbonoModule { }
