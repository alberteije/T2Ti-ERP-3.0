import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PontoHorarioAutorizadoController } from '../controller/ponto-horario-autorizado.controller';
import { PontoHorarioAutorizadoService } from '../service/ponto-horario-autorizado.service';
import { PontoHorarioAutorizadoModel } from '../model/ponto-horario-autorizado.entity';

@Module({
    imports: [TypeOrmModule.forFeature([PontoHorarioAutorizadoModel])],
    controllers: [PontoHorarioAutorizadoController],
    providers: [PontoHorarioAutorizadoService],
})
export class PontoHorarioAutorizadoModule { }
