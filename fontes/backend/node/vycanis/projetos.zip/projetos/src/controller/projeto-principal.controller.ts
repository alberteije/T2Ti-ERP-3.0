import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { ProjetoPrincipalService } from '../service/projeto-principal.service';
import { ProjetoPrincipalModel } from '../model/projeto-principal.entity';

@Crud({
  model: {
    type: ProjetoPrincipalModel,
  },
  query: {
    join: {
			projetoCronogramaModelList: { eager: true },
			projetoRiscoModelList: { eager: true },
			projetoCustoModelList: { eager: true },
			projetoStakeholdersModelList: { eager: true },
    },
  },
})
@Controller('projeto-principal')
export class ProjetoPrincipalController implements CrudController<ProjetoPrincipalModel> {
  constructor(public service: ProjetoPrincipalService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const projetoPrincipal = new ProjetoPrincipalModel(jsonObj);
		const result = await this.service.save(projetoPrincipal, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const projetoPrincipal = new ProjetoPrincipalModel(jsonObj);
		const result = await this.service.save(projetoPrincipal, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}