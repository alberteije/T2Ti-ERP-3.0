import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ViewPessoaUsuarioModel } from '../entities-export';

@Injectable()
export class ViewPessoaUsuarioService extends TypeOrmCrudService<ViewPessoaUsuarioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ViewPessoaUsuarioModel)
    private readonly repository: Repository<ViewPessoaUsuarioModel>
  ) {
    super(repository);
  }

	async save(viewPessoaUsuarioModel: ViewPessoaUsuarioModel): Promise<ViewPessoaUsuarioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(viewPessoaUsuarioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
