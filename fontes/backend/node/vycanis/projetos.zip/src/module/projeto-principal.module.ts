import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProjetoPrincipalController } from '../controller/projeto-principal.controller';
import { ProjetoPrincipalService } from '../service/projeto-principal.service';
import { ProjetoPrincipalModel } from '../model/projeto-principal.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ProjetoPrincipalModel])],
    controllers: [ProjetoPrincipalController],
    providers: [ProjetoPrincipalService],
})
export class ProjetoPrincipalModule { }
