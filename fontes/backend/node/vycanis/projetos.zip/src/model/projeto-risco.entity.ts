import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProjetoPrincipalModel } from '../entities-export';

@Entity({ name: 'projeto_risco' })
export class ProjetoRiscoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'probabilidade' }) 
	probabilidade: number; 

	@Column({ name: 'impacto' }) 
	impacto: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => ProjetoPrincipalModel, projetoPrincipalModel => projetoPrincipalModel.projetoRiscoModelList)
	@JoinColumn({ name: 'id_projeto_principal' })
	projetoPrincipalModel: ProjetoPrincipalModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.probabilidade = jsonObj['probabilidade'];
			this.impacto = jsonObj['impacto'];
			this.descricao = jsonObj['descricao'];
		}
	}
}