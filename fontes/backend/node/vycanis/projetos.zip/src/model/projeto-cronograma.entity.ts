import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProjetoPrincipalModel } from '../entities-export';

@Entity({ name: 'projeto_cronograma' })
export class ProjetoCronogramaModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'tarefa' }) 
	tarefa: string; 

	@Column({ name: 'data_tarefa' }) 
	dataTarefa: Date; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => ProjetoPrincipalModel, projetoPrincipalModel => projetoPrincipalModel.projetoCronogramaModelList)
	@JoinColumn({ name: 'id_projeto_principal' })
	projetoPrincipalModel: ProjetoPrincipalModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.tarefa = jsonObj['tarefa'];
			this.dataTarefa = jsonObj['dataTarefa'];
			this.descricao = jsonObj['descricao'];
		}
	}
}