import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProjetoPrincipalModel } from '../entities-export';
import { FinNaturezaFinanceiraModel } from '../entities-export';

@Entity({ name: 'projeto_custo' })
export class ProjetoCustoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'valor_mensal', type: 'decimal', precision: 18, scale: 6 }) 
	valorMensal: number; 

	@Column({ name: 'valor_total', type: 'decimal', precision: 18, scale: 6 }) 
	valorTotal: number; 

	@Column({ name: 'justificativa' }) 
	justificativa: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => ProjetoPrincipalModel, projetoPrincipalModel => projetoPrincipalModel.projetoCustoModelList)
	@JoinColumn({ name: 'id_projeto_principal' })
	projetoPrincipalModel: ProjetoPrincipalModel;

	@OneToOne(() => FinNaturezaFinanceiraModel)
	@JoinColumn({ name: 'id_fin_natureza_financeira' })
	finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.valorMensal = jsonObj['valorMensal'];
			this.valorTotal = jsonObj['valorTotal'];
			this.justificativa = jsonObj['justificativa'];
			if (jsonObj['finNaturezaFinanceiraModel'] != null) {
				this.finNaturezaFinanceiraModel = new FinNaturezaFinanceiraModel(jsonObj['finNaturezaFinanceiraModel']);
			}

		}
	}
}