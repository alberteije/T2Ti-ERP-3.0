import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProjetoCronogramaModel } from '../entities-export';
import { ProjetoRiscoModel } from '../entities-export';
import { ProjetoCustoModel } from '../entities-export';
import { ProjetoStakeholdersModel } from '../entities-export';

@Entity({ name: 'projeto_principal' })
export class ProjetoPrincipalModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_previsao_fim' }) 
	dataPrevisaoFim: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'valor_orcamento', type: 'decimal', precision: 18, scale: 6 }) 
	valorOrcamento: number; 

	@Column({ name: 'link_quadro_kanban' }) 
	linkQuadroKanban: string; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => ProjetoCronogramaModel, projetoCronogramaModel => projetoCronogramaModel.projetoPrincipalModel, { cascade: true })
	projetoCronogramaModelList: ProjetoCronogramaModel[];

	@OneToMany(() => ProjetoRiscoModel, projetoRiscoModel => projetoRiscoModel.projetoPrincipalModel, { cascade: true })
	projetoRiscoModelList: ProjetoRiscoModel[];

	@OneToMany(() => ProjetoCustoModel, projetoCustoModel => projetoCustoModel.projetoPrincipalModel, { cascade: true })
	projetoCustoModelList: ProjetoCustoModel[];

	@OneToMany(() => ProjetoStakeholdersModel, projetoStakeholdersModel => projetoStakeholdersModel.projetoPrincipalModel, { cascade: true })
	projetoStakeholdersModelList: ProjetoStakeholdersModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataPrevisaoFim = jsonObj['dataPrevisaoFim'];
			this.dataFim = jsonObj['dataFim'];
			this.valorOrcamento = jsonObj['valorOrcamento'];
			this.linkQuadroKanban = jsonObj['linkQuadroKanban'];
			this.observacao = jsonObj['observacao'];
			this.projetoCronogramaModelList = [];
			let projetoCronogramaModelJsonList = jsonObj['projetoCronogramaModelList'];
			if (projetoCronogramaModelJsonList != null) {
				for (let i = 0; i < projetoCronogramaModelJsonList.length; i++) {
					let obj = new ProjetoCronogramaModel(projetoCronogramaModelJsonList[i]);
					this.projetoCronogramaModelList.push(obj);
				}
			}

			this.projetoRiscoModelList = [];
			let projetoRiscoModelJsonList = jsonObj['projetoRiscoModelList'];
			if (projetoRiscoModelJsonList != null) {
				for (let i = 0; i < projetoRiscoModelJsonList.length; i++) {
					let obj = new ProjetoRiscoModel(projetoRiscoModelJsonList[i]);
					this.projetoRiscoModelList.push(obj);
				}
			}

			this.projetoCustoModelList = [];
			let projetoCustoModelJsonList = jsonObj['projetoCustoModelList'];
			if (projetoCustoModelJsonList != null) {
				for (let i = 0; i < projetoCustoModelJsonList.length; i++) {
					let obj = new ProjetoCustoModel(projetoCustoModelJsonList[i]);
					this.projetoCustoModelList.push(obj);
				}
			}

			this.projetoStakeholdersModelList = [];
			let projetoStakeholdersModelJsonList = jsonObj['projetoStakeholdersModelList'];
			if (projetoStakeholdersModelJsonList != null) {
				for (let i = 0; i < projetoStakeholdersModelJsonList.length; i++) {
					let obj = new ProjetoStakeholdersModel(projetoStakeholdersModelJsonList[i]);
					this.projetoStakeholdersModelList.push(obj);
				}
			}

		}
	}
}