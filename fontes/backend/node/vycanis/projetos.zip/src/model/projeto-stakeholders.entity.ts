import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ProjetoPrincipalModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'projeto_stakeholders' })
export class ProjetoStakeholdersModel { 

	@PrimaryGeneratedColumn() 
	id: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => ProjetoPrincipalModel, projetoPrincipalModel => projetoPrincipalModel.projetoStakeholdersModelList)
	@JoinColumn({ name: 'id_projeto_principal' })
	projetoPrincipalModel: ProjetoPrincipalModel;

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}