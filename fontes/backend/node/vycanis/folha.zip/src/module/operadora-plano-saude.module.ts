import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OperadoraPlanoSaudeController } from '../controller/operadora-plano-saude.controller';
import { OperadoraPlanoSaudeService } from '../service/operadora-plano-saude.service';
import { OperadoraPlanoSaudeModel } from '../model/operadora-plano-saude.entity';

@Module({
    imports: [TypeOrmModule.forFeature([OperadoraPlanoSaudeModel])],
    controllers: [OperadoraPlanoSaudeController],
    providers: [OperadoraPlanoSaudeService],
})
export class OperadoraPlanoSaudeModule { }
