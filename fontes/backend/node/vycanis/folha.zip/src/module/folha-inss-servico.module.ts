import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaInssServicoController } from '../controller/folha-inss-servico.controller';
import { FolhaInssServicoService } from '../service/folha-inss-servico.service';
import { FolhaInssServicoModel } from '../model/folha-inss-servico.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaInssServicoModel])],
    controllers: [FolhaInssServicoController],
    providers: [FolhaInssServicoService],
})
export class FolhaInssServicoModule { }
