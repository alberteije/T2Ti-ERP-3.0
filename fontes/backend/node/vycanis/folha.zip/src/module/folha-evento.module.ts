import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaEventoController } from '../controller/folha-evento.controller';
import { FolhaEventoService } from '../service/folha-evento.service';
import { FolhaEventoModel } from '../model/folha-evento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaEventoModel])],
    controllers: [FolhaEventoController],
    providers: [FolhaEventoService],
})
export class FolhaEventoModule { }
