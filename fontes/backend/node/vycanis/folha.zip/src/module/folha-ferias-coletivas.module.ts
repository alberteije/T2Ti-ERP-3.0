import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaFeriasColetivasController } from '../controller/folha-ferias-coletivas.controller';
import { FolhaFeriasColetivasService } from '../service/folha-ferias-coletivas.service';
import { FolhaFeriasColetivasModel } from '../model/folha-ferias-coletivas.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaFeriasColetivasModel])],
    controllers: [FolhaFeriasColetivasController],
    providers: [FolhaFeriasColetivasService],
})
export class FolhaFeriasColetivasModule { }
