import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaLancamentoCabecalhoController } from '../controller/folha-lancamento-cabecalho.controller';
import { FolhaLancamentoCabecalhoService } from '../service/folha-lancamento-cabecalho.service';
import { FolhaLancamentoCabecalhoModel } from '../model/folha-lancamento-cabecalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaLancamentoCabecalhoModel])],
    controllers: [FolhaLancamentoCabecalhoController],
    providers: [FolhaLancamentoCabecalhoService],
})
export class FolhaLancamentoCabecalhoModule { }
