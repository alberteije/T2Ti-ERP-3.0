import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaRescisaoController } from '../controller/folha-rescisao.controller';
import { FolhaRescisaoService } from '../service/folha-rescisao.service';
import { FolhaRescisaoModel } from '../model/folha-rescisao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaRescisaoModel])],
    controllers: [FolhaRescisaoController],
    providers: [FolhaRescisaoService],
})
export class FolhaRescisaoModule { }
