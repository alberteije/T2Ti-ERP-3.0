import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EmpresaTransporteController } from '../controller/empresa-transporte.controller';
import { EmpresaTransporteService } from '../service/empresa-transporte.service';
import { EmpresaTransporteModel } from '../model/empresa-transporte.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EmpresaTransporteModel])],
    controllers: [EmpresaTransporteController],
    providers: [EmpresaTransporteService],
})
export class EmpresaTransporteModule { }
