import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaPlanoSaudeController } from '../controller/folha-plano-saude.controller';
import { FolhaPlanoSaudeService } from '../service/folha-plano-saude.service';
import { FolhaPlanoSaudeModel } from '../model/folha-plano-saude.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaPlanoSaudeModel])],
    controllers: [FolhaPlanoSaudeController],
    providers: [FolhaPlanoSaudeService],
})
export class FolhaPlanoSaudeModule { }
