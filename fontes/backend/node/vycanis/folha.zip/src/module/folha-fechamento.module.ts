import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaFechamentoController } from '../controller/folha-fechamento.controller';
import { FolhaFechamentoService } from '../service/folha-fechamento.service';
import { FolhaFechamentoModel } from '../model/folha-fechamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaFechamentoModel])],
    controllers: [FolhaFechamentoController],
    providers: [FolhaFechamentoService],
})
export class FolhaFechamentoModule { }
