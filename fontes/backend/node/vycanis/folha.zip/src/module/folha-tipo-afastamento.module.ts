import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaTipoAfastamentoController } from '../controller/folha-tipo-afastamento.controller';
import { FolhaTipoAfastamentoService } from '../service/folha-tipo-afastamento.service';
import { FolhaTipoAfastamentoModel } from '../model/folha-tipo-afastamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaTipoAfastamentoModel])],
    controllers: [FolhaTipoAfastamentoController],
    providers: [FolhaTipoAfastamentoService],
})
export class FolhaTipoAfastamentoModule { }
