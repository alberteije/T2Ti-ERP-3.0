import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { EmpresaTransporteModule } from './modules-export';
import { FolhaLancamentoCabecalhoModule } from './modules-export';
import { FolhaInssModule } from './modules-export';
import { FolhaPppModule } from './modules-export';
import { OperadoraPlanoSaudeModule } from './modules-export';
import { FolhaLancamentoComissaoModule } from './modules-export';
import { FolhaParametroModule } from './modules-export';
import { GuiasAcumuladasModule } from './modules-export';
import { FolhaFechamentoModule } from './modules-export';
import { FeriasPeriodoAquisitivoModule } from './modules-export';
import { FolhaTipoAfastamentoModule } from './modules-export';
import { FolhaAfastamentoModule } from './modules-export';
import { FolhaPlanoSaudeModule } from './modules-export';
import { FolhaEventoModule } from './modules-export';
import { FolhaRescisaoModule } from './modules-export';
import { FolhaFeriasColetivasModule } from './modules-export';
import { FolhaValeTransporteModule } from './modules-export';
import { FolhaInssServicoModule } from './modules-export';
import { FolhaHistoricoSalarialModule } from './modules-export';
import { FeriadosModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaColaboradorModule } from './modules-export';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AppInterceptor } from './app.interceptor';
import { LoginModule } from './login/login.module';
import { HandleBodyMiddleware } from './handle-body-middleware';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			EmpresaTransporteModule,
			FolhaLancamentoCabecalhoModule,
			FolhaInssModule,
			FolhaPppModule,
			OperadoraPlanoSaudeModule,
			FolhaLancamentoComissaoModule,
			FolhaParametroModule,
			GuiasAcumuladasModule,
			FolhaFechamentoModule,
			FeriasPeriodoAquisitivoModule,
			FolhaTipoAfastamentoModule,
			FolhaAfastamentoModule,
			FolhaPlanoSaudeModule,
			FolhaEventoModule,
			FolhaRescisaoModule,
			FolhaFeriasColetivasModule,
			FolhaValeTransporteModule,
			FolhaInssServicoModule,
			FolhaHistoricoSalarialModule,
			FeriadosModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaColaboradorModule,
      LoginModule,
    ],
    providers: [
      {
        provide: APP_INTERCEPTOR,
        useClass: AppInterceptor,
      },
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}

  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(HandleBodyMiddleware)
      .forRoutes('*');  // Aplicar middleware para todas as rotas
  }

}