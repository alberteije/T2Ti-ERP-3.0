import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { EmpresaTransporteItinerarioModel } from '../entities-export';

@Entity({ name: 'folha_vale_transporte' })
export class FolhaValeTransporteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'quantidade' }) 
	quantidade: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => EmpresaTransporteItinerarioModel)
	@JoinColumn({ name: 'id_empresa_transp_itin' })
	empresaTransporteItinerarioModel: EmpresaTransporteItinerarioModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.quantidade = jsonObj['quantidade'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['empresaTransporteItinerarioModel'] != null) {
				this.empresaTransporteItinerarioModel = new EmpresaTransporteItinerarioModel(jsonObj['empresaTransporteItinerarioModel']);
			}

		}
	}
}