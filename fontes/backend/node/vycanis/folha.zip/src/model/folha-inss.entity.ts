import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaInssRetencaoModel } from '../entities-export';

@Entity({ name: 'folha_inss' })
export class FolhaInssModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FolhaInssRetencaoModel, folhaInssRetencaoModel => folhaInssRetencaoModel.folhaInssModel, { cascade: true })
	folhaInssRetencaoModelList: FolhaInssRetencaoModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.folhaInssRetencaoModelList = [];
			let folhaInssRetencaoModelJsonList = jsonObj['folhaInssRetencaoModelList'];
			if (folhaInssRetencaoModelJsonList != null) {
				for (let i = 0; i < folhaInssRetencaoModelJsonList.length; i++) {
					let obj = new FolhaInssRetencaoModel(folhaInssRetencaoModelJsonList[i]);
					this.folhaInssRetencaoModelList.push(obj);
				}
			}

		}
	}
}