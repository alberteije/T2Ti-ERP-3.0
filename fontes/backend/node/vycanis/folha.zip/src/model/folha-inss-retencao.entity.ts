import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaInssModel } from '../entities-export';
import { FolhaInssServicoModel } from '../entities-export';

@Entity({ name: 'folha_inss_retencao' })
export class FolhaInssRetencaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'valor_mensal', type: 'decimal', precision: 18, scale: 6 }) 
	valorMensal: number; 

	@Column({ name: 'valor_13', type: 'decimal', precision: 18, scale: 6 }) 
	valor13: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => FolhaInssModel, folhaInssModel => folhaInssModel.folhaInssRetencaoModelList)
	@JoinColumn({ name: 'id_folha_inss' })
	folhaInssModel: FolhaInssModel;

	@OneToOne(() => FolhaInssServicoModel)
	@JoinColumn({ name: 'id_folha_inss_servico' })
	folhaInssServicoModel: FolhaInssServicoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.valorMensal = jsonObj['valorMensal'];
			this.valor13 = jsonObj['valor13'];
			if (jsonObj['folhaInssServicoModel'] != null) {
				this.folhaInssServicoModel = new FolhaInssServicoModel(jsonObj['folhaInssServicoModel']);
			}

		}
	}
}