import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaPppModel } from '../entities-export';

@Entity({ name: 'folha_ppp_exame_medico' })
export class FolhaPppExameMedicoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_ultimo' }) 
	dataUltimo: Date; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'exame' }) 
	exame: string; 

	@Column({ name: 'natureza' }) 
	natureza: string; 

	@Column({ name: 'indicacao_resultados' }) 
	indicacaoResultados: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FolhaPppModel, folhaPppModel => folhaPppModel.folhaPppExameMedicoModelList)
	@JoinColumn({ name: 'id_folha_ppp' })
	folhaPppModel: FolhaPppModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataUltimo = jsonObj['dataUltimo'];
			this.tipo = jsonObj['tipo'];
			this.exame = jsonObj['exame'];
			this.natureza = jsonObj['natureza'];
			this.indicacaoResultados = jsonObj['indicacaoResultados'];
		}
	}
}