import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaPppModel } from '../entities-export';

@Entity({ name: 'folha_ppp_atividade' })
export class FolhaPppAtividadeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'descricao' }) 
	descricao: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FolhaPppModel, folhaPppModel => folhaPppModel.folhaPppAtividadeModelList)
	@JoinColumn({ name: 'id_folha_ppp' })
	folhaPppModel: FolhaPppModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
			this.descricao = jsonObj['descricao'];
		}
	}
}