import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'operadora_plano_saude' })
export class OperadoraPlanoSaudeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'registro_ans' }) 
	registroAns: string; 

	@Column({ name: 'classificacao_contabil_conta' }) 
	classificacaoContabilConta: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.registroAns = jsonObj['registroAns'];
			this.classificacaoContabilConta = jsonObj['classificacaoContabilConta'];
		}
	}
}