import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'folha_evento' })
export class FolhaEventoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'base_calculo' }) 
	baseCalculo: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'unidade' }) 
	unidade: string; 

	@Column({ name: 'taxa', type: 'decimal', precision: 18, scale: 6 }) 
	taxa: number; 

	@Column({ name: 'rubrica_esocial' }) 
	rubricaEsocial: string; 

	@Column({ name: 'cod_incidencia_previdencia' }) 
	codIncidenciaPrevidencia: string; 

	@Column({ name: 'cod_incidencia_irrf' }) 
	codIncidenciaIrrf: string; 

	@Column({ name: 'cod_incidencia_fgts' }) 
	codIncidenciaFgts: string; 

	@Column({ name: 'cod_incidencia_sindicato' }) 
	codIncidenciaSindicato: string; 

	@Column({ name: 'repercute_dsr' }) 
	repercuteDsr: string; 

	@Column({ name: 'repercute_13' }) 
	repercute13: string; 

	@Column({ name: 'repercute_ferias' }) 
	repercuteFerias: string; 

	@Column({ name: 'repercute_aviso' }) 
	repercuteAviso: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.nome = jsonObj['nome'];
			this.descricao = jsonObj['descricao'];
			this.baseCalculo = jsonObj['baseCalculo'];
			this.tipo = jsonObj['tipo'];
			this.unidade = jsonObj['unidade'];
			this.taxa = jsonObj['taxa'];
			this.rubricaEsocial = jsonObj['rubricaEsocial'];
			this.codIncidenciaPrevidencia = jsonObj['codIncidenciaPrevidencia'];
			this.codIncidenciaIrrf = jsonObj['codIncidenciaIrrf'];
			this.codIncidenciaFgts = jsonObj['codIncidenciaFgts'];
			this.codIncidenciaSindicato = jsonObj['codIncidenciaSindicato'];
			this.repercuteDsr = jsonObj['repercuteDsr'];
			this.repercute13 = jsonObj['repercute13'];
			this.repercuteFerias = jsonObj['repercuteFerias'];
			this.repercuteAviso = jsonObj['repercuteAviso'];
		}
	}
}