import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'folha_rescisao' })
export class FolhaRescisaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_demissao' }) 
	dataDemissao: Date; 

	@Column({ name: 'data_pagamento' }) 
	dataPagamento: Date; 

	@Column({ name: 'motivo' }) 
	motivo: string; 

	@Column({ name: 'motivo_esocial' }) 
	motivoEsocial: string; 

	@Column({ name: 'data_aviso_previo' }) 
	dataAvisoPrevio: Date; 

	@Column({ name: 'dias_aviso_previo' }) 
	diasAvisoPrevio: number; 

	@Column({ name: 'comprovou_novo_emprego' }) 
	comprovouNovoEmprego: string; 

	@Column({ name: 'dispensou_empregado' }) 
	dispensouEmpregado: string; 

	@Column({ name: 'pensao_alimenticia', type: 'decimal', precision: 18, scale: 6 }) 
	pensaoAlimenticia: number; 

	@Column({ name: 'pensao_alimenticia_fgts', type: 'decimal', precision: 18, scale: 6 }) 
	pensaoAlimenticiaFgts: number; 

	@Column({ name: 'fgts_valor_rescisao', type: 'decimal', precision: 18, scale: 6 }) 
	fgtsValorRescisao: number; 

	@Column({ name: 'fgts_saldo_banco', type: 'decimal', precision: 18, scale: 6 }) 
	fgtsSaldoBanco: number; 

	@Column({ name: 'fgts_complemento_saldo', type: 'decimal', precision: 18, scale: 6 }) 
	fgtsComplementoSaldo: number; 

	@Column({ name: 'fgts_codigo_afastamento' }) 
	fgtsCodigoAfastamento: string; 

	@Column({ name: 'fgts_codigo_saque' }) 
	fgtsCodigoSaque: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataDemissao = jsonObj['dataDemissao'];
			this.dataPagamento = jsonObj['dataPagamento'];
			this.motivo = jsonObj['motivo'];
			this.motivoEsocial = jsonObj['motivoEsocial'];
			this.dataAvisoPrevio = jsonObj['dataAvisoPrevio'];
			this.diasAvisoPrevio = jsonObj['diasAvisoPrevio'];
			this.comprovouNovoEmprego = jsonObj['comprovouNovoEmprego'];
			this.dispensouEmpregado = jsonObj['dispensouEmpregado'];
			this.pensaoAlimenticia = jsonObj['pensaoAlimenticia'];
			this.pensaoAlimenticiaFgts = jsonObj['pensaoAlimenticiaFgts'];
			this.fgtsValorRescisao = jsonObj['fgtsValorRescisao'];
			this.fgtsSaldoBanco = jsonObj['fgtsSaldoBanco'];
			this.fgtsComplementoSaldo = jsonObj['fgtsComplementoSaldo'];
			this.fgtsCodigoAfastamento = jsonObj['fgtsCodigoAfastamento'];
			this.fgtsCodigoSaque = jsonObj['fgtsCodigoSaque'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}