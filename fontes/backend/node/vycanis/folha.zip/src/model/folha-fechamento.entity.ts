import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'folha_fechamento' })
export class FolhaFechamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'fechamento_atual' }) 
	fechamentoAtual: string; 

	@Column({ name: 'proximo_fechamento' }) 
	proximoFechamento: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.fechamentoAtual = jsonObj['fechamentoAtual'];
			this.proximoFechamento = jsonObj['proximoFechamento'];
		}
	}
}