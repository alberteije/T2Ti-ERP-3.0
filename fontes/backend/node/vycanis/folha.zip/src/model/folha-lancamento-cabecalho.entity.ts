import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaLancamentoDetalheModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'folha_lancamento_cabecalho' })
export class FolhaLancamentoCabecalhoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'tipo' }) 
	tipo: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FolhaLancamentoDetalheModel, folhaLancamentoDetalheModel => folhaLancamentoDetalheModel.folhaLancamentoCabecalhoModel, { cascade: true })
	folhaLancamentoDetalheModelList: FolhaLancamentoDetalheModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.tipo = jsonObj['tipo'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.folhaLancamentoDetalheModelList = [];
			let folhaLancamentoDetalheModelJsonList = jsonObj['folhaLancamentoDetalheModelList'];
			if (folhaLancamentoDetalheModelJsonList != null) {
				for (let i = 0; i < folhaLancamentoDetalheModelJsonList.length; i++) {
					let obj = new FolhaLancamentoDetalheModel(folhaLancamentoDetalheModelJsonList[i]);
					this.folhaLancamentoDetalheModelList.push(obj);
				}
			}

		}
	}
}