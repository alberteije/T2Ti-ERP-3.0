import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'folha_historico_salarial' })
export class FolhaHistoricoSalarialModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'salario_atual', type: 'decimal', precision: 18, scale: 6 }) 
	salarioAtual: number; 

	@Column({ name: 'percentual_aumento', type: 'decimal', precision: 18, scale: 6 }) 
	percentualAumento: number; 

	@Column({ name: 'salario_novo', type: 'decimal', precision: 18, scale: 6 }) 
	salarioNovo: number; 

	@Column({ name: 'valido_a_partir' }) 
	validoAPartir: string; 

	@Column({ name: 'motivo' }) 
	motivo: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.salarioAtual = jsonObj['salarioAtual'];
			this.percentualAumento = jsonObj['percentualAumento'];
			this.salarioNovo = jsonObj['salarioNovo'];
			this.validoAPartir = jsonObj['validoAPartir'];
			this.motivo = jsonObj['motivo'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}