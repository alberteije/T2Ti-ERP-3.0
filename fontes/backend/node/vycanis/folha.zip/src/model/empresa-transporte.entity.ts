import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EmpresaTransporteItinerarioModel } from '../entities-export';

@Entity({ name: 'empresa_transporte' })
export class EmpresaTransporteModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'classificacao_contabil_conta' }) 
	classificacaoContabilConta: string; 


	/**
	* Relations
	*/
	@OneToMany(() => EmpresaTransporteItinerarioModel, empresaTransporteItinerarioModel => empresaTransporteItinerarioModel.empresaTransporteModel, { cascade: true })
	empresaTransporteItinerarioModelList: EmpresaTransporteItinerarioModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.uf = jsonObj['uf'];
			this.classificacaoContabilConta = jsonObj['classificacaoContabilConta'];
			this.empresaTransporteItinerarioModelList = [];
			let empresaTransporteItinerarioModelJsonList = jsonObj['empresaTransporteItinerarioModelList'];
			if (empresaTransporteItinerarioModelJsonList != null) {
				for (let i = 0; i < empresaTransporteItinerarioModelJsonList.length; i++) {
					let obj = new EmpresaTransporteItinerarioModel(empresaTransporteItinerarioModelJsonList[i]);
					this.empresaTransporteItinerarioModelList.push(obj);
				}
			}

		}
	}
}