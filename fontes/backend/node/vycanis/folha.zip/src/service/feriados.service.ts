import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FeriadosModel } from '../entities-export';

@Injectable()
export class FeriadosService extends TypeOrmCrudService<FeriadosModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FeriadosModel)
    private readonly repository: Repository<FeriadosModel>
  ) {
    super(repository);
  }

	async save(feriadosModel: FeriadosModel): Promise<FeriadosModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(feriadosModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
