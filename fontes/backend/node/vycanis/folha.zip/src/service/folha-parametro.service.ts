import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaParametroModel } from '../entities-export';

@Injectable()
export class FolhaParametroService extends TypeOrmCrudService<FolhaParametroModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaParametroModel)
    private readonly repository: Repository<FolhaParametroModel>
  ) {
    super(repository);
  }

	async save(folhaParametroModel: FolhaParametroModel): Promise<FolhaParametroModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaParametroModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
