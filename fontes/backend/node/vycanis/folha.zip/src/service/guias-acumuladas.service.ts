import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { GuiasAcumuladasModel } from '../entities-export';

@Injectable()
export class GuiasAcumuladasService extends TypeOrmCrudService<GuiasAcumuladasModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(GuiasAcumuladasModel)
    private readonly repository: Repository<GuiasAcumuladasModel>
  ) {
    super(repository);
  }

	async save(guiasAcumuladasModel: GuiasAcumuladasModel): Promise<GuiasAcumuladasModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(guiasAcumuladasModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
