import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaRescisaoModel } from '../entities-export';

@Injectable()
export class FolhaRescisaoService extends TypeOrmCrudService<FolhaRescisaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaRescisaoModel)
    private readonly repository: Repository<FolhaRescisaoModel>
  ) {
    super(repository);
  }

	async save(folhaRescisaoModel: FolhaRescisaoModel): Promise<FolhaRescisaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaRescisaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
