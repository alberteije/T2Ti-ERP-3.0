import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { FolhaPppModel } from '../entities-export';

@Injectable()
export class FolhaPppService extends TypeOrmCrudService<FolhaPppModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(FolhaPppModel) 
    private readonly repository: Repository<FolhaPppModel>,
  ) {
    super(repository);
  }

	async save(folhaPppModel: FolhaPppModel, operation: string): Promise<FolhaPppModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, folhaPppModel.id);
      }

      const resultObj = await queryRunner.manager.save(folhaPppModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(FolhaPppModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from folha_ppp_cat where id_folha_ppp=' + id); 

		await queryRunner.query('delete from folha_ppp_atividade where id_folha_ppp=' + id); 

		await queryRunner.query('delete from folha_ppp_fator_risco where id_folha_ppp=' + id); 

		await queryRunner.query('delete from folha_ppp_exame_medico where id_folha_ppp=' + id); 

	}
	
}