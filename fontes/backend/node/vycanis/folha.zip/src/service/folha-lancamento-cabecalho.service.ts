import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { FolhaLancamentoCabecalhoModel } from '../entities-export';

@Injectable()
export class FolhaLancamentoCabecalhoService extends TypeOrmCrudService<FolhaLancamentoCabecalhoModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(FolhaLancamentoCabecalhoModel) 
    private readonly repository: Repository<FolhaLancamentoCabecalhoModel>,
  ) {
    super(repository);
  }

	async save(folhaLancamentoCabecalhoModel: FolhaLancamentoCabecalhoModel, operation: string): Promise<FolhaLancamentoCabecalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, folhaLancamentoCabecalhoModel.id);
      }

      const resultObj = await queryRunner.manager.save(folhaLancamentoCabecalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(FolhaLancamentoCabecalhoModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from folha_lancamento_detalhe where id_folha_lancamento_cabecalho=' + id); 

	}
	
}