import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaTipoAfastamentoModel } from '../entities-export';

@Injectable()
export class FolhaTipoAfastamentoService extends TypeOrmCrudService<FolhaTipoAfastamentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaTipoAfastamentoModel)
    private readonly repository: Repository<FolhaTipoAfastamentoModel>
  ) {
    super(repository);
  }

	async save(folhaTipoAfastamentoModel: FolhaTipoAfastamentoModel): Promise<FolhaTipoAfastamentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaTipoAfastamentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
