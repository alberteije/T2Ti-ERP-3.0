import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FeriadosService } from '../service/feriados.service';
import { FeriadosModel } from '../model/feriados.entity';

@Crud({
  model: {
    type: FeriadosModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('feriados')
export class FeriadosController implements CrudController<FeriadosModel> {
  constructor(public service: FeriadosService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const feriadosModel = new FeriadosModel(jsonObj);
		const result = await this.service.save(feriadosModel);
		return result;
	}  


}


















