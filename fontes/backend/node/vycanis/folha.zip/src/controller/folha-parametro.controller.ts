import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaParametroService } from '../service/folha-parametro.service';
import { FolhaParametroModel } from '../model/folha-parametro.entity';

@Crud({
  model: {
    type: FolhaParametroModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-parametro')
export class FolhaParametroController implements CrudController<FolhaParametroModel> {
  constructor(public service: FolhaParametroService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaParametroModel = new FolhaParametroModel(jsonObj);
		const result = await this.service.save(folhaParametroModel);
		return result;
	}  


}


















