import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FolhaInssService } from '../service/folha-inss.service';
import { FolhaInssModel } from '../model/folha-inss.entity';

@Crud({
  model: {
    type: FolhaInssModel,
  },
  query: {
    join: {
			folhaInssRetencaoModelList: { eager: true },
    },
  },
})
@Controller('folha-inss')
export class FolhaInssController implements CrudController<FolhaInssModel> {
  constructor(public service: FolhaInssService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaInss = new FolhaInssModel(jsonObj);
		const result = await this.service.save(folhaInss, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaInss = new FolhaInssModel(jsonObj);
		const result = await this.service.save(folhaInss, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}