import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FolhaLancamentoCabecalhoService } from '../service/folha-lancamento-cabecalho.service';
import { FolhaLancamentoCabecalhoModel } from '../model/folha-lancamento-cabecalho.entity';

@Crud({
  model: {
    type: FolhaLancamentoCabecalhoModel,
  },
  query: {
    join: {
			folhaLancamentoDetalheModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('folha-lancamento-cabecalho')
export class FolhaLancamentoCabecalhoController implements CrudController<FolhaLancamentoCabecalhoModel> {
  constructor(public service: FolhaLancamentoCabecalhoService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaLancamentoCabecalho = new FolhaLancamentoCabecalhoModel(jsonObj);
		const result = await this.service.save(folhaLancamentoCabecalho, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaLancamentoCabecalho = new FolhaLancamentoCabecalhoModel(jsonObj);
		const result = await this.service.save(folhaLancamentoCabecalho, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}