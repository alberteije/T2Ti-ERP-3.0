import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FeriasPeriodoAquisitivoService } from '../service/ferias-periodo-aquisitivo.service';
import { FeriasPeriodoAquisitivoModel } from '../model/ferias-periodo-aquisitivo.entity';

@Crud({
  model: {
    type: FeriasPeriodoAquisitivoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('ferias-periodo-aquisitivo')
export class FeriasPeriodoAquisitivoController implements CrudController<FeriasPeriodoAquisitivoModel> {
  constructor(public service: FeriasPeriodoAquisitivoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const feriasPeriodoAquisitivoModel = new FeriasPeriodoAquisitivoModel(jsonObj);
		const result = await this.service.save(feriasPeriodoAquisitivoModel);
		return result;
	}  


}


















