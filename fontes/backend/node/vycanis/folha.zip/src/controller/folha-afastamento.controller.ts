import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaAfastamentoService } from '../service/folha-afastamento.service';
import { FolhaAfastamentoModel } from '../model/folha-afastamento.entity';

@Crud({
  model: {
    type: FolhaAfastamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-afastamento')
export class FolhaAfastamentoController implements CrudController<FolhaAfastamentoModel> {
  constructor(public service: FolhaAfastamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaAfastamentoModel = new FolhaAfastamentoModel(jsonObj);
		const result = await this.service.save(folhaAfastamentoModel);
		return result;
	}  


}


















