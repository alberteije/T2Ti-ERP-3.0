import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaLancamentoComissaoService } from '../service/folha-lancamento-comissao.service';
import { FolhaLancamentoComissaoModel } from '../model/folha-lancamento-comissao.entity';

@Crud({
  model: {
    type: FolhaLancamentoComissaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-lancamento-comissao')
export class FolhaLancamentoComissaoController implements CrudController<FolhaLancamentoComissaoModel> {
  constructor(public service: FolhaLancamentoComissaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaLancamentoComissaoModel = new FolhaLancamentoComissaoModel(jsonObj);
		const result = await this.service.save(folhaLancamentoComissaoModel);
		return result;
	}  


}


















