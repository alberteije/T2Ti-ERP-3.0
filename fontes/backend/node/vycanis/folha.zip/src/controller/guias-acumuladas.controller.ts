import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { GuiasAcumuladasService } from '../service/guias-acumuladas.service';
import { GuiasAcumuladasModel } from '../model/guias-acumuladas.entity';

@Crud({
  model: {
    type: GuiasAcumuladasModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('guias-acumuladas')
export class GuiasAcumuladasController implements CrudController<GuiasAcumuladasModel> {
  constructor(public service: GuiasAcumuladasService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const guiasAcumuladasModel = new GuiasAcumuladasModel(jsonObj);
		const result = await this.service.save(guiasAcumuladasModel);
		return result;
	}  


}


















