import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaValeTransporteService } from '../service/folha-vale-transporte.service';
import { FolhaValeTransporteModel } from '../model/folha-vale-transporte.entity';

@Crud({
  model: {
    type: FolhaValeTransporteModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-vale-transporte')
export class FolhaValeTransporteController implements CrudController<FolhaValeTransporteModel> {
  constructor(public service: FolhaValeTransporteService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaValeTransporteModel = new FolhaValeTransporteModel(jsonObj);
		const result = await this.service.save(folhaValeTransporteModel);
		return result;
	}  


}


















