import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaEventoService } from '../service/folha-evento.service';
import { FolhaEventoModel } from '../model/folha-evento.entity';

@Crud({
  model: {
    type: FolhaEventoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-evento')
export class FolhaEventoController implements CrudController<FolhaEventoModel> {
  constructor(public service: FolhaEventoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaEventoModel = new FolhaEventoModel(jsonObj);
		const result = await this.service.save(folhaEventoModel);
		return result;
	}  


}


















