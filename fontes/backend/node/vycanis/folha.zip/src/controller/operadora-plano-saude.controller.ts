import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { OperadoraPlanoSaudeService } from '../service/operadora-plano-saude.service';
import { OperadoraPlanoSaudeModel } from '../model/operadora-plano-saude.entity';

@Crud({
  model: {
    type: OperadoraPlanoSaudeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('operadora-plano-saude')
export class OperadoraPlanoSaudeController implements CrudController<OperadoraPlanoSaudeModel> {
  constructor(public service: OperadoraPlanoSaudeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const operadoraPlanoSaudeModel = new OperadoraPlanoSaudeModel(jsonObj);
		const result = await this.service.save(operadoraPlanoSaudeModel);
		return result;
	}  


}


















