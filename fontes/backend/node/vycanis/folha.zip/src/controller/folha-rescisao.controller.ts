import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaRescisaoService } from '../service/folha-rescisao.service';
import { FolhaRescisaoModel } from '../model/folha-rescisao.entity';

@Crud({
  model: {
    type: FolhaRescisaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-rescisao')
export class FolhaRescisaoController implements CrudController<FolhaRescisaoModel> {
  constructor(public service: FolhaRescisaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaRescisaoModel = new FolhaRescisaoModel(jsonObj);
		const result = await this.service.save(folhaRescisaoModel);
		return result;
	}  


}


















