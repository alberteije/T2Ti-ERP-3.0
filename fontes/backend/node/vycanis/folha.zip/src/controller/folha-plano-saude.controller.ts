import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaPlanoSaudeService } from '../service/folha-plano-saude.service';
import { FolhaPlanoSaudeModel } from '../model/folha-plano-saude.entity';

@Crud({
  model: {
    type: FolhaPlanoSaudeModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-plano-saude')
export class FolhaPlanoSaudeController implements CrudController<FolhaPlanoSaudeModel> {
  constructor(public service: FolhaPlanoSaudeService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaPlanoSaudeModel = new FolhaPlanoSaudeModel(jsonObj);
		const result = await this.service.save(folhaPlanoSaudeModel);
		return result;
	}  


}


















