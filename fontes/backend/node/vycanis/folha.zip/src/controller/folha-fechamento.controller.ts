import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaFechamentoService } from '../service/folha-fechamento.service';
import { FolhaFechamentoModel } from '../model/folha-fechamento.entity';

@Crud({
  model: {
    type: FolhaFechamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-fechamento')
export class FolhaFechamentoController implements CrudController<FolhaFechamentoModel> {
  constructor(public service: FolhaFechamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaFechamentoModel = new FolhaFechamentoModel(jsonObj);
		const result = await this.service.save(folhaFechamentoModel);
		return result;
	}  


}


















