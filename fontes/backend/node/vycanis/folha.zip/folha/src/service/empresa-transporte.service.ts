import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { EmpresaTransporteModel } from '../entities-export';

@Injectable()
export class EmpresaTransporteService extends TypeOrmCrudService<EmpresaTransporteModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(EmpresaTransporteModel) 
    private readonly repository: Repository<EmpresaTransporteModel>,
  ) {
    super(repository);
  }

	async save(empresaTransporteModel: EmpresaTransporteModel, operation: string): Promise<EmpresaTransporteModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, empresaTransporteModel.id);
      }

      const resultObj = await queryRunner.manager.save(empresaTransporteModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(EmpresaTransporteModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from empresa_transporte_itinerario where id_empresa_transporte=' + id); 

	}
	
}