import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CodigoGpsModel } from '../entities-export';

@Injectable()
export class CodigoGpsService extends TypeOrmCrudService<CodigoGpsModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CodigoGpsModel)
    private readonly repository: Repository<CodigoGpsModel>
  ) {
    super(repository);
  }

	async save(codigoGpsModel: CodigoGpsModel): Promise<CodigoGpsModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(codigoGpsModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
