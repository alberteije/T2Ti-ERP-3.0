import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { EmpresaTransporteItinerarioModel } from '../entities-export';

@Injectable()
export class EmpresaTransporteItinerarioService extends TypeOrmCrudService<EmpresaTransporteItinerarioModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(EmpresaTransporteItinerarioModel)
    private readonly repository: Repository<EmpresaTransporteItinerarioModel>
  ) {
    super(repository);
  }

	async save(empresaTransporteItinerarioModel: EmpresaTransporteItinerarioModel): Promise<EmpresaTransporteItinerarioModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(empresaTransporteItinerarioModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
