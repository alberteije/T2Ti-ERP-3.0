import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaEventoModel } from '../entities-export';

@Injectable()
export class FolhaEventoService extends TypeOrmCrudService<FolhaEventoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaEventoModel)
    private readonly repository: Repository<FolhaEventoModel>
  ) {
    super(repository);
  }

	async save(folhaEventoModel: FolhaEventoModel): Promise<FolhaEventoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaEventoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
