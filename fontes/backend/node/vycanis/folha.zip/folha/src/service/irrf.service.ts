import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { IrrfModel } from '../entities-export';

@Injectable()
export class IrrfService extends TypeOrmCrudService<IrrfModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(IrrfModel) 
    private readonly repository: Repository<IrrfModel>,
  ) {
    super(repository);
  }

	async save(irrfModel: IrrfModel, operation: string): Promise<IrrfModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, irrfModel.id);
      }

      const resultObj = await queryRunner.manager.save(irrfModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(IrrfModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from irrf_detalhe where id_irrf=' + id); 

	}
	
}