import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaAfastamentoModel } from '../entities-export';

@Injectable()
export class FolhaAfastamentoService extends TypeOrmCrudService<FolhaAfastamentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaAfastamentoModel)
    private readonly repository: Repository<FolhaAfastamentoModel>
  ) {
    super(repository);
  }

	async save(folhaAfastamentoModel: FolhaAfastamentoModel): Promise<FolhaAfastamentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaAfastamentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
