import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { FolhaInssModel } from '../entities-export';

@Injectable()
export class FolhaInssService extends TypeOrmCrudService<FolhaInssModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(FolhaInssModel) 
    private readonly repository: Repository<FolhaInssModel>,
  ) {
    super(repository);
  }

	async save(folhaInssModel: FolhaInssModel, operation: string): Promise<FolhaInssModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, folhaInssModel.id);
      }

      const resultObj = await queryRunner.manager.save(folhaInssModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(FolhaInssModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from folha_inss_retencao where id_folha_inss=' + id); 

	}
	
}