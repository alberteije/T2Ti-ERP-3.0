import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaHistoricoSalarialModel } from '../entities-export';

@Injectable()
export class FolhaHistoricoSalarialService extends TypeOrmCrudService<FolhaHistoricoSalarialModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaHistoricoSalarialModel)
    private readonly repository: Repository<FolhaHistoricoSalarialModel>
  ) {
    super(repository);
  }

	async save(folhaHistoricoSalarialModel: FolhaHistoricoSalarialModel): Promise<FolhaHistoricoSalarialModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaHistoricoSalarialModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
