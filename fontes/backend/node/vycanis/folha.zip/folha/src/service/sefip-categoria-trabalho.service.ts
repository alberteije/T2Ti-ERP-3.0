import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SefipCategoriaTrabalhoModel } from '../entities-export';

@Injectable()
export class SefipCategoriaTrabalhoService extends TypeOrmCrudService<SefipCategoriaTrabalhoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SefipCategoriaTrabalhoModel)
    private readonly repository: Repository<SefipCategoriaTrabalhoModel>
  ) {
    super(repository);
  }

	async save(sefipCategoriaTrabalhoModel: SefipCategoriaTrabalhoModel): Promise<SefipCategoriaTrabalhoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(sefipCategoriaTrabalhoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
