import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FeriasPeriodoAquisitivoModel } from '../entities-export';

@Injectable()
export class FeriasPeriodoAquisitivoService extends TypeOrmCrudService<FeriasPeriodoAquisitivoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FeriasPeriodoAquisitivoModel)
    private readonly repository: Repository<FeriasPeriodoAquisitivoModel>
  ) {
    super(repository);
  }

	async save(feriasPeriodoAquisitivoModel: FeriasPeriodoAquisitivoModel): Promise<FeriasPeriodoAquisitivoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(feriasPeriodoAquisitivoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
