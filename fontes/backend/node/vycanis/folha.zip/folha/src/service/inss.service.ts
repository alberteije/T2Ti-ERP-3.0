import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, QueryRunner, Repository } from 'typeorm';
import { InssModel } from '../entities-export';

@Injectable()
export class InssService extends TypeOrmCrudService<InssModel> {

  constructor(
		private dataSource: DataSource,
    @InjectRepository(InssModel) 
    private readonly repository: Repository<InssModel>,
  ) {
    super(repository);
  }

	async save(inssModel: InssModel, operation: string): Promise<InssModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      if (operation === 'U') {
        await this.deleteChildren(queryRunner, inssModel.id);
      }

      const resultObj = await queryRunner.manager.save(inssModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
  
	async deleteMasterDetail(id: number) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      await this.deleteChildren(queryRunner, id);
      await queryRunner.manager.delete(InssModel, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

	async deleteChildren(queryRunner: QueryRunner, id: number) {
		await queryRunner.query('delete from salario_familia where id_inss=' + id); 

		await queryRunner.query('delete from inss_detalhe where id_inss=' + id); 

	}
	
}