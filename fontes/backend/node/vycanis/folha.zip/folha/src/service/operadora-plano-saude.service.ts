import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { OperadoraPlanoSaudeModel } from '../entities-export';

@Injectable()
export class OperadoraPlanoSaudeService extends TypeOrmCrudService<OperadoraPlanoSaudeModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(OperadoraPlanoSaudeModel)
    private readonly repository: Repository<OperadoraPlanoSaudeModel>
  ) {
    super(repository);
  }

	async save(operadoraPlanoSaudeModel: OperadoraPlanoSaudeModel): Promise<OperadoraPlanoSaudeModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(operadoraPlanoSaudeModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
