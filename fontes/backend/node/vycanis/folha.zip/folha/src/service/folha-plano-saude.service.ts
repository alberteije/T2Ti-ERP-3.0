import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaPlanoSaudeModel } from '../entities-export';

@Injectable()
export class FolhaPlanoSaudeService extends TypeOrmCrudService<FolhaPlanoSaudeModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaPlanoSaudeModel)
    private readonly repository: Repository<FolhaPlanoSaudeModel>
  ) {
    super(repository);
  }

	async save(folhaPlanoSaudeModel: FolhaPlanoSaudeModel): Promise<FolhaPlanoSaudeModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaPlanoSaudeModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
