import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SefipCodigoMovimentacaoModel } from '../entities-export';

@Injectable()
export class SefipCodigoMovimentacaoService extends TypeOrmCrudService<SefipCodigoMovimentacaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SefipCodigoMovimentacaoModel)
    private readonly repository: Repository<SefipCodigoMovimentacaoModel>
  ) {
    super(repository);
  }

	async save(sefipCodigoMovimentacaoModel: SefipCodigoMovimentacaoModel): Promise<SefipCodigoMovimentacaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(sefipCodigoMovimentacaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
