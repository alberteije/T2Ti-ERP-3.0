import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FpasModel } from '../entities-export';

@Injectable()
export class FpasService extends TypeOrmCrudService<FpasModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FpasModel)
    private readonly repository: Repository<FpasModel>
  ) {
    super(repository);
  }

	async save(fpasModel: FpasModel): Promise<FpasModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(fpasModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
