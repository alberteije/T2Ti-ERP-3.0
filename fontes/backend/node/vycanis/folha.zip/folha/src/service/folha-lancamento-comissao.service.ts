import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaLancamentoComissaoModel } from '../entities-export';

@Injectable()
export class FolhaLancamentoComissaoService extends TypeOrmCrudService<FolhaLancamentoComissaoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaLancamentoComissaoModel)
    private readonly repository: Repository<FolhaLancamentoComissaoModel>
  ) {
    super(repository);
  }

	async save(folhaLancamentoComissaoModel: FolhaLancamentoComissaoModel): Promise<FolhaLancamentoComissaoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaLancamentoComissaoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
