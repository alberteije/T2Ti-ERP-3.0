import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { CboModel } from '../entities-export';

@Injectable()
export class CboService extends TypeOrmCrudService<CboModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(CboModel)
    private readonly repository: Repository<CboModel>
  ) {
    super(repository);
  }

	async save(cboModel: CboModel): Promise<CboModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(cboModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
