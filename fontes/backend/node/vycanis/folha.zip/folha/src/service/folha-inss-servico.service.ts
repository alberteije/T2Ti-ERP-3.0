import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaInssServicoModel } from '../entities-export';

@Injectable()
export class FolhaInssServicoService extends TypeOrmCrudService<FolhaInssServicoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaInssServicoModel)
    private readonly repository: Repository<FolhaInssServicoModel>
  ) {
    super(repository);
  }

	async save(folhaInssServicoModel: FolhaInssServicoModel): Promise<FolhaInssServicoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaInssServicoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
