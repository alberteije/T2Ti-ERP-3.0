import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaFechamentoModel } from '../entities-export';

@Injectable()
export class FolhaFechamentoService extends TypeOrmCrudService<FolhaFechamentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaFechamentoModel)
    private readonly repository: Repository<FolhaFechamentoModel>
  ) {
    super(repository);
  }

	async save(folhaFechamentoModel: FolhaFechamentoModel): Promise<FolhaFechamentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaFechamentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
