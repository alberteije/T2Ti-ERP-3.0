import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SalarioMinimoModel } from '../entities-export';

@Injectable()
export class SalarioMinimoService extends TypeOrmCrudService<SalarioMinimoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SalarioMinimoModel)
    private readonly repository: Repository<SalarioMinimoModel>
  ) {
    super(repository);
  }

	async save(salarioMinimoModel: SalarioMinimoModel): Promise<SalarioMinimoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(salarioMinimoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
