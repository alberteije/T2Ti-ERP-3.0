import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaFeriasColetivasModel } from '../entities-export';

@Injectable()
export class FolhaFeriasColetivasService extends TypeOrmCrudService<FolhaFeriasColetivasModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaFeriasColetivasModel)
    private readonly repository: Repository<FolhaFeriasColetivasModel>
  ) {
    super(repository);
  }

	async save(folhaFeriasColetivasModel: FolhaFeriasColetivasModel): Promise<FolhaFeriasColetivasModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaFeriasColetivasModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
