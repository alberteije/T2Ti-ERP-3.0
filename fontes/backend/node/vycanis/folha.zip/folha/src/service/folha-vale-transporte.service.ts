import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { FolhaValeTransporteModel } from '../entities-export';

@Injectable()
export class FolhaValeTransporteService extends TypeOrmCrudService<FolhaValeTransporteModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(FolhaValeTransporteModel)
    private readonly repository: Repository<FolhaValeTransporteModel>
  ) {
    super(repository);
  }

	async save(folhaValeTransporteModel: FolhaValeTransporteModel): Promise<FolhaValeTransporteModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(folhaValeTransporteModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
