import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { SefipCodigoRecolhimentoModel } from '../entities-export';

@Injectable()
export class SefipCodigoRecolhimentoService extends TypeOrmCrudService<SefipCodigoRecolhimentoModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(SefipCodigoRecolhimentoModel)
    private readonly repository: Repository<SefipCodigoRecolhimentoModel>
  ) {
    super(repository);
  }

	async save(sefipCodigoRecolhimentoModel: SefipCodigoRecolhimentoModel): Promise<SefipCodigoRecolhimentoModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(sefipCodigoRecolhimentoModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
