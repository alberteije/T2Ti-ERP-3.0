import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TypeOrmCrudService } from '@nestjsx/crud-typeorm';
import { DataSource, Repository } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Injectable()
export class ViewPessoaColaboradorService extends TypeOrmCrudService<ViewPessoaColaboradorModel> {

  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(ViewPessoaColaboradorModel)
    private readonly repository: Repository<ViewPessoaColaboradorModel>
  ) {
    super(repository);
  }

	async save(viewPessoaColaboradorModel: ViewPessoaColaboradorModel): Promise<ViewPessoaColaboradorModel> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

	  try {
      const resultObj = await queryRunner.manager.save(viewPessoaColaboradorModel);
      await queryRunner.commitTransaction();
      return resultObj;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }
}
