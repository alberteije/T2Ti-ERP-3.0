import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { configMySQL } from './orm.config';
import { EmpresaTransporteItinerarioModule } from './modules-export';
import { EmpresaTransporteModule } from './modules-export';
import { FolhaLancamentoCabecalhoModule } from './modules-export';
import { FolhaInssModule } from './modules-export';
import { FolhaPppModule } from './modules-export';
import { IrrfModule } from './modules-export';
import { InssModule } from './modules-export';
import { OperadoraPlanoSaudeModule } from './modules-export';
import { FolhaLancamentoComissaoModule } from './modules-export';
import { FolhaParametroModule } from './modules-export';
import { GuiasAcumuladasModule } from './modules-export';
import { FolhaFechamentoModule } from './modules-export';
import { FeriasPeriodoAquisitivoModule } from './modules-export';
import { FolhaTipoAfastamentoModule } from './modules-export';
import { FolhaAfastamentoModule } from './modules-export';
import { FolhaPlanoSaudeModule } from './modules-export';
import { FolhaEventoModule } from './modules-export';
import { FolhaRescisaoModule } from './modules-export';
import { FolhaFeriasColetivasModule } from './modules-export';
import { FolhaValeTransporteModule } from './modules-export';
import { FolhaInssServicoModule } from './modules-export';
import { FolhaHistoricoSalarialModule } from './modules-export';
import { FeriadosModule } from './modules-export';
import { ViewControleAcessoModule } from './modules-export';
import { ViewPessoaUsuarioModule } from './modules-export';
import { ViewPessoaColaboradorModule } from './modules-export';
import { CboModule } from './modules-export';
import { CodigoGpsModule } from './modules-export';
import { FpasModule } from './modules-export';
import { SalarioMinimoModule } from './modules-export';
import { SefipCodigoMovimentacaoModule } from './modules-export';
import { SefipCategoriaTrabalhoModule } from './modules-export';
import { SefipCodigoRecolhimentoModule } from './modules-export';

@Module(
  {
    imports: [
      TypeOrmModule.forRoot(configMySQL),
			EmpresaTransporteItinerarioModule,
			EmpresaTransporteModule,
			FolhaLancamentoCabecalhoModule,
			FolhaInssModule,
			FolhaPppModule,
			IrrfModule,
			InssModule,
			OperadoraPlanoSaudeModule,
			FolhaLancamentoComissaoModule,
			FolhaParametroModule,
			GuiasAcumuladasModule,
			FolhaFechamentoModule,
			FeriasPeriodoAquisitivoModule,
			FolhaTipoAfastamentoModule,
			FolhaAfastamentoModule,
			FolhaPlanoSaudeModule,
			FolhaEventoModule,
			FolhaRescisaoModule,
			FolhaFeriasColetivasModule,
			FolhaValeTransporteModule,
			FolhaInssServicoModule,
			FolhaHistoricoSalarialModule,
			FeriadosModule,
			ViewControleAcessoModule,
			ViewPessoaUsuarioModule,
			ViewPessoaColaboradorModule,
			CboModule,
			CodigoGpsModule,
			FpasModule,
			SalarioMinimoModule,
			SefipCodigoMovimentacaoModule,
			SefipCategoriaTrabalhoModule,
			SefipCodigoRecolhimentoModule,
    ],
  }
)
export class AppModule { 
  constructor(private dataSource: DataSource) {}
}