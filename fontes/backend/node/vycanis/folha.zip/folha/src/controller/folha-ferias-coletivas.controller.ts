import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaFeriasColetivasService } from '../service/folha-ferias-coletivas.service';
import { FolhaFeriasColetivasModel } from '../model/folha-ferias-coletivas.entity';

@Crud({
  model: {
    type: FolhaFeriasColetivasModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-ferias-coletivas')
export class FolhaFeriasColetivasController implements CrudController<FolhaFeriasColetivasModel> {
  constructor(public service: FolhaFeriasColetivasService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaFeriasColetivasModel = new FolhaFeriasColetivasModel(jsonObj);
		const result = await this.service.save(folhaFeriasColetivasModel);
		return result;
	}  


}


















