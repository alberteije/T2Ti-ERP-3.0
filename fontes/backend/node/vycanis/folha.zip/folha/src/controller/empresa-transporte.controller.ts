import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { EmpresaTransporteService } from '../service/empresa-transporte.service';
import { EmpresaTransporteModel } from '../model/empresa-transporte.entity';

@Crud({
  model: {
    type: EmpresaTransporteModel,
  },
  query: {
    join: {
			empresaTransporteItinerarioModelList: { eager: true },
    },
  },
})
@Controller('empresa-transporte')
export class EmpresaTransporteController implements CrudController<EmpresaTransporteModel> {
  constructor(public service: EmpresaTransporteService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const empresaTransporte = new EmpresaTransporteModel(jsonObj);
		const result = await this.service.save(empresaTransporte, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const empresaTransporte = new EmpresaTransporteModel(jsonObj);
		const result = await this.service.save(empresaTransporte, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}