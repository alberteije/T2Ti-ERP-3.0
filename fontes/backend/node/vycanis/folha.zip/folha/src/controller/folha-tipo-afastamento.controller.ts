import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaTipoAfastamentoService } from '../service/folha-tipo-afastamento.service';
import { FolhaTipoAfastamentoModel } from '../model/folha-tipo-afastamento.entity';

@Crud({
  model: {
    type: FolhaTipoAfastamentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-tipo-afastamento')
export class FolhaTipoAfastamentoController implements CrudController<FolhaTipoAfastamentoModel> {
  constructor(public service: FolhaTipoAfastamentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaTipoAfastamentoModel = new FolhaTipoAfastamentoModel(jsonObj);
		const result = await this.service.save(folhaTipoAfastamentoModel);
		return result;
	}  


}


















