import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { IrrfService } from '../service/irrf.service';
import { IrrfModel } from '../model/irrf.entity';

@Crud({
  model: {
    type: IrrfModel,
  },
  query: {
    join: {
			irrfDetalheModelList: { eager: true },
    },
  },
})
@Controller('irrf')
export class IrrfController implements CrudController<IrrfModel> {
  constructor(public service: IrrfService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const irrf = new IrrfModel(jsonObj);
		const result = await this.service.save(irrf, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const irrf = new IrrfModel(jsonObj);
		const result = await this.service.save(irrf, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}