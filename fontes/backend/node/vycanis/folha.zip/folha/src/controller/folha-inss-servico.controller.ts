import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaInssServicoService } from '../service/folha-inss-servico.service';
import { FolhaInssServicoModel } from '../model/folha-inss-servico.entity';

@Crud({
  model: {
    type: FolhaInssServicoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-inss-servico')
export class FolhaInssServicoController implements CrudController<FolhaInssServicoModel> {
  constructor(public service: FolhaInssServicoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaInssServicoModel = new FolhaInssServicoModel(jsonObj);
		const result = await this.service.save(folhaInssServicoModel);
		return result;
	}  


}


















