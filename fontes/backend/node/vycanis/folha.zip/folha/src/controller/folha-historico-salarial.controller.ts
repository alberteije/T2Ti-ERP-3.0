import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FolhaHistoricoSalarialService } from '../service/folha-historico-salarial.service';
import { FolhaHistoricoSalarialModel } from '../model/folha-historico-salarial.entity';

@Crud({
  model: {
    type: FolhaHistoricoSalarialModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('folha-historico-salarial')
export class FolhaHistoricoSalarialController implements CrudController<FolhaHistoricoSalarialModel> {
  constructor(public service: FolhaHistoricoSalarialService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaHistoricoSalarialModel = new FolhaHistoricoSalarialModel(jsonObj);
		const result = await this.service.save(folhaHistoricoSalarialModel);
		return result;
	}  


}


















