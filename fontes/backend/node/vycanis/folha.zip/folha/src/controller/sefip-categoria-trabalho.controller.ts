import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SefipCategoriaTrabalhoService } from '../service/sefip-categoria-trabalho.service';
import { SefipCategoriaTrabalhoModel } from '../model/sefip-categoria-trabalho.entity';

@Crud({
  model: {
    type: SefipCategoriaTrabalhoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('sefip-categoria-trabalho')
export class SefipCategoriaTrabalhoController implements CrudController<SefipCategoriaTrabalhoModel> {
  constructor(public service: SefipCategoriaTrabalhoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const sefipCategoriaTrabalhoModel = new SefipCategoriaTrabalhoModel(jsonObj);
		const result = await this.service.save(sefipCategoriaTrabalhoModel);
		return result;
	}  


}


















