import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { FpasService } from '../service/fpas.service';
import { FpasModel } from '../model/fpas.entity';

@Crud({
  model: {
    type: FpasModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('fpas')
export class FpasController implements CrudController<FpasModel> {
  constructor(public service: FpasService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const fpasModel = new FpasModel(jsonObj);
		const result = await this.service.save(fpasModel);
		return result;
	}  


}


















