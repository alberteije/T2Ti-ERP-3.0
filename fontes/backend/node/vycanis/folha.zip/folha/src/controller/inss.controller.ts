import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { InssService } from '../service/inss.service';
import { InssModel } from '../model/inss.entity';

@Crud({
  model: {
    type: InssModel,
  },
  query: {
    join: {
			salarioFamiliaModelList: { eager: true },
			inssDetalheModelList: { eager: true },
    },
  },
})
@Controller('inss')
export class InssController implements CrudController<InssModel> {
  constructor(public service: InssService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const inss = new InssModel(jsonObj);
		const result = await this.service.save(inss, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const inss = new InssModel(jsonObj);
		const result = await this.service.save(inss, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}