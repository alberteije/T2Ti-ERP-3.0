import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CboService } from '../service/cbo.service';
import { CboModel } from '../model/cbo.entity';

@Crud({
  model: {
    type: CboModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('cbo')
export class CboController implements CrudController<CboModel> {
  constructor(public service: CboService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const cboModel = new CboModel(jsonObj);
		const result = await this.service.save(cboModel);
		return result;
	}  


}


















