import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SefipCodigoRecolhimentoService } from '../service/sefip-codigo-recolhimento.service';
import { SefipCodigoRecolhimentoModel } from '../model/sefip-codigo-recolhimento.entity';

@Crud({
  model: {
    type: SefipCodigoRecolhimentoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('sefip-codigo-recolhimento')
export class SefipCodigoRecolhimentoController implements CrudController<SefipCodigoRecolhimentoModel> {
  constructor(public service: SefipCodigoRecolhimentoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const sefipCodigoRecolhimentoModel = new SefipCodigoRecolhimentoModel(jsonObj);
		const result = await this.service.save(sefipCodigoRecolhimentoModel);
		return result;
	}  


}


















