import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { CodigoGpsService } from '../service/codigo-gps.service';
import { CodigoGpsModel } from '../model/codigo-gps.entity';

@Crud({
  model: {
    type: CodigoGpsModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('codigo-gps')
export class CodigoGpsController implements CrudController<CodigoGpsModel> {
  constructor(public service: CodigoGpsService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const codigoGpsModel = new CodigoGpsModel(jsonObj);
		const result = await this.service.save(codigoGpsModel);
		return result;
	}  


}


















