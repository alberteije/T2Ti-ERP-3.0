import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { EmpresaTransporteItinerarioService } from '../service/empresa-transporte-itinerario.service';
import { EmpresaTransporteItinerarioModel } from '../model/empresa-transporte-itinerario.entity';

@Crud({
  model: {
    type: EmpresaTransporteItinerarioModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('empresa-transporte-itinerario')
export class EmpresaTransporteItinerarioController implements CrudController<EmpresaTransporteItinerarioModel> {
  constructor(public service: EmpresaTransporteItinerarioService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const empresaTransporteItinerarioModel = new EmpresaTransporteItinerarioModel(jsonObj);
		const result = await this.service.save(empresaTransporteItinerarioModel);
		return result;
	}  


}


















