import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SefipCodigoMovimentacaoService } from '../service/sefip-codigo-movimentacao.service';
import { SefipCodigoMovimentacaoModel } from '../model/sefip-codigo-movimentacao.entity';

@Crud({
  model: {
    type: SefipCodigoMovimentacaoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('sefip-codigo-movimentacao')
export class SefipCodigoMovimentacaoController implements CrudController<SefipCodigoMovimentacaoModel> {
  constructor(public service: SefipCodigoMovimentacaoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const sefipCodigoMovimentacaoModel = new SefipCodigoMovimentacaoModel(jsonObj);
		const result = await this.service.save(sefipCodigoMovimentacaoModel);
		return result;
	}  


}


















