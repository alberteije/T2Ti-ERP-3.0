import { Controller, Put, Req, } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { SalarioMinimoService } from '../service/salario-minimo.service';
import { SalarioMinimoModel } from '../model/salario-minimo.entity';

@Crud({
  model: {
    type: SalarioMinimoModel,
  },
  query: {
    join: {
    },
  },
})
@Controller('salario-minimo')
export class SalarioMinimoController implements CrudController<SalarioMinimoModel> {
  constructor(public service: SalarioMinimoService) { }

	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const salarioMinimoModel = new SalarioMinimoModel(jsonObj);
		const result = await this.service.save(salarioMinimoModel);
		return result;
	}  


}


















