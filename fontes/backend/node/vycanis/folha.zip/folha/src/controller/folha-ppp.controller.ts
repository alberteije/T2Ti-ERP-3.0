import { Controller, Delete, Get, Header, HttpCode, Param, Post, Put, Req } from '@nestjs/common';
import { Crud, CrudController } from '@nestjsx/crud';
import { Request } from 'express';
import { FolhaPppService } from '../service/folha-ppp.service';
import { FolhaPppModel } from '../model/folha-ppp.entity';

@Crud({
  model: {
    type: FolhaPppModel,
  },
  query: {
    join: {
			folhaPppCatModelList: { eager: true },
			folhaPppAtividadeModelList: { eager: true },
			folhaPppFatorRiscoModelList: { eager: true },
			folhaPppExameMedicoModelList: { eager: true },
			viewPessoaColaboradorModel: { eager: true },
    },
  },
})
@Controller('folha-ppp')
export class FolhaPppController implements CrudController<FolhaPppModel> {
  constructor(public service: FolhaPppService) { }

	@Post()
	async insert(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaPpp = new FolhaPppModel(jsonObj);
		const result = await this.service.save(folhaPpp, 'I');
		return result;
	}


	@Put()
	async update(@Req() request: Request) {
		const jsonObj = request.body;
		const folhaPpp = new FolhaPppModel(jsonObj);
		const result = await this.service.save(folhaPpp, 'U');
		return result;
	}

	@Delete(':id')
	async delete(@Param('id') id: number) {
		return this.service.deleteMasterDetail(id);
	}
  
}