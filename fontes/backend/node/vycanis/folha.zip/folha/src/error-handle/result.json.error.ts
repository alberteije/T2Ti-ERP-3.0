/**
   * transient class that stores the error object that will be returned to the client
   */

export class ResultJsonError {

    status: string;
    message: string;
    error: string;
    trace: string;

    constructor(params: any) {
        this.status = params.code;
        this.message = params.message;
        switch (params.code) {
            case 400:
                this.error = "Bad Request";
                break;
            case 404:
                this.error = "Not Found";
                break;
            case 500:
                this.error = "Internal Server Error";
                break;
            default:
                this.error = "Not Mapped Error";
                break;
        }
        if (params.error != null) {
            this.message = this.message + " - Exception: " + params.error.message.errorr + " - " + params.error.message.message;
            this.trace = params.error.stack;
        } else if (params.erro != null) {
            this.message = this.message + " - Exception: " + params.erro.message.errorr + " - " + params.erro.message.message;
            this.trace = params.erro.stack;
        }
    }
}