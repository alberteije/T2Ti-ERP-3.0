import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CodigoGpsController } from '../controller/codigo-gps.controller';
import { CodigoGpsService } from '../service/codigo-gps.service';
import { CodigoGpsModel } from '../model/codigo-gps.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CodigoGpsModel])],
    controllers: [CodigoGpsController],
    providers: [CodigoGpsService],
})
export class CodigoGpsModule { }
