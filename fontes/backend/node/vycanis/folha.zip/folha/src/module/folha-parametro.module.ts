import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaParametroController } from '../controller/folha-parametro.controller';
import { FolhaParametroService } from '../service/folha-parametro.service';
import { FolhaParametroModel } from '../model/folha-parametro.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaParametroModel])],
    controllers: [FolhaParametroController],
    providers: [FolhaParametroService],
})
export class FolhaParametroModule { }
