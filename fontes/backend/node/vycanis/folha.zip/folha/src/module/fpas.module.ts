import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FpasController } from '../controller/fpas.controller';
import { FpasService } from '../service/fpas.service';
import { FpasModel } from '../model/fpas.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FpasModel])],
    controllers: [FpasController],
    providers: [FpasService],
})
export class FpasModule { }
