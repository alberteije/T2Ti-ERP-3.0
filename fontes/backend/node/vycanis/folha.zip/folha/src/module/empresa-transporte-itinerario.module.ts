import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EmpresaTransporteItinerarioController } from '../controller/empresa-transporte-itinerario.controller';
import { EmpresaTransporteItinerarioService } from '../service/empresa-transporte-itinerario.service';
import { EmpresaTransporteItinerarioModel } from '../model/empresa-transporte-itinerario.entity';

@Module({
    imports: [TypeOrmModule.forFeature([EmpresaTransporteItinerarioModel])],
    controllers: [EmpresaTransporteItinerarioController],
    providers: [EmpresaTransporteItinerarioService],
})
export class EmpresaTransporteItinerarioModule { }
