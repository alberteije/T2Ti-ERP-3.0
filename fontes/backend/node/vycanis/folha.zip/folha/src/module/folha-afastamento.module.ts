import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaAfastamentoController } from '../controller/folha-afastamento.controller';
import { FolhaAfastamentoService } from '../service/folha-afastamento.service';
import { FolhaAfastamentoModel } from '../model/folha-afastamento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaAfastamentoModel])],
    controllers: [FolhaAfastamentoController],
    providers: [FolhaAfastamentoService],
})
export class FolhaAfastamentoModule { }
