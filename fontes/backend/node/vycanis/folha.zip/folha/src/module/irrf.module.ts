import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { IrrfController } from '../controller/irrf.controller';
import { IrrfService } from '../service/irrf.service';
import { IrrfModel } from '../model/irrf.entity';

@Module({
    imports: [TypeOrmModule.forFeature([IrrfModel])],
    controllers: [IrrfController],
    providers: [IrrfService],
})
export class IrrfModule { }
