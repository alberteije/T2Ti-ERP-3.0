import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FeriasPeriodoAquisitivoController } from '../controller/ferias-periodo-aquisitivo.controller';
import { FeriasPeriodoAquisitivoService } from '../service/ferias-periodo-aquisitivo.service';
import { FeriasPeriodoAquisitivoModel } from '../model/ferias-periodo-aquisitivo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FeriasPeriodoAquisitivoModel])],
    controllers: [FeriasPeriodoAquisitivoController],
    providers: [FeriasPeriodoAquisitivoService],
})
export class FeriasPeriodoAquisitivoModule { }
