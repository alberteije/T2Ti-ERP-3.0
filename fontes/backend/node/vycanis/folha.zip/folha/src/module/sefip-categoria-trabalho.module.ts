import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SefipCategoriaTrabalhoController } from '../controller/sefip-categoria-trabalho.controller';
import { SefipCategoriaTrabalhoService } from '../service/sefip-categoria-trabalho.service';
import { SefipCategoriaTrabalhoModel } from '../model/sefip-categoria-trabalho.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SefipCategoriaTrabalhoModel])],
    controllers: [SefipCategoriaTrabalhoController],
    providers: [SefipCategoriaTrabalhoService],
})
export class SefipCategoriaTrabalhoModule { }
