import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SefipCodigoRecolhimentoController } from '../controller/sefip-codigo-recolhimento.controller';
import { SefipCodigoRecolhimentoService } from '../service/sefip-codigo-recolhimento.service';
import { SefipCodigoRecolhimentoModel } from '../model/sefip-codigo-recolhimento.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SefipCodigoRecolhimentoModel])],
    controllers: [SefipCodigoRecolhimentoController],
    providers: [SefipCodigoRecolhimentoService],
})
export class SefipCodigoRecolhimentoModule { }
