import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InssController } from '../controller/inss.controller';
import { InssService } from '../service/inss.service';
import { InssModel } from '../model/inss.entity';

@Module({
    imports: [TypeOrmModule.forFeature([InssModel])],
    controllers: [InssController],
    providers: [InssService],
})
export class InssModule { }
