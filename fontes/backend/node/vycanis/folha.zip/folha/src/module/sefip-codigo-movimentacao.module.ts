import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SefipCodigoMovimentacaoController } from '../controller/sefip-codigo-movimentacao.controller';
import { SefipCodigoMovimentacaoService } from '../service/sefip-codigo-movimentacao.service';
import { SefipCodigoMovimentacaoModel } from '../model/sefip-codigo-movimentacao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SefipCodigoMovimentacaoModel])],
    controllers: [SefipCodigoMovimentacaoController],
    providers: [SefipCodigoMovimentacaoService],
})
export class SefipCodigoMovimentacaoModule { }
