import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaInssController } from '../controller/folha-inss.controller';
import { FolhaInssService } from '../service/folha-inss.service';
import { FolhaInssModel } from '../model/folha-inss.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaInssModel])],
    controllers: [FolhaInssController],
    providers: [FolhaInssService],
})
export class FolhaInssModule { }
