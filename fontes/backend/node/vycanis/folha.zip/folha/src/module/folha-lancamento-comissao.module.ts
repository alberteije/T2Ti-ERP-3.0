import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaLancamentoComissaoController } from '../controller/folha-lancamento-comissao.controller';
import { FolhaLancamentoComissaoService } from '../service/folha-lancamento-comissao.service';
import { FolhaLancamentoComissaoModel } from '../model/folha-lancamento-comissao.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaLancamentoComissaoModel])],
    controllers: [FolhaLancamentoComissaoController],
    providers: [FolhaLancamentoComissaoService],
})
export class FolhaLancamentoComissaoModule { }
