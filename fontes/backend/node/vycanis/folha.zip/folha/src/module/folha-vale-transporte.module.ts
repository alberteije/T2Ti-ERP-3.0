import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaValeTransporteController } from '../controller/folha-vale-transporte.controller';
import { FolhaValeTransporteService } from '../service/folha-vale-transporte.service';
import { FolhaValeTransporteModel } from '../model/folha-vale-transporte.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaValeTransporteModel])],
    controllers: [FolhaValeTransporteController],
    providers: [FolhaValeTransporteService],
})
export class FolhaValeTransporteModule { }
