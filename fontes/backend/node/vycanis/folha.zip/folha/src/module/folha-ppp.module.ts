import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaPppController } from '../controller/folha-ppp.controller';
import { FolhaPppService } from '../service/folha-ppp.service';
import { FolhaPppModel } from '../model/folha-ppp.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaPppModel])],
    controllers: [FolhaPppController],
    providers: [FolhaPppService],
})
export class FolhaPppModule { }
