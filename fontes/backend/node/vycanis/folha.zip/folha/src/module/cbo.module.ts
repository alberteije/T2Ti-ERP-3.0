import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CboController } from '../controller/cbo.controller';
import { CboService } from '../service/cbo.service';
import { CboModel } from '../model/cbo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([CboModel])],
    controllers: [CboController],
    providers: [CboService],
})
export class CboModule { }
