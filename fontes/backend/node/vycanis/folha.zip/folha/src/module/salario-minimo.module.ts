import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SalarioMinimoController } from '../controller/salario-minimo.controller';
import { SalarioMinimoService } from '../service/salario-minimo.service';
import { SalarioMinimoModel } from '../model/salario-minimo.entity';

@Module({
    imports: [TypeOrmModule.forFeature([SalarioMinimoModel])],
    controllers: [SalarioMinimoController],
    providers: [SalarioMinimoService],
})
export class SalarioMinimoModule { }
