import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FeriadosController } from '../controller/feriados.controller';
import { FeriadosService } from '../service/feriados.service';
import { FeriadosModel } from '../model/feriados.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FeriadosModel])],
    controllers: [FeriadosController],
    providers: [FeriadosService],
})
export class FeriadosModule { }
