import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FolhaHistoricoSalarialController } from '../controller/folha-historico-salarial.controller';
import { FolhaHistoricoSalarialService } from '../service/folha-historico-salarial.service';
import { FolhaHistoricoSalarialModel } from '../model/folha-historico-salarial.entity';

@Module({
    imports: [TypeOrmModule.forFeature([FolhaHistoricoSalarialModel])],
    controllers: [FolhaHistoricoSalarialController],
    providers: [FolhaHistoricoSalarialService],
})
export class FolhaHistoricoSalarialModule { }
