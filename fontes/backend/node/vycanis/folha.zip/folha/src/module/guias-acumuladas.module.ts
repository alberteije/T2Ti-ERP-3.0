import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GuiasAcumuladasController } from '../controller/guias-acumuladas.controller';
import { GuiasAcumuladasService } from '../service/guias-acumuladas.service';
import { GuiasAcumuladasModel } from '../model/guias-acumuladas.entity';

@Module({
    imports: [TypeOrmModule.forFeature([GuiasAcumuladasModel])],
    controllers: [GuiasAcumuladasController],
    providers: [GuiasAcumuladasService],
})
export class GuiasAcumuladasModule { }
