import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewPessoaColaboradorController } from '../controller/view-pessoa-colaborador.controller';
import { ViewPessoaColaboradorService } from '../service/view-pessoa-colaborador.service';
import { ViewPessoaColaboradorModel } from '../model/view-pessoa-colaborador.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ViewPessoaColaboradorModel])],
    controllers: [ViewPessoaColaboradorController],
    providers: [ViewPessoaColaboradorService],
})
export class ViewPessoaColaboradorModule { }
