import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { IrrfModel } from '../entities-export';

@Entity({ name: 'irrf_detalhe' })
export class IrrfDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'faixa' }) 
	faixa: number; 

	@Column({ name: 'de', type: 'decimal', precision: 18, scale: 6 }) 
	de: number; 

	@Column({ name: 'ate', type: 'decimal', precision: 18, scale: 6 }) 
	ate: number; 

	@Column({ name: 'taxa', type: 'decimal', precision: 18, scale: 6 }) 
	taxa: number; 

	@Column({ name: 'desconto', type: 'decimal', precision: 18, scale: 6 }) 
	desconto: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => IrrfModel, irrfModel => irrfModel.irrfDetalheModelList)
	@JoinColumn({ name: 'id_irrf' })
	irrfModel: IrrfModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.faixa = jsonObj['faixa'];
			this.de = jsonObj['de'];
			this.ate = jsonObj['ate'];
			this.taxa = jsonObj['taxa'];
			this.desconto = jsonObj['desconto'];
		}
	}
}