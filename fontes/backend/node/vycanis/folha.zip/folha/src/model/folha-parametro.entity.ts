import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'folha_parametro' })
export class FolhaParametroModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'contribui_pis' }) 
	contribuiPis: string; 

	@Column({ name: 'aliquota_pis', type: 'decimal', precision: 18, scale: 6 }) 
	aliquotaPis: number; 

	@Column({ name: 'discriminar_dsr' }) 
	discriminarDsr: string; 

	@Column({ name: 'dia_pagamento' }) 
	diaPagamento: string; 

	@Column({ name: 'calculo_proporcionalidade' }) 
	calculoProporcionalidade: string; 

	@Column({ name: 'descontar_faltas_13' }) 
	descontarFaltas13: string; 

	@Column({ name: 'pagar_adicionais_13' }) 
	pagarAdicionais13: string; 

	@Column({ name: 'pagar_estagiarios_13' }) 
	pagarEstagiarios13: string; 

	@Column({ name: 'mes_adiantamento_13' }) 
	mesAdiantamento13: string; 

	@Column({ name: 'percentual_adiantam_13', type: 'decimal', precision: 18, scale: 6 }) 
	percentualAdiantam13: number; 

	@Column({ name: 'ferias_descontar_faltas' }) 
	feriasDescontarFaltas: string; 

	@Column({ name: 'ferias_pagar_adicionais' }) 
	feriasPagarAdicionais: string; 

	@Column({ name: 'ferias_adiantar_13' }) 
	feriasAdiantar13: string; 

	@Column({ name: 'ferias_pagar_estagiarios' }) 
	feriasPagarEstagiarios: string; 

	@Column({ name: 'ferias_calc_justa_causa' }) 
	feriasCalcJustaCausa: string; 

	@Column({ name: 'ferias_movimento_mensal' }) 
	feriasMovimentoMensal: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.contribuiPis = jsonObj['contribuiPis'];
			this.aliquotaPis = jsonObj['aliquotaPis'];
			this.discriminarDsr = jsonObj['discriminarDsr'];
			this.diaPagamento = jsonObj['diaPagamento'];
			this.calculoProporcionalidade = jsonObj['calculoProporcionalidade'];
			this.descontarFaltas13 = jsonObj['descontarFaltas13'];
			this.pagarAdicionais13 = jsonObj['pagarAdicionais13'];
			this.pagarEstagiarios13 = jsonObj['pagarEstagiarios13'];
			this.mesAdiantamento13 = jsonObj['mesAdiantamento13'];
			this.percentualAdiantam13 = jsonObj['percentualAdiantam13'];
			this.feriasDescontarFaltas = jsonObj['feriasDescontarFaltas'];
			this.feriasPagarAdicionais = jsonObj['feriasPagarAdicionais'];
			this.feriasAdiantar13 = jsonObj['feriasAdiantar13'];
			this.feriasPagarEstagiarios = jsonObj['feriasPagarEstagiarios'];
			this.feriasCalcJustaCausa = jsonObj['feriasCalcJustaCausa'];
			this.feriasMovimentoMensal = jsonObj['feriasMovimentoMensal'];
		}
	}
}