import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaPppCatModel } from '../entities-export';
import { FolhaPppAtividadeModel } from '../entities-export';
import { FolhaPppFatorRiscoModel } from '../entities-export';
import { FolhaPppExameMedicoModel } from '../entities-export';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'folha_ppp' })
export class FolhaPppModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'observacao' }) 
	observacao: string; 


	/**
	* Relations
	*/
	@OneToMany(() => FolhaPppCatModel, folhaPppCatModel => folhaPppCatModel.folhaPppModel, { cascade: true })
	folhaPppCatModelList: FolhaPppCatModel[];

	@OneToMany(() => FolhaPppAtividadeModel, folhaPppAtividadeModel => folhaPppAtividadeModel.folhaPppModel, { cascade: true })
	folhaPppAtividadeModelList: FolhaPppAtividadeModel[];

	@OneToMany(() => FolhaPppFatorRiscoModel, folhaPppFatorRiscoModel => folhaPppFatorRiscoModel.folhaPppModel, { cascade: true })
	folhaPppFatorRiscoModelList: FolhaPppFatorRiscoModel[];

	@OneToMany(() => FolhaPppExameMedicoModel, folhaPppExameMedicoModel => folhaPppExameMedicoModel.folhaPppModel, { cascade: true })
	folhaPppExameMedicoModelList: FolhaPppExameMedicoModel[];

	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.observacao = jsonObj['observacao'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			this.folhaPppCatModelList = [];
			let folhaPppCatModelJsonList = jsonObj['folhaPppCatModelList'];
			if (folhaPppCatModelJsonList != null) {
				for (let i = 0; i < folhaPppCatModelJsonList.length; i++) {
					let obj = new FolhaPppCatModel(folhaPppCatModelJsonList[i]);
					this.folhaPppCatModelList.push(obj);
				}
			}

			this.folhaPppAtividadeModelList = [];
			let folhaPppAtividadeModelJsonList = jsonObj['folhaPppAtividadeModelList'];
			if (folhaPppAtividadeModelJsonList != null) {
				for (let i = 0; i < folhaPppAtividadeModelJsonList.length; i++) {
					let obj = new FolhaPppAtividadeModel(folhaPppAtividadeModelJsonList[i]);
					this.folhaPppAtividadeModelList.push(obj);
				}
			}

			this.folhaPppFatorRiscoModelList = [];
			let folhaPppFatorRiscoModelJsonList = jsonObj['folhaPppFatorRiscoModelList'];
			if (folhaPppFatorRiscoModelJsonList != null) {
				for (let i = 0; i < folhaPppFatorRiscoModelJsonList.length; i++) {
					let obj = new FolhaPppFatorRiscoModel(folhaPppFatorRiscoModelJsonList[i]);
					this.folhaPppFatorRiscoModelList.push(obj);
				}
			}

			this.folhaPppExameMedicoModelList = [];
			let folhaPppExameMedicoModelJsonList = jsonObj['folhaPppExameMedicoModelList'];
			if (folhaPppExameMedicoModelJsonList != null) {
				for (let i = 0; i < folhaPppExameMedicoModelJsonList.length; i++) {
					let obj = new FolhaPppExameMedicoModel(folhaPppExameMedicoModelJsonList[i]);
					this.folhaPppExameMedicoModelList.push(obj);
				}
			}

		}
	}
}