import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { FolhaTipoAfastamentoModel } from '../entities-export';

@Entity({ name: 'folha_afastamento' })
export class FolhaAfastamentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'dias_afastado' }) 
	diasAfastado: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => FolhaTipoAfastamentoModel)
	@JoinColumn({ name: 'id_folha_tipo_afastamento' })
	folhaTipoAfastamentoModel: FolhaTipoAfastamentoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
			this.diasAfastado = jsonObj['diasAfastado'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['folhaTipoAfastamentoModel'] != null) {
				this.folhaTipoAfastamentoModel = new FolhaTipoAfastamentoModel(jsonObj['folhaTipoAfastamentoModel']);
			}

		}
	}
}