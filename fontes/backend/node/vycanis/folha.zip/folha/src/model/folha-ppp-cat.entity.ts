import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaPppModel } from '../entities-export';

@Entity({ name: 'folha_ppp_cat' })
export class FolhaPppCatModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'numero_cat' }) 
	numeroCat: number; 

	@Column({ name: 'data_afastamento' }) 
	dataAfastamento: Date; 

	@Column({ name: 'data_registro' }) 
	dataRegistro: Date; 


	/**
	* Relations
	*/
	@ManyToOne(() => FolhaPppModel, folhaPppModel => folhaPppModel.folhaPppCatModelList)
	@JoinColumn({ name: 'id_folha_ppp' })
	folhaPppModel: FolhaPppModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.numeroCat = jsonObj['numeroCat'];
			this.dataAfastamento = jsonObj['dataAfastamento'];
			this.dataRegistro = jsonObj['dataRegistro'];
		}
	}
}