import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'sefip_codigo_recolhimento' })
export class SefipCodigoRecolhimentoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'aplicacao' }) 
	aplicacao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.descricao = jsonObj['descricao'];
			this.aplicacao = jsonObj['aplicacao'];
		}
	}
}