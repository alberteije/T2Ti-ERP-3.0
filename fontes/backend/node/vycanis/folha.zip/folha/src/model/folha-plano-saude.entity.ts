import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';
import { OperadoraPlanoSaudeModel } from '../entities-export';

@Entity({ name: 'folha_plano_saude' })
export class FolhaPlanoSaudeModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'beneficiario' }) 
	beneficiario: string; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;

	@OneToOne(() => OperadoraPlanoSaudeModel)
	@JoinColumn({ name: 'id_operadora_plano_saude' })
	operadoraPlanoSaudeModel: OperadoraPlanoSaudeModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.beneficiario = jsonObj['beneficiario'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

			if (jsonObj['operadoraPlanoSaudeModel'] != null) {
				this.operadoraPlanoSaudeModel = new OperadoraPlanoSaudeModel(jsonObj['operadoraPlanoSaudeModel']);
			}

		}
	}
}