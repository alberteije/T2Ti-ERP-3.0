import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'folha_ferias_coletivas' })
export class FolhaFeriasColetivasModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'dias_gozo' }) 
	diasGozo: number; 

	@Column({ name: 'abono_pecuniario_inicio' }) 
	abonoPecuniarioInicio: Date; 

	@Column({ name: 'abono_pecuniario_fim' }) 
	abonoPecuniarioFim: Date; 

	@Column({ name: 'dias_abono' }) 
	diasAbono: number; 

	@Column({ name: 'data_pagamento' }) 
	dataPagamento: Date; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
			this.diasGozo = jsonObj['diasGozo'];
			this.abonoPecuniarioInicio = jsonObj['abonoPecuniarioInicio'];
			this.abonoPecuniarioFim = jsonObj['abonoPecuniarioFim'];
			this.diasAbono = jsonObj['diasAbono'];
			this.dataPagamento = jsonObj['dataPagamento'];
		}
	}
}