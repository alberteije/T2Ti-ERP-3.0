import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'guias_acumuladas' })
export class GuiasAcumuladasModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'gps_tipo' }) 
	gpsTipo: string; 

	@Column({ name: 'gps_competencia' }) 
	gpsCompetencia: string; 

	@Column({ name: 'gps_valor_inss', type: 'decimal', precision: 18, scale: 6 }) 
	gpsValorInss: number; 

	@Column({ name: 'gps_valor_outras_ent', type: 'decimal', precision: 18, scale: 6 }) 
	gpsValorOutrasEnt: number; 

	@Column({ name: 'gps_data_pagamento' }) 
	gpsDataPagamento: Date; 

	@Column({ name: 'irrf_competencia' }) 
	irrfCompetencia: string; 

	@Column({ name: 'irrf_codigo_recolhimento' }) 
	irrfCodigoRecolhimento: number; 

	@Column({ name: 'irrf_valor_acumulado', type: 'decimal', precision: 18, scale: 6 }) 
	irrfValorAcumulado: number; 

	@Column({ name: 'irrf_data_pagamento' }) 
	irrfDataPagamento: Date; 

	@Column({ name: 'pis_competencia' }) 
	pisCompetencia: string; 

	@Column({ name: 'pis_valor_acumulado', type: 'decimal', precision: 18, scale: 6 }) 
	pisValorAcumulado: number; 

	@Column({ name: 'pis_data_pagamento' }) 
	pisDataPagamento: Date; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.gpsTipo = jsonObj['gpsTipo'];
			this.gpsCompetencia = jsonObj['gpsCompetencia'];
			this.gpsValorInss = jsonObj['gpsValorInss'];
			this.gpsValorOutrasEnt = jsonObj['gpsValorOutrasEnt'];
			this.gpsDataPagamento = jsonObj['gpsDataPagamento'];
			this.irrfCompetencia = jsonObj['irrfCompetencia'];
			this.irrfCodigoRecolhimento = jsonObj['irrfCodigoRecolhimento'];
			this.irrfValorAcumulado = jsonObj['irrfValorAcumulado'];
			this.irrfDataPagamento = jsonObj['irrfDataPagamento'];
			this.pisCompetencia = jsonObj['pisCompetencia'];
			this.pisValorAcumulado = jsonObj['pisValorAcumulado'];
			this.pisDataPagamento = jsonObj['pisDataPagamento'];
		}
	}
}