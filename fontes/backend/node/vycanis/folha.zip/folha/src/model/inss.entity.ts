import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { SalarioFamiliaModel } from '../entities-export';
import { InssDetalheModel } from '../entities-export';

@Entity({ name: 'inss' })
export class InssModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 


	/**
	* Relations
	*/
	@OneToMany(() => SalarioFamiliaModel, salarioFamiliaModel => salarioFamiliaModel.inssModel, { cascade: true })
	salarioFamiliaModelList: SalarioFamiliaModel[];

	@OneToMany(() => InssDetalheModel, inssDetalheModel => inssDetalheModel.inssModel, { cascade: true })
	inssDetalheModelList: InssDetalheModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.salarioFamiliaModelList = [];
			let salarioFamiliaModelJsonList = jsonObj['salarioFamiliaModelList'];
			if (salarioFamiliaModelJsonList != null) {
				for (let i = 0; i < salarioFamiliaModelJsonList.length; i++) {
					let obj = new SalarioFamiliaModel(salarioFamiliaModelJsonList[i]);
					this.salarioFamiliaModelList.push(obj);
				}
			}

			this.inssDetalheModelList = [];
			let inssDetalheModelJsonList = jsonObj['inssDetalheModelList'];
			if (inssDetalheModelJsonList != null) {
				for (let i = 0; i < inssDetalheModelJsonList.length; i++) {
					let obj = new InssDetalheModel(inssDetalheModelJsonList[i]);
					this.inssDetalheModelList.push(obj);
				}
			}

		}
	}
}