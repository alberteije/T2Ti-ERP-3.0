import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { InssModel } from '../entities-export';

@Entity({ name: 'inss_detalhe' })
export class InssDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'faixa' }) 
	faixa: number; 

	@Column({ name: 'de', type: 'decimal', precision: 18, scale: 6 }) 
	de: number; 

	@Column({ name: 'ate', type: 'decimal', precision: 18, scale: 6 }) 
	ate: number; 

	@Column({ name: 'taxa', type: 'decimal', precision: 18, scale: 6 }) 
	taxa: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => InssModel, inssModel => inssModel.inssDetalheModelList)
	@JoinColumn({ name: 'id_inss' })
	inssModel: InssModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.faixa = jsonObj['faixa'];
			this.de = jsonObj['de'];
			this.ate = jsonObj['ate'];
			this.taxa = jsonObj['taxa'];
		}
	}
}