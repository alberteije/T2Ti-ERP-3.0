import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { EmpresaTransporteModel } from '../entities-export';

@Entity({ name: 'empresa_transporte_itinerario' })
export class EmpresaTransporteItinerarioModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'tarifa', type: 'decimal', precision: 18, scale: 6 }) 
	tarifa: number; 

	@Column({ name: 'trajeto' }) 
	trajeto: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => EmpresaTransporteModel, empresaTransporteModel => empresaTransporteModel.empresaTransporteItinerarioModelList)
	@JoinColumn({ name: 'id_empresa_transporte' })
	empresaTransporteModel: EmpresaTransporteModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.nome = jsonObj['nome'];
			this.tarifa = jsonObj['tarifa'];
			this.trajeto = jsonObj['trajeto'];
		}
	}
}