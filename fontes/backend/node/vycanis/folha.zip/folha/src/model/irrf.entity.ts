import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { IrrfDetalheModel } from '../entities-export';

@Entity({ name: 'irrf' })
export class IrrfModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'competencia' }) 
	competencia: string; 

	@Column({ name: 'desconto_por_dependente', type: 'decimal', precision: 18, scale: 6 }) 
	descontoPorDependente: number; 

	@Column({ name: 'minimo_para_retencao', type: 'decimal', precision: 18, scale: 6 }) 
	minimoParaRetencao: number; 


	/**
	* Relations
	*/
	@OneToMany(() => IrrfDetalheModel, irrfDetalheModel => irrfDetalheModel.irrfModel, { cascade: true })
	irrfDetalheModelList: IrrfDetalheModel[];


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.competencia = jsonObj['competencia'];
			this.descontoPorDependente = jsonObj['descontoPorDependente'];
			this.minimoParaRetencao = jsonObj['minimoParaRetencao'];
			this.irrfDetalheModelList = [];
			let irrfDetalheModelJsonList = jsonObj['irrfDetalheModelList'];
			if (irrfDetalheModelJsonList != null) {
				for (let i = 0; i < irrfDetalheModelJsonList.length; i++) {
					let obj = new IrrfDetalheModel(irrfDetalheModelJsonList[i]);
					this.irrfDetalheModelList.push(obj);
				}
			}

		}
	}
}