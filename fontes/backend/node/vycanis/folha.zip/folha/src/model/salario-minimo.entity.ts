import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'salario_minimo' })
export class SalarioMinimoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'vigencia' }) 
	vigencia: Date; 

	@Column({ name: 'valor_mensal', type: 'decimal', precision: 18, scale: 6 }) 
	valorMensal: number; 

	@Column({ name: 'valor_diario', type: 'decimal', precision: 18, scale: 6 }) 
	valorDiario: number; 

	@Column({ name: 'valor_hora', type: 'decimal', precision: 18, scale: 6 }) 
	valorHora: number; 

	@Column({ name: 'norma_legal' }) 
	normaLegal: string; 

	@Column({ name: 'dou' }) 
	dou: Date; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.vigencia = jsonObj['vigencia'];
			this.valorMensal = jsonObj['valorMensal'];
			this.valorDiario = jsonObj['valorDiario'];
			this.valorHora = jsonObj['valorHora'];
			this.normaLegal = jsonObj['normaLegal'];
			this.dou = jsonObj['dou'];
		}
	}
}