import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'feriados' })
export class FeriadosModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'ano' }) 
	ano: string; 

	@Column({ name: 'nome' }) 
	nome: string; 

	@Column({ name: 'abrangencia' }) 
	abrangencia: string; 

	@Column({ name: 'uf' }) 
	uf: string; 

	@Column({ name: 'municipio_ibge' }) 
	municipioIbge: number; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'data_feriado' }) 
	dataFeriado: Date; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.ano = jsonObj['ano'];
			this.nome = jsonObj['nome'];
			this.abrangencia = jsonObj['abrangencia'];
			this.uf = jsonObj['uf'];
			this.municipioIbge = jsonObj['municipioIbge'];
			this.tipo = jsonObj['tipo'];
			this.dataFeriado = jsonObj['dataFeriado'];
		}
	}
}