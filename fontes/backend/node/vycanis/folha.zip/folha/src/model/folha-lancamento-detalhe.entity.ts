import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaLancamentoCabecalhoModel } from '../entities-export';
import { FolhaEventoModel } from '../entities-export';

@Entity({ name: 'folha_lancamento_detalhe' })
export class FolhaLancamentoDetalheModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'origem', type: 'decimal', precision: 18, scale: 6 }) 
	origem: number; 

	@Column({ name: 'provento', type: 'decimal', precision: 18, scale: 6 }) 
	provento: number; 

	@Column({ name: 'desconto', type: 'decimal', precision: 18, scale: 6 }) 
	desconto: number; 


	/**
	* Relations
	*/
	@ManyToOne(() => FolhaLancamentoCabecalhoModel, folhaLancamentoCabecalhoModel => folhaLancamentoCabecalhoModel.folhaLancamentoDetalheModelList)
	@JoinColumn({ name: 'id_folha_lancamento_cabecalho' })
	folhaLancamentoCabecalhoModel: FolhaLancamentoCabecalhoModel;

	@OneToOne(() => FolhaEventoModel)
	@JoinColumn({ name: 'id_folha_evento' })
	folhaEventoModel: FolhaEventoModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.origem = jsonObj['origem'];
			this.provento = jsonObj['provento'];
			this.desconto = jsonObj['desconto'];
			if (jsonObj['folhaEventoModel'] != null) {
				this.folhaEventoModel = new FolhaEventoModel(jsonObj['folhaEventoModel']);
			}

		}
	}
}