import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'fpas' })
export class FpasModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: number; 

	@Column({ name: 'cnae' }) 
	cnae: string; 

	@Column({ name: 'aliquota_sat' }) 
	aliquotaSat: number; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'percentual_inss_patronal', type: 'decimal', precision: 18, scale: 6 }) 
	percentualInssPatronal: number; 

	@Column({ name: 'codigo_terceiro' }) 
	codigoTerceiro: string; 

	@Column({ name: 'percentual_terceiros', type: 'decimal', precision: 18, scale: 6 }) 
	percentualTerceiros: number; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.cnae = jsonObj['cnae'];
			this.aliquotaSat = jsonObj['aliquotaSat'];
			this.descricao = jsonObj['descricao'];
			this.percentualInssPatronal = jsonObj['percentualInssPatronal'];
			this.codigoTerceiro = jsonObj['codigoTerceiro'];
			this.percentualTerceiros = jsonObj['percentualTerceiros'];
		}
	}
}