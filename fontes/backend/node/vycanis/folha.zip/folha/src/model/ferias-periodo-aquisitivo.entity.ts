import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { ViewPessoaColaboradorModel } from '../entities-export';

@Entity({ name: 'ferias_periodo_aquisitivo' })
export class FeriasPeriodoAquisitivoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'situacao' }) 
	situacao: string; 

	@Column({ name: 'limite_para_gozo' }) 
	limiteParaGozo: Date; 

	@Column({ name: 'descontar_faltas' }) 
	descontarFaltas: string; 

	@Column({ name: 'desconsiderar_afastamento' }) 
	desconsiderarAfastamento: string; 

	@Column({ name: 'afastamento_previdencia' }) 
	afastamentoPrevidencia: number; 

	@Column({ name: 'afastamento_sem_remun' }) 
	afastamentoSemRemun: number; 

	@Column({ name: 'afastamento_com_remun' }) 
	afastamentoComRemun: number; 

	@Column({ name: 'dias_direito' }) 
	diasDireito: number; 

	@Column({ name: 'dias_gozados' }) 
	diasGozados: number; 

	@Column({ name: 'dias_faltas' }) 
	diasFaltas: number; 

	@Column({ name: 'dias_restantes' }) 
	diasRestantes: number; 


	/**
	* Relations
	*/
	@OneToOne(() => ViewPessoaColaboradorModel)
	@JoinColumn({ name: 'id_colaborador' })
	viewPessoaColaboradorModel: ViewPessoaColaboradorModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
			this.situacao = jsonObj['situacao'];
			this.limiteParaGozo = jsonObj['limiteParaGozo'];
			this.descontarFaltas = jsonObj['descontarFaltas'];
			this.desconsiderarAfastamento = jsonObj['desconsiderarAfastamento'];
			this.afastamentoPrevidencia = jsonObj['afastamentoPrevidencia'];
			this.afastamentoSemRemun = jsonObj['afastamentoSemRemun'];
			this.afastamentoComRemun = jsonObj['afastamentoComRemun'];
			this.diasDireito = jsonObj['diasDireito'];
			this.diasGozados = jsonObj['diasGozados'];
			this.diasFaltas = jsonObj['diasFaltas'];
			this.diasRestantes = jsonObj['diasRestantes'];
			if (jsonObj['viewPessoaColaboradorModel'] != null) {
				this.viewPessoaColaboradorModel = new ViewPessoaColaboradorModel(jsonObj['viewPessoaColaboradorModel']);
			}

		}
	}
}