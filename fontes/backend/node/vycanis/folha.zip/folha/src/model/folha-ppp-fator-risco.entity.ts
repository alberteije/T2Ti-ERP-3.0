import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';
import { FolhaPppModel } from '../entities-export';

@Entity({ name: 'folha_ppp_fator_risco' })
export class FolhaPppFatorRiscoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'data_inicio' }) 
	dataInicio: Date; 

	@Column({ name: 'data_fim' }) 
	dataFim: Date; 

	@Column({ name: 'tipo' }) 
	tipo: string; 

	@Column({ name: 'fator_risco' }) 
	fatorRisco: string; 

	@Column({ name: 'intensidade' }) 
	intensidade: string; 

	@Column({ name: 'tecnica_utilizada' }) 
	tecnicaUtilizada: string; 

	@Column({ name: 'epc_eficaz' }) 
	epcEficaz: string; 

	@Column({ name: 'epi_eficaz' }) 
	epiEficaz: string; 

	@Column({ name: 'ca_epi' }) 
	caEpi: number; 

	@Column({ name: 'atendimento_nr06_1' }) 
	atendimentoNr061: string; 

	@Column({ name: 'atendimento_nr06_2' }) 
	atendimentoNr062: string; 

	@Column({ name: 'atendimento_nr06_3' }) 
	atendimentoNr063: string; 

	@Column({ name: 'atendimento_nr06_4' }) 
	atendimentoNr064: string; 

	@Column({ name: 'atendimento_nr06_5' }) 
	atendimentoNr065: string; 


	/**
	* Relations
	*/
	@ManyToOne(() => FolhaPppModel, folhaPppModel => folhaPppModel.folhaPppFatorRiscoModelList)
	@JoinColumn({ name: 'id_folha_ppp' })
	folhaPppModel: FolhaPppModel;


	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.dataInicio = jsonObj['dataInicio'];
			this.dataFim = jsonObj['dataFim'];
			this.tipo = jsonObj['tipo'];
			this.fatorRisco = jsonObj['fatorRisco'];
			this.intensidade = jsonObj['intensidade'];
			this.tecnicaUtilizada = jsonObj['tecnicaUtilizada'];
			this.epcEficaz = jsonObj['epcEficaz'];
			this.epiEficaz = jsonObj['epiEficaz'];
			this.caEpi = jsonObj['caEpi'];
			this.atendimentoNr061 = jsonObj['atendimentoNr061'];
			this.atendimentoNr062 = jsonObj['atendimentoNr062'];
			this.atendimentoNr063 = jsonObj['atendimentoNr063'];
			this.atendimentoNr064 = jsonObj['atendimentoNr064'];
			this.atendimentoNr065 = jsonObj['atendimentoNr065'];
		}
	}
}