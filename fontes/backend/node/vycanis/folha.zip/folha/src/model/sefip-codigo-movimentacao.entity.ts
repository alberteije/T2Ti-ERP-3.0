import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne, ManyToOne, JoinColumn } from 'typeorm';

@Entity({ name: 'sefip_codigo_movimentacao' })
export class SefipCodigoMovimentacaoModel { 

	@PrimaryGeneratedColumn() 
	id: number; 

	@Column({ name: 'codigo' }) 
	codigo: string; 

	@Column({ name: 'descricao' }) 
	descricao: string; 

	@Column({ name: 'aplicacao' }) 
	aplicacao: string; 


	/**
	* Relations
	*/

	/**
	* Constructor
	*/
	constructor(jsonObj: {}) {
		if (jsonObj != null) {
			this.id = jsonObj['id'] == 0 ? undefined : jsonObj['id'];
			this.codigo = jsonObj['codigo'];
			this.descricao = jsonObj['descricao'];
			this.aplicacao = jsonObj['aplicacao'];
		}
	}
}