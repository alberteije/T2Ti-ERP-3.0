abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const orcamentoFluxoCaixaListPage = '/orcamentoFluxoCaixaListPage'; 
	static const orcamentoFluxoCaixaTabPage = '/orcamentoFluxoCaixaTabPage';
	static const orcamentoEmpresarialListPage = '/orcamentoEmpresarialListPage'; 
	static const orcamentoEmpresarialTabPage = '/orcamentoEmpresarialTabPage';
	static const orcamentoFluxoCaixaPeriodoListPage = '/orcamentoFluxoCaixaPeriodoListPage'; 
	static const orcamentoFluxoCaixaPeriodoEditPage = '/orcamentoFluxoCaixaPeriodoEditPage';
	static const orcamentoPeriodoListPage = '/orcamentoPeriodoListPage'; 
	static const orcamentoPeriodoEditPage = '/orcamentoPeriodoEditPage';
}