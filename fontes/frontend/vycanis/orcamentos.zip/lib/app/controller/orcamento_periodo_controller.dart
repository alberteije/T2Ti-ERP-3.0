import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:orcamentos/app/page/shared_widget/input/input_imports.dart';

import 'package:orcamentos/app/page/shared_widget/message_dialog.dart';
import 'package:orcamentos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:orcamentos/app/routes/app_routes.dart';
import 'package:orcamentos/app/controller/controller_imports.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';
import 'package:orcamentos/app/data/repository/orcamento_periodo_repository.dart';

class OrcamentoPeriodoController extends ControllerBase<OrcamentoPeriodoModel, OrcamentoPeriodoRepository> {

  OrcamentoPeriodoController({required super.repository}) {
    dbColumns = OrcamentoPeriodoModel.dbColumns;
    aliasColumns = OrcamentoPeriodoModel.aliasColumns;
    gridColumns = orcamentoPeriodoGridColumns();
    functionName = "orcamento_periodo";
    screenTitle = "Períodos do Orçamento";
  }

  @override
  OrcamentoPeriodoModel createNewModel() => OrcamentoPeriodoModel();

  @override
  final standardFieldForFilter = OrcamentoPeriodoModel.aliasColumns[OrcamentoPeriodoModel.dbColumns.indexOf('periodo')];

  final periodoController = CustomDropdownButtonController('01=Diário');
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['periodo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((orcamentoPeriodo) => orcamentoPeriodo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.orcamentoPeriodoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    periodoController.selected = '01=Diário';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.orcamentoPeriodoEditPage);
  }

  void updateControllersFromModel() {
    periodoController.selected = currentModel.periodo ?? '01=Diário';
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(orcamentoPeriodoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    periodoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}