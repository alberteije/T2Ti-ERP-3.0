import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:orcamentos/app/page/shared_widget/input/input_imports.dart';

import 'package:orcamentos/app/page/shared_widget/message_dialog.dart';
import 'package:orcamentos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:orcamentos/app/routes/app_routes.dart';
import 'package:orcamentos/app/controller/controller_imports.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';
import 'package:orcamentos/app/data/repository/orcamento_fluxo_caixa_periodo_repository.dart';

class OrcamentoFluxoCaixaPeriodoController extends ControllerBase<OrcamentoFluxoCaixaPeriodoModel, OrcamentoFluxoCaixaPeriodoRepository> {

  OrcamentoFluxoCaixaPeriodoController({required super.repository}) {
    dbColumns = OrcamentoFluxoCaixaPeriodoModel.dbColumns;
    aliasColumns = OrcamentoFluxoCaixaPeriodoModel.aliasColumns;
    gridColumns = orcamentoFluxoCaixaPeriodoGridColumns();
    functionName = "orcamento_fluxo_caixa_periodo";
    screenTitle = "Períodos - Fluxo de Caixa";
  }

  @override
  OrcamentoFluxoCaixaPeriodoModel createNewModel() => OrcamentoFluxoCaixaPeriodoModel();

  @override
  final standardFieldForFilter = OrcamentoFluxoCaixaPeriodoModel.aliasColumns[OrcamentoFluxoCaixaPeriodoModel.dbColumns.indexOf('periodo')];

  final bancoContaCaixaModelController = TextEditingController();
  final periodoController = CustomDropdownButtonController('01=Diário');
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['periodo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((orcamentoFluxoCaixaPeriodo) => orcamentoFluxoCaixaPeriodo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.orcamentoFluxoCaixaPeriodoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    bancoContaCaixaModelController.text = '';
    periodoController.selected = '01=Diário';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.orcamentoFluxoCaixaPeriodoEditPage);
  }

  void updateControllersFromModel() {
    bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome?.toString() ?? '';
    periodoController.selected = currentModel.periodo ?? '01=Diário';
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(orcamentoFluxoCaixaPeriodoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callBancoContaCaixaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta/Caixa]'; 
		lookupController.route = '/banco-conta-caixa/'; 
		lookupController.gridColumns = bancoContaCaixaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoContaCaixaModel.aliasColumns; 
		lookupController.dbColumns = BancoContaCaixaModel.dbColumns; 
		lookupController.standardColumn = BancoContaCaixaModel.aliasColumns[BancoContaCaixaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idBancoContaCaixa = plutoRowResult.cells['id']!.value; 
			currentModel.bancoContaCaixaModel = BancoContaCaixaModel.fromPlutoRow(plutoRowResult); 
			bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    bancoContaCaixaModelController.dispose();
    periodoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}