import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:orcamentos/app/routes/app_routes.dart';

import 'package:orcamentos/app/page/page_imports.dart';
import 'package:orcamentos/app/page/shared_widget/message_dialog.dart';
import 'package:orcamentos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:orcamentos/app/controller/controller_imports.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

class OrcamentoDetalheController extends ControllerBase<OrcamentoDetalheModel, void> {

  OrcamentoDetalheController() : super(repository: null) {
    dbColumns = OrcamentoDetalheModel.dbColumns;
    aliasColumns = OrcamentoDetalheModel.aliasColumns;
    gridColumns = orcamentoDetalheGridColumns();
    functionName = "orcamento_detalhe";
    screenTitle = "Itens";
  }

  final _orcamentoDetalheModel = OrcamentoDetalheModel().obs;
  OrcamentoDetalheModel get orcamentoDetalheModel => _orcamentoDetalheModel.value;
  set orcamentoDetalheModel(value) => _orcamentoDetalheModel.value = value ?? OrcamentoDetalheModel();

  List<OrcamentoDetalheModel> get orcamentoDetalheModelList => Get.find<OrcamentoEmpresarialController>().currentModel.orcamentoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final orcamentoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final orcamentoDetalheFormKey = GlobalKey<FormState>();

  @override
  OrcamentoDetalheModel createNewModel() => OrcamentoDetalheModel();

  @override
  final standardFieldForFilter = OrcamentoDetalheModel.aliasColumns[OrcamentoDetalheModel.dbColumns.indexOf('periodo')];

  final finNaturezaFinanceiraModelController = TextEditingController();
  final periodoController = TextEditingController();
  final valorOrcadoController = MoneyMaskedTextController();
  final valorRealizadoController = MoneyMaskedTextController();
  final taxaVariacaoController = MoneyMaskedTextController();
  final valorVariacaoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['periodo'],
    'secondaryColumns': ['valor_orcado'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((orcamentoDetalhe) => orcamentoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(orcamentoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    orcamentoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => OrcamentoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    finNaturezaFinanceiraModelController.text = '';
    periodoController.text = '';
    valorOrcadoController.updateValue(0);
    valorRealizadoController.updateValue(0);
    taxaVariacaoController.updateValue(0);
    valorVariacaoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = orcamentoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    orcamentoDetalheModel = model.clone();
		orcamentoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => OrcamentoDetalheEditPage());
  }

  void updateControllersFromModel() {
    finNaturezaFinanceiraModelController.text = orcamentoDetalheModel.finNaturezaFinanceiraModel?.descricao?.toString() ?? '';
    periodoController.text = orcamentoDetalheModel.periodo ?? '';
    valorOrcadoController.updateValue(orcamentoDetalheModel.valorOrcado ?? 0);
    valorRealizadoController.updateValue(orcamentoDetalheModel.valorRealizado ?? 0);
    taxaVariacaoController.updateValue(orcamentoDetalheModel.taxaVariacao ?? 0);
    valorVariacaoController.updateValue(orcamentoDetalheModel.valorVariacao ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!orcamentoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        orcamentoDetalheModelList.insert(0, orcamentoDetalheModel.clone());
      } else {
        final index = orcamentoDetalheModelList.indexWhere((m) => m.tempId == orcamentoDetalheModel.tempId);
        if (index >= 0) {
          orcamentoDetalheModelList[index] = orcamentoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callFinNaturezaFinanceiraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Natureza Financeira]'; 
		lookupController.route = '/fin-natureza-financeira/'; 
		lookupController.gridColumns = finNaturezaFinanceiraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinNaturezaFinanceiraModel.aliasColumns; 
		lookupController.dbColumns = FinNaturezaFinanceiraModel.dbColumns; 
		lookupController.standardColumn = FinNaturezaFinanceiraModel.aliasColumns[FinNaturezaFinanceiraModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			orcamentoDetalheModel.idFinNaturezaFinanceira = plutoRowResult.cells['id']!.value; 
			orcamentoDetalheModel.finNaturezaFinanceiraModel = FinNaturezaFinanceiraModel.fromPlutoRow(plutoRowResult); 
			finNaturezaFinanceiraModelController.text = orcamentoDetalheModel.finNaturezaFinanceiraModel?.descricao ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      orcamentoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    finNaturezaFinanceiraModelController.dispose();
    periodoController.dispose();
    valorOrcadoController.dispose();
    valorRealizadoController.dispose();
    taxaVariacaoController.dispose();
    valorVariacaoController.dispose();
  }

}