import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:orcamentos/app/page/shared_widget/input/input_imports.dart';

import 'package:orcamentos/app/infra/infra_imports.dart';
import 'package:orcamentos/app/page/page_imports.dart';
import 'package:orcamentos/app/page/shared_widget/message_dialog.dart';
import 'package:orcamentos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:orcamentos/app/routes/app_routes.dart';
import 'package:orcamentos/app/controller/controller_imports.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';
import 'package:orcamentos/app/data/repository/orcamento_empresarial_repository.dart';

class OrcamentoEmpresarialController extends ControllerBase<OrcamentoEmpresarialModel, OrcamentoEmpresarialRepository> 
with GetSingleTickerProviderStateMixin {

  OrcamentoEmpresarialController({required super.repository}) {
    dbColumns = OrcamentoEmpresarialModel.dbColumns;
    aliasColumns = OrcamentoEmpresarialModel.aliasColumns;
    gridColumns = orcamentoEmpresarialGridColumns();
    functionName = "orcamento_empresarial";
    screenTitle = "Orçamento";
  }

  final orcamentoEmpresarialScaffoldKey = GlobalKey<ScaffoldState>();
  final orcamentoEmpresarialTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final orcamentoEmpresarialFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  OrcamentoEmpresarialModel createNewModel() => OrcamentoEmpresarialModel();

  @override
  final standardFieldForFilter = OrcamentoEmpresarialModel.aliasColumns[OrcamentoEmpresarialModel.dbColumns.indexOf('nome')];

  final orcamentoPeriodoModelController = TextEditingController();
  final nomeController = TextEditingController();
  final dataInicialController = DatePickerItemController(null);
  final numeroPeriodosController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataBaseController = DatePickerItemController(null);
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['data_inicial'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((orcamentoEmpresarial) => orcamentoEmpresarial.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.orcamentoEmpresarialTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    orcamentoPeriodoModelController.text = '';
    nomeController.text = '';
    dataInicialController.date = null;
    numeroPeriodosController.updateValue(0);
    dataBaseController.date = null;
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.orcamentoEmpresarialTabPage);
  }

  _configureChildrenControllers() {
    //Itens
		Get.put<OrcamentoDetalheController>(OrcamentoDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Itens
		Get.delete<OrcamentoDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    orcamentoPeriodoModelController.text = currentModel.orcamentoPeriodoModel?.nome?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    dataInicialController.date = currentModel.dataInicial;
    numeroPeriodosController.updateValue((currentModel.numeroPeriodos ?? 0).toDouble());
    dataBaseController.date = currentModel.dataBase;
    descricaoController.text = currentModel.descricao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Itens
		final orcamentoDetalheController = Get.find<OrcamentoDetalheController>(); 
		orcamentoDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(orcamentoEmpresarialModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callOrcamentoPeriodoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Periodo]'; 
		lookupController.route = '/orcamento-periodo/'; 
		lookupController.gridColumns = orcamentoPeriodoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = OrcamentoPeriodoModel.aliasColumns; 
		lookupController.dbColumns = OrcamentoPeriodoModel.dbColumns; 
		lookupController.standardColumn = OrcamentoPeriodoModel.aliasColumns[OrcamentoPeriodoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idOrcamentoPeriodo = plutoRowResult.cells['id']!.value; 
			currentModel.orcamentoPeriodoModel = OrcamentoPeriodoModel.fromPlutoRow(plutoRowResult); 
			orcamentoPeriodoModelController.text = currentModel.orcamentoPeriodoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Orçamento', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens', 
		),
  ];

  List<Widget> tabPages() {
    return [
      OrcamentoEmpresarialEditPage(),
      const OrcamentoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<OrcamentoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.orcamentoPeriodoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Periodo]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    orcamentoPeriodoModelController.dispose();
    nomeController.dispose();
    dataInicialController.dispose();
    numeroPeriodosController.dispose();
    dataBaseController.dispose();
    descricaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}