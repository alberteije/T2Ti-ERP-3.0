import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';


class OrcamentoFluxoCaixaDetalheModel extends ModelBase {
  int? id;
  int? idOrcamentoFluxoCaixa;
  int? idFinNaturezaFinanceira;
  String? periodo;
  double? valorOrcado;
  double? valorRealizado;
  double? taxaVariacao;
  double? valorVariacao;
  FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel;

  OrcamentoFluxoCaixaDetalheModel({
    this.id,
    this.idOrcamentoFluxoCaixa,
    this.idFinNaturezaFinanceira,
    this.periodo,
    this.valorOrcado,
    this.valorRealizado,
    this.taxaVariacao,
    this.valorVariacao,
    FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel,
  }) {
    this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel ?? FinNaturezaFinanceiraModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'periodo',
    'valor_orcado',
    'valor_realizado',
    'taxa_variacao',
    'valor_variacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Periodo',
    'Valor Orcado',
    'Valor Realizado',
    'Taxa Variacao',
    'Valor Variacao',
  ];

  OrcamentoFluxoCaixaDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOrcamentoFluxoCaixa = jsonData['idOrcamentoFluxoCaixa'];
    idFinNaturezaFinanceira = jsonData['idFinNaturezaFinanceira'];
    periodo = jsonData['periodo'];
    valorOrcado = jsonData['valorOrcado']?.toDouble();
    valorRealizado = jsonData['valorRealizado']?.toDouble();
    taxaVariacao = jsonData['taxaVariacao']?.toDouble();
    valorVariacao = jsonData['valorVariacao']?.toDouble();
    finNaturezaFinanceiraModel = jsonData['finNaturezaFinanceiraModel'] == null ? FinNaturezaFinanceiraModel() : FinNaturezaFinanceiraModel.fromJson(jsonData['finNaturezaFinanceiraModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOrcamentoFluxoCaixa'] = idOrcamentoFluxoCaixa != 0 ? idOrcamentoFluxoCaixa : null;
    jsonData['idFinNaturezaFinanceira'] = idFinNaturezaFinanceira != 0 ? idFinNaturezaFinanceira : null;
    jsonData['periodo'] = periodo;
    jsonData['valorOrcado'] = valorOrcado;
    jsonData['valorRealizado'] = valorRealizado;
    jsonData['taxaVariacao'] = taxaVariacao;
    jsonData['valorVariacao'] = valorVariacao;
    jsonData['finNaturezaFinanceiraModel'] = finNaturezaFinanceiraModel?.toJson;
    jsonData['finNaturezaFinanceira'] = finNaturezaFinanceiraModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OrcamentoFluxoCaixaDetalheModel fromPlutoRow(PlutoRow row) {
    return OrcamentoFluxoCaixaDetalheModel(
      id: row.cells['id']?.value,
      idOrcamentoFluxoCaixa: row.cells['idOrcamentoFluxoCaixa']?.value,
      idFinNaturezaFinanceira: row.cells['idFinNaturezaFinanceira']?.value,
      periodo: row.cells['periodo']?.value,
      valorOrcado: row.cells['valorOrcado']?.value,
      valorRealizado: row.cells['valorRealizado']?.value,
      taxaVariacao: row.cells['taxaVariacao']?.value,
      valorVariacao: row.cells['valorVariacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOrcamentoFluxoCaixa': PlutoCell(value: idOrcamentoFluxoCaixa ?? 0),
        'idFinNaturezaFinanceira': PlutoCell(value: idFinNaturezaFinanceira ?? 0),
        'periodo': PlutoCell(value: periodo ?? ''),
        'valorOrcado': PlutoCell(value: valorOrcado ?? 0.0),
        'valorRealizado': PlutoCell(value: valorRealizado ?? 0.0),
        'taxaVariacao': PlutoCell(value: taxaVariacao ?? 0.0),
        'valorVariacao': PlutoCell(value: valorVariacao ?? 0.0),
        'finNaturezaFinanceira': PlutoCell(value: finNaturezaFinanceiraModel?.descricao ?? ''),
      },
    );
  }

  OrcamentoFluxoCaixaDetalheModel clone() {
    return OrcamentoFluxoCaixaDetalheModel(
      id: id,
      idOrcamentoFluxoCaixa: idOrcamentoFluxoCaixa,
      idFinNaturezaFinanceira: idFinNaturezaFinanceira,
      periodo: periodo,
      valorOrcado: valorOrcado,
      valorRealizado: valorRealizado,
      taxaVariacao: taxaVariacao,
      valorVariacao: valorVariacao,
      finNaturezaFinanceiraModel: finNaturezaFinanceiraModel?.clone(),
    );
  }


}