import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

import 'package:orcamentos/app/data/domain/domain_imports.dart';

class OrcamentoFluxoCaixaPeriodoModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  String? periodo;
  String? nome;
  BancoContaCaixaModel? bancoContaCaixaModel;

  OrcamentoFluxoCaixaPeriodoModel({
    this.id,
    this.idBancoContaCaixa,
    this.periodo = '01=Diário',
    this.nome,
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'periodo',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Periodo',
    'Nome',
  ];

  OrcamentoFluxoCaixaPeriodoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    periodo = OrcamentoFluxoCaixaPeriodoDomain.getPeriodo(jsonData['periodo']);
    nome = jsonData['nome'];
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['periodo'] = OrcamentoFluxoCaixaPeriodoDomain.setPeriodo(periodo);
    jsonData['nome'] = nome;
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OrcamentoFluxoCaixaPeriodoModel fromPlutoRow(PlutoRow row) {
    return OrcamentoFluxoCaixaPeriodoModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      periodo: row.cells['periodo']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'periodo': PlutoCell(value: periodo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  OrcamentoFluxoCaixaPeriodoModel clone() {
    return OrcamentoFluxoCaixaPeriodoModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      periodo: periodo,
      nome: nome,
      bancoContaCaixaModel: bancoContaCaixaModel?.clone(),
    );
  }


}