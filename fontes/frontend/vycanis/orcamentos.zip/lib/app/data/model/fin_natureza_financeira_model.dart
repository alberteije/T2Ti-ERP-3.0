import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

import 'package:orcamentos/app/data/domain/domain_imports.dart';

class FinNaturezaFinanceiraModel extends ModelBase {
  int? id;
  String? codigo;
  String? descricao;
  String? tipo;
  String? aplicacao;

  FinNaturezaFinanceiraModel({
    this.id,
    this.codigo = 'AAA',
    this.descricao,
    this.tipo = 'AAA',
    this.aplicacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'descricao',
    'tipo',
    'aplicacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Descricao',
    'Tipo',
    'Aplicacao',
  ];

  FinNaturezaFinanceiraModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = FinNaturezaFinanceiraDomain.getCodigo(jsonData['codigo']);
    descricao = jsonData['descricao'];
    tipo = FinNaturezaFinanceiraDomain.getTipo(jsonData['tipo']);
    aplicacao = jsonData['aplicacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = FinNaturezaFinanceiraDomain.setCodigo(codigo);
    jsonData['descricao'] = descricao;
    jsonData['tipo'] = FinNaturezaFinanceiraDomain.setTipo(tipo);
    jsonData['aplicacao'] = aplicacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinNaturezaFinanceiraModel fromPlutoRow(PlutoRow row) {
    return FinNaturezaFinanceiraModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      descricao: row.cells['descricao']?.value,
      tipo: row.cells['tipo']?.value,
      aplicacao: row.cells['aplicacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'aplicacao': PlutoCell(value: aplicacao ?? ''),
      },
    );
  }

  FinNaturezaFinanceiraModel clone() {
    return FinNaturezaFinanceiraModel(
      id: id,
      codigo: codigo,
      descricao: descricao,
      tipo: tipo,
      aplicacao: aplicacao,
    );
  }


}