import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

import 'package:orcamentos/app/data/domain/domain_imports.dart';

class OrcamentoPeriodoModel extends ModelBase {
  int? id;
  String? periodo;
  String? nome;

  OrcamentoPeriodoModel({
    this.id,
    this.periodo = '01=Diário',
    this.nome,
  });

  static List<String> dbColumns = <String>[
    'id',
    'periodo',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Periodo',
    'Nome',
  ];

  OrcamentoPeriodoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    periodo = OrcamentoPeriodoDomain.getPeriodo(jsonData['periodo']);
    nome = jsonData['nome'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['periodo'] = OrcamentoPeriodoDomain.setPeriodo(periodo);
    jsonData['nome'] = nome;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OrcamentoPeriodoModel fromPlutoRow(PlutoRow row) {
    return OrcamentoPeriodoModel(
      id: row.cells['id']?.value,
      periodo: row.cells['periodo']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'periodo': PlutoCell(value: periodo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
      },
    );
  }

  OrcamentoPeriodoModel clone() {
    return OrcamentoPeriodoModel(
      id: id,
      periodo: periodo,
      nome: nome,
    );
  }


}