import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';


class OrcamentoDetalheModel extends ModelBase {
  int? id;
  int? idOrcamentoEmpresarial;
  int? idFinNaturezaFinanceira;
  String? periodo;
  double? valorOrcado;
  double? valorRealizado;
  double? taxaVariacao;
  double? valorVariacao;
  FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel;

  OrcamentoDetalheModel({
    this.id,
    this.idOrcamentoEmpresarial,
    this.idFinNaturezaFinanceira,
    this.periodo,
    this.valorOrcado,
    this.valorRealizado,
    this.taxaVariacao,
    this.valorVariacao,
    FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel,
  }) {
    this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel ?? FinNaturezaFinanceiraModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'periodo',
    'valor_orcado',
    'valor_realizado',
    'taxa_variacao',
    'valor_variacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Periodo',
    'Valor Orcado',
    'Valor Realizado',
    'Taxa Variacao',
    'Valor Variacao',
  ];

  OrcamentoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOrcamentoEmpresarial = jsonData['idOrcamentoEmpresarial'];
    idFinNaturezaFinanceira = jsonData['idFinNaturezaFinanceira'];
    periodo = jsonData['periodo'];
    valorOrcado = jsonData['valorOrcado']?.toDouble();
    valorRealizado = jsonData['valorRealizado']?.toDouble();
    taxaVariacao = jsonData['taxaVariacao']?.toDouble();
    valorVariacao = jsonData['valorVariacao']?.toDouble();
    finNaturezaFinanceiraModel = jsonData['finNaturezaFinanceiraModel'] == null ? FinNaturezaFinanceiraModel() : FinNaturezaFinanceiraModel.fromJson(jsonData['finNaturezaFinanceiraModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOrcamentoEmpresarial'] = idOrcamentoEmpresarial != 0 ? idOrcamentoEmpresarial : null;
    jsonData['idFinNaturezaFinanceira'] = idFinNaturezaFinanceira != 0 ? idFinNaturezaFinanceira : null;
    jsonData['periodo'] = periodo;
    jsonData['valorOrcado'] = valorOrcado;
    jsonData['valorRealizado'] = valorRealizado;
    jsonData['taxaVariacao'] = taxaVariacao;
    jsonData['valorVariacao'] = valorVariacao;
    jsonData['finNaturezaFinanceiraModel'] = finNaturezaFinanceiraModel?.toJson;
    jsonData['finNaturezaFinanceira'] = finNaturezaFinanceiraModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OrcamentoDetalheModel fromPlutoRow(PlutoRow row) {
    return OrcamentoDetalheModel(
      id: row.cells['id']?.value,
      idOrcamentoEmpresarial: row.cells['idOrcamentoEmpresarial']?.value,
      idFinNaturezaFinanceira: row.cells['idFinNaturezaFinanceira']?.value,
      periodo: row.cells['periodo']?.value,
      valorOrcado: row.cells['valorOrcado']?.value,
      valorRealizado: row.cells['valorRealizado']?.value,
      taxaVariacao: row.cells['taxaVariacao']?.value,
      valorVariacao: row.cells['valorVariacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOrcamentoEmpresarial': PlutoCell(value: idOrcamentoEmpresarial ?? 0),
        'idFinNaturezaFinanceira': PlutoCell(value: idFinNaturezaFinanceira ?? 0),
        'periodo': PlutoCell(value: periodo ?? ''),
        'valorOrcado': PlutoCell(value: valorOrcado ?? 0.0),
        'valorRealizado': PlutoCell(value: valorRealizado ?? 0.0),
        'taxaVariacao': PlutoCell(value: taxaVariacao ?? 0.0),
        'valorVariacao': PlutoCell(value: valorVariacao ?? 0.0),
        'finNaturezaFinanceira': PlutoCell(value: finNaturezaFinanceiraModel?.descricao ?? ''),
      },
    );
  }

  OrcamentoDetalheModel clone() {
    return OrcamentoDetalheModel(
      id: id,
      idOrcamentoEmpresarial: idOrcamentoEmpresarial,
      idFinNaturezaFinanceira: idFinNaturezaFinanceira,
      periodo: periodo,
      valorOrcado: valorOrcado,
      valorRealizado: valorRealizado,
      taxaVariacao: taxaVariacao,
      valorVariacao: valorVariacao,
      finNaturezaFinanceiraModel: finNaturezaFinanceiraModel?.clone(),
    );
  }


}