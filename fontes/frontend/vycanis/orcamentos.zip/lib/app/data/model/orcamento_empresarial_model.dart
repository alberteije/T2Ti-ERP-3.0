import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

import 'package:orcamentos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class OrcamentoEmpresarialModel extends ModelBase {
  int? id;
  int? idOrcamentoPeriodo;
  String? nome;
  DateTime? dataInicial;
  int? numeroPeriodos;
  DateTime? dataBase;
  String? descricao;
  List<OrcamentoDetalheModel>? orcamentoDetalheModelList;
  OrcamentoPeriodoModel? orcamentoPeriodoModel;

  OrcamentoEmpresarialModel({
    this.id,
    this.idOrcamentoPeriodo,
    this.nome,
    this.dataInicial,
    this.numeroPeriodos,
    this.dataBase,
    this.descricao,
    List<OrcamentoDetalheModel>? orcamentoDetalheModelList,
    OrcamentoPeriodoModel? orcamentoPeriodoModel,
  }) {
    this.orcamentoDetalheModelList = orcamentoDetalheModelList?.toList(growable: true) ?? [];
    this.orcamentoPeriodoModel = orcamentoPeriodoModel ?? OrcamentoPeriodoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'data_inicial',
    'numero_periodos',
    'data_base',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Data Inicial',
    'Numero Periodos',
    'Data Base',
    'Descricao',
  ];

  OrcamentoEmpresarialModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOrcamentoPeriodo = jsonData['idOrcamentoPeriodo'];
    nome = jsonData['nome'];
    dataInicial = jsonData['dataInicial'] != null ? DateTime.tryParse(jsonData['dataInicial']) : null;
    numeroPeriodos = jsonData['numeroPeriodos'];
    dataBase = jsonData['dataBase'] != null ? DateTime.tryParse(jsonData['dataBase']) : null;
    descricao = jsonData['descricao'];
    orcamentoDetalheModelList = (jsonData['orcamentoDetalheModelList'] as Iterable?)?.map((m) => OrcamentoDetalheModel.fromJson(m)).toList() ?? [];
    orcamentoPeriodoModel = jsonData['orcamentoPeriodoModel'] == null ? OrcamentoPeriodoModel() : OrcamentoPeriodoModel.fromJson(jsonData['orcamentoPeriodoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOrcamentoPeriodo'] = idOrcamentoPeriodo != 0 ? idOrcamentoPeriodo : null;
    jsonData['nome'] = nome;
    jsonData['dataInicial'] = dataInicial != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicial!) : null;
    jsonData['numeroPeriodos'] = numeroPeriodos;
    jsonData['dataBase'] = dataBase != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataBase!) : null;
    jsonData['descricao'] = descricao;
    
		var orcamentoDetalheModelLocalList = []; 
		for (OrcamentoDetalheModel object in orcamentoDetalheModelList ?? []) { 
			orcamentoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['orcamentoDetalheModelList'] = orcamentoDetalheModelLocalList;
    jsonData['orcamentoPeriodoModel'] = orcamentoPeriodoModel?.toJson;
    jsonData['orcamentoPeriodo'] = orcamentoPeriodoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OrcamentoEmpresarialModel fromPlutoRow(PlutoRow row) {
    return OrcamentoEmpresarialModel(
      id: row.cells['id']?.value,
      idOrcamentoPeriodo: row.cells['idOrcamentoPeriodo']?.value,
      nome: row.cells['nome']?.value,
      dataInicial: Util.stringToDate(row.cells['dataInicial']?.value),
      numeroPeriodos: row.cells['numeroPeriodos']?.value,
      dataBase: Util.stringToDate(row.cells['dataBase']?.value),
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOrcamentoPeriodo': PlutoCell(value: idOrcamentoPeriodo ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'dataInicial': PlutoCell(value: dataInicial),
        'numeroPeriodos': PlutoCell(value: numeroPeriodos ?? 0),
        'dataBase': PlutoCell(value: dataBase),
        'descricao': PlutoCell(value: descricao ?? ''),
        'orcamentoPeriodo': PlutoCell(value: orcamentoPeriodoModel?.nome ?? ''),
      },
    );
  }

  OrcamentoEmpresarialModel clone() {
    return OrcamentoEmpresarialModel(
      id: id,
      idOrcamentoPeriodo: idOrcamentoPeriodo,
      nome: nome,
      dataInicial: dataInicial,
      numeroPeriodos: numeroPeriodos,
      dataBase: dataBase,
      descricao: descricao,
      orcamentoDetalheModelList: orcamentoDetalheModelListClone(orcamentoDetalheModelList!),
      orcamentoPeriodoModel: orcamentoPeriodoModel?.clone(),
    );
  }

  orcamentoDetalheModelListClone(List<OrcamentoDetalheModel> orcamentoDetalheModelList) { 
		List<OrcamentoDetalheModel> resultList = [];
		for (var orcamentoDetalheModel in orcamentoDetalheModelList) {
			resultList.add(orcamentoDetalheModel.clone());
		}
		return resultList;
	}


}