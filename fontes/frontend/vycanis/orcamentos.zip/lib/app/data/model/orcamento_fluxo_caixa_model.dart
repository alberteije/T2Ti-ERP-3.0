import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

import 'package:orcamentos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class OrcamentoFluxoCaixaModel extends ModelBase {
  int? id;
  int? idOrcFluxoCaixaPeriodo;
  String? nome;
  DateTime? dataInicial;
  int? numeroPeriodos;
  DateTime? dataBase;
  String? descricao;
  List<OrcamentoFluxoCaixaDetalheModel>? orcamentoFluxoCaixaDetalheModelList;
  OrcamentoFluxoCaixaPeriodoModel? orcamentoFluxoCaixaPeriodoModel;

  OrcamentoFluxoCaixaModel({
    this.id,
    this.idOrcFluxoCaixaPeriodo,
    this.nome,
    this.dataInicial,
    this.numeroPeriodos,
    this.dataBase,
    this.descricao,
    List<OrcamentoFluxoCaixaDetalheModel>? orcamentoFluxoCaixaDetalheModelList,
    OrcamentoFluxoCaixaPeriodoModel? orcamentoFluxoCaixaPeriodoModel,
  }) {
    this.orcamentoFluxoCaixaDetalheModelList = orcamentoFluxoCaixaDetalheModelList?.toList(growable: true) ?? [];
    this.orcamentoFluxoCaixaPeriodoModel = orcamentoFluxoCaixaPeriodoModel ?? OrcamentoFluxoCaixaPeriodoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'data_inicial',
    'numero_periodos',
    'data_base',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Data Inicial',
    'Numero Periodos',
    'Data Base',
    'Descricao',
  ];

  OrcamentoFluxoCaixaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOrcFluxoCaixaPeriodo = jsonData['idOrcFluxoCaixaPeriodo'];
    nome = jsonData['nome'];
    dataInicial = jsonData['dataInicial'] != null ? DateTime.tryParse(jsonData['dataInicial']) : null;
    numeroPeriodos = jsonData['numeroPeriodos'];
    dataBase = jsonData['dataBase'] != null ? DateTime.tryParse(jsonData['dataBase']) : null;
    descricao = jsonData['descricao'];
    orcamentoFluxoCaixaDetalheModelList = (jsonData['orcamentoFluxoCaixaDetalheModelList'] as Iterable?)?.map((m) => OrcamentoFluxoCaixaDetalheModel.fromJson(m)).toList() ?? [];
    orcamentoFluxoCaixaPeriodoModel = jsonData['orcamentoFluxoCaixaPeriodoModel'] == null ? OrcamentoFluxoCaixaPeriodoModel() : OrcamentoFluxoCaixaPeriodoModel.fromJson(jsonData['orcamentoFluxoCaixaPeriodoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOrcFluxoCaixaPeriodo'] = idOrcFluxoCaixaPeriodo != 0 ? idOrcFluxoCaixaPeriodo : null;
    jsonData['nome'] = nome;
    jsonData['dataInicial'] = dataInicial != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicial!) : null;
    jsonData['numeroPeriodos'] = numeroPeriodos;
    jsonData['dataBase'] = dataBase != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataBase!) : null;
    jsonData['descricao'] = descricao;
    
		var orcamentoFluxoCaixaDetalheModelLocalList = []; 
		for (OrcamentoFluxoCaixaDetalheModel object in orcamentoFluxoCaixaDetalheModelList ?? []) { 
			orcamentoFluxoCaixaDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['orcamentoFluxoCaixaDetalheModelList'] = orcamentoFluxoCaixaDetalheModelLocalList;
    jsonData['orcamentoFluxoCaixaPeriodoModel'] = orcamentoFluxoCaixaPeriodoModel?.toJson;
    jsonData['orcamentoFluxoCaixaPeriodo'] = orcamentoFluxoCaixaPeriodoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OrcamentoFluxoCaixaModel fromPlutoRow(PlutoRow row) {
    return OrcamentoFluxoCaixaModel(
      id: row.cells['id']?.value,
      idOrcFluxoCaixaPeriodo: row.cells['idOrcFluxoCaixaPeriodo']?.value,
      nome: row.cells['nome']?.value,
      dataInicial: Util.stringToDate(row.cells['dataInicial']?.value),
      numeroPeriodos: row.cells['numeroPeriodos']?.value,
      dataBase: Util.stringToDate(row.cells['dataBase']?.value),
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOrcFluxoCaixaPeriodo': PlutoCell(value: idOrcFluxoCaixaPeriodo ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'dataInicial': PlutoCell(value: dataInicial),
        'numeroPeriodos': PlutoCell(value: numeroPeriodos ?? 0),
        'dataBase': PlutoCell(value: dataBase),
        'descricao': PlutoCell(value: descricao ?? ''),
        'orcamentoFluxoCaixaPeriodo': PlutoCell(value: orcamentoFluxoCaixaPeriodoModel?.nome ?? ''),
      },
    );
  }

  OrcamentoFluxoCaixaModel clone() {
    return OrcamentoFluxoCaixaModel(
      id: id,
      idOrcFluxoCaixaPeriodo: idOrcFluxoCaixaPeriodo,
      nome: nome,
      dataInicial: dataInicial,
      numeroPeriodos: numeroPeriodos,
      dataBase: dataBase,
      descricao: descricao,
      orcamentoFluxoCaixaDetalheModelList: orcamentoFluxoCaixaDetalheModelListClone(orcamentoFluxoCaixaDetalheModelList!),
      orcamentoFluxoCaixaPeriodoModel: orcamentoFluxoCaixaPeriodoModel?.clone(),
    );
  }

  orcamentoFluxoCaixaDetalheModelListClone(List<OrcamentoFluxoCaixaDetalheModel> orcamentoFluxoCaixaDetalheModelList) { 
		List<OrcamentoFluxoCaixaDetalheModel> resultList = [];
		for (var orcamentoFluxoCaixaDetalheModel in orcamentoFluxoCaixaDetalheModelList) {
			resultList.add(orcamentoFluxoCaixaDetalheModel.clone());
		}
		return resultList;
	}


}