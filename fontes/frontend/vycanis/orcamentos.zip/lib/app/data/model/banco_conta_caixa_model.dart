import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

import 'package:orcamentos/app/data/domain/domain_imports.dart';

class BancoContaCaixaModel extends ModelBase {
  int? id;
  String? numero;
  String? digito;
  String? nome;
  String? tipo;
  String? descricao;

  BancoContaCaixaModel({
    this.id,
    this.numero,
    this.digito = 'AAA',
    this.nome,
    this.tipo = 'AAA',
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'digito',
    'nome',
    'tipo',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Digito',
    'Nome',
    'Tipo',
    'Descricao',
  ];

  BancoContaCaixaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    numero = jsonData['numero'];
    digito = BancoContaCaixaDomain.getDigito(jsonData['digito']);
    nome = jsonData['nome'];
    tipo = BancoContaCaixaDomain.getTipo(jsonData['tipo']);
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['numero'] = numero;
    jsonData['digito'] = BancoContaCaixaDomain.setDigito(digito);
    jsonData['nome'] = nome;
    jsonData['tipo'] = BancoContaCaixaDomain.setTipo(tipo);
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BancoContaCaixaModel fromPlutoRow(PlutoRow row) {
    return BancoContaCaixaModel(
      id: row.cells['id']?.value,
      numero: row.cells['numero']?.value,
      digito: row.cells['digito']?.value,
      nome: row.cells['nome']?.value,
      tipo: row.cells['tipo']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'digito': PlutoCell(value: digito ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  BancoContaCaixaModel clone() {
    return BancoContaCaixaModel(
      id: id,
      numero: numero,
      digito: digito,
      nome: nome,
      tipo: tipo,
      descricao: descricao,
    );
  }


}