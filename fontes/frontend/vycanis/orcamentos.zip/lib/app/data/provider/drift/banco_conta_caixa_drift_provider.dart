import 'package:orcamentos/app/data/provider/drift/database/database_imports.dart';
import 'package:orcamentos/app/infra/infra_imports.dart';
import 'package:orcamentos/app/data/provider/provider_base.dart';
import 'package:orcamentos/app/data/provider/drift/database/database.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';
import 'package:orcamentos/app/data/domain/domain_imports.dart';

class BancoContaCaixaDriftProvider extends ProviderBase {

	Future<List<BancoContaCaixaModel>?> getList({Filter? filter}) async {
		List<BancoContaCaixaGrouped> bancoContaCaixaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				bancoContaCaixaDriftList = await Session.database.bancoContaCaixaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				bancoContaCaixaDriftList = await Session.database.bancoContaCaixaDao.getGroupedList(); 
			}
			if (bancoContaCaixaDriftList.isNotEmpty) {
				return toListModel(bancoContaCaixaDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<BancoContaCaixaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.bancoContaCaixaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<BancoContaCaixaModel?>? insert(BancoContaCaixaModel bancoContaCaixaModel) async {
		try {
			final lastPk = await Session.database.bancoContaCaixaDao.insertObject(toDrift(bancoContaCaixaModel));
			bancoContaCaixaModel.id = lastPk;
			return bancoContaCaixaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<BancoContaCaixaModel?>? update(BancoContaCaixaModel bancoContaCaixaModel) async {
		try {
			await Session.database.bancoContaCaixaDao.updateObject(toDrift(bancoContaCaixaModel));
			return bancoContaCaixaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.bancoContaCaixaDao.deleteObject(toDrift(BancoContaCaixaModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<BancoContaCaixaModel> toListModel(List<BancoContaCaixaGrouped> bancoContaCaixaDriftList) {
		List<BancoContaCaixaModel> listModel = [];
		for (var bancoContaCaixaDrift in bancoContaCaixaDriftList) {
			listModel.add(toModel(bancoContaCaixaDrift)!);
		}
		return listModel;
	}	

	BancoContaCaixaModel? toModel(BancoContaCaixaGrouped? bancoContaCaixaDrift) {
		if (bancoContaCaixaDrift != null) {
			return BancoContaCaixaModel(
				id: bancoContaCaixaDrift.bancoContaCaixa?.id,
				numero: bancoContaCaixaDrift.bancoContaCaixa?.numero,
				digito: BancoContaCaixaDomain.getDigito(bancoContaCaixaDrift.bancoContaCaixa?.digito),
				nome: bancoContaCaixaDrift.bancoContaCaixa?.nome,
				tipo: BancoContaCaixaDomain.getTipo(bancoContaCaixaDrift.bancoContaCaixa?.tipo),
				descricao: bancoContaCaixaDrift.bancoContaCaixa?.descricao,
			);
		} else {
			return null;
		}
	}


	BancoContaCaixaGrouped toDrift(BancoContaCaixaModel bancoContaCaixaModel) {
		return BancoContaCaixaGrouped(
			bancoContaCaixa: BancoContaCaixa(
				id: bancoContaCaixaModel.id,
				numero: bancoContaCaixaModel.numero,
				digito: BancoContaCaixaDomain.setDigito(bancoContaCaixaModel.digito),
				nome: bancoContaCaixaModel.nome,
				tipo: BancoContaCaixaDomain.setTipo(bancoContaCaixaModel.tipo),
				descricao: bancoContaCaixaModel.descricao,
			),
		);
	}

		
}
