// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'banco_conta_caixa_dao.dart';

// ignore_for_file: type=lint
mixin _$BancoContaCaixaDaoMixin on DatabaseAccessor<AppDatabase> {
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
