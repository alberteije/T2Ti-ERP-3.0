// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_pessoa_usuario_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewPessoaUsuarioDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewPessoaUsuariosTable get viewPessoaUsuarios =>
      attachedDatabase.viewPessoaUsuarios;
}
