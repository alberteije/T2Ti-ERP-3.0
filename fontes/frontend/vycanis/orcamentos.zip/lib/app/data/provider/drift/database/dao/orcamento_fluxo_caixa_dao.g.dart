// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'orcamento_fluxo_caixa_dao.dart';

// ignore_for_file: type=lint
mixin _$OrcamentoFluxoCaixaDaoMixin on DatabaseAccessor<AppDatabase> {
  $OrcamentoFluxoCaixasTable get orcamentoFluxoCaixas =>
      attachedDatabase.orcamentoFluxoCaixas;
  $OrcamentoFluxoCaixaDetalhesTable get orcamentoFluxoCaixaDetalhes =>
      attachedDatabase.orcamentoFluxoCaixaDetalhes;
  $FinNaturezaFinanceirasTable get finNaturezaFinanceiras =>
      attachedDatabase.finNaturezaFinanceiras;
  $OrcamentoFluxoCaixaPeriodosTable get orcamentoFluxoCaixaPeriodos =>
      attachedDatabase.orcamentoFluxoCaixaPeriodos;
}
