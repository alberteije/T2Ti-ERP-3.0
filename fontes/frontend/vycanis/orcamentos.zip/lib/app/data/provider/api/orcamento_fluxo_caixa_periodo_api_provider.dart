import 'package:orcamentos/app/data/provider/api/api_provider_base.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

class OrcamentoFluxoCaixaPeriodoApiProvider extends ApiProviderBase {
  static const _path = '/orcamento-fluxo-caixa-periodo';

  Future<List<OrcamentoFluxoCaixaPeriodoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => OrcamentoFluxoCaixaPeriodoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<OrcamentoFluxoCaixaPeriodoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => OrcamentoFluxoCaixaPeriodoModel.fromJson(json),
    );
  }

  Future<OrcamentoFluxoCaixaPeriodoModel?>? insert(OrcamentoFluxoCaixaPeriodoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => OrcamentoFluxoCaixaPeriodoModel.fromJson(json),
    );
  }

  Future<OrcamentoFluxoCaixaPeriodoModel?>? update(OrcamentoFluxoCaixaPeriodoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => OrcamentoFluxoCaixaPeriodoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
