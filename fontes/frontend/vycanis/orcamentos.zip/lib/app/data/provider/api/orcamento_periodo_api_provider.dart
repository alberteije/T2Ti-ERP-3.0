import 'package:orcamentos/app/data/provider/api/api_provider_base.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

class OrcamentoPeriodoApiProvider extends ApiProviderBase {
  static const _path = '/orcamento-periodo';

  Future<List<OrcamentoPeriodoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => OrcamentoPeriodoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<OrcamentoPeriodoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => OrcamentoPeriodoModel.fromJson(json),
    );
  }

  Future<OrcamentoPeriodoModel?>? insert(OrcamentoPeriodoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => OrcamentoPeriodoModel.fromJson(json),
    );
  }

  Future<OrcamentoPeriodoModel?>? update(OrcamentoPeriodoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => OrcamentoPeriodoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
