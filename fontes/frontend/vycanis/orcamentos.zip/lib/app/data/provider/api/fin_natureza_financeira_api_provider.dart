import 'package:orcamentos/app/data/provider/api/api_provider_base.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

class FinNaturezaFinanceiraApiProvider extends ApiProviderBase {
  static const _path = '/fin-natureza-financeira';

  Future<List<FinNaturezaFinanceiraModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FinNaturezaFinanceiraModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FinNaturezaFinanceiraModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FinNaturezaFinanceiraModel.fromJson(json),
    );
  }

  Future<FinNaturezaFinanceiraModel?>? insert(FinNaturezaFinanceiraModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FinNaturezaFinanceiraModel.fromJson(json),
    );
  }

  Future<FinNaturezaFinanceiraModel?>? update(FinNaturezaFinanceiraModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FinNaturezaFinanceiraModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
