import 'package:orcamentos/app/data/provider/api/api_provider_base.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

class BancoContaCaixaApiProvider extends ApiProviderBase {
  static const _path = '/banco-conta-caixa';

  Future<List<BancoContaCaixaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => BancoContaCaixaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<BancoContaCaixaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => BancoContaCaixaModel.fromJson(json),
    );
  }

  Future<BancoContaCaixaModel?>? insert(BancoContaCaixaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => BancoContaCaixaModel.fromJson(json),
    );
  }

  Future<BancoContaCaixaModel?>? update(BancoContaCaixaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => BancoContaCaixaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
