import 'package:orcamentos/app/data/provider/api/api_provider_base.dart';
import 'package:orcamentos/app/data/model/model_imports.dart';

class OrcamentoEmpresarialApiProvider extends ApiProviderBase {
  static const _path = '/orcamento-empresarial';

  Future<List<OrcamentoEmpresarialModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => OrcamentoEmpresarialModel.fromJson(json),
      filter: filter,
    );
  }

  Future<OrcamentoEmpresarialModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => OrcamentoEmpresarialModel.fromJson(json),
    );
  }

  Future<OrcamentoEmpresarialModel?>? insert(OrcamentoEmpresarialModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => OrcamentoEmpresarialModel.fromJson(json),
    );
  }

  Future<OrcamentoEmpresarialModel?>? update(OrcamentoEmpresarialModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => OrcamentoEmpresarialModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
