import 'package:flutter/material.dart';
import 'package:estoque/app/page/shared_page/list_page_base.dart';
import 'package:estoque/app/page/shared_widget/shared_widget_imports.dart';
import 'package:estoque/app/controller/estoque_reajuste_detalhe_controller.dart';

class EstoqueReajusteDetalheListPage extends ListPageBase<EstoqueReajusteDetalheController> {
  const EstoqueReajusteDetalheListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  List<Widget> standardAppBarActions() { 
    return [];
  }

  @override
  List<Widget> standardBottomActions() { 
    return [
      editButton(onPressed: controller.canUpdate ? controller.editSelectedItem : controller.noPrivilegeMessage),
      deleteButton(onPressed: controller.canDelete ? controller.deleteSelected : controller.noPrivilegeMessage),
      IconButton(
        color: Colors.black,
        tooltip: 'Calcular',
        icon: const Icon(Icons.calculate),
        onPressed: controller.calcularValores,
      ),
    ];
  }

  @override
  PreferredSizeWidget? appBar() { 
    return null;
  }
}