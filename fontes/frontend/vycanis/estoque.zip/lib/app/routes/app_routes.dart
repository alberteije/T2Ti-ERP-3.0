abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const requisicaoInternaCabecalhoListPage = '/requisicaoInternaCabecalhoListPage'; 
	static const requisicaoInternaCabecalhoTabPage = '/requisicaoInternaCabecalhoTabPage';
	static const estoqueReajusteCabecalhoListPage = '/estoqueReajusteCabecalhoListPage'; 
	static const estoqueReajusteCabecalhoTabPage = '/estoqueReajusteCabecalhoTabPage';
	static const estoqueCorListPage = '/estoqueCorListPage'; 
	static const estoqueCorEditPage = '/estoqueCorEditPage';
	static const estoqueTamanhoListPage = '/estoqueTamanhoListPage'; 
	static const estoqueTamanhoEditPage = '/estoqueTamanhoEditPage';
	static const estoqueSaborListPage = '/estoqueSaborListPage'; 
	static const estoqueSaborEditPage = '/estoqueSaborEditPage';
	static const estoqueMarcaListPage = '/estoqueMarcaListPage'; 
	static const estoqueMarcaEditPage = '/estoqueMarcaEditPage';
	static const estoqueGradeListPage = '/estoqueGradeListPage'; 
	static const estoqueGradeEditPage = '/estoqueGradeEditPage';
}