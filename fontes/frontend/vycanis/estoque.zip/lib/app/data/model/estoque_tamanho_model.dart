import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:estoque/app/data/model/model_imports.dart';


class EstoqueTamanhoModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  double? altura;
  double? comprimento;
  double? largura;

  EstoqueTamanhoModel({
    this.id,
    this.codigo,
    this.nome,
    this.altura,
    this.comprimento,
    this.largura,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'altura',
    'comprimento',
    'largura',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Altura',
    'Comprimento',
    'Largura',
  ];

  EstoqueTamanhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    altura = jsonData['altura']?.toDouble();
    comprimento = jsonData['comprimento']?.toDouble();
    largura = jsonData['largura']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['altura'] = altura;
    jsonData['comprimento'] = comprimento;
    jsonData['largura'] = largura;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static EstoqueTamanhoModel fromPlutoRow(PlutoRow row) {
    return EstoqueTamanhoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      altura: row.cells['altura']?.value,
      comprimento: row.cells['comprimento']?.value,
      largura: row.cells['largura']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'altura': PlutoCell(value: altura ?? 0.0),
        'comprimento': PlutoCell(value: comprimento ?? 0.0),
        'largura': PlutoCell(value: largura ?? 0.0),
      },
    );
  }

  EstoqueTamanhoModel clone() {
    return EstoqueTamanhoModel(
      id: id,
      codigo: codigo,
      nome: nome,
      altura: altura,
      comprimento: comprimento,
      largura: largura,
    );
  }

  static EstoqueTamanhoModel cloneFrom(EstoqueTamanhoModel? model) {
    return EstoqueTamanhoModel(
      id: model?.id,
      codigo: model?.codigo,
      nome: model?.nome,
      altura: model?.altura,
      comprimento: model?.comprimento,
      largura: model?.largura,
    );
  }


}