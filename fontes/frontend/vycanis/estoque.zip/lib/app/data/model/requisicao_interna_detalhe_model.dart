import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:estoque/app/data/model/model_imports.dart';


class RequisicaoInternaDetalheModel extends ModelBase {
  int? id;
  int? idRequisicaoInternaCabecalho;
  int? idProduto;
  double? quantidade;
  ProdutoModel? produtoModel;

  RequisicaoInternaDetalheModel({
    this.id,
    this.idRequisicaoInternaCabecalho,
    this.idProduto,
    this.quantidade,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade',
  ];

  RequisicaoInternaDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idRequisicaoInternaCabecalho = jsonData['idRequisicaoInternaCabecalho'];
    idProduto = jsonData['idProduto'];
    quantidade = jsonData['quantidade']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idRequisicaoInternaCabecalho'] = idRequisicaoInternaCabecalho != 0 ? idRequisicaoInternaCabecalho : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['quantidade'] = quantidade;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static RequisicaoInternaDetalheModel fromPlutoRow(PlutoRow row) {
    return RequisicaoInternaDetalheModel(
      id: row.cells['id']?.value,
      idRequisicaoInternaCabecalho: row.cells['idRequisicaoInternaCabecalho']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidade: row.cells['quantidade']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idRequisicaoInternaCabecalho': PlutoCell(value: idRequisicaoInternaCabecalho ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  RequisicaoInternaDetalheModel clone() {
    return RequisicaoInternaDetalheModel(
      id: id,
      idRequisicaoInternaCabecalho: idRequisicaoInternaCabecalho,
      idProduto: idProduto,
      quantidade: quantidade,
      produtoModel: ProdutoModel.cloneFrom(produtoModel),
    );
  }

  static RequisicaoInternaDetalheModel cloneFrom(RequisicaoInternaDetalheModel? model) {
    return RequisicaoInternaDetalheModel(
      id: model?.id,
      idRequisicaoInternaCabecalho: model?.idRequisicaoInternaCabecalho,
      idProduto: model?.idProduto,
      quantidade: model?.quantidade,
      produtoModel: ProdutoModel.cloneFrom(model?.produtoModel),
    );
  }


}