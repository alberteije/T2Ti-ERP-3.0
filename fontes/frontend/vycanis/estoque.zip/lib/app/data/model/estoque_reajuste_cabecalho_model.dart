import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:estoque/app/data/model/model_imports.dart';

import 'package:estoque/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:estoque/app/data/domain/domain_imports.dart';

class EstoqueReajusteCabecalhoModel extends ModelBase {
  int? id;
  int? idColaborador;
  DateTime? dataReajuste;
  double? taxa;
  String? tipoReajuste;
  String? justificativa;
  List<EstoqueReajusteDetalheModel>? estoqueReajusteDetalheModelList;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  EstoqueReajusteCabecalhoModel({
    this.id,
    this.idColaborador,
    this.dataReajuste,
    this.taxa,
    this.tipoReajuste = 'Aumentar',
    this.justificativa,
    List<EstoqueReajusteDetalheModel>? estoqueReajusteDetalheModelList,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.estoqueReajusteDetalheModelList = estoqueReajusteDetalheModelList?.toList(growable: true) ?? [];
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_reajuste',
    'taxa',
    'tipo_reajuste',
    'justificativa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Reajuste',
    'Taxa',
    'Tipo Reajuste',
    'Justificativa',
  ];

  EstoqueReajusteCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    dataReajuste = jsonData['dataReajuste'] != null ? DateTime.tryParse(jsonData['dataReajuste']) : null;
    taxa = jsonData['taxa']?.toDouble();
    tipoReajuste = EstoqueReajusteCabecalhoDomain.getTipoReajuste(jsonData['tipoReajuste']);
    justificativa = jsonData['justificativa'];
    estoqueReajusteDetalheModelList = (jsonData['estoqueReajusteDetalheModelList'] as Iterable?)?.map((m) => EstoqueReajusteDetalheModel.fromJson(m)).toList() ?? [];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['dataReajuste'] = dataReajuste != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataReajuste!) : null;
    jsonData['taxa'] = taxa;
    jsonData['tipoReajuste'] = EstoqueReajusteCabecalhoDomain.setTipoReajuste(tipoReajuste);
    jsonData['justificativa'] = justificativa;
    
		var estoqueReajusteDetalheModelLocalList = []; 
		for (EstoqueReajusteDetalheModel object in estoqueReajusteDetalheModelList ?? []) { 
			estoqueReajusteDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['estoqueReajusteDetalheModelList'] = estoqueReajusteDetalheModelLocalList;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static EstoqueReajusteCabecalhoModel fromPlutoRow(PlutoRow row) {
    return EstoqueReajusteCabecalhoModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      dataReajuste: Util.stringToDate(row.cells['dataReajuste']?.value),
      taxa: row.cells['taxa']?.value,
      tipoReajuste: row.cells['tipoReajuste']?.value,
      justificativa: row.cells['justificativa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'dataReajuste': PlutoCell(value: dataReajuste),
        'taxa': PlutoCell(value: taxa ?? 0.0),
        'tipoReajuste': PlutoCell(value: tipoReajuste ?? ''),
        'justificativa': PlutoCell(value: justificativa ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  EstoqueReajusteCabecalhoModel clone() {
    return EstoqueReajusteCabecalhoModel(
      id: id,
      idColaborador: idColaborador,
      dataReajuste: dataReajuste,
      taxa: taxa,
      tipoReajuste: tipoReajuste,
      justificativa: justificativa,
      estoqueReajusteDetalheModelList: estoqueReajusteDetalheModelListClone(estoqueReajusteDetalheModelList!),
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(viewPessoaColaboradorModel),
    );
  }

  static EstoqueReajusteCabecalhoModel cloneFrom(EstoqueReajusteCabecalhoModel? model) {
    return EstoqueReajusteCabecalhoModel(
      id: model?.id,
      idColaborador: model?.idColaborador,
      dataReajuste: model?.dataReajuste,
      taxa: model?.taxa,
      tipoReajuste: model?.tipoReajuste,
      justificativa: model?.justificativa,
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(model?.viewPessoaColaboradorModel),
    );
  }

  estoqueReajusteDetalheModelListClone(List<EstoqueReajusteDetalheModel> estoqueReajusteDetalheModelList) { 
		List<EstoqueReajusteDetalheModel> resultList = [];
		for (var estoqueReajusteDetalheModel in estoqueReajusteDetalheModelList) {
			resultList.add(EstoqueReajusteDetalheModel.cloneFrom(estoqueReajusteDetalheModel));
		}
		return resultList;
	}


}