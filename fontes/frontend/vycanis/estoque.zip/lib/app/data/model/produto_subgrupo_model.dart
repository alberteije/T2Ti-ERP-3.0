import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:estoque/app/data/model/model_imports.dart';


class ProdutoSubgrupoModel extends ModelBase {
  int? id;
  int? idProdutoGrupo;
  String? nome;
  String? descricao;
  ProdutoGrupoModel? produtoGrupoModel;

  ProdutoSubgrupoModel({
    this.id,
    this.idProdutoGrupo,
    this.nome,
    this.descricao,
    ProdutoGrupoModel? produtoGrupoModel,
  }) {
    this.produtoGrupoModel = produtoGrupoModel ?? ProdutoGrupoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
  ];

  ProdutoSubgrupoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProdutoGrupo = jsonData['idProdutoGrupo'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    produtoGrupoModel = jsonData['produtoGrupoModel'] == null ? ProdutoGrupoModel() : ProdutoGrupoModel.fromJson(jsonData['produtoGrupoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProdutoGrupo'] = idProdutoGrupo != 0 ? idProdutoGrupo : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['produtoGrupoModel'] = produtoGrupoModel?.toJson;
    jsonData['produtoGrupo'] = produtoGrupoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProdutoSubgrupoModel fromPlutoRow(PlutoRow row) {
    return ProdutoSubgrupoModel(
      id: row.cells['id']?.value,
      idProdutoGrupo: row.cells['idProdutoGrupo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProdutoGrupo': PlutoCell(value: idProdutoGrupo ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'produtoGrupo': PlutoCell(value: produtoGrupoModel?.nome ?? ''),
      },
    );
  }

  ProdutoSubgrupoModel clone() {
    return ProdutoSubgrupoModel(
      id: id,
      idProdutoGrupo: idProdutoGrupo,
      nome: nome,
      descricao: descricao,
      produtoGrupoModel: ProdutoGrupoModel.cloneFrom(produtoGrupoModel),
    );
  }

  static ProdutoSubgrupoModel cloneFrom(ProdutoSubgrupoModel? model) {
    return ProdutoSubgrupoModel(
      id: model?.id,
      idProdutoGrupo: model?.idProdutoGrupo,
      nome: model?.nome,
      descricao: model?.descricao,
      produtoGrupoModel: ProdutoGrupoModel.cloneFrom(model?.produtoGrupoModel),
    );
  }


}