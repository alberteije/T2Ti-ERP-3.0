import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:estoque/app/data/model/model_imports.dart';


class EstoqueReajusteDetalheModel extends ModelBase {
  int? id;
  int? idEstoqueReajusteCabecalho;
  int? idProduto;
  double? valorOriginal;
  double? valorReajuste;
  ProdutoModel? produtoModel;

  EstoqueReajusteDetalheModel({
    this.id,
    this.idEstoqueReajusteCabecalho,
    this.idProduto,
    this.valorOriginal,
    this.valorReajuste,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'valor_original',
    'valor_reajuste',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Valor Original',
    'Valor Reajuste',
  ];

  EstoqueReajusteDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idEstoqueReajusteCabecalho = jsonData['idEstoqueReajusteCabecalho'];
    idProduto = jsonData['idProduto'];
    valorOriginal = jsonData['valorOriginal']?.toDouble();
    valorReajuste = jsonData['valorReajuste']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idEstoqueReajusteCabecalho'] = idEstoqueReajusteCabecalho != 0 ? idEstoqueReajusteCabecalho : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['valorOriginal'] = valorOriginal;
    jsonData['valorReajuste'] = valorReajuste;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static EstoqueReajusteDetalheModel fromPlutoRow(PlutoRow row) {
    return EstoqueReajusteDetalheModel(
      id: row.cells['id']?.value,
      idEstoqueReajusteCabecalho: row.cells['idEstoqueReajusteCabecalho']?.value,
      idProduto: row.cells['idProduto']?.value,
      valorOriginal: row.cells['valorOriginal']?.value,
      valorReajuste: row.cells['valorReajuste']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idEstoqueReajusteCabecalho': PlutoCell(value: idEstoqueReajusteCabecalho ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'valorOriginal': PlutoCell(value: valorOriginal ?? 0.0),
        'valorReajuste': PlutoCell(value: valorReajuste ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  EstoqueReajusteDetalheModel clone() {
    return EstoqueReajusteDetalheModel(
      id: id,
      idEstoqueReajusteCabecalho: idEstoqueReajusteCabecalho,
      idProduto: idProduto,
      valorOriginal: valorOriginal,
      valorReajuste: valorReajuste,
      produtoModel: ProdutoModel.cloneFrom(produtoModel),
    );
  }

  static EstoqueReajusteDetalheModel cloneFrom(EstoqueReajusteDetalheModel? model) {
    return EstoqueReajusteDetalheModel(
      id: model?.id,
      idEstoqueReajusteCabecalho: model?.idEstoqueReajusteCabecalho,
      idProduto: model?.idProduto,
      valorOriginal: model?.valorOriginal,
      valorReajuste: model?.valorReajuste,
      produtoModel: ProdutoModel.cloneFrom(model?.produtoModel),
    );
  }


}