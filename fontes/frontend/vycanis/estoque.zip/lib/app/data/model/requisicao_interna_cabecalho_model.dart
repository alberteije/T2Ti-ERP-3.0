import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:estoque/app/data/model/model_imports.dart';

import 'package:estoque/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:estoque/app/data/domain/domain_imports.dart';

class RequisicaoInternaCabecalhoModel extends ModelBase {
  int? id;
  int? idColaborador;
  DateTime? dataRequisicao;
  String? situacao;
  List<RequisicaoInternaDetalheModel>? requisicaoInternaDetalheModelList;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  RequisicaoInternaCabecalhoModel({
    this.id,
    this.idColaborador,
    this.dataRequisicao,
    this.situacao = 'Aberta',
    List<RequisicaoInternaDetalheModel>? requisicaoInternaDetalheModelList,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.requisicaoInternaDetalheModelList = requisicaoInternaDetalheModelList?.toList(growable: true) ?? [];
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_requisicao',
    'situacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Requisicao',
    'Situacao',
  ];

  RequisicaoInternaCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    dataRequisicao = jsonData['dataRequisicao'] != null ? DateTime.tryParse(jsonData['dataRequisicao']) : null;
    situacao = RequisicaoInternaCabecalhoDomain.getSituacao(jsonData['situacao']);
    requisicaoInternaDetalheModelList = (jsonData['requisicaoInternaDetalheModelList'] as Iterable?)?.map((m) => RequisicaoInternaDetalheModel.fromJson(m)).toList() ?? [];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['dataRequisicao'] = dataRequisicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRequisicao!) : null;
    jsonData['situacao'] = RequisicaoInternaCabecalhoDomain.setSituacao(situacao);
    
		var requisicaoInternaDetalheModelLocalList = []; 
		for (RequisicaoInternaDetalheModel object in requisicaoInternaDetalheModelList ?? []) { 
			requisicaoInternaDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['requisicaoInternaDetalheModelList'] = requisicaoInternaDetalheModelLocalList;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static RequisicaoInternaCabecalhoModel fromPlutoRow(PlutoRow row) {
    return RequisicaoInternaCabecalhoModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      dataRequisicao: Util.stringToDate(row.cells['dataRequisicao']?.value),
      situacao: row.cells['situacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'dataRequisicao': PlutoCell(value: dataRequisicao),
        'situacao': PlutoCell(value: situacao ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  RequisicaoInternaCabecalhoModel clone() {
    return RequisicaoInternaCabecalhoModel(
      id: id,
      idColaborador: idColaborador,
      dataRequisicao: dataRequisicao,
      situacao: situacao,
      requisicaoInternaDetalheModelList: requisicaoInternaDetalheModelListClone(requisicaoInternaDetalheModelList!),
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(viewPessoaColaboradorModel),
    );
  }

  static RequisicaoInternaCabecalhoModel cloneFrom(RequisicaoInternaCabecalhoModel? model) {
    return RequisicaoInternaCabecalhoModel(
      id: model?.id,
      idColaborador: model?.idColaborador,
      dataRequisicao: model?.dataRequisicao,
      situacao: model?.situacao,
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(model?.viewPessoaColaboradorModel),
    );
  }

  requisicaoInternaDetalheModelListClone(List<RequisicaoInternaDetalheModel> requisicaoInternaDetalheModelList) { 
		List<RequisicaoInternaDetalheModel> resultList = [];
		for (var requisicaoInternaDetalheModel in requisicaoInternaDetalheModelList) {
			resultList.add(RequisicaoInternaDetalheModel.cloneFrom(requisicaoInternaDetalheModel));
		}
		return resultList;
	}


}