import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:estoque/app/data/model/model_imports.dart';


class EstoqueGradeModel extends ModelBase {
  int? id;
  int? idProduto;
  int? idEstoqueMarca;
  int? idEstoqueSabor;
  int? idEstoqueTamanho;
  int? idEstoqueCor;
  String? codigo;
  double? quantidade;
  ProdutoModel? produtoModel;
  EstoqueCorModel? estoqueCorModel;
  EstoqueTamanhoModel? estoqueTamanhoModel;
  EstoqueSaborModel? estoqueSaborModel;
  EstoqueMarcaModel? estoqueMarcaModel;

  EstoqueGradeModel({
    this.id,
    this.idProduto,
    this.idEstoqueMarca,
    this.idEstoqueSabor,
    this.idEstoqueTamanho,
    this.idEstoqueCor,
    this.codigo,
    this.quantidade,
    ProdutoModel? produtoModel,
    EstoqueCorModel? estoqueCorModel,
    EstoqueTamanhoModel? estoqueTamanhoModel,
    EstoqueSaborModel? estoqueSaborModel,
    EstoqueMarcaModel? estoqueMarcaModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
    this.estoqueCorModel = estoqueCorModel ?? EstoqueCorModel();
    this.estoqueTamanhoModel = estoqueTamanhoModel ?? EstoqueTamanhoModel();
    this.estoqueSaborModel = estoqueSaborModel ?? EstoqueSaborModel();
    this.estoqueMarcaModel = estoqueMarcaModel ?? EstoqueMarcaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'quantidade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Quantidade',
  ];

  EstoqueGradeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProduto = jsonData['idProduto'];
    idEstoqueMarca = jsonData['idEstoqueMarca'];
    idEstoqueSabor = jsonData['idEstoqueSabor'];
    idEstoqueTamanho = jsonData['idEstoqueTamanho'];
    idEstoqueCor = jsonData['idEstoqueCor'];
    codigo = jsonData['codigo'];
    quantidade = jsonData['quantidade']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
    estoqueCorModel = jsonData['estoqueCorModel'] == null ? EstoqueCorModel() : EstoqueCorModel.fromJson(jsonData['estoqueCorModel']);
    estoqueTamanhoModel = jsonData['estoqueTamanhoModel'] == null ? EstoqueTamanhoModel() : EstoqueTamanhoModel.fromJson(jsonData['estoqueTamanhoModel']);
    estoqueSaborModel = jsonData['estoqueSaborModel'] == null ? EstoqueSaborModel() : EstoqueSaborModel.fromJson(jsonData['estoqueSaborModel']);
    estoqueMarcaModel = jsonData['estoqueMarcaModel'] == null ? EstoqueMarcaModel() : EstoqueMarcaModel.fromJson(jsonData['estoqueMarcaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['idEstoqueMarca'] = idEstoqueMarca != 0 ? idEstoqueMarca : null;
    jsonData['idEstoqueSabor'] = idEstoqueSabor != 0 ? idEstoqueSabor : null;
    jsonData['idEstoqueTamanho'] = idEstoqueTamanho != 0 ? idEstoqueTamanho : null;
    jsonData['idEstoqueCor'] = idEstoqueCor != 0 ? idEstoqueCor : null;
    jsonData['codigo'] = codigo;
    jsonData['quantidade'] = quantidade;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';
    jsonData['estoqueCorModel'] = estoqueCorModel?.toJson;
    jsonData['estoqueCor'] = estoqueCorModel?.nome ?? '';
    jsonData['estoqueTamanhoModel'] = estoqueTamanhoModel?.toJson;
    jsonData['estoqueTamanho'] = estoqueTamanhoModel?.nome ?? '';
    jsonData['estoqueSaborModel'] = estoqueSaborModel?.toJson;
    jsonData['estoqueSabor'] = estoqueSaborModel?.nome ?? '';
    jsonData['estoqueMarcaModel'] = estoqueMarcaModel?.toJson;
    jsonData['estoqueMarca'] = estoqueMarcaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static EstoqueGradeModel fromPlutoRow(PlutoRow row) {
    return EstoqueGradeModel(
      id: row.cells['id']?.value,
      idProduto: row.cells['idProduto']?.value,
      idEstoqueMarca: row.cells['idEstoqueMarca']?.value,
      idEstoqueSabor: row.cells['idEstoqueSabor']?.value,
      idEstoqueTamanho: row.cells['idEstoqueTamanho']?.value,
      idEstoqueCor: row.cells['idEstoqueCor']?.value,
      codigo: row.cells['codigo']?.value,
      quantidade: row.cells['quantidade']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'idEstoqueMarca': PlutoCell(value: idEstoqueMarca ?? 0),
        'idEstoqueSabor': PlutoCell(value: idEstoqueSabor ?? 0),
        'idEstoqueTamanho': PlutoCell(value: idEstoqueTamanho ?? 0),
        'idEstoqueCor': PlutoCell(value: idEstoqueCor ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
        'estoqueCor': PlutoCell(value: estoqueCorModel?.nome ?? ''),
        'estoqueTamanho': PlutoCell(value: estoqueTamanhoModel?.nome ?? ''),
        'estoqueSabor': PlutoCell(value: estoqueSaborModel?.nome ?? ''),
        'estoqueMarca': PlutoCell(value: estoqueMarcaModel?.nome ?? ''),
      },
    );
  }

  EstoqueGradeModel clone() {
    return EstoqueGradeModel(
      id: id,
      idProduto: idProduto,
      idEstoqueMarca: idEstoqueMarca,
      idEstoqueSabor: idEstoqueSabor,
      idEstoqueTamanho: idEstoqueTamanho,
      idEstoqueCor: idEstoqueCor,
      codigo: codigo,
      quantidade: quantidade,
      produtoModel: ProdutoModel.cloneFrom(produtoModel),
      estoqueCorModel: EstoqueCorModel.cloneFrom(estoqueCorModel),
      estoqueTamanhoModel: EstoqueTamanhoModel.cloneFrom(estoqueTamanhoModel),
      estoqueSaborModel: EstoqueSaborModel.cloneFrom(estoqueSaborModel),
      estoqueMarcaModel: EstoqueMarcaModel.cloneFrom(estoqueMarcaModel),
    );
  }

  static EstoqueGradeModel cloneFrom(EstoqueGradeModel? model) {
    return EstoqueGradeModel(
      id: model?.id,
      idProduto: model?.idProduto,
      idEstoqueMarca: model?.idEstoqueMarca,
      idEstoqueSabor: model?.idEstoqueSabor,
      idEstoqueTamanho: model?.idEstoqueTamanho,
      idEstoqueCor: model?.idEstoqueCor,
      codigo: model?.codigo,
      quantidade: model?.quantidade,
      produtoModel: ProdutoModel.cloneFrom(model?.produtoModel),
      estoqueCorModel: EstoqueCorModel.cloneFrom(model?.estoqueCorModel),
      estoqueTamanhoModel: EstoqueTamanhoModel.cloneFrom(model?.estoqueTamanhoModel),
      estoqueSaborModel: EstoqueSaborModel.cloneFrom(model?.estoqueSaborModel),
      estoqueMarcaModel: EstoqueMarcaModel.cloneFrom(model?.estoqueMarcaModel),
    );
  }


}