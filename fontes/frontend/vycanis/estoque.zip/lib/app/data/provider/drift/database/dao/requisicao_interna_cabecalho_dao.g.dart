// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'requisicao_interna_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$RequisicaoInternaCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $RequisicaoInternaCabecalhosTable get requisicaoInternaCabecalhos =>
      attachedDatabase.requisicaoInternaCabecalhos;
  $RequisicaoInternaDetalhesTable get requisicaoInternaDetalhes =>
      attachedDatabase.requisicaoInternaDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
