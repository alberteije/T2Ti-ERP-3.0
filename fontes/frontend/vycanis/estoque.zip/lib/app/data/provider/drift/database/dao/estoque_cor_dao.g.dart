// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estoque_cor_dao.dart';

// ignore_for_file: type=lint
mixin _$EstoqueCorDaoMixin on DatabaseAccessor<AppDatabase> {
  $EstoqueCorsTable get estoqueCors => attachedDatabase.estoqueCors;
}
