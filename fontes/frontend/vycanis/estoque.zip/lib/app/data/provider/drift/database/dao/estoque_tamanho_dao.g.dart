// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estoque_tamanho_dao.dart';

// ignore_for_file: type=lint
mixin _$EstoqueTamanhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $EstoqueTamanhosTable get estoqueTamanhos => attachedDatabase.estoqueTamanhos;
}
