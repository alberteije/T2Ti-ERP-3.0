// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'produto_subgrupo_dao.dart';

// ignore_for_file: type=lint
mixin _$ProdutoSubgrupoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProdutoSubgruposTable get produtoSubgrupos =>
      attachedDatabase.produtoSubgrupos;
  $ProdutoGruposTable get produtoGrupos => attachedDatabase.produtoGrupos;
}
