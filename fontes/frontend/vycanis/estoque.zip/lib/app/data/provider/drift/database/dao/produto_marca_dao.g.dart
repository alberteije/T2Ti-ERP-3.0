// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'produto_marca_dao.dart';

// ignore_for_file: type=lint
mixin _$ProdutoMarcaDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProdutoMarcasTable get produtoMarcas => attachedDatabase.produtoMarcas;
}
