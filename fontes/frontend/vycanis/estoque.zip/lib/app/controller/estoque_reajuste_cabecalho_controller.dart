import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:estoque/app/infra/infra_imports.dart';
import 'package:estoque/app/page/page_imports.dart';
import 'package:estoque/app/page/shared_widget/message_dialog.dart';
import 'package:estoque/app/page/grid_columns/grid_columns_imports.dart';
import 'package:estoque/app/routes/app_routes.dart';
import 'package:estoque/app/controller/controller_imports.dart';
import 'package:estoque/app/data/model/model_imports.dart';
import 'package:estoque/app/data/repository/estoque_reajuste_cabecalho_repository.dart';

class EstoqueReajusteCabecalhoController extends ControllerBase<EstoqueReajusteCabecalhoModel, EstoqueReajusteCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  EstoqueReajusteCabecalhoController({required super.repository}) {
    dbColumns = EstoqueReajusteCabecalhoModel.dbColumns;
    aliasColumns = EstoqueReajusteCabecalhoModel.aliasColumns;
    gridColumns = estoqueReajusteCabecalhoGridColumns();
    functionName = "estoque_reajuste_cabecalho";
    screenTitle = "Reajuste de Preços";
  }

  final estoqueReajusteCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final estoqueReajusteCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final estoqueReajusteCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  EstoqueReajusteCabecalhoModel createNewModel() => EstoqueReajusteCabecalhoModel();

  @override
  final standardFieldForFilter = EstoqueReajusteCabecalhoModel.aliasColumns[EstoqueReajusteCabecalhoModel.dbColumns.indexOf('data_reajuste')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final taxaController = MoneyMaskedTextController();
  final justificativaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_reajuste'],
    'secondaryColumns': ['taxa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((estoqueReajusteCabecalho) => estoqueReajusteCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.estoqueReajusteCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    taxaController.updateValue(0);
    justificativaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.estoqueReajusteCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Itens do Reajuste
		Get.put<EstoqueReajusteDetalheController>(EstoqueReajusteDetalheController()); 
		final estoqueReajusteDetalheController = Get.find<EstoqueReajusteDetalheController>(); 
		estoqueReajusteDetalheController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    taxaController.updateValue(currentModel.taxa ?? 0);
    justificativaController.text = currentModel.justificativa ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(estoqueReajusteCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Reajuste de Preços', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens do Reajuste', 
		),
  ];

  List<Widget> tabPages() {
    return [
      EstoqueReajusteCabecalhoEditPage(),
      const EstoqueReajusteDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<EstoqueReajusteDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaColaboradorModelController.dispose();
    taxaController.dispose();
    justificativaController.dispose();
    super.onClose();
  }	
}