import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:estoque/app/infra/infra_imports.dart';
import 'package:estoque/app/page/page_imports.dart';
import 'package:estoque/app/page/shared_widget/message_dialog.dart';
import 'package:estoque/app/page/grid_columns/grid_columns_imports.dart';
import 'package:estoque/app/routes/app_routes.dart';
import 'package:estoque/app/controller/controller_imports.dart';
import 'package:estoque/app/data/model/model_imports.dart';
import 'package:estoque/app/data/repository/requisicao_interna_cabecalho_repository.dart';

class RequisicaoInternaCabecalhoController extends ControllerBase<RequisicaoInternaCabecalhoModel, RequisicaoInternaCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  RequisicaoInternaCabecalhoController({required super.repository}) {
    dbColumns = RequisicaoInternaCabecalhoModel.dbColumns;
    aliasColumns = RequisicaoInternaCabecalhoModel.aliasColumns;
    gridColumns = requisicaoInternaCabecalhoGridColumns();
    functionName = "requisicao_interna_cabecalho";
    screenTitle = "Requisicao Interna";
  }

  final requisicaoInternaCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final requisicaoInternaCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final requisicaoInternaCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  RequisicaoInternaCabecalhoModel createNewModel() => RequisicaoInternaCabecalhoModel();

  @override
  final standardFieldForFilter = RequisicaoInternaCabecalhoModel.aliasColumns[RequisicaoInternaCabecalhoModel.dbColumns.indexOf('data_requisicao')];

  final viewPessoaColaboradorModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_requisicao'],
    'secondaryColumns': ['situacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((requisicaoInternaCabecalho) => requisicaoInternaCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.requisicaoInternaCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.requisicaoInternaCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Itens Requisicao
		Get.put<RequisicaoInternaDetalheController>(RequisicaoInternaDetalheController()); 
		final requisicaoInternaDetalheController = Get.find<RequisicaoInternaDetalheController>(); 
		requisicaoInternaDetalheController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(requisicaoInternaCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Requisicao Interna', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens Requisicao', 
		),
  ];

  List<Widget> tabPages() {
    return [
      RequisicaoInternaCabecalhoEditPage(),
      const RequisicaoInternaDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<RequisicaoInternaDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaColaboradorModelController.dispose();
    super.onClose();
  }	
}