import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:estoque/app/page/shared_widget/message_dialog.dart';
import 'package:estoque/app/page/grid_columns/grid_columns_imports.dart';
import 'package:estoque/app/routes/app_routes.dart';
import 'package:estoque/app/controller/controller_imports.dart';
import 'package:estoque/app/data/model/model_imports.dart';
import 'package:estoque/app/data/repository/estoque_tamanho_repository.dart';

class EstoqueTamanhoController extends ControllerBase<EstoqueTamanhoModel, EstoqueTamanhoRepository> {

  EstoqueTamanhoController({required super.repository}) {
    dbColumns = EstoqueTamanhoModel.dbColumns;
    aliasColumns = EstoqueTamanhoModel.aliasColumns;
    gridColumns = estoqueTamanhoGridColumns();
    functionName = "estoque_tamanho";
    screenTitle = "Tamanhos";
  }

  @override
  EstoqueTamanhoModel createNewModel() => EstoqueTamanhoModel();

  @override
  final standardFieldForFilter = EstoqueTamanhoModel.aliasColumns[EstoqueTamanhoModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final alturaController = MoneyMaskedTextController();
  final comprimentoController = MoneyMaskedTextController();
  final larguraController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((estoqueTamanho) => estoqueTamanho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.estoqueTamanhoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
    alturaController.updateValue(0);
    comprimentoController.updateValue(0);
    larguraController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.estoqueTamanhoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    alturaController.updateValue(currentModel.altura ?? 0);
    comprimentoController.updateValue(currentModel.comprimento ?? 0);
    larguraController.updateValue(currentModel.largura ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(estoqueTamanhoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    alturaController.dispose();
    comprimentoController.dispose();
    larguraController.dispose();
    super.onClose();
  }

}