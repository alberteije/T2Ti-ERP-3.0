import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:estoque/app/routes/app_routes.dart';

import 'package:estoque/app/page/page_imports.dart';
import 'package:estoque/app/page/shared_widget/message_dialog.dart';
import 'package:estoque/app/page/grid_columns/grid_columns_imports.dart';
import 'package:estoque/app/controller/controller_imports.dart';
import 'package:estoque/app/data/model/model_imports.dart';

class EstoqueReajusteDetalheController extends ControllerBase<EstoqueReajusteDetalheModel, void> {

  EstoqueReajusteDetalheController() : super(repository: null) {
    dbColumns = EstoqueReajusteDetalheModel.dbColumns;
    aliasColumns = EstoqueReajusteDetalheModel.aliasColumns;
    gridColumns = estoqueReajusteDetalheGridColumns();
    functionName = "estoque_reajuste_detalhe";
    screenTitle = "Itens do Reajuste";
  }

  final _estoqueReajusteDetalheModel = EstoqueReajusteDetalheModel().obs;
  EstoqueReajusteDetalheModel get estoqueReajusteDetalheModel => _estoqueReajusteDetalheModel.value;
  set estoqueReajusteDetalheModel(value) => _estoqueReajusteDetalheModel.value = value ?? EstoqueReajusteDetalheModel();

  List<EstoqueReajusteDetalheModel> get estoqueReajusteDetalheModelList => Get.find<EstoqueReajusteCabecalhoController>().currentModel.estoqueReajusteDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final estoqueReajusteDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final estoqueReajusteDetalheFormKey = GlobalKey<FormState>();

  @override
  EstoqueReajusteDetalheModel createNewModel() => EstoqueReajusteDetalheModel();

  @override
  final standardFieldForFilter = EstoqueReajusteDetalheModel.aliasColumns[EstoqueReajusteDetalheModel.dbColumns.indexOf('valor_original')];

  final produtoModelController = TextEditingController();
  final valorOriginalController = MoneyMaskedTextController();
  final valorReajusteController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['valor_original'],
    'secondaryColumns': ['valor_reajuste'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((estoqueReajusteDetalhe) => estoqueReajusteDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(estoqueReajusteDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    estoqueReajusteDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => EstoqueReajusteDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    valorOriginalController.updateValue(0);
    valorReajusteController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = estoqueReajusteDetalheModelList.firstWhere((m) => m.tempId == tempId);
    estoqueReajusteDetalheModel = model.clone();
		estoqueReajusteDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => EstoqueReajusteDetalheEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = estoqueReajusteDetalheModel.produtoModel?.nome?.toString() ?? '';
    valorOriginalController.updateValue(estoqueReajusteDetalheModel.valorOriginal ?? 0);
    valorReajusteController.updateValue(estoqueReajusteDetalheModel.valorReajuste ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!estoqueReajusteDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        estoqueReajusteDetalheModelList.insert(0, estoqueReajusteDetalheModel.clone());
      } else {
        final index = estoqueReajusteDetalheModelList.indexWhere((m) => m.tempId == estoqueReajusteDetalheModel.tempId);
        if (index >= 0) {
          estoqueReajusteDetalheModelList[index] = estoqueReajusteDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			estoqueReajusteDetalheModel.idProduto = plutoRowResult.cells['id']!.value; 
			estoqueReajusteDetalheModel.valorOriginal = plutoRowResult.cells['valorVenda']!.value; 
			estoqueReajusteDetalheModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = estoqueReajusteDetalheModel.produtoModel?.nome ?? ''; 
      valorOriginalController.updateValue(plutoRowResult.cells['valorVenda']!.value);
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      estoqueReajusteDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  Future<void> calcularValores() async {
    showQuestionDialog('Deseja ajustar os valores?', () async {
      final taxaReajuste = Get.find<EstoqueReajusteCabecalhoController>().currentModel.taxa ?? 0;
        final tipoReajuste = Get.find<EstoqueReajusteCabecalhoController>().currentModel.tipoReajuste;
        for (var item in estoqueReajusteDetalheModelList) {
          final valorOriginal = item.valorOriginal ?? 0;
          if (tipoReajuste == 'Aumentar') {
            item.valorReajuste = (valorOriginal * taxaReajuste / 100) + valorOriginal;
          } else {
            item.valorReajuste = valorOriginal - (valorOriginal * taxaReajuste / 100);
          }
        }
        await loadData();
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    valorOriginalController.dispose();
    valorReajusteController.dispose();
  }

}