import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:estoque/app/page/shared_widget/message_dialog.dart';
import 'package:estoque/app/page/grid_columns/grid_columns_imports.dart';
import 'package:estoque/app/routes/app_routes.dart';
import 'package:estoque/app/controller/controller_imports.dart';
import 'package:estoque/app/data/model/model_imports.dart';
import 'package:estoque/app/data/repository/estoque_grade_repository.dart';

class EstoqueGradeController extends ControllerBase<EstoqueGradeModel, EstoqueGradeRepository> {

  EstoqueGradeController({required super.repository}) {
    dbColumns = EstoqueGradeModel.dbColumns;
    aliasColumns = EstoqueGradeModel.aliasColumns;
    gridColumns = estoqueGradeGridColumns();
    functionName = "estoque_grade";
    screenTitle = "Grade de Estoque";
  }

  @override
  EstoqueGradeModel createNewModel() => EstoqueGradeModel();

  @override
  final standardFieldForFilter = EstoqueGradeModel.aliasColumns[EstoqueGradeModel.dbColumns.indexOf('codigo')];

  final produtoModelController = TextEditingController();
  final estoqueMarcaModelController = TextEditingController();
  final estoqueSaborModelController = TextEditingController();
  final estoqueTamanhoModelController = TextEditingController();
  final estoqueCorModelController = TextEditingController();
  final codigoController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['quantidade'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((estoqueGrade) => estoqueGrade.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.estoqueGradeEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    produtoModelController.text = '';
    estoqueMarcaModelController.text = '';
    estoqueSaborModelController.text = '';
    estoqueTamanhoModelController.text = '';
    estoqueCorModelController.text = '';
    codigoController.text = '';
    quantidadeController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.estoqueGradeEditPage);
  }

  void updateControllersFromModel() {
    produtoModelController.text = currentModel.produtoModel?.nome?.toString() ?? '';
    estoqueMarcaModelController.text = currentModel.estoqueMarcaModel?.nome?.toString() ?? '';
    estoqueSaborModelController.text = currentModel.estoqueSaborModel?.nome?.toString() ?? '';
    estoqueTamanhoModelController.text = currentModel.estoqueTamanhoModel?.nome?.toString() ?? '';
    estoqueCorModelController.text = currentModel.estoqueCorModel?.nome?.toString() ?? '';
    codigoController.text = currentModel.codigo ?? '';
    quantidadeController.updateValue(currentModel.quantidade ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(estoqueGradeModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProduto = plutoRowResult.cells['id']!.value; 
			currentModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = currentModel.produtoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callEstoqueMarcaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Marca]'; 
		lookupController.route = '/estoque-marca/'; 
		lookupController.gridColumns = estoqueMarcaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = EstoqueMarcaModel.aliasColumns; 
		lookupController.dbColumns = EstoqueMarcaModel.dbColumns; 
		lookupController.standardColumn = EstoqueMarcaModel.aliasColumns[EstoqueMarcaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idEstoqueMarca = plutoRowResult.cells['id']!.value; 
			currentModel.estoqueMarcaModel = EstoqueMarcaModel.fromPlutoRow(plutoRowResult); 
			estoqueMarcaModelController.text = currentModel.estoqueMarcaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callEstoqueSaborLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Sabor]'; 
		lookupController.route = '/estoque-sabor/'; 
		lookupController.gridColumns = estoqueSaborGridColumns(isForLookup: true); 
		lookupController.aliasColumns = EstoqueSaborModel.aliasColumns; 
		lookupController.dbColumns = EstoqueSaborModel.dbColumns; 
		lookupController.standardColumn = EstoqueSaborModel.aliasColumns[EstoqueSaborModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idEstoqueSabor = plutoRowResult.cells['id']!.value; 
			currentModel.estoqueSaborModel = EstoqueSaborModel.fromPlutoRow(plutoRowResult); 
			estoqueSaborModelController.text = currentModel.estoqueSaborModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callEstoqueTamanhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tamanho]'; 
		lookupController.route = '/estoque-tamanho/'; 
		lookupController.gridColumns = estoqueTamanhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = EstoqueTamanhoModel.aliasColumns; 
		lookupController.dbColumns = EstoqueTamanhoModel.dbColumns; 
		lookupController.standardColumn = EstoqueTamanhoModel.aliasColumns[EstoqueTamanhoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idEstoqueTamanho = plutoRowResult.cells['id']!.value; 
			currentModel.estoqueTamanhoModel = EstoqueTamanhoModel.fromPlutoRow(plutoRowResult); 
			estoqueTamanhoModelController.text = currentModel.estoqueTamanhoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callEstoqueCorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cor]'; 
		lookupController.route = '/estoque-cor/'; 
		lookupController.gridColumns = estoqueCorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = EstoqueCorModel.aliasColumns; 
		lookupController.dbColumns = EstoqueCorModel.dbColumns; 
		lookupController.standardColumn = EstoqueCorModel.aliasColumns[EstoqueCorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idEstoqueCor = plutoRowResult.cells['id']!.value; 
			currentModel.estoqueCorModel = EstoqueCorModel.fromPlutoRow(plutoRowResult); 
			estoqueCorModelController.text = currentModel.estoqueCorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    produtoModelController.dispose();
    estoqueMarcaModelController.dispose();
    estoqueSaborModelController.dispose();
    estoqueTamanhoModelController.dispose();
    estoqueCorModelController.dispose();
    codigoController.dispose();
    quantidadeController.dispose();
    super.onClose();
  }

}