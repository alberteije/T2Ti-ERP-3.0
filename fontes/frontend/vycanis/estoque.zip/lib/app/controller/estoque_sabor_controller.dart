import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:estoque/app/page/shared_widget/message_dialog.dart';
import 'package:estoque/app/page/grid_columns/grid_columns_imports.dart';
import 'package:estoque/app/routes/app_routes.dart';
import 'package:estoque/app/controller/controller_imports.dart';
import 'package:estoque/app/data/model/model_imports.dart';
import 'package:estoque/app/data/repository/estoque_sabor_repository.dart';

class EstoqueSaborController extends ControllerBase<EstoqueSaborModel, EstoqueSaborRepository> {

  EstoqueSaborController({required super.repository}) {
    dbColumns = EstoqueSaborModel.dbColumns;
    aliasColumns = EstoqueSaborModel.aliasColumns;
    gridColumns = estoqueSaborGridColumns();
    functionName = "estoque_sabor";
    screenTitle = "Sabores";
  }

  @override
  EstoqueSaborModel createNewModel() => EstoqueSaborModel();

  @override
  final standardFieldForFilter = EstoqueSaborModel.aliasColumns[EstoqueSaborModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((estoqueSabor) => estoqueSabor.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.estoqueSaborEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.estoqueSaborEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(estoqueSaborModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}