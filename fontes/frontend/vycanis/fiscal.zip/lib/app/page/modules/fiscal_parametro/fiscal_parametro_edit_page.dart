import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:fiscal/app/page/shared_widget/shared_widget_imports.dart';
import 'package:fiscal/app/data/domain/domain_imports.dart';
import 'package:fiscal/app/controller/fiscal_parametro_controller.dart';
import 'package:fiscal/app/infra/infra_imports.dart';
import 'package:fiscal/app/page/shared_widget/input/input_imports.dart';

class FiscalParametroEditPage extends StatelessWidget {
	FiscalParametroEditPage({Key? key}) : super(key: key);
	final fiscalParametroController = Get.find<FiscalParametroController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: fiscalParametroController.fiscalParametroScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: fiscalParametroController.fiscalParametroFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: fiscalParametroController.scrollController,
							child: SingleChildScrollView(
								controller: fiscalParametroController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: fiscalParametroController.fiscalEstadualPorteModelController,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Porte Estadual',
																			labelText: 'Porte Estadual',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: fiscalParametroController.callFiscalEstadualPorteLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: fiscalParametroController.fiscalEstadualRegimeModelController,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Regime Estadual',
																			labelText: 'Regime Estadual',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: fiscalParametroController.callFiscalEstadualRegimeLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: fiscalParametroController.fiscalMunicipalRegimeModelController,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Regime Municipal',
																			labelText: 'Regime Municipal',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: fiscalParametroController.callFiscalMunicipalRegimeLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fiscalParametroController.vigenciaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Vigencia',
																labelText: 'Vigencia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fiscalParametroController.currentModel.vigencia = text;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: fiscalParametroController.descricaoVigenciaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao Vigencia',
																labelText: 'Descricao Vigencia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fiscalParametroController.currentModel.descricaoVigencia = text;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.criterioLancamentoController,
															labelText: 'Criterio Lancamento',
															hintText: 'Informe os dados para o campo Criterio Lancamento',
															items: FiscalParametroDomain.criterioLancamentoListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.criterioLancamento = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.apuracaoController,
															labelText: 'Apuracao',
															hintText: 'Informe os dados para o campo Apuracao',
															items: FiscalParametroDomain.apuracaoListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.apuracao = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.microempreeIndividualController,
															labelText: 'Microempree Individual',
															hintText: 'Informe os dados para o campo Microempree Individual',
															items: FiscalParametroDomain.microempreeIndividualListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.microempreeIndividual = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.calcPisCofinsEfdController,
															labelText: 'Calc Pis Cofins Efd',
															hintText: 'Informe os dados para o campo Calc Pis Cofins Efd',
															items: FiscalParametroDomain.calcPisCofinsEfdListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.calcPisCofinsEfd = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 50,
															controller: fiscalParametroController.simplesCodigoAcessoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Simples Codigo Acesso',
																labelText: 'Simples Codigo Acesso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fiscalParametroController.currentModel.simplesCodigoAcesso = text;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.simplesTabelaController,
															labelText: 'Simples Tabela',
															hintText: 'Informe os dados para o campo Simples Tabela',
															items: FiscalParametroDomain.simplesTabelaListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.simplesTabela = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.simplesAtividadeController,
															labelText: 'Simples Atividade',
															hintText: 'Informe os dados para o campo Simples Atividade',
															items: FiscalParametroDomain.simplesAtividadeListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.simplesAtividade = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.perfilSpedController,
															labelText: 'Perfil Sped',
															hintText: 'Informe os dados para o campo Perfil Sped',
															items: FiscalParametroDomain.perfilSpedListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.perfilSped = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.apuracaoConsolidadaController,
															labelText: 'Apuracao Consolidada',
															hintText: 'Informe os dados para o campo Apuracao Consolidada',
															items: FiscalParametroDomain.apuracaoConsolidadaListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.apuracaoConsolidada = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.substituicaoTributariaController,
															labelText: 'Substituicao Tributaria',
															hintText: 'Informe os dados para o campo Substituicao Tributaria',
															items: FiscalParametroDomain.substituicaoTributariaListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.substituicaoTributaria = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fiscalParametroController.formaCalculoIssController,
															labelText: 'Forma Calculo Iss',
															hintText: 'Informe os dados para o campo Forma Calculo Iss',
															items: FiscalParametroDomain.formaCalculoIssListDropdown,
															onChanged: (dynamic newValue) {
																fiscalParametroController.currentModel.formaCalculoIss = newValue;
																fiscalParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
