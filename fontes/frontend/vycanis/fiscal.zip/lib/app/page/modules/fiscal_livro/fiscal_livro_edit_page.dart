import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:fiscal/app/controller/fiscal_livro_controller.dart';
import 'package:fiscal/app/infra/infra_imports.dart';
import 'package:fiscal/app/page/shared_widget/input/input_imports.dart';

class FiscalLivroEditPage extends StatelessWidget {
	FiscalLivroEditPage({Key? key}) : super(key: key);
	final fiscalLivroController = Get.find<FiscalLivroController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: fiscalLivroController.fiscalLivroScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: fiscalLivroController.fiscalLivroFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: fiscalLivroController.scrollController,
							child: SingleChildScrollView(
								controller: fiscalLivroController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: fiscalLivroController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fiscalLivroController.currentModel.descricao = text;
																fiscalLivroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
