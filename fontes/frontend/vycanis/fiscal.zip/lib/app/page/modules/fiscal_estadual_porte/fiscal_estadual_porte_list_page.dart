import 'package:flutter/material.dart';
import 'package:fiscal/app/controller/fiscal_estadual_porte_controller.dart';
import 'package:fiscal/app/page/shared_page/list_page_base.dart';

class FiscalEstadualPorteListPage extends ListPageBase<FiscalEstadualPorteController> {
  const FiscalEstadualPorteListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}