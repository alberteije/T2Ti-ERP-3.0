import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:fiscal/app/page/shared_widget/input/input_imports.dart';

import 'package:fiscal/app/infra/infra_imports.dart';
import 'package:fiscal/app/page/page_imports.dart';
import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/routes/app_routes.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';
import 'package:fiscal/app/data/repository/simples_nacional_cabecalho_repository.dart';

class SimplesNacionalCabecalhoController extends ControllerBase<SimplesNacionalCabecalhoModel, SimplesNacionalCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  SimplesNacionalCabecalhoController({required super.repository}) {
    dbColumns = SimplesNacionalCabecalhoModel.dbColumns;
    aliasColumns = SimplesNacionalCabecalhoModel.aliasColumns;
    gridColumns = simplesNacionalCabecalhoGridColumns();
    functionName = "simples_nacional_cabecalho";
    screenTitle = "Simples Nacional";
  }

  final simplesNacionalCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final simplesNacionalCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final simplesNacionalCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  SimplesNacionalCabecalhoModel createNewModel() => SimplesNacionalCabecalhoModel();

  @override
  final standardFieldForFilter = SimplesNacionalCabecalhoModel.aliasColumns[SimplesNacionalCabecalhoModel.dbColumns.indexOf('vigencia_inicial')];

  final vigenciaInicialController = DatePickerItemController(null);
  final vigenciaFinalController = DatePickerItemController(null);
  final anexoController = TextEditingController();
  final tabelaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['vigencia_inicial'],
    'secondaryColumns': ['vigencia_final'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((simplesNacionalCabecalho) => simplesNacionalCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.simplesNacionalCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    vigenciaInicialController.date = null;
    vigenciaFinalController.date = null;
    anexoController.text = '';
    tabelaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.simplesNacionalCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<SimplesNacionalDetalheController>(SimplesNacionalDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<SimplesNacionalDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    vigenciaInicialController.date = currentModel.vigenciaInicial;
    vigenciaFinalController.date = currentModel.vigenciaFinal;
    anexoController.text = currentModel.anexo ?? '';
    tabelaController.text = currentModel.tabela ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final simplesNacionalDetalheController = Get.find<SimplesNacionalDetalheController>(); 
		simplesNacionalDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(simplesNacionalCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Simples Nacional', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      SimplesNacionalCabecalhoEditPage(),
      const SimplesNacionalDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<SimplesNacionalDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    vigenciaInicialController.dispose();
    vigenciaFinalController.dispose();
    anexoController.dispose();
    tabelaController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}