import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:fiscal/app/infra/infra_imports.dart';
import 'package:fiscal/app/page/page_imports.dart';
import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/routes/app_routes.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';
import 'package:fiscal/app/data/repository/fiscal_livro_repository.dart';

class FiscalLivroController extends ControllerBase<FiscalLivroModel, FiscalLivroRepository> 
with GetSingleTickerProviderStateMixin {

  FiscalLivroController({required super.repository}) {
    dbColumns = FiscalLivroModel.dbColumns;
    aliasColumns = FiscalLivroModel.aliasColumns;
    gridColumns = fiscalLivroGridColumns();
    functionName = "fiscal_livro";
    screenTitle = "Livros";
  }

  final fiscalLivroScaffoldKey = GlobalKey<ScaffoldState>();
  final fiscalLivroTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final fiscalLivroFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  FiscalLivroModel createNewModel() => FiscalLivroModel();

  @override
  final standardFieldForFilter = FiscalLivroModel.aliasColumns[FiscalLivroModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fiscalLivro) => fiscalLivro.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.fiscalLivroTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.fiscalLivroTabPage);
  }

  _configureChildrenControllers() {
    //Termos
		Get.put<FiscalTermoController>(FiscalTermoController()); 

  }
	
	_releaseChildrenControllers() {
    //Termos
		Get.delete<FiscalTermoController>(); 

	}
  
  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Termos
		final fiscalTermoController = Get.find<FiscalTermoController>(); 
		fiscalTermoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(fiscalLivroModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Livros', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Termos', 
		),
  ];

  List<Widget> tabPages() {
    return [
      FiscalLivroEditPage(),
      const FiscalTermoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<FiscalTermoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    descricaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}