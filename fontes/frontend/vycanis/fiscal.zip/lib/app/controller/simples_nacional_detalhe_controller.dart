import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:fiscal/app/page/page_imports.dart';
import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class SimplesNacionalDetalheController extends ControllerBase<SimplesNacionalDetalheModel, void> {

  SimplesNacionalDetalheController() : super(repository: null) {
    dbColumns = SimplesNacionalDetalheModel.dbColumns;
    aliasColumns = SimplesNacionalDetalheModel.aliasColumns;
    gridColumns = simplesNacionalDetalheGridColumns();
    functionName = "simples_nacional_detalhe";
    screenTitle = "Detalhes";
  }

  final _simplesNacionalDetalheModel = SimplesNacionalDetalheModel().obs;
  SimplesNacionalDetalheModel get simplesNacionalDetalheModel => _simplesNacionalDetalheModel.value;
  set simplesNacionalDetalheModel(value) => _simplesNacionalDetalheModel.value = value ?? SimplesNacionalDetalheModel();

  List<SimplesNacionalDetalheModel> get simplesNacionalDetalheModelList => Get.find<SimplesNacionalCabecalhoController>().currentModel.simplesNacionalDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final simplesNacionalDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final simplesNacionalDetalheFormKey = GlobalKey<FormState>();

  @override
  SimplesNacionalDetalheModel createNewModel() => SimplesNacionalDetalheModel();

  @override
  final standardFieldForFilter = SimplesNacionalDetalheModel.aliasColumns[SimplesNacionalDetalheModel.dbColumns.indexOf('faixa')];

  final faixaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorInicialController = MoneyMaskedTextController();
  final valorFinalController = MoneyMaskedTextController();
  final aliquotaController = MoneyMaskedTextController();
  final irpjController = MoneyMaskedTextController();
  final csllController = MoneyMaskedTextController();
  final cofinsController = MoneyMaskedTextController();
  final pisPasepController = MoneyMaskedTextController();
  final cppController = MoneyMaskedTextController();
  final icmsController = MoneyMaskedTextController();
  final ipiController = MoneyMaskedTextController();
  final issController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['faixa'],
    'secondaryColumns': ['valor_inicial'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((simplesNacionalDetalhe) => simplesNacionalDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(simplesNacionalDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    simplesNacionalDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => SimplesNacionalDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    faixaController.updateValue(0);
    valorInicialController.updateValue(0);
    valorFinalController.updateValue(0);
    aliquotaController.updateValue(0);
    irpjController.updateValue(0);
    csllController.updateValue(0);
    cofinsController.updateValue(0);
    pisPasepController.updateValue(0);
    cppController.updateValue(0);
    icmsController.updateValue(0);
    ipiController.updateValue(0);
    issController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = simplesNacionalDetalheModelList.firstWhere((m) => m.tempId == tempId);
    simplesNacionalDetalheModel = model.clone();
		simplesNacionalDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => SimplesNacionalDetalheEditPage());
  }

  void updateControllersFromModel() {
    faixaController.updateValue((simplesNacionalDetalheModel.faixa ?? 0).toDouble());
    valorInicialController.updateValue(simplesNacionalDetalheModel.valorInicial ?? 0);
    valorFinalController.updateValue(simplesNacionalDetalheModel.valorFinal ?? 0);
    aliquotaController.updateValue(simplesNacionalDetalheModel.aliquota ?? 0);
    irpjController.updateValue(simplesNacionalDetalheModel.irpj ?? 0);
    csllController.updateValue(simplesNacionalDetalheModel.csll ?? 0);
    cofinsController.updateValue(simplesNacionalDetalheModel.cofins ?? 0);
    pisPasepController.updateValue(simplesNacionalDetalheModel.pisPasep ?? 0);
    cppController.updateValue(simplesNacionalDetalheModel.cpp ?? 0);
    icmsController.updateValue(simplesNacionalDetalheModel.icms ?? 0);
    ipiController.updateValue(simplesNacionalDetalheModel.ipi ?? 0);
    issController.updateValue(simplesNacionalDetalheModel.iss ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!simplesNacionalDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        simplesNacionalDetalheModelList.insert(0, simplesNacionalDetalheModel.clone());
      } else {
        final index = simplesNacionalDetalheModelList.indexWhere((m) => m.tempId == simplesNacionalDetalheModel.tempId);
        if (index >= 0) {
          simplesNacionalDetalheModelList[index] = simplesNacionalDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      simplesNacionalDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    faixaController.dispose();
    valorInicialController.dispose();
    valorFinalController.dispose();
    aliquotaController.dispose();
    irpjController.dispose();
    csllController.dispose();
    cofinsController.dispose();
    pisPasepController.dispose();
    cppController.dispose();
    icmsController.dispose();
    ipiController.dispose();
    issController.dispose();
  }

}