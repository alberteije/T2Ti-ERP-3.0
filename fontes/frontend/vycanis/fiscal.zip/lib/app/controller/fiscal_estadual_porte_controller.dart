import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fiscal/app/page/shared_widget/input/input_imports.dart';

import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/routes/app_routes.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';
import 'package:fiscal/app/data/repository/fiscal_estadual_porte_repository.dart';

class FiscalEstadualPorteController extends ControllerBase<FiscalEstadualPorteModel, FiscalEstadualPorteRepository> {

  FiscalEstadualPorteController({required super.repository}) {
    dbColumns = FiscalEstadualPorteModel.dbColumns;
    aliasColumns = FiscalEstadualPorteModel.aliasColumns;
    gridColumns = fiscalEstadualPorteGridColumns();
    functionName = "fiscal_estadual_porte";
    screenTitle = "Porte Estadual";
  }

  @override
  FiscalEstadualPorteModel createNewModel() => FiscalEstadualPorteModel();

  @override
  final standardFieldForFilter = FiscalEstadualPorteModel.aliasColumns[FiscalEstadualPorteModel.dbColumns.indexOf('uf')];

  final ufController = CustomDropdownButtonController('AC');
  final codigoController = TextEditingController();
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['uf'],
    'secondaryColumns': ['codigo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fiscalEstadualPorte) => fiscalEstadualPorte.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fiscalEstadualPorteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    ufController.selected = 'AC';
    codigoController.text = '';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fiscalEstadualPorteEditPage);
  }

  void updateControllersFromModel() {
    ufController.selected = currentModel.uf ?? 'AC';
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fiscalEstadualPorteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    ufController.dispose();
    codigoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}