import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/routes/app_routes.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';
import 'package:fiscal/app/data/repository/fiscal_apuracao_icms_repository.dart';

class FiscalApuracaoIcmsController extends ControllerBase<FiscalApuracaoIcmsModel, FiscalApuracaoIcmsRepository> {

  FiscalApuracaoIcmsController({required super.repository}) {
    dbColumns = FiscalApuracaoIcmsModel.dbColumns;
    aliasColumns = FiscalApuracaoIcmsModel.aliasColumns;
    gridColumns = fiscalApuracaoIcmsGridColumns();
    functionName = "fiscal_apuracao_icms";
    screenTitle = "Apuração do ICMS";
  }

  @override
  FiscalApuracaoIcmsModel createNewModel() => FiscalApuracaoIcmsModel();

  @override
  final standardFieldForFilter = FiscalApuracaoIcmsModel.aliasColumns[FiscalApuracaoIcmsModel.dbColumns.indexOf('competencia')];

  final competenciaController = MaskedTextController(mask: '00/0000',);
  final valorTotalDebitoController = MoneyMaskedTextController();
  final valorAjusteDebitoController = MoneyMaskedTextController();
  final valorTotalAjusteDebitoController = MoneyMaskedTextController();
  final valorEstornoCreditoController = MoneyMaskedTextController();
  final valorTotalCreditoController = MoneyMaskedTextController();
  final valorAjusteCreditoController = MoneyMaskedTextController();
  final valorTotalAjusteCreditoController = MoneyMaskedTextController();
  final valorEstornoDebitoController = MoneyMaskedTextController();
  final valorSaldoCredorAnteriorController = MoneyMaskedTextController();
  final valorSaldoApuradoController = MoneyMaskedTextController();
  final valorTotalDeducaoController = MoneyMaskedTextController();
  final valorIcmsRecolherController = MoneyMaskedTextController();
  final valorSaldoCredorTranspController = MoneyMaskedTextController();
  final valorDebitoEspecialController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['valor_total_debito'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fiscalApuracaoIcms) => fiscalApuracaoIcms.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fiscalApuracaoIcmsEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    competenciaController.text = '';
    valorTotalDebitoController.updateValue(0);
    valorAjusteDebitoController.updateValue(0);
    valorTotalAjusteDebitoController.updateValue(0);
    valorEstornoCreditoController.updateValue(0);
    valorTotalCreditoController.updateValue(0);
    valorAjusteCreditoController.updateValue(0);
    valorTotalAjusteCreditoController.updateValue(0);
    valorEstornoDebitoController.updateValue(0);
    valorSaldoCredorAnteriorController.updateValue(0);
    valorSaldoApuradoController.updateValue(0);
    valorTotalDeducaoController.updateValue(0);
    valorIcmsRecolherController.updateValue(0);
    valorSaldoCredorTranspController.updateValue(0);
    valorDebitoEspecialController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fiscalApuracaoIcmsEditPage);
  }

  void updateControllersFromModel() {
    competenciaController.text = currentModel.competencia ?? '';
    valorTotalDebitoController.updateValue(currentModel.valorTotalDebito ?? 0);
    valorAjusteDebitoController.updateValue(currentModel.valorAjusteDebito ?? 0);
    valorTotalAjusteDebitoController.updateValue(currentModel.valorTotalAjusteDebito ?? 0);
    valorEstornoCreditoController.updateValue(currentModel.valorEstornoCredito ?? 0);
    valorTotalCreditoController.updateValue(currentModel.valorTotalCredito ?? 0);
    valorAjusteCreditoController.updateValue(currentModel.valorAjusteCredito ?? 0);
    valorTotalAjusteCreditoController.updateValue(currentModel.valorTotalAjusteCredito ?? 0);
    valorEstornoDebitoController.updateValue(currentModel.valorEstornoDebito ?? 0);
    valorSaldoCredorAnteriorController.updateValue(currentModel.valorSaldoCredorAnterior ?? 0);
    valorSaldoApuradoController.updateValue(currentModel.valorSaldoApurado ?? 0);
    valorTotalDeducaoController.updateValue(currentModel.valorTotalDeducao ?? 0);
    valorIcmsRecolherController.updateValue(currentModel.valorIcmsRecolher ?? 0);
    valorSaldoCredorTranspController.updateValue(currentModel.valorSaldoCredorTransp ?? 0);
    valorDebitoEspecialController.updateValue(currentModel.valorDebitoEspecial ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fiscalApuracaoIcmsModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    competenciaController.dispose();
    valorTotalDebitoController.dispose();
    valorAjusteDebitoController.dispose();
    valorTotalAjusteDebitoController.dispose();
    valorEstornoCreditoController.dispose();
    valorTotalCreditoController.dispose();
    valorAjusteCreditoController.dispose();
    valorTotalAjusteCreditoController.dispose();
    valorEstornoDebitoController.dispose();
    valorSaldoCredorAnteriorController.dispose();
    valorSaldoApuradoController.dispose();
    valorTotalDeducaoController.dispose();
    valorIcmsRecolherController.dispose();
    valorSaldoCredorTranspController.dispose();
    valorDebitoEspecialController.dispose();
    super.onClose();
  }

}