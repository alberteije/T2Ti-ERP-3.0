import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:fiscal/app/page/shared_widget/input/input_imports.dart';

import 'package:fiscal/app/infra/infra_imports.dart';
import 'package:fiscal/app/page/page_imports.dart';
import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/routes/app_routes.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';
import 'package:fiscal/app/data/repository/fiscal_parametro_repository.dart';

class FiscalParametroController extends ControllerBase<FiscalParametroModel, FiscalParametroRepository> 
with GetSingleTickerProviderStateMixin {

  FiscalParametroController({required super.repository}) {
    dbColumns = FiscalParametroModel.dbColumns;
    aliasColumns = FiscalParametroModel.aliasColumns;
    gridColumns = fiscalParametroGridColumns();
    functionName = "fiscal_parametro";
    screenTitle = "Parâmetros";
  }

  final fiscalParametroScaffoldKey = GlobalKey<ScaffoldState>();
  final fiscalParametroTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final fiscalParametroFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  FiscalParametroModel createNewModel() => FiscalParametroModel();

  @override
  final standardFieldForFilter = FiscalParametroModel.aliasColumns[FiscalParametroModel.dbColumns.indexOf('vigencia')];

  final fiscalEstadualPorteModelController = TextEditingController();
  final fiscalEstadualRegimeModelController = TextEditingController();
  final fiscalMunicipalRegimeModelController = TextEditingController();
  final vigenciaController = MaskedTextController(mask: '00/0000',);
  final descricaoVigenciaController = TextEditingController();
  final criterioLancamentoController = CustomDropdownButtonController('Livre');
  final apuracaoController = CustomDropdownButtonController('1-Regime Competencia');
  final microempreeIndividualController = CustomDropdownButtonController('Sim');
  final calcPisCofinsEfdController = CustomDropdownButtonController('AB=Alíquota Básica');
  final simplesCodigoAcessoController = TextEditingController();
  final simplesTabelaController = CustomDropdownButtonController('1=Federal');
  final simplesAtividadeController = CustomDropdownButtonController('Comercio');
  final perfilSpedController = CustomDropdownButtonController('A');
  final apuracaoConsolidadaController = CustomDropdownButtonController('Sim');
  final substituicaoTributariaController = CustomDropdownButtonController('Sim');
  final formaCalculoIssController = CustomDropdownButtonController('Normal');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['vigencia'],
    'secondaryColumns': ['descricao_vigencia'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fiscalParametro) => fiscalParametro.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.fiscalParametroTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    fiscalEstadualPorteModelController.text = '';
    fiscalEstadualRegimeModelController.text = '';
    fiscalMunicipalRegimeModelController.text = '';
    vigenciaController.text = '';
    descricaoVigenciaController.text = '';
    criterioLancamentoController.selected = 'Livre';
    apuracaoController.selected = '1-Regime Competencia';
    microempreeIndividualController.selected = 'Sim';
    calcPisCofinsEfdController.selected = 'AB=Alíquota Básica';
    simplesCodigoAcessoController.text = '';
    simplesTabelaController.selected = '1=Federal';
    simplesAtividadeController.selected = 'Comercio';
    perfilSpedController.selected = 'A';
    apuracaoConsolidadaController.selected = 'Sim';
    substituicaoTributariaController.selected = 'Sim';
    formaCalculoIssController.selected = 'Normal';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.fiscalParametroTabPage);
  }

  _configureChildrenControllers() {
    //Inscrições Substitutas
		Get.put<FiscalInscricoesSubstitutasController>(FiscalInscricoesSubstitutasController()); 

  }
	
	_releaseChildrenControllers() {
    //Inscrições Substitutas
		Get.delete<FiscalInscricoesSubstitutasController>(); 

	}
  
  void updateControllersFromModel() {
    fiscalEstadualPorteModelController.text = currentModel.fiscalEstadualPorteModel?.nome?.toString() ?? '';
    fiscalEstadualRegimeModelController.text = currentModel.fiscalEstadualRegimeModel?.nome?.toString() ?? '';
    fiscalMunicipalRegimeModelController.text = currentModel.fiscalMunicipalRegimeModel?.nome?.toString() ?? '';
    vigenciaController.text = currentModel.vigencia ?? '';
    descricaoVigenciaController.text = currentModel.descricaoVigencia ?? '';
    criterioLancamentoController.selected = currentModel.criterioLancamento ?? 'Livre';
    apuracaoController.selected = currentModel.apuracao ?? '1-Regime Competencia';
    microempreeIndividualController.selected = currentModel.microempreeIndividual ?? 'Sim';
    calcPisCofinsEfdController.selected = currentModel.calcPisCofinsEfd ?? 'AB=Alíquota Básica';
    simplesCodigoAcessoController.text = currentModel.simplesCodigoAcesso ?? '';
    simplesTabelaController.selected = currentModel.simplesTabela ?? '1=Federal';
    simplesAtividadeController.selected = currentModel.simplesAtividade ?? 'Comercio';
    perfilSpedController.selected = currentModel.perfilSped ?? 'A';
    apuracaoConsolidadaController.selected = currentModel.apuracaoConsolidada ?? 'Sim';
    substituicaoTributariaController.selected = currentModel.substituicaoTributaria ?? 'Sim';
    formaCalculoIssController.selected = currentModel.formaCalculoIss ?? 'Normal';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Inscrições Substitutas
		final fiscalInscricoesSubstitutasController = Get.find<FiscalInscricoesSubstitutasController>(); 
		fiscalInscricoesSubstitutasController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(fiscalParametroModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callFiscalEstadualPorteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Porte Estadual]'; 
		lookupController.route = '/fiscal-estadual-porte/'; 
		lookupController.gridColumns = fiscalEstadualPorteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FiscalEstadualPorteModel.aliasColumns; 
		lookupController.dbColumns = FiscalEstadualPorteModel.dbColumns; 
		lookupController.standardColumn = FiscalEstadualPorteModel.aliasColumns[FiscalEstadualPorteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFiscalEstadualPorte = plutoRowResult.cells['id']!.value; 
			currentModel.fiscalEstadualPorteModel = FiscalEstadualPorteModel.fromPlutoRow(plutoRowResult); 
			fiscalEstadualPorteModelController.text = currentModel.fiscalEstadualPorteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFiscalEstadualRegimeLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Regime Estadual]'; 
		lookupController.route = '/fiscal-estadual-regime/'; 
		lookupController.gridColumns = fiscalEstadualRegimeGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FiscalEstadualRegimeModel.aliasColumns; 
		lookupController.dbColumns = FiscalEstadualRegimeModel.dbColumns; 
		lookupController.standardColumn = FiscalEstadualRegimeModel.aliasColumns[FiscalEstadualRegimeModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFiscalEstadualRegime = plutoRowResult.cells['id']!.value; 
			currentModel.fiscalEstadualRegimeModel = FiscalEstadualRegimeModel.fromPlutoRow(plutoRowResult); 
			fiscalEstadualRegimeModelController.text = currentModel.fiscalEstadualRegimeModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFiscalMunicipalRegimeLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Regime Municipal]'; 
		lookupController.route = '/fiscal-municipal-regime/'; 
		lookupController.gridColumns = fiscalMunicipalRegimeGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FiscalMunicipalRegimeModel.aliasColumns; 
		lookupController.dbColumns = FiscalMunicipalRegimeModel.dbColumns; 
		lookupController.standardColumn = FiscalMunicipalRegimeModel.aliasColumns[FiscalMunicipalRegimeModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFiscalMunicipalRegime = plutoRowResult.cells['id']!.value; 
			currentModel.fiscalMunicipalRegimeModel = FiscalMunicipalRegimeModel.fromPlutoRow(plutoRowResult); 
			fiscalMunicipalRegimeModelController.text = currentModel.fiscalMunicipalRegimeModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Parâmetros', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Inscrições Substitutas', 
		),
  ];

  List<Widget> tabPages() {
    return [
      FiscalParametroEditPage(),
      const FiscalInscricoesSubstitutasListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<FiscalInscricoesSubstitutasController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    fiscalEstadualPorteModelController.dispose();
    fiscalEstadualRegimeModelController.dispose();
    fiscalMunicipalRegimeModelController.dispose();
    vigenciaController.dispose();
    descricaoVigenciaController.dispose();
    criterioLancamentoController.dispose();
    apuracaoController.dispose();
    microempreeIndividualController.dispose();
    calcPisCofinsEfdController.dispose();
    simplesCodigoAcessoController.dispose();
    simplesTabelaController.dispose();
    simplesAtividadeController.dispose();
    perfilSpedController.dispose();
    apuracaoConsolidadaController.dispose();
    substituicaoTributariaController.dispose();
    formaCalculoIssController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}