import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/routes/app_routes.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';
import 'package:fiscal/app/data/repository/fiscal_nota_fiscal_saida_repository.dart';

class FiscalNotaFiscalSaidaController extends ControllerBase<FiscalNotaFiscalSaidaModel, FiscalNotaFiscalSaidaRepository> {

  FiscalNotaFiscalSaidaController({required super.repository}) {
    dbColumns = FiscalNotaFiscalSaidaModel.dbColumns;
    aliasColumns = FiscalNotaFiscalSaidaModel.aliasColumns;
    gridColumns = fiscalNotaFiscalSaidaGridColumns();
    functionName = "fiscal_nota_fiscal_saida";
    screenTitle = "Registro de Saídas";
  }

  @override
  FiscalNotaFiscalSaidaModel createNewModel() => FiscalNotaFiscalSaidaModel();

  @override
  final standardFieldForFilter = FiscalNotaFiscalSaidaModel.aliasColumns[FiscalNotaFiscalSaidaModel.dbColumns.indexOf('competencia')];

  final nfeCabecalhoModelController = TextEditingController();
  final competenciaController = MaskedTextController(mask: '00/0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fiscalNotaFiscalSaida) => fiscalNotaFiscalSaida.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fiscalNotaFiscalSaidaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nfeCabecalhoModelController.text = '';
    competenciaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fiscalNotaFiscalSaidaEditPage);
  }

  void updateControllersFromModel() {
    nfeCabecalhoModelController.text = currentModel.nfeCabecalhoModel?.chaveAcesso?.toString() ?? '';
    competenciaController.text = currentModel.competencia ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fiscalNotaFiscalSaidaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callNfeCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [NF-e Cabecalho]'; 
		lookupController.route = '/nfe-cabecalho/'; 
		lookupController.gridColumns = nfeCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = NfeCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = NfeCabecalhoModel.dbColumns; 
		lookupController.standardColumn = NfeCabecalhoModel.aliasColumns[NfeCabecalhoModel.dbColumns.indexOf('chave_acesso')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idNfeCabecalho = plutoRowResult.cells['id']!.value; 
			currentModel.nfeCabecalhoModel = NfeCabecalhoModel.fromPlutoRow(plutoRowResult); 
			nfeCabecalhoModelController.text = currentModel.nfeCabecalhoModel?.chaveAcesso ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    nfeCabecalhoModelController.dispose();
    competenciaController.dispose();
    super.onClose();
  }

}