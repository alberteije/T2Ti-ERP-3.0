import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:fiscal/app/page/shared_widget/input/input_imports.dart';

import 'package:fiscal/app/page/page_imports.dart';
import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class FiscalTermoController extends ControllerBase<FiscalTermoModel, void> {

  FiscalTermoController() : super(repository: null) {
    dbColumns = FiscalTermoModel.dbColumns;
    aliasColumns = FiscalTermoModel.aliasColumns;
    gridColumns = fiscalTermoGridColumns();
    functionName = "fiscal_termo";
    screenTitle = "Termos";
  }

  final _fiscalTermoModel = FiscalTermoModel().obs;
  FiscalTermoModel get fiscalTermoModel => _fiscalTermoModel.value;
  set fiscalTermoModel(value) => _fiscalTermoModel.value = value ?? FiscalTermoModel();

  List<FiscalTermoModel> get fiscalTermoModelList => Get.find<FiscalLivroController>().currentModel.fiscalTermoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final fiscalTermoScaffoldKey = GlobalKey<ScaffoldState>();
  final fiscalTermoFormKey = GlobalKey<FormState>();

  @override
  FiscalTermoModel createNewModel() => FiscalTermoModel();

  @override
  final standardFieldForFilter = FiscalTermoModel.aliasColumns[FiscalTermoModel.dbColumns.indexOf('abertura_encerramento')];

  final aberturaEncerramentoController = CustomDropdownButtonController('Abertura');
  final numeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final paginaInicialController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final paginaFinalController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final numeroRegistroController = TextEditingController();
  final registradoController = TextEditingController();
  final dataDespachoController = DatePickerItemController(null);
  final dataAberturaController = DatePickerItemController(null);
  final dataEncerramentoController = DatePickerItemController(null);
  final escrituracaoInicioController = DatePickerItemController(null);
  final escrituracaoFimController = DatePickerItemController(null);
  final textoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['abertura_encerramento'],
    'secondaryColumns': ['numero'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fiscalTermo) => fiscalTermo.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(fiscalTermoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    fiscalTermoModel = createNewModel();
    _resetForm();
    Get.to(() => FiscalTermoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    aberturaEncerramentoController.selected = 'Abertura';
    numeroController.updateValue(0);
    paginaInicialController.updateValue(0);
    paginaFinalController.updateValue(0);
    numeroRegistroController.text = '';
    registradoController.text = '';
    dataDespachoController.date = null;
    dataAberturaController.date = null;
    dataEncerramentoController.date = null;
    escrituracaoInicioController.date = null;
    escrituracaoFimController.date = null;
    textoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = fiscalTermoModelList.firstWhere((m) => m.tempId == tempId);
    fiscalTermoModel = model.clone();
		fiscalTermoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FiscalTermoEditPage());
  }

  void updateControllersFromModel() {
    aberturaEncerramentoController.selected = fiscalTermoModel.aberturaEncerramento ?? 'Abertura';
    numeroController.updateValue((fiscalTermoModel.numero ?? 0).toDouble());
    paginaInicialController.updateValue((fiscalTermoModel.paginaInicial ?? 0).toDouble());
    paginaFinalController.updateValue((fiscalTermoModel.paginaFinal ?? 0).toDouble());
    numeroRegistroController.text = fiscalTermoModel.numeroRegistro ?? '';
    registradoController.text = fiscalTermoModel.registrado ?? '';
    dataDespachoController.date = fiscalTermoModel.dataDespacho;
    dataAberturaController.date = fiscalTermoModel.dataAbertura;
    dataEncerramentoController.date = fiscalTermoModel.dataEncerramento;
    escrituracaoInicioController.date = fiscalTermoModel.escrituracaoInicio;
    escrituracaoFimController.date = fiscalTermoModel.escrituracaoFim;
    textoController.text = fiscalTermoModel.texto ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!fiscalTermoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        fiscalTermoModelList.insert(0, fiscalTermoModel.clone());
      } else {
        final index = fiscalTermoModelList.indexWhere((m) => m.tempId == fiscalTermoModel.tempId);
        if (index >= 0) {
          fiscalTermoModelList[index] = fiscalTermoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      fiscalTermoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    aberturaEncerramentoController.dispose();
    numeroController.dispose();
    paginaInicialController.dispose();
    paginaFinalController.dispose();
    numeroRegistroController.dispose();
    registradoController.dispose();
    dataDespachoController.dispose();
    dataAberturaController.dispose();
    dataEncerramentoController.dispose();
    escrituracaoInicioController.dispose();
    escrituracaoFimController.dispose();
    textoController.dispose();
  }

}