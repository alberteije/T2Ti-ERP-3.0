import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:fiscal/app/page/shared_widget/message_dialog.dart';
import 'package:fiscal/app/page/grid_columns/grid_columns_imports.dart';
import 'package:fiscal/app/routes/app_routes.dart';
import 'package:fiscal/app/controller/controller_imports.dart';
import 'package:fiscal/app/data/model/model_imports.dart';
import 'package:fiscal/app/data/repository/fiscal_nota_fiscal_entrada_repository.dart';

class FiscalNotaFiscalEntradaController extends ControllerBase<FiscalNotaFiscalEntradaModel, FiscalNotaFiscalEntradaRepository> {

  FiscalNotaFiscalEntradaController({required super.repository}) {
    dbColumns = FiscalNotaFiscalEntradaModel.dbColumns;
    aliasColumns = FiscalNotaFiscalEntradaModel.aliasColumns;
    gridColumns = fiscalNotaFiscalEntradaGridColumns();
    functionName = "fiscal_nota_fiscal_entrada";
    screenTitle = "Registro de Entradas";
  }

  @override
  FiscalNotaFiscalEntradaModel createNewModel() => FiscalNotaFiscalEntradaModel();

  @override
  final standardFieldForFilter = FiscalNotaFiscalEntradaModel.aliasColumns[FiscalNotaFiscalEntradaModel.dbColumns.indexOf('competencia')];

  final nfeCabecalhoModelController = TextEditingController();
  final competenciaController = MaskedTextController(mask: '00/0000',);
  final cfopEntradaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorRateioFreteController = MoneyMaskedTextController();
  final valorCustoMedioController = MoneyMaskedTextController();
  final valorIcmsAntecipadoController = MoneyMaskedTextController();
  final valorBcIcmsAntecipadoController = MoneyMaskedTextController();
  final valorBcIcmsCreditadoController = MoneyMaskedTextController();
  final valorBcPisCreditadoController = MoneyMaskedTextController();
  final valorBcCofinsCreditadoController = MoneyMaskedTextController();
  final valorBcIpiCreditadoController = MoneyMaskedTextController();
  final cstCreditoIcmsController = TextEditingController();
  final cstCreditoPisController = TextEditingController();
  final cstCreditoCofinsController = TextEditingController();
  final cstCreditoIpiController = TextEditingController();
  final valorIcmsCreditadoController = MoneyMaskedTextController();
  final valorPisCreditadoController = MoneyMaskedTextController();
  final valorCofinsCreditadoController = MoneyMaskedTextController();
  final valorIpiCreditadoController = MoneyMaskedTextController();
  final qtdeParcelaCreditoPisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final qtdeParcelaCreditoCofinsController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final qtdeParcelaCreditoIcmsController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final qtdeParcelaCreditoIpiController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final aliquotaCreditoIcmsController = MoneyMaskedTextController();
  final aliquotaCreditoPisController = MoneyMaskedTextController();
  final aliquotaCreditoCofinsController = MoneyMaskedTextController();
  final aliquotaCreditoIpiController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['cfop_entrada'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fiscalNotaFiscalEntrada) => fiscalNotaFiscalEntrada.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fiscalNotaFiscalEntradaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nfeCabecalhoModelController.text = '';
    competenciaController.text = '';
    cfopEntradaController.updateValue(0);
    valorRateioFreteController.updateValue(0);
    valorCustoMedioController.updateValue(0);
    valorIcmsAntecipadoController.updateValue(0);
    valorBcIcmsAntecipadoController.updateValue(0);
    valorBcIcmsCreditadoController.updateValue(0);
    valorBcPisCreditadoController.updateValue(0);
    valorBcCofinsCreditadoController.updateValue(0);
    valorBcIpiCreditadoController.updateValue(0);
    cstCreditoIcmsController.text = '';
    cstCreditoPisController.text = '';
    cstCreditoCofinsController.text = '';
    cstCreditoIpiController.text = '';
    valorIcmsCreditadoController.updateValue(0);
    valorPisCreditadoController.updateValue(0);
    valorCofinsCreditadoController.updateValue(0);
    valorIpiCreditadoController.updateValue(0);
    qtdeParcelaCreditoPisController.updateValue(0);
    qtdeParcelaCreditoCofinsController.updateValue(0);
    qtdeParcelaCreditoIcmsController.updateValue(0);
    qtdeParcelaCreditoIpiController.updateValue(0);
    aliquotaCreditoIcmsController.updateValue(0);
    aliquotaCreditoPisController.updateValue(0);
    aliquotaCreditoCofinsController.updateValue(0);
    aliquotaCreditoIpiController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fiscalNotaFiscalEntradaEditPage);
  }

  void updateControllersFromModel() {
    nfeCabecalhoModelController.text = currentModel.nfeCabecalhoModel?.chaveAcesso?.toString() ?? '';
    competenciaController.text = currentModel.competencia ?? '';
    cfopEntradaController.updateValue((currentModel.cfopEntrada ?? 0).toDouble());
    valorRateioFreteController.updateValue(currentModel.valorRateioFrete ?? 0);
    valorCustoMedioController.updateValue(currentModel.valorCustoMedio ?? 0);
    valorIcmsAntecipadoController.updateValue(currentModel.valorIcmsAntecipado ?? 0);
    valorBcIcmsAntecipadoController.updateValue(currentModel.valorBcIcmsAntecipado ?? 0);
    valorBcIcmsCreditadoController.updateValue(currentModel.valorBcIcmsCreditado ?? 0);
    valorBcPisCreditadoController.updateValue(currentModel.valorBcPisCreditado ?? 0);
    valorBcCofinsCreditadoController.updateValue(currentModel.valorBcCofinsCreditado ?? 0);
    valorBcIpiCreditadoController.updateValue(currentModel.valorBcIpiCreditado ?? 0);
    cstCreditoIcmsController.text = currentModel.cstCreditoIcms ?? '';
    cstCreditoPisController.text = currentModel.cstCreditoPis ?? '';
    cstCreditoCofinsController.text = currentModel.cstCreditoCofins ?? '';
    cstCreditoIpiController.text = currentModel.cstCreditoIpi ?? '';
    valorIcmsCreditadoController.updateValue(currentModel.valorIcmsCreditado ?? 0);
    valorPisCreditadoController.updateValue(currentModel.valorPisCreditado ?? 0);
    valorCofinsCreditadoController.updateValue(currentModel.valorCofinsCreditado ?? 0);
    valorIpiCreditadoController.updateValue(currentModel.valorIpiCreditado ?? 0);
    qtdeParcelaCreditoPisController.updateValue((currentModel.qtdeParcelaCreditoPis ?? 0).toDouble());
    qtdeParcelaCreditoCofinsController.updateValue((currentModel.qtdeParcelaCreditoCofins ?? 0).toDouble());
    qtdeParcelaCreditoIcmsController.updateValue((currentModel.qtdeParcelaCreditoIcms ?? 0).toDouble());
    qtdeParcelaCreditoIpiController.updateValue((currentModel.qtdeParcelaCreditoIpi ?? 0).toDouble());
    aliquotaCreditoIcmsController.updateValue(currentModel.aliquotaCreditoIcms ?? 0);
    aliquotaCreditoPisController.updateValue(currentModel.aliquotaCreditoPis ?? 0);
    aliquotaCreditoCofinsController.updateValue(currentModel.aliquotaCreditoCofins ?? 0);
    aliquotaCreditoIpiController.updateValue(currentModel.aliquotaCreditoIpi ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fiscalNotaFiscalEntradaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callNfeCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [NFe Cabecalho]'; 
		lookupController.route = '/nfe-cabecalho/'; 
		lookupController.gridColumns = nfeCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = NfeCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = NfeCabecalhoModel.dbColumns; 
		lookupController.standardColumn = NfeCabecalhoModel.aliasColumns[NfeCabecalhoModel.dbColumns.indexOf('chave_acesso')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idNfeCabecalho = plutoRowResult.cells['id']!.value; 
			currentModel.nfeCabecalhoModel = NfeCabecalhoModel.fromPlutoRow(plutoRowResult); 
			nfeCabecalhoModelController.text = currentModel.nfeCabecalhoModel?.chaveAcesso ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    nfeCabecalhoModelController.dispose();
    competenciaController.dispose();
    cfopEntradaController.dispose();
    valorRateioFreteController.dispose();
    valorCustoMedioController.dispose();
    valorIcmsAntecipadoController.dispose();
    valorBcIcmsAntecipadoController.dispose();
    valorBcIcmsCreditadoController.dispose();
    valorBcPisCreditadoController.dispose();
    valorBcCofinsCreditadoController.dispose();
    valorBcIpiCreditadoController.dispose();
    cstCreditoIcmsController.dispose();
    cstCreditoPisController.dispose();
    cstCreditoCofinsController.dispose();
    cstCreditoIpiController.dispose();
    valorIcmsCreditadoController.dispose();
    valorPisCreditadoController.dispose();
    valorCofinsCreditadoController.dispose();
    valorIpiCreditadoController.dispose();
    qtdeParcelaCreditoPisController.dispose();
    qtdeParcelaCreditoCofinsController.dispose();
    qtdeParcelaCreditoIcmsController.dispose();
    qtdeParcelaCreditoIpiController.dispose();
    aliquotaCreditoIcmsController.dispose();
    aliquotaCreditoPisController.dispose();
    aliquotaCreditoCofinsController.dispose();
    aliquotaCreditoIpiController.dispose();
    super.onClose();
  }

}