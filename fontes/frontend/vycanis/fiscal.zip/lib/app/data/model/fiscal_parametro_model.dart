import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

import 'package:fiscal/app/infra/infra_imports.dart';
import 'package:fiscal/app/data/domain/domain_imports.dart';

class FiscalParametroModel extends ModelBase {
  int? id;
  int? idFiscalEstadualPorte;
  int? idFiscalEstadualRegime;
  int? idFiscalMunicipalRegime;
  String? vigencia;
  String? descricaoVigencia;
  String? criterioLancamento;
  String? apuracao;
  String? microempreeIndividual;
  String? calcPisCofinsEfd;
  String? simplesCodigoAcesso;
  String? simplesTabela;
  String? simplesAtividade;
  String? perfilSped;
  String? apuracaoConsolidada;
  String? substituicaoTributaria;
  String? formaCalculoIss;
  List<FiscalInscricoesSubstitutasModel>? fiscalInscricoesSubstitutasModelList;
  FiscalEstadualRegimeModel? fiscalEstadualRegimeModel;
  FiscalEstadualPorteModel? fiscalEstadualPorteModel;
  FiscalMunicipalRegimeModel? fiscalMunicipalRegimeModel;

  FiscalParametroModel({
    this.id,
    this.idFiscalEstadualPorte,
    this.idFiscalEstadualRegime,
    this.idFiscalMunicipalRegime,
    this.vigencia,
    this.descricaoVigencia,
    this.criterioLancamento = 'Livre',
    this.apuracao = '1-Regime Competencia',
    this.microempreeIndividual = 'Sim',
    this.calcPisCofinsEfd = 'AB=Alíquota Básica',
    this.simplesCodigoAcesso,
    this.simplesTabela = '1=Federal',
    this.simplesAtividade = 'Comercio',
    this.perfilSped = 'A',
    this.apuracaoConsolidada = 'Sim',
    this.substituicaoTributaria = 'Sim',
    this.formaCalculoIss = 'Normal',
    List<FiscalInscricoesSubstitutasModel>? fiscalInscricoesSubstitutasModelList,
    FiscalEstadualRegimeModel? fiscalEstadualRegimeModel,
    FiscalEstadualPorteModel? fiscalEstadualPorteModel,
    FiscalMunicipalRegimeModel? fiscalMunicipalRegimeModel,
  }) {
    this.fiscalInscricoesSubstitutasModelList = fiscalInscricoesSubstitutasModelList?.toList(growable: true) ?? [];
    this.fiscalEstadualRegimeModel = fiscalEstadualRegimeModel ?? FiscalEstadualRegimeModel();
    this.fiscalEstadualPorteModel = fiscalEstadualPorteModel ?? FiscalEstadualPorteModel();
    this.fiscalMunicipalRegimeModel = fiscalMunicipalRegimeModel ?? FiscalMunicipalRegimeModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'vigencia',
    'descricao_vigencia',
    'criterio_lancamento',
    'apuracao',
    'microempree_individual',
    'calc_pis_cofins_efd',
    'simples_codigo_acesso',
    'simples_tabela',
    'simples_atividade',
    'perfil_sped',
    'apuracao_consolidada',
    'substituicao_tributaria',
    'forma_calculo_iss',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Vigencia',
    'Descricao Vigencia',
    'Criterio Lancamento',
    'Apuracao',
    'Microempree Individual',
    'Calc Pis Cofins Efd',
    'Simples Codigo Acesso',
    'Simples Tabela',
    'Simples Atividade',
    'Perfil Sped',
    'Apuracao Consolidada',
    'Substituicao Tributaria',
    'Forma Calculo Iss',
  ];

  FiscalParametroModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFiscalEstadualPorte = jsonData['idFiscalEstadualPorte'];
    idFiscalEstadualRegime = jsonData['idFiscalEstadualRegime'];
    idFiscalMunicipalRegime = jsonData['idFiscalMunicipalRegime'];
    vigencia = jsonData['vigencia'];
    descricaoVigencia = jsonData['descricaoVigencia'];
    criterioLancamento = FiscalParametroDomain.getCriterioLancamento(jsonData['criterioLancamento']);
    apuracao = FiscalParametroDomain.getApuracao(jsonData['apuracao']);
    microempreeIndividual = FiscalParametroDomain.getMicroempreeIndividual(jsonData['microempreeIndividual']);
    calcPisCofinsEfd = FiscalParametroDomain.getCalcPisCofinsEfd(jsonData['calcPisCofinsEfd']);
    simplesCodigoAcesso = jsonData['simplesCodigoAcesso'];
    simplesTabela = FiscalParametroDomain.getSimplesTabela(jsonData['simplesTabela']);
    simplesAtividade = FiscalParametroDomain.getSimplesAtividade(jsonData['simplesAtividade']);
    perfilSped = FiscalParametroDomain.getPerfilSped(jsonData['perfilSped']);
    apuracaoConsolidada = FiscalParametroDomain.getApuracaoConsolidada(jsonData['apuracaoConsolidada']);
    substituicaoTributaria = FiscalParametroDomain.getSubstituicaoTributaria(jsonData['substituicaoTributaria']);
    formaCalculoIss = FiscalParametroDomain.getFormaCalculoIss(jsonData['formaCalculoIss']);
    fiscalInscricoesSubstitutasModelList = (jsonData['fiscalInscricoesSubstitutasModelList'] as Iterable?)?.map((m) => FiscalInscricoesSubstitutasModel.fromJson(m)).toList() ?? [];
    fiscalEstadualRegimeModel = jsonData['fiscalEstadualRegimeModel'] == null ? FiscalEstadualRegimeModel() : FiscalEstadualRegimeModel.fromJson(jsonData['fiscalEstadualRegimeModel']);
    fiscalEstadualPorteModel = jsonData['fiscalEstadualPorteModel'] == null ? FiscalEstadualPorteModel() : FiscalEstadualPorteModel.fromJson(jsonData['fiscalEstadualPorteModel']);
    fiscalMunicipalRegimeModel = jsonData['fiscalMunicipalRegimeModel'] == null ? FiscalMunicipalRegimeModel() : FiscalMunicipalRegimeModel.fromJson(jsonData['fiscalMunicipalRegimeModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFiscalEstadualPorte'] = idFiscalEstadualPorte != 0 ? idFiscalEstadualPorte : null;
    jsonData['idFiscalEstadualRegime'] = idFiscalEstadualRegime != 0 ? idFiscalEstadualRegime : null;
    jsonData['idFiscalMunicipalRegime'] = idFiscalMunicipalRegime != 0 ? idFiscalMunicipalRegime : null;
    jsonData['vigencia'] = Util.removeMask(vigencia);
    jsonData['descricaoVigencia'] = descricaoVigencia;
    jsonData['criterioLancamento'] = FiscalParametroDomain.setCriterioLancamento(criterioLancamento);
    jsonData['apuracao'] = FiscalParametroDomain.setApuracao(apuracao);
    jsonData['microempreeIndividual'] = FiscalParametroDomain.setMicroempreeIndividual(microempreeIndividual);
    jsonData['calcPisCofinsEfd'] = FiscalParametroDomain.setCalcPisCofinsEfd(calcPisCofinsEfd);
    jsonData['simplesCodigoAcesso'] = simplesCodigoAcesso;
    jsonData['simplesTabela'] = FiscalParametroDomain.setSimplesTabela(simplesTabela);
    jsonData['simplesAtividade'] = FiscalParametroDomain.setSimplesAtividade(simplesAtividade);
    jsonData['perfilSped'] = FiscalParametroDomain.setPerfilSped(perfilSped);
    jsonData['apuracaoConsolidada'] = FiscalParametroDomain.setApuracaoConsolidada(apuracaoConsolidada);
    jsonData['substituicaoTributaria'] = FiscalParametroDomain.setSubstituicaoTributaria(substituicaoTributaria);
    jsonData['formaCalculoIss'] = FiscalParametroDomain.setFormaCalculoIss(formaCalculoIss);
    
		var fiscalInscricoesSubstitutasModelLocalList = []; 
		for (FiscalInscricoesSubstitutasModel object in fiscalInscricoesSubstitutasModelList ?? []) { 
			fiscalInscricoesSubstitutasModelLocalList.add(object.toJson); 
		}
		jsonData['fiscalInscricoesSubstitutasModelList'] = fiscalInscricoesSubstitutasModelLocalList;
    jsonData['fiscalEstadualRegimeModel'] = fiscalEstadualRegimeModel?.toJson;
    jsonData['fiscalEstadualRegime'] = fiscalEstadualRegimeModel?.nome ?? '';
    jsonData['fiscalEstadualPorteModel'] = fiscalEstadualPorteModel?.toJson;
    jsonData['fiscalEstadualPorte'] = fiscalEstadualPorteModel?.nome ?? '';
    jsonData['fiscalMunicipalRegimeModel'] = fiscalMunicipalRegimeModel?.toJson;
    jsonData['fiscalMunicipalRegime'] = fiscalMunicipalRegimeModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FiscalParametroModel fromPlutoRow(PlutoRow row) {
    return FiscalParametroModel(
      id: row.cells['id']?.value,
      idFiscalEstadualPorte: row.cells['idFiscalEstadualPorte']?.value,
      idFiscalEstadualRegime: row.cells['idFiscalEstadualRegime']?.value,
      idFiscalMunicipalRegime: row.cells['idFiscalMunicipalRegime']?.value,
      vigencia: row.cells['vigencia']?.value,
      descricaoVigencia: row.cells['descricaoVigencia']?.value,
      criterioLancamento: row.cells['criterioLancamento']?.value,
      apuracao: row.cells['apuracao']?.value,
      microempreeIndividual: row.cells['microempreeIndividual']?.value,
      calcPisCofinsEfd: row.cells['calcPisCofinsEfd']?.value,
      simplesCodigoAcesso: row.cells['simplesCodigoAcesso']?.value,
      simplesTabela: row.cells['simplesTabela']?.value,
      simplesAtividade: row.cells['simplesAtividade']?.value,
      perfilSped: row.cells['perfilSped']?.value,
      apuracaoConsolidada: row.cells['apuracaoConsolidada']?.value,
      substituicaoTributaria: row.cells['substituicaoTributaria']?.value,
      formaCalculoIss: row.cells['formaCalculoIss']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFiscalEstadualPorte': PlutoCell(value: idFiscalEstadualPorte ?? 0),
        'idFiscalEstadualRegime': PlutoCell(value: idFiscalEstadualRegime ?? 0),
        'idFiscalMunicipalRegime': PlutoCell(value: idFiscalMunicipalRegime ?? 0),
        'vigencia': PlutoCell(value: vigencia ?? ''),
        'descricaoVigencia': PlutoCell(value: descricaoVigencia ?? ''),
        'criterioLancamento': PlutoCell(value: criterioLancamento ?? ''),
        'apuracao': PlutoCell(value: apuracao ?? ''),
        'microempreeIndividual': PlutoCell(value: microempreeIndividual ?? ''),
        'calcPisCofinsEfd': PlutoCell(value: calcPisCofinsEfd ?? ''),
        'simplesCodigoAcesso': PlutoCell(value: simplesCodigoAcesso ?? ''),
        'simplesTabela': PlutoCell(value: simplesTabela ?? ''),
        'simplesAtividade': PlutoCell(value: simplesAtividade ?? ''),
        'perfilSped': PlutoCell(value: perfilSped ?? ''),
        'apuracaoConsolidada': PlutoCell(value: apuracaoConsolidada ?? ''),
        'substituicaoTributaria': PlutoCell(value: substituicaoTributaria ?? ''),
        'formaCalculoIss': PlutoCell(value: formaCalculoIss ?? ''),
        'fiscalEstadualRegime': PlutoCell(value: fiscalEstadualRegimeModel?.nome ?? ''),
        'fiscalEstadualPorte': PlutoCell(value: fiscalEstadualPorteModel?.nome ?? ''),
        'fiscalMunicipalRegime': PlutoCell(value: fiscalMunicipalRegimeModel?.nome ?? ''),
      },
    );
  }

  FiscalParametroModel clone() {
    return FiscalParametroModel(
      id: id,
      idFiscalEstadualPorte: idFiscalEstadualPorte,
      idFiscalEstadualRegime: idFiscalEstadualRegime,
      idFiscalMunicipalRegime: idFiscalMunicipalRegime,
      vigencia: vigencia,
      descricaoVigencia: descricaoVigencia,
      criterioLancamento: criterioLancamento,
      apuracao: apuracao,
      microempreeIndividual: microempreeIndividual,
      calcPisCofinsEfd: calcPisCofinsEfd,
      simplesCodigoAcesso: simplesCodigoAcesso,
      simplesTabela: simplesTabela,
      simplesAtividade: simplesAtividade,
      perfilSped: perfilSped,
      apuracaoConsolidada: apuracaoConsolidada,
      substituicaoTributaria: substituicaoTributaria,
      formaCalculoIss: formaCalculoIss,
      fiscalInscricoesSubstitutasModelList: fiscalInscricoesSubstitutasModelListClone(fiscalInscricoesSubstitutasModelList!),
      fiscalEstadualRegimeModel: fiscalEstadualRegimeModel?.clone(),
      fiscalEstadualPorteModel: fiscalEstadualPorteModel?.clone(),
      fiscalMunicipalRegimeModel: fiscalMunicipalRegimeModel?.clone(),
    );
  }

  fiscalInscricoesSubstitutasModelListClone(List<FiscalInscricoesSubstitutasModel> fiscalInscricoesSubstitutasModelList) { 
		List<FiscalInscricoesSubstitutasModel> resultList = [];
		for (var fiscalInscricoesSubstitutasModel in fiscalInscricoesSubstitutasModelList) {
			resultList.add(fiscalInscricoesSubstitutasModel.clone());
		}
		return resultList;
	}


}