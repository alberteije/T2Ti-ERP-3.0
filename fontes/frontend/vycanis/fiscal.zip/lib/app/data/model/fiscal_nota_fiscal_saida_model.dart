import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

import 'package:fiscal/app/infra/infra_imports.dart';

class FiscalNotaFiscalSaidaModel extends ModelBase {
  int? id;
  int? idNfeCabecalho;
  String? competencia;
  NfeCabecalhoModel? nfeCabecalhoModel;

  FiscalNotaFiscalSaidaModel({
    this.id,
    this.idNfeCabecalho,
    this.competencia,
    NfeCabecalhoModel? nfeCabecalhoModel,
  }) {
    this.nfeCabecalhoModel = nfeCabecalhoModel ?? NfeCabecalhoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
  ];

  FiscalNotaFiscalSaidaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idNfeCabecalho = jsonData['idNfeCabecalho'];
    competencia = jsonData['competencia'];
    nfeCabecalhoModel = jsonData['nfeCabecalhoModel'] == null ? NfeCabecalhoModel() : NfeCabecalhoModel.fromJson(jsonData['nfeCabecalhoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idNfeCabecalho'] = idNfeCabecalho != 0 ? idNfeCabecalho : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['nfeCabecalhoModel'] = nfeCabecalhoModel?.toJson;
    jsonData['nfeCabecalho'] = nfeCabecalhoModel?.chaveAcesso ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FiscalNotaFiscalSaidaModel fromPlutoRow(PlutoRow row) {
    return FiscalNotaFiscalSaidaModel(
      id: row.cells['id']?.value,
      idNfeCabecalho: row.cells['idNfeCabecalho']?.value,
      competencia: row.cells['competencia']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idNfeCabecalho': PlutoCell(value: idNfeCabecalho ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'nfeCabecalho': PlutoCell(value: nfeCabecalhoModel?.chaveAcesso ?? ''),
      },
    );
  }

  FiscalNotaFiscalSaidaModel clone() {
    return FiscalNotaFiscalSaidaModel(
      id: id,
      idNfeCabecalho: idNfeCabecalho,
      competencia: competencia,
      nfeCabecalhoModel: nfeCabecalhoModel?.clone(),
    );
  }


}