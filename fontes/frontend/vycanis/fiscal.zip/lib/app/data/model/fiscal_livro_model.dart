import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:fiscal/app/data/model/model_imports.dart';


class FiscalLivroModel extends ModelBase {
  int? id;
  String? descricao;
  List<FiscalTermoModel>? fiscalTermoModelList;

  FiscalLivroModel({
    this.id,
    this.descricao,
    List<FiscalTermoModel>? fiscalTermoModelList,
  }) {
    this.fiscalTermoModelList = fiscalTermoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
  ];

  FiscalLivroModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    fiscalTermoModelList = (jsonData['fiscalTermoModelList'] as Iterable?)?.map((m) => FiscalTermoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    
		var fiscalTermoModelLocalList = []; 
		for (FiscalTermoModel object in fiscalTermoModelList ?? []) { 
			fiscalTermoModelLocalList.add(object.toJson); 
		}
		jsonData['fiscalTermoModelList'] = fiscalTermoModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FiscalLivroModel fromPlutoRow(PlutoRow row) {
    return FiscalLivroModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  FiscalLivroModel clone() {
    return FiscalLivroModel(
      id: id,
      descricao: descricao,
      fiscalTermoModelList: fiscalTermoModelListClone(fiscalTermoModelList!),
    );
  }

  fiscalTermoModelListClone(List<FiscalTermoModel> fiscalTermoModelList) { 
		List<FiscalTermoModel> resultList = [];
		for (var fiscalTermoModel in fiscalTermoModelList) {
			resultList.add(fiscalTermoModel.clone());
		}
		return resultList;
	}


}