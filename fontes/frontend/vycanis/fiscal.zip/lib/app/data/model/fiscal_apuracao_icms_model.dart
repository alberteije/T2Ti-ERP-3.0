import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

import 'package:fiscal/app/infra/infra_imports.dart';

class FiscalApuracaoIcmsModel extends ModelBase {
  int? id;
  String? competencia;
  double? valorTotalDebito;
  double? valorAjusteDebito;
  double? valorTotalAjusteDebito;
  double? valorEstornoCredito;
  double? valorTotalCredito;
  double? valorAjusteCredito;
  double? valorTotalAjusteCredito;
  double? valorEstornoDebito;
  double? valorSaldoCredorAnterior;
  double? valorSaldoApurado;
  double? valorTotalDeducao;
  double? valorIcmsRecolher;
  double? valorSaldoCredorTransp;
  double? valorDebitoEspecial;

  FiscalApuracaoIcmsModel({
    this.id,
    this.competencia,
    this.valorTotalDebito,
    this.valorAjusteDebito,
    this.valorTotalAjusteDebito,
    this.valorEstornoCredito,
    this.valorTotalCredito,
    this.valorAjusteCredito,
    this.valorTotalAjusteCredito,
    this.valorEstornoDebito,
    this.valorSaldoCredorAnterior,
    this.valorSaldoApurado,
    this.valorTotalDeducao,
    this.valorIcmsRecolher,
    this.valorSaldoCredorTransp,
    this.valorDebitoEspecial,
  });

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
    'valor_total_debito',
    'valor_ajuste_debito',
    'valor_total_ajuste_debito',
    'valor_estorno_credito',
    'valor_total_credito',
    'valor_ajuste_credito',
    'valor_total_ajuste_credito',
    'valor_estorno_debito',
    'valor_saldo_credor_anterior',
    'valor_saldo_apurado',
    'valor_total_deducao',
    'valor_icms_recolher',
    'valor_saldo_credor_transp',
    'valor_debito_especial',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
    'Valor Total Debito',
    'Valor Ajuste Debito',
    'Valor Total Ajuste Debito',
    'Valor Estorno Credito',
    'Valor Total Credito',
    'Valor Ajuste Credito',
    'Valor Total Ajuste Credito',
    'Valor Estorno Debito',
    'Valor Saldo Credor Anterior',
    'Valor Saldo Apurado',
    'Valor Total Deducao',
    'Valor Icms Recolher',
    'Valor Saldo Credor Transp',
    'Valor Debito Especial',
  ];

  FiscalApuracaoIcmsModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    competencia = jsonData['competencia'];
    valorTotalDebito = jsonData['valorTotalDebito']?.toDouble();
    valorAjusteDebito = jsonData['valorAjusteDebito']?.toDouble();
    valorTotalAjusteDebito = jsonData['valorTotalAjusteDebito']?.toDouble();
    valorEstornoCredito = jsonData['valorEstornoCredito']?.toDouble();
    valorTotalCredito = jsonData['valorTotalCredito']?.toDouble();
    valorAjusteCredito = jsonData['valorAjusteCredito']?.toDouble();
    valorTotalAjusteCredito = jsonData['valorTotalAjusteCredito']?.toDouble();
    valorEstornoDebito = jsonData['valorEstornoDebito']?.toDouble();
    valorSaldoCredorAnterior = jsonData['valorSaldoCredorAnterior']?.toDouble();
    valorSaldoApurado = jsonData['valorSaldoApurado']?.toDouble();
    valorTotalDeducao = jsonData['valorTotalDeducao']?.toDouble();
    valorIcmsRecolher = jsonData['valorIcmsRecolher']?.toDouble();
    valorSaldoCredorTransp = jsonData['valorSaldoCredorTransp']?.toDouble();
    valorDebitoEspecial = jsonData['valorDebitoEspecial']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['valorTotalDebito'] = valorTotalDebito;
    jsonData['valorAjusteDebito'] = valorAjusteDebito;
    jsonData['valorTotalAjusteDebito'] = valorTotalAjusteDebito;
    jsonData['valorEstornoCredito'] = valorEstornoCredito;
    jsonData['valorTotalCredito'] = valorTotalCredito;
    jsonData['valorAjusteCredito'] = valorAjusteCredito;
    jsonData['valorTotalAjusteCredito'] = valorTotalAjusteCredito;
    jsonData['valorEstornoDebito'] = valorEstornoDebito;
    jsonData['valorSaldoCredorAnterior'] = valorSaldoCredorAnterior;
    jsonData['valorSaldoApurado'] = valorSaldoApurado;
    jsonData['valorTotalDeducao'] = valorTotalDeducao;
    jsonData['valorIcmsRecolher'] = valorIcmsRecolher;
    jsonData['valorSaldoCredorTransp'] = valorSaldoCredorTransp;
    jsonData['valorDebitoEspecial'] = valorDebitoEspecial;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FiscalApuracaoIcmsModel fromPlutoRow(PlutoRow row) {
    return FiscalApuracaoIcmsModel(
      id: row.cells['id']?.value,
      competencia: row.cells['competencia']?.value,
      valorTotalDebito: row.cells['valorTotalDebito']?.value,
      valorAjusteDebito: row.cells['valorAjusteDebito']?.value,
      valorTotalAjusteDebito: row.cells['valorTotalAjusteDebito']?.value,
      valorEstornoCredito: row.cells['valorEstornoCredito']?.value,
      valorTotalCredito: row.cells['valorTotalCredito']?.value,
      valorAjusteCredito: row.cells['valorAjusteCredito']?.value,
      valorTotalAjusteCredito: row.cells['valorTotalAjusteCredito']?.value,
      valorEstornoDebito: row.cells['valorEstornoDebito']?.value,
      valorSaldoCredorAnterior: row.cells['valorSaldoCredorAnterior']?.value,
      valorSaldoApurado: row.cells['valorSaldoApurado']?.value,
      valorTotalDeducao: row.cells['valorTotalDeducao']?.value,
      valorIcmsRecolher: row.cells['valorIcmsRecolher']?.value,
      valorSaldoCredorTransp: row.cells['valorSaldoCredorTransp']?.value,
      valorDebitoEspecial: row.cells['valorDebitoEspecial']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'valorTotalDebito': PlutoCell(value: valorTotalDebito ?? 0.0),
        'valorAjusteDebito': PlutoCell(value: valorAjusteDebito ?? 0.0),
        'valorTotalAjusteDebito': PlutoCell(value: valorTotalAjusteDebito ?? 0.0),
        'valorEstornoCredito': PlutoCell(value: valorEstornoCredito ?? 0.0),
        'valorTotalCredito': PlutoCell(value: valorTotalCredito ?? 0.0),
        'valorAjusteCredito': PlutoCell(value: valorAjusteCredito ?? 0.0),
        'valorTotalAjusteCredito': PlutoCell(value: valorTotalAjusteCredito ?? 0.0),
        'valorEstornoDebito': PlutoCell(value: valorEstornoDebito ?? 0.0),
        'valorSaldoCredorAnterior': PlutoCell(value: valorSaldoCredorAnterior ?? 0.0),
        'valorSaldoApurado': PlutoCell(value: valorSaldoApurado ?? 0.0),
        'valorTotalDeducao': PlutoCell(value: valorTotalDeducao ?? 0.0),
        'valorIcmsRecolher': PlutoCell(value: valorIcmsRecolher ?? 0.0),
        'valorSaldoCredorTransp': PlutoCell(value: valorSaldoCredorTransp ?? 0.0),
        'valorDebitoEspecial': PlutoCell(value: valorDebitoEspecial ?? 0.0),
      },
    );
  }

  FiscalApuracaoIcmsModel clone() {
    return FiscalApuracaoIcmsModel(
      id: id,
      competencia: competencia,
      valorTotalDebito: valorTotalDebito,
      valorAjusteDebito: valorAjusteDebito,
      valorTotalAjusteDebito: valorTotalAjusteDebito,
      valorEstornoCredito: valorEstornoCredito,
      valorTotalCredito: valorTotalCredito,
      valorAjusteCredito: valorAjusteCredito,
      valorTotalAjusteCredito: valorTotalAjusteCredito,
      valorEstornoDebito: valorEstornoDebito,
      valorSaldoCredorAnterior: valorSaldoCredorAnterior,
      valorSaldoApurado: valorSaldoApurado,
      valorTotalDeducao: valorTotalDeducao,
      valorIcmsRecolher: valorIcmsRecolher,
      valorSaldoCredorTransp: valorSaldoCredorTransp,
      valorDebitoEspecial: valorDebitoEspecial,
    );
  }


}