import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

import 'package:fiscal/app/data/domain/domain_imports.dart';

class FiscalEstadualPorteModel extends ModelBase {
  int? id;
  String? uf;
  String? codigo;
  String? nome;

  FiscalEstadualPorteModel({
    this.id,
    this.uf = 'AC',
    this.codigo,
    this.nome,
  });

  static List<String> dbColumns = <String>[
    'id',
    'uf',
    'codigo',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Uf',
    'Codigo',
    'Nome',
  ];

  FiscalEstadualPorteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    uf = FiscalEstadualPorteDomain.getUf(jsonData['uf']);
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['uf'] = FiscalEstadualPorteDomain.setUf(uf);
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FiscalEstadualPorteModel fromPlutoRow(PlutoRow row) {
    return FiscalEstadualPorteModel(
      id: row.cells['id']?.value,
      uf: row.cells['uf']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'uf': PlutoCell(value: uf ?? ''),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
      },
    );
  }

  FiscalEstadualPorteModel clone() {
    return FiscalEstadualPorteModel(
      id: id,
      uf: uf,
      codigo: codigo,
      nome: nome,
    );
  }


}