import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:fiscal/app/data/model/model_imports.dart';


class SimplesNacionalDetalheModel extends ModelBase {
  int? id;
  int? idSimplesNacionalCabecalho;
  int? faixa;
  double? valorInicial;
  double? valorFinal;
  double? aliquota;
  double? irpj;
  double? csll;
  double? cofins;
  double? pisPasep;
  double? cpp;
  double? icms;
  double? ipi;
  double? iss;

  SimplesNacionalDetalheModel({
    this.id,
    this.idSimplesNacionalCabecalho,
    this.faixa,
    this.valorInicial,
    this.valorFinal,
    this.aliquota,
    this.irpj,
    this.csll,
    this.cofins,
    this.pisPasep,
    this.cpp,
    this.icms,
    this.ipi,
    this.iss,
  });

  static List<String> dbColumns = <String>[
    'id',
    'faixa',
    'valor_inicial',
    'valor_final',
    'aliquota',
    'irpj',
    'csll',
    'cofins',
    'pis_pasep',
    'cpp',
    'icms',
    'ipi',
    'iss',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Faixa',
    'Valor Inicial',
    'Valor Final',
    'Aliquota',
    'Irpj',
    'Csll',
    'Cofins',
    'Pis Pasep',
    'Cpp',
    'Icms',
    'Ipi',
    'Iss',
  ];

  SimplesNacionalDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idSimplesNacionalCabecalho = jsonData['idSimplesNacionalCabecalho'];
    faixa = jsonData['faixa'];
    valorInicial = jsonData['valorInicial']?.toDouble();
    valorFinal = jsonData['valorFinal']?.toDouble();
    aliquota = jsonData['aliquota']?.toDouble();
    irpj = jsonData['irpj']?.toDouble();
    csll = jsonData['csll']?.toDouble();
    cofins = jsonData['cofins']?.toDouble();
    pisPasep = jsonData['pisPasep']?.toDouble();
    cpp = jsonData['cpp']?.toDouble();
    icms = jsonData['icms']?.toDouble();
    ipi = jsonData['ipi']?.toDouble();
    iss = jsonData['iss']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idSimplesNacionalCabecalho'] = idSimplesNacionalCabecalho != 0 ? idSimplesNacionalCabecalho : null;
    jsonData['faixa'] = faixa;
    jsonData['valorInicial'] = valorInicial;
    jsonData['valorFinal'] = valorFinal;
    jsonData['aliquota'] = aliquota;
    jsonData['irpj'] = irpj;
    jsonData['csll'] = csll;
    jsonData['cofins'] = cofins;
    jsonData['pisPasep'] = pisPasep;
    jsonData['cpp'] = cpp;
    jsonData['icms'] = icms;
    jsonData['ipi'] = ipi;
    jsonData['iss'] = iss;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static SimplesNacionalDetalheModel fromPlutoRow(PlutoRow row) {
    return SimplesNacionalDetalheModel(
      id: row.cells['id']?.value,
      idSimplesNacionalCabecalho: row.cells['idSimplesNacionalCabecalho']?.value,
      faixa: row.cells['faixa']?.value,
      valorInicial: row.cells['valorInicial']?.value,
      valorFinal: row.cells['valorFinal']?.value,
      aliquota: row.cells['aliquota']?.value,
      irpj: row.cells['irpj']?.value,
      csll: row.cells['csll']?.value,
      cofins: row.cells['cofins']?.value,
      pisPasep: row.cells['pisPasep']?.value,
      cpp: row.cells['cpp']?.value,
      icms: row.cells['icms']?.value,
      ipi: row.cells['ipi']?.value,
      iss: row.cells['iss']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idSimplesNacionalCabecalho': PlutoCell(value: idSimplesNacionalCabecalho ?? 0),
        'faixa': PlutoCell(value: faixa ?? 0),
        'valorInicial': PlutoCell(value: valorInicial ?? 0.0),
        'valorFinal': PlutoCell(value: valorFinal ?? 0.0),
        'aliquota': PlutoCell(value: aliquota ?? 0.0),
        'irpj': PlutoCell(value: irpj ?? 0.0),
        'csll': PlutoCell(value: csll ?? 0.0),
        'cofins': PlutoCell(value: cofins ?? 0.0),
        'pisPasep': PlutoCell(value: pisPasep ?? 0.0),
        'cpp': PlutoCell(value: cpp ?? 0.0),
        'icms': PlutoCell(value: icms ?? 0.0),
        'ipi': PlutoCell(value: ipi ?? 0.0),
        'iss': PlutoCell(value: iss ?? 0.0),
      },
    );
  }

  SimplesNacionalDetalheModel clone() {
    return SimplesNacionalDetalheModel(
      id: id,
      idSimplesNacionalCabecalho: idSimplesNacionalCabecalho,
      faixa: faixa,
      valorInicial: valorInicial,
      valorFinal: valorFinal,
      aliquota: aliquota,
      irpj: irpj,
      csll: csll,
      cofins: cofins,
      pisPasep: pisPasep,
      cpp: cpp,
      icms: icms,
      ipi: ipi,
      iss: iss,
    );
  }


}