import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

import 'package:fiscal/app/data/domain/domain_imports.dart';

class FiscalInscricoesSubstitutasModel extends ModelBase {
  int? id;
  int? idFiscalParametros;
  String? uf;
  String? inscricaoEstadual;
  String? pmpf;

  FiscalInscricoesSubstitutasModel({
    this.id,
    this.idFiscalParametros,
    this.uf = 'AC',
    this.inscricaoEstadual,
    this.pmpf = 'Sim',
  });

  static List<String> dbColumns = <String>[
    'id',
    'uf',
    'inscricao_estadual',
    'pmpf',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Uf',
    'Inscricao Estadual',
    'Pmpf',
  ];

  FiscalInscricoesSubstitutasModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFiscalParametros = jsonData['idFiscalParametros'];
    uf = FiscalInscricoesSubstitutasDomain.getUf(jsonData['uf']);
    inscricaoEstadual = jsonData['inscricaoEstadual'];
    pmpf = FiscalInscricoesSubstitutasDomain.getPmpf(jsonData['pmpf']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFiscalParametros'] = idFiscalParametros != 0 ? idFiscalParametros : null;
    jsonData['uf'] = FiscalInscricoesSubstitutasDomain.setUf(uf);
    jsonData['inscricaoEstadual'] = inscricaoEstadual;
    jsonData['pmpf'] = FiscalInscricoesSubstitutasDomain.setPmpf(pmpf);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FiscalInscricoesSubstitutasModel fromPlutoRow(PlutoRow row) {
    return FiscalInscricoesSubstitutasModel(
      id: row.cells['id']?.value,
      idFiscalParametros: row.cells['idFiscalParametros']?.value,
      uf: row.cells['uf']?.value,
      inscricaoEstadual: row.cells['inscricaoEstadual']?.value,
      pmpf: row.cells['pmpf']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFiscalParametros': PlutoCell(value: idFiscalParametros ?? 0),
        'uf': PlutoCell(value: uf ?? ''),
        'inscricaoEstadual': PlutoCell(value: inscricaoEstadual ?? ''),
        'pmpf': PlutoCell(value: pmpf ?? ''),
      },
    );
  }

  FiscalInscricoesSubstitutasModel clone() {
    return FiscalInscricoesSubstitutasModel(
      id: id,
      idFiscalParametros: idFiscalParametros,
      uf: uf,
      inscricaoEstadual: inscricaoEstadual,
      pmpf: pmpf,
    );
  }


}