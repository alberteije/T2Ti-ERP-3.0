import 'package:fiscal/app/data/provider/api/api_provider_base.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class FiscalNotaFiscalSaidaApiProvider extends ApiProviderBase {
  static const _path = '/fiscal-nota-fiscal-saida';

  Future<List<FiscalNotaFiscalSaidaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FiscalNotaFiscalSaidaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FiscalNotaFiscalSaidaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FiscalNotaFiscalSaidaModel.fromJson(json),
    );
  }

  Future<FiscalNotaFiscalSaidaModel?>? insert(FiscalNotaFiscalSaidaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FiscalNotaFiscalSaidaModel.fromJson(json),
    );
  }

  Future<FiscalNotaFiscalSaidaModel?>? update(FiscalNotaFiscalSaidaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FiscalNotaFiscalSaidaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
