// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_livro_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalLivroDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalLivrosTable get fiscalLivros => attachedDatabase.fiscalLivros;
  $FiscalTermosTable get fiscalTermos => attachedDatabase.fiscalTermos;
}
