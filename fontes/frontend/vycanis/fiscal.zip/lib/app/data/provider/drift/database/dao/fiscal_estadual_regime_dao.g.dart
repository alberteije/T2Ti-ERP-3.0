// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_estadual_regime_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalEstadualRegimeDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalEstadualRegimesTable get fiscalEstadualRegimes =>
      attachedDatabase.fiscalEstadualRegimes;
}
