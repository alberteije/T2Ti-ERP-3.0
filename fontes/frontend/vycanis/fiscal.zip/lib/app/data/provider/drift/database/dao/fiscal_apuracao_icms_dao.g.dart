// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_apuracao_icms_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalApuracaoIcmsDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalApuracaoIcmssTable get fiscalApuracaoIcmss =>
      attachedDatabase.fiscalApuracaoIcmss;
}
