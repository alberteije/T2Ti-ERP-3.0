import 'package:fiscal/app/data/provider/api/api_provider_base.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class ViewControleAcessoApiProvider extends ApiProviderBase {
  static const _path = '/view-controle-acesso';

  Future<List<ViewControleAcessoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ViewControleAcessoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ViewControleAcessoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ViewControleAcessoModel.fromJson(json),
    );
  }

  Future<ViewControleAcessoModel?>? insert(ViewControleAcessoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ViewControleAcessoModel.fromJson(json),
    );
  }

  Future<ViewControleAcessoModel?>? update(ViewControleAcessoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ViewControleAcessoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
