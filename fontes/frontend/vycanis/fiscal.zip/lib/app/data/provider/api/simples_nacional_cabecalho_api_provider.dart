import 'package:fiscal/app/data/provider/api/api_provider_base.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class SimplesNacionalCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/simples-nacional-cabecalho';

  Future<List<SimplesNacionalCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => SimplesNacionalCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<SimplesNacionalCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => SimplesNacionalCabecalhoModel.fromJson(json),
    );
  }

  Future<SimplesNacionalCabecalhoModel?>? insert(SimplesNacionalCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => SimplesNacionalCabecalhoModel.fromJson(json),
    );
  }

  Future<SimplesNacionalCabecalhoModel?>? update(SimplesNacionalCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => SimplesNacionalCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
