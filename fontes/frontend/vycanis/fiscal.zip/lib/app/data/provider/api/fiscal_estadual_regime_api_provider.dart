import 'package:fiscal/app/data/provider/api/api_provider_base.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class FiscalEstadualRegimeApiProvider extends ApiProviderBase {
  static const _path = '/fiscal-estadual-regime';

  Future<List<FiscalEstadualRegimeModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FiscalEstadualRegimeModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FiscalEstadualRegimeModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FiscalEstadualRegimeModel.fromJson(json),
    );
  }

  Future<FiscalEstadualRegimeModel?>? insert(FiscalEstadualRegimeModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FiscalEstadualRegimeModel.fromJson(json),
    );
  }

  Future<FiscalEstadualRegimeModel?>? update(FiscalEstadualRegimeModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FiscalEstadualRegimeModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
