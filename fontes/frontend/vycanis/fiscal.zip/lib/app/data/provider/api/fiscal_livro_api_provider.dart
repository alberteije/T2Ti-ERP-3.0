import 'package:fiscal/app/data/provider/api/api_provider_base.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class FiscalLivroApiProvider extends ApiProviderBase {
  static const _path = '/fiscal-livro';

  Future<List<FiscalLivroModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FiscalLivroModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FiscalLivroModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FiscalLivroModel.fromJson(json),
    );
  }

  Future<FiscalLivroModel?>? insert(FiscalLivroModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FiscalLivroModel.fromJson(json),
    );
  }

  Future<FiscalLivroModel?>? update(FiscalLivroModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FiscalLivroModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
