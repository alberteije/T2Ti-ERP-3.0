// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_municipal_regime_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalMunicipalRegimeDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalMunicipalRegimesTable get fiscalMunicipalRegimes =>
      attachedDatabase.fiscalMunicipalRegimes;
}
