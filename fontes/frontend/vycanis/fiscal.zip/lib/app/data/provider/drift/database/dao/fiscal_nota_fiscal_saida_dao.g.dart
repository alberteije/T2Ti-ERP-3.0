// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_nota_fiscal_saida_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalNotaFiscalSaidaDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalNotaFiscalSaidasTable get fiscalNotaFiscalSaidas =>
      attachedDatabase.fiscalNotaFiscalSaidas;
  $NfeCabecalhosTable get nfeCabecalhos => attachedDatabase.nfeCabecalhos;
}
