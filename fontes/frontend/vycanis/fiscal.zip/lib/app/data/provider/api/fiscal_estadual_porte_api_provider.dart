import 'package:fiscal/app/data/provider/api/api_provider_base.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class FiscalEstadualPorteApiProvider extends ApiProviderBase {
  static const _path = '/fiscal-estadual-porte';

  Future<List<FiscalEstadualPorteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FiscalEstadualPorteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FiscalEstadualPorteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FiscalEstadualPorteModel.fromJson(json),
    );
  }

  Future<FiscalEstadualPorteModel?>? insert(FiscalEstadualPorteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FiscalEstadualPorteModel.fromJson(json),
    );
  }

  Future<FiscalEstadualPorteModel?>? update(FiscalEstadualPorteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FiscalEstadualPorteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
