import 'package:fiscal/app/data/provider/api/api_provider_base.dart';
import 'package:fiscal/app/data/model/model_imports.dart';

class FiscalMunicipalRegimeApiProvider extends ApiProviderBase {
  static const _path = '/fiscal-municipal-regime';

  Future<List<FiscalMunicipalRegimeModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FiscalMunicipalRegimeModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FiscalMunicipalRegimeModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FiscalMunicipalRegimeModel.fromJson(json),
    );
  }

  Future<FiscalMunicipalRegimeModel?>? insert(FiscalMunicipalRegimeModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FiscalMunicipalRegimeModel.fromJson(json),
    );
  }

  Future<FiscalMunicipalRegimeModel?>? update(FiscalMunicipalRegimeModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FiscalMunicipalRegimeModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
