abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const fiscalParametroListPage = '/fiscalParametroListPage'; 
	static const fiscalParametroTabPage = '/fiscalParametroTabPage';
	static const fiscalLivroListPage = '/fiscalLivroListPage'; 
	static const fiscalLivroTabPage = '/fiscalLivroTabPage';
	static const simplesNacionalCabecalhoListPage = '/simplesNacionalCabecalhoListPage'; 
	static const simplesNacionalCabecalhoTabPage = '/simplesNacionalCabecalhoTabPage';
	static const fiscalMunicipalRegimeListPage = '/fiscalMunicipalRegimeListPage'; 
	static const fiscalMunicipalRegimeEditPage = '/fiscalMunicipalRegimeEditPage';
	static const fiscalEstadualRegimeListPage = '/fiscalEstadualRegimeListPage'; 
	static const fiscalEstadualRegimeEditPage = '/fiscalEstadualRegimeEditPage';
	static const fiscalEstadualPorteListPage = '/fiscalEstadualPorteListPage'; 
	static const fiscalEstadualPorteEditPage = '/fiscalEstadualPorteEditPage';
	static const fiscalNotaFiscalEntradaListPage = '/fiscalNotaFiscalEntradaListPage'; 
	static const fiscalNotaFiscalEntradaEditPage = '/fiscalNotaFiscalEntradaEditPage';
	static const fiscalApuracaoIcmsListPage = '/fiscalApuracaoIcmsListPage'; 
	static const fiscalApuracaoIcmsEditPage = '/fiscalApuracaoIcmsEditPage';
	static const fiscalNotaFiscalSaidaListPage = '/fiscalNotaFiscalSaidaListPage'; 
	static const fiscalNotaFiscalSaidaEditPage = '/fiscalNotaFiscalSaidaEditPage';
}