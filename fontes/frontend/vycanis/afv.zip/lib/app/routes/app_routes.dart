abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const pessoaListPage = '/pessoaListPage'; 
	static const pessoaTabPage = '/pessoaTabPage';
	static const vendedorRotaListPage = '/vendedorRotaListPage'; 
	static const vendedorRotaTabPage = '/vendedorRotaTabPage';
	static const vendaCabecalhoListPage = '/vendaCabecalhoListPage'; 
	static const vendaCabecalhoTabPage = '/vendaCabecalhoTabPage';
	static const vendaOrcamentoCabecalhoListPage = '/vendaOrcamentoCabecalhoListPage'; 
	static const vendaOrcamentoCabecalhoTabPage = '/vendaOrcamentoCabecalhoTabPage';
	static const tabelaPrecoListPage = '/tabelaPrecoListPage'; 
	static const tabelaPrecoEditPage = '/tabelaPrecoEditPage';
	static const vendedorMetaListPage = '/vendedorMetaListPage'; 
	static const vendedorMetaEditPage = '/vendedorMetaEditPage';
}