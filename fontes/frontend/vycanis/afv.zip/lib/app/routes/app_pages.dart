import 'package:get/get.dart';
import 'package:afv/app/page/shared_widget/shared_widget_imports.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:afv/app/page/login/login_page.dart';
import 'package:afv/app/page/shared_page/splash_screen_page.dart';
import 'package:afv/app/bindings/bindings_imports.dart';
import 'package:afv/app/page/shared_page/shared_page_imports.dart';
import 'package:afv/app/page/page_imports.dart';

class AppPages {
	
	static final pages = [
		GetPage(name: Routes.splashPage, page:()=> const SplashScreenPage()),
		GetPage(name: Routes.loginPage, page:()=> const LoginPage(), binding: LoginBindings()),
		GetPage(name: Routes.homePage, page:()=> HomePage()),
		GetPage(name: Routes.filterPage, page:()=> const FilterPage()),
		GetPage(name: Routes.lookupPage, page:()=> const LookupPage()),
    GetPage(name: Routes.menuModulesPage, page:()=> const MenuModulesPage()),
		
		GetPage(name: Routes.pessoaListPage, page:()=> const PessoaListPage(), binding: PessoaBindings()), 
		GetPage(name: Routes.pessoaTabPage, page:()=> PessoaTabPage()),
		GetPage(name: Routes.vendedorRotaListPage, page:()=> const VendedorRotaListPage(), binding: VendedorRotaBindings()), 
		GetPage(name: Routes.vendedorRotaTabPage, page:()=> VendedorRotaTabPage()),
		GetPage(name: Routes.vendaCabecalhoListPage, page:()=> const VendaCabecalhoListPage(), binding: VendaCabecalhoBindings()), 
		GetPage(name: Routes.vendaCabecalhoTabPage, page:()=> VendaCabecalhoTabPage()),
		GetPage(name: Routes.vendaOrcamentoCabecalhoListPage, page:()=> const VendaOrcamentoCabecalhoListPage(), binding: VendaOrcamentoCabecalhoBindings()), 
		GetPage(name: Routes.vendaOrcamentoCabecalhoTabPage, page:()=> VendaOrcamentoCabecalhoTabPage()),
		GetPage(name: Routes.tabelaPrecoListPage, page:()=> const TabelaPrecoListPage(), binding: TabelaPrecoBindings()), 
		GetPage(name: Routes.tabelaPrecoEditPage, page:()=> TabelaPrecoEditPage()),
		GetPage(name: Routes.vendedorMetaListPage, page:()=> const VendedorMetaListPage(), binding: VendedorMetaBindings()), 
		GetPage(name: Routes.vendedorMetaEditPage, page:()=> VendedorMetaEditPage()),
	];
}