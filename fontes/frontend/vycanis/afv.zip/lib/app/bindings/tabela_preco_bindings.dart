import 'package:get/get.dart';
import 'package:afv/app/controller/tabela_preco_controller.dart';
import 'package:afv/app/data/provider/api/tabela_preco_api_provider.dart';
import 'package:afv/app/data/provider/drift/tabela_preco_drift_provider.dart';
import 'package:afv/app/data/repository/tabela_preco_repository.dart';

class TabelaPrecoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<TabelaPrecoController>(() => TabelaPrecoController(
					repository: TabelaPrecoRepository(tabelaPrecoApiProvider: TabelaPrecoApiProvider(), tabelaPrecoDriftProvider: TabelaPrecoDriftProvider()))),
		];
	}
}
