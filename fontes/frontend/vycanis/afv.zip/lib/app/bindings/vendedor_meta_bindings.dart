import 'package:get/get.dart';
import 'package:afv/app/controller/vendedor_meta_controller.dart';
import 'package:afv/app/data/provider/api/vendedor_meta_api_provider.dart';
import 'package:afv/app/data/provider/drift/vendedor_meta_drift_provider.dart';
import 'package:afv/app/data/repository/vendedor_meta_repository.dart';

class VendedorMetaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<VendedorMetaController>(() => VendedorMetaController(
					repository: VendedorMetaRepository(vendedorMetaApiProvider: VendedorMetaApiProvider(), vendedorMetaDriftProvider: VendedorMetaDriftProvider()))),
		];
	}
}
