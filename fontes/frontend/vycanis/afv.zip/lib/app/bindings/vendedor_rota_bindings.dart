import 'package:get/get.dart';
import 'package:afv/app/controller/vendedor_rota_controller.dart';
import 'package:afv/app/data/provider/api/vendedor_rota_api_provider.dart';
import 'package:afv/app/data/provider/drift/vendedor_rota_drift_provider.dart';
import 'package:afv/app/data/repository/vendedor_rota_repository.dart';

class VendedorRotaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<VendedorRotaController>(() => VendedorRotaController(
					repository: VendedorRotaRepository(vendedorRotaApiProvider: VendedorRotaApiProvider(), vendedorRotaDriftProvider: VendedorRotaDriftProvider()))),
		];
	}
}
