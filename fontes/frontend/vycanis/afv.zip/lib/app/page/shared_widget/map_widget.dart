import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class MapaOSMScreen extends StatelessWidget {
  const MapaOSMScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const ponto = LatLng(-23.550520, -46.633308);

    return Scaffold(
      // appBar: AppBar(title: const Text('Mapa OSM')),
      body: FlutterMap(
        options: const MapOptions(
          initialCenter: ponto,
          initialZoom: 15,
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.seuapp.afv',
          ),
          const MarkerLayer(
            markers: [
              Marker(
                point: ponto,
                width: 40,
                height: 40,
                child: Icon(
                  Icons.location_pin,
                  color: Colors.red,
                  size: 40,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
