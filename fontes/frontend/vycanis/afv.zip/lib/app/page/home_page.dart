import 'package:afv/app/data/provider/drift/dashboard_drift_provider.dart';
import 'package:afv/app/data/repository/dashboard_repository.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:afv/app/controller/login_controller.dart';
import 'package:afv/app/controller/theme_controller.dart';
import 'package:afv/app/controller/dashboard_controller.dart';
import 'package:afv/app/page/shared_widget/main_side_drawer.dart';
import 'package:afv/app/infra/infra_imports.dart';

class HomePage extends GetView<LoginController> {
  HomePage({Key? key}) : super(key: key);
  final themeController = Get.find<ThemeController>();
  final dashboardController = Get.put(DashboardController(
    repository: DashboardRepository(
      dashboardDriftProvider: DashboardDriftProvider(),
    ),
  ));

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 150,
          height: 120,
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(icon, color: color, size: 20),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Obx(() {
      final vendedor = dashboardController.dashboardData.value.vendedorInfo;
      final metaAtingida = dashboardController.dashboardData.value.metaAtingida;
      
      return Card(
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: Colors.blue.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Icon(
                  Icons.person,
                  size: 32,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Bem-vindo, ${vendedor?.nome ?? 'Vendedor'}!',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Dashboard de Vendas',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    if (vendedor?.email != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        vendedor!.email!,
                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ],
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: metaAtingida / 100,
                      backgroundColor: Colors.grey[200],
                      valueColor: AlwaysStoppedAnimation<Color>(
                        metaAtingida >= 100 ? Colors.green :
                        metaAtingida >= 70 ? Colors.orange : Colors.red,
                      ),
                      minHeight: 6,
                      borderRadius: BorderRadius.circular(3),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Meta: ${metaAtingida.toStringAsFixed(1)}%',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  Widget _buildSectionCard({
    required String title,
    required Widget child,
    VoidCallback? onSeeAll,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (onSeeAll != null)
                  TextButton(
                    onPressed: onSeeAll,
                    child: const Text(
                      'Ver Todos',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(Constants.appName),
        actions: [
          Obx(
            () => IconButton(
              onPressed: () {
                themeController.isDarkMode
                    ? themeController.changeThemeMode(ThemeMode.light)
                    : themeController.changeThemeMode(ThemeMode.dark);
              },
              icon: themeController.isDarkMode
                  ? const Icon(Icons.dark_mode_outlined)
                  : const Icon(Icons.light_mode_outlined),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: dashboardController.refreshDashboard,
          ),
        ],
      ),
      drawer: MainSideDrawer(),
      body: Obx(() {
        final isLoading = dashboardController.isLoading.value;
        final error = dashboardController.errorMessage.value;
        final data = dashboardController.dashboardData.value;
        
        return Stack(
          children: [
            // Background
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  stops: const [0.1, 0.4, 0.7, 0.9],
                  colors: themeController.isDarkMode
                      ? [
                          Colors.blueGrey.shade900,
                          Colors.green.shade900,
                          Colors.grey.shade900,
                          Colors.blue.shade900,
                        ]
                      : [
                          Colors.blueGrey.shade100,
                          Colors.green,
                          Colors.grey,
                          Colors.blue.shade100,
                        ],
                ),
                image: DecorationImage(
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                    Colors.red.withValues(alpha: 0.2),
                    BlendMode.dstATop,
                  ),
                  image: Image.asset(Constants.backgroundImage).image,
                ),
              ),
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : error.isNotEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.error, color: Colors.red, size: 48),
                              const SizedBox(height: 16),
                              Text(
                                error,
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: Colors.red),
                              ),
                              const SizedBox(height: 16),
                              ElevatedButton(
                                onPressed: dashboardController.refreshDashboard,
                                child: const Text('Tentar Novamente'),
                              ),
                            ],
                          ),
                        )
                      : SingleChildScrollView(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Card de boas-vindas
                              _buildWelcomeCard(),
                              const SizedBox(height: 20),

                              // Grid de métricas
                              GridView.count(
                                crossAxisCount: 6,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                childAspectRatio: 1.2,
                                mainAxisSpacing: 12,
                                crossAxisSpacing: 12,
                                children: [
                                  _buildStatCard(
                                    title: 'Vendas do Mês',
                                    value: 'R\$${data.totalVendasMes.toStringAsFixed(2)}',
                                    icon: Icons.attach_money,
                                    color: Colors.green,
                                    onTap: () {
                                      Get.toNamed(Routes.vendaCabecalhoListPage);
                                    },
                                  ),
                                  _buildStatCard(
                                    title: 'Orçamentos',
                                    value: data.totalOrcamentosMes.toString(),
                                    icon: Icons.description,
                                    color: Colors.blue,
                                    onTap: () {
                                      Get.toNamed(Routes.vendaOrcamentoCabecalhoListPage);
                                    },
                                  ),
                                  _buildStatCard(
                                    title: 'Visitas Hoje',
                                    value: data.visitasHoje.toString(),
                                    icon: Icons.calendar_today,
                                    color: Colors.orange,
                                    onTap: () {
                                      Get.toNamed(Routes.vendedorRotaListPage);
                                    },
                                  ),
                                  _buildStatCard(
                                    title: 'Clientes Ativos',
                                    value: data.clientesAtivos.toString(),
                                    icon: Icons.people,
                                    color: Colors.purple,
                                    onTap: () {
                                      Get.toNamed(Routes.pessoaListPage);
                                    },
                                  ),
                                  _buildStatCard(
                                    title: 'A Receber',
                                    value: 'R\$${data.receberHoje.toStringAsFixed(2)}',
                                    icon: Icons.money,
                                    color: Colors.teal,
                                    onTap: () {
                                      Get.toNamed(Routes.pessoaListPage);
                                    },
                                  ),
                                  _buildStatCard(
                                    title: 'Meta',
                                    value: '${data.metaAtingida.toStringAsFixed(1)}%',
                                    icon: Icons.trending_up,
                                    color: Colors.red,
                                    onTap: () {
                                      // Navegar para relatórios de vendas
                                    },
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),

                              // Últimas Vendas
                              if (data.ultimasVendas.isNotEmpty)
                                _buildSectionCard(
                                  title: 'Últimas Vendas',
                                  onSeeAll: () {
                                    Get.toNamed(Routes.vendaCabecalhoListPage);
                                  },
                                  child: Column(
                                    children: data.ultimasVendas
                                        .map<Widget>((venda) {
                                      return ListTile(
                                        contentPadding: EdgeInsets.zero,
                                        leading: Container(
                                          width: 40,
                                          height: 40,
                                          decoration: BoxDecoration(
                                            color: Colors.green.withValues(alpha: 0.1),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: const Icon(
                                            Icons.shopping_cart,
                                            color: Colors.green,
                                            size: 20,
                                          ),
                                        ),
                                        title: Text(
                                          venda.clienteNome,
                                          style: const TextStyle(fontSize: 14),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        subtitle: Text(
                                          '${venda.data.day}/${venda.data.month}/${venda.data.year}',
                                          style: const TextStyle(fontSize: 12),
                                        ),
                                        trailing: Text(
                                          'R\$${venda.valor.toStringAsFixed(2)}',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.green,
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              if (data.ultimasVendas.isNotEmpty) const SizedBox(height: 20),

                              // Próximas Visitas
                              if (data.proximasVisitas.isNotEmpty)
                                _buildSectionCard(
                                  title: 'Próximas Visitas',
                                  onSeeAll: () {
                                    Get.toNamed(Routes.vendedorRotaListPage);
                                  },
                                  child: Column(
                                    children: data.proximasVisitas
                                        .map<Widget>((visita) {
                                      return ListTile(
                                        contentPadding: EdgeInsets.zero,
                                        leading: Container(
                                          width: 40,
                                          height: 40,
                                          decoration: BoxDecoration(
                                            color: Colors.blue.withValues(alpha: 0.1),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: const Icon(
                                            Icons.location_on,
                                            color: Colors.blue,
                                            size: 20,
                                          ),
                                        ),
                                        title: Text(
                                          visita.clienteNome,
                                          style: const TextStyle(fontSize: 14),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        subtitle: Text(
                                          '${visita.data.day}/${visita.data.month} - ${visita.observacao ?? ''}',
                                          style: const TextStyle(fontSize: 12),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        trailing: const Icon(
                                          Icons.chevron_right,
                                          color: Colors.grey,
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              const SizedBox(height: 80),
                            ],
                          ),
                        ),
            ),

            // Botões de ajuda e feedback
            // Positioned(
            //   top: 10,
            //   left: 10,
            //   child: Row(
            //     children: [
            //       SizedBox(
            //         width: 25,
            //         height: 25,
            //         child: FloatingActionButton(
            //           heroTag: "btnHelp",
            //           mini: true,
            //           backgroundColor: Colors.grey,
            //           splashColor: Colors.black,
            //           tooltip: "Ajuda",
            //           onPressed: () {
            //             launchUrl(Uri.parse(
            //                 "https://t2tisistemas.com/erp/modulos/trib/help/"));
            //           },
            //           hoverElevation: 1.5,
            //           elevation: 1.5,
            //           child: const Icon(
            //             Icons.help,
            //             size: 16,
            //             color: Colors.white,
            //           ),
            //         ),
            //       ),
            //       const SizedBox(width: 8),
            //       SizedBox(
            //         width: 25,
            //         height: 25,
            //         child: FloatingActionButton(
            //           heroTag: "btnFeedback",
            //           mini: true,
            //           backgroundColor: Colors.grey,
            //           splashColor: Colors.black,
            //           tooltip: "Feedback",
            //           onPressed: () {
            //             showInfoSnackBar(
            //                 message:
            //                     "Envie o feedback do seu usuário para o Trello.");
            //           },
            //           hoverElevation: 1.5,
            //           elevation: 1.5,
            //           child: const Icon(
            //             Icons.message,
            //             size: 15,
            //             color: Colors.white,
            //           ),
            //         ),
            //       ),
            //     ],
            //   ),
            // ),

            // Informação da versão
            // Positioned(
            //   right: 16,
            //   top: 10,
            //   child: Column(
            //     crossAxisAlignment: CrossAxisAlignment.end,
            //     children: [
            //       Text(
            //         Session.empresaComPlanoAtivo
            //             ? 'Usando banco de dados remoto'
            //             : 'Usando banco de dados local [DEMO]',
            //         style: const TextStyle(
            //           fontWeight: FontWeight.w600,
            //           fontSize: 11.0,
            //           fontFamily: 'Courrier',
            //         ),
            //       ),
            //     ],
            //   ),
            // ),

            // Botão de módulos
            // Positioned(
            //   right: 20,
            //   bottom: 20,
            //   child: FloatingActionButton(
            //     heroTag: "btnModules",
            //     backgroundColor: Colors.blue.shade900,
            //     splashColor: Colors.black,
            //     tooltip: "Módulos do ERP",
            //     onPressed: () {
            //       Get.dialog(
            //         const AlertDialog(
            //           content: MenuModulesPage(),
            //         ),
            //       );
            //     },
            //     hoverElevation: 1.5,
            //     shape: const StadiumBorder(
            //       side: BorderSide(color: Colors.blue, width: 4),
            //     ),
            //     elevation: 1.5,
            //     child: const Icon(
            //       Icons.screen_share_outlined,
            //       size: 35,
            //       color: Colors.yellow,
            //     ),
            //   ),
            // ),
          ],
        );
      }),
    );
  }
}