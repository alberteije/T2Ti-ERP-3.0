import 'package:flutter/material.dart';
import 'package:afv/app/controller/venda_cabecalho_controller.dart';
import 'package:afv/app/page/shared_page/list_page_base.dart';

class VendaCabecalhoListPage extends ListPageBase<VendaCabecalhoController> {
  const VendaCabecalhoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}