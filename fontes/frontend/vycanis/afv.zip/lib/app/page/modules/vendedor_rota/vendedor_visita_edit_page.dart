import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:afv/app/page/shared_widget/shared_widget_imports.dart';
import 'package:afv/app/controller/vendedor_visita_controller.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

class VendedorVisitaEditPage extends StatelessWidget {
	VendedorVisitaEditPage({Key? key}) : super(key: key);
	final vendedorVisitaController = Get.find<VendedorVisitaController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: vendedorVisitaController.vendedorVisitaScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ vendedorVisitaController.screenTitle } - ${ vendedorVisitaController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: vendedorVisitaController.save),
						cancelAndExitButton(onPressed: vendedorVisitaController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: vendedorVisitaController.vendedorVisitaFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: vendedorVisitaController.scrollController,
							child: SingleChildScrollView(
								controller: vendedorVisitaController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Prevista',
																labelText: 'Data Prevista',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: vendedorVisitaController.dataPrevistaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	vendedorVisitaController.vendedorVisitaModel.dataPrevista = value;
																	vendedorVisitaController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Realizada',
																labelText: 'Data Realizada',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: vendedorVisitaController.dataRealizadaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	vendedorVisitaController.vendedorVisitaModel.dataRealizada = value;
																	vendedorVisitaController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: vendedorVisitaController.horaInicioController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Hora Inicio',
																labelText: 'Hora Inicio',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																vendedorVisitaController.vendedorVisitaModel.horaInicio = text;
																vendedorVisitaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: vendedorVisitaController.horaFimController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Hora Fim',
																labelText: 'Hora Fim',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																vendedorVisitaController.vendedorVisitaModel.horaFim = text;
																vendedorVisitaController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: vendedorVisitaController.latitudeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Latitude',
																labelText: 'Latitude',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																vendedorVisitaController.vendedorVisitaModel.latitude = vendedorVisitaController.latitudeController.numberValue;
																vendedorVisitaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: vendedorVisitaController.longitudeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Longitude',
																labelText: 'Longitude',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																vendedorVisitaController.vendedorVisitaModel.longitude = vendedorVisitaController.longitudeController.numberValue;
																vendedorVisitaController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: vendedorVisitaController.observacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Observacao',
																labelText: 'Observacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																vendedorVisitaController.vendedorVisitaModel.observacao = text;
																vendedorVisitaController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: vendedorVisitaController.vendaCabecalhoModelController,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Venda',
																			labelText: 'Venda',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: vendedorVisitaController.callVendaCabecalhoLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: vendedorVisitaController.vendaOrcamentoCabecalhoModelController,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Orçamento',
																			labelText: 'Orçamento',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: vendedorVisitaController.callVendaOrcamentoCabecalhoLookup),
															),
														],
													),
												),
											],
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: const SizedBox(
                            height: 400,
                            child: MapaOSMScreen(),
                          ),                          
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
