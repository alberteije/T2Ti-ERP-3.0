import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:afv/app/data/domain/domain_imports.dart';
import 'package:afv/app/controller/pessoa_juridica_controller.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

class PessoaJuridicaEditPage extends StatelessWidget {
  PessoaJuridicaEditPage({Key? key}) : super(key: key);
  final pessoaJuridicaController = Get.find<PessoaJuridicaController>();

  @override
  Widget build(BuildContext context) {
      return Scaffold(
        key: pessoaJuridicaController.pessoaJuridicaScaffoldKey,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Form(
            key: pessoaJuridicaController.pessoaJuridicaFormKey,
            autovalidateMode: AutovalidateMode.always,
            child: Scrollbar(
              controller: pessoaJuridicaController.scrollController,
              child: SingleChildScrollView(
                controller: pessoaJuridicaController.scrollController,
                child: BootstrapContainer(
                  fluid: true,
                  padding: const EdgeInsets.all(10.0),
                  children: <Widget>[
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                        BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															controller: pessoaJuridicaController.cnpjController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo CNPJ',
																labelText: 'CNPJ',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaJuridicaController.pessoaJuridicaModel.cnpj = text;
																pessoaJuridicaController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-8',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															maxLength: 100,
															controller: pessoaJuridicaController.nomeFantasiaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Fantasia',
																labelText: 'Nome Fantasia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaJuridicaController.pessoaJuridicaModel.nomeFantasia = text;
																pessoaJuridicaController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															maxLength: 45,
															controller: pessoaJuridicaController.inscricaoEstadualController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Inscrição Estadual',
																labelText: 'Inscrição Estadual',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaJuridicaController.pessoaJuridicaModel.inscricaoEstadual = text;
																pessoaJuridicaController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															maxLength: 45,
															controller: pessoaJuridicaController.inscricaoMunicipalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Inscrição Municipal',
																labelText: 'Inscrição Municipal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaJuridicaController.pessoaJuridicaModel.inscricaoMunicipal = text;
																pessoaJuridicaController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Constituição',
																labelText: 'Data Constituição',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
                                readOnly: true,
																controller: pessoaJuridicaController.dataConstituicaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	pessoaJuridicaController.pessoaJuridicaModel.dataConstituicao = value;
																	pessoaJuridicaController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaJuridicaController.tipoRegimeController,
															labelText: 'Tipo Regime',
															hintText: 'Informe os dados para o campo Tipo Regime',
															items: PessoaJuridicaDomain.tipoRegimeListDropdown,
															onChanged: (dynamic newValue) {
																pessoaJuridicaController.pessoaJuridicaModel.tipoRegime = newValue;
																pessoaJuridicaController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaJuridicaController.crtController,
															labelText: 'CRT',
															hintText: 'Informe os dados para o campo CRT',
															items: PessoaJuridicaDomain.crtListDropdown,
															onChanged: (dynamic newValue) {
																pessoaJuridicaController.pessoaJuridicaModel.crt = newValue;
																pessoaJuridicaController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
                      indent: 10,
                      endIndent: 10,
                      thickness: 2,
                    ),
                    BootstrapRow(
                      height: 60,
                      children: <BootstrapCol>[
                        BootstrapCol(
                          sizes: 'col-12',
                          child: Text(
                            'field_is_mandatory'.tr,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
  }
}
