import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:afv/app/controller/vendedor_rota_controller.dart';
import 'package:afv/app/page/shared_widget/shared_widget_imports.dart';

class VendedorRotaTabPage extends StatelessWidget {
  VendedorRotaTabPage({Key? key}) : super(key: key);
  final vendedorRotaController = Get.find<VendedorRotaController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          vendedorRotaController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: vendedorRotaController.vendedorRotaTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ vendedorRotaController.screenTitle } - ${ vendedorRotaController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: vendedorRotaController.save),
						cancelAndExitButton(onPressed: vendedorRotaController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: vendedorRotaController.tabController,
                  children: vendedorRotaController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: vendedorRotaController.tabController,
                onTap: vendedorRotaController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: vendedorRotaController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
