import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:afv/app/data/domain/domain_imports.dart';
import 'package:afv/app/controller/pessoa_controller.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

class PessoaEditPage extends StatelessWidget {
	PessoaEditPage({Key? key}) : super(key: key);
	final pessoaController = Get.find<PessoaController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: pessoaController.pessoaScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: pessoaController.pessoaFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: pessoaController.scrollController,
							child: SingleChildScrollView(
								controller: pessoaController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															maxLength: 150,
															controller: pessoaController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaController.currentModel.nome = text;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.tipoController,
															labelText: 'Tipo',
															hintText: 'Informe os dados para o campo Tipo',
															items: PessoaDomain.tipoListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.tipo = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															maxLength: 250,
															controller: pessoaController.siteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Site',
																labelText: 'Site',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaController.currentModel.site = text;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															validator: ValidateFormField.validateEmail,
															maxLength: 250,
															controller: pessoaController.emailController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Email',
																labelText: 'Email',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaController.currentModel.email = text;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.ehClienteController,
															labelText: 'É Cliente',
															hintText: 'Informe os dados para o campo É Cliente',
															items: PessoaDomain.ehClienteListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.ehCliente = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.ehFornecedorController,
															labelText: 'É Fornecedor',
															hintText: 'Informe os dados para o campo É Fornecedor',
															items: PessoaDomain.ehFornecedorListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.ehFornecedor = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.ehTransportadoraController,
															labelText: 'É Transportadora',
															hintText: 'Informe os dados para o campo É Transportadora',
															items: PessoaDomain.ehTransportadoraListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.ehTransportadora = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.ehColaboradorController,
															labelText: 'É Colaborador',
															hintText: 'Informe os dados para o campo É Colaborador',
															items: PessoaDomain.ehColaboradorListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.ehColaborador = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.ehContadorController,
															labelText: 'É Contador',
															hintText: 'Informe os dados para o campo É Contador',
															items: PessoaDomain.ehContadorListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.ehContador = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.situacaoContribuinteController,
															labelText: 'Situação do Contribuinte',
															hintText: 'Informe os dados para o campo Situação do Contribuinte',
															items: PessoaDomain.situacaoContribuinteListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.situacaoContribuinte = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaController.ativoController,
															labelText: 'Ativo',
															hintText: 'Informe os dados para o campo Ativo',
															items: PessoaDomain.ativoListDropdown,
															onChanged: (dynamic newValue) {
																pessoaController.currentModel.ativo = newValue;
																pessoaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}

}
