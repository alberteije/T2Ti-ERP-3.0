import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:afv/app/page/shared_widget/shared_widget_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';
import 'package:afv/app/controller/view_fin_lancamento_receber_controller.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

class ViewFinLancamentoReceberEditPage extends StatelessWidget {
	ViewFinLancamentoReceberEditPage({Key? key}) : super(key: key);
	final viewFinLancamentoReceberController = Get.find<ViewFinLancamentoReceberController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: viewFinLancamentoReceberController.viewFinLancamentoReceberScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ viewFinLancamentoReceberController.screenTitle } - ${ viewFinLancamentoReceberController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: viewFinLancamentoReceberController.save),
						cancelAndExitButton(onPressed: viewFinLancamentoReceberController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: viewFinLancamentoReceberController.viewFinLancamentoReceberFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: viewFinLancamentoReceberController.scrollController,
							child: SingleChildScrollView(
								controller: viewFinLancamentoReceberController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.idFinLancamentoReceberController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Fin Lancamento Receber',
																labelText: 'Id Fin Lancamento Receber',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.idFinLancamentoReceber = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.quantidadeParcelaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade Parcela',
																labelText: 'Quantidade Parcela',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.quantidadeParcela = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.valorLancamentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Lancamento',
																labelText: 'Valor Lancamento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.valorLancamento = viewFinLancamentoReceberController.valorLancamentoController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Lancamento',
																labelText: 'Data Lancamento',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: viewFinLancamentoReceberController.dataLancamentoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	viewFinLancamentoReceberController.viewFinLancamentoReceberModel.dataLancamento = value;
																	viewFinLancamentoReceberController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: viewFinLancamentoReceberController.numeroDocumentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Documento',
																labelText: 'Numero Documento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.numeroDocumento = text;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.idFinParcelaReceberController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Fin Parcela Receber',
																labelText: 'Id Fin Parcela Receber',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.idFinParcelaReceber = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.numeroParcelaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Parcela',
																labelText: 'Numero Parcela',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.numeroParcela = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Vencimento',
																labelText: 'Data Vencimento',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: viewFinLancamentoReceberController.dataVencimentoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	viewFinLancamentoReceberController.viewFinLancamentoReceberModel.dataVencimento = value;
																	viewFinLancamentoReceberController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Recebimento',
																labelText: 'Data Recebimento',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: viewFinLancamentoReceberController.dataRecebimentoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	viewFinLancamentoReceberController.viewFinLancamentoReceberModel.dataRecebimento = value;
																	viewFinLancamentoReceberController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.valorParcelaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Parcela',
																labelText: 'Valor Parcela',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.valorParcela = viewFinLancamentoReceberController.valorParcelaController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.taxaJuroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Juro',
																labelText: 'Taxa Juro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.taxaJuro = viewFinLancamentoReceberController.taxaJuroController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.valorJuroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Juro',
																labelText: 'Valor Juro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.valorJuro = viewFinLancamentoReceberController.valorJuroController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.taxaMultaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Multa',
																labelText: 'Taxa Multa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.taxaMulta = viewFinLancamentoReceberController.taxaMultaController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.valorMultaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Multa',
																labelText: 'Valor Multa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.valorMulta = viewFinLancamentoReceberController.valorMultaController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.taxaDescontoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Desconto',
																labelText: 'Taxa Desconto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.taxaDesconto = viewFinLancamentoReceberController.taxaDescontoController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.valorDescontoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Desconto',
																labelText: 'Valor Desconto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.valorDesconto = viewFinLancamentoReceberController.valorDescontoController.numberValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: viewFinLancamentoReceberController.siglaDocumentoController,
															labelText: 'Sigla Documento',
															hintText: 'Informe os dados para o campo Sigla Documento',
															items: ViewFinLancamentoReceberDomain.siglaDocumentoListDropdown,
															onChanged: (dynamic newValue) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.siglaDocumento = newValue;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.idClienteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Cliente',
																labelText: 'Id Cliente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.idCliente = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.idPessoaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Pessoa',
																labelText: 'Id Pessoa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.idPessoa = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 150,
															controller: viewFinLancamentoReceberController.nomeClienteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Cliente',
																labelText: 'Nome Cliente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.nomeCliente = text;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.idFinStatusParcelaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Fin Status Parcela',
																labelText: 'Id Fin Status Parcela',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.idFinStatusParcela = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: viewFinLancamentoReceberController.situacaoParcelaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Situacao Parcela',
																labelText: 'Situacao Parcela',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.situacaoParcela = text;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 255,
															controller: viewFinLancamentoReceberController.descricaoSituacaoParcelaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao Situacao Parcela',
																labelText: 'Descricao Situacao Parcela',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.descricaoSituacaoParcela = text;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: viewFinLancamentoReceberController.idBancoContaCaixaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Banco Conta Caixa',
																labelText: 'Id Banco Conta Caixa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.idBancoContaCaixa = int.tryParse(text);
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: viewFinLancamentoReceberController.nomeContaCaixaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Conta Caixa',
																labelText: 'Nome Conta Caixa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																viewFinLancamentoReceberController.viewFinLancamentoReceberModel.nomeContaCaixa = text;
																viewFinLancamentoReceberController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
