import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:afv/app/page/shared_widget/shared_widget_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';
import 'package:afv/app/controller/vendedor_meta_controller.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

class VendedorMetaEditPage extends StatelessWidget {
	VendedorMetaEditPage({Key? key}) : super(key: key);
	final vendedorMetaController = Get.find<VendedorMetaController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					vendedorMetaController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: vendedorMetaController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ vendedorMetaController.screenTitle } - ${ vendedorMetaController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: vendedorMetaController.save),
						cancelAndExitButton(onPressed: vendedorMetaController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: vendedorMetaController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: vendedorMetaController.scrollController,
							child: SingleChildScrollView(
								controller: vendedorMetaController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: vendedorMetaController.viewPessoaVendedorModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Id Vendedor',
																			labelText: 'Vendedor *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															// Expanded(
															// 	flex: 0,
															// 	child: lookupButton(onPressed: vendedorMetaController.callViewPessoaVendedorLookup),
															// ),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: vendedorMetaController.viewPessoaClienteModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Id Cliente',
																			labelText: 'Cliente *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															// Expanded(
															// 	flex: 0,
															// 	child: lookupButton(onPressed: vendedorMetaController.callViewPessoaClienteLookup),
															// ),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: vendedorMetaController.periodoMetaController,
															labelText: 'Período Meta',
															hintText: 'Informe os dados para o campo Período Meta',
															items: VendedorMetaDomain.periodoMetaListDropdown,
															onChanged: (dynamic newValue) {
																vendedorMetaController.currentModel.periodoMeta = newValue;
																vendedorMetaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															controller: vendedorMetaController.metaOrcadaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Meta Orçada',
																labelText: 'Meta Orçada',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																vendedorMetaController.currentModel.metaOrcada = vendedorMetaController.metaOrcadaController.numberValue;
																vendedorMetaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															controller: vendedorMetaController.metaRealizadaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Meta Realizada',
																labelText: 'Meta Realizada',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																vendedorMetaController.currentModel.metaRealizada = vendedorMetaController.metaRealizadaController.numberValue;
																vendedorMetaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Início',
																labelText: 'Data Início',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
                                readOnly: true,
																controller: vendedorMetaController.dataInicioController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	vendedorMetaController.currentModel.dataInicio = value;
																	vendedorMetaController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Fim',
																labelText: 'Data Fim',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
                                readOnly: true,
																controller: vendedorMetaController.dataFimController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	vendedorMetaController.currentModel.dataFim = value;
																	vendedorMetaController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
