import 'package:flutter/material.dart';
import 'package:afv/app/controller/venda_orcamento_cabecalho_controller.dart';
import 'package:afv/app/page/shared_page/list_page_base.dart';

class VendaOrcamentoCabecalhoListPage extends ListPageBase<VendaOrcamentoCabecalhoController> {
  const VendaOrcamentoCabecalhoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}