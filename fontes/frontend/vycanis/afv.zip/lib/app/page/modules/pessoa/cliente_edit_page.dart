import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:afv/app/data/domain/domain_imports.dart';
import 'package:afv/app/controller/cliente_controller.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

class ClienteEditPage extends StatelessWidget {
  ClienteEditPage({Key? key}) : super(key: key);
  final clienteController = Get.find<ClienteController>();

  @override
  Widget build(BuildContext context) {
      return Scaffold(
        key: clienteController.clienteScaffoldKey,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Form(
            key: clienteController.clienteFormKey,
            autovalidateMode: AutovalidateMode.always,
            child: Scrollbar(
              controller: clienteController.scrollController,
              child: SingleChildScrollView(
                controller: clienteController.scrollController,
                child: BootstrapContainer(
                  fluid: true,
                  padding: const EdgeInsets.all(10.0),
                  children: <Widget>[
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-8',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: clienteController.tabelaPrecoModelController,
																		// validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Importar Tabela Preco',
																			labelText: 'Tabela Preco *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															// Expanded(
															// 	flex: 0,
															// 	child: lookupButton(onPressed: clienteController.callTabelaPrecoLookup),
															// ),
														],
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Desde',
																labelText: 'Desde',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
                                readOnly: true,
																controller: clienteController.desdeController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	clienteController.clienteModel.desde = value;
																	clienteController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
                    	],
										),
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Cadastro',
																labelText: 'Data Cadastro',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
                                readOnly: true,
                                controller: clienteController.dataCadastroController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	clienteController.clienteModel.dataCadastro = value;
																	clienteController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															controller: clienteController.taxaDescontoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Desconto',
																labelText: 'Taxa Desconto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																clienteController.clienteModel.taxaDesconto = clienteController.taxaDescontoController.numberValue;
																clienteController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
                              readOnly: true,
															controller: clienteController.limiteCreditoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Limite Crédito',
																labelText: 'Limite Crédito',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																clienteController.clienteModel.limiteCredito = clienteController.limiteCreditoController.numberValue;
																clienteController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															maxLength: 250,
															maxLines: 3,
															controller: clienteController.observacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Observação',
																labelText: 'Observação',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																clienteController.clienteModel.observacao = text;
																clienteController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: clienteController.ehGovernoController,
															labelText: 'É Governo',
															hintText: 'Informe os dados para o campo É Governo',
															items: ClienteDomain.ehGovernoListDropdown,
															onChanged: (dynamic newValue) {
																clienteController.clienteModel.ehGoverno = newValue;
																clienteController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: clienteController.tipoEnteGovernamentalController,
															labelText: 'Tipo Ente Governamental',
															hintText: 'Informe os dados para o campo Tipo Ente Governamental',
															items: ClienteDomain.tipoEnteGovernamentalListDropdown,
															onChanged: (dynamic newValue) {
																clienteController.clienteModel.tipoEnteGovernamental = newValue;
																clienteController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: clienteController.governoPercentualReducaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Governo Percentual Redução',
																labelText: 'Governo Percentual Redução',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																clienteController.clienteModel.governoPercentualReducao = clienteController.governoPercentualReducaoController.numberValue;
																clienteController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
                      indent: 10,
                      endIndent: 10,
                      thickness: 2,
                    ),
                    BootstrapRow(
                      height: 60,
                      children: <BootstrapCol>[
                        BootstrapCol(
                          sizes: 'col-12',
                          child: Text(
                            'field_is_mandatory'.tr,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
  }
}
