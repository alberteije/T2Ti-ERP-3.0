import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:afv/app/page/shared_widget/shared_widget_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';
import 'package:afv/app/controller/pessoa_endereco_controller.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

class PessoaEnderecoEditPage extends StatelessWidget {
	PessoaEnderecoEditPage({Key? key}) : super(key: key);
	final pessoaEnderecoController = Get.find<PessoaEnderecoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: pessoaEnderecoController.pessoaEnderecoScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ pessoaEnderecoController.screenTitle } - ${ pessoaEnderecoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: pessoaEnderecoController.save),
						cancelAndExitButton(onPressed: pessoaEnderecoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: pessoaEnderecoController.pessoaEnderecoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: pessoaEnderecoController.scrollController,
							child: SingleChildScrollView(
								controller: pessoaEnderecoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: pessoaEnderecoController.logradouroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Logradouro',
																labelText: 'Logradouro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaEnderecoController.pessoaEnderecoModel.logradouro = text;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 10,
															controller: pessoaEnderecoController.numeroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Número',
																labelText: 'Número',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaEnderecoController.pessoaEnderecoModel.numero = text;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: pessoaEnderecoController.complementoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Complemento',
																labelText: 'Complemento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaEnderecoController.pessoaEnderecoModel.complemento = text;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-5',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: pessoaEnderecoController.bairroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Bairro',
																labelText: 'Bairro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaEnderecoController.pessoaEnderecoModel.bairro = text;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-5',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: pessoaEnderecoController.cidadeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cidade',
																labelText: 'Cidade',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaEnderecoController.pessoaEnderecoModel.cidade = text;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaEnderecoController.ufController,
															labelText: 'UF',
															hintText: 'Informe os dados para o campo UF',
															items: PessoaEnderecoDomain.ufListDropdown,
															onChanged: (dynamic newValue) {
																pessoaEnderecoController.pessoaEnderecoModel.uf = newValue;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pessoaEnderecoController.cepController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo CEP',
																labelText: 'CEP',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaEnderecoController.pessoaEnderecoModel.cep = text;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pessoaEnderecoController.municipioIbgeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Município IBGE',
																labelText: 'Município IBGE',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pessoaEnderecoController.pessoaEnderecoModel.municipioIbge = int.tryParse(text);
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaEnderecoController.principalController,
															labelText: 'Principal',
															hintText: 'Informe os dados para o campo Principal',
															items: PessoaEnderecoDomain.principalListDropdown,
															onChanged: (dynamic newValue) {
																pessoaEnderecoController.pessoaEnderecoModel.principal = newValue;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaEnderecoController.entregaController,
															labelText: 'Entrega',
															hintText: 'Informe os dados para o campo Entrega',
															items: PessoaEnderecoDomain.entregaListDropdown,
															onChanged: (dynamic newValue) {
																pessoaEnderecoController.pessoaEnderecoModel.entrega = newValue;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaEnderecoController.cobrancaController,
															labelText: 'Cobrança',
															hintText: 'Informe os dados para o campo Cobrança',
															items: PessoaEnderecoDomain.cobrancaListDropdown,
															onChanged: (dynamic newValue) {
																pessoaEnderecoController.pessoaEnderecoModel.cobranca = newValue;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pessoaEnderecoController.correspondenciaController,
															labelText: 'Correspondência',
															hintText: 'Informe os dados para o campo Correspondência',
															items: PessoaEnderecoDomain.correspondenciaListDropdown,
															onChanged: (dynamic newValue) {
																pessoaEnderecoController.pessoaEnderecoModel.correspondencia = newValue;
																pessoaEnderecoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
