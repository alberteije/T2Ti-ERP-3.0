import 'package:afv/app/data/provider/api/api_provider_base.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendedorMetaApiProvider extends ApiProviderBase {
  static const _path = '/vendedor-meta';

  Future<List<VendedorMetaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => VendedorMetaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<VendedorMetaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => VendedorMetaModel.fromJson(json),
    );
  }

  Future<VendedorMetaModel?>? insert(VendedorMetaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => VendedorMetaModel.fromJson(json),
    );
  }

  Future<VendedorMetaModel?>? update(VendedorMetaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => VendedorMetaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
