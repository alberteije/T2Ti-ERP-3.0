import 'package:afv/app/data/provider/api/api_provider_base.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendaOrcamentoCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/venda-orcamento-cabecalho';

  Future<List<VendaOrcamentoCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => VendaOrcamentoCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<VendaOrcamentoCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => VendaOrcamentoCabecalhoModel.fromJson(json),
    );
  }

  Future<VendaOrcamentoCabecalhoModel?>? insert(VendaOrcamentoCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => VendaOrcamentoCabecalhoModel.fromJson(json),
    );
  }

  Future<VendaOrcamentoCabecalhoModel?>? update(VendaOrcamentoCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => VendaOrcamentoCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
