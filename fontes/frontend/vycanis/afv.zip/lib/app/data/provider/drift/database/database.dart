import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database_imports.dart';

part 'database.g.dart';

@DriftDatabase(
	tables: [
		PessoaJuridicas,
		Clientes,
		PessoaEnderecos,
		PessoaContatos,
		PessoaTelefones,
		VendaDetalhes,
		VendaCondicoesParcelass,
		VendaFretes,
		ViewFinLancamentoRecebers,
		VendedorVisitas,
		ProdutoPromocaos,
		VendaOrcamentoDetalhes,
		Pessoas,
		VendedorRotas,
		VendaCondicoesPagamentos,
		VendaCabecalhos,
		Produtos,
		VendaOrcamentoCabecalhos,
		TabelaPrecos,
		ViewControleAcessos,
		ViewPessoaUsuarios,
		VendedorMetas,
		NotaFiscalModelos,
		NotaFiscalTipos,
		ViewPessoaClientes,
		ViewPessoaVendedors,
		ViewPessoaTransportadoras,
		ProdutoGrupos,
		ProdutoSubgrupos,
		ProdutoMarcas,
		ProdutoUnidades,
 ], 
	daos: [
		PessoaDao,
		VendedorRotaDao,
		VendaCondicoesPagamentoDao,
		VendaCabecalhoDao,
		ProdutoDao,
		VendaOrcamentoCabecalhoDao,
		TabelaPrecoDao,
		ViewControleAcessoDao,
		ViewPessoaUsuarioDao,
		VendedorMetaDao,
		NotaFiscalModeloDao,
		NotaFiscalTipoDao,
		ViewPessoaClienteDao,
		ViewPessoaVendedorDao,
		ViewPessoaTransportadoraDao,
		ProdutoGrupoDao,
		ProdutoSubgrupoDao,
		ProdutoMarcaDao,
		ProdutoUnidadeDao,
	],
)

class AppDatabase extends _$AppDatabase {
	AppDatabase(QueryExecutor executor) : super(executor);

	@override
	int get schemaVersion => 1;

	@override
	MigrationStrategy get migration => MigrationStrategy(
		onCreate: (Migrator m) async {
			await m.createAll();
			await _populateDatabase(this);
		},		
	);	
}

Future<void> _populateDatabase(db) async {
	await db.customStatement("CREATE TABLE HIDDEN_SETTINGS("
				"ID INTEGER PRIMARY KEY,"
				"APP_THEME TEXT"
			")");
	await db.customStatement("INSERT INTO HIDDEN_SETTINGS (ID, APP_THEME) VALUES (1, 'ThemeMode.light')");
  await db.customStatement(
    "INSERT INTO pessoa (id, nome, tipo, email, ativo, eh_cliente, eh_colaborador) "
    "VALUES (1, 'Mercado Bom Preço Ltda', 'J', 'contato@bompreco.com', 'S', 'S', 'N')"
  );
  await db.customStatement(
    "INSERT INTO pessoa (id, nome, tipo, email, ativo, eh_cliente, eh_colaborador) "
    "VALUES (2, 'João da Silva', 'F', 'joao.silva@empresa.com', 'S', 'N', 'S')"
  );
  await db.customStatement(
    "INSERT INTO view_pessoa_cliente "
    "(id, nome, tipo, email, cpf_cnpj, limite_credito, id_pessoa) "
    "VALUES (1, 'Mercado Bom Preço Ltda', 'J', 'contato@bompreco.com', "
    "'12345678000199', 50000, 1)"
  );
  await db.customStatement(
    "INSERT INTO view_pessoa_vendedor "
    "(id, nome, email, comissao, meta_venda, id_pessoa) "
    "VALUES (1, 'João da Silva', 'joao.silva@empresa.com', "
    "5, 100000, 2)"
  );
  await db.customStatement(
    "INSERT INTO tabela_preco "
    "(id, nome, principal, coeficiente, valor_fixo) "
    "VALUES (1, 'Tabela Padrão', 'S', 1, 0)"
  );
  await db.customStatement(
    "INSERT INTO produto_grupo (id, nome) VALUES (1, 'Bebidas')"
  );
  await db.customStatement(
    "INSERT INTO produto_subgrupo (id, id_produto_grupo, nome) "
    "VALUES (1, 1, 'Refrigerantes')"
  );
  await db.customStatement(
    "INSERT INTO produto_marca (id, nome) VALUES (1, 'Marca Cola')"
  );
  await db.customStatement(
    "INSERT INTO produto_unidade (id, sigla, pode_fracionar) "
    "VALUES (1, 'UN', 'N')"
  );
  await db.customStatement(
    "INSERT INTO produto "
    "(id, id_produto_subgrupo, id_produto_marca, id_produto_unidade, nome, valor_venda, ativo) "
    "VALUES (1, 1, 1, 1, 'Refrigerante Cola 2L', 8.50, 'S')"
  );
}
