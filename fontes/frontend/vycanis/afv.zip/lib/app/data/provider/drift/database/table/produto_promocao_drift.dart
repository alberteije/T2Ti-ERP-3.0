import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';

@DataClassName("ProdutoPromocao")
class ProdutoPromocaos extends Table {
	@override
	String get tableName => 'produto_promocao';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idProduto => integer().named('id_produto').nullable()();
	DateTimeColumn get dataInicio => dateTime().named('data_inicio').nullable()();
	DateTimeColumn get dataFim => dateTime().named('data_fim').nullable()();
	RealColumn get quantidadeEmPromocao => real().named('quantidade_em_promocao').nullable()();
	RealColumn get quantidadeMaximaCliente => real().named('quantidade_maxima_cliente').nullable()();
	RealColumn get valor => real().named('valor').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ProdutoPromocaoGrouped {
	ProdutoPromocao? produtoPromocao; 

  ProdutoPromocaoGrouped({
		this.produtoPromocao, 

  });
}
