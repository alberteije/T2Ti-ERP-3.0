import 'package:afv/app/data/provider/drift/database/database_imports.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/data/provider/provider_base.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class VendedorMetaDriftProvider extends ProviderBase {

	Future<List<VendedorMetaModel>?> getList({Filter? filter}) async {
		List<VendedorMetaGrouped> vendedorMetaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				vendedorMetaDriftList = await Session.database.vendedorMetaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				vendedorMetaDriftList = await Session.database.vendedorMetaDao.getGroupedList(); 
			}
			if (vendedorMetaDriftList.isNotEmpty) {
				return toListModel(vendedorMetaDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<VendedorMetaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.vendedorMetaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendedorMetaModel?>? insert(VendedorMetaModel vendedorMetaModel) async {
		try {
			final lastPk = await Session.database.vendedorMetaDao.insertObject(toDrift(vendedorMetaModel));
			vendedorMetaModel.id = lastPk;
			return vendedorMetaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendedorMetaModel?>? update(VendedorMetaModel vendedorMetaModel) async {
		try {
			await Session.database.vendedorMetaDao.updateObject(toDrift(vendedorMetaModel));
			return vendedorMetaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.vendedorMetaDao.deleteObject(toDrift(VendedorMetaModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<VendedorMetaModel> toListModel(List<VendedorMetaGrouped> vendedorMetaDriftList) {
		List<VendedorMetaModel> listModel = [];
		for (var vendedorMetaDrift in vendedorMetaDriftList) {
			listModel.add(toModel(vendedorMetaDrift)!);
		}
		return listModel;
	}	

	VendedorMetaModel? toModel(VendedorMetaGrouped? vendedorMetaDrift) {
		if (vendedorMetaDrift != null) {
			return VendedorMetaModel(
				id: vendedorMetaDrift.vendedorMeta?.id,
				idVendedor: vendedorMetaDrift.vendedorMeta?.idVendedor,
				idCliente: vendedorMetaDrift.vendedorMeta?.idCliente,
				periodoMeta: VendedorMetaDomain.getPeriodoMeta(vendedorMetaDrift.vendedorMeta?.periodoMeta),
				metaOrcada: vendedorMetaDrift.vendedorMeta?.metaOrcada,
				metaRealizada: vendedorMetaDrift.vendedorMeta?.metaRealizada,
				dataInicio: vendedorMetaDrift.vendedorMeta?.dataInicio,
				dataFim: vendedorMetaDrift.vendedorMeta?.dataFim,
				viewPessoaVendedorModel: ViewPessoaVendedorModel(
					id: vendedorMetaDrift.viewPessoaVendedor?.id,
					nome: vendedorMetaDrift.viewPessoaVendedor?.nome,
					tipo: vendedorMetaDrift.viewPessoaVendedor?.tipo,
					email: vendedorMetaDrift.viewPessoaVendedor?.email,
					site: vendedorMetaDrift.viewPessoaVendedor?.site,
					cpfCnpj: vendedorMetaDrift.viewPessoaVendedor?.cpfCnpj,
					rgIe: vendedorMetaDrift.viewPessoaVendedor?.rgIe,
					matricula: vendedorMetaDrift.viewPessoaVendedor?.matricula,
					dataCadastro: vendedorMetaDrift.viewPessoaVendedor?.dataCadastro,
					dataAdmissao: vendedorMetaDrift.viewPessoaVendedor?.dataAdmissao,
					dataDemissao: vendedorMetaDrift.viewPessoaVendedor?.dataDemissao,
					ctpsNumero: vendedorMetaDrift.viewPessoaVendedor?.ctpsNumero,
					ctpsSerie: vendedorMetaDrift.viewPessoaVendedor?.ctpsSerie,
					ctpsDataExpedicao: vendedorMetaDrift.viewPessoaVendedor?.ctpsDataExpedicao,
					ctpsUf: vendedorMetaDrift.viewPessoaVendedor?.ctpsUf,
					observacao: vendedorMetaDrift.viewPessoaVendedor?.observacao,
					logradouro: vendedorMetaDrift.viewPessoaVendedor?.logradouro,
					numero: vendedorMetaDrift.viewPessoaVendedor?.numero,
					complemento: vendedorMetaDrift.viewPessoaVendedor?.complemento,
					bairro: vendedorMetaDrift.viewPessoaVendedor?.bairro,
					cidade: vendedorMetaDrift.viewPessoaVendedor?.cidade,
					cep: vendedorMetaDrift.viewPessoaVendedor?.cep,
					municipioIbge: vendedorMetaDrift.viewPessoaVendedor?.municipioIbge,
					uf: vendedorMetaDrift.viewPessoaVendedor?.uf,
					idPessoa: vendedorMetaDrift.viewPessoaVendedor?.idPessoa,
					idCargo: vendedorMetaDrift.viewPessoaVendedor?.idCargo,
					idSetor: vendedorMetaDrift.viewPessoaVendedor?.idSetor,
					comissao: vendedorMetaDrift.viewPessoaVendedor?.comissao,
					metaVenda: vendedorMetaDrift.viewPessoaVendedor?.metaVenda,
				),
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: vendedorMetaDrift.viewPessoaCliente?.id,
					nome: vendedorMetaDrift.viewPessoaCliente?.nome,
					tipo: vendedorMetaDrift.viewPessoaCliente?.tipo,
					email: vendedorMetaDrift.viewPessoaCliente?.email,
					site: vendedorMetaDrift.viewPessoaCliente?.site,
					cpfCnpj: vendedorMetaDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: vendedorMetaDrift.viewPessoaCliente?.rgIe,
					desde: vendedorMetaDrift.viewPessoaCliente?.desde,
					taxaDesconto: vendedorMetaDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: vendedorMetaDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: vendedorMetaDrift.viewPessoaCliente?.dataCadastro,
					observacao: vendedorMetaDrift.viewPessoaCliente?.observacao,
					idPessoa: vendedorMetaDrift.viewPessoaCliente?.idPessoa,
				),
			);
		} else {
			return null;
		}
	}


	VendedorMetaGrouped toDrift(VendedorMetaModel vendedorMetaModel) {
		return VendedorMetaGrouped(
			vendedorMeta: VendedorMeta(
				id: vendedorMetaModel.id,
				idVendedor: vendedorMetaModel.idVendedor,
				idCliente: vendedorMetaModel.idCliente,
				periodoMeta: VendedorMetaDomain.setPeriodoMeta(vendedorMetaModel.periodoMeta),
				metaOrcada: vendedorMetaModel.metaOrcada,
				metaRealizada: vendedorMetaModel.metaRealizada,
				dataInicio: vendedorMetaModel.dataInicio,
				dataFim: vendedorMetaModel.dataFim,
			),
		);
	}

		
}
