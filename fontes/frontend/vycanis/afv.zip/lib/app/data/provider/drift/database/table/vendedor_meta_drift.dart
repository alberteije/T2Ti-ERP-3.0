import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';

@DataClassName("VendedorMeta")
class VendedorMetas extends Table {
	@override
	String get tableName => 'vendedor_meta';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idVendedor => integer().named('id_vendedor').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	TextColumn get periodoMeta => text().named('periodo_meta').withLength(min: 0, max: 1).nullable()();
	RealColumn get metaOrcada => real().named('meta_orcada').nullable()();
	RealColumn get metaRealizada => real().named('meta_realizada').nullable()();
	DateTimeColumn get dataInicio => dateTime().named('data_inicio').nullable()();
	DateTimeColumn get dataFim => dateTime().named('data_fim').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class VendedorMetaGrouped {
	VendedorMeta? vendedorMeta; 
	ViewPessoaVendedor? viewPessoaVendedor; 
	ViewPessoaCliente? viewPessoaCliente; 

  VendedorMetaGrouped({
		this.vendedorMeta, 
		this.viewPessoaVendedor, 
		this.viewPessoaCliente, 

  });
}
