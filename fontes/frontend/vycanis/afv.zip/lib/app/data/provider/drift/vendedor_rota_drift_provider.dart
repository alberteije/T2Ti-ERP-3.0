import 'package:afv/app/data/provider/drift/database/database_imports.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/data/provider/provider_base.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class VendedorRotaDriftProvider extends ProviderBase {

	Future<List<VendedorRotaModel>?> getList({Filter? filter}) async {
		List<VendedorRotaGrouped> vendedorRotaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				vendedorRotaDriftList = await Session.database.vendedorRotaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				vendedorRotaDriftList = await Session.database.vendedorRotaDao.getGroupedList(); 
			}
			if (vendedorRotaDriftList.isNotEmpty) {
				return toListModel(vendedorRotaDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<VendedorRotaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.vendedorRotaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendedorRotaModel?>? insert(VendedorRotaModel vendedorRotaModel) async {
		try {
			final lastPk = await Session.database.vendedorRotaDao.insertObject(toDrift(vendedorRotaModel));
			vendedorRotaModel.id = lastPk;
			return vendedorRotaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendedorRotaModel?>? update(VendedorRotaModel vendedorRotaModel) async {
		try {
			await Session.database.vendedorRotaDao.updateObject(toDrift(vendedorRotaModel));
			return vendedorRotaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.vendedorRotaDao.deleteObject(toDrift(VendedorRotaModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<VendedorRotaModel> toListModel(List<VendedorRotaGrouped> vendedorRotaDriftList) {
		List<VendedorRotaModel> listModel = [];
		for (var vendedorRotaDrift in vendedorRotaDriftList) {
			listModel.add(toModel(vendedorRotaDrift)!);
		}
		return listModel;
	}	

	VendedorRotaModel? toModel(VendedorRotaGrouped? vendedorRotaDrift) {
		if (vendedorRotaDrift != null) {
			return VendedorRotaModel(
				id: vendedorRotaDrift.vendedorRota?.id,
				idVendedor: vendedorRotaDrift.vendedorRota?.idVendedor,
				idCliente: vendedorRotaDrift.vendedorRota?.idCliente,
				dataRota: vendedorRotaDrift.vendedorRota?.dataRota,
				status: VendedorRotaDomain.getStatus(vendedorRotaDrift.vendedorRota?.status),
				observacao: vendedorRotaDrift.vendedorRota?.observacao,
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: vendedorRotaDrift.viewPessoaCliente?.id,
					nome: vendedorRotaDrift.viewPessoaCliente?.nome,
					tipo: vendedorRotaDrift.viewPessoaCliente?.tipo,
					email: vendedorRotaDrift.viewPessoaCliente?.email,
					site: vendedorRotaDrift.viewPessoaCliente?.site,
					cpfCnpj: vendedorRotaDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: vendedorRotaDrift.viewPessoaCliente?.rgIe,
					desde: vendedorRotaDrift.viewPessoaCliente?.desde,
					taxaDesconto: vendedorRotaDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: vendedorRotaDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: vendedorRotaDrift.viewPessoaCliente?.dataCadastro,
					observacao: vendedorRotaDrift.viewPessoaCliente?.observacao,
					idPessoa: vendedorRotaDrift.viewPessoaCliente?.idPessoa,
				),
				viewPessoaVendedorModel: ViewPessoaVendedorModel(
					id: vendedorRotaDrift.viewPessoaVendedor?.id,
					nome: vendedorRotaDrift.viewPessoaVendedor?.nome,
					tipo: vendedorRotaDrift.viewPessoaVendedor?.tipo,
					email: vendedorRotaDrift.viewPessoaVendedor?.email,
					site: vendedorRotaDrift.viewPessoaVendedor?.site,
					cpfCnpj: vendedorRotaDrift.viewPessoaVendedor?.cpfCnpj,
					rgIe: vendedorRotaDrift.viewPessoaVendedor?.rgIe,
					matricula: vendedorRotaDrift.viewPessoaVendedor?.matricula,
					dataCadastro: vendedorRotaDrift.viewPessoaVendedor?.dataCadastro,
					dataAdmissao: vendedorRotaDrift.viewPessoaVendedor?.dataAdmissao,
					dataDemissao: vendedorRotaDrift.viewPessoaVendedor?.dataDemissao,
					ctpsNumero: vendedorRotaDrift.viewPessoaVendedor?.ctpsNumero,
					ctpsSerie: vendedorRotaDrift.viewPessoaVendedor?.ctpsSerie,
					ctpsDataExpedicao: vendedorRotaDrift.viewPessoaVendedor?.ctpsDataExpedicao,
					ctpsUf: vendedorRotaDrift.viewPessoaVendedor?.ctpsUf,
					observacao: vendedorRotaDrift.viewPessoaVendedor?.observacao,
					logradouro: vendedorRotaDrift.viewPessoaVendedor?.logradouro,
					numero: vendedorRotaDrift.viewPessoaVendedor?.numero,
					complemento: vendedorRotaDrift.viewPessoaVendedor?.complemento,
					bairro: vendedorRotaDrift.viewPessoaVendedor?.bairro,
					cidade: vendedorRotaDrift.viewPessoaVendedor?.cidade,
					cep: vendedorRotaDrift.viewPessoaVendedor?.cep,
					municipioIbge: vendedorRotaDrift.viewPessoaVendedor?.municipioIbge,
					uf: vendedorRotaDrift.viewPessoaVendedor?.uf,
					idPessoa: vendedorRotaDrift.viewPessoaVendedor?.idPessoa,
					idCargo: vendedorRotaDrift.viewPessoaVendedor?.idCargo,
					idSetor: vendedorRotaDrift.viewPessoaVendedor?.idSetor,
					comissao: vendedorRotaDrift.viewPessoaVendedor?.comissao,
					metaVenda: vendedorRotaDrift.viewPessoaVendedor?.metaVenda,
				),
				vendedorVisitaModelList: vendedorVisitaDriftToModel(vendedorRotaDrift.vendedorVisitaGroupedList),
			);
		} else {
			return null;
		}
	}

	List<VendedorVisitaModel> vendedorVisitaDriftToModel(List<VendedorVisitaGrouped>? vendedorVisitaDriftList) { 
		List<VendedorVisitaModel> vendedorVisitaModelList = [];
		if (vendedorVisitaDriftList != null) {
			for (var vendedorVisitaGrouped in vendedorVisitaDriftList) {
				vendedorVisitaModelList.add(
					VendedorVisitaModel(
						id: vendedorVisitaGrouped.vendedorVisita?.id,
						idVendedorRota: vendedorVisitaGrouped.vendedorVisita?.idVendedorRota,
						idVendaCabecalho: vendedorVisitaGrouped.vendedorVisita?.idVendaCabecalho,
						vendaCabecalhoModel: VendaCabecalhoModel(
							id: vendedorVisitaGrouped.vendaCabecalho?.id,
							idNotaFiscalTipo: vendedorVisitaGrouped.vendaCabecalho?.idNotaFiscalTipo,
							idVendedor: vendedorVisitaGrouped.vendaCabecalho?.idVendedor,
							idVendaOrcamentoCabecalho: vendedorVisitaGrouped.vendaCabecalho?.idVendaOrcamentoCabecalho,
							idVendaCondicoesPagamento: vendedorVisitaGrouped.vendaCabecalho?.idVendaCondicoesPagamento,
							idTransportadora: vendedorVisitaGrouped.vendaCabecalho?.idTransportadora,
							idCliente: vendedorVisitaGrouped.vendaCabecalho?.idCliente,
							localEntrega: vendedorVisitaGrouped.vendaCabecalho?.localEntrega,
							localCobranca: vendedorVisitaGrouped.vendaCabecalho?.localCobranca,
							tipoFrete: vendedorVisitaGrouped.vendaCabecalho?.tipoFrete,
							formaPagamento: vendedorVisitaGrouped.vendaCabecalho?.formaPagamento,
							dataVenda: vendedorVisitaGrouped.vendaCabecalho?.dataVenda,
							dataSaida: vendedorVisitaGrouped.vendaCabecalho?.dataSaida,
							horaSaida: vendedorVisitaGrouped.vendaCabecalho?.horaSaida,
							numeroFatura: vendedorVisitaGrouped.vendaCabecalho?.numeroFatura,
							valorFrete: vendedorVisitaGrouped.vendaCabecalho?.valorFrete,
							valorSeguro: vendedorVisitaGrouped.vendaCabecalho?.valorSeguro,
							valorSubtotal: vendedorVisitaGrouped.vendaCabecalho?.valorSubtotal,
							taxaComissao: vendedorVisitaGrouped.vendaCabecalho?.taxaComissao,
							valorComissao: vendedorVisitaGrouped.vendaCabecalho?.valorComissao,
							taxaDesconto: vendedorVisitaGrouped.vendaCabecalho?.taxaDesconto,
							valorDesconto: vendedorVisitaGrouped.vendaCabecalho?.valorDesconto,
							valorTotal: vendedorVisitaGrouped.vendaCabecalho?.valorTotal,
							situacao: vendedorVisitaGrouped.vendaCabecalho?.situacao,
							diaFixoParcela: vendedorVisitaGrouped.vendaCabecalho?.diaFixoParcela,
							observacao: vendedorVisitaGrouped.vendaCabecalho?.observacao,
						),
						idVendaOrcamentoCabecalho: vendedorVisitaGrouped.vendedorVisita?.idVendaOrcamentoCabecalho,
						vendaOrcamentoCabecalhoModel: VendaOrcamentoCabecalhoModel(
							id: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.id,
							idCliente: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.idCliente,
							idVendedor: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.idVendedor,
							idTransportadora: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.idTransportadora,
							idVendaCondicoesPagamento: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.idVendaCondicoesPagamento,
							tipoFrete: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.tipoFrete,
							codigo: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.codigo,
							dataCadastro: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.dataCadastro,
							dataEntrega: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.dataEntrega,
							dataValidade: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.dataValidade,
							valorSubtotal: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.valorSubtotal,
							valorFrete: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.valorFrete,
							taxaComissao: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.taxaComissao,
							valorComissao: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.valorComissao,
							taxaDesconto: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.taxaDesconto,
							valorDesconto: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.valorDesconto,
							valorTotal: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.valorTotal,
							observacao: vendedorVisitaGrouped.vendaOrcamentoCabecalho?.observacao,
						),
						dataPrevista: vendedorVisitaGrouped.vendedorVisita?.dataPrevista,
						dataRealizada: vendedorVisitaGrouped.vendedorVisita?.dataRealizada,
						horaInicio: vendedorVisitaGrouped.vendedorVisita?.horaInicio,
						horaFim: vendedorVisitaGrouped.vendedorVisita?.horaFim,
						latitude: vendedorVisitaGrouped.vendedorVisita?.latitude,
						longitude: vendedorVisitaGrouped.vendedorVisita?.longitude,
						observacao: vendedorVisitaGrouped.vendedorVisita?.observacao,
					)
				);
			}
			return vendedorVisitaModelList;
		}
		return [];
	}


	VendedorRotaGrouped toDrift(VendedorRotaModel vendedorRotaModel) {
		return VendedorRotaGrouped(
			vendedorRota: VendedorRota(
				id: vendedorRotaModel.id,
				idVendedor: vendedorRotaModel.idVendedor,
				idCliente: vendedorRotaModel.idCliente,
				dataRota: vendedorRotaModel.dataRota,
				status: VendedorRotaDomain.setStatus(vendedorRotaModel.status),
				observacao: vendedorRotaModel.observacao,
			),
			vendedorVisitaGroupedList: vendedorVisitaModelToDrift(vendedorRotaModel.vendedorVisitaModelList),
		);
	}

	List<VendedorVisitaGrouped> vendedorVisitaModelToDrift(List<VendedorVisitaModel>? vendedorVisitaModelList) { 
		List<VendedorVisitaGrouped> vendedorVisitaGroupedList = [];
		if (vendedorVisitaModelList != null) {
			for (var vendedorVisitaModel in vendedorVisitaModelList) {
				vendedorVisitaGroupedList.add(
					VendedorVisitaGrouped(
						vendedorVisita: VendedorVisita(
							id: vendedorVisitaModel.id,
							idVendedorRota: vendedorVisitaModel.idVendedorRota,
							idVendaCabecalho: vendedorVisitaModel.idVendaCabecalho,
							idVendaOrcamentoCabecalho: vendedorVisitaModel.idVendaOrcamentoCabecalho,
							dataPrevista: vendedorVisitaModel.dataPrevista,
							dataRealizada: vendedorVisitaModel.dataRealizada,
							horaInicio: Util.removeMask(vendedorVisitaModel.horaInicio),
							horaFim: Util.removeMask(vendedorVisitaModel.horaFim),
							latitude: vendedorVisitaModel.latitude,
							longitude: vendedorVisitaModel.longitude,
							observacao: vendedorVisitaModel.observacao,
						),
					),
				);
			}
			return vendedorVisitaGroupedList;
		}
		return [];
	}

		
}
