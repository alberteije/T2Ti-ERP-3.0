import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';

@DataClassName("ViewFinLancamentoReceber")
class ViewFinLancamentoRecebers extends Table {
	@override
	String get tableName => 'view_fin_lancamento_receber';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idFinLancamentoReceber => integer().named('id_fin_lancamento_receber').nullable()();
	IntColumn get quantidadeParcela => integer().named('quantidade_parcela').nullable()();
	RealColumn get valorLancamento => real().named('valor_lancamento').nullable()();
	DateTimeColumn get dataLancamento => dateTime().named('data_lancamento').nullable()();
	TextColumn get numeroDocumento => text().named('numero_documento').withLength(min: 0, max: 20).nullable()();
	IntColumn get idFinParcelaReceber => integer().named('id_fin_parcela_receber').nullable()();
	IntColumn get numeroParcela => integer().named('numero_parcela').nullable()();
	DateTimeColumn get dataVencimento => dateTime().named('data_vencimento').nullable()();
	DateTimeColumn get dataRecebimento => dateTime().named('data_recebimento').nullable()();
	RealColumn get valorParcela => real().named('valor_parcela').nullable()();
	RealColumn get taxaJuro => real().named('taxa_juro').nullable()();
	RealColumn get valorJuro => real().named('valor_juro').nullable()();
	RealColumn get taxaMulta => real().named('taxa_multa').nullable()();
	RealColumn get valorMulta => real().named('valor_multa').nullable()();
	RealColumn get taxaDesconto => real().named('taxa_desconto').nullable()();
	RealColumn get valorDesconto => real().named('valor_desconto').nullable()();
	TextColumn get siglaDocumento => text().named('sigla_documento').withLength(min: 0, max: 10).nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	IntColumn get idPessoa => integer().named('id_pessoa').nullable()();
	TextColumn get nomeCliente => text().named('nome_cliente').withLength(min: 0, max: 150).nullable()();
	IntColumn get idFinStatusParcela => integer().named('id_fin_status_parcela').nullable()();
	TextColumn get situacaoParcela => text().named('situacao_parcela').withLength(min: 0, max: 2).nullable()();
	TextColumn get descricaoSituacaoParcela => text().named('descricao_situacao_parcela').withLength(min: 0, max: 255).nullable()();
	IntColumn get idBancoContaCaixa => integer().named('id_banco_conta_caixa').nullable()();
	TextColumn get nomeContaCaixa => text().named('nome_conta_caixa').withLength(min: 0, max: 100).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ViewFinLancamentoReceberGrouped {
	ViewFinLancamentoReceber? viewFinLancamentoReceber; 

  ViewFinLancamentoReceberGrouped({
		this.viewFinLancamentoReceber, 

  });
}
