import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';

@DataClassName("VendedorVisita")
class VendedorVisitas extends Table {
	@override
	String get tableName => 'vendedor_visita';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idVendedorRota => integer().named('id_vendedor_rota').nullable()();
	IntColumn get idVendaCabecalho => integer().named('id_venda_cabecalho').nullable()();
	IntColumn get idVendaOrcamentoCabecalho => integer().named('id_venda_orcamento_cabecalho').nullable()();
	DateTimeColumn get dataPrevista => dateTime().named('data_prevista').nullable()();
	DateTimeColumn get dataRealizada => dateTime().named('data_realizada').nullable()();
	TextColumn get horaInicio => text().named('hora_inicio').withLength(min: 0, max: 8).nullable()();
	TextColumn get horaFim => text().named('hora_fim').withLength(min: 0, max: 8).nullable()();
	RealColumn get latitude => real().named('latitude').nullable()();
	RealColumn get longitude => real().named('longitude').nullable()();
	TextColumn get observacao => text().named('observacao').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class VendedorVisitaGrouped {
	VendedorVisita? vendedorVisita; 
	VendaCabecalho? vendaCabecalho; 
	VendaOrcamentoCabecalho? vendaOrcamentoCabecalho; 

  VendedorVisitaGrouped({
		this.vendedorVisita, 
		this.vendaCabecalho, 
		this.vendaOrcamentoCabecalho, 

  });
}
