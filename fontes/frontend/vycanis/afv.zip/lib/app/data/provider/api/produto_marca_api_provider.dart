import 'package:afv/app/data/provider/api/api_provider_base.dart';
import 'package:afv/app/data/model/model_imports.dart';

class ProdutoMarcaApiProvider extends ApiProviderBase {
  static const _path = '/produto-marca';

  Future<List<ProdutoMarcaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ProdutoMarcaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ProdutoMarcaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ProdutoMarcaModel.fromJson(json),
    );
  }

  Future<ProdutoMarcaModel?>? insert(ProdutoMarcaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ProdutoMarcaModel.fromJson(json),
    );
  }

  Future<ProdutoMarcaModel?>? update(ProdutoMarcaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ProdutoMarcaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
