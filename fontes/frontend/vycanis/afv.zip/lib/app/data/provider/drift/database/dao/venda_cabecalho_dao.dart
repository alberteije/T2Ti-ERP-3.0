import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/provider/drift/database/database_imports.dart';

part 'venda_cabecalho_dao.g.dart';

@DriftAccessor(tables: [
	VendaCabecalhos,
	VendaDetalhes,
	Produtos,
	VendaFretes,
	ViewPessoaTransportadoras,
	VendaCondicoesPagamentos,
	ViewPessoaVendedors,
	ViewPessoaTransportadoras,
	NotaFiscalTipos,
	ViewPessoaClientes,
	VendaOrcamentoCabecalhos,
])
class VendaCabecalhoDao extends DatabaseAccessor<AppDatabase> with _$VendaCabecalhoDaoMixin {
	final AppDatabase db;

	List<VendaCabecalho> vendaCabecalhoList = []; 
	List<VendaCabecalhoGrouped> vendaCabecalhoGroupedList = []; 

	VendaCabecalhoDao(this.db) : super(db);

	Future<List<VendaCabecalho>> getList() async {
		vendaCabecalhoList = await select(vendaCabecalhos).get();
		return vendaCabecalhoList;
	}

	Future<List<VendaCabecalho>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		vendaCabecalhoList = await (select(vendaCabecalhos)..where((t) => expression)).get();
		return vendaCabecalhoList;	 
	}

	Future<List<VendaCabecalhoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(vendaCabecalhos)
			.join([ 
				leftOuterJoin(vendaCondicoesPagamentos, vendaCondicoesPagamentos.id.equalsExp(vendaCabecalhos.idVendaCondicoesPagamento)), 
			]).join([ 
				leftOuterJoin(viewPessoaVendedors, viewPessoaVendedors.id.equalsExp(vendaCabecalhos.idVendedor)), 
			]).join([ 
				leftOuterJoin(viewPessoaTransportadoras, viewPessoaTransportadoras.id.equalsExp(vendaCabecalhos.idTransportadora)), 
			]).join([ 
				leftOuterJoin(notaFiscalTipos, notaFiscalTipos.id.equalsExp(vendaCabecalhos.idNotaFiscalTipo)), 
			]).join([ 
				leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(vendaCabecalhos.idCliente)), 
			]).join([ 
				leftOuterJoin(vendaOrcamentoCabecalhos, vendaOrcamentoCabecalhos.id.equalsExp(vendaCabecalhos.idVendaOrcamentoCabecalho)), 
			]);

		if (field != null && field != '') { 
			final column = vendaCabecalhos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		vendaCabecalhoGroupedList = await query.map((row) {
			final vendaCabecalho = row.readTableOrNull(vendaCabecalhos); 
			final vendaCondicoesPagamento = row.readTableOrNull(vendaCondicoesPagamentos); 
			final viewPessoaVendedor = row.readTableOrNull(viewPessoaVendedors); 
			final viewPessoaTransportadora = row.readTableOrNull(viewPessoaTransportadoras); 
			final notaFiscalTipo = row.readTableOrNull(notaFiscalTipos); 
			final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 
			final vendaOrcamentoCabecalho = row.readTableOrNull(vendaOrcamentoCabecalhos); 

			return VendaCabecalhoGrouped(
				vendaCabecalho: vendaCabecalho, 
				vendaCondicoesPagamento: vendaCondicoesPagamento, 
				viewPessoaVendedor: viewPessoaVendedor, 
				viewPessoaTransportadora: viewPessoaTransportadora, 
				notaFiscalTipo: notaFiscalTipo, 
				viewPessoaCliente: viewPessoaCliente, 
				vendaOrcamentoCabecalho: vendaOrcamentoCabecalho, 
			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var vendaCabecalhoGrouped in vendaCabecalhoGroupedList) {
			vendaCabecalhoGrouped.vendaDetalheGroupedList = [];
			final queryVendaDetalhe = ' id_venda_cabecalho = ${vendaCabecalhoGrouped.vendaCabecalho!.id}';
			expression = CustomExpression<bool>(queryVendaDetalhe);
			final vendaDetalheList = await (select(vendaDetalhes)..where((t) => expression)).get();
			for (var vendaDetalhe in vendaDetalheList) {
				VendaDetalheGrouped vendaDetalheGrouped = VendaDetalheGrouped(
					vendaDetalhe: vendaDetalhe,
					produto: await (select(produtos)..where((t) => t.id.equals(vendaDetalhe.idProduto!))).getSingleOrNull(),
				);
				vendaCabecalhoGrouped.vendaDetalheGroupedList!.add(vendaDetalheGrouped);
			}

			vendaCabecalhoGrouped.vendaFreteGroupedList = [];
			final queryVendaFrete = ' id_venda_cabecalho = ${vendaCabecalhoGrouped.vendaCabecalho!.id}';
			expression = CustomExpression<bool>(queryVendaFrete);
			final vendaFreteList = await (select(vendaFretes)..where((t) => expression)).get();
			for (var vendaFrete in vendaFreteList) {
				VendaFreteGrouped vendaFreteGrouped = VendaFreteGrouped(
					vendaFrete: vendaFrete,
					viewPessoaTransportadora: await (select(viewPessoaTransportadoras)..where((t) => t.id.equals(vendaFrete.idTransportadora!))).getSingleOrNull(),
				);
				vendaCabecalhoGrouped.vendaFreteGroupedList!.add(vendaFreteGrouped);
			}

		}		

		return vendaCabecalhoGroupedList;	
	}

	Future<VendaCabecalho?> getObject(dynamic pk) async {
		return await (select(vendaCabecalhos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<VendaCabecalho?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM venda_cabecalho WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as VendaCabecalho;		 
	} 

	Future<VendaCabecalhoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(VendaCabecalhoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.vendaCabecalho = object.vendaCabecalho!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(vendaCabecalhos).insert(object.vendaCabecalho!);
			object.vendaCabecalho = object.vendaCabecalho!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(VendaCabecalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(vendaCabecalhos).replace(object.vendaCabecalho!);
		});	 
	} 

	Future<int> deleteObject(VendaCabecalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(vendaCabecalhos).delete(object.vendaCabecalho!);
		});		
	}

	Future<void> insertChildren(VendaCabecalhoGrouped object) async {
		for (var vendaDetalheGrouped in object.vendaDetalheGroupedList!) {
			vendaDetalheGrouped.vendaDetalhe = vendaDetalheGrouped.vendaDetalhe?.copyWith(
				id: const Value(null),
				idVendaCabecalho: Value(object.vendaCabecalho!.id),
			);
			await into(vendaDetalhes).insert(vendaDetalheGrouped.vendaDetalhe!);
		}
		for (var vendaFreteGrouped in object.vendaFreteGroupedList!) {
			vendaFreteGrouped.vendaFrete = vendaFreteGrouped.vendaFrete?.copyWith(
				id: const Value(null),
				idVendaCabecalho: Value(object.vendaCabecalho!.id),
			);
			await into(vendaFretes).insert(vendaFreteGrouped.vendaFrete!);
		}
	}
	
	Future<void> deleteChildren(VendaCabecalhoGrouped object) async {
		await (delete(vendaDetalhes)..where((t) => t.idVendaCabecalho.equals(object.vendaCabecalho!.id!))).go();
		await (delete(vendaFretes)..where((t) => t.idVendaCabecalho.equals(object.vendaCabecalho!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from venda_cabecalho").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 

  // Adicionar ao VendaCabecalhoDao (em venda_cabecalho_dao.dart)
  Future<double> getVendasDoMes(int idVendedor, DateTime primeiroDiaMes) async {
    // const query = '''
    //   SELECT COALESCE(SUM(valor_total), 0) as total
    //   FROM venda_cabecalho 
    //   WHERE id_vendedor = ? 
    //   AND date(data_venda) >= date(?)
    //   AND situacao = 'F'
    // ''';

    // final result = await customSelect(query, 
    //   variables: [Variable(idVendedor), Variable(primeiroDiaMes.toIso8601String())])
    //   .getSingleOrNull();

    const query = '''
      SELECT COALESCE(SUM(valor_total), 0) as total
      FROM venda_cabecalho 
    ''';

    final result = await customSelect(query, 
      variables: [])
      .getSingleOrNull();
    
    return result?.read<double>('total') ?? 0;
  }

  Future<int> getClientesAtivos(int idVendedor, DateTime hoje) async {
    // const query = '''
    //   SELECT COUNT(DISTINCT id_cliente) as total
    //   FROM venda_cabecalho 
    //   WHERE id_vendedor = ? 
    //   AND date(data_venda) >= date(?, '-3 months')
    //   AND situacao = 'F'
    // ''';
    
    // final result = await customSelect(query,
    //   variables: [Variable(idVendedor), Variable(hoje.toIso8601String())])
    //   .getSingleOrNull();

    const query = '''
      SELECT COUNT(DISTINCT id_cliente) as total
      FROM venda_cabecalho 
    ''';
    
    final result = await customSelect(query,
      variables: [])
      .getSingleOrNull();

    return result?.read<int>('total') ?? 0;
  }

  Future<List<Map<String, dynamic>>> getUltimasVendas(int idVendedor, int limite) async {
    const query = '''
      SELECT 
        vc.id,
        vc.data_venda,
        vc.valor_total,
        c.nome as cliente_nome
      FROM venda_cabecalho vc
      INNER JOIN view_pessoa_cliente c ON vc.id_cliente = c.id
      WHERE vc.id_vendedor = ?
      ORDER BY vc.data_venda DESC
      LIMIT ?
    ''';
    
    final results = await customSelect(query,
      variables: [Variable(idVendedor), Variable(limite)])
      .get();
    
    return results.map((row) {
      return {
        'id': row.read<int>('id'),
        'data_venda': row.read<String>('data_venda'),
        'valor_total': row.read<double>('valor_total'),
        'cliente_nome': row.read<String>('cliente_nome'),
      };
    }).toList();
  }
}