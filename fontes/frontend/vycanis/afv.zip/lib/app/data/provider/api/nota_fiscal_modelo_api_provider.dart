import 'package:afv/app/data/provider/api/api_provider_base.dart';
import 'package:afv/app/data/model/model_imports.dart';

class NotaFiscalModeloApiProvider extends ApiProviderBase {
  static const _path = '/nota-fiscal-modelo';

  Future<List<NotaFiscalModeloModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => NotaFiscalModeloModel.fromJson(json),
      filter: filter,
    );
  }

  Future<NotaFiscalModeloModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => NotaFiscalModeloModel.fromJson(json),
    );
  }

  Future<NotaFiscalModeloModel?>? insert(NotaFiscalModeloModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => NotaFiscalModeloModel.fromJson(json),
    );
  }

  Future<NotaFiscalModeloModel?>? update(NotaFiscalModeloModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => NotaFiscalModeloModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
