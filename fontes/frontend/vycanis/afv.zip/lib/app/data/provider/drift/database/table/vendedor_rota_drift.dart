import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/provider/drift/database/database_imports.dart';

@DataClassName("VendedorRota")
class VendedorRotas extends Table {
	@override
	String get tableName => 'vendedor_rota';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idVendedor => integer().named('id_vendedor').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	DateTimeColumn get dataRota => dateTime().named('data_rota').nullable()();
	TextColumn get status => text().named('status').withLength(min: 0, max: 1).nullable()();
	TextColumn get observacao => text().named('observacao').withLength(min: 0, max: 255).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class VendedorRotaGrouped {
	VendedorRota? vendedorRota; 
	ViewPessoaCliente? viewPessoaCliente; 
	ViewPessoaVendedor? viewPessoaVendedor; 
	List<VendedorVisitaGrouped>? vendedorVisitaGroupedList; 

  VendedorRotaGrouped({
		this.vendedorRota, 
		this.viewPessoaCliente, 
		this.viewPessoaVendedor, 
		this.vendedorVisitaGroupedList, 

  });
}
