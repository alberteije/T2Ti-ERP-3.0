import 'package:afv/app/data/provider/drift/database/database_imports.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/data/provider/provider_base.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class VendaCabecalhoDriftProvider extends ProviderBase {

	Future<List<VendaCabecalhoModel>?> getList({Filter? filter}) async {
		List<VendaCabecalhoGrouped> vendaCabecalhoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				vendaCabecalhoDriftList = await Session.database.vendaCabecalhoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				vendaCabecalhoDriftList = await Session.database.vendaCabecalhoDao.getGroupedList(); 
			}
			if (vendaCabecalhoDriftList.isNotEmpty) {
				return toListModel(vendaCabecalhoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<VendaCabecalhoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.vendaCabecalhoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendaCabecalhoModel?>? insert(VendaCabecalhoModel vendaCabecalhoModel) async {
		try {
			final lastPk = await Session.database.vendaCabecalhoDao.insertObject(toDrift(vendaCabecalhoModel));
			vendaCabecalhoModel.id = lastPk;
			return vendaCabecalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendaCabecalhoModel?>? update(VendaCabecalhoModel vendaCabecalhoModel) async {
		try {
			await Session.database.vendaCabecalhoDao.updateObject(toDrift(vendaCabecalhoModel));
			return vendaCabecalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.vendaCabecalhoDao.deleteObject(toDrift(VendaCabecalhoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<VendaCabecalhoModel> toListModel(List<VendaCabecalhoGrouped> vendaCabecalhoDriftList) {
		List<VendaCabecalhoModel> listModel = [];
		for (var vendaCabecalhoDrift in vendaCabecalhoDriftList) {
			listModel.add(toModel(vendaCabecalhoDrift)!);
		}
		return listModel;
	}	

	VendaCabecalhoModel? toModel(VendaCabecalhoGrouped? vendaCabecalhoDrift) {
		if (vendaCabecalhoDrift != null) {
			return VendaCabecalhoModel(
				id: vendaCabecalhoDrift.vendaCabecalho?.id,
				idNotaFiscalTipo: vendaCabecalhoDrift.vendaCabecalho?.idNotaFiscalTipo,
				idVendedor: vendaCabecalhoDrift.vendaCabecalho?.idVendedor,
				idVendaOrcamentoCabecalho: vendaCabecalhoDrift.vendaCabecalho?.idVendaOrcamentoCabecalho,
				idVendaCondicoesPagamento: vendaCabecalhoDrift.vendaCabecalho?.idVendaCondicoesPagamento,
				idTransportadora: vendaCabecalhoDrift.vendaCabecalho?.idTransportadora,
				idCliente: vendaCabecalhoDrift.vendaCabecalho?.idCliente,
				localEntrega: vendaCabecalhoDrift.vendaCabecalho?.localEntrega,
				localCobranca: vendaCabecalhoDrift.vendaCabecalho?.localCobranca,
				tipoFrete: VendaCabecalhoDomain.getTipoFrete(vendaCabecalhoDrift.vendaCabecalho?.tipoFrete),
				formaPagamento: VendaCabecalhoDomain.getFormaPagamento(vendaCabecalhoDrift.vendaCabecalho?.formaPagamento),
				dataVenda: vendaCabecalhoDrift.vendaCabecalho?.dataVenda,
				dataSaida: vendaCabecalhoDrift.vendaCabecalho?.dataSaida,
				horaSaida: vendaCabecalhoDrift.vendaCabecalho?.horaSaida,
				numeroFatura: vendaCabecalhoDrift.vendaCabecalho?.numeroFatura,
				valorFrete: vendaCabecalhoDrift.vendaCabecalho?.valorFrete,
				valorSeguro: vendaCabecalhoDrift.vendaCabecalho?.valorSeguro,
				valorSubtotal: vendaCabecalhoDrift.vendaCabecalho?.valorSubtotal,
				taxaComissao: vendaCabecalhoDrift.vendaCabecalho?.taxaComissao,
				valorComissao: vendaCabecalhoDrift.vendaCabecalho?.valorComissao,
				taxaDesconto: vendaCabecalhoDrift.vendaCabecalho?.taxaDesconto,
				valorDesconto: vendaCabecalhoDrift.vendaCabecalho?.valorDesconto,
				valorTotal: vendaCabecalhoDrift.vendaCabecalho?.valorTotal,
				situacao: VendaCabecalhoDomain.getSituacao(vendaCabecalhoDrift.vendaCabecalho?.situacao),
				diaFixoParcela: vendaCabecalhoDrift.vendaCabecalho?.diaFixoParcela,
				observacao: vendaCabecalhoDrift.vendaCabecalho?.observacao,
				vendaDetalheModelList: vendaDetalheDriftToModel(vendaCabecalhoDrift.vendaDetalheGroupedList),
				vendaFreteModelList: vendaFreteDriftToModel(vendaCabecalhoDrift.vendaFreteGroupedList),
				vendaCondicoesPagamentoModel: VendaCondicoesPagamentoModel(
					id: vendaCabecalhoDrift.vendaCondicoesPagamento?.id,
					nome: vendaCabecalhoDrift.vendaCondicoesPagamento?.nome,
					descricao: vendaCabecalhoDrift.vendaCondicoesPagamento?.descricao,
					faturamentoMinimo: vendaCabecalhoDrift.vendaCondicoesPagamento?.faturamentoMinimo,
					faturamentoMaximo: vendaCabecalhoDrift.vendaCondicoesPagamento?.faturamentoMaximo,
					indiceCorrecao: vendaCabecalhoDrift.vendaCondicoesPagamento?.indiceCorrecao,
					diasTolerancia: vendaCabecalhoDrift.vendaCondicoesPagamento?.diasTolerancia,
					valorTolerancia: vendaCabecalhoDrift.vendaCondicoesPagamento?.valorTolerancia,
					prazoMedio: vendaCabecalhoDrift.vendaCondicoesPagamento?.prazoMedio,
					vistaPrazo: vendaCabecalhoDrift.vendaCondicoesPagamento?.vistaPrazo,
				),
				viewPessoaVendedorModel: ViewPessoaVendedorModel(
					id: vendaCabecalhoDrift.viewPessoaVendedor?.id,
					nome: vendaCabecalhoDrift.viewPessoaVendedor?.nome,
					tipo: vendaCabecalhoDrift.viewPessoaVendedor?.tipo,
					email: vendaCabecalhoDrift.viewPessoaVendedor?.email,
					site: vendaCabecalhoDrift.viewPessoaVendedor?.site,
					cpfCnpj: vendaCabecalhoDrift.viewPessoaVendedor?.cpfCnpj,
					rgIe: vendaCabecalhoDrift.viewPessoaVendedor?.rgIe,
					matricula: vendaCabecalhoDrift.viewPessoaVendedor?.matricula,
					dataCadastro: vendaCabecalhoDrift.viewPessoaVendedor?.dataCadastro,
					dataAdmissao: vendaCabecalhoDrift.viewPessoaVendedor?.dataAdmissao,
					dataDemissao: vendaCabecalhoDrift.viewPessoaVendedor?.dataDemissao,
					ctpsNumero: vendaCabecalhoDrift.viewPessoaVendedor?.ctpsNumero,
					ctpsSerie: vendaCabecalhoDrift.viewPessoaVendedor?.ctpsSerie,
					ctpsDataExpedicao: vendaCabecalhoDrift.viewPessoaVendedor?.ctpsDataExpedicao,
					ctpsUf: vendaCabecalhoDrift.viewPessoaVendedor?.ctpsUf,
					observacao: vendaCabecalhoDrift.viewPessoaVendedor?.observacao,
					logradouro: vendaCabecalhoDrift.viewPessoaVendedor?.logradouro,
					numero: vendaCabecalhoDrift.viewPessoaVendedor?.numero,
					complemento: vendaCabecalhoDrift.viewPessoaVendedor?.complemento,
					bairro: vendaCabecalhoDrift.viewPessoaVendedor?.bairro,
					cidade: vendaCabecalhoDrift.viewPessoaVendedor?.cidade,
					cep: vendaCabecalhoDrift.viewPessoaVendedor?.cep,
					municipioIbge: vendaCabecalhoDrift.viewPessoaVendedor?.municipioIbge,
					uf: vendaCabecalhoDrift.viewPessoaVendedor?.uf,
					idPessoa: vendaCabecalhoDrift.viewPessoaVendedor?.idPessoa,
					idCargo: vendaCabecalhoDrift.viewPessoaVendedor?.idCargo,
					idSetor: vendaCabecalhoDrift.viewPessoaVendedor?.idSetor,
					comissao: vendaCabecalhoDrift.viewPessoaVendedor?.comissao,
					metaVenda: vendaCabecalhoDrift.viewPessoaVendedor?.metaVenda,
				),
				viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel(
					id: vendaCabecalhoDrift.viewPessoaTransportadora?.id,
					nome: vendaCabecalhoDrift.viewPessoaTransportadora?.nome,
					tipo: vendaCabecalhoDrift.viewPessoaTransportadora?.tipo,
					email: vendaCabecalhoDrift.viewPessoaTransportadora?.email,
					site: vendaCabecalhoDrift.viewPessoaTransportadora?.site,
					cpfCnpj: vendaCabecalhoDrift.viewPessoaTransportadora?.cpfCnpj,
					rgIe: vendaCabecalhoDrift.viewPessoaTransportadora?.rgIe,
					dataCadastro: vendaCabecalhoDrift.viewPessoaTransportadora?.dataCadastro,
					observacao: vendaCabecalhoDrift.viewPessoaTransportadora?.observacao,
					idPessoa: vendaCabecalhoDrift.viewPessoaTransportadora?.idPessoa,
				),
				notaFiscalTipoModel: NotaFiscalTipoModel(
					id: vendaCabecalhoDrift.notaFiscalTipo?.id,
					idNotaFiscalModelo: vendaCabecalhoDrift.notaFiscalTipo?.idNotaFiscalModelo,
					nome: vendaCabecalhoDrift.notaFiscalTipo?.nome,
					descricao: vendaCabecalhoDrift.notaFiscalTipo?.descricao,
					serie: vendaCabecalhoDrift.notaFiscalTipo?.serie,
					ultimoNumero: vendaCabecalhoDrift.notaFiscalTipo?.ultimoNumero,
				),
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: vendaCabecalhoDrift.viewPessoaCliente?.id,
					nome: vendaCabecalhoDrift.viewPessoaCliente?.nome,
					tipo: vendaCabecalhoDrift.viewPessoaCliente?.tipo,
					email: vendaCabecalhoDrift.viewPessoaCliente?.email,
					site: vendaCabecalhoDrift.viewPessoaCliente?.site,
					cpfCnpj: vendaCabecalhoDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: vendaCabecalhoDrift.viewPessoaCliente?.rgIe,
					desde: vendaCabecalhoDrift.viewPessoaCliente?.desde,
					taxaDesconto: vendaCabecalhoDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: vendaCabecalhoDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: vendaCabecalhoDrift.viewPessoaCliente?.dataCadastro,
					observacao: vendaCabecalhoDrift.viewPessoaCliente?.observacao,
					idPessoa: vendaCabecalhoDrift.viewPessoaCliente?.idPessoa,
				),
				vendaOrcamentoCabecalhoModel: VendaOrcamentoCabecalhoModel(
					id: vendaCabecalhoDrift.vendaOrcamentoCabecalho?.id,
				),
			);
		} else {
			return null;
		}
	}

	List<VendaDetalheModel> vendaDetalheDriftToModel(List<VendaDetalheGrouped>? vendaDetalheDriftList) { 
		List<VendaDetalheModel> vendaDetalheModelList = [];
		if (vendaDetalheDriftList != null) {
			for (var vendaDetalheGrouped in vendaDetalheDriftList) {
				vendaDetalheModelList.add(
					VendaDetalheModel(
						id: vendaDetalheGrouped.vendaDetalhe?.id,
						idVendaCabecalho: vendaDetalheGrouped.vendaDetalhe?.idVendaCabecalho,
						idProduto: vendaDetalheGrouped.vendaDetalhe?.idProduto,
						produtoModel: ProdutoModel(
							id: vendaDetalheGrouped.produto?.id,
							idProdutoSubgrupo: vendaDetalheGrouped.produto?.idProdutoSubgrupo,
							idProdutoMarca: vendaDetalheGrouped.produto?.idProdutoMarca,
							idProdutoUnidade: vendaDetalheGrouped.produto?.idProdutoUnidade,
							tipoItem: vendaDetalheGrouped.produto?.tipoItem,
							nome: vendaDetalheGrouped.produto?.nome,
							descricao: vendaDetalheGrouped.produto?.descricao,
							gtin: vendaDetalheGrouped.produto?.gtin,
							codigoInterno: vendaDetalheGrouped.produto?.codigoInterno,
							valorCompra: vendaDetalheGrouped.produto?.valorCompra,
							valorVenda: vendaDetalheGrouped.produto?.valorVenda,
							codigoNcm: vendaDetalheGrouped.produto?.codigoNcm,
							codigoNbs: vendaDetalheGrouped.produto?.codigoNbs,
							codigoCest: vendaDetalheGrouped.produto?.codigoCest,
							dataCadastro: vendaDetalheGrouped.produto?.dataCadastro,
							quantidadeEstoque: vendaDetalheGrouped.produto?.quantidadeEstoque,
							estoqueMinimo: vendaDetalheGrouped.produto?.estoqueMinimo,
							estoqueMaximo: vendaDetalheGrouped.produto?.estoqueMaximo,
							estoqueIdeal: vendaDetalheGrouped.produto?.estoqueIdeal,
							pesavel: vendaDetalheGrouped.produto?.pesavel,
							peso: vendaDetalheGrouped.produto?.peso,
							markup: vendaDetalheGrouped.produto?.markup,
							precoSugerido: vendaDetalheGrouped.produto?.precoSugerido,
							precoVendaMinimo: vendaDetalheGrouped.produto?.precoVendaMinimo,
							custoPercentual: vendaDetalheGrouped.produto?.custoPercentual,
							custoUnitario: vendaDetalheGrouped.produto?.custoUnitario,
							custoProducao: vendaDetalheGrouped.produto?.custoProducao,
							custoMedioLiquido: vendaDetalheGrouped.produto?.custoMedioLiquido,
							precoLucroZero: vendaDetalheGrouped.produto?.precoLucroZero,
							precoLucroMinimo: vendaDetalheGrouped.produto?.precoLucroMinimo,
							precoLucroMaximo: vendaDetalheGrouped.produto?.precoLucroMaximo,
							margemLucro: vendaDetalheGrouped.produto?.margemLucro,
							codigoBalanca: vendaDetalheGrouped.produto?.codigoBalanca,
							classeAbc: vendaDetalheGrouped.produto?.classeAbc,
							ativo: vendaDetalheGrouped.produto?.ativo,
							informacoesAdicionaisNfe: vendaDetalheGrouped.produto?.informacoesAdicionaisNfe,
						),
						quantidade: vendaDetalheGrouped.vendaDetalhe?.quantidade,
						valorUnitario: vendaDetalheGrouped.vendaDetalhe?.valorUnitario,
						valorSubtotal: vendaDetalheGrouped.vendaDetalhe?.valorSubtotal,
						taxaDesconto: vendaDetalheGrouped.vendaDetalhe?.taxaDesconto,
						valorDesconto: vendaDetalheGrouped.vendaDetalhe?.valorDesconto,
						valorTotal: vendaDetalheGrouped.vendaDetalhe?.valorTotal,
					)
				);
			}
			return vendaDetalheModelList;
		}
		return [];
	}

	List<VendaFreteModel> vendaFreteDriftToModel(List<VendaFreteGrouped>? vendaFreteDriftList) { 
		List<VendaFreteModel> vendaFreteModelList = [];
		if (vendaFreteDriftList != null) {
			for (var vendaFreteGrouped in vendaFreteDriftList) {
				vendaFreteModelList.add(
					VendaFreteModel(
						id: vendaFreteGrouped.vendaFrete?.id,
						idVendaCabecalho: vendaFreteGrouped.vendaFrete?.idVendaCabecalho,
						idTransportadora: vendaFreteGrouped.vendaFrete?.idTransportadora,
						viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel(
							id: vendaFreteGrouped.viewPessoaTransportadora?.id,
							nome: vendaFreteGrouped.viewPessoaTransportadora?.nome,
							tipo: vendaFreteGrouped.viewPessoaTransportadora?.tipo,
							email: vendaFreteGrouped.viewPessoaTransportadora?.email,
							site: vendaFreteGrouped.viewPessoaTransportadora?.site,
							cpfCnpj: vendaFreteGrouped.viewPessoaTransportadora?.cpfCnpj,
							rgIe: vendaFreteGrouped.viewPessoaTransportadora?.rgIe,
							dataCadastro: vendaFreteGrouped.viewPessoaTransportadora?.dataCadastro,
							observacao: vendaFreteGrouped.viewPessoaTransportadora?.observacao,
							idPessoa: vendaFreteGrouped.viewPessoaTransportadora?.idPessoa,
						),
						responsavel: VendaFreteDomain.getResponsavel(vendaFreteGrouped.vendaFrete?.responsavel),
						conhecimento: vendaFreteGrouped.vendaFrete?.conhecimento,
						placa: vendaFreteGrouped.vendaFrete?.placa,
						ufPlaca: VendaFreteDomain.getUfPlaca(vendaFreteGrouped.vendaFrete?.ufPlaca),
						seloFiscal: vendaFreteGrouped.vendaFrete?.seloFiscal,
						quantidadeVolume: vendaFreteGrouped.vendaFrete?.quantidadeVolume,
						marcaVolume: vendaFreteGrouped.vendaFrete?.marcaVolume,
						especieVolume: vendaFreteGrouped.vendaFrete?.especieVolume,
						pesoBruto: vendaFreteGrouped.vendaFrete?.pesoBruto,
						pesoLiquido: vendaFreteGrouped.vendaFrete?.pesoLiquido,
					)
				);
			}
			return vendaFreteModelList;
		}
		return [];
	}


	VendaCabecalhoGrouped toDrift(VendaCabecalhoModel vendaCabecalhoModel) {
		return VendaCabecalhoGrouped(
			vendaCabecalho: VendaCabecalho(
				id: vendaCabecalhoModel.id,
				idNotaFiscalTipo: vendaCabecalhoModel.idNotaFiscalTipo,
				idVendedor: vendaCabecalhoModel.idVendedor,
				idVendaOrcamentoCabecalho: vendaCabecalhoModel.idVendaOrcamentoCabecalho,
				idVendaCondicoesPagamento: vendaCabecalhoModel.idVendaCondicoesPagamento,
				idTransportadora: vendaCabecalhoModel.idTransportadora,
				idCliente: vendaCabecalhoModel.idCliente,
				localEntrega: vendaCabecalhoModel.localEntrega,
				localCobranca: vendaCabecalhoModel.localCobranca,
				tipoFrete: VendaCabecalhoDomain.setTipoFrete(vendaCabecalhoModel.tipoFrete),
				formaPagamento: VendaCabecalhoDomain.setFormaPagamento(vendaCabecalhoModel.formaPagamento),
				dataVenda: vendaCabecalhoModel.dataVenda,
				dataSaida: vendaCabecalhoModel.dataSaida,
				horaSaida: Util.removeMask(vendaCabecalhoModel.horaSaida),
				numeroFatura: vendaCabecalhoModel.numeroFatura,
				valorFrete: vendaCabecalhoModel.valorFrete,
				valorSeguro: vendaCabecalhoModel.valorSeguro,
				valorSubtotal: vendaCabecalhoModel.valorSubtotal,
				taxaComissao: vendaCabecalhoModel.taxaComissao,
				valorComissao: vendaCabecalhoModel.valorComissao,
				taxaDesconto: vendaCabecalhoModel.taxaDesconto,
				valorDesconto: vendaCabecalhoModel.valorDesconto,
				valorTotal: vendaCabecalhoModel.valorTotal,
				situacao: VendaCabecalhoDomain.setSituacao(vendaCabecalhoModel.situacao),
				diaFixoParcela: vendaCabecalhoModel.diaFixoParcela,
				observacao: vendaCabecalhoModel.observacao,
			),
			vendaDetalheGroupedList: vendaDetalheModelToDrift(vendaCabecalhoModel.vendaDetalheModelList),
			vendaFreteGroupedList: vendaFreteModelToDrift(vendaCabecalhoModel.vendaFreteModelList),
		);
	}

	List<VendaDetalheGrouped> vendaDetalheModelToDrift(List<VendaDetalheModel>? vendaDetalheModelList) { 
		List<VendaDetalheGrouped> vendaDetalheGroupedList = [];
		if (vendaDetalheModelList != null) {
			for (var vendaDetalheModel in vendaDetalheModelList) {
				vendaDetalheGroupedList.add(
					VendaDetalheGrouped(
						vendaDetalhe: VendaDetalhe(
							id: vendaDetalheModel.id,
							idVendaCabecalho: vendaDetalheModel.idVendaCabecalho,
							idProduto: vendaDetalheModel.idProduto,
							quantidade: vendaDetalheModel.quantidade,
							valorUnitario: vendaDetalheModel.valorUnitario,
							valorSubtotal: vendaDetalheModel.valorSubtotal,
							taxaDesconto: vendaDetalheModel.taxaDesconto,
							valorDesconto: vendaDetalheModel.valorDesconto,
							valorTotal: vendaDetalheModel.valorTotal,
						),
					),
				);
			}
			return vendaDetalheGroupedList;
		}
		return [];
	}

	List<VendaFreteGrouped> vendaFreteModelToDrift(List<VendaFreteModel>? vendaFreteModelList) { 
		List<VendaFreteGrouped> vendaFreteGroupedList = [];
		if (vendaFreteModelList != null) {
			for (var vendaFreteModel in vendaFreteModelList) {
				vendaFreteGroupedList.add(
					VendaFreteGrouped(
						vendaFrete: VendaFrete(
							id: vendaFreteModel.id,
							idVendaCabecalho: vendaFreteModel.idVendaCabecalho,
							idTransportadora: vendaFreteModel.idTransportadora,
							responsavel: VendaFreteDomain.setResponsavel(vendaFreteModel.responsavel),
							conhecimento: vendaFreteModel.conhecimento,
							placa: vendaFreteModel.placa,
							ufPlaca: VendaFreteDomain.setUfPlaca(vendaFreteModel.ufPlaca),
							seloFiscal: vendaFreteModel.seloFiscal,
							quantidadeVolume: vendaFreteModel.quantidadeVolume,
							marcaVolume: vendaFreteModel.marcaVolume,
							especieVolume: vendaFreteModel.especieVolume,
							pesoBruto: vendaFreteModel.pesoBruto,
							pesoLiquido: vendaFreteModel.pesoLiquido,
						),
					),
				);
			}
			return vendaFreteGroupedList;
		}
		return [];
	}

		
}
