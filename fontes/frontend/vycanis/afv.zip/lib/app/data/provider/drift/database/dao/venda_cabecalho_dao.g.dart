// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'venda_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$VendaCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $VendaCabecalhosTable get vendaCabecalhos => attachedDatabase.vendaCabecalhos;
  $VendaDetalhesTable get vendaDetalhes => attachedDatabase.vendaDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $VendaFretesTable get vendaFretes => attachedDatabase.vendaFretes;
  $ViewPessoaTransportadorasTable get viewPessoaTransportadoras =>
      attachedDatabase.viewPessoaTransportadoras;
  $VendaCondicoesPagamentosTable get vendaCondicoesPagamentos =>
      attachedDatabase.vendaCondicoesPagamentos;
  $ViewPessoaVendedorsTable get viewPessoaVendedors =>
      attachedDatabase.viewPessoaVendedors;
  $NotaFiscalTiposTable get notaFiscalTipos => attachedDatabase.notaFiscalTipos;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $VendaOrcamentoCabecalhosTable get vendaOrcamentoCabecalhos =>
      attachedDatabase.vendaOrcamentoCabecalhos;
}
