// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pessoa_dao.dart';

// ignore_for_file: type=lint
mixin _$PessoaDaoMixin on DatabaseAccessor<AppDatabase> {
  $PessoasTable get pessoas => attachedDatabase.pessoas;
  $PessoaJuridicasTable get pessoaJuridicas => attachedDatabase.pessoaJuridicas;
  $ClientesTable get clientes => attachedDatabase.clientes;
  $TabelaPrecosTable get tabelaPrecos => attachedDatabase.tabelaPrecos;
  $PessoaContatosTable get pessoaContatos => attachedDatabase.pessoaContatos;
  $PessoaTelefonesTable get pessoaTelefones => attachedDatabase.pessoaTelefones;
  $PessoaEnderecosTable get pessoaEnderecos => attachedDatabase.pessoaEnderecos;
  $ViewFinLancamentoRecebersTable get viewFinLancamentoRecebers =>
      attachedDatabase.viewFinLancamentoRecebers;
}
