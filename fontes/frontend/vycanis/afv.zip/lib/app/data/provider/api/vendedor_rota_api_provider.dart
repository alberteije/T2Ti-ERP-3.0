import 'package:afv/app/data/provider/api/api_provider_base.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendedorRotaApiProvider extends ApiProviderBase {
  static const _path = '/vendedor-rota';

  Future<List<VendedorRotaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => VendedorRotaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<VendedorRotaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => VendedorRotaModel.fromJson(json),
    );
  }

  Future<VendedorRotaModel?>? insert(VendedorRotaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => VendedorRotaModel.fromJson(json),
    );
  }

  Future<VendedorRotaModel?>? update(VendedorRotaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => VendedorRotaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
