// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vendedor_meta_dao.dart';

// ignore_for_file: type=lint
mixin _$VendedorMetaDaoMixin on DatabaseAccessor<AppDatabase> {
  $VendedorMetasTable get vendedorMetas => attachedDatabase.vendedorMetas;
  $ViewPessoaVendedorsTable get viewPessoaVendedors =>
      attachedDatabase.viewPessoaVendedors;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
