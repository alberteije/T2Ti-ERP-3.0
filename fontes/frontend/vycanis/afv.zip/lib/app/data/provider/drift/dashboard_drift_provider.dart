import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/data/provider/provider_base.dart';
import 'package:afv/app/controller/dashboard_controller.dart';

class DashboardDriftProvider extends ProviderBase {
  
  Future<DashboardData?> getDashboardData() async {
    try {
      final now = DateTime.now();
      final firstDayOfMonth = DateTime(now.year, now.month, 1);
      final today = DateTime(now.year, now.month, now.day);
      
      final usuario = Session.loggedInUser;
      
      final vendedor = await Session.database.viewPessoaVendedorDao
          .getByUsuarioId(usuario.id!);
      
      if (vendedor == null) return null;
      
      final dashboardData = DashboardData();
      
      // Informações do vendedor
      dashboardData.vendedorInfo = VendedorInfo(
        id: vendedor.id!,
        nome: vendedor.nome ?? 'Vendedor',
        email: vendedor.email,
        comissao: vendedor.comissao?.toDouble(),
        metaVenda: vendedor.metaVenda?.toDouble(),
      );
      
      // Total de vendas do mês
      final vendasResult = await Session.database.vendaCabecalhoDao
          .getVendasDoMes(vendedor.id!, firstDayOfMonth);
      dashboardData.totalVendasMes = vendasResult;
      
      // Total de orçamentos do mês
      final orcamentosResult = await Session.database.vendaOrcamentoCabecalhoDao
          .getOrcamentosDoMes(vendedor.id!, firstDayOfMonth);
      dashboardData.totalOrcamentosMes = orcamentosResult;
      
      // Visitas para hoje
      final visitasResult = await Session.database.vendedorRotaDao
          .getVisitasHoje(vendedor.id!, today);
      dashboardData.visitasHoje = visitasResult;
      
      // Clientes ativos
      final clientesResult = await Session.database.vendaCabecalhoDao
          .getClientesAtivos(vendedor.id!, today);
      dashboardData.clientesAtivos = clientesResult;
      
      // Valores a receber hoje
      final receberResult = await Session.database.pessoaDao
          .getReceberHoje(vendedor.id!, today);
      dashboardData.receberHoje = receberResult;
      
      // Meta atingida
      if (dashboardData.vendedorInfo!.metaVenda != null && 
          dashboardData.vendedorInfo!.metaVenda! > 0) {
        dashboardData.metaAtingida = 
            (dashboardData.totalVendasMes / dashboardData.vendedorInfo!.metaVenda!) * 100;
      }
      
      // Últimas vendas - Converter Map para VendaResumo
      final ultimasVendasMap = await Session.database.vendaCabecalhoDao
          .getUltimasVendas(vendedor.id!, 5);
      
      dashboardData.ultimasVendas = ultimasVendasMap.map((map) {
        return VendaResumo(
          id: map['id'] as int,
          data: DateTime.parse(map['data_venda'] as String),
          valor: map['valor_total'] as double,
          clienteNome: map['cliente_nome'] as String,
        );
      }).toList();
      
      // Próximas visitas - Converter Map para VisitaResumo
      final proximasVisitasMap = await Session.database.vendedorRotaDao
          .getProximasVisitas(vendedor.id!, today, 7);
      
      dashboardData.proximasVisitas = proximasVisitasMap.map((map) {
        return VisitaResumo(
          id: map['id'] as int,
          data: DateTime.fromMillisecondsSinceEpoch(map['data_rota'] as int),
          clienteNome: map['cliente_nome'] as String,
          observacao: map['observacao'] as String?,
        );
      }).toList();
      
      return dashboardData;
      
    } catch (e) {
      handleResultError(null, null, exception: e);
      return null;
    }
  }

}