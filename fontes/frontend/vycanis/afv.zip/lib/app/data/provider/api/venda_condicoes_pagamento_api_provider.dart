import 'package:afv/app/data/provider/api/api_provider_base.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendaCondicoesPagamentoApiProvider extends ApiProviderBase {
  static const _path = '/venda-condicoes-pagamento';

  Future<List<VendaCondicoesPagamentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => VendaCondicoesPagamentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<VendaCondicoesPagamentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => VendaCondicoesPagamentoModel.fromJson(json),
    );
  }

  Future<VendaCondicoesPagamentoModel?>? insert(VendaCondicoesPagamentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => VendaCondicoesPagamentoModel.fromJson(json),
    );
  }

  Future<VendaCondicoesPagamentoModel?>? update(VendaCondicoesPagamentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => VendaCondicoesPagamentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
