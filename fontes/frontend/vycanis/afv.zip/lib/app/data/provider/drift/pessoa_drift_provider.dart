import 'package:afv/app/data/provider/drift/database/database_imports.dart';
import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/data/provider/provider_base.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class PessoaDriftProvider extends ProviderBase {

	Future<List<PessoaModel>?> getList({Filter? filter}) async {
		List<PessoaGrouped> pessoaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				pessoaDriftList = await Session.database.pessoaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				pessoaDriftList = await Session.database.pessoaDao.getGroupedList(); 
			}
			if (pessoaDriftList.isNotEmpty) {
				return toListModel(pessoaDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<PessoaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.pessoaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<PessoaModel?>? insert(PessoaModel pessoaModel) async {
		try {
			final lastPk = await Session.database.pessoaDao.insertObject(toDrift(pessoaModel));
			pessoaModel.id = lastPk;
			return pessoaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<PessoaModel?>? update(PessoaModel pessoaModel) async {
		try {
			await Session.database.pessoaDao.updateObject(toDrift(pessoaModel));
			return pessoaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.pessoaDao.deleteObject(toDrift(PessoaModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<PessoaModel> toListModel(List<PessoaGrouped> pessoaDriftList) {
		List<PessoaModel> listModel = [];
		for (var pessoaDrift in pessoaDriftList) {
			listModel.add(toModel(pessoaDrift)!);
		}
		return listModel;
	}	

	PessoaModel? toModel(PessoaGrouped? pessoaDrift) {
		if (pessoaDrift != null) {
			return PessoaModel(
				id: pessoaDrift.pessoa?.id,
				nome: pessoaDrift.pessoa?.nome,
				tipo: PessoaDomain.getTipo(pessoaDrift.pessoa?.tipo),
				site: pessoaDrift.pessoa?.site,
				email: pessoaDrift.pessoa?.email,
				ehCliente: PessoaDomain.getEhCliente(pessoaDrift.pessoa?.ehCliente),
				ehFornecedor: PessoaDomain.getEhFornecedor(pessoaDrift.pessoa?.ehFornecedor),
				ehTransportadora: PessoaDomain.getEhTransportadora(pessoaDrift.pessoa?.ehTransportadora),
				ehColaborador: PessoaDomain.getEhColaborador(pessoaDrift.pessoa?.ehColaborador),
				ehContador: PessoaDomain.getEhContador(pessoaDrift.pessoa?.ehContador),
				situacaoContribuinte: PessoaDomain.getSituacaoContribuinte(pessoaDrift.pessoa?.situacaoContribuinte),
				ativo: PessoaDomain.getAtivo(pessoaDrift.pessoa?.ativo),
				pessoaJuridicaModel: PessoaJuridicaModel(
					id: pessoaDrift.pessoaJuridica?.id,
					idPessoa: pessoaDrift.pessoaJuridica?.idPessoa,
					cnpj: pessoaDrift.pessoaJuridica?.cnpj,
					nomeFantasia: pessoaDrift.pessoaJuridica?.nomeFantasia,
					inscricaoEstadual: pessoaDrift.pessoaJuridica?.inscricaoEstadual,
					inscricaoMunicipal: pessoaDrift.pessoaJuridica?.inscricaoMunicipal,
					dataConstituicao: pessoaDrift.pessoaJuridica?.dataConstituicao,
					tipoRegime: PessoaJuridicaDomain.getTipoRegime(pessoaDrift.pessoaJuridica?.tipoRegime),
					crt: PessoaJuridicaDomain.getCrt(pessoaDrift.pessoaJuridica?.crt),
				),
				clienteModel: ClienteModel(
					id: pessoaDrift.clienteGrouped?.cliente?.id,
					idPessoa: pessoaDrift.clienteGrouped?.cliente?.idPessoa,
					idTabelaPreco: pessoaDrift.clienteGrouped?.cliente?.idTabelaPreco,
					desde: pessoaDrift.clienteGrouped?.cliente?.desde,
					dataCadastro: pessoaDrift.clienteGrouped?.cliente?.dataCadastro,
					taxaDesconto: pessoaDrift.clienteGrouped?.cliente?.taxaDesconto,
					limiteCredito: pessoaDrift.clienteGrouped?.cliente?.limiteCredito,
					observacao: pessoaDrift.clienteGrouped?.cliente?.observacao,
					ehGoverno: ClienteDomain.getEhGoverno(pessoaDrift.clienteGrouped?.cliente?.ehGoverno),
					tipoEnteGovernamental: ClienteDomain.getTipoEnteGovernamental(pessoaDrift.clienteGrouped?.cliente?.tipoEnteGovernamental),
					governoPercentualReducao: pessoaDrift.clienteGrouped?.cliente?.governoPercentualReducao,
					tabelaPrecoModel: TabelaPrecoModel(
						id: pessoaDrift.clienteGrouped?.tabelaPreco?.id,
						nome: pessoaDrift.clienteGrouped?.tabelaPreco?.nome,
						principal: pessoaDrift.clienteGrouped?.tabelaPreco?.principal,
						coeficiente: pessoaDrift.clienteGrouped?.tabelaPreco?.coeficiente,
						valorFixo: pessoaDrift.clienteGrouped?.tabelaPreco?.valorFixo,
						tipoAjuste: pessoaDrift.clienteGrouped?.tabelaPreco?.tipoAjuste,
					),
				),
				pessoaContatoModelList: pessoaContatoDriftToModel(pessoaDrift.pessoaContatoGroupedList),
				pessoaTelefoneModelList: pessoaTelefoneDriftToModel(pessoaDrift.pessoaTelefoneGroupedList),
				pessoaEnderecoModelList: pessoaEnderecoDriftToModel(pessoaDrift.pessoaEnderecoGroupedList),
				viewFinLancamentoReceberModelList: viewFinLancamentoReceberDriftToModel(pessoaDrift.viewFinLancamentoReceberGroupedList),
			);
		} else {
			return null;
		}
	}

	List<PessoaContatoModel> pessoaContatoDriftToModel(List<PessoaContatoGrouped>? pessoaContatoDriftList) { 
		List<PessoaContatoModel> pessoaContatoModelList = [];
		if (pessoaContatoDriftList != null) {
			for (var pessoaContatoGrouped in pessoaContatoDriftList) {
				pessoaContatoModelList.add(
					PessoaContatoModel(
						id: pessoaContatoGrouped.pessoaContato?.id,
						idPessoa: pessoaContatoGrouped.pessoaContato?.idPessoa,
						nome: pessoaContatoGrouped.pessoaContato?.nome,
						email: pessoaContatoGrouped.pessoaContato?.email,
						observacao: pessoaContatoGrouped.pessoaContato?.observacao,
					)
				);
			}
			return pessoaContatoModelList;
		}
		return [];
	}

	List<PessoaTelefoneModel> pessoaTelefoneDriftToModel(List<PessoaTelefoneGrouped>? pessoaTelefoneDriftList) { 
		List<PessoaTelefoneModel> pessoaTelefoneModelList = [];
		if (pessoaTelefoneDriftList != null) {
			for (var pessoaTelefoneGrouped in pessoaTelefoneDriftList) {
				pessoaTelefoneModelList.add(
					PessoaTelefoneModel(
						id: pessoaTelefoneGrouped.pessoaTelefone?.id,
						idPessoa: pessoaTelefoneGrouped.pessoaTelefone?.idPessoa,
						tipo: PessoaTelefoneDomain.getTipo(pessoaTelefoneGrouped.pessoaTelefone?.tipo),
						numero: pessoaTelefoneGrouped.pessoaTelefone?.numero,
					)
				);
			}
			return pessoaTelefoneModelList;
		}
		return [];
	}

	List<PessoaEnderecoModel> pessoaEnderecoDriftToModel(List<PessoaEnderecoGrouped>? pessoaEnderecoDriftList) { 
		List<PessoaEnderecoModel> pessoaEnderecoModelList = [];
		if (pessoaEnderecoDriftList != null) {
			for (var pessoaEnderecoGrouped in pessoaEnderecoDriftList) {
				pessoaEnderecoModelList.add(
					PessoaEnderecoModel(
						id: pessoaEnderecoGrouped.pessoaEndereco?.id,
						idPessoa: pessoaEnderecoGrouped.pessoaEndereco?.idPessoa,
						logradouro: pessoaEnderecoGrouped.pessoaEndereco?.logradouro,
						numero: pessoaEnderecoGrouped.pessoaEndereco?.numero,
						complemento: pessoaEnderecoGrouped.pessoaEndereco?.complemento,
						bairro: pessoaEnderecoGrouped.pessoaEndereco?.bairro,
						cidade: pessoaEnderecoGrouped.pessoaEndereco?.cidade,
						uf: PessoaEnderecoDomain.getUf(pessoaEnderecoGrouped.pessoaEndereco?.uf),
						cep: pessoaEnderecoGrouped.pessoaEndereco?.cep,
						municipioIbge: pessoaEnderecoGrouped.pessoaEndereco?.municipioIbge,
						principal: PessoaEnderecoDomain.getPrincipal(pessoaEnderecoGrouped.pessoaEndereco?.principal),
						entrega: PessoaEnderecoDomain.getEntrega(pessoaEnderecoGrouped.pessoaEndereco?.entrega),
						cobranca: PessoaEnderecoDomain.getCobranca(pessoaEnderecoGrouped.pessoaEndereco?.cobranca),
						correspondencia: PessoaEnderecoDomain.getCorrespondencia(pessoaEnderecoGrouped.pessoaEndereco?.correspondencia),
					)
				);
			}
			return pessoaEnderecoModelList;
		}
		return [];
	}

	List<ViewFinLancamentoReceberModel> viewFinLancamentoReceberDriftToModel(List<ViewFinLancamentoReceberGrouped>? viewFinLancamentoReceberDriftList) { 
		List<ViewFinLancamentoReceberModel> viewFinLancamentoReceberModelList = [];
		if (viewFinLancamentoReceberDriftList != null) {
			for (var viewFinLancamentoReceberGrouped in viewFinLancamentoReceberDriftList) {
				viewFinLancamentoReceberModelList.add(
					ViewFinLancamentoReceberModel(
						id: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.id,
						idFinLancamentoReceber: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.idFinLancamentoReceber,
						quantidadeParcela: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.quantidadeParcela,
						valorLancamento: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.valorLancamento,
						dataLancamento: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.dataLancamento,
						numeroDocumento: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.numeroDocumento,
						idFinParcelaReceber: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.idFinParcelaReceber,
						numeroParcela: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.numeroParcela,
						dataVencimento: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.dataVencimento,
						dataRecebimento: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.dataRecebimento,
						valorParcela: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.valorParcela,
						taxaJuro: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.taxaJuro,
						valorJuro: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.valorJuro,
						taxaMulta: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.taxaMulta,
						valorMulta: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.valorMulta,
						taxaDesconto: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.taxaDesconto,
						valorDesconto: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.valorDesconto,
						siglaDocumento: ViewFinLancamentoReceberDomain.getSiglaDocumento(viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.siglaDocumento),
						idCliente: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.idCliente,
						idPessoa: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.idPessoa,
						nomeCliente: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.nomeCliente,
						idFinStatusParcela: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.idFinStatusParcela,
						situacaoParcela: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.situacaoParcela,
						descricaoSituacaoParcela: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.descricaoSituacaoParcela,
						idBancoContaCaixa: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.idBancoContaCaixa,
						nomeContaCaixa: viewFinLancamentoReceberGrouped.viewFinLancamentoReceber?.nomeContaCaixa,
					)
				);
			}
			return viewFinLancamentoReceberModelList;
		}
		return [];
	}


	PessoaGrouped toDrift(PessoaModel pessoaModel) {
		return PessoaGrouped(
			pessoa: Pessoa(
				id: pessoaModel.id,
				nome: pessoaModel.nome,
				tipo: PessoaDomain.setTipo(pessoaModel.tipo),
				site: pessoaModel.site,
				email: pessoaModel.email,
				ehCliente: PessoaDomain.setEhCliente(pessoaModel.ehCliente),
				ehFornecedor: PessoaDomain.setEhFornecedor(pessoaModel.ehFornecedor),
				ehTransportadora: PessoaDomain.setEhTransportadora(pessoaModel.ehTransportadora),
				ehColaborador: PessoaDomain.setEhColaborador(pessoaModel.ehColaborador),
				ehContador: PessoaDomain.setEhContador(pessoaModel.ehContador),
				situacaoContribuinte: PessoaDomain.setSituacaoContribuinte(pessoaModel.situacaoContribuinte),
				ativo: PessoaDomain.setAtivo(pessoaModel.ativo),
			),
			pessoaJuridica: PessoaJuridica(
				id: pessoaModel.pessoaJuridicaModel?.id,
				idPessoa: pessoaModel.pessoaJuridicaModel?.idPessoa,
				cnpj: Util.removeMask(pessoaModel.pessoaJuridicaModel?.cnpj),
				nomeFantasia: pessoaModel.pessoaJuridicaModel?.nomeFantasia,
				inscricaoEstadual: pessoaModel.pessoaJuridicaModel?.inscricaoEstadual,
				inscricaoMunicipal: pessoaModel.pessoaJuridicaModel?.inscricaoMunicipal,
				dataConstituicao: pessoaModel.pessoaJuridicaModel?.dataConstituicao,
				tipoRegime: PessoaJuridicaDomain.setTipoRegime(pessoaModel.pessoaJuridicaModel?.tipoRegime),
				crt: PessoaJuridicaDomain.setCrt(pessoaModel.pessoaJuridicaModel?.crt),
			),
			clienteGrouped: ClienteGrouped(
				cliente: Cliente(
					id: pessoaModel.clienteModel?.id,
					idPessoa: pessoaModel.clienteModel?.idPessoa,
					idTabelaPreco: pessoaModel.clienteModel?.idTabelaPreco,
					desde: pessoaModel.clienteModel?.desde,
					dataCadastro: pessoaModel.clienteModel?.dataCadastro,
					taxaDesconto: pessoaModel.clienteModel?.taxaDesconto,
					limiteCredito: pessoaModel.clienteModel?.limiteCredito,
					observacao: pessoaModel.clienteModel?.observacao,
					ehGoverno: ClienteDomain.setEhGoverno(pessoaModel.clienteModel?.ehGoverno),
					tipoEnteGovernamental: ClienteDomain.setTipoEnteGovernamental(pessoaModel.clienteModel?.tipoEnteGovernamental),
					governoPercentualReducao: pessoaModel.clienteModel?.governoPercentualReducao,
				),
				tabelaPreco: TabelaPreco(
					id: pessoaModel.clienteModel?.tabelaPrecoModel?.id,
					nome: pessoaModel.clienteModel?.tabelaPrecoModel?.nome,
					principal: pessoaModel.clienteModel?.tabelaPrecoModel?.principal,
					coeficiente: pessoaModel.clienteModel?.tabelaPrecoModel?.coeficiente,
					valorFixo: pessoaModel.clienteModel?.tabelaPrecoModel?.valorFixo,
					tipoAjuste: pessoaModel.clienteModel?.tabelaPrecoModel?.tipoAjuste,
				),
			),
			pessoaContatoGroupedList: pessoaContatoModelToDrift(pessoaModel.pessoaContatoModelList),
			pessoaTelefoneGroupedList: pessoaTelefoneModelToDrift(pessoaModel.pessoaTelefoneModelList),
			pessoaEnderecoGroupedList: pessoaEnderecoModelToDrift(pessoaModel.pessoaEnderecoModelList),
			viewFinLancamentoReceberGroupedList: viewFinLancamentoReceberModelToDrift(pessoaModel.viewFinLancamentoReceberModelList),
		);
	}

	List<PessoaContatoGrouped> pessoaContatoModelToDrift(List<PessoaContatoModel>? pessoaContatoModelList) { 
		List<PessoaContatoGrouped> pessoaContatoGroupedList = [];
		if (pessoaContatoModelList != null) {
			for (var pessoaContatoModel in pessoaContatoModelList) {
				pessoaContatoGroupedList.add(
					PessoaContatoGrouped(
						pessoaContato: PessoaContato(
							id: pessoaContatoModel.id,
							idPessoa: pessoaContatoModel.idPessoa,
							nome: pessoaContatoModel.nome,
							email: pessoaContatoModel.email,
							observacao: pessoaContatoModel.observacao,
						),
					),
				);
			}
			return pessoaContatoGroupedList;
		}
		return [];
	}

	List<PessoaTelefoneGrouped> pessoaTelefoneModelToDrift(List<PessoaTelefoneModel>? pessoaTelefoneModelList) { 
		List<PessoaTelefoneGrouped> pessoaTelefoneGroupedList = [];
		if (pessoaTelefoneModelList != null) {
			for (var pessoaTelefoneModel in pessoaTelefoneModelList) {
				pessoaTelefoneGroupedList.add(
					PessoaTelefoneGrouped(
						pessoaTelefone: PessoaTelefone(
							id: pessoaTelefoneModel.id,
							idPessoa: pessoaTelefoneModel.idPessoa,
							tipo: PessoaTelefoneDomain.setTipo(pessoaTelefoneModel.tipo),
							numero: Util.removeMask(pessoaTelefoneModel.numero),
						),
					),
				);
			}
			return pessoaTelefoneGroupedList;
		}
		return [];
	}

	List<PessoaEnderecoGrouped> pessoaEnderecoModelToDrift(List<PessoaEnderecoModel>? pessoaEnderecoModelList) { 
		List<PessoaEnderecoGrouped> pessoaEnderecoGroupedList = [];
		if (pessoaEnderecoModelList != null) {
			for (var pessoaEnderecoModel in pessoaEnderecoModelList) {
				pessoaEnderecoGroupedList.add(
					PessoaEnderecoGrouped(
						pessoaEndereco: PessoaEndereco(
							id: pessoaEnderecoModel.id,
							idPessoa: pessoaEnderecoModel.idPessoa,
							logradouro: pessoaEnderecoModel.logradouro,
							numero: pessoaEnderecoModel.numero,
							complemento: pessoaEnderecoModel.complemento,
							bairro: pessoaEnderecoModel.bairro,
							cidade: pessoaEnderecoModel.cidade,
							uf: PessoaEnderecoDomain.setUf(pessoaEnderecoModel.uf),
							cep: Util.removeMask(pessoaEnderecoModel.cep),
							municipioIbge: pessoaEnderecoModel.municipioIbge,
							principal: PessoaEnderecoDomain.setPrincipal(pessoaEnderecoModel.principal),
							entrega: PessoaEnderecoDomain.setEntrega(pessoaEnderecoModel.entrega),
							cobranca: PessoaEnderecoDomain.setCobranca(pessoaEnderecoModel.cobranca),
							correspondencia: PessoaEnderecoDomain.setCorrespondencia(pessoaEnderecoModel.correspondencia),
						),
					),
				);
			}
			return pessoaEnderecoGroupedList;
		}
		return [];
	}

	List<ViewFinLancamentoReceberGrouped> viewFinLancamentoReceberModelToDrift(List<ViewFinLancamentoReceberModel>? viewFinLancamentoReceberModelList) { 
		List<ViewFinLancamentoReceberGrouped> viewFinLancamentoReceberGroupedList = [];
		if (viewFinLancamentoReceberModelList != null) {
			for (var viewFinLancamentoReceberModel in viewFinLancamentoReceberModelList) {
				viewFinLancamentoReceberGroupedList.add(
					ViewFinLancamentoReceberGrouped(
						viewFinLancamentoReceber: ViewFinLancamentoReceber(
							id: viewFinLancamentoReceberModel.id,
							idFinLancamentoReceber: viewFinLancamentoReceberModel.idFinLancamentoReceber,
							quantidadeParcela: viewFinLancamentoReceberModel.quantidadeParcela,
							valorLancamento: viewFinLancamentoReceberModel.valorLancamento,
							dataLancamento: viewFinLancamentoReceberModel.dataLancamento,
							numeroDocumento: viewFinLancamentoReceberModel.numeroDocumento,
							idFinParcelaReceber: viewFinLancamentoReceberModel.idFinParcelaReceber,
							numeroParcela: viewFinLancamentoReceberModel.numeroParcela,
							dataVencimento: viewFinLancamentoReceberModel.dataVencimento,
							dataRecebimento: viewFinLancamentoReceberModel.dataRecebimento,
							valorParcela: viewFinLancamentoReceberModel.valorParcela,
							taxaJuro: viewFinLancamentoReceberModel.taxaJuro,
							valorJuro: viewFinLancamentoReceberModel.valorJuro,
							taxaMulta: viewFinLancamentoReceberModel.taxaMulta,
							valorMulta: viewFinLancamentoReceberModel.valorMulta,
							taxaDesconto: viewFinLancamentoReceberModel.taxaDesconto,
							valorDesconto: viewFinLancamentoReceberModel.valorDesconto,
							siglaDocumento: ViewFinLancamentoReceberDomain.setSiglaDocumento(viewFinLancamentoReceberModel.siglaDocumento),
							idCliente: viewFinLancamentoReceberModel.idCliente,
							idPessoa: viewFinLancamentoReceberModel.idPessoa,
							nomeCliente: viewFinLancamentoReceberModel.nomeCliente,
							idFinStatusParcela: viewFinLancamentoReceberModel.idFinStatusParcela,
							situacaoParcela: viewFinLancamentoReceberModel.situacaoParcela,
							descricaoSituacaoParcela: viewFinLancamentoReceberModel.descricaoSituacaoParcela,
							idBancoContaCaixa: viewFinLancamentoReceberModel.idBancoContaCaixa,
							nomeContaCaixa: viewFinLancamentoReceberModel.nomeContaCaixa,
						),
					),
				);
			}
			return viewFinLancamentoReceberGroupedList;
		}
		return [];
	}

		
}
