// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vendedor_rota_dao.dart';

// ignore_for_file: type=lint
mixin _$VendedorRotaDaoMixin on DatabaseAccessor<AppDatabase> {
  $VendedorRotasTable get vendedorRotas => attachedDatabase.vendedorRotas;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $ViewPessoaVendedorsTable get viewPessoaVendedors =>
      attachedDatabase.viewPessoaVendedors;
  $VendedorVisitasTable get vendedorVisitas => attachedDatabase.vendedorVisitas;
  $VendaCabecalhosTable get vendaCabecalhos => attachedDatabase.vendaCabecalhos;
  $VendaOrcamentoCabecalhosTable get vendaOrcamentoCabecalhos =>
      attachedDatabase.vendaOrcamentoCabecalhos;
}
