import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/provider/drift/database/database_imports.dart';

part 'vendedor_rota_dao.g.dart';

@DriftAccessor(tables: [
	VendedorRotas,
	ViewPessoaClientes,
	ViewPessoaVendedors,
	VendedorVisitas,
	VendaCabecalhos,
	VendaOrcamentoCabecalhos,
])
class VendedorRotaDao extends DatabaseAccessor<AppDatabase> with _$VendedorRotaDaoMixin {
	final AppDatabase db;

	List<VendedorRota> vendedorRotaList = []; 
	List<VendedorRotaGrouped> vendedorRotaGroupedList = []; 

	VendedorRotaDao(this.db) : super(db);

	Future<List<VendedorRota>> getList() async {
		vendedorRotaList = await select(vendedorRotas).get();
		return vendedorRotaList;
	}

	Future<List<VendedorRota>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		vendedorRotaList = await (select(vendedorRotas)..where((t) => expression)).get();
		return vendedorRotaList;	 
	}

	Future<List<VendedorRotaGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(vendedorRotas)
			.join([ 
				leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(vendedorRotas.idCliente)), 
			]).join([ 
				leftOuterJoin(viewPessoaVendedors, viewPessoaVendedors.id.equalsExp(vendedorRotas.idVendedor)), 
			]);

		if (field != null && field != '') { 
			final column = vendedorRotas.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		vendedorRotaGroupedList = await query.map((row) {
			final vendedorRota = row.readTableOrNull(vendedorRotas); 
			final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 
			final viewPessoaVendedor = row.readTableOrNull(viewPessoaVendedors); 

			return VendedorRotaGrouped(
				vendedorRota: vendedorRota, 
				viewPessoaCliente: viewPessoaCliente, 
				viewPessoaVendedor: viewPessoaVendedor, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var vendedorRotaGrouped in vendedorRotaGroupedList) {
			vendedorRotaGrouped.vendedorVisitaGroupedList = [];
			final queryVendedorVisita = ' id_vendedor_rota = ${vendedorRotaGrouped.vendedorRota!.id}';
			expression = CustomExpression<bool>(queryVendedorVisita);
			final vendedorVisitaList = await (select(vendedorVisitas)..where((t) => expression)).get();
			for (var vendedorVisita in vendedorVisitaList) {
				VendedorVisitaGrouped vendedorVisitaGrouped = VendedorVisitaGrouped(
					vendedorVisita: vendedorVisita,
					vendaCabecalho: await (select(vendaCabecalhos)..where((t) => t.id.equals(vendedorVisita.idVendaCabecalho ?? 0))).getSingleOrNull(),
					vendaOrcamentoCabecalho: await (select(vendaOrcamentoCabecalhos)..where((t) => t.id.equals(vendedorVisita.idVendaOrcamentoCabecalho ?? 0))).getSingleOrNull(),
				);
				vendedorRotaGrouped.vendedorVisitaGroupedList!.add(vendedorVisitaGrouped);
			}

		}		

		return vendedorRotaGroupedList;	
	}

	Future<VendedorRota?> getObject(dynamic pk) async {
		return await (select(vendedorRotas)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<VendedorRota?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM vendedor_rota WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as VendedorRota;		 
	} 

	Future<VendedorRotaGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(VendedorRotaGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.vendedorRota = object.vendedorRota!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(vendedorRotas).insert(object.vendedorRota!);
			object.vendedorRota = object.vendedorRota!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(VendedorRotaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(vendedorRotas).replace(object.vendedorRota!);
		});	 
	} 

	Future<int> deleteObject(VendedorRotaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(vendedorRotas).delete(object.vendedorRota!);
		});		
	}

	Future<void> insertChildren(VendedorRotaGrouped object) async {
		for (var vendedorVisitaGrouped in object.vendedorVisitaGroupedList!) {
			vendedorVisitaGrouped.vendedorVisita = vendedorVisitaGrouped.vendedorVisita?.copyWith(
				id: const Value(null),
				idVendedorRota: Value(object.vendedorRota!.id),
			);
			await into(vendedorVisitas).insert(vendedorVisitaGrouped.vendedorVisita!);
		}
	}
	
	Future<void> deleteChildren(VendedorRotaGrouped object) async {
		await (delete(vendedorVisitas)..where((t) => t.idVendedorRota.equals(object.vendedorRota!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from vendedor_rota").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 

  Future<int> getVisitasHoje(int idVendedor, DateTime hoje) async {
    // const query = '''
    //   SELECT COUNT(*) as total
    //   FROM vendedor_rota vr
    //   WHERE vr.id_vendedor = ? 
    //   AND vr.data_rota = ?
    //   AND vr.status = 'P'
    // ''';
    
    // final result = await customSelect(query,
    //   variables: [Variable(idVendedor), Variable(hoje.millisecondsSinceEpoch)])
    //   .getSingleOrNull();
    
    const query = '''
      SELECT COUNT(*) as total
      FROM vendedor_rota vr
    ''';
    
    final result = await customSelect(query,
      variables: [])
      .getSingleOrNull();

    return result?.read<int>('total') ?? 0;
  }

  Future<List<Map<String, dynamic>>> getProximasVisitas(int idVendedor, DateTime hoje, int dias) async {
    final futuro = hoje.add(Duration(days: dias));
    
    const query = '''
      SELECT 
        vr.id,
        vr.data_rota,
        c.nome as cliente_nome,
        vr.observacao
      FROM vendedor_rota vr
      INNER JOIN view_pessoa_cliente c ON vr.id_cliente = c.id
      WHERE vr.id_vendedor = ? 
      AND vr.data_rota BETWEEN ? AND ?
      AND vr.status = 'P'
      ORDER BY vr.data_rota ASC
      LIMIT 5
    ''';
    
    final results = await customSelect(query,
      variables: [
        Variable(idVendedor),
        Variable(hoje.millisecondsSinceEpoch),
        Variable(futuro.millisecondsSinceEpoch)
      ]).get();
    
    return results.map((row) {
      return {
        'id': row.read<int>('id'),
        'data_rota': row.read<int>('data_rota'),
        'cliente_nome': row.read<String>('cliente_nome'),
        'observacao': row.read<String?>('observacao'),
      };
    }).toList();
  }

}