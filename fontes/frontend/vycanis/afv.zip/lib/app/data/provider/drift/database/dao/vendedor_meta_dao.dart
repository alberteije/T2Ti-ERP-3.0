import 'package:drift/drift.dart';
import 'package:afv/app/data/provider/drift/database/database.dart';
import 'package:afv/app/data/provider/drift/database/database_imports.dart';

part 'vendedor_meta_dao.g.dart';

@DriftAccessor(tables: [
	VendedorMetas,
	ViewPessoaVendedors,
	ViewPessoaClientes,
])
class VendedorMetaDao extends DatabaseAccessor<AppDatabase> with _$VendedorMetaDaoMixin {
	final AppDatabase db;

	List<VendedorMeta> vendedorMetaList = []; 
	List<VendedorMetaGrouped> vendedorMetaGroupedList = []; 

	VendedorMetaDao(this.db) : super(db);

	Future<List<VendedorMeta>> getList() async {
		vendedorMetaList = await select(vendedorMetas).get();
		return vendedorMetaList;
	}

	Future<List<VendedorMeta>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		vendedorMetaList = await (select(vendedorMetas)..where((t) => expression)).get();
		return vendedorMetaList;	 
	}

	Future<List<VendedorMetaGrouped>> getGroupedList({String? field, dynamic value}) async {
    final query = select(vendedorMetas)
      .join([ 
        leftOuterJoin(viewPessoaVendedors, viewPessoaVendedors.id.equalsExp(vendedorMetas.idVendedor)), 
      ]).join([ 
        leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(vendedorMetas.idCliente)), 
      ]);

    if (field != null && field != '') { 
      final column = vendedorMetas.$columns.where(((column) => column.$name == field)).first;
      if (column is TextColumn) {
        query.where((column as TextColumn).like('%$value%'));
      } else if (column is IntColumn) {
        query.where(column.equals(value));
      } else if (column is RealColumn) {
        query.where(column.equals(value));
      }
    }

    vendedorMetaGroupedList = await query.map((row) {
      final vendedorMeta = row.readTableOrNull(vendedorMetas); 
      final viewPessoaVendedor = row.readTableOrNull(viewPessoaVendedors); 
      final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 

      return VendedorMetaGrouped(
        vendedorMeta: vendedorMeta, 
        viewPessoaVendedor: viewPessoaVendedor, 
        viewPessoaCliente: viewPessoaCliente, 

      );
    }).get();

    // fill internal lists
    //dynamic expression;
    //for (var vendedorMetaGrouped in vendedorMetaGroupedList) {
    //}		

    return vendedorMetaGroupedList;	      
	}

	Future<VendedorMeta?> getObject(dynamic pk) async {
		return await (select(vendedorMetas)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<VendedorMeta?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM vendedor_meta WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as VendedorMeta;		 
	} 

	Future<VendedorMetaGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(VendedorMetaGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.vendedorMeta = object.vendedorMeta!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(vendedorMetas).insert(object.vendedorMeta!);
			object.vendedorMeta = object.vendedorMeta!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(VendedorMetaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(vendedorMetas).replace(object.vendedorMeta!);
		});	 
	} 

	Future<int> deleteObject(VendedorMetaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(vendedorMetas).delete(object.vendedorMeta!);
		});		
	}

	Future<void> insertChildren(VendedorMetaGrouped object) async {
	}
	
	Future<void> deleteChildren(VendedorMetaGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from vendedor_meta").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}