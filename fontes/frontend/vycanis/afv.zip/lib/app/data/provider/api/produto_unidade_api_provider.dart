import 'package:afv/app/data/provider/api/api_provider_base.dart';
import 'package:afv/app/data/model/model_imports.dart';

class ProdutoUnidadeApiProvider extends ApiProviderBase {
  static const _path = '/produto-unidade';

  Future<List<ProdutoUnidadeModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ProdutoUnidadeModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ProdutoUnidadeModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ProdutoUnidadeModel.fromJson(json),
    );
  }

  Future<ProdutoUnidadeModel?>? insert(ProdutoUnidadeModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ProdutoUnidadeModel.fromJson(json),
    );
  }

  Future<ProdutoUnidadeModel?>? update(ProdutoUnidadeModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ProdutoUnidadeModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
