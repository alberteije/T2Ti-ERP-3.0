// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nota_fiscal_modelo_dao.dart';

// ignore_for_file: type=lint
mixin _$NotaFiscalModeloDaoMixin on DatabaseAccessor<AppDatabase> {
  $NotaFiscalModelosTable get notaFiscalModelos =>
      attachedDatabase.notaFiscalModelos;
}
