class PessoaDomain {
  PessoaDomain._();

  static getTipo(String? tipo) { 
		switch (tipo) { 
			case '': 
			case 'F': 
				return 'Física'; 
			case 'J': 
				return 'Jurídica'; 
			default: 
				return null; 
		} 
	} 

  static setTipo(String? tipo) { 
		switch (tipo) { 
			case 'Física': 
				return 'F'; 
			case 'Jurídica': 
				return 'J'; 
			default: 
				return null; 
		} 
	}

  static getEhCliente(String? ehCliente) { 
		switch (ehCliente) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setEhCliente(String? ehCliente) { 
		switch (ehCliente) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getEhFornecedor(String? ehFornecedor) { 
		switch (ehFornecedor) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setEhFornecedor(String? ehFornecedor) { 
		switch (ehFornecedor) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getEhTransportadora(String? ehTransportadora) { 
		switch (ehTransportadora) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setEhTransportadora(String? ehTransportadora) { 
		switch (ehTransportadora) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getEhColaborador(String? ehColaborador) { 
		switch (ehColaborador) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setEhColaborador(String? ehColaborador) { 
		switch (ehColaborador) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getEhContador(String? ehContador) { 
		switch (ehContador) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setEhContador(String? ehContador) { 
		switch (ehContador) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getSituacaoContribuinte(String? situacaoContribuinte) { 
		switch (situacaoContribuinte) { 
			case '': 
			case '1': 
				return '1-Contribuinte ICMS'; 
			case '2': 
				return '2-Isento'; 
			case '9': 
				return '9-Não Contribuinte'; 
			default: 
				return null; 
		} 
	} 

  static setSituacaoContribuinte(String? situacaoContribuinte) { 
		switch (situacaoContribuinte) { 
			case '1-Contribuinte ICMS': 
				return '1'; 
			case '2-Isento': 
				return '2'; 
			case '9-Não Contribuinte': 
				return '9'; 
			default: 
				return null; 
		} 
	}

  static getAtivo(String? ativo) { 
		switch (ativo) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setAtivo(String? ativo) { 
		switch (ativo) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}


  static final tipoListDropdown = ['Física','Jurídica'];
  static final ehClienteListDropdown = ['Sim','Não'];
  static final ehFornecedorListDropdown = ['Sim','Não'];
  static final ehTransportadoraListDropdown = ['Sim','Não'];
  static final ehColaboradorListDropdown = ['Sim','Não'];
  static final ehContadorListDropdown = ['Sim','Não'];
  static final situacaoContribuinteListDropdown = ['1-Contribuinte ICMS','2-Isento','9-Não Contribuinte'];
  static final ativoListDropdown = ['Sim','Não'];

}