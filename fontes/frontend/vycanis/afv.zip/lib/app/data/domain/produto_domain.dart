class ProdutoDomain {
  ProdutoDomain._();

  static getTipoItem(String? tipoItem) { 
		switch (tipoItem) { 
			case '': 
			case 'P': 
				return 'Produto'; 
			case 'S': 
				return 'Serviço'; 
			default: 
				return null; 
		} 
	} 

  static setTipoItem(String? tipoItem) { 
		switch (tipoItem) { 
			case 'Produto': 
				return 'P'; 
			case 'Serviço': 
				return 'S'; 
			default: 
				return null; 
		} 
	}

  static getPesavel(String? pesavel) { 
		switch (pesavel) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setPesavel(String? pesavel) { 
		switch (pesavel) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getClasseAbc(String? classeAbc) { 
		switch (classeAbc) { 
			case '': 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			default: 
				return null; 
		} 
	} 

  static setClasseAbc(String? classeAbc) { 
		switch (classeAbc) { 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			default: 
				return null; 
		} 
	}

  static getAtivo(String? ativo) { 
		switch (ativo) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setAtivo(String? ativo) { 
		switch (ativo) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}


  static final tipoItemListDropdown = ['Produto','Serviço'];
  static final pesavelListDropdown = ['Sim','Não'];
  static final classeAbcListDropdown = ['A','B','C'];
  static final ativoListDropdown = ['Sim','Não'];

}