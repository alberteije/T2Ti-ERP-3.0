class ClienteDomain {
  ClienteDomain._();

  static getEhGoverno(String? ehGoverno) { 
		switch (ehGoverno) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setEhGoverno(String? ehGoverno) { 
		switch (ehGoverno) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getTipoEnteGovernamental(String? tipoEnteGovernamental) { 
		switch (tipoEnteGovernamental) { 
			case '': 
			case 'N': 
				return 'Não é Governo'; 
			case '1': 
				return '1=União'; 
			case '2': 
				return '2=Estado'; 
			case '3': 
				return '3=Distrito Federal'; 
			case '4': 
				return '4=Município'; 
			default: 
				return null; 
		} 
	} 

  static setTipoEnteGovernamental(String? tipoEnteGovernamental) { 
		switch (tipoEnteGovernamental) { 
			case 'Não é Governo': 
				return 'N'; 
			case '1=União': 
				return '1'; 
			case '2=Estado': 
				return '2'; 
			case '3=Distrito Federal': 
				return '3'; 
			case '4=Município': 
				return '4'; 
			default: 
				return null; 
		} 
	}


  static final ehGovernoListDropdown = ['Sim','Não'];
  static final tipoEnteGovernamentalListDropdown = ['Não é Governo','1=União','2=Estado','3=Distrito Federal','4=Município'];

}