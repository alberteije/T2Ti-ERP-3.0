class ViewFinLancamentoReceberDomain {
  ViewFinLancamentoReceberDomain._();

  static getSiglaDocumento(String? siglaDocumento) { 
		switch (siglaDocumento) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

  static setSiglaDocumento(String? siglaDocumento) { 
		switch (siglaDocumento) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final siglaDocumentoListDropdown = ['AAA','BBB','CCC'];

}