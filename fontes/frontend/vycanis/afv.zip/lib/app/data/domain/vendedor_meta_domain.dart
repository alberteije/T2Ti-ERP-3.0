class VendedorMetaDomain {
  VendedorMetaDomain._();

  static getPeriodoMeta(String? periodoMeta) { 
		switch (periodoMeta) { 
			case '': 
			case 'M': 
				return 'Mensal'; 
			case 'B': 
				return 'Bimestral'; 
			case 'T': 
				return 'Trimestral'; 
			case 'S': 
				return 'Semestral'; 
			case 'A': 
				return 'Anual'; 
			default: 
				return null; 
		} 
	} 

  static setPeriodoMeta(String? periodoMeta) { 
		switch (periodoMeta) { 
			case 'Mensal': 
				return 'M'; 
			case 'Bimestral': 
				return 'B'; 
			case 'Trimestral': 
				return 'T'; 
			case 'Semestral': 
				return 'S'; 
			case 'Anual': 
				return 'A'; 
			default: 
				return null; 
		} 
	}


  static final periodoMetaListDropdown = ['Mensal','Bimestral','Trimestral','Semestral','Anual'];

}