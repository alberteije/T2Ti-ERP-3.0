class VendedorRotaDomain {
  VendedorRotaDomain._();

  static getStatus(String? status) { 
		switch (status) { 
			case '': 
			case 'P': 
				return 'Planejada'; 
			case 'E': 
				return 'Em Execução'; 
			case 'T': 
				return 'Terminada'; 
			case 'C': 
				return 'Cancelada'; 
			case 'R': 
				return 'Reagendada'; 
			default: 
				return null; 
		} 
	} 

  static setStatus(String? status) { 
		switch (status) { 
			case 'Planejada': 
				return 'P'; 
			case 'Em Execução': 
				return 'E'; 
			case 'Terminada': 
				return 'T'; 
			case 'Cancelada': 
				return 'C'; 
			case 'Reagendada': 
				return 'R'; 
			default: 
				return null; 
		} 
	}


  static final statusListDropdown = ['Planejada','Em Execução','Terminada','Cancelada','Reagendada'];

}