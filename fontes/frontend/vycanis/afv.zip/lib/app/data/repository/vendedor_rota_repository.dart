import 'package:afv/app/infra/constants.dart';
import 'package:afv/app/data/provider/api/vendedor_rota_api_provider.dart';
import 'package:afv/app/data/provider/drift/vendedor_rota_drift_provider.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendedorRotaRepository {
  final VendedorRotaApiProvider vendedorRotaApiProvider;
  final VendedorRotaDriftProvider vendedorRotaDriftProvider;

  VendedorRotaRepository({required this.vendedorRotaApiProvider, required this.vendedorRotaDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await vendedorRotaDriftProvider.getList(filter: filter);
    } else {
      return await vendedorRotaApiProvider.getList(filter: filter);
    }
  }

  Future<VendedorRotaModel?>? save({required VendedorRotaModel vendedorRotaModel}) async {
    if (vendedorRotaModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await vendedorRotaDriftProvider.update(vendedorRotaModel);
      } else {
        return await vendedorRotaApiProvider.update(vendedorRotaModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await vendedorRotaDriftProvider.insert(vendedorRotaModel);
      } else {
        return await vendedorRotaApiProvider.insert(vendedorRotaModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await vendedorRotaDriftProvider.delete(id) ?? false;
    } else {
      return await vendedorRotaApiProvider.delete(id) ?? false;
    }
  }
}