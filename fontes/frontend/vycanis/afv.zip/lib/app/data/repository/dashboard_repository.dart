import 'package:afv/app/controller/dashboard_controller.dart';
import 'package:afv/app/data/provider/drift/dashboard_drift_provider.dart';

class DashboardRepository {
  final DashboardDriftProvider dashboardDriftProvider;

  DashboardRepository({
    required this.dashboardDriftProvider,
  });

  Future<DashboardData?> getDashboardData() async {
    return await dashboardDriftProvider.getDashboardData();
  }
}