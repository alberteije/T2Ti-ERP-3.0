import 'package:afv/app/infra/constants.dart';
import 'package:afv/app/data/provider/api/vendedor_meta_api_provider.dart';
import 'package:afv/app/data/provider/drift/vendedor_meta_drift_provider.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendedorMetaRepository {
  final VendedorMetaApiProvider vendedorMetaApiProvider;
  final VendedorMetaDriftProvider vendedorMetaDriftProvider;

  VendedorMetaRepository({required this.vendedorMetaApiProvider, required this.vendedorMetaDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await vendedorMetaDriftProvider.getList(filter: filter);
    } else {
      return await vendedorMetaApiProvider.getList(filter: filter);
    }
  }

  Future<VendedorMetaModel?>? save({required VendedorMetaModel vendedorMetaModel}) async {
    if (vendedorMetaModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await vendedorMetaDriftProvider.update(vendedorMetaModel);
      } else {
        return await vendedorMetaApiProvider.update(vendedorMetaModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await vendedorMetaDriftProvider.insert(vendedorMetaModel);
      } else {
        return await vendedorMetaApiProvider.insert(vendedorMetaModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await vendedorMetaDriftProvider.delete(id) ?? false;
    } else {
      return await vendedorMetaApiProvider.delete(id) ?? false;
    }
  }
}