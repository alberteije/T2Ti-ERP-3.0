import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:afv/app/data/model/model_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class VendedorVisitaModel extends ModelBase {
  int? id;
  int? idVendedorRota;
  int? idVendaCabecalho;
  int? idVendaOrcamentoCabecalho;
  DateTime? dataPrevista;
  DateTime? dataRealizada;
  String? horaInicio;
  String? horaFim;
  double? latitude;
  double? longitude;
  String? observacao;
  VendaCabecalhoModel? vendaCabecalhoModel;
  VendaOrcamentoCabecalhoModel? vendaOrcamentoCabecalhoModel;

  VendedorVisitaModel({
    this.id,
    this.idVendedorRota,
    this.idVendaCabecalho,
    this.idVendaOrcamentoCabecalho,
    this.dataPrevista,
    this.dataRealizada,
    this.horaInicio,
    this.horaFim,
    this.latitude,
    this.longitude,
    this.observacao,
    VendaCabecalhoModel? vendaCabecalhoModel,
    VendaOrcamentoCabecalhoModel? vendaOrcamentoCabecalhoModel,
  }) {
    this.vendaCabecalhoModel = vendaCabecalhoModel ?? VendaCabecalhoModel();
    this.vendaOrcamentoCabecalhoModel = vendaOrcamentoCabecalhoModel ?? VendaOrcamentoCabecalhoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_prevista',
    'data_realizada',
    'hora_inicio',
    'hora_fim',
    'latitude',
    'longitude',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Prevista',
    'Data Realizada',
    'Hora Inicio',
    'Hora Fim',
    'Latitude',
    'Longitude',
    'Observacao',
  ];

  VendedorVisitaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendedorRota = jsonData['idVendedorRota'];
    idVendaCabecalho = jsonData['idVendaCabecalho'];
    idVendaOrcamentoCabecalho = jsonData['idVendaOrcamentoCabecalho'];
    dataPrevista = jsonData['dataPrevista'] != null ? DateTime.tryParse(jsonData['dataPrevista']) : null;
    dataRealizada = jsonData['dataRealizada'] != null ? DateTime.tryParse(jsonData['dataRealizada']) : null;
    horaInicio = jsonData['horaInicio'];
    horaFim = jsonData['horaFim'];
    latitude = jsonData['latitude']?.toDouble();
    longitude = jsonData['longitude']?.toDouble();
    observacao = jsonData['observacao'];
    vendaCabecalhoModel = jsonData['vendaCabecalhoModel'] == null ? VendaCabecalhoModel() : VendaCabecalhoModel.fromJson(jsonData['vendaCabecalhoModel']);
    vendaOrcamentoCabecalhoModel = jsonData['vendaOrcamentoCabecalhoModel'] == null ? VendaOrcamentoCabecalhoModel() : VendaOrcamentoCabecalhoModel.fromJson(jsonData['vendaOrcamentoCabecalhoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendedorRota'] = idVendedorRota != 0 ? idVendedorRota : null;
    jsonData['idVendaCabecalho'] = idVendaCabecalho != 0 ? idVendaCabecalho : null;
    jsonData['idVendaOrcamentoCabecalho'] = idVendaOrcamentoCabecalho != 0 ? idVendaOrcamentoCabecalho : null;
    jsonData['dataPrevista'] = dataPrevista != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevista!) : null;
    jsonData['dataRealizada'] = dataRealizada != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRealizada!) : null;
    jsonData['horaInicio'] = Util.removeMask(horaInicio);
    jsonData['horaFim'] = Util.removeMask(horaFim);
    jsonData['latitude'] = latitude;
    jsonData['longitude'] = longitude;
    jsonData['observacao'] = observacao;
    jsonData['vendaCabecalhoModel'] = vendaCabecalhoModel?.toJson;
    jsonData['vendaCabecalho'] = vendaCabecalhoModel?.id ?? '';
    jsonData['vendaOrcamentoCabecalhoModel'] = vendaOrcamentoCabecalhoModel?.toJson;
    jsonData['vendaOrcamentoCabecalho'] = vendaOrcamentoCabecalhoModel?.id ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendedorVisitaModel fromPlutoRow(PlutoRow row) {
    return VendedorVisitaModel(
      id: row.cells['id']?.value,
      idVendedorRota: row.cells['idVendedorRota']?.value,
      idVendaCabecalho: row.cells['idVendaCabecalho']?.value,
      idVendaOrcamentoCabecalho: row.cells['idVendaOrcamentoCabecalho']?.value,
      dataPrevista: Util.stringToDate(row.cells['dataPrevista']?.value),
      dataRealizada: Util.stringToDate(row.cells['dataRealizada']?.value),
      horaInicio: row.cells['horaInicio']?.value,
      horaFim: row.cells['horaFim']?.value,
      latitude: row.cells['latitude']?.value,
      longitude: row.cells['longitude']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendedorRota': PlutoCell(value: idVendedorRota ?? 0),
        'idVendaCabecalho': PlutoCell(value: idVendaCabecalho ?? 0),
        'idVendaOrcamentoCabecalho': PlutoCell(value: idVendaOrcamentoCabecalho ?? 0),
        'dataPrevista': PlutoCell(value: dataPrevista),
        'dataRealizada': PlutoCell(value: dataRealizada),
        'horaInicio': PlutoCell(value: horaInicio ?? ''),
        'horaFim': PlutoCell(value: horaFim ?? ''),
        'latitude': PlutoCell(value: latitude ?? 0.0),
        'longitude': PlutoCell(value: longitude ?? 0.0),
        'observacao': PlutoCell(value: observacao ?? ''),
        'vendaCabecalho': PlutoCell(value: vendaCabecalhoModel?.id ?? ''),
        'vendaOrcamentoCabecalho': PlutoCell(value: vendaOrcamentoCabecalhoModel?.id ?? ''),
      },
    );
  }

  VendedorVisitaModel clone() {
    return VendedorVisitaModel(
      id: id,
      idVendedorRota: idVendedorRota,
      idVendaCabecalho: idVendaCabecalho,
      idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho,
      dataPrevista: dataPrevista,
      dataRealizada: dataRealizada,
      horaInicio: horaInicio,
      horaFim: horaFim,
      latitude: latitude,
      longitude: longitude,
      observacao: observacao,
      vendaCabecalhoModel: vendaCabecalhoModel?.clone(),
      vendaOrcamentoCabecalhoModel: vendaOrcamentoCabecalhoModel?.clone(),
    );
  }


}