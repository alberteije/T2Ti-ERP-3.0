import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:afv/app/data/model/model_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ProdutoPromocaoModel extends ModelBase {
  int? id;
  int? idProduto;
  DateTime? dataInicio;
  DateTime? dataFim;
  double? quantidadeEmPromocao;
  double? quantidadeMaximaCliente;
  double? valor;

  ProdutoPromocaoModel({
    this.id,
    this.idProduto,
    this.dataInicio,
    this.dataFim,
    this.quantidadeEmPromocao,
    this.quantidadeMaximaCliente,
    this.valor,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_inicio',
    'data_fim',
    'quantidade_em_promocao',
    'quantidade_maxima_cliente',
    'valor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Inicio',
    'Data Fim',
    'Quantidade Em Promocao',
    'Quantidade Maxima Cliente',
    'Valor',
  ];

  ProdutoPromocaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProduto = jsonData['idProduto'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    quantidadeEmPromocao = jsonData['quantidadeEmPromocao']?.toDouble();
    quantidadeMaximaCliente = jsonData['quantidadeMaximaCliente']?.toDouble();
    valor = jsonData['valor']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['quantidadeEmPromocao'] = quantidadeEmPromocao;
    jsonData['quantidadeMaximaCliente'] = quantidadeMaximaCliente;
    jsonData['valor'] = valor;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProdutoPromocaoModel fromPlutoRow(PlutoRow row) {
    return ProdutoPromocaoModel(
      id: row.cells['id']?.value,
      idProduto: row.cells['idProduto']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      quantidadeEmPromocao: row.cells['quantidadeEmPromocao']?.value,
      quantidadeMaximaCliente: row.cells['quantidadeMaximaCliente']?.value,
      valor: row.cells['valor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'quantidadeEmPromocao': PlutoCell(value: quantidadeEmPromocao ?? 0.0),
        'quantidadeMaximaCliente': PlutoCell(value: quantidadeMaximaCliente ?? 0.0),
        'valor': PlutoCell(value: valor ?? 0.0),
      },
    );
  }

  ProdutoPromocaoModel clone() {
    return ProdutoPromocaoModel(
      id: id,
      idProduto: idProduto,
      dataInicio: dataInicio,
      dataFim: dataFim,
      quantidadeEmPromocao: quantidadeEmPromocao,
      quantidadeMaximaCliente: quantidadeMaximaCliente,
      valor: valor,
    );
  }


}