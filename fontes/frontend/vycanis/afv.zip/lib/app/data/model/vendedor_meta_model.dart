import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:afv/app/data/model/model_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class VendedorMetaModel extends ModelBase {
  int? id;
  int? idVendedor;
  int? idCliente;
  String? periodoMeta;
  double? metaOrcada;
  double? metaRealizada;
  DateTime? dataInicio;
  DateTime? dataFim;
  ViewPessoaVendedorModel? viewPessoaVendedorModel;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  VendedorMetaModel({
    this.id,
    this.idVendedor,
    this.idCliente,
    this.periodoMeta = 'Mensal',
    this.metaOrcada,
    this.metaRealizada,
    this.dataInicio,
    this.dataFim,
    ViewPessoaVendedorModel? viewPessoaVendedorModel,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.viewPessoaVendedorModel = viewPessoaVendedorModel ?? ViewPessoaVendedorModel();
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'periodo_meta',
    'meta_orcada',
    'meta_realizada',
    'data_inicio',
    'data_fim',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Periodo Meta',
    'Meta Orcada',
    'Meta Realizada',
    'Data Inicio',
    'Data Fim',
  ];

  VendedorMetaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendedor = jsonData['idVendedor'];
    idCliente = jsonData['idCliente'];
    periodoMeta = VendedorMetaDomain.getPeriodoMeta(jsonData['periodoMeta']);
    metaOrcada = jsonData['metaOrcada']?.toDouble();
    metaRealizada = jsonData['metaRealizada']?.toDouble();
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    viewPessoaVendedorModel = jsonData['viewPessoaVendedorModel'] == null ? ViewPessoaVendedorModel() : ViewPessoaVendedorModel.fromJson(jsonData['viewPessoaVendedorModel']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendedor'] = idVendedor != 0 ? idVendedor : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['periodoMeta'] = VendedorMetaDomain.setPeriodoMeta(periodoMeta);
    jsonData['metaOrcada'] = metaOrcada;
    jsonData['metaRealizada'] = metaRealizada;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['viewPessoaVendedorModel'] = viewPessoaVendedorModel?.toJson;
    jsonData['viewPessoaVendedor'] = viewPessoaVendedorModel?.nome ?? '';
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendedorMetaModel fromPlutoRow(PlutoRow row) {
    return VendedorMetaModel(
      id: row.cells['id']?.value,
      idVendedor: row.cells['idVendedor']?.value,
      idCliente: row.cells['idCliente']?.value,
      periodoMeta: row.cells['periodoMeta']?.value,
      metaOrcada: row.cells['metaOrcada']?.value,
      metaRealizada: row.cells['metaRealizada']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendedor': PlutoCell(value: idVendedor ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'periodoMeta': PlutoCell(value: periodoMeta ?? ''),
        'metaOrcada': PlutoCell(value: metaOrcada ?? 0.0),
        'metaRealizada': PlutoCell(value: metaRealizada ?? 0.0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'viewPessoaVendedor': PlutoCell(value: viewPessoaVendedorModel?.nome ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  VendedorMetaModel clone() {
    return VendedorMetaModel(
      id: id,
      idVendedor: idVendedor,
      idCliente: idCliente,
      periodoMeta: periodoMeta,
      metaOrcada: metaOrcada,
      metaRealizada: metaRealizada,
      dataInicio: dataInicio,
      dataFim: dataFim,
      viewPessoaVendedorModel: viewPessoaVendedorModel?.clone(),
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
    );
  }


}