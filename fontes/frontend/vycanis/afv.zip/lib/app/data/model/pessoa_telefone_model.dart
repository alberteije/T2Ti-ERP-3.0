import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:afv/app/data/model/model_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class PessoaTelefoneModel extends ModelBase {
  int? id;
  int? idPessoa;
  String? tipo;
  String? numero;

  PessoaTelefoneModel({
    this.id,
    this.idPessoa,
    this.tipo = 'Fixo',
    this.numero,
  });

  static List<String> dbColumns = <String>[
    'id',
    'tipo',
    'numero',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo',
    'Numero',
  ];

  PessoaTelefoneModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    tipo = PessoaTelefoneDomain.getTipo(jsonData['tipo']);
    numero = jsonData['numero'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['tipo'] = PessoaTelefoneDomain.setTipo(tipo);
    jsonData['numero'] = Util.removeMask(numero);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PessoaTelefoneModel fromPlutoRow(PlutoRow row) {
    return PessoaTelefoneModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      tipo: row.cells['tipo']?.value,
      numero: row.cells['numero']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
      },
    );
  }

  PessoaTelefoneModel clone() {
    return PessoaTelefoneModel(
      id: id,
      idPessoa: idPessoa,
      tipo: tipo,
      numero: numero,
    );
  }


}