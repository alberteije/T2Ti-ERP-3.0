import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:afv/app/data/model/model_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class VendaOrcamentoCabecalhoModel extends ModelBase {
  int? id;
  int? idCliente;
  int? idVendedor;
  int? idTransportadora;
  int? idVendaCondicoesPagamento;
  String? tipoFrete;
  String? codigo;
  DateTime? dataCadastro;
  DateTime? dataEntrega;
  DateTime? dataValidade;
  double? valorSubtotal;
  double? valorFrete;
  double? taxaComissao;
  double? valorComissao;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  String? observacao;
  List<VendaOrcamentoDetalheModel>? vendaOrcamentoDetalheModelList;
  ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel;
  VendaCondicoesPagamentoModel? vendaCondicoesPagamentoModel;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  ViewPessoaVendedorModel? viewPessoaVendedorModel;

  VendaOrcamentoCabecalhoModel({
    this.id,
    this.idCliente,
    this.idVendedor,
    this.idTransportadora,
    this.idVendaCondicoesPagamento,
    this.tipoFrete = 'CIF',
    this.codigo,
    this.dataCadastro,
    this.dataEntrega,
    this.dataValidade,
    this.valorSubtotal,
    this.valorFrete,
    this.taxaComissao,
    this.valorComissao,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    this.observacao,
    List<VendaOrcamentoDetalheModel>? vendaOrcamentoDetalheModelList,
    ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel,
    VendaCondicoesPagamentoModel? vendaCondicoesPagamentoModel,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    ViewPessoaVendedorModel? viewPessoaVendedorModel,
  }) {
    this.vendaOrcamentoDetalheModelList = vendaOrcamentoDetalheModelList?.toList(growable: true) ?? [];
    this.viewPessoaTransportadoraModel = viewPessoaTransportadoraModel ?? ViewPessoaTransportadoraModel();
    this.vendaCondicoesPagamentoModel = vendaCondicoesPagamentoModel ?? VendaCondicoesPagamentoModel();
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.viewPessoaVendedorModel = viewPessoaVendedorModel ?? ViewPessoaVendedorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo_frete',
    'codigo',
    'data_cadastro',
    'data_entrega',
    'data_validade',
    'valor_subtotal',
    'valor_frete',
    'taxa_comissao',
    'valor_comissao',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo Frete',
    'Codigo',
    'Data Cadastro',
    'Data Entrega',
    'Data Validade',
    'Valor Subtotal',
    'Valor Frete',
    'Taxa Comissao',
    'Valor Comissao',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
    'Observacao',
  ];

  VendaOrcamentoCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    idVendedor = jsonData['idVendedor'];
    idTransportadora = jsonData['idTransportadora'];
    idVendaCondicoesPagamento = jsonData['idVendaCondicoesPagamento'];
    tipoFrete = VendaOrcamentoCabecalhoDomain.getTipoFrete(jsonData['tipoFrete']);
    codigo = jsonData['codigo'];
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    dataEntrega = jsonData['dataEntrega'] != null ? DateTime.tryParse(jsonData['dataEntrega']) : null;
    dataValidade = jsonData['dataValidade'] != null ? DateTime.tryParse(jsonData['dataValidade']) : null;
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    valorFrete = jsonData['valorFrete']?.toDouble();
    taxaComissao = jsonData['taxaComissao']?.toDouble();
    valorComissao = jsonData['valorComissao']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    observacao = jsonData['observacao'];
    vendaOrcamentoDetalheModelList = (jsonData['vendaOrcamentoDetalheModelList'] as Iterable?)?.map((m) => VendaOrcamentoDetalheModel.fromJson(m)).toList() ?? [];
    viewPessoaTransportadoraModel = jsonData['viewPessoaTransportadoraModel'] == null ? ViewPessoaTransportadoraModel() : ViewPessoaTransportadoraModel.fromJson(jsonData['viewPessoaTransportadoraModel']);
    vendaCondicoesPagamentoModel = jsonData['vendaCondicoesPagamentoModel'] == null ? VendaCondicoesPagamentoModel() : VendaCondicoesPagamentoModel.fromJson(jsonData['vendaCondicoesPagamentoModel']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    viewPessoaVendedorModel = jsonData['viewPessoaVendedorModel'] == null ? ViewPessoaVendedorModel() : ViewPessoaVendedorModel.fromJson(jsonData['viewPessoaVendedorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idVendedor'] = idVendedor != 0 ? idVendedor : null;
    jsonData['idTransportadora'] = idTransportadora != 0 ? idTransportadora : null;
    jsonData['idVendaCondicoesPagamento'] = idVendaCondicoesPagamento != 0 ? idVendaCondicoesPagamento : null;
    jsonData['tipoFrete'] = VendaOrcamentoCabecalhoDomain.setTipoFrete(tipoFrete);
    jsonData['codigo'] = codigo;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['dataEntrega'] = dataEntrega != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEntrega!) : null;
    jsonData['dataValidade'] = dataValidade != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataValidade!) : null;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['valorFrete'] = valorFrete;
    jsonData['taxaComissao'] = taxaComissao;
    jsonData['valorComissao'] = valorComissao;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['observacao'] = observacao;
    
		var vendaOrcamentoDetalheModelLocalList = []; 
		for (VendaOrcamentoDetalheModel object in vendaOrcamentoDetalheModelList ?? []) { 
			vendaOrcamentoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['vendaOrcamentoDetalheModelList'] = vendaOrcamentoDetalheModelLocalList;
    jsonData['viewPessoaTransportadoraModel'] = viewPessoaTransportadoraModel?.toJson;
    jsonData['viewPessoaTransportadora'] = viewPessoaTransportadoraModel?.nome ?? '';
    jsonData['vendaCondicoesPagamentoModel'] = vendaCondicoesPagamentoModel?.toJson;
    jsonData['vendaCondicoesPagamento'] = vendaCondicoesPagamentoModel?.nome ?? '';
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['viewPessoaVendedorModel'] = viewPessoaVendedorModel?.toJson;
    jsonData['viewPessoaVendedor'] = viewPessoaVendedorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaOrcamentoCabecalhoModel fromPlutoRow(PlutoRow row) {
    return VendaOrcamentoCabecalhoModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      idVendedor: row.cells['idVendedor']?.value,
      idTransportadora: row.cells['idTransportadora']?.value,
      idVendaCondicoesPagamento: row.cells['idVendaCondicoesPagamento']?.value,
      tipoFrete: row.cells['tipoFrete']?.value,
      codigo: row.cells['codigo']?.value,
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      dataEntrega: Util.stringToDate(row.cells['dataEntrega']?.value),
      dataValidade: Util.stringToDate(row.cells['dataValidade']?.value),
      valorSubtotal: row.cells['valorSubtotal']?.value,
      valorFrete: row.cells['valorFrete']?.value,
      taxaComissao: row.cells['taxaComissao']?.value,
      valorComissao: row.cells['valorComissao']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idVendedor': PlutoCell(value: idVendedor ?? 0),
        'idTransportadora': PlutoCell(value: idTransportadora ?? 0),
        'idVendaCondicoesPagamento': PlutoCell(value: idVendaCondicoesPagamento ?? 0),
        'tipoFrete': PlutoCell(value: tipoFrete ?? ''),
        'codigo': PlutoCell(value: codigo ?? ''),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'dataEntrega': PlutoCell(value: dataEntrega),
        'dataValidade': PlutoCell(value: dataValidade),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'valorFrete': PlutoCell(value: valorFrete ?? 0.0),
        'taxaComissao': PlutoCell(value: taxaComissao ?? 0.0),
        'valorComissao': PlutoCell(value: valorComissao ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'observacao': PlutoCell(value: observacao ?? ''),
        'viewPessoaTransportadora': PlutoCell(value: viewPessoaTransportadoraModel?.nome ?? ''),
        'vendaCondicoesPagamento': PlutoCell(value: vendaCondicoesPagamentoModel?.nome ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'viewPessoaVendedor': PlutoCell(value: viewPessoaVendedorModel?.nome ?? ''),
      },
    );
  }

  VendaOrcamentoCabecalhoModel clone() {
    return VendaOrcamentoCabecalhoModel(
      id: id,
      idCliente: idCliente,
      idVendedor: idVendedor,
      idTransportadora: idTransportadora,
      idVendaCondicoesPagamento: idVendaCondicoesPagamento,
      tipoFrete: tipoFrete,
      codigo: codigo,
      dataCadastro: dataCadastro,
      dataEntrega: dataEntrega,
      dataValidade: dataValidade,
      valorSubtotal: valorSubtotal,
      valorFrete: valorFrete,
      taxaComissao: taxaComissao,
      valorComissao: valorComissao,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      observacao: observacao,
      vendaOrcamentoDetalheModelList: vendaOrcamentoDetalheModelListClone(vendaOrcamentoDetalheModelList!),
      viewPessoaTransportadoraModel: viewPessoaTransportadoraModel?.clone(),
      vendaCondicoesPagamentoModel: vendaCondicoesPagamentoModel?.clone(),
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      viewPessoaVendedorModel: viewPessoaVendedorModel?.clone(),
    );
  }

  vendaOrcamentoDetalheModelListClone(List<VendaOrcamentoDetalheModel> vendaOrcamentoDetalheModelList) { 
		List<VendaOrcamentoDetalheModel> resultList = [];
		for (var vendaOrcamentoDetalheModel in vendaOrcamentoDetalheModelList) {
			resultList.add(vendaOrcamentoDetalheModel.clone());
		}
		return resultList;
	}


}