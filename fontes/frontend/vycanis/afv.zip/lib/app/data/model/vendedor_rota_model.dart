import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:afv/app/data/model/model_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class VendedorRotaModel extends ModelBase {
  int? id;
  int? idVendedor;
  int? idCliente;
  DateTime? dataRota;
  String? status;
  String? observacao;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  ViewPessoaVendedorModel? viewPessoaVendedorModel;
  List<VendedorVisitaModel>? vendedorVisitaModelList;

  VendedorRotaModel({
    this.id,
    this.idVendedor,
    this.idCliente,
    this.dataRota,
    this.status = 'Planejada',
    this.observacao,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    ViewPessoaVendedorModel? viewPessoaVendedorModel,
    List<VendedorVisitaModel>? vendedorVisitaModelList,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.viewPessoaVendedorModel = viewPessoaVendedorModel ?? ViewPessoaVendedorModel();
    this.vendedorVisitaModelList = vendedorVisitaModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_rota',
    'status',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Rota',
    'Status',
    'Observacao',
  ];

  VendedorRotaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendedor = jsonData['idVendedor'];
    idCliente = jsonData['idCliente'];
    dataRota = jsonData['dataRota'] != null ? DateTime.tryParse(jsonData['dataRota']) : null;
    status = VendedorRotaDomain.getStatus(jsonData['status']);
    observacao = jsonData['observacao'];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    viewPessoaVendedorModel = jsonData['viewPessoaVendedorModel'] == null ? ViewPessoaVendedorModel() : ViewPessoaVendedorModel.fromJson(jsonData['viewPessoaVendedorModel']);
    vendedorVisitaModelList = (jsonData['vendedorVisitaModelList'] as Iterable?)?.map((m) => VendedorVisitaModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendedor'] = idVendedor != 0 ? idVendedor : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['dataRota'] = dataRota != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRota!) : null;
    jsonData['status'] = VendedorRotaDomain.setStatus(status);
    jsonData['observacao'] = observacao;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['viewPessoaVendedorModel'] = viewPessoaVendedorModel?.toJson;
    jsonData['viewPessoaVendedor'] = viewPessoaVendedorModel?.nome ?? '';
    
		var vendedorVisitaModelLocalList = []; 
		for (VendedorVisitaModel object in vendedorVisitaModelList ?? []) { 
			vendedorVisitaModelLocalList.add(object.toJson); 
		}
		jsonData['vendedorVisitaModelList'] = vendedorVisitaModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendedorRotaModel fromPlutoRow(PlutoRow row) {
    return VendedorRotaModel(
      id: row.cells['id']?.value,
      idVendedor: row.cells['idVendedor']?.value,
      idCliente: row.cells['idCliente']?.value,
      dataRota: Util.stringToDate(row.cells['dataRota']?.value),
      status: row.cells['status']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendedor': PlutoCell(value: idVendedor ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'dataRota': PlutoCell(value: dataRota),
        'status': PlutoCell(value: status ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'viewPessoaVendedor': PlutoCell(value: viewPessoaVendedorModel?.nome ?? ''),
      },
    );
  }

  VendedorRotaModel clone() {
    return VendedorRotaModel(
      id: id,
      idVendedor: idVendedor,
      idCliente: idCliente,
      dataRota: dataRota,
      status: status,
      observacao: observacao,
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      viewPessoaVendedorModel: viewPessoaVendedorModel?.clone(),
      vendedorVisitaModelList: vendedorVisitaModelListClone(vendedorVisitaModelList!),
    );
  }

  vendedorVisitaModelListClone(List<VendedorVisitaModel> vendedorVisitaModelList) { 
		List<VendedorVisitaModel> resultList = [];
		for (var vendedorVisitaModel in vendedorVisitaModelList) {
			resultList.add(vendedorVisitaModel.clone());
		}
		return resultList;
	}


}