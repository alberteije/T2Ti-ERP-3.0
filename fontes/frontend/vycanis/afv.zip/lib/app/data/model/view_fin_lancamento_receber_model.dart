import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:afv/app/data/model/model_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:afv/app/data/domain/domain_imports.dart';

class ViewFinLancamentoReceberModel extends ModelBase {
  int? id;
  int? idFinLancamentoReceber;
  int? quantidadeParcela;
  double? valorLancamento;
  DateTime? dataLancamento;
  String? numeroDocumento;
  int? idFinParcelaReceber;
  int? numeroParcela;
  DateTime? dataVencimento;
  DateTime? dataRecebimento;
  double? valorParcela;
  double? taxaJuro;
  double? valorJuro;
  double? taxaMulta;
  double? valorMulta;
  double? taxaDesconto;
  double? valorDesconto;
  String? siglaDocumento;
  int? idCliente;
  int? idPessoa;
  String? nomeCliente;
  int? idFinStatusParcela;
  String? situacaoParcela;
  String? descricaoSituacaoParcela;
  int? idBancoContaCaixa;
  String? nomeContaCaixa;

  ViewFinLancamentoReceberModel({
    this.id,
    this.idFinLancamentoReceber,
    this.quantidadeParcela,
    this.valorLancamento,
    this.dataLancamento,
    this.numeroDocumento,
    this.idFinParcelaReceber,
    this.numeroParcela,
    this.dataVencimento,
    this.dataRecebimento,
    this.valorParcela,
    this.taxaJuro,
    this.valorJuro,
    this.taxaMulta,
    this.valorMulta,
    this.taxaDesconto,
    this.valorDesconto,
    this.siglaDocumento = 'AAA',
    this.idCliente,
    this.idPessoa,
    this.nomeCliente,
    this.idFinStatusParcela,
    this.situacaoParcela,
    this.descricaoSituacaoParcela,
    this.idBancoContaCaixa,
    this.nomeContaCaixa,
  });

  static List<String> dbColumns = <String>[
    'id',
    'id_fin_lancamento_receber',
    'quantidade_parcela',
    'valor_lancamento',
    'data_lancamento',
    'numero_documento',
    'id_fin_parcela_receber',
    'numero_parcela',
    'data_vencimento',
    'data_recebimento',
    'valor_parcela',
    'taxa_juro',
    'valor_juro',
    'taxa_multa',
    'valor_multa',
    'taxa_desconto',
    'valor_desconto',
    'sigla_documento',
    'id_cliente',
    'id_pessoa',
    'nome_cliente',
    'id_fin_status_parcela',
    'situacao_parcela',
    'descricao_situacao_parcela',
    'id_banco_conta_caixa',
    'nome_conta_caixa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Id Fin Lancamento Receber',
    'Quantidade Parcela',
    'Valor Lancamento',
    'Data Lancamento',
    'Numero Documento',
    'Id Fin Parcela Receber',
    'Numero Parcela',
    'Data Vencimento',
    'Data Recebimento',
    'Valor Parcela',
    'Taxa Juro',
    'Valor Juro',
    'Taxa Multa',
    'Valor Multa',
    'Taxa Desconto',
    'Valor Desconto',
    'Sigla Documento',
    'Id Cliente',
    'Id Pessoa',
    'Nome Cliente',
    'Id Fin Status Parcela',
    'Situacao Parcela',
    'Descricao Situacao Parcela',
    'Id Banco Conta Caixa',
    'Nome Conta Caixa',
  ];

  ViewFinLancamentoReceberModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFinLancamentoReceber = jsonData['idFinLancamentoReceber'];
    quantidadeParcela = jsonData['quantidadeParcela'];
    valorLancamento = jsonData['valorLancamento']?.toDouble();
    dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
    numeroDocumento = jsonData['numeroDocumento'];
    idFinParcelaReceber = jsonData['idFinParcelaReceber'];
    numeroParcela = jsonData['numeroParcela'];
    dataVencimento = jsonData['dataVencimento'] != null ? DateTime.tryParse(jsonData['dataVencimento']) : null;
    dataRecebimento = jsonData['dataRecebimento'] != null ? DateTime.tryParse(jsonData['dataRecebimento']) : null;
    valorParcela = jsonData['valorParcela']?.toDouble();
    taxaJuro = jsonData['taxaJuro']?.toDouble();
    valorJuro = jsonData['valorJuro']?.toDouble();
    taxaMulta = jsonData['taxaMulta']?.toDouble();
    valorMulta = jsonData['valorMulta']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    siglaDocumento = ViewFinLancamentoReceberDomain.getSiglaDocumento(jsonData['siglaDocumento']);
    idCliente = jsonData['idCliente'];
    idPessoa = jsonData['idPessoa'];
    nomeCliente = jsonData['nomeCliente'];
    idFinStatusParcela = jsonData['idFinStatusParcela'];
    situacaoParcela = jsonData['situacaoParcela'];
    descricaoSituacaoParcela = jsonData['descricaoSituacaoParcela'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    nomeContaCaixa = jsonData['nomeContaCaixa'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFinLancamentoReceber'] = idFinLancamentoReceber;
    jsonData['quantidadeParcela'] = quantidadeParcela;
    jsonData['valorLancamento'] = valorLancamento;
    jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
    jsonData['numeroDocumento'] = numeroDocumento;
    jsonData['idFinParcelaReceber'] = idFinParcelaReceber;
    jsonData['numeroParcela'] = numeroParcela;
    jsonData['dataVencimento'] = dataVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVencimento!) : null;
    jsonData['dataRecebimento'] = dataRecebimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRecebimento!) : null;
    jsonData['valorParcela'] = valorParcela;
    jsonData['taxaJuro'] = taxaJuro;
    jsonData['valorJuro'] = valorJuro;
    jsonData['taxaMulta'] = taxaMulta;
    jsonData['valorMulta'] = valorMulta;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['siglaDocumento'] = ViewFinLancamentoReceberDomain.setSiglaDocumento(siglaDocumento);
    jsonData['idCliente'] = idCliente;
    jsonData['idPessoa'] = idPessoa;
    jsonData['nomeCliente'] = nomeCliente;
    jsonData['idFinStatusParcela'] = idFinStatusParcela;
    jsonData['situacaoParcela'] = situacaoParcela;
    jsonData['descricaoSituacaoParcela'] = descricaoSituacaoParcela;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa;
    jsonData['nomeContaCaixa'] = nomeContaCaixa;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ViewFinLancamentoReceberModel fromPlutoRow(PlutoRow row) {
    return ViewFinLancamentoReceberModel(
      id: row.cells['id']?.value,
      idFinLancamentoReceber: row.cells['idFinLancamentoReceber']?.value,
      quantidadeParcela: row.cells['quantidadeParcela']?.value,
      valorLancamento: row.cells['valorLancamento']?.value,
      dataLancamento: Util.stringToDate(row.cells['dataLancamento']?.value),
      numeroDocumento: row.cells['numeroDocumento']?.value,
      idFinParcelaReceber: row.cells['idFinParcelaReceber']?.value,
      numeroParcela: row.cells['numeroParcela']?.value,
      dataVencimento: Util.stringToDate(row.cells['dataVencimento']?.value),
      dataRecebimento: Util.stringToDate(row.cells['dataRecebimento']?.value),
      valorParcela: row.cells['valorParcela']?.value,
      taxaJuro: row.cells['taxaJuro']?.value,
      valorJuro: row.cells['valorJuro']?.value,
      taxaMulta: row.cells['taxaMulta']?.value,
      valorMulta: row.cells['valorMulta']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      siglaDocumento: row.cells['siglaDocumento']?.value,
      idCliente: row.cells['idCliente']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      nomeCliente: row.cells['nomeCliente']?.value,
      idFinStatusParcela: row.cells['idFinStatusParcela']?.value,
      situacaoParcela: row.cells['situacaoParcela']?.value,
      descricaoSituacaoParcela: row.cells['descricaoSituacaoParcela']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      nomeContaCaixa: row.cells['nomeContaCaixa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFinLancamentoReceber': PlutoCell(value: idFinLancamentoReceber ?? 0),
        'quantidadeParcela': PlutoCell(value: quantidadeParcela ?? 0),
        'valorLancamento': PlutoCell(value: valorLancamento ?? 0.0),
        'dataLancamento': PlutoCell(value: dataLancamento),
        'numeroDocumento': PlutoCell(value: numeroDocumento ?? ''),
        'idFinParcelaReceber': PlutoCell(value: idFinParcelaReceber ?? 0),
        'numeroParcela': PlutoCell(value: numeroParcela ?? 0),
        'dataVencimento': PlutoCell(value: dataVencimento),
        'dataRecebimento': PlutoCell(value: dataRecebimento),
        'valorParcela': PlutoCell(value: valorParcela ?? 0.0),
        'taxaJuro': PlutoCell(value: taxaJuro ?? 0.0),
        'valorJuro': PlutoCell(value: valorJuro ?? 0.0),
        'taxaMulta': PlutoCell(value: taxaMulta ?? 0.0),
        'valorMulta': PlutoCell(value: valorMulta ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'siglaDocumento': PlutoCell(value: siglaDocumento ?? ''),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'nomeCliente': PlutoCell(value: nomeCliente ?? ''),
        'idFinStatusParcela': PlutoCell(value: idFinStatusParcela ?? 0),
        'situacaoParcela': PlutoCell(value: situacaoParcela ?? ''),
        'descricaoSituacaoParcela': PlutoCell(value: descricaoSituacaoParcela ?? ''),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'nomeContaCaixa': PlutoCell(value: nomeContaCaixa ?? ''),
      },
    );
  }

  ViewFinLancamentoReceberModel clone() {
    return ViewFinLancamentoReceberModel(
      id: id,
      idFinLancamentoReceber: idFinLancamentoReceber,
      quantidadeParcela: quantidadeParcela,
      valorLancamento: valorLancamento,
      dataLancamento: dataLancamento,
      numeroDocumento: numeroDocumento,
      idFinParcelaReceber: idFinParcelaReceber,
      numeroParcela: numeroParcela,
      dataVencimento: dataVencimento,
      dataRecebimento: dataRecebimento,
      valorParcela: valorParcela,
      taxaJuro: taxaJuro,
      valorJuro: valorJuro,
      taxaMulta: taxaMulta,
      valorMulta: valorMulta,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      siglaDocumento: siglaDocumento,
      idCliente: idCliente,
      idPessoa: idPessoa,
      nomeCliente: nomeCliente,
      idFinStatusParcela: idFinStatusParcela,
      situacaoParcela: situacaoParcela,
      descricaoSituacaoParcela: descricaoSituacaoParcela,
      idBancoContaCaixa: idBancoContaCaixa,
      nomeContaCaixa: nomeContaCaixa,
    );
  }


}