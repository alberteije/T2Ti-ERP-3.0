import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/page_imports.dart';
import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/repository/vendedor_rota_repository.dart';

class VendedorRotaController extends ControllerBase<VendedorRotaModel, VendedorRotaRepository> 
with GetSingleTickerProviderStateMixin {

  VendedorRotaController({required super.repository}) {
    dbColumns = VendedorRotaModel.dbColumns;
    aliasColumns = VendedorRotaModel.aliasColumns;
    gridColumns = vendedorRotaGridColumns();
    functionName = "vendedor_rota";
    screenTitle = "Rotas";
  }

  final vendedorRotaScaffoldKey = GlobalKey<ScaffoldState>();
  final vendedorRotaTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final vendedorRotaFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  VendedorRotaModel createNewModel() => VendedorRotaModel();

  @override
  final standardFieldForFilter = VendedorRotaModel.aliasColumns[VendedorRotaModel.dbColumns.indexOf('data_rota')];

  final viewPessoaVendedorModelController = TextEditingController();
  final viewPessoaClienteModelController = TextEditingController();
  final dataRotaController = DatePickerItemController(null);
  final statusController = CustomDropdownButtonController('Planejada');
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_rota'],
    'secondaryColumns': ['status'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendedorRota) => vendedorRota.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.vendedorRotaTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaVendedorModelController.text = '';
    viewPessoaClienteModelController.text = '';
    dataRotaController.date = null;
    statusController.selected = 'Planejada';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.vendedorRotaTabPage);
  }

  _configureChildrenControllers() {
    //Visitas
		Get.put<VendedorVisitaController>(VendedorVisitaController()); 

  }
	
	_releaseChildrenControllers() {
    //Visitas
		Get.delete<VendedorVisitaController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome?.toString() ?? '';
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    dataRotaController.date = currentModel.dataRota;
    statusController.selected = currentModel.status ?? 'Planejada';
    observacaoController.text = currentModel.observacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Visitas
		final vendedorVisitaController = Get.find<VendedorVisitaController>(); 
		vendedorVisitaController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(vendedorRotaModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaVendedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Vendedor]'; 
		lookupController.route = '/view-pessoa-vendedor/'; 
		lookupController.gridColumns = viewPessoaVendedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaVendedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaVendedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaVendedorModel.aliasColumns[ViewPessoaVendedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaVendedorModel = ViewPessoaVendedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Rotas', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Visitas', 
		),
  ];

  List<Widget> tabPages() {
    return [
      VendedorRotaEditPage(),
      const VendedorVisitaListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<VendedorVisitaController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaVendedorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Vendedor]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaVendedorModelController.dispose();
    viewPessoaClienteModelController.dispose();
    dataRotaController.dispose();
    statusController.dispose();
    observacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}