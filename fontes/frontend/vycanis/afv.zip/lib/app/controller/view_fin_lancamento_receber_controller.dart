import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

import 'package:afv/app/page/page_imports.dart';
import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';

class ViewFinLancamentoReceberController extends ControllerBase<ViewFinLancamentoReceberModel, void> {

  ViewFinLancamentoReceberController() : super(repository: null) {
    dbColumns = ViewFinLancamentoReceberModel.dbColumns;
    aliasColumns = ViewFinLancamentoReceberModel.aliasColumns;
    gridColumns = viewFinLancamentoReceberGridColumns();
    functionName = "view_fin_lancamento_receber";
    screenTitle = "Financeiro";
  }

  final _viewFinLancamentoReceberModel = ViewFinLancamentoReceberModel().obs;
  ViewFinLancamentoReceberModel get viewFinLancamentoReceberModel => _viewFinLancamentoReceberModel.value;
  set viewFinLancamentoReceberModel(value) => _viewFinLancamentoReceberModel.value = value ?? ViewFinLancamentoReceberModel();

  List<ViewFinLancamentoReceberModel> get viewFinLancamentoReceberModelList => Get.find<PessoaController>().currentModel.viewFinLancamentoReceberModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final viewFinLancamentoReceberScaffoldKey = GlobalKey<ScaffoldState>();
  final viewFinLancamentoReceberFormKey = GlobalKey<FormState>();

  @override
  ViewFinLancamentoReceberModel createNewModel() => ViewFinLancamentoReceberModel();

  @override
  final standardFieldForFilter = ViewFinLancamentoReceberModel.aliasColumns[ViewFinLancamentoReceberModel.dbColumns.indexOf('id_fin_lancamento_receber')];

  final idFinLancamentoReceberController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeParcelaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorLancamentoController = MoneyMaskedTextController();
  final dataLancamentoController = DatePickerItemController(null);
  final numeroDocumentoController = TextEditingController();
  final idFinParcelaReceberController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final numeroParcelaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataVencimentoController = DatePickerItemController(null);
  final dataRecebimentoController = DatePickerItemController(null);
  final valorParcelaController = MoneyMaskedTextController();
  final taxaJuroController = MoneyMaskedTextController();
  final valorJuroController = MoneyMaskedTextController();
  final taxaMultaController = MoneyMaskedTextController();
  final valorMultaController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final siglaDocumentoController = CustomDropdownButtonController('AAA');
  final idClienteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idPessoaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeClienteController = TextEditingController();
  final idFinStatusParcelaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final situacaoParcelaController = TextEditingController();
  final descricaoSituacaoParcelaController = TextEditingController();
  final idBancoContaCaixaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeContaCaixaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['id_fin_lancamento_receber'],
    'secondaryColumns': ['quantidade_parcela'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((viewFinLancamentoReceber) => viewFinLancamentoReceber.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(viewFinLancamentoReceberModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    viewFinLancamentoReceberModel = createNewModel();
    _resetForm();
    Get.to(() => ViewFinLancamentoReceberEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    idFinLancamentoReceberController.updateValue(0);
    quantidadeParcelaController.updateValue(0);
    valorLancamentoController.updateValue(0);
    dataLancamentoController.date = null;
    numeroDocumentoController.text = '';
    idFinParcelaReceberController.updateValue(0);
    numeroParcelaController.updateValue(0);
    dataVencimentoController.date = null;
    dataRecebimentoController.date = null;
    valorParcelaController.updateValue(0);
    taxaJuroController.updateValue(0);
    valorJuroController.updateValue(0);
    taxaMultaController.updateValue(0);
    valorMultaController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    siglaDocumentoController.selected = 'AAA';
    idClienteController.updateValue(0);
    idPessoaController.updateValue(0);
    nomeClienteController.text = '';
    idFinStatusParcelaController.updateValue(0);
    situacaoParcelaController.text = '';
    descricaoSituacaoParcelaController.text = '';
    idBancoContaCaixaController.updateValue(0);
    nomeContaCaixaController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = viewFinLancamentoReceberModelList.firstWhere((m) => m.tempId == tempId);
    viewFinLancamentoReceberModel = model.clone();
		viewFinLancamentoReceberModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ViewFinLancamentoReceberEditPage());
  }

  void updateControllersFromModel() {
    idFinLancamentoReceberController.updateValue((viewFinLancamentoReceberModel.idFinLancamentoReceber ?? 0).toDouble());
    quantidadeParcelaController.updateValue((viewFinLancamentoReceberModel.quantidadeParcela ?? 0).toDouble());
    valorLancamentoController.updateValue(viewFinLancamentoReceberModel.valorLancamento ?? 0);
    dataLancamentoController.date = viewFinLancamentoReceberModel.dataLancamento;
    numeroDocumentoController.text = viewFinLancamentoReceberModel.numeroDocumento ?? '';
    idFinParcelaReceberController.updateValue((viewFinLancamentoReceberModel.idFinParcelaReceber ?? 0).toDouble());
    numeroParcelaController.updateValue((viewFinLancamentoReceberModel.numeroParcela ?? 0).toDouble());
    dataVencimentoController.date = viewFinLancamentoReceberModel.dataVencimento;
    dataRecebimentoController.date = viewFinLancamentoReceberModel.dataRecebimento;
    valorParcelaController.updateValue(viewFinLancamentoReceberModel.valorParcela ?? 0);
    taxaJuroController.updateValue(viewFinLancamentoReceberModel.taxaJuro ?? 0);
    valorJuroController.updateValue(viewFinLancamentoReceberModel.valorJuro ?? 0);
    taxaMultaController.updateValue(viewFinLancamentoReceberModel.taxaMulta ?? 0);
    valorMultaController.updateValue(viewFinLancamentoReceberModel.valorMulta ?? 0);
    taxaDescontoController.updateValue(viewFinLancamentoReceberModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(viewFinLancamentoReceberModel.valorDesconto ?? 0);
    siglaDocumentoController.selected = viewFinLancamentoReceberModel.siglaDocumento ?? 'AAA';
    idClienteController.updateValue((viewFinLancamentoReceberModel.idCliente ?? 0).toDouble());
    idPessoaController.updateValue((viewFinLancamentoReceberModel.idPessoa ?? 0).toDouble());
    nomeClienteController.text = viewFinLancamentoReceberModel.nomeCliente ?? '';
    idFinStatusParcelaController.updateValue((viewFinLancamentoReceberModel.idFinStatusParcela ?? 0).toDouble());
    situacaoParcelaController.text = viewFinLancamentoReceberModel.situacaoParcela ?? '';
    descricaoSituacaoParcelaController.text = viewFinLancamentoReceberModel.descricaoSituacaoParcela ?? '';
    idBancoContaCaixaController.updateValue((viewFinLancamentoReceberModel.idBancoContaCaixa ?? 0).toDouble());
    nomeContaCaixaController.text = viewFinLancamentoReceberModel.nomeContaCaixa ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!viewFinLancamentoReceberFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        viewFinLancamentoReceberModelList.insert(0, viewFinLancamentoReceberModel.clone());
      } else {
        final index = viewFinLancamentoReceberModelList.indexWhere((m) => m.tempId == viewFinLancamentoReceberModel.tempId);
        if (index >= 0) {
          viewFinLancamentoReceberModelList[index] = viewFinLancamentoReceberModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      viewFinLancamentoReceberModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    idFinLancamentoReceberController.dispose();
    quantidadeParcelaController.dispose();
    valorLancamentoController.dispose();
    dataLancamentoController.dispose();
    numeroDocumentoController.dispose();
    idFinParcelaReceberController.dispose();
    numeroParcelaController.dispose();
    dataVencimentoController.dispose();
    dataRecebimentoController.dispose();
    valorParcelaController.dispose();
    taxaJuroController.dispose();
    valorJuroController.dispose();
    taxaMultaController.dispose();
    valorMultaController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    siglaDocumentoController.dispose();
    idClienteController.dispose();
    idPessoaController.dispose();
    nomeClienteController.dispose();
    idFinStatusParcelaController.dispose();
    situacaoParcelaController.dispose();
    descricaoSituacaoParcelaController.dispose();
    idBancoContaCaixaController.dispose();
    nomeContaCaixaController.dispose();
  }

}