import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';

class ClienteController extends ControllerBase<ClienteModel, void> {

  ClienteController() : super(repository: null) {
    dbColumns = ClienteModel.dbColumns;
    aliasColumns = ClienteModel.aliasColumns;
    functionName = "cliente";
    screenTitle = "Cliente";
  }

	String? mandatoryMessage;

  final _clienteModel = ClienteModel().obs;
  ClienteModel get clienteModel => Get.find<PessoaController>().currentModel.clienteModel ?? ClienteModel();
  set clienteModel(value) => _clienteModel.value = value ?? ClienteModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final clienteScaffoldKey = GlobalKey<ScaffoldState>();
  final clienteFormKey = GlobalKey<FormState>();

  @override
  ClienteModel createNewModel() => ClienteModel();

  @override
  final standardFieldForFilter = "";

  final tabelaPrecoModelController = TextEditingController();
  final desdeController = DatePickerItemController(null);
  final dataCadastroController = DatePickerItemController(null);
  final taxaDescontoController = MoneyMaskedTextController();
  final limiteCreditoController = MoneyMaskedTextController();
  final observacaoController = TextEditingController();
  final ehGovernoController = CustomDropdownButtonController('Sim');
  final tipoEnteGovernamentalController = CustomDropdownButtonController('Não é Governo');
  final governoPercentualReducaoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cliente) => cliente.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    tabelaPrecoModelController.text = '';
    desdeController.date = null;
    dataCadastroController.date = null;
    taxaDescontoController.updateValue(0);
    limiteCreditoController.updateValue(0);
    observacaoController.text = '';
    ehGovernoController.selected = 'Sim';
    tipoEnteGovernamentalController.selected = 'Não é Governo';
    governoPercentualReducaoController.updateValue(0);
  }

  void updateControllersFromModel() {
		_resetForm();
    tabelaPrecoModelController.text = clienteModel.tabelaPrecoModel?.nome?.toString() ?? '';
    desdeController.date = clienteModel.desde;
    dataCadastroController.date = clienteModel.dataCadastro;
    taxaDescontoController.updateValue(clienteModel.taxaDesconto ?? 0);
    limiteCreditoController.updateValue(clienteModel.limiteCredito ?? 0);
    observacaoController.text = clienteModel.observacao ?? '';
    ehGovernoController.selected = clienteModel.ehGoverno ?? 'Sim';
    tipoEnteGovernamentalController.selected = clienteModel.tipoEnteGovernamental ?? 'Não é Governo';
    governoPercentualReducaoController.updateValue(clienteModel.governoPercentualReducao ?? 0);
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    // mandatoryMessage = ValidateFormField.validateMandatory(clienteModel.tabelaPrecoModel?.nome); 
		// if (mandatoryMessage != null) { 
		// 	showErrorSnackBar(message: '$mandatoryMessage [Tabela Preco]'); 
		// 	return false; 
		// }
    return true;
	}

  Future callTabelaPrecoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tabela Preco]'; 
		lookupController.route = '/tabela-preco/'; 
		lookupController.gridColumns = tabelaPrecoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TabelaPrecoModel.aliasColumns; 
		lookupController.dbColumns = TabelaPrecoModel.dbColumns; 
		lookupController.standardColumn = TabelaPrecoModel.aliasColumns[TabelaPrecoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			clienteModel.idTabelaPreco = plutoRowResult.cells['id']!.value; 
			clienteModel.tabelaPrecoModel = TabelaPrecoModel.fromPlutoRow(plutoRowResult); 
			tabelaPrecoModelController.text = clienteModel.tabelaPrecoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    tabelaPrecoModelController.dispose();
    desdeController.dispose();
    dataCadastroController.dispose();
    taxaDescontoController.dispose();
    limiteCreditoController.dispose();
    observacaoController.dispose();
    ehGovernoController.dispose();
    tipoEnteGovernamentalController.dispose();
    governoPercentualReducaoController.dispose();
  }

}