import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/repository/tabela_preco_repository.dart';

class TabelaPrecoController extends ControllerBase<TabelaPrecoModel, TabelaPrecoRepository> {

  TabelaPrecoController({required super.repository}) {
    dbColumns = TabelaPrecoModel.dbColumns;
    aliasColumns = TabelaPrecoModel.aliasColumns;
    gridColumns = tabelaPrecoGridColumns();
    functionName = "tabela_preco";
    screenTitle = "Tabelas de Preço";
  }

  @override
  TabelaPrecoModel createNewModel() => TabelaPrecoModel();

  @override
  final standardFieldForFilter = TabelaPrecoModel.aliasColumns[TabelaPrecoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final principalController = CustomDropdownButtonController('Sim');
  final coeficienteController = MoneyMaskedTextController();
  final valorFixoController = MoneyMaskedTextController();
  final tipoAjusteController = CustomDropdownButtonController('Coeficiente');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['principal'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tabelaPreco) => tabelaPreco.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.tabelaPrecoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    principalController.selected = 'Sim';
    coeficienteController.updateValue(0);
    valorFixoController.updateValue(0);
    tipoAjusteController.selected = 'Coeficiente';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.tabelaPrecoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    principalController.selected = currentModel.principal ?? 'Sim';
    coeficienteController.updateValue(currentModel.coeficiente ?? 0);
    valorFixoController.updateValue(currentModel.valorFixo ?? 0);
    tipoAjusteController.selected = currentModel.tipoAjuste ?? 'Coeficiente';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(tabelaPrecoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    principalController.dispose();
    coeficienteController.dispose();
    valorFixoController.dispose();
    tipoAjusteController.dispose();
    super.onClose();
  }

}