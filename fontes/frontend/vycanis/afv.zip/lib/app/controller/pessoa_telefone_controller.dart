import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

import 'package:afv/app/page/page_imports.dart';
import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';

class PessoaTelefoneController extends ControllerBase<PessoaTelefoneModel, void> {

  PessoaTelefoneController() : super(repository: null) {
    dbColumns = PessoaTelefoneModel.dbColumns;
    aliasColumns = PessoaTelefoneModel.aliasColumns;
    gridColumns = pessoaTelefoneGridColumns();
    functionName = "pessoa_telefone";
    screenTitle = "Telefones";
  }

  final _pessoaTelefoneModel = PessoaTelefoneModel().obs;
  PessoaTelefoneModel get pessoaTelefoneModel => _pessoaTelefoneModel.value;
  set pessoaTelefoneModel(value) => _pessoaTelefoneModel.value = value ?? PessoaTelefoneModel();

  List<PessoaTelefoneModel> get pessoaTelefoneModelList => Get.find<PessoaController>().currentModel.pessoaTelefoneModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pessoaTelefoneScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaTelefoneFormKey = GlobalKey<FormState>();

  @override
  PessoaTelefoneModel createNewModel() => PessoaTelefoneModel();

  @override
  final standardFieldForFilter = PessoaTelefoneModel.aliasColumns[PessoaTelefoneModel.dbColumns.indexOf('tipo')];

  final tipoController = CustomDropdownButtonController('Fixo');
  final numeroController = MaskedTextController(mask: '(00)00000-0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo'],
    'secondaryColumns': ['numero'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pessoaTelefone) => pessoaTelefone.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pessoaTelefoneModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pessoaTelefoneModel = createNewModel();
    _resetForm();
    Get.to(() => PessoaTelefoneEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    tipoController.selected = 'Fixo';
    numeroController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pessoaTelefoneModelList.firstWhere((m) => m.tempId == tempId);
    pessoaTelefoneModel = model.clone();
		pessoaTelefoneModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PessoaTelefoneEditPage());
  }

  void updateControllersFromModel() {
    tipoController.selected = pessoaTelefoneModel.tipo ?? 'Fixo';
    numeroController.text = pessoaTelefoneModel.numero ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pessoaTelefoneFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pessoaTelefoneModelList.insert(0, pessoaTelefoneModel.clone());
      } else {
        final index = pessoaTelefoneModelList.indexWhere((m) => m.tempId == pessoaTelefoneModel.tempId);
        if (index >= 0) {
          pessoaTelefoneModelList[index] = pessoaTelefoneModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pessoaTelefoneModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    tipoController.dispose();
    numeroController.dispose();
  }

}