import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';
import 'package:afv/app/routes/app_routes.dart';

import 'package:afv/app/page/page_imports.dart';
import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendedorVisitaController extends ControllerBase<VendedorVisitaModel, void> {

  VendedorVisitaController() : super(repository: null) {
    dbColumns = VendedorVisitaModel.dbColumns;
    aliasColumns = VendedorVisitaModel.aliasColumns;
    gridColumns = vendedorVisitaGridColumns();
    functionName = "vendedor_visita";
    screenTitle = "Visitas";
  }

  final _vendedorVisitaModel = VendedorVisitaModel().obs;
  VendedorVisitaModel get vendedorVisitaModel => _vendedorVisitaModel.value;
  set vendedorVisitaModel(value) => _vendedorVisitaModel.value = value ?? VendedorVisitaModel();

  List<VendedorVisitaModel> get vendedorVisitaModelList => Get.find<VendedorRotaController>().currentModel.vendedorVisitaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final vendedorVisitaScaffoldKey = GlobalKey<ScaffoldState>();
  final vendedorVisitaFormKey = GlobalKey<FormState>();

  @override
  VendedorVisitaModel createNewModel() => VendedorVisitaModel();

  @override
  final standardFieldForFilter = VendedorVisitaModel.aliasColumns[VendedorVisitaModel.dbColumns.indexOf('data_prevista')];

  final vendaCabecalhoModelController = TextEditingController();
  final vendaOrcamentoCabecalhoModelController = TextEditingController();
  final dataPrevistaController = DatePickerItemController(null);
  final dataRealizadaController = DatePickerItemController(null);
  final horaInicioController = MaskedTextController(mask: '00:00:00',);
  final horaFimController = MaskedTextController(mask: '00:00:00',);
  final latitudeController = MoneyMaskedTextController();
  final longitudeController = MoneyMaskedTextController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_prevista'],
    'secondaryColumns': ['data_realizada'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendedorVisita) => vendedorVisita.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(vendedorVisitaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    vendedorVisitaModel = createNewModel();
    _resetForm();
    Get.to(() => VendedorVisitaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    vendaCabecalhoModelController.text = '';
    vendaOrcamentoCabecalhoModelController.text = '';
    dataPrevistaController.date = null;
    dataRealizadaController.date = null;
    horaInicioController.text = '';
    horaFimController.text = '';
    latitudeController.updateValue(0);
    longitudeController.updateValue(0);
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = vendedorVisitaModelList.firstWhere((m) => m.tempId == tempId);
    vendedorVisitaModel = model.clone();
		vendedorVisitaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => VendedorVisitaEditPage());
  }

  void updateControllersFromModel() {
    vendaCabecalhoModelController.text = vendedorVisitaModel.vendaCabecalhoModel?.id?.toString() ?? '';
    vendaOrcamentoCabecalhoModelController.text = vendedorVisitaModel.vendaOrcamentoCabecalhoModel?.id?.toString() ?? '';
    dataPrevistaController.date = vendedorVisitaModel.dataPrevista;
    dataRealizadaController.date = vendedorVisitaModel.dataRealizada;
    horaInicioController.text = vendedorVisitaModel.horaInicio ?? '';
    horaFimController.text = vendedorVisitaModel.horaFim ?? '';
    latitudeController.updateValue(vendedorVisitaModel.latitude ?? 0);
    longitudeController.updateValue(vendedorVisitaModel.longitude ?? 0);
    observacaoController.text = vendedorVisitaModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!vendedorVisitaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        vendedorVisitaModelList.insert(0, vendedorVisitaModel.clone());
      } else {
        final index = vendedorVisitaModelList.indexWhere((m) => m.tempId == vendedorVisitaModel.tempId);
        if (index >= 0) {
          vendedorVisitaModelList[index] = vendedorVisitaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callVendaCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Venda Cabecalho]'; 
		lookupController.route = '/venda-cabecalho/'; 
		lookupController.gridColumns = vendaCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = VendaCabecalhoModel.dbColumns; 
		lookupController.standardColumn = VendaCabecalhoModel.aliasColumns[VendaCabecalhoModel.dbColumns.indexOf('id')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendedorVisitaModel.idVendaCabecalho = plutoRowResult.cells['id']!.value; 
			vendedorVisitaModel.vendaCabecalhoModel = VendaCabecalhoModel.fromPlutoRow(plutoRowResult); 
			vendaCabecalhoModelController.text = vendedorVisitaModel.vendaCabecalhoModel?.id?.toString() ?? ''; 
			formWasChangedDetail = true; 
		}
	}

  Future callVendaOrcamentoCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Venda Orcamento Cabecalho]'; 
		lookupController.route = '/venda-orcamento-cabecalho/'; 
		lookupController.gridColumns = vendaOrcamentoCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaOrcamentoCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = VendaOrcamentoCabecalhoModel.dbColumns; 
		lookupController.standardColumn = VendaOrcamentoCabecalhoModel.aliasColumns[VendaOrcamentoCabecalhoModel.dbColumns.indexOf('id')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendedorVisitaModel.idVendaOrcamentoCabecalho = plutoRowResult.cells['id']!.value; 
			vendedorVisitaModel.vendaOrcamentoCabecalhoModel = VendaOrcamentoCabecalhoModel.fromPlutoRow(plutoRowResult); 
			vendaOrcamentoCabecalhoModelController.text = vendedorVisitaModel.vendaOrcamentoCabecalhoModel?.id?.toString() ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      vendedorVisitaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    vendaCabecalhoModelController.dispose();
    vendaOrcamentoCabecalhoModelController.dispose();
    dataPrevistaController.dispose();
    dataRealizadaController.dispose();
    horaInicioController.dispose();
    horaFimController.dispose();
    latitudeController.dispose();
    longitudeController.dispose();
    observacaoController.dispose();
  }

}