import 'package:get/get.dart';
import 'package:afv/app/data/repository/dashboard_repository.dart';

class DashboardController extends GetxController {
  final DashboardRepository repository;
  
  final Rx<DashboardData> dashboardData = DashboardData().obs;
  final RxBool isLoading = true.obs;
  final RxString errorMessage = ''.obs;
  
  DashboardController({required this.repository});
  
  @override
  void onInit() {
    super.onInit();
    loadDashboardData();
  }
  
  Future<void> loadDashboardData() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';
      
      final result = await repository.getDashboardData();
      if (result != null) {
        dashboardData.value = result;
      }
    } catch (e) {
      errorMessage.value = 'Erro ao carregar dashboard: $e';
    } finally {
      isLoading.value = false;
    }
  }
  
  Future<void> refreshDashboard() async {
    await loadDashboardData();
  }
}

class DashboardData {
  VendedorInfo? vendedorInfo;
  double totalVendasMes = 0;
  int totalOrcamentosMes = 0;
  int visitasHoje = 0;
  int clientesAtivos = 0;
  double receberHoje = 0;
  double metaAtingida = 0;
  List<VendaResumo> ultimasVendas = [];
  List<VisitaResumo> proximasVisitas = [];
  
  DashboardData();
}

class VendedorInfo {
  final int id;
  final String nome;
  final String? email;
  final double? comissao;
  final double? metaVenda;
  
  VendedorInfo({
    required this.id,
    required this.nome,
    this.email,
    this.comissao,
    this.metaVenda,
  });
}

class VendaResumo {
  final int id;
  final DateTime data;
  final double valor;
  final String clienteNome;
  
  VendaResumo({
    required this.id,
    required this.data,
    required this.valor,
    required this.clienteNome,
  });
}

class VisitaResumo {
  final int id;
  final DateTime data;
  final String clienteNome;
  final String? observacao;
  
  VisitaResumo({
    required this.id,
    required this.data,
    required this.clienteNome,
    this.observacao,
  });
}