import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/page_imports.dart';
import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/repository/venda_cabecalho_repository.dart';

class VendaCabecalhoController extends ControllerBase<VendaCabecalhoModel, VendaCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  VendaCabecalhoController({required super.repository}) {
    dbColumns = VendaCabecalhoModel.dbColumns;
    aliasColumns = VendaCabecalhoModel.aliasColumns;
    gridColumns = vendaCabecalhoGridColumns();
    functionName = "venda_cabecalho";
    screenTitle = "Pedido de Venda";
  }

  final vendaCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  VendaCabecalhoModel createNewModel() => VendaCabecalhoModel();

  @override
  final standardFieldForFilter = VendaCabecalhoModel.aliasColumns[VendaCabecalhoModel.dbColumns.indexOf('local_entrega')];

  final notaFiscalTipoModelController = TextEditingController();
  final viewPessoaVendedorModelController = TextEditingController();
  final vendaOrcamentoCabecalhoModelController = TextEditingController();
  final vendaCondicoesPagamentoModelController = TextEditingController();
  final viewPessoaTransportadoraModelController = TextEditingController();
  final viewPessoaClienteModelController = TextEditingController();
  final localEntregaController = TextEditingController();
  final localCobrancaController = TextEditingController();
  final tipoFreteController = CustomDropdownButtonController('CIF');
  final formaPagamentoController = CustomDropdownButtonController('A Vista');
  final dataVendaController = DatePickerItemController(null);
  final dataSaidaController = DatePickerItemController(null);
  final horaSaidaController = MaskedTextController(mask: '00:00:00',);
  final numeroFaturaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorFreteController = MoneyMaskedTextController();
  final valorSeguroController = MoneyMaskedTextController();
  final valorSubtotalController = MoneyMaskedTextController();
  final taxaComissaoController = MoneyMaskedTextController();
  final valorComissaoController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();
  final situacaoController = CustomDropdownButtonController('Digitação');
  final diaFixoParcelaController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['local_entrega'],
    'secondaryColumns': ['local_cobranca'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaCabecalho) => vendaCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.vendaCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    notaFiscalTipoModelController.text = '';
    viewPessoaVendedorModelController.text = '';
    vendaOrcamentoCabecalhoModelController.text = '';
    vendaCondicoesPagamentoModelController.text = '';
    viewPessoaTransportadoraModelController.text = '';
    viewPessoaClienteModelController.text = '';
    localEntregaController.text = '';
    localCobrancaController.text = '';
    tipoFreteController.selected = 'CIF';
    formaPagamentoController.selected = 'A Vista';
    dataVendaController.date = null;
    dataSaidaController.date = null;
    horaSaidaController.text = '';
    numeroFaturaController.updateValue(0);
    valorFreteController.updateValue(0);
    valorSeguroController.updateValue(0);
    valorSubtotalController.updateValue(0);
    taxaComissaoController.updateValue(0);
    valorComissaoController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
    situacaoController.selected = 'Digitação';
    diaFixoParcelaController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.vendaCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Itens da Venda
		Get.put<VendaDetalheController>(VendaDetalheController()); 

    //Frete
		Get.put<VendaFreteController>(VendaFreteController()); 

  }
	
	_releaseChildrenControllers() {
    //Itens da Venda
		Get.delete<VendaDetalheController>(); 

    //Frete
		Get.delete<VendaFreteController>(); 

	}
  
  void updateControllersFromModel() {
    notaFiscalTipoModelController.text = currentModel.notaFiscalTipoModel?.nome?.toString() ?? '';
    viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome?.toString() ?? '';
    vendaOrcamentoCabecalhoModelController.text = currentModel.vendaOrcamentoCabecalhoModel?.codigo?.toString() ?? '';
    vendaCondicoesPagamentoModelController.text = currentModel.vendaCondicoesPagamentoModel?.nome?.toString() ?? '';
    viewPessoaTransportadoraModelController.text = currentModel.viewPessoaTransportadoraModel?.nome?.toString() ?? '';
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    localEntregaController.text = currentModel.localEntrega ?? '';
    localCobrancaController.text = currentModel.localCobranca ?? '';
    tipoFreteController.selected = currentModel.tipoFrete ?? 'CIF';
    formaPagamentoController.selected = currentModel.formaPagamento ?? 'A Vista';
    dataVendaController.date = currentModel.dataVenda;
    dataSaidaController.date = currentModel.dataSaida;
    horaSaidaController.text = currentModel.horaSaida ?? '';
    numeroFaturaController.updateValue((currentModel.numeroFatura ?? 0).toDouble());
    valorFreteController.updateValue(currentModel.valorFrete ?? 0);
    valorSeguroController.updateValue(currentModel.valorSeguro ?? 0);
    valorSubtotalController.updateValue(currentModel.valorSubtotal ?? 0);
    taxaComissaoController.updateValue(currentModel.taxaComissao ?? 0);
    valorComissaoController.updateValue(currentModel.valorComissao ?? 0);
    taxaDescontoController.updateValue(currentModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(currentModel.valorDesconto ?? 0);
    valorTotalController.updateValue(currentModel.valorTotal ?? 0);
    situacaoController.selected = currentModel.situacao ?? 'Digitação';
    diaFixoParcelaController.text = currentModel.diaFixoParcela ?? '';
    observacaoController.text = currentModel.observacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Itens da Venda
		final vendaDetalheController = Get.find<VendaDetalheController>(); 
		vendaDetalheController.userMadeChanges = false; 

    //Frete
		final vendaFreteController = Get.find<VendaFreteController>(); 
		vendaFreteController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(vendaCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callNotaFiscalTipoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Nota Fiscal]'; 
		lookupController.route = '/nota-fiscal-tipo/'; 
		lookupController.gridColumns = notaFiscalTipoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = NotaFiscalTipoModel.aliasColumns; 
		lookupController.dbColumns = NotaFiscalTipoModel.dbColumns; 
		lookupController.standardColumn = NotaFiscalTipoModel.aliasColumns[NotaFiscalTipoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idNotaFiscalTipo = plutoRowResult.cells['id']!.value; 
			currentModel.notaFiscalTipoModel = NotaFiscalTipoModel.fromPlutoRow(plutoRowResult); 
			notaFiscalTipoModelController.text = currentModel.notaFiscalTipoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaVendedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Vendedor]'; 
		lookupController.route = '/view-pessoa-vendedor/'; 
		lookupController.gridColumns = viewPessoaVendedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaVendedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaVendedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaVendedorModel.aliasColumns[ViewPessoaVendedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaVendedorModel = ViewPessoaVendedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callVendaOrcamentoCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Orçamento]'; 
		lookupController.route = '/venda-orcamento-cabecalho/'; 
		lookupController.gridColumns = vendaOrcamentoCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaOrcamentoCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = VendaOrcamentoCabecalhoModel.dbColumns; 
		lookupController.standardColumn = VendaOrcamentoCabecalhoModel.aliasColumns[VendaOrcamentoCabecalhoModel.dbColumns.indexOf('codigo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendaOrcamentoCabecalho = plutoRowResult.cells['id']!.value; 
			currentModel.vendaOrcamentoCabecalhoModel = VendaOrcamentoCabecalhoModel.fromPlutoRow(plutoRowResult); 
			vendaOrcamentoCabecalhoModelController.text = currentModel.vendaOrcamentoCabecalhoModel?.codigo ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callVendaCondicoesPagamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Condições Pagamento]'; 
		lookupController.route = '/venda-condicoes-pagamento/'; 
		lookupController.gridColumns = vendaCondicoesPagamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaCondicoesPagamentoModel.aliasColumns; 
		lookupController.dbColumns = VendaCondicoesPagamentoModel.dbColumns; 
		lookupController.standardColumn = VendaCondicoesPagamentoModel.aliasColumns[VendaCondicoesPagamentoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendaCondicoesPagamento = plutoRowResult.cells['id']!.value; 
			currentModel.vendaCondicoesPagamentoModel = VendaCondicoesPagamentoModel.fromPlutoRow(plutoRowResult); 
			vendaCondicoesPagamentoModelController.text = currentModel.vendaCondicoesPagamentoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaTransportadoraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Transportadora]'; 
		lookupController.route = '/view-pessoa-transportadora/'; 
		lookupController.gridColumns = viewPessoaTransportadoraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaTransportadoraModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaTransportadoraModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaTransportadoraModel.aliasColumns[ViewPessoaTransportadoraModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTransportadora = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaTransportadoraModel = ViewPessoaTransportadoraModel.fromPlutoRow(plutoRowResult); 
			viewPessoaTransportadoraModelController.text = currentModel.viewPessoaTransportadoraModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pedido de Venda', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens da Venda', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Frete', 
		),
  ];

  List<Widget> tabPages() {
    return [
      VendaCabecalhoEditPage(),
      const VendaDetalheListPage(),
      const VendaFreteListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<VendaDetalheController>().userMadeChanges
    || 
		Get.find<VendaFreteController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.notaFiscalTipoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Tipo Nota Fiscal]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaVendedorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Vendedor]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.vendaCondicoesPagamentoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Condições Pagamento]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaTransportadoraModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Transportadora]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    notaFiscalTipoModelController.dispose();
    viewPessoaVendedorModelController.dispose();
    vendaOrcamentoCabecalhoModelController.dispose();
    vendaCondicoesPagamentoModelController.dispose();
    viewPessoaTransportadoraModelController.dispose();
    viewPessoaClienteModelController.dispose();
    localEntregaController.dispose();
    localCobrancaController.dispose();
    tipoFreteController.dispose();
    formaPagamentoController.dispose();
    dataVendaController.dispose();
    dataSaidaController.dispose();
    horaSaidaController.dispose();
    numeroFaturaController.dispose();
    valorFreteController.dispose();
    valorSeguroController.dispose();
    valorSubtotalController.dispose();
    taxaComissaoController.dispose();
    valorComissaoController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
    situacaoController.dispose();
    diaFixoParcelaController.dispose();
    observacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}