import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/repository/vendedor_meta_repository.dart';

class VendedorMetaController extends ControllerBase<VendedorMetaModel, VendedorMetaRepository> {

  VendedorMetaController({required super.repository}) {
    dbColumns = VendedorMetaModel.dbColumns;
    aliasColumns = VendedorMetaModel.aliasColumns;
    gridColumns = vendedorMetaGridColumns();
    functionName = "vendedor_meta";
    screenTitle = "Metas";
  }

  @override
  VendedorMetaModel createNewModel() => VendedorMetaModel();

  @override
  final standardFieldForFilter = VendedorMetaModel.aliasColumns[VendedorMetaModel.dbColumns.indexOf('periodo_meta')];

  final viewPessoaVendedorModelController = TextEditingController();
  final viewPessoaClienteModelController = TextEditingController();
  final periodoMetaController = CustomDropdownButtonController('Mensal');
  final metaOrcadaController = MoneyMaskedTextController();
  final metaRealizadaController = MoneyMaskedTextController();
  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['periodo_meta'],
    'secondaryColumns': ['meta_orcada'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendedorMeta) => vendedorMeta.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.vendedorMetaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaVendedorModelController.text = '';
    viewPessoaClienteModelController.text = '';
    periodoMetaController.selected = 'Mensal';
    metaOrcadaController.updateValue(0);
    metaRealizadaController.updateValue(0);
    dataInicioController.date = null;
    dataFimController.date = null;
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.vendedorMetaEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome?.toString() ?? '';
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    periodoMetaController.selected = currentModel.periodoMeta ?? 'Mensal';
    metaOrcadaController.updateValue(currentModel.metaOrcada ?? 0);
    metaRealizadaController.updateValue(currentModel.metaRealizada ?? 0);
    dataInicioController.date = currentModel.dataInicio;
    dataFimController.date = currentModel.dataFim;
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(vendedorMetaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaVendedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Vendedor]'; 
		lookupController.route = '/view-pessoa-vendedor/'; 
		lookupController.gridColumns = viewPessoaVendedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaVendedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaVendedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaVendedorModel.aliasColumns[ViewPessoaVendedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaVendedorModel = ViewPessoaVendedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaVendedorModelController.dispose();
    viewPessoaClienteModelController.dispose();
    periodoMetaController.dispose();
    metaOrcadaController.dispose();
    metaRealizadaController.dispose();
    dataInicioController.dispose();
    dataFimController.dispose();
    super.onClose();
  }

}