import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:afv/app/routes/app_routes.dart';

import 'package:afv/app/page/page_imports.dart';
import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';

class VendaOrcamentoDetalheController extends ControllerBase<VendaOrcamentoDetalheModel, void> {

  VendaOrcamentoDetalheController() : super(repository: null) {
    dbColumns = VendaOrcamentoDetalheModel.dbColumns;
    aliasColumns = VendaOrcamentoDetalheModel.aliasColumns;
    gridColumns = vendaOrcamentoDetalheGridColumns();
    functionName = "venda_orcamento_detalhe";
    screenTitle = "Itens do Orçamento";
  }

  final _vendaOrcamentoDetalheModel = VendaOrcamentoDetalheModel().obs;
  VendaOrcamentoDetalheModel get vendaOrcamentoDetalheModel => _vendaOrcamentoDetalheModel.value;
  set vendaOrcamentoDetalheModel(value) => _vendaOrcamentoDetalheModel.value = value ?? VendaOrcamentoDetalheModel();

  List<VendaOrcamentoDetalheModel> get vendaOrcamentoDetalheModelList => Get.find<VendaOrcamentoCabecalhoController>().currentModel.vendaOrcamentoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final vendaOrcamentoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaOrcamentoDetalheFormKey = GlobalKey<FormState>();

  @override
  VendaOrcamentoDetalheModel createNewModel() => VendaOrcamentoDetalheModel();

  @override
  final standardFieldForFilter = VendaOrcamentoDetalheModel.aliasColumns[VendaOrcamentoDetalheModel.dbColumns.indexOf('quantidade')];

  final produtoModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController();
  final valorUnitarioController = MoneyMaskedTextController();
  final valorSubtotalController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': ['valor_unitario'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaOrcamentoDetalhe) => vendaOrcamentoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(vendaOrcamentoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    vendaOrcamentoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => VendaOrcamentoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    quantidadeController.updateValue(0);
    valorUnitarioController.updateValue(0);
    valorSubtotalController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = vendaOrcamentoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    vendaOrcamentoDetalheModel = model.clone();
		vendaOrcamentoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => VendaOrcamentoDetalheEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = vendaOrcamentoDetalheModel.produtoModel?.nome?.toString() ?? '';
    quantidadeController.updateValue(vendaOrcamentoDetalheModel.quantidade ?? 0);
    valorUnitarioController.updateValue(vendaOrcamentoDetalheModel.valorUnitario ?? 0);
    valorSubtotalController.updateValue(vendaOrcamentoDetalheModel.valorSubtotal ?? 0);
    taxaDescontoController.updateValue(vendaOrcamentoDetalheModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(vendaOrcamentoDetalheModel.valorDesconto ?? 0);
    valorTotalController.updateValue(vendaOrcamentoDetalheModel.valorTotal ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!vendaOrcamentoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        vendaOrcamentoDetalheModelList.insert(0, vendaOrcamentoDetalheModel.clone());
      } else {
        final index = vendaOrcamentoDetalheModelList.indexWhere((m) => m.tempId == vendaOrcamentoDetalheModel.tempId);
        if (index >= 0) {
          vendaOrcamentoDetalheModelList[index] = vendaOrcamentoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendaOrcamentoDetalheModel.idProduto = plutoRowResult.cells['id']!.value; 
			vendaOrcamentoDetalheModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = vendaOrcamentoDetalheModel.produtoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      vendaOrcamentoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeController.dispose();
    valorUnitarioController.dispose();
    valorSubtotalController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
  }

}