import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:afv/app/page/shared_widget/input/input_imports.dart';

import 'package:afv/app/infra/infra_imports.dart';
import 'package:afv/app/page/page_imports.dart';
import 'package:afv/app/page/shared_widget/message_dialog.dart';
import 'package:afv/app/page/grid_columns/grid_columns_imports.dart';
import 'package:afv/app/routes/app_routes.dart';
import 'package:afv/app/controller/controller_imports.dart';
import 'package:afv/app/data/model/model_imports.dart';
import 'package:afv/app/data/repository/pessoa_repository.dart';

class PessoaController extends ControllerBase<PessoaModel, PessoaRepository> 
with GetSingleTickerProviderStateMixin {

  PessoaController({required super.repository}) {
    dbColumns = PessoaModel.dbColumns;
    aliasColumns = PessoaModel.aliasColumns;
    gridColumns = pessoaGridColumns();
    functionName = "pessoa";
    screenTitle = "Pessoa";
  }

  final pessoaScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  PessoaModel createNewModel() => PessoaModel();

  @override
  final standardFieldForFilter = PessoaModel.aliasColumns[PessoaModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final tipoController = CustomDropdownButtonController('Física');
  final siteController = TextEditingController();
  final emailController = TextEditingController();
  final ehClienteController = CustomDropdownButtonController('Sim');
  final ehFornecedorController = CustomDropdownButtonController('Sim');
  final ehTransportadoraController = CustomDropdownButtonController('Sim');
  final ehColaboradorController = CustomDropdownButtonController('Sim');
  final ehContadorController = CustomDropdownButtonController('Sim');
  final situacaoContribuinteController = CustomDropdownButtonController('1-Contribuinte ICMS');
  final ativoController = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['tipo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pessoa) => pessoa.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.pessoaTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    tipoController.selected = 'Física';
    siteController.text = '';
    emailController.text = '';
    ehClienteController.selected = 'Sim';
    ehFornecedorController.selected = 'Sim';
    ehTransportadoraController.selected = 'Sim';
    ehColaboradorController.selected = 'Sim';
    ehContadorController.selected = 'Sim';
    situacaoContribuinteController.selected = '1-Contribuinte ICMS';
    ativoController.selected = 'Sim';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.pessoaTabPage);
  }

  _configureChildrenControllers() {
    //Pessoa Jurídica
		Get.put<PessoaJuridicaController>(PessoaJuridicaController()); 

    //Cliente
		Get.put<ClienteController>(ClienteController()); 

    //Contatos
		Get.put<PessoaContatoController>(PessoaContatoController()); 

    //Telefones
		Get.put<PessoaTelefoneController>(PessoaTelefoneController()); 

    //Endereços
		Get.put<PessoaEnderecoController>(PessoaEnderecoController()); 

    //Financeiro
		Get.put<ViewFinLancamentoReceberController>(ViewFinLancamentoReceberController()); 

  }
	
	_releaseChildrenControllers() {
    //Pessoa Jurídica
		Get.delete<PessoaJuridicaController>(); 

    //Cliente
		Get.delete<ClienteController>(); 

    //Contatos
		Get.delete<PessoaContatoController>(); 

    //Telefones
		Get.delete<PessoaTelefoneController>(); 

    //Endereços
		Get.delete<PessoaEnderecoController>(); 

    //Financeiro
		Get.delete<ViewFinLancamentoReceberController>(); 

	}
  
  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    tipoController.selected = currentModel.tipo ?? 'Física';
    siteController.text = currentModel.site ?? '';
    emailController.text = currentModel.email ?? '';
    ehClienteController.selected = currentModel.ehCliente ?? 'Sim';
    ehFornecedorController.selected = currentModel.ehFornecedor ?? 'Sim';
    ehTransportadoraController.selected = currentModel.ehTransportadora ?? 'Sim';
    ehColaboradorController.selected = currentModel.ehColaborador ?? 'Sim';
    ehContadorController.selected = currentModel.ehContador ?? 'Sim';
    situacaoContribuinteController.selected = currentModel.situacaoContribuinte ?? '1-Contribuinte ICMS';
    ativoController.selected = currentModel.ativo ?? 'Sim';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Pessoa Jurídica
		final pessoaJuridicaController = Get.find<PessoaJuridicaController>(); 
		pessoaJuridicaController.updateControllersFromModel(); 

    //Cliente
		final clienteController = Get.find<ClienteController>(); 
		clienteController.updateControllersFromModel(); 

    //Contatos
		final pessoaContatoController = Get.find<PessoaContatoController>(); 
		pessoaContatoController.userMadeChanges = false; 

    //Telefones
		final pessoaTelefoneController = Get.find<PessoaTelefoneController>(); 
		pessoaTelefoneController.userMadeChanges = false; 

    //Endereços
		final pessoaEnderecoController = Get.find<PessoaEnderecoController>(); 
		pessoaEnderecoController.userMadeChanges = false; 

    //Financeiro
		final viewFinLancamentoReceberController = Get.find<ViewFinLancamentoReceberController>(); 
		viewFinLancamentoReceberController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(pessoaModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pessoa', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pessoa Jurídica', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Cliente', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Contatos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Telefones', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Endereços', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Financeiro', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PessoaEditPage(),
      PessoaJuridicaEditPage(),
      ClienteEditPage(),
      const PessoaContatoListPage(),
      const PessoaTelefoneListPage(),
      const PessoaEnderecoListPage(),
      const ViewFinLancamentoReceberListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PessoaJuridicaController>().formWasChangedDetail
    || 
		Get.find<ClienteController>().formWasChangedDetail
    || 
		Get.find<PessoaContatoController>().userMadeChanges
    || 
		Get.find<PessoaTelefoneController>().userMadeChanges
    || 
		Get.find<PessoaEnderecoController>().userMadeChanges
    || 
		Get.find<ViewFinLancamentoReceberController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    final emailValidationMessage = ValidateFormField.validateEmail(currentModel.email); 
		if (emailValidationMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: emailValidationMessage); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    final resultPessoaJuridica = Get.find<PessoaJuridicaController>().validateForm(); 
		if (!resultPessoaJuridica) { 
			tabController.animateTo(1); 
			return false; 
		}
    final resultCliente = Get.find<ClienteController>().validateForm(); 
		if (!resultCliente) { 
			tabController.animateTo(2); 
			return false; 
		}
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    tipoController.dispose();
    siteController.dispose();
    emailController.dispose();
    ehClienteController.dispose();
    ehFornecedorController.dispose();
    ehTransportadoraController.dispose();
    ehColaboradorController.dispose();
    ehContadorController.dispose();
    situacaoContribuinteController.dispose();
    ativoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}