import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:tributacao/app/data/domain/domain_imports.dart';
import 'package:tributacao/app/controller/tribut_cofins_controller.dart';
import 'package:tributacao/app/infra/infra_imports.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';

class TributCofinsEditPage extends StatelessWidget {
  TributCofinsEditPage({Key? key}) : super(key: key);
  final tributCofinsController = Get.find<TributCofinsController>();

  @override
  Widget build(BuildContext context) {
      return Scaffold(
        key: tributCofinsController.tributCofinsScaffoldKey,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Form(
            key: tributCofinsController.tributCofinsFormKey,
            autovalidateMode: AutovalidateMode.always,
            child: Scrollbar(
              controller: tributCofinsController.scrollController,
              child: SingleChildScrollView(
                controller: tributCofinsController.scrollController,
                child: BootstrapContainer(
                  fluid: true,
                  padding: const EdgeInsets.all(10.0),
                  children: <Widget>[
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: tributCofinsController.cstCofinsController,
															labelText: 'CST',
															hintText: 'Informe os dados para o campo Cst Cofins',
															items: TributCofinsDomain.cstCofinsListDropdown,
															onChanged: (dynamic newValue) {
																tributCofinsController.tributCofinsModel.cstCofins = newValue;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: tributCofinsController.modalidadeBaseCalculoController,
															labelText: 'Modalidade Base Cálculo',
															hintText: 'Informe os dados para o campo Modalidade Base Calculo',
															items: TributCofinsDomain.modalidadeBaseCalculoListDropdown,
															onChanged: (dynamic newValue) {
																tributCofinsController.tributCofinsModel.modalidadeBaseCalculo = newValue;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: tributCofinsController.efdTabela435Controller,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Efd Tabela 435',
																labelText: 'Código Apuração EFD',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributCofinsController.tributCofinsModel.efdTabela435 = text;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributCofinsController.porcentoBaseCalculoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Porcento Base Calculo',
																labelText: 'Porcento Base Cálculo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributCofinsController.tributCofinsModel.porcentoBaseCalculo = tributCofinsController.porcentoBaseCalculoController.numberValue;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributCofinsController.aliquotaPorcentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Porcento',
																labelText: 'Alíquota Porcento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributCofinsController.tributCofinsModel.aliquotaPorcento = tributCofinsController.aliquotaPorcentoController.numberValue;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributCofinsController.aliquotaUnidadeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Unidade',
																labelText: 'Alíquota Unidade',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributCofinsController.tributCofinsModel.aliquotaUnidade = tributCofinsController.aliquotaUnidadeController.numberValue;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributCofinsController.valorPrecoMaximoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Preco Maximo',
																labelText: 'Valor Preco Maximo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributCofinsController.tributCofinsModel.valorPrecoMaximo = tributCofinsController.valorPrecoMaximoController.numberValue;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributCofinsController.valorPautaFiscalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Pauta Fiscal',
																labelText: 'Valor Pauta Fiscal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributCofinsController.tributCofinsModel.valorPautaFiscal = tributCofinsController.valorPautaFiscalController.numberValue;
																tributCofinsController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
                      indent: 10,
                      endIndent: 10,
                      thickness: 2,
                    ),
                    BootstrapRow(
                      height: 60,
                      children: <BootstrapCol>[
                        BootstrapCol(
                          sizes: 'col-12',
                          child: Text(
                            'field_is_mandatory'.tr,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
  }
}
