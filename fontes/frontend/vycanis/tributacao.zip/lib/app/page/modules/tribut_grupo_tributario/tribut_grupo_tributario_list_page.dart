import 'package:flutter/material.dart';
import 'package:tributacao/app/controller/tribut_grupo_tributario_controller.dart';
import 'package:tributacao/app/page/shared_page/list_page_base.dart';

class TributGrupoTributarioListPage extends ListPageBase<TributGrupoTributarioController> {
  const TributGrupoTributarioListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}