import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:tributacao/app/data/domain/domain_imports.dart';
import 'package:tributacao/app/controller/tribut_pis_controller.dart';
import 'package:tributacao/app/infra/infra_imports.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';

class TributPisEditPage extends StatelessWidget {
  TributPisEditPage({Key? key}) : super(key: key);
  final tributPisController = Get.find<TributPisController>();

  @override
  Widget build(BuildContext context) {
      return Scaffold(
        key: tributPisController.tributPisScaffoldKey,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Form(
            key: tributPisController.tributPisFormKey,
            autovalidateMode: AutovalidateMode.always,
            child: Scrollbar(
              controller: tributPisController.scrollController,
              child: SingleChildScrollView(
                controller: tributPisController.scrollController,
                child: BootstrapContainer(
                  fluid: true,
                  padding: const EdgeInsets.all(10.0),
                  children: <Widget>[
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: tributPisController.cstPisController,
															labelText: 'CST',
															hintText: 'Informe os dados para o campo Cst Pis',
															items: TributPisDomain.cstPisListDropdown,
															onChanged: (dynamic newValue) {
																tributPisController.tributPisModel.cstPis = newValue;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: tributPisController.modalidadeBaseCalculoController,
															labelText: 'Modalidade Base Cálculo',
															hintText: 'Informe os dados para o campo Modalidade Base Calculo',
															items: TributPisDomain.modalidadeBaseCalculoListDropdown,
															onChanged: (dynamic newValue) {
																tributPisController.tributPisModel.modalidadeBaseCalculo = newValue;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: tributPisController.efdTabela435Controller,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Efd Tabela 435',
																labelText: 'Código Apuração EFD',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributPisController.tributPisModel.efdTabela435 = text;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributPisController.porcentoBaseCalculoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Porcento Base Calculo',
																labelText: 'Porcento Base Cálculo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributPisController.tributPisModel.porcentoBaseCalculo = tributPisController.porcentoBaseCalculoController.numberValue;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributPisController.aliquotaPorcentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Porcento',
																labelText: 'Alíquota Porcento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributPisController.tributPisModel.aliquotaPorcento = tributPisController.aliquotaPorcentoController.numberValue;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributPisController.aliquotaUnidadeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Unidade',
																labelText: 'Alíquota Unidade',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributPisController.tributPisModel.aliquotaUnidade = tributPisController.aliquotaUnidadeController.numberValue;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributPisController.valorPrecoMaximoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Preco Maximo',
																labelText: 'Valor Preço Máximo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributPisController.tributPisModel.valorPrecoMaximo = tributPisController.valorPrecoMaximoController.numberValue;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    		BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: tributPisController.valorPautaFiscalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Pauta Fiscal',
																labelText: 'Valor Pauta Fiscal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																tributPisController.tributPisModel.valorPautaFiscal = tributPisController.valorPautaFiscalController.numberValue;
																tributPisController.formWasChangedDetail = true;
															},
														),
													),
												),
                    	],
										),
                    const Divider(
                      indent: 10,
                      endIndent: 10,
                      thickness: 2,
                    ),
                    BootstrapRow(
                      height: 60,
                      children: <BootstrapCol>[
                        BootstrapCol(
                          sizes: 'col-12',
                          child: Text(
                            'field_is_mandatory'.tr,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10.0),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
  }
}
