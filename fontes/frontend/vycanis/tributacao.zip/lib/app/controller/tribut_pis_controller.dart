import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributPisController extends ControllerBase<TributPisModel, void> {

  TributPisController() : super(repository: null) {
    dbColumns = TributPisModel.dbColumns;
    aliasColumns = TributPisModel.aliasColumns;
    functionName = "tribut_pis";
    screenTitle = "PIS";
  }

	String? mandatoryMessage;

  final _tributPisModel = TributPisModel().obs;
  TributPisModel get tributPisModel => Get.find<TributConfiguraOfGtController>().currentModel.tributPisModel ?? TributPisModel();
  set tributPisModel(value) => _tributPisModel.value = value ?? TributPisModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final tributPisScaffoldKey = GlobalKey<ScaffoldState>();
  final tributPisFormKey = GlobalKey<FormState>();

  @override
  TributPisModel createNewModel() => TributPisModel();

  @override
  final standardFieldForFilter = "";

  final cstPisController = CustomDropdownButtonController('00');
  final modalidadeBaseCalculoController = CustomDropdownButtonController('0-Percentual');
  final efdTabela435Controller = TextEditingController();
  final porcentoBaseCalculoController = MoneyMaskedTextController();
  final aliquotaPorcentoController = MoneyMaskedTextController();
  final aliquotaUnidadeController = MoneyMaskedTextController();
  final valorPrecoMaximoController = MoneyMaskedTextController();
  final valorPautaFiscalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributPis) => tributPis.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    cstPisController.selected = '00';
    modalidadeBaseCalculoController.selected = '0-Percentual';
    efdTabela435Controller.text = '';
    porcentoBaseCalculoController.updateValue(0);
    aliquotaPorcentoController.updateValue(0);
    aliquotaUnidadeController.updateValue(0);
    valorPrecoMaximoController.updateValue(0);
    valorPautaFiscalController.updateValue(0);
  }

  void updateControllersFromModel() {
		_resetForm();
    cstPisController.selected = tributPisModel.cstPis ?? '00';
    modalidadeBaseCalculoController.selected = tributPisModel.modalidadeBaseCalculo ?? '0-Percentual';
    efdTabela435Controller.text = tributPisModel.efdTabela435 ?? '';
    porcentoBaseCalculoController.updateValue(tributPisModel.porcentoBaseCalculo ?? 0);
    aliquotaPorcentoController.updateValue(tributPisModel.aliquotaPorcento ?? 0);
    aliquotaUnidadeController.updateValue(tributPisModel.aliquotaUnidade ?? 0);
    valorPrecoMaximoController.updateValue(tributPisModel.valorPrecoMaximo ?? 0);
    valorPautaFiscalController.updateValue(tributPisModel.valorPautaFiscal ?? 0);
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    return true;
	}


  @override
  void onClose() {
    cstPisController.dispose();
    modalidadeBaseCalculoController.dispose();
    efdTabela435Controller.dispose();
    porcentoBaseCalculoController.dispose();
    aliquotaPorcentoController.dispose();
    aliquotaUnidadeController.dispose();
    valorPrecoMaximoController.dispose();
    valorPautaFiscalController.dispose();
  }

}