import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:tributacao/app/infra/infra_imports.dart';
import 'package:tributacao/app/page/page_imports.dart';
import 'package:tributacao/app/page/shared_widget/message_dialog.dart';
import 'package:tributacao/app/page/grid_columns/grid_columns_imports.dart';
import 'package:tributacao/app/routes/app_routes.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';
import 'package:tributacao/app/data/repository/tribut_configura_of_gt_repository.dart';

class TributConfiguraOfGtController extends ControllerBase<TributConfiguraOfGtModel, TributConfiguraOfGtRepository> 
with GetSingleTickerProviderStateMixin {

  TributConfiguraOfGtController({required super.repository}) {
    dbColumns = TributConfiguraOfGtModel.dbColumns;
    aliasColumns = TributConfiguraOfGtModel.aliasColumns;
    gridColumns = tributConfiguraOfGtGridColumns();
    functionName = "tribut_configura_of_gt";
    screenTitle = "Configura Tributação";
  }

  final tributConfiguraOfGtScaffoldKey = GlobalKey<ScaffoldState>();
  final tributConfiguraOfGtTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final tributConfiguraOfGtFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  TributConfiguraOfGtModel createNewModel() => TributConfiguraOfGtModel();

  @override
  final standardFieldForFilter = TributConfiguraOfGtModel.aliasColumns[TributConfiguraOfGtModel.dbColumns.indexOf('id')];

  final tributGrupoTributarioModelController = TextEditingController();
  final tributOperacaoFiscalModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': [],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributConfiguraOfGt) => tributConfiguraOfGt.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.tributConfiguraOfGtTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    tributGrupoTributarioModelController.text = '';
    tributOperacaoFiscalModelController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.tributConfiguraOfGtTabPage);
  }

  _configureChildrenControllers() {
    //IPI
		Get.put<TributIpiController>(TributIpiController()); 

    //COFINS
		Get.put<TributCofinsController>(TributCofinsController()); 

    //PIS
		Get.put<TributPisController>(TributPisController()); 

    //ICMS
		Get.put<TributIcmsUfController>(TributIcmsUfController()); 

  }
	
	_releaseChildrenControllers() {
    //IPI
		Get.delete<TributIpiController>(); 

    //COFINS
		Get.delete<TributCofinsController>(); 

    //PIS
		Get.delete<TributPisController>(); 

    //ICMS
		Get.delete<TributIcmsUfController>(); 

	}
  
  void updateControllersFromModel() {
    tributGrupoTributarioModelController.text = currentModel.tributGrupoTributarioModel?.descricao?.toString() ?? '';
    tributOperacaoFiscalModelController.text = currentModel.tributOperacaoFiscalModel?.descricao?.toString() ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //IPI
		final tributIpiController = Get.find<TributIpiController>(); 
		tributIpiController.updateControllersFromModel(); 

    //COFINS
		final tributCofinsController = Get.find<TributCofinsController>(); 
		tributCofinsController.updateControllersFromModel(); 

    //PIS
		final tributPisController = Get.find<TributPisController>(); 
		tributPisController.updateControllersFromModel(); 

    //ICMS
		final tributIcmsUfController = Get.find<TributIcmsUfController>(); 
		tributIcmsUfController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(tributConfiguraOfGtModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callTributGrupoTributarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Grupo Tributário]'; 
		lookupController.route = '/tribut-grupo-tributario/'; 
		lookupController.gridColumns = tributGrupoTributarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TributGrupoTributarioModel.aliasColumns; 
		lookupController.dbColumns = TributGrupoTributarioModel.dbColumns; 
		lookupController.standardColumn = TributGrupoTributarioModel.aliasColumns[TributGrupoTributarioModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTributGrupoTributario = plutoRowResult.cells['id']!.value; 
			currentModel.tributGrupoTributarioModel = TributGrupoTributarioModel.fromPlutoRow(plutoRowResult); 
			tributGrupoTributarioModelController.text = currentModel.tributGrupoTributarioModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callTributOperacaoFiscalLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Operação Fiscal]'; 
		lookupController.route = '/tribut-operacao-fiscal/'; 
		lookupController.gridColumns = tributOperacaoFiscalGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TributOperacaoFiscalModel.aliasColumns; 
		lookupController.dbColumns = TributOperacaoFiscalModel.dbColumns; 
		lookupController.standardColumn = TributOperacaoFiscalModel.aliasColumns[TributOperacaoFiscalModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTributOperacaoFiscal = plutoRowResult.cells['id']!.value; 
			currentModel.tributOperacaoFiscalModel = TributOperacaoFiscalModel.fromPlutoRow(plutoRowResult); 
			tributOperacaoFiscalModelController.text = currentModel.tributOperacaoFiscalModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Configura Tributação', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'IPI', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'COFINS', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'PIS', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'ICMS', 
		),
  ];

  List<Widget> tabPages() {
    return [
      TributConfiguraOfGtEditPage(),
      TributIpiEditPage(),
      TributCofinsEditPage(),
      TributPisEditPage(),
      const TributIcmsUfListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<TributIpiController>().formWasChangedDetail
    || 
		Get.find<TributCofinsController>().formWasChangedDetail
    || 
		Get.find<TributPisController>().formWasChangedDetail
    || 
		Get.find<TributIcmsUfController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.tributGrupoTributarioModel?.descricao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Grupo Tributário]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.tributOperacaoFiscalModel?.descricao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Operação Fiscal]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    final resultTributIpi = Get.find<TributIpiController>().validateForm(); 
		if (!resultTributIpi) { 
			tabController.animateTo(1); 
			return false; 
		}
    final resultTributCofins = Get.find<TributCofinsController>().validateForm(); 
		if (!resultTributCofins) { 
			tabController.animateTo(2); 
			return false; 
		}
    final resultTributPis = Get.find<TributPisController>().validateForm(); 
		if (!resultTributPis) { 
			tabController.animateTo(3); 
			return false; 
		}
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    tributGrupoTributarioModelController.dispose();
    tributOperacaoFiscalModelController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}