import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';

import 'package:tributacao/app/page/page_imports.dart';
import 'package:tributacao/app/page/shared_widget/message_dialog.dart';
import 'package:tributacao/app/page/grid_columns/grid_columns_imports.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributIcmsUfController extends ControllerBase<TributIcmsUfModel, void> {

  TributIcmsUfController() : super(repository: null) {
    dbColumns = TributIcmsUfModel.dbColumns;
    aliasColumns = TributIcmsUfModel.aliasColumns;
    gridColumns = tributIcmsUfGridColumns();
    functionName = "tribut_icms_uf";
    screenTitle = "ICMS";
  }

  final _tributIcmsUfModel = TributIcmsUfModel().obs;
  TributIcmsUfModel get tributIcmsUfModel => _tributIcmsUfModel.value;
  set tributIcmsUfModel(value) => _tributIcmsUfModel.value = value ?? TributIcmsUfModel();

  List<TributIcmsUfModel> get tributIcmsUfModelList => Get.find<TributConfiguraOfGtController>().currentModel.tributIcmsUfModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final tributIcmsUfScaffoldKey = GlobalKey<ScaffoldState>();
  final tributIcmsUfFormKey = GlobalKey<FormState>();

  @override
  TributIcmsUfModel createNewModel() => TributIcmsUfModel();

  @override
  final standardFieldForFilter = TributIcmsUfModel.aliasColumns[TributIcmsUfModel.dbColumns.indexOf('uf_destino')];

  final ufDestinoController = CustomDropdownButtonController('AC');
  final cstController = CustomDropdownButtonController('00');
  final csosnController = CustomDropdownButtonController('101');
  final modalidadeBcController = CustomDropdownButtonController('0-Margem Valor Agregado');
  final cfopController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final aliquotaController = MoneyMaskedTextController();
  final valorPautaController = MoneyMaskedTextController();
  final valorPrecoMaximoController = MoneyMaskedTextController();
  final mvaController = MoneyMaskedTextController();
  final porcentoBcController = MoneyMaskedTextController();
  final modalidadeBcStController = CustomDropdownButtonController('0-Valor Preço Máximo');
  final aliquotaInternaStController = MoneyMaskedTextController();
  final aliquotaInterestadualStController = MoneyMaskedTextController();
  final porcentoBcStController = MoneyMaskedTextController();
  final aliquotaIcmsStController = MoneyMaskedTextController();
  final valorPautaStController = MoneyMaskedTextController();
  final valorPrecoMaximoStController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['uf_destino'],
    'secondaryColumns': ['cst'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributIcmsUf) => tributIcmsUf.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(tributIcmsUfModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    tributIcmsUfModel = createNewModel();
    _resetForm();
    Get.to(() => TributIcmsUfEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    ufDestinoController.selected = 'AC';
    cstController.selected = '00';
    csosnController.selected = '101';
    modalidadeBcController.selected = '0-Margem Valor Agregado';
    cfopController.updateValue(0);
    aliquotaController.updateValue(0);
    valorPautaController.updateValue(0);
    valorPrecoMaximoController.updateValue(0);
    mvaController.updateValue(0);
    porcentoBcController.updateValue(0);
    modalidadeBcStController.selected = '0-Valor Preço Máximo';
    aliquotaInternaStController.updateValue(0);
    aliquotaInterestadualStController.updateValue(0);
    porcentoBcStController.updateValue(0);
    aliquotaIcmsStController.updateValue(0);
    valorPautaStController.updateValue(0);
    valorPrecoMaximoStController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = tributIcmsUfModelList.firstWhere((m) => m.tempId == tempId);
    tributIcmsUfModel = model.clone();
		tributIcmsUfModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => TributIcmsUfEditPage());
  }

  void updateControllersFromModel() {
    ufDestinoController.selected = tributIcmsUfModel.ufDestino ?? 'AC';
    cstController.selected = tributIcmsUfModel.cst ?? '00';
    csosnController.selected = tributIcmsUfModel.csosn ?? '101';
    modalidadeBcController.selected = tributIcmsUfModel.modalidadeBc ?? '0-Margem Valor Agregado';
    cfopController.updateValue((tributIcmsUfModel.cfop ?? 0).toDouble());
    aliquotaController.updateValue(tributIcmsUfModel.aliquota ?? 0);
    valorPautaController.updateValue(tributIcmsUfModel.valorPauta ?? 0);
    valorPrecoMaximoController.updateValue(tributIcmsUfModel.valorPrecoMaximo ?? 0);
    mvaController.updateValue(tributIcmsUfModel.mva ?? 0);
    porcentoBcController.updateValue(tributIcmsUfModel.porcentoBc ?? 0);
    modalidadeBcStController.selected = tributIcmsUfModel.modalidadeBcSt ?? '0-Valor Preço Máximo';
    aliquotaInternaStController.updateValue(tributIcmsUfModel.aliquotaInternaSt ?? 0);
    aliquotaInterestadualStController.updateValue(tributIcmsUfModel.aliquotaInterestadualSt ?? 0);
    porcentoBcStController.updateValue(tributIcmsUfModel.porcentoBcSt ?? 0);
    aliquotaIcmsStController.updateValue(tributIcmsUfModel.aliquotaIcmsSt ?? 0);
    valorPautaStController.updateValue(tributIcmsUfModel.valorPautaSt ?? 0);
    valorPrecoMaximoStController.updateValue(tributIcmsUfModel.valorPrecoMaximoSt ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!tributIcmsUfFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        tributIcmsUfModelList.insert(0, tributIcmsUfModel.clone());
      } else {
        final index = tributIcmsUfModelList.indexWhere((m) => m.tempId == tributIcmsUfModel.tempId);
        if (index >= 0) {
          tributIcmsUfModelList[index] = tributIcmsUfModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      tributIcmsUfModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    ufDestinoController.dispose();
    cstController.dispose();
    csosnController.dispose();
    modalidadeBcController.dispose();
    cfopController.dispose();
    aliquotaController.dispose();
    valorPautaController.dispose();
    valorPrecoMaximoController.dispose();
    mvaController.dispose();
    porcentoBcController.dispose();
    modalidadeBcStController.dispose();
    aliquotaInternaStController.dispose();
    aliquotaInterestadualStController.dispose();
    porcentoBcStController.dispose();
    aliquotaIcmsStController.dispose();
    valorPautaStController.dispose();
    valorPrecoMaximoStController.dispose();
  }

}