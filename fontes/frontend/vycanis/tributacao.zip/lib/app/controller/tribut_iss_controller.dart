import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';

import 'package:tributacao/app/page/shared_widget/message_dialog.dart';
import 'package:tributacao/app/page/grid_columns/grid_columns_imports.dart';
import 'package:tributacao/app/routes/app_routes.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';
import 'package:tributacao/app/data/repository/tribut_iss_repository.dart';

class TributIssController extends ControllerBase<TributIssModel, TributIssRepository> {

  TributIssController({required super.repository}) {
    dbColumns = TributIssModel.dbColumns;
    aliasColumns = TributIssModel.aliasColumns;
    gridColumns = tributIssGridColumns();
    functionName = "tribut_iss";
    screenTitle = "ISS";
  }

  @override
  TributIssModel createNewModel() => TributIssModel();

  @override
  final standardFieldForFilter = TributIssModel.aliasColumns[TributIssModel.dbColumns.indexOf('modalidade_base_calculo')];

  final tributOperacaoFiscalModelController = TextEditingController();
  final modalidadeBaseCalculoController = CustomDropdownButtonController('0-Valor Operação');
  final codigoTributacaoController = CustomDropdownButtonController('Normal');
  final itemListaServicoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final porcentoBaseCalculoController = MoneyMaskedTextController();
  final aliquotaPorcentoController = MoneyMaskedTextController();
  final aliquotaUnidadeController = MoneyMaskedTextController();
  final valorPrecoMaximoController = MoneyMaskedTextController();
  final valorPautaFiscalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['modalidade_base_calculo'],
    'secondaryColumns': ['codigo_tributacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributIss) => tributIss.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.tributIssEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    tributOperacaoFiscalModelController.text = '';
    modalidadeBaseCalculoController.selected = '0-Valor Operação';
    codigoTributacaoController.selected = 'Normal';
    itemListaServicoController.updateValue(0);
    porcentoBaseCalculoController.updateValue(0);
    aliquotaPorcentoController.updateValue(0);
    aliquotaUnidadeController.updateValue(0);
    valorPrecoMaximoController.updateValue(0);
    valorPautaFiscalController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.tributIssEditPage);
  }

  void updateControllersFromModel() {
    tributOperacaoFiscalModelController.text = currentModel.tributOperacaoFiscalModel?.descricao?.toString() ?? '';
    modalidadeBaseCalculoController.selected = currentModel.modalidadeBaseCalculo ?? '0-Valor Operação';
    codigoTributacaoController.selected = currentModel.codigoTributacao ?? 'Normal';
    itemListaServicoController.updateValue((currentModel.itemListaServico ?? 0).toDouble());
    porcentoBaseCalculoController.updateValue(currentModel.porcentoBaseCalculo ?? 0);
    aliquotaPorcentoController.updateValue(currentModel.aliquotaPorcento ?? 0);
    aliquotaUnidadeController.updateValue(currentModel.aliquotaUnidade ?? 0);
    valorPrecoMaximoController.updateValue(currentModel.valorPrecoMaximo ?? 0);
    valorPautaFiscalController.updateValue(currentModel.valorPautaFiscal ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(tributIssModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callTributOperacaoFiscalLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Operação Fiscal]'; 
		lookupController.route = '/tribut-operacao-fiscal/'; 
		lookupController.gridColumns = tributOperacaoFiscalGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TributOperacaoFiscalModel.aliasColumns; 
		lookupController.dbColumns = TributOperacaoFiscalModel.dbColumns; 
		lookupController.standardColumn = TributOperacaoFiscalModel.aliasColumns[TributOperacaoFiscalModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTributOperacaoFiscal = plutoRowResult.cells['id']!.value; 
			currentModel.tributOperacaoFiscalModel = TributOperacaoFiscalModel.fromPlutoRow(plutoRowResult); 
			tributOperacaoFiscalModelController.text = currentModel.tributOperacaoFiscalModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    tributOperacaoFiscalModelController.dispose();
    modalidadeBaseCalculoController.dispose();
    codigoTributacaoController.dispose();
    itemListaServicoController.dispose();
    porcentoBaseCalculoController.dispose();
    aliquotaPorcentoController.dispose();
    aliquotaUnidadeController.dispose();
    valorPrecoMaximoController.dispose();
    valorPautaFiscalController.dispose();
    super.onClose();
  }

}