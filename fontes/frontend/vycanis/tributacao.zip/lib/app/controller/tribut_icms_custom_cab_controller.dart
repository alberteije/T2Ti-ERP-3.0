import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';

import 'package:tributacao/app/infra/infra_imports.dart';
import 'package:tributacao/app/page/page_imports.dart';
import 'package:tributacao/app/page/shared_widget/message_dialog.dart';
import 'package:tributacao/app/page/grid_columns/grid_columns_imports.dart';
import 'package:tributacao/app/routes/app_routes.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';
import 'package:tributacao/app/data/repository/tribut_icms_custom_cab_repository.dart';

class TributIcmsCustomCabController extends ControllerBase<TributIcmsCustomCabModel, TributIcmsCustomCabRepository> 
with GetSingleTickerProviderStateMixin {

  TributIcmsCustomCabController({required super.repository}) {
    dbColumns = TributIcmsCustomCabModel.dbColumns;
    aliasColumns = TributIcmsCustomCabModel.aliasColumns;
    gridColumns = tributIcmsCustomCabGridColumns();
    functionName = "tribut_icms_custom_cab";
    screenTitle = "ICMS Customizado";
  }

  final tributIcmsCustomCabScaffoldKey = GlobalKey<ScaffoldState>();
  final tributIcmsCustomCabTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final tributIcmsCustomCabFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  TributIcmsCustomCabModel createNewModel() => TributIcmsCustomCabModel();

  @override
  final standardFieldForFilter = TributIcmsCustomCabModel.aliasColumns[TributIcmsCustomCabModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();
  final origemMercadoriaController = CustomDropdownButtonController('0=Nacional');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['origem_mercadoria'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributIcmsCustomCab) => tributIcmsCustomCab.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.tributIcmsCustomCabTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
    origemMercadoriaController.selected = '0=Nacional';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.tributIcmsCustomCabTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<TributIcmsCustomDetController>(TributIcmsCustomDetController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<TributIcmsCustomDetController>(); 

	}
  
  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';
    origemMercadoriaController.selected = currentModel.origemMercadoria ?? '0=Nacional';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final tributIcmsCustomDetController = Get.find<TributIcmsCustomDetController>(); 
		tributIcmsCustomDetController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(tributIcmsCustomCabModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'ICMS Customizado', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      TributIcmsCustomCabEditPage(),
      const TributIcmsCustomDetListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<TributIcmsCustomDetController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    descricaoController.dispose();
    origemMercadoriaController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}