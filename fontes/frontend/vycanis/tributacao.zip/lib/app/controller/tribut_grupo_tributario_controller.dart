import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';

import 'package:tributacao/app/page/shared_widget/message_dialog.dart';
import 'package:tributacao/app/page/grid_columns/grid_columns_imports.dart';
import 'package:tributacao/app/routes/app_routes.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';
import 'package:tributacao/app/data/repository/tribut_grupo_tributario_repository.dart';

class TributGrupoTributarioController extends ControllerBase<TributGrupoTributarioModel, TributGrupoTributarioRepository> {

  TributGrupoTributarioController({required super.repository}) {
    dbColumns = TributGrupoTributarioModel.dbColumns;
    aliasColumns = TributGrupoTributarioModel.aliasColumns;
    gridColumns = tributGrupoTributarioGridColumns();
    functionName = "tribut_grupo_tributario";
    screenTitle = "Grupo Tributário";
  }

  @override
  TributGrupoTributarioModel createNewModel() => TributGrupoTributarioModel();

  @override
  final standardFieldForFilter = TributGrupoTributarioModel.aliasColumns[TributGrupoTributarioModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();
  final origemMercadoriaController = CustomDropdownButtonController('0=Nacional');
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['origem_mercadoria'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributGrupoTributario) => tributGrupoTributario.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.tributGrupoTributarioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
    origemMercadoriaController.selected = '0=Nacional';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.tributGrupoTributarioEditPage);
  }

  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';
    origemMercadoriaController.selected = currentModel.origemMercadoria ?? '0=Nacional';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(tributGrupoTributarioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    descricaoController.dispose();
    origemMercadoriaController.dispose();
    observacaoController.dispose();
    super.onClose();
  }

}