import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributCofinsController extends ControllerBase<TributCofinsModel, void> {

  TributCofinsController() : super(repository: null) {
    dbColumns = TributCofinsModel.dbColumns;
    aliasColumns = TributCofinsModel.aliasColumns;
    functionName = "tribut_cofins";
    screenTitle = "COFINS";
  }

	String? mandatoryMessage;

  final _tributCofinsModel = TributCofinsModel().obs;
  TributCofinsModel get tributCofinsModel => Get.find<TributConfiguraOfGtController>().currentModel.tributCofinsModel ?? TributCofinsModel();
  set tributCofinsModel(value) => _tributCofinsModel.value = value ?? TributCofinsModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final tributCofinsScaffoldKey = GlobalKey<ScaffoldState>();
  final tributCofinsFormKey = GlobalKey<FormState>();

  @override
  TributCofinsModel createNewModel() => TributCofinsModel();

  @override
  final standardFieldForFilter = "";

  final cstCofinsController = CustomDropdownButtonController('00');
  final modalidadeBaseCalculoController = CustomDropdownButtonController('0-Percentual');
  final efdTabela435Controller = TextEditingController();
  final porcentoBaseCalculoController = MoneyMaskedTextController();
  final aliquotaPorcentoController = MoneyMaskedTextController();
  final aliquotaUnidadeController = MoneyMaskedTextController();
  final valorPrecoMaximoController = MoneyMaskedTextController();
  final valorPautaFiscalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributCofins) => tributCofins.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    cstCofinsController.selected = '00';
    modalidadeBaseCalculoController.selected = '0-Percentual';
    efdTabela435Controller.text = '';
    porcentoBaseCalculoController.updateValue(0);
    aliquotaPorcentoController.updateValue(0);
    aliquotaUnidadeController.updateValue(0);
    valorPrecoMaximoController.updateValue(0);
    valorPautaFiscalController.updateValue(0);
  }

  void updateControllersFromModel() {
		_resetForm();
    cstCofinsController.selected = tributCofinsModel.cstCofins ?? '00';
    modalidadeBaseCalculoController.selected = tributCofinsModel.modalidadeBaseCalculo ?? '0-Percentual';
    efdTabela435Controller.text = tributCofinsModel.efdTabela435 ?? '';
    porcentoBaseCalculoController.updateValue(tributCofinsModel.porcentoBaseCalculo ?? 0);
    aliquotaPorcentoController.updateValue(tributCofinsModel.aliquotaPorcento ?? 0);
    aliquotaUnidadeController.updateValue(tributCofinsModel.aliquotaUnidade ?? 0);
    valorPrecoMaximoController.updateValue(tributCofinsModel.valorPrecoMaximo ?? 0);
    valorPautaFiscalController.updateValue(tributCofinsModel.valorPautaFiscal ?? 0);
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    return true;
	}


  @override
  void onClose() {
    cstCofinsController.dispose();
    modalidadeBaseCalculoController.dispose();
    efdTabela435Controller.dispose();
    porcentoBaseCalculoController.dispose();
    aliquotaPorcentoController.dispose();
    aliquotaUnidadeController.dispose();
    valorPrecoMaximoController.dispose();
    valorPautaFiscalController.dispose();
  }

}