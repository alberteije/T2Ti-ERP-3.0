import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:tributacao/app/page/shared_widget/message_dialog.dart';
import 'package:tributacao/app/page/grid_columns/grid_columns_imports.dart';
import 'package:tributacao/app/routes/app_routes.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';
import 'package:tributacao/app/data/repository/tribut_operacao_fiscal_repository.dart';

class TributOperacaoFiscalController extends ControllerBase<TributOperacaoFiscalModel, TributOperacaoFiscalRepository> {

  TributOperacaoFiscalController({required super.repository}) {
    dbColumns = TributOperacaoFiscalModel.dbColumns;
    aliasColumns = TributOperacaoFiscalModel.aliasColumns;
    gridColumns = tributOperacaoFiscalGridColumns();
    functionName = "tribut_operacao_fiscal";
    screenTitle = "Operação Fiscal";
  }

  @override
  TributOperacaoFiscalModel createNewModel() => TributOperacaoFiscalModel();

  @override
  final standardFieldForFilter = TributOperacaoFiscalModel.aliasColumns[TributOperacaoFiscalModel.dbColumns.indexOf('cfop')];

  final cfopController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final descricaoController = TextEditingController();
  final descricaoNaNfController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cfop'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributOperacaoFiscal) => tributOperacaoFiscal.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.tributOperacaoFiscalEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cfopController.updateValue(0);
    descricaoController.text = '';
    descricaoNaNfController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.tributOperacaoFiscalEditPage);
  }

  void updateControllersFromModel() {
    cfopController.updateValue((currentModel.cfop ?? 0).toDouble());
    descricaoController.text = currentModel.descricao ?? '';
    descricaoNaNfController.text = currentModel.descricaoNaNf ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(tributOperacaoFiscalModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    cfopController.dispose();
    descricaoController.dispose();
    descricaoNaNfController.dispose();
    observacaoController.dispose();
    super.onClose();
  }

}