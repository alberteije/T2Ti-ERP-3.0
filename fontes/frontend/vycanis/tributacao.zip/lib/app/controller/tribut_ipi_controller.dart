import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributIpiController extends ControllerBase<TributIpiModel, void> {

  TributIpiController() : super(repository: null) {
    dbColumns = TributIpiModel.dbColumns;
    aliasColumns = TributIpiModel.aliasColumns;
    functionName = "tribut_ipi";
    screenTitle = "IPI";
  }

	String? mandatoryMessage;

  final _tributIpiModel = TributIpiModel().obs;
  TributIpiModel get tributIpiModel => Get.find<TributConfiguraOfGtController>().currentModel.tributIpiModel ?? TributIpiModel();
  set tributIpiModel(value) => _tributIpiModel.value = value ?? TributIpiModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final tributIpiScaffoldKey = GlobalKey<ScaffoldState>();
  final tributIpiFormKey = GlobalKey<FormState>();

  @override
  TributIpiModel createNewModel() => TributIpiModel();

  @override
  final standardFieldForFilter = "";

  final cstIpiController = CustomDropdownButtonController('00');
  final modalidadeBaseCalculoController = CustomDropdownButtonController('0-Percentual');
  final porcentoBaseCalculoController = MoneyMaskedTextController();
  final aliquotaPorcentoController = MoneyMaskedTextController();
  final aliquotaUnidadeController = MoneyMaskedTextController();
  final valorPrecoMaximoController = MoneyMaskedTextController();
  final valorPautaFiscalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributIpi) => tributIpi.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    cstIpiController.selected = '00';
    modalidadeBaseCalculoController.selected = '0-Percentual';
    porcentoBaseCalculoController.updateValue(0);
    aliquotaPorcentoController.updateValue(0);
    aliquotaUnidadeController.updateValue(0);
    valorPrecoMaximoController.updateValue(0);
    valorPautaFiscalController.updateValue(0);
  }

  void updateControllersFromModel() {
		_resetForm();
    cstIpiController.selected = tributIpiModel.cstIpi ?? '00';
    modalidadeBaseCalculoController.selected = tributIpiModel.modalidadeBaseCalculo ?? '0-Percentual';
    porcentoBaseCalculoController.updateValue(tributIpiModel.porcentoBaseCalculo ?? 0);
    aliquotaPorcentoController.updateValue(tributIpiModel.aliquotaPorcento ?? 0);
    aliquotaUnidadeController.updateValue(tributIpiModel.aliquotaUnidade ?? 0);
    valorPrecoMaximoController.updateValue(tributIpiModel.valorPrecoMaximo ?? 0);
    valorPautaFiscalController.updateValue(tributIpiModel.valorPautaFiscal ?? 0);
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    return true;
	}


  @override
  void onClose() {
    cstIpiController.dispose();
    modalidadeBaseCalculoController.dispose();
    porcentoBaseCalculoController.dispose();
    aliquotaPorcentoController.dispose();
    aliquotaUnidadeController.dispose();
    valorPrecoMaximoController.dispose();
    valorPautaFiscalController.dispose();
  }

}