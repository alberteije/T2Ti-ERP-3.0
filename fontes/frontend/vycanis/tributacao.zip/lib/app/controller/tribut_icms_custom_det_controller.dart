import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:tributacao/app/page/shared_widget/input/input_imports.dart';

import 'package:tributacao/app/page/page_imports.dart';
import 'package:tributacao/app/page/shared_widget/message_dialog.dart';
import 'package:tributacao/app/page/grid_columns/grid_columns_imports.dart';
import 'package:tributacao/app/controller/controller_imports.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributIcmsCustomDetController extends ControllerBase<TributIcmsCustomDetModel, void> {

  TributIcmsCustomDetController() : super(repository: null) {
    dbColumns = TributIcmsCustomDetModel.dbColumns;
    aliasColumns = TributIcmsCustomDetModel.aliasColumns;
    gridColumns = tributIcmsCustomDetGridColumns();
    functionName = "tribut_icms_custom_det";
    screenTitle = "Detalhes";
  }

  final _tributIcmsCustomDetModel = TributIcmsCustomDetModel().obs;
  TributIcmsCustomDetModel get tributIcmsCustomDetModel => _tributIcmsCustomDetModel.value;
  set tributIcmsCustomDetModel(value) => _tributIcmsCustomDetModel.value = value ?? TributIcmsCustomDetModel();

  List<TributIcmsCustomDetModel> get tributIcmsCustomDetModelList => Get.find<TributIcmsCustomCabController>().currentModel.tributIcmsCustomDetModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final tributIcmsCustomDetScaffoldKey = GlobalKey<ScaffoldState>();
  final tributIcmsCustomDetFormKey = GlobalKey<FormState>();

  @override
  TributIcmsCustomDetModel createNewModel() => TributIcmsCustomDetModel();

  @override
  final standardFieldForFilter = TributIcmsCustomDetModel.aliasColumns[TributIcmsCustomDetModel.dbColumns.indexOf('uf_destino')];

  final ufDestinoController = CustomDropdownButtonController('AC');
  final cstController = CustomDropdownButtonController('00');
  final csosnController = CustomDropdownButtonController('101');
  final modalidadeBcController = CustomDropdownButtonController('0-Margem Valor Agregado');
  final cfopController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final aliquotaController = MoneyMaskedTextController();
  final valorPautaController = MoneyMaskedTextController();
  final valorPrecoMaximoController = MoneyMaskedTextController();
  final mvaController = MoneyMaskedTextController();
  final porcentoBcController = MoneyMaskedTextController();
  final modalidadeBcStController = CustomDropdownButtonController('0-Valor Preço Máximo');
  final aliquotaInternaStController = MoneyMaskedTextController();
  final aliquotaInterestadualStController = MoneyMaskedTextController();
  final porcentoBcStController = MoneyMaskedTextController();
  final aliquotaIcmsStController = MoneyMaskedTextController();
  final valorPautaStController = MoneyMaskedTextController();
  final valorPrecoMaximoStController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['uf_destino'],
    'secondaryColumns': ['cst'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tributIcmsCustomDet) => tributIcmsCustomDet.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(tributIcmsCustomDetModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    tributIcmsCustomDetModel = createNewModel();
    _resetForm();
    Get.to(() => TributIcmsCustomDetEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    ufDestinoController.selected = 'AC';
    cstController.selected = '00';
    csosnController.selected = '101';
    modalidadeBcController.selected = '0-Margem Valor Agregado';
    cfopController.updateValue(0);
    aliquotaController.updateValue(0);
    valorPautaController.updateValue(0);
    valorPrecoMaximoController.updateValue(0);
    mvaController.updateValue(0);
    porcentoBcController.updateValue(0);
    modalidadeBcStController.selected = '0-Valor Preço Máximo';
    aliquotaInternaStController.updateValue(0);
    aliquotaInterestadualStController.updateValue(0);
    porcentoBcStController.updateValue(0);
    aliquotaIcmsStController.updateValue(0);
    valorPautaStController.updateValue(0);
    valorPrecoMaximoStController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = tributIcmsCustomDetModelList.firstWhere((m) => m.tempId == tempId);
    tributIcmsCustomDetModel = model.clone();
		tributIcmsCustomDetModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => TributIcmsCustomDetEditPage());
  }

  void updateControllersFromModel() {
    ufDestinoController.selected = tributIcmsCustomDetModel.ufDestino ?? 'AC';
    cstController.selected = tributIcmsCustomDetModel.cst ?? '00';
    csosnController.selected = tributIcmsCustomDetModel.csosn ?? '101';
    modalidadeBcController.selected = tributIcmsCustomDetModel.modalidadeBc ?? '0-Margem Valor Agregado';
    cfopController.updateValue((tributIcmsCustomDetModel.cfop ?? 0).toDouble());
    aliquotaController.updateValue(tributIcmsCustomDetModel.aliquota ?? 0);
    valorPautaController.updateValue(tributIcmsCustomDetModel.valorPauta ?? 0);
    valorPrecoMaximoController.updateValue(tributIcmsCustomDetModel.valorPrecoMaximo ?? 0);
    mvaController.updateValue(tributIcmsCustomDetModel.mva ?? 0);
    porcentoBcController.updateValue(tributIcmsCustomDetModel.porcentoBc ?? 0);
    modalidadeBcStController.selected = tributIcmsCustomDetModel.modalidadeBcSt ?? '0-Valor Preço Máximo';
    aliquotaInternaStController.updateValue(tributIcmsCustomDetModel.aliquotaInternaSt ?? 0);
    aliquotaInterestadualStController.updateValue(tributIcmsCustomDetModel.aliquotaInterestadualSt ?? 0);
    porcentoBcStController.updateValue(tributIcmsCustomDetModel.porcentoBcSt ?? 0);
    aliquotaIcmsStController.updateValue(tributIcmsCustomDetModel.aliquotaIcmsSt ?? 0);
    valorPautaStController.updateValue(tributIcmsCustomDetModel.valorPautaSt ?? 0);
    valorPrecoMaximoStController.updateValue(tributIcmsCustomDetModel.valorPrecoMaximoSt ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!tributIcmsCustomDetFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        tributIcmsCustomDetModelList.insert(0, tributIcmsCustomDetModel.clone());
      } else {
        final index = tributIcmsCustomDetModelList.indexWhere((m) => m.tempId == tributIcmsCustomDetModel.tempId);
        if (index >= 0) {
          tributIcmsCustomDetModelList[index] = tributIcmsCustomDetModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      tributIcmsCustomDetModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    ufDestinoController.dispose();
    cstController.dispose();
    csosnController.dispose();
    modalidadeBcController.dispose();
    cfopController.dispose();
    aliquotaController.dispose();
    valorPautaController.dispose();
    valorPrecoMaximoController.dispose();
    mvaController.dispose();
    porcentoBcController.dispose();
    modalidadeBcStController.dispose();
    aliquotaInternaStController.dispose();
    aliquotaInterestadualStController.dispose();
    porcentoBcStController.dispose();
    aliquotaIcmsStController.dispose();
    valorPautaStController.dispose();
    valorPrecoMaximoStController.dispose();
  }

}