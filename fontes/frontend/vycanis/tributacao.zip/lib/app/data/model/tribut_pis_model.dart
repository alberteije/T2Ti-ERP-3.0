import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

import 'package:tributacao/app/data/domain/domain_imports.dart';

class TributPisModel extends ModelBase {
  int? id;
  int? idTributConfiguraOfGt;
  String? cstPis;
  String? modalidadeBaseCalculo;
  String? efdTabela435;
  double? porcentoBaseCalculo;
  double? aliquotaPorcento;
  double? aliquotaUnidade;
  double? valorPrecoMaximo;
  double? valorPautaFiscal;

  TributPisModel({
    this.id,
    this.idTributConfiguraOfGt,
    this.cstPis = '00',
    this.modalidadeBaseCalculo = '0-Percentual',
    this.efdTabela435,
    this.porcentoBaseCalculo,
    this.aliquotaPorcento,
    this.aliquotaUnidade,
    this.valorPrecoMaximo,
    this.valorPautaFiscal,
  });

  static List<String> dbColumns = <String>[
    'id',
    'cst_pis',
    'modalidade_base_calculo',
    'efd_tabela_435',
    'porcento_base_calculo',
    'aliquota_porcento',
    'aliquota_unidade',
    'valor_preco_maximo',
    'valor_pauta_fiscal',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cst Pis',
    'Modalidade Base Calculo',
    'Efd Tabela 435',
    'Porcento Base Calculo',
    'Aliquota Porcento',
    'Aliquota Unidade',
    'Valor Preco Maximo',
    'Valor Pauta Fiscal',
  ];

  TributPisModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTributConfiguraOfGt = jsonData['idTributConfiguraOfGt'];
    cstPis = TributPisDomain.getCstPis(jsonData['cstPis']);
    modalidadeBaseCalculo = TributPisDomain.getModalidadeBaseCalculo(jsonData['modalidadeBaseCalculo']);
    efdTabela435 = jsonData['efdTabela435'];
    porcentoBaseCalculo = jsonData['porcentoBaseCalculo']?.toDouble();
    aliquotaPorcento = jsonData['aliquotaPorcento']?.toDouble();
    aliquotaUnidade = jsonData['aliquotaUnidade']?.toDouble();
    valorPrecoMaximo = jsonData['valorPrecoMaximo']?.toDouble();
    valorPautaFiscal = jsonData['valorPautaFiscal']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTributConfiguraOfGt'] = idTributConfiguraOfGt != 0 ? idTributConfiguraOfGt : null;
    jsonData['cstPis'] = TributPisDomain.setCstPis(cstPis);
    jsonData['modalidadeBaseCalculo'] = TributPisDomain.setModalidadeBaseCalculo(modalidadeBaseCalculo);
    jsonData['efdTabela435'] = efdTabela435;
    jsonData['porcentoBaseCalculo'] = porcentoBaseCalculo;
    jsonData['aliquotaPorcento'] = aliquotaPorcento;
    jsonData['aliquotaUnidade'] = aliquotaUnidade;
    jsonData['valorPrecoMaximo'] = valorPrecoMaximo;
    jsonData['valorPautaFiscal'] = valorPautaFiscal;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributPisModel fromPlutoRow(PlutoRow row) {
    return TributPisModel(
      id: row.cells['id']?.value,
      idTributConfiguraOfGt: row.cells['idTributConfiguraOfGt']?.value,
      cstPis: row.cells['cstPis']?.value,
      modalidadeBaseCalculo: row.cells['modalidadeBaseCalculo']?.value,
      efdTabela435: row.cells['efdTabela435']?.value,
      porcentoBaseCalculo: row.cells['porcentoBaseCalculo']?.value,
      aliquotaPorcento: row.cells['aliquotaPorcento']?.value,
      aliquotaUnidade: row.cells['aliquotaUnidade']?.value,
      valorPrecoMaximo: row.cells['valorPrecoMaximo']?.value,
      valorPautaFiscal: row.cells['valorPautaFiscal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTributConfiguraOfGt': PlutoCell(value: idTributConfiguraOfGt ?? 0),
        'cstPis': PlutoCell(value: cstPis ?? ''),
        'modalidadeBaseCalculo': PlutoCell(value: modalidadeBaseCalculo ?? ''),
        'efdTabela435': PlutoCell(value: efdTabela435 ?? ''),
        'porcentoBaseCalculo': PlutoCell(value: porcentoBaseCalculo ?? 0.0),
        'aliquotaPorcento': PlutoCell(value: aliquotaPorcento ?? 0.0),
        'aliquotaUnidade': PlutoCell(value: aliquotaUnidade ?? 0.0),
        'valorPrecoMaximo': PlutoCell(value: valorPrecoMaximo ?? 0.0),
        'valorPautaFiscal': PlutoCell(value: valorPautaFiscal ?? 0.0),
      },
    );
  }

  TributPisModel clone() {
    return TributPisModel(
      id: id,
      idTributConfiguraOfGt: idTributConfiguraOfGt,
      cstPis: cstPis,
      modalidadeBaseCalculo: modalidadeBaseCalculo,
      efdTabela435: efdTabela435,
      porcentoBaseCalculo: porcentoBaseCalculo,
      aliquotaPorcento: aliquotaPorcento,
      aliquotaUnidade: aliquotaUnidade,
      valorPrecoMaximo: valorPrecoMaximo,
      valorPautaFiscal: valorPautaFiscal,
    );
  }


}