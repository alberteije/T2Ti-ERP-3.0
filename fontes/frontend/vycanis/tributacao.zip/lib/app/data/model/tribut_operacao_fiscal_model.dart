import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:tributacao/app/data/model/model_imports.dart';


class TributOperacaoFiscalModel extends ModelBase {
  int? id;
  int? cfop;
  String? descricao;
  String? descricaoNaNf;
  String? observacao;

  TributOperacaoFiscalModel({
    this.id,
    this.cfop,
    this.descricao,
    this.descricaoNaNf,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'cfop',
    'descricao',
    'descricao_na_nf',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cfop',
    'Descricao',
    'Descricao Na Nf',
    'Observacao',
  ];

  TributOperacaoFiscalModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    cfop = jsonData['cfop'];
    descricao = jsonData['descricao'];
    descricaoNaNf = jsonData['descricaoNaNf'];
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['cfop'] = cfop;
    jsonData['descricao'] = descricao;
    jsonData['descricaoNaNf'] = descricaoNaNf;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributOperacaoFiscalModel fromPlutoRow(PlutoRow row) {
    return TributOperacaoFiscalModel(
      id: row.cells['id']?.value,
      cfop: row.cells['cfop']?.value,
      descricao: row.cells['descricao']?.value,
      descricaoNaNf: row.cells['descricaoNaNf']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'cfop': PlutoCell(value: cfop ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'descricaoNaNf': PlutoCell(value: descricaoNaNf ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  TributOperacaoFiscalModel clone() {
    return TributOperacaoFiscalModel(
      id: id,
      cfop: cfop,
      descricao: descricao,
      descricaoNaNf: descricaoNaNf,
      observacao: observacao,
    );
  }


}