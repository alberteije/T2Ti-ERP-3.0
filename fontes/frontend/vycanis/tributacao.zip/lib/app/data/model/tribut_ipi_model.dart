import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

import 'package:tributacao/app/data/domain/domain_imports.dart';

class TributIpiModel extends ModelBase {
  int? id;
  int? idTributConfiguraOfGt;
  String? cstIpi;
  String? modalidadeBaseCalculo;
  double? porcentoBaseCalculo;
  double? aliquotaPorcento;
  double? aliquotaUnidade;
  double? valorPrecoMaximo;
  double? valorPautaFiscal;

  TributIpiModel({
    this.id,
    this.idTributConfiguraOfGt,
    this.cstIpi = '00',
    this.modalidadeBaseCalculo = '0-Percentual',
    this.porcentoBaseCalculo,
    this.aliquotaPorcento,
    this.aliquotaUnidade,
    this.valorPrecoMaximo,
    this.valorPautaFiscal,
  });

  static List<String> dbColumns = <String>[
    'id',
    'cst_ipi',
    'modalidade_base_calculo',
    'porcento_base_calculo',
    'aliquota_porcento',
    'aliquota_unidade',
    'valor_preco_maximo',
    'valor_pauta_fiscal',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cst Ipi',
    'Modalidade Base Calculo',
    'Porcento Base Calculo',
    'Aliquota Porcento',
    'Aliquota Unidade',
    'Valor Preco Maximo',
    'Valor Pauta Fiscal',
  ];

  TributIpiModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTributConfiguraOfGt = jsonData['idTributConfiguraOfGt'];
    cstIpi = TributIpiDomain.getCstIpi(jsonData['cstIpi']);
    modalidadeBaseCalculo = TributIpiDomain.getModalidadeBaseCalculo(jsonData['modalidadeBaseCalculo']);
    porcentoBaseCalculo = jsonData['porcentoBaseCalculo']?.toDouble();
    aliquotaPorcento = jsonData['aliquotaPorcento']?.toDouble();
    aliquotaUnidade = jsonData['aliquotaUnidade']?.toDouble();
    valorPrecoMaximo = jsonData['valorPrecoMaximo']?.toDouble();
    valorPautaFiscal = jsonData['valorPautaFiscal']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTributConfiguraOfGt'] = idTributConfiguraOfGt != 0 ? idTributConfiguraOfGt : null;
    jsonData['cstIpi'] = TributIpiDomain.setCstIpi(cstIpi);
    jsonData['modalidadeBaseCalculo'] = TributIpiDomain.setModalidadeBaseCalculo(modalidadeBaseCalculo);
    jsonData['porcentoBaseCalculo'] = porcentoBaseCalculo;
    jsonData['aliquotaPorcento'] = aliquotaPorcento;
    jsonData['aliquotaUnidade'] = aliquotaUnidade;
    jsonData['valorPrecoMaximo'] = valorPrecoMaximo;
    jsonData['valorPautaFiscal'] = valorPautaFiscal;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributIpiModel fromPlutoRow(PlutoRow row) {
    return TributIpiModel(
      id: row.cells['id']?.value,
      idTributConfiguraOfGt: row.cells['idTributConfiguraOfGt']?.value,
      cstIpi: row.cells['cstIpi']?.value,
      modalidadeBaseCalculo: row.cells['modalidadeBaseCalculo']?.value,
      porcentoBaseCalculo: row.cells['porcentoBaseCalculo']?.value,
      aliquotaPorcento: row.cells['aliquotaPorcento']?.value,
      aliquotaUnidade: row.cells['aliquotaUnidade']?.value,
      valorPrecoMaximo: row.cells['valorPrecoMaximo']?.value,
      valorPautaFiscal: row.cells['valorPautaFiscal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTributConfiguraOfGt': PlutoCell(value: idTributConfiguraOfGt ?? 0),
        'cstIpi': PlutoCell(value: cstIpi ?? ''),
        'modalidadeBaseCalculo': PlutoCell(value: modalidadeBaseCalculo ?? ''),
        'porcentoBaseCalculo': PlutoCell(value: porcentoBaseCalculo ?? 0.0),
        'aliquotaPorcento': PlutoCell(value: aliquotaPorcento ?? 0.0),
        'aliquotaUnidade': PlutoCell(value: aliquotaUnidade ?? 0.0),
        'valorPrecoMaximo': PlutoCell(value: valorPrecoMaximo ?? 0.0),
        'valorPautaFiscal': PlutoCell(value: valorPautaFiscal ?? 0.0),
      },
    );
  }

  TributIpiModel clone() {
    return TributIpiModel(
      id: id,
      idTributConfiguraOfGt: idTributConfiguraOfGt,
      cstIpi: cstIpi,
      modalidadeBaseCalculo: modalidadeBaseCalculo,
      porcentoBaseCalculo: porcentoBaseCalculo,
      aliquotaPorcento: aliquotaPorcento,
      aliquotaUnidade: aliquotaUnidade,
      valorPrecoMaximo: valorPrecoMaximo,
      valorPautaFiscal: valorPautaFiscal,
    );
  }


}