import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

import 'package:tributacao/app/data/domain/domain_imports.dart';

class TributIcmsUfModel extends ModelBase {
  int? id;
  int? idTributConfiguraOfGt;
  String? ufDestino;
  String? cst;
  String? csosn;
  String? modalidadeBc;
  int? cfop;
  double? aliquota;
  double? valorPauta;
  double? valorPrecoMaximo;
  double? mva;
  double? porcentoBc;
  String? modalidadeBcSt;
  double? aliquotaInternaSt;
  double? aliquotaInterestadualSt;
  double? porcentoBcSt;
  double? aliquotaIcmsSt;
  double? valorPautaSt;
  double? valorPrecoMaximoSt;

  TributIcmsUfModel({
    this.id,
    this.idTributConfiguraOfGt,
    this.ufDestino = 'AC',
    this.cst = '00',
    this.csosn = '101',
    this.modalidadeBc = '0-Margem Valor Agregado',
    this.cfop,
    this.aliquota,
    this.valorPauta,
    this.valorPrecoMaximo,
    this.mva,
    this.porcentoBc,
    this.modalidadeBcSt = '0-Valor Preço Máximo',
    this.aliquotaInternaSt,
    this.aliquotaInterestadualSt,
    this.porcentoBcSt,
    this.aliquotaIcmsSt,
    this.valorPautaSt,
    this.valorPrecoMaximoSt,
  });

  static List<String> dbColumns = <String>[
    'id',
    'uf_destino',
    'cst',
    'csosn',
    'modalidade_bc',
    'cfop',
    'aliquota',
    'valor_pauta',
    'valor_preco_maximo',
    'mva',
    'porcento_bc',
    'modalidade_bc_st',
    'aliquota_interna_st',
    'aliquota_interestadual_st',
    'porcento_bc_st',
    'aliquota_icms_st',
    'valor_pauta_st',
    'valor_preco_maximo_st',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Uf Destino',
    'Cst',
    'Csosn',
    'Modalidade Bc',
    'Cfop',
    'Aliquota',
    'Valor Pauta',
    'Valor Preco Maximo',
    'Mva',
    'Porcento Bc',
    'Modalidade Bc St',
    'Aliquota Interna St',
    'Aliquota Interestadual St',
    'Porcento Bc St',
    'Aliquota Icms St',
    'Valor Pauta St',
    'Valor Preco Maximo St',
  ];

  TributIcmsUfModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTributConfiguraOfGt = jsonData['idTributConfiguraOfGt'];
    ufDestino = TributIcmsUfDomain.getUfDestino(jsonData['ufDestino']);
    cst = TributIcmsUfDomain.getCst(jsonData['cst']);
    csosn = TributIcmsUfDomain.getCsosn(jsonData['csosn']);
    modalidadeBc = TributIcmsUfDomain.getModalidadeBc(jsonData['modalidadeBc']);
    cfop = jsonData['cfop'];
    aliquota = jsonData['aliquota']?.toDouble();
    valorPauta = jsonData['valorPauta']?.toDouble();
    valorPrecoMaximo = jsonData['valorPrecoMaximo']?.toDouble();
    mva = jsonData['mva']?.toDouble();
    porcentoBc = jsonData['porcentoBc']?.toDouble();
    modalidadeBcSt = TributIcmsUfDomain.getModalidadeBcSt(jsonData['modalidadeBcSt']);
    aliquotaInternaSt = jsonData['aliquotaInternaSt']?.toDouble();
    aliquotaInterestadualSt = jsonData['aliquotaInterestadualSt']?.toDouble();
    porcentoBcSt = jsonData['porcentoBcSt']?.toDouble();
    aliquotaIcmsSt = jsonData['aliquotaIcmsSt']?.toDouble();
    valorPautaSt = jsonData['valorPautaSt']?.toDouble();
    valorPrecoMaximoSt = jsonData['valorPrecoMaximoSt']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTributConfiguraOfGt'] = idTributConfiguraOfGt != 0 ? idTributConfiguraOfGt : null;
    jsonData['ufDestino'] = TributIcmsUfDomain.setUfDestino(ufDestino);
    jsonData['cst'] = TributIcmsUfDomain.setCst(cst);
    jsonData['csosn'] = TributIcmsUfDomain.setCsosn(csosn);
    jsonData['modalidadeBc'] = TributIcmsUfDomain.setModalidadeBc(modalidadeBc);
    jsonData['cfop'] = cfop;
    jsonData['aliquota'] = aliquota;
    jsonData['valorPauta'] = valorPauta;
    jsonData['valorPrecoMaximo'] = valorPrecoMaximo;
    jsonData['mva'] = mva;
    jsonData['porcentoBc'] = porcentoBc;
    jsonData['modalidadeBcSt'] = TributIcmsUfDomain.setModalidadeBcSt(modalidadeBcSt);
    jsonData['aliquotaInternaSt'] = aliquotaInternaSt;
    jsonData['aliquotaInterestadualSt'] = aliquotaInterestadualSt;
    jsonData['porcentoBcSt'] = porcentoBcSt;
    jsonData['aliquotaIcmsSt'] = aliquotaIcmsSt;
    jsonData['valorPautaSt'] = valorPautaSt;
    jsonData['valorPrecoMaximoSt'] = valorPrecoMaximoSt;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributIcmsUfModel fromPlutoRow(PlutoRow row) {
    return TributIcmsUfModel(
      id: row.cells['id']?.value,
      idTributConfiguraOfGt: row.cells['idTributConfiguraOfGt']?.value,
      ufDestino: row.cells['ufDestino']?.value,
      cst: row.cells['cst']?.value,
      csosn: row.cells['csosn']?.value,
      modalidadeBc: row.cells['modalidadeBc']?.value,
      cfop: row.cells['cfop']?.value,
      aliquota: row.cells['aliquota']?.value,
      valorPauta: row.cells['valorPauta']?.value,
      valorPrecoMaximo: row.cells['valorPrecoMaximo']?.value,
      mva: row.cells['mva']?.value,
      porcentoBc: row.cells['porcentoBc']?.value,
      modalidadeBcSt: row.cells['modalidadeBcSt']?.value,
      aliquotaInternaSt: row.cells['aliquotaInternaSt']?.value,
      aliquotaInterestadualSt: row.cells['aliquotaInterestadualSt']?.value,
      porcentoBcSt: row.cells['porcentoBcSt']?.value,
      aliquotaIcmsSt: row.cells['aliquotaIcmsSt']?.value,
      valorPautaSt: row.cells['valorPautaSt']?.value,
      valorPrecoMaximoSt: row.cells['valorPrecoMaximoSt']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTributConfiguraOfGt': PlutoCell(value: idTributConfiguraOfGt ?? 0),
        'ufDestino': PlutoCell(value: ufDestino ?? ''),
        'cst': PlutoCell(value: cst ?? ''),
        'csosn': PlutoCell(value: csosn ?? ''),
        'modalidadeBc': PlutoCell(value: modalidadeBc ?? ''),
        'cfop': PlutoCell(value: cfop ?? 0),
        'aliquota': PlutoCell(value: aliquota ?? 0.0),
        'valorPauta': PlutoCell(value: valorPauta ?? 0.0),
        'valorPrecoMaximo': PlutoCell(value: valorPrecoMaximo ?? 0.0),
        'mva': PlutoCell(value: mva ?? 0.0),
        'porcentoBc': PlutoCell(value: porcentoBc ?? 0.0),
        'modalidadeBcSt': PlutoCell(value: modalidadeBcSt ?? ''),
        'aliquotaInternaSt': PlutoCell(value: aliquotaInternaSt ?? 0.0),
        'aliquotaInterestadualSt': PlutoCell(value: aliquotaInterestadualSt ?? 0.0),
        'porcentoBcSt': PlutoCell(value: porcentoBcSt ?? 0.0),
        'aliquotaIcmsSt': PlutoCell(value: aliquotaIcmsSt ?? 0.0),
        'valorPautaSt': PlutoCell(value: valorPautaSt ?? 0.0),
        'valorPrecoMaximoSt': PlutoCell(value: valorPrecoMaximoSt ?? 0.0),
      },
    );
  }

  TributIcmsUfModel clone() {
    return TributIcmsUfModel(
      id: id,
      idTributConfiguraOfGt: idTributConfiguraOfGt,
      ufDestino: ufDestino,
      cst: cst,
      csosn: csosn,
      modalidadeBc: modalidadeBc,
      cfop: cfop,
      aliquota: aliquota,
      valorPauta: valorPauta,
      valorPrecoMaximo: valorPrecoMaximo,
      mva: mva,
      porcentoBc: porcentoBc,
      modalidadeBcSt: modalidadeBcSt,
      aliquotaInternaSt: aliquotaInternaSt,
      aliquotaInterestadualSt: aliquotaInterestadualSt,
      porcentoBcSt: porcentoBcSt,
      aliquotaIcmsSt: aliquotaIcmsSt,
      valorPautaSt: valorPautaSt,
      valorPrecoMaximoSt: valorPrecoMaximoSt,
    );
  }


}