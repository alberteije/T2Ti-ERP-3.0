import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

import 'package:tributacao/app/data/domain/domain_imports.dart';

class TributIcmsCustomCabModel extends ModelBase {
  int? id;
  String? descricao;
  String? origemMercadoria;
  List<TributIcmsCustomDetModel>? tributIcmsCustomDetModelList;

  TributIcmsCustomCabModel({
    this.id,
    this.descricao,
    this.origemMercadoria = '0=Nacional',
    List<TributIcmsCustomDetModel>? tributIcmsCustomDetModelList,
  }) {
    this.tributIcmsCustomDetModelList = tributIcmsCustomDetModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'origem_mercadoria',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Origem Mercadoria',
  ];

  TributIcmsCustomCabModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    origemMercadoria = TributIcmsCustomCabDomain.getOrigemMercadoria(jsonData['origemMercadoria']);
    tributIcmsCustomDetModelList = (jsonData['tributIcmsCustomDetModelList'] as Iterable?)?.map((m) => TributIcmsCustomDetModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    jsonData['origemMercadoria'] = TributIcmsCustomCabDomain.setOrigemMercadoria(origemMercadoria);
    
		var tributIcmsCustomDetModelLocalList = []; 
		for (TributIcmsCustomDetModel object in tributIcmsCustomDetModelList ?? []) { 
			tributIcmsCustomDetModelLocalList.add(object.toJson); 
		}
		jsonData['tributIcmsCustomDetModelList'] = tributIcmsCustomDetModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributIcmsCustomCabModel fromPlutoRow(PlutoRow row) {
    return TributIcmsCustomCabModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
      origemMercadoria: row.cells['origemMercadoria']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'origemMercadoria': PlutoCell(value: origemMercadoria ?? ''),
      },
    );
  }

  TributIcmsCustomCabModel clone() {
    return TributIcmsCustomCabModel(
      id: id,
      descricao: descricao,
      origemMercadoria: origemMercadoria,
      tributIcmsCustomDetModelList: tributIcmsCustomDetModelListClone(tributIcmsCustomDetModelList!),
    );
  }

  tributIcmsCustomDetModelListClone(List<TributIcmsCustomDetModel> tributIcmsCustomDetModelList) { 
		List<TributIcmsCustomDetModel> resultList = [];
		for (var tributIcmsCustomDetModel in tributIcmsCustomDetModelList) {
			resultList.add(tributIcmsCustomDetModel.clone());
		}
		return resultList;
	}


}