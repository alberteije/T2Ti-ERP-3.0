import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

import 'package:tributacao/app/data/domain/domain_imports.dart';

class TributIssModel extends ModelBase {
  int? id;
  int? idTributOperacaoFiscal;
  String? modalidadeBaseCalculo;
  String? codigoTributacao;
  int? itemListaServico;
  double? porcentoBaseCalculo;
  double? aliquotaPorcento;
  double? aliquotaUnidade;
  double? valorPrecoMaximo;
  double? valorPautaFiscal;
  TributOperacaoFiscalModel? tributOperacaoFiscalModel;

  TributIssModel({
    this.id,
    this.idTributOperacaoFiscal,
    this.modalidadeBaseCalculo = '0-Valor Operação',
    this.codigoTributacao = 'Normal',
    this.itemListaServico,
    this.porcentoBaseCalculo,
    this.aliquotaPorcento,
    this.aliquotaUnidade,
    this.valorPrecoMaximo,
    this.valorPautaFiscal,
    TributOperacaoFiscalModel? tributOperacaoFiscalModel,
  }) {
    this.tributOperacaoFiscalModel = tributOperacaoFiscalModel ?? TributOperacaoFiscalModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'modalidade_base_calculo',
    'codigo_trib',
    'item_lista_servico',
    'porcento_base_calculo',
    'aliquota_porcento',
    'aliquota_unidade',
    'valor_preco_maximo',
    'valor_pauta_fiscal',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Modalidade Base Calculo',
    'Codigo Tributacao',
    'Item Lista Servico',
    'Porcento Base Calculo',
    'Aliquota Porcento',
    'Aliquota Unidade',
    'Valor Preco Maximo',
    'Valor Pauta Fiscal',
  ];

  TributIssModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTributOperacaoFiscal = jsonData['idTributOperacaoFiscal'];
    modalidadeBaseCalculo = TributIssDomain.getModalidadeBaseCalculo(jsonData['modalidadeBaseCalculo']);
    codigoTributacao = TributIssDomain.getCodigoTributacao(jsonData['codigoTributacao']);
    itemListaServico = jsonData['itemListaServico'];
    porcentoBaseCalculo = jsonData['porcentoBaseCalculo']?.toDouble();
    aliquotaPorcento = jsonData['aliquotaPorcento']?.toDouble();
    aliquotaUnidade = jsonData['aliquotaUnidade']?.toDouble();
    valorPrecoMaximo = jsonData['valorPrecoMaximo']?.toDouble();
    valorPautaFiscal = jsonData['valorPautaFiscal']?.toDouble();
    tributOperacaoFiscalModel = jsonData['tributOperacaoFiscalModel'] == null ? TributOperacaoFiscalModel() : TributOperacaoFiscalModel.fromJson(jsonData['tributOperacaoFiscalModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTributOperacaoFiscal'] = idTributOperacaoFiscal != 0 ? idTributOperacaoFiscal : null;
    jsonData['modalidadeBaseCalculo'] = TributIssDomain.setModalidadeBaseCalculo(modalidadeBaseCalculo);
    jsonData['codigoTributacao'] = TributIssDomain.setCodigoTributacao(codigoTributacao);
    jsonData['itemListaServico'] = itemListaServico;
    jsonData['porcentoBaseCalculo'] = porcentoBaseCalculo;
    jsonData['aliquotaPorcento'] = aliquotaPorcento;
    jsonData['aliquotaUnidade'] = aliquotaUnidade;
    jsonData['valorPrecoMaximo'] = valorPrecoMaximo;
    jsonData['valorPautaFiscal'] = valorPautaFiscal;
    jsonData['tributOperacaoFiscalModel'] = tributOperacaoFiscalModel?.toJson;
    jsonData['tributOperacaoFiscal'] = tributOperacaoFiscalModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributIssModel fromPlutoRow(PlutoRow row) {
    return TributIssModel(
      id: row.cells['id']?.value,
      idTributOperacaoFiscal: row.cells['idTributOperacaoFiscal']?.value,
      modalidadeBaseCalculo: row.cells['modalidadeBaseCalculo']?.value,
      codigoTributacao: row.cells['codigoTributacao']?.value,
      itemListaServico: row.cells['itemListaServico']?.value,
      porcentoBaseCalculo: row.cells['porcentoBaseCalculo']?.value,
      aliquotaPorcento: row.cells['aliquotaPorcento']?.value,
      aliquotaUnidade: row.cells['aliquotaUnidade']?.value,
      valorPrecoMaximo: row.cells['valorPrecoMaximo']?.value,
      valorPautaFiscal: row.cells['valorPautaFiscal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTributOperacaoFiscal': PlutoCell(value: idTributOperacaoFiscal ?? 0),
        'modalidadeBaseCalculo': PlutoCell(value: modalidadeBaseCalculo ?? ''),
        'codigoTributacao': PlutoCell(value: codigoTributacao ?? ''),
        'itemListaServico': PlutoCell(value: itemListaServico ?? 0),
        'porcentoBaseCalculo': PlutoCell(value: porcentoBaseCalculo ?? 0.0),
        'aliquotaPorcento': PlutoCell(value: aliquotaPorcento ?? 0.0),
        'aliquotaUnidade': PlutoCell(value: aliquotaUnidade ?? 0.0),
        'valorPrecoMaximo': PlutoCell(value: valorPrecoMaximo ?? 0.0),
        'valorPautaFiscal': PlutoCell(value: valorPautaFiscal ?? 0.0),
        'tributOperacaoFiscal': PlutoCell(value: tributOperacaoFiscalModel?.descricao ?? ''),
      },
    );
  }

  TributIssModel clone() {
    return TributIssModel(
      id: id,
      idTributOperacaoFiscal: idTributOperacaoFiscal,
      modalidadeBaseCalculo: modalidadeBaseCalculo,
      codigoTributacao: codigoTributacao,
      itemListaServico: itemListaServico,
      porcentoBaseCalculo: porcentoBaseCalculo,
      aliquotaPorcento: aliquotaPorcento,
      aliquotaUnidade: aliquotaUnidade,
      valorPrecoMaximo: valorPrecoMaximo,
      valorPautaFiscal: valorPautaFiscal,
      tributOperacaoFiscalModel: tributOperacaoFiscalModel?.clone(),
    );
  }


}