import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:tributacao/app/data/model/model_imports.dart';


class TributConfiguraOfGtModel extends ModelBase {
  int? id;
  int? idTributGrupoTributario;
  int? idTributOperacaoFiscal;
  TributIpiModel? tributIpiModel;
  TributCofinsModel? tributCofinsModel;
  TributPisModel? tributPisModel;
  TributGrupoTributarioModel? tributGrupoTributarioModel;
  TributOperacaoFiscalModel? tributOperacaoFiscalModel;
  List<TributIcmsUfModel>? tributIcmsUfModelList;

  TributConfiguraOfGtModel({
    this.id,
    this.idTributGrupoTributario,
    this.idTributOperacaoFiscal,
    TributIpiModel? tributIpiModel,
    TributCofinsModel? tributCofinsModel,
    TributPisModel? tributPisModel,
    TributGrupoTributarioModel? tributGrupoTributarioModel,
    TributOperacaoFiscalModel? tributOperacaoFiscalModel,
    List<TributIcmsUfModel>? tributIcmsUfModelList,
  }) {
    this.tributIpiModel = tributIpiModel ?? TributIpiModel();
    this.tributCofinsModel = tributCofinsModel ?? TributCofinsModel();
    this.tributPisModel = tributPisModel ?? TributPisModel();
    this.tributGrupoTributarioModel = tributGrupoTributarioModel ?? TributGrupoTributarioModel();
    this.tributOperacaoFiscalModel = tributOperacaoFiscalModel ?? TributOperacaoFiscalModel();
    this.tributIcmsUfModelList = tributIcmsUfModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  TributConfiguraOfGtModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTributGrupoTributario = jsonData['idTributGrupoTributario'];
    idTributOperacaoFiscal = jsonData['idTributOperacaoFiscal'];
    tributIpiModel = jsonData['tributIpiModel'] == null ? TributIpiModel() : TributIpiModel.fromJson(jsonData['tributIpiModel']);
    tributCofinsModel = jsonData['tributCofinsModel'] == null ? TributCofinsModel() : TributCofinsModel.fromJson(jsonData['tributCofinsModel']);
    tributPisModel = jsonData['tributPisModel'] == null ? TributPisModel() : TributPisModel.fromJson(jsonData['tributPisModel']);
    tributGrupoTributarioModel = jsonData['tributGrupoTributarioModel'] == null ? TributGrupoTributarioModel() : TributGrupoTributarioModel.fromJson(jsonData['tributGrupoTributarioModel']);
    tributOperacaoFiscalModel = jsonData['tributOperacaoFiscalModel'] == null ? TributOperacaoFiscalModel() : TributOperacaoFiscalModel.fromJson(jsonData['tributOperacaoFiscalModel']);
    tributIcmsUfModelList = (jsonData['tributIcmsUfModelList'] as Iterable?)?.map((m) => TributIcmsUfModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTributGrupoTributario'] = idTributGrupoTributario != 0 ? idTributGrupoTributario : null;
    jsonData['idTributOperacaoFiscal'] = idTributOperacaoFiscal != 0 ? idTributOperacaoFiscal : null;
    jsonData['tributIpiModel'] = tributIpiModel?.toJson;
    jsonData['tributCofinsModel'] = tributCofinsModel?.toJson;
    jsonData['tributPisModel'] = tributPisModel?.toJson;
    jsonData['tributGrupoTributarioModel'] = tributGrupoTributarioModel?.toJson;
    jsonData['tributGrupoTributario'] = tributGrupoTributarioModel?.descricao ?? '';
    jsonData['tributOperacaoFiscalModel'] = tributOperacaoFiscalModel?.toJson;
    jsonData['tributOperacaoFiscal'] = tributOperacaoFiscalModel?.descricao ?? '';
    
		var tributIcmsUfModelLocalList = []; 
		for (TributIcmsUfModel object in tributIcmsUfModelList ?? []) { 
			tributIcmsUfModelLocalList.add(object.toJson); 
		}
		jsonData['tributIcmsUfModelList'] = tributIcmsUfModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributConfiguraOfGtModel fromPlutoRow(PlutoRow row) {
    return TributConfiguraOfGtModel(
      id: row.cells['id']?.value,
      idTributGrupoTributario: row.cells['idTributGrupoTributario']?.value,
      idTributOperacaoFiscal: row.cells['idTributOperacaoFiscal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTributGrupoTributario': PlutoCell(value: idTributGrupoTributario ?? 0),
        'idTributOperacaoFiscal': PlutoCell(value: idTributOperacaoFiscal ?? 0),
        'tributGrupoTributario': PlutoCell(value: tributGrupoTributarioModel?.descricao ?? ''),
        'tributOperacaoFiscal': PlutoCell(value: tributOperacaoFiscalModel?.descricao ?? ''),
      },
    );
  }

  TributConfiguraOfGtModel clone() {
    return TributConfiguraOfGtModel(
      id: id,
      idTributGrupoTributario: idTributGrupoTributario,
      idTributOperacaoFiscal: idTributOperacaoFiscal,
      tributIpiModel: tributIpiModel?.clone(),
      tributCofinsModel: tributCofinsModel?.clone(),
      tributPisModel: tributPisModel?.clone(),
      tributGrupoTributarioModel: tributGrupoTributarioModel?.clone(),
      tributOperacaoFiscalModel: tributOperacaoFiscalModel?.clone(),
      tributIcmsUfModelList: tributIcmsUfModelListClone(tributIcmsUfModelList!),
    );
  }

  tributIcmsUfModelListClone(List<TributIcmsUfModel> tributIcmsUfModelList) { 
		List<TributIcmsUfModel> resultList = [];
		for (var tributIcmsUfModel in tributIcmsUfModelList) {
			resultList.add(tributIcmsUfModel.clone());
		}
		return resultList;
	}


}