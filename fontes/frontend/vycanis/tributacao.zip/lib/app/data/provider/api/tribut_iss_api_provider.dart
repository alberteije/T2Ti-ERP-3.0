import 'package:tributacao/app/data/provider/api/api_provider_base.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributIssApiProvider extends ApiProviderBase {
  static const _path = '/tribut-iss';

  Future<List<TributIssModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => TributIssModel.fromJson(json),
      filter: filter,
    );
  }

  Future<TributIssModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => TributIssModel.fromJson(json),
    );
  }

  Future<TributIssModel?>? insert(TributIssModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => TributIssModel.fromJson(json),
    );
  }

  Future<TributIssModel?>? update(TributIssModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => TributIssModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
