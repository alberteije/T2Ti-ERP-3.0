import 'package:tributacao/app/data/provider/api/api_provider_base.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributGrupoTributarioApiProvider extends ApiProviderBase {
  static const _path = '/tribut-grupo-tributario';

  Future<List<TributGrupoTributarioModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => TributGrupoTributarioModel.fromJson(json),
      filter: filter,
    );
  }

  Future<TributGrupoTributarioModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => TributGrupoTributarioModel.fromJson(json),
    );
  }

  Future<TributGrupoTributarioModel?>? insert(TributGrupoTributarioModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => TributGrupoTributarioModel.fromJson(json),
    );
  }

  Future<TributGrupoTributarioModel?>? update(TributGrupoTributarioModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => TributGrupoTributarioModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
