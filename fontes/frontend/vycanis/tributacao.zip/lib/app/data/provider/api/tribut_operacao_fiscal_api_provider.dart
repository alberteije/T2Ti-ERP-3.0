import 'package:tributacao/app/data/provider/api/api_provider_base.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributOperacaoFiscalApiProvider extends ApiProviderBase {
  static const _path = '/tribut-operacao-fiscal';

  Future<List<TributOperacaoFiscalModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => TributOperacaoFiscalModel.fromJson(json),
      filter: filter,
    );
  }

  Future<TributOperacaoFiscalModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => TributOperacaoFiscalModel.fromJson(json),
    );
  }

  Future<TributOperacaoFiscalModel?>? insert(TributOperacaoFiscalModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => TributOperacaoFiscalModel.fromJson(json),
    );
  }

  Future<TributOperacaoFiscalModel?>? update(TributOperacaoFiscalModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => TributOperacaoFiscalModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
