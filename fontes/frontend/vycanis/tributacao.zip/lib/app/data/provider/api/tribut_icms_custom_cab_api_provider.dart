import 'package:tributacao/app/data/provider/api/api_provider_base.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributIcmsCustomCabApiProvider extends ApiProviderBase {
  static const _path = '/tribut-icms-custom-cab';

  Future<List<TributIcmsCustomCabModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => TributIcmsCustomCabModel.fromJson(json),
      filter: filter,
    );
  }

  Future<TributIcmsCustomCabModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => TributIcmsCustomCabModel.fromJson(json),
    );
  }

  Future<TributIcmsCustomCabModel?>? insert(TributIcmsCustomCabModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => TributIcmsCustomCabModel.fromJson(json),
    );
  }

  Future<TributIcmsCustomCabModel?>? update(TributIcmsCustomCabModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => TributIcmsCustomCabModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
