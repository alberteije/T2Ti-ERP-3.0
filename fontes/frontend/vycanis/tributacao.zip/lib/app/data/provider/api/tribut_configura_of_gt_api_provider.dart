import 'package:tributacao/app/data/provider/api/api_provider_base.dart';
import 'package:tributacao/app/data/model/model_imports.dart';

class TributConfiguraOfGtApiProvider extends ApiProviderBase {
  static const _path = '/tribut-configura-of-gt';

  Future<List<TributConfiguraOfGtModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => TributConfiguraOfGtModel.fromJson(json),
      filter: filter,
    );
  }

  Future<TributConfiguraOfGtModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => TributConfiguraOfGtModel.fromJson(json),
    );
  }

  Future<TributConfiguraOfGtModel?>? insert(TributConfiguraOfGtModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => TributConfiguraOfGtModel.fromJson(json),
    );
  }

  Future<TributConfiguraOfGtModel?>? update(TributConfiguraOfGtModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => TributConfiguraOfGtModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
