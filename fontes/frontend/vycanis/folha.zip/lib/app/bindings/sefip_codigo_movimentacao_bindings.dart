import 'package:get/get.dart';
import 'package:folha/app/controller/sefip_codigo_movimentacao_controller.dart';
import 'package:folha/app/data/provider/api/sefip_codigo_movimentacao_api_provider.dart';
import 'package:folha/app/data/provider/drift/sefip_codigo_movimentacao_drift_provider.dart';
import 'package:folha/app/data/repository/sefip_codigo_movimentacao_repository.dart';

class SefipCodigoMovimentacaoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<SefipCodigoMovimentacaoController>(() => SefipCodigoMovimentacaoController(
					repository: SefipCodigoMovimentacaoRepository(sefipCodigoMovimentacaoApiProvider: SefipCodigoMovimentacaoApiProvider(), sefipCodigoMovimentacaoDriftProvider: SefipCodigoMovimentacaoDriftProvider()))),
		];
	}
}
