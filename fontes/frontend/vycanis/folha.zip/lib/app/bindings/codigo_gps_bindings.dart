import 'package:get/get.dart';
import 'package:folha/app/controller/codigo_gps_controller.dart';
import 'package:folha/app/data/provider/api/codigo_gps_api_provider.dart';
import 'package:folha/app/data/provider/drift/codigo_gps_drift_provider.dart';
import 'package:folha/app/data/repository/codigo_gps_repository.dart';

class CodigoGpsBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CodigoGpsController>(() => CodigoGpsController(
					repository: CodigoGpsRepository(codigoGpsApiProvider: CodigoGpsApiProvider(), codigoGpsDriftProvider: CodigoGpsDriftProvider()))),
		];
	}
}
