import 'package:get/get.dart';
import 'package:folha/app/controller/inss_controller.dart';
import 'package:folha/app/data/provider/api/inss_api_provider.dart';
import 'package:folha/app/data/provider/drift/inss_drift_provider.dart';
import 'package:folha/app/data/repository/inss_repository.dart';

class InssBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<InssController>(() => InssController(
					repository: InssRepository(inssApiProvider: InssApiProvider(), inssDriftProvider: InssDriftProvider()))),
		];
	}
}
