import 'package:get/get.dart';
import 'package:folha/app/controller/sefip_codigo_recolhimento_controller.dart';
import 'package:folha/app/data/provider/api/sefip_codigo_recolhimento_api_provider.dart';
import 'package:folha/app/data/provider/drift/sefip_codigo_recolhimento_drift_provider.dart';
import 'package:folha/app/data/repository/sefip_codigo_recolhimento_repository.dart';

class SefipCodigoRecolhimentoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<SefipCodigoRecolhimentoController>(() => SefipCodigoRecolhimentoController(
					repository: SefipCodigoRecolhimentoRepository(sefipCodigoRecolhimentoApiProvider: SefipCodigoRecolhimentoApiProvider(), sefipCodigoRecolhimentoDriftProvider: SefipCodigoRecolhimentoDriftProvider()))),
		];
	}
}
