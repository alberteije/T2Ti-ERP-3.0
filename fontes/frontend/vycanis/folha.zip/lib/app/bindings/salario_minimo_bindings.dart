import 'package:get/get.dart';
import 'package:folha/app/controller/salario_minimo_controller.dart';
import 'package:folha/app/data/provider/api/salario_minimo_api_provider.dart';
import 'package:folha/app/data/provider/drift/salario_minimo_drift_provider.dart';
import 'package:folha/app/data/repository/salario_minimo_repository.dart';

class SalarioMinimoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<SalarioMinimoController>(() => SalarioMinimoController(
					repository: SalarioMinimoRepository(salarioMinimoApiProvider: SalarioMinimoApiProvider(), salarioMinimoDriftProvider: SalarioMinimoDriftProvider()))),
		];
	}
}
