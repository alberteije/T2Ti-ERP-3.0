import 'package:get/get.dart';
import 'package:folha/app/controller/fpas_controller.dart';
import 'package:folha/app/data/provider/api/fpas_api_provider.dart';
import 'package:folha/app/data/provider/drift/fpas_drift_provider.dart';
import 'package:folha/app/data/repository/fpas_repository.dart';

class FpasBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<FpasController>(() => FpasController(
					repository: FpasRepository(fpasApiProvider: FpasApiProvider(), fpasDriftProvider: FpasDriftProvider()))),
		];
	}
}
