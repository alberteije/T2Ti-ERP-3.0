import 'package:get/get.dart';
import 'package:folha/app/controller/irrf_controller.dart';
import 'package:folha/app/data/provider/api/irrf_api_provider.dart';
import 'package:folha/app/data/provider/drift/irrf_drift_provider.dart';
import 'package:folha/app/data/repository/irrf_repository.dart';

class IrrfBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<IrrfController>(() => IrrfController(
					repository: IrrfRepository(irrfApiProvider: IrrfApiProvider(), irrfDriftProvider: IrrfDriftProvider()))),
		];
	}
}
