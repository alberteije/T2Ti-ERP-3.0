import 'package:get/get.dart';
import 'package:folha/app/controller/sefip_categoria_trabalho_controller.dart';
import 'package:folha/app/data/provider/api/sefip_categoria_trabalho_api_provider.dart';
import 'package:folha/app/data/provider/drift/sefip_categoria_trabalho_drift_provider.dart';
import 'package:folha/app/data/repository/sefip_categoria_trabalho_repository.dart';

class SefipCategoriaTrabalhoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<SefipCategoriaTrabalhoController>(() => SefipCategoriaTrabalhoController(
					repository: SefipCategoriaTrabalhoRepository(sefipCategoriaTrabalhoApiProvider: SefipCategoriaTrabalhoApiProvider(), sefipCategoriaTrabalhoDriftProvider: SefipCategoriaTrabalhoDriftProvider()))),
		];
	}
}
