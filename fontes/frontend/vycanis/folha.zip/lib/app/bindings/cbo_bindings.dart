import 'package:get/get.dart';
import 'package:folha/app/controller/cbo_controller.dart';
import 'package:folha/app/data/provider/api/cbo_api_provider.dart';
import 'package:folha/app/data/provider/drift/cbo_drift_provider.dart';
import 'package:folha/app/data/repository/cbo_repository.dart';

class CboBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CboController>(() => CboController(
					repository: CboRepository(cboApiProvider: CboApiProvider(), cboDriftProvider: CboDriftProvider()))),
		];
	}
}
