import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_vale_transporte_repository.dart';

class FolhaValeTransporteController extends ControllerBase<FolhaValeTransporteModel, FolhaValeTransporteRepository> {

  FolhaValeTransporteController({required super.repository}) {
    dbColumns = FolhaValeTransporteModel.dbColumns;
    aliasColumns = FolhaValeTransporteModel.aliasColumns;
    gridColumns = folhaValeTransporteGridColumns();
    functionName = "folha_vale_transporte";
    screenTitle = "Vale Transporte";
  }

  @override
  FolhaValeTransporteModel createNewModel() => FolhaValeTransporteModel();

  @override
  final standardFieldForFilter = FolhaValeTransporteModel.aliasColumns[FolhaValeTransporteModel.dbColumns.indexOf('quantidade')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final empresaTransporteItinerarioModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaValeTransporte) => folhaValeTransporte.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaValeTransporteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    empresaTransporteItinerarioModelController.text = '';
    quantidadeController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaValeTransporteEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    empresaTransporteItinerarioModelController.text = currentModel.empresaTransporteItinerarioModel?.nome?.toString() ?? '';
    quantidadeController.updateValue((currentModel.quantidade ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaValeTransporteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callEmpresaTransporteItinerarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Itinerario]'; 
		lookupController.route = '/empresa-transporte-itinerario/'; 
		lookupController.gridColumns = empresaTransporteItinerarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = EmpresaTransporteItinerarioModel.aliasColumns; 
		lookupController.dbColumns = EmpresaTransporteItinerarioModel.dbColumns; 
		lookupController.standardColumn = EmpresaTransporteItinerarioModel.aliasColumns[EmpresaTransporteItinerarioModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idEmpresaTranspItin = plutoRowResult.cells['id']!.value; 
			currentModel.empresaTransporteItinerarioModel = EmpresaTransporteItinerarioModel.fromPlutoRow(plutoRowResult); 
			empresaTransporteItinerarioModelController.text = currentModel.empresaTransporteItinerarioModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    empresaTransporteItinerarioModelController.dispose();
    quantidadeController.dispose();
    super.onClose();
  }

}