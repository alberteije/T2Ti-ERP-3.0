import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_inss_servico_repository.dart';

class FolhaInssServicoController extends ControllerBase<FolhaInssServicoModel, FolhaInssServicoRepository> {

  FolhaInssServicoController({required super.repository}) {
    dbColumns = FolhaInssServicoModel.dbColumns;
    aliasColumns = FolhaInssServicoModel.aliasColumns;
    gridColumns = folhaInssServicoGridColumns();
    functionName = "folha_inss_servico";
    screenTitle = "Serviços";
  }

  @override
  FolhaInssServicoModel createNewModel() => FolhaInssServicoModel();

  @override
  final standardFieldForFilter = FolhaInssServicoModel.aliasColumns[FolhaInssServicoModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaInssServico) => folhaInssServico.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaInssServicoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaInssServicoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaInssServicoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}