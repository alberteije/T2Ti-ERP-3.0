import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaPppAtividadeController extends ControllerBase<FolhaPppAtividadeModel, void> {

  FolhaPppAtividadeController() : super(repository: null) {
    dbColumns = FolhaPppAtividadeModel.dbColumns;
    aliasColumns = FolhaPppAtividadeModel.aliasColumns;
    gridColumns = folhaPppAtividadeGridColumns();
    functionName = "folha_ppp_atividade";
    screenTitle = "Atividade";
  }

  final _folhaPppAtividadeModel = FolhaPppAtividadeModel().obs;
  FolhaPppAtividadeModel get folhaPppAtividadeModel => _folhaPppAtividadeModel.value;
  set folhaPppAtividadeModel(value) => _folhaPppAtividadeModel.value = value ?? FolhaPppAtividadeModel();

  List<FolhaPppAtividadeModel> get folhaPppAtividadeModelList => Get.find<FolhaPppController>().currentModel.folhaPppAtividadeModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final folhaPppAtividadeScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaPppAtividadeFormKey = GlobalKey<FormState>();

  @override
  FolhaPppAtividadeModel createNewModel() => FolhaPppAtividadeModel();

  @override
  final standardFieldForFilter = FolhaPppAtividadeModel.aliasColumns[FolhaPppAtividadeModel.dbColumns.indexOf('data_inicio')];

  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaPppAtividade) => folhaPppAtividade.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(folhaPppAtividadeModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    folhaPppAtividadeModel = createNewModel();
    _resetForm();
    Get.to(() => FolhaPppAtividadeEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataInicioController.date = null;
    dataFimController.date = null;
    descricaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = folhaPppAtividadeModelList.firstWhere((m) => m.tempId == tempId);
    folhaPppAtividadeModel = model.clone();
		folhaPppAtividadeModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FolhaPppAtividadeEditPage());
  }

  void updateControllersFromModel() {
    dataInicioController.date = folhaPppAtividadeModel.dataInicio;
    dataFimController.date = folhaPppAtividadeModel.dataFim;
    descricaoController.text = folhaPppAtividadeModel.descricao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!folhaPppAtividadeFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        folhaPppAtividadeModelList.insert(0, folhaPppAtividadeModel.clone());
      } else {
        final index = folhaPppAtividadeModelList.indexWhere((m) => m.tempId == folhaPppAtividadeModel.tempId);
        if (index >= 0) {
          folhaPppAtividadeModelList[index] = folhaPppAtividadeModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      folhaPppAtividadeModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataInicioController.dispose();
    dataFimController.dispose();
    descricaoController.dispose();
  }

}