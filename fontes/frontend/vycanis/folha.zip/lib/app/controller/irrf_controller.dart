import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/irrf_repository.dart';

class IrrfController extends ControllerBase<IrrfModel, IrrfRepository> 
with GetSingleTickerProviderStateMixin {

  IrrfController({required super.repository}) {
    dbColumns = IrrfModel.dbColumns;
    aliasColumns = IrrfModel.aliasColumns;
    gridColumns = irrfGridColumns();
    functionName = "irrf";
    screenTitle = "Imposto de Renda";
  }

  final irrfScaffoldKey = GlobalKey<ScaffoldState>();
  final irrfTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final irrfFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  IrrfModel createNewModel() => IrrfModel();

  @override
  final standardFieldForFilter = IrrfModel.aliasColumns[IrrfModel.dbColumns.indexOf('competencia')];

  final competenciaController = MaskedTextController(mask: '00/0000',);
  final descontoPorDependenteController = MoneyMaskedTextController();
  final minimoParaRetencaoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['desconto_por_dependente'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((irrf) => irrf.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.irrfTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    competenciaController.text = '';
    descontoPorDependenteController.updateValue(0);
    minimoParaRetencaoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.irrfTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<IrrfDetalheController>(IrrfDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<IrrfDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    competenciaController.text = currentModel.competencia ?? '';
    descontoPorDependenteController.updateValue(currentModel.descontoPorDependente ?? 0);
    minimoParaRetencaoController.updateValue(currentModel.minimoParaRetencao ?? 0);

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final irrfDetalheController = Get.find<IrrfDetalheController>(); 
		irrfDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(irrfModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Imposto de Renda', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      IrrfEditPage(),
      const IrrfDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<IrrfDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    competenciaController.dispose();
    descontoPorDependenteController.dispose();
    minimoParaRetencaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}