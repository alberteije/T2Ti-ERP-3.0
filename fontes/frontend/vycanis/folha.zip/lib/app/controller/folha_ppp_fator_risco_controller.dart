import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaPppFatorRiscoController extends ControllerBase<FolhaPppFatorRiscoModel, void> {

  FolhaPppFatorRiscoController() : super(repository: null) {
    dbColumns = FolhaPppFatorRiscoModel.dbColumns;
    aliasColumns = FolhaPppFatorRiscoModel.aliasColumns;
    gridColumns = folhaPppFatorRiscoGridColumns();
    functionName = "folha_ppp_fator_risco";
    screenTitle = "Fator de Risco";
  }

  final _folhaPppFatorRiscoModel = FolhaPppFatorRiscoModel().obs;
  FolhaPppFatorRiscoModel get folhaPppFatorRiscoModel => _folhaPppFatorRiscoModel.value;
  set folhaPppFatorRiscoModel(value) => _folhaPppFatorRiscoModel.value = value ?? FolhaPppFatorRiscoModel();

  List<FolhaPppFatorRiscoModel> get folhaPppFatorRiscoModelList => Get.find<FolhaPppController>().currentModel.folhaPppFatorRiscoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final folhaPppFatorRiscoScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaPppFatorRiscoFormKey = GlobalKey<FormState>();

  @override
  FolhaPppFatorRiscoModel createNewModel() => FolhaPppFatorRiscoModel();

  @override
  final standardFieldForFilter = FolhaPppFatorRiscoModel.aliasColumns[FolhaPppFatorRiscoModel.dbColumns.indexOf('data_inicio')];

  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final tipoController = CustomDropdownButtonController('F=Físico');
  final fatorRiscoController = TextEditingController();
  final intensidadeController = TextEditingController();
  final tecnicaUtilizadaController = TextEditingController();
  final epcEficazController = CustomDropdownButtonController('Sim');
  final epiEficazController = CustomDropdownButtonController('Sim');
  final caEpiController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final atendimentoNr061Controller = CustomDropdownButtonController('Sim');
  final atendimentoNr062Controller = CustomDropdownButtonController('Sim');
  final atendimentoNr063Controller = CustomDropdownButtonController('Sim');
  final atendimentoNr064Controller = CustomDropdownButtonController('Sim');
  final atendimentoNr065Controller = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaPppFatorRisco) => folhaPppFatorRisco.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(folhaPppFatorRiscoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    folhaPppFatorRiscoModel = createNewModel();
    _resetForm();
    Get.to(() => FolhaPppFatorRiscoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataInicioController.date = null;
    dataFimController.date = null;
    tipoController.selected = 'F=Físico';
    fatorRiscoController.text = '';
    intensidadeController.text = '';
    tecnicaUtilizadaController.text = '';
    epcEficazController.selected = 'Sim';
    epiEficazController.selected = 'Sim';
    caEpiController.updateValue(0);
    atendimentoNr061Controller.selected = 'Sim';
    atendimentoNr062Controller.selected = 'Sim';
    atendimentoNr063Controller.selected = 'Sim';
    atendimentoNr064Controller.selected = 'Sim';
    atendimentoNr065Controller.selected = 'Sim';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = folhaPppFatorRiscoModelList.firstWhere((m) => m.tempId == tempId);
    folhaPppFatorRiscoModel = model.clone();
		folhaPppFatorRiscoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FolhaPppFatorRiscoEditPage());
  }

  void updateControllersFromModel() {
    dataInicioController.date = folhaPppFatorRiscoModel.dataInicio;
    dataFimController.date = folhaPppFatorRiscoModel.dataFim;
    tipoController.selected = folhaPppFatorRiscoModel.tipo ?? 'F=Físico';
    fatorRiscoController.text = folhaPppFatorRiscoModel.fatorRisco ?? '';
    intensidadeController.text = folhaPppFatorRiscoModel.intensidade ?? '';
    tecnicaUtilizadaController.text = folhaPppFatorRiscoModel.tecnicaUtilizada ?? '';
    epcEficazController.selected = folhaPppFatorRiscoModel.epcEficaz ?? 'Sim';
    epiEficazController.selected = folhaPppFatorRiscoModel.epiEficaz ?? 'Sim';
    caEpiController.updateValue((folhaPppFatorRiscoModel.caEpi ?? 0).toDouble());
    atendimentoNr061Controller.selected = folhaPppFatorRiscoModel.atendimentoNr061 ?? 'Sim';
    atendimentoNr062Controller.selected = folhaPppFatorRiscoModel.atendimentoNr062 ?? 'Sim';
    atendimentoNr063Controller.selected = folhaPppFatorRiscoModel.atendimentoNr063 ?? 'Sim';
    atendimentoNr064Controller.selected = folhaPppFatorRiscoModel.atendimentoNr064 ?? 'Sim';
    atendimentoNr065Controller.selected = folhaPppFatorRiscoModel.atendimentoNr065 ?? 'Sim';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!folhaPppFatorRiscoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        folhaPppFatorRiscoModelList.insert(0, folhaPppFatorRiscoModel.clone());
      } else {
        final index = folhaPppFatorRiscoModelList.indexWhere((m) => m.tempId == folhaPppFatorRiscoModel.tempId);
        if (index >= 0) {
          folhaPppFatorRiscoModelList[index] = folhaPppFatorRiscoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      folhaPppFatorRiscoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataInicioController.dispose();
    dataFimController.dispose();
    tipoController.dispose();
    fatorRiscoController.dispose();
    intensidadeController.dispose();
    tecnicaUtilizadaController.dispose();
    epcEficazController.dispose();
    epiEficazController.dispose();
    caEpiController.dispose();
    atendimentoNr061Controller.dispose();
    atendimentoNr062Controller.dispose();
    atendimentoNr063Controller.dispose();
    atendimentoNr064Controller.dispose();
    atendimentoNr065Controller.dispose();
  }

}