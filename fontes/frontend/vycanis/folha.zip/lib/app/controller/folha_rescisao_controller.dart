import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_rescisao_repository.dart';

class FolhaRescisaoController extends ControllerBase<FolhaRescisaoModel, FolhaRescisaoRepository> {

  FolhaRescisaoController({required super.repository}) {
    dbColumns = FolhaRescisaoModel.dbColumns;
    aliasColumns = FolhaRescisaoModel.aliasColumns;
    gridColumns = folhaRescisaoGridColumns();
    functionName = "folha_rescisao";
    screenTitle = "Rescisão";
  }

  @override
  FolhaRescisaoModel createNewModel() => FolhaRescisaoModel();

  @override
  final standardFieldForFilter = FolhaRescisaoModel.aliasColumns[FolhaRescisaoModel.dbColumns.indexOf('data_demissao')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final dataDemissaoController = DatePickerItemController(null);
  final dataPagamentoController = DatePickerItemController(null);
  final motivoController = TextEditingController();
  final motivoEsocialController = TextEditingController();
  final dataAvisoPrevioController = DatePickerItemController(null);
  final diasAvisoPrevioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final comprovouNovoEmpregoController = CustomDropdownButtonController('Sim');
  final dispensouEmpregadoController = CustomDropdownButtonController('Sim');
  final pensaoAlimenticiaController = MoneyMaskedTextController();
  final pensaoAlimenticiaFgtsController = MoneyMaskedTextController();
  final fgtsValorRescisaoController = MoneyMaskedTextController();
  final fgtsSaldoBancoController = MoneyMaskedTextController();
  final fgtsComplementoSaldoController = MoneyMaskedTextController();
  final fgtsCodigoAfastamentoController = TextEditingController();
  final fgtsCodigoSaqueController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_demissao'],
    'secondaryColumns': ['data_pagamento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaRescisao) => folhaRescisao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaRescisaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    dataDemissaoController.date = null;
    dataPagamentoController.date = null;
    motivoController.text = '';
    motivoEsocialController.text = '';
    dataAvisoPrevioController.date = null;
    diasAvisoPrevioController.updateValue(0);
    comprovouNovoEmpregoController.selected = 'Sim';
    dispensouEmpregadoController.selected = 'Sim';
    pensaoAlimenticiaController.updateValue(0);
    pensaoAlimenticiaFgtsController.updateValue(0);
    fgtsValorRescisaoController.updateValue(0);
    fgtsSaldoBancoController.updateValue(0);
    fgtsComplementoSaldoController.updateValue(0);
    fgtsCodigoAfastamentoController.text = '';
    fgtsCodigoSaqueController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaRescisaoEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataDemissaoController.date = currentModel.dataDemissao;
    dataPagamentoController.date = currentModel.dataPagamento;
    motivoController.text = currentModel.motivo ?? '';
    motivoEsocialController.text = currentModel.motivoEsocial ?? '';
    dataAvisoPrevioController.date = currentModel.dataAvisoPrevio;
    diasAvisoPrevioController.updateValue((currentModel.diasAvisoPrevio ?? 0).toDouble());
    comprovouNovoEmpregoController.selected = currentModel.comprovouNovoEmprego ?? 'Sim';
    dispensouEmpregadoController.selected = currentModel.dispensouEmpregado ?? 'Sim';
    pensaoAlimenticiaController.updateValue(currentModel.pensaoAlimenticia ?? 0);
    pensaoAlimenticiaFgtsController.updateValue(currentModel.pensaoAlimenticiaFgts ?? 0);
    fgtsValorRescisaoController.updateValue(currentModel.fgtsValorRescisao ?? 0);
    fgtsSaldoBancoController.updateValue(currentModel.fgtsSaldoBanco ?? 0);
    fgtsComplementoSaldoController.updateValue(currentModel.fgtsComplementoSaldo ?? 0);
    fgtsCodigoAfastamentoController.text = currentModel.fgtsCodigoAfastamento ?? '';
    fgtsCodigoSaqueController.text = currentModel.fgtsCodigoSaque ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaRescisaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    dataDemissaoController.dispose();
    dataPagamentoController.dispose();
    motivoController.dispose();
    motivoEsocialController.dispose();
    dataAvisoPrevioController.dispose();
    diasAvisoPrevioController.dispose();
    comprovouNovoEmpregoController.dispose();
    dispensouEmpregadoController.dispose();
    pensaoAlimenticiaController.dispose();
    pensaoAlimenticiaFgtsController.dispose();
    fgtsValorRescisaoController.dispose();
    fgtsSaldoBancoController.dispose();
    fgtsComplementoSaldoController.dispose();
    fgtsCodigoAfastamentoController.dispose();
    fgtsCodigoSaqueController.dispose();
    super.onClose();
  }

}