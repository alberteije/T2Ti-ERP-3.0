import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/routes/app_routes.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaInssRetencaoController extends ControllerBase<FolhaInssRetencaoModel, void> {

  FolhaInssRetencaoController() : super(repository: null) {
    dbColumns = FolhaInssRetencaoModel.dbColumns;
    aliasColumns = FolhaInssRetencaoModel.aliasColumns;
    gridColumns = folhaInssRetencaoGridColumns();
    functionName = "folha_inss_retencao";
    screenTitle = "Retenções";
  }

  final _folhaInssRetencaoModel = FolhaInssRetencaoModel().obs;
  FolhaInssRetencaoModel get folhaInssRetencaoModel => _folhaInssRetencaoModel.value;
  set folhaInssRetencaoModel(value) => _folhaInssRetencaoModel.value = value ?? FolhaInssRetencaoModel();

  List<FolhaInssRetencaoModel> get folhaInssRetencaoModelList => Get.find<FolhaInssController>().currentModel.folhaInssRetencaoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final folhaInssRetencaoScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaInssRetencaoFormKey = GlobalKey<FormState>();

  @override
  FolhaInssRetencaoModel createNewModel() => FolhaInssRetencaoModel();

  @override
  final standardFieldForFilter = FolhaInssRetencaoModel.aliasColumns[FolhaInssRetencaoModel.dbColumns.indexOf('valor_mensal')];

  final folhaInssServicoModelController = TextEditingController();
  final valorMensalController = MoneyMaskedTextController();
  final valor13Controller = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['valor_mensal'],
    'secondaryColumns': ['valor_13'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaInssRetencao) => folhaInssRetencao.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(folhaInssRetencaoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    folhaInssRetencaoModel = createNewModel();
    _resetForm();
    Get.to(() => FolhaInssRetencaoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    folhaInssServicoModelController.text = '';
    valorMensalController.updateValue(0);
    valor13Controller.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = folhaInssRetencaoModelList.firstWhere((m) => m.tempId == tempId);
    folhaInssRetencaoModel = model.clone();
		folhaInssRetencaoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FolhaInssRetencaoEditPage());
  }

  void updateControllersFromModel() {
    folhaInssServicoModelController.text = folhaInssRetencaoModel.folhaInssServicoModel?.nome?.toString() ?? '';
    valorMensalController.updateValue(folhaInssRetencaoModel.valorMensal ?? 0);
    valor13Controller.updateValue(folhaInssRetencaoModel.valor13 ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!folhaInssRetencaoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        folhaInssRetencaoModelList.insert(0, folhaInssRetencaoModel.clone());
      } else {
        final index = folhaInssRetencaoModelList.indexWhere((m) => m.tempId == folhaInssRetencaoModel.tempId);
        if (index >= 0) {
          folhaInssRetencaoModelList[index] = folhaInssRetencaoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callFolhaInssServicoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Serviço INSS]'; 
		lookupController.route = '/folha-inss-servico/'; 
		lookupController.gridColumns = folhaInssServicoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FolhaInssServicoModel.aliasColumns; 
		lookupController.dbColumns = FolhaInssServicoModel.dbColumns; 
		lookupController.standardColumn = FolhaInssServicoModel.aliasColumns[FolhaInssServicoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			folhaInssRetencaoModel.idFolhaInssServico = plutoRowResult.cells['id']!.value; 
			folhaInssRetencaoModel.folhaInssServicoModel = FolhaInssServicoModel.fromPlutoRow(plutoRowResult); 
			folhaInssServicoModelController.text = folhaInssRetencaoModel.folhaInssServicoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      folhaInssRetencaoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    folhaInssServicoModelController.dispose();
    valorMensalController.dispose();
    valor13Controller.dispose();
  }

}