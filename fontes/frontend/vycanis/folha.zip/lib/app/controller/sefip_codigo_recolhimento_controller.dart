import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/sefip_codigo_recolhimento_repository.dart';

class SefipCodigoRecolhimentoController extends ControllerBase<SefipCodigoRecolhimentoModel, SefipCodigoRecolhimentoRepository> {

  SefipCodigoRecolhimentoController({required super.repository}) {
    dbColumns = SefipCodigoRecolhimentoModel.dbColumns;
    aliasColumns = SefipCodigoRecolhimentoModel.aliasColumns;
    gridColumns = sefipCodigoRecolhimentoGridColumns();
    functionName = "sefip_codigo_recolhimento";
    screenTitle = "SEFIP - Código Recolhimento";
  }

  @override
  SefipCodigoRecolhimentoModel createNewModel() => SefipCodigoRecolhimentoModel();

  @override
  final standardFieldForFilter = SefipCodigoRecolhimentoModel.aliasColumns[SefipCodigoRecolhimentoModel.dbColumns.indexOf('codigo')];

  final codigoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final descricaoController = TextEditingController();
  final aplicacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((sefipCodigoRecolhimento) => sefipCodigoRecolhimento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.sefipCodigoRecolhimentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.updateValue(0);
    descricaoController.text = '';
    aplicacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.sefipCodigoRecolhimentoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.updateValue((currentModel.codigo ?? 0).toDouble());
    descricaoController.text = currentModel.descricao ?? '';
    aplicacaoController.text = currentModel.aplicacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(sefipCodigoRecolhimentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    descricaoController.dispose();
    aplicacaoController.dispose();
    super.onClose();
  }

}