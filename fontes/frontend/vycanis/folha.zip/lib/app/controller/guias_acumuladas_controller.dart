import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/guias_acumuladas_repository.dart';

class GuiasAcumuladasController extends ControllerBase<GuiasAcumuladasModel, GuiasAcumuladasRepository> {

  GuiasAcumuladasController({required super.repository}) {
    dbColumns = GuiasAcumuladasModel.dbColumns;
    aliasColumns = GuiasAcumuladasModel.aliasColumns;
    gridColumns = guiasAcumuladasGridColumns();
    functionName = "guias_acumuladas";
    screenTitle = "Guias Acumuladas";
  }

  @override
  GuiasAcumuladasModel createNewModel() => GuiasAcumuladasModel();

  @override
  final standardFieldForFilter = GuiasAcumuladasModel.aliasColumns[GuiasAcumuladasModel.dbColumns.indexOf('gps_tipo')];

  final gpsTipoController = CustomDropdownButtonController('1-Filial própia empresa');
  final gpsCompetenciaController = MaskedTextController(mask: '00/0000',);
  final gpsValorInssController = MoneyMaskedTextController();
  final gpsValorOutrasEntController = MoneyMaskedTextController();
  final gpsDataPagamentoController = DatePickerItemController(null);
  final irrfCompetenciaController = MaskedTextController(mask: '00/0000',);
  final irrfCodigoRecolhimentoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final irrfValorAcumuladoController = MoneyMaskedTextController();
  final irrfDataPagamentoController = DatePickerItemController(null);
  final pisCompetenciaController = MaskedTextController(mask: '00/0000',);
  final pisValorAcumuladoController = MoneyMaskedTextController();
  final pisDataPagamentoController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['gps_tipo'],
    'secondaryColumns': ['gps_competencia'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((guiasAcumuladas) => guiasAcumuladas.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.guiasAcumuladasEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    gpsTipoController.selected = '1-Filial própia empresa';
    gpsCompetenciaController.text = '';
    gpsValorInssController.updateValue(0);
    gpsValorOutrasEntController.updateValue(0);
    gpsDataPagamentoController.date = null;
    irrfCompetenciaController.text = '';
    irrfCodigoRecolhimentoController.updateValue(0);
    irrfValorAcumuladoController.updateValue(0);
    irrfDataPagamentoController.date = null;
    pisCompetenciaController.text = '';
    pisValorAcumuladoController.updateValue(0);
    pisDataPagamentoController.date = null;
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.guiasAcumuladasEditPage);
  }

  void updateControllersFromModel() {
    gpsTipoController.selected = currentModel.gpsTipo ?? '1-Filial própia empresa';
    gpsCompetenciaController.text = currentModel.gpsCompetencia ?? '';
    gpsValorInssController.updateValue(currentModel.gpsValorInss ?? 0);
    gpsValorOutrasEntController.updateValue(currentModel.gpsValorOutrasEnt ?? 0);
    gpsDataPagamentoController.date = currentModel.gpsDataPagamento;
    irrfCompetenciaController.text = currentModel.irrfCompetencia ?? '';
    irrfCodigoRecolhimentoController.updateValue((currentModel.irrfCodigoRecolhimento ?? 0).toDouble());
    irrfValorAcumuladoController.updateValue(currentModel.irrfValorAcumulado ?? 0);
    irrfDataPagamentoController.date = currentModel.irrfDataPagamento;
    pisCompetenciaController.text = currentModel.pisCompetencia ?? '';
    pisValorAcumuladoController.updateValue(currentModel.pisValorAcumulado ?? 0);
    pisDataPagamentoController.date = currentModel.pisDataPagamento;
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(guiasAcumuladasModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    gpsTipoController.dispose();
    gpsCompetenciaController.dispose();
    gpsValorInssController.dispose();
    gpsValorOutrasEntController.dispose();
    gpsDataPagamentoController.dispose();
    irrfCompetenciaController.dispose();
    irrfCodigoRecolhimentoController.dispose();
    irrfValorAcumuladoController.dispose();
    irrfDataPagamentoController.dispose();
    pisCompetenciaController.dispose();
    pisValorAcumuladoController.dispose();
    pisDataPagamentoController.dispose();
    super.onClose();
  }

}