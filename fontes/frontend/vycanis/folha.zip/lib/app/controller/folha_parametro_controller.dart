import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_parametro_repository.dart';

class FolhaParametroController extends ControllerBase<FolhaParametroModel, FolhaParametroRepository> {

  FolhaParametroController({required super.repository}) {
    dbColumns = FolhaParametroModel.dbColumns;
    aliasColumns = FolhaParametroModel.aliasColumns;
    gridColumns = folhaParametroGridColumns();
    functionName = "folha_parametro";
    screenTitle = "Parâmetros";
  }

  @override
  FolhaParametroModel createNewModel() => FolhaParametroModel();

  @override
  final standardFieldForFilter = FolhaParametroModel.aliasColumns[FolhaParametroModel.dbColumns.indexOf('competencia')];

  final competenciaController = MaskedTextController(mask: '00/0000',);
  final contribuiPisController = CustomDropdownButtonController('Sim');
  final aliquotaPisController = MoneyMaskedTextController();
  final discriminarDsrController = CustomDropdownButtonController('Sim');
  final diaPagamentoController = TextEditingController();
  final calculoProporcionalidadeController = CustomDropdownButtonController('30 Dias');
  final descontarFaltas13Controller = CustomDropdownButtonController('Sim');
  final pagarAdicionais13Controller = CustomDropdownButtonController('Sim');
  final pagarEstagiarios13Controller = CustomDropdownButtonController('Sim');
  final mesAdiantamento13Controller = TextEditingController();
  final percentualAdiantam13Controller = MoneyMaskedTextController();
  final feriasDescontarFaltasController = CustomDropdownButtonController('Sim');
  final feriasPagarAdicionaisController = CustomDropdownButtonController('Sim');
  final feriasAdiantar13Controller = CustomDropdownButtonController('Sim');
  final feriasPagarEstagiariosController = CustomDropdownButtonController('Sim');
  final feriasCalcJustaCausaController = CustomDropdownButtonController('Sim');
  final feriasMovimentoMensalController = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['contribui_pis'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaParametro) => folhaParametro.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaParametroEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    competenciaController.text = '';
    contribuiPisController.selected = 'Sim';
    aliquotaPisController.updateValue(0);
    discriminarDsrController.selected = 'Sim';
    diaPagamentoController.text = '';
    calculoProporcionalidadeController.selected = '30 Dias';
    descontarFaltas13Controller.selected = 'Sim';
    pagarAdicionais13Controller.selected = 'Sim';
    pagarEstagiarios13Controller.selected = 'Sim';
    mesAdiantamento13Controller.text = '';
    percentualAdiantam13Controller.updateValue(0);
    feriasDescontarFaltasController.selected = 'Sim';
    feriasPagarAdicionaisController.selected = 'Sim';
    feriasAdiantar13Controller.selected = 'Sim';
    feriasPagarEstagiariosController.selected = 'Sim';
    feriasCalcJustaCausaController.selected = 'Sim';
    feriasMovimentoMensalController.selected = 'Sim';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaParametroEditPage);
  }

  void updateControllersFromModel() {
    competenciaController.text = currentModel.competencia ?? '';
    contribuiPisController.selected = currentModel.contribuiPis ?? 'Sim';
    aliquotaPisController.updateValue(currentModel.aliquotaPis ?? 0);
    discriminarDsrController.selected = currentModel.discriminarDsr ?? 'Sim';
    diaPagamentoController.text = currentModel.diaPagamento ?? '';
    calculoProporcionalidadeController.selected = currentModel.calculoProporcionalidade ?? '30 Dias';
    descontarFaltas13Controller.selected = currentModel.descontarFaltas13 ?? 'Sim';
    pagarAdicionais13Controller.selected = currentModel.pagarAdicionais13 ?? 'Sim';
    pagarEstagiarios13Controller.selected = currentModel.pagarEstagiarios13 ?? 'Sim';
    mesAdiantamento13Controller.text = currentModel.mesAdiantamento13 ?? '';
    percentualAdiantam13Controller.updateValue(currentModel.percentualAdiantam13 ?? 0);
    feriasDescontarFaltasController.selected = currentModel.feriasDescontarFaltas ?? 'Sim';
    feriasPagarAdicionaisController.selected = currentModel.feriasPagarAdicionais ?? 'Sim';
    feriasAdiantar13Controller.selected = currentModel.feriasAdiantar13 ?? 'Sim';
    feriasPagarEstagiariosController.selected = currentModel.feriasPagarEstagiarios ?? 'Sim';
    feriasCalcJustaCausaController.selected = currentModel.feriasCalcJustaCausa ?? 'Sim';
    feriasMovimentoMensalController.selected = currentModel.feriasMovimentoMensal ?? 'Sim';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaParametroModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    competenciaController.dispose();
    contribuiPisController.dispose();
    aliquotaPisController.dispose();
    discriminarDsrController.dispose();
    diaPagamentoController.dispose();
    calculoProporcionalidadeController.dispose();
    descontarFaltas13Controller.dispose();
    pagarAdicionais13Controller.dispose();
    pagarEstagiarios13Controller.dispose();
    mesAdiantamento13Controller.dispose();
    percentualAdiantam13Controller.dispose();
    feriasDescontarFaltasController.dispose();
    feriasPagarAdicionaisController.dispose();
    feriasAdiantar13Controller.dispose();
    feriasPagarEstagiariosController.dispose();
    feriasCalcJustaCausaController.dispose();
    feriasMovimentoMensalController.dispose();
    super.onClose();
  }

}