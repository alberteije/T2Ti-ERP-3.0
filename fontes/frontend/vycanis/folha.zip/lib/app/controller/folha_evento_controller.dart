import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_evento_repository.dart';

class FolhaEventoController extends ControllerBase<FolhaEventoModel, FolhaEventoRepository> {

  FolhaEventoController({required super.repository}) {
    dbColumns = FolhaEventoModel.dbColumns;
    aliasColumns = FolhaEventoModel.aliasColumns;
    gridColumns = folhaEventoGridColumns();
    functionName = "folha_evento";
    screenTitle = "Eventos";
  }

  @override
  FolhaEventoModel createNewModel() => FolhaEventoModel();

  @override
  final standardFieldForFilter = FolhaEventoModel.aliasColumns[FolhaEventoModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final baseCalculoController = CustomDropdownButtonController('1=Salário contratual: define que a base de cálculo deve ser calculada sobre o valor do salário contratual');
  final tipoController = CustomDropdownButtonController('Provento');
  final unidadeController = CustomDropdownButtonController('Valor');
  final taxaController = MoneyMaskedTextController();
  final rubricaEsocialController = TextEditingController();
  final codIncidenciaPrevidenciaController = TextEditingController();
  final codIncidenciaIrrfController = TextEditingController();
  final codIncidenciaFgtsController = TextEditingController();
  final codIncidenciaSindicatoController = TextEditingController();
  final repercuteDsrController = CustomDropdownButtonController('Sim');
  final repercute13Controller = CustomDropdownButtonController('Sim');
  final repercuteFeriasController = CustomDropdownButtonController('Sim');
  final repercuteAvisoController = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaEvento) => folhaEvento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaEventoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    baseCalculoController.selected = '1=Salário contratual: define que a base de cálculo deve ser calculada sobre o valor do salário contratual';
    tipoController.selected = 'Provento';
    unidadeController.selected = 'Valor';
    taxaController.updateValue(0);
    rubricaEsocialController.text = '';
    codIncidenciaPrevidenciaController.text = '';
    codIncidenciaIrrfController.text = '';
    codIncidenciaFgtsController.text = '';
    codIncidenciaSindicatoController.text = '';
    repercuteDsrController.selected = 'Sim';
    repercute13Controller.selected = 'Sim';
    repercuteFeriasController.selected = 'Sim';
    repercuteAvisoController.selected = 'Sim';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaEventoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    baseCalculoController.selected = currentModel.baseCalculo ?? '1=Salário contratual: define que a base de cálculo deve ser calculada sobre o valor do salário contratual';
    tipoController.selected = currentModel.tipo ?? 'Provento';
    unidadeController.selected = currentModel.unidade ?? 'Valor';
    taxaController.updateValue(currentModel.taxa ?? 0);
    rubricaEsocialController.text = currentModel.rubricaEsocial ?? '';
    codIncidenciaPrevidenciaController.text = currentModel.codIncidenciaPrevidencia ?? '';
    codIncidenciaIrrfController.text = currentModel.codIncidenciaIrrf ?? '';
    codIncidenciaFgtsController.text = currentModel.codIncidenciaFgts ?? '';
    codIncidenciaSindicatoController.text = currentModel.codIncidenciaSindicato ?? '';
    repercuteDsrController.selected = currentModel.repercuteDsr ?? 'Sim';
    repercute13Controller.selected = currentModel.repercute13 ?? 'Sim';
    repercuteFeriasController.selected = currentModel.repercuteFerias ?? 'Sim';
    repercuteAvisoController.selected = currentModel.repercuteAviso ?? 'Sim';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaEventoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    baseCalculoController.dispose();
    tipoController.dispose();
    unidadeController.dispose();
    taxaController.dispose();
    rubricaEsocialController.dispose();
    codIncidenciaPrevidenciaController.dispose();
    codIncidenciaIrrfController.dispose();
    codIncidenciaFgtsController.dispose();
    codIncidenciaSindicatoController.dispose();
    repercuteDsrController.dispose();
    repercute13Controller.dispose();
    repercuteFeriasController.dispose();
    repercuteAvisoController.dispose();
    super.onClose();
  }

}