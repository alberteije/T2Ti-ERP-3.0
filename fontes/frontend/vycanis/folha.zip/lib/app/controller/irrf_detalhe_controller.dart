import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class IrrfDetalheController extends ControllerBase<IrrfDetalheModel, void> {

  IrrfDetalheController() : super(repository: null) {
    dbColumns = IrrfDetalheModel.dbColumns;
    aliasColumns = IrrfDetalheModel.aliasColumns;
    gridColumns = irrfDetalheGridColumns();
    functionName = "irrf_detalhe";
    screenTitle = "Detalhes";
  }

  final _irrfDetalheModel = IrrfDetalheModel().obs;
  IrrfDetalheModel get irrfDetalheModel => _irrfDetalheModel.value;
  set irrfDetalheModel(value) => _irrfDetalheModel.value = value ?? IrrfDetalheModel();

  List<IrrfDetalheModel> get irrfDetalheModelList => Get.find<IrrfController>().currentModel.irrfDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final irrfDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final irrfDetalheFormKey = GlobalKey<FormState>();

  @override
  IrrfDetalheModel createNewModel() => IrrfDetalheModel();

  @override
  final standardFieldForFilter = IrrfDetalheModel.aliasColumns[IrrfDetalheModel.dbColumns.indexOf('faixa')];

  final faixaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final deController = MoneyMaskedTextController();
  final ateController = MoneyMaskedTextController();
  final taxaController = MoneyMaskedTextController();
  final descontoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['faixa'],
    'secondaryColumns': ['de'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((irrfDetalhe) => irrfDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(irrfDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    irrfDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => IrrfDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    faixaController.updateValue(0);
    deController.updateValue(0);
    ateController.updateValue(0);
    taxaController.updateValue(0);
    descontoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = irrfDetalheModelList.firstWhere((m) => m.tempId == tempId);
    irrfDetalheModel = model.clone();
		irrfDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => IrrfDetalheEditPage());
  }

  void updateControllersFromModel() {
    faixaController.updateValue((irrfDetalheModel.faixa ?? 0).toDouble());
    deController.updateValue(irrfDetalheModel.de ?? 0);
    ateController.updateValue(irrfDetalheModel.ate ?? 0);
    taxaController.updateValue(irrfDetalheModel.taxa ?? 0);
    descontoController.updateValue(irrfDetalheModel.desconto ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!irrfDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        irrfDetalheModelList.insert(0, irrfDetalheModel.clone());
      } else {
        final index = irrfDetalheModelList.indexWhere((m) => m.tempId == irrfDetalheModel.tempId);
        if (index >= 0) {
          irrfDetalheModelList[index] = irrfDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      irrfDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    faixaController.dispose();
    deController.dispose();
    ateController.dispose();
    taxaController.dispose();
    descontoController.dispose();
  }

}