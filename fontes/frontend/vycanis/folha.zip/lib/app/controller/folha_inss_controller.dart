import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_inss_repository.dart';

class FolhaInssController extends ControllerBase<FolhaInssModel, FolhaInssRepository> 
with GetSingleTickerProviderStateMixin {

  FolhaInssController({required super.repository}) {
    dbColumns = FolhaInssModel.dbColumns;
    aliasColumns = FolhaInssModel.aliasColumns;
    gridColumns = folhaInssGridColumns();
    functionName = "folha_inss";
    screenTitle = "INSS";
  }

  final folhaInssScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaInssTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaInssFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  FolhaInssModel createNewModel() => FolhaInssModel();

  @override
  final standardFieldForFilter = FolhaInssModel.aliasColumns[FolhaInssModel.dbColumns.indexOf('competencia')];

  final competenciaController = MaskedTextController(mask: '00/0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaInss) => folhaInss.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.folhaInssTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    competenciaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.folhaInssTabPage);
  }

  _configureChildrenControllers() {
    //Retenções
		Get.put<FolhaInssRetencaoController>(FolhaInssRetencaoController()); 

  }
	
	_releaseChildrenControllers() {
    //Retenções
		Get.delete<FolhaInssRetencaoController>(); 

	}
  
  void updateControllersFromModel() {
    competenciaController.text = currentModel.competencia ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Retenções
		final folhaInssRetencaoController = Get.find<FolhaInssRetencaoController>(); 
		folhaInssRetencaoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(folhaInssModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'INSS', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Retenções', 
		),
  ];

  List<Widget> tabPages() {
    return [
      FolhaInssEditPage(),
      const FolhaInssRetencaoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<FolhaInssRetencaoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    competenciaController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}