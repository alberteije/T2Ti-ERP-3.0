import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/sefip_categoria_trabalho_repository.dart';

class SefipCategoriaTrabalhoController extends ControllerBase<SefipCategoriaTrabalhoModel, SefipCategoriaTrabalhoRepository> {

  SefipCategoriaTrabalhoController({required super.repository}) {
    dbColumns = SefipCategoriaTrabalhoModel.dbColumns;
    aliasColumns = SefipCategoriaTrabalhoModel.aliasColumns;
    gridColumns = sefipCategoriaTrabalhoGridColumns();
    functionName = "sefip_categoria_trabalho";
    screenTitle = "SEFIP - Categoria Trabalho";
  }

  @override
  SefipCategoriaTrabalhoModel createNewModel() => SefipCategoriaTrabalhoModel();

  @override
  final standardFieldForFilter = SefipCategoriaTrabalhoModel.aliasColumns[SefipCategoriaTrabalhoModel.dbColumns.indexOf('codigo')];

  final codigoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((sefipCategoriaTrabalho) => sefipCategoriaTrabalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.sefipCategoriaTrabalhoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.updateValue(0);
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.sefipCategoriaTrabalhoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.updateValue((currentModel.codigo ?? 0).toDouble());
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(sefipCategoriaTrabalhoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}