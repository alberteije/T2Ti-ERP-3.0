import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/salario_minimo_repository.dart';

class SalarioMinimoController extends ControllerBase<SalarioMinimoModel, SalarioMinimoRepository> {

  SalarioMinimoController({required super.repository}) {
    dbColumns = SalarioMinimoModel.dbColumns;
    aliasColumns = SalarioMinimoModel.aliasColumns;
    gridColumns = salarioMinimoGridColumns();
    functionName = "salario_minimo";
    screenTitle = "Salário Mínimo";
  }

  @override
  SalarioMinimoModel createNewModel() => SalarioMinimoModel();

  @override
  final standardFieldForFilter = SalarioMinimoModel.aliasColumns[SalarioMinimoModel.dbColumns.indexOf('vigencia')];

  final vigenciaController = DatePickerItemController(null);
  final valorMensalController = MoneyMaskedTextController();
  final valorDiarioController = MoneyMaskedTextController();
  final valorHoraController = MoneyMaskedTextController();
  final normaLegalController = TextEditingController();
  final douController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['vigencia'],
    'secondaryColumns': ['valor_mensal'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((salarioMinimo) => salarioMinimo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.salarioMinimoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    vigenciaController.date = null;
    valorMensalController.updateValue(0);
    valorDiarioController.updateValue(0);
    valorHoraController.updateValue(0);
    normaLegalController.text = '';
    douController.date = null;
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.salarioMinimoEditPage);
  }

  void updateControllersFromModel() {
    vigenciaController.date = currentModel.vigencia;
    valorMensalController.updateValue(currentModel.valorMensal ?? 0);
    valorDiarioController.updateValue(currentModel.valorDiario ?? 0);
    valorHoraController.updateValue(currentModel.valorHora ?? 0);
    normaLegalController.text = currentModel.normaLegal ?? '';
    douController.date = currentModel.dou;
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(salarioMinimoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    vigenciaController.dispose();
    valorMensalController.dispose();
    valorDiarioController.dispose();
    valorHoraController.dispose();
    normaLegalController.dispose();
    douController.dispose();
    super.onClose();
  }

}