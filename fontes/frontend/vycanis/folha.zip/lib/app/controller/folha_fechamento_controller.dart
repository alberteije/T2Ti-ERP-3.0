import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_fechamento_repository.dart';

class FolhaFechamentoController extends ControllerBase<FolhaFechamentoModel, FolhaFechamentoRepository> {

  FolhaFechamentoController({required super.repository}) {
    dbColumns = FolhaFechamentoModel.dbColumns;
    aliasColumns = FolhaFechamentoModel.aliasColumns;
    gridColumns = folhaFechamentoGridColumns();
    functionName = "folha_fechamento";
    screenTitle = "Fechamento da Folha";
  }

  @override
  FolhaFechamentoModel createNewModel() => FolhaFechamentoModel();

  @override
  final standardFieldForFilter = FolhaFechamentoModel.aliasColumns[FolhaFechamentoModel.dbColumns.indexOf('fechamento_atual')];

  final fechamentoAtualController = MaskedTextController(mask: '00/0000',);
  final proximoFechamentoController = MaskedTextController(mask: '00/0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['fechamento_atual'],
    'secondaryColumns': ['proximo_fechamento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaFechamento) => folhaFechamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaFechamentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    fechamentoAtualController.text = '';
    proximoFechamentoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaFechamentoEditPage);
  }

  void updateControllersFromModel() {
    fechamentoAtualController.text = currentModel.fechamentoAtual ?? '';
    proximoFechamentoController.text = currentModel.proximoFechamento ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaFechamentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    fechamentoAtualController.dispose();
    proximoFechamentoController.dispose();
    super.onClose();
  }

}