import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/empresa_transporte_repository.dart';

class EmpresaTransporteController extends ControllerBase<EmpresaTransporteModel, EmpresaTransporteRepository> 
with GetSingleTickerProviderStateMixin {

  EmpresaTransporteController({required super.repository}) {
    dbColumns = EmpresaTransporteModel.dbColumns;
    aliasColumns = EmpresaTransporteModel.aliasColumns;
    gridColumns = empresaTransporteGridColumns();
    functionName = "empresa_transporte";
    screenTitle = "Empresa de Transporte";
  }

  final empresaTransporteScaffoldKey = GlobalKey<ScaffoldState>();
  final empresaTransporteTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final empresaTransporteFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  EmpresaTransporteModel createNewModel() => EmpresaTransporteModel();

  @override
  final standardFieldForFilter = EmpresaTransporteModel.aliasColumns[EmpresaTransporteModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final classificacaoContabilContaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['uf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((empresaTransporte) => empresaTransporte.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.empresaTransporteTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    ufController.selected = 'AC';
    classificacaoContabilContaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.empresaTransporteTabPage);
  }

  _configureChildrenControllers() {
    //Itinerario
		Get.put<EmpresaTransporteItinerarioController>(EmpresaTransporteItinerarioController()); 

  }
	
	_releaseChildrenControllers() {
    //Itinerario
		Get.delete<EmpresaTransporteItinerarioController>(); 

	}
  
  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    ufController.selected = currentModel.uf ?? 'AC';
    classificacaoContabilContaController.text = currentModel.classificacaoContabilConta ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Itinerario
		final empresaTransporteItinerarioController = Get.find<EmpresaTransporteItinerarioController>(); 
		empresaTransporteItinerarioController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(empresaTransporteModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Empresa de Transporte', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itinerario', 
		),
  ];

  List<Widget> tabPages() {
    return [
      EmpresaTransporteEditPage(),
      const EmpresaTransporteItinerarioListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<EmpresaTransporteItinerarioController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    ufController.dispose();
    classificacaoContabilContaController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}