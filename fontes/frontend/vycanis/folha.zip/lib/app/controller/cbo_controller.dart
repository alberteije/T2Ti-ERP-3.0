import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/cbo_repository.dart';

class CboController extends ControllerBase<CboModel, CboRepository> {

  CboController({required super.repository}) {
    dbColumns = CboModel.dbColumns;
    aliasColumns = CboModel.aliasColumns;
    gridColumns = cboGridColumns();
    functionName = "cbo";
    screenTitle = "CBO";
  }

  @override
  CboModel createNewModel() => CboModel();

  @override
  final standardFieldForFilter = CboModel.aliasColumns[CboModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final codigo1994Controller = TextEditingController();
  final nomeController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['codigo_1994'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cbo) => cbo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cboEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    codigo1994Controller.text = '';
    nomeController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cboEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    codigo1994Controller.text = currentModel.codigo1994 ?? '';
    nomeController.text = currentModel.nome ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cboModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    codigo1994Controller.dispose();
    nomeController.dispose();
    observacaoController.dispose();
    super.onClose();
  }

}