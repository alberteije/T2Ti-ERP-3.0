import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class InssDetalheController extends ControllerBase<InssDetalheModel, void> {

  InssDetalheController() : super(repository: null) {
    dbColumns = InssDetalheModel.dbColumns;
    aliasColumns = InssDetalheModel.aliasColumns;
    gridColumns = inssDetalheGridColumns();
    functionName = "inss_detalhe";
    screenTitle = "Detalhes";
  }

  final _inssDetalheModel = InssDetalheModel().obs;
  InssDetalheModel get inssDetalheModel => _inssDetalheModel.value;
  set inssDetalheModel(value) => _inssDetalheModel.value = value ?? InssDetalheModel();

  List<InssDetalheModel> get inssDetalheModelList => Get.find<InssController>().currentModel.inssDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final inssDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final inssDetalheFormKey = GlobalKey<FormState>();

  @override
  InssDetalheModel createNewModel() => InssDetalheModel();

  @override
  final standardFieldForFilter = InssDetalheModel.aliasColumns[InssDetalheModel.dbColumns.indexOf('faixa')];

  final faixaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final deController = MoneyMaskedTextController();
  final ateController = MoneyMaskedTextController();
  final taxaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['faixa'],
    'secondaryColumns': ['de'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((inssDetalhe) => inssDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(inssDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    inssDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => InssDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    faixaController.updateValue(0);
    deController.updateValue(0);
    ateController.updateValue(0);
    taxaController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = inssDetalheModelList.firstWhere((m) => m.tempId == tempId);
    inssDetalheModel = model.clone();
		inssDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => InssDetalheEditPage());
  }

  void updateControllersFromModel() {
    faixaController.updateValue((inssDetalheModel.faixa ?? 0).toDouble());
    deController.updateValue(inssDetalheModel.de ?? 0);
    ateController.updateValue(inssDetalheModel.ate ?? 0);
    taxaController.updateValue(inssDetalheModel.taxa ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!inssDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        inssDetalheModelList.insert(0, inssDetalheModel.clone());
      } else {
        final index = inssDetalheModelList.indexWhere((m) => m.tempId == inssDetalheModel.tempId);
        if (index >= 0) {
          inssDetalheModelList[index] = inssDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      inssDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    faixaController.dispose();
    deController.dispose();
    ateController.dispose();
    taxaController.dispose();
  }

}