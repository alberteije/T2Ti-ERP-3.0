import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_lancamento_comissao_repository.dart';

class FolhaLancamentoComissaoController extends ControllerBase<FolhaLancamentoComissaoModel, FolhaLancamentoComissaoRepository> {

  FolhaLancamentoComissaoController({required super.repository}) {
    dbColumns = FolhaLancamentoComissaoModel.dbColumns;
    aliasColumns = FolhaLancamentoComissaoModel.aliasColumns;
    gridColumns = folhaLancamentoComissaoGridColumns();
    functionName = "folha_lancamento_comissao";
    screenTitle = "Comissões";
  }

  @override
  FolhaLancamentoComissaoModel createNewModel() => FolhaLancamentoComissaoModel();

  @override
  final standardFieldForFilter = FolhaLancamentoComissaoModel.aliasColumns[FolhaLancamentoComissaoModel.dbColumns.indexOf('competencia')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final competenciaController = MaskedTextController(mask: '00/0000',);
  final vencimentoController = DatePickerItemController(null);
  final baseCalculoController = MoneyMaskedTextController();
  final valorComissaoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['vencimento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaLancamentoComissao) => folhaLancamentoComissao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaLancamentoComissaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    competenciaController.text = '';
    vencimentoController.date = null;
    baseCalculoController.updateValue(0);
    valorComissaoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaLancamentoComissaoEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    competenciaController.text = currentModel.competencia ?? '';
    vencimentoController.date = currentModel.vencimento;
    baseCalculoController.updateValue(currentModel.baseCalculo ?? 0);
    valorComissaoController.updateValue(currentModel.valorComissao ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaLancamentoComissaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    competenciaController.dispose();
    vencimentoController.dispose();
    baseCalculoController.dispose();
    valorComissaoController.dispose();
    super.onClose();
  }

}