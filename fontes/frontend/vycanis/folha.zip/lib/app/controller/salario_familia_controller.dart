import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SalarioFamiliaController extends ControllerBase<SalarioFamiliaModel, void> {

  SalarioFamiliaController() : super(repository: null) {
    dbColumns = SalarioFamiliaModel.dbColumns;
    aliasColumns = SalarioFamiliaModel.aliasColumns;
    gridColumns = salarioFamiliaGridColumns();
    functionName = "salario_familia";
    screenTitle = "Salário Família";
  }

  final _salarioFamiliaModel = SalarioFamiliaModel().obs;
  SalarioFamiliaModel get salarioFamiliaModel => _salarioFamiliaModel.value;
  set salarioFamiliaModel(value) => _salarioFamiliaModel.value = value ?? SalarioFamiliaModel();

  List<SalarioFamiliaModel> get salarioFamiliaModelList => Get.find<InssController>().currentModel.salarioFamiliaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final salarioFamiliaScaffoldKey = GlobalKey<ScaffoldState>();
  final salarioFamiliaFormKey = GlobalKey<FormState>();

  @override
  SalarioFamiliaModel createNewModel() => SalarioFamiliaModel();

  @override
  final standardFieldForFilter = SalarioFamiliaModel.aliasColumns[SalarioFamiliaModel.dbColumns.indexOf('faixa')];

  final faixaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final deController = MoneyMaskedTextController();
  final ateController = MoneyMaskedTextController();
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['faixa'],
    'secondaryColumns': ['de'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((salarioFamilia) => salarioFamilia.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(salarioFamiliaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    salarioFamiliaModel = createNewModel();
    _resetForm();
    Get.to(() => SalarioFamiliaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    faixaController.updateValue(0);
    deController.updateValue(0);
    ateController.updateValue(0);
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = salarioFamiliaModelList.firstWhere((m) => m.tempId == tempId);
    salarioFamiliaModel = model.clone();
		salarioFamiliaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => SalarioFamiliaEditPage());
  }

  void updateControllersFromModel() {
    faixaController.updateValue((salarioFamiliaModel.faixa ?? 0).toDouble());
    deController.updateValue(salarioFamiliaModel.de ?? 0);
    ateController.updateValue(salarioFamiliaModel.ate ?? 0);
    valorController.updateValue(salarioFamiliaModel.valor ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!salarioFamiliaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        salarioFamiliaModelList.insert(0, salarioFamiliaModel.clone());
      } else {
        final index = salarioFamiliaModelList.indexWhere((m) => m.tempId == salarioFamiliaModel.tempId);
        if (index >= 0) {
          salarioFamiliaModelList[index] = salarioFamiliaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      salarioFamiliaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    faixaController.dispose();
    deController.dispose();
    ateController.dispose();
    valorController.dispose();
  }

}