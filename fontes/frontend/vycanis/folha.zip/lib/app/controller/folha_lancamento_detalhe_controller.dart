import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/routes/app_routes.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaLancamentoDetalheController extends ControllerBase<FolhaLancamentoDetalheModel, void> {

  FolhaLancamentoDetalheController() : super(repository: null) {
    dbColumns = FolhaLancamentoDetalheModel.dbColumns;
    aliasColumns = FolhaLancamentoDetalheModel.aliasColumns;
    gridColumns = folhaLancamentoDetalheGridColumns();
    functionName = "folha_lancamento_detalhe";
    screenTitle = "Detalhes";
  }

  final _folhaLancamentoDetalheModel = FolhaLancamentoDetalheModel().obs;
  FolhaLancamentoDetalheModel get folhaLancamentoDetalheModel => _folhaLancamentoDetalheModel.value;
  set folhaLancamentoDetalheModel(value) => _folhaLancamentoDetalheModel.value = value ?? FolhaLancamentoDetalheModel();

  List<FolhaLancamentoDetalheModel> get folhaLancamentoDetalheModelList => Get.find<FolhaLancamentoCabecalhoController>().currentModel.folhaLancamentoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final folhaLancamentoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaLancamentoDetalheFormKey = GlobalKey<FormState>();

  @override
  FolhaLancamentoDetalheModel createNewModel() => FolhaLancamentoDetalheModel();

  @override
  final standardFieldForFilter = FolhaLancamentoDetalheModel.aliasColumns[FolhaLancamentoDetalheModel.dbColumns.indexOf('origem')];

  final folhaEventoModelController = TextEditingController();
  final origemController = MoneyMaskedTextController();
  final proventoController = MoneyMaskedTextController();
  final descontoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['origem'],
    'secondaryColumns': ['provento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaLancamentoDetalhe) => folhaLancamentoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(folhaLancamentoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    folhaLancamentoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => FolhaLancamentoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    folhaEventoModelController.text = '';
    origemController.updateValue(0);
    proventoController.updateValue(0);
    descontoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = folhaLancamentoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    folhaLancamentoDetalheModel = model.clone();
		folhaLancamentoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FolhaLancamentoDetalheEditPage());
  }

  void updateControllersFromModel() {
    folhaEventoModelController.text = folhaLancamentoDetalheModel.folhaEventoModel?.nome?.toString() ?? '';
    origemController.updateValue(folhaLancamentoDetalheModel.origem ?? 0);
    proventoController.updateValue(folhaLancamentoDetalheModel.provento ?? 0);
    descontoController.updateValue(folhaLancamentoDetalheModel.desconto ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!folhaLancamentoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        folhaLancamentoDetalheModelList.insert(0, folhaLancamentoDetalheModel.clone());
      } else {
        final index = folhaLancamentoDetalheModelList.indexWhere((m) => m.tempId == folhaLancamentoDetalheModel.tempId);
        if (index >= 0) {
          folhaLancamentoDetalheModelList[index] = folhaLancamentoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callFolhaEventoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Evento]'; 
		lookupController.route = '/folha-evento/'; 
		lookupController.gridColumns = folhaEventoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FolhaEventoModel.aliasColumns; 
		lookupController.dbColumns = FolhaEventoModel.dbColumns; 
		lookupController.standardColumn = FolhaEventoModel.aliasColumns[FolhaEventoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			folhaLancamentoDetalheModel.idFolhaEvento = plutoRowResult.cells['id']!.value; 
			folhaLancamentoDetalheModel.folhaEventoModel = FolhaEventoModel.fromPlutoRow(plutoRowResult); 
			folhaEventoModelController.text = folhaLancamentoDetalheModel.folhaEventoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      folhaLancamentoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    folhaEventoModelController.dispose();
    origemController.dispose();
    proventoController.dispose();
    descontoController.dispose();
  }

}