import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/ferias_periodo_aquisitivo_repository.dart';

class FeriasPeriodoAquisitivoController extends ControllerBase<FeriasPeriodoAquisitivoModel, FeriasPeriodoAquisitivoRepository> {

  FeriasPeriodoAquisitivoController({required super.repository}) {
    dbColumns = FeriasPeriodoAquisitivoModel.dbColumns;
    aliasColumns = FeriasPeriodoAquisitivoModel.aliasColumns;
    gridColumns = feriasPeriodoAquisitivoGridColumns();
    functionName = "ferias_periodo_aquisitivo";
    screenTitle = "Períodos Aquisitivos";
  }

  @override
  FeriasPeriodoAquisitivoModel createNewModel() => FeriasPeriodoAquisitivoModel();

  @override
  final standardFieldForFilter = FeriasPeriodoAquisitivoModel.aliasColumns[FeriasPeriodoAquisitivoModel.dbColumns.indexOf('data_inicio')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final situacaoController = CustomDropdownButtonController('0=Em Aberto');
  final limiteParaGozoController = DatePickerItemController(null);
  final descontarFaltasController = CustomDropdownButtonController('Sim');
  final desconsiderarAfastamentoController = CustomDropdownButtonController('Sim');
  final afastamentoPrevidenciaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final afastamentoSemRemunController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final afastamentoComRemunController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diasDireitoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diasGozadosController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diasFaltasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diasRestantesController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((feriasPeriodoAquisitivo) => feriasPeriodoAquisitivo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.feriasPeriodoAquisitivoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    dataInicioController.date = null;
    dataFimController.date = null;
    situacaoController.selected = '0=Em Aberto';
    limiteParaGozoController.date = null;
    descontarFaltasController.selected = 'Sim';
    desconsiderarAfastamentoController.selected = 'Sim';
    afastamentoPrevidenciaController.updateValue(0);
    afastamentoSemRemunController.updateValue(0);
    afastamentoComRemunController.updateValue(0);
    diasDireitoController.updateValue(0);
    diasGozadosController.updateValue(0);
    diasFaltasController.updateValue(0);
    diasRestantesController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.feriasPeriodoAquisitivoEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataInicioController.date = currentModel.dataInicio;
    dataFimController.date = currentModel.dataFim;
    situacaoController.selected = currentModel.situacao ?? '0=Em Aberto';
    limiteParaGozoController.date = currentModel.limiteParaGozo;
    descontarFaltasController.selected = currentModel.descontarFaltas ?? 'Sim';
    desconsiderarAfastamentoController.selected = currentModel.desconsiderarAfastamento ?? 'Sim';
    afastamentoPrevidenciaController.updateValue((currentModel.afastamentoPrevidencia ?? 0).toDouble());
    afastamentoSemRemunController.updateValue((currentModel.afastamentoSemRemun ?? 0).toDouble());
    afastamentoComRemunController.updateValue((currentModel.afastamentoComRemun ?? 0).toDouble());
    diasDireitoController.updateValue((currentModel.diasDireito ?? 0).toDouble());
    diasGozadosController.updateValue((currentModel.diasGozados ?? 0).toDouble());
    diasFaltasController.updateValue((currentModel.diasFaltas ?? 0).toDouble());
    diasRestantesController.updateValue((currentModel.diasRestantes ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(feriasPeriodoAquisitivoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    dataInicioController.dispose();
    dataFimController.dispose();
    situacaoController.dispose();
    limiteParaGozoController.dispose();
    descontarFaltasController.dispose();
    desconsiderarAfastamentoController.dispose();
    afastamentoPrevidenciaController.dispose();
    afastamentoSemRemunController.dispose();
    afastamentoComRemunController.dispose();
    diasDireitoController.dispose();
    diasGozadosController.dispose();
    diasFaltasController.dispose();
    diasRestantesController.dispose();
    super.onClose();
  }

}