import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/operadora_plano_saude_repository.dart';

class OperadoraPlanoSaudeController extends ControllerBase<OperadoraPlanoSaudeModel, OperadoraPlanoSaudeRepository> {

  OperadoraPlanoSaudeController({required super.repository}) {
    dbColumns = OperadoraPlanoSaudeModel.dbColumns;
    aliasColumns = OperadoraPlanoSaudeModel.aliasColumns;
    gridColumns = operadoraPlanoSaudeGridColumns();
    functionName = "operadora_plano_saude";
    screenTitle = "Operadora Plano de Saúde";
  }

  @override
  OperadoraPlanoSaudeModel createNewModel() => OperadoraPlanoSaudeModel();

  @override
  final standardFieldForFilter = OperadoraPlanoSaudeModel.aliasColumns[OperadoraPlanoSaudeModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final registroAnsController = TextEditingController();
  final classificacaoContabilContaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['registro_ans'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((operadoraPlanoSaude) => operadoraPlanoSaude.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.operadoraPlanoSaudeEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    registroAnsController.text = '';
    classificacaoContabilContaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.operadoraPlanoSaudeEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    registroAnsController.text = currentModel.registroAns ?? '';
    classificacaoContabilContaController.text = currentModel.classificacaoContabilConta ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(operadoraPlanoSaudeModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    registroAnsController.dispose();
    classificacaoContabilContaController.dispose();
    super.onClose();
  }

}