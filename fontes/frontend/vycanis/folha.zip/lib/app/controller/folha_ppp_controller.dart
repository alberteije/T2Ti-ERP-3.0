import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_ppp_repository.dart';

class FolhaPppController extends ControllerBase<FolhaPppModel, FolhaPppRepository> 
with GetSingleTickerProviderStateMixin {

  FolhaPppController({required super.repository}) {
    dbColumns = FolhaPppModel.dbColumns;
    aliasColumns = FolhaPppModel.aliasColumns;
    gridColumns = folhaPppGridColumns();
    functionName = "folha_ppp";
    screenTitle = "PPP";
  }

  final folhaPppScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaPppTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaPppFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  FolhaPppModel createNewModel() => FolhaPppModel();

  @override
  final standardFieldForFilter = FolhaPppModel.aliasColumns[FolhaPppModel.dbColumns.indexOf('observacao')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['observacao'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaPpp) => folhaPpp.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.folhaPppTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.folhaPppTabPage);
  }

  _configureChildrenControllers() {
    //CAT
		Get.put<FolhaPppCatController>(FolhaPppCatController()); 

    //Atividade
		Get.put<FolhaPppAtividadeController>(FolhaPppAtividadeController()); 

    //Fator de Risco
		Get.put<FolhaPppFatorRiscoController>(FolhaPppFatorRiscoController()); 

    //Exame Médico
		Get.put<FolhaPppExameMedicoController>(FolhaPppExameMedicoController()); 

  }
	
	_releaseChildrenControllers() {
    //CAT
		Get.delete<FolhaPppCatController>(); 

    //Atividade
		Get.delete<FolhaPppAtividadeController>(); 

    //Fator de Risco
		Get.delete<FolhaPppFatorRiscoController>(); 

    //Exame Médico
		Get.delete<FolhaPppExameMedicoController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    observacaoController.text = currentModel.observacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //CAT
		final folhaPppCatController = Get.find<FolhaPppCatController>(); 
		folhaPppCatController.userMadeChanges = false; 

    //Atividade
		final folhaPppAtividadeController = Get.find<FolhaPppAtividadeController>(); 
		folhaPppAtividadeController.userMadeChanges = false; 

    //Fator de Risco
		final folhaPppFatorRiscoController = Get.find<FolhaPppFatorRiscoController>(); 
		folhaPppFatorRiscoController.userMadeChanges = false; 

    //Exame Médico
		final folhaPppExameMedicoController = Get.find<FolhaPppExameMedicoController>(); 
		folhaPppExameMedicoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(folhaPppModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'PPP', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'CAT', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Atividade', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Fator de Risco', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Exame Médico', 
		),
  ];

  List<Widget> tabPages() {
    return [
      FolhaPppEditPage(),
      const FolhaPppCatListPage(),
      const FolhaPppAtividadeListPage(),
      const FolhaPppFatorRiscoListPage(),
      const FolhaPppExameMedicoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<FolhaPppCatController>().userMadeChanges
    || 
		Get.find<FolhaPppAtividadeController>().userMadeChanges
    || 
		Get.find<FolhaPppFatorRiscoController>().userMadeChanges
    || 
		Get.find<FolhaPppExameMedicoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaColaboradorModelController.dispose();
    observacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}