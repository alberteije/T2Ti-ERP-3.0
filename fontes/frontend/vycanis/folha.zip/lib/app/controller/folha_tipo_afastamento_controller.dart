import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_tipo_afastamento_repository.dart';

class FolhaTipoAfastamentoController extends ControllerBase<FolhaTipoAfastamentoModel, FolhaTipoAfastamentoRepository> {

  FolhaTipoAfastamentoController({required super.repository}) {
    dbColumns = FolhaTipoAfastamentoModel.dbColumns;
    aliasColumns = FolhaTipoAfastamentoModel.aliasColumns;
    gridColumns = folhaTipoAfastamentoGridColumns();
    functionName = "folha_tipo_afastamento";
    screenTitle = "Tipo de Afastamento";
  }

  @override
  FolhaTipoAfastamentoModel createNewModel() => FolhaTipoAfastamentoModel();

  @override
  final standardFieldForFilter = FolhaTipoAfastamentoModel.aliasColumns[FolhaTipoAfastamentoModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final codigoEsocialController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaTipoAfastamento) => folhaTipoAfastamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaTipoAfastamentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
    codigoEsocialController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaTipoAfastamentoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    codigoEsocialController.text = currentModel.codigoEsocial ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaTipoAfastamentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    codigoEsocialController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}