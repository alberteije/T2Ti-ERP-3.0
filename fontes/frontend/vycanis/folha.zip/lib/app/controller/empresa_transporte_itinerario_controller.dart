import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class EmpresaTransporteItinerarioController extends ControllerBase<EmpresaTransporteItinerarioModel, void> {

  EmpresaTransporteItinerarioController() : super(repository: null) {
    dbColumns = EmpresaTransporteItinerarioModel.dbColumns;
    aliasColumns = EmpresaTransporteItinerarioModel.aliasColumns;
    gridColumns = empresaTransporteItinerarioGridColumns();
    functionName = "empresa_transporte_itinerario";
    screenTitle = "Itinerario";
  }

  final _empresaTransporteItinerarioModel = EmpresaTransporteItinerarioModel().obs;
  EmpresaTransporteItinerarioModel get empresaTransporteItinerarioModel => _empresaTransporteItinerarioModel.value;
  set empresaTransporteItinerarioModel(value) => _empresaTransporteItinerarioModel.value = value ?? EmpresaTransporteItinerarioModel();

  List<EmpresaTransporteItinerarioModel> get empresaTransporteItinerarioModelList => Get.find<EmpresaTransporteController>().currentModel.empresaTransporteItinerarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final empresaTransporteItinerarioScaffoldKey = GlobalKey<ScaffoldState>();
  final empresaTransporteItinerarioFormKey = GlobalKey<FormState>();

  @override
  EmpresaTransporteItinerarioModel createNewModel() => EmpresaTransporteItinerarioModel();

  @override
  final standardFieldForFilter = EmpresaTransporteItinerarioModel.aliasColumns[EmpresaTransporteItinerarioModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final tarifaController = MoneyMaskedTextController();
  final trajetoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['tarifa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((empresaTransporteItinerario) => empresaTransporteItinerario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(empresaTransporteItinerarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    empresaTransporteItinerarioModel = createNewModel();
    _resetForm();
    Get.to(() => EmpresaTransporteItinerarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    nomeController.text = '';
    tarifaController.updateValue(0);
    trajetoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = empresaTransporteItinerarioModelList.firstWhere((m) => m.tempId == tempId);
    empresaTransporteItinerarioModel = model.clone();
		empresaTransporteItinerarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => EmpresaTransporteItinerarioEditPage());
  }

  void updateControllersFromModel() {
    nomeController.text = empresaTransporteItinerarioModel.nome ?? '';
    tarifaController.updateValue(empresaTransporteItinerarioModel.tarifa ?? 0);
    trajetoController.text = empresaTransporteItinerarioModel.trajeto ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!empresaTransporteItinerarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        empresaTransporteItinerarioModelList.insert(0, empresaTransporteItinerarioModel.clone());
      } else {
        final index = empresaTransporteItinerarioModelList.indexWhere((m) => m.tempId == empresaTransporteItinerarioModel.tempId);
        if (index >= 0) {
          empresaTransporteItinerarioModelList[index] = empresaTransporteItinerarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      empresaTransporteItinerarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    nomeController.dispose();
    tarifaController.dispose();
    trajetoController.dispose();
  }

}