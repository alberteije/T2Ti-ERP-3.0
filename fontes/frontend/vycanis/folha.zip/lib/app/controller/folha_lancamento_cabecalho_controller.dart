import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_lancamento_cabecalho_repository.dart';

class FolhaLancamentoCabecalhoController extends ControllerBase<FolhaLancamentoCabecalhoModel, FolhaLancamentoCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  FolhaLancamentoCabecalhoController({required super.repository}) {
    dbColumns = FolhaLancamentoCabecalhoModel.dbColumns;
    aliasColumns = FolhaLancamentoCabecalhoModel.aliasColumns;
    gridColumns = folhaLancamentoCabecalhoGridColumns();
    functionName = "folha_lancamento_cabecalho";
    screenTitle = "Lançamento";
  }

  final folhaLancamentoCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaLancamentoCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaLancamentoCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  FolhaLancamentoCabecalhoModel createNewModel() => FolhaLancamentoCabecalhoModel();

  @override
  final standardFieldForFilter = FolhaLancamentoCabecalhoModel.aliasColumns[FolhaLancamentoCabecalhoModel.dbColumns.indexOf('competencia')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final competenciaController = TextEditingController();
  final tipoController = CustomDropdownButtonController('Folha Mensal');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['tipo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaLancamentoCabecalho) => folhaLancamentoCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.folhaLancamentoCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    competenciaController.text = '';
    tipoController.selected = 'Folha Mensal';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.folhaLancamentoCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<FolhaLancamentoDetalheController>(FolhaLancamentoDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<FolhaLancamentoDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    competenciaController.text = currentModel.competencia ?? '';
    tipoController.selected = currentModel.tipo ?? 'Folha Mensal';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final folhaLancamentoDetalheController = Get.find<FolhaLancamentoDetalheController>(); 
		folhaLancamentoDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(folhaLancamentoCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Lançamento', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      FolhaLancamentoCabecalhoEditPage(),
      const FolhaLancamentoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<FolhaLancamentoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaColaboradorModelController.dispose();
    competenciaController.dispose();
    tipoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}