import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/fpas_repository.dart';

class FpasController extends ControllerBase<FpasModel, FpasRepository> {

  FpasController({required super.repository}) {
    dbColumns = FpasModel.dbColumns;
    aliasColumns = FpasModel.aliasColumns;
    gridColumns = fpasGridColumns();
    functionName = "fpas";
    screenTitle = "FPAS - Fundo da Previdência e Assistência Social";
  }

  @override
  FpasModel createNewModel() => FpasModel();

  @override
  final standardFieldForFilter = FpasModel.aliasColumns[FpasModel.dbColumns.indexOf('codigo')];

  final codigoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final cnaeController = TextEditingController();
  final aliquotaSatController = MoneyMaskedTextController();
  final descricaoController = TextEditingController();
  final percentualInssPatronalController = MoneyMaskedTextController();
  final codigoTerceiroController = CustomDropdownButtonController('AAA');
  final percentualTerceirosController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['cnae'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fpas) => fpas.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fpasEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.updateValue(0);
    cnaeController.text = '';
    aliquotaSatController.updateValue(0);
    descricaoController.text = '';
    percentualInssPatronalController.updateValue(0);
    codigoTerceiroController.selected = 'AAA';
    percentualTerceirosController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fpasEditPage);
  }

  void updateControllersFromModel() {
    codigoController.updateValue((currentModel.codigo ?? 0).toDouble());
    cnaeController.text = currentModel.cnae ?? '';
    aliquotaSatController.updateValue(currentModel.aliquotaSat ?? 0);
    descricaoController.text = currentModel.descricao ?? '';
    percentualInssPatronalController.updateValue(currentModel.percentualInssPatronal ?? 0);
    codigoTerceiroController.selected = currentModel.codigoTerceiro ?? 'AAA';
    percentualTerceirosController.updateValue(currentModel.percentualTerceiros ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fpasModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    cnaeController.dispose();
    aliquotaSatController.dispose();
    descricaoController.dispose();
    percentualInssPatronalController.dispose();
    codigoTerceiroController.dispose();
    percentualTerceirosController.dispose();
    super.onClose();
  }

}