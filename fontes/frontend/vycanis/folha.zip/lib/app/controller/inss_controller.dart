import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/inss_repository.dart';

class InssController extends ControllerBase<InssModel, InssRepository> 
with GetSingleTickerProviderStateMixin {

  InssController({required super.repository}) {
    dbColumns = InssModel.dbColumns;
    aliasColumns = InssModel.aliasColumns;
    gridColumns = inssGridColumns();
    functionName = "inss";
    screenTitle = "INSS";
  }

  final inssScaffoldKey = GlobalKey<ScaffoldState>();
  final inssTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final inssFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  InssModel createNewModel() => InssModel();

  @override
  final standardFieldForFilter = InssModel.aliasColumns[InssModel.dbColumns.indexOf('competencia')];

  final competenciaController = MaskedTextController(mask: '00/0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((inss) => inss.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.inssTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    competenciaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.inssTabPage);
  }

  _configureChildrenControllers() {
    //Salário Família
		Get.put<SalarioFamiliaController>(SalarioFamiliaController()); 

    //Detalhes
		Get.put<InssDetalheController>(InssDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Salário Família
		Get.delete<SalarioFamiliaController>(); 

    //Detalhes
		Get.delete<InssDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    competenciaController.text = currentModel.competencia ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Salário Família
		final salarioFamiliaController = Get.find<SalarioFamiliaController>(); 
		salarioFamiliaController.userMadeChanges = false; 

    //Detalhes
		final inssDetalheController = Get.find<InssDetalheController>(); 
		inssDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(inssModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'INSS', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Salário Família', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      InssEditPage(),
      const SalarioFamiliaListPage(),
      const InssDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<SalarioFamiliaController>().userMadeChanges
    || 
		Get.find<InssDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    competenciaController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}