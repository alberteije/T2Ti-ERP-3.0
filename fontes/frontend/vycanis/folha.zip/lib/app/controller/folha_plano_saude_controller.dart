import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_plano_saude_repository.dart';

class FolhaPlanoSaudeController extends ControllerBase<FolhaPlanoSaudeModel, FolhaPlanoSaudeRepository> {

  FolhaPlanoSaudeController({required super.repository}) {
    dbColumns = FolhaPlanoSaudeModel.dbColumns;
    aliasColumns = FolhaPlanoSaudeModel.aliasColumns;
    gridColumns = folhaPlanoSaudeGridColumns();
    functionName = "folha_plano_saude";
    screenTitle = "Plano de Saúde";
  }

  @override
  FolhaPlanoSaudeModel createNewModel() => FolhaPlanoSaudeModel();

  @override
  final standardFieldForFilter = FolhaPlanoSaudeModel.aliasColumns[FolhaPlanoSaudeModel.dbColumns.indexOf('data_inicio')];

  final operadoraPlanoSaudeModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final dataInicioController = DatePickerItemController(null);
  final beneficiarioController = CustomDropdownButtonController('1=Somente Colaborador');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['beneficiario'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaPlanoSaude) => folhaPlanoSaude.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaPlanoSaudeEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    operadoraPlanoSaudeModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    dataInicioController.date = null;
    beneficiarioController.selected = '1=Somente Colaborador';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaPlanoSaudeEditPage);
  }

  void updateControllersFromModel() {
    operadoraPlanoSaudeModelController.text = currentModel.operadoraPlanoSaudeModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataInicioController.date = currentModel.dataInicio;
    beneficiarioController.selected = currentModel.beneficiario ?? '1=Somente Colaborador';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaPlanoSaudeModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callOperadoraPlanoSaudeLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Operadora]'; 
		lookupController.route = '/operadora-plano-saude/'; 
		lookupController.gridColumns = operadoraPlanoSaudeGridColumns(isForLookup: true); 
		lookupController.aliasColumns = OperadoraPlanoSaudeModel.aliasColumns; 
		lookupController.dbColumns = OperadoraPlanoSaudeModel.dbColumns; 
		lookupController.standardColumn = OperadoraPlanoSaudeModel.aliasColumns[OperadoraPlanoSaudeModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idOperadoraPlanoSaude = plutoRowResult.cells['id']!.value; 
			currentModel.operadoraPlanoSaudeModel = OperadoraPlanoSaudeModel.fromPlutoRow(plutoRowResult); 
			operadoraPlanoSaudeModelController.text = currentModel.operadoraPlanoSaudeModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    operadoraPlanoSaudeModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    dataInicioController.dispose();
    beneficiarioController.dispose();
    super.onClose();
  }

}