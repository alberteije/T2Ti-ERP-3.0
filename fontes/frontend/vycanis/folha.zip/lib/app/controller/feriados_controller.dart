import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/feriados_repository.dart';

class FeriadosController extends ControllerBase<FeriadosModel, FeriadosRepository> {

  FeriadosController({required super.repository}) {
    dbColumns = FeriadosModel.dbColumns;
    aliasColumns = FeriadosModel.aliasColumns;
    gridColumns = feriadosGridColumns();
    functionName = "feriados";
    screenTitle = "Feriados";
  }

  @override
  FeriadosModel createNewModel() => FeriadosModel();

  @override
  final standardFieldForFilter = FeriadosModel.aliasColumns[FeriadosModel.dbColumns.indexOf('ano')];

  final anoController = TextEditingController();
  final nomeController = TextEditingController();
  final abrangenciaController = CustomDropdownButtonController('Federal');
  final ufController = CustomDropdownButtonController('AC');
  final municipioIbgeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final tipoController = CustomDropdownButtonController('Fixo.Movel');
  final dataFeriadoController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['ano'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((feriados) => feriados.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.feriadosEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    anoController.text = '';
    nomeController.text = '';
    abrangenciaController.selected = 'Federal';
    ufController.selected = 'AC';
    municipioIbgeController.updateValue(0);
    tipoController.selected = 'Fixo.Movel';
    dataFeriadoController.date = null;
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.feriadosEditPage);
  }

  void updateControllersFromModel() {
    anoController.text = currentModel.ano ?? '';
    nomeController.text = currentModel.nome ?? '';
    abrangenciaController.selected = currentModel.abrangencia ?? 'Federal';
    ufController.selected = currentModel.uf ?? 'AC';
    municipioIbgeController.updateValue((currentModel.municipioIbge ?? 0).toDouble());
    tipoController.selected = currentModel.tipo ?? 'Fixo.Movel';
    dataFeriadoController.date = currentModel.dataFeriado;
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(feriadosModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    anoController.dispose();
    nomeController.dispose();
    abrangenciaController.dispose();
    ufController.dispose();
    municipioIbgeController.dispose();
    tipoController.dispose();
    dataFeriadoController.dispose();
    super.onClose();
  }

}