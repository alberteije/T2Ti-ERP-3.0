import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/page_imports.dart';
import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaPppExameMedicoController extends ControllerBase<FolhaPppExameMedicoModel, void> {

  FolhaPppExameMedicoController() : super(repository: null) {
    dbColumns = FolhaPppExameMedicoModel.dbColumns;
    aliasColumns = FolhaPppExameMedicoModel.aliasColumns;
    gridColumns = folhaPppExameMedicoGridColumns();
    functionName = "folha_ppp_exame_medico";
    screenTitle = "Exame Médico";
  }

  final _folhaPppExameMedicoModel = FolhaPppExameMedicoModel().obs;
  FolhaPppExameMedicoModel get folhaPppExameMedicoModel => _folhaPppExameMedicoModel.value;
  set folhaPppExameMedicoModel(value) => _folhaPppExameMedicoModel.value = value ?? FolhaPppExameMedicoModel();

  List<FolhaPppExameMedicoModel> get folhaPppExameMedicoModelList => Get.find<FolhaPppController>().currentModel.folhaPppExameMedicoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final folhaPppExameMedicoScaffoldKey = GlobalKey<ScaffoldState>();
  final folhaPppExameMedicoFormKey = GlobalKey<FormState>();

  @override
  FolhaPppExameMedicoModel createNewModel() => FolhaPppExameMedicoModel();

  @override
  final standardFieldForFilter = FolhaPppExameMedicoModel.aliasColumns[FolhaPppExameMedicoModel.dbColumns.indexOf('data_ultimo')];

  final dataUltimoController = DatePickerItemController(null);
  final tipoController = CustomDropdownButtonController('Admissional');
  final exameController = CustomDropdownButtonController('Referencial');
  final naturezaController = TextEditingController();
  final indicacaoResultadosController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_ultimo'],
    'secondaryColumns': ['tipo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaPppExameMedico) => folhaPppExameMedico.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(folhaPppExameMedicoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    folhaPppExameMedicoModel = createNewModel();
    _resetForm();
    Get.to(() => FolhaPppExameMedicoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataUltimoController.date = null;
    tipoController.selected = 'Admissional';
    exameController.selected = 'Referencial';
    naturezaController.text = '';
    indicacaoResultadosController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = folhaPppExameMedicoModelList.firstWhere((m) => m.tempId == tempId);
    folhaPppExameMedicoModel = model.clone();
		folhaPppExameMedicoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FolhaPppExameMedicoEditPage());
  }

  void updateControllersFromModel() {
    dataUltimoController.date = folhaPppExameMedicoModel.dataUltimo;
    tipoController.selected = folhaPppExameMedicoModel.tipo ?? 'Admissional';
    exameController.selected = folhaPppExameMedicoModel.exame ?? 'Referencial';
    naturezaController.text = folhaPppExameMedicoModel.natureza ?? '';
    indicacaoResultadosController.text = folhaPppExameMedicoModel.indicacaoResultados ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!folhaPppExameMedicoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        folhaPppExameMedicoModelList.insert(0, folhaPppExameMedicoModel.clone());
      } else {
        final index = folhaPppExameMedicoModelList.indexWhere((m) => m.tempId == folhaPppExameMedicoModel.tempId);
        if (index >= 0) {
          folhaPppExameMedicoModelList[index] = folhaPppExameMedicoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      folhaPppExameMedicoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataUltimoController.dispose();
    tipoController.dispose();
    exameController.dispose();
    naturezaController.dispose();
    indicacaoResultadosController.dispose();
  }

}