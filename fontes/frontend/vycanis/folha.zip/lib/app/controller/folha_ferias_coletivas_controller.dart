import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_ferias_coletivas_repository.dart';

class FolhaFeriasColetivasController extends ControllerBase<FolhaFeriasColetivasModel, FolhaFeriasColetivasRepository> {

  FolhaFeriasColetivasController({required super.repository}) {
    dbColumns = FolhaFeriasColetivasModel.dbColumns;
    aliasColumns = FolhaFeriasColetivasModel.aliasColumns;
    gridColumns = folhaFeriasColetivasGridColumns();
    functionName = "folha_ferias_coletivas";
    screenTitle = "Férias Coletivas";
  }

  @override
  FolhaFeriasColetivasModel createNewModel() => FolhaFeriasColetivasModel();

  @override
  final standardFieldForFilter = FolhaFeriasColetivasModel.aliasColumns[FolhaFeriasColetivasModel.dbColumns.indexOf('data_inicio')];

  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final diasGozoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final abonoPecuniarioInicioController = DatePickerItemController(null);
  final abonoPecuniarioFimController = DatePickerItemController(null);
  final diasAbonoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataPagamentoController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaFeriasColetivas) => folhaFeriasColetivas.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaFeriasColetivasEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataInicioController.date = null;
    dataFimController.date = null;
    diasGozoController.updateValue(0);
    abonoPecuniarioInicioController.date = null;
    abonoPecuniarioFimController.date = null;
    diasAbonoController.updateValue(0);
    dataPagamentoController.date = null;
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaFeriasColetivasEditPage);
  }

  void updateControllersFromModel() {
    dataInicioController.date = currentModel.dataInicio;
    dataFimController.date = currentModel.dataFim;
    diasGozoController.updateValue((currentModel.diasGozo ?? 0).toDouble());
    abonoPecuniarioInicioController.date = currentModel.abonoPecuniarioInicio;
    abonoPecuniarioFimController.date = currentModel.abonoPecuniarioFim;
    diasAbonoController.updateValue((currentModel.diasAbono ?? 0).toDouble());
    dataPagamentoController.date = currentModel.dataPagamento;
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaFeriasColetivasModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    dataInicioController.dispose();
    dataFimController.dispose();
    diasGozoController.dispose();
    abonoPecuniarioInicioController.dispose();
    abonoPecuniarioFimController.dispose();
    diasAbonoController.dispose();
    dataPagamentoController.dispose();
    super.onClose();
  }

}