import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/sefip_codigo_movimentacao_repository.dart';

class SefipCodigoMovimentacaoController extends ControllerBase<SefipCodigoMovimentacaoModel, SefipCodigoMovimentacaoRepository> {

  SefipCodigoMovimentacaoController({required super.repository}) {
    dbColumns = SefipCodigoMovimentacaoModel.dbColumns;
    aliasColumns = SefipCodigoMovimentacaoModel.aliasColumns;
    gridColumns = sefipCodigoMovimentacaoGridColumns();
    functionName = "sefip_codigo_movimentacao";
    screenTitle = "SEFIP - Código Movimentação";
  }

  @override
  SefipCodigoMovimentacaoModel createNewModel() => SefipCodigoMovimentacaoModel();

  @override
  final standardFieldForFilter = SefipCodigoMovimentacaoModel.aliasColumns[SefipCodigoMovimentacaoModel.dbColumns.indexOf('codigo')];

  final codigoController = CustomDropdownButtonController('AAA');
  final descricaoController = TextEditingController();
  final aplicacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((sefipCodigoMovimentacao) => sefipCodigoMovimentacao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.sefipCodigoMovimentacaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.selected = 'AAA';
    descricaoController.text = '';
    aplicacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.sefipCodigoMovimentacaoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.selected = currentModel.codigo ?? 'AAA';
    descricaoController.text = currentModel.descricao ?? '';
    aplicacaoController.text = currentModel.aplicacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(sefipCodigoMovimentacaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    descricaoController.dispose();
    aplicacaoController.dispose();
    super.onClose();
  }

}