import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_historico_salarial_repository.dart';

class FolhaHistoricoSalarialController extends ControllerBase<FolhaHistoricoSalarialModel, FolhaHistoricoSalarialRepository> {

  FolhaHistoricoSalarialController({required super.repository}) {
    dbColumns = FolhaHistoricoSalarialModel.dbColumns;
    aliasColumns = FolhaHistoricoSalarialModel.aliasColumns;
    gridColumns = folhaHistoricoSalarialGridColumns();
    functionName = "folha_historico_salarial";
    screenTitle = "Histórico Salarial";
  }

  @override
  FolhaHistoricoSalarialModel createNewModel() => FolhaHistoricoSalarialModel();

  @override
  final standardFieldForFilter = FolhaHistoricoSalarialModel.aliasColumns[FolhaHistoricoSalarialModel.dbColumns.indexOf('competencia')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final competenciaController = MaskedTextController(mask: '00/0000',);
  final salarioAtualController = MoneyMaskedTextController();
  final percentualAumentoController = MoneyMaskedTextController();
  final salarioNovoController = MoneyMaskedTextController();
  final validoAPartirController = MaskedTextController(mask: '00/0000',);
  final motivoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['salario_atual'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaHistoricoSalarial) => folhaHistoricoSalarial.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaHistoricoSalarialEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    competenciaController.text = '';
    salarioAtualController.updateValue(0);
    percentualAumentoController.updateValue(0);
    salarioNovoController.updateValue(0);
    validoAPartirController.text = '';
    motivoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaHistoricoSalarialEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    competenciaController.text = currentModel.competencia ?? '';
    salarioAtualController.updateValue(currentModel.salarioAtual ?? 0);
    percentualAumentoController.updateValue(currentModel.percentualAumento ?? 0);
    salarioNovoController.updateValue(currentModel.salarioNovo ?? 0);
    validoAPartirController.text = currentModel.validoAPartir ?? '';
    motivoController.text = currentModel.motivo ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaHistoricoSalarialModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    competenciaController.dispose();
    salarioAtualController.dispose();
    percentualAumentoController.dispose();
    salarioNovoController.dispose();
    validoAPartirController.dispose();
    motivoController.dispose();
    super.onClose();
  }

}