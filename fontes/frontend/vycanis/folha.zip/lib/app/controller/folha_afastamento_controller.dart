import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

import 'package:folha/app/page/shared_widget/message_dialog.dart';
import 'package:folha/app/page/grid_columns/grid_columns_imports.dart';
import 'package:folha/app/routes/app_routes.dart';
import 'package:folha/app/controller/controller_imports.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/repository/folha_afastamento_repository.dart';

class FolhaAfastamentoController extends ControllerBase<FolhaAfastamentoModel, FolhaAfastamentoRepository> {

  FolhaAfastamentoController({required super.repository}) {
    dbColumns = FolhaAfastamentoModel.dbColumns;
    aliasColumns = FolhaAfastamentoModel.aliasColumns;
    gridColumns = folhaAfastamentoGridColumns();
    functionName = "folha_afastamento";
    screenTitle = "Afastamentos";
  }

  @override
  FolhaAfastamentoModel createNewModel() => FolhaAfastamentoModel();

  @override
  final standardFieldForFilter = FolhaAfastamentoModel.aliasColumns[FolhaAfastamentoModel.dbColumns.indexOf('data_inicio')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final folhaTipoAfastamentoModelController = TextEditingController();
  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final diasAfastadoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((folhaAfastamento) => folhaAfastamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.folhaAfastamentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    folhaTipoAfastamentoModelController.text = '';
    dataInicioController.date = null;
    dataFimController.date = null;
    diasAfastadoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.folhaAfastamentoEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    folhaTipoAfastamentoModelController.text = currentModel.folhaTipoAfastamentoModel?.nome?.toString() ?? '';
    dataInicioController.date = currentModel.dataInicio;
    dataFimController.date = currentModel.dataFim;
    diasAfastadoController.updateValue((currentModel.diasAfastado ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(folhaAfastamentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFolhaTipoAfastamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Afastamento]'; 
		lookupController.route = '/folha-tipo-afastamento/'; 
		lookupController.gridColumns = folhaTipoAfastamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FolhaTipoAfastamentoModel.aliasColumns; 
		lookupController.dbColumns = FolhaTipoAfastamentoModel.dbColumns; 
		lookupController.standardColumn = FolhaTipoAfastamentoModel.aliasColumns[FolhaTipoAfastamentoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFolhaTipoAfastamento = plutoRowResult.cells['id']!.value; 
			currentModel.folhaTipoAfastamentoModel = FolhaTipoAfastamentoModel.fromPlutoRow(plutoRowResult); 
			folhaTipoAfastamentoModelController.text = currentModel.folhaTipoAfastamentoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    folhaTipoAfastamentoModelController.dispose();
    dataInicioController.dispose();
    dataFimController.dispose();
    diasAfastadoController.dispose();
    super.onClose();
  }

}