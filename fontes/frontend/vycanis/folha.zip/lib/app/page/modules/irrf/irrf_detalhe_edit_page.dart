import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';
import 'package:folha/app/controller/irrf_detalhe_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class IrrfDetalheEditPage extends StatelessWidget {
	IrrfDetalheEditPage({Key? key}) : super(key: key);
	final irrfDetalheController = Get.find<IrrfDetalheController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: irrfDetalheController.irrfDetalheScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ irrfDetalheController.screenTitle } - ${ irrfDetalheController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: irrfDetalheController.save),
						cancelAndExitButton(onPressed: irrfDetalheController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: irrfDetalheController.irrfDetalheFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: irrfDetalheController.scrollController,
							child: SingleChildScrollView(
								controller: irrfDetalheController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfDetalheController.faixaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Faixa',
																labelText: 'Faixa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfDetalheController.irrfDetalheModel.faixa = int.tryParse(text);
																irrfDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfDetalheController.deController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo De',
																labelText: 'De',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfDetalheController.irrfDetalheModel.de = irrfDetalheController.deController.numberValue;
																irrfDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfDetalheController.ateController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Ate',
																labelText: 'Ate',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfDetalheController.irrfDetalheModel.ate = irrfDetalheController.ateController.numberValue;
																irrfDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfDetalheController.taxaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa',
																labelText: 'Taxa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfDetalheController.irrfDetalheModel.taxa = irrfDetalheController.taxaController.numberValue;
																irrfDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfDetalheController.descontoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Desconto',
																labelText: 'Desconto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfDetalheController.irrfDetalheModel.desconto = irrfDetalheController.descontoController.numberValue;
																irrfDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
