import 'package:flutter/material.dart';
import 'package:folha/app/controller/operadora_plano_saude_controller.dart';
import 'package:folha/app/page/shared_page/list_page_base.dart';

class OperadoraPlanoSaudeListPage extends ListPageBase<OperadoraPlanoSaudeController> {
  const OperadoraPlanoSaudeListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}