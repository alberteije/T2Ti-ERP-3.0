import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';
import 'package:folha/app/controller/salario_minimo_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class SalarioMinimoEditPage extends StatelessWidget {
	SalarioMinimoEditPage({Key? key}) : super(key: key);
	final salarioMinimoController = Get.find<SalarioMinimoController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					salarioMinimoController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: salarioMinimoController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ salarioMinimoController.screenTitle } - ${ salarioMinimoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: salarioMinimoController.save),
						cancelAndExitButton(onPressed: salarioMinimoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: salarioMinimoController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: salarioMinimoController.scrollController,
							child: SingleChildScrollView(
								controller: salarioMinimoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Vigencia',
																labelText: 'Vigencia',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: salarioMinimoController.vigenciaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	salarioMinimoController.currentModel.vigencia = value;
																	salarioMinimoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: salarioMinimoController.valorMensalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Mensal',
																labelText: 'Valor Mensal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioMinimoController.currentModel.valorMensal = salarioMinimoController.valorMensalController.numberValue;
																salarioMinimoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: salarioMinimoController.valorDiarioController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Diario',
																labelText: 'Valor Diario',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioMinimoController.currentModel.valorDiario = salarioMinimoController.valorDiarioController.numberValue;
																salarioMinimoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: salarioMinimoController.valorHoraController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Hora',
																labelText: 'Valor Hora',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioMinimoController.currentModel.valorHora = salarioMinimoController.valorHoraController.numberValue;
																salarioMinimoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: salarioMinimoController.normaLegalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Norma Legal',
																labelText: 'Norma Legal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioMinimoController.currentModel.normaLegal = text;
																salarioMinimoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Dou',
																labelText: 'Dou',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: salarioMinimoController.douController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	salarioMinimoController.currentModel.dou = value;
																	salarioMinimoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
