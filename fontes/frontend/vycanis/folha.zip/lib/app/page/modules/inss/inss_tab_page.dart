import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:folha/app/controller/inss_controller.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';

class InssTabPage extends StatelessWidget {
  InssTabPage({Key? key}) : super(key: key);
  final inssController = Get.find<InssController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          inssController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: inssController.inssTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ inssController.screenTitle } - ${ inssController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: inssController.save),
						cancelAndExitButton(onPressed: inssController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: inssController.tabController,
                  children: inssController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: inssController.tabController,
                onTap: inssController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: inssController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
