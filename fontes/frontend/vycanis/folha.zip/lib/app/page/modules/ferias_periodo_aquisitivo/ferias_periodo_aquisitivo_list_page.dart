import 'package:flutter/material.dart';
import 'package:folha/app/controller/ferias_periodo_aquisitivo_controller.dart';
import 'package:folha/app/page/shared_page/list_page_base.dart';

class FeriasPeriodoAquisitivoListPage extends ListPageBase<FeriasPeriodoAquisitivoController> {
  const FeriasPeriodoAquisitivoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}