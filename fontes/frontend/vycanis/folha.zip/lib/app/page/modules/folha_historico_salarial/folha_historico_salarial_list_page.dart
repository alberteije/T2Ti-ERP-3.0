import 'package:flutter/material.dart';
import 'package:folha/app/controller/folha_historico_salarial_controller.dart';
import 'package:folha/app/page/shared_page/list_page_base.dart';

class FolhaHistoricoSalarialListPage extends ListPageBase<FolhaHistoricoSalarialController> {
  const FolhaHistoricoSalarialListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}