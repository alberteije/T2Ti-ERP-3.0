import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:folha/app/controller/irrf_controller.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';

class IrrfTabPage extends StatelessWidget {
  IrrfTabPage({Key? key}) : super(key: key);
  final irrfController = Get.find<IrrfController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          irrfController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: irrfController.irrfTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ irrfController.screenTitle } - ${ irrfController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: irrfController.save),
						cancelAndExitButton(onPressed: irrfController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: irrfController.tabController,
                  children: irrfController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: irrfController.tabController,
                onTap: irrfController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: irrfController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
