import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';
import 'package:folha/app/controller/salario_familia_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class SalarioFamiliaEditPage extends StatelessWidget {
	SalarioFamiliaEditPage({Key? key}) : super(key: key);
	final salarioFamiliaController = Get.find<SalarioFamiliaController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: salarioFamiliaController.salarioFamiliaScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ salarioFamiliaController.screenTitle } - ${ salarioFamiliaController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: salarioFamiliaController.save),
						cancelAndExitButton(onPressed: salarioFamiliaController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: salarioFamiliaController.salarioFamiliaFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: salarioFamiliaController.scrollController,
							child: SingleChildScrollView(
								controller: salarioFamiliaController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: salarioFamiliaController.faixaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Faixa',
																labelText: 'Faixa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioFamiliaController.salarioFamiliaModel.faixa = int.tryParse(text);
																salarioFamiliaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: salarioFamiliaController.deController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo De',
																labelText: 'De',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioFamiliaController.salarioFamiliaModel.de = salarioFamiliaController.deController.numberValue;
																salarioFamiliaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: salarioFamiliaController.ateController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Ate',
																labelText: 'Ate',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioFamiliaController.salarioFamiliaModel.ate = salarioFamiliaController.ateController.numberValue;
																salarioFamiliaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: salarioFamiliaController.valorController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor',
																labelText: 'Valor',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																salarioFamiliaController.salarioFamiliaModel.valor = salarioFamiliaController.valorController.numberValue;
																salarioFamiliaController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
