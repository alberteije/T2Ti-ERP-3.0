import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';
import 'package:folha/app/data/domain/domain_imports.dart';
import 'package:folha/app/controller/folha_parametro_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class FolhaParametroEditPage extends StatelessWidget {
	FolhaParametroEditPage({Key? key}) : super(key: key);
	final folhaParametroController = Get.find<FolhaParametroController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					folhaParametroController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: folhaParametroController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ folhaParametroController.screenTitle } - ${ folhaParametroController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: folhaParametroController.save),
						cancelAndExitButton(onPressed: folhaParametroController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: folhaParametroController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: folhaParametroController.scrollController,
							child: SingleChildScrollView(
								controller: folhaParametroController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: folhaParametroController.competenciaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Competencia',
																labelText: 'Competencia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaParametroController.currentModel.competencia = text;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.contribuiPisController,
															labelText: 'Contribui Pis',
															hintText: 'Informe os dados para o campo Contribui Pis',
															items: FolhaParametroDomain.contribuiPisListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.contribuiPis = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: folhaParametroController.aliquotaPisController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Pis',
																labelText: 'Aliquota Pis',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaParametroController.currentModel.aliquotaPis = folhaParametroController.aliquotaPisController.numberValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.discriminarDsrController,
															labelText: 'Discriminar Dsr',
															hintText: 'Informe os dados para o campo Discriminar Dsr',
															items: FolhaParametroDomain.discriminarDsrListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.discriminarDsr = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: folhaParametroController.diaPagamentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Dia Pagamento',
																labelText: 'Dia Pagamento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaParametroController.currentModel.diaPagamento = text;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.calculoProporcionalidadeController,
															labelText: 'Calculo Proporcionalidade',
															hintText: 'Informe os dados para o campo Calculo Proporcionalidade',
															items: FolhaParametroDomain.calculoProporcionalidadeListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.calculoProporcionalidade = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.descontarFaltas13Controller,
															labelText: 'Descontar Faltas 13',
															hintText: 'Informe os dados para o campo Descontar Faltas 13',
															items: FolhaParametroDomain.descontarFaltas13ListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.descontarFaltas13 = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.pagarAdicionais13Controller,
															labelText: 'Pagar Adicionais 13',
															hintText: 'Informe os dados para o campo Pagar Adicionais 13',
															items: FolhaParametroDomain.pagarAdicionais13ListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.pagarAdicionais13 = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.pagarEstagiarios13Controller,
															labelText: 'Pagar Estagiarios 13',
															hintText: 'Informe os dados para o campo Pagar Estagiarios 13',
															items: FolhaParametroDomain.pagarEstagiarios13ListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.pagarEstagiarios13 = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: folhaParametroController.mesAdiantamento13Controller,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Mes Adiantamento 13',
																labelText: 'Mes Adiantamento 13',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaParametroController.currentModel.mesAdiantamento13 = text;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: folhaParametroController.percentualAdiantam13Controller,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Percentual Adiantam 13',
																labelText: 'Percentual Adiantam 13',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaParametroController.currentModel.percentualAdiantam13 = folhaParametroController.percentualAdiantam13Controller.numberValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.feriasDescontarFaltasController,
															labelText: 'Ferias Descontar Faltas',
															hintText: 'Informe os dados para o campo Ferias Descontar Faltas',
															items: FolhaParametroDomain.feriasDescontarFaltasListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.feriasDescontarFaltas = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.feriasPagarAdicionaisController,
															labelText: 'Ferias Pagar Adicionais',
															hintText: 'Informe os dados para o campo Ferias Pagar Adicionais',
															items: FolhaParametroDomain.feriasPagarAdicionaisListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.feriasPagarAdicionais = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.feriasAdiantar13Controller,
															labelText: 'Ferias Adiantar 13',
															hintText: 'Informe os dados para o campo Ferias Adiantar 13',
															items: FolhaParametroDomain.feriasAdiantar13ListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.feriasAdiantar13 = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.feriasPagarEstagiariosController,
															labelText: 'Ferias Pagar Estagiarios',
															hintText: 'Informe os dados para o campo Ferias Pagar Estagiarios',
															items: FolhaParametroDomain.feriasPagarEstagiariosListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.feriasPagarEstagiarios = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.feriasCalcJustaCausaController,
															labelText: 'Ferias Calc Justa Causa',
															hintText: 'Informe os dados para o campo Ferias Calc Justa Causa',
															items: FolhaParametroDomain.feriasCalcJustaCausaListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.feriasCalcJustaCausa = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaParametroController.feriasMovimentoMensalController,
															labelText: 'Ferias Movimento Mensal',
															hintText: 'Informe os dados para o campo Ferias Movimento Mensal',
															items: FolhaParametroDomain.feriasMovimentoMensalListDropdown,
															onChanged: (dynamic newValue) {
																folhaParametroController.currentModel.feriasMovimentoMensal = newValue;
																folhaParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
