import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';
import 'package:folha/app/data/domain/domain_imports.dart';
import 'package:folha/app/controller/fpas_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class FpasEditPage extends StatelessWidget {
	FpasEditPage({Key? key}) : super(key: key);
	final fpasController = Get.find<FpasController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					fpasController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: fpasController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ fpasController.screenTitle } - ${ fpasController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: fpasController.save),
						cancelAndExitButton(onPressed: fpasController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: fpasController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: fpasController.scrollController,
							child: SingleChildScrollView(
								controller: fpasController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fpasController.codigoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo',
																labelText: 'Codigo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fpasController.currentModel.codigo = int.tryParse(text);
																fpasController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 14,
															controller: fpasController.cnaeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cnae',
																labelText: 'Cnae',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fpasController.currentModel.cnae = text;
																fpasController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fpasController.aliquotaSatController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Sat',
																labelText: 'Aliquota Sat',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fpasController.currentModel.aliquotaSat = fpasController.aliquotaSatController.numberValue;
																fpasController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 250,
															controller: fpasController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fpasController.currentModel.descricao = text;
																fpasController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fpasController.percentualInssPatronalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Percentual Inss Patronal',
																labelText: 'Percentual Inss Patronal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fpasController.currentModel.percentualInssPatronal = fpasController.percentualInssPatronalController.numberValue;
																fpasController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: fpasController.codigoTerceiroController,
															labelText: 'Codigo Terceiro',
															hintText: 'Informe os dados para o campo Codigo Terceiro',
															items: FpasDomain.codigoTerceiroListDropdown,
															onChanged: (dynamic newValue) {
																fpasController.currentModel.codigoTerceiro = newValue;
																fpasController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fpasController.percentualTerceirosController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Percentual Terceiros',
																labelText: 'Percentual Terceiros',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fpasController.currentModel.percentualTerceiros = fpasController.percentualTerceirosController.numberValue;
																fpasController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
