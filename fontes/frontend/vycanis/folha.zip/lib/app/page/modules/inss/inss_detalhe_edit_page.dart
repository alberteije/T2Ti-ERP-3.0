import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';
import 'package:folha/app/controller/inss_detalhe_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class InssDetalheEditPage extends StatelessWidget {
	InssDetalheEditPage({Key? key}) : super(key: key);
	final inssDetalheController = Get.find<InssDetalheController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: inssDetalheController.inssDetalheScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ inssDetalheController.screenTitle } - ${ inssDetalheController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: inssDetalheController.save),
						cancelAndExitButton(onPressed: inssDetalheController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: inssDetalheController.inssDetalheFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: inssDetalheController.scrollController,
							child: SingleChildScrollView(
								controller: inssDetalheController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: inssDetalheController.faixaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Faixa',
																labelText: 'Faixa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																inssDetalheController.inssDetalheModel.faixa = int.tryParse(text);
																inssDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: inssDetalheController.deController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo De',
																labelText: 'De',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																inssDetalheController.inssDetalheModel.de = inssDetalheController.deController.numberValue;
																inssDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: inssDetalheController.ateController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Ate',
																labelText: 'Ate',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																inssDetalheController.inssDetalheModel.ate = inssDetalheController.ateController.numberValue;
																inssDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: inssDetalheController.taxaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa',
																labelText: 'Taxa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																inssDetalheController.inssDetalheModel.taxa = inssDetalheController.taxaController.numberValue;
																inssDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
