import 'package:flutter/material.dart';
import 'package:folha/app/controller/inss_controller.dart';
import 'package:folha/app/page/shared_page/list_page_base.dart';

class InssListPage extends ListPageBase<InssController> {
  const InssListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}