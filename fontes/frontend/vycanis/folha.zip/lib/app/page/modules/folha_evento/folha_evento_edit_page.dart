import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/page/shared_widget/shared_widget_imports.dart';
import 'package:folha/app/data/domain/domain_imports.dart';
import 'package:folha/app/controller/folha_evento_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class FolhaEventoEditPage extends StatelessWidget {
	FolhaEventoEditPage({Key? key}) : super(key: key);
	final folhaEventoController = Get.find<FolhaEventoController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					folhaEventoController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: folhaEventoController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ folhaEventoController.screenTitle } - ${ folhaEventoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: folhaEventoController.save),
						cancelAndExitButton(onPressed: folhaEventoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: folhaEventoController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: folhaEventoController.scrollController,
							child: SingleChildScrollView(
								controller: folhaEventoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: folhaEventoController.codigoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo',
																labelText: 'Codigo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.codigo = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: folhaEventoController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.nome = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: folhaEventoController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.descricao = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaEventoController.baseCalculoController,
															labelText: 'Base Calculo',
															hintText: 'Informe os dados para o campo Base Calculo',
															items: FolhaEventoDomain.baseCalculoListDropdown,
															onChanged: (dynamic newValue) {
																folhaEventoController.currentModel.baseCalculo = newValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaEventoController.tipoController,
															labelText: 'Tipo',
															hintText: 'Informe os dados para o campo Tipo',
															items: FolhaEventoDomain.tipoListDropdown,
															onChanged: (dynamic newValue) {
																folhaEventoController.currentModel.tipo = newValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaEventoController.unidadeController,
															labelText: 'Unidade',
															hintText: 'Informe os dados para o campo Unidade',
															items: FolhaEventoDomain.unidadeListDropdown,
															onChanged: (dynamic newValue) {
																folhaEventoController.currentModel.unidade = newValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: folhaEventoController.taxaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa',
																labelText: 'Taxa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.taxa = folhaEventoController.taxaController.numberValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 4,
															controller: folhaEventoController.rubricaEsocialController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Rubrica Esocial',
																labelText: 'Rubrica Esocial',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.rubricaEsocial = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: folhaEventoController.codIncidenciaPrevidenciaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cod Incidencia Previdencia',
																labelText: 'Cod Incidencia Previdencia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.codIncidenciaPrevidencia = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: folhaEventoController.codIncidenciaIrrfController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cod Incidencia Irrf',
																labelText: 'Cod Incidencia IRRF',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.codIncidenciaIrrf = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: folhaEventoController.codIncidenciaFgtsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cod Incidencia Fgts',
																labelText: 'Cod Incidencia FGTS',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.codIncidenciaFgts = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: folhaEventoController.codIncidenciaSindicatoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cod Incidencia Sindicato',
																labelText: 'Cod Incidencia Sindicato',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																folhaEventoController.currentModel.codIncidenciaSindicato = text;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaEventoController.repercuteDsrController,
															labelText: 'Repercute DSR',
															hintText: 'Informe os dados para o campo Repercute Dsr',
															items: FolhaEventoDomain.repercuteDsrListDropdown,
															onChanged: (dynamic newValue) {
																folhaEventoController.currentModel.repercuteDsr = newValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaEventoController.repercute13Controller,
															labelText: 'Repercute 13',
															hintText: 'Informe os dados para o campo Repercute 13',
															items: FolhaEventoDomain.repercute13ListDropdown,
															onChanged: (dynamic newValue) {
																folhaEventoController.currentModel.repercute13 = newValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaEventoController.repercuteFeriasController,
															labelText: 'Repercute Ferias',
															hintText: 'Informe os dados para o campo Repercute Ferias',
															items: FolhaEventoDomain.repercuteFeriasListDropdown,
															onChanged: (dynamic newValue) {
																folhaEventoController.currentModel.repercuteFerias = newValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: folhaEventoController.repercuteAvisoController,
															labelText: 'Repercute Aviso',
															hintText: 'Informe os dados para o campo Repercute Aviso',
															items: FolhaEventoDomain.repercuteAvisoListDropdown,
															onChanged: (dynamic newValue) {
																folhaEventoController.currentModel.repercuteAviso = newValue;
																folhaEventoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
