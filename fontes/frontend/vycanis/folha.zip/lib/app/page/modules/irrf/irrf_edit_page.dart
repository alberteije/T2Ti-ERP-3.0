import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:folha/app/controller/irrf_controller.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/page/shared_widget/input/input_imports.dart';

class IrrfEditPage extends StatelessWidget {
	IrrfEditPage({Key? key}) : super(key: key);
	final irrfController = Get.find<IrrfController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: irrfController.irrfScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: irrfController.irrfFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: irrfController.scrollController,
							child: SingleChildScrollView(
								controller: irrfController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfController.competenciaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Competencia',
																labelText: 'Competencia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfController.currentModel.competencia = text;
																irrfController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfController.descontoPorDependenteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Desconto Por Dependente',
																labelText: 'Desconto Por Dependente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfController.currentModel.descontoPorDependente = irrfController.descontoPorDependenteController.numberValue;
																irrfController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: irrfController.minimoParaRetencaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Minimo Para Retencao',
																labelText: 'Minimo Para Retencao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																irrfController.currentModel.minimoParaRetencao = irrfController.minimoParaRetencaoController.numberValue;
																irrfController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
