import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/salario_minimo_api_provider.dart';
import 'package:folha/app/data/provider/drift/salario_minimo_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SalarioMinimoRepository {
  final SalarioMinimoApiProvider salarioMinimoApiProvider;
  final SalarioMinimoDriftProvider salarioMinimoDriftProvider;

  SalarioMinimoRepository({required this.salarioMinimoApiProvider, required this.salarioMinimoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await salarioMinimoDriftProvider.getList(filter: filter);
    } else {
      return await salarioMinimoApiProvider.getList(filter: filter);
    }
  }

  Future<SalarioMinimoModel?>? save({required SalarioMinimoModel salarioMinimoModel}) async {
    if (salarioMinimoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await salarioMinimoDriftProvider.update(salarioMinimoModel);
      } else {
        return await salarioMinimoApiProvider.update(salarioMinimoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await salarioMinimoDriftProvider.insert(salarioMinimoModel);
      } else {
        return await salarioMinimoApiProvider.insert(salarioMinimoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await salarioMinimoDriftProvider.delete(id) ?? false;
    } else {
      return await salarioMinimoApiProvider.delete(id) ?? false;
    }
  }
}