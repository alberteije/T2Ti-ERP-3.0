import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/irrf_api_provider.dart';
import 'package:folha/app/data/provider/drift/irrf_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class IrrfRepository {
  final IrrfApiProvider irrfApiProvider;
  final IrrfDriftProvider irrfDriftProvider;

  IrrfRepository({required this.irrfApiProvider, required this.irrfDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await irrfDriftProvider.getList(filter: filter);
    } else {
      return await irrfApiProvider.getList(filter: filter);
    }
  }

  Future<IrrfModel?>? save({required IrrfModel irrfModel}) async {
    if (irrfModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await irrfDriftProvider.update(irrfModel);
      } else {
        return await irrfApiProvider.update(irrfModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await irrfDriftProvider.insert(irrfModel);
      } else {
        return await irrfApiProvider.insert(irrfModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await irrfDriftProvider.delete(id) ?? false;
    } else {
      return await irrfApiProvider.delete(id) ?? false;
    }
  }
}