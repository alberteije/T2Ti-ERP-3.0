import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/cbo_api_provider.dart';
import 'package:folha/app/data/provider/drift/cbo_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class CboRepository {
  final CboApiProvider cboApiProvider;
  final CboDriftProvider cboDriftProvider;

  CboRepository({required this.cboApiProvider, required this.cboDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await cboDriftProvider.getList(filter: filter);
    } else {
      return await cboApiProvider.getList(filter: filter);
    }
  }

  Future<CboModel?>? save({required CboModel cboModel}) async {
    if (cboModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await cboDriftProvider.update(cboModel);
      } else {
        return await cboApiProvider.update(cboModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await cboDriftProvider.insert(cboModel);
      } else {
        return await cboApiProvider.insert(cboModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await cboDriftProvider.delete(id) ?? false;
    } else {
      return await cboApiProvider.delete(id) ?? false;
    }
  }
}