import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/fpas_api_provider.dart';
import 'package:folha/app/data/provider/drift/fpas_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FpasRepository {
  final FpasApiProvider fpasApiProvider;
  final FpasDriftProvider fpasDriftProvider;

  FpasRepository({required this.fpasApiProvider, required this.fpasDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await fpasDriftProvider.getList(filter: filter);
    } else {
      return await fpasApiProvider.getList(filter: filter);
    }
  }

  Future<FpasModel?>? save({required FpasModel fpasModel}) async {
    if (fpasModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await fpasDriftProvider.update(fpasModel);
      } else {
        return await fpasApiProvider.update(fpasModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await fpasDriftProvider.insert(fpasModel);
      } else {
        return await fpasApiProvider.insert(fpasModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await fpasDriftProvider.delete(id) ?? false;
    } else {
      return await fpasApiProvider.delete(id) ?? false;
    }
  }
}