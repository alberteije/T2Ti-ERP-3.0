import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/inss_api_provider.dart';
import 'package:folha/app/data/provider/drift/inss_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class InssRepository {
  final InssApiProvider inssApiProvider;
  final InssDriftProvider inssDriftProvider;

  InssRepository({required this.inssApiProvider, required this.inssDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await inssDriftProvider.getList(filter: filter);
    } else {
      return await inssApiProvider.getList(filter: filter);
    }
  }

  Future<InssModel?>? save({required InssModel inssModel}) async {
    if (inssModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await inssDriftProvider.update(inssModel);
      } else {
        return await inssApiProvider.update(inssModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await inssDriftProvider.insert(inssModel);
      } else {
        return await inssApiProvider.insert(inssModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await inssDriftProvider.delete(id) ?? false;
    } else {
      return await inssApiProvider.delete(id) ?? false;
    }
  }
}