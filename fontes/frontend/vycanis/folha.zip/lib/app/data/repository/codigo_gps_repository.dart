import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/codigo_gps_api_provider.dart';
import 'package:folha/app/data/provider/drift/codigo_gps_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class CodigoGpsRepository {
  final CodigoGpsApiProvider codigoGpsApiProvider;
  final CodigoGpsDriftProvider codigoGpsDriftProvider;

  CodigoGpsRepository({required this.codigoGpsApiProvider, required this.codigoGpsDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await codigoGpsDriftProvider.getList(filter: filter);
    } else {
      return await codigoGpsApiProvider.getList(filter: filter);
    }
  }

  Future<CodigoGpsModel?>? save({required CodigoGpsModel codigoGpsModel}) async {
    if (codigoGpsModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await codigoGpsDriftProvider.update(codigoGpsModel);
      } else {
        return await codigoGpsApiProvider.update(codigoGpsModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await codigoGpsDriftProvider.insert(codigoGpsModel);
      } else {
        return await codigoGpsApiProvider.insert(codigoGpsModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await codigoGpsDriftProvider.delete(id) ?? false;
    } else {
      return await codigoGpsApiProvider.delete(id) ?? false;
    }
  }
}