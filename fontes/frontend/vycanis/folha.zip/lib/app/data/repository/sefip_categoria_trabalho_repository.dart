import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/sefip_categoria_trabalho_api_provider.dart';
import 'package:folha/app/data/provider/drift/sefip_categoria_trabalho_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCategoriaTrabalhoRepository {
  final SefipCategoriaTrabalhoApiProvider sefipCategoriaTrabalhoApiProvider;
  final SefipCategoriaTrabalhoDriftProvider sefipCategoriaTrabalhoDriftProvider;

  SefipCategoriaTrabalhoRepository({required this.sefipCategoriaTrabalhoApiProvider, required this.sefipCategoriaTrabalhoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await sefipCategoriaTrabalhoDriftProvider.getList(filter: filter);
    } else {
      return await sefipCategoriaTrabalhoApiProvider.getList(filter: filter);
    }
  }

  Future<SefipCategoriaTrabalhoModel?>? save({required SefipCategoriaTrabalhoModel sefipCategoriaTrabalhoModel}) async {
    if (sefipCategoriaTrabalhoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await sefipCategoriaTrabalhoDriftProvider.update(sefipCategoriaTrabalhoModel);
      } else {
        return await sefipCategoriaTrabalhoApiProvider.update(sefipCategoriaTrabalhoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await sefipCategoriaTrabalhoDriftProvider.insert(sefipCategoriaTrabalhoModel);
      } else {
        return await sefipCategoriaTrabalhoApiProvider.insert(sefipCategoriaTrabalhoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await sefipCategoriaTrabalhoDriftProvider.delete(id) ?? false;
    } else {
      return await sefipCategoriaTrabalhoApiProvider.delete(id) ?? false;
    }
  }
}