import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/sefip_codigo_movimentacao_api_provider.dart';
import 'package:folha/app/data/provider/drift/sefip_codigo_movimentacao_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCodigoMovimentacaoRepository {
  final SefipCodigoMovimentacaoApiProvider sefipCodigoMovimentacaoApiProvider;
  final SefipCodigoMovimentacaoDriftProvider sefipCodigoMovimentacaoDriftProvider;

  SefipCodigoMovimentacaoRepository({required this.sefipCodigoMovimentacaoApiProvider, required this.sefipCodigoMovimentacaoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await sefipCodigoMovimentacaoDriftProvider.getList(filter: filter);
    } else {
      return await sefipCodigoMovimentacaoApiProvider.getList(filter: filter);
    }
  }

  Future<SefipCodigoMovimentacaoModel?>? save({required SefipCodigoMovimentacaoModel sefipCodigoMovimentacaoModel}) async {
    if (sefipCodigoMovimentacaoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await sefipCodigoMovimentacaoDriftProvider.update(sefipCodigoMovimentacaoModel);
      } else {
        return await sefipCodigoMovimentacaoApiProvider.update(sefipCodigoMovimentacaoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await sefipCodigoMovimentacaoDriftProvider.insert(sefipCodigoMovimentacaoModel);
      } else {
        return await sefipCodigoMovimentacaoApiProvider.insert(sefipCodigoMovimentacaoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await sefipCodigoMovimentacaoDriftProvider.delete(id) ?? false;
    } else {
      return await sefipCodigoMovimentacaoApiProvider.delete(id) ?? false;
    }
  }
}