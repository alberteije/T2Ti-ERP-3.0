import 'package:folha/app/infra/constants.dart';
import 'package:folha/app/data/provider/api/sefip_codigo_recolhimento_api_provider.dart';
import 'package:folha/app/data/provider/drift/sefip_codigo_recolhimento_drift_provider.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCodigoRecolhimentoRepository {
  final SefipCodigoRecolhimentoApiProvider sefipCodigoRecolhimentoApiProvider;
  final SefipCodigoRecolhimentoDriftProvider sefipCodigoRecolhimentoDriftProvider;

  SefipCodigoRecolhimentoRepository({required this.sefipCodigoRecolhimentoApiProvider, required this.sefipCodigoRecolhimentoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await sefipCodigoRecolhimentoDriftProvider.getList(filter: filter);
    } else {
      return await sefipCodigoRecolhimentoApiProvider.getList(filter: filter);
    }
  }

  Future<SefipCodigoRecolhimentoModel?>? save({required SefipCodigoRecolhimentoModel sefipCodigoRecolhimentoModel}) async {
    if (sefipCodigoRecolhimentoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await sefipCodigoRecolhimentoDriftProvider.update(sefipCodigoRecolhimentoModel);
      } else {
        return await sefipCodigoRecolhimentoApiProvider.update(sefipCodigoRecolhimentoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await sefipCodigoRecolhimentoDriftProvider.insert(sefipCodigoRecolhimentoModel);
      } else {
        return await sefipCodigoRecolhimentoApiProvider.insert(sefipCodigoRecolhimentoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await sefipCodigoRecolhimentoDriftProvider.delete(id) ?? false;
    } else {
      return await sefipCodigoRecolhimentoApiProvider.delete(id) ?? false;
    }
  }
}