class FpasDomain {
  FpasDomain._();

  static getCodigoTerceiro(String? codigoTerceiro) { 
		switch (codigoTerceiro) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

  static setCodigoTerceiro(String? codigoTerceiro) { 
		switch (codigoTerceiro) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final codigoTerceiroListDropdown = ['AAA','BBB','CCC'];

}