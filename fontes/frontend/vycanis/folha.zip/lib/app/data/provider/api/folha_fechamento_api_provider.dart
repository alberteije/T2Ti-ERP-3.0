import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaFechamentoApiProvider extends ApiProviderBase {
  static const _path = '/folha-fechamento';

  Future<List<FolhaFechamentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaFechamentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaFechamentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaFechamentoModel.fromJson(json),
    );
  }

  Future<FolhaFechamentoModel?>? insert(FolhaFechamentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaFechamentoModel.fromJson(json),
    );
  }

  Future<FolhaFechamentoModel?>? update(FolhaFechamentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaFechamentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
