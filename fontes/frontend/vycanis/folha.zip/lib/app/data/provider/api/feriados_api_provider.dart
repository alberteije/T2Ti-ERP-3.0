import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FeriadosApiProvider extends ApiProviderBase {
  static const _path = '/feriados';

  Future<List<FeriadosModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FeriadosModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FeriadosModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FeriadosModel.fromJson(json),
    );
  }

  Future<FeriadosModel?>? insert(FeriadosModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FeriadosModel.fromJson(json),
    );
  }

  Future<FeriadosModel?>? update(FeriadosModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FeriadosModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
