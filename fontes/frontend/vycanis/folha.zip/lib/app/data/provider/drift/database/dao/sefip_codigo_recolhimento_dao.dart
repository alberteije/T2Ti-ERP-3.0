import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'sefip_codigo_recolhimento_dao.g.dart';

@DriftAccessor(tables: [
	SefipCodigoRecolhimentos,
])
class SefipCodigoRecolhimentoDao extends DatabaseAccessor<AppDatabase> with _$SefipCodigoRecolhimentoDaoMixin {
	final AppDatabase db;

	List<SefipCodigoRecolhimento> sefipCodigoRecolhimentoList = []; 
	List<SefipCodigoRecolhimentoGrouped> sefipCodigoRecolhimentoGroupedList = []; 

	SefipCodigoRecolhimentoDao(this.db) : super(db);

	Future<List<SefipCodigoRecolhimento>> getList() async {
		sefipCodigoRecolhimentoList = await select(sefipCodigoRecolhimentos).get();
		return sefipCodigoRecolhimentoList;
	}

	Future<List<SefipCodigoRecolhimento>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		sefipCodigoRecolhimentoList = await (select(sefipCodigoRecolhimentos)..where((t) => expression)).get();
		return sefipCodigoRecolhimentoList;	 
	}

	Future<List<SefipCodigoRecolhimentoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(sefipCodigoRecolhimentos)
			.join([]);

		if (field != null && field != '') { 
			final column = sefipCodigoRecolhimentos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		sefipCodigoRecolhimentoGroupedList = await query.map((row) {
			final sefipCodigoRecolhimento = row.readTableOrNull(sefipCodigoRecolhimentos); 

			return SefipCodigoRecolhimentoGrouped(
				sefipCodigoRecolhimento: sefipCodigoRecolhimento, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var sefipCodigoRecolhimentoGrouped in sefipCodigoRecolhimentoGroupedList) {
		//}		

		return sefipCodigoRecolhimentoGroupedList;	
	}

	Future<SefipCodigoRecolhimento?> getObject(dynamic pk) async {
		return await (select(sefipCodigoRecolhimentos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<SefipCodigoRecolhimento?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM sefip_codigo_recolhimento WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as SefipCodigoRecolhimento;		 
	} 

	Future<SefipCodigoRecolhimentoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(SefipCodigoRecolhimentoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.sefipCodigoRecolhimento = object.sefipCodigoRecolhimento!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(sefipCodigoRecolhimentos).insert(object.sefipCodigoRecolhimento!);
			object.sefipCodigoRecolhimento = object.sefipCodigoRecolhimento!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(SefipCodigoRecolhimentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(sefipCodigoRecolhimentos).replace(object.sefipCodigoRecolhimento!);
		});	 
	} 

	Future<int> deleteObject(SefipCodigoRecolhimentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(sefipCodigoRecolhimentos).delete(object.sefipCodigoRecolhimento!);
		});		
	}

	Future<void> insertChildren(SefipCodigoRecolhimentoGrouped object) async {
	}
	
	Future<void> deleteChildren(SefipCodigoRecolhimentoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from sefip_codigo_recolhimento").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}