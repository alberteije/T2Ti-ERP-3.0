import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaHistoricoSalarialApiProvider extends ApiProviderBase {
  static const _path = '/folha-historico-salarial';

  Future<List<FolhaHistoricoSalarialModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaHistoricoSalarialModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaHistoricoSalarialModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaHistoricoSalarialModel.fromJson(json),
    );
  }

  Future<FolhaHistoricoSalarialModel?>? insert(FolhaHistoricoSalarialModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaHistoricoSalarialModel.fromJson(json),
    );
  }

  Future<FolhaHistoricoSalarialModel?>? update(FolhaHistoricoSalarialModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaHistoricoSalarialModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
