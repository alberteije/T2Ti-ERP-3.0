import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaLancamentoComissaoApiProvider extends ApiProviderBase {
  static const _path = '/folha-lancamento-comissao';

  Future<List<FolhaLancamentoComissaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaLancamentoComissaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaLancamentoComissaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaLancamentoComissaoModel.fromJson(json),
    );
  }

  Future<FolhaLancamentoComissaoModel?>? insert(FolhaLancamentoComissaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaLancamentoComissaoModel.fromJson(json),
    );
  }

  Future<FolhaLancamentoComissaoModel?>? update(FolhaLancamentoComissaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaLancamentoComissaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
