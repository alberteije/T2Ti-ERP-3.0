// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'irrf_dao.dart';

// ignore_for_file: type=lint
mixin _$IrrfDaoMixin on DatabaseAccessor<AppDatabase> {
  $IrrfsTable get irrfs => attachedDatabase.irrfs;
  $IrrfDetalhesTable get irrfDetalhes => attachedDatabase.irrfDetalhes;
}
