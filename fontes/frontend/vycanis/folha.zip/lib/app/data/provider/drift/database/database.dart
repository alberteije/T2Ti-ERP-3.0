import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'database.g.dart';

@DriftDatabase(
	tables: [
		EmpresaTransporteItinerarios,
		FolhaLancamentoDetalhes,
		FolhaInssRetencaos,
		FolhaPppCats,
		FolhaPppAtividades,
		FolhaPppFatorRiscos,
		FolhaPppExameMedicos,
		IrrfDetalhes,
		InssDetalhes,
		SalarioFamilias,
		EmpresaTransportes,
		FolhaLancamentoCabecalhos,
		FolhaInsss,
		FolhaPpps,
		Irrfs,
		Insss,
		OperadoraPlanoSaudes,
		FolhaLancamentoComissaos,
		FolhaParametros,
		GuiasAcumuladass,
		FolhaFechamentos,
		FeriasPeriodoAquisitivos,
		FolhaTipoAfastamentos,
		FolhaAfastamentos,
		FolhaPlanoSaudes,
		FolhaEventos,
		FolhaRescisaos,
		FolhaFeriasColetivass,
		FolhaValeTransportes,
		FolhaInssServicos,
		FolhaHistoricoSalarials,
		Feriadoss,
		ViewControleAcessos,
		ViewPessoaUsuarios,
		ViewPessoaColaboradors,
		Cbos,
		CodigoGpss,
		Fpass,
		SalarioMinimos,
		SefipCodigoMovimentacaos,
		SefipCategoriaTrabalhos,
		SefipCodigoRecolhimentos,
 ], 
	daos: [
		EmpresaTransporteDao,
		FolhaLancamentoCabecalhoDao,
		FolhaInssDao,
		FolhaPppDao,
		IrrfDao,
		InssDao,
		OperadoraPlanoSaudeDao,
		FolhaLancamentoComissaoDao,
		FolhaParametroDao,
		GuiasAcumuladasDao,
		FolhaFechamentoDao,
		FeriasPeriodoAquisitivoDao,
		FolhaTipoAfastamentoDao,
		FolhaAfastamentoDao,
		FolhaPlanoSaudeDao,
		FolhaEventoDao,
		FolhaRescisaoDao,
		FolhaFeriasColetivasDao,
		FolhaValeTransporteDao,
		FolhaInssServicoDao,
		FolhaHistoricoSalarialDao,
		FeriadosDao,
		ViewControleAcessoDao,
		ViewPessoaUsuarioDao,
		ViewPessoaColaboradorDao,
		CboDao,
		CodigoGpsDao,
		FpasDao,
		SalarioMinimoDao,
		SefipCodigoMovimentacaoDao,
		SefipCategoriaTrabalhoDao,
		SefipCodigoRecolhimentoDao,
	],
)

class AppDatabase extends _$AppDatabase {
	AppDatabase(QueryExecutor executor) : super(executor);

	@override
	int get schemaVersion => 1;

	@override
	MigrationStrategy get migration => MigrationStrategy(
		onCreate: (Migrator m) async {
			await m.createAll();
			await _populateDatabase(this);
		},		
	);	
}

Future<void> _populateDatabase(db) async {
	await db.customStatement("CREATE TABLE HIDDEN_SETTINGS("
				"ID INTEGER PRIMARY KEY,"
				"APP_THEME TEXT"
			")");
	await db.customStatement("INSERT INTO HIDDEN_SETTINGS (ID, APP_THEME) VALUES (1, 'ThemeMode.light')");
}
