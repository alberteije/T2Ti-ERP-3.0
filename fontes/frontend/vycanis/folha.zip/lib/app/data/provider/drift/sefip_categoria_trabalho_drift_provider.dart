import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCategoriaTrabalhoDriftProvider extends ProviderBase {

	Future<List<SefipCategoriaTrabalhoModel>?> getList({Filter? filter}) async {
		List<SefipCategoriaTrabalhoGrouped> sefipCategoriaTrabalhoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				sefipCategoriaTrabalhoDriftList = await Session.database.sefipCategoriaTrabalhoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				sefipCategoriaTrabalhoDriftList = await Session.database.sefipCategoriaTrabalhoDao.getGroupedList(); 
			}
			if (sefipCategoriaTrabalhoDriftList.isNotEmpty) {
				return toListModel(sefipCategoriaTrabalhoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<SefipCategoriaTrabalhoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.sefipCategoriaTrabalhoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SefipCategoriaTrabalhoModel?>? insert(SefipCategoriaTrabalhoModel sefipCategoriaTrabalhoModel) async {
		try {
			final lastPk = await Session.database.sefipCategoriaTrabalhoDao.insertObject(toDrift(sefipCategoriaTrabalhoModel));
			sefipCategoriaTrabalhoModel.id = lastPk;
			return sefipCategoriaTrabalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SefipCategoriaTrabalhoModel?>? update(SefipCategoriaTrabalhoModel sefipCategoriaTrabalhoModel) async {
		try {
			await Session.database.sefipCategoriaTrabalhoDao.updateObject(toDrift(sefipCategoriaTrabalhoModel));
			return sefipCategoriaTrabalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.sefipCategoriaTrabalhoDao.deleteObject(toDrift(SefipCategoriaTrabalhoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<SefipCategoriaTrabalhoModel> toListModel(List<SefipCategoriaTrabalhoGrouped> sefipCategoriaTrabalhoDriftList) {
		List<SefipCategoriaTrabalhoModel> listModel = [];
		for (var sefipCategoriaTrabalhoDrift in sefipCategoriaTrabalhoDriftList) {
			listModel.add(toModel(sefipCategoriaTrabalhoDrift)!);
		}
		return listModel;
	}	

	SefipCategoriaTrabalhoModel? toModel(SefipCategoriaTrabalhoGrouped? sefipCategoriaTrabalhoDrift) {
		if (sefipCategoriaTrabalhoDrift != null) {
			return SefipCategoriaTrabalhoModel(
				id: sefipCategoriaTrabalhoDrift.sefipCategoriaTrabalho?.id,
				codigo: sefipCategoriaTrabalhoDrift.sefipCategoriaTrabalho?.codigo,
				nome: sefipCategoriaTrabalhoDrift.sefipCategoriaTrabalho?.nome,
			);
		} else {
			return null;
		}
	}


	SefipCategoriaTrabalhoGrouped toDrift(SefipCategoriaTrabalhoModel sefipCategoriaTrabalhoModel) {
		return SefipCategoriaTrabalhoGrouped(
			sefipCategoriaTrabalho: SefipCategoriaTrabalho(
				id: sefipCategoriaTrabalhoModel.id,
				codigo: sefipCategoriaTrabalhoModel.codigo,
				nome: sefipCategoriaTrabalhoModel.nome,
			),
		);
	}

		
}
