import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';

class CboDriftProvider extends ProviderBase {

	Future<List<CboModel>?> getList({Filter? filter}) async {
		List<CboGrouped> cboDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				cboDriftList = await Session.database.cboDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				cboDriftList = await Session.database.cboDao.getGroupedList(); 
			}
			if (cboDriftList.isNotEmpty) {
				return toListModel(cboDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CboModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.cboDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CboModel?>? insert(CboModel cboModel) async {
		try {
			final lastPk = await Session.database.cboDao.insertObject(toDrift(cboModel));
			cboModel.id = lastPk;
			return cboModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CboModel?>? update(CboModel cboModel) async {
		try {
			await Session.database.cboDao.updateObject(toDrift(cboModel));
			return cboModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.cboDao.deleteObject(toDrift(CboModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CboModel> toListModel(List<CboGrouped> cboDriftList) {
		List<CboModel> listModel = [];
		for (var cboDrift in cboDriftList) {
			listModel.add(toModel(cboDrift)!);
		}
		return listModel;
	}	

	CboModel? toModel(CboGrouped? cboDrift) {
		if (cboDrift != null) {
			return CboModel(
				id: cboDrift.cbo?.id,
				codigo: cboDrift.cbo?.codigo,
				codigo1994: cboDrift.cbo?.codigo1994,
				nome: cboDrift.cbo?.nome,
				observacao: cboDrift.cbo?.observacao,
			);
		} else {
			return null;
		}
	}


	CboGrouped toDrift(CboModel cboModel) {
		return CboGrouped(
			cbo: Cbo(
				id: cboModel.id,
				codigo: cboModel.codigo,
				codigo1994: cboModel.codigo1994,
				nome: cboModel.nome,
				observacao: cboModel.observacao,
			),
		);
	}

		
}
