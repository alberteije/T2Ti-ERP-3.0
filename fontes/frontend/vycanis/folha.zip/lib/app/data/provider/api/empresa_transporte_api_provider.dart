import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class EmpresaTransporteApiProvider extends ApiProviderBase {
  static const _path = '/empresa-transporte';

  Future<List<EmpresaTransporteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => EmpresaTransporteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<EmpresaTransporteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => EmpresaTransporteModel.fromJson(json),
    );
  }

  Future<EmpresaTransporteModel?>? insert(EmpresaTransporteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => EmpresaTransporteModel.fromJson(json),
    );
  }

  Future<EmpresaTransporteModel?>? update(EmpresaTransporteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => EmpresaTransporteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
