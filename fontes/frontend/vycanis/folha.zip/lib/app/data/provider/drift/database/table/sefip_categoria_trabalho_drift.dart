import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("SefipCategoriaTrabalho")
class SefipCategoriaTrabalhos extends Table {
	@override
	String get tableName => 'sefip_categoria_trabalho';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get codigo => integer().named('codigo').nullable()();
	TextColumn get nome => text().named('nome').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class SefipCategoriaTrabalhoGrouped {
	SefipCategoriaTrabalho? sefipCategoriaTrabalho; 

  SefipCategoriaTrabalhoGrouped({
		this.sefipCategoriaTrabalho, 

  });
}
