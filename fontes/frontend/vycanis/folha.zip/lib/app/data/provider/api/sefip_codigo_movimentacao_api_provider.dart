import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCodigoMovimentacaoApiProvider extends ApiProviderBase {
  static const _path = '/sefip-codigo-movimentacao';

  Future<List<SefipCodigoMovimentacaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => SefipCodigoMovimentacaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<SefipCodigoMovimentacaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => SefipCodigoMovimentacaoModel.fromJson(json),
    );
  }

  Future<SefipCodigoMovimentacaoModel?>? insert(SefipCodigoMovimentacaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => SefipCodigoMovimentacaoModel.fromJson(json),
    );
  }

  Future<SefipCodigoMovimentacaoModel?>? update(SefipCodigoMovimentacaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => SefipCodigoMovimentacaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
