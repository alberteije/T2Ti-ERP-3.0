import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaPlanoSaudeApiProvider extends ApiProviderBase {
  static const _path = '/folha-plano-saude';

  Future<List<FolhaPlanoSaudeModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaPlanoSaudeModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaPlanoSaudeModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaPlanoSaudeModel.fromJson(json),
    );
  }

  Future<FolhaPlanoSaudeModel?>? insert(FolhaPlanoSaudeModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaPlanoSaudeModel.fromJson(json),
    );
  }

  Future<FolhaPlanoSaudeModel?>? update(FolhaPlanoSaudeModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaPlanoSaudeModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
