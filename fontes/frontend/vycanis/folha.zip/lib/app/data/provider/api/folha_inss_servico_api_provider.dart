import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaInssServicoApiProvider extends ApiProviderBase {
  static const _path = '/folha-inss-servico';

  Future<List<FolhaInssServicoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaInssServicoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaInssServicoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaInssServicoModel.fromJson(json),
    );
  }

  Future<FolhaInssServicoModel?>? insert(FolhaInssServicoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaInssServicoModel.fromJson(json),
    );
  }

  Future<FolhaInssServicoModel?>? update(FolhaInssServicoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaInssServicoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
