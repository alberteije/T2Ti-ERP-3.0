import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("SefipCodigoMovimentacao")
class SefipCodigoMovimentacaos extends Table {
	@override
	String get tableName => 'sefip_codigo_movimentacao';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get codigo => text().named('codigo').withLength(min: 0, max: 2).nullable()();
	TextColumn get descricao => text().named('descricao').nullable()();
	TextColumn get aplicacao => text().named('aplicacao').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class SefipCodigoMovimentacaoGrouped {
	SefipCodigoMovimentacao? sefipCodigoMovimentacao; 

  SefipCodigoMovimentacaoGrouped({
		this.sefipCodigoMovimentacao, 

  });
}
