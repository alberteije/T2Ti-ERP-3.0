import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SalarioMinimoDriftProvider extends ProviderBase {

	Future<List<SalarioMinimoModel>?> getList({Filter? filter}) async {
		List<SalarioMinimoGrouped> salarioMinimoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				salarioMinimoDriftList = await Session.database.salarioMinimoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				salarioMinimoDriftList = await Session.database.salarioMinimoDao.getGroupedList(); 
			}
			if (salarioMinimoDriftList.isNotEmpty) {
				return toListModel(salarioMinimoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<SalarioMinimoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.salarioMinimoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SalarioMinimoModel?>? insert(SalarioMinimoModel salarioMinimoModel) async {
		try {
			final lastPk = await Session.database.salarioMinimoDao.insertObject(toDrift(salarioMinimoModel));
			salarioMinimoModel.id = lastPk;
			return salarioMinimoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SalarioMinimoModel?>? update(SalarioMinimoModel salarioMinimoModel) async {
		try {
			await Session.database.salarioMinimoDao.updateObject(toDrift(salarioMinimoModel));
			return salarioMinimoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.salarioMinimoDao.deleteObject(toDrift(SalarioMinimoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<SalarioMinimoModel> toListModel(List<SalarioMinimoGrouped> salarioMinimoDriftList) {
		List<SalarioMinimoModel> listModel = [];
		for (var salarioMinimoDrift in salarioMinimoDriftList) {
			listModel.add(toModel(salarioMinimoDrift)!);
		}
		return listModel;
	}	

	SalarioMinimoModel? toModel(SalarioMinimoGrouped? salarioMinimoDrift) {
		if (salarioMinimoDrift != null) {
			return SalarioMinimoModel(
				id: salarioMinimoDrift.salarioMinimo?.id,
				vigencia: salarioMinimoDrift.salarioMinimo?.vigencia,
				valorMensal: salarioMinimoDrift.salarioMinimo?.valorMensal,
				valorDiario: salarioMinimoDrift.salarioMinimo?.valorDiario,
				valorHora: salarioMinimoDrift.salarioMinimo?.valorHora,
				normaLegal: salarioMinimoDrift.salarioMinimo?.normaLegal,
				dou: salarioMinimoDrift.salarioMinimo?.dou,
			);
		} else {
			return null;
		}
	}


	SalarioMinimoGrouped toDrift(SalarioMinimoModel salarioMinimoModel) {
		return SalarioMinimoGrouped(
			salarioMinimo: SalarioMinimo(
				id: salarioMinimoModel.id,
				vigencia: salarioMinimoModel.vigencia,
				valorMensal: salarioMinimoModel.valorMensal,
				valorDiario: salarioMinimoModel.valorDiario,
				valorHora: salarioMinimoModel.valorHora,
				normaLegal: salarioMinimoModel.normaLegal,
				dou: salarioMinimoModel.dou,
			),
		);
	}

		
}
