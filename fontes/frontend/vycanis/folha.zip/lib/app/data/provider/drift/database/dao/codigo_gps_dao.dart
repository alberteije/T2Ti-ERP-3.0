import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'codigo_gps_dao.g.dart';

@DriftAccessor(tables: [
	CodigoGpss,
])
class CodigoGpsDao extends DatabaseAccessor<AppDatabase> with _$CodigoGpsDaoMixin {
	final AppDatabase db;

	List<CodigoGps> codigoGpsList = []; 
	List<CodigoGpsGrouped> codigoGpsGroupedList = []; 

	CodigoGpsDao(this.db) : super(db);

	Future<List<CodigoGps>> getList() async {
		codigoGpsList = await select(codigoGpss).get();
		return codigoGpsList;
	}

	Future<List<CodigoGps>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		codigoGpsList = await (select(codigoGpss)..where((t) => expression)).get();
		return codigoGpsList;	 
	}

	Future<List<CodigoGpsGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(codigoGpss)
			.join([]);

		if (field != null && field != '') { 
			final column = codigoGpss.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		codigoGpsGroupedList = await query.map((row) {
			final codigoGps = row.readTableOrNull(codigoGpss); 

			return CodigoGpsGrouped(
				codigoGps: codigoGps, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var codigoGpsGrouped in codigoGpsGroupedList) {
		//}		

		return codigoGpsGroupedList;	
	}

	Future<CodigoGps?> getObject(dynamic pk) async {
		return await (select(codigoGpss)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CodigoGps?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM codigo_gps WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CodigoGps;		 
	} 

	Future<CodigoGpsGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CodigoGpsGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.codigoGps = object.codigoGps!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(codigoGpss).insert(object.codigoGps!);
			object.codigoGps = object.codigoGps!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CodigoGpsGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(codigoGpss).replace(object.codigoGps!);
		});	 
	} 

	Future<int> deleteObject(CodigoGpsGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(codigoGpss).delete(object.codigoGps!);
		});		
	}

	Future<void> insertChildren(CodigoGpsGrouped object) async {
	}
	
	Future<void> deleteChildren(CodigoGpsGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from codigo_gps").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}