import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';

class IrrfDriftProvider extends ProviderBase {

	Future<List<IrrfModel>?> getList({Filter? filter}) async {
		List<IrrfGrouped> irrfDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				irrfDriftList = await Session.database.irrfDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				irrfDriftList = await Session.database.irrfDao.getGroupedList(); 
			}
			if (irrfDriftList.isNotEmpty) {
				return toListModel(irrfDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<IrrfModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.irrfDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<IrrfModel?>? insert(IrrfModel irrfModel) async {
		try {
			final lastPk = await Session.database.irrfDao.insertObject(toDrift(irrfModel));
			irrfModel.id = lastPk;
			return irrfModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<IrrfModel?>? update(IrrfModel irrfModel) async {
		try {
			await Session.database.irrfDao.updateObject(toDrift(irrfModel));
			return irrfModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.irrfDao.deleteObject(toDrift(IrrfModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<IrrfModel> toListModel(List<IrrfGrouped> irrfDriftList) {
		List<IrrfModel> listModel = [];
		for (var irrfDrift in irrfDriftList) {
			listModel.add(toModel(irrfDrift)!);
		}
		return listModel;
	}	

	IrrfModel? toModel(IrrfGrouped? irrfDrift) {
		if (irrfDrift != null) {
			return IrrfModel(
				id: irrfDrift.irrf?.id,
				competencia: irrfDrift.irrf?.competencia,
				descontoPorDependente: irrfDrift.irrf?.descontoPorDependente,
				minimoParaRetencao: irrfDrift.irrf?.minimoParaRetencao,
				irrfDetalheModelList: irrfDetalheDriftToModel(irrfDrift.irrfDetalheGroupedList),
			);
		} else {
			return null;
		}
	}

	List<IrrfDetalheModel> irrfDetalheDriftToModel(List<IrrfDetalheGrouped>? irrfDetalheDriftList) { 
		List<IrrfDetalheModel> irrfDetalheModelList = [];
		if (irrfDetalheDriftList != null) {
			for (var irrfDetalheGrouped in irrfDetalheDriftList) {
				irrfDetalheModelList.add(
					IrrfDetalheModel(
						id: irrfDetalheGrouped.irrfDetalhe?.id,
						idIrrf: irrfDetalheGrouped.irrfDetalhe?.idIrrf,
						faixa: irrfDetalheGrouped.irrfDetalhe?.faixa,
						de: irrfDetalheGrouped.irrfDetalhe?.de,
						ate: irrfDetalheGrouped.irrfDetalhe?.ate,
						taxa: irrfDetalheGrouped.irrfDetalhe?.taxa,
						desconto: irrfDetalheGrouped.irrfDetalhe?.desconto,
					)
				);
			}
			return irrfDetalheModelList;
		}
		return [];
	}


	IrrfGrouped toDrift(IrrfModel irrfModel) {
		return IrrfGrouped(
			irrf: Irrf(
				id: irrfModel.id,
				competencia: Util.removeMask(irrfModel.competencia),
				descontoPorDependente: irrfModel.descontoPorDependente,
				minimoParaRetencao: irrfModel.minimoParaRetencao,
			),
			irrfDetalheGroupedList: irrfDetalheModelToDrift(irrfModel.irrfDetalheModelList),
		);
	}

	List<IrrfDetalheGrouped> irrfDetalheModelToDrift(List<IrrfDetalheModel>? irrfDetalheModelList) { 
		List<IrrfDetalheGrouped> irrfDetalheGroupedList = [];
		if (irrfDetalheModelList != null) {
			for (var irrfDetalheModel in irrfDetalheModelList) {
				irrfDetalheGroupedList.add(
					IrrfDetalheGrouped(
						irrfDetalhe: IrrfDetalhe(
							id: irrfDetalheModel.id,
							idIrrf: irrfDetalheModel.idIrrf,
							faixa: irrfDetalheModel.faixa,
							de: irrfDetalheModel.de,
							ate: irrfDetalheModel.ate,
							taxa: irrfDetalheModel.taxa,
							desconto: irrfDetalheModel.desconto,
						),
					),
				);
			}
			return irrfDetalheGroupedList;
		}
		return [];
	}

		
}
