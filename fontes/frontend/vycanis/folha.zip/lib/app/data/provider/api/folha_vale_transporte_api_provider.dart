import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaValeTransporteApiProvider extends ApiProviderBase {
  static const _path = '/folha-vale-transporte';

  Future<List<FolhaValeTransporteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaValeTransporteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaValeTransporteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaValeTransporteModel.fromJson(json),
    );
  }

  Future<FolhaValeTransporteModel?>? insert(FolhaValeTransporteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaValeTransporteModel.fromJson(json),
    );
  }

  Future<FolhaValeTransporteModel?>? update(FolhaValeTransporteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaValeTransporteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
