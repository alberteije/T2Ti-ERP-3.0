import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCodigoRecolhimentoApiProvider extends ApiProviderBase {
  static const _path = '/sefip-codigo-recolhimento';

  Future<List<SefipCodigoRecolhimentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => SefipCodigoRecolhimentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<SefipCodigoRecolhimentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => SefipCodigoRecolhimentoModel.fromJson(json),
    );
  }

  Future<SefipCodigoRecolhimentoModel?>? insert(SefipCodigoRecolhimentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => SefipCodigoRecolhimentoModel.fromJson(json),
    );
  }

  Future<SefipCodigoRecolhimentoModel?>? update(SefipCodigoRecolhimentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => SefipCodigoRecolhimentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
