import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

@DataClassName("Inss")
class Insss extends Table {
	@override
	String get tableName => 'inss';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get competencia => text().named('competencia').withLength(min: 0, max: 7).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class InssGrouped {
	Inss? inss; 
	List<SalarioFamiliaGrouped>? salarioFamiliaGroupedList; 
	List<InssDetalheGrouped>? inssDetalheGroupedList; 

  InssGrouped({
		this.inss, 
		this.salarioFamiliaGroupedList, 
		this.inssDetalheGroupedList, 

  });
}
