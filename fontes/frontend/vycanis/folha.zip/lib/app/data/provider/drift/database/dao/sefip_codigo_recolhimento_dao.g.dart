// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sefip_codigo_recolhimento_dao.dart';

// ignore_for_file: type=lint
mixin _$SefipCodigoRecolhimentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $SefipCodigoRecolhimentosTable get sefipCodigoRecolhimentos =>
      attachedDatabase.sefipCodigoRecolhimentos;
}
