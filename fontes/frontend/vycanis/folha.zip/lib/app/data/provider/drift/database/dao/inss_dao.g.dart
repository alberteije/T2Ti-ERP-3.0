// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'inss_dao.dart';

// ignore_for_file: type=lint
mixin _$InssDaoMixin on DatabaseAccessor<AppDatabase> {
  $InsssTable get insss => attachedDatabase.insss;
  $SalarioFamiliasTable get salarioFamilias => attachedDatabase.salarioFamilias;
  $InssDetalhesTable get inssDetalhes => attachedDatabase.inssDetalhes;
}
