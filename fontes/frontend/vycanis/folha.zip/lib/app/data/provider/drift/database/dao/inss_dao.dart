import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'inss_dao.g.dart';

@DriftAccessor(tables: [
	Insss,
	SalarioFamilias,
	InssDetalhes,
])
class InssDao extends DatabaseAccessor<AppDatabase> with _$InssDaoMixin {
	final AppDatabase db;

	List<Inss> inssList = []; 
	List<InssGrouped> inssGroupedList = []; 

	InssDao(this.db) : super(db);

	Future<List<Inss>> getList() async {
		inssList = await select(insss).get();
		return inssList;
	}

	Future<List<Inss>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		inssList = await (select(insss)..where((t) => expression)).get();
		return inssList;	 
	}

	Future<List<InssGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(insss)
			.join([]);

		if (field != null && field != '') { 
			final column = insss.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		inssGroupedList = await query.map((row) {
			final inss = row.readTableOrNull(insss); 

			return InssGrouped(
				inss: inss, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var inssGrouped in inssGroupedList) {
			inssGrouped.salarioFamiliaGroupedList = [];
			final querySalarioFamilia = ' id_inss = ${inssGrouped.inss!.id}';
			expression = CustomExpression<bool>(querySalarioFamilia);
			final salarioFamiliaList = await (select(salarioFamilias)..where((t) => expression)).get();
			for (var salarioFamilia in salarioFamiliaList) {
				SalarioFamiliaGrouped salarioFamiliaGrouped = SalarioFamiliaGrouped(
					salarioFamilia: salarioFamilia,
				);
				inssGrouped.salarioFamiliaGroupedList!.add(salarioFamiliaGrouped);
			}

			inssGrouped.inssDetalheGroupedList = [];
			final queryInssDetalhe = ' id_inss = ${inssGrouped.inss!.id}';
			expression = CustomExpression<bool>(queryInssDetalhe);
			final inssDetalheList = await (select(inssDetalhes)..where((t) => expression)).get();
			for (var inssDetalhe in inssDetalheList) {
				InssDetalheGrouped inssDetalheGrouped = InssDetalheGrouped(
					inssDetalhe: inssDetalhe,
				);
				inssGrouped.inssDetalheGroupedList!.add(inssDetalheGrouped);
			}

		}		

		return inssGroupedList;	
	}

	Future<Inss?> getObject(dynamic pk) async {
		return await (select(insss)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<Inss?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM inss WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as Inss;		 
	} 

	Future<InssGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(InssGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.inss = object.inss!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(insss).insert(object.inss!);
			object.inss = object.inss!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(InssGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(insss).replace(object.inss!);
		});	 
	} 

	Future<int> deleteObject(InssGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(insss).delete(object.inss!);
		});		
	}

	Future<void> insertChildren(InssGrouped object) async {
		for (var salarioFamiliaGrouped in object.salarioFamiliaGroupedList!) {
			salarioFamiliaGrouped.salarioFamilia = salarioFamiliaGrouped.salarioFamilia?.copyWith(
				id: const Value(null),
				idInss: Value(object.inss!.id),
			);
			await into(salarioFamilias).insert(salarioFamiliaGrouped.salarioFamilia!);
		}
		for (var inssDetalheGrouped in object.inssDetalheGroupedList!) {
			inssDetalheGrouped.inssDetalhe = inssDetalheGrouped.inssDetalhe?.copyWith(
				id: const Value(null),
				idInss: Value(object.inss!.id),
			);
			await into(inssDetalhes).insert(inssDetalheGrouped.inssDetalhe!);
		}
	}
	
	Future<void> deleteChildren(InssGrouped object) async {
		await (delete(salarioFamilias)..where((t) => t.idInss.equals(object.inss!.id!))).go();
		await (delete(inssDetalhes)..where((t) => t.idInss.equals(object.inss!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from inss").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}