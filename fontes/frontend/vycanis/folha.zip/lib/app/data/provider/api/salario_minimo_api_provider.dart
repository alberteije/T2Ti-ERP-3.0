import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SalarioMinimoApiProvider extends ApiProviderBase {
  static const _path = '/salario-minimo';

  Future<List<SalarioMinimoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => SalarioMinimoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<SalarioMinimoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => SalarioMinimoModel.fromJson(json),
    );
  }

  Future<SalarioMinimoModel?>? insert(SalarioMinimoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => SalarioMinimoModel.fromJson(json),
    );
  }

  Future<SalarioMinimoModel?>? update(SalarioMinimoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => SalarioMinimoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
