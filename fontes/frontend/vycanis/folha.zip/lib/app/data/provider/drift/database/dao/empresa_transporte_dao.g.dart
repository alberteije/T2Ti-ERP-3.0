// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'empresa_transporte_dao.dart';

// ignore_for_file: type=lint
mixin _$EmpresaTransporteDaoMixin on DatabaseAccessor<AppDatabase> {
  $EmpresaTransportesTable get empresaTransportes =>
      attachedDatabase.empresaTransportes;
  $EmpresaTransporteItinerariosTable get empresaTransporteItinerarios =>
      attachedDatabase.empresaTransporteItinerarios;
}
