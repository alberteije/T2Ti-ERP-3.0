// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cbo_dao.dart';

// ignore_for_file: type=lint
mixin _$CboDaoMixin on DatabaseAccessor<AppDatabase> {
  $CbosTable get cbos => attachedDatabase.cbos;
}
