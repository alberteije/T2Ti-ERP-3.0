import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';

class InssDriftProvider extends ProviderBase {

	Future<List<InssModel>?> getList({Filter? filter}) async {
		List<InssGrouped> inssDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				inssDriftList = await Session.database.inssDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				inssDriftList = await Session.database.inssDao.getGroupedList(); 
			}
			if (inssDriftList.isNotEmpty) {
				return toListModel(inssDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<InssModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.inssDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<InssModel?>? insert(InssModel inssModel) async {
		try {
			final lastPk = await Session.database.inssDao.insertObject(toDrift(inssModel));
			inssModel.id = lastPk;
			return inssModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<InssModel?>? update(InssModel inssModel) async {
		try {
			await Session.database.inssDao.updateObject(toDrift(inssModel));
			return inssModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.inssDao.deleteObject(toDrift(InssModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<InssModel> toListModel(List<InssGrouped> inssDriftList) {
		List<InssModel> listModel = [];
		for (var inssDrift in inssDriftList) {
			listModel.add(toModel(inssDrift)!);
		}
		return listModel;
	}	

	InssModel? toModel(InssGrouped? inssDrift) {
		if (inssDrift != null) {
			return InssModel(
				id: inssDrift.inss?.id,
				competencia: inssDrift.inss?.competencia,
				salarioFamiliaModelList: salarioFamiliaDriftToModel(inssDrift.salarioFamiliaGroupedList),
				inssDetalheModelList: inssDetalheDriftToModel(inssDrift.inssDetalheGroupedList),
			);
		} else {
			return null;
		}
	}

	List<SalarioFamiliaModel> salarioFamiliaDriftToModel(List<SalarioFamiliaGrouped>? salarioFamiliaDriftList) { 
		List<SalarioFamiliaModel> salarioFamiliaModelList = [];
		if (salarioFamiliaDriftList != null) {
			for (var salarioFamiliaGrouped in salarioFamiliaDriftList) {
				salarioFamiliaModelList.add(
					SalarioFamiliaModel(
						id: salarioFamiliaGrouped.salarioFamilia?.id,
						idInss: salarioFamiliaGrouped.salarioFamilia?.idInss,
						faixa: salarioFamiliaGrouped.salarioFamilia?.faixa,
						de: salarioFamiliaGrouped.salarioFamilia?.de,
						ate: salarioFamiliaGrouped.salarioFamilia?.ate,
						valor: salarioFamiliaGrouped.salarioFamilia?.valor,
					)
				);
			}
			return salarioFamiliaModelList;
		}
		return [];
	}

	List<InssDetalheModel> inssDetalheDriftToModel(List<InssDetalheGrouped>? inssDetalheDriftList) { 
		List<InssDetalheModel> inssDetalheModelList = [];
		if (inssDetalheDriftList != null) {
			for (var inssDetalheGrouped in inssDetalheDriftList) {
				inssDetalheModelList.add(
					InssDetalheModel(
						id: inssDetalheGrouped.inssDetalhe?.id,
						idInss: inssDetalheGrouped.inssDetalhe?.idInss,
						faixa: inssDetalheGrouped.inssDetalhe?.faixa,
						de: inssDetalheGrouped.inssDetalhe?.de,
						ate: inssDetalheGrouped.inssDetalhe?.ate,
						taxa: inssDetalheGrouped.inssDetalhe?.taxa,
					)
				);
			}
			return inssDetalheModelList;
		}
		return [];
	}


	InssGrouped toDrift(InssModel inssModel) {
		return InssGrouped(
			inss: Inss(
				id: inssModel.id,
				competencia: Util.removeMask(inssModel.competencia),
			),
			salarioFamiliaGroupedList: salarioFamiliaModelToDrift(inssModel.salarioFamiliaModelList),
			inssDetalheGroupedList: inssDetalheModelToDrift(inssModel.inssDetalheModelList),
		);
	}

	List<SalarioFamiliaGrouped> salarioFamiliaModelToDrift(List<SalarioFamiliaModel>? salarioFamiliaModelList) { 
		List<SalarioFamiliaGrouped> salarioFamiliaGroupedList = [];
		if (salarioFamiliaModelList != null) {
			for (var salarioFamiliaModel in salarioFamiliaModelList) {
				salarioFamiliaGroupedList.add(
					SalarioFamiliaGrouped(
						salarioFamilia: SalarioFamilia(
							id: salarioFamiliaModel.id,
							idInss: salarioFamiliaModel.idInss,
							faixa: salarioFamiliaModel.faixa,
							de: salarioFamiliaModel.de,
							ate: salarioFamiliaModel.ate,
							valor: salarioFamiliaModel.valor,
						),
					),
				);
			}
			return salarioFamiliaGroupedList;
		}
		return [];
	}

	List<InssDetalheGrouped> inssDetalheModelToDrift(List<InssDetalheModel>? inssDetalheModelList) { 
		List<InssDetalheGrouped> inssDetalheGroupedList = [];
		if (inssDetalheModelList != null) {
			for (var inssDetalheModel in inssDetalheModelList) {
				inssDetalheGroupedList.add(
					InssDetalheGrouped(
						inssDetalhe: InssDetalhe(
							id: inssDetalheModel.id,
							idInss: inssDetalheModel.idInss,
							faixa: inssDetalheModel.faixa,
							de: inssDetalheModel.de,
							ate: inssDetalheModel.ate,
							taxa: inssDetalheModel.taxa,
						),
					),
				);
			}
			return inssDetalheGroupedList;
		}
		return [];
	}

		
}
