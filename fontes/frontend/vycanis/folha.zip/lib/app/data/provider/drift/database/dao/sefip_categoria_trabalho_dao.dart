import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'sefip_categoria_trabalho_dao.g.dart';

@DriftAccessor(tables: [
	SefipCategoriaTrabalhos,
])
class SefipCategoriaTrabalhoDao extends DatabaseAccessor<AppDatabase> with _$SefipCategoriaTrabalhoDaoMixin {
	final AppDatabase db;

	List<SefipCategoriaTrabalho> sefipCategoriaTrabalhoList = []; 
	List<SefipCategoriaTrabalhoGrouped> sefipCategoriaTrabalhoGroupedList = []; 

	SefipCategoriaTrabalhoDao(this.db) : super(db);

	Future<List<SefipCategoriaTrabalho>> getList() async {
		sefipCategoriaTrabalhoList = await select(sefipCategoriaTrabalhos).get();
		return sefipCategoriaTrabalhoList;
	}

	Future<List<SefipCategoriaTrabalho>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		sefipCategoriaTrabalhoList = await (select(sefipCategoriaTrabalhos)..where((t) => expression)).get();
		return sefipCategoriaTrabalhoList;	 
	}

	Future<List<SefipCategoriaTrabalhoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(sefipCategoriaTrabalhos)
			.join([]);

		if (field != null && field != '') { 
			final column = sefipCategoriaTrabalhos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		sefipCategoriaTrabalhoGroupedList = await query.map((row) {
			final sefipCategoriaTrabalho = row.readTableOrNull(sefipCategoriaTrabalhos); 

			return SefipCategoriaTrabalhoGrouped(
				sefipCategoriaTrabalho: sefipCategoriaTrabalho, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var sefipCategoriaTrabalhoGrouped in sefipCategoriaTrabalhoGroupedList) {
		//}		

		return sefipCategoriaTrabalhoGroupedList;	
	}

	Future<SefipCategoriaTrabalho?> getObject(dynamic pk) async {
		return await (select(sefipCategoriaTrabalhos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<SefipCategoriaTrabalho?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM sefip_categoria_trabalho WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as SefipCategoriaTrabalho;		 
	} 

	Future<SefipCategoriaTrabalhoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(SefipCategoriaTrabalhoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.sefipCategoriaTrabalho = object.sefipCategoriaTrabalho!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(sefipCategoriaTrabalhos).insert(object.sefipCategoriaTrabalho!);
			object.sefipCategoriaTrabalho = object.sefipCategoriaTrabalho!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(SefipCategoriaTrabalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(sefipCategoriaTrabalhos).replace(object.sefipCategoriaTrabalho!);
		});	 
	} 

	Future<int> deleteObject(SefipCategoriaTrabalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(sefipCategoriaTrabalhos).delete(object.sefipCategoriaTrabalho!);
		});		
	}

	Future<void> insertChildren(SefipCategoriaTrabalhoGrouped object) async {
	}
	
	Future<void> deleteChildren(SefipCategoriaTrabalhoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from sefip_categoria_trabalho").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}