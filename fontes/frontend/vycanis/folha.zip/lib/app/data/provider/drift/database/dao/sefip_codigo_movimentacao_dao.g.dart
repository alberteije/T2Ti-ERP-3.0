// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sefip_codigo_movimentacao_dao.dart';

// ignore_for_file: type=lint
mixin _$SefipCodigoMovimentacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $SefipCodigoMovimentacaosTable get sefipCodigoMovimentacaos =>
      attachedDatabase.sefipCodigoMovimentacaos;
}
