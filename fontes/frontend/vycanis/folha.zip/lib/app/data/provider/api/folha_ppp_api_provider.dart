import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaPppApiProvider extends ApiProviderBase {
  static const _path = '/folha-ppp';

  Future<List<FolhaPppModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaPppModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaPppModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaPppModel.fromJson(json),
    );
  }

  Future<FolhaPppModel?>? insert(FolhaPppModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaPppModel.fromJson(json),
    );
  }

  Future<FolhaPppModel?>? update(FolhaPppModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaPppModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
