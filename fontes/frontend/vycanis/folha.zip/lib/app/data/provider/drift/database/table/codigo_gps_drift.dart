import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("CodigoGps")
class CodigoGpss extends Table {
	@override
	String get tableName => 'codigo_gps';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get codigo => integer().named('codigo').nullable()();
	TextColumn get descricao => text().named('descricao').withLength(min: 0, max: 250).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CodigoGpsGrouped {
	CodigoGps? codigoGps; 

  CodigoGpsGrouped({
		this.codigoGps, 

  });
}
