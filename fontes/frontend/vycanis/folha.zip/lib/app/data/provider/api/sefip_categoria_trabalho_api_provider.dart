import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCategoriaTrabalhoApiProvider extends ApiProviderBase {
  static const _path = '/sefip-categoria-trabalho';

  Future<List<SefipCategoriaTrabalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => SefipCategoriaTrabalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<SefipCategoriaTrabalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => SefipCategoriaTrabalhoModel.fromJson(json),
    );
  }

  Future<SefipCategoriaTrabalhoModel?>? insert(SefipCategoriaTrabalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => SefipCategoriaTrabalhoModel.fromJson(json),
    );
  }

  Future<SefipCategoriaTrabalhoModel?>? update(SefipCategoriaTrabalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => SefipCategoriaTrabalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
