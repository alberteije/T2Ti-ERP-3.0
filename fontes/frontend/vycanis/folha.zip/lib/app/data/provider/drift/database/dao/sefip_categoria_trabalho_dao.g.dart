// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sefip_categoria_trabalho_dao.dart';

// ignore_for_file: type=lint
mixin _$SefipCategoriaTrabalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $SefipCategoriaTrabalhosTable get sefipCategoriaTrabalhos =>
      attachedDatabase.sefipCategoriaTrabalhos;
}
