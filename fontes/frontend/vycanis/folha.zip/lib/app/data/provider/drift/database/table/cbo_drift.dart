import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("Cbo")
class Cbos extends Table {
	@override
	String get tableName => 'cbo';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get codigo => text().named('codigo').withLength(min: 0, max: 10).nullable()();
	TextColumn get codigo1994 => text().named('codigo_1994').withLength(min: 0, max: 10).nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 250).nullable()();
	TextColumn get observacao => text().named('observacao').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CboGrouped {
	Cbo? cbo; 

  CboGrouped({
		this.cbo, 

  });
}
