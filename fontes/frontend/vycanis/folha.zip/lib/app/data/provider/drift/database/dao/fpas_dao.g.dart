// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fpas_dao.dart';

// ignore_for_file: type=lint
mixin _$FpasDaoMixin on DatabaseAccessor<AppDatabase> {
  $FpassTable get fpass => attachedDatabase.fpass;
}
