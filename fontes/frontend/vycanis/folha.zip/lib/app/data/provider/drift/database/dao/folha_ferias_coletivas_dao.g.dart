// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_ferias_coletivas_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaFeriasColetivasDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaFeriasColetivassTable get folhaFeriasColetivass =>
      attachedDatabase.folhaFeriasColetivass;
}
