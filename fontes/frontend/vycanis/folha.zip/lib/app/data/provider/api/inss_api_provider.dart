import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class InssApiProvider extends ApiProviderBase {
  static const _path = '/inss';

  Future<List<InssModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => InssModel.fromJson(json),
      filter: filter,
    );
  }

  Future<InssModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => InssModel.fromJson(json),
    );
  }

  Future<InssModel?>? insert(InssModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => InssModel.fromJson(json),
    );
  }

  Future<InssModel?>? update(InssModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => InssModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
