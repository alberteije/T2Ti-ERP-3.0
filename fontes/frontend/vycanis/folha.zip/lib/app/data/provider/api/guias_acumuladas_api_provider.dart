import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class GuiasAcumuladasApiProvider extends ApiProviderBase {
  static const _path = '/guias-acumuladas';

  Future<List<GuiasAcumuladasModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GuiasAcumuladasModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GuiasAcumuladasModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GuiasAcumuladasModel.fromJson(json),
    );
  }

  Future<GuiasAcumuladasModel?>? insert(GuiasAcumuladasModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GuiasAcumuladasModel.fromJson(json),
    );
  }

  Future<GuiasAcumuladasModel?>? update(GuiasAcumuladasModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GuiasAcumuladasModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
