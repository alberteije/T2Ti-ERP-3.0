import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("InssDetalhe")
class InssDetalhes extends Table {
	@override
	String get tableName => 'inss_detalhe';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idInss => integer().named('id_inss').nullable()();
	IntColumn get faixa => integer().named('faixa').nullable()();
	RealColumn get de => real().named('de').nullable()();
	RealColumn get ate => real().named('ate').nullable()();
	RealColumn get taxa => real().named('taxa').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class InssDetalheGrouped {
	InssDetalhe? inssDetalhe; 

  InssDetalheGrouped({
		this.inssDetalhe, 

  });
}
