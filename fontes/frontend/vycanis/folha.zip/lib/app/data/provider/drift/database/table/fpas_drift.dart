import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("Fpas")
class Fpass extends Table {
	@override
	String get tableName => 'fpas';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get codigo => integer().named('codigo').nullable()();
	TextColumn get cnae => text().named('cnae').withLength(min: 0, max: 14).nullable()();
	RealColumn get aliquotaSat => real().named('aliquota_sat').nullable()();
	TextColumn get descricao => text().named('descricao').withLength(min: 0, max: 250).nullable()();
	RealColumn get percentualInssPatronal => real().named('percentual_inss_patronal').nullable()();
	TextColumn get codigoTerceiro => text().named('codigo_terceiro').withLength(min: 0, max: 4).nullable()();
	RealColumn get percentualTerceiros => real().named('percentual_terceiros').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class FpasGrouped {
	Fpas? fpas; 

  FpasGrouped({
		this.fpas, 

  });
}
