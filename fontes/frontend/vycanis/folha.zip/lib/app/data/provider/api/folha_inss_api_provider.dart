import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaInssApiProvider extends ApiProviderBase {
  static const _path = '/folha-inss';

  Future<List<FolhaInssModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaInssModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaInssModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaInssModel.fromJson(json),
    );
  }

  Future<FolhaInssModel?>? insert(FolhaInssModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaInssModel.fromJson(json),
    );
  }

  Future<FolhaInssModel?>? update(FolhaInssModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaInssModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
