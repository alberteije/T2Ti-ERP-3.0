// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_inss_servico_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaInssServicoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaInssServicosTable get folhaInssServicos =>
      attachedDatabase.folhaInssServicos;
}
