import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("SalarioMinimo")
class SalarioMinimos extends Table {
	@override
	String get tableName => 'salario_minimo';

	IntColumn get id => integer().named('id').nullable()();
	DateTimeColumn get vigencia => dateTime().named('vigencia').nullable()();
	RealColumn get valorMensal => real().named('valor_mensal').nullable()();
	RealColumn get valorDiario => real().named('valor_diario').nullable()();
	RealColumn get valorHora => real().named('valor_hora').nullable()();
	TextColumn get normaLegal => text().named('norma_legal').withLength(min: 0, max: 100).nullable()();
	DateTimeColumn get dou => dateTime().named('dou').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class SalarioMinimoGrouped {
	SalarioMinimo? salarioMinimo; 

  SalarioMinimoGrouped({
		this.salarioMinimo, 

  });
}
