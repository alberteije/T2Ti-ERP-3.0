import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'sefip_codigo_movimentacao_dao.g.dart';

@DriftAccessor(tables: [
	SefipCodigoMovimentacaos,
])
class SefipCodigoMovimentacaoDao extends DatabaseAccessor<AppDatabase> with _$SefipCodigoMovimentacaoDaoMixin {
	final AppDatabase db;

	List<SefipCodigoMovimentacao> sefipCodigoMovimentacaoList = []; 
	List<SefipCodigoMovimentacaoGrouped> sefipCodigoMovimentacaoGroupedList = []; 

	SefipCodigoMovimentacaoDao(this.db) : super(db);

	Future<List<SefipCodigoMovimentacao>> getList() async {
		sefipCodigoMovimentacaoList = await select(sefipCodigoMovimentacaos).get();
		return sefipCodigoMovimentacaoList;
	}

	Future<List<SefipCodigoMovimentacao>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		sefipCodigoMovimentacaoList = await (select(sefipCodigoMovimentacaos)..where((t) => expression)).get();
		return sefipCodigoMovimentacaoList;	 
	}

	Future<List<SefipCodigoMovimentacaoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(sefipCodigoMovimentacaos)
			.join([]);

		if (field != null && field != '') { 
			final column = sefipCodigoMovimentacaos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		sefipCodigoMovimentacaoGroupedList = await query.map((row) {
			final sefipCodigoMovimentacao = row.readTableOrNull(sefipCodigoMovimentacaos); 

			return SefipCodigoMovimentacaoGrouped(
				sefipCodigoMovimentacao: sefipCodigoMovimentacao, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var sefipCodigoMovimentacaoGrouped in sefipCodigoMovimentacaoGroupedList) {
		//}		

		return sefipCodigoMovimentacaoGroupedList;	
	}

	Future<SefipCodigoMovimentacao?> getObject(dynamic pk) async {
		return await (select(sefipCodigoMovimentacaos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<SefipCodigoMovimentacao?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM sefip_codigo_movimentacao WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as SefipCodigoMovimentacao;		 
	} 

	Future<SefipCodigoMovimentacaoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(SefipCodigoMovimentacaoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.sefipCodigoMovimentacao = object.sefipCodigoMovimentacao!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(sefipCodigoMovimentacaos).insert(object.sefipCodigoMovimentacao!);
			object.sefipCodigoMovimentacao = object.sefipCodigoMovimentacao!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(SefipCodigoMovimentacaoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(sefipCodigoMovimentacaos).replace(object.sefipCodigoMovimentacao!);
		});	 
	} 

	Future<int> deleteObject(SefipCodigoMovimentacaoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(sefipCodigoMovimentacaos).delete(object.sefipCodigoMovimentacao!);
		});		
	}

	Future<void> insertChildren(SefipCodigoMovimentacaoGrouped object) async {
	}
	
	Future<void> deleteChildren(SefipCodigoMovimentacaoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from sefip_codigo_movimentacao").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}