// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_fechamento_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaFechamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaFechamentosTable get folhaFechamentos =>
      attachedDatabase.folhaFechamentos;
}
