import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class OperadoraPlanoSaudeApiProvider extends ApiProviderBase {
  static const _path = '/operadora-plano-saude';

  Future<List<OperadoraPlanoSaudeModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => OperadoraPlanoSaudeModel.fromJson(json),
      filter: filter,
    );
  }

  Future<OperadoraPlanoSaudeModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => OperadoraPlanoSaudeModel.fromJson(json),
    );
  }

  Future<OperadoraPlanoSaudeModel?>? insert(OperadoraPlanoSaudeModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => OperadoraPlanoSaudeModel.fromJson(json),
    );
  }

  Future<OperadoraPlanoSaudeModel?>? update(OperadoraPlanoSaudeModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => OperadoraPlanoSaudeModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
