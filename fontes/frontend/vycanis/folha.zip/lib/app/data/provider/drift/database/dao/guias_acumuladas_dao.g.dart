// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'guias_acumuladas_dao.dart';

// ignore_for_file: type=lint
mixin _$GuiasAcumuladasDaoMixin on DatabaseAccessor<AppDatabase> {
  $GuiasAcumuladassTable get guiasAcumuladass =>
      attachedDatabase.guiasAcumuladass;
}
