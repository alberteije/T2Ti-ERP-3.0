import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'fpas_dao.g.dart';

@DriftAccessor(tables: [
	Fpass,
])
class FpasDao extends DatabaseAccessor<AppDatabase> with _$FpasDaoMixin {
	final AppDatabase db;

	List<Fpas> fpasList = []; 
	List<FpasGrouped> fpasGroupedList = []; 

	FpasDao(this.db) : super(db);

	Future<List<Fpas>> getList() async {
		fpasList = await select(fpass).get();
		return fpasList;
	}

	Future<List<Fpas>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		fpasList = await (select(fpass)..where((t) => expression)).get();
		return fpasList;	 
	}

	Future<List<FpasGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(fpass)
			.join([]);

		if (field != null && field != '') { 
			final column = fpass.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		fpasGroupedList = await query.map((row) {
			final fpas = row.readTableOrNull(fpass); 

			return FpasGrouped(
				fpas: fpas, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var fpasGrouped in fpasGroupedList) {
		//}		

		return fpasGroupedList;	
	}

	Future<Fpas?> getObject(dynamic pk) async {
		return await (select(fpass)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<Fpas?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM fpas WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as Fpas;		 
	} 

	Future<FpasGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(FpasGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.fpas = object.fpas!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(fpass).insert(object.fpas!);
			object.fpas = object.fpas!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(FpasGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(fpass).replace(object.fpas!);
		});	 
	} 

	Future<int> deleteObject(FpasGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(fpass).delete(object.fpas!);
		});		
	}

	Future<void> insertChildren(FpasGrouped object) async {
	}
	
	Future<void> deleteChildren(FpasGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from fpas").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}