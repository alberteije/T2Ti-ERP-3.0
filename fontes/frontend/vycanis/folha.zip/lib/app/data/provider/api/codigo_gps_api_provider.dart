import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class CodigoGpsApiProvider extends ApiProviderBase {
  static const _path = '/codigo-gps';

  Future<List<CodigoGpsModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CodigoGpsModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CodigoGpsModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CodigoGpsModel.fromJson(json),
    );
  }

  Future<CodigoGpsModel?>? insert(CodigoGpsModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CodigoGpsModel.fromJson(json),
    );
  }

  Future<CodigoGpsModel?>? update(CodigoGpsModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CodigoGpsModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
