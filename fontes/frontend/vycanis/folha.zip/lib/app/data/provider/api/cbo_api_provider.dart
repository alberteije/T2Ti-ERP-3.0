import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class CboApiProvider extends ApiProviderBase {
  static const _path = '/cbo';

  Future<List<CboModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CboModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CboModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CboModel.fromJson(json),
    );
  }

  Future<CboModel?>? insert(CboModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CboModel.fromJson(json),
    );
  }

  Future<CboModel?>? update(CboModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CboModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
