import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class SefipCodigoMovimentacaoDriftProvider extends ProviderBase {

	Future<List<SefipCodigoMovimentacaoModel>?> getList({Filter? filter}) async {
		List<SefipCodigoMovimentacaoGrouped> sefipCodigoMovimentacaoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				sefipCodigoMovimentacaoDriftList = await Session.database.sefipCodigoMovimentacaoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				sefipCodigoMovimentacaoDriftList = await Session.database.sefipCodigoMovimentacaoDao.getGroupedList(); 
			}
			if (sefipCodigoMovimentacaoDriftList.isNotEmpty) {
				return toListModel(sefipCodigoMovimentacaoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<SefipCodigoMovimentacaoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.sefipCodigoMovimentacaoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SefipCodigoMovimentacaoModel?>? insert(SefipCodigoMovimentacaoModel sefipCodigoMovimentacaoModel) async {
		try {
			final lastPk = await Session.database.sefipCodigoMovimentacaoDao.insertObject(toDrift(sefipCodigoMovimentacaoModel));
			sefipCodigoMovimentacaoModel.id = lastPk;
			return sefipCodigoMovimentacaoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SefipCodigoMovimentacaoModel?>? update(SefipCodigoMovimentacaoModel sefipCodigoMovimentacaoModel) async {
		try {
			await Session.database.sefipCodigoMovimentacaoDao.updateObject(toDrift(sefipCodigoMovimentacaoModel));
			return sefipCodigoMovimentacaoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.sefipCodigoMovimentacaoDao.deleteObject(toDrift(SefipCodigoMovimentacaoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<SefipCodigoMovimentacaoModel> toListModel(List<SefipCodigoMovimentacaoGrouped> sefipCodigoMovimentacaoDriftList) {
		List<SefipCodigoMovimentacaoModel> listModel = [];
		for (var sefipCodigoMovimentacaoDrift in sefipCodigoMovimentacaoDriftList) {
			listModel.add(toModel(sefipCodigoMovimentacaoDrift)!);
		}
		return listModel;
	}	

	SefipCodigoMovimentacaoModel? toModel(SefipCodigoMovimentacaoGrouped? sefipCodigoMovimentacaoDrift) {
		if (sefipCodigoMovimentacaoDrift != null) {
			return SefipCodigoMovimentacaoModel(
				id: sefipCodigoMovimentacaoDrift.sefipCodigoMovimentacao?.id,
				codigo: SefipCodigoMovimentacaoDomain.getCodigo(sefipCodigoMovimentacaoDrift.sefipCodigoMovimentacao?.codigo),
				descricao: sefipCodigoMovimentacaoDrift.sefipCodigoMovimentacao?.descricao,
				aplicacao: sefipCodigoMovimentacaoDrift.sefipCodigoMovimentacao?.aplicacao,
			);
		} else {
			return null;
		}
	}


	SefipCodigoMovimentacaoGrouped toDrift(SefipCodigoMovimentacaoModel sefipCodigoMovimentacaoModel) {
		return SefipCodigoMovimentacaoGrouped(
			sefipCodigoMovimentacao: SefipCodigoMovimentacao(
				id: sefipCodigoMovimentacaoModel.id,
				codigo: SefipCodigoMovimentacaoDomain.setCodigo(sefipCodigoMovimentacaoModel.codigo),
				descricao: sefipCodigoMovimentacaoModel.descricao,
				aplicacao: sefipCodigoMovimentacaoModel.aplicacao,
			),
		);
	}

		
}
