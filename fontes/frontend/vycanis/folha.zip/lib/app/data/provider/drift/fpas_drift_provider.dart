import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class FpasDriftProvider extends ProviderBase {

	Future<List<FpasModel>?> getList({Filter? filter}) async {
		List<FpasGrouped> fpasDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				fpasDriftList = await Session.database.fpasDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				fpasDriftList = await Session.database.fpasDao.getGroupedList(); 
			}
			if (fpasDriftList.isNotEmpty) {
				return toListModel(fpasDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<FpasModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.fpasDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FpasModel?>? insert(FpasModel fpasModel) async {
		try {
			final lastPk = await Session.database.fpasDao.insertObject(toDrift(fpasModel));
			fpasModel.id = lastPk;
			return fpasModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FpasModel?>? update(FpasModel fpasModel) async {
		try {
			await Session.database.fpasDao.updateObject(toDrift(fpasModel));
			return fpasModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.fpasDao.deleteObject(toDrift(FpasModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<FpasModel> toListModel(List<FpasGrouped> fpasDriftList) {
		List<FpasModel> listModel = [];
		for (var fpasDrift in fpasDriftList) {
			listModel.add(toModel(fpasDrift)!);
		}
		return listModel;
	}	

	FpasModel? toModel(FpasGrouped? fpasDrift) {
		if (fpasDrift != null) {
			return FpasModel(
				id: fpasDrift.fpas?.id,
				codigo: fpasDrift.fpas?.codigo,
				cnae: fpasDrift.fpas?.cnae,
				aliquotaSat: fpasDrift.fpas?.aliquotaSat,
				descricao: fpasDrift.fpas?.descricao,
				percentualInssPatronal: fpasDrift.fpas?.percentualInssPatronal,
				codigoTerceiro: FpasDomain.getCodigoTerceiro(fpasDrift.fpas?.codigoTerceiro),
				percentualTerceiros: fpasDrift.fpas?.percentualTerceiros,
			);
		} else {
			return null;
		}
	}


	FpasGrouped toDrift(FpasModel fpasModel) {
		return FpasGrouped(
			fpas: Fpas(
				id: fpasModel.id,
				codigo: fpasModel.codigo,
				cnae: fpasModel.cnae,
				aliquotaSat: fpasModel.aliquotaSat,
				descricao: fpasModel.descricao,
				percentualInssPatronal: fpasModel.percentualInssPatronal,
				codigoTerceiro: FpasDomain.setCodigoTerceiro(fpasModel.codigoTerceiro),
				percentualTerceiros: fpasModel.percentualTerceiros,
			),
		);
	}

		
}
