import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("SalarioFamilia")
class SalarioFamilias extends Table {
	@override
	String get tableName => 'salario_familia';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idInss => integer().named('id_inss').nullable()();
	IntColumn get faixa => integer().named('faixa').nullable()();
	RealColumn get de => real().named('de').nullable()();
	RealColumn get ate => real().named('ate').nullable()();
	RealColumn get valor => real().named('valor').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class SalarioFamiliaGrouped {
	SalarioFamilia? salarioFamilia; 

  SalarioFamiliaGrouped({
		this.salarioFamilia, 

  });
}
