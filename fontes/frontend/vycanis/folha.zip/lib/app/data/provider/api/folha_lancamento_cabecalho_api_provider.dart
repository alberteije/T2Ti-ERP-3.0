import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaLancamentoCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/folha-lancamento-cabecalho';

  Future<List<FolhaLancamentoCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaLancamentoCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaLancamentoCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaLancamentoCabecalhoModel.fromJson(json),
    );
  }

  Future<FolhaLancamentoCabecalhoModel?>? insert(FolhaLancamentoCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaLancamentoCabecalhoModel.fromJson(json),
    );
  }

  Future<FolhaLancamentoCabecalhoModel?>? update(FolhaLancamentoCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaLancamentoCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
