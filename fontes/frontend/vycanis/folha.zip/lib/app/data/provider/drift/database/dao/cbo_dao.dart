import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'cbo_dao.g.dart';

@DriftAccessor(tables: [
	Cbos,
])
class CboDao extends DatabaseAccessor<AppDatabase> with _$CboDaoMixin {
	final AppDatabase db;

	List<Cbo> cboList = []; 
	List<CboGrouped> cboGroupedList = []; 

	CboDao(this.db) : super(db);

	Future<List<Cbo>> getList() async {
		cboList = await select(cbos).get();
		return cboList;
	}

	Future<List<Cbo>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		cboList = await (select(cbos)..where((t) => expression)).get();
		return cboList;	 
	}

	Future<List<CboGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(cbos)
			.join([]);

		if (field != null && field != '') { 
			final column = cbos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		cboGroupedList = await query.map((row) {
			final cbo = row.readTableOrNull(cbos); 

			return CboGrouped(
				cbo: cbo, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var cboGrouped in cboGroupedList) {
		//}		

		return cboGroupedList;	
	}

	Future<Cbo?> getObject(dynamic pk) async {
		return await (select(cbos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<Cbo?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM cbo WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as Cbo;		 
	} 

	Future<CboGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CboGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.cbo = object.cbo!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(cbos).insert(object.cbo!);
			object.cbo = object.cbo!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CboGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(cbos).replace(object.cbo!);
		});	 
	} 

	Future<int> deleteObject(CboGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(cbos).delete(object.cbo!);
		});		
	}

	Future<void> insertChildren(CboGrouped object) async {
	}
	
	Future<void> deleteChildren(CboGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from cbo").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}