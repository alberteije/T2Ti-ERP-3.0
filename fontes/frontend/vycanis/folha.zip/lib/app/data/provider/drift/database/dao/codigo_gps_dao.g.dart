// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'codigo_gps_dao.dart';

// ignore_for_file: type=lint
mixin _$CodigoGpsDaoMixin on DatabaseAccessor<AppDatabase> {
  $CodigoGpssTable get codigoGpss => attachedDatabase.codigoGpss;
}
