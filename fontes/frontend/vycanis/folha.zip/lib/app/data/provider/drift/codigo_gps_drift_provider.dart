import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';

class CodigoGpsDriftProvider extends ProviderBase {

	Future<List<CodigoGpsModel>?> getList({Filter? filter}) async {
		List<CodigoGpsGrouped> codigoGpsDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				codigoGpsDriftList = await Session.database.codigoGpsDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				codigoGpsDriftList = await Session.database.codigoGpsDao.getGroupedList(); 
			}
			if (codigoGpsDriftList.isNotEmpty) {
				return toListModel(codigoGpsDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CodigoGpsModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.codigoGpsDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CodigoGpsModel?>? insert(CodigoGpsModel codigoGpsModel) async {
		try {
			final lastPk = await Session.database.codigoGpsDao.insertObject(toDrift(codigoGpsModel));
			codigoGpsModel.id = lastPk;
			return codigoGpsModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CodigoGpsModel?>? update(CodigoGpsModel codigoGpsModel) async {
		try {
			await Session.database.codigoGpsDao.updateObject(toDrift(codigoGpsModel));
			return codigoGpsModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.codigoGpsDao.deleteObject(toDrift(CodigoGpsModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CodigoGpsModel> toListModel(List<CodigoGpsGrouped> codigoGpsDriftList) {
		List<CodigoGpsModel> listModel = [];
		for (var codigoGpsDrift in codigoGpsDriftList) {
			listModel.add(toModel(codigoGpsDrift)!);
		}
		return listModel;
	}	

	CodigoGpsModel? toModel(CodigoGpsGrouped? codigoGpsDrift) {
		if (codigoGpsDrift != null) {
			return CodigoGpsModel(
				id: codigoGpsDrift.codigoGps?.id,
				codigo: codigoGpsDrift.codigoGps?.codigo,
				descricao: codigoGpsDrift.codigoGps?.descricao,
			);
		} else {
			return null;
		}
	}


	CodigoGpsGrouped toDrift(CodigoGpsModel codigoGpsModel) {
		return CodigoGpsGrouped(
			codigoGps: CodigoGps(
				id: codigoGpsModel.id,
				codigo: codigoGpsModel.codigo,
				descricao: codigoGpsModel.descricao,
			),
		);
	}

		
}
