import 'package:folha/app/data/provider/drift/database/database_imports.dart';
import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/provider/provider_base.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/model/model_imports.dart';

class SefipCodigoRecolhimentoDriftProvider extends ProviderBase {

	Future<List<SefipCodigoRecolhimentoModel>?> getList({Filter? filter}) async {
		List<SefipCodigoRecolhimentoGrouped> sefipCodigoRecolhimentoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				sefipCodigoRecolhimentoDriftList = await Session.database.sefipCodigoRecolhimentoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				sefipCodigoRecolhimentoDriftList = await Session.database.sefipCodigoRecolhimentoDao.getGroupedList(); 
			}
			if (sefipCodigoRecolhimentoDriftList.isNotEmpty) {
				return toListModel(sefipCodigoRecolhimentoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<SefipCodigoRecolhimentoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.sefipCodigoRecolhimentoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SefipCodigoRecolhimentoModel?>? insert(SefipCodigoRecolhimentoModel sefipCodigoRecolhimentoModel) async {
		try {
			final lastPk = await Session.database.sefipCodigoRecolhimentoDao.insertObject(toDrift(sefipCodigoRecolhimentoModel));
			sefipCodigoRecolhimentoModel.id = lastPk;
			return sefipCodigoRecolhimentoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<SefipCodigoRecolhimentoModel?>? update(SefipCodigoRecolhimentoModel sefipCodigoRecolhimentoModel) async {
		try {
			await Session.database.sefipCodigoRecolhimentoDao.updateObject(toDrift(sefipCodigoRecolhimentoModel));
			return sefipCodigoRecolhimentoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.sefipCodigoRecolhimentoDao.deleteObject(toDrift(SefipCodigoRecolhimentoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<SefipCodigoRecolhimentoModel> toListModel(List<SefipCodigoRecolhimentoGrouped> sefipCodigoRecolhimentoDriftList) {
		List<SefipCodigoRecolhimentoModel> listModel = [];
		for (var sefipCodigoRecolhimentoDrift in sefipCodigoRecolhimentoDriftList) {
			listModel.add(toModel(sefipCodigoRecolhimentoDrift)!);
		}
		return listModel;
	}	

	SefipCodigoRecolhimentoModel? toModel(SefipCodigoRecolhimentoGrouped? sefipCodigoRecolhimentoDrift) {
		if (sefipCodigoRecolhimentoDrift != null) {
			return SefipCodigoRecolhimentoModel(
				id: sefipCodigoRecolhimentoDrift.sefipCodigoRecolhimento?.id,
				codigo: sefipCodigoRecolhimentoDrift.sefipCodigoRecolhimento?.codigo,
				descricao: sefipCodigoRecolhimentoDrift.sefipCodigoRecolhimento?.descricao,
				aplicacao: sefipCodigoRecolhimentoDrift.sefipCodigoRecolhimento?.aplicacao,
			);
		} else {
			return null;
		}
	}


	SefipCodigoRecolhimentoGrouped toDrift(SefipCodigoRecolhimentoModel sefipCodigoRecolhimentoModel) {
		return SefipCodigoRecolhimentoGrouped(
			sefipCodigoRecolhimento: SefipCodigoRecolhimento(
				id: sefipCodigoRecolhimentoModel.id,
				codigo: sefipCodigoRecolhimentoModel.codigo,
				descricao: sefipCodigoRecolhimentoModel.descricao,
				aplicacao: sefipCodigoRecolhimentoModel.aplicacao,
			),
		);
	}

		
}
