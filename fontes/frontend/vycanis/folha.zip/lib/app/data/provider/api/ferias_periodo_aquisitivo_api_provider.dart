import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FeriasPeriodoAquisitivoApiProvider extends ApiProviderBase {
  static const _path = '/ferias-periodo-aquisitivo';

  Future<List<FeriasPeriodoAquisitivoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FeriasPeriodoAquisitivoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FeriasPeriodoAquisitivoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FeriasPeriodoAquisitivoModel.fromJson(json),
    );
  }

  Future<FeriasPeriodoAquisitivoModel?>? insert(FeriasPeriodoAquisitivoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FeriasPeriodoAquisitivoModel.fromJson(json),
    );
  }

  Future<FeriasPeriodoAquisitivoModel?>? update(FeriasPeriodoAquisitivoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FeriasPeriodoAquisitivoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
