// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'salario_minimo_dao.dart';

// ignore_for_file: type=lint
mixin _$SalarioMinimoDaoMixin on DatabaseAccessor<AppDatabase> {
  $SalarioMinimosTable get salarioMinimos => attachedDatabase.salarioMinimos;
}
