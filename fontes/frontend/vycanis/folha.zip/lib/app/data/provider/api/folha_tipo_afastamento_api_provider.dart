import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaTipoAfastamentoApiProvider extends ApiProviderBase {
  static const _path = '/folha-tipo-afastamento';

  Future<List<FolhaTipoAfastamentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaTipoAfastamentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaTipoAfastamentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaTipoAfastamentoModel.fromJson(json),
    );
  }

  Future<FolhaTipoAfastamentoModel?>? insert(FolhaTipoAfastamentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaTipoAfastamentoModel.fromJson(json),
    );
  }

  Future<FolhaTipoAfastamentoModel?>? update(FolhaTipoAfastamentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaTipoAfastamentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
