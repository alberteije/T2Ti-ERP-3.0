import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaRescisaoApiProvider extends ApiProviderBase {
  static const _path = '/folha-rescisao';

  Future<List<FolhaRescisaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaRescisaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaRescisaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaRescisaoModel.fromJson(json),
    );
  }

  Future<FolhaRescisaoModel?>? insert(FolhaRescisaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaRescisaoModel.fromJson(json),
    );
  }

  Future<FolhaRescisaoModel?>? update(FolhaRescisaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaRescisaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
