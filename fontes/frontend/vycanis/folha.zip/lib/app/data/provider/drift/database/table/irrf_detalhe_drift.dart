import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("IrrfDetalhe")
class IrrfDetalhes extends Table {
	@override
	String get tableName => 'irrf_detalhe';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idIrrf => integer().named('id_irrf').nullable()();
	IntColumn get faixa => integer().named('faixa').nullable()();
	RealColumn get de => real().named('de').nullable()();
	RealColumn get ate => real().named('ate').nullable()();
	RealColumn get taxa => real().named('taxa').nullable()();
	RealColumn get desconto => real().named('desconto').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class IrrfDetalheGrouped {
	IrrfDetalhe? irrfDetalhe; 

  IrrfDetalheGrouped({
		this.irrfDetalhe, 

  });
}
