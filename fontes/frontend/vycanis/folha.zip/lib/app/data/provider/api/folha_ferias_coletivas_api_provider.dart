import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaFeriasColetivasApiProvider extends ApiProviderBase {
  static const _path = '/folha-ferias-coletivas';

  Future<List<FolhaFeriasColetivasModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaFeriasColetivasModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaFeriasColetivasModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaFeriasColetivasModel.fromJson(json),
    );
  }

  Future<FolhaFeriasColetivasModel?>? insert(FolhaFeriasColetivasModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaFeriasColetivasModel.fromJson(json),
    );
  }

  Future<FolhaFeriasColetivasModel?>? update(FolhaFeriasColetivasModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaFeriasColetivasModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
