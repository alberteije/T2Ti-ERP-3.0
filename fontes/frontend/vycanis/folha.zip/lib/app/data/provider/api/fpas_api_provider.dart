import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FpasApiProvider extends ApiProviderBase {
  static const _path = '/fpas';

  Future<List<FpasModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FpasModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FpasModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FpasModel.fromJson(json),
    );
  }

  Future<FpasModel?>? insert(FpasModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FpasModel.fromJson(json),
    );
  }

  Future<FpasModel?>? update(FpasModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FpasModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
