import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'irrf_dao.g.dart';

@DriftAccessor(tables: [
	Irrfs,
	IrrfDetalhes,
])
class IrrfDao extends DatabaseAccessor<AppDatabase> with _$IrrfDaoMixin {
	final AppDatabase db;

	List<Irrf> irrfList = []; 
	List<IrrfGrouped> irrfGroupedList = []; 

	IrrfDao(this.db) : super(db);

	Future<List<Irrf>> getList() async {
		irrfList = await select(irrfs).get();
		return irrfList;
	}

	Future<List<Irrf>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		irrfList = await (select(irrfs)..where((t) => expression)).get();
		return irrfList;	 
	}

	Future<List<IrrfGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(irrfs)
			.join([]);

		if (field != null && field != '') { 
			final column = irrfs.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		irrfGroupedList = await query.map((row) {
			final irrf = row.readTableOrNull(irrfs); 

			return IrrfGrouped(
				irrf: irrf, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var irrfGrouped in irrfGroupedList) {
			irrfGrouped.irrfDetalheGroupedList = [];
			final queryIrrfDetalhe = ' id_irrf = ${irrfGrouped.irrf!.id}';
			expression = CustomExpression<bool>(queryIrrfDetalhe);
			final irrfDetalheList = await (select(irrfDetalhes)..where((t) => expression)).get();
			for (var irrfDetalhe in irrfDetalheList) {
				IrrfDetalheGrouped irrfDetalheGrouped = IrrfDetalheGrouped(
					irrfDetalhe: irrfDetalhe,
				);
				irrfGrouped.irrfDetalheGroupedList!.add(irrfDetalheGrouped);
			}

		}		

		return irrfGroupedList;	
	}

	Future<Irrf?> getObject(dynamic pk) async {
		return await (select(irrfs)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<Irrf?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM irrf WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as Irrf;		 
	} 

	Future<IrrfGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(IrrfGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.irrf = object.irrf!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(irrfs).insert(object.irrf!);
			object.irrf = object.irrf!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(IrrfGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(irrfs).replace(object.irrf!);
		});	 
	} 

	Future<int> deleteObject(IrrfGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(irrfs).delete(object.irrf!);
		});		
	}

	Future<void> insertChildren(IrrfGrouped object) async {
		for (var irrfDetalheGrouped in object.irrfDetalheGroupedList!) {
			irrfDetalheGrouped.irrfDetalhe = irrfDetalheGrouped.irrfDetalhe?.copyWith(
				id: const Value(null),
				idIrrf: Value(object.irrf!.id),
			);
			await into(irrfDetalhes).insert(irrfDetalheGrouped.irrfDetalhe!);
		}
	}
	
	Future<void> deleteChildren(IrrfGrouped object) async {
		await (delete(irrfDetalhes)..where((t) => t.idIrrf.equals(object.irrf!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from irrf").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}