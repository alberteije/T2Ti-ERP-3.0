import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaAfastamentoApiProvider extends ApiProviderBase {
  static const _path = '/folha-afastamento';

  Future<List<FolhaAfastamentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaAfastamentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaAfastamentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaAfastamentoModel.fromJson(json),
    );
  }

  Future<FolhaAfastamentoModel?>? insert(FolhaAfastamentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaAfastamentoModel.fromJson(json),
    );
  }

  Future<FolhaAfastamentoModel?>? update(FolhaAfastamentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaAfastamentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
