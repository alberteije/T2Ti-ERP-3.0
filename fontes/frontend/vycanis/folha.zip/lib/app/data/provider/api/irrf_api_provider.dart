import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class IrrfApiProvider extends ApiProviderBase {
  static const _path = '/irrf';

  Future<List<IrrfModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => IrrfModel.fromJson(json),
      filter: filter,
    );
  }

  Future<IrrfModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => IrrfModel.fromJson(json),
    );
  }

  Future<IrrfModel?>? insert(IrrfModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => IrrfModel.fromJson(json),
    );
  }

  Future<IrrfModel?>? update(IrrfModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => IrrfModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
