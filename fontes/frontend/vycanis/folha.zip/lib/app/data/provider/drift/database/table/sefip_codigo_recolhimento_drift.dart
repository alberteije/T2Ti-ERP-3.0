import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';

@DataClassName("SefipCodigoRecolhimento")
class SefipCodigoRecolhimentos extends Table {
	@override
	String get tableName => 'sefip_codigo_recolhimento';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get codigo => integer().named('codigo').nullable()();
	TextColumn get descricao => text().named('descricao').nullable()();
	TextColumn get aplicacao => text().named('aplicacao').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class SefipCodigoRecolhimentoGrouped {
	SefipCodigoRecolhimento? sefipCodigoRecolhimento; 

  SefipCodigoRecolhimentoGrouped({
		this.sefipCodigoRecolhimento, 

  });
}
