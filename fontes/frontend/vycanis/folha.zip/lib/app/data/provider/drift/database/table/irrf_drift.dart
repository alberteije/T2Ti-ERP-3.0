import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

@DataClassName("Irrf")
class Irrfs extends Table {
	@override
	String get tableName => 'irrf';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get competencia => text().named('competencia').withLength(min: 0, max: 7).nullable()();
	RealColumn get descontoPorDependente => real().named('desconto_por_dependente').nullable()();
	RealColumn get minimoParaRetencao => real().named('minimo_para_retencao').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class IrrfGrouped {
	Irrf? irrf; 
	List<IrrfDetalheGrouped>? irrfDetalheGroupedList; 

  IrrfGrouped({
		this.irrf, 
		this.irrfDetalheGroupedList, 

  });
}
