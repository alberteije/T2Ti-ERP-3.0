import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaParametroApiProvider extends ApiProviderBase {
  static const _path = '/folha-parametro';

  Future<List<FolhaParametroModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaParametroModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaParametroModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaParametroModel.fromJson(json),
    );
  }

  Future<FolhaParametroModel?>? insert(FolhaParametroModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaParametroModel.fromJson(json),
    );
  }

  Future<FolhaParametroModel?>? update(FolhaParametroModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaParametroModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
