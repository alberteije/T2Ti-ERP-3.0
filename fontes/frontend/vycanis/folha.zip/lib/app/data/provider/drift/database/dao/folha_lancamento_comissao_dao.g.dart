// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_lancamento_comissao_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaLancamentoComissaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaLancamentoComissaosTable get folhaLancamentoComissaos =>
      attachedDatabase.folhaLancamentoComissaos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
