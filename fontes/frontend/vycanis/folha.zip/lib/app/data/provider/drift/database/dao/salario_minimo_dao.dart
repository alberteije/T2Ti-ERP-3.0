import 'package:drift/drift.dart';
import 'package:folha/app/data/provider/drift/database/database.dart';
import 'package:folha/app/data/provider/drift/database/database_imports.dart';

part 'salario_minimo_dao.g.dart';

@DriftAccessor(tables: [
	SalarioMinimos,
])
class SalarioMinimoDao extends DatabaseAccessor<AppDatabase> with _$SalarioMinimoDaoMixin {
	final AppDatabase db;

	List<SalarioMinimo> salarioMinimoList = []; 
	List<SalarioMinimoGrouped> salarioMinimoGroupedList = []; 

	SalarioMinimoDao(this.db) : super(db);

	Future<List<SalarioMinimo>> getList() async {
		salarioMinimoList = await select(salarioMinimos).get();
		return salarioMinimoList;
	}

	Future<List<SalarioMinimo>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		salarioMinimoList = await (select(salarioMinimos)..where((t) => expression)).get();
		return salarioMinimoList;	 
	}

	Future<List<SalarioMinimoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(salarioMinimos)
			.join([]);

		if (field != null && field != '') { 
			final column = salarioMinimos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		salarioMinimoGroupedList = await query.map((row) {
			final salarioMinimo = row.readTableOrNull(salarioMinimos); 

			return SalarioMinimoGrouped(
				salarioMinimo: salarioMinimo, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var salarioMinimoGrouped in salarioMinimoGroupedList) {
		//}		

		return salarioMinimoGroupedList;	
	}

	Future<SalarioMinimo?> getObject(dynamic pk) async {
		return await (select(salarioMinimos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<SalarioMinimo?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM salario_minimo WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as SalarioMinimo;		 
	} 

	Future<SalarioMinimoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(SalarioMinimoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.salarioMinimo = object.salarioMinimo!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(salarioMinimos).insert(object.salarioMinimo!);
			object.salarioMinimo = object.salarioMinimo!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(SalarioMinimoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(salarioMinimos).replace(object.salarioMinimo!);
		});	 
	} 

	Future<int> deleteObject(SalarioMinimoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(salarioMinimos).delete(object.salarioMinimo!);
		});		
	}

	Future<void> insertChildren(SalarioMinimoGrouped object) async {
	}
	
	Future<void> deleteChildren(SalarioMinimoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from salario_minimo").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}