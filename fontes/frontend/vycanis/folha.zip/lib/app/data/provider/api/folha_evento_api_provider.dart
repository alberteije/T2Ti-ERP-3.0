import 'package:folha/app/data/provider/api/api_provider_base.dart';
import 'package:folha/app/data/model/model_imports.dart';

class FolhaEventoApiProvider extends ApiProviderBase {
  static const _path = '/folha-evento';

  Future<List<FolhaEventoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FolhaEventoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FolhaEventoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FolhaEventoModel.fromJson(json),
    );
  }

  Future<FolhaEventoModel?>? insert(FolhaEventoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FolhaEventoModel.fromJson(json),
    );
  }

  Future<FolhaEventoModel?>? update(FolhaEventoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FolhaEventoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
