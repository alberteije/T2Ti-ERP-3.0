import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class IrrfDetalheModel extends ModelBase {
  int? id;
  int? idIrrf;
  int? faixa;
  double? de;
  double? ate;
  double? taxa;
  double? desconto;

  IrrfDetalheModel({
    this.id,
    this.idIrrf,
    this.faixa,
    this.de,
    this.ate,
    this.taxa,
    this.desconto,
  });

  static List<String> dbColumns = <String>[
    'id',
    'faixa',
    'de',
    'ate',
    'taxa',
    'desconto',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Faixa',
    'De',
    'Ate',
    'Taxa',
    'Desconto',
  ];

  IrrfDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idIrrf = jsonData['idIrrf'];
    faixa = jsonData['faixa'];
    de = jsonData['de']?.toDouble();
    ate = jsonData['ate']?.toDouble();
    taxa = jsonData['taxa']?.toDouble();
    desconto = jsonData['desconto']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idIrrf'] = idIrrf != 0 ? idIrrf : null;
    jsonData['faixa'] = faixa;
    jsonData['de'] = de;
    jsonData['ate'] = ate;
    jsonData['taxa'] = taxa;
    jsonData['desconto'] = desconto;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static IrrfDetalheModel fromPlutoRow(PlutoRow row) {
    return IrrfDetalheModel(
      id: row.cells['id']?.value,
      idIrrf: row.cells['idIrrf']?.value,
      faixa: row.cells['faixa']?.value,
      de: row.cells['de']?.value,
      ate: row.cells['ate']?.value,
      taxa: row.cells['taxa']?.value,
      desconto: row.cells['desconto']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idIrrf': PlutoCell(value: idIrrf ?? 0),
        'faixa': PlutoCell(value: faixa ?? 0),
        'de': PlutoCell(value: de ?? 0.0),
        'ate': PlutoCell(value: ate ?? 0.0),
        'taxa': PlutoCell(value: taxa ?? 0.0),
        'desconto': PlutoCell(value: desconto ?? 0.0),
      },
    );
  }

  IrrfDetalheModel clone() {
    return IrrfDetalheModel(
      id: id,
      idIrrf: idIrrf,
      faixa: faixa,
      de: de,
      ate: ate,
      taxa: taxa,
      desconto: desconto,
    );
  }


}