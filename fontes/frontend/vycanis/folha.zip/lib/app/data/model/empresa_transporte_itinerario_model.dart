import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class EmpresaTransporteItinerarioModel extends ModelBase {
  int? id;
  int? idEmpresaTransporte;
  String? nome;
  double? tarifa;
  String? trajeto;

  EmpresaTransporteItinerarioModel({
    this.id,
    this.idEmpresaTransporte,
    this.nome,
    this.tarifa,
    this.trajeto,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'tarifa',
    'trajeto',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Tarifa',
    'Trajeto',
  ];

  EmpresaTransporteItinerarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idEmpresaTransporte = jsonData['idEmpresaTransporte'];
    nome = jsonData['nome'];
    tarifa = jsonData['tarifa']?.toDouble();
    trajeto = jsonData['trajeto'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idEmpresaTransporte'] = idEmpresaTransporte != 0 ? idEmpresaTransporte : null;
    jsonData['nome'] = nome;
    jsonData['tarifa'] = tarifa;
    jsonData['trajeto'] = trajeto;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static EmpresaTransporteItinerarioModel fromPlutoRow(PlutoRow row) {
    return EmpresaTransporteItinerarioModel(
      id: row.cells['id']?.value,
      idEmpresaTransporte: row.cells['idEmpresaTransporte']?.value,
      nome: row.cells['nome']?.value,
      tarifa: row.cells['tarifa']?.value,
      trajeto: row.cells['trajeto']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idEmpresaTransporte': PlutoCell(value: idEmpresaTransporte ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'tarifa': PlutoCell(value: tarifa ?? 0.0),
        'trajeto': PlutoCell(value: trajeto ?? ''),
      },
    );
  }

  EmpresaTransporteItinerarioModel clone() {
    return EmpresaTransporteItinerarioModel(
      id: id,
      idEmpresaTransporte: idEmpresaTransporte,
      nome: nome,
      tarifa: tarifa,
      trajeto: trajeto,
    );
  }


}