import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class FolhaPppModel extends ModelBase {
  int? id;
  int? idColaborador;
  String? observacao;
  List<FolhaPppCatModel>? folhaPppCatModelList;
  List<FolhaPppAtividadeModel>? folhaPppAtividadeModelList;
  List<FolhaPppFatorRiscoModel>? folhaPppFatorRiscoModelList;
  List<FolhaPppExameMedicoModel>? folhaPppExameMedicoModelList;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  FolhaPppModel({
    this.id,
    this.idColaborador,
    this.observacao,
    List<FolhaPppCatModel>? folhaPppCatModelList,
    List<FolhaPppAtividadeModel>? folhaPppAtividadeModelList,
    List<FolhaPppFatorRiscoModel>? folhaPppFatorRiscoModelList,
    List<FolhaPppExameMedicoModel>? folhaPppExameMedicoModelList,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.folhaPppCatModelList = folhaPppCatModelList?.toList(growable: true) ?? [];
    this.folhaPppAtividadeModelList = folhaPppAtividadeModelList?.toList(growable: true) ?? [];
    this.folhaPppFatorRiscoModelList = folhaPppFatorRiscoModelList?.toList(growable: true) ?? [];
    this.folhaPppExameMedicoModelList = folhaPppExameMedicoModelList?.toList(growable: true) ?? [];
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Observacao',
  ];

  FolhaPppModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    observacao = jsonData['observacao'];
    folhaPppCatModelList = (jsonData['folhaPppCatModelList'] as Iterable?)?.map((m) => FolhaPppCatModel.fromJson(m)).toList() ?? [];
    folhaPppAtividadeModelList = (jsonData['folhaPppAtividadeModelList'] as Iterable?)?.map((m) => FolhaPppAtividadeModel.fromJson(m)).toList() ?? [];
    folhaPppFatorRiscoModelList = (jsonData['folhaPppFatorRiscoModelList'] as Iterable?)?.map((m) => FolhaPppFatorRiscoModel.fromJson(m)).toList() ?? [];
    folhaPppExameMedicoModelList = (jsonData['folhaPppExameMedicoModelList'] as Iterable?)?.map((m) => FolhaPppExameMedicoModel.fromJson(m)).toList() ?? [];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['observacao'] = observacao;
    
		var folhaPppCatModelLocalList = []; 
		for (FolhaPppCatModel object in folhaPppCatModelList ?? []) { 
			folhaPppCatModelLocalList.add(object.toJson); 
		}
		jsonData['folhaPppCatModelList'] = folhaPppCatModelLocalList;
    
		var folhaPppAtividadeModelLocalList = []; 
		for (FolhaPppAtividadeModel object in folhaPppAtividadeModelList ?? []) { 
			folhaPppAtividadeModelLocalList.add(object.toJson); 
		}
		jsonData['folhaPppAtividadeModelList'] = folhaPppAtividadeModelLocalList;
    
		var folhaPppFatorRiscoModelLocalList = []; 
		for (FolhaPppFatorRiscoModel object in folhaPppFatorRiscoModelList ?? []) { 
			folhaPppFatorRiscoModelLocalList.add(object.toJson); 
		}
		jsonData['folhaPppFatorRiscoModelList'] = folhaPppFatorRiscoModelLocalList;
    
		var folhaPppExameMedicoModelLocalList = []; 
		for (FolhaPppExameMedicoModel object in folhaPppExameMedicoModelList ?? []) { 
			folhaPppExameMedicoModelLocalList.add(object.toJson); 
		}
		jsonData['folhaPppExameMedicoModelList'] = folhaPppExameMedicoModelLocalList;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaPppModel fromPlutoRow(PlutoRow row) {
    return FolhaPppModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'observacao': PlutoCell(value: observacao ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  FolhaPppModel clone() {
    return FolhaPppModel(
      id: id,
      idColaborador: idColaborador,
      observacao: observacao,
      folhaPppCatModelList: folhaPppCatModelListClone(folhaPppCatModelList!),
      folhaPppAtividadeModelList: folhaPppAtividadeModelListClone(folhaPppAtividadeModelList!),
      folhaPppFatorRiscoModelList: folhaPppFatorRiscoModelListClone(folhaPppFatorRiscoModelList!),
      folhaPppExameMedicoModelList: folhaPppExameMedicoModelListClone(folhaPppExameMedicoModelList!),
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }

  folhaPppCatModelListClone(List<FolhaPppCatModel> folhaPppCatModelList) { 
		List<FolhaPppCatModel> resultList = [];
		for (var folhaPppCatModel in folhaPppCatModelList) {
			resultList.add(folhaPppCatModel.clone());
		}
		return resultList;
	}

  folhaPppAtividadeModelListClone(List<FolhaPppAtividadeModel> folhaPppAtividadeModelList) { 
		List<FolhaPppAtividadeModel> resultList = [];
		for (var folhaPppAtividadeModel in folhaPppAtividadeModelList) {
			resultList.add(folhaPppAtividadeModel.clone());
		}
		return resultList;
	}

  folhaPppFatorRiscoModelListClone(List<FolhaPppFatorRiscoModel> folhaPppFatorRiscoModelList) { 
		List<FolhaPppFatorRiscoModel> resultList = [];
		for (var folhaPppFatorRiscoModel in folhaPppFatorRiscoModelList) {
			resultList.add(folhaPppFatorRiscoModel.clone());
		}
		return resultList;
	}

  folhaPppExameMedicoModelListClone(List<FolhaPppExameMedicoModel> folhaPppExameMedicoModelList) { 
		List<FolhaPppExameMedicoModel> resultList = [];
		for (var folhaPppExameMedicoModel in folhaPppExameMedicoModelList) {
			resultList.add(folhaPppExameMedicoModel.clone());
		}
		return resultList;
	}


}