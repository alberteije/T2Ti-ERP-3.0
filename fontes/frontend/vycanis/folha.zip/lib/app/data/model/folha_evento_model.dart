import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/data/domain/domain_imports.dart';

class FolhaEventoModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  String? descricao;
  String? baseCalculo;
  String? tipo;
  String? unidade;
  double? taxa;
  String? rubricaEsocial;
  String? codIncidenciaPrevidencia;
  String? codIncidenciaIrrf;
  String? codIncidenciaFgts;
  String? codIncidenciaSindicato;
  String? repercuteDsr;
  String? repercute13;
  String? repercuteFerias;
  String? repercuteAviso;

  FolhaEventoModel({
    this.id,
    this.codigo,
    this.nome,
    this.descricao,
    this.baseCalculo = '1=Salário contratual: define que a base de cálculo deve ser calculada sobre o valor do salário contratual',
    this.tipo = 'Provento',
    this.unidade = 'Valor',
    this.taxa,
    this.rubricaEsocial,
    this.codIncidenciaPrevidencia,
    this.codIncidenciaIrrf,
    this.codIncidenciaFgts,
    this.codIncidenciaSindicato,
    this.repercuteDsr = 'Sim',
    this.repercute13 = 'Sim',
    this.repercuteFerias = 'Sim',
    this.repercuteAviso = 'Sim',
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'descricao',
    'base_calculo',
    'tipo',
    'unidade',
    'taxa',
    'rubrica_esocial',
    'cod_incidencia_previdencia',
    'cod_incidencia_irrf',
    'cod_incidencia_fgts',
    'cod_incidencia_sindicato',
    'repercute_dsr',
    'repercute_13',
    'repercute_ferias',
    'repercute_aviso',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Descricao',
    'Base Calculo',
    'Tipo',
    'Unidade',
    'Taxa',
    'Rubrica Esocial',
    'Cod Incidencia Previdencia',
    'Cod Incidencia Irrf',
    'Cod Incidencia Fgts',
    'Cod Incidencia Sindicato',
    'Repercute Dsr',
    'Repercute 13',
    'Repercute Ferias',
    'Repercute Aviso',
  ];

  FolhaEventoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    baseCalculo = FolhaEventoDomain.getBaseCalculo(jsonData['baseCalculo']);
    tipo = FolhaEventoDomain.getTipo(jsonData['tipo']);
    unidade = FolhaEventoDomain.getUnidade(jsonData['unidade']);
    taxa = jsonData['taxa']?.toDouble();
    rubricaEsocial = jsonData['rubricaEsocial'];
    codIncidenciaPrevidencia = jsonData['codIncidenciaPrevidencia'];
    codIncidenciaIrrf = jsonData['codIncidenciaIrrf'];
    codIncidenciaFgts = jsonData['codIncidenciaFgts'];
    codIncidenciaSindicato = jsonData['codIncidenciaSindicato'];
    repercuteDsr = FolhaEventoDomain.getRepercuteDsr(jsonData['repercuteDsr']);
    repercute13 = FolhaEventoDomain.getRepercute13(jsonData['repercute13']);
    repercuteFerias = FolhaEventoDomain.getRepercuteFerias(jsonData['repercuteFerias']);
    repercuteAviso = FolhaEventoDomain.getRepercuteAviso(jsonData['repercuteAviso']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['baseCalculo'] = FolhaEventoDomain.setBaseCalculo(baseCalculo);
    jsonData['tipo'] = FolhaEventoDomain.setTipo(tipo);
    jsonData['unidade'] = FolhaEventoDomain.setUnidade(unidade);
    jsonData['taxa'] = taxa;
    jsonData['rubricaEsocial'] = rubricaEsocial;
    jsonData['codIncidenciaPrevidencia'] = codIncidenciaPrevidencia;
    jsonData['codIncidenciaIrrf'] = codIncidenciaIrrf;
    jsonData['codIncidenciaFgts'] = codIncidenciaFgts;
    jsonData['codIncidenciaSindicato'] = codIncidenciaSindicato;
    jsonData['repercuteDsr'] = FolhaEventoDomain.setRepercuteDsr(repercuteDsr);
    jsonData['repercute13'] = FolhaEventoDomain.setRepercute13(repercute13);
    jsonData['repercuteFerias'] = FolhaEventoDomain.setRepercuteFerias(repercuteFerias);
    jsonData['repercuteAviso'] = FolhaEventoDomain.setRepercuteAviso(repercuteAviso);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaEventoModel fromPlutoRow(PlutoRow row) {
    return FolhaEventoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      baseCalculo: row.cells['baseCalculo']?.value,
      tipo: row.cells['tipo']?.value,
      unidade: row.cells['unidade']?.value,
      taxa: row.cells['taxa']?.value,
      rubricaEsocial: row.cells['rubricaEsocial']?.value,
      codIncidenciaPrevidencia: row.cells['codIncidenciaPrevidencia']?.value,
      codIncidenciaIrrf: row.cells['codIncidenciaIrrf']?.value,
      codIncidenciaFgts: row.cells['codIncidenciaFgts']?.value,
      codIncidenciaSindicato: row.cells['codIncidenciaSindicato']?.value,
      repercuteDsr: row.cells['repercuteDsr']?.value,
      repercute13: row.cells['repercute13']?.value,
      repercuteFerias: row.cells['repercuteFerias']?.value,
      repercuteAviso: row.cells['repercuteAviso']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'baseCalculo': PlutoCell(value: baseCalculo ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'unidade': PlutoCell(value: unidade ?? ''),
        'taxa': PlutoCell(value: taxa ?? 0.0),
        'rubricaEsocial': PlutoCell(value: rubricaEsocial ?? ''),
        'codIncidenciaPrevidencia': PlutoCell(value: codIncidenciaPrevidencia ?? ''),
        'codIncidenciaIrrf': PlutoCell(value: codIncidenciaIrrf ?? ''),
        'codIncidenciaFgts': PlutoCell(value: codIncidenciaFgts ?? ''),
        'codIncidenciaSindicato': PlutoCell(value: codIncidenciaSindicato ?? ''),
        'repercuteDsr': PlutoCell(value: repercuteDsr ?? ''),
        'repercute13': PlutoCell(value: repercute13 ?? ''),
        'repercuteFerias': PlutoCell(value: repercuteFerias ?? ''),
        'repercuteAviso': PlutoCell(value: repercuteAviso ?? ''),
      },
    );
  }

  FolhaEventoModel clone() {
    return FolhaEventoModel(
      id: id,
      codigo: codigo,
      nome: nome,
      descricao: descricao,
      baseCalculo: baseCalculo,
      tipo: tipo,
      unidade: unidade,
      taxa: taxa,
      rubricaEsocial: rubricaEsocial,
      codIncidenciaPrevidencia: codIncidenciaPrevidencia,
      codIncidenciaIrrf: codIncidenciaIrrf,
      codIncidenciaFgts: codIncidenciaFgts,
      codIncidenciaSindicato: codIncidenciaSindicato,
      repercuteDsr: repercuteDsr,
      repercute13: repercute13,
      repercuteFerias: repercuteFerias,
      repercuteAviso: repercuteAviso,
    );
  }


}