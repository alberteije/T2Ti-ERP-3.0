import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/data/domain/domain_imports.dart';

class SefipCodigoMovimentacaoModel extends ModelBase {
  int? id;
  String? codigo;
  String? descricao;
  String? aplicacao;

  SefipCodigoMovimentacaoModel({
    this.id,
    this.codigo = 'AAA',
    this.descricao,
    this.aplicacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'descricao',
    'aplicacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Descricao',
    'Aplicacao',
  ];

  SefipCodigoMovimentacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = SefipCodigoMovimentacaoDomain.getCodigo(jsonData['codigo']);
    descricao = jsonData['descricao'];
    aplicacao = jsonData['aplicacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = SefipCodigoMovimentacaoDomain.setCodigo(codigo);
    jsonData['descricao'] = descricao;
    jsonData['aplicacao'] = aplicacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static SefipCodigoMovimentacaoModel fromPlutoRow(PlutoRow row) {
    return SefipCodigoMovimentacaoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      descricao: row.cells['descricao']?.value,
      aplicacao: row.cells['aplicacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'aplicacao': PlutoCell(value: aplicacao ?? ''),
      },
    );
  }

  SefipCodigoMovimentacaoModel clone() {
    return SefipCodigoMovimentacaoModel(
      id: id,
      codigo: codigo,
      descricao: descricao,
      aplicacao: aplicacao,
    );
  }


}