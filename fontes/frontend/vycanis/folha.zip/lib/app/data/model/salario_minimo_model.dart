import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class SalarioMinimoModel extends ModelBase {
  int? id;
  DateTime? vigencia;
  double? valorMensal;
  double? valorDiario;
  double? valorHora;
  String? normaLegal;
  DateTime? dou;

  SalarioMinimoModel({
    this.id,
    this.vigencia,
    this.valorMensal,
    this.valorDiario,
    this.valorHora,
    this.normaLegal,
    this.dou,
  });

  static List<String> dbColumns = <String>[
    'id',
    'vigencia',
    'valor_mensal',
    'valor_diario',
    'valor_hora',
    'norma_legal',
    'dou',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Vigencia',
    'Valor Mensal',
    'Valor Diario',
    'Valor Hora',
    'Norma Legal',
    'Dou',
  ];

  SalarioMinimoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    vigencia = jsonData['vigencia'] != null ? DateTime.tryParse(jsonData['vigencia']) : null;
    valorMensal = jsonData['valorMensal']?.toDouble();
    valorDiario = jsonData['valorDiario']?.toDouble();
    valorHora = jsonData['valorHora']?.toDouble();
    normaLegal = jsonData['normaLegal'];
    dou = jsonData['dou'] != null ? DateTime.tryParse(jsonData['dou']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['vigencia'] = vigencia != null ? DateFormat('yyyy-MM-ddT00:00:00').format(vigencia!) : null;
    jsonData['valorMensal'] = valorMensal;
    jsonData['valorDiario'] = valorDiario;
    jsonData['valorHora'] = valorHora;
    jsonData['normaLegal'] = normaLegal;
    jsonData['dou'] = dou != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dou!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static SalarioMinimoModel fromPlutoRow(PlutoRow row) {
    return SalarioMinimoModel(
      id: row.cells['id']?.value,
      vigencia: Util.stringToDate(row.cells['vigencia']?.value),
      valorMensal: row.cells['valorMensal']?.value,
      valorDiario: row.cells['valorDiario']?.value,
      valorHora: row.cells['valorHora']?.value,
      normaLegal: row.cells['normaLegal']?.value,
      dou: Util.stringToDate(row.cells['dou']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'vigencia': PlutoCell(value: vigencia),
        'valorMensal': PlutoCell(value: valorMensal ?? 0.0),
        'valorDiario': PlutoCell(value: valorDiario ?? 0.0),
        'valorHora': PlutoCell(value: valorHora ?? 0.0),
        'normaLegal': PlutoCell(value: normaLegal ?? ''),
        'dou': PlutoCell(value: dou),
      },
    );
  }

  SalarioMinimoModel clone() {
    return SalarioMinimoModel(
      id: id,
      vigencia: vigencia,
      valorMensal: valorMensal,
      valorDiario: valorDiario,
      valorHora: valorHora,
      normaLegal: normaLegal,
      dou: dou,
    );
  }


}