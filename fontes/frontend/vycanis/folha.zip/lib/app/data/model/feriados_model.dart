import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class FeriadosModel extends ModelBase {
  int? id;
  String? ano;
  String? nome;
  String? abrangencia;
  String? uf;
  int? municipioIbge;
  String? tipo;
  DateTime? dataFeriado;

  FeriadosModel({
    this.id,
    this.ano,
    this.nome,
    this.abrangencia = 'Federal',
    this.uf = 'AC',
    this.municipioIbge,
    this.tipo = 'Fixo.Movel',
    this.dataFeriado,
  });

  static List<String> dbColumns = <String>[
    'id',
    'ano',
    'nome',
    'abrangencia',
    'uf',
    'municipio_ibge',
    'tipo',
    'data_feriado',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Ano',
    'Nome',
    'Abrangencia',
    'Uf',
    'Municipio Ibge',
    'Tipo',
    'Data Feriado',
  ];

  FeriadosModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    ano = jsonData['ano'];
    nome = jsonData['nome'];
    abrangencia = FeriadosDomain.getAbrangencia(jsonData['abrangencia']);
    uf = FeriadosDomain.getUf(jsonData['uf']);
    municipioIbge = jsonData['municipioIbge'];
    tipo = FeriadosDomain.getTipo(jsonData['tipo']);
    dataFeriado = jsonData['dataFeriado'] != null ? DateTime.tryParse(jsonData['dataFeriado']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['ano'] = ano;
    jsonData['nome'] = nome;
    jsonData['abrangencia'] = FeriadosDomain.setAbrangencia(abrangencia);
    jsonData['uf'] = FeriadosDomain.setUf(uf);
    jsonData['municipioIbge'] = municipioIbge;
    jsonData['tipo'] = FeriadosDomain.setTipo(tipo);
    jsonData['dataFeriado'] = dataFeriado != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFeriado!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FeriadosModel fromPlutoRow(PlutoRow row) {
    return FeriadosModel(
      id: row.cells['id']?.value,
      ano: row.cells['ano']?.value,
      nome: row.cells['nome']?.value,
      abrangencia: row.cells['abrangencia']?.value,
      uf: row.cells['uf']?.value,
      municipioIbge: row.cells['municipioIbge']?.value,
      tipo: row.cells['tipo']?.value,
      dataFeriado: Util.stringToDate(row.cells['dataFeriado']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'ano': PlutoCell(value: ano ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'abrangencia': PlutoCell(value: abrangencia ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'municipioIbge': PlutoCell(value: municipioIbge ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'dataFeriado': PlutoCell(value: dataFeriado),
      },
    );
  }

  FeriadosModel clone() {
    return FeriadosModel(
      id: id,
      ano: ano,
      nome: nome,
      abrangencia: abrangencia,
      uf: uf,
      municipioIbge: municipioIbge,
      tipo: tipo,
      dataFeriado: dataFeriado,
    );
  }


}