import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FolhaLancamentoComissaoModel extends ModelBase {
  int? id;
  int? idColaborador;
  String? competencia;
  DateTime? vencimento;
  double? baseCalculo;
  double? valorComissao;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  FolhaLancamentoComissaoModel({
    this.id,
    this.idColaborador,
    this.competencia,
    this.vencimento,
    this.baseCalculo,
    this.valorComissao,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
    'vencimento',
    'base_calculo',
    'valor_comissao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
    'Vencimento',
    'Base Calculo',
    'Valor Comissao',
  ];

  FolhaLancamentoComissaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    competencia = jsonData['competencia'];
    vencimento = jsonData['vencimento'] != null ? DateTime.tryParse(jsonData['vencimento']) : null;
    baseCalculo = jsonData['baseCalculo']?.toDouble();
    valorComissao = jsonData['valorComissao']?.toDouble();
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['vencimento'] = vencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(vencimento!) : null;
    jsonData['baseCalculo'] = baseCalculo;
    jsonData['valorComissao'] = valorComissao;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaLancamentoComissaoModel fromPlutoRow(PlutoRow row) {
    return FolhaLancamentoComissaoModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      competencia: row.cells['competencia']?.value,
      vencimento: Util.stringToDate(row.cells['vencimento']?.value),
      baseCalculo: row.cells['baseCalculo']?.value,
      valorComissao: row.cells['valorComissao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'vencimento': PlutoCell(value: vencimento),
        'baseCalculo': PlutoCell(value: baseCalculo ?? 0.0),
        'valorComissao': PlutoCell(value: valorComissao ?? 0.0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  FolhaLancamentoComissaoModel clone() {
    return FolhaLancamentoComissaoModel(
      id: id,
      idColaborador: idColaborador,
      competencia: competencia,
      vencimento: vencimento,
      baseCalculo: baseCalculo,
      valorComissao: valorComissao,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}