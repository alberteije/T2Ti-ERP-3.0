import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class FolhaParametroModel extends ModelBase {
  int? id;
  String? competencia;
  String? contribuiPis;
  double? aliquotaPis;
  String? discriminarDsr;
  String? diaPagamento;
  String? calculoProporcionalidade;
  String? descontarFaltas13;
  String? pagarAdicionais13;
  String? pagarEstagiarios13;
  String? mesAdiantamento13;
  double? percentualAdiantam13;
  String? feriasDescontarFaltas;
  String? feriasPagarAdicionais;
  String? feriasAdiantar13;
  String? feriasPagarEstagiarios;
  String? feriasCalcJustaCausa;
  String? feriasMovimentoMensal;

  FolhaParametroModel({
    this.id,
    this.competencia,
    this.contribuiPis = 'Sim',
    this.aliquotaPis,
    this.discriminarDsr = 'Sim',
    this.diaPagamento,
    this.calculoProporcionalidade = '30 Dias',
    this.descontarFaltas13 = 'Sim',
    this.pagarAdicionais13 = 'Sim',
    this.pagarEstagiarios13 = 'Sim',
    this.mesAdiantamento13,
    this.percentualAdiantam13,
    this.feriasDescontarFaltas = 'Sim',
    this.feriasPagarAdicionais = 'Sim',
    this.feriasAdiantar13 = 'Sim',
    this.feriasPagarEstagiarios = 'Sim',
    this.feriasCalcJustaCausa = 'Sim',
    this.feriasMovimentoMensal = 'Sim',
  });

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
    'contribui_pis',
    'aliquota_pis',
    'discriminar_dsr',
    'dia_pagamento',
    'calculo_proporcionalidade',
    'descontar_faltas_13',
    'pagar_adicionais_13',
    'pagar_estagiarios_13',
    'mes_adiantamento_13',
    'percentual_adiantam_13',
    'ferias_descontar_faltas',
    'ferias_pagar_adicionais',
    'ferias_adiantar_13',
    'ferias_pagar_estagiarios',
    'ferias_calc_justa_causa',
    'ferias_movimento_mensal',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
    'Contribui Pis',
    'Aliquota Pis',
    'Discriminar Dsr',
    'Dia Pagamento',
    'Calculo Proporcionalidade',
    'Descontar Faltas 13',
    'Pagar Adicionais 13',
    'Pagar Estagiarios 13',
    'Mes Adiantamento 13',
    'Percentual Adiantam 13',
    'Ferias Descontar Faltas',
    'Ferias Pagar Adicionais',
    'Ferias Adiantar 13',
    'Ferias Pagar Estagiarios',
    'Ferias Calc Justa Causa',
    'Ferias Movimento Mensal',
  ];

  FolhaParametroModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    competencia = jsonData['competencia'];
    contribuiPis = FolhaParametroDomain.getContribuiPis(jsonData['contribuiPis']);
    aliquotaPis = jsonData['aliquotaPis']?.toDouble();
    discriminarDsr = FolhaParametroDomain.getDiscriminarDsr(jsonData['discriminarDsr']);
    diaPagamento = jsonData['diaPagamento'];
    calculoProporcionalidade = FolhaParametroDomain.getCalculoProporcionalidade(jsonData['calculoProporcionalidade']);
    descontarFaltas13 = FolhaParametroDomain.getDescontarFaltas13(jsonData['descontarFaltas13']);
    pagarAdicionais13 = FolhaParametroDomain.getPagarAdicionais13(jsonData['pagarAdicionais13']);
    pagarEstagiarios13 = FolhaParametroDomain.getPagarEstagiarios13(jsonData['pagarEstagiarios13']);
    mesAdiantamento13 = jsonData['mesAdiantamento13'];
    percentualAdiantam13 = jsonData['percentualAdiantam13']?.toDouble();
    feriasDescontarFaltas = FolhaParametroDomain.getFeriasDescontarFaltas(jsonData['feriasDescontarFaltas']);
    feriasPagarAdicionais = FolhaParametroDomain.getFeriasPagarAdicionais(jsonData['feriasPagarAdicionais']);
    feriasAdiantar13 = FolhaParametroDomain.getFeriasAdiantar13(jsonData['feriasAdiantar13']);
    feriasPagarEstagiarios = FolhaParametroDomain.getFeriasPagarEstagiarios(jsonData['feriasPagarEstagiarios']);
    feriasCalcJustaCausa = FolhaParametroDomain.getFeriasCalcJustaCausa(jsonData['feriasCalcJustaCausa']);
    feriasMovimentoMensal = FolhaParametroDomain.getFeriasMovimentoMensal(jsonData['feriasMovimentoMensal']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['contribuiPis'] = FolhaParametroDomain.setContribuiPis(contribuiPis);
    jsonData['aliquotaPis'] = aliquotaPis;
    jsonData['discriminarDsr'] = FolhaParametroDomain.setDiscriminarDsr(discriminarDsr);
    jsonData['diaPagamento'] = diaPagamento;
    jsonData['calculoProporcionalidade'] = FolhaParametroDomain.setCalculoProporcionalidade(calculoProporcionalidade);
    jsonData['descontarFaltas13'] = FolhaParametroDomain.setDescontarFaltas13(descontarFaltas13);
    jsonData['pagarAdicionais13'] = FolhaParametroDomain.setPagarAdicionais13(pagarAdicionais13);
    jsonData['pagarEstagiarios13'] = FolhaParametroDomain.setPagarEstagiarios13(pagarEstagiarios13);
    jsonData['mesAdiantamento13'] = mesAdiantamento13;
    jsonData['percentualAdiantam13'] = percentualAdiantam13;
    jsonData['feriasDescontarFaltas'] = FolhaParametroDomain.setFeriasDescontarFaltas(feriasDescontarFaltas);
    jsonData['feriasPagarAdicionais'] = FolhaParametroDomain.setFeriasPagarAdicionais(feriasPagarAdicionais);
    jsonData['feriasAdiantar13'] = FolhaParametroDomain.setFeriasAdiantar13(feriasAdiantar13);
    jsonData['feriasPagarEstagiarios'] = FolhaParametroDomain.setFeriasPagarEstagiarios(feriasPagarEstagiarios);
    jsonData['feriasCalcJustaCausa'] = FolhaParametroDomain.setFeriasCalcJustaCausa(feriasCalcJustaCausa);
    jsonData['feriasMovimentoMensal'] = FolhaParametroDomain.setFeriasMovimentoMensal(feriasMovimentoMensal);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaParametroModel fromPlutoRow(PlutoRow row) {
    return FolhaParametroModel(
      id: row.cells['id']?.value,
      competencia: row.cells['competencia']?.value,
      contribuiPis: row.cells['contribuiPis']?.value,
      aliquotaPis: row.cells['aliquotaPis']?.value,
      discriminarDsr: row.cells['discriminarDsr']?.value,
      diaPagamento: row.cells['diaPagamento']?.value,
      calculoProporcionalidade: row.cells['calculoProporcionalidade']?.value,
      descontarFaltas13: row.cells['descontarFaltas13']?.value,
      pagarAdicionais13: row.cells['pagarAdicionais13']?.value,
      pagarEstagiarios13: row.cells['pagarEstagiarios13']?.value,
      mesAdiantamento13: row.cells['mesAdiantamento13']?.value,
      percentualAdiantam13: row.cells['percentualAdiantam13']?.value,
      feriasDescontarFaltas: row.cells['feriasDescontarFaltas']?.value,
      feriasPagarAdicionais: row.cells['feriasPagarAdicionais']?.value,
      feriasAdiantar13: row.cells['feriasAdiantar13']?.value,
      feriasPagarEstagiarios: row.cells['feriasPagarEstagiarios']?.value,
      feriasCalcJustaCausa: row.cells['feriasCalcJustaCausa']?.value,
      feriasMovimentoMensal: row.cells['feriasMovimentoMensal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'contribuiPis': PlutoCell(value: contribuiPis ?? ''),
        'aliquotaPis': PlutoCell(value: aliquotaPis ?? 0.0),
        'discriminarDsr': PlutoCell(value: discriminarDsr ?? ''),
        'diaPagamento': PlutoCell(value: diaPagamento ?? ''),
        'calculoProporcionalidade': PlutoCell(value: calculoProporcionalidade ?? ''),
        'descontarFaltas13': PlutoCell(value: descontarFaltas13 ?? ''),
        'pagarAdicionais13': PlutoCell(value: pagarAdicionais13 ?? ''),
        'pagarEstagiarios13': PlutoCell(value: pagarEstagiarios13 ?? ''),
        'mesAdiantamento13': PlutoCell(value: mesAdiantamento13 ?? ''),
        'percentualAdiantam13': PlutoCell(value: percentualAdiantam13 ?? 0.0),
        'feriasDescontarFaltas': PlutoCell(value: feriasDescontarFaltas ?? ''),
        'feriasPagarAdicionais': PlutoCell(value: feriasPagarAdicionais ?? ''),
        'feriasAdiantar13': PlutoCell(value: feriasAdiantar13 ?? ''),
        'feriasPagarEstagiarios': PlutoCell(value: feriasPagarEstagiarios ?? ''),
        'feriasCalcJustaCausa': PlutoCell(value: feriasCalcJustaCausa ?? ''),
        'feriasMovimentoMensal': PlutoCell(value: feriasMovimentoMensal ?? ''),
      },
    );
  }

  FolhaParametroModel clone() {
    return FolhaParametroModel(
      id: id,
      competencia: competencia,
      contribuiPis: contribuiPis,
      aliquotaPis: aliquotaPis,
      discriminarDsr: discriminarDsr,
      diaPagamento: diaPagamento,
      calculoProporcionalidade: calculoProporcionalidade,
      descontarFaltas13: descontarFaltas13,
      pagarAdicionais13: pagarAdicionais13,
      pagarEstagiarios13: pagarEstagiarios13,
      mesAdiantamento13: mesAdiantamento13,
      percentualAdiantam13: percentualAdiantam13,
      feriasDescontarFaltas: feriasDescontarFaltas,
      feriasPagarAdicionais: feriasPagarAdicionais,
      feriasAdiantar13: feriasAdiantar13,
      feriasPagarEstagiarios: feriasPagarEstagiarios,
      feriasCalcJustaCausa: feriasCalcJustaCausa,
      feriasMovimentoMensal: feriasMovimentoMensal,
    );
  }


}