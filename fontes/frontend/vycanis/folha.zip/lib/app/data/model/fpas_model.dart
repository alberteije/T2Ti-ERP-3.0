import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/data/domain/domain_imports.dart';

class FpasModel extends ModelBase {
  int? id;
  int? codigo;
  String? cnae;
  double? aliquotaSat;
  String? descricao;
  double? percentualInssPatronal;
  String? codigoTerceiro;
  double? percentualTerceiros;

  FpasModel({
    this.id,
    this.codigo,
    this.cnae,
    this.aliquotaSat,
    this.descricao,
    this.percentualInssPatronal,
    this.codigoTerceiro = 'AAA',
    this.percentualTerceiros,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'cnae',
    'aliquota_sat',
    'descricao',
    'percentual_inss_patronal',
    'codigo_terceiro',
    'percentual_terceiros',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Cnae',
    'Aliquota Sat',
    'Descricao',
    'Percentual Inss Patronal',
    'Codigo Terceiro',
    'Percentual Terceiros',
  ];

  FpasModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    cnae = jsonData['cnae'];
    aliquotaSat = jsonData['aliquotaSat']?.toDouble();
    descricao = jsonData['descricao'];
    percentualInssPatronal = jsonData['percentualInssPatronal']?.toDouble();
    codigoTerceiro = FpasDomain.getCodigoTerceiro(jsonData['codigoTerceiro']);
    percentualTerceiros = jsonData['percentualTerceiros']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['cnae'] = cnae;
    jsonData['aliquotaSat'] = aliquotaSat;
    jsonData['descricao'] = descricao;
    jsonData['percentualInssPatronal'] = percentualInssPatronal;
    jsonData['codigoTerceiro'] = FpasDomain.setCodigoTerceiro(codigoTerceiro);
    jsonData['percentualTerceiros'] = percentualTerceiros;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FpasModel fromPlutoRow(PlutoRow row) {
    return FpasModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      cnae: row.cells['cnae']?.value,
      aliquotaSat: row.cells['aliquotaSat']?.value,
      descricao: row.cells['descricao']?.value,
      percentualInssPatronal: row.cells['percentualInssPatronal']?.value,
      codigoTerceiro: row.cells['codigoTerceiro']?.value,
      percentualTerceiros: row.cells['percentualTerceiros']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? 0),
        'cnae': PlutoCell(value: cnae ?? ''),
        'aliquotaSat': PlutoCell(value: aliquotaSat ?? 0.0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'percentualInssPatronal': PlutoCell(value: percentualInssPatronal ?? 0.0),
        'codigoTerceiro': PlutoCell(value: codigoTerceiro ?? ''),
        'percentualTerceiros': PlutoCell(value: percentualTerceiros ?? 0.0),
      },
    );
  }

  FpasModel clone() {
    return FpasModel(
      id: id,
      codigo: codigo,
      cnae: cnae,
      aliquotaSat: aliquotaSat,
      descricao: descricao,
      percentualInssPatronal: percentualInssPatronal,
      codigoTerceiro: codigoTerceiro,
      percentualTerceiros: percentualTerceiros,
    );
  }


}