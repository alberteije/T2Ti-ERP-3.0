import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class FolhaInssRetencaoModel extends ModelBase {
  int? id;
  int? idFolhaInss;
  int? idFolhaInssServico;
  double? valorMensal;
  double? valor13;
  FolhaInssServicoModel? folhaInssServicoModel;

  FolhaInssRetencaoModel({
    this.id,
    this.idFolhaInss,
    this.idFolhaInssServico,
    this.valorMensal,
    this.valor13,
    FolhaInssServicoModel? folhaInssServicoModel,
  }) {
    this.folhaInssServicoModel = folhaInssServicoModel ?? FolhaInssServicoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'valor_mensal',
    'valor_13',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Valor Mensal',
    'Valor 13',
  ];

  FolhaInssRetencaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFolhaInss = jsonData['idFolhaInss'];
    idFolhaInssServico = jsonData['idFolhaInssServico'];
    valorMensal = jsonData['valorMensal']?.toDouble();
    valor13 = jsonData['valor13']?.toDouble();
    folhaInssServicoModel = jsonData['folhaInssServicoModel'] == null ? FolhaInssServicoModel() : FolhaInssServicoModel.fromJson(jsonData['folhaInssServicoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFolhaInss'] = idFolhaInss != 0 ? idFolhaInss : null;
    jsonData['idFolhaInssServico'] = idFolhaInssServico != 0 ? idFolhaInssServico : null;
    jsonData['valorMensal'] = valorMensal;
    jsonData['valor13'] = valor13;
    jsonData['folhaInssServicoModel'] = folhaInssServicoModel?.toJson;
    jsonData['folhaInssServico'] = folhaInssServicoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaInssRetencaoModel fromPlutoRow(PlutoRow row) {
    return FolhaInssRetencaoModel(
      id: row.cells['id']?.value,
      idFolhaInss: row.cells['idFolhaInss']?.value,
      idFolhaInssServico: row.cells['idFolhaInssServico']?.value,
      valorMensal: row.cells['valorMensal']?.value,
      valor13: row.cells['valor13']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFolhaInss': PlutoCell(value: idFolhaInss ?? 0),
        'idFolhaInssServico': PlutoCell(value: idFolhaInssServico ?? 0),
        'valorMensal': PlutoCell(value: valorMensal ?? 0.0),
        'valor13': PlutoCell(value: valor13 ?? 0.0),
        'folhaInssServico': PlutoCell(value: folhaInssServicoModel?.nome ?? ''),
      },
    );
  }

  FolhaInssRetencaoModel clone() {
    return FolhaInssRetencaoModel(
      id: id,
      idFolhaInss: idFolhaInss,
      idFolhaInssServico: idFolhaInssServico,
      valorMensal: valorMensal,
      valor13: valor13,
      folhaInssServicoModel: folhaInssServicoModel?.clone(),
    );
  }


}