import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FolhaAfastamentoModel extends ModelBase {
  int? id;
  int? idColaborador;
  int? idFolhaTipoAfastamento;
  DateTime? dataInicio;
  DateTime? dataFim;
  int? diasAfastado;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  FolhaTipoAfastamentoModel? folhaTipoAfastamentoModel;

  FolhaAfastamentoModel({
    this.id,
    this.idColaborador,
    this.idFolhaTipoAfastamento,
    this.dataInicio,
    this.dataFim,
    this.diasAfastado,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    FolhaTipoAfastamentoModel? folhaTipoAfastamentoModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.folhaTipoAfastamentoModel = folhaTipoAfastamentoModel ?? FolhaTipoAfastamentoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_inicio',
    'data_fim',
    'dias_afastado',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Inicio',
    'Data Fim',
    'Dias Afastado',
  ];

  FolhaAfastamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    idFolhaTipoAfastamento = jsonData['idFolhaTipoAfastamento'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    diasAfastado = jsonData['diasAfastado'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    folhaTipoAfastamentoModel = jsonData['folhaTipoAfastamentoModel'] == null ? FolhaTipoAfastamentoModel() : FolhaTipoAfastamentoModel.fromJson(jsonData['folhaTipoAfastamentoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idFolhaTipoAfastamento'] = idFolhaTipoAfastamento != 0 ? idFolhaTipoAfastamento : null;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['diasAfastado'] = diasAfastado;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['folhaTipoAfastamentoModel'] = folhaTipoAfastamentoModel?.toJson;
    jsonData['folhaTipoAfastamento'] = folhaTipoAfastamentoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaAfastamentoModel fromPlutoRow(PlutoRow row) {
    return FolhaAfastamentoModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idFolhaTipoAfastamento: row.cells['idFolhaTipoAfastamento']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      diasAfastado: row.cells['diasAfastado']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idFolhaTipoAfastamento': PlutoCell(value: idFolhaTipoAfastamento ?? 0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'diasAfastado': PlutoCell(value: diasAfastado ?? 0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'folhaTipoAfastamento': PlutoCell(value: folhaTipoAfastamentoModel?.nome ?? ''),
      },
    );
  }

  FolhaAfastamentoModel clone() {
    return FolhaAfastamentoModel(
      id: id,
      idColaborador: idColaborador,
      idFolhaTipoAfastamento: idFolhaTipoAfastamento,
      dataInicio: dataInicio,
      dataFim: dataFim,
      diasAfastado: diasAfastado,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      folhaTipoAfastamentoModel: folhaTipoAfastamentoModel?.clone(),
    );
  }


}