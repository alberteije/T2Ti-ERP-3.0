import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';

class FolhaInssModel extends ModelBase {
  int? id;
  String? competencia;
  List<FolhaInssRetencaoModel>? folhaInssRetencaoModelList;

  FolhaInssModel({
    this.id,
    this.competencia,
    List<FolhaInssRetencaoModel>? folhaInssRetencaoModelList,
  }) {
    this.folhaInssRetencaoModelList = folhaInssRetencaoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
  ];

  FolhaInssModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    competencia = jsonData['competencia'];
    folhaInssRetencaoModelList = (jsonData['folhaInssRetencaoModelList'] as Iterable?)?.map((m) => FolhaInssRetencaoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    
		var folhaInssRetencaoModelLocalList = []; 
		for (FolhaInssRetencaoModel object in folhaInssRetencaoModelList ?? []) { 
			folhaInssRetencaoModelLocalList.add(object.toJson); 
		}
		jsonData['folhaInssRetencaoModelList'] = folhaInssRetencaoModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaInssModel fromPlutoRow(PlutoRow row) {
    return FolhaInssModel(
      id: row.cells['id']?.value,
      competencia: row.cells['competencia']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
      },
    );
  }

  FolhaInssModel clone() {
    return FolhaInssModel(
      id: id,
      competencia: competencia,
      folhaInssRetencaoModelList: folhaInssRetencaoModelListClone(folhaInssRetencaoModelList!),
    );
  }

  folhaInssRetencaoModelListClone(List<FolhaInssRetencaoModel> folhaInssRetencaoModelList) { 
		List<FolhaInssRetencaoModel> resultList = [];
		for (var folhaInssRetencaoModel in folhaInssRetencaoModelList) {
			resultList.add(folhaInssRetencaoModel.clone());
		}
		return resultList;
	}


}