import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class OperadoraPlanoSaudeModel extends ModelBase {
  int? id;
  String? nome;
  String? registroAns;
  String? classificacaoContabilConta;

  OperadoraPlanoSaudeModel({
    this.id,
    this.nome,
    this.registroAns,
    this.classificacaoContabilConta,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'registro_ans',
    'classificacao_contabil_conta',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Registro Ans',
    'Classificacao Contabil Conta',
  ];

  OperadoraPlanoSaudeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    registroAns = jsonData['registroAns'];
    classificacaoContabilConta = jsonData['classificacaoContabilConta'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['registroAns'] = registroAns;
    jsonData['classificacaoContabilConta'] = classificacaoContabilConta;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OperadoraPlanoSaudeModel fromPlutoRow(PlutoRow row) {
    return OperadoraPlanoSaudeModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      registroAns: row.cells['registroAns']?.value,
      classificacaoContabilConta: row.cells['classificacaoContabilConta']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'registroAns': PlutoCell(value: registroAns ?? ''),
        'classificacaoContabilConta': PlutoCell(value: classificacaoContabilConta ?? ''),
      },
    );
  }

  OperadoraPlanoSaudeModel clone() {
    return OperadoraPlanoSaudeModel(
      id: id,
      nome: nome,
      registroAns: registroAns,
      classificacaoContabilConta: classificacaoContabilConta,
    );
  }


}