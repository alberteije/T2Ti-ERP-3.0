import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class FolhaValeTransporteModel extends ModelBase {
  int? id;
  int? idColaborador;
  int? idEmpresaTranspItin;
  int? quantidade;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  EmpresaTransporteItinerarioModel? empresaTransporteItinerarioModel;

  FolhaValeTransporteModel({
    this.id,
    this.idColaborador,
    this.idEmpresaTranspItin,
    this.quantidade,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    EmpresaTransporteItinerarioModel? empresaTransporteItinerarioModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.empresaTransporteItinerarioModel = empresaTransporteItinerarioModel ?? EmpresaTransporteItinerarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade',
  ];

  FolhaValeTransporteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    idEmpresaTranspItin = jsonData['idEmpresaTranspItin'];
    quantidade = jsonData['quantidade'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    empresaTransporteItinerarioModel = jsonData['empresaTransporteItinerarioModel'] == null ? EmpresaTransporteItinerarioModel() : EmpresaTransporteItinerarioModel.fromJson(jsonData['empresaTransporteItinerarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idEmpresaTranspItin'] = idEmpresaTranspItin != 0 ? idEmpresaTranspItin : null;
    jsonData['quantidade'] = quantidade;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['empresaTransporteItinerarioModel'] = empresaTransporteItinerarioModel?.toJson;
    jsonData['empresaTransporteItinerario'] = empresaTransporteItinerarioModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaValeTransporteModel fromPlutoRow(PlutoRow row) {
    return FolhaValeTransporteModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idEmpresaTranspItin: row.cells['idEmpresaTranspItin']?.value,
      quantidade: row.cells['quantidade']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idEmpresaTranspItin': PlutoCell(value: idEmpresaTranspItin ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'empresaTransporteItinerario': PlutoCell(value: empresaTransporteItinerarioModel?.nome ?? ''),
      },
    );
  }

  FolhaValeTransporteModel clone() {
    return FolhaValeTransporteModel(
      id: id,
      idColaborador: idColaborador,
      idEmpresaTranspItin: idEmpresaTranspItin,
      quantidade: quantidade,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      empresaTransporteItinerarioModel: empresaTransporteItinerarioModel?.clone(),
    );
  }


}