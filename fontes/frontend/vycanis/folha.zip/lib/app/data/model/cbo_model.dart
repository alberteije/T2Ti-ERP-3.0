import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class CboModel extends ModelBase {
  int? id;
  String? codigo;
  String? codigo1994;
  String? nome;
  String? observacao;

  CboModel({
    this.id,
    this.codigo,
    this.codigo1994,
    this.nome,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'codigo_1994',
    'nome',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Codigo 1994',
    'Nome',
    'Observacao',
  ];

  CboModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    codigo1994 = jsonData['codigo1994'];
    nome = jsonData['nome'];
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['codigo1994'] = codigo1994;
    jsonData['nome'] = nome;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CboModel fromPlutoRow(PlutoRow row) {
    return CboModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      codigo1994: row.cells['codigo1994']?.value,
      nome: row.cells['nome']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'codigo1994': PlutoCell(value: codigo1994 ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  CboModel clone() {
    return CboModel(
      id: id,
      codigo: codigo,
      codigo1994: codigo1994,
      nome: nome,
      observacao: observacao,
    );
  }


}