import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';

class IrrfModel extends ModelBase {
  int? id;
  String? competencia;
  double? descontoPorDependente;
  double? minimoParaRetencao;
  List<IrrfDetalheModel>? irrfDetalheModelList;

  IrrfModel({
    this.id,
    this.competencia,
    this.descontoPorDependente,
    this.minimoParaRetencao,
    List<IrrfDetalheModel>? irrfDetalheModelList,
  }) {
    this.irrfDetalheModelList = irrfDetalheModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
    'desconto_por_dependente',
    'minimo_para_retencao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
    'Desconto Por Dependente',
    'Minimo Para Retencao',
  ];

  IrrfModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    competencia = jsonData['competencia'];
    descontoPorDependente = jsonData['descontoPorDependente']?.toDouble();
    minimoParaRetencao = jsonData['minimoParaRetencao']?.toDouble();
    irrfDetalheModelList = (jsonData['irrfDetalheModelList'] as Iterable?)?.map((m) => IrrfDetalheModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['descontoPorDependente'] = descontoPorDependente;
    jsonData['minimoParaRetencao'] = minimoParaRetencao;
    
		var irrfDetalheModelLocalList = []; 
		for (IrrfDetalheModel object in irrfDetalheModelList ?? []) { 
			irrfDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['irrfDetalheModelList'] = irrfDetalheModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static IrrfModel fromPlutoRow(PlutoRow row) {
    return IrrfModel(
      id: row.cells['id']?.value,
      competencia: row.cells['competencia']?.value,
      descontoPorDependente: row.cells['descontoPorDependente']?.value,
      minimoParaRetencao: row.cells['minimoParaRetencao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'descontoPorDependente': PlutoCell(value: descontoPorDependente ?? 0.0),
        'minimoParaRetencao': PlutoCell(value: minimoParaRetencao ?? 0.0),
      },
    );
  }

  IrrfModel clone() {
    return IrrfModel(
      id: id,
      competencia: competencia,
      descontoPorDependente: descontoPorDependente,
      minimoParaRetencao: minimoParaRetencao,
      irrfDetalheModelList: irrfDetalheModelListClone(irrfDetalheModelList!),
    );
  }

  irrfDetalheModelListClone(List<IrrfDetalheModel> irrfDetalheModelList) { 
		List<IrrfDetalheModel> resultList = [];
		for (var irrfDetalheModel in irrfDetalheModelList) {
			resultList.add(irrfDetalheModel.clone());
		}
		return resultList;
	}


}