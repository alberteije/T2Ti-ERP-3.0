import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';

class InssModel extends ModelBase {
  int? id;
  String? competencia;
  List<SalarioFamiliaModel>? salarioFamiliaModelList;
  List<InssDetalheModel>? inssDetalheModelList;

  InssModel({
    this.id,
    this.competencia,
    List<SalarioFamiliaModel>? salarioFamiliaModelList,
    List<InssDetalheModel>? inssDetalheModelList,
  }) {
    this.salarioFamiliaModelList = salarioFamiliaModelList?.toList(growable: true) ?? [];
    this.inssDetalheModelList = inssDetalheModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
  ];

  InssModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    competencia = jsonData['competencia'];
    salarioFamiliaModelList = (jsonData['salarioFamiliaModelList'] as Iterable?)?.map((m) => SalarioFamiliaModel.fromJson(m)).toList() ?? [];
    inssDetalheModelList = (jsonData['inssDetalheModelList'] as Iterable?)?.map((m) => InssDetalheModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    
		var salarioFamiliaModelLocalList = []; 
		for (SalarioFamiliaModel object in salarioFamiliaModelList ?? []) { 
			salarioFamiliaModelLocalList.add(object.toJson); 
		}
		jsonData['salarioFamiliaModelList'] = salarioFamiliaModelLocalList;
    
		var inssDetalheModelLocalList = []; 
		for (InssDetalheModel object in inssDetalheModelList ?? []) { 
			inssDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['inssDetalheModelList'] = inssDetalheModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static InssModel fromPlutoRow(PlutoRow row) {
    return InssModel(
      id: row.cells['id']?.value,
      competencia: row.cells['competencia']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
      },
    );
  }

  InssModel clone() {
    return InssModel(
      id: id,
      competencia: competencia,
      salarioFamiliaModelList: salarioFamiliaModelListClone(salarioFamiliaModelList!),
      inssDetalheModelList: inssDetalheModelListClone(inssDetalheModelList!),
    );
  }

  salarioFamiliaModelListClone(List<SalarioFamiliaModel> salarioFamiliaModelList) { 
		List<SalarioFamiliaModel> resultList = [];
		for (var salarioFamiliaModel in salarioFamiliaModelList) {
			resultList.add(salarioFamiliaModel.clone());
		}
		return resultList;
	}

  inssDetalheModelListClone(List<InssDetalheModel> inssDetalheModelList) { 
		List<InssDetalheModel> resultList = [];
		for (var inssDetalheModel in inssDetalheModelList) {
			resultList.add(inssDetalheModel.clone());
		}
		return resultList;
	}


}