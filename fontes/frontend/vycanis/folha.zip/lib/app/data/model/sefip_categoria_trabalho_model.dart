import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class SefipCategoriaTrabalhoModel extends ModelBase {
  int? id;
  int? codigo;
  String? nome;

  SefipCategoriaTrabalhoModel({
    this.id,
    this.codigo,
    this.nome,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
  ];

  SefipCategoriaTrabalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static SefipCategoriaTrabalhoModel fromPlutoRow(PlutoRow row) {
    return SefipCategoriaTrabalhoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
      },
    );
  }

  SefipCategoriaTrabalhoModel clone() {
    return SefipCategoriaTrabalhoModel(
      id: id,
      codigo: codigo,
      nome: nome,
    );
  }


}