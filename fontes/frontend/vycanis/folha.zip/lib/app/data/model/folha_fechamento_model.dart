import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';

class FolhaFechamentoModel extends ModelBase {
  int? id;
  String? fechamentoAtual;
  String? proximoFechamento;

  FolhaFechamentoModel({
    this.id,
    this.fechamentoAtual,
    this.proximoFechamento,
  });

  static List<String> dbColumns = <String>[
    'id',
    'fechamento_atual',
    'proximo_fechamento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Fechamento Atual',
    'Proximo Fechamento',
  ];

  FolhaFechamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    fechamentoAtual = jsonData['fechamentoAtual'];
    proximoFechamento = jsonData['proximoFechamento'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['fechamentoAtual'] = Util.removeMask(fechamentoAtual);
    jsonData['proximoFechamento'] = Util.removeMask(proximoFechamento);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaFechamentoModel fromPlutoRow(PlutoRow row) {
    return FolhaFechamentoModel(
      id: row.cells['id']?.value,
      fechamentoAtual: row.cells['fechamentoAtual']?.value,
      proximoFechamento: row.cells['proximoFechamento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'fechamentoAtual': PlutoCell(value: fechamentoAtual ?? ''),
        'proximoFechamento': PlutoCell(value: proximoFechamento ?? ''),
      },
    );
  }

  FolhaFechamentoModel clone() {
    return FolhaFechamentoModel(
      id: id,
      fechamentoAtual: fechamentoAtual,
      proximoFechamento: proximoFechamento,
    );
  }


}