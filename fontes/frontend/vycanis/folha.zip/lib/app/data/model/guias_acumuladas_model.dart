import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class GuiasAcumuladasModel extends ModelBase {
  int? id;
  String? gpsTipo;
  String? gpsCompetencia;
  double? gpsValorInss;
  double? gpsValorOutrasEnt;
  DateTime? gpsDataPagamento;
  String? irrfCompetencia;
  int? irrfCodigoRecolhimento;
  double? irrfValorAcumulado;
  DateTime? irrfDataPagamento;
  String? pisCompetencia;
  double? pisValorAcumulado;
  DateTime? pisDataPagamento;

  GuiasAcumuladasModel({
    this.id,
    this.gpsTipo = '1-Filial própia empresa',
    this.gpsCompetencia,
    this.gpsValorInss,
    this.gpsValorOutrasEnt,
    this.gpsDataPagamento,
    this.irrfCompetencia,
    this.irrfCodigoRecolhimento,
    this.irrfValorAcumulado,
    this.irrfDataPagamento,
    this.pisCompetencia,
    this.pisValorAcumulado,
    this.pisDataPagamento,
  });

  static List<String> dbColumns = <String>[
    'id',
    'gps_tipo',
    'gps_competencia',
    'gps_valor_inss',
    'gps_valor_outras_ent',
    'gps_data_pagamento',
    'irrf_competencia',
    'irrf_codigo_recolhimento',
    'irrf_valor_acumulado',
    'irrf_data_pagamento',
    'pis_competencia',
    'pis_valor_acumulado',
    'pis_data_pagamento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Gps Tipo',
    'Gps Competencia',
    'Gps Valor Inss',
    'Gps Valor Outras Ent',
    'Gps Data Pagamento',
    'Irrf Competencia',
    'Irrf Codigo Recolhimento',
    'Irrf Valor Acumulado',
    'Irrf Data Pagamento',
    'Pis Competencia',
    'Pis Valor Acumulado',
    'Pis Data Pagamento',
  ];

  GuiasAcumuladasModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    gpsTipo = GuiasAcumuladasDomain.getGpsTipo(jsonData['gpsTipo']);
    gpsCompetencia = jsonData['gpsCompetencia'];
    gpsValorInss = jsonData['gpsValorInss']?.toDouble();
    gpsValorOutrasEnt = jsonData['gpsValorOutrasEnt']?.toDouble();
    gpsDataPagamento = jsonData['gpsDataPagamento'] != null ? DateTime.tryParse(jsonData['gpsDataPagamento']) : null;
    irrfCompetencia = jsonData['irrfCompetencia'];
    irrfCodigoRecolhimento = jsonData['irrfCodigoRecolhimento'];
    irrfValorAcumulado = jsonData['irrfValorAcumulado']?.toDouble();
    irrfDataPagamento = jsonData['irrfDataPagamento'] != null ? DateTime.tryParse(jsonData['irrfDataPagamento']) : null;
    pisCompetencia = jsonData['pisCompetencia'];
    pisValorAcumulado = jsonData['pisValorAcumulado']?.toDouble();
    pisDataPagamento = jsonData['pisDataPagamento'] != null ? DateTime.tryParse(jsonData['pisDataPagamento']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['gpsTipo'] = GuiasAcumuladasDomain.setGpsTipo(gpsTipo);
    jsonData['gpsCompetencia'] = Util.removeMask(gpsCompetencia);
    jsonData['gpsValorInss'] = gpsValorInss;
    jsonData['gpsValorOutrasEnt'] = gpsValorOutrasEnt;
    jsonData['gpsDataPagamento'] = gpsDataPagamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(gpsDataPagamento!) : null;
    jsonData['irrfCompetencia'] = Util.removeMask(irrfCompetencia);
    jsonData['irrfCodigoRecolhimento'] = irrfCodigoRecolhimento;
    jsonData['irrfValorAcumulado'] = irrfValorAcumulado;
    jsonData['irrfDataPagamento'] = irrfDataPagamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(irrfDataPagamento!) : null;
    jsonData['pisCompetencia'] = Util.removeMask(pisCompetencia);
    jsonData['pisValorAcumulado'] = pisValorAcumulado;
    jsonData['pisDataPagamento'] = pisDataPagamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(pisDataPagamento!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GuiasAcumuladasModel fromPlutoRow(PlutoRow row) {
    return GuiasAcumuladasModel(
      id: row.cells['id']?.value,
      gpsTipo: row.cells['gpsTipo']?.value,
      gpsCompetencia: row.cells['gpsCompetencia']?.value,
      gpsValorInss: row.cells['gpsValorInss']?.value,
      gpsValorOutrasEnt: row.cells['gpsValorOutrasEnt']?.value,
      gpsDataPagamento: Util.stringToDate(row.cells['gpsDataPagamento']?.value),
      irrfCompetencia: row.cells['irrfCompetencia']?.value,
      irrfCodigoRecolhimento: row.cells['irrfCodigoRecolhimento']?.value,
      irrfValorAcumulado: row.cells['irrfValorAcumulado']?.value,
      irrfDataPagamento: Util.stringToDate(row.cells['irrfDataPagamento']?.value),
      pisCompetencia: row.cells['pisCompetencia']?.value,
      pisValorAcumulado: row.cells['pisValorAcumulado']?.value,
      pisDataPagamento: Util.stringToDate(row.cells['pisDataPagamento']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'gpsTipo': PlutoCell(value: gpsTipo ?? ''),
        'gpsCompetencia': PlutoCell(value: gpsCompetencia ?? ''),
        'gpsValorInss': PlutoCell(value: gpsValorInss ?? 0.0),
        'gpsValorOutrasEnt': PlutoCell(value: gpsValorOutrasEnt ?? 0.0),
        'gpsDataPagamento': PlutoCell(value: gpsDataPagamento),
        'irrfCompetencia': PlutoCell(value: irrfCompetencia ?? ''),
        'irrfCodigoRecolhimento': PlutoCell(value: irrfCodigoRecolhimento ?? 0),
        'irrfValorAcumulado': PlutoCell(value: irrfValorAcumulado ?? 0.0),
        'irrfDataPagamento': PlutoCell(value: irrfDataPagamento),
        'pisCompetencia': PlutoCell(value: pisCompetencia ?? ''),
        'pisValorAcumulado': PlutoCell(value: pisValorAcumulado ?? 0.0),
        'pisDataPagamento': PlutoCell(value: pisDataPagamento),
      },
    );
  }

  GuiasAcumuladasModel clone() {
    return GuiasAcumuladasModel(
      id: id,
      gpsTipo: gpsTipo,
      gpsCompetencia: gpsCompetencia,
      gpsValorInss: gpsValorInss,
      gpsValorOutrasEnt: gpsValorOutrasEnt,
      gpsDataPagamento: gpsDataPagamento,
      irrfCompetencia: irrfCompetencia,
      irrfCodigoRecolhimento: irrfCodigoRecolhimento,
      irrfValorAcumulado: irrfValorAcumulado,
      irrfDataPagamento: irrfDataPagamento,
      pisCompetencia: pisCompetencia,
      pisValorAcumulado: pisValorAcumulado,
      pisDataPagamento: pisDataPagamento,
    );
  }


}