import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class FolhaTipoAfastamentoModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  String? codigoEsocial;
  String? descricao;

  FolhaTipoAfastamentoModel({
    this.id,
    this.codigo,
    this.nome,
    this.codigoEsocial,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'codigo_esocial',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Codigo Esocial',
    'Descricao',
  ];

  FolhaTipoAfastamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    codigoEsocial = jsonData['codigoEsocial'];
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['codigoEsocial'] = codigoEsocial;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaTipoAfastamentoModel fromPlutoRow(PlutoRow row) {
    return FolhaTipoAfastamentoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      codigoEsocial: row.cells['codigoEsocial']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'codigoEsocial': PlutoCell(value: codigoEsocial ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  FolhaTipoAfastamentoModel clone() {
    return FolhaTipoAfastamentoModel(
      id: id,
      codigo: codigo,
      nome: nome,
      codigoEsocial: codigoEsocial,
      descricao: descricao,
    );
  }


}