import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class FeriasPeriodoAquisitivoModel extends ModelBase {
  int? id;
  int? idColaborador;
  DateTime? dataInicio;
  DateTime? dataFim;
  String? situacao;
  DateTime? limiteParaGozo;
  String? descontarFaltas;
  String? desconsiderarAfastamento;
  int? afastamentoPrevidencia;
  int? afastamentoSemRemun;
  int? afastamentoComRemun;
  int? diasDireito;
  int? diasGozados;
  int? diasFaltas;
  int? diasRestantes;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  FeriasPeriodoAquisitivoModel({
    this.id,
    this.idColaborador,
    this.dataInicio,
    this.dataFim,
    this.situacao = '0=Em Aberto',
    this.limiteParaGozo,
    this.descontarFaltas = 'Sim',
    this.desconsiderarAfastamento = 'Sim',
    this.afastamentoPrevidencia,
    this.afastamentoSemRemun,
    this.afastamentoComRemun,
    this.diasDireito,
    this.diasGozados,
    this.diasFaltas,
    this.diasRestantes,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_inicio',
    'data_fim',
    'situacao',
    'limite_para_gozo',
    'descontar_faltas',
    'desconsiderar_afastamento',
    'afastamento_previdencia',
    'afastamento_sem_remun',
    'afastamento_com_remun',
    'dias_direito',
    'dias_gozados',
    'dias_faltas',
    'dias_restantes',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Inicio',
    'Data Fim',
    'Situacao',
    'Limite Para Gozo',
    'Descontar Faltas',
    'Desconsiderar Afastamento',
    'Afastamento Previdencia',
    'Afastamento Sem Remun',
    'Afastamento Com Remun',
    'Dias Direito',
    'Dias Gozados',
    'Dias Faltas',
    'Dias Restantes',
  ];

  FeriasPeriodoAquisitivoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    situacao = FeriasPeriodoAquisitivoDomain.getSituacao(jsonData['situacao']);
    limiteParaGozo = jsonData['limiteParaGozo'] != null ? DateTime.tryParse(jsonData['limiteParaGozo']) : null;
    descontarFaltas = FeriasPeriodoAquisitivoDomain.getDescontarFaltas(jsonData['descontarFaltas']);
    desconsiderarAfastamento = FeriasPeriodoAquisitivoDomain.getDesconsiderarAfastamento(jsonData['desconsiderarAfastamento']);
    afastamentoPrevidencia = jsonData['afastamentoPrevidencia'];
    afastamentoSemRemun = jsonData['afastamentoSemRemun'];
    afastamentoComRemun = jsonData['afastamentoComRemun'];
    diasDireito = jsonData['diasDireito'];
    diasGozados = jsonData['diasGozados'];
    diasFaltas = jsonData['diasFaltas'];
    diasRestantes = jsonData['diasRestantes'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['situacao'] = FeriasPeriodoAquisitivoDomain.setSituacao(situacao);
    jsonData['limiteParaGozo'] = limiteParaGozo != null ? DateFormat('yyyy-MM-ddT00:00:00').format(limiteParaGozo!) : null;
    jsonData['descontarFaltas'] = FeriasPeriodoAquisitivoDomain.setDescontarFaltas(descontarFaltas);
    jsonData['desconsiderarAfastamento'] = FeriasPeriodoAquisitivoDomain.setDesconsiderarAfastamento(desconsiderarAfastamento);
    jsonData['afastamentoPrevidencia'] = afastamentoPrevidencia;
    jsonData['afastamentoSemRemun'] = afastamentoSemRemun;
    jsonData['afastamentoComRemun'] = afastamentoComRemun;
    jsonData['diasDireito'] = diasDireito;
    jsonData['diasGozados'] = diasGozados;
    jsonData['diasFaltas'] = diasFaltas;
    jsonData['diasRestantes'] = diasRestantes;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FeriasPeriodoAquisitivoModel fromPlutoRow(PlutoRow row) {
    return FeriasPeriodoAquisitivoModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      situacao: row.cells['situacao']?.value,
      limiteParaGozo: Util.stringToDate(row.cells['limiteParaGozo']?.value),
      descontarFaltas: row.cells['descontarFaltas']?.value,
      desconsiderarAfastamento: row.cells['desconsiderarAfastamento']?.value,
      afastamentoPrevidencia: row.cells['afastamentoPrevidencia']?.value,
      afastamentoSemRemun: row.cells['afastamentoSemRemun']?.value,
      afastamentoComRemun: row.cells['afastamentoComRemun']?.value,
      diasDireito: row.cells['diasDireito']?.value,
      diasGozados: row.cells['diasGozados']?.value,
      diasFaltas: row.cells['diasFaltas']?.value,
      diasRestantes: row.cells['diasRestantes']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'situacao': PlutoCell(value: situacao ?? ''),
        'limiteParaGozo': PlutoCell(value: limiteParaGozo),
        'descontarFaltas': PlutoCell(value: descontarFaltas ?? ''),
        'desconsiderarAfastamento': PlutoCell(value: desconsiderarAfastamento ?? ''),
        'afastamentoPrevidencia': PlutoCell(value: afastamentoPrevidencia ?? 0),
        'afastamentoSemRemun': PlutoCell(value: afastamentoSemRemun ?? 0),
        'afastamentoComRemun': PlutoCell(value: afastamentoComRemun ?? 0),
        'diasDireito': PlutoCell(value: diasDireito ?? 0),
        'diasGozados': PlutoCell(value: diasGozados ?? 0),
        'diasFaltas': PlutoCell(value: diasFaltas ?? 0),
        'diasRestantes': PlutoCell(value: diasRestantes ?? 0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  FeriasPeriodoAquisitivoModel clone() {
    return FeriasPeriodoAquisitivoModel(
      id: id,
      idColaborador: idColaborador,
      dataInicio: dataInicio,
      dataFim: dataFim,
      situacao: situacao,
      limiteParaGozo: limiteParaGozo,
      descontarFaltas: descontarFaltas,
      desconsiderarAfastamento: desconsiderarAfastamento,
      afastamentoPrevidencia: afastamentoPrevidencia,
      afastamentoSemRemun: afastamentoSemRemun,
      afastamentoComRemun: afastamentoComRemun,
      diasDireito: diasDireito,
      diasGozados: diasGozados,
      diasFaltas: diasFaltas,
      diasRestantes: diasRestantes,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}