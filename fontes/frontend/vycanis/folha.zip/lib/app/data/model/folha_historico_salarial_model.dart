import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';

class FolhaHistoricoSalarialModel extends ModelBase {
  int? id;
  int? idColaborador;
  String? competencia;
  double? salarioAtual;
  double? percentualAumento;
  double? salarioNovo;
  String? validoAPartir;
  String? motivo;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  FolhaHistoricoSalarialModel({
    this.id,
    this.idColaborador,
    this.competencia,
    this.salarioAtual,
    this.percentualAumento,
    this.salarioNovo,
    this.validoAPartir,
    this.motivo,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
    'salario_atual',
    'percentual_aumento',
    'salario_novo',
    'valido_a_partir',
    'motivo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
    'Salario Atual',
    'Percentual Aumento',
    'Salario Novo',
    'Valido A Partir',
    'Motivo',
  ];

  FolhaHistoricoSalarialModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    competencia = jsonData['competencia'];
    salarioAtual = jsonData['salarioAtual']?.toDouble();
    percentualAumento = jsonData['percentualAumento']?.toDouble();
    salarioNovo = jsonData['salarioNovo']?.toDouble();
    validoAPartir = jsonData['validoAPartir'];
    motivo = jsonData['motivo'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['salarioAtual'] = salarioAtual;
    jsonData['percentualAumento'] = percentualAumento;
    jsonData['salarioNovo'] = salarioNovo;
    jsonData['validoAPartir'] = Util.removeMask(validoAPartir);
    jsonData['motivo'] = motivo;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaHistoricoSalarialModel fromPlutoRow(PlutoRow row) {
    return FolhaHistoricoSalarialModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      competencia: row.cells['competencia']?.value,
      salarioAtual: row.cells['salarioAtual']?.value,
      percentualAumento: row.cells['percentualAumento']?.value,
      salarioNovo: row.cells['salarioNovo']?.value,
      validoAPartir: row.cells['validoAPartir']?.value,
      motivo: row.cells['motivo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'salarioAtual': PlutoCell(value: salarioAtual ?? 0.0),
        'percentualAumento': PlutoCell(value: percentualAumento ?? 0.0),
        'salarioNovo': PlutoCell(value: salarioNovo ?? 0.0),
        'validoAPartir': PlutoCell(value: validoAPartir ?? ''),
        'motivo': PlutoCell(value: motivo ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  FolhaHistoricoSalarialModel clone() {
    return FolhaHistoricoSalarialModel(
      id: id,
      idColaborador: idColaborador,
      competencia: competencia,
      salarioAtual: salarioAtual,
      percentualAumento: percentualAumento,
      salarioNovo: salarioNovo,
      validoAPartir: validoAPartir,
      motivo: motivo,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}