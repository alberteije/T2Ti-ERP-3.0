import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/data/domain/domain_imports.dart';

class FolhaLancamentoCabecalhoModel extends ModelBase {
  int? id;
  int? idColaborador;
  String? competencia;
  String? tipo;
  List<FolhaLancamentoDetalheModel>? folhaLancamentoDetalheModelList;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  FolhaLancamentoCabecalhoModel({
    this.id,
    this.idColaborador,
    this.competencia,
    this.tipo = 'Folha Mensal',
    List<FolhaLancamentoDetalheModel>? folhaLancamentoDetalheModelList,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.folhaLancamentoDetalheModelList = folhaLancamentoDetalheModelList?.toList(growable: true) ?? [];
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
    'tipo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
    'Tipo',
  ];

  FolhaLancamentoCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    competencia = jsonData['competencia'];
    tipo = FolhaLancamentoCabecalhoDomain.getTipo(jsonData['tipo']);
    folhaLancamentoDetalheModelList = (jsonData['folhaLancamentoDetalheModelList'] as Iterable?)?.map((m) => FolhaLancamentoDetalheModel.fromJson(m)).toList() ?? [];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['competencia'] = competencia;
    jsonData['tipo'] = FolhaLancamentoCabecalhoDomain.setTipo(tipo);
    
		var folhaLancamentoDetalheModelLocalList = []; 
		for (FolhaLancamentoDetalheModel object in folhaLancamentoDetalheModelList ?? []) { 
			folhaLancamentoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['folhaLancamentoDetalheModelList'] = folhaLancamentoDetalheModelLocalList;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaLancamentoCabecalhoModel fromPlutoRow(PlutoRow row) {
    return FolhaLancamentoCabecalhoModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      competencia: row.cells['competencia']?.value,
      tipo: row.cells['tipo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  FolhaLancamentoCabecalhoModel clone() {
    return FolhaLancamentoCabecalhoModel(
      id: id,
      idColaborador: idColaborador,
      competencia: competencia,
      tipo: tipo,
      folhaLancamentoDetalheModelList: folhaLancamentoDetalheModelListClone(folhaLancamentoDetalheModelList!),
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }

  folhaLancamentoDetalheModelListClone(List<FolhaLancamentoDetalheModel> folhaLancamentoDetalheModelList) { 
		List<FolhaLancamentoDetalheModel> resultList = [];
		for (var folhaLancamentoDetalheModel in folhaLancamentoDetalheModelList) {
			resultList.add(folhaLancamentoDetalheModel.clone());
		}
		return resultList;
	}


}