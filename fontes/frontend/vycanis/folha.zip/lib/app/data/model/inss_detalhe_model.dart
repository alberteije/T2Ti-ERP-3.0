import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class InssDetalheModel extends ModelBase {
  int? id;
  int? idInss;
  int? faixa;
  double? de;
  double? ate;
  double? taxa;

  InssDetalheModel({
    this.id,
    this.idInss,
    this.faixa,
    this.de,
    this.ate,
    this.taxa,
  });

  static List<String> dbColumns = <String>[
    'id',
    'faixa',
    'de',
    'ate',
    'taxa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Faixa',
    'De',
    'Ate',
    'Taxa',
  ];

  InssDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idInss = jsonData['idInss'];
    faixa = jsonData['faixa'];
    de = jsonData['de']?.toDouble();
    ate = jsonData['ate']?.toDouble();
    taxa = jsonData['taxa']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idInss'] = idInss != 0 ? idInss : null;
    jsonData['faixa'] = faixa;
    jsonData['de'] = de;
    jsonData['ate'] = ate;
    jsonData['taxa'] = taxa;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static InssDetalheModel fromPlutoRow(PlutoRow row) {
    return InssDetalheModel(
      id: row.cells['id']?.value,
      idInss: row.cells['idInss']?.value,
      faixa: row.cells['faixa']?.value,
      de: row.cells['de']?.value,
      ate: row.cells['ate']?.value,
      taxa: row.cells['taxa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idInss': PlutoCell(value: idInss ?? 0),
        'faixa': PlutoCell(value: faixa ?? 0),
        'de': PlutoCell(value: de ?? 0.0),
        'ate': PlutoCell(value: ate ?? 0.0),
        'taxa': PlutoCell(value: taxa ?? 0.0),
      },
    );
  }

  InssDetalheModel clone() {
    return InssDetalheModel(
      id: id,
      idInss: idInss,
      faixa: faixa,
      de: de,
      ate: ate,
      taxa: taxa,
    );
  }


}