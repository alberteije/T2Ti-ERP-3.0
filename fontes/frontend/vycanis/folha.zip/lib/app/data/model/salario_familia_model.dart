import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class SalarioFamiliaModel extends ModelBase {
  int? id;
  int? idInss;
  int? faixa;
  double? de;
  double? ate;
  double? valor;

  SalarioFamiliaModel({
    this.id,
    this.idInss,
    this.faixa,
    this.de,
    this.ate,
    this.valor,
  });

  static List<String> dbColumns = <String>[
    'id',
    'faixa',
    'de',
    'ate',
    'valor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Faixa',
    'De',
    'Ate',
    'Valor',
  ];

  SalarioFamiliaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idInss = jsonData['idInss'];
    faixa = jsonData['faixa'];
    de = jsonData['de']?.toDouble();
    ate = jsonData['ate']?.toDouble();
    valor = jsonData['valor']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idInss'] = idInss != 0 ? idInss : null;
    jsonData['faixa'] = faixa;
    jsonData['de'] = de;
    jsonData['ate'] = ate;
    jsonData['valor'] = valor;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static SalarioFamiliaModel fromPlutoRow(PlutoRow row) {
    return SalarioFamiliaModel(
      id: row.cells['id']?.value,
      idInss: row.cells['idInss']?.value,
      faixa: row.cells['faixa']?.value,
      de: row.cells['de']?.value,
      ate: row.cells['ate']?.value,
      valor: row.cells['valor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idInss': PlutoCell(value: idInss ?? 0),
        'faixa': PlutoCell(value: faixa ?? 0),
        'de': PlutoCell(value: de ?? 0.0),
        'ate': PlutoCell(value: ate ?? 0.0),
        'valor': PlutoCell(value: valor ?? 0.0),
      },
    );
  }

  SalarioFamiliaModel clone() {
    return SalarioFamiliaModel(
      id: id,
      idInss: idInss,
      faixa: faixa,
      de: de,
      ate: ate,
      valor: valor,
    );
  }


}