import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';


class FolhaLancamentoDetalheModel extends ModelBase {
  int? id;
  int? idFolhaLancamentoCabecalho;
  int? idFolhaEvento;
  double? origem;
  double? provento;
  double? desconto;
  FolhaEventoModel? folhaEventoModel;

  FolhaLancamentoDetalheModel({
    this.id,
    this.idFolhaLancamentoCabecalho,
    this.idFolhaEvento,
    this.origem,
    this.provento,
    this.desconto,
    FolhaEventoModel? folhaEventoModel,
  }) {
    this.folhaEventoModel = folhaEventoModel ?? FolhaEventoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'origem',
    'provento',
    'desconto',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Origem',
    'Provento',
    'Desconto',
  ];

  FolhaLancamentoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFolhaLancamentoCabecalho = jsonData['idFolhaLancamentoCabecalho'];
    idFolhaEvento = jsonData['idFolhaEvento'];
    origem = jsonData['origem']?.toDouble();
    provento = jsonData['provento']?.toDouble();
    desconto = jsonData['desconto']?.toDouble();
    folhaEventoModel = jsonData['folhaEventoModel'] == null ? FolhaEventoModel() : FolhaEventoModel.fromJson(jsonData['folhaEventoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFolhaLancamentoCabecalho'] = idFolhaLancamentoCabecalho != 0 ? idFolhaLancamentoCabecalho : null;
    jsonData['idFolhaEvento'] = idFolhaEvento != 0 ? idFolhaEvento : null;
    jsonData['origem'] = origem;
    jsonData['provento'] = provento;
    jsonData['desconto'] = desconto;
    jsonData['folhaEventoModel'] = folhaEventoModel?.toJson;
    jsonData['folhaEvento'] = folhaEventoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaLancamentoDetalheModel fromPlutoRow(PlutoRow row) {
    return FolhaLancamentoDetalheModel(
      id: row.cells['id']?.value,
      idFolhaLancamentoCabecalho: row.cells['idFolhaLancamentoCabecalho']?.value,
      idFolhaEvento: row.cells['idFolhaEvento']?.value,
      origem: row.cells['origem']?.value,
      provento: row.cells['provento']?.value,
      desconto: row.cells['desconto']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFolhaLancamentoCabecalho': PlutoCell(value: idFolhaLancamentoCabecalho ?? 0),
        'idFolhaEvento': PlutoCell(value: idFolhaEvento ?? 0),
        'origem': PlutoCell(value: origem ?? 0.0),
        'provento': PlutoCell(value: provento ?? 0.0),
        'desconto': PlutoCell(value: desconto ?? 0.0),
        'folhaEvento': PlutoCell(value: folhaEventoModel?.nome ?? ''),
      },
    );
  }

  FolhaLancamentoDetalheModel clone() {
    return FolhaLancamentoDetalheModel(
      id: id,
      idFolhaLancamentoCabecalho: idFolhaLancamentoCabecalho,
      idFolhaEvento: idFolhaEvento,
      origem: origem,
      provento: provento,
      desconto: desconto,
      folhaEventoModel: folhaEventoModel?.clone(),
    );
  }


}