import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class FolhaPppFatorRiscoModel extends ModelBase {
  int? id;
  int? idFolhaPpp;
  DateTime? dataInicio;
  DateTime? dataFim;
  String? tipo;
  String? fatorRisco;
  String? intensidade;
  String? tecnicaUtilizada;
  String? epcEficaz;
  String? epiEficaz;
  int? caEpi;
  String? atendimentoNr061;
  String? atendimentoNr062;
  String? atendimentoNr063;
  String? atendimentoNr064;
  String? atendimentoNr065;

  FolhaPppFatorRiscoModel({
    this.id,
    this.idFolhaPpp,
    this.dataInicio,
    this.dataFim,
    this.tipo = 'F=Físico',
    this.fatorRisco,
    this.intensidade,
    this.tecnicaUtilizada,
    this.epcEficaz = 'Sim',
    this.epiEficaz = 'Sim',
    this.caEpi,
    this.atendimentoNr061 = 'Sim',
    this.atendimentoNr062 = 'Sim',
    this.atendimentoNr063 = 'Sim',
    this.atendimentoNr064 = 'Sim',
    this.atendimentoNr065 = 'Sim',
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_inicio',
    'data_fim',
    'tipo',
    'fator_risco',
    'intensidade',
    'tecnica_utilizada',
    'epc_eficaz',
    'epi_eficaz',
    'ca_epi',
    'atendimento_nr06_1',
    'atendimento_nr06_2',
    'atendimento_nr06_3',
    'atendimento_nr06_4',
    'atendimento_nr06_5',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Inicio',
    'Data Fim',
    'Tipo',
    'Fator Risco',
    'Intensidade',
    'Tecnica Utilizada',
    'Epc Eficaz',
    'Epi Eficaz',
    'Ca Epi',
    'Atendimento Nr06 1',
    'Atendimento Nr06 2',
    'Atendimento Nr06 3',
    'Atendimento Nr06 4',
    'Atendimento Nr06 5',
  ];

  FolhaPppFatorRiscoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFolhaPpp = jsonData['idFolhaPpp'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    tipo = FolhaPppFatorRiscoDomain.getTipo(jsonData['tipo']);
    fatorRisco = jsonData['fatorRisco'];
    intensidade = jsonData['intensidade'];
    tecnicaUtilizada = jsonData['tecnicaUtilizada'];
    epcEficaz = FolhaPppFatorRiscoDomain.getEpcEficaz(jsonData['epcEficaz']);
    epiEficaz = FolhaPppFatorRiscoDomain.getEpiEficaz(jsonData['epiEficaz']);
    caEpi = jsonData['caEpi'];
    atendimentoNr061 = FolhaPppFatorRiscoDomain.getAtendimentoNr061(jsonData['atendimentoNr061']);
    atendimentoNr062 = FolhaPppFatorRiscoDomain.getAtendimentoNr062(jsonData['atendimentoNr062']);
    atendimentoNr063 = FolhaPppFatorRiscoDomain.getAtendimentoNr063(jsonData['atendimentoNr063']);
    atendimentoNr064 = FolhaPppFatorRiscoDomain.getAtendimentoNr064(jsonData['atendimentoNr064']);
    atendimentoNr065 = FolhaPppFatorRiscoDomain.getAtendimentoNr065(jsonData['atendimentoNr065']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFolhaPpp'] = idFolhaPpp != 0 ? idFolhaPpp : null;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['tipo'] = FolhaPppFatorRiscoDomain.setTipo(tipo);
    jsonData['fatorRisco'] = fatorRisco;
    jsonData['intensidade'] = intensidade;
    jsonData['tecnicaUtilizada'] = tecnicaUtilizada;
    jsonData['epcEficaz'] = FolhaPppFatorRiscoDomain.setEpcEficaz(epcEficaz);
    jsonData['epiEficaz'] = FolhaPppFatorRiscoDomain.setEpiEficaz(epiEficaz);
    jsonData['caEpi'] = caEpi;
    jsonData['atendimentoNr061'] = FolhaPppFatorRiscoDomain.setAtendimentoNr061(atendimentoNr061);
    jsonData['atendimentoNr062'] = FolhaPppFatorRiscoDomain.setAtendimentoNr062(atendimentoNr062);
    jsonData['atendimentoNr063'] = FolhaPppFatorRiscoDomain.setAtendimentoNr063(atendimentoNr063);
    jsonData['atendimentoNr064'] = FolhaPppFatorRiscoDomain.setAtendimentoNr064(atendimentoNr064);
    jsonData['atendimentoNr065'] = FolhaPppFatorRiscoDomain.setAtendimentoNr065(atendimentoNr065);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaPppFatorRiscoModel fromPlutoRow(PlutoRow row) {
    return FolhaPppFatorRiscoModel(
      id: row.cells['id']?.value,
      idFolhaPpp: row.cells['idFolhaPpp']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      tipo: row.cells['tipo']?.value,
      fatorRisco: row.cells['fatorRisco']?.value,
      intensidade: row.cells['intensidade']?.value,
      tecnicaUtilizada: row.cells['tecnicaUtilizada']?.value,
      epcEficaz: row.cells['epcEficaz']?.value,
      epiEficaz: row.cells['epiEficaz']?.value,
      caEpi: row.cells['caEpi']?.value,
      atendimentoNr061: row.cells['atendimentoNr061']?.value,
      atendimentoNr062: row.cells['atendimentoNr062']?.value,
      atendimentoNr063: row.cells['atendimentoNr063']?.value,
      atendimentoNr064: row.cells['atendimentoNr064']?.value,
      atendimentoNr065: row.cells['atendimentoNr065']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFolhaPpp': PlutoCell(value: idFolhaPpp ?? 0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'tipo': PlutoCell(value: tipo ?? ''),
        'fatorRisco': PlutoCell(value: fatorRisco ?? ''),
        'intensidade': PlutoCell(value: intensidade ?? ''),
        'tecnicaUtilizada': PlutoCell(value: tecnicaUtilizada ?? ''),
        'epcEficaz': PlutoCell(value: epcEficaz ?? ''),
        'epiEficaz': PlutoCell(value: epiEficaz ?? ''),
        'caEpi': PlutoCell(value: caEpi ?? 0),
        'atendimentoNr061': PlutoCell(value: atendimentoNr061 ?? ''),
        'atendimentoNr062': PlutoCell(value: atendimentoNr062 ?? ''),
        'atendimentoNr063': PlutoCell(value: atendimentoNr063 ?? ''),
        'atendimentoNr064': PlutoCell(value: atendimentoNr064 ?? ''),
        'atendimentoNr065': PlutoCell(value: atendimentoNr065 ?? ''),
      },
    );
  }

  FolhaPppFatorRiscoModel clone() {
    return FolhaPppFatorRiscoModel(
      id: id,
      idFolhaPpp: idFolhaPpp,
      dataInicio: dataInicio,
      dataFim: dataFim,
      tipo: tipo,
      fatorRisco: fatorRisco,
      intensidade: intensidade,
      tecnicaUtilizada: tecnicaUtilizada,
      epcEficaz: epcEficaz,
      epiEficaz: epiEficaz,
      caEpi: caEpi,
      atendimentoNr061: atendimentoNr061,
      atendimentoNr062: atendimentoNr062,
      atendimentoNr063: atendimentoNr063,
      atendimentoNr064: atendimentoNr064,
      atendimentoNr065: atendimentoNr065,
    );
  }


}