import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:folha/app/data/model/model_imports.dart';

import 'package:folha/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:folha/app/data/domain/domain_imports.dart';

class FolhaPlanoSaudeModel extends ModelBase {
  int? id;
  int? idOperadoraPlanoSaude;
  int? idColaborador;
  DateTime? dataInicio;
  String? beneficiario;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  OperadoraPlanoSaudeModel? operadoraPlanoSaudeModel;

  FolhaPlanoSaudeModel({
    this.id,
    this.idOperadoraPlanoSaude,
    this.idColaborador,
    this.dataInicio,
    this.beneficiario = '1=Somente Colaborador',
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    OperadoraPlanoSaudeModel? operadoraPlanoSaudeModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.operadoraPlanoSaudeModel = operadoraPlanoSaudeModel ?? OperadoraPlanoSaudeModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_inicio',
    'beneficiario',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Inicio',
    'Beneficiario',
  ];

  FolhaPlanoSaudeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOperadoraPlanoSaude = jsonData['idOperadoraPlanoSaude'];
    idColaborador = jsonData['idColaborador'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    beneficiario = FolhaPlanoSaudeDomain.getBeneficiario(jsonData['beneficiario']);
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    operadoraPlanoSaudeModel = jsonData['operadoraPlanoSaudeModel'] == null ? OperadoraPlanoSaudeModel() : OperadoraPlanoSaudeModel.fromJson(jsonData['operadoraPlanoSaudeModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOperadoraPlanoSaude'] = idOperadoraPlanoSaude != 0 ? idOperadoraPlanoSaude : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['beneficiario'] = FolhaPlanoSaudeDomain.setBeneficiario(beneficiario);
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['operadoraPlanoSaudeModel'] = operadoraPlanoSaudeModel?.toJson;
    jsonData['operadoraPlanoSaude'] = operadoraPlanoSaudeModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FolhaPlanoSaudeModel fromPlutoRow(PlutoRow row) {
    return FolhaPlanoSaudeModel(
      id: row.cells['id']?.value,
      idOperadoraPlanoSaude: row.cells['idOperadoraPlanoSaude']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      beneficiario: row.cells['beneficiario']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOperadoraPlanoSaude': PlutoCell(value: idOperadoraPlanoSaude ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'dataInicio': PlutoCell(value: dataInicio),
        'beneficiario': PlutoCell(value: beneficiario ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'operadoraPlanoSaude': PlutoCell(value: operadoraPlanoSaudeModel?.nome ?? ''),
      },
    );
  }

  FolhaPlanoSaudeModel clone() {
    return FolhaPlanoSaudeModel(
      id: id,
      idOperadoraPlanoSaude: idOperadoraPlanoSaude,
      idColaborador: idColaborador,
      dataInicio: dataInicio,
      beneficiario: beneficiario,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      operadoraPlanoSaudeModel: operadoraPlanoSaudeModel?.clone(),
    );
  }


}