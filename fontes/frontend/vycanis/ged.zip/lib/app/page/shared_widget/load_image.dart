import 'dart:io';
import 'package:ged/app/page/shared_widget/input/input_imports.dart';
import 'package:get/get.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

class LoadImage extends StatefulWidget {
  final Widget widgetFilho;
  final Function showImageCallBack;

  const LoadImage({Key? key, required this.widgetFilho, required this.showImageCallBack}) : super(key: key);

  @override
  LoadImageState createState() => LoadImageState();
}

class LoadImageState extends State<LoadImage> {
  final ImagePicker _imagePicker = ImagePicker();
  final _imageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _showImagePicker(context);
      },
      child: widget.widgetFilho,
    );
  }

  void _showImagePicker(context) {
    _imageController.text = '';
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(child: Wrap(children: _getImportImageOptions()));
      },
    );
  }

  List<Widget> _getImportImageOptions() {
    List<Widget> resultList = [];
    resultList.add(
      ListTile(
        leading: const Padding(padding: EdgeInsets.all(5), child: Icon(Icons.cloud_download)),
        title: _getEditUrl(),
        onTap: () async {
          final ByteData imageData = await NetworkAssetBundle(Uri.parse(_imageController.text)).load('');
          widget.showImageCallBack(imageData);
          Get.back();
        },
      ),
    );
    resultList.add(
      ListTile(
        leading: const Icon(Icons.file_copy),
        title: const Text('Carregar Imagem'),
        onTap: () async {
          FilePickerResult? selectedFile = await FilePicker.platform.pickFiles(dialogTitle: 'Selecione a imagem desejada');
          if (selectedFile != null) {
            File file = File(selectedFile.files.first.path!);
            await widget.showImageCallBack(file.readAsBytesSync());
          }
          if (!mounted) return;
          Navigator.pop(context);
        },
      ),
    );

    if (GetPlatform.isMobile) {
      resultList.add(
        ListTile(
          leading: const Icon(Icons.photo_library),
          title: const Text('Galeria de Imagens'),
          onTap: () {
            _getImageFromGallery();
            Navigator.pop(context);
          },
        ),
      );
      resultList.add(
        ListTile(
          leading: const Icon(Icons.photo_camera),
          title: const Text('Câmera'),
          onTap: () {
            _getImageFromCamera();
            Navigator.pop(context);
          },
        ),
      );
    }
    return resultList;
  }

  _getImageFromCamera() async {
    final pickedFile = await _imagePicker.pickImage(source: ImageSource.camera, imageQuality: 50);
    widget.showImageCallBack(await pickedFile?.readAsBytes());
  }

  _getImageFromGallery() async {
    final pickedFile = await _imagePicker.pickImage(source: ImageSource.gallery, imageQuality: 50);
    if (pickedFile != null) {
      widget.showImageCallBack(await pickedFile.readAsBytes());
    }
  }

  Widget _getEditUrl() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 10, left: 0, right: 0),
          child: TextFormField(controller: _imageController, decoration: inputDecoration(hintText: 'Informe a URL para a imagem', labelText: 'URL da Imagem', usePadding: true), onChanged: (text) {}),
        ),
      ],
    );
  }
}
