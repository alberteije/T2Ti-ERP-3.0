import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:ged/app/page/shared_widget/shared_widget_imports.dart';
import 'package:ged/app/data/domain/domain_imports.dart';
import 'package:ged/app/controller/ged_documento_detalhe_controller.dart';
import 'package:ged/app/infra/infra_imports.dart';
import 'package:ged/app/page/shared_widget/input/input_imports.dart';

class GedDocumentoDetalheEditPage extends StatelessWidget {
	GedDocumentoDetalheEditPage({Key? key}) : super(key: key);
	final gedDocumentoDetalheController = Get.find<GedDocumentoDetalheController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: gedDocumentoDetalheController.gedDocumentoDetalheScaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ gedDocumentoDetalheController.screenTitle } - ${ gedDocumentoDetalheController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
            IconButton(
              onPressed: gedDocumentoDetalheController.openHistory,
              icon: const Icon(Icons.history),
              tooltip: 'Visualizar Versionamento',
            ),
            IconButton(
              onPressed: gedDocumentoDetalheController.getDocument,
              icon: const Icon(Icons.document_scanner_outlined),
              tooltip: 'Carregar Documento',
            ),
						saveButton(onPressed: gedDocumentoDetalheController.save),
						cancelAndExitButton(onPressed: gedDocumentoDetalheController.preventDataLoss),
					]
				),
				body: Obx( () => SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: gedDocumentoDetalheController.gedDocumentoDetalheFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: gedDocumentoDetalheController.scrollController,
							child: SingleChildScrollView(
								controller: gedDocumentoDetalheController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: gedDocumentoDetalheController.gedTipoDocumentoModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Id Ged Tipo Documento',
																			labelText: 'Tipo Documento *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: gedDocumentoDetalheController.callGedTipoDocumentoLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: gedDocumentoDetalheController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																gedDocumentoDetalheController.gedDocumentoDetalheModel.nome = text;
																gedDocumentoDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: gedDocumentoDetalheController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																gedDocumentoDetalheController.gedDocumentoDetalheModel.descricao = text;
																gedDocumentoDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 250,
                              maxLines: 3,
															controller: gedDocumentoDetalheController.palavrasChaveController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Palavras Chave',
																labelText: 'Palavras Chave',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																gedDocumentoDetalheController.gedDocumentoDetalheModel.palavrasChave = text;
																gedDocumentoDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: gedDocumentoDetalheController.podeExcluirController,
															labelText: 'Pode Excluir',
															hintText: 'Informe os dados para o campo Pode Excluir',
															items: GedDocumentoDetalheDomain.podeExcluirListDropdown,
															onChanged: (dynamic newValue) {
																gedDocumentoDetalheController.gedDocumentoDetalheModel.podeExcluir = newValue;
																gedDocumentoDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: gedDocumentoDetalheController.podeAlterarController,
															labelText: 'Pode Alterar',
															hintText: 'Informe os dados para o campo Pode Alterar',
															items: GedDocumentoDetalheDomain.podeAlterarListDropdown,
															onChanged: (dynamic newValue) {
																gedDocumentoDetalheController.gedDocumentoDetalheModel.podeAlterar = newValue;
																gedDocumentoDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Fim Vigencia',
																labelText: 'Data Fim Vigencia',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: gedDocumentoDetalheController.dataFimVigenciaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	gedDocumentoDetalheController.gedDocumentoDetalheModel.dataFimVigencia = value;
																	gedDocumentoDetalheController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),

                    BootstrapRow(
                      height: 60,
                      children: <BootstrapCol>[
                        BootstrapCol(
                          sizes: 'col-12',
                          child: LoadImage(
                            widgetFilho: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 10),
                              height: 200,
                              child: FittedBox(
                                fit: BoxFit.contain,
                                child: gedDocumentoDetalheController.gedLastVersaoDocumentoModel.caminho == null ? Image.asset(Constants.logotipo) : Image.memory(base64Decode(gedDocumentoDetalheController.gedLastVersaoDocumentoModel.caminho!)),
                              ),
                            ),
                            showImageCallBack: gedDocumentoDetalheController.getImage,
                          ),
                        ),
                        BootstrapCol(
                          sizes: 'col-12',
                          child: Row(children: [
                            const Text('Versão do Documento: '),
                            const SizedBox(width: 5,),
                            Text(gedDocumentoDetalheController.gedLastVersaoDocumentoModel.versao == null ? 'Nenhuma versão carregada' : gedDocumentoDetalheController.gedLastVersaoDocumentoModel.versao.toString()), // TODO: use os arquivos de tradução
                          ],)
                        ),
                      ],
                    ),

										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),),
			);
	}
}
