import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:ged/app/controller/ged_documento_cabecalho_controller.dart';
import 'package:ged/app/page/shared_widget/shared_widget_imports.dart';

class GedDocumentoCabecalhoTabPage extends StatelessWidget {
  GedDocumentoCabecalhoTabPage({Key? key}) : super(key: key);
  final gedDocumentoCabecalhoController = Get.find<GedDocumentoCabecalhoController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          gedDocumentoCabecalhoController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: gedDocumentoCabecalhoController.gedDocumentoCabecalhoTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ gedDocumentoCabecalhoController.screenTitle } - ${ gedDocumentoCabecalhoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: gedDocumentoCabecalhoController.save),
						cancelAndExitButton(onPressed: gedDocumentoCabecalhoController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: gedDocumentoCabecalhoController.tabController,
                  children: gedDocumentoCabecalhoController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: gedDocumentoCabecalhoController.tabController,
                onTap: gedDocumentoCabecalhoController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: gedDocumentoCabecalhoController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
