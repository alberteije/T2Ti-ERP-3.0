import 'package:ged/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ged/app/controller/controller_imports.dart';
import 'package:ged/app/data/model/model_imports.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

class GedVersaoDocumentoController extends ControllerBase<GedVersaoDocumentoModel, void> {

  GedVersaoDocumentoController() : super(repository: null) {
    dbColumns = GedVersaoDocumentoModel.dbColumns;
    aliasColumns = GedVersaoDocumentoModel.aliasColumns;
    gridColumns = gedVersaoDocumentoGridColumns();
    functionName = "ged_versao_documento";
    screenTitle = "Versionamento";
  }

  @override
  GedVersaoDocumentoModel createNewModel() => GedVersaoDocumentoModel();

  List<GedVersaoDocumentoModel> get gedVersaoDocumentoModelList => Get.find<GedDocumentoDetalheController>().gedDocumentoDetalheModel.gedVersaoDocumentoModelList ?? [];

  @override
  final standardFieldForFilter = GedVersaoDocumentoModel.aliasColumns[GedVersaoDocumentoModel.dbColumns.indexOf('acao')];

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['acao'],
    'secondaryColumns': ['versao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((gedVersaoDocumento) => gedVersaoDocumento.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(gedVersaoDocumentoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  @override
  Future<void> save() async {}

  @override
  void onClose() {}
}