import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:ged/app/infra/infra_imports.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:file_picker/file_picker.dart';

import 'package:ged/app/page/shared_widget/input/input_imports.dart';
import 'package:ged/app/routes/app_routes.dart';
import 'package:ged/app/page/page_imports.dart';
import 'package:ged/app/page/shared_widget/message_dialog.dart';
import 'package:ged/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ged/app/controller/controller_imports.dart';
import 'package:ged/app/data/model/model_imports.dart';

class GedDocumentoDetalheController extends ControllerBase<GedDocumentoDetalheModel, void> {

  GedDocumentoDetalheController() : super(repository: null) {
    dbColumns = GedDocumentoDetalheModel.dbColumns;
    aliasColumns = GedDocumentoDetalheModel.aliasColumns;
    gridColumns = gedDocumentoDetalheGridColumns();
    functionName = "ged_documento_detalhe";
    screenTitle = "Detalhes";
  }

  final _gedDocumentoDetalheModel = GedDocumentoDetalheModel().obs;
  GedDocumentoDetalheModel get gedDocumentoDetalheModel => _gedDocumentoDetalheModel.value;
  set gedDocumentoDetalheModel(value) => _gedDocumentoDetalheModel.value = value ?? GedDocumentoDetalheModel();

	final _gedLastVersaoDocumentoModel = GedVersaoDocumentoModel().obs;
	GedVersaoDocumentoModel get gedLastVersaoDocumentoModel => _gedLastVersaoDocumentoModel.value;
	set gedLastVersaoDocumentoModel(value) => _gedLastVersaoDocumentoModel.value = value ?? GedVersaoDocumentoModel();

  List<GedDocumentoDetalheModel> get gedDocumentoDetalheModelList => Get.find<GedDocumentoCabecalhoController>().currentModel.gedDocumentoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final gedDocumentoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final gedDocumentoDetalheFormKey = GlobalKey<FormState>();

  @override
  GedDocumentoDetalheModel createNewModel() => GedDocumentoDetalheModel();

  @override
  final standardFieldForFilter = GedDocumentoDetalheModel.aliasColumns[GedDocumentoDetalheModel.dbColumns.indexOf('nome')];

  final gedTipoDocumentoModelController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final palavrasChaveController = TextEditingController();
  final podeExcluirController = CustomDropdownButtonController('S');
  final podeAlterarController = CustomDropdownButtonController('S');
  final assinadoController = CustomDropdownButtonController('S');
  final dataFimVigenciaController = DatePickerItemController(null);
  final dataExclusaoController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((gedDocumentoDetalhe) => gedDocumentoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(gedDocumentoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    gedDocumentoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => GedDocumentoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    gedTipoDocumentoModelController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    palavrasChaveController.text = '';
    podeExcluirController.selected = 'S';
    podeAlterarController.selected = 'S';
    assinadoController.selected = 'S';
    dataFimVigenciaController.date = null;
    dataExclusaoController.date = null;
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = gedDocumentoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    gedDocumentoDetalheModel = model.clone();
		gedDocumentoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => GedDocumentoDetalheEditPage());
  }

  void updateControllersFromModel() {
    gedTipoDocumentoModelController.text = gedDocumentoDetalheModel.gedTipoDocumentoModel?.nome?.toString() ?? '';
    nomeController.text = gedDocumentoDetalheModel.nome ?? '';
    descricaoController.text = gedDocumentoDetalheModel.descricao ?? '';
    palavrasChaveController.text = gedDocumentoDetalheModel.palavrasChave ?? '';
    podeExcluirController.selected = gedDocumentoDetalheModel.podeExcluir ?? 'S';
    podeAlterarController.selected = gedDocumentoDetalheModel.podeAlterar ?? 'S';
    assinadoController.selected = gedDocumentoDetalheModel.assinado ?? 'S';
    dataFimVigenciaController.date = gedDocumentoDetalheModel.dataFimVigencia;
    dataExclusaoController.date = gedDocumentoDetalheModel.dataExclusao;
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!gedDocumentoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        gedDocumentoDetalheModelList.insert(0, gedDocumentoDetalheModel.clone());
      } else {
        final index = gedDocumentoDetalheModelList.indexWhere((m) => m.tempId == gedDocumentoDetalheModel.tempId);
        if (index >= 0) {
          gedDocumentoDetalheModelList[index] = gedDocumentoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callGedTipoDocumentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Documento]'; 
		lookupController.route = '/ged-tipo-documento/'; 
		lookupController.gridColumns = gedTipoDocumentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = GedTipoDocumentoModel.aliasColumns; 
		lookupController.dbColumns = GedTipoDocumentoModel.dbColumns; 
		lookupController.standardColumn = GedTipoDocumentoModel.aliasColumns[GedTipoDocumentoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			gedDocumentoDetalheModel.idGedTipoDocumento = plutoRowResult.cells['id']!.value; 
			gedDocumentoDetalheModel.gedTipoDocumentoModel = GedTipoDocumentoModel.fromPlutoRow(plutoRowResult); 
			gedTipoDocumentoModelController.text = gedDocumentoDetalheModel.gedTipoDocumentoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}

  // captura documento
  Future getDocument() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.any);
    if (result != null) {
      Uint8List? fileBytes;
      if (GetPlatform.isWindows) {
        fileBytes = Uint8List.fromList(File(result.files[0].path!).readAsBytesSync());
      } else {
        fileBytes = result.files.first.bytes!;
      }
      final fileSize = fileBytes.lengthInBytes / 1024 / 1024;
      if (fileSize > gedDocumentoDetalheModel.gedTipoDocumentoModel!.tamanhoMaximo!) {
        showErrorSnackBar(message: 'Tamanho do arquivo ultrapassa o permitido');
      } else {
        gedDocumentoDetalheModel.gedVersaoDocumentoModelList ??= [];
        GedVersaoDocumentoModel gedVersaoDocumentoModel = GedVersaoDocumentoModel(
          idColaborador: Session.loggedInUser.idColaborador,
          viewPessoaColaboradorModel: ViewPessoaColaboradorModel(id: Session.loggedInUser.idColaborador, nome: Session.loggedInUser.pessoaNome),
          acao: gedDocumentoDetalheModel.gedVersaoDocumentoModelList!.isEmpty ? 'I' : 'A',
          hashArquivo: await Util.gerarHashArquivo(fileBytes),
          caminho: base64.encode(fileBytes),
          dataVersao: DateTime.now(),
          horaVersao: Util.timeFormat(DateTime.now()),
          versao: (gedDocumentoDetalheModel.gedVersaoDocumentoModelList?.length ?? 0) + 1,
        );
        gedDocumentoDetalheModel.gedVersaoDocumentoModelList!.add(gedVersaoDocumentoModel);
        formWasChangedDetail = true;
      }
    }
  }

  // captura imagem
  Future getImage(Uint8List data) async {
    gedDocumentoDetalheModel.gedVersaoDocumentoModelList ??= [];
    gedLastVersaoDocumentoModel = GedVersaoDocumentoModel(
      idColaborador: Session.loggedInUser.idColaborador,
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel(id: Session.loggedInUser.idColaborador, nome: Session.loggedInUser.pessoaNome),
      acao: gedDocumentoDetalheModel.gedVersaoDocumentoModelList!.isEmpty ? 'I' : 'A',
      hashArquivo: await Util.gerarHashArquivo(data),
      caminho: base64.encode(data),
      dataVersao: DateTime.now(),
      horaVersao: Util.timeFormat(DateTime.now()),
      versao: (gedDocumentoDetalheModel.gedVersaoDocumentoModelList?.length ?? 0) + 1,
    );
    gedDocumentoDetalheModel.gedVersaoDocumentoModelList!.add(gedLastVersaoDocumentoModel);
    formWasChangedDetail = true;
    update();
  }

  void openHistory() {
    Get.dialog(
      const AlertDialog(
        content: GedVersaoDocumentoListPage(),
      )
    );
  }

  void loadLastVersion() {
    gedDocumentoDetalheModel.gedVersaoDocumentoModelList ??= [];
    if (gedDocumentoDetalheModel.gedVersaoDocumentoModelList!.isNotEmpty) {
      gedLastVersaoDocumentoModel = gedDocumentoDetalheModel.gedVersaoDocumentoModelList![gedDocumentoDetalheModel.gedVersaoDocumentoModelList!.length-1];
    } else {
      gedLastVersaoDocumentoModel = GedVersaoDocumentoModel();
    }
  }

  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      gedDocumentoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    gedTipoDocumentoModelController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    palavrasChaveController.dispose();
    podeExcluirController.dispose();
    podeAlterarController.dispose();
    assinadoController.dispose();
    dataFimVigenciaController.dispose();
    dataExclusaoController.dispose();
  }

}