import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:ged/app/page/shared_widget/message_dialog.dart';
import 'package:ged/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ged/app/routes/app_routes.dart';
import 'package:ged/app/controller/controller_imports.dart';
import 'package:ged/app/data/model/model_imports.dart';
import 'package:ged/app/data/repository/ged_tipo_documento_repository.dart';

class GedTipoDocumentoController extends ControllerBase<GedTipoDocumentoModel, GedTipoDocumentoRepository> {

  GedTipoDocumentoController({required super.repository}) {
    dbColumns = GedTipoDocumentoModel.dbColumns;
    aliasColumns = GedTipoDocumentoModel.aliasColumns;
    gridColumns = gedTipoDocumentoGridColumns();
    functionName = "ged_tipo_documento";
    screenTitle = "Tipo Documento";
  }

  @override
  GedTipoDocumentoModel createNewModel() => GedTipoDocumentoModel();

  @override
  final standardFieldForFilter = GedTipoDocumentoModel.aliasColumns[GedTipoDocumentoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final tamanhoMaximoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['tamanho_maximo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((gedTipoDocumento) => gedTipoDocumento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.gedTipoDocumentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    tamanhoMaximoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.gedTipoDocumentoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    tamanhoMaximoController.updateValue(currentModel.tamanhoMaximo ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(gedTipoDocumentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    tamanhoMaximoController.dispose();
    super.onClose();
  }

}