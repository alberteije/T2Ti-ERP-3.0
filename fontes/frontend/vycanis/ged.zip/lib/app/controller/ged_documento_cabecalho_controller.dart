import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:ged/app/page/shared_widget/input/input_imports.dart';

import 'package:ged/app/infra/infra_imports.dart';
import 'package:ged/app/page/page_imports.dart';
import 'package:ged/app/page/shared_widget/message_dialog.dart';
import 'package:ged/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ged/app/routes/app_routes.dart';
import 'package:ged/app/controller/controller_imports.dart';
import 'package:ged/app/data/model/model_imports.dart';
import 'package:ged/app/data/repository/ged_documento_cabecalho_repository.dart';

class GedDocumentoCabecalhoController extends ControllerBase<GedDocumentoCabecalhoModel, GedDocumentoCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  GedDocumentoCabecalhoController({required super.repository}) {
    dbColumns = GedDocumentoCabecalhoModel.dbColumns;
    aliasColumns = GedDocumentoCabecalhoModel.aliasColumns;
    gridColumns = gedDocumentoCabecalhoGridColumns();
    functionName = "ged_documento_cabecalho";
    screenTitle = "Documento";
  }

  final gedDocumentoCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final gedDocumentoCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final gedDocumentoCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  GedDocumentoCabecalhoModel createNewModel() => GedDocumentoCabecalhoModel();

  @override
  final standardFieldForFilter = GedDocumentoCabecalhoModel.aliasColumns[GedDocumentoCabecalhoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final dataInclusaoController = DatePickerItemController(null);
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['data_inclusao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((gedDocumentoCabecalho) => gedDocumentoCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.gedDocumentoCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    dataInclusaoController.date = null;
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.gedDocumentoCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<GedDocumentoDetalheController>(GedDocumentoDetalheController());

    // Versionamento
    Get.put<GedVersaoDocumentoController>(GedVersaoDocumentoController());
  }

	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<GedDocumentoDetalheController>();

    // Versionamento
    Get.delete<GedVersaoDocumentoController>();
	}

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    dataInclusaoController.date = currentModel.dataInclusao;
    descricaoController.text = currentModel.descricao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final gedDocumentoDetalheController = Get.find<GedDocumentoDetalheController>(); 
		gedDocumentoDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(gedDocumentoCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Documento', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      GedDocumentoCabecalhoEditPage(),
      const GedDocumentoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<GedDocumentoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }

  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    dataInclusaoController.dispose();
    descricaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }
}