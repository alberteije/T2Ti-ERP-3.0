import 'package:get/get.dart';
import 'package:ged/app/controller/ged_versao_documento_controller.dart';

class GedVersaoDocumentoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<GedVersaoDocumentoController>(() => GedVersaoDocumentoController()),
		];
	}
}
