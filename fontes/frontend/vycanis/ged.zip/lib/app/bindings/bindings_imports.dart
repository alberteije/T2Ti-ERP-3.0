export 'login_bindings.dart';
export 'ged_documento_cabecalho_bindings.dart';
export 'ged_tipo_documento_bindings.dart';
export 'ged_versao_documento_bindings.dart';