import 'package:ged/app/data/provider/api/api_provider_base.dart';
import 'package:ged/app/data/model/model_imports.dart';

class GedDocumentoCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/ged-documento-cabecalho';

  Future<List<GedDocumentoCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GedDocumentoCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GedDocumentoCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GedDocumentoCabecalhoModel.fromJson(json),
    );
  }

  Future<GedDocumentoCabecalhoModel?>? insert(GedDocumentoCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GedDocumentoCabecalhoModel.fromJson(json),
    );
  }

  Future<GedDocumentoCabecalhoModel?>? update(GedDocumentoCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GedDocumentoCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
