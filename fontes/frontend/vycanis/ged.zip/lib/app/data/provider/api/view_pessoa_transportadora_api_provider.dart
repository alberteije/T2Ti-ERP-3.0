import 'package:ged/app/data/provider/api/api_provider_base.dart';
import 'package:ged/app/data/model/model_imports.dart';

class ViewPessoaTransportadoraApiProvider extends ApiProviderBase {
  static const _path = '/view-pessoa-transportadora';

  Future<List<ViewPessoaTransportadoraModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ViewPessoaTransportadoraModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ViewPessoaTransportadoraModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ViewPessoaTransportadoraModel.fromJson(json),
    );
  }

  Future<ViewPessoaTransportadoraModel?>? insert(ViewPessoaTransportadoraModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ViewPessoaTransportadoraModel.fromJson(json),
    );
  }

  Future<ViewPessoaTransportadoraModel?>? update(ViewPessoaTransportadoraModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ViewPessoaTransportadoraModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
