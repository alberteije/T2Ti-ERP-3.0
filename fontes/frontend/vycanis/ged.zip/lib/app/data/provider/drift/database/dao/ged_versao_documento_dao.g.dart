// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ged_versao_documento_dao.dart';

// ignore_for_file: type=lint
mixin _$GedVersaoDocumentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $GedVersaoDocumentosTable get gedVersaoDocumentos =>
      attachedDatabase.gedVersaoDocumentos;
  $GedDocumentoDetalhesTable get gedDocumentoDetalhes =>
      attachedDatabase.gedDocumentoDetalhes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
